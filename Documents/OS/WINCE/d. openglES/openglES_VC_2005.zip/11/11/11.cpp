// 11.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//
/*****************************************
* Zeus CMD - OpenGL ES Tutorial 22 : Fog *
* By Grant James (ZEUS)                  *
* http://www.zeuscmd.com                 *
*****************************************/

#define GLUTES_STATIC

#include "stdafx.h"
#include <windows.h>
#include <commctrl.h>


#include <GLES/glutes.h>
#include <GLES/glues.h>
#include <GLES/glues.c>

#pragma comment(lib, "libGLES_CM.lib")


GLuint texture[1];

float fogColor[] = { 0.5f, 0.5f, 0.5f, 1.0f };
float fogTypes[] = { GL_EXP, GL_EXP2, GL_LINEAR };

int fogType = 0;

float xrot = 0.0f;
float yrot = 0.0f;

GLfloat box[] = {
	// FRONT
	-0.5f, -0.5f,  0.5f,
	 0.5f, -0.5f,  0.5f,
	-0.5f,  0.5f,  0.5f,
	 0.5f,  0.5f,  0.5f,
	// BACK
	-0.5f, -0.5f, -0.5f,
	-0.5f,  0.5f, -0.5f,
	 0.5f, -0.5f, -0.5f,
	 0.5f,  0.5f, -0.5f,
	// LEFT
	-0.5f, -0.5f,  0.5f,
	-0.5f,  0.5f,  0.5f,
	-0.5f, -0.5f, -0.5f,
	-0.5f,  0.5f, -0.5f,
	// RIGHT
	 0.5f, -0.5f, -0.5f,
	 0.5f,  0.5f, -0.5f,
	 0.5f, -0.5f,  0.5f,
	 0.5f,  0.5f,  0.5f,
	// TOP
	-0.5f,  0.5f,  0.5f,
	 0.5f,  0.5f,  0.5f,
	 -0.5f,  0.5f, -0.5f,
	 0.5f,  0.5f, -0.5f,
	// BOTTOM
	-0.5f, -0.5f,  0.5f,
	-0.5f, -0.5f, -0.5f,
	 0.5f, -0.5f,  0.5f,
	 0.5f, -0.5f, -0.5f,
};

GLfloat texCoords[] = {
	// FRONT
	 0.0f, 0.0f,
	 1.0f, 0.0f,
	 0.0f, 1.0f,
	 1.0f, 1.0f,
	// BACK
	 1.0f, 0.0f,
	 1.0f, 1.0f,
	 0.0f, 0.0f,
	 0.0f, 1.0f,
	// LEFT
	 1.0f, 0.0f,
	 1.0f, 1.0f,
	 0.0f, 0.0f,
	 0.0f, 1.0f,
	// RIGHT
	 1.0f, 0.0f,
	 1.0f, 1.0f,
	 0.0f, 0.0f,
	 0.0f, 1.0f,
	// TOP
	 0.0f, 0.0f,
	 1.0f, 0.0f,
	 0.0f, 1.0f,
	 1.0f, 1.0f,
	// BOTTOM
	 1.0f, 0.0f,
	 1.0f, 1.0f,
	 0.0f, 0.0f,
	 0.0f, 1.0f
};

float lightAmbient[] = { 1.0f, 1.0f, 1.0f, 1.0f };

float matAmbient[] = { 1.0f, 1.0f, 1.0f, 1.0f };

unsigned char *loadBMP(char *filename, BITMAPINFOHEADER *bmpInfo)
{
	FILE *file;
	BITMAPFILEHEADER bmpFile;
	unsigned char *bmpImage = NULL;
	unsigned char tmpRGB;

	TCHAR path[256];
	char fullPath[256];
	GetModuleFileName(NULL, path, 256);

	TCHAR *pos = wcsrchr(path, '\\');
	*(pos + 1) = '\0';
	
	wcstombs(fullPath, path, 256);
	
	strcat(fullPath, filename);

	file = fopen(fullPath,"rb");

	if (!file)
	{
		MessageBox(NULL, L"Can't Find Bitmap", L"Error", MB_OK);
		return NULL;
	}

	fread(&bmpFile,sizeof(BITMAPFILEHEADER),1,file);

	if (bmpFile.bfType != 0x4D42)
	{
		MessageBox(NULL, L"Incorrect texture type", L"Error", MB_OK);
		fclose(file);
		return NULL;
	}

	fread(bmpInfo,sizeof(BITMAPINFOHEADER),1,file);

	fseek(file,bmpFile.bfOffBits,SEEK_SET);

	bmpImage = new unsigned char[bmpInfo->biSizeImage];

	if (!bmpImage)
	{
		MessageBox(NULL, L"Out of Memory", L"Error", MB_OK);
		delete[] bmpImage;
		fclose(file);
		return NULL;
	}

	fread(bmpImage,1,bmpInfo->biSizeImage,file);

	if (!bmpImage)
	{
		MessageBox(NULL, L"Error reading bitmap", L"Error", MB_OK);
		fclose(file);
		return NULL;
	}

	for (unsigned int i = 0; i < bmpInfo->biSizeImage; i+=3)
	{
		tmpRGB = bmpImage[i];
		bmpImage[i] = bmpImage[i+2];
		bmpImage[i+2] = tmpRGB;
	}

	fclose(file);

	return bmpImage;
}

bool loadTextures()
{
	BITMAPINFOHEADER info;
	unsigned char *bitmap = NULL;
	
	bitmap = loadBMP("block.bmp", &info);

	if (!bitmap)
		return false;

	glGenTextures(1, texture);

	glBindTexture(GL_TEXTURE_2D, texture[0]);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, info.biWidth,
		info.biHeight, 0, GL_RGB, GL_UNSIGNED_BYTE,
		bitmap);

	glTexParameterf(GL_TEXTURE_2D, 
		GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D,
		GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	delete[] bitmap;

	return true;
}

bool init()
{
	if (!loadTextures())
	{
		MessageBox(NULL, L"Error loading textures", L"Error", MB_OK);
		return false;
	}

	glFogf(GL_FOG_MODE, GL_EXP);
	glFogfv(GL_FOG_COLOR, fogColor);
	glFogf(GL_FOG_DENSITY, 0.35f);
	glHint(GL_FOG_HINT, GL_DONT_CARE);
	glFogf(GL_FOG_START, 1.0f);
	glFogf(GL_FOG_END, 5.0f);
	glEnable(GL_FOG);

	glEnable(GL_TEXTURE_2D);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, matAmbient);
	
	glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmbient);

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);

	glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
	glClearDepthf(1.0f);

	glVertexPointer(3, GL_FLOAT, 0, box);
	glTexCoordPointer(2, GL_FLOAT, 0, texCoords);
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);

	glEnable(GL_CULL_FACE);
	glShadeModel(GL_SMOOTH);

	return true;
}

void display()
{
   glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glLoadIdentity();

   glTranslatef(0.0f, 0.0f, -5.0f);

   glRotatef(xrot, 1.0f, 0.0f, 0.0f);
   glRotatef(yrot, 0.0f, 1.0f, 0.0f);

   glScalef(2.0f, 2.0f, 2.0f);

   // FRONT AND BACK
   glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
   glNormal3f(0.0f, 0.0f, 1.0f);
   glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
   glNormal3f(0.0f, 0.0f, -1.0f);
   glDrawArrays(GL_TRIANGLE_STRIP, 4, 4);

   // LEFT AND RIGHT
   glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
   glNormal3f(-1.0f, 0.0f, 0.0f);
   glDrawArrays(GL_TRIANGLE_STRIP, 8, 4);
   glNormal3f(1.0f, 0.0f, 0.0f);
   glDrawArrays(GL_TRIANGLE_STRIP, 12, 4);

   // TOP AND BOTTOM
   glColor4f(0.0f, 0.0f, 1.0f, 1.0f);
   glNormal3f(0.0f, 1.0f, 0.0f);
   glDrawArrays(GL_TRIANGLE_STRIP, 16, 4);
   glNormal3f(0.0f, -1.0f, 0.0f);
   glDrawArrays(GL_TRIANGLE_STRIP, 20, 4);

   glFlush ();
   glutSwapBuffers();
}

void idle()
{
	xrot += 2.0f;
	yrot += 3.0f;

	glutPostRedisplay();
}

void keyboard2(int key, int x, int y)
{
	switch(key)
	{
	case GLUT_KEY_UP : exit(0); break;
	}
}

void reshape(int width, int height)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glViewport(0, 0, width, height);
	gluPerspectivef(45.0f, 1.0f * width / height, 0.1f, 100.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void menu(int entry)
{
	switch(entry)
	{
	case 1 : exit(0); break;
	case 2 :
		if (glIsEnabled(GL_LIGHTING))
			glDisable(GL_LIGHTING);
		else
			glEnable(GL_LIGHTING);
		break;
	case 3 :
		++fogType %= 3;
		glFogf(GL_FOG_MODE, fogTypes[fogType]);
		break;
	}
}

int _tmain(int argc, _TCHAR* argv[])

{
	glutInit(&argc, (char **)argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);

	glutCreateWindow("22 - Fog");

	if (!init())
		return 1;

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutSpecialFunc(keyboard2);

	glutIdleFunc(idle);

	glutCreateMenu(menu);
	glutAddMenuEntry("Fog Mode", 3);
	glutAddMenuEntry("Toggle Lighting", 2);
	glutAddMenuEntry("Quit", 1);

	glutAttachMenu(GLUT_LEFT_BUTTON);
	
	glutMainLoop();

	return 0;
}
