// 22.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//
/******************************************************
* Zeus CMD - OpenGL ES Tutorial 8 : Color And Shading *
* By Grant James (ZEUS)                               *
* http://www.zeuscmd.com                              *
******************************************************/

#define GLUTES_STATIC


#include "stdafx.h"
#include <windows.h>
#include <commctrl.h>


#include <GLES/glutes.h>
#include <GLES/glues.h>
#include <GLES/glues.c>

#pragma comment(lib, "libGLES_CM.lib")


float xrot = 0.0f;
float yrot = 0.0f;

GLfloat box[] = {
	// FRONT
	-0.5f, -0.5f,  0.5f,
	 0.5f, -0.5f,  0.5f,
	-0.5f,  0.5f,  0.5f,
	 0.5f,  0.5f,  0.5f,
	// BACK
	-0.5f, -0.5f, -0.5f,
	-0.5f,  0.5f, -0.5f,
	 0.5f, -0.5f, -0.5f,
	 0.5f,  0.5f, -0.5f,
	// LEFT
	-0.5f, -0.5f,  0.5f,
	-0.5f,  0.5f,  0.5f,
	-0.5f, -0.5f, -0.5f,
	-0.5f,  0.5f, -0.5f,
	// RIGHT
	 0.5f, -0.5f, -0.5f,
	 0.5f,  0.5f, -0.5f,
	 0.5f, -0.5f,  0.5f,
	 0.5f,  0.5f,  0.5f,
	// TOP
	-0.5f,  0.5f,  0.5f,
	 0.5f,  0.5f,  0.5f,
	 -0.5f,  0.5f, -0.5f,
	 0.5f,  0.5f, -0.5f,
	// BOTTOM
	-0.5f, -0.5f,  0.5f,
	-0.5f, -0.5f, -0.5f,
	 0.5f, -0.5f,  0.5f,
	 0.5f, -0.5f, -0.5f,
};

void init()
{
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);

	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClearDepthf(1.0f);

	glVertexPointer(3, GL_FLOAT, 0, box);
	glEnableClientState(GL_VERTEX_ARRAY);

	glShadeModel(GL_FLAT);
}

void display()
{
   glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glLoadIdentity();

   gluLookAtf(
		0.0f, 0.0f, 3.0f,
		0.0f, 0.0f, 0.0f,
		0.0f, 1.0f, 0.0f);

   glRotatef(xrot, 1.0f, 0.0f, 0.0f);
   glRotatef(yrot, 0.0f, 1.0f, 0.0f);

   glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
   glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
   glDrawArrays(GL_TRIANGLE_STRIP, 4, 4);

   glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
   glDrawArrays(GL_TRIANGLE_STRIP, 8, 4);
   glDrawArrays(GL_TRIANGLE_STRIP, 12, 4);

   glColor4f(0.0f, 0.0f, 1.0f, 1.0f);
   glDrawArrays(GL_TRIANGLE_STRIP, 16, 4);
   glDrawArrays(GL_TRIANGLE_STRIP, 20, 4);

   glFlush ();
   glutSwapBuffers();
}

void idle()
{
	xrot += 2.0f;
	yrot += 3.0f;

	glutPostRedisplay();
}

void keyboard2(int key, int x, int y)
{
	switch(key)
	{
	case GLUT_KEY_UP : exit(0); break;
	}
}

void reshape(int width, int height)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glViewport(0, 0, width, height);
	gluPerspectivef(45.0f, 1.0f * width / height, 1.0f, 100.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void menu(int entry)
{
	switch(entry)
	{
	case 1 : exit(0); break;
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	glutInit(&argc, (char **)argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);

	glutCreateWindow("13 - 3D Shapes");

	init();

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);

	glutSpecialFunc(keyboard2);

	glutIdleFunc(idle);

		glutCreateMenu(menu);
	glutAddMenuEntry("Quit", 1);

	glutAttachMenu(GLUT_LEFT_BUTTON);

	glutMainLoop();

	return 0;
}
