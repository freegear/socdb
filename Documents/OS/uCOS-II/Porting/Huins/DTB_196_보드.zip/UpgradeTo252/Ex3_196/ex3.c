#include "..\\includes.h"
#include "..\\drivers\\key.h"
#include "..\\drivers\\lcd.h"
#include "..\\drivers\\CommRtos.h"

/********************************************************************************************/
/*                                   CONSTANT DEFINITIONS                                   */
/********************************************************************************************/
#define         KEY_ESC          0x1b
#define         TASK_STK_SIZE     100      /* Size of each task's stacks (# of WORDs)       */

#define         TASK_1_ID           1
#define         TASK_2_ID           2
#define         TASK_3_ID           3
#define         TASK_4_ID           4
#define         TASK_5_ID           5

#define         TASK_1_PRIO         1                
#define         TASK_2_PRIO         2
#define         TASK_3_PRIO         3
#define         TASK_4_PRIO         4
#define         TASK_5_PRIO         5


/********************************************************************************************/
/*                                     GLOBAL VARIABLES                                     */
/********************************************************************************************/
OS_STK          TaskStartStk[TASK_STK_SIZE];   /* TaskStart()�Լ��� ���ÿ���                */
OS_STK          Task1Stk[TASK_STK_SIZE];       /* Task #1    task stack                     */
OS_STK          Task2Stk[TASK_STK_SIZE];       /* Task #2    task stack                     */
OS_STK          Task3Stk[TASK_STK_SIZE];       /* Task #3    task stack                     */
OS_STK          Task4Stk[TASK_STK_SIZE];       /* Task #4    task stack                     */
OS_STK          Task5Stk[TASK_STK_SIZE];       /* Task #5    task stack                     */

OS_EVENT        *AckMbox;                      /* Message mailboxes for Tasks #4 and #5     */
OS_EVENT        *TxMbox;

char * movingCursor[8];

/********************************************************************************************/
/*                                  EXTERNAL GLOBAL VARIABLES                               */
/********************************************************************************************/
extern const char UserKeyMapTbl[];


/********************************************************************************************/
/*                                      FUNCTION PROTOCOLS                                  */
/********************************************************************************************/
void            TaskStart(void *data);
void            Task1(void *data);
void            Task2(void *data);
void            Task3(void *data);
void            Task4(void *data);
void            Task5(void *data);

/********************************************************************************************/
/*                                 EXTERNAL FUNCTION PROTOCOLS                              */
/********************************************************************************************/
extern void     TimeTickInit(void);

void main (void)
{
    OSInit();                                                   /* uC/OS-II�� �ʱ�ȭ�Ѵ�    */
    /* ���� �½�ũ ���� */
    OSTaskCreate(TaskStart, (void *)0, (void *)&TaskStartStk[TASK_STK_SIZE - 1], 0);
    OSStart();                                                  /* uC/OS-II �⵿            */
}


void TaskStart(void *pdat)
{
    BYTE cnt, err, sData, sentCnt;
    char dispBuf[20];
    WORD dataCnt;

    disable();                                                  /* ���ͷ�Ʈ ��Ȱ��ȭ        */  
    TimeTickInit();                                             /* Ÿ�� ƽ�� Ÿ�̸� �ʱ�ȭ  */
    enable();                                                   /* ���ͷ�Ʈ Ȱ��ȭ          */

    movingCursor[0] = "*    ";
    movingCursor[1] = " *   ";
    movingCursor[2] = "  *  ";
    movingCursor[3] = "   * ";
    movingCursor[4] = "    *";
    movingCursor[5] = "   * ";
    movingCursor[6] = "  *  ";
    movingCursor[7] = " *   ";


    AckMbox = OSMboxCreate((void *)0);                     /* Create 2 message mailboxes               */
    TxMbox  = OSMboxCreate((void *)0);

    CommInit();                                            /* Initialize Serial module                 */
    DispInit(2,16);                                        /* LCD����̹��� 2*16 ������ �ʱ�ȭ�Ѵ�     */
    KeyInit();                                             /* Initialize Keyboard module               */

    err = 0;

    err += OSTaskCreateExt(Task1, (void *)0, &Task1Stk[TASK_STK_SIZE-1], TASK_1_PRIO, 
                   TASK_1_ID, &Task1Stk[0], TASK_STK_SIZE, (void *)0, 
                   OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    err += OSTaskCreateExt(Task2, (void *)0, &Task2Stk[TASK_STK_SIZE-1], TASK_2_PRIO, 
                   TASK_2_ID, &Task2Stk[0], TASK_STK_SIZE, (void *)0, 
                   OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
                   
    err += OSTaskCreateExt(Task3, (void *)0, &Task3Stk[TASK_STK_SIZE-1], TASK_3_PRIO, 
                   TASK_3_ID, &Task3Stk[0], TASK_STK_SIZE, (void *)0, 
                   OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    err += OSTaskCreateExt(Task4, (void *)0, &Task4Stk[TASK_STK_SIZE-1], TASK_4_PRIO, 
                   TASK_4_ID, &Task4Stk[0], TASK_STK_SIZE, (void *)0, 
                   OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    err += OSTaskCreateExt(Task5, (void *)0, &Task5Stk[TASK_STK_SIZE-1], TASK_5_PRIO, 
                   TASK_5_ID, &Task5Stk[0], TASK_STK_SIZE, (void *)0, 
                   OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    if(err)
    {
        /* err ������ � ���� ������ �½�ũ �������� ������ �߻��� ���� */
        DispStr(0,0,"Error!");
        while(1);
    }
    else
    {
        /* ���� ���� ��� �½�ũ���� �����Ǿ��� */
        DispStr(0,0,"No Error!");
        OSTimeDly(OS_TICKS_PER_SEC * 5);
        DispClrLine(0);
    }

    dataCnt = cnt = 0;

    for (;;) {
        sData = CommGetChar(0, &err);
        if(sData==KEY_ESC) asm rst;

        err = CommPutChar(sData, 0);
        if(err != COMM_NO_ERR)
        {
            sprintf(dispBuf,"%d",err);
            DispStr(11,1,dispBuf);
        }
        sprintf(dispBuf, "%5u", ++dataCnt);

        if(cnt>10)
        {
            cnt = 0;
            DispStr(0,0,"           ");
        }

        DispStr(0,11,dispBuf);
        DispChar(0,cnt++,sData);
    }
}

void  Task1 (void *data)
{
    BYTE err,key,cnt;
    WORD i, j, k;

    cnt = key = k = 0;

    while(1)
    {
        key = KeyGetKey(0);
        key = UserKeyMapTbl[key];
        
        err = CommPutChar(key, 0);
        DispChar(1,14,key);
    }
}

void  Task2 (void *data)
{
    BYTE i, err;

    data = data;

    i = 0;
    for (;;) {
        DispStr(1,0,movingCursor[i]);
        OSTimeDly(5);
        if(++i>7) i = 0;
    }
}

void  Task3 (void *data)
{
    BYTE i, err;

    data = data;

    i = 0;
    for (;;) {
        DispStr(1,5,movingCursor[i]);
        OSTimeDly(10);
        if(++i>7) i = 0;
    }
}

void  Task4 (void *data)
{
    char   txmsg;
    INT8U  err;
    
    
    data  = data;
    txmsg = 'A';
    for (;;) {
        while (txmsg <= 'Z') {
            OSMboxPost(TxMbox, (void *)&txmsg);     /* Send message to Task #5                            */  
            OSMboxPend(AckMbox, 0, &err);           /* Wait for acknowledgement from Task #5              */
            txmsg++;                                /* Next message to send                               */
        }                                                                                                   
        txmsg = 'A';                                /* Start new series of messages                       */
    }
}

void  Task5 (void *data)
{
    char  *rxmsg;
    char  string[20];
    INT8U  err;
    
    
    data = data;
    for (;;) {
        rxmsg = (char *)OSMboxPend(TxMbox, 0, &err); /* Wait for message from Task #4 */
        DispChar(1,10,*rxmsg);

        OSTimeDlyHMSM(0, 0, 1, 0);                   /* Wait 1 second                 */
        OSMboxPost(AckMbox, (void *)1);              /* Acknowledge reception of msg  */
    }
}

