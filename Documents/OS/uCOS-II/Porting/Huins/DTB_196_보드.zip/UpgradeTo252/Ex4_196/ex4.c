#include "..\\includes.h"
#include "..\\drivers\\lcd.h"
#include "..\\drivers\\CommTest.h"

/*#define         OS_TIME_DELAY*/
#define         TASK_STK_SIZE     100      /* Size of each task's stacks (# of WORDs)       */

/********************************************************************************************/
/*                                     GLOBAL VARIABLES                                     */
/********************************************************************************************/
OS_STK          TaskStartStk[TASK_STK_SIZE];   /* TaskStart()�Լ��� ���ÿ���                */
OS_STK          process1Stk[TASK_STK_SIZE];    /* Task #1    task stack                     */
OS_STK          process2Stk[TASK_STK_SIZE];    /* Task #2    task stack                     */
OS_STK          process3Stk[TASK_STK_SIZE];    /* Task #3    task stack                     */
OS_STK          process4Stk[TASK_STK_SIZE];    /* Task #4    task stack                     */

#ifdef OS_TIME_DELAY
    #define     TITLE_DELAY()   OSTimeDly(60)
    #define     LOOP_DELAY()    OSTimeDly(1)
#else
    #define     TITLE_DELAY()   delay(1000)
    #define     LOOP_DELAY()    delay(10)
#endif

void TaskStart(void *pdat);
void process1(void *pdat);
void process2(void *pdat);
void process3(void *pdat);
void process4(void *pdat);


/********************************************************************************************/
/*                                 EXTERNAL FUNCTION PROTOCOLS                              */
/********************************************************************************************/
extern void     TimeTickInit(void);

void main (void)
{
    OSInit();                                                   /* uC/OS-II�� �ʱ�ȭ�Ѵ�    */
    /* ���� �½�ũ ���� */
    OSTaskCreate(TaskStart, (void *)0, (void *)&TaskStartStk[TASK_STK_SIZE - 1], 10);
    OSStart();                                                  /* uC/OS-II �⵿            */
}

void TaskStart(void *pdat)
{
    BYTE cnt, err, sData, sentCnt;
    char dispBuf[20];
    WORD dataCnt;

    disable();                                                  /* ���ͷ�Ʈ ��Ȱ��ȭ        */  
    TimeTickInit();                                             /* Ÿ�� ƽ�� Ÿ�̸� �ʱ�ȭ  */
    enable();                                                   /* ���ͷ�Ʈ Ȱ��ȭ          */

    CommInit();                                            /* Initialize Serial module                 */
    DispInit(2,16);                                        /* LCD����̹��� 2*16 ������ �ʱ�ȭ�Ѵ�     */

    err = 0;

    err += OSTaskCreate(process1, (void *)0, &process1Stk[TASK_STK_SIZE-1], 11);
    err += OSTaskCreate(process2, (void *)0, &process2Stk[TASK_STK_SIZE-1], 12);
    err += OSTaskCreate(process3, (void *)0, &process3Stk[TASK_STK_SIZE-1], 13);
    err += OSTaskCreate(process4, (void *)0, &process4Stk[TASK_STK_SIZE-1], 14);

    for(;;)
    {
        OSTimeDlyHMSM(10,0,0,0);
    }
}



void delay(WORD cnt)
{
    volatile WORD i;

    while(cnt--)
    {
        for(i=0;i<300;i++);
    }
}

void process1(void *pdat)
{
    BYTE err;
    WORD cnt;
    char disp[10];
    
    
    for(;;)
    {
        OSSemPend(P1Sem, 0, &err);
        DispStr(0,0,"P1 start");
        TITLE_DELAY();
    
        cnt  = 0xff;
        while(cnt--)
        {
            sprintf(disp,"   %5d", cnt);
            DispStr(0,0,disp);
            LOOP_DELAY();
        }

        DispStr(0,0,"P1 ends ");
        TITLE_DELAY();
        DispStr(0,0,"        ");
    }
}

void process2(void *pdat)
{
    BYTE err;
    WORD cnt;
    char disp[10];
    
    for(;;)
    {
        OSSemPend(P2Sem, 0, &err);
        DispStr(0,8,"P2 start");
        TITLE_DELAY();
    
        cnt  = 0xff;
        while(cnt--)
        {
            sprintf(disp,"   %5d", cnt);
            DispStr(0,8,disp);
            LOOP_DELAY();
        }

        DispStr(0,8,"P2 ends ");
        TITLE_DELAY();
        DispStr(0,8,"        ");
    }
}

void process3(void *pdat)
{
    BYTE err;
    WORD cnt;
    char disp[10];
    
    for(;;)
    {
        OSSemPend(P3Sem, 0, &err);
        DispStr(1,0,"P3 start");
        TITLE_DELAY();
    
        cnt  = 0xff;
        while(cnt--)
        {
            sprintf(disp,"   %5d", cnt);
            DispStr(1,0,disp);
            LOOP_DELAY();
        }

        DispStr(1,0,"P3 ends ");
        TITLE_DELAY();
        DispStr(1,0,"        ");
    }
}

void process4(void *pdat)
{
    BYTE err;
    WORD cnt;
    char disp[10];
    
    for(;;)
    {
        OSSemPend(P4Sem, 0, &err);
        DispStr(1,8,"P4 start");
        TITLE_DELAY();
    
        cnt  = 0xff;
        while(cnt--)
        {
            sprintf(disp,"   %5d", cnt);
            DispStr(1,8,disp);
            LOOP_DELAY();
        }

        DispStr(1,8,"P4 ends ");
        TITLE_DELAY();
        DispStr(1,8,"        ");
    }
}
