c:\ic96\bin\make %1
