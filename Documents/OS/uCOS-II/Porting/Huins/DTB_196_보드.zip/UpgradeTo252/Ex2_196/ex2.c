#include "..\\includes.h"
#include "..\\drivers\\lcd.h"
#include "..\\drivers\\CommRtos.h"

#define     KEY_ESC             0x1b

/*
*********************************************************************************************************
*                                              CONSTANTS
*********************************************************************************************************
*/

#define          TASK_STK_SIZE     200                /* Size of each task's stacks (# of WORDs)       */

#define          TASK_START_ID      10                /* Application tasks IDs                         */
#define          TASK_1_ID          11
#define          TASK_2_ID          13
#define          TASK_3_ID          14
#define          TASK_4_ID          15
#define          TASK_5_ID          16

#define          TASK_START_PRIO    10                /* Application tasks priorities                  */
#define          TASK_1_PRIO        19
#define          TASK_2_PRIO        12
#define          TASK_3_PRIO        14
#define          TASK_4_PRIO        16
#define          TASK_5_PRIO        18


/*
*********************************************************************************************************
*                                              VARIABLES
*********************************************************************************************************
*/

OS_STK          TaskStartStk[TASK_STK_SIZE];         /* Startup    task stack                         */
OS_STK          Task1Stk[TASK_STK_SIZE];             /* Task #2    task stack                         */
OS_STK          Task2Stk[TASK_STK_SIZE];             /* Task #2    task stack                         */
OS_STK          Task3Stk[TASK_STK_SIZE];             /* Task #3    task stack                         */
OS_STK          Task4Stk[TASK_STK_SIZE];             /* Task #4    task stack                         */
OS_STK          Task5Stk[TASK_STK_SIZE];             /* Task #5    task stack                         */

OS_EVENT        *AckMbox;                             /* Message mailboxes for Tasks #4 and #5         */
OS_EVENT        *TxMbox;
char            * movingCursor[8];

/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*********************************************************************************************************
*/

void            TaskStart(void *data);               /* Function prototypes of tasks                  */
void            Task1(void *data);
void            Task2(void *data);
void            Task3(void *data);
void            Task4(void *data);
void            Task5(void *data);

extern void TimeTickInit(void);

void main (void)
{
    OSInit();                                                   /* uC/OS-II�� �ʱ�ȭ�Ѵ�    */
    /* ���� �½�ũ ���� */
    OSTaskCreate(TaskStart, (void *)0, (void *)&TaskStartStk[TASK_STK_SIZE - 1], TASK_START_PRIO);
    OSStart();                                                  /* uC/OS-II �⵿            */
}

void  TaskStart (void *data)
{
    BYTE cnt, err, sData;
    char dispBuf[10];
    WORD dataCnt;

    disable();                                                  /* ���ͷ�Ʈ ��Ȱ��ȭ        */  
    TimeTickInit();                                             /* Ÿ�� ƽ�� Ÿ�̸� �ʱ�ȭ  */
    enable();                                                   /* ���ͷ�Ʈ Ȱ��ȭ          */

    data = data;
    dataCnt = cnt = 0;

    movingCursor[0] = "*    ";
    movingCursor[1] = " *   ";
    movingCursor[2] = "  *  ";
    movingCursor[3] = "   * ";
    movingCursor[4] = "    *";
    movingCursor[5] = "   * ";
    movingCursor[6] = "  *  ";
    movingCursor[7] = " *   ";

    CommInit();                                            /* Initialize Serial module                 */
    DispInit(2,16);                                        /* Initialize 2 * 16 character LCD module   */

    AckMbox = OSMboxCreate((void *)0);                     /* Create 2 message mailboxes               */
    TxMbox  = OSMboxCreate((void *)0);

    OSTaskCreateExt(Task2, (void *)0, &Task2Stk[TASK_STK_SIZE-1], TASK_2_PRIO,
                   TASK_2_ID, &Task2Stk[0], TASK_STK_SIZE, (void *)0,
                   OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    OSTaskCreateExt(Task3, (void *)0, &Task3Stk[TASK_STK_SIZE-1], TASK_3_PRIO,
                   TASK_3_ID, &Task3Stk[0], TASK_STK_SIZE, (void *)0,
                   OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    OSTaskCreateExt(Task4, (void *)0, &Task4Stk[TASK_STK_SIZE-1], TASK_4_PRIO,
                   TASK_4_ID, &Task4Stk[0], TASK_STK_SIZE, (void *)0,
                   OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    OSTaskCreateExt(Task5, (void *)0, &Task5Stk[TASK_STK_SIZE-1], TASK_5_PRIO,
                   TASK_5_ID, &Task5Stk[0], TASK_STK_SIZE, (void *)0,
                   OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    OSTaskCreateExt(Task1, (void *)0, &Task1Stk[TASK_STK_SIZE-1], TASK_1_PRIO,
                   TASK_1_ID, &Task1Stk[0], TASK_STK_SIZE, (void *)0,
                   OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    for (;;) {
        sData = CommGetChar(0, &err);
        if(sData==KEY_ESC) asm rst;

        err = CommPutChar(sData, 0);
        if(err != COMM_NO_ERR)
        {
            sprintf(dispBuf,"%d",err);
            DispStr(11,1,dispBuf);
        }
        sprintf(dispBuf, "%5u", ++dataCnt);

        if(cnt>10)
        {
            cnt = 0;
            DispStr(0,0,"           ");
        }

        DispStr(0,11,dispBuf);
        DispChar(0,cnt++,sData);
    }
}

void  Task1 (void *data)
{
    BYTE err,key;
    WORD i, j, k;
    char string[20];

    key = k = 0;

    while(1)
    {
        OSTimeDly(5);
        for(i=0;i<0x0ff;i++)
        {
            for(j=0;j<0x1ff;j++)
            {
                j = j;
            }
        }
        sprintf(string,"%5u", k++);
        DispStr(1,11,string);
    }
}

void  Task2 (void *data)
{
    BYTE i;

    data = data;

    i = 0;
    DispHorBarInit();
    for (;;) {
        for(i=0;i<26;i++)
        {
            DispHorBar(1,0,i);
            OSTimeDly(5);
        }
        for(i=25;i>0;i--)
        {
            DispHorBar(1,0,i);
            OSTimeDly(5);
        }
    }
}



void  Task3 (void *data)
{
    BYTE i, err;

    data = data;

    i = 0;
    for (;;) {
        DispStr(1,5, movingCursor[i]);
        OSTimeDly(5);
        if(++i>7) i = 0;
    }
}

void  Task4 (void *data)
{
    char   txmsg;
    INT8U  err;


    data  = data;
    txmsg = 'A';
    for (;;) {
        while (txmsg <= 'Z') {
            OSMboxPost(TxMbox, (void *)&txmsg);
            OSMboxPend(AckMbox, 0, &err);
            txmsg++;
        }
        txmsg = 'A';
    }
}

void  Task5 (void *data)
{
    char  *rxmsg;
    char  string[20];
    INT8U  err;


    data = data;
    for (;;) {
        rxmsg = (char *)OSMboxPend(TxMbox, 0, &err);
        DispChar(1,10,*rxmsg);

        OSTimeDlyHMSM(0,0,1,0);
        OSMboxPost(AckMbox, (void *)1);
    }
}

