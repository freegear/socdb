               OS_CPU_A    MODULE

R0             EQU   00H:WORD      ; R    ZERO REGISTER
AD_COMMAND     EQU   02H:BYTE      ;   W
AD_RESULT_LO   EQU   02H:BYTE      ; R
AD_RESULT_HI   EQU   03H:BYTE      ; R
HSI_MODE       EQU   03H:BYTE      ;   W
HSO_TIME       EQU   04H:WORD      ;   W
HSI_TIME       EQU   04H:WORD      ; R
HSO_COMMAND    EQU   06H:BYTE      ;   W
HSI_STATUS     EQU   06H:BYTE      ; R
SBUF           EQU   07H:BYTE      ; R/W
INT_MASK       EQU   08H:BYTE      ; R/W
INT_PENDING    EQU   09H:BYTE      ; R/W
WATCHDOG       EQU   0AH:BYTE      ;   W  WATCHDOG TIMER
TIMER1         EQU   0AH:WORD      ; R
TIMER2         EQU   0CH:WORD      ; R/w
IOC2           EQU   0BH:BYTE      ; W
IOC3           EQU   0CH:BYTE      ; W
BAUD_RATE      EQU   0EH:BYTE      ;   W
IOPORT0        EQU   0EH:BYTE      ; R
IOPORT1        EQU   0FH:BYTE      ; R/W
IOPORT2        EQU   10H:BYTE      ; R/W
SP_CON         EQU   11H:BYTE      ;   W
SP_STAT        EQU   11H:BYTE      ; R
INT_PEND1      EQU   12H:BYTE      ; R/W
INT_MASK1      EQU   13H:BYTE      ; R/W
WSR            EQU   14H:BYTE      ; R/W

IOC0           EQU   15H:BYTE      ;   W
IOS0           EQU   15H:BYTE      ; R
IOC1           EQU   16H:BYTE      ;   W
IOS1           EQU   16H:BYTE      ; R
IOS2           EQU   17H:BYTE      ; R
PWM_CONTROL    EQU   17H:BYTE      ;   W
SP             EQU   18H:WORD      ; R/W

        PUBLIC  OSCtxSw
        PUBLIC  OSIntCtxSw
        PUBLIC  OSStartHighRdy
        PUBLIC  TxISR
        PUBLIC  RxISR
        PUBLIC  OSTickISR

;#ifdef OS_CPU_HOOKS_EN
        extrn   OSTaskSwHook
;#endif
        extrn   OSRunning
        extrn   OSTCBCur
        extrn   OSPrioCur
        extrn   OSPrioHighRdy
        extrn   OSTCBHighRdy
        extrn   OSIntNesting
        extrn   OSIntEnter
        extrn   OSTimeTick
        extrn   OSIntExit
        extrn   TxIntHandler
        extrn   RxIntHandler

        rseg
        extrn   ?FRAME01
        extrn   PLMREG

        CSEG

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
OSStartHighRdy:
        CALL  OSTaskSwHook
        LD    PLMREG,OSTCBHighRdy
        LD    SP,[PLMREG]

        LDB   PLMREG,#1H
        STB   PLMREG,OSRunning

        ljmp  popRegisters

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
OSIntCtxSw:
        ;ADD   SP,#4H
        ;LD    PLMREG,OSTCBCur
        ;ST    SP,[PLMREG]
        CALL  OSTaskSwHook

        LD    PLMREG,OSTCBHighRdy
        ST    PLMREG,OSTCBCur

        LDB   PLMREG,OSPrioHighRdy
        STB   PLMREG,OSPrioCur

        LD    PLMREG,OSTCBHighRdy
        LD    SP,[PLMREG]

        ljmp  popRegisters

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
OSCtxSw:
        PUSHA
        PUSH  1AH
        PUSH  1CH
        PUSH  1EH
        PUSH  20H
        PUSH  22H

        LD    PLMREG,OSTCBCur
        ST    SP,[PLMREG]
        CALL  OSTaskSwHook
        LD    PLMREG,OSTCBHighRdy
        ST    PLMREG,OSTCBCur
        LDB   PLMREG,OSPrioHighRdy
        STB   PLMREG,OSPrioCur

        LD    PLMREG,OSTCBHighRdy
        LD    SP,[PLMREG]

        ljmp  popRegisters

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
TxISR:
        PUSHA
        PUSH  1AH
        PUSH  1CH
        PUSH  1EH
        PUSH  20H
        PUSH  22H

        CALL OSIntEnter

        LDB   PLMREG,OSIntNesting
        CMPB  PLMREG,#1H
        BNE   TxISR1
        LD    PLMREG,OSTCBCur
        ST    SP,[PLMREG]

TxISR1:
        CALL TxIntHandler

        CALL OSIntExit
        ljmp  popRegisters

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
RxISR:
        PUSHA
        PUSH  1AH
        PUSH  1CH
        PUSH  1EH
        PUSH  20H
        PUSH  22H


        CALL OSIntEnter

        LDB   PLMREG,OSIntNesting
        CMPB  PLMREG,#1H
        BNE   RxISR1
        LD    PLMREG,OSTCBCur
        ST    SP,[PLMREG]

RxISR1:
 
        CALL RxIntHandler

        CALL OSIntExit
        ljmp  popRegisters

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
OSTickISR:
        PUSHA
        PUSH  1AH
        PUSH  1CH
        PUSH  1EH
        PUSH  20H
        PUSH  22H

        CALL  OSIntEnter

        LDB   PLMREG,OSIntNesting
        CMPB  PLMREG,#1H
        BNE   OSTickISR1
        LD    PLMREG,OSTCBCur
        ST    SP,[PLMREG]

OSTickISR1:
        LD    timer2,#05160h ;SYSTEM_CLOCK/16/OS_TICKS_PER_SEC(60)-1;

        CALL  OSTimeTick

        CALL  OSIntExit

popRegisters:
        POP   22H
        POP   20H
        POP   1EH
        POP   1CH
        POP   1AH
        POPA
        RET

        END

