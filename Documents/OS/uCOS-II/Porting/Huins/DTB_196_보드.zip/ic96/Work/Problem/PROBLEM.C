/*
***********************************************************************
*                    DTB-196 Monitor Program
*                     Version 1.0, Jan. 2002
*
*                           
*                   DIOIZ, All Rights Reserved
*                      http://www.dioiz.com
*
* File Name : Monitor.c
* Author : Won-Ho, Sung
***********************************************************************
*/

#include <80c196.h>
#include "stdio.h"
typedef unsigned char   BYTE;
typedef unsigned short  WORD;
typedef unsigned long   LWORD;

#define     SYSTEM_CLOCK    20000000L

#define     ON      1
#define     OFF     0
#define     YES     1
#define     NO      0

#define     BAUD_RATE           57600
#define     BAUD_REG ((WORD)(SYSTEM_CLOCK/((long)BAUD_RATE*16)-1)+0x8000)

#define     LCD_CW  0x0300
#define     LCD_DW  0x0301
#define     LCD_CR  0x0302
#define     LCD_DR  0x0303

void process1(void);
void process2(void);
void process3(void);
void process4(void);

BYTE * pLcdCW;
BYTE * pLcdCR;
BYTE * pLcdDW;
BYTE flag1, flag2, flag3, flag4;

void RxIntHandler(void)
{
    BYTE temp;
    
    temp = sbuf;
    
    switch(temp)
    {
        case '1':
            flag1++;
        break;
        case '2':
            flag2++;
        break;
        case '3':
            flag3++;
        break;
        case '4':
            flag4++;
        break;
    }
}

void lcdCheckBusy(void)
{
#ifdef HW_CHECK_BUSY
    while(*pLcdCR & 0x80);
#else
    volatile BYTE cnt;
    cnt = 40;

    while(cnt--);
#endif
}

void lcdInitModule(void)
{
    BYTE i;

    pLcdCW = (BYTE *)LCD_CW;
    pLcdCR = (BYTE *)LCD_CR;
    pLcdDW = (BYTE *)LCD_DW;

    *pLcdCW = 0x3c;
    for(i=0;i<50;i++)
        lcdCheckBusy();

    *pLcdCW = 0x0c;
    for(i=0;i<50;i++)
        lcdCheckBusy();

    *pLcdCW = 0x01;
    for(i=0;i<50;i++)
        lcdCheckBusy();

    *pLcdCW = 0x06;
    for(i=0;i<50;i++)
        lcdCheckBusy();
}

void lcdMoveCursor(BYTE x, BYTE y)
{
    BYTE val;

    x &= 0x0f;
    y &= 0x01;

    val = (y<<6) | x | 0x80;

    lcdCheckBusy();
    *pLcdCW = val;
}

void lcdCursorOnOff(BYTE flag)
{
}

void lcdPutChar(char ch)
{
    lcdCheckBusy();
    *pLcdDW = ch;
}

void lcdPutString(char * str)
{
    while(*str)
    {
        lcdPutChar(*str++);
    }
}

void delay(WORD cnt)
{
    volatile WORD i;

    while(cnt--)
    {
        for(i=0;i<300;i++);
    }
}

void initSerial(void)
{
     BYTE val;

     wsr = 15;
     val = ioc1;
     wsr = 0;
     val |= 0x20;

     sp_con = 0x09;     /* mode1 & recieve enable */
     ioc1 = val;        /* select TxD */

     /* Baud rate must be written in the order of LSB first at the same address */
     baud_rate = ((unsigned char) BAUD_REG);
     baud_rate = ((unsigned char) (BAUD_REG >> 8));
}

void initSystem(void)
{
    asm DI;

    ioport1 = 0xff;

    initSerial();
    lcdInitModule();
    lcdInitModule();

    imask1 = 0x02;
    asm EI;
}

void process1(void)
{
    WORD cnt;
    char disp[10];
    
    cnt  = 0xff;

    lcdMoveCursor(0,0);
    lcdPutString("P1 start");
    delay(1000);
    
    cnt  = 0xff;
    while(cnt--)
    {
        sprintf(disp,"   %5d", cnt);
        lcdMoveCursor(0,0);
        lcdPutString(disp);
        delay(10);
    }

    lcdMoveCursor(0,0);
    lcdPutString("P1 end  ");
    delay(1000);
    lcdMoveCursor(0,0);
    lcdPutString("        ");
}

void process2(void)
{
    WORD cnt;
    char disp[10];
    
    cnt  = 0xff;

    lcdMoveCursor(8,0);
    lcdPutString("P2 start");
    delay(1000);
    
    cnt  = 0xff;
    while(cnt--)
    {
        sprintf(disp,"   %5d", cnt);
        lcdMoveCursor(8,0);
        lcdPutString(disp);
        delay(10);
    }

    lcdMoveCursor(8,0);
    lcdPutString("P2 end  ");
    delay(1000);
    lcdMoveCursor(8,0);
    lcdPutString("        ");
}

void process3(void)
{
    WORD cnt;
    char disp[10];
    
    cnt  = 0xff;

    lcdMoveCursor(0,1);
    lcdPutString("P3 start");
    delay(1000);
    
    cnt  = 0xff;
    while(cnt--)
    {
        sprintf(disp,"   %5d", cnt);
        lcdMoveCursor(0,1);
        lcdPutString(disp);
        delay(10);
    }

    lcdMoveCursor(0,1);
    lcdPutString("P3 end  ");
    delay(1000);
    lcdMoveCursor(0,1);
    lcdPutString("        ");
}

void process4(void)
{
    WORD cnt;
    char disp[10];
    
    cnt  = 0xff;

    lcdMoveCursor(8,1);
    lcdPutString("P4 start");
    delay(1000);
    
    cnt  = 0xff;
    while(cnt--)
    {
        sprintf(disp,"   %5d", cnt);
        lcdMoveCursor(8,1);
        lcdPutString(disp);
        delay(10);
    }

    lcdMoveCursor(8,1);
    lcdPutString("P4 end  ");
    delay(1000);
    lcdMoveCursor(8,1);
    lcdPutString("        ");
}

void main(void)
{
    initSystem();
    flag1 = flag2 = flag3 = flag4 = 0;

    while(1)
    {
        if(flag1)
        {
            flag1--;
            process1();
        }
        if(flag2)
        {
            flag2--;
            process2();
        }
        if(flag3)
        {
            flag3--;
            process3();
        }
        if(flag4)
        {
            flag4--;
            process4();
        }
    }
}
