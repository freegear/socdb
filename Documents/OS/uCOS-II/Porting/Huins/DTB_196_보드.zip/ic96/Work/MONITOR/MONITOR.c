/*
***********************************************************************
*                    DTB-196 Monitor Program
*                     Version 1.0, Jan. 2002
*
*                           
*                   DIOIZ, All Rights Reserved
*                      http://www.dioiz.com
*
* File Name : Monitor.c
* Author : Won-Ho, Sung
***********************************************************************
*/

#include <80c196.h>
#include "stdio.h"
typedef unsigned char   BYTE;
typedef unsigned short  WORD;
typedef unsigned long   LWORD;

/*#define     CMP_HEX_DOWNLOAD*/
#define     SYSTEM_CLOCK    20000000L

#define     ON      1
#define     OFF     0
#define     YES     1
#define     NO      0

#define     KEY_BUF_NUM         60

#define     KEY_BS              0x08
#define     KEY_RETURN          '\r'
#define     KEY_SPACE           ' '
#define     KEY_ESC             0x1b

#define     BAUD_RATE           57600
#define     BAUD_REG ((WORD)(SYSTEM_CLOCK/((long)BAUD_RATE*16)-1)+0x8000)

#define     LCD_CW  0x0300
#define     LCD_DW  0x0301
#define     LCD_CR  0x0302
#define     LCD_DR  0x0303

WORD dumpAddr;
char keyBuf[KEY_BUF_NUM+2];

BYTE * pLcdCW;
BYTE * pLcdCR;
BYTE * pLcdDW;

void lcdCheckBusy(void)
{
#ifdef HW_CHECK_BUSY
    while(*pLcdCR & 0x80);
#else
    volatile BYTE cnt;
    cnt = 40;

    while(cnt--);
#endif
}

void lcdInitModule(void)
{
    BYTE i;

    pLcdCW = (BYTE *)LCD_CW;
    pLcdCR = (BYTE *)LCD_CR;
    pLcdDW = (BYTE *)LCD_DW;

    *pLcdCW = 0x3c;
    for(i=0;i<50;i++)
        lcdCheckBusy();

    *pLcdCW = 0x0c;
    for(i=0;i<50;i++)
        lcdCheckBusy();

    *pLcdCW = 0x01;
    for(i=0;i<50;i++)
        lcdCheckBusy();

    *pLcdCW = 0x06;
    for(i=0;i<50;i++)
        lcdCheckBusy();
}

void lcdMoveCursor(BYTE x, BYTE y)
{
    BYTE val;

    x &= 0x0f;
    y &= 0x01;

    val = (y<<6) | x | 0x80;

    lcdCheckBusy();
    *pLcdCW = val;
}

void lcdCursorOnOff(BYTE flag)
{
}

void lcdPutChar(char ch)
{
    lcdCheckBusy();
    *pLcdDW = ch;
}

void lcdPutString(char * str)
{
    while(*str)
    {
        lcdPutChar(*str++);
    }
}

void delay(WORD cnt)
{
    volatile WORD i;

    while(cnt--)
    {
        for(i=0;i<300;i++);
    }
}

char getch(void)
{
    char tmp;

    while(!(sp_stat & 0x40));
    tmp = sbuf;

    return tmp;
}

char getchN(char *str, BYTE len)
{
    while(len--)
    {
        *str++ = getch();
    }
}

void putch(char tmp)
{
    while(!(sp_stat & 0x08));
    sbuf = tmp;
}

void print(char *str)
{
    while(*str)
    {
        putch(*str++);
    }
}

BYTE ascii2Num(char ascii)
{
    if      ((ascii>='0') && (ascii<='9')) return   (ascii-'0');
    else if ((ascii>='A') && (ascii<='F')) return ( (ascii-'A')+10 );
    else if ((ascii>='a') && (ascii<='f')) return ( (ascii-'a')+10 );
    else return -1;
}

/* calculates two bytes of hexa string into byte data  */
BYTE ascii2BYTE(char *str)
{
    BYTE temp;

    temp = ascii2Num(str[0]) * 16 + ascii2Num(str[1]);
    return temp;
}

/* calculates four bytes of hexa string into word data  */
WORD ascii2WORD(char *str)
{
    WORD temp;

    temp = ascii2BYTE(str) * 256 + ascii2BYTE(str+2);
    return temp;
}

/* calculates eight bytes of hexa string into word data  */
LWORD ascii2LWORD(char *str)
{
    LWORD temp;

    temp = ascii2WORD(str)*256*256;
    temp = ascii2WORD(str+4);

    return temp;
}

char nibble2ascii(BYTE temp)
{
    /* 0 <= temp <= 16 */
    if(temp>=10) return (temp - 10 + 'A');
    else return (temp + '0');
}

void byte2ascii(char *str,BYTE temp)
{
    str[0] = nibble2ascii(temp>>4);
    str[1] = nibble2ascii(temp&0x0f);
}

void word2ascii(char *str,WORD temp)
{
    byte2ascii(str, (BYTE)(temp>>8));
    byte2ascii(str+2, (BYTE)(temp & 0xff));
}


void numToString(char * f, WORD temp)
{
    BYTE i;

    f[0] = temp/(WORD)10000; temp -= f[0]*(WORD)10000; f[0] = !f[0] ? ' ' : f[0]+'0';
    f[1] = temp/(WORD) 1000; temp -= f[1]*(WORD) 1000; f[1] = (f[0]==' ' && !f[1]) ? ' ' : f[1]+'0';
    f[2] = temp/(WORD)  100; temp -= f[2]*(WORD)  100; f[2] = (f[1]==' ' && !f[2]) ? ' ' : f[2]+'0';
    f[3] = temp/(WORD)   10; temp -= f[3]*(WORD)   10; f[3] = (f[2]==' ' && !f[3]) ? ' ' : f[3]+'0';
    f[4] = temp; f[4] += '0';
    f[5] = ' ';
    f[6] = 0;
}

BYTE getString(void)
{
    char tmp;
    BYTE index;

    index = 0;
    do{
        tmp = getch();
        if(tmp!=KEY_ESC && tmp!=KEY_BS && index<KEY_BUF_NUM)
        {
            keyBuf[index++] = tmp;
            putch(tmp);
        }
        else if(tmp==KEY_BS && index>0)
        {
            index--;
            putch(KEY_BS);
            putch(KEY_SPACE);
            putch(KEY_BS);
        }
        if(tmp==KEY_RETURN) break;
        if(tmp==KEY_ESC)
        {
            putch(KEY_RETURN);
            index = 0;
            keyBuf[0] = 0;
            break;
        }
    }while(1);

    return index;
}

runProg(void)
{
    char str[5];
    void (*FUN)(void);

    print("\r\nInput start address(4 hexa digit, default 8080h) --> ");
    getString();

    if(keyBuf[0]=='\r') FUN=(void(*)())0x8080;
    else FUN=(void(*)())ascii2WORD(keyBuf);

    printf("\r\nRunning address %04xh..\r\n", FUN);
    delay(10);
    (*FUN)();
}

void helpMessage(void)
{
    print("\r\n");
    print("L : Hexa file download\r\n");
    print("G : Run downloaded program\r\n");
    print("H : Show help message\r\n");
#ifdef CMP_HEX_DOWNLOAD
    print("S : Compressed Hex file download\r\n");
#endif
    print("D : Dump memory\r\n");
    print("E : Edit memory\r\n");
    print("F : Fill memory\r\n");
    print("R : Reset system\r\n");
}

void loadHexaFile(void)
{
    BYTE tmp, i;
    BYTE len;
    BYTE *ptr;
    BYTE checkSum;
    WORD addr;
    char rxBuf[5];

    WORD totRecvBytes;
    char txBuf[10];
    BYTE isTxEmpty;
    BYTE txBufIndex;

    totRecvBytes = 0;
    txBufIndex = 0;
    isTxEmpty = YES;

    print("\r\nReady to download hexa file\r\n");
    print("Use terminal program in ASCII file transfer mode\r\n");
    print("\r\n");
    print("Starting download..\r\n");
    print("    0 bytes recieved..");

    do
    {
        do
        {
            tmp = getch();
        }while(tmp != ':');

        checkSum = 0;

        /* Figure out the number of data in the row */
        getchN(rxBuf, 2);
        len = ascii2BYTE(rxBuf);
        checkSum += len;

        /* Figure out the address */
        getchN(rxBuf, 4);
        addr = ascii2WORD(rxBuf);
        ptr = (BYTE *)addr;
        checkSum += (BYTE)(addr&0xff);
        checkSum += (BYTE)(addr>>8);

        getchN(rxBuf, 2);
        checkSum += ascii2BYTE(rxBuf);

        if(len==0 && addr==0)
        {
            getchN(rxBuf, 2);
            break;
        }

        for(i=0; i<len ; i++)
        {
            getchN(rxBuf, 2);
            tmp = ascii2BYTE(rxBuf);
            *ptr++ = tmp;
            checkSum += tmp;
            if(isTxEmpty==NO && txBufIndex<7)
            {
                if(sp_stat & 0x08);
                {
                    sbuf = txBuf[txBufIndex++];
                }
                if(txBufIndex>6) isTxEmpty = YES;
            }
        }

        /* Read checksum code in this row */
        getchN(rxBuf, 2);
        checkSum += ascii2BYTE(rxBuf);

        totRecvBytes += len;

        if(isTxEmpty)
        {
            numToString(txBuf+1, totRecvBytes);
            txBuf[0] = '\r';
            isTxEmpty = NO;
            txBufIndex = 0;
        }

        if(isTxEmpty==NO && txBufIndex<7)
        {
            if(sp_stat & 0x08);
            {
                sbuf = txBuf[txBufIndex++];
            }
            if(txBufIndex>6) isTxEmpty = YES;
        }

        if(checkSum)
        {
            printf("Check sum failed at address 0x%04x\r\n", addr);
            printf("Checksum is 0x%02x\r\n", checkSum);
            printf("Length is %d\r\n", len);
            printf("Restart the system..\r\n");
            while(1);
        }
    }while(1);

    print("\r\nDownload finished\r\n");
    printf("\r\nTotal %d bytes received..\r\n", totRecvBytes);
}

#ifdef  CMP_HEX_DOWNLOAD
void loadCmpHexFile(void)
{
    BYTE i;
    BYTE len;
    BYTE *ptr;
    BYTE lowByte, highByte;
    WORD addr;

    WORD totRecvBytes;
    WORD hxLoopCnt;
    char txBuf[10];
    BYTE isTxEmpty;
    BYTE txBufIndex;

    totRecvBytes = 0;
    txBufIndex = 0;
    isTxEmpty = YES;
    hxLoopCnt = 0;

    print("\r\nReady to download compressed hex file\r\n");
    print("Use terminal program in binary file transfer mode\r\n");
    print("    0 bytes recieved..");

    do
    {
        len = (BYTE)getch();
        highByte = (BYTE)getch();
        lowByte = (BYTE)getch();
        addr = (highByte<<8) + lowByte;
        hxLoopCnt++;

        if((len==0)&&(addr==0)) break;
        if(len>16 || addr<0x8000)
        {
            print("\r\n load failed..\r\n");
            printf("Cnt : %d, Addr : %04x, len : %d\r\n", hxLoopCnt, addr, len);
            printf("high : %02x, low : %02x \r\n", highByte, lowByte);
            while(1);
        }

        ptr = (BYTE *)addr;
        for(i=0; i<len; i++)
        {
            *ptr++ = getch();
        }
        totRecvBytes += len;

        if(isTxEmpty)
        {
            numToString(txBuf+1, totRecvBytes);
            txBuf[0] = '\r';
            isTxEmpty = NO;
            txBufIndex = 0;
        }

        if(isTxEmpty==NO && txBufIndex<7)
        {
            if(sp_stat & 0x08);
            {
                sbuf = txBuf[txBufIndex++];
            }
            if(txBufIndex>6) isTxEmpty = YES;
        }
    }while(1);

    print("\r\nDownload finished\r\n");
    printf("\r\nTotal %d bytes received..\r\n", totRecvBytes);
}
#endif

void dumpMemory(void)
{
    BYTE i, j;
    BYTE tmp;
    BYTE *ptr;

    printf("\r\nInput memory address (4 hexa digit, Defualt %04xh)-> ",dumpAddr);
    getString();
    if(keyBuf[0]!='\r')
    {
        dumpAddr = ascii2WORD(keyBuf);
    }

    ptr = (BYTE *)dumpAddr;

    while(1)
    {
        print("addr   ");
        for(i=0;i<16;i++)
            printf("%02x ", i);

        print("\r\n");
        for(i=0;i<20;i++)
        {
            printf("%04x : ", (WORD)ptr);
            for(j=0;j<16;j++)
            {
                printf("%02x ", *ptr++);
                dumpAddr++;
            }
            print("\r\n");
        }

        print("Press any key to continue to dump..\r\n");
        print("Or press [esc] to quit dump mode\r\n");

        tmp = getch();
        if(tmp==KEY_ESC) break;
    }
}

void editMemory(void)
{
    BYTE i, j;
    BYTE tmp;
    BYTE *ptr;
    WORD addr;

    addr = 0x8000;
    printf("\r\nInput memory address(4 hexa digit, default : 0x8000h) -->");

    while(1)
    {
        tmp = getString();

        if(tmp<3)
        {
            if(keyBuf[0]=='q' ||keyBuf[0]=='Q')
            {
                printf("\r\nq or Q pressed. Exiting..\r\n");
            }
            else if(keyBuf[0]==KEY_RETURN) goto next_step;
            return;
        }
        else
        {
            addr = ascii2WORD(keyBuf);
        }
next_step:

        printf("\r\nInput value(2 hexa digit) --> ");
        tmp = getString();
        tmp = ascii2BYTE(keyBuf);

        ptr = (BYTE *)addr;
        addr++;
        *ptr = tmp;

        printf("\r\nInput address(4 hexa digit, current : 0x%04xh) or press 'q' to quit --> ", addr);
    }
}

void fillMemory( void)
{
    BYTE val, *ptr;
    WORD i;
    WORD startAddr;
    WORD endAddr;

    printf("\r\nFill memory\r\n");
    printf("\r\nInput start address(4 hexa digit) --> ");
    getString();
    startAddr = ascii2WORD(keyBuf);

    printf("\r\nInput end address(4 hexa digit) --> ");
    getString();
    endAddr = ascii2WORD(keyBuf);

    printf("\r\nInput fill value(2 hexa digit) --> ");
    getString();
    val = ascii2BYTE(keyBuf);


    ptr = (BYTE *)startAddr;

    for(i=startAddr;i<endAddr;i++)
    {
        *ptr++ = val;
    }
    *ptr = val;

    printf("\r\nMemory filled with : 0x%02x", val);
}

void initSerial(void)
{
     BYTE val;

     wsr = 15;
     val = ioc1;
     wsr = 0;
     val |= 0x20;

     sp_con = 0x09;     /* mode1 & recieve enable */
     ioc1 = val;        /* select TxD */

     /* Baud rate must be written in the order of LSB first at the same address */
     baud_rate = ((unsigned char) BAUD_REG);
     baud_rate = ((unsigned char) (BAUD_REG >> 8));
}

void main(void)
{
    char key;
    asm DI;

    ioport1 = 0xff;

    initSerial();
    lcdInitModule();
    lcdInitModule();

    dumpAddr = 0x2000;

    print("\r\n");
    print("*****************************************\r\n");
    print("*            Welcome to DTB-196         *\r\n");
    print("*        Monitor program version 1.0    *\r\n");
    print("*                  DIOIZ                *\r\n");
    print("*                Jan, 2002              *\r\n");
    print("*****************************************\r\n");

    lcdMoveCursor(0, 0);
    lcdPutString("MONITOR PROGRAM ");
    lcdMoveCursor(0, 1);
    lcdPutString("  FOR  DTB-196  ");

    while(1)
    {
        print("\r\n80c196kc>");
        getString();
        key  = keyBuf[0];
        /* Download */
        if((key=='l') || (key=='L')) loadHexaFile();

        /* Help */
        if((key=='h') || (key=='H') || (key=='?')) helpMessage();

        /* Go */
        if((key=='g') || (key=='G')) runProg();

        /* Reset */
        if((key=='r') || (key=='R')) asm rst;

#ifdef  CMP_HEX_DOWNLOAD
        /* compressed hexa file download */
        if((key=='s') || (key=='S')) loadCmpHexFile();
#endif
        /* Dump memory */
        if((key=='d') || (key=='D')) dumpMemory();

        /* Edit memory */
        if((key=='e') || (key=='E')) editMemory();

        /* Fill memory */
        if((key=='f') || (key=='F')) fillMemory();
    }
}
