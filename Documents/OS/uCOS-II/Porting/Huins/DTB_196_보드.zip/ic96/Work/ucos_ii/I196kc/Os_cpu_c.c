/*
*********************************************************************************************************
*                                               uC/OS-II
*                                         The Real-Time Kernel
*
*                        (c) Copyright 1992-1998, Jean J. Labrosse, Plantation, FL
*                                          All Rights Reserved
*
*
*                                       80x86/80x88 Specific code
*                                          LARGE MEMORY MODEL
*
* File : OS_CPU_C.C
* By   : Jean J. Labrosse
*********************************************************************************************************
*/
#define  OS_CPU_GLOBALS
#include "c:\\ic96\\Work\\ucos_ii\\includes.h"

/*
*********************************************************************************************************
*                                        INITIALIZE A TASK'S STACK
*
* Description: This function is called by either OSTaskCreate() or OSTaskCreateExt() to initialize the
*              stack frame of the task being created.  This function is highly processor specific.
*
* Arguments  : task          is a pointer to the task code
*
*              pdata         is a pointer to a user supplied data area that will be passed to the task
*                            when the task first executes.
*
*              ptos          is a pointer to the top of stack.  It is assumed that 'ptos' points to
*                            a 'free' entry on the task stack.  If OS_STK_GROWTH is set to 1 then 
*                            'ptos' will contain the HIGHEST valid address of the stack.  Similarly, if
*                            OS_STK_GROWTH is set to 0, the 'ptos' will contains the LOWEST valid address
*                            of the stack.
*
*              opt           specifies options that can be used to alter the behavior of OSTaskStkInit().
*                            (see uCOS_II.H for OS_TASK_OPT_???).
*
* Returns    : Always returns the location of the new top-of-stack' once the processor registers have
*              been placed on the stack in the proper order.
*
* Note(s)    : Interrupts are enabled when your task starts executing. You can change this by setting the
*              PSW to 0x0002 instead.  In this case, interrupts would be disabled upon task startup.  The
*              application code would be responsible for enabling interrupts at the beginning of the task
*              code.  You will need to modify OSTaskIdle() and OSTaskStat() so that they enable 
*              interrupts.  Failure to do this will make your system crash!
*********************************************************************************************************
*/

void * OSTaskStkInit (void (*task)(void *pd), void *pdata, void *ptos, INT16U opt)
{
    OS_STK *stk;

    opt = opt;                 /* Prevent compiler warning */

	stk = (OS_STK*)ptos;

    *--stk = (OS_STK)pdata;    /* Simulate call to function with argument */
    *--stk = (OS_STK)0;        /* Dummy code */
    *--stk = (OS_STK)task;     /* Put pointer to task on top of stack */

    *--stk = (OS_STK)(0x0400 | INT_MASK);   /* PSW/IMASK = 0 (PUSHA) */
    *--stk = (OS_STK)(INT_MASK1<<8 | 0x00); /* IMASK1/WSR = 0 (PUSHA) */

    *--stk = (OS_STK)0;        /* 1ah, 1bh = 0 */
    *--stk = (OS_STK)0;        /* 1ch, 1dh PLMREG+0 = 0 */
    *--stk = (OS_STK)0;        /* 1eh, 1fh PLMREG+2 = 0 */
    *--stk = (OS_STK)0;        /* 20h, 21h PLMREG+4 = 0 */
    *--stk = (OS_STK)0;        /* 22h, 23h PLMREG+6 = 0 */

    return ((void *)stk);
}

/* Initialize Timer2 in down counter mode */
void TimeTickInit(void)
{
    INT8U val;
    
    wsr=15;
    timer1 = 0;
    wsr = 0;

    wsr=15;
    val = ioc0;
    val |= 0x02;
    wsr = 0;
    ioc0 = val;
    
    wsr=15;
    val = ioc1;
    val |= 0x08;
    wsr = 0;
    ioc1 = val;

    wsr=15;
    val = ioc2;
    val |= 0x02;
    wsr = 0;
    ioc2 = val;
    
    wsr = 1;
    val = t2control;
    val = 0x01;
    t2control = val; /* Tricky method for accessing ioc3 */
    wsr = 0;

    timer2 = SYSTEM_CLOCK/16/OS_TICKS_PER_SEC-1;
}

/*$PAGE*/
#if OS_CPU_HOOKS_EN
/*
*********************************************************************************************************
*                                          TASK CREATION HOOK
*
* Description: This function is called when a task is created.
*
* Arguments  : ptcb   is a pointer to the task control block of the task being created.
*
* Note(s)    : 1) Interrupts are disabled during this call.
*********************************************************************************************************
*/
void OSTaskCreateHook (OS_TCB *ptcb)
{
    ptcb = ptcb;                       /* Prevent compiler warning                                     */
}


/*
*********************************************************************************************************
*                                           TASK DELETION HOOK
*
* Description: This function is called when a task is deleted.
*
* Arguments  : ptcb   is a pointer to the task control block of the task being deleted.
*
* Note(s)    : 1) Interrupts are disabled during this call.
*********************************************************************************************************
*/
void OSTaskDelHook (OS_TCB *ptcb)
{
    ptcb = ptcb;                       /* Prevent compiler warning                                     */
}

/*
*********************************************************************************************************
*                                           TASK SWITCH HOOK
*
* Description: This function is called when a task switch is performed.  This allows you to perform other
*              operations during a context switch.
*
* Arguments  : none
*
* Note(s)    : 1) Interrupts are disabled during this call.
*              2) It is assumed that the global pointer 'OSTCBHighRdy' points to the TCB of the task that
*                 will be 'switched in' (i.e. the highest priority task) and, 'OSTCBCur' points to the 
*                 task being switched out (i.e. the preempted task).
*********************************************************************************************************
*/
void OSTaskSwHook (void)
{
}

/*
*********************************************************************************************************
*                                           STATISTIC TASK HOOK
*
* Description: This function is called every second by uC/OS-II's statistics task.  This allows your 
*              application to add functionality to the statistics task.
*
* Arguments  : none
*********************************************************************************************************
*/
void OSTaskStatHook (void)
{
}

/*
*********************************************************************************************************
*                                               TICK HOOK
*
* Description: This function is called every tick.
*
* Arguments  : none
*
* Note(s)    : 1) Interrupts may or may not be ENABLED during this call.
*********************************************************************************************************
*/
void OSTimeTickHook (void)
{
}
#endif
