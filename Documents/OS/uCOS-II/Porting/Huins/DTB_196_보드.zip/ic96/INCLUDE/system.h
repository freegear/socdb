#ifndef _DEFINE_H
#define _DEFINE_H

typedef unsigned char   BYTE;
typedef unsigned short  WORD;
typedef unsigned long   LWORD;

#define     ON              1
#define     OFF             0

#define     TRUE            1
#define     FALSE           0

#define     YES             1
#define     NO              0

#define     SYSTEM_CLOCK    20000000L

#define     ENABLE_INTERRUPT()      asm EI;
#define     DISABLE_INTERRUPT()     asm DI;

#define     INT_MASK        0x00
#define     INT_MASK1       0x13 /* Timer2 overflow, Rx, Tx interrupt */

#endif /* _DEFINE_H */
