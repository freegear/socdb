/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                        (c) Copyright 1992-1998, Jean J. Labrosse, Plantation, FL
*                                           All Rights Reserved
*
*                                                 V2.51
*
*                                               EXAMPLE #1
*********************************************************************************************************
*/
#include "stdio.h"
#include "includes.h"
#define _EDU_CS0	0x14000000
#define FND_DOT_KEY_CS(Num) (*((volatile unsigned int*)(_EDU_CS0+((Num)<<20))))
#define DOT_CS0	FND_DOT_KEY_CS(4) //0x14400000
#define DOT_CS1	FND_DOT_KEY_CS(5) //0x14500000
/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/

#define  TASK_STK_SIZE                 512       /* Size of each task's stacks (# of WORDs)            */
#define  N_TASKS                       3         /* Number of identical tasks                          */

/*
*********************************************************************************************************
*                                               VARIABLES
*********************************************************************************************************
*/

OS_STK		TaskStk[N_TASKS][TASK_STK_SIZE];     /* Tasks stacks                                  */
OS_STK		TaskStartStk[TASK_STK_SIZE];
/*
*********************************************************************************************************
*                                           FUNCTION PROTOTYPES
*********************************************************************************************************
*/

void   Task1(void *data);                             /* Function prototypes of tasks                  */
void   Task2(void *data);                             /* Function prototypes of tasks                  */
void   Task3(void *data);
void   TaskStart(void *data);                         /* Function prototypes of Startup task           */

/*$PAGE*/

/*
*********************************************************************************************************
*                                                MAIN
*********************************************************************************************************
*/



extern void SerialInit(void);
/*$PAGE*/
int main(void)
{		
	SerialInit();
	printf("\nC_Entry...\n");
	OSInit();                                              /* Initialize uC/OS-II                     */
	printf("\nOSInit...\n");

	OSTaskCreate(TaskStart, (void *)0,&TaskStartStk[TASK_STK_SIZE - 1], 7);
	printf("\nOSTaskCreate...\n");

	OSStart();                                             /* Start multitasking                      */
	printf("\nOSStart...\n");

}

/*
*********************************************************************************************************
*                                              STARTUP TASK
*********************************************************************************************************
*/
void TaskStart (void *data)
{
	//char   s[100];
	printf("TaskStart!!\n");

	OSTimer0_Period_Setting();
	printf("x\n");
	OSTimer0_Interrupt_Setting();			/* Timer Enable					          */
	printf("y\n");

	OSStatInit();					/* Initialize uC/OS-II's statistics        */
	printf("z\n");
	printf("Task...!!\n");

	OSTaskCreate(Task1,(void *)"Task1",&TaskStk[0][TASK_STK_SIZE - 1],8);

	OSTaskCreate(Task2,(void *)"Task2",&TaskStk[1][TASK_STK_SIZE - 1],9);
	
	for (;;) {
		printf("\n-------------------------------");
		printf("\nRunning Task : %5d\n", OSTaskCtr);     /* Display #tasks running                  */
		printf("Cpu Usage : %3d\n", OSCPUUsage);       /* Display CPU usage in %                  */														   /* Display #context switches per second    */
		printf("Context Switches per Sec : %5d\n",(int)OSCtxSwCtr);  
		printf("\n-------------------------------\n");
		OSCtxSwCtr = 0;
		OSTimeDlyHMSM(0, 0, 1, 0);                         /* Wait one second                         */
	}
}
/*$PAGE*/
/*
*********************************************************************************************************
*                                                  TASKS
*********************************************************************************************************
*/

void Task1(void *data)
{
	for (;;) {
		printf((char *)data);
		printf("-----------------------\n");	
        	OSTimeDly(50);                            
	}
}

void Task2(void *data)

{
	for (;;) {
		printf((char *)data);
		printf("-----------------------\n");	
        	OSTimeDly(20);                            
	}
}
