// Description:  This file contains register base addresses and offsets
//				 and access macros for the PXA255 on-chip peripherals
//



//---------------------------------------
// Memory Controller - offsets and bit 
// defines are in pxa250_msc.h
#define MSC_BASE			0x48000000
#define MSC_REG(_x_)		*(vulong *)(MSC_BASE + _x_)	

//---------------------------------------
// LCD Controller
#define LCD_BASE			0x44000000
#define LCD_REG(_x_)		*(vulong *)(LCD_BASE + _x_)	

//---------------------------------------
// DMA Controller
#define DMA_BASE			0x40000000
#define DMA_REG(_x_)		*(vulong *)(DMA_BASE + _x_)	
#define DMA_DCSR0    		0x000		// DMA Control / Status Register for Channel 0  		
#define DMA_DCSR1    		0x004		// DMA Control / Status Register for Channel 1  		
#define DMA_DCSR2    		0x008		// DMA Control / Status Register for Channel 2  		
#define DMA_DCSR3    		0x00c		// DMA Control / Status Register for Channel 3  		
#define DMA_DCSR4    		0x010		// DMA Control / Status Register for Channel 4  		
#define DMA_DCSR5    		0x014		// DMA Control / Status Register for Channel 5  		
#define DMA_DCSR6    		0x018		// DMA Control / Status Register for Channel 6  		
#define DMA_DCSR7    		0x01c		// DMA Control / Status Register for Channel 7  		
#define DMA_DCSR8    		0x020		// DMA Control / Status Register for Channel 8  		
#define DMA_DCSR9    		0x024		// DMA Control / Status Register for Channel 9  		
#define DMA_DCSR10   		0x028		// DMA Control / Status Register for Channel 10  		
#define DMA_DCSR11   		0x02c		// DMA Control / Status Register for Channel 11  		
#define DMA_DCSR12   		0x030		// DMA Control / Status Register for Channel 12  		
#define DMA_DCSR13   		0x034		// DMA Control / Status Register for Channel 13  		
#define DMA_DCSR14   		0x038		// DMA Control / Status Register for Channel 14  		
#define DMA_DCSR15   		0x03c		// DMA Control / Status Register for Channel 15  		
#define DMA_DINT     		0x0f0		// DMA Interrupt Register  		
#define DMA_DRCMR0   		0x100		// Request to Channel Map Register for DREQ 0 (companion chip request 0)  		
#define DMA_DRCMR1   		0x104		// Request to Channel Map Register for DREQ 1 (companion chip request 1)  		
#define DMA_DRCMR2   		0x108		// Request to Channel Map Register for I2S receive Request  		
#define DMA_DRCMR3   		0x10c		// Request to Channel Map Register for I2S transmit Request  		
#define DMA_DRCMR4   		0x110		// Request to Channel Map Register for BTUART receive Request  		
#define DMA_DRCMR5   		0x114		// Request to Channel Map Register for BTUART transmit Request.  		
#define DMA_DRCMR6   		0x118		// Request to Channel Map Register for FFUART receive Request  		
#define DMA_DRCMR7   		0x11c		// Request to Channel Map Register for FFUART transmit Request  		
#define DMA_DRCMR8   		0x120		// Request to Channel Map Register for AC97 microphone Request  		
#define DMA_DRCMR9   		0x124		// Request to Channel Map Register for AC97 modem receive Request  		
#define DMA_DRCMR10  		0x128		// Request to Channel Map Register for AC97 modem transmit Request  		
#define DMA_DRCMR11  		0x12c		// Request to Channel Map Register for AC97 audio receive Request  		
#define DMA_DRCMR12  		0x130		// Request to Channel Map Register for AC97 audio transmit Request  		
#define DMA_DRCMR13  		0x134		// Request to Channel Map Register for SSP receive Request  		
#define DMA_DRCMR14  		0x138		// Request to Channel Map Register for SSP transmit Request  		
#define DMA_DRCMR15  		0x13c		// Reserved  		
#define DMA_DRCMR16  		0x140		// Reserved  		
#define DMA_DRCMR17  		0x144		// Request to Channel Map Register for ICP receive Request  		
#define DMA_DRCMR18  		0x148		// Request to Channel Map Register for ICP transmit Request  		
#define DMA_DRCMR19  		0x14c		// Request to Channel Map Register for STUART receive Request  		
#define DMA_DRCMR20  		0x150		// Request to Channel Map Register for STUART transmit Request  		
#define DMA_DRCMR21  		0x154		// Request to Channel Map Register for MMC receive Request  		
#define DMA_DRCMR22  		0x158		// Request to Channel Map Register for MMC transmit Request  		
#define DMA_DRCMR23  		0x15c		// RESERVED
#define DMA_DRCMR24  		0x160		// RESERVED
#define DMA_DRCMR25  		0x164		// Request to Channel Map Register for USB endpoint 1 Request
#define DMA_DRCMR26  		0x168		// Request to Channel Map Register for USB endpoint 2 Request
#define DMA_DRCMR27  		0x16c		// Request to Channel Map Register for USB endpoint 3 Request
#define DMA_DRCMR28  		0x170		// Request to Channel Map Register for USB endpoint 4 Request
#define DMA_DRCMR29  		0x174		// RESERVED
#define DMA_DRCMR30  		0x178		// Request to Channel Map Register for USB endpoint 6 Request
#define DMA_DRCMR31  		0x17c		// Request to Channel Map Register for USB endpoint 7 Request
#define DMA_DRCMR32  		0x180		// Request to Channel Map Register for USB endpoint 8 Request
#define DMA_DRCMR33  		0x184		// Request to Channel Map Register for USB endpoint 9 Request
#define DMA_DRCMR34  		0x188		// RESERVED
#define DMA_DRCMR35  		0x18c		// Request to Channel Map Register for USB endpoint 11 Request
#define DMA_DRCMR36  		0x190		// Request to Channel Map Register for USB endpoint 12 Request
#define DMA_DRCMR37  		0x194		// Request to Channel Map Register for USB endpoint 13 Request
#define DMA_DRCMR38  		0x198		// Request to Channel Map Register for USB endpoint 14 Request
#define DMA_DRCMR39  		0x19c		// RESERVED
#define DMA_DDADR0   		0x200		// DMA Descriptor Address Register channel 0
#define DMA_DSADR0   		0x204		// DMA Source Address Register channel 0
#define DMA_DTADR0   		0x208		// DMA Target Address Register channel 0
#define DMA_DCMD0    		0x20c		// DMA Command Address Register channel 0
#define DMA_DDADR1   		0x210		// DMA Descriptor Address Register channel 1
#define DMA_DSADR1   		0x214		// DMA Source Address Register channel 1
#define DMA_DTADR1   		0x218		// DMA Target Address Register channel 1
#define DMA_DCMD1    		0x21c		// DMA Command Address Register channel 1
#define DMA_DDADR2   		0x220		// DMA Descriptor Address Register channel 2
#define DMA_DSADR2   		0x224		// DMA Source Address Register channel 2
#define DMA_DTADR2   		0x228		// DMA Target Address Register channel 2
#define DMA_DCMD2    		0x22c		// DMA Command Address Register channel 2
#define DMA_DDADR3   		0x230		// DMA Descriptor Address Register channel 3
#define DMA_DSADR3   		0x234		// DMA Source Address Register channel 3
#define DMA_DTADR3   		0x238		// DMA Target Address Register channel 3
#define DMA_DCMD3    		0x23c		// DMA Command Address Register channel 3
#define DMA_DDADR4   		0x240		// DMA Descriptor Address Register channel 4
#define DMA_DSADR4   		0x244		// DMA Source Address Register channel 4
#define DMA_DTADR4   		0x248		// DMA Target Address Register channel 4
#define DMA_DCMD4    		0x24c		// DMA Command Address Register channel 4
#define DMA_DDADR5   		0x250		// DMA Descriptor Address Register channel 5
#define DMA_DSADR5   		0x254		// DMA Source Address Register channel 5
#define DMA_DTADR5   		0x258		// DMA Target Address Register channel 5
#define DMA_DCMD5    		0x25c		// DMA Command Address Register channel 5
#define DMA_DDADR6   		0x260		// DMA Descriptor Address Register channel 6
#define DMA_DSADR6   		0x264		// DMA Source Address Register channel 6
#define DMA_DTADR6   		0x268		// DMA Target Address Register channel 6
#define DMA_CMD6     		0x26c		// DMA Command Address Register channel 6
#define DMA_DADR7    		0x270		// DMA Descriptor Address Register channel 7
#define DMA_SADR7    		0x274		// DMA Source Address Register channel 7
#define DMA_TADR7    		0x278		// DMA Target Address Register channel 7
#define DMA_CMD7     		0x27c		// DMA Command Address Register channel 7
#define DMA_DADR8    		0x280		// DMA Descriptor Address Register channel 8
#define DMA_SADR8    		0x284		// DMA Source Address Register channel 8
#define DMA_TADR8    		0x288		// DMA Target Address Register channel 8
#define DMA_CMD8     		0x28c		// DMA Command Address Register channel 8
#define DMA_DADR9    		0x290		// DMA Descriptor Address Register channel 9
#define DMA_SADR9    		0x294		// DMA Source Address Register channel 9
#define DMA_TADR9    		0x298		// DMA Target Address Register channel 9
#define DMA_CMD9     		0x29c		// DMA Command Address Register channel 9
#define DMA_DADR10   		0x2a0		// DMA Descriptor Address Register channel 10
#define DMA_SADR10   		0x2a4		// DMA Source Address Register channel 10
#define DMA_TADR10   		0x2a8		// DMA Target Address Register channel 10
#define DMA_CMD10    		0x2ac		// DMA Command Address Register channel 10
#define DMA_DADR11   		0x2b0		// DMA Descriptor Address Register channel 11
#define DMA_SADR11   		0x2b4		// DMA Source Address Register channel 11
#define DMA_TADR11   		0x2b8		// DMA Target Address Register channel 11
#define DMA_CMD11    		0x2bc		// DMA Command Address Register channel 11
#define DMA_DADR12   		0x2c0		// DMA Descriptor Address Register channel 12
#define DMA_SADR12   		0x2c4		// DMA Source Address Register channel 12     
#define DMA_TADR12   		0x2c8		// DMA Target Address Register channel 12     
#define DMA_CMD12    		0x2cc		// DMA Command Address Register channel 12     
#define DMA_DADR13   		0x2d0		// DMA Descriptor Address Register channel 13     
#define DMA_SADR13   		0x2d4		// DMA Source Address Register channel 13     
#define DMA_TADR13   		0x2d8		// DMA Target Address Register channel 13     
#define DMA_CMD13    		0x2dc		// DMA Command Address Register channel 13     
#define DMA_DADR14   		0x2e0		// DMA Descriptor Address Register channel 14     
#define DMA_SADR14   		0x2e4		// DMA Source Address Register channel 14     
#define DMA_TADR14   		0x2e8		// DMA Target Address Register channel 14     
#define DMA_CMD14    		0x2ec		// DMA Command Address Register channel 14     
#define DMA_DADR15   		0x2f0		// DMA Descriptor Address Register channel 15     
#define DMA_SADR15   		0x2f4		// DMA Source Address Register channel 15     
#define DMA_TADR15   		0x2f8		// DMA Target Address Register channel 15     
#define DMA_CMD15    		0x2fc		// DMA Command Address Register channel 15     

//---------------------------------------
//     UARTs
#define FF_UART_BASE		0x40100000	// Full Function UART Base Address
#define FF_UART_REG(_x_)	*(vulong *)(FF_UART_BASE + _x_)	
#define BT_UART_BASE		0x40200000	// Bluetooth UART Base Address
#define BT_UART_REG(_x_)	*(vulong *)(BT_UART_BASE + _x_)	
#define STD_UART_BASE		0x40700000	// Standard UART Base Address
#define STD_UART_REG(_x_)	*(vulong *)(STD_UART_BASE + _x_)	

#define UART_RBR      		0x00        // Receive Buffer Register (read only)     
#define UART_THR      		0x00        // Transmit Holding Register (write only)     
#define UART_IER      		0x04        // Interrupt Enable Register (read/write)     
#define UART_IIR      		0x08        // Interrupt ID Register (read only)     
#define UART_FCR      		0x08        // FIFO Control Register (write only)     
#define UART_LCR      		0x0C        // Line Control Register (read/write)     
#define UART_MCR      		0x10        // Modem Control Register (read/write)     
#define UART_LSR      		0x14        // Line Status Register (read only)     
#define UART_MSR      		0x18        // Modem Status Register (read only)     
#define UART_SPR      		0x1C        // Scratch Pad Register (read/write)     
#define UART_DLL      		0x00        // Baud divisor lower byte (read/write)     
#define UART_DLH      		0x04        // Baud divisor higher byte (read/write)     
#define UART_ISR      		0x20        // Infrared Select Register (read/write)     

//---------------------------------------
//     I2C
#define I2C_BASE			0x40301680
#define I2C_REG(_x_)		*(vulong *)(I2C_BASE + _x_)
// pjk 030718: pxa255-pro
#define I2C_ISAR		0x20		// I2C Slave Address Register	
#define I2C_ICR			0x10		// I2C Control Register
#define I2C_IDBR		0x08		// I2C Data Buffer Register
#define I2C_ISR			0X18

//---------------------------------------
//     I2S
#define I2S_BASE		0x40400000   
#define I2S_REG(_x_)		*(vulong *)(I2S_BASE + _x_)	
#define I2S_SACR0      		0x00        // Global Control Register
#define I2S_SACR1      		0x04        // Serial Audio I2S/MSB-Justified Control Register
#define I2S_SASR0      		0x0C        // Serial Audio I2S/MSB-Justified Interface and FIFO Status Register
#define I2S_SAIMR      		0x14        // Serial Audio Interrupt Mask Register
#define I2S_SAICR      		0x18        // Serial Audio Interrupt Clear Register
#define I2S_SAITR      		0x5C        // Serial Audio Interrupt Test Register
#define I2S_SADIV      		0x60        // Audio clock divider register. See section Section 12.3
										// Serial Audio Clocks and Sampling Frequencies on page 12-7.
#define I2S_SADR       		0x80        // Serial Audio Data Register (TX and RX FIFO access register).

//---------------------------------------
//     AC97
#define AC97_BASE		0x40500000   
#define AC97_REG(_x_)		*(vulong *)(AC97_BASE + _x_)	
#define AC97_POCR        	0x000       // PCM Out Control Register
#define AC97_PICR        	0x004       // PCM In Control Register
#define AC97_MCCR        	0x008       // Mic In Control Register
#define AC97_GCR         	0x00C       // Global Control Register 
#define AC97_POSR        	0x010       // PCM Out Status Register
#define AC97_PISR        	0x014       // PCM In Status Register
#define AC97_MCSR        	0x018       // Mic In Status Register
#define AC97_GSR         	0x01C       // Global Status Register 
#define AC97_CAR         	0x020       // CODEC Access Register 
#define AC97_PCDR       	0x040       // PCM FIFO Data Register 
#define AC97_MCDR       	0x060       // Mic-in FIFO Data Register 
#define AC97_MOCR       	0x100       // MODEM Out Control Register
#define AC97_MICR       	0x108       // MODEM In Control Register
#define AC97_MOSR       	0x110       // MODEM Out Status Register
#define AC97_MISR       	0x118       // MODEM In Status Register
#define AC97_MODR       	0x140       // MODEM FIFO Data Register

//---------------------------------------
//     UDC
#define USB_BASE		0x40600000   
#define USB_REG(_x_)		*(vulong *)(USB_BASE + _x_)	
#define USB_UDCCR      		0x000          	// UDC control register
#define USB_UDCCS0     		0x010          	// UDC Endpoint 0 Control/Status Register
#define USB_UDCCS1     		0x014          	// UDC Endpoint 1 (IN) Control/Status Register
#define USB_UDCCS2     		0x018          	// UDC Endpoint 2 (OUT) Control/Status Register
#define USB_UDCCS3     		0x01C          	// UDC Endpoint 3 (IN) Control/Status Register
#define USB_UDCCS4     		0x020          	// UDC Endpoint 4 (OUT) Control/Status Register
#define USB_UDCCS5     		0x024          	// UDC Endpoint 5 (Interrupt) Control/Status Register
#define USB_UDCCS6     		0x028          	// UDC Endpoint 6 (IN) Control/Status Register
#define USB_UDCCS7     		0x02C          	// UDC Endpoint 7 (OUT) Control/Status Register
#define USB_UDCCS8     		0x030          	// UDC Endpoint 8 (IN) Control/Status Register
#define USB_UDCCS9     		0x034          	// UDC Endpoint 9 (OUT) Control/Status Register
#define USB_UDCCS10    		0x038          	// UDC Endpoint 10 (Interrupt) Control/Status Register
#define USB_UDCCS11    		0x03C          	// UDC Endpoint 11 (IN) Control/Status Register
#define USB_UDCCS12    		0x040          	// UDC Endpoint 12 (OUT) Control/Status Register
#define USB_UDCCS13    		0x044          	// UDC Endpoint 13 (IN) Control/Status Register
#define USB_UDCCS14    		0x048          	// UDC Endpoint 14 (OUT) Control/Status Register
#define USB_UDCCS15    		0x04C          	// UDC Endpoint 15 (Interrupt) Control/Status Register
#define USB_UICR0      		0x050          	// UDC Interrupt Control Register 0
#define USB_UICR1      		0x054          	// UDC Interrupt Control Register 1
#define USB_USIR0      		0x058          	// UDC Status Interrupt Register 0
#define USB_USIR1      		0x05C          	// UDC Status Interrupt Register 1
#define USB_UFNRH      		0x060          	// UDC Frame Number Register High
#define USB_UFNRL      		0x064          	// UDC Frame Number Register Low
#define USB_UDDR0      		0x080          	// UDC Endpoint 0 Data Register
#define USB_UDDR1      		0x100          	// UDC Endpoint 1 Data Register
#define USB_UDDR2      		0x1C0          	// UDC Endpoint 2 Data Register
#define USB_UDDR3      		0x200          	// UDC Endpoint 3 Data Register
#define USB_UDDR4      		0x400          	// UDC Endpoint 4 Data Register
#define USB_UDDR5      		0x0A0          	// UDC Endpoint 5 Data Register
#define USB_UDDR6      		0x600          	// UDC Endpoint 6 Data Register
#define USB_UDDR7      		0x680          	// UDC Endpoint 7 Data Register
#define USB_UDDR8      		0x700          	// UDC Endpoint 8 Data Register
#define USB_UDDR9      		0xA00          	// UDC Endpoint 9 Data Register
#define USB_UDDR10     		0x0C0          	// UDC Endpoint 10 Data Register
#define USB_UDDR11     		0xB00          	// UDC Endpoint 11 Data Register
#define USB_UDDR12     		0xB80          	// UDC Endpoint 12 Data Register
#define USB_UDDR13     		0xC00          	// UDC Endpoint 13 Data Register
#define USB_UDDR14     		0xE00          	// UDC Endpoint 14 Data Register
#define USB_UDDR15     		0x0E0          	// UDC Endpoint 15 Data Register

//---------------------------------------
//     Fast Infrared UART
#define IRDA_BASE		0x40800000  
#define IRDA_REG(_x_)		*(vulong *)(IRDA_BASE + _x_)	
#define IRDA_ICCR0      	0x00          	// ICP control register 0
#define IRDA_ICCR1      	0x04          	// ICP control register 1
#define IRDA_ICCR2      	0x08          	// ICP control register 2
#define IRDA_ICDR       	0x0C          	// ICP data register
#define IRDA_ICSR0      	0x14          	// ICP status register 0
#define IRDA_ICSR1      	0x18          	// ICP status register 1

//---------------------------------------
//     RTC
#define RTC_BASE			0x40900000   
#define RTC_REG(_x_)		*(vulong *)(RTC_BASE + _x_)	
#define RTC_RCNR       		0x00          	// RTC count register
#define RTC_RTAR       		0x04          	// RTC alarm register
#define RTC_RTSR       		0x08          	// RTC status register
#define RTC_RTTR       		0x0C          	// RTC timer trim register

//---------------------------------------
//     OS Timer
#define TMR_BASE			0x40A00000   
#define TMR_REG(_x_)		*(vulong *)(TMR_BASE + _x_)	
#define TMR_OSMR0      		0x00          	// OS timer match registers<3:0>
#define TMR_OSMR1      		0x04          	//
#define TMR_OSMR2      		0x08          	//
#define TMR_OSMR3      		0x0C          	//
#define TMR_OSCR       		0x10          	// OS timer counter register
#define TMR_OSSR       		0x14          	// OS timer status register
#define TMR_OWER       		0x18          	// OS timer watchdog enable register
#define TMR_OIER       		0x1C          	// OS timer interrupt enable register

//---------------------------------------
//     PWM 
#define PWM0_BASE		0x40B00000  
#define PWM0_REG(_x_)		*(vulong *)(PWM0_BASE + _x_)	
#define PWM1_BASE		0x40C00000  
#define PWM1_REG(_x_)		*(vulong *)(PWM1_BASE + _x_)	
#define PWM_PWMCTRL   		0x00          	// PWM Control Register
#define PWM_PWDUTY    		0x04          	// PWM Duty Cycle Register
#define PWM_PERVAL    		0x08          	// PWM Period Control Register

//---------------------------------------
//     Interrupt Control   
#define INT_BASE   		0x40D00000      // Interrupt controller IRQ pending register
#define INT_REG(_x_)		*(vulong *)(INT_BASE + _x_)	
#define INT_ICIP       		0x00      		// Interrupt controller IRQ pending register
#define INT_ICMR       		0x04      		// Interrupt controller mask register
#define INT_ICLR       		0x08      		// Interrupt controller level register
#define INT_ICFP       		0x0C      		// Interrupt controller FIQ pending register
#define INT_ICPR       		0x10      		// Interrupt controller pending register
#define INT_ICCR       		0x14      		// Interrupt controller control register

//---------------------------------------
// GPIO - Register offsets and bit 
// defines are in pxa250_gpio.h
#define GPIO_BASE		0x40E00000
#define GPIO_REG(_x_)		*(vulong *)(GPIO_BASE + _x_)	

//---------------------------------------
//     Power Manager and Reset Control
#define PWR_CTL_BASE		0x40F00000  	 
#define PWR_REG(_x_)		*(vulong *)(PWR_CTL_BASE + _x_)	
#define PWR_PMCR       		0x00      // Power Manager Control register
#define PWR_PSSR       		0x04      // Power Manager Sleep Status register
#define PWR_PSPR       		0x08      // Power Manager Scratch Pad register
#define PWR_PWER       		0x0C      // Power Manager Wake-up Enable register
#define PWR_PRER       		0x10      // Power Manager GPIO Rising-edge Detect Enable register
#define PWR_PFER       		0x14      // Power Manager GPIO Falling-edge Detect Enable register
#define PWR_PEDR       		0x18      // Power Manager GPIO Edge Detect Status register
#define PWR_PCFR       		0x1C      // Power Manager General Configuration register
#define PWR_PGSRx      		0x20      // Power Manager GPIO Sleep State register for GP[31-0]
#define PWR_PGSRy      		0x24      // Power Manager GPIO Sleep State register for GP[63-32]
#define PWR_PGSRz      		0x28      // Power Manager GPIO Sleep State register for GP[84-64]
#define PWR_RCSR       		0x30      // Reset controller status register

//---------------------------------------
//     Clocks Manager
#define CLK_BASE		0x41300000   
#define CLK_REG(_x_)		*(vulong *)(CLK_BASE + _x_)	
#define CLK_CCCR       		0x00          // Core Clock Configuration Register
#define CLK_CKEN       		0x04          // Clock Enable Register
#define CLK_OSCC       		0x08          // Oscillator Configuration Register

//---------------------------------------
//     SSP
#define SSP_BASE		0x41000000  
#define SSP_REG(_x_)		*(vulong *)(SSP_BASE + _x_)	
#define SSP_SSCR0      		0x00          	// SSP Control Register 0
#define SSP_SSCR1      		0x04          	// SSP Control Register 1 
#define SSP_SSSR       		0x08          	// SSP Status Register
#define SSP_SSITR      		0x0C          	// SSP Interrupt Test Register
#define SSP_SSDR       		0x10          	// SSP Data Write Register/SSP Data Read Register

//---------------------------------------
//     MMC 
#define MMC_BASE		0x41100000  
#define MMC_REG(_x_)		*(vulong *)(MMC_BASE + _x_)	
#define MMC_MMCSTRPCL  		0x00          	// Control to start and stop MMC clock	
#define MMC_MMCSTAT    		0x04          	// MMC status register (read only)	
#define MMC_MMCCLKRT   		0x08          	// MMC clock rate 	
#define MMC_MMCSPI     		0x0c          	// SPI mode control bits	
#define MMC_MMCCMDAT   		0x10          	// Command/response/data sequence control	
#define MMC_MMCRESTO   		0x14          	// Expected response time out	
#define MMC_MMCRDTO    		0x18          	// Expected data read time out	
#define MMC_MMCBLKLEN  		0x1c          	// Block length of data transaction	
#define MMC_MMCNOB     		0x20          	// "Number of blocksfor block mode"	
#define MMC_MMCPRTBUF  		0x24          	// Partial MMC_TXFIFO FIFO written	
#define MMC_MMCIMASK   		0x28          	// Interrupt Mask	
#define MMC_MMCIREG    		0x2c          	// Interrupt Register (read only)	
#define MMC_MMCCMD     		0x30          	// Index of current command	
#define MMC_MMCARGH    		0x34          	// MSW part of the current command argument	
#define MMC_MMCARGL    		0x38          	// LSW part of the current command argument	
#define MMC_MMCRES     		0x3c          	// Response FIFO (read only)	
#define MMC_MMCRXFIFO  		0x40          	// Receive FIFO (read only)	
#define MMC_MMCTXFIFO  		0x44          	// Transmit FIFO (write only)	

//==========================================================================
//
// pxa255_msc.h
//
// Author(s):    Michael Kelly, Cogent Computer Systems, Inc.
// Contributors: 
// Date:         04/17/2002
// Description:  This file contains register and bit defines for the PXA250
//               Memory Controller
//

//---------------------------------------
//  Memory Controller Register Offsets
#define MSC_MDCNFG     		0x00          			// SDRAM configuration register 0
#define MSC_MDREFR     		0x04          			// SDRAM refresh control register
#define MSC_MSC0       		0x08          			// Static memory control register 0
#define MSC_MSC1       		0x0C          			// Static memory control register 1
#define MSC_MSC2       		0x10          			// Static memory control register 2
#define MSC_MECR       		0x14          			// Expansion memory (PCMCIA / Compact Flash) bus configuration register
#define MSC_SXCNFG     		0x1C          			// Synchronous static memory control register
#define MSC_SXMRS      		0x24          			// MRS value to be written to Synchronous Flash or SMROM
#define MSC_MCMEM0     		0x28          			// Card interface Common Memory Space Socket 0 Timing Configuration
#define MSC_MCMEM1     		0x2C          			// Card interface Common Memory Space Socket 1 Timing Configuration
#define MSC_MCATT0     		0x30          			// Card interface Attribute Space Socket 0 Timing Configuration
#define MSC_MCATT1     		0x34          			// Card interface Attribute Space Socket 1 Timing Configuration
#define MSC_MCIO0      		0x38          			// Card interface I/O Space Socket 0 Timing Configuration
#define MSC_MCIO1      		0x3C          			// Card interface I/O Space Socket 1 Timing Configuration
#define MSC_MDMRS      		0x40          			// MRS value to be written to SDRAM
#define MSC_BOOTDEF    		0x44          			// Read-Only Boot-time register. Contains BOOT_SEL and PKG_SEL values.


// SDRAM configuration register 0
// Pair 2/3
#define MDCNFG_DSA1111_1	BIT28					// Use SA1111 Addressing Muxing Mode for pair 2/3.
#define MDCNFG_DLATCH1		BIT27					// Return Data from SDRAM latching scheme for pair 2/3, must be 1
#define MDCNFG_DADDR1		BIT26					// Use alternate addressing for pair 2/3
#define MDCNFG_DTC1_0		(0x00 << 24)			// 00 - tRP = 2 clks, CL = 2, tRCD = 1 clks, tRAS(min) = 3 clks, tRC = 4 clks
#define MDCNFG_DTC1_1		(0x01 << 24)			// 01 - tRP = 2 clks, CL = 2, tRCD = 2 clks, tRAS(min) = 5 clks, tRC = 8 clks
#define MDCNFG_DTC1_2		(0x02 << 24)			// 10 - tRP = 3 clks, CL = 3, tRCD = 3 clks, tRAS(min) =7 clks, tRC=10 clks
#define MDCNFG_DTC1_3		(0x03 << 24)			// 11 - tRP = 3 clks, CL = 3, tRCD = 3 clks, tRAS(min) = 7 clks, tRC = 11 clks
#define MDCNFG_DNB1			BIT23					// Number of banks in partition pair 2/3, 0 = 2, 1 = 4
#define MDCNFG_DRAC1_11		(0x00 << 21)			// SDRAM row address bit count for partition pair 2/3
#define MDCNFG_DRAC1_12		(0x01 << 21)
#define MDCNFG_DRAC1_13		(0x02 << 21)
#define MDCNFG_DCAC1_8		(0x00 << 19)			// Number of Column Address bits for partition pair 2/3
#define MDCNFG_DCAC1_9		(0x01 << 19)
#define MDCNFG_DCAC1_10		(0x02 << 19)
#define MDCNFG_DCAC1_11		(0x03 << 19)
#define MDCNFG_DWID2_16		BIT18					// SDRAM data bus width for partition pair 2/3
#define MDCNFG_DE3			BIT17					// SDRAM enable for partition 3
#define MDCNFG_DE2			BIT16					// SDRAM enable for partition 2
// Pair 0/1
#define MDCNFG_DSA1111_0	BIT12					// Use SA1111 Addressing Muxing Mode for pair 0/1.
#define MDCNFG_DLATCH0		BIT11					// Return Data from SDRAM latching scheme for pair 0/1, must be 1
#define MDCNFG_DADDR0		BIT10					// Use alternate addressing for pair 0/1
#define MDCNFG_DTC0_0		(0x00 << 8)				// 00 - tRP = 2 clks, CL = 2, tRCD = 1 clks, tRAS(min) = 3 clks, tRC = 4 clks
#define MDCNFG_DTC0_1		(0x01 << 8)				// 01 - tRP = 2 clks, CL = 2, tRCD = 2 clks, tRAS(min) = 5 clks, tRC = 8 clks
#define MDCNFG_DTC0_2		(0x02 << 8)				// 10 - tRP = 3 clks, CL = 3, tRCD = 3 clks, tRAS(min) =7 clks, tRC=10 clks
#define MDCNFG_DTC0_3		(0x03 << 8)				// 11 - tRP = 3 clks, CL = 3, tRCD = 3 clks, tRAS(min) = 7 clks, tRC = 11 clks
#define MDCNFG_DNB0			BIT7					// Number of banks in partition pair 0/1, 0 = 2, 1 = 4
#define MDCNFG_DRAC0_11		(0x00 << 5)				// SDRAM row address bit count for partition pair 0/1
#define MDCNFG_DRAC0_12		(0x01 << 5)
#define MDCNFG_DRAC0_13		(0x02 << 5)
#define MDCNFG_DCAC0_8		(0x00 << 3)				// Number of Column Address bits for partition pair 0/1
#define MDCNFG_DCAC0_9		(0x01 << 3)
#define MDCNFG_DCAC0_10		(0x02 << 3)
#define MDCNFG_DCAC0_11		(0x03 << 3)
#define MDCNFG_DWID0_16		BIT2					// SDRAM data bus width for partition pair 0/1, 0 = 32, 1 = 16
#define MDCNFG_DE1			BIT1					// SDRAM enable for partition 1
#define MDCNFG_DE0			BIT0					// SDRAM enable for partition 0

// SDRAM refresh control register
#define MDREFR_K2FREE		BIT25					// 1 = SDCLK2 is free-running (ignores MDREFR[APD] or MDREFR[K2RUN] bits)
#define MDREFR_K1FREE		BIT24					// 1 = SDCLK1 is free-running (ignores MDREFR[APD] or MDREFR[K1RUN] bits)
#define MDREFR_K0FREE		BIT23					// 1 = SDCLK0 is free-running (ignores MDREFR[APD] or MDREFR[K0RUN] bits)
#define MDREFR_SLFRSH		BIT22					// 1 = SDRAM Self-Refresh Enabled
#define MDREFR_APD			BIT20					// 1 = SDRAM/Synchronous Static Memory Auto-Power-Down Enable.
#define MDREFR_K2DB2		BIT19					// SDCLK2 Divide by 2, 1 = Divide by 2
#define MDREFR_K2RUN		BIT18					// SDCLK2 Run Control, 1 = Run
#define MDREFR_K1DB2		BIT17					// SDCLK1 Divide by 2, 1 = Divide by 2
#define MDREFR_K1RUN		BIT16					// SDCLK1 Run Control, 1 = Run
#define MDREFR_E1PIN		BIT15					// SDCKE1 Level Control, 1 = Enabled
#define MDREFR_K0DB2		BIT14					// SDCLK0 Divide by 2, 1 = Divide by 2
#define MDREFR_K0RUN		BIT13					// SDCLK0 Run Control, 1 = Run
#define MDREFR_E0PIN		BIT12					// SDCKE0 Level Control, 1 = Enabled
#define MDREFR_DRI(_x_)		(_x_ & 0xfff)			// Refresh Interval = (Refresh time/rows) x (MEMCLK/32)

// Static memory control register 0/1/2
// Chip Selects 1/3/5
#define MSC_RBUFF1			BIT31					// Return Data Buffer vs. Streaming behavior.
#define MSC_RRR1(_x_)		((_x_ & 0x7) << 28) 	// ROM/SRAM recovery time.
#define MSC_RDN1(_x_)		((_x_ & 0xf) << 24) 	// ROM delay next access
#define MSC_RDF1(_x_)		((_x_ & 0xf) << 20) 	// ROM delay first access (0-11, 12 = 13, 13 = 15, 14 = 18, 15 = 23)
#define MSC_RBW1_16			BIT19					// ROM bus width, 0 = 32, 1 = 16
#define MSC_RT1_NBROM		(0x0 << 16)				// ROM Type, Nonburst ROM or Flash Memory
#define MSC_RT1_SRAM		(0x1 << 16)				// SRAM
#define MSC_RT1_B4ROM		(0x2 << 16)				// Burst-of-four ROM or Flash (with non-burst writes)
#define MSC_RT1_B8ROM		(0x3 << 16)				// Burst-of-eight ROM or Flash (with non-burst writes)
#define MSC_RT1_VLIO		(0x4 << 16)				// Variable Latency I/O (VLIO)
// Chip Selects 0/2/4
#define MSC_RBUFF0			BIT15					// Return Data Buffer vs. Streaming behavior.
#define MSC_RRR0(_x_)		((_x_ & 0x7) << 12) 	// ROM/SRAM recovery time.
#define MSC_RDN0(_x_)		((_x_ & 0xf) << 8) 		// ROM delay next access
#define MSC_RDF0(_x_)		((_x_ & 0xf) << 4) 		// ROM delay first access (0-11, 12 = 13, 13 = 15, 14 = 18, 15 = 23)
#define MSC_RBW0_16			BIT3					// ROM bus width, 0 = 32, 1 = 16
#define MSC_RT0_NBROM		(0x0 << 0)				// ROM Type, Nonburst ROM or Flash Memory
#define MSC_RT0_SRAM		(0x1 << 0)				// SRAM
#define MSC_RT0_B4ROM		(0x2 << 0)				// Burst-of-four ROM or Flash (with non-burst writes)
#define MSC_RT0_B8ROM		(0x3 << 0)				// Burst-of-eight ROM or Flash (with non-burst writes)
#define MSC_RT0_VLIO		(0x4 << 0)				// Variable Latency I/O (VLIO)

// Synchronous static memory control register
// Pair 2/3
#define SXCNFG_SXLATCH2		BIT15					// SXMEM latching scheme for pair 2/3, must be 1
#define SXCNFG_SXTP2_SMROM	(0x0 << 13) 			// SX Memory type for pair 2/3, Sync Masked ROM
#define SXCNFG_SXTP2_NONSD	(0x2 << 13)				// Non-SDRAM type Sync FLASH
#define SXCNFG_SXCA2_7		(0x0 << 11)				// SX Memory column address bit count for pair 2/3
#define SXCNFG_SXCA2_8		(0x1 << 11)
#define SXCNFG_SXCA2_9		(0x2 << 11)
#define SXCNFG_SXCA2_10		(0x3 << 11)
#define SXCNFG_SXRA2_12		(0x0 << 9)				// SX Memory row address bit count for pair 2/3
#define SXCNFG_SXRA2_13		(0x1 << 9)
#define SXCNFG_SXRL2(_x_)	((_x_ & 0x7) << 21) 	// RAS Latency for pair 2/3. Must be 0x7 for SXCNFG_SXTP2_NONSD
#define SXCNFG_SXCL2_3		(0x2 << 18)				// CAS Latency for pair 2/3
#define SXCNFG_SXCL2_4		(0x3 << 18)
#define SXCNFG_SXCL2_5		(0x4 << 18)
#define SXCNFG_SXCL2_6		(0x5 << 18)
#define SXCNFG_SXCL2_7		(0x6 << 18)				// SXCNFG_SXTP2_NONSD only
#define SXCNFG_SXEN3		BIT17					// Enable Bit for Partition 3
#define SXCNFG_SXEN2		BIT16					// Enable Bit for Partition 2
// Pair 0/1
#define SXCNFG_SXLATCH0		BIT14					// SXMEM latching scheme for pair 0/1, must be 1
#define SXCNFG_SXTP0_SMROM	(0x0 << 12) 			// SX Memory type for pair 0/1, Sync Masked ROM
#define SXCNFG_SXTP0_NONSD	(0x2 << 12)				// Non-SDRAM type Sync FLASH
#define SXCNFG_SXCA0_7		(0x0 << 10)				// SX Memory column address bit count for pair 0/1
#define SXCNFG_SXCA0_8		(0x1 << 10)
#define SXCNFG_SXCA0_9		(0x2 << 10)
#define SXCNFG_SXCA0_10		(0x3 << 10)
#define SXCNFG_SXRA0_12		(0x0 << 8)				// SX Memory row address bit count for pair 0/1
#define SXCNFG_SXRA0_13		(0x1 << 8)
#define SXCNFG_SXRL0(_x_)	((_x_ & 0x7) << 5) 		// RAS Latency for pair 0/1. Must be 0x7 for SXCNFG_SXTP2_NONSD
#define SXCNFG_SXCL0_3		(0x2 << 2)				// CAS Latency for pair 0/1
#define SXCNFG_SXCL0_4		(0x3 << 2)
#define SXCNFG_SXCL0_5		(0x4 << 2)
#define SXCNFG_SXCL0_6		(0x5 << 2)
#define SXCNFG_SXCL0_7		(0x6 << 2)				// SXCNFG_SXTP2_NONSD only
#define SXCNFG_SXEN1		BIT1					// Enable Bit for Partition 1
#define SXCNFG_SXEN0		BIT0					// Enable Bit for Partition 0

// MRS value to be written to Synchronous Flash or SMROM
#define SXMRS_SXMRS2(_x_)	((_x_ & 0x7fff) << 16)	// Value to write for SX Memory requiring and MRS, pair 2/3
#define SXMRS_SXMRS0(_x_)	((_x_ & 0x7fff) << 0)	// Value to write for SX Memory requiring and MRS, pair 0/1

// Memory Card Interface Timing Configurations
// Values are valid for MEMC0/1, MCATT0/1 and MCIO0/1
#define MCTMG_HOLD(_x_)		((_x_ & 0x3f) << 14)	// # MEMCLKs to hold address after command deassertion
#define MCTMG_ASST(_x_)		((_x_ & 0x1f) << 7)		// Code for the command assertion time. See Table 6-26.
#define MCTMG_SET(_x_)		((_x_ & 0x7f) << 0)		// # MEMCLKs to set up address before command assertion

// Expansion memory (PCMCIA / Compact Flash) bus configuration register
// MECR_CIT must be set appropriately by software after card detection 
// is complete
#define MECR_CIT			BIT1					// Card-Is-There, 0 - No card inserted, 1 - Card inserted
#define MECR_NOS			BIT0					// Number-of-Sockets, 0 - 1 Socket, 1 - 2 Sockets

// Read-Only Boot-time register. Contains BOOT_SEL and PKG_SEL values.
#define BOOTDEF_PKG_TYPE	BIT3					// Processor type. 1 - PXA250 application processor
#define BOOTDEF_BOOT_SEL	0x7						// BOOT_SEL[2:0] pins

#define FFUART_BASE       0x40100000

#define FFRBR             0x00
#define FFTHR             0x00
#define FFIER             0x04
#define FFIIR             0x08
#define FFFCR             0x08
#define FFLCR             0x0C
#define FFMCR             0x10
#define FFLSR             0x14
#define FFMSR             0x18
#define FFSPR             0x1C
#define FFISR             0x20
#define FFDLL             0x00
#define FFDLH             0x04
//FFUART Register initial values (9600 bps, 8N1)
#define FFIER_VALUE       0x00000057
#define FFFCR_VALUE       0x00000041
#define FFLCR_VALUE_SETUP       0x00000083
#define FFLCR_VALUE_USAGE       0x00000003
#define FFMCR_VALUE       0x00000000
#define FFSPR_VALUE       0x00000000
#define FFISR_VALUE       0x00000000
#define FFDLL_VALUE       0x00000000//0x00000018
#define FFDLH_VALUE       0x00000010

#define GPIO_BASE	0x40E00000
#define GPIO_REG(_x_)	*(volatile unsigned long *)(GPIO_BASE + _x_)
#define GPIO_GPLR0      0x00        // GPIO<31:0>   status register 
#define GPIO_GPLR1      0x04        // GPIO<63:32>  status register 
#define GPIO_GPLR2      0x08        // GPIO<80:64>  status register 
#define GPIO_GPDR0      0x0C        // GPIO<31:0>   direction register 
#define GPIO_GPDR1      0x10        // GPIO<63:32>  direction register 
#define GPIO_GPDR2      0x14        // GPIO<80:64>  direction register 
#define GPIO_GPSR0      0x18        // GPIO<31:0>   output set register 
#define GPIO_GPSR1      0x1C        // GPIO<63:32>  output set register 
#define GPIO_GPSR2      0x20        // GPIO<80:64>  output set register 
#define GPIO_GPCR0      0x24        // GPIO<31:0>   output clear register 
#define GPIO_GPCR1      0x28        // GPIO<63:32>  output clear register 
#define GPIO_GPCR2      0x2C        // GPIO<80:64>  output clear register 
#define GPIO_GRER0      0x30        // GPIO<31:0>   rising-edge detect register 
#define GPIO_GRER1      0x34        // GPIO<63:32>  rising-edge detect register 
#define GPIO_GRER2      0x38        // GPIO<80:64>  rising-edge detect register 
#define GPIO_GFER0      0x3C        // GPIO<31:0>   falling-edge detect register 
#define GPIO_GFER1      0x40        // GPIO<63:32>  falling-edge detect register    
#define GPIO_GFER2      0x44        // GPIO<80:64>  falling-edge detect register                         
#define GPIO_GEDR0      0x48        // GPIO<31:0>   edge detect status register 
#define GPIO_GEDR1      0x4C        // GPIO<63:32>  edge detect status register 
#define GPIO_GEDR2      0x50        // GPIO<80:64>  edge detect status register 
#define GPIO_GAFR0L     0x54        // GPIO<15:0>   alternate function select register 0 Lower           
#define GPIO_GAFR0U     0x58        // GPIO<31:16>  alternate function select register 0 Upper           
#define GPIO_GAFR1L     0x5C        // GPIO<47:32>  alternate function select register 1 Lower           
#define GPIO_GAFR1U     0x60        // GPIO<63:48>  alternate function select register 1 Upper           
#define GPIO_GAFR2L     0x64        // GPIO<79:64>  alternate function select register 2 Lower           
#define GPIO_GAFR2U     0x68        // GPIO80       alternate function select register 2 Upper           

#define BIT0                0x00000001
#define BIT1                0x00000002
#define BIT2                0x00000004
#define BIT3                0x00000008
#define BIT4                0x00000010
#define BIT5                0x00000020
#define BIT6                0x00000040
#define BIT7                0x00000080
#define BIT8                0x00000100
#define BIT9                0x00000200
#define BIT10               0x00000400
#define BIT11               0x00000800
#define BIT12               0x00001000
#define BIT13               0x00002000
#define BIT14               0x00004000
#define BIT15               0x00008000
#define BIT16               0x00010000
#define BIT17               0x00020000
#define BIT18               0x00040000
#define BIT19               0x00080000
#define BIT20               0x00100000
#define BIT21               0x00200000
#define BIT22               0x00400000
#define BIT23               0x00800000
#define BIT24               0x01000000
#define BIT25               0x02000000
#define BIT26               0x04000000
#define BIT27               0x08000000
#define BIT28               0x10000000
#define BIT29               0x20000000
#define BIT30               0x40000000
#define BIT31               0x80000000


#define GPIO_0          BIT0
#define GPIO_1          BIT1
#define GPIO_2          BIT2
#define GPIO_3          BIT3
#define GPIO_4          BIT4
#define GPIO_5          BIT5
#define GPIO_6          BIT6
#define GPIO_7          BIT7
#define GPIO_8          BIT8
#define GPIO_9          BIT9
#define GPIO_10         BIT10
#define GPIO_11         BIT11
#define GPIO_12         BIT12
#define GPIO_13         BIT13
#define GPIO_14         BIT14
#define GPIO_15         BIT15
#define GPIO_16         BIT16
#define GPIO_17         BIT17
#define GPIO_18         BIT18
#define GPIO_19         BIT19
#define GPIO_20         BIT20
#define GPIO_21         BIT21
#define GPIO_22         BIT22
#define GPIO_23         BIT23
#define GPIO_24         BIT24
#define GPIO_25         BIT25
#define GPIO_26         BIT26
#define GPIO_27         BIT27
#define GPIO_28         BIT28
#define GPIO_29         BIT29
#define GPIO_30         BIT30
#define GPIO_31         BIT31
// GPLR1, GPDR1, GPSR1, GPCR1, GPRE1, GPFE1, GPED1
#define GPIO_32         BIT0
#define GPIO_33         BIT1
#define GPIO_34         BIT2
#define GPIO_35         BIT3
#define GPIO_36         BIT4
#define GPIO_37         BIT5
#define GPIO_38         BIT6
#define GPIO_39         BIT7
#define GPIO_40         BIT8
#define GPIO_41         BIT9
#define GPIO_42         BIT10
#define GPIO_43         BIT11
#define GPIO_44         BIT12
#define GPIO_45         BIT13
#define GPIO_46         BIT14
#define GPIO_47         BIT15
#define GPIO_48         BIT16
#define GPIO_49         BIT17
#define GPIO_50         BIT18
#define GPIO_51         BIT19
#define GPIO_52         BIT20
#define GPIO_53         BIT21
#define GPIO_54         BIT22
#define GPIO_55         BIT23
#define GPIO_56         BIT24
#define GPIO_57         BIT25
#define GPIO_58         BIT26
#define GPIO_59         BIT27
#define GPIO_60         BIT28
#define GPIO_61         BIT29
#define GPIO_62         BIT30
#define GPIO_63         BIT31
// GPLR2, GPDR2, GPSR2, GPCR2, GPRE2, GPFE2, GPED2
#define GPIO_64         BIT0
#define GPIO_65         BIT1
#define GPIO_66         BIT2
#define GPIO_67         BIT3
#define GPIO_68         BIT4
#define GPIO_69         BIT5
#define GPIO_70         BIT6
#define GPIO_71         BIT7
#define GPIO_72         BIT8
#define GPIO_73         BIT9
#define GPIO_74         BIT10
#define GPIO_75         BIT11
#define GPIO_76         BIT12
#define GPIO_77         BIT13
#define GPIO_78         BIT14
#define GPIO_79         BIT15
#define GPIO_80         BIT16
// pjk 040828: pxa255-pro3
#define GPIO_81         BIT17
#define GPIO_84		BIT20

#define AF0     0x0      
#define AF1     0x1      
#define AF2     0x2      
#define AF3     0x3      
                         


// GPAFR0_L              
#define GPIO_0_AF                   AF0 << 0
#define GPIO_1_AF_RST               AF1 << 2    // Set GPDR0, bit GPIO_1 = 0
#define GPIO_2_AF                   AF0 << 4
#define GPIO_3_AF                   AF0 << 6
#define GPIO_4_AF                   AF0 << 8
#define GPIO_5_AF                   AF0 << 10
#define GPIO_6_AF_MMC_CLK           AF1 << 12   // Set GPDR0, bit GPIO_6 = 1
#define GPIO_7_AF_48MHZ             AF1 << 14   // Set GPDR0, bit GPIO_7 = 1
#define GPIO_8_AF_MMC_CS0           AF1 << 16   // Set GPDR0, bit GPIO_8 = 1
#define GPIO_9_AF_MMC_CS1           AF1 << 18   // Set GPDR0, bit GPIO_9 = 1
#define GPIO_10_AF_RTC_CLK          AF1 << 20   // Set GPDR0, bit GPIO_10 = 1
#define GPIO_11_AF_3_68MHZ          AF1 << 22   // Set GPDR0, bit GPIO_11 = 1
#define GPIO_12_AF_32KHZ            AF1 << 24   // Set GPDR0, bit GPIO_12 = 1
#define GPIO_13_AF_MBGNT            AF2 << 26   // Set GPDR0, bit GPIO_13 = 1
#define GPIO_14_AF_MBREQ            AF1 << 28   // Set GPDR0, bit GPIO_14 = 0
#define GPIO_15_AF_CS1              AF2 << 30   // Set GPDR0, bit GPIO_15 = 1
// GPAFR0_U
#define GPIO_16_AF_PWM0             AF2 << 0    // Set GPDR0, bit GPIO_16 = 1
#define GPIO_17_AF_PWM1             AF2 << 2    // Set GPDR0, bit GPIO_17 = 1
#define GPIO_18_AF_RDY              AF1 << 4    // Set GPDR0, bit GPIO_18 = 0
#define GPIO_19_AF_DREQ1            AF1 << 6    // Set GPDR0, bit GPIO_19 = 0
#define GPIO_20_AF_DREQ0            AF1 << 8    // Set GPDR0, bit GPIO_20 = 0
#define GPIO_21_AF                  AF0 << 10
#define GPIO_22_AF                  AF0 << 12
#define GPIO_23_AF_SSP_CLK          AF2 << 14   // Set GPDR0, bit GPIO_23 = 1
#define GPIO_24_AF_SSP_FRM          AF2 << 16   // Set GPDR0, bit GPIO_24 = 1
#define GPIO_25_AF_SSP_TXD          AF2 << 18   // Set GPDR0, bit GPIO_25 = 1
#define GPIO_26_AF_SSP_RXD          AF1 << 20   // Set GPDR0, bit GPIO_26 = 0
#define GPIO_27_AF_SSP_EXTCLK       AF1 << 22   // Set GPDR0, bit GPIO_27 = 0
#define GPIO_28_AF_AC97_BCLK_IN     AF1 << 24   // When GPDR0, bit GPIO_28 = 0
#define GPIO_28_AF_I2S_BCLK_IN      AF2 << 24   // When GPDR0, bit GPIO_28 = 0
#define GPIO_28_AF_I2S_BCLK_OUT     AF1 << 24   // When GPDR0, bit GPIO_28 = 1
#define GPIO_28_AF_AC97_BCLK_OUT    AF2 << 24   // When GPDR0, bit GPIO_28 = 1
#define GPIO_29_AF_AC97_SDIN0       AF1 << 26   // Set GPDR0, bit GPIO_29 = 0
#define GPIO_29_AF_I2S_SDIN         AF2 << 26   // Set GPDR0, bit GPIO_29 = 0
#define GPIO_30_AF_I2S_SDOUT        AF1 << 28   // Set GPDR0, bit GPIO_30 = 1
#define GPIO_30_AF_AC97_SDOUT       AF2 << 28   // Set GPDR0, bit GPIO_30 = 1
#define GPIO_31_AF_I2S_SYNC         AF1 << 30   // Set GPDR0, bit GPIO_31 = 1
#define GPIO_31_AF_AC97_SYNC        AF2 << 30   // Set GPDR0, bit GPIO_31 = 1

// GPAFR1_L
#define GPIO_32_AF_AC97_SDIN1       AF1 << 0    // When GPDR1, BIT GPIO_32 = 0
#define GPIO_32_AF_I2S_SYSCLK       AF1 << 0    // When GPDR1, BIT GPIO_32 = 1
#define GPIO_33_AF_CS5              AF2 << 2    // Set GPDR1, BIT GPIO_33 = 1
#define GPIO_34_AF_FF_RXD           AF1 << 4    // Set GPDR1, BIT GPIO_34 = 0
#define GPIO_34_AF_MMC_CS0          AF2 << 4    // Set GPDR1, BIT GPIO_34 = 1
#define GPIO_35_AF_FF_CTS           AF1 << 6    // Set GPDR1, BIT GPIO_35 = 0
#define GPIO_36_AF_FF_DCD           AF1 << 8    // Set GPDR1, BIT GPIO_36 = 0
#define GPIO_37_AF_FF_DSR           AF1 << 10   // Set GPDR1, BIT GPIO_37 = 0
#define GPIO_38_AF_FF_RI            AF1 << 12   // Set GPDR1, BIT GPIO_38 = 0
#define GPIO_39_AF_MM_CS1           AF1 << 14   // Set GPDR1, BIT GPIO_39 = 1
#define GPIO_39_AF_FF_TXD           AF2 << 14   // Set GPDR1, BIT GPIO_39 = 1
#define GPIO_40_AF_FF_DTR           AF2 << 16   // Set GPDR1, BIT GPIO_40 = 1
#define GPIO_41_AF_FF_RTS           AF2 << 18   // Set GPDR1, BIT GPIO_41 = 1
#define GPIO_42_AF_BT_RXD           AF1 << 20   // Set GPDR1, BIT GPIO_42 = 0
#define GPIO_43_AF_BT_TXD           AF2 << 22   // Set GPDR1, BIT GPIO_43 = 1
#define GPIO_44_AF_BT_CTS           AF1 << 24   // Set GPDR1, BIT GPIO_44 = 0
#define GPIO_45_AF_BT_RTS           AF2 << 26   // Set GPDR1, BIT GPIO_45 = 1
#define GPIO_46_AF_IR_RXD           AF1 << 28   // Set GPDR1, BIT GPIO_46 = 0
#define GPIO_46_AF_STD_RXD          AF2 << 28   // Set GPDR1, BIT GPIO_46 = 0
#define GPIO_47_AF_IR_TXD           AF1 << 30   // Set GPDR1, BIT GPIO_47 = 1
#define GPIO_47_AF_STD_TXD          AF2 << 30   // Set GPDR1, BIT GPIO_47 = 1

// GPAFR1_U
#define GPIO_48_AF_POE              AF2 << 0    // Set GPDR1, BIT GPIO_48 = 1
#define GPIO_49_AF_PWE              AF2 << 2    // Set GPDR1, BIT GPIO_49 = 1
#define GPIO_50_AF_PIOR             AF2 << 4    // Set GPDR1, BIT GPIO_50 = 1
#define GPIO_51_AF_PIOW             AF2 << 6    // Set GPDR1, BIT GPIO_51 = 1
#define GPIO_52_AF_PCE1             AF2 << 8    // Set GPDR1, BIT GPIO_52 = 1
#define GPIO_53_AF_MMC_CLK          AF1 << 10   // Set GPDR1, BIT GPIO_53 = 1
#define GPIO_53_AF_PCE2             AF2 << 10   // Set GPDR1, BIT GPIO_53 = 1
#define GPIO_54_AF_MMC_CLK          AF1 << 12   // Set GPDR1, BIT GPIO_54 = 1
#define GPIO_54_AF_PSKTSEL          AF2 << 12   // Set GPDR1, BIT GPIO_54 = 1
#define GPIO_55_AF_PREG             AF2 << 14   // Set GPDR1, BIT GPIO_55 = 1
#define GPIO_56_AF_PWAIT            AF1 << 16   // Set GPDR1, BIT GPIO_56 = 0
#define GPIO_57_AF_IOIS16           AF1 << 18   // Set GPDR1, BIT GPIO_57 = 0
#define GPIO_58_AF_LDD0             AF2 << 20   // Set GPDR1, BIT GPIO_58 = 1
#define GPIO_59_AF_LDD1             AF2 << 22   // Set GPDR1, BIT GPIO_59 = 1
#define GPIO_60_AF_LDD2             AF2 << 24   // Set GPDR1, BIT GPIO_60 = 1
#define GPIO_61_AF_LDD3             AF2 << 26   // Set GPDR1, BIT GPIO_61 = 1
#define GPIO_62_AF_LDD4             AF2 << 28   // Set GPDR1, BIT GPIO_62 = 1
#define GPIO_63_AF_LDD5             AF2 << 30   // Set GPDR1, BIT GPIO_63 = 1
// GPAFR2_L
#define GPIO_64_AF_LDD6             AF2 << 0    // Set GPDR1, BIT GPIO_64 = 1
#define GPIO_65_AF_LDD7             AF2 << 2    // Set GPDR1, BIT GPIO_65 = 1
#define GPIO_66_AF_MBREQ            AF1 << 4    // Set GPDR1, BIT GPIO_66 = 0
#define GPIO_66_AF_LDD8             AF2 << 4    // Set GPDR1, BIT GPIO_66 = 1
#define GPIO_67_AF_MMC_CS0          AF1 << 6    // Set GPDR1, BIT GPIO_67 = 1
#define GPIO_67_AF_LDD9             AF2 << 6    // Set GPDR1, BIT GPIO_67 = 1
#define GPIO_68_AF_MMC_CS1          AF1 << 8    // Set GPDR1, BIT GPIO_68 = 1
#define GPIO_68_AF_LDD10            AF2 << 8    // Set GPDR1, BIT GPIO_68 = 1
#define GPIO_69_AF_MMC_CLK          AF1 << 10   // Set GPDR1, BIT GPIO_69 = 1
#define GPIO_69_AF_LDD11            AF2 << 10   // Set GPDR1, BIT GPIO_69 = 1
#define GPIO_70_AF_RTC_CLK          AF1 << 12   // Set GPDR1, BIT GPIO_70 = 1
#define GPIO_70_AF_LDD12            AF2 << 12   // Set GPDR1, BIT GPIO_70 = 1
#define GPIO_71_AF_3_68MHZ          AF1 << 14   // Set GPDR1, BIT GPIO_71 = 1
#define GPIO_71_AF_LDD13            AF2 << 14   // Set GPDR1, BIT GPIO_71 = 1
#define GPIO_72_AF_32KHZ            AF1 << 16   // Set GPDR1, BIT GPIO_72 = 1
#define GPIO_72_AF_LDD14            AF2 << 16   // Set GPDR1, BIT GPIO_72 = 1
#define GPIO_73_AF_MBGNT            AF1 << 18   // Set GPDR1, BIT GPIO_73 = 1
#define GPIO_73_AF_LDD15            AF2 << 18   // Set GPDR1, BIT GPIO_73 = 1
#define GPIO_74_AF_LCD_FCLK         AF2 << 20   // Set GPDR1, BIT GPIO_74 = 1
#define GPIO_75_AF_LCD_LCLK         AF2 << 22   // Set GPDR1, BIT GPIO_75 = 1
#define GPIO_76_AF_LCD_PCLK         AF2 << 24   // Set GPDR1, BIT GPIO_76 = 1
#define GPIO_77_AF_LCD_BIAS         AF2 << 26   // Set GPDR1, BIT GPIO_77 = 1
#define GPIO_78_AF_CS2              AF2 << 28   // Set GPDR1, BIT GPIO_78 = 1
#define GPIO_79_AF_CS3              AF2 << 30   // Set GPDR1, BIT GPIO_79 = 1

// GPAFR2_U
#define GPIO_80_AF_CS4              AF2 << 0    // Set GPDR1, BIT GPIO_80 = 1

// Power management 
#define RCSR              0x40F00030
#define RCSR_SLEEP        0x00000004
#define PSPR              0x40F00008
#define PSSR              0x40F00004
#define PSSR_PH           0x00000010
#define PSSR_RDH          0x00000020
#define PSSR_STATUS_MASK  0x00000007

// Timer management
#define RCNR			0x40900000
#define RTTR			0x4090000C
#define OSCR			0x40A00010
#define CLK_TO_10MS		36864			// 3.686400 Mhz
#define RTAR			0x40900004
#define RTSR			0x40900008
