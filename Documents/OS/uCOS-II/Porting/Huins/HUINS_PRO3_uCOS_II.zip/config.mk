#
# pjk 050608
#

CROSS_COMPILE = armv5l-linux-

#
# Include the make variables (CC, etc...)
#
AS	= $(CROSS_COMPILE)as
LD	= $(CROSS_COMPILE)ld
CC	= $(CROSS_COMPILE)gcc
CPP	= $(CC) -E
AR	= ar
NM	= $(CROSS_COMPILE)nm
STRIP	= $(CROSS_COMPILE)strip
OBJCOPY = $(CROSS_COMPILE)objcopy
OBJDUMP = $(CROSS_COMPILE)objdump
RANLIB	= $(CROSS_COMPILE)ranlib

UCOS	= ucosii
PORT	= pxa255
APP	= appl

INCLUDE = -I$(TOPDIR)/includes -I./
CFLAGS = -O1 -Wall -mcpu=xscale -mtune=xscale -msoft-float -fno-builtin -fomit-frame-pointer -mapcs-32 -nostdinc $(INCLUDE)
CPPFLAGS += $(INCLUDE)
COMPILE = $(CC) $(CFLAGS)

COMPILER = ARM-LINUX-GCC_332
TARGET	 = PXA255_PRO3
APPLICATION_DIR = EX5_PXA255

