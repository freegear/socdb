#!/bin/sh 
#-----------------------------------------------------------------------------
# Taiwan Semiconductor Manufacturing Company, Ltd.
#-----------------------------------------------------------------------------
#
# CADENCE LEF 5.5 Stream Layer Mapping Table Generator 
#
#-----------------------------------------------------------------------------
# History:
#
# REV 1.0 21/07/03   created
#
#-----------------------------------------------------------------------------

#
# mapping table
#
M3='#-----------------------------------------------------------------------------
# Taiwan Semiconductor Manufacturing Company, Ltd.
#-----------------------------------------------------------------------------
#
# CADENCE LEF 5.5 Stream layer mapping table for TSMC DSD 
#
#-----------------------------------------------------------------------------
# Layer/ Object Name Layer/ Object Type Layer Number Datatype
# <t_ layerObjectName> <t_ objectType> <n_ layerNum> <n_ datatype>
PO              NET                             17      0
CO              VIA                             30      0
M1		NET, SPNET, VIA			31	0
M2		NET, SPNET, VIA			32	0
M3		NET, SPNET, VIA			33	0
VIA1		VIA				51	0
VIA2		VIA				52	0
M1		PIN				131	0
M2		PIN				132	0
M3		PIN				133	0
M1		FILL				31	1
M2		FILL				32	1
M3		FILL				33	1
VIA1		VIAFILL				51	1
VIA2		VIAFILL				52	1
DIEAREA 	ALL 				108	0
COMP		ALL				127	0
NAME		COMP				127	0
NAME		M1/PIN				131	0
NAME		M2/PIN				132	0
NAME		M3/PIN				133	0'
M4='M4		NET, SPNET, VIA			34	0
M4		FILL				34	1
M4		PIN				134	0
VIA3		VIAFILL				53	1
VIA3		VIA				53	0
NAME		M4/PIN				134	0'
M5='M5		NET, SPNET, VIA			35	0
M5		FILL				35	1
M5		PIN				135	0
VIA4		VIAFILL				54	1
VIA4		VIA				54	0
NAME		M5/PIN				135	0'
M6='M6		NET, SPNET, VIA			36	0
M6		FILL				36	1
M6		PIN				136	0
VIA5		VIAFILL				55	1
VIA5		VIA				55	0
NAME		M6/PIN				136	0'
M7='M7		NET, SPNET, VIA			37	0
M7		FILL				37	1
M7		PIN				137	0
VIA6		VIAFILL				56	1
VIA6		VIA				56	0
NAME		M7/PIN				137	0'
M8='M8		NET, SPNET, VIA			38	0
M8		FILL				38      1
M8		PIN				138	0
VIA7		VIAFILL				57	1
VIA7		VIA				57	0
NAME		M8/PIN				138	0'
M9='M9		NET, SPNET, VIA			39	0
M9		FILL				39	1
M9		PIN				139	0
VIA8		VIAFILL				58	1
VIA8		VIA				58	0
NAME		M9/PIN				139	0'


EXE=`basename $0`
HELP="
 
CADENCE LEF5.5 Stream Layer Mapping Table Utility:
 
> $EXE <options>

Example:

> $EXE -layer 4 

Options:
 
  -h|-help        HELP, print this message
 
  -layer          Metal Layer number 9|8|7|6|5|4|3, Default is \"5\". 
                  Create a \"gds2.map\" for the specified layer number.
 
"
#
# argument
#
mapfile="gds2.map"
layer="5"

[ -z "$1" ] && { echo "$HELP"; exit 0; }
while [ -n "$1" ]; do
case "$1" in
  -h|-help)
    echo "$HELP"; exit 0;
    ;;
  -layer)
    [ -z "$2" ] && { echo "Error: No arg $1 <layer number>"; exit 1; }
    layer="$2"; shift
    ;;
  *)
    echo "$1" | grep '^-' >/dev/null && { echo "Unknown option $1"; exit 1; }
esac
shift
done

echo "$M3" > $mapfile

[ `expr $layer \> 3` = 1 ] && { echo "$M4" >> $mapfile ; }
[ `expr $layer \> 4` = 1 ] && { echo "$M5" >> $mapfile ; }
[ `expr $layer \> 5` = 1 ] && { echo "$M6" >> $mapfile ; }
[ `expr $layer \> 6` = 1 ] && { echo "$M7" >> $mapfile ; }
[ `expr $layer \> 7` = 1 ] && { echo "$M8" >> $mapfile ; }
[ `expr $layer \> 8` = 1 ] && { echo "$M9" >> $mapfile ; }

