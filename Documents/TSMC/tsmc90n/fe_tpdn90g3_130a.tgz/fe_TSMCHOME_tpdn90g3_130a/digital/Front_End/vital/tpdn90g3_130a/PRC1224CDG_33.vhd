------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TSMC Library/IP Product
-- Filename: PRC1224CDG_33.vhd
-- Technology: CLN90G
-- Product Type: Standard I/O
-- Product Name: tpdn90g3
-- Version: 130a
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----
--  STATEMENT OF USE
--
--  This information contains confidential and proprietary information of TSMC.
--  No part of this information may be reproduced, transmitted, transcribed,
--  stored in a retrieval system, or translated into any human or computer
--  language, in any form or by any means, electronic, mechanical, magnetic,
--  optical, chemical, manual, or otherwise, without the prior written permission
--  of TSMC.  This information was prepared for informational purpose and is for
--  use by TSMC's customers only.  TSMC reserves the right to make changes in the
--  information at any time and without notice.
--
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------
--            Technology   :  tpdn90g3
--            Created by   :  NISUNG, TSMC ASIC 
--            Created Date :  Fri Dec 10 12:22:04 CST 2004
---------------------------------------------------------
---------------------------------------------------
------  The file is generated using changevital.pl
---------------------------------------------------
----- CELL PRC1224CDG_33 -----
library IEEE;
use IEEE.STD_LOGIC_1164.all;
-- synopsys translate_off 
library IEEE;
use IEEE.VITAL_Timing.all;


-- synopsys translate_on 
-- entity declaration --
entity PRC1224CDG_33 is
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_I_PAD_DS_EQ_0             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_I_PAD_DS_EQ_1             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_OEN_PAD                    :	VitalDelayType01z :=
                (0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns);
      tpd_PAD_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_IE_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PS                        :  VitalDelayType01 := (100000 ns, 100000 ns);
      tipd_PE                        :  VitalDelayType01 := (0.000 ns, 0.000 ns); 
      tipd_DS                        :  VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_I                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_IE                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_OEN                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PAD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on 
   port(
      I                              :	in    STD_ULOGIC;
      DS                             :	in    STD_ULOGIC;
      OEN                            :	in    STD_ULOGIC;
      PAD                            :	inout STD_ULOGIC;
      C                              :	out   STD_ULOGIC;
      PS                             :	in    STD_ULOGIC;
      IE                             :	in    STD_ULOGIC;
      PE                             :	in    STD_ULOGIC);
attribute VITAL_LEVEL0 of PRC1224CDG_33 : entity is TRUE;
end PRC1224CDG_33;

-- architecture body --
library IEEE;
use IEEE.VITAL_Primitives.all;
library VITAL;
use VITAL.VTABLES.all;
architecture VITAL of PRC1224CDG_33 is
   attribute VITAL_LEVEL0 of VITAL : architecture is TRUE;

   SIGNAL I_ipd		 : STD_ULOGIC := 'X';
   SIGNAL OEN_ipd	 : STD_ULOGIC := 'X';
   SIGNAL PAD_ipd	 : STD_ULOGIC := 'X';
   SIGNAL IE_ipd         : STD_ULOGIC := 'X';
   SIGNAL PS_ipd         : STD_ULOGIC := 'X';
   SIGNAL PE_ipd         : STD_ULOGIC := 'X';
   SIGNAL DS_ipd         : STD_ULOGIC := 'X';


begin

   ---------------------
   --  INPUT PATH DELAYs
   ---------------------
   WireDelay : block
   begin
   VitalWireDelay (I_ipd, I, tipd_I);
   VitalWireDelay (DS_ipd, DS, tipd_DS);
   VitalWireDelay (OEN_ipd, OEN, tipd_OEN);
   VitalWireDelay (PAD_ipd, PAD, tipd_PAD);
   VitalWireDelay (IE_ipd, IE, tipd_IE);
   VitalWireDelay (PS_ipd, PS, tipd_PS);
   VitalWireDelay (PE_ipd, PE, tipd_PE);
   end block;
   --------------------
   --  BEHAVIOR SECTION
   --------------------
   VITALBehavior : process (I_ipd, OEN_ipd, PAD_ipd, DS_ipd , IE_ipd, PS_ipd, PE_ipd)


   -- functionality results
   VARIABLE PAD_ipd2 : STD_ULOGIC := 'X';
   VARIABLE PAD_ipd_u : STD_ULOGIC := 'X';
   VARIABLE PAD_ipd_d : STD_ULOGIC := 'X';
   VARIABLE Results : STD_LOGIC_VECTOR(1 to 3) := (others => 'X');
   ALIAS PAD_zd : STD_LOGIC is Results(1);
   ALIAS C_zd : STD_LOGIC is Results(2);

   -- output glitch detection variables
   VARIABLE PAD_GlitchData	: VitalGlitchDataType;
   VARIABLE C_GlitchData	: VitalGlitchDataType;

   begin

      -------------------------
      --  Functionality Section
      -------------------------
      -- PAD_ipd_u := VitalIdent (data => PAD_ipd,
      --                      ResultMap => ('U','X','0','1','H'));
      -- PAD_ipd_d := VitalIdent (data => PAD_ipd,
      --                      ResultMap => ('U','X','0','1','L'));

      if (OEN_ipd = '0' or OEN_ipd = 'L') then
         PAD_zd := I_ipd;
      elsif (OEN_ipd = '1' or OEN_ipd = 'H') then
         PAD_zd := 'Z';
      else
        PAD_zd := 'X';
      end if;

      if ((OEN_ipd = '1') and (PS_ipd = '1' or PS_ipd = 'H') and (PE_ipd = '1' or PE_ipd = 'H')) then
         PAD_ipd2 := 'H';
         PAD_zd := 'H';
      elsif ((OEN_ipd = '1') and (PS_ipd = '0' or PS_ipd = 'L') and (PE_ipd = '1' or PE_ipd = 'H')) then
         PAD_ipd2 := 'L';
         PAD_zd := 'L';
      else
         PAD_ipd2 := PAD_ipd;
         PAD_zd := VitalBUFIF0 (data => I_ipd, enable => OEN_ipd);
      end if;
     
       
      -- PAD_zd := VitalBUFIF0 (data => I_ipd,
      --         enable => OEN_ipd);
      C_zd := TO_X01((PAD_ipd2) AND (IE_ipd));

      ----------------------
      --  Path Delay Section
      ----------------------
      VitalPathDelay01Z (
       OutSignal => PAD,
       GlitchData => PAD_GlitchData,
       OutSignalName => "PAD",
       OutTemp => PAD_zd,
       Paths => (0 => (I_ipd'last_event, VitalExtendToFillDelay(tpd_I_PAD_DS_EQ_0),
                        (TO_X01((NOT DS_ipd))='1')),
                 1 => (I_ipd'last_event, VitalExtendToFillDelay(tpd_I_PAD_DS_EQ_1),
                        (TO_X01(DS_ipd)='1')),
                 2 => (OEN_ipd'last_event, VitalExtendToFillDelay(tpd_OEN_PAD), TRUE)),
       Mode => OnEvent,
       Xon => Xon,
       MsgOn => MsgOn,
       MsgSeverity => WARNING);
      VitalPathDelay01 (
       OutSignal => C,
       GlitchData => C_GlitchData,
       OutSignalName => "C",
       OutTemp => C_zd,
       Paths => (0 => (PAD_ipd'last_event, tpd_PAD_C, TRUE),
                 1 => (IE_ipd'last_event, tpd_IE_C, TRUE)),
       Mode => OnEvent,
       Xon => Xon,
       MsgOn => MsgOn,
       MsgSeverity => WARNING);

end process;

end VITAL;

configuration CFG_PRC1224CDG_33_VITAL of PRC1224CDG_33 is
   for VITAL
   end for;
end CFG_PRC1224CDG_33_VITAL;


---- end of library ----
