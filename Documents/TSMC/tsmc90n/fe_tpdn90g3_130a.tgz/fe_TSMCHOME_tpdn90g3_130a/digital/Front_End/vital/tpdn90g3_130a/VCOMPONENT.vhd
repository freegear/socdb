------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TSMC Library/IP Product
-- Filename: VCOMPONENT.vhd
-- Technology: CLN90G
-- Product Type: Standard I/O
-- Product Name: tpdn90g3
-- Version: 130a
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----
--  STATEMENT OF USE
--
--  This information contains confidential and proprietary information of TSMC.
--  No part of this information may be reproduced, transmitted, transcribed,
--  stored in a retrieval system, or translated into any human or computer
--  language, in any form or by any means, electronic, mechanical, magnetic,
--  optical, chemical, manual, or otherwise, without the prior written permission
--  of TSMC.  This information was prepared for informational purpose and is for
--  use by TSMC's customers only.  TSMC reserves the right to make changes in the
--  information at any time and without notice.
--
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--
-- Technology:  tpdn90g3 
-- Created by:  NISUNG, TSMC ASIC 
-- Created Date: Fri Dec 10 12:22:04 CST 2004 
--
library IEEE;
use IEEE.STD_LOGIC_1164.all;
-- synopsys translate_off

library IEEE;
use IEEE.VITAL_Timing.all;
-- synopsys translate_on

package VCOMPONENTS is

constant DefaultTimingChecksOn : Boolean := True;
constant DefaultXon : Boolean := True;
constant DefaultMsgOn : Boolean := True;




----- Component PDC0204CDG_33 ----- 
component PDC0204CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_I_PAD_DS_EQ_0             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_I_PAD_DS_EQ_1             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_OEN_PAD                    :	VitalDelayType01z :=
                (0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns);
      tpd_PAD_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_IE_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PS                        :  VitalDelayType01 := (100000 ns, 100000 ns);
      tipd_PE                        :  VitalDelayType01 := (0.000 ns, 0.000 ns); 
      tipd_DS                        :  VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_I                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_IE                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_OEN                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PAD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on 
   port(
      I                              :	in    STD_ULOGIC;
      DS                             :	in    STD_ULOGIC;
      OEN                            :	in    STD_ULOGIC;
      PAD                            :	inout STD_ULOGIC;
      C                              :	out   STD_ULOGIC;
      PS                             :	in    STD_ULOGIC;
      IE                             :	in    STD_ULOGIC;
      PE                             :	in    STD_ULOGIC);
end component; 




----- Component PDC0816CDG_33 ----- 
component PDC0816CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_I_PAD_DS_EQ_0             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_I_PAD_DS_EQ_1             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_OEN_PAD                    :	VitalDelayType01z :=
                (0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns);
      tpd_PAD_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_IE_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PS                        :  VitalDelayType01 := (100000 ns, 100000 ns);
      tipd_PE                        :  VitalDelayType01 := (0.000 ns, 0.000 ns); 
      tipd_DS                        :  VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_I                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_IE                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_OEN                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PAD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on 
   port(
      I                              :	in    STD_ULOGIC;
      DS                             :	in    STD_ULOGIC;
      OEN                            :	in    STD_ULOGIC;
      PAD                            :	inout STD_ULOGIC;
      C                              :	out   STD_ULOGIC;
      PS                             :	in    STD_ULOGIC;
      IE                             :	in    STD_ULOGIC;
      PE                             :	in    STD_ULOGIC);
end component; 




----- Component PDC1224CDG_33 ----- 
component PDC1224CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_I_PAD_DS_EQ_0             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_I_PAD_DS_EQ_1             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_OEN_PAD                    :	VitalDelayType01z :=
                (0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns);
      tpd_PAD_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_IE_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PS                        :  VitalDelayType01 := (100000 ns, 100000 ns);
      tipd_PE                        :  VitalDelayType01 := (0.000 ns, 0.000 ns); 
      tipd_DS                        :  VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_I                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_IE                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_OEN                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PAD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on 
   port(
      I                              :	in    STD_ULOGIC;
      DS                             :	in    STD_ULOGIC;
      OEN                            :	in    STD_ULOGIC;
      PAD                            :	inout STD_ULOGIC;
      C                              :	out   STD_ULOGIC;
      PS                             :	in    STD_ULOGIC;
      IE                             :	in    STD_ULOGIC;
      PE                             :	in    STD_ULOGIC);
end component; 




----- Component PDS0204CDG_33 ----- 
component PDS0204CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_I_PAD_DS_EQ_0             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_I_PAD_DS_EQ_1             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_OEN_PAD                    :	VitalDelayType01z :=
                (0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns);
      tpd_PAD_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_IE_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PS                        :  VitalDelayType01 := (100000 ns, 100000 ns);
      tipd_PE                        :  VitalDelayType01 := (0.000 ns, 0.000 ns); 
      tipd_DS                        :  VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_I                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_IE                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_OEN                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PAD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on 
   port(
      I                              :	in    STD_ULOGIC;
      DS                             :	in    STD_ULOGIC;
      OEN                            :	in    STD_ULOGIC;
      PAD                            :	inout STD_ULOGIC;
      C                              :	out   STD_ULOGIC;
      PS                             :	in    STD_ULOGIC;
      IE                             :	in    STD_ULOGIC;
      PE                             :	in    STD_ULOGIC);
end component; 




----- Component PDS0816CDG_33 ----- 
component PDS0816CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_I_PAD_DS_EQ_0             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_I_PAD_DS_EQ_1             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_OEN_PAD                    :	VitalDelayType01z :=
                (0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns);
      tpd_PAD_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_IE_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PS                        :  VitalDelayType01 := (100000 ns, 100000 ns);
      tipd_PE                        :  VitalDelayType01 := (0.000 ns, 0.000 ns); 
      tipd_DS                        :  VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_I                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_IE                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_OEN                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PAD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on 
   port(
      I                              :	in    STD_ULOGIC;
      DS                             :	in    STD_ULOGIC;
      OEN                            :	in    STD_ULOGIC;
      PAD                            :	inout STD_ULOGIC;
      C                              :	out   STD_ULOGIC;
      PS                             :	in    STD_ULOGIC;
      IE                             :	in    STD_ULOGIC;
      PE                             :	in    STD_ULOGIC);
end component; 




----- Component PDS1224CDG_33 ----- 
component PDS1224CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_I_PAD_DS_EQ_0             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_I_PAD_DS_EQ_1             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_OEN_PAD                    :	VitalDelayType01z :=
                (0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns);
      tpd_PAD_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_IE_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PS                        :  VitalDelayType01 := (100000 ns, 100000 ns);
      tipd_PE                        :  VitalDelayType01 := (0.000 ns, 0.000 ns); 
      tipd_DS                        :  VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_I                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_IE                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_OEN                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PAD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on 
   port(
      I                              :	in    STD_ULOGIC;
      DS                             :	in    STD_ULOGIC;
      OEN                            :	in    STD_ULOGIC;
      PAD                            :	inout STD_ULOGIC;
      C                              :	out   STD_ULOGIC;
      PS                             :	in    STD_ULOGIC;
      IE                             :	in    STD_ULOGIC;
      PE                             :	in    STD_ULOGIC);
end component; 




----- Component PRC0816CDG_33 ----- 
component PRC0816CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_I_PAD_DS_EQ_0             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_I_PAD_DS_EQ_1             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_OEN_PAD                    :	VitalDelayType01z :=
                (0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns);
      tpd_PAD_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_IE_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PS                        :  VitalDelayType01 := (100000 ns, 100000 ns);
      tipd_PE                        :  VitalDelayType01 := (0.000 ns, 0.000 ns); 
      tipd_DS                        :  VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_I                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_IE                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_OEN                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PAD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on 
   port(
      I                              :	in    STD_ULOGIC;
      DS                             :	in    STD_ULOGIC;
      OEN                            :	in    STD_ULOGIC;
      PAD                            :	inout STD_ULOGIC;
      C                              :	out   STD_ULOGIC;
      PS                             :	in    STD_ULOGIC;
      IE                             :	in    STD_ULOGIC;
      PE                             :	in    STD_ULOGIC);
end component; 




----- Component PRC1224CDG_33 ----- 
component PRC1224CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_I_PAD_DS_EQ_0             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_I_PAD_DS_EQ_1             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_OEN_PAD                    :	VitalDelayType01z :=
                (0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns);
      tpd_PAD_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_IE_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PS                        :  VitalDelayType01 := (100000 ns, 100000 ns);
      tipd_PE                        :  VitalDelayType01 := (0.000 ns, 0.000 ns); 
      tipd_DS                        :  VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_I                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_IE                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_OEN                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PAD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on 
   port(
      I                              :	in    STD_ULOGIC;
      DS                             :	in    STD_ULOGIC;
      OEN                            :	in    STD_ULOGIC;
      PAD                            :	inout STD_ULOGIC;
      C                              :	out   STD_ULOGIC;
      PS                             :	in    STD_ULOGIC;
      IE                             :	in    STD_ULOGIC;
      PE                             :	in    STD_ULOGIC);
end component; 




----- Component PRS0816CDG_33 ----- 
component PRS0816CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_I_PAD_DS_EQ_0             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_I_PAD_DS_EQ_1             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_OEN_PAD                    :	VitalDelayType01z :=
                (0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns);
      tpd_PAD_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_IE_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PS                        :  VitalDelayType01 := (100000 ns, 100000 ns);
      tipd_PE                        :  VitalDelayType01 := (0.000 ns, 0.000 ns); 
      tipd_DS                        :  VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_I                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_IE                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_OEN                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PAD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on 
   port(
      I                              :	in    STD_ULOGIC;
      DS                             :	in    STD_ULOGIC;
      OEN                            :	in    STD_ULOGIC;
      PAD                            :	inout STD_ULOGIC;
      C                              :	out   STD_ULOGIC;
      PS                             :	in    STD_ULOGIC;
      IE                             :	in    STD_ULOGIC;
      PE                             :	in    STD_ULOGIC);
end component; 




----- Component PRS1224CDG_33 ----- 
component PRS1224CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_I_PAD_DS_EQ_0             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_I_PAD_DS_EQ_1             :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_OEN_PAD                    :	VitalDelayType01z :=
                (0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns, 0.000 ns);
      tpd_PAD_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tpd_IE_C                      :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PS                        :  VitalDelayType01 := (100000 ns, 100000 ns);
      tipd_PE                        :  VitalDelayType01 := (0.000 ns, 0.000 ns); 
      tipd_DS                        :  VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_I                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_IE                         :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_OEN                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_PAD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on 
   port(
      I                              :	in    STD_ULOGIC;
      DS                             :	in    STD_ULOGIC;
      OEN                            :	in    STD_ULOGIC;
      PAD                            :	inout STD_ULOGIC;
      C                              :	out   STD_ULOGIC;
      PS                             :	in    STD_ULOGIC;
      IE                             :	in    STD_ULOGIC;
      PE                             :	in    STD_ULOGIC);
end component; 




----- Component PVDD1CDG_33 ----- 
component PVDD1CDG_33
-- synopsys translate_off
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tipd_VDD                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on
   port(
--Edit by NISUNG Wed Feb 19 14:50:02 CST 1997
--      VDD                            :	in    STD_ULOGIC);
      VDD                            :	inout    STD_ULOGIC);
end component; 




----- Component PVDD2CDG_33 ----- 
component PVDD2CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True);

-- synopsys translate_on 
--   port();
end component; 




----- Component PVDD2POC_33 ----- 
component PVDD2POC_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True);

-- synopsys translate_on 
--   port();
end component; 




----- Component PVSS1CDG_33 ----- 
component PVSS1CDG_33
-- synopsys translate_off
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tipd_VSS                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on
   port(
--Edit by NISUNG Wed Feb 19 14:50:02 CST 1997
--      VSS                            :	in    STD_ULOGIC);
      VSS                            :	inout    STD_ULOGIC);
end component; 




----- Component PVSS2CDG_33 ----- 
component PVSS2CDG_33
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True);

-- synopsys translate_on 
--   port();
end component; 




----- Component PVSS3CDG_33 ----- 
component PVSS3CDG_33
-- synopsys translate_off
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tipd_VSS                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on
   port(
--Edit by NISUNG Wed Feb 19 14:50:02 CST 1997
--      VSS                            :	in    STD_ULOGIC);
      VSS                            :	inout    STD_ULOGIC);
end component; 




----- Component PXOE1CDG_33 ----- 
component PXOE1CDG_33
-- synopsys translate_off
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_XI_XO                   :	VitalDelayType01 := (2.854 ns, 2.267 ns);
      tpd_XE_XO                   :	VitalDelayType01 := (2.267 ns, 2.178 ns);
-- Edit by NISUNG Mon Feb 17 14:51:52 CST 1997
--      tpd_XO_XC                   :	VitalDelayType01 := (0.059 ns, 0.057 ns);
      tpd_XI_XC                   :   VitalDelayType01 := (0.063 ns, 0.049 ns);
      tpd_XE_XC                   :   VitalDelayType01 := (0.063 ns, 0.049 ns);
      tipd_XI                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_XE                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on
   port(
      XI                            :	in    STD_ULOGIC;
      XE                            :	in    STD_ULOGIC;
      XO                           :	out   STD_ULOGIC;
      XC                            :	out   STD_ULOGIC);

   -- real names
   -- REAL_NAME of XC is "IN"
end component; 




----- Component PXOE2CDG_33 ----- 
component PXOE2CDG_33
-- synopsys translate_off
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_XI_XO                   :	VitalDelayType01 := (2.854 ns, 2.267 ns);
      tpd_XE_XO                   :	VitalDelayType01 := (2.267 ns, 2.178 ns);
-- Edit by NISUNG Mon Feb 17 14:51:52 CST 1997
--      tpd_XO_XC                   :	VitalDelayType01 := (0.059 ns, 0.057 ns);
      tpd_XI_XC                   :   VitalDelayType01 := (0.063 ns, 0.049 ns);
      tpd_XE_XC                   :   VitalDelayType01 := (0.063 ns, 0.049 ns);
      tipd_XI                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_XE                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on
   port(
      XI                            :	in    STD_ULOGIC;
      XE                            :	in    STD_ULOGIC;
      XO                           :	out   STD_ULOGIC;
      XC                            :	out   STD_ULOGIC);

   -- real names
   -- REAL_NAME of XC is "IN"
end component; 




end VCOMPONENTS;
---- end of VITAL components library ----
