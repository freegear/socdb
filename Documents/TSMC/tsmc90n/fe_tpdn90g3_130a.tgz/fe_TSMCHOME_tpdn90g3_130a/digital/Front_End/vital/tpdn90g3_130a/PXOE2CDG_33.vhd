------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TSMC Library/IP Product
-- Filename: PXOE2CDG_33.vhd
-- Technology: CLN90G
-- Product Type: Standard I/O
-- Product Name: tpdn90g3
-- Version: 130a
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----
--  STATEMENT OF USE
--
--  This information contains confidential and proprietary information of TSMC.
--  No part of this information may be reproduced, transmitted, transcribed,
--  stored in a retrieval system, or translated into any human or computer
--  language, in any form or by any means, electronic, mechanical, magnetic,
--  optical, chemical, manual, or otherwise, without the prior written permission
--  of TSMC.  This information was prepared for informational purpose and is for
--  use by TSMC's customers only.  TSMC reserves the right to make changes in the
--  information at any time and without notice.
--
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------
--            Technology   :  tpdn90g3
--            Created by   :  NISUNG, TSMC ASIC 
--            Created Date :  Fri Dec 10 12:22:04 CST 2004
---------------------------------------------------------
---------------------------------------------------
------  The file is generated using model2sdf.pl
---------------------------------------------------
----- CELL PXOE2CDG_33 -----
library IEEE;
use IEEE.STD_LOGIC_1164.all;
-- synopsys translate_off
library IEEE;
use IEEE.VITAL_Timing.all;
-- synopsys translate_on


-- entity declaration --
entity PXOE2CDG_33 is
-- synopsys translate_off
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tpd_XI_XO                   :	VitalDelayType01 := (2.854 ns, 2.267 ns);
      tpd_XE_XO                   :	VitalDelayType01 := (2.267 ns, 2.178 ns);
-- Edit by NISUNG Mon Feb 17 14:51:52 CST 1997
--      tpd_XO_XC                   :	VitalDelayType01 := (0.059 ns, 0.057 ns);
      tpd_XI_XC                   :   VitalDelayType01 := (0.063 ns, 0.049 ns);
      tpd_XE_XC                   :   VitalDelayType01 := (0.063 ns, 0.049 ns);
      tipd_XI                       :	VitalDelayType01 := (0.000 ns, 0.000 ns);
      tipd_XE                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on
   port(
      XI                            :	in    STD_ULOGIC;
      XE                            :	in    STD_ULOGIC;
      XO                           :	out   STD_ULOGIC;
      XC                            :	out   STD_ULOGIC);
attribute VITAL_LEVEL0 of PXOE2CDG_33 : entity is TRUE;

   -- real names
   -- REAL_NAME of XC is "IN"
end PXOE2CDG_33;

-- architecture body --
library IEEE;
use IEEE.VITAL_Primitives.all;
library VITAL;
use VITAL.VTABLES.all;
architecture VITAL of PXOE2CDG_33 is
   attribute VITAL_LEVEL1 of VITAL : architecture is TRUE;

   SIGNAL XI_ipd	 : STD_ULOGIC := 'X';
   SIGNAL XE_ipd	 : STD_ULOGIC := 'X';

begin

   ---------------------
   --  INPUT PATH DELAYs
   ---------------------
   WireDelay : block
   begin
   VitalWireDelay (XI_ipd, XI, tipd_XI);
   VitalWireDelay (XE_ipd, XE, tipd_XE);
   end block;
   --------------------
   --  BEHAVIOR SECTION
   --------------------
   VITALBehavior : process (XI_ipd, XE_ipd)


   -- functionality results
   VARIABLE Results : STD_LOGIC_VECTOR(1 to 2) := (others => 'X');
   ALIAS XO_zd : STD_LOGIC is Results(1);
   ALIAS XC_zd : STD_LOGIC is Results(2);

   -- output glitch detection variables
   VARIABLE XO_GlitchData	: VitalGlitchDataType;
   VARIABLE XC_GlitchData	: VitalGlitchDataType;

   begin

      -------------------------
      --  Functionality Section
      -------------------------
      -- XO_zd := (NOT ((XI_ipd) AND ((NOT XE_ipd))));  -bug
      XO_zd := (NOT ((XI_ipd) AND (XE_ipd)));
      -- XC_zd := TO_X01(XI_ipd);  -bug
      XC_zd := TO_X01(NOT (XO_zd));


      ----------------------
      --  Path Delay Section
      ----------------------
      VitalPathDelay01 (
       OutSignal => XO,
       GlitchData => XO_GlitchData,
       OutSignalName => "XO",
       OutTemp => XO_zd,
       Paths => (0 => (XI_ipd'last_event, tpd_XI_XO, TRUE),
                 1 => (XE_ipd'last_event, tpd_XE_XO, TRUE)),
       Mode => OnDetect,
       Xon => Xon,
       MsgOn => MsgOn,
       MsgSeverity => WARNING);

-- Edit by NISUNG Mon Feb 17 14:51:52 CST 1997
 
      VitalPathDelay01 (
       OutSignal => XC,
       GlitchData => XC_GlitchData,
       OutSignalName => "XC",
       OutTemp => XC_zd,
       Paths => (0 => (XI_ipd'last_event, tpd_XI_XC, TRUE),
                 1 => (XE_ipd'last_event, tpd_XE_XC, TRUE)),
       Mode => OnDetect,
       Xon => Xon,
       MsgOn => MsgOn,
       MsgSeverity => WARNING);

end process;

end VITAL;

configuration CFG_PXOE2CDG_33_VITAL of PXOE2CDG_33 is
   for VITAL
   end for;
end CFG_PXOE2CDG_33_VITAL;


