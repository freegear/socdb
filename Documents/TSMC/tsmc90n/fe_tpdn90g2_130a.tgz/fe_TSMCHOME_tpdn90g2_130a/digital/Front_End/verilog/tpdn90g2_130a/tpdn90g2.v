////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// TSMC Library/IP Product
/// Filename: tpdn90g2.v
/// Technology: CLN90G
/// Product Type: Standard I/O
/// Product Name: tpdn90g2
/// Version: 130a
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
///  STATEMENT OF USE
///
///  This information contains confidential and proprietary information of TSMC.
///  No part of this information may be reproduced, transmitted, transcribed,
///  stored in a retrieval system, or translated into any human or computer
///  language, in any form or by any means, electronic, mechanical, magnetic,
///  optical, chemical, manual, or otherwise, without the prior written permission
///  of TSMC.  This information was prepared for informational purpose and is for
///  use by TSMC's customers only.  TSMC reserves the right to make changes in the
///  information at any time and without notice.
///
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
`timescale 1ns/10ps

// type: PDCSxCDG
`celldefine

module PDC0204CDG_25 (I,DS,OEN,PAD,C,PS,PE,IE);
   input I,DS,OEN,PS,PE,IE;
   inout PAD;
   output C;
   wire  MG;
   parameter PullTime = 100000;
   reg lastPAD, pull_uen, pull_den;
initial begin
  pull_uen = 0;
  pull_den = 0;
end
  bufif1 (weak0, weak1)(PAD_i, 1'b1, pull_uen);
  bufif1 (weak0, weak1)(PAD_i, 1'b0, pull_den); 
  buf    (C, CO);
  and    (CO, C_buf, IE);
  nand   (PUEN, PS, PE, OEN);
  not    (PU, PUEN);
  not    (PSB, PS);
  and    (PD, PE, PSB, OEN);
  bufif0 (PAD_q, I, OEN);
  pmos   (DS_tmp, DS, 1'b0);
  pmos   (C_buf, PAD, 1'b0);
  pmos   (MG, PAD_q, 1'b0);
  pmos   (MG, PAD_i, 1'b0);
  pmos   (PAD, MG, 1'b0);
  always @(PAD) lastPAD=PAD;
  always @(PAD or PU or PD) begin
    if (PAD === 1'bx && !$test$plusargs("bus_conflict_off") && $countdrivers(PAD))
       $display("ERROR : %t ++BUS CONFLICT++ : %m", $realtime);
    if (PAD === 1'bz || (PAD === 1'b1) || (PAD === 1'b0)) begin
         if (PU) begin
            if (lastPAD === 1'b1) 
            begin
              pull_uen=1; pull_den=0;
            end
            else begin
              pull_uen <= #PullTime 1;
              pull_den <= #PullTime 0;
            end
         end           
         else pull_uen=0;
         if (PD) begin
            if (lastPAD === 1'b0) 
            begin
              pull_den=1; pull_uen=0;
            end
            else begin
              pull_den <= #PullTime 1;
              pull_uen <= #PullTime 0;
            end
         end
         else pull_den=0;
    end 
  end
   specify
     if (DS == 1'b0) (I => PAD)=(0, 0);
     if (DS == 1'b1) (I => PAD)=(0, 0);
     (OEN => PAD)=(0, 0, 0, 0, 0, 0);
     (PAD => C)=(0, 0);
     (IE => C)=(0, 0);
   endspecify

endmodule
`endcelldefine


// type: PDCSxCDG
`celldefine

module PDC0816CDG_25 (I,DS,OEN,PAD,C,PS,PE,IE);
   input I,DS,OEN,PS,PE,IE;
   inout PAD;
   output C;
   wire  MG;
   parameter PullTime = 100000;
   reg lastPAD, pull_uen, pull_den;
initial begin
  pull_uen = 0;
  pull_den = 0;
end
  bufif1 (weak0, weak1)(PAD_i, 1'b1, pull_uen);
  bufif1 (weak0, weak1)(PAD_i, 1'b0, pull_den); 
  buf    (C, CO);
  and    (CO, C_buf, IE);
  nand   (PUEN, PS, PE, OEN);
  not    (PU, PUEN);
  not    (PSB, PS);
  and    (PD, PE, PSB, OEN);
  bufif0 (PAD_q, I, OEN);
  pmos   (DS_tmp, DS, 1'b0);
  pmos   (C_buf, PAD, 1'b0);
  pmos   (MG, PAD_q, 1'b0);
  pmos   (MG, PAD_i, 1'b0);
  pmos   (PAD, MG, 1'b0);
  always @(PAD) lastPAD=PAD;
  always @(PAD or PU or PD) begin
    if (PAD === 1'bx && !$test$plusargs("bus_conflict_off") && $countdrivers(PAD))
       $display("ERROR : %t ++BUS CONFLICT++ : %m", $realtime);
    if (PAD === 1'bz || (PAD === 1'b1) || (PAD === 1'b0)) begin
         if (PU) begin
            if (lastPAD === 1'b1) 
            begin
              pull_uen=1; pull_den=0;
            end
            else begin
              pull_uen <= #PullTime 1;
              pull_den <= #PullTime 0;
            end
         end           
         else pull_uen=0;
         if (PD) begin
            if (lastPAD === 1'b0) 
            begin
              pull_den=1; pull_uen=0;
            end
            else begin
              pull_den <= #PullTime 1;
              pull_uen <= #PullTime 0;
            end
         end
         else pull_den=0;
    end 
  end
   specify
     if (DS == 1'b0) (I => PAD)=(0, 0);
     if (DS == 1'b1) (I => PAD)=(0, 0);
     (OEN => PAD)=(0, 0, 0, 0, 0, 0);
     (PAD => C)=(0, 0);
     (IE => C)=(0, 0);
   endspecify

endmodule
`endcelldefine


// type: PDCSxCDG
`celldefine

module PDC1224CDG_25 (I,DS,OEN,PAD,C,PS,PE,IE);
   input I,DS,OEN,PS,PE,IE;
   inout PAD;
   output C;
   wire  MG;
   parameter PullTime = 100000;
   reg lastPAD, pull_uen, pull_den;
initial begin
  pull_uen = 0;
  pull_den = 0;
end
  bufif1 (weak0, weak1)(PAD_i, 1'b1, pull_uen);
  bufif1 (weak0, weak1)(PAD_i, 1'b0, pull_den); 
  buf    (C, CO);
  and    (CO, C_buf, IE);
  nand   (PUEN, PS, PE, OEN);
  not    (PU, PUEN);
  not    (PSB, PS);
  and    (PD, PE, PSB, OEN);
  bufif0 (PAD_q, I, OEN);
  pmos   (DS_tmp, DS, 1'b0);
  pmos   (C_buf, PAD, 1'b0);
  pmos   (MG, PAD_q, 1'b0);
  pmos   (MG, PAD_i, 1'b0);
  pmos   (PAD, MG, 1'b0);
  always @(PAD) lastPAD=PAD;
  always @(PAD or PU or PD) begin
    if (PAD === 1'bx && !$test$plusargs("bus_conflict_off") && $countdrivers(PAD))
       $display("ERROR : %t ++BUS CONFLICT++ : %m", $realtime);
    if (PAD === 1'bz || (PAD === 1'b1) || (PAD === 1'b0)) begin
         if (PU) begin
            if (lastPAD === 1'b1) 
            begin
              pull_uen=1; pull_den=0;
            end
            else begin
              pull_uen <= #PullTime 1;
              pull_den <= #PullTime 0;
            end
         end           
         else pull_uen=0;
         if (PD) begin
            if (lastPAD === 1'b0) 
            begin
              pull_den=1; pull_uen=0;
            end
            else begin
              pull_den <= #PullTime 1;
              pull_uen <= #PullTime 0;
            end
         end
         else pull_den=0;
    end 
  end
   specify
     if (DS == 1'b0) (I => PAD)=(0, 0);
     if (DS == 1'b1) (I => PAD)=(0, 0);
     (OEN => PAD)=(0, 0, 0, 0, 0, 0);
     (PAD => C)=(0, 0);
     (IE => C)=(0, 0);
   endspecify

endmodule
`endcelldefine


// type: PDCSxCDG
`celldefine

module PDS0204CDG_25 (I,DS,OEN,PAD,C,PS,PE,IE);
   input I,DS,OEN,PS,PE,IE;
   inout PAD;
   output C;
   wire  MG;
   parameter PullTime = 100000;
   reg lastPAD, pull_uen, pull_den;
initial begin
  pull_uen = 0;
  pull_den = 0;
end
  bufif1 (weak0, weak1)(PAD_i, 1'b1, pull_uen);
  bufif1 (weak0, weak1)(PAD_i, 1'b0, pull_den); 
  buf    (C, CO);
  and    (CO, C_buf, IE);
  nand   (PUEN, PS, PE, OEN);
  not    (PU, PUEN);
  not    (PSB, PS);
  and    (PD, PE, PSB, OEN);
  bufif0 (PAD_q, I, OEN);
  pmos   (DS_tmp, DS, 1'b0);
  pmos   (C_buf, PAD, 1'b0);
  pmos   (MG, PAD_q, 1'b0);
  pmos   (MG, PAD_i, 1'b0);
  pmos   (PAD, MG, 1'b0);
  always @(PAD) lastPAD=PAD;
  always @(PAD or PU or PD) begin
    if (PAD === 1'bx && !$test$plusargs("bus_conflict_off") && $countdrivers(PAD))
       $display("ERROR : %t ++BUS CONFLICT++ : %m", $realtime);
    if (PAD === 1'bz || (PAD === 1'b1) || (PAD === 1'b0)) begin
         if (PU) begin
            if (lastPAD === 1'b1) 
            begin
              pull_uen=1; pull_den=0;
            end
            else begin
              pull_uen <= #PullTime 1;
              pull_den <= #PullTime 0;
            end
         end           
         else pull_uen=0;
         if (PD) begin
            if (lastPAD === 1'b0) 
            begin
              pull_den=1; pull_uen=0;
            end
            else begin
              pull_den <= #PullTime 1;
              pull_uen <= #PullTime 0;
            end
         end
         else pull_den=0;
    end 
  end
   specify
     if (DS == 1'b0) (I => PAD)=(0, 0);
     if (DS == 1'b1) (I => PAD)=(0, 0);
     (OEN => PAD)=(0, 0, 0, 0, 0, 0);
     (PAD => C)=(0, 0);
     (IE => C)=(0, 0);
   endspecify

endmodule
`endcelldefine


// type: PDCSxCDG
`celldefine

module PDS0816CDG_25 (I,DS,OEN,PAD,C,PS,PE,IE);
   input I,DS,OEN,PS,PE,IE;
   inout PAD;
   output C;
   wire  MG;
   parameter PullTime = 100000;
   reg lastPAD, pull_uen, pull_den;
initial begin
  pull_uen = 0;
  pull_den = 0;
end
  bufif1 (weak0, weak1)(PAD_i, 1'b1, pull_uen);
  bufif1 (weak0, weak1)(PAD_i, 1'b0, pull_den); 
  buf    (C, CO);
  and    (CO, C_buf, IE);
  nand   (PUEN, PS, PE, OEN);
  not    (PU, PUEN);
  not    (PSB, PS);
  and    (PD, PE, PSB, OEN);
  bufif0 (PAD_q, I, OEN);
  pmos   (DS_tmp, DS, 1'b0);
  pmos   (C_buf, PAD, 1'b0);
  pmos   (MG, PAD_q, 1'b0);
  pmos   (MG, PAD_i, 1'b0);
  pmos   (PAD, MG, 1'b0);
  always @(PAD) lastPAD=PAD;
  always @(PAD or PU or PD) begin
    if (PAD === 1'bx && !$test$plusargs("bus_conflict_off") && $countdrivers(PAD))
       $display("ERROR : %t ++BUS CONFLICT++ : %m", $realtime);
    if (PAD === 1'bz || (PAD === 1'b1) || (PAD === 1'b0)) begin
         if (PU) begin
            if (lastPAD === 1'b1) 
            begin
              pull_uen=1; pull_den=0;
            end
            else begin
              pull_uen <= #PullTime 1;
              pull_den <= #PullTime 0;
            end
         end           
         else pull_uen=0;
         if (PD) begin
            if (lastPAD === 1'b0) 
            begin
              pull_den=1; pull_uen=0;
            end
            else begin
              pull_den <= #PullTime 1;
              pull_uen <= #PullTime 0;
            end
         end
         else pull_den=0;
    end 
  end
   specify
     if (DS == 1'b0) (I => PAD)=(0, 0);
     if (DS == 1'b1) (I => PAD)=(0, 0);
     (OEN => PAD)=(0, 0, 0, 0, 0, 0);
     (PAD => C)=(0, 0);
     (IE => C)=(0, 0);
   endspecify

endmodule
`endcelldefine


// type: PDCSxCDG
`celldefine

module PDS1224CDG_25 (I,DS,OEN,PAD,C,PS,PE,IE);
   input I,DS,OEN,PS,PE,IE;
   inout PAD;
   output C;
   wire  MG;
   parameter PullTime = 100000;
   reg lastPAD, pull_uen, pull_den;
initial begin
  pull_uen = 0;
  pull_den = 0;
end
  bufif1 (weak0, weak1)(PAD_i, 1'b1, pull_uen);
  bufif1 (weak0, weak1)(PAD_i, 1'b0, pull_den); 
  buf    (C, CO);
  and    (CO, C_buf, IE);
  nand   (PUEN, PS, PE, OEN);
  not    (PU, PUEN);
  not    (PSB, PS);
  and    (PD, PE, PSB, OEN);
  bufif0 (PAD_q, I, OEN);
  pmos   (DS_tmp, DS, 1'b0);
  pmos   (C_buf, PAD, 1'b0);
  pmos   (MG, PAD_q, 1'b0);
  pmos   (MG, PAD_i, 1'b0);
  pmos   (PAD, MG, 1'b0);
  always @(PAD) lastPAD=PAD;
  always @(PAD or PU or PD) begin
    if (PAD === 1'bx && !$test$plusargs("bus_conflict_off") && $countdrivers(PAD))
       $display("ERROR : %t ++BUS CONFLICT++ : %m", $realtime);
    if (PAD === 1'bz || (PAD === 1'b1) || (PAD === 1'b0)) begin
         if (PU) begin
            if (lastPAD === 1'b1) 
            begin
              pull_uen=1; pull_den=0;
            end
            else begin
              pull_uen <= #PullTime 1;
              pull_den <= #PullTime 0;
            end
         end           
         else pull_uen=0;
         if (PD) begin
            if (lastPAD === 1'b0) 
            begin
              pull_den=1; pull_uen=0;
            end
            else begin
              pull_den <= #PullTime 1;
              pull_uen <= #PullTime 0;
            end
         end
         else pull_den=0;
    end 
  end
   specify
     if (DS == 1'b0) (I => PAD)=(0, 0);
     if (DS == 1'b1) (I => PAD)=(0, 0);
     (OEN => PAD)=(0, 0, 0, 0, 0, 0);
     (PAD => C)=(0, 0);
     (IE => C)=(0, 0);
   endspecify

endmodule
`endcelldefine


// type: PDCSxCDG
`celldefine

module PRC0816CDG_25 (I,DS,OEN,PAD,C,PS,PE,IE);
   input I,DS,OEN,PS,PE,IE;
   inout PAD;
   output C;
   wire  MG;
   parameter PullTime = 100000;
   reg lastPAD, pull_uen, pull_den;
initial begin
  pull_uen = 0;
  pull_den = 0;
end
  bufif1 (weak0, weak1)(PAD_i, 1'b1, pull_uen);
  bufif1 (weak0, weak1)(PAD_i, 1'b0, pull_den); 
  buf    (C, CO);
  and    (CO, C_buf, IE);
  nand   (PUEN, PS, PE, OEN);
  not    (PU, PUEN);
  not    (PSB, PS);
  and    (PD, PE, PSB, OEN);
  bufif0 (PAD_q, I, OEN);
  pmos   (DS_tmp, DS, 1'b0);
  pmos   (C_buf, PAD, 1'b0);
  pmos   (MG, PAD_q, 1'b0);
  pmos   (MG, PAD_i, 1'b0);
  pmos   (PAD, MG, 1'b0);
  always @(PAD) lastPAD=PAD;
  always @(PAD or PU or PD) begin
    if (PAD === 1'bx && !$test$plusargs("bus_conflict_off") && $countdrivers(PAD))
       $display("ERROR : %t ++BUS CONFLICT++ : %m", $realtime);
    if (PAD === 1'bz || (PAD === 1'b1) || (PAD === 1'b0)) begin
         if (PU) begin
            if (lastPAD === 1'b1) 
            begin
              pull_uen=1; pull_den=0;
            end
            else begin
              pull_uen <= #PullTime 1;
              pull_den <= #PullTime 0;
            end
         end           
         else pull_uen=0;
         if (PD) begin
            if (lastPAD === 1'b0) 
            begin
              pull_den=1; pull_uen=0;
            end
            else begin
              pull_den <= #PullTime 1;
              pull_uen <= #PullTime 0;
            end
         end
         else pull_den=0;
    end 
  end
   specify
     if (DS == 1'b0) (I => PAD)=(0, 0);
     if (DS == 1'b1) (I => PAD)=(0, 0);
     (OEN => PAD)=(0, 0, 0, 0, 0, 0);
     (PAD => C)=(0, 0);
     (IE => C)=(0, 0);
   endspecify

endmodule
`endcelldefine


// type: PDCSxCDG
`celldefine

module PRC1224CDG_25 (I,DS,OEN,PAD,C,PS,PE,IE);
   input I,DS,OEN,PS,PE,IE;
   inout PAD;
   output C;
   wire  MG;
   parameter PullTime = 100000;
   reg lastPAD, pull_uen, pull_den;
initial begin
  pull_uen = 0;
  pull_den = 0;
end
  bufif1 (weak0, weak1)(PAD_i, 1'b1, pull_uen);
  bufif1 (weak0, weak1)(PAD_i, 1'b0, pull_den); 
  buf    (C, CO);
  and    (CO, C_buf, IE);
  nand   (PUEN, PS, PE, OEN);
  not    (PU, PUEN);
  not    (PSB, PS);
  and    (PD, PE, PSB, OEN);
  bufif0 (PAD_q, I, OEN);
  pmos   (DS_tmp, DS, 1'b0);
  pmos   (C_buf, PAD, 1'b0);
  pmos   (MG, PAD_q, 1'b0);
  pmos   (MG, PAD_i, 1'b0);
  pmos   (PAD, MG, 1'b0);
  always @(PAD) lastPAD=PAD;
  always @(PAD or PU or PD) begin
    if (PAD === 1'bx && !$test$plusargs("bus_conflict_off") && $countdrivers(PAD))
       $display("ERROR : %t ++BUS CONFLICT++ : %m", $realtime);
    if (PAD === 1'bz || (PAD === 1'b1) || (PAD === 1'b0)) begin
         if (PU) begin
            if (lastPAD === 1'b1) 
            begin
              pull_uen=1; pull_den=0;
            end
            else begin
              pull_uen <= #PullTime 1;
              pull_den <= #PullTime 0;
            end
         end           
         else pull_uen=0;
         if (PD) begin
            if (lastPAD === 1'b0) 
            begin
              pull_den=1; pull_uen=0;
            end
            else begin
              pull_den <= #PullTime 1;
              pull_uen <= #PullTime 0;
            end
         end
         else pull_den=0;
    end 
  end
   specify
     if (DS == 1'b0) (I => PAD)=(0, 0);
     if (DS == 1'b1) (I => PAD)=(0, 0);
     (OEN => PAD)=(0, 0, 0, 0, 0, 0);
     (PAD => C)=(0, 0);
     (IE => C)=(0, 0);
   endspecify

endmodule
`endcelldefine


// type: PDCSxCDG
`celldefine

module PRS0816CDG_25 (I,DS,OEN,PAD,C,PS,PE,IE);
   input I,DS,OEN,PS,PE,IE;
   inout PAD;
   output C;
   wire  MG;
   parameter PullTime = 100000;
   reg lastPAD, pull_uen, pull_den;
initial begin
  pull_uen = 0;
  pull_den = 0;
end
  bufif1 (weak0, weak1)(PAD_i, 1'b1, pull_uen);
  bufif1 (weak0, weak1)(PAD_i, 1'b0, pull_den); 
  buf    (C, CO);
  and    (CO, C_buf, IE);
  nand   (PUEN, PS, PE, OEN);
  not    (PU, PUEN);
  not    (PSB, PS);
  and    (PD, PE, PSB, OEN);
  bufif0 (PAD_q, I, OEN);
  pmos   (DS_tmp, DS, 1'b0);
  pmos   (C_buf, PAD, 1'b0);
  pmos   (MG, PAD_q, 1'b0);
  pmos   (MG, PAD_i, 1'b0);
  pmos   (PAD, MG, 1'b0);
  always @(PAD) lastPAD=PAD;
  always @(PAD or PU or PD) begin
    if (PAD === 1'bx && !$test$plusargs("bus_conflict_off") && $countdrivers(PAD))
       $display("ERROR : %t ++BUS CONFLICT++ : %m", $realtime);
    if (PAD === 1'bz || (PAD === 1'b1) || (PAD === 1'b0)) begin
         if (PU) begin
            if (lastPAD === 1'b1) 
            begin
              pull_uen=1; pull_den=0;
            end
            else begin
              pull_uen <= #PullTime 1;
              pull_den <= #PullTime 0;
            end
         end           
         else pull_uen=0;
         if (PD) begin
            if (lastPAD === 1'b0) 
            begin
              pull_den=1; pull_uen=0;
            end
            else begin
              pull_den <= #PullTime 1;
              pull_uen <= #PullTime 0;
            end
         end
         else pull_den=0;
    end 
  end
   specify
     if (DS == 1'b0) (I => PAD)=(0, 0);
     if (DS == 1'b1) (I => PAD)=(0, 0);
     (OEN => PAD)=(0, 0, 0, 0, 0, 0);
     (PAD => C)=(0, 0);
     (IE => C)=(0, 0);
   endspecify

endmodule
`endcelldefine


// type: PDCSxCDG
`celldefine

module PRS1224CDG_25 (I,DS,OEN,PAD,C,PS,PE,IE);
   input I,DS,OEN,PS,PE,IE;
   inout PAD;
   output C;
   wire  MG;
   parameter PullTime = 100000;
   reg lastPAD, pull_uen, pull_den;
initial begin
  pull_uen = 0;
  pull_den = 0;
end
  bufif1 (weak0, weak1)(PAD_i, 1'b1, pull_uen);
  bufif1 (weak0, weak1)(PAD_i, 1'b0, pull_den); 
  buf    (C, CO);
  and    (CO, C_buf, IE);
  nand   (PUEN, PS, PE, OEN);
  not    (PU, PUEN);
  not    (PSB, PS);
  and    (PD, PE, PSB, OEN);
  bufif0 (PAD_q, I, OEN);
  pmos   (DS_tmp, DS, 1'b0);
  pmos   (C_buf, PAD, 1'b0);
  pmos   (MG, PAD_q, 1'b0);
  pmos   (MG, PAD_i, 1'b0);
  pmos   (PAD, MG, 1'b0);
  always @(PAD) lastPAD=PAD;
  always @(PAD or PU or PD) begin
    if (PAD === 1'bx && !$test$plusargs("bus_conflict_off") && $countdrivers(PAD))
       $display("ERROR : %t ++BUS CONFLICT++ : %m", $realtime);
    if (PAD === 1'bz || (PAD === 1'b1) || (PAD === 1'b0)) begin
         if (PU) begin
            if (lastPAD === 1'b1) 
            begin
              pull_uen=1; pull_den=0;
            end
            else begin
              pull_uen <= #PullTime 1;
              pull_den <= #PullTime 0;
            end
         end           
         else pull_uen=0;
         if (PD) begin
            if (lastPAD === 1'b0) 
            begin
              pull_den=1; pull_uen=0;
            end
            else begin
              pull_den <= #PullTime 1;
              pull_uen <= #PullTime 0;
            end
         end
         else pull_den=0;
    end 
  end
   specify
     if (DS == 1'b0) (I => PAD)=(0, 0);
     if (DS == 1'b1) (I => PAD)=(0, 0);
     (OEN => PAD)=(0, 0, 0, 0, 0, 0);
     (PAD => C)=(0, 0);
     (IE => C)=(0, 0);
   endspecify

endmodule
`endcelldefine


// type: PVDD1CDG
`celldefine
module PVDD1CDG_25 (VDD);
    inout   VDD;
    supply1 VDD;
endmodule
`endcelldefine


// type: PVDD2CDG
`celldefine
module PVDD2CDG_25 ();
endmodule
`endcelldefine


// type: PVDD2POC
`celldefine
module PVDD2POC_25 ();
endmodule
`endcelldefine


// type: PVSS1CDG
`celldefine
module PVSS1CDG_25 (VSS);
    inout   VSS;
    supply0 VSS;
endmodule
`endcelldefine


// type: PVSS2CDG
`celldefine
module PVSS2CDG_25 ();
endmodule
`endcelldefine


// type: PVSS3CDG
`celldefine
module PVSS3CDG_25 (VSS);
    inout   VSS;
    supply0 VSS;
endmodule
`endcelldefine


// type: PXOE1CDG
`celldefine
module PXOE1CDG_25 (XC, XO, XI, XE);
    input XI, XE;
    output XC, XO;
    not                  (XC, XO);
    nand                 (XO, XE, XI);
    specify
       (XE => XC)=(0, 0);
       (XE => XO)=(0, 0);
       (XI => XC)=(0, 0);
       (XI => XO)=(0, 0);
    endspecify
endmodule
`endcelldefine


// type: PXOE2CDG
`celldefine
module PXOE2CDG_25 (XC, XO, XI, XE);
    input XI, XE;
    output XC, XO;
    not                  (XC, XO);
    nand                 (XO, XE, XI);
    specify
       (XE => XC)=(0, 0);
       (XE => XO)=(0, 0);
       (XI => XC)=(0, 0);
       (XI => XO)=(0, 0);
    endspecify
endmodule
`endcelldefine

