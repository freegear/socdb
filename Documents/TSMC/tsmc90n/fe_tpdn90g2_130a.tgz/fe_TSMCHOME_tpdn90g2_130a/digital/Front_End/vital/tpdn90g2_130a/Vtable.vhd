------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TSMC Library/IP Product
-- Filename: Vtable.vhd
-- Technology: CLN90G
-- Product Type: Standard I/O
-- Product Name: tpdn90g2
-- Version: 130a
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----
--  STATEMENT OF USE
--
--  This information contains confidential and proprietary information of TSMC.
--  No part of this information may be reproduced, transmitted, transcribed,
--  stored in a retrieval system, or translated into any human or computer
--  language, in any form or by any means, electronic, mechanical, magnetic,
--  optical, chemical, manual, or otherwise, without the prior written permission
--  of TSMC.  This information was prepared for informational purpose and is for
--  use by TSMC's customers only.  TSMC reserves the right to make changes in the
--  information at any time and without notice.
--
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------
--            Technology   :  tpdn90g2
--            Created by   :  NISUNG, TSMC ASIC 
--            Created Date :  Fri Dec 24 10:04:43 CST 2004
---------------------------------------------------------

---- head of VITAL tables library ----

library IEEE;
use IEEE.STD_LOGIC_1164.all;
-- synopsys translate_off

library IEEE;
use IEEE.VITAL_Timing.all;
use IEEE.VITAL_Primitives.all;
-- synopsys translate_on

package VTABLES is

   CONSTANT L : VitalTableSymbolType := '0';
   CONSTANT H : VitalTableSymbolType := '1';
   CONSTANT x : VitalTableSymbolType := '-';
   CONSTANT S : VitalTableSymbolType := 'S';
   CONSTANT R : VitalTableSymbolType := '/';
   CONSTANT U : VitalTableSymbolType := 'X';
   CONSTANT V : VitalTableSymbolType := 'B'; -- valid clock signal (non-rising)



-- BEGIN: for TCB015's 15 scan cells (May 3, 2000)
   CONSTANT SSDFD1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  x,  L ),
    ( L,  L,  x,  H,  H,  x,  L ),
    ( L,  H,  H,  x,  H,  x,  H ),
    ( L,  H,  x,  H,  H,  x,  H ),
    ( L,  x,  L,  L,  H,  x,  L ),
    ( L,  x,  H,  L,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  S ));

   CONSTANT SSDFXD1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  L,  x,  x,  H,  x,  L ),
    ( L,  L,  L,  x,  x,  L,  H,  x,  L ),
    ( L,  L,  x,  L,  x,  H,  H,  x,  L ),
    ( L,  L,  x,  x,  H,  x,  H,  x,  L ),
    ( L,  H,  H,  H,  x,  x,  H,  x,  H ),
    ( L,  H,  H,  x,  x,  L,  H,  x,  H ),
    ( L,  H,  x,  H,  x,  H,  H,  x,  H ),
    ( L,  H,  x,  x,  H,  x,  H,  x,  H ),
    ( L,  x,  L,  L,  L,  x,  H,  x,  L ),
    ( L,  x,  L,  x,  L,  L,  H,  x,  L ),
    ( L,  x,  H,  H,  L,  x,  H,  x,  H ),
    ( L,  x,  H,  x,  L,  L,  H,  x,  H ),
    ( L,  x,  x,  L,  L,  H,  H,  x,  L ),
    ( L,  x,  x,  H,  L,  H,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  x,  x,  L,  x,  S ));
-- END: for TCB015's 15 scan cells (May 3, 2000)


-- BEGIN: for TCB015's 18 new cells (Mar 13, 2000)

   CONSTANT EDFKCND1_Q_tab : VitalStateTableType := (
    ( L,  L,  x,  x,  x,  H,  x,  L ),
    ( L,  H,  H,  H,  x,  H,  x,  H ),
    ( L,  H,  H,  x,  L,  H,  x,  H ),
    ( L,  H,  x,  H,  H,  H,  x,  H ),
    ( L,  x,  L,  L,  x,  H,  x,  L ),
    ( L,  x,  L,  x,  L,  H,  x,  L ),
    ( L,  x,  x,  L,  H,  H,  x,  L ),
    ( H,  x,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  x,  L,  x,  S ));

   CONSTANT SEDFKCND1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  x,  x,  x,  x,  H,  x,  L ),
    ( L,  L,  x,  L,  x,  x,  x,  H,  x,  L ),
    ( L,  L,  x,  x,  L,  L,  x,  H,  x,  L ),
    ( L,  L,  x,  x,  L,  x,  L,  H,  x,  L ),
    ( L,  L,  x,  x,  x,  L,  H,  H,  x,  L ),
    ( L,  H,  H,  x,  x,  x,  x,  H,  x,  H ),
    ( L,  H,  x,  H,  H,  H,  x,  H,  x,  H ),
    ( L,  H,  x,  H,  H,  x,  L,  H,  x,  H ),
    ( L,  H,  x,  H,  x,  H,  H,  H,  x,  H ),
    ( L,  x,  L,  L,  x,  x,  x,  H,  x,  L ),
    ( L,  x,  L,  H,  H,  H,  x,  H,  x,  H ),
    ( L,  x,  L,  H,  H,  x,  L,  H,  x,  H ),
    ( L,  x,  L,  H,  x,  H,  H,  H,  x,  H ),
    ( L,  x,  L,  x,  L,  L,  x,  H,  x,  L ),
    ( L,  x,  L,  x,  L,  x,  L,  H,  x,  L ),
    ( L,  x,  L,  x,  x,  L,  H,  H,  x,  L ),
    ( H,  x,  x,  x,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  x,  x,  x,  L,  x,  S ));
-- END

-- BEGIN: for TCB015's new cells (Mar 7, 2000) 

   CONSTANT CKLNQD1_Q_tab : VitalStateTableType := (
    ( L,  x,  L,  L,  x,  x,  L ),
    ( L,  x,  H,  x,  H,  x,  H ),
    ( L,  x,  x,  H,  H,  x,  H ),
    ( x,  x,  x,  x,  L,  x,  L ),
    ( H,  L,  x,  x,  H,  x,  L ),
    ( H,  H,  x,  x,  H,  x,  H ),
    ( H,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  L,  H,  x,  L ),
    ( x,  H,  H,  x,  H,  x,  H ),
    ( x,  H,  x,  H,  H,  x,  H ));

   CONSTANT DFCND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  S ),
    ( H,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  H,  x,  L ));

   CONSTANT DFCSND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  x,  H,  x,  H ),
    ( H,  H,  x,  H,  x,  x,  S ),
    ( H,  x,  x,  L,  x,  x,  H ),
    ( H,  x,  x,  H,  L,  x,  S ),
    ( x,  L,  L,  H,  H,  x,  L ));

   CONSTANT DFCSND1_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  x,  L,  H,  x,  H ),
    ( H,  H,  H,  x,  x,  x,  S ),
    ( H,  x,  L,  x,  x,  x,  H ),
    ( H,  x,  H,  x,  L,  x,  S ),
    ( x,  L,  H,  H,  H,  x,  L ));

   CONSTANT DFD1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  x,  L ),
    ( L,  H,  H,  x,  H ),
    ( H,  x,  x,  x,  S ),
    ( x,  x,  L,  x,  S ));

   CONSTANT DFKCND1_Q_tab : VitalStateTableType := (
    ( L,  L,  x,  H,  x,  L ),
    ( L,  H,  H,  H,  x,  H ),
    ( L,  x,  L,  H,  x,  L ),
    ( H,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  L,  x,  S ));

   CONSTANT DFKCSND1_Q_tab : VitalStateTableType := (
    ( L,  L,  x,  x,  H,  x,  L ),
    ( L,  H,  H,  x,  H,  x,  H ),
    ( L,  H,  x,  L,  H,  x,  H ),
    ( L,  x,  L,  H,  H,  x,  L ),
    ( H,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  S ));

   CONSTANT DFKSND1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  H,  x,  L ),
    ( L,  H,  x,  H,  x,  H ),
    ( L,  x,  L,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  L,  x,  S ));

   CONSTANT DFSND1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  H,  x,  L ),
    ( L,  H,  x,  H,  x,  H ),
    ( H,  x,  H,  x,  x,  S ),
    ( x,  x,  L,  x,  x,  H ),
    ( x,  x,  H,  L,  x,  S ));

   CONSTANT DFXD1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  x,  L ),
    ( L,  L,  x,  L,  H,  x,  L ),
    ( L,  H,  H,  x,  H,  x,  H ),
    ( L,  H,  x,  L,  H,  x,  H ),
    ( L,  x,  L,  H,  H,  x,  L ),
    ( L,  x,  H,  H,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  S ));

   CONSTANT EDFCND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  L,  H,  x,  H ),
    ( H,  L,  x,  H,  H,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  L,  x,  H,  x,  L ),
    ( x,  L,  L,  x,  L,  H,  x,  L ),
    ( x,  L,  x,  L,  H,  H,  x,  L ));


   CONSTANT LHCSND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  H,  x,  L ),
    ( H,  H,  H,  x,  x,  H ),
    ( H,  x,  L,  H,  x,  S ),
    ( x,  L,  H,  H,  x,  L ),
    ( x,  x,  x,  L,  x,  H ));

   CONSTANT LHD1_Q_tab : VitalStateTableType := (
    ( L,  H,  x,  L ),
    ( H,  H,  x,  H ),
    ( x,  L,  x,  S ));

   CONSTANT LNCSND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  H,  x,  L ),
    ( H,  L,  H,  x,  x,  H ),
    ( H,  H,  x,  H,  x,  S ),
    ( x,  L,  L,  H,  x,  L ),
    ( x,  x,  x,  L,  x,  H ));

   CONSTANT LND1_Q_tab : VitalStateTableType := (
    ( L,  L,  x,  L ),
    ( L,  H,  x,  H ),
    ( H,  x,  x,  S ));

   CONSTANT SDFCND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  H,  H,  x,  H ),
    ( H,  L,  x,  H,  L,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  L,  x,  H,  x,  L ),
    ( x,  L,  L,  x,  H,  H,  x,  L ),
    ( x,  L,  x,  L,  L,  H,  x,  L ));

   CONSTANT SDFCSND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  H,  x,  H,  x,  H ),
    ( H,  L,  x,  H,  L,  x,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  H,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  x,  H ),
    ( H,  x,  x,  x,  x,  H,  L,  x,  S ),
    ( x,  L,  L,  L,  x,  H,  H,  x,  L ),
    ( x,  L,  L,  x,  H,  H,  H,  x,  L ),
    ( x,  L,  x,  L,  L,  H,  H,  x,  L ));

   CONSTANT SDFCSND1_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  L,  x,  L,  x,  H,  x,  H ),
    ( H,  L,  H,  L,  x,  x,  H,  x,  H ),
    ( H,  L,  x,  L,  L,  x,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  H,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  x,  H ),
    ( H,  x,  x,  x,  x,  H,  L,  x,  S ),
    ( x,  L,  L,  x,  H,  H,  H,  x,  L ),
    ( x,  L,  H,  H,  x,  H,  H,  x,  L ),
    ( x,  L,  x,  H,  H,  H,  H,  x,  L ));

   CONSTANT SDFD1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  x,  L ),
    ( L,  L,  x,  H,  H,  x,  L ),
    ( L,  H,  H,  x,  H,  x,  H ),
    ( L,  H,  x,  H,  H,  x,  H ),
    ( L,  x,  L,  L,  H,  x,  L ),
    ( L,  x,  H,  L,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  S ));

   CONSTANT SDFKCND1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  x,  x,  H,  x,  L ),
    ( L,  L,  x,  L,  x,  H,  x,  L ),
    ( L,  L,  x,  x,  L,  H,  x,  L ),
    ( L,  H,  H,  x,  x,  H,  x,  H ),
    ( L,  H,  x,  H,  H,  H,  x,  H ),
    ( L,  x,  L,  L,  x,  H,  x,  L ),
    ( L,  x,  L,  H,  H,  H,  x,  H ),
    ( L,  x,  L,  x,  L,  H,  x,  L ),
    ( H,  x,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  x,  L,  x,  S ));

   CONSTANT SDFKCSND1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  x,  x,  H,  x,  L ),
    ( L,  L,  x,  H,  x,  x,  H,  x,  L ),
    ( L,  L,  x,  x,  L,  H,  H,  x,  L ),
    ( L,  H,  H,  x,  H,  x,  H,  x,  H ),
    ( L,  H,  H,  x,  x,  L,  H,  x,  H ),
    ( L,  H,  x,  H,  x,  x,  H,  x,  H ),
    ( L,  x,  L,  L,  x,  x,  H,  x,  L ),
    ( L,  x,  H,  L,  H,  x,  H,  x,  H ),
    ( L,  x,  H,  L,  x,  L,  H,  x,  H ),
    ( L,  x,  x,  L,  L,  H,  H,  x,  L ),
    ( H,  x,  x,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  x,  x,  L,  x,  S ));

   CONSTANT SDFKSND1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  H,  x,  L ),
    ( L,  L,  x,  H,  x,  H,  x,  L ),
    ( L,  H,  H,  x,  x,  H,  x,  H ),
    ( L,  H,  x,  H,  x,  H,  x,  H ),
    ( L,  H,  x,  x,  L,  H,  x,  H ),
    ( L,  x,  L,  L,  H,  H,  x,  L ),
    ( L,  x,  H,  L,  x,  H,  x,  H ),
    ( L,  x,  x,  L,  L,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  x,  L,  x,  S ));

   CONSTANT SDFSND1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  H,  x,  L ),
    ( L,  L,  x,  H,  H,  H,  x,  L ),
    ( L,  H,  H,  x,  x,  H,  x,  H ),
    ( L,  H,  x,  H,  x,  H,  x,  H ),
    ( L,  x,  L,  L,  H,  H,  x,  L ),
    ( L,  x,  H,  L,  x,  H,  x,  H ),
    ( H,  x,  x,  x,  H,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  x,  H ),
    ( x,  x,  x,  x,  H,  L,  x,  S ));

   CONSTANT SDFXD1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  L,  x,  x,  H,  x,  L ),
    ( L,  L,  L,  x,  x,  L,  H,  x,  L ),
    ( L,  L,  x,  L,  x,  H,  H,  x,  L ),
    ( L,  L,  x,  x,  H,  x,  H,  x,  L ),
    ( L,  H,  H,  H,  x,  x,  H,  x,  H ),
    ( L,  H,  H,  x,  x,  L,  H,  x,  H ),
    ( L,  H,  x,  H,  x,  H,  H,  x,  H ),
    ( L,  H,  x,  x,  H,  x,  H,  x,  H ),
    ( L,  x,  L,  L,  L,  x,  H,  x,  L ),
    ( L,  x,  L,  x,  L,  L,  H,  x,  L ),
    ( L,  x,  H,  H,  L,  x,  H,  x,  H ),
    ( L,  x,  H,  x,  L,  L,  H,  x,  H ),
    ( L,  x,  x,  L,  L,  H,  H,  x,  L ),
    ( L,  x,  x,  H,  L,  H,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  x,  x,  L,  x,  S ));

   CONSTANT SEDFCND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  H,  x,  x,  H,  x,  H ),
    ( H,  L,  H,  H,  x,  x,  L,  H,  x,  H ),
    ( H,  L,  H,  x,  H,  x,  H,  H,  x,  H ),
    ( H,  L,  H,  x,  x,  H,  x,  H,  x,  H ),
    ( H,  L,  x,  H,  H,  L,  x,  H,  x,  H ),
    ( H,  L,  x,  H,  x,  L,  L,  H,  x,  H ),
    ( H,  L,  x,  x,  H,  L,  H,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  x,  x,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  L,  L,  x,  x,  H,  x,  L ),
    ( x,  L,  L,  L,  x,  x,  L,  H,  x,  L ),
    ( x,  L,  L,  x,  L,  x,  H,  H,  x,  L ),
    ( x,  L,  L,  x,  x,  H,  x,  H,  x,  L ),
    ( x,  L,  x,  L,  L,  L,  x,  H,  x,  L ),
    ( x,  L,  x,  L,  x,  L,  L,  H,  x,  L ),
    ( x,  L,  x,  x,  L,  L,  H,  H,  x,  L ));

-- END


-- BEGIN: for TCB015's scan cells (Feb 9, 2000) (cells DFXKSNn(Q), SDFKSN(Q)Dn
   CONSTANT DFXKSN1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  H,  x,  L ),
    ( L,  L,  x,  L,  H,  H,  x,  L ),
    ( L,  H,  H,  x,  x,  H,  x,  H ),
    ( L,  H,  x,  L,  x,  H,  x,  H ),
    ( L,  x,  L,  H,  H,  H,  x,  L ),
    ( L,  x,  H,  H,  x,  H,  x,  H ),
    ( L,  x,  x,  x,  L,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  x,  L,  x,  S ));
-- END: for TCB015's scan cells (Feb 9, 2000)


-- Added them for TCB015 (Sep 15, 1999)

   CONSTANT DFKRN1_Q_tab : VitalStateTableType := (
    ( L,  L,  x,  H,  x,  L ),
    ( L,  H,  H,  H,  x,  H ),
    ( L,  x,  L,  H,  x,  L ),
    ( H,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  L,  x,  S ));

   CONSTANT DFKRN1N_QN_tab : VitalStateTableType := (
    ( L,  L,  x,  H,  x,  H ),
    ( L,  H,  H,  H,  x,  L ),
    ( L,  x,  L,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  L,  x,  S ));

   CONSTANT DFKRSN1_Q_tab : VitalStateTableType := (
    ( L,  L,  x,  x,  H,  x,  L ),
    ( L,  H,  H,  x,  H,  x,  H ),
    ( L,  H,  x,  L,  H,  x,  H ),
    ( L,  x,  L,  H,  H,  x,  L ),
    ( H,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  S ));

   CONSTANT DFKRSN1N_QN_tab : VitalStateTableType := (
    ( L,  L,  x,  H,  H,  x,  L ),
    ( L,  H,  L,  x,  H,  x,  H ),
    ( L,  x,  H,  H,  H,  x,  L ),
    ( L,  x,  x,  L,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  S ));

   CONSTANT DFKSN1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  H,  x,  L ),
    ( L,  H,  x,  H,  x,  H ),
    ( L,  x,  L,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  L,  x,  S ));

   CONSTANT DFKSN1N_QN_tab : VitalStateTableType := (
    ( L,  L,  x,  H,  x,  L ),
    ( L,  H,  L,  H,  x,  H ),
    ( L,  x,  H,  H,  x,  L ),
    ( H,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  L,  x,  S ));

---- end of new VITAL tables ----


-- Added them for TCB872 (Sep 22, 1998)
   CONSTANT DFCNEX1Q_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  L,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  x,  S ),
    ( H,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  x,  H,  x,  L ),
    ( x,  L,  x,  H,  H,  x,  L ));
-- End

-- Begin: added by TY Wu (Mar 27, 1998)
-- Remove the bug in DFCNE1Q (Sep 22, 1998)

   CONSTANT DFCNE1Q_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  x,  S ),
    ( H,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  x,  H,  x,  L ),
    ( x,  L,  x,  L,  H,  x,  L ));
 
   CONSTANT DFCNS1Q_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  L,  H,  x,  H ),
    ( H,  L,  x,  H,  H,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  L,  x,  H,  x,  L ),
    ( x,  L,  L,  x,  L,  H,  x,  L ),
    ( x,  L,  x,  L,  H,  H,  x,  L ));

-- End

-- Begin: edited by TY Wu

   CONSTANT CNTCN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  L,  H,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  x,  S ),
    ( H,  x,  x,  L,  x,  x,  S ),
    ( H,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  H,  H,  H,  x,  L ));

   CONSTANT CNTCSN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  x,  L,  H,  H,  x,  H ),
    ( H,  H,  H,  x,  x,  x,  x,  S ),
    ( H,  x,  L,  x,  x,  x,  x,  H ),
    ( H,  x,  H,  x,  L,  x,  x,  S ),
    ( H,  x,  H,  x,  x,  L,  x,  S ),
    ( x,  L,  H,  H,  H,  H,  x,  L ));

   CONSTANT CNTCSN1_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  x,  H,  H,  x,  H ),
    ( H,  H,  x,  H,  x,  x,  x,  S ),
    ( H,  x,  x,  L,  x,  x,  x,  H ),
    ( H,  x,  x,  H,  L,  x,  x,  S ),
    ( H,  x,  x,  H,  x,  L,  x,  S ),
    ( x,  L,  L,  H,  H,  H,  x,  L ));

-- End

   CONSTANT DFCN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  S ),
    ( H,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  H,  x,  L ));

   CONSTANT DFCN1N_QN_tab : VitalStateTableType := (
    ( L,  H,  H,  H,  x,  L ),
    ( L,  x,  L,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  S ),
    ( x,  L,  x,  x,  x,  H ),
    ( x,  H,  x,  L,  x,  S ));

   CONSTANT DFCSN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  x,  H,  x,  H ),
    ( H,  H,  x,  H,  x,  x,  S ),
    ( H,  x,  x,  L,  x,  x,  H ),
    ( H,  x,  x,  H,  L,  x,  S ),
    ( x,  L,  L,  H,  H,  x,  L ));

   CONSTANT DFCSN1_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  x,  L,  H,  x,  H ),
    ( H,  H,  H,  x,  x,  x,  S ),
    ( H,  x,  L,  x,  x,  x,  H ),
    ( H,  x,  H,  x,  L,  x,  S ),
    ( x,  L,  H,  H,  H,  x,  L ));

   CONSTANT DFF1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  x,  L ),
    ( L,  H,  H,  x,  H ),
    ( H,  x,  x,  x,  S ),
    ( x,  x,  L,  x,  S ));

   CONSTANT DFF1N_QN_tab : VitalStateTableType := (
    ( L,  L,  H,  x,  H ),
    ( L,  H,  H,  x,  L ),
    ( H,  x,  x,  x,  S ),
    ( x,  x,  L,  x,  S ));

   CONSTANT DFSN1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  H,  x,  L ),
    ( L,  H,  x,  H,  x,  H ),
    ( H,  x,  H,  x,  x,  S ),
    ( x,  x,  L,  x,  x,  H ),
    ( x,  x,  H,  L,  x,  S ));

   CONSTANT DFSN1N_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  L ),
    ( H,  L,  L,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  S ),
    ( H,  x,  x,  L,  x,  S ),
    ( x,  L,  H,  H,  x,  L ));

   CONSTANT DFX1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  x,  L ),
    ( L,  L,  x,  L,  H,  x,  L ),
    ( L,  H,  H,  x,  H,  x,  H ),
    ( L,  H,  x,  L,  H,  x,  H ),
    ( L,  x,  L,  H,  H,  x,  L ),
    ( L,  x,  H,  H,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  S ));

   CONSTANT DFX1N_QN_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  x,  H ),
    ( L,  L,  H,  x,  H,  x,  L ),
    ( L,  H,  x,  L,  H,  x,  H ),
    ( L,  H,  x,  H,  H,  x,  L ),
    ( L,  x,  L,  L,  H,  x,  H ),
    ( L,  x,  H,  H,  H,  x,  L ),
    ( H,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  S ));

   CONSTANT DFXCN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  L,  H,  x,  H ),
    ( H,  L,  x,  H,  H,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  L,  x,  H,  x,  L ),
    ( x,  L,  L,  x,  L,  H,  x,  L ),
    ( x,  L,  x,  L,  H,  H,  x,  L ));

   CONSTANT DFXCN1N_QN_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  x,  H,  x,  H ),
    ( L,  L,  H,  x,  H,  H,  x,  L ),
    ( L,  H,  x,  L,  x,  H,  x,  H ),
    ( L,  H,  x,  H,  H,  H,  x,  L ),
    ( L,  x,  L,  L,  x,  H,  x,  H ),
    ( L,  x,  H,  H,  H,  H,  x,  L ),
    ( H,  x,  x,  x,  H,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  x,  H ),
    ( x,  x,  x,  x,  H,  L,  x,  S ));

   CONSTANT DFXCSN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  L,  x,  H,  x,  H ),
    ( H,  L,  x,  H,  H,  x,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  H,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  x,  H ),
    ( H,  x,  x,  x,  x,  H,  L,  x,  S ),
    ( x,  L,  L,  L,  x,  H,  H,  x,  L ),
    ( x,  L,  L,  x,  L,  H,  H,  x,  L ),
    ( x,  L,  x,  L,  H,  H,  H,  x,  L ));

   CONSTANT DFXCSN1_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  L,  L,  x,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  L,  x,  H,  x,  H ),
    ( H,  L,  x,  L,  L,  x,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  H,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  x,  H ),
    ( H,  x,  x,  x,  x,  H,  L,  x,  S ),
    ( x,  L,  L,  H,  x,  H,  H,  x,  L ),
    ( x,  L,  H,  x,  H,  H,  H,  x,  L ),
    ( x,  L,  x,  H,  H,  H,  H,  x,  L ));

   CONSTANT DFXSN1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  H,  x,  L ),
    ( L,  L,  x,  L,  H,  H,  x,  L ),
    ( L,  H,  H,  x,  x,  H,  x,  H ),
    ( L,  H,  x,  L,  x,  H,  x,  H ),
    ( L,  x,  L,  H,  H,  H,  x,  L ),
    ( L,  x,  H,  H,  x,  H,  x,  H ),
    ( H,  x,  x,  x,  H,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  x,  H ),
    ( x,  x,  x,  x,  H,  L,  x,  S ));

   CONSTANT DFXSN1N_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  L,  L,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  L,  H,  x,  H ),
    ( H,  L,  x,  L,  L,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  H,  x,  H,  x,  L ),
    ( x,  L,  H,  x,  H,  H,  x,  L ),
    ( x,  L,  x,  H,  H,  H,  x,  L ));

   CONSTANT JKF1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  x,  L ),
    ( L,  L,  x,  H,  H,  x,  L ),
    ( L,  H,  L,  x,  H,  x,  H ),
    ( L,  H,  x,  L,  H,  x,  H ),
    ( L,  x,  H,  L,  H,  x,  H ),
    ( L,  x,  H,  H,  H,  x,  L ),
    ( H,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  S ));

   CONSTANT JKFCN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  L,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  L,  H,  x,  H ),
    ( H,  L,  x,  H,  L,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  L,  x,  H,  x,  L ),
    ( x,  L,  L,  x,  H,  H,  x,  L ),
    ( x,  L,  x,  H,  H,  H,  x,  L ));

   CONSTANT JKFCN1N_QN_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  H,  x,  L ),
    ( L,  L,  x,  H,  H,  H,  x,  L ),
    ( L,  H,  L,  x,  x,  H,  x,  H ),
    ( L,  H,  x,  L,  x,  H,  x,  H ),
    ( L,  x,  H,  L,  x,  H,  x,  H ),
    ( L,  x,  H,  H,  H,  H,  x,  L ),
    ( H,  x,  x,  x,  H,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  x,  H ),
    ( x,  x,  x,  x,  H,  L,  x,  S ));

   CONSTANT JKFCSN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  L,  x,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  L,  x,  H,  x,  H ),
    ( H,  L,  x,  H,  L,  x,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  H,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  x,  H ),
    ( H,  x,  x,  x,  x,  H,  L,  x,  S ),
    ( x,  L,  L,  L,  x,  H,  H,  x,  L ),
    ( x,  L,  L,  x,  H,  H,  H,  x,  L ),
    ( x,  L,  x,  H,  H,  H,  H,  x,  L ));

   CONSTANT JKFCSN1_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  L,  x,  H,  x,  H ),
    ( H,  L,  x,  L,  L,  x,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  H,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  x,  H ),
    ( H,  x,  x,  x,  x,  H,  L,  x,  S ),
    ( x,  L,  L,  H,  x,  H,  H,  x,  L ),
    ( x,  L,  L,  x,  H,  H,  H,  x,  L ),
    ( x,  L,  x,  L,  H,  H,  H,  x,  L ));

   CONSTANT LH1_Q_tab : VitalStateTableType := (
    ( L,  H,  x,  L ),
    ( H,  H,  x,  H ),
    ( x,  L,  x,  S ));

   CONSTANT LH1N_QN_tab : VitalStateTableType := (
    ( L,  H,  x,  H ),
    ( H,  H,  x,  L ),
    ( x,  L,  x,  S ));

   CONSTANT LHCN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  L ),
    ( H,  H,  H,  x,  H ),
    ( H,  x,  L,  x,  S ),
    ( x,  L,  H,  x,  L ));

   CONSTANT LHCN1N_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  H ),
    ( H,  H,  H,  x,  L ),
    ( H,  x,  L,  x,  S ),
    ( x,  L,  H,  x,  H ));

   CONSTANT LN1_Q_tab : VitalStateTableType := (
    ( L,  L,  x,  L ),
    ( L,  H,  x,  H ),
    ( H,  x,  x,  S ));

   CONSTANT LN1N_QN_tab : VitalStateTableType := (
    ( L,  L,  x,  H ),
    ( L,  H,  x,  L ),
    ( H,  x,  x,  S ));

   CONSTANT LNCN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  L ),
    ( H,  L,  H,  x,  H ),
    ( H,  H,  x,  x,  S ),
    ( x,  L,  L,  x,  L ));

   CONSTANT LNCN1N_QN_tab : VitalStateTableType := (
    ( L,  H,  H,  x,  L ),
    ( L,  x,  L,  x,  H ),
    ( H,  H,  x,  x,  S ),
    ( x,  L,  x,  x,  H ));

   CONSTANT LNCSN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  H,  x,  L ),
    ( H,  L,  H,  x,  x,  H ),
    ( H,  H,  x,  H,  x,  S ),
    ( x,  L,  L,  H,  x,  L ),
    ( x,  x,  x,  L,  x,  H ));

   CONSTANT LNCSN1N_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  L ),
    ( H,  L,  x,  L,  x,  H ),
    ( H,  H,  H,  x,  x,  S ),
    ( H,  x,  L,  x,  x,  H ),
    ( x,  L,  H,  H,  x,  L ));

   CONSTANT LNSN1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  x,  L ),
    ( L,  H,  x,  x,  H ),
    ( H,  x,  H,  x,  S ),
    ( x,  x,  L,  x,  H ));

   CONSTANT LNSN1N_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  L ),
    ( H,  L,  L,  x,  H ),
    ( H,  H,  x,  x,  S ),
    ( x,  L,  H,  x,  L ));

   CONSTANT NDL1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  L ),
    ( H,  L,  x,  H ),
    ( H,  H,  x,  S ));

   CONSTANT NRL1_Q_tab : VitalStateTableType := (
    ( L,  L,  x,  S ),
    ( L,  H,  x,  L ),
    ( H,  x,  x,  H ));

   CONSTANT TFCN1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  L ),
    ( H,  L,  L,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  S ),
    ( H,  x,  x,  L,  x,  S ),
    ( x,  L,  H,  H,  x,  L ));


-- Dec 22, 2000 
-- TYWU Beging

   CONSTANT DFNCND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  S ),
    ( H,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  H,  x,  L ));

   CONSTANT DFNCSND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  x,  H,  x,  H ),
    ( H,  H,  x,  H,  x,  x,  S ),
    ( H,  x,  x,  L,  x,  x,  H ),
    ( H,  x,  x,  H,  L,  x,  S ),
    ( x,  L,  L,  H,  H,  x,  L ));

   CONSTANT DFNCSND1_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  x,  L,  H,  x,  H ),
    ( H,  H,  H,  x,  x,  x,  S ),
    ( H,  x,  L,  x,  x,  x,  H ),
    ( H,  x,  H,  x,  L,  x,  S ),
    ( x,  L,  H,  H,  H,  x,  L ));

   CONSTANT DFND1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  x,  L ),
    ( L,  H,  H,  x,  H ),
    ( H,  x,  x,  x,  S ),
    ( x,  x,  L,  x,  S ));

   CONSTANT DFNSND1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  H,  x,  L ),
    ( L,  H,  x,  H,  x,  H ),
    ( H,  x,  H,  x,  x,  S ),
    ( x,  x,  L,  x,  x,  H ),
    ( x,  x,  H,  L,  x,  S ));

   CONSTANT LHCND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  L ),
    ( H,  H,  H,  x,  H ),
    ( H,  x,  L,  x,  S ),
    ( x,  L,  H,  x,  L ));

   CONSTANT LHSND1_Q_tab : VitalStateTableType := (
    ( L,  H,  H,  x,  L ),
    ( H,  x,  H,  x,  H ),
    ( x,  L,  x,  x,  H ),
    ( x,  H,  L,  x,  S ));

   CONSTANT LNCND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  L ),
    ( H,  L,  H,  x,  H ),
    ( H,  H,  x,  x,  S ),
    ( x,  L,  L,  x,  L ));

   CONSTANT LNSND1_Q_tab : VitalStateTableType := (
    ( L,  L,  H,  x,  L ),
    ( L,  H,  x,  x,  H ),
    ( H,  x,  H,  x,  S ),
    ( x,  x,  L,  x,  H ));

   CONSTANT SDFNCND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  H,  H,  x,  H ),
    ( H,  L,  x,  H,  L,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  S ),
    ( x,  L,  L,  L,  x,  H,  x,  L ),
    ( x,  L,  L,  x,  H,  H,  x,  L ),
    ( x,  L,  x,  L,  L,  H,  x,  L ));

   CONSTANT SDFNCSND1_Q_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  H,  H,  x,  x,  H,  x,  H ),
    ( H,  L,  H,  x,  H,  x,  H,  x,  H ),
    ( H,  L,  x,  H,  L,  x,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  H,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  x,  H ),
    ( H,  x,  x,  x,  x,  H,  L,  x,  S ),
    ( x,  L,  L,  L,  x,  H,  H,  x,  L ),
    ( x,  L,  L,  x,  H,  H,  H,  x,  L ),
    ( x,  L,  x,  L,  L,  H,  H,  x,  L ));

   CONSTANT SDFNCSND1_QN_tab : VitalStateTableType := (
    ( L,  x,  x,  x,  x,  x,  x,  x,  L ),
    ( H,  L,  L,  x,  L,  x,  H,  x,  H ),
    ( H,  L,  H,  L,  x,  x,  H,  x,  H ),
    ( H,  L,  x,  L,  L,  x,  H,  x,  H ),
    ( H,  H,  x,  x,  x,  H,  x,  x,  S ),
    ( H,  x,  x,  x,  x,  L,  x,  x,  H ),
    ( H,  x,  x,  x,  x,  H,  L,  x,  S ),
    ( x,  L,  L,  x,  H,  H,  H,  x,  L ),
    ( x,  L,  H,  H,  x,  H,  H,  x,  L ),
    ( x,  L,  x,  H,  H,  H,  H,  x,  L ));

   CONSTANT SDFND1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  x,  L ),
    ( L,  L,  x,  H,  H,  x,  L ),
    ( L,  H,  H,  x,  H,  x,  H ),
    ( L,  H,  x,  H,  H,  x,  H ),
    ( L,  x,  L,  L,  H,  x,  L ),
    ( L,  x,  H,  L,  H,  x,  H ),
    ( H,  x,  x,  x,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  S ));

   CONSTANT SDFNSND1_Q_tab : VitalStateTableType := (
    ( L,  L,  L,  x,  H,  H,  x,  L ),
    ( L,  L,  x,  H,  H,  H,  x,  L ),
    ( L,  H,  H,  x,  x,  H,  x,  H ),
    ( L,  H,  x,  H,  x,  H,  x,  H ),
    ( L,  x,  L,  L,  H,  H,  x,  L ),
    ( L,  x,  H,  L,  x,  H,  x,  H ),
    ( H,  x,  x,  x,  H,  x,  x,  S ),
    ( x,  x,  x,  x,  L,  x,  x,  H ),
    ( x,  x,  x,  x,  H,  L,  x,  S ));

   CONSTANT KR5CZLUHD1_Q_tab : VitalStateTableType := (
    ( L,  H,  H,  x,  L ),
    ( H,  H,  H,  x,  H ),
    ( x,  H,  L,  x,  S ),
    ( x,  L,  H,  x,  S ),
    ( x,  L,  L,  x,  S ));

   CONSTANT KR5CZLUHRD1_Q_tab : VitalStateTableType := (
    ( x,  x,  x,  H,  x,  L ),
    ( L,  H,  H,  L,  x,  L ),
    ( H,  H,  H,  L,  x,  H ),
    ( x,  H,  L,  L,  x,  S ),
    ( x,  L,  H,  L,  x,  S ),
    ( x,  L,  L,  L,  x,  S ));

   CONSTANT KR5CZLUHSD1_Q_tab : VitalStateTableType := (
    ( x,  x,  x,  L,  x,  H ),
    ( L,  H,  H,  H,  x,  L ),
    ( H,  H,  H,  H,  x,  H ),
    ( x,  H,  L,  H,  x,  S ),
    ( x,  L,  H,  H,  x,  S ),
    ( x,  L,  L,  H,  x,  S ));

   CONSTANT KR5CZDUPSRD2_Q_tab : VitalStateTableType := (
    ( H,  x,  x,  x,  x,  x,  x,  x,  L ),
    ( L,  L,  x,  x,  x,  x,  x,  x,  H ),
    ( L,  H,  L,  L,  x,  x,  x,  x,  S ),
    ( L,  H,  L,  H,  L,  x,  x,  x,  S ),
    ( L,  H,  L,  H,  H,  L,  x,  x,  S ),
    ( L,  H,  L,  H,  H,  H,  L,  x,  L ),
    ( L,  H,  L,  H,  H,  H,  H,  x,  H ),
    ( L,  H,  H,  L,  x,  x,  x,  x,  S ),
    ( L,  H,  H,  H,  H,  x,  x,  x,  S ),
    ( L,  H,  H,  H,  L,  L,  x,  x,  S ),
    ( L,  H,  H,  H,  L,  H,  L,  x,  L ),
    ( L,  H,  H,  H,  L,  H,  H,  x,  H ));
    
   CONSTANT KRPCHGHLD32_tab : VitalStateTableType := (
    ( L,  x,  H ),
    ( H,  L,  L ),
    ( H,  H,  H));

CONSTANT tsmc_udpmux : VitalTruthTableType (1 TO 12, 1 TO 6) := (
     (  '0',   '1',   '1',   '-',   '-',    '0' ),
     (  '0',   '1',   '0',   '0',   '-',    '1' ),
     (  '0',   '1',   '0',   '1',   '-',    '0' ),
     (  '0',   '0',   '1',   '0',   '-',    '0' ),
     (  '0',   '0',   '1',   '1',   '-',    '1' ),
     (  '0',   '0',   '0',   '-',   '-',    '1' ),
     (  '1',   '1',   '1',   '-',   '-',    '0' ),
     (  '1',   '1',   '0',   '-',   '0',    '1' ),
     (  '1',   '1',   '0',   '-',   '1',    '0' ),
     (  '1',   '0',   '1',   '-',   '0',    '0' ),
     (  '1',   '0',   '1',   '-',   '1',    '1' ),
     (  '1',   '0',   '0',   '-',   '-',    '1' ));

CONSTANT tsmc_udpts : VitalStateTableType (1 TO 8, 1 TO 6) := (
--      NOT      D       G      GN       Q(t)  Q(t+1)
     (  'X',    '-',    '-',    '-',    '-',    'X'  ),
     (  '-',    '1',    '1',    '0',    '-',    '0'  ),
     (  '-',    '0',    '1',    '0',    '-',    '1'  ),
     (  '-',    '0',    '*',    '-',    '1',    '1'  ),
     (  '-',    '1',    '*',    '-',    '-',    'S'  ),
     (  '-',    '0',    '-',    '*',    '1',    '1'  ),
     (  '-',    '1',    '-',    '*',    '-',    'S'  ),
     (  '-',    '-',    '0',    '1',    '-',    'S'  ));

CONSTANT tsmc_orf : VitalTruthTableType (1 TO 5, 1 TO 4) := (
     (  '0',    '0',    '-',    '0'  ),
     (  '1',    '-',    '1',    '0'  ),
     (  '-',    '1',    '0',    '1'  ),
     (  '1',    '-',    '-',    '1'  ),
     (  '0',    '1',    '-',    '1'  ));

end VTABLES;

---- end of VITAL tables library ----
