------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TSMC Library/IP Product
-- Filename: PVDD2CDG_25.vhd
-- Technology: CLN90G
-- Product Type: Standard I/O
-- Product Name: tpdn90g2
-- Version: 130a
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----
--  STATEMENT OF USE
--
--  This information contains confidential and proprietary information of TSMC.
--  No part of this information may be reproduced, transmitted, transcribed,
--  stored in a retrieval system, or translated into any human or computer
--  language, in any form or by any means, electronic, mechanical, magnetic,
--  optical, chemical, manual, or otherwise, without the prior written permission
--  of TSMC.  This information was prepared for informational purpose and is for
--  use by TSMC's customers only.  TSMC reserves the right to make changes in the
--  information at any time and without notice.
--
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------
--            Technology   :  tpdn90g2
--            Created by   :  NISUNG, TSMC ASIC 
--            Created Date :  Fri Dec 24 10:04:43 CST 2004
---------------------------------------------------------
---------------------------------------------------
------  The file is generated using changevital.pl
---------------------------------------------------
----- CELL PVDD2CDG_25 -----
library IEEE;
use IEEE.STD_LOGIC_1164.all;
-- synopsys translate_off 
library IEEE;
use IEEE.VITAL_Timing.all;


-- synopsys translate_on 
-- entity declaration --
entity PVDD2CDG_25 is
-- synopsys translate_off 
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True);

-- synopsys translate_on 
--   port();
attribute VITAL_LEVEL0 of PVDD2CDG_25 : entity is TRUE;
end PVDD2CDG_25;

-- architecture body --
library IEEE;
use IEEE.VITAL_Primitives.all;
library VITAL;
use VITAL.VTABLES.all;
architecture VITAL of PVDD2CDG_25 is
   attribute VITAL_LEVEL0 of VITAL : architecture is TRUE;


begin

   ---------------------
   --  INPUT PATH DELAYs
   ---------------------
   WireDelay : block
   begin
   --  empty
   end block;

end VITAL;

configuration CFG_PVDD2CDG_25_VITAL of PVDD2CDG_25 is
   for VITAL
   end for;
end CFG_PVDD2CDG_25_VITAL;


