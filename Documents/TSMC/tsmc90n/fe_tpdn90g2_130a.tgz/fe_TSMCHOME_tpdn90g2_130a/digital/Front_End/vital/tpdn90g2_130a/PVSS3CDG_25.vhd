------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TSMC Library/IP Product
-- Filename: PVSS3CDG_25.vhd
-- Technology: CLN90G
-- Product Type: Standard I/O
-- Product Name: tpdn90g2
-- Version: 130a
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----
--  STATEMENT OF USE
--
--  This information contains confidential and proprietary information of TSMC.
--  No part of this information may be reproduced, transmitted, transcribed,
--  stored in a retrieval system, or translated into any human or computer
--  language, in any form or by any means, electronic, mechanical, magnetic,
--  optical, chemical, manual, or otherwise, without the prior written permission
--  of TSMC.  This information was prepared for informational purpose and is for
--  use by TSMC's customers only.  TSMC reserves the right to make changes in the
--  information at any time and without notice.
--
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------
--            Technology   :  tpdn90g2
--            Created by   :  NISUNG, TSMC ASIC 
--            Created Date :  Fri Dec 24 10:04:43 CST 2004
---------------------------------------------------------
---------------------------------------------------
------  The file is generated using model2sdf.pl
---------------------------------------------------
----- CELL PVSS3CDG_25 -----
library IEEE;
use IEEE.STD_LOGIC_1164.all;
-- synopsys translate_off
library IEEE;
use IEEE.VITAL_Timing.all;
-- synopsys translate_on


-- entity declaration --
entity PVSS3CDG_25 is
-- synopsys translate_off
   generic(
      TimingChecksOn: Boolean := True;
      InstancePath: STRING := "*";
      Xon: Boolean := True;
      MsgOn: Boolean := True;
      tipd_VSS                       :	VitalDelayType01 := (0.000 ns, 0.000 ns));

-- synopsys translate_on
   port(
--Edit by NISUNG Wed Feb 19 14:50:02 CST 1997
--      VSS                            :	in    STD_ULOGIC);
      VSS                            :	inout    STD_ULOGIC);
attribute VITAL_LEVEL0 of PVSS3CDG_25 : entity is TRUE;
end PVSS3CDG_25;

-- architecture body --
library IEEE;
use IEEE.VITAL_Primitives.all;
library VITAL;
use VITAL.VTABLES.all;
architecture VITAL of PVSS3CDG_25 is
--Edit by NISUNG Wed Feb 19 14:50:02 CST 1997
--   attribute VITAL_LEVEL1 of VITAL : architecture is TRUE;
   attribute VITAL_LEVEL0 of VITAL : architecture is TRUE;


begin

--Edit by NISUNG Wed Feb 19 14:50:02 CST 1997
   VSS <= '0' ;

end VITAL;

configuration CFG_PVSS3CDG_25_VITAL of PVSS3CDG_25 is
   for VITAL
   end for;
end CFG_PVSS3CDG_25_VITAL;


