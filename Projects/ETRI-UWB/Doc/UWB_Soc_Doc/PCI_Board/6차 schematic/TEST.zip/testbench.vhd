library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity testbench is
end testbench;

architecture rtl of testbench is
    component test
	 Port ( CLK : in  STD_LOGIC;
           RST : in  STD_LOGIC;
           LED : out  STD_LOGIC_VECTOR (3 downto 0);
           SEGMENT_DATA : out  STD_LOGIC_VECTOR (7 downto 0);
           SEGMENT_COM : out  STD_LOGIC_VECTOR (3 downto 0));
	end component;
	
	signal clk : std_logic := '0';
	signal rst : std_logic := '0';
	
	signal led, segment_com : std_logic_vector( 3 downto 0 );
	
	signal segment_data : std_logic_vector( 7 downto 0 );
	
begin

    u1 : test port map ( clk, rst, led, segment_data, segment_com );
    
    
    clk <= not clk after 5ns;
    
    
    rst <= '0', '1' after 3ns;
end rtl;