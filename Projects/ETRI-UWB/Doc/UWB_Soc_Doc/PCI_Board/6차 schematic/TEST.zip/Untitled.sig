// PROMGEN: Xilinx Prom Generator J.32
// Copyright (c) 1995-2007 Xilinx, Inc.  All rights reserved.

DATE      04/16/07-09:15
SOURCE    E:\vhdl_test_folder\SH_P2\TEST\//Untitled.exo
DEVICE    XCF08P
SIGNATURE 0x0FBF5827
