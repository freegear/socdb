----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    09:40:54 04/14/2007 
-- Design Name: 
-- Module Name:    TEST - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TEST is
    Port ( CLK : in  STD_LOGIC;
           RST : in  STD_LOGIC;
           LED : out  STD_LOGIC_VECTOR (3 downto 0);
           SEGMENT_DATA : out  STD_LOGIC_VECTOR (7 downto 0);
           SEGMENT_COM : out  STD_LOGIC_VECTOR (0 to 3));
end TEST;

architecture Behavioral of TEST is
 COMPONENT DATA_CON_SEG_DATA
        PORT ( DATA_IN : IN STD_LOGIC_VECTOR( 3 DOWNTO 0 );
               DATA_OUT : OUT STD_LOGIC_VECTOR( 7 DOWNTO 0 ));
    END COMPONENT;
	CONSTANT FREQ_CLK : INTEGER := 25000000;
	CONSTANT SPEED    : INTEGER := 63;
	CONSTANT SCAN_SPD : INTEGER := 480;
	
	SIGNAL CLK1_DIV_CNTL : INTEGER RANGE 25000000 DOWNTO 0;
	SIGNAL CLK2_DIV_CNTL : INTEGER RANGE 25000000 DOWNTO 0;
	SIGNAL CLK1, CLK2 : STD_LOGIC;
	
	
	 SIGNAL SEG_0_COUNT : STD_LOGIC_VECTOR( 3 DOWNTO 0 );
    SIGNAL SEG_1_COUNT : STD_LOGIC_VECTOR( 3 DOWNTO 0 );
    SIGNAL SEG_2_COUNT : STD_LOGIC_VECTOR( 3 DOWNTO 0 );
    SIGNAL SEG_3_COUNT : STD_LOGIC_VECTOR( 3 DOWNTO 0 );
    SIGNAL SEG_1_EN,
           SEG_2_EN,
           SEG_3_EN : STD_LOGIC;
			  
    SIGNAL COM_SIG : STD_LOGIC_VECTOR( 3 DOWNTO 0 );

    SIGNAL SEL_DATA : STD_LOGIC_VECTOR( 3 DOWNTO 0 );			   
	
begin
  U0 : DATA_CON_SEG_DATA PORT MAP ( DATA_IN  => SEL_DATA,
                                      DATA_OUT => SEGMENT_DATA);

    SEGMENT_COM <= COM_SIG;

    PROCESS( CLK, RST )
    BEGIN
	     IF (RST='0') THEN
		      CLK1_DIV_CNTL <= 0;
				CLK1 <= '0';
		  ELSIF RISING_EDGE(CLK) THEN
		      IF (CLK1_DIV_CNTL=(FREQ_CLK/SPEED)) THEN
	             CLK1_DIV_CNTL <= 0;
					 CLK1 <= NOT CLK1;
				ELSE
				    CLK1_DIV_CNTL <= CLK1_DIV_CNTL + 1;
				END IF;
		  END IF;
    END PROCESS;
	 
	 
	 PROCESS( CLK, RST )
    BEGIN
	     IF (RST='0') THEN
		      CLK2_DIV_CNTL <= 0;
				CLK2 <= '0';
		  ELSIF RISING_EDGE(CLK) THEN
		      IF (CLK2_DIV_CNTL=(FREQ_CLK/SCAN_SPD)) THEN
	             CLK2_DIV_CNTL <= 0;
					 CLK2 <= NOT CLK2;
				ELSE
				    CLK2_DIV_CNTL <= CLK2_DIV_CNTL + 1;
				END IF;
		  END IF;
    END PROCESS;
	 
	 PROCESS( CLK1, RST )
	     VARIABLE LED_CNT : STD_LOGIC_VECTOR( 3 DOWNTO 0 );
	 BEGIN
	     IF ( RST='0' ) THEN
		      LED_CNT := "0000";
		  ELSIF RISING_EDGE(CLK1) THEN
		      CASE LED_CNT IS
				    WHEN "1110" => LED_CNT := "1101";
					 WHEN "1101" => LED_CNT := "1011";
					 WHEN "1011" => LED_CNT := "0111";
					 WHEN "0111" => LED_CNT := "1110";
					 WHEN OTHERS => LED_CNT := "1110";
				END CASE;
				
				LED <= LED_CNT;
				
			END IF;
		END PROCESS;
		
------------------------------------------------------------
   PROCESS( CLK1, RST )
    BEGIN
        IF ( RST='0' ) THEN
            SEG_0_COUNT <= ( OTHERS => '0' );
        ELSIF RISING_EDGE(CLK1) THEN
            IF (SEG_0_COUNT="1001") THEN
                SEG_0_COUNT <= ( OTHERS => '0' );
            ELSE
                SEG_0_COUNT <= SEG_0_COUNT + 1;
            END IF;
        END IF;
    END PROCESS;

    SEG_1_EN <= '1' WHEN ( SEG_0_COUNT="1001" ) ELSE '0';

    PROCESS( CLK1, RST )
    BEGIN
        IF ( RST='0' ) THEN
            SEG_1_COUNT <= ( OTHERS => '0' );
        ELSIF RISING_EDGE(CLK1) THEN
            IF (SEG_1_EN='1') THEN
                IF (SEG_1_COUNT="1001") THEN
                    SEG_1_COUNT <= ( OTHERS => '0' );
                ELSE
                    SEG_1_COUNT <= SEG_1_COUNT + 1;
                END IF;
            END IF;
        END IF;
    END PROCESS;

    SEG_2_EN <= '1' WHEN ( SEG_1_COUNT="1001" ) ELSE '0';

    PROCESS( CLK1, RST )
    BEGIN
        IF ( RST='0' ) THEN
            SEG_2_COUNT <= ( OTHERS => '0' );
        ELSIF RISING_EDGE(CLK1) THEN
            IF ((SEG_2_EN='1')AND(SEG_1_EN='1')) THEN
                IF (SEG_2_COUNT="1001") THEN
                    SEG_2_COUNT <= ( OTHERS => '0' );
                ELSE
                    SEG_2_COUNT <= SEG_2_COUNT + 1;
                END IF;
            END IF;
        END IF;
    END PROCESS;

    SEG_3_EN <= '1' WHEN ( SEG_2_COUNT="1001" ) ELSE '0';
            
    PROCESS( CLK1, RST )
    BEGIN
        IF ( RST='0' ) THEN
            SEG_3_COUNT <= ( OTHERS => '0' );
        ELSIF RISING_EDGE(CLK1) THEN
            IF ((SEG_3_EN='1')AND(SEG_2_EN='1')AND(SEG_1_EN='1')) THEN
                IF (SEG_3_COUNT="1001") THEN
                    SEG_3_COUNT <= ( OTHERS => '0' );
                ELSE
                    SEG_3_COUNT <= SEG_3_COUNT + 1;
                END IF;
            END IF;
        END IF;
    END PROCESS;
-- SEGMENT COMMON(-) SCANNING -----------------------------------------------
    PROCESS( CLK2, RST )
    BEGIN
        IF ( RST='0') THEN
             COM_SIG <= ( OTHERS => '0' );
        ELSIF RISING_EDGE(CLK2) THEN
            IF (COM_SIG="0000") THEN
                COM_SIG <= "1110";
            ELSE
                COM_SIG <= COM_SIG( 2 DOWNTO 0 ) & COM_SIG(3);
            END IF;
        END IF;
    END PROCESS;
-- DISPLAY DATA SELECT -------------------------------------------------------
    WITH COM_SIG SELECT
    SEL_DATA <= SEG_0_COUNT WHEN ("1110"),
                SEG_1_COUNT WHEN ("1101"),
                SEG_2_COUNT WHEN ("1011"),
                SEG_3_COUNT WHEN ("0111"),
                ( OTHERS => '1' ) WHEN OTHERS;		
		
		
		
		
	     


end Behavioral;

