library verilog;
use verilog.vl_types.all;
entity a926CacheDirtyIntf is
    port(
        CClk            : in     vl_logic;
        CnReset         : in     vl_logic;
        LFDIRTYrd       : in     vl_logic;
        sNSeqVA         : in     vl_logic_vector(14 downto 5);
        sEvictionWay    : in     vl_logic_vector(3 downto 0);
        LFDIRTYwr       : in     vl_logic;
        LfVA            : in     vl_logic_vector(14 downto 5);
        LfWay           : in     vl_logic_vector(3 downto 0);
        FBDirtyLower    : in     vl_logic;
        FBDirtyUpper    : in     vl_logic;
        PWRAMFull       : in     vl_logic;
        PWRAMWriteback  : in     vl_logic;
        PWRAMAddr       : in     vl_logic_vector(14 downto 4);
        PWRAMHitWay     : in     vl_logic_vector(3 downto 0);
        CnRW            : in     vl_logic;
        LFBlock         : in     vl_logic;
        CDIRTYCS        : out    vl_logic;
        CDIRTYA         : out    vl_logic_vector(9 downto 0);
        CDIRTYWE        : out    vl_logic_vector(7 downto 0);
        CDIRTYRD        : in     vl_logic_vector(7 downto 0);
        CDIRTYWD        : out    vl_logic_vector(7 downto 0);
        CBISTEN         : in     vl_logic;
        CBISTDIRTYCS    : in     vl_logic;
        CBISTA          : in     vl_logic_vector(9 downto 0);
        CP15DIRTYCS     : in     vl_logic;
        CP15DIRTYrd     : in     vl_logic;
        CP15DIRTYwr0    : in     vl_logic;
        CP15Way         : in     vl_logic_vector(3 downto 0);
        Dl              : out    vl_logic;
        Du              : out    vl_logic;
        sCDIRTYRD       : out    vl_logic_vector(7 downto 0)
    );
end a926CacheDirtyIntf;
