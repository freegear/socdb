library verilog;
use verilog.vl_types.all;
entity a926ejsCPjtag is
    port(
        CP15DebugClk    : in     vl_logic;
        DBGnTRST        : in     vl_logic;
        DBGTCKEN        : in     vl_logic;
        AccCmplt        : in     vl_logic;
        AccUnderway     : in     vl_logic;
        JTAGWD          : in     vl_logic_vector(31 downto 0);
        DBGTDI          : in     vl_logic;
        DBGTDOa9ejs     : in     vl_logic;
        DBGTDO          : out    vl_logic;
        DBGTAPSM        : in     vl_logic_vector(3 downto 0);
        DBGIR           : in     vl_logic_vector(3 downto 0);
        DBGSCREG        : in     vl_logic_vector(4 downto 0);
        SC15ShiftReg    : out    vl_logic_vector(47 downto 0);
        SC15Enable      : out    vl_logic;
        pulseUpdateDR   : out    vl_logic;
        pulseCaptureDR  : out    vl_logic
    );
end a926ejsCPjtag;
