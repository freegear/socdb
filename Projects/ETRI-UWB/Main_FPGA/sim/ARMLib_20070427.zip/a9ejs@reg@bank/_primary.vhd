library verilog;
use verilog.vl_types.all;
entity a9ejsRegBank is
    generic(
        RGDEL           : integer := 1
    );
    port(
        ADataEx         : out    vl_logic_vector(31 downto 0);
        BDataEx         : out    vl_logic_vector(31 downto 0);
        ADataAGUEx      : out    vl_logic_vector(31 downto 0);
        BDataAGUEx      : out    vl_logic_vector(31 downto 0);
        DDoutInt        : out    vl_logic_vector(31 downto 0);
        CDataDe         : out    vl_logic_vector(31 downto 0);
        RDataWr         : out    vl_logic_vector(31 downto 0);
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        nRESET          : in     vl_logic;
        Mode            : in     vl_logic_vector(3 downto 0);
        TBit            : in     vl_logic;
        FUserWrDIN      : in     vl_logic;
        FUserReadC      : in     vl_logic;
        WriteRegALU     : in     vl_logic_vector(3 downto 0);
        WriteRegDIN     : in     vl_logic_vector(3 downto 0);
        ReadRegA        : in     vl_logic_vector(3 downto 0);
        ReadRegB        : in     vl_logic_vector(3 downto 0);
        ReadRegC        : in     vl_logic_vector(3 downto 0);
        EnWriteALU      : in     vl_logic;
        EnWriteDIN      : in     vl_logic;
        ZeroABus1       : in     vl_logic;
        PC              : in     vl_logic_vector(31 downto 0);
        ResultWB        : in     vl_logic_vector(31 downto 0);
        AMuxCtlDe       : in     vl_logic_vector(7 downto 0);
        AUInvADe        : in     vl_logic;
        ABBusEnDe       : in     vl_logic_vector(1 downto 0);
        ALUOutEx        : in     vl_logic_vector(31 downto 0);
        ResultMe        : in     vl_logic_vector(31 downto 0);
        BMuxCtlDe       : in     vl_logic_vector(7 downto 0);
        ImmSgnExtDe     : in     vl_logic;
        AUInvBDe        : in     vl_logic;
        ImmedDe         : in     vl_logic_vector(25 downto 0);
        CMuxCtlEx       : in     vl_logic;
        ByteReplEx      : in     vl_logic_vector(1 downto 0);
        DRotCtlMe       : in     vl_logic_vector(1 downto 0);
        DSignExtMe      : in     vl_logic_vector(2 downto 0);
        RDATAint        : in     vl_logic_vector(31 downto 0);
        SC1Enable       : in     vl_logic;
        SelCommsRdata   : in     vl_logic;
        SC1DDShftReg    : in     vl_logic_vector(31 downto 0);
        CommsDataToCore : in     vl_logic_vector(31 downto 0);
        DInLtEnMe       : in     vl_logic;
        MulResultMe     : in     vl_logic_vector(31 downto 0);
        SelMulResMe     : in     vl_logic;
        rawJBit         : in     vl_logic;
        JRdData         : in     vl_logic_vector(31 downto 0);
        SelJRdDataMe    : in     vl_logic
    );
end a9ejsRegBank;
