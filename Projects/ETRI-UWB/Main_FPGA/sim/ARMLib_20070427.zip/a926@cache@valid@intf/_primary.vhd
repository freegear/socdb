library verilog;
use verilog.vl_types.all;
entity a926CacheValidIntf is
    port(
        CClk            : in     vl_logic;
        CnReset         : in     vl_logic;
        CMREQ           : in     vl_logic;
        CSEQ            : in     vl_logic;
        LastWord        : in     vl_logic;
        CacheReady      : in     vl_logic;
        sNSeqWrMemReq   : in     vl_logic;
        sNSeqRdMemReq   : in     vl_logic;
        LFVALIDwr0      : in     vl_logic;
        LFVALIDwr1      : in     vl_logic;
        VA              : in     vl_logic_vector(14 downto 7);
        sNSeqVA         : in     vl_logic_vector(14 downto 5);
        sNSeqVAIndex    : in     vl_logic_vector(14 downto 7);
        LfIndex         : in     vl_logic_vector(14 downto 7);
        CSizeBit        : in     vl_logic_vector(5 downto 0);
        EvictionWay     : in     vl_logic_vector(3 downto 0);
        CP15InvalAll    : in     vl_logic;
        CP15VALIDCS     : in     vl_logic;
        sCP15VALIDrd    : in     vl_logic;
        CP15VALIDwr0    : in     vl_logic;
        CP15Way         : in     vl_logic_vector(3 downto 0);
        CBISTEN         : in     vl_logic;
        CBISTVALIDCS    : in     vl_logic;
        CBISTA          : in     vl_logic_vector(7 downto 0);
        CVALIDCS        : out    vl_logic;
        CVALIDA         : out    vl_logic_vector(7 downto 0);
        CVALIDWE        : out    vl_logic;
        CVALIDRD        : in     vl_logic_vector(23 downto 0);
        CVALIDWD        : out    vl_logic_vector(23 downto 0);
        ValidReady      : out    vl_logic;
        ValidWay        : out    vl_logic_vector(3 downto 0);
        sValidWay       : out    vl_logic_vector(3 downto 0);
        RRCount         : out    vl_logic_vector(1 downto 0)
    );
end a926CacheValidIntf;
