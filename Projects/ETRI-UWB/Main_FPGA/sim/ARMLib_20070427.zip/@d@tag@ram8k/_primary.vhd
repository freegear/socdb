library verilog;
use verilog.vl_types.all;
entity DTagRam8k is
    generic(
        word_depth      : integer := 128
    );
    port(
        CLK             : in     vl_logic;
        CE              : in     vl_logic;
        WE              : in     vl_logic;
        A               : in     vl_logic_vector(6 downto 0);
        D               : in     vl_logic_vector(21 downto 0);
        Q               : out    vl_logic_vector(21 downto 0)
    );
end DTagRam8k;
