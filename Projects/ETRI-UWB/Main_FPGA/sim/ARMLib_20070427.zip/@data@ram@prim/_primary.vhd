library verilog;
use verilog.vl_types.all;
entity DataRamPrim is
    generic(
        word_depth      : integer := 512
    );
    port(
        CLK             : in     vl_logic;
        CE              : in     vl_logic;
        WE              : in     vl_logic;
        A               : in     vl_logic_vector(8 downto 0);
        D               : in     vl_logic_vector(7 downto 0);
        Q               : out    vl_logic_vector(7 downto 0)
    );
end DataRamPrim;
