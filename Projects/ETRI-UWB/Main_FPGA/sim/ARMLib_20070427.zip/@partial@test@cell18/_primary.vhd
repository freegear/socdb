library verilog;
use verilog.vl_types.all;
entity PartialTestCell18 is
    port(
        TestOut         : out    vl_logic_vector(17 downto 0);
        CLK             : in     vl_logic;
        SigOut          : in     vl_logic_vector(17 downto 0);
        INTEST          : in     vl_logic;
        EXTEST          : in     vl_logic
    );
end PartialTestCell18;
