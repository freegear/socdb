library verilog;
use verilog.vl_types.all;
entity dummy_buffer is
    port(
        I               : in     vl_logic;
        Z               : out    vl_logic
    );
end dummy_buffer;
