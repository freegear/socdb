library verilog;
use verilog.vl_types.all;
entity a926CacheEWB is
    port(
        CClk            : in     vl_logic;
        CnReset         : in     vl_logic;
        CDATARD0        : in     vl_logic_vector(31 downto 0);
        CDATARD1        : in     vl_logic_vector(31 downto 0);
        CDATARD2        : in     vl_logic_vector(31 downto 0);
        CDATARD3        : in     vl_logic_vector(31 downto 0);
        EWBLower        : in     vl_logic;
        EWBUpper        : in     vl_logic;
        LfWay           : in     vl_logic_vector(3 downto 0);
        CACHEBIUNextWD  : in     vl_logic;
        CACHEBIUWD      : out    vl_logic_vector(31 downto 0);
        PWEWBD          : in     vl_logic_vector(31 downto 0);
        PWEWBByteSel    : in     vl_logic_vector(3 downto 0);
        PWEWBWord       : in     vl_logic_vector(4 downto 2);
        PWEWBWrite      : in     vl_logic;
        EWBBusy         : out    vl_logic
    );
end a926CacheEWB;
