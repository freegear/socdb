library verilog;
use verilog.vl_types.all;
entity a9ejsWRegDecoder is
    generic(
        RGDEL           : integer := 1
    );
    port(
        ARegDEx         : out    vl_logic_vector(10 downto 0);
        IRegEx          : in     vl_logic_vector(27 downto 0);
        CState          : in     vl_logic_vector(7 downto 0);
        TBit            : in     vl_logic;
        BLXImmedEx      : in     vl_logic;
        MulTerm         : in     vl_logic;
        MulTermD        : in     vl_logic;
        CHSGOLAST       : in     vl_logic;
        CHSLAST         : in     vl_logic;
        DMoreEx         : in     vl_logic;
        WBackEx         : in     vl_logic;
        MAFoundEx       : in     vl_logic;
        MAFUser         : in     vl_logic;
        MAaddrEx        : in     vl_logic_vector(3 downto 0);
        MemRegAddrEx    : in     vl_logic_vector(3 downto 0);
        nRWMemEx        : in     vl_logic;
        PldInstEx       : in     vl_logic;
        JBitEx          : in     vl_logic;
        JStWr           : in     vl_logic;
        RAAjaEx         : in     vl_logic_vector(3 downto 0);
        ALURWAjaEx      : in     vl_logic_vector(3 downto 0);
        BIGENDint       : in     vl_logic
    );
end a9ejsWRegDecoder;
