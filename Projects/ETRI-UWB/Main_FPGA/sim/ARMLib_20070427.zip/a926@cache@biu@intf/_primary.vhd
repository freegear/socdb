library verilog;
use verilog.vl_types.all;
entity a926CacheBiuIntf is
    port(
        sDirtyLower     : in     vl_logic;
        sDirtyUpper     : in     vl_logic;
        CACHEBIUReq     : out    vl_logic;
        CACHEBIUA       : out    vl_logic_vector(31 downto 0);
        CACHEBIUBurst   : out    vl_logic_vector(2 downto 0);
        CACHEBIUnRW     : out    vl_logic;
        CACHEBIUWrap    : out    vl_logic;
        CACHEBIUPriv    : out    vl_logic;
        FBBIUReq        : in     vl_logic;
        EWBBIUReq       : in     vl_logic;
        BIUEWBSel       : in     vl_logic;
        sPA             : in     vl_logic_vector(31 downto 10);
        sNSeqVA         : in     vl_logic_vector(9 downto 5);
        sVA             : in     vl_logic_vector(4 downto 2);
        sTAGRD          : in     vl_logic_vector(21 downto 0);
        LfVA            : in     vl_logic_vector(9 downto 5);
        sPriv           : in     vl_logic
    );
end a926CacheBiuIntf;
