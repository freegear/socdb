library verilog;
use verilog.vl_types.all;
entity a9ejsShALUTDec is
    generic(
        RGDEL           : integer := 1
    );
    port(
        ThuUpdPSR       : out    vl_logic;
        ThuALUop        : out    vl_logic_vector(14 downto 0);
        ThuSHop         : out    vl_logic_vector(8 downto 0);
        ThuABBusEn      : out    vl_logic_vector(1 downto 0);
        ThuClass        : out    vl_logic_vector(4 downto 0);
        ThuUndef        : out    vl_logic;
        ThuMAInstr      : out    vl_logic;
        BaseNotInRegList: out    vl_logic;
        BLXImmedT       : out    vl_logic;
        BreakT          : out    vl_logic;
        IDthumbDe       : in     vl_logic_vector(15 downto 0);
        PBitLDMSTMDe    : in     vl_logic;
        UBitLDMSTMDe    : in     vl_logic
    );
end a9ejsShALUTDec;
