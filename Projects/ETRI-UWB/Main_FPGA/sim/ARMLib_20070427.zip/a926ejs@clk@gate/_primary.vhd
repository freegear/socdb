library verilog;
use verilog.vl_types.all;
entity a926ejsClkGate is
    port(
        CLK             : in     vl_logic;
        RESETn          : in     vl_logic;
        ClkEnable       : in     vl_logic;
        disableg        : in     vl_logic;
        GatedClk        : out    vl_logic
    );
end a926ejsClkGate;
