library verilog;
use verilog.vl_types.all;
entity DW01_inc is
    generic(
        size            : integer := 32
    );
    port(
        A               : in     vl_logic_vector;
        SUM             : out    vl_logic_vector
    );
end DW01_inc;
