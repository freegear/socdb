library verilog;
use verilog.vl_types.all;
entity a9ejsDbgCommsdp is
    generic(
        RGDEL           : integer := 1
    );
    port(
        CommsDataToCore : out    vl_logic_vector(31 downto 0);
        CommsDataToSC2  : out    vl_logic_vector(31 downto 0);
        CPinstDe        : out    vl_logic_vector(4 downto 0);
        CLK             : in     vl_logic;
        TCLK            : in     vl_logic;
        nTRST           : in     vl_logic;
        CCtlEnMe        : in     vl_logic;
        CDataEnMe       : in     vl_logic;
        CommsCtl        : in     vl_logic_vector(1 downto 0);
        CommsCtlT       : in     vl_logic_vector(1 downto 0);
        CommsWrCtl      : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        DDoutInt        : in     vl_logic_vector(31 downto 0);
        ICERegWrStrobe  : in     vl_logic;
        IDarmDe         : in     vl_logic_vector(27 downto 0);
        SC2DataOut      : in     vl_logic_vector(31 downto 0);
        SC2SelCommsData : in     vl_logic;
        StatFlag0       : in     vl_logic;
        StatFlagEnMe    : in     vl_logic;
        TCkEn           : in     vl_logic
    );
end a9ejsDbgCommsdp;
