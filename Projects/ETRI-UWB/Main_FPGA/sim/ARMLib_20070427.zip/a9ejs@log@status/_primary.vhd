library verilog;
use verilog.vl_types.all;
entity a9ejsLogStatus is
    generic(
        RGDEL           : integer := 1;
        eis_echo_to_stdout: integer := 0;
        eis_dont_generate: integer := 0;
        eis_filename    : string  := "log.eis";
        eis_prefix      : string  := "EIS         "
    );
    port(
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        CHS             : in     vl_logic_vector(1 downto 0);
        nRESET          : in     vl_logic;
        TBit            : in     vl_logic;
        CondCodesDe     : in     vl_logic_vector(3 downto 0);
        IRegDe          : in     vl_logic_vector(27 downto 0);
        PC              : in     vl_logic_vector(31 downto 0);
        CState          : in     vl_logic_vector(7 downto 0);
        FirstCycExe     : in     vl_logic;
        CCFailEx        : in     vl_logic;
        EarlyIssueExeEx : in     vl_logic;
        INSTREXECint    : in     vl_logic;
        IssueMemMe      : in     vl_logic;
        BIGENDint       : in     vl_logic;
        ICEDbgAck       : in     vl_logic;
        ReEnterDbgDe    : in     vl_logic;
        DnMREQint       : in     vl_logic;
        DKILL           : in     vl_logic;
        DSEQint         : in     vl_logic;
        DnRWint         : in     vl_logic;
        DMASint         : in     vl_logic_vector(1 downto 0);
        DAint           : in     vl_logic_vector(31 downto 0);
        DDinInt         : in     vl_logic_vector(31 downto 0);
        DDoutInt        : in     vl_logic_vector(31 downto 0);
        RDATAint        : in     vl_logic_vector(31 downto 0);
        JBit            : in     vl_logic;
        StallDe         : in     vl_logic;
        ReEnterDebug    : in     vl_logic;
        Opcode          : in     vl_logic_vector(7 downto 0);
        NxtStateD       : in     vl_logic_vector(8 downto 0);
        Operand1        : in     vl_logic_vector(7 downto 0);
        Op1Valid        : in     vl_logic;
        Operand2        : in     vl_logic_vector(7 downto 0);
        Op2Valid        : in     vl_logic;
        AllValid        : in     vl_logic;
        CycleZeroDe     : in     vl_logic;
        en_stk          : in     vl_logic;
        en_lv0          : in     vl_logic
    );
end a9ejsLogStatus;
