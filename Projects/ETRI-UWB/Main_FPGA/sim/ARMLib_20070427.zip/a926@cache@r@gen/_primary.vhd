library verilog;
use verilog.vl_types.all;
entity a926CacheRGen is
    port(
        CClk            : in     vl_logic;
        CnReset         : in     vl_logic;
        RRBIT           : in     vl_logic;
        CnWayAlloc      : in     vl_logic_vector(3 downto 0);
        RRCount         : in     vl_logic_vector(1 downto 0);
        CNoRRgen        : in     vl_logic;
        LFBlock         : in     vl_logic;
        SmpLf           : in     vl_logic;
        CP15WayNS       : in     vl_logic_vector(3 downto 0);
        CP15Update      : in     vl_logic;
        EvictionWay     : out    vl_logic_vector(3 downto 0);
        sEvictionWay    : out    vl_logic_vector(3 downto 0);
        LfWay           : out    vl_logic_vector(3 downto 0);
        LfWayFB         : out    vl_logic_vector(3 downto 0);
        LfWayTDE        : out    vl_logic_vector(3 downto 0)
    );
end a926CacheRGen;
