library verilog;
use verilog.vl_types.all;
entity a9ejsJStack is
    generic(
        RGDEL           : integer := 1
    );
    port(
        StackReady      : out    vl_logic;
        StackLnS        : out    vl_logic;
        StackCReg       : out    vl_logic_vector(3 downto 0);
        TOSm3           : out    vl_logic_vector(1 downto 0);
        TOSm2           : out    vl_logic_vector(1 downto 0);
        TOSm1           : out    vl_logic_vector(1 downto 0);
        TOS             : out    vl_logic_vector(1 downto 0);
        TOS1            : out    vl_logic_vector(1 downto 0);
        TOS2            : out    vl_logic_vector(1 downto 0);
        JStackStFe      : out    vl_logic_vector(5 downto 0);
        CLK             : in     vl_logic;
        nRESET          : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        IJBITD          : in     vl_logic;
        StackFlush      : in     vl_logic;
        StackReqFull    : in     vl_logic_vector(2 downto 0);
        StackReqEmpty   : in     vl_logic_vector(2 downto 0);
        StackAction     : in     vl_logic_vector(3 downto 0);
        ActiveFe        : in     vl_logic;
        ISEQFe          : in     vl_logic;
        JStateRd        : in     vl_logic_vector(5 downto 0);
        JStClr          : in     vl_logic;
        StallDe         : in     vl_logic;
        JState          : in     vl_logic_vector(4 downto 0);
        AllValid        : in     vl_logic
    );
end a9ejsJStack;
