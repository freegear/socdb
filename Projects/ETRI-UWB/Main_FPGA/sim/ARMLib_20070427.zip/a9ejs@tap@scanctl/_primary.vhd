library verilog;
use verilog.vl_types.all;
entity a9ejsTapScanctl is
    generic(
        RGDEL           : integer := 1
    );
    port(
        CaptureDR       : out    vl_logic;
        ClkDbgAckD      : out    vl_logic;
        DbgClkEn        : out    vl_logic;
        DbgClkEnSel     : out    vl_logic;
        DbgForceIntCyc  : out    vl_logic;
        DBGnTDOENint    : out    vl_logic;
        DBGSDINint      : out    vl_logic;
        EiceDisInit     : out    vl_logic;
        ICERegRdStrobe  : out    vl_logic;
        ICERegWrStrobe  : out    vl_logic;
        InstrReg        : out    vl_logic_vector(3 downto 0);
        RunTestIdle     : out    vl_logic;
        SC1Enable       : out    vl_logic;
        SC2Addr         : out    vl_logic_vector(4 downto 0);
        SC2Enable       : out    vl_logic;
        SC2Write        : out    vl_logic;
        SCSelReg        : out    vl_logic_vector(4 downto 0);
        SDInDp          : out    vl_logic;
        ShiftDR         : out    vl_logic;
        TapCstate       : out    vl_logic_vector(3 downto 0);
        TDO             : out    vl_logic;
        TestLogicReset  : out    vl_logic;
        UpdateDR        : out    vl_logic;
        FreeCLK         : in     vl_logic;
        TCLK            : in     vl_logic;
        nRESET          : in     vl_logic;
        nTRST           : in     vl_logic;
        ClkDbgAck       : in     vl_logic;
        ClkEnData       : in     vl_logic;
        CommsCtlT1      : in     vl_logic;
        DBGSDOUTint     : in     vl_logic;
        SC0ShftRegSo    : in     vl_logic;
        SC1ShftRegSo    : in     vl_logic;
        SC2ShftRegSo    : in     vl_logic;
        TAPIDint        : in     vl_logic_vector(31 downto 0);
        TCkEn           : in     vl_logic;
        TCkEnData       : in     vl_logic;
        TDI             : in     vl_logic;
        TMS             : in     vl_logic
    );
end a9ejsTapScanctl;
