library verilog;
use verilog.vl_types.all;
entity a9ejsJArrayBndChk is
    generic(
        RGDEL           : integer := 1
    );
    port(
        ArrayBndEx      : out    vl_logic;
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        BDataAGUEx      : in     vl_logic_vector(31 downto 0);
        JBit            : in     vl_logic;
        FirstCycExe     : in     vl_logic;
        ArrayBndEnEx    : in     vl_logic;
        ArrayBndBDataEnEx: in     vl_logic;
        RDataWr         : in     vl_logic_vector(31 downto 0);
        BSH             : in     vl_logic_vector(4 downto 0)
    );
end a9ejsJArrayBndChk;
