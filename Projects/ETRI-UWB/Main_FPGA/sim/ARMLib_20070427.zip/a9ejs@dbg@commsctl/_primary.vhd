library verilog;
use verilog.vl_types.all;
entity a9ejsDbgCommsctl is
    generic(
        RGDEL           : integer := 1
    );
    port(
        CHSice          : out    vl_logic;
        DBGCOMMRXint    : out    vl_logic;
        DBGCOMMTXint    : out    vl_logic;
        CommsWrCtl      : out    vl_logic;
        CommsCtlT       : out    vl_logic_vector(1 downto 0);
        CommsCtl        : out    vl_logic_vector(1 downto 0);
        CCtlEnMe        : out    vl_logic;
        CDataEnMe       : out    vl_logic;
        StatFlagEnMe    : out    vl_logic;
        SelCommsRdata   : out    vl_logic;
        StatFlag0       : out    vl_logic;
        CLK             : in     vl_logic;
        TCLK            : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        SC2SelCommsCtl  : in     vl_logic;
        SC2SelCommsData : in     vl_logic;
        DBGENintD       : in     vl_logic;
        DBGENintDCLK    : in     vl_logic;
        ICERegRdStrobe  : in     vl_logic;
        ICERegWrStrobe  : in     vl_logic;
        PADV            : in     vl_logic;
        LATECANCELint   : in     vl_logic;
        nTRST           : in     vl_logic;
        PASSint         : in     vl_logic;
        TCkEn           : in     vl_logic;
        TestLogicReset  : in     vl_logic;
        CPinstDe        : in     vl_logic_vector(4 downto 0);
        DDLatch0        : in     vl_logic;
        SetDbgAbortFlag : in     vl_logic
    );
end a9ejsDbgCommsctl;
