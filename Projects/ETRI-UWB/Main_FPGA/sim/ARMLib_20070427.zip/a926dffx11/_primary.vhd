library verilog;
use verilog.vl_types.all;
entity a926dffx11 is
    generic(
        Comb1           : integer := 1;
        Reg1            : integer := 1
    );
    port(
        q               : out    vl_logic_vector(10 downto 0);
        d               : in     vl_logic_vector(10 downto 0);
        clk             : in     vl_logic
    );
end a926dffx11;
