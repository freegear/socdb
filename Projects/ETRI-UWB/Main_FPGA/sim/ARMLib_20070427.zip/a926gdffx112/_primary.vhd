library verilog;
use verilog.vl_types.all;
entity a926gdffx112 is
    generic(
        Comb1           : integer := 1;
        Reg1            : integer := 1
    );
    port(
        q               : out    vl_logic_vector(111 downto 0);
        d               : in     vl_logic_vector(111 downto 0);
        clk             : in     vl_logic;
        e               : in     vl_logic
    );
end a926gdffx112;
