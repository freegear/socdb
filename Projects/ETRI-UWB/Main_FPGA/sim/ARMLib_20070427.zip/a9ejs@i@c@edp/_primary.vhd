library verilog;
use verilog.vl_types.all;
entity a9ejsICEdp is
    generic(
        RGDEL           : integer := 1
    );
    port(
        AMatch0         : out    vl_logic;
        AMatch1         : out    vl_logic;
        CommsDataToCore : out    vl_logic_vector(31 downto 0);
        CPinstDe        : out    vl_logic_vector(4 downto 0);
        DMatchL0        : out    vl_logic;
        DMatchL1        : out    vl_logic;
        DMatchU0        : out    vl_logic;
        DMatchU1        : out    vl_logic;
        IA1BitFe        : out    vl_logic;
        SC2CtlDataOut   : out    vl_logic_vector(8 downto 0);
        SC2DataIn       : out    vl_logic_vector(31 downto 0);
        CLK             : in     vl_logic;
        TCLK            : in     vl_logic;
        nRESET          : in     vl_logic;
        nTRST           : in     vl_logic;
        BIGENDint       : in     vl_logic;
        CCtlEnMe        : in     vl_logic;
        CDataEnMe       : in     vl_logic;
        CommsCtl        : in     vl_logic_vector(1 downto 0);
        CommsCtlT       : in     vl_logic_vector(1 downto 0);
        CommsWrCtl      : in     vl_logic;
        CompEnL0        : in     vl_logic;
        CompEnL1        : in     vl_logic;
        CompEnU0        : in     vl_logic;
        CompEnU1        : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        DAint           : in     vl_logic_vector(31 downto 0);
        DDoutInt        : in     vl_logic_vector(31 downto 0);
        DnMREQint       : in     vl_logic;
        DnRWint         : in     vl_logic;
        EiceDisable     : in     vl_logic;
        IAint           : in     vl_logic_vector(31 downto 1);
        ICERegWrStrobe  : in     vl_logic;
        IDarmDe         : in     vl_logic_vector(27 downto 0);
        InD0            : in     vl_logic;
        InD1            : in     vl_logic;
        RDATAint        : in     vl_logic_vector(31 downto 0);
        SC2Addr         : in     vl_logic_vector(4 downto 0);
        SC2CtlDataIn    : in     vl_logic_vector(9 downto 0);
        SC2DataOut      : in     vl_logic_vector(31 downto 0);
        StatFlag0       : in     vl_logic;
        StatFlagEnMe    : in     vl_logic;
        StoredInstr     : in     vl_logic_vector(31 downto 0);
        TCkEn           : in     vl_logic;
        IJBIT           : in     vl_logic;
        JavaPCFe        : in     vl_logic_vector(31 downto 0)
    );
end a9ejsICEdp;
