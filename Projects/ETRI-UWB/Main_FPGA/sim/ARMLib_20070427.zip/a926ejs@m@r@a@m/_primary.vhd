library verilog;
use verilog.vl_types.all;
entity a926ejsMRAM is
    port(
        MMUxRD          : out    vl_logic_vector(111 downto 0);
        MMUxADDR        : in     vl_logic_vector(4 downto 0);
        MMUxWD          : in     vl_logic_vector(111 downto 0);
        MMUxCS          : in     vl_logic;
        MMUxWE          : in     vl_logic_vector(3 downto 0);
        MMUClk          : in     vl_logic
    );
end a926ejsMRAM;
