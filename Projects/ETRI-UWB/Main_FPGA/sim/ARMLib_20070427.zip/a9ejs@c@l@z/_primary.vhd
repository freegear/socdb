library verilog;
use verilog.vl_types.all;
entity a9ejsCLZ is
    generic(
        RGDEL           : integer := 1
    );
    port(
        BDataEx         : in     vl_logic_vector(31 downto 0);
        CLZOutEx        : out    vl_logic_vector(5 downto 0)
    );
end a9ejsCLZ;
