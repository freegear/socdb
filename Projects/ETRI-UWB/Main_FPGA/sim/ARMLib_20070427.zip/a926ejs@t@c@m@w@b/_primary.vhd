library verilog;
use verilog.vl_types.all;
entity a926ejsTCMWB is
    port(
        RWD             : out    vl_logic_vector(31 downto 0);
        WBEquals        : out    vl_logic_vector(3 downto 0);
        WBFull          : out    vl_logic;
        WBValid         : out    vl_logic;
        WBA             : out    vl_logic_vector(17 downto 0);
        WBSEQ           : out    vl_logic;
        WBD             : out    vl_logic_vector(31 downto 0);
        WBWBL           : out    vl_logic_vector(3 downto 0);
        WBBusy          : out    vl_logic;
        TCMClk          : in     vl_logic;
        TCMnReset       : in     vl_logic;
        BIGEND          : in     vl_logic;
        TCMWRREQ        : in     vl_logic;
        TCMCancel       : in     vl_logic;
        TCMReady        : in     vl_logic;
        TCMNoReq        : in     vl_logic;
        TCMAS           : in     vl_logic_vector(1 downto 0);
        TCMWD           : in     vl_logic_vector(31 downto 0);
        WaitState       : in     vl_logic;
        WBEn            : in     vl_logic;
        TCMAInt         : in     vl_logic_vector(19 downto 0);
        TCMSEQ          : in     vl_logic;
        ReadPipe        : in     vl_logic
    );
end a926ejsTCMWB;
