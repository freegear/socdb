library verilog;
use verilog.vl_types.all;
entity DirtyRam8k is
    generic(
        word_depth      : integer := 64
    );
    port(
        CLK             : in     vl_logic;
        RSTN            : in     vl_logic;
        CEN             : in     vl_logic;
        WEN             : in     vl_logic_vector(7 downto 0);
        A               : in     vl_logic_vector(5 downto 0);
        D               : in     vl_logic_vector(7 downto 0);
        Q               : out    vl_logic_vector(7 downto 0)
    );
end DirtyRam8k;
