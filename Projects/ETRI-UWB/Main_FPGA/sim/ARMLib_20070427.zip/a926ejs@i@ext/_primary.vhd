library verilog;
use verilog.vl_types.all;
entity a926ejsIExt is
    port(
        IEXTIdle        : out    vl_logic;
        IEXTBlocked     : out    vl_logic;
        IEXTReady       : out    vl_logic;
        IEXTNoFinish    : out    vl_logic;
        IEXTRD          : out    vl_logic_vector(31 downto 0);
        IEXTError       : out    vl_logic;
        IEXTBIUReq      : out    vl_logic;
        IEXTBIUBurst    : out    vl_logic_vector(2 downto 0);
        IEXTBIUA        : out    vl_logic_vector(31 downto 0);
        IEXTBIUPriv     : out    vl_logic;
        IEXTBIUCacheable: out    vl_logic;
        IEXTClk         : in     vl_logic;
        IEXTnReset      : in     vl_logic;
        IEXTMREQ        : in     vl_logic;
        IEXTSEQ         : in     vl_logic;
        IEXTCancel      : in     vl_logic;
        IPrivileged     : in     vl_logic;
        IPA             : in     vl_logic_vector(31 downto 0);
        IEXTEnPrefetch  : in     vl_logic;
        IEXTBIUReady    : in     vl_logic;
        IEXTBIUAck      : in     vl_logic;
        IEXTBIUErr      : in     vl_logic;
        IBIURD          : in     vl_logic_vector(31 downto 0);
        IL2Cacheable    : in     vl_logic
    );
end a926ejsIExt;
