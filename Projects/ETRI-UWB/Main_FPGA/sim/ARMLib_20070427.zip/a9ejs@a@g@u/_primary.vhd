library verilog;
use verilog.vl_types.all;
entity a9ejsAGU is
    generic(
        RGDEL           : integer := 1
    );
    port(
        DAint           : out    vl_logic_vector(31 downto 0);
        DAAlignEx       : out    vl_logic;
        DA1BitMe        : out    vl_logic;
        DA0BitMe        : out    vl_logic;
        ETMIAFE         : out    vl_logic_vector(31 downto 0);
        IAint           : out    vl_logic_vector(31 downto 1);
        IA1BitFe        : out    vl_logic;
        PC              : out    vl_logic_vector(31 downto 0);
        JIAlsbs         : out    vl_logic_vector(2 downto 0);
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        nRESET          : in     vl_logic;
        PCIncUpdEx      : in     vl_logic;
        PCUpdateEx      : in     vl_logic;
        VectSelEx       : in     vl_logic_vector(2 downto 0);
        ITBITint        : in     vl_logic;
        BIGENDint       : in     vl_logic;
        VBITint         : in     vl_logic;
        JavaPCDe        : in     vl_logic_vector(31 downto 0);
        JavaPCFe        : in     vl_logic_vector(31 downto 0);
        JBitFe          : in     vl_logic;
        CycleZeroDe     : in     vl_logic;
        rawJBit         : in     vl_logic;
        EnteringDbg     : in     vl_logic;
        EnteredDebug    : in     vl_logic;
        DAEnEx          : in     vl_logic;
        IAMuxCtl        : in     vl_logic_vector(1 downto 0);
        DAMuxCtlEx      : in     vl_logic_vector(1 downto 0);
        ADataAGUEx      : in     vl_logic_vector(31 downto 0);
        BDataAGUEx      : in     vl_logic_vector(31 downto 0);
        RDataWr         : in     vl_logic_vector(31 downto 0);
        CarryInAGUEx    : in     vl_logic;
        Wpted           : in     vl_logic;
        CFGTHUMB32D     : in     vl_logic;
        rawIJBIT        : in     vl_logic;
        PCSub4          : in     vl_logic;
        StopPCAdv       : in     vl_logic
    );
end a9ejsAGU;
