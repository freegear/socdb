library verilog;
use verilog.vl_types.all;
entity DW01_add is
    generic(
        size            : integer := 32
    );
    port(
        A               : in     vl_logic_vector;
        B               : in     vl_logic_vector;
        CI              : in     vl_logic;
        CO              : out    vl_logic;
        SUM             : out    vl_logic_vector
    );
end DW01_add;
