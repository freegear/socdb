library verilog;
use verilog.vl_types.all;
entity a926ejsRAM is
    generic(
        DW              : integer := 30
    );
    port(
        DATAOUT         : out    vl_logic_vector;
        CLK             : in     vl_logic;
        DATAIN          : in     vl_logic_vector;
        ADDR            : in     vl_logic_vector(4 downto 0);
        WE              : in     vl_logic;
        CS              : in     vl_logic;
        OE              : in     vl_logic
    );
end a926ejsRAM;
