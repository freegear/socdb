library verilog;
use verilog.vl_types.all;
entity a9ejsREG is
    generic(
        RGDEL           : integer := 1
    );
    port(
        EnReadA         : out    vl_logic;
        EnReadB         : out    vl_logic;
        ZeroABus1       : out    vl_logic;
        ReadRegA        : out    vl_logic_vector(3 downto 0);
        ReadRegB        : out    vl_logic_vector(3 downto 0);
        AfromExALU      : out    vl_logic;
        AfromExDIN      : out    vl_logic;
        AfromMeALU      : out    vl_logic;
        AfromMeDIN      : out    vl_logic;
        BfromExALU      : out    vl_logic;
        BfromExDIN      : out    vl_logic;
        BfromMeALU      : out    vl_logic;
        BfromMeDIN      : out    vl_logic;
        JBitDe          : in     vl_logic;
        TBitDe          : in     vl_logic;
        CycleZeroDe     : in     vl_logic;
        FirstCycExe     : in     vl_logic;
        CState          : in     vl_logic_vector(7 downto 0);
        IDarmDe         : in     vl_logic_vector(27 downto 0);
        IDthumbDe       : in     vl_logic_vector(15 downto 0);
        IRegEx          : in     vl_logic_vector(27 downto 0);
        BLXImmedEx      : in     vl_logic;
        DisableBXJ      : in     vl_logic;
        AENjaDe         : in     vl_logic;
        BENjaDe         : in     vl_logic;
        RAAjaDe         : in     vl_logic_vector(3 downto 0);
        RBAjaDe         : in     vl_logic_vector(3 downto 0);
        WriteRegALUEx   : in     vl_logic_vector(3 downto 0);
        EnWriteALUEx    : in     vl_logic;
        WriteRegDINEx   : in     vl_logic_vector(3 downto 0);
        EnWriteDINEx    : in     vl_logic;
        WriteRegALUMe   : in     vl_logic_vector(3 downto 0);
        EnWriteALUMe    : in     vl_logic;
        WriteRegDINMe   : in     vl_logic_vector(3 downto 0);
        EnWriteDINMe    : in     vl_logic;
        RAAjaEx         : in     vl_logic_vector(3 downto 0)
    );
end a9ejsREG;
