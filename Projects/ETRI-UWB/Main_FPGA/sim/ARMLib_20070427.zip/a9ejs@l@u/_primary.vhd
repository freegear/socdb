library verilog;
use verilog.vl_types.all;
entity a9ejsLU is
    generic(
        RGDEL           : integer := 1
    );
    port(
        LUOut           : out    vl_logic_vector(31 downto 0);
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        nRESET          : in     vl_logic;
        LUOpEx          : in     vl_logic_vector(3 downto 0);
        ADataEx         : in     vl_logic_vector(31 downto 0);
        ShiftOut        : in     vl_logic_vector(31 downto 0);
        PSRRdEx         : in     vl_logic_vector(12 downto 0);
        PSRReadDe       : in     vl_logic;
        LUEnDe          : in     vl_logic;
        JStWrEn         : in     vl_logic;
        JStClr          : in     vl_logic;
        JState          : in     vl_logic_vector(5 downto 0)
    );
end a9ejsLU;
