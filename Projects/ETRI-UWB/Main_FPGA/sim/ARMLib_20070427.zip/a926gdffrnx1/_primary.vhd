library verilog;
use verilog.vl_types.all;
entity a926gdffrnx1 is
    generic(
        Comb1           : integer := 1;
        Reg1            : integer := 1
    );
    port(
        q               : out    vl_logic;
        d               : in     vl_logic;
        clk             : in     vl_logic;
        e               : in     vl_logic;
        r               : in     vl_logic
    );
end a926gdffrnx1;
