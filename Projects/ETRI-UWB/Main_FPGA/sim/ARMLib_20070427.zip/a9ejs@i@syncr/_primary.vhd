library verilog;
use verilog.vl_types.all;
entity a9ejsISyncr is
    generic(
        RGDEL           : integer := 1
    );
    port(
        PendInt         : out    vl_logic;
        GatedInt        : out    vl_logic;
        GatedFIQ        : out    vl_logic;
        GatedIRQ        : out    vl_logic;
        DbgRqi          : out    vl_logic;
        FIQDISint       : out    vl_logic;
        IRQDISint       : out    vl_logic;
        CLK             : in     vl_logic;
        FreeCLK         : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        nRESET          : in     vl_logic;
        nIRQint         : in     vl_logic;
        nFIQint         : in     vl_logic;
        RawCPSRIBit     : in     vl_logic;
        RawCPSRFBit     : in     vl_logic;
        CPSRIBit        : in     vl_logic;
        CPSRFBit        : in     vl_logic;
        IfEn            : in     vl_logic;
        DebugRq         : in     vl_logic
    );
end a9ejsISyncr;
