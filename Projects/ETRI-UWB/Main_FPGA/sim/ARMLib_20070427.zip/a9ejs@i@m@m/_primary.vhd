library verilog;
use verilog.vl_types.all;
entity a9ejsIMM is
    generic(
        RGDEL           : integer := 1
    );
    port(
        ImmedDe         : out    vl_logic_vector(25 downto 0);
        ImmSgnExtDe     : out    vl_logic;
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        nRESET          : in     vl_logic;
        TBitDe          : in     vl_logic;
        CycleZeroDe     : in     vl_logic;
        IDarmDe         : in     vl_logic_vector(31 downto 0);
        IDthumbDe       : in     vl_logic_vector(15 downto 0);
        FImmDe          : in     vl_logic;
        IRegDe          : in     vl_logic_vector(24 downto 0);
        MACount         : in     vl_logic_vector(3 downto 0);
        FImmBitsDe      : in     vl_logic_vector(4 downto 0);
        JImmValDe       : in     vl_logic_vector(24 downto 0);
        JBitDe          : in     vl_logic;
        UseExtendedSDe  : in     vl_logic;
        NullPtrEx       : in     vl_logic;
        ArrayBndEx      : in     vl_logic;
        JVFPExpEx       : in     vl_logic
    );
end a9ejsIMM;
