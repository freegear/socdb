library verilog;
use verilog.vl_types.all;
entity a926ejsClkBlk is
    port(
        CLK             : in     vl_logic;
        HRESETn         : in     vl_logic;
        DisableBlkClkGate: in     vl_logic;
        WFIWakeUp       : in     vl_logic;
        STANDBYWFI      : in     vl_logic;
        ICClkEn         : in     vl_logic;
        DCClkEn         : in     vl_logic;
        ITCMClkEn       : in     vl_logic;
        DTCMClkEn       : in     vl_logic;
        IEXTClkEn       : in     vl_logic;
        DEXTClkEn       : in     vl_logic;
        CP15PipeClkEn   : in     vl_logic;
        CP15DbgClkEn    : in     vl_logic;
        ARM9ClkEn       : in     vl_logic;
        MMUClkEn        : in     vl_logic;
        ETMEN           : in     vl_logic;
        TESTMODE        : in     vl_logic;
        GCLK            : out    vl_logic;
        ARM9Clk         : out    vl_logic;
        IEXTClk         : out    vl_logic;
        DEXTClk         : out    vl_logic;
        ICClk           : out    vl_logic;
        DCClk           : out    vl_logic;
        DTCMClk         : out    vl_logic;
        ITCMClk         : out    vl_logic;
        CP15PipeClk     : out    vl_logic;
        CP15DebugClk    : out    vl_logic;
        MMUClk          : out    vl_logic;
        ETMIFClk        : out    vl_logic;
        pETMEN          : out    vl_logic
    );
end a926ejsClkBlk;
