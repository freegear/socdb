library verilog;
use verilog.vl_types.all;
entity a9ejsMulDP is
    generic(
        RGDEL           : integer := 1
    );
    port(
        IER16LMe        : out    vl_logic;
        MulSFlagMe      : out    vl_logic;
        MulResultMe     : out    vl_logic_vector(31 downto 0);
        MulCLK          : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        MulClockEnable  : in     vl_logic;
        nRESET          : in     vl_logic;
        InLatCtlDe      : in     vl_logic;
        HoldIERDe       : in     vl_logic;
        ICANDCtlDe      : in     vl_logic_vector(1 downto 0);
        IERCtlDe        : in     vl_logic_vector(1 downto 0);
        Sum2aCtlEx      : in     vl_logic;
        Sum2bCtlEx      : in     vl_logic;
        AccCtlEx        : in     vl_logic_vector(1 downto 0);
        Sum4LCtlMe      : in     vl_logic;
        MulResCtlMe     : in     vl_logic_vector(1 downto 0);
        ADataEx         : in     vl_logic_vector(31 downto 0);
        BDataEx         : in     vl_logic_vector(31 downto 0);
        CDataDe         : in     vl_logic_vector(31 downto 0)
    );
end a9ejsMulDP;
