library verilog;
use verilog.vl_types.all;
entity ValidRam8k is
    generic(
        word_depth      : integer := 16
    );
    port(
        CLK             : in     vl_logic;
        CE              : in     vl_logic;
        WE              : in     vl_logic;
        A               : in     vl_logic_vector(3 downto 0);
        D               : in     vl_logic_vector(23 downto 0);
        Q               : out    vl_logic_vector(23 downto 0)
    );
end ValidRam8k;
