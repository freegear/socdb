library verilog;
use verilog.vl_types.all;
entity DW01_bsh is
    generic(
        size            : integer := 32;
        shift           : integer := 5
    );
    port(
        A               : in     vl_logic_vector;
        SH              : in     vl_logic_vector;
        B               : out    vl_logic_vector
    );
end DW01_bsh;
