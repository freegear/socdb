library verilog;
use verilog.vl_types.all;
entity a926CacheRamGasket is
    port(
        CACHESIZE       : in     vl_logic_vector(3 downto 0);
        CTAGAIn         : in     vl_logic_vector(10 downto 0);
        CDATAINDEXIn    : in     vl_logic_vector(9 downto 0);
        CDATAWORDB0In   : in     vl_logic_vector(2 downto 0);
        CDATAWORDB1In   : in     vl_logic_vector(2 downto 0);
        CDATAWORDB2In   : in     vl_logic_vector(2 downto 0);
        CDATAWORDB3In   : in     vl_logic_vector(2 downto 0);
        CVALIDAIn       : in     vl_logic_vector(7 downto 0);
        CDIRTYAIn       : in     vl_logic_vector(9 downto 0);
        CTAGAOut        : out    vl_logic_vector(10 downto 0);
        CDATAA0Out      : out    vl_logic_vector(12 downto 0);
        CDATAA1Out      : out    vl_logic_vector(12 downto 0);
        CDATAA2Out      : out    vl_logic_vector(12 downto 0);
        CDATAA3Out      : out    vl_logic_vector(12 downto 0);
        CVALIDAOut      : out    vl_logic_vector(7 downto 0);
        CDIRTYAOut      : out    vl_logic_vector(9 downto 0)
    );
end a926CacheRamGasket;
