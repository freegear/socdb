library verilog;
use verilog.vl_types.all;
entity a9ejsShALUSeq is
    generic(
        RGDEL           : integer := 1
    );
    port(
        MultiUpdPSR     : out    vl_logic;
        MultiALUop      : out    vl_logic_vector(14 downto 0);
        MultiSHop       : out    vl_logic_vector(8 downto 0);
        MultiABBusEn    : out    vl_logic_vector(1 downto 0);
        JStWrEn         : out    vl_logic;
        JStClr          : out    vl_logic;
        CState          : in     vl_logic_vector(7 downto 0);
        ForceSubnAdd    : in     vl_logic;
        IRegEx          : in     vl_logic_vector(27 downto 0);
        MulAdd1De       : in     vl_logic;
        MulAdd2De       : in     vl_logic;
        TBitDe          : in     vl_logic;
        UBitLDMSTMEx    : in     vl_logic;
        WBitLDMSTMEx    : in     vl_logic;
        BLXImmedEx      : in     vl_logic;
        JBit            : in     vl_logic;
        rawIJBIT        : in     vl_logic;
        rawJBit         : in     vl_logic;
        DisableBXJ      : in     vl_logic;
        RegShOpjaEx     : in     vl_logic_vector(1 downto 0)
    );
end a9ejsShALUSeq;
