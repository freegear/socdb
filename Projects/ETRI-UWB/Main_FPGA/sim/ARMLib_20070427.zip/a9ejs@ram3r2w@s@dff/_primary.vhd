library verilog;
use verilog.vl_types.all;
entity a9ejsRam3r2wSDff is
    generic(
        RGDEL           : integer := 1
    );
    port(
        Rd0Data         : out    vl_logic_vector(31 downto 0);
        Rd1Data         : out    vl_logic_vector(31 downto 0);
        Rd2Data         : out    vl_logic_vector(31 downto 0);
        CLK             : in     vl_logic;
        Mode            : in     vl_logic_vector(3 downto 0);
        NewPC           : in     vl_logic_vector(31 downto 0);
        Rd0Addr         : in     vl_logic_vector(3 downto 0);
        Rd1Addr         : in     vl_logic_vector(3 downto 0);
        Rd2Addr         : in     vl_logic_vector(3 downto 0);
        Rd2FUser        : in     vl_logic;
        Wr0             : in     vl_logic;
        Wr0Addr         : in     vl_logic_vector(4 downto 0);
        Wr0Data         : in     vl_logic_vector(31 downto 0);
        Wr1             : in     vl_logic;
        Wr1Addr         : in     vl_logic_vector(4 downto 0);
        Wr1Data         : in     vl_logic_vector(31 downto 0);
        ZeroABus1       : in     vl_logic
    );
end a9ejsRam3r2wSDff;
