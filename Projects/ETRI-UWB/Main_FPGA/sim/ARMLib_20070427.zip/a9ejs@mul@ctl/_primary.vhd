library verilog;
use verilog.vl_types.all;
entity a9ejsMulCtl is
    generic(
        RGDEL           : integer := 1
    );
    port(
        InLatCtlDe      : out    vl_logic;
        HoldIERDe       : out    vl_logic;
        ICANDCtlDe      : out    vl_logic_vector(1 downto 0);
        IERCtlDe        : out    vl_logic_vector(1 downto 0);
        Sum2aCtlEx      : out    vl_logic;
        Sum2bCtlEx      : out    vl_logic;
        AccCtlEx        : out    vl_logic_vector(1 downto 0);
        Sum4LCtlMe      : out    vl_logic;
        MulResCtlMe     : out    vl_logic_vector(1 downto 0);
        MulTerm         : out    vl_logic;
        MulClockEn      : out    vl_logic;
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        nRESET          : in     vl_logic;
        MulEnable       : in     vl_logic;
        Interlock       : in     vl_logic;
        MulSkp          : in     vl_logic;
        MulCtlDe        : in     vl_logic_vector(7 downto 0);
        IER16LMe        : in     vl_logic
    );
end a9ejsMulCtl;
