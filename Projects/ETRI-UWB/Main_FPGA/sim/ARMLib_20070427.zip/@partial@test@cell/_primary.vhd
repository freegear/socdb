library verilog;
use verilog.vl_types.all;
entity PartialTestCell is
    port(
        TestOut         : out    vl_logic;
        CLK             : in     vl_logic;
        SigOut          : in     vl_logic;
        INTEST          : in     vl_logic;
        EXTEST          : in     vl_logic
    );
end PartialTestCell;
