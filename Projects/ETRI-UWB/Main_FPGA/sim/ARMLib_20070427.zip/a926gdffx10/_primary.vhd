library verilog;
use verilog.vl_types.all;
entity a926gdffx10 is
    generic(
        Comb1           : integer := 1;
        Reg1            : integer := 1
    );
    port(
        q               : out    vl_logic_vector(9 downto 0);
        d               : in     vl_logic_vector(9 downto 0);
        clk             : in     vl_logic;
        e               : in     vl_logic
    );
end a926gdffx10;
