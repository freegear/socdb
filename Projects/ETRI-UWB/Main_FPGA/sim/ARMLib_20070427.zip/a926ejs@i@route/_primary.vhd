library verilog;
use verilog.vl_types.all;
entity a926ejsIRoute is
    port(
        GCLK            : in     vl_logic;
        INSTRSelICRD    : in     vl_logic;
        INSTRSelIEXTRD  : in     vl_logic;
        INSTRSelITCMRD  : in     vl_logic;
        INSTRSelHold    : in     vl_logic;
        INSTRCapture    : in     vl_logic;
        ICRD            : in     vl_logic_vector(31 downto 0);
        IEXTRD          : in     vl_logic_vector(31 downto 0);
        ITCMRD          : in     vl_logic_vector(31 downto 0);
        INSTR           : out    vl_logic_vector(31 downto 0)
    );
end a926ejsIRoute;
