library verilog;
use verilog.vl_types.all;
entity a9ejsWptdp is
    generic(
        RGDEL           : integer := 1
    );
    port(
        AMatch          : out    vl_logic;
        DMatchL         : out    vl_logic;
        DMatchU         : out    vl_logic;
        SC2DataIn       : out    vl_logic_vector(31 downto 0);
        CLK             : in     vl_logic;
        TCLK            : in     vl_logic;
        nRESET          : in     vl_logic;
        nTRST           : in     vl_logic;
        CompEnL         : in     vl_logic;
        CompEnU         : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        DAintD          : in     vl_logic_vector(31 downto 0);
        DDioIntD        : in     vl_logic_vector(31 downto 0);
        IAintD          : in     vl_logic_vector(31 downto 0);
        ICERegWrStrobe  : in     vl_logic;
        InD             : in     vl_logic;
        SC2Addr         : in     vl_logic_vector(2 downto 0);
        SC2DataOut      : in     vl_logic_vector(31 downto 0);
        SC2SelThisWpt   : in     vl_logic;
        StoredInstr     : in     vl_logic_vector(31 downto 0);
        TCkEn           : in     vl_logic
    );
end a9ejsWptdp;
