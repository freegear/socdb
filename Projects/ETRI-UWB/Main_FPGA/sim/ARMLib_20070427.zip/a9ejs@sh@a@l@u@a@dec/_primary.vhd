library verilog;
use verilog.vl_types.all;
entity a9ejsShALUADec is
    generic(
        RGDEL           : integer := 1
    );
    port(
        ArmUpdPSR       : out    vl_logic;
        ArmALUop        : out    vl_logic_vector(14 downto 0);
        ArmSHop         : out    vl_logic_vector(8 downto 0);
        ArmABBusEn      : out    vl_logic_vector(1 downto 0);
        ArmClass        : out    vl_logic_vector(4 downto 0);
        ArmUndef        : out    vl_logic;
        ArmMAInstr      : out    vl_logic;
        ArmMSRInstrDe   : out    vl_logic;
        ArmMCR15        : out    vl_logic;
        ArmScaledLDRSTRDe: out    vl_logic;
        BLXImmedA       : out    vl_logic;
        BreakA          : out    vl_logic;
        PLDA            : out    vl_logic;
        JMultiMCR       : out    vl_logic;
        IDarmDe         : in     vl_logic_vector(31 downto 0);
        PBitLDMSTMDe    : in     vl_logic;
        UBitLDMSTMDe    : in     vl_logic
    );
end a9ejsShALUADec;
