library verilog;
use verilog.vl_types.all;
entity DW01_mux_any is
    generic(
        sizein          : integer := 10;
        sizemux         : integer := 1;
        sizeout         : integer := 5
    );
    port(
        A               : in     vl_logic_vector;
        SEL             : in     vl_logic_vector;
        MUX             : out    vl_logic_vector
    );
end DW01_mux_any;
