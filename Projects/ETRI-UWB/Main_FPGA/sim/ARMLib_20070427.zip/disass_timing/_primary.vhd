library verilog;
use verilog.vl_types.all;
entity disass_timing is
    port(
        data2           : in     vl_logic_vector(31 downto 0);
        data            : in     vl_logic_vector(31 downto 0);
        addr            : in     vl_logic_vector(31 downto 0);
        tbit            : in     vl_logic;
        disass          : out    vl_logic_vector(2048 downto 1)
    );
end disass_timing;
