library verilog;
use verilog.vl_types.all;
entity MMURam26 is
    generic(
        DW              : integer := 26
    );
    port(
        DATAOUT         : out    vl_logic_vector;
        CLK             : in     vl_logic;
        DATAIN          : in     vl_logic_vector;
        ADDR            : in     vl_logic_vector(4 downto 0);
        WE              : in     vl_logic;
        CS              : in     vl_logic;
        OE              : in     vl_logic
    );
end MMURam26;
