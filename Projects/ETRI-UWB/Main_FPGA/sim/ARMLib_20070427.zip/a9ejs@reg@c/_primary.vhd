library verilog;
use verilog.vl_types.all;
entity a9ejsRegC is
    generic(
        RGDEL           : integer := 1
    );
    port(
        MemRegAddrDe    : out    vl_logic_vector(3 downto 0);
        EnReadCDe       : out    vl_logic;
        nRWMemDe        : out    vl_logic;
        MemInstrEx      : out    vl_logic;
        MemRegAddrEx    : out    vl_logic_vector(3 downto 0);
        nRWMemEx        : out    vl_logic;
        MemFTransEx     : out    vl_logic;
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        nRESET          : in     vl_logic;
        IDarmDe         : in     vl_logic_vector(27 downto 0);
        IDthumbDe       : in     vl_logic_vector(15 downto 0);
        TBitDe          : in     vl_logic;
        JBitDe          : in     vl_logic;
        CycleZeroDe     : in     vl_logic;
        ReEnterDebug    : in     vl_logic;
        RCAjaDe         : in     vl_logic_vector(3 downto 0);
        LDRSTRjaDe      : in     vl_logic;
        nRWjaDe         : in     vl_logic;
        MEMjaDe         : in     vl_logic;
        MulAccjaDe      : in     vl_logic
    );
end a9ejsRegC;
