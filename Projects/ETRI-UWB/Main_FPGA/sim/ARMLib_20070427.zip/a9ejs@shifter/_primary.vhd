library verilog;
use verilog.vl_types.all;
entity a9ejsShifter is
    generic(
        RGDEL           : integer := 1
    );
    port(
        ShiftOut        : out    vl_logic_vector(31 downto 0);
        ShCOut          : out    vl_logic;
        BDataEx         : in     vl_logic_vector(31 downto 0);
        CFlagDe         : in     vl_logic;
        ShiftImmDe      : in     vl_logic_vector(4 downto 0);
        ShiftOpDe       : in     vl_logic_vector(1 downto 0);
        ShImmCtlDe      : in     vl_logic_vector(1 downto 0);
        AUInvBDe        : in     vl_logic;
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        nRESET          : in     vl_logic;
        AUEnDe          : in     vl_logic;
        LUEnDe          : in     vl_logic
    );
end a9ejsShifter;
