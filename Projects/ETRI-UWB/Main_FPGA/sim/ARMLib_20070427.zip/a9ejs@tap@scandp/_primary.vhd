library verilog;
use verilog.vl_types.all;
entity a9ejsTapScandp is
    generic(
        RGDEL           : integer := 1
    );
    port(
        SC1DDShftReg    : out    vl_logic_vector(31 downto 0);
        SC1IDShftReg    : out    vl_logic_vector(31 downto 0);
        SC1ShftRegSo    : out    vl_logic;
        SC2DataOut      : out    vl_logic_vector(31 downto 0);
        SC2ShftRegSo    : out    vl_logic;
        SysSpeed        : out    vl_logic;
        nBkptWpt        : in     vl_logic;
        CLK             : in     vl_logic;
        TCLK            : in     vl_logic;
        FreeCLK         : in     vl_logic;
        CaptureDR       : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        CoreClkEnData   : in     vl_logic;
        DDoutInt        : in     vl_logic_vector(31 downto 0);
        EnterBkptWpt    : in     vl_logic;
        nRESET          : in     vl_logic;
        nTRST           : in     vl_logic;
        SC1Enable       : in     vl_logic;
        SC2DataIn       : in     vl_logic_vector(31 downto 0);
        SC2Enable       : in     vl_logic;
        SC2Write        : in     vl_logic;
        SDInDp          : in     vl_logic;
        ShiftDR         : in     vl_logic;
        TCkEn           : in     vl_logic;
        TCkEnData       : in     vl_logic;
        TDI             : in     vl_logic;
        UpdateDR        : in     vl_logic;
        WptAndBkpt      : in     vl_logic
    );
end a9ejsTapScandp;
