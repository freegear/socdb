library verilog;
use verilog.vl_types.all;
entity a9ejsWptctl is
    generic(
        RGDEL           : integer := 1
    );
    port(
        AMatchD         : out    vl_logic;
        ChainOutE       : out    vl_logic;
        DWptICE         : out    vl_logic;
        DAbortWptICE    : out    vl_logic;
        IBkptICE        : out    vl_logic;
        IAbortBkptICE   : out    vl_logic;
        RangeOut        : out    vl_logic;
        SC2DataIn       : out    vl_logic_vector(8 downto 0);
        InD             : out    vl_logic;
        CompEnL         : out    vl_logic;
        CompEnU         : out    vl_logic;
        CLK             : in     vl_logic;
        TCLK            : in     vl_logic;
        FreeCLK         : in     vl_logic;
        ChainIn         : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        CoreClkEnData   : in     vl_logic;
        DBGEXTbitD      : in     vl_logic;
        DMASintD        : in     vl_logic_vector(1 downto 0);
        DnRWintD        : in     vl_logic;
        DnMREQintD      : in     vl_logic;
        DnTRANSintD     : in     vl_logic;
        ForceIDMatchLD  : in     vl_logic;
        ForceIDMatchUD  : in     vl_logic;
        ICERegWrStrobe  : in     vl_logic;
        ITBITintD       : in     vl_logic;
        IJBITintD       : in     vl_logic;
        InMREQD         : in     vl_logic;
        InTRANSintD     : in     vl_logic;
        AMatchIn        : in     vl_logic;
        nRESET          : in     vl_logic;
        SC2Addr         : in     vl_logic_vector(2 downto 0);
        SC2DataOut      : in     vl_logic_vector(8 downto 0);
        TCkEn           : in     vl_logic;
        TCkEn1          : in     vl_logic;
        nTRST           : in     vl_logic;
        TestLogicReset  : in     vl_logic;
        SC2SelThisWpt   : in     vl_logic;
        AMatch          : in     vl_logic;
        DMatchL         : in     vl_logic;
        DMatchU         : in     vl_logic;
        DBGENintD       : in     vl_logic
    );
end a9ejsWptctl;
