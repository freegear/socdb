library verilog;
use verilog.vl_types.all;
entity a926ejsDExtAddrFifo is
    port(
        FIFOFull        : out    vl_logic;
        FIFOValid       : out    vl_logic;
        FIFODOut        : out    vl_logic_vector(38 downto 0);
        DEXTClk         : in     vl_logic;
        DEXTnReset      : in     vl_logic;
        FIFOCommit      : in     vl_logic;
        FIFODIn         : in     vl_logic_vector(38 downto 0);
        FIFOAck         : in     vl_logic
    );
end a926ejsDExtAddrFifo;
