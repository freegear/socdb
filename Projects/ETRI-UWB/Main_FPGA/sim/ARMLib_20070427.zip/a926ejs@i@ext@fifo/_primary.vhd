library verilog;
use verilog.vl_types.all;
entity a926ejsIExtFifo is
    port(
        RdBufData       : out    vl_logic_vector(32 downto 0);
        IEXTClk         : in     vl_logic;
        WrPtr           : in     vl_logic_vector(1 downto 0);
        WrEnable        : in     vl_logic;
        WrEnableErr     : in     vl_logic;
        WrBufData       : in     vl_logic_vector(32 downto 0);
        RdPtr           : in     vl_logic_vector(1 downto 0)
    );
end a926ejsIExtFifo;
