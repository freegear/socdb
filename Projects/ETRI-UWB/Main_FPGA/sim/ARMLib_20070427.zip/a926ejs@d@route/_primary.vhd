library verilog;
use verilog.vl_types.all;
entity a926ejsDRoute is
    port(
        GCLK            : in     vl_logic;
        RDSelCP15RD     : in     vl_logic;
        RDSelDCRD       : in     vl_logic;
        RDSelDEXTRD     : in     vl_logic;
        RDSelDTCMRD     : in     vl_logic;
        RDSelITCMRD     : in     vl_logic;
        RDSelHold       : in     vl_logic;
        RDCapture       : in     vl_logic;
        WDSelCP15RD     : in     vl_logic;
        WDSelWDATA      : in     vl_logic;
        CPWDSelWDATA    : in     vl_logic;
        CPWDSelDCRD     : in     vl_logic;
        CPWDSelDEXTRD   : in     vl_logic;
        CPWDSelDTCMRD   : in     vl_logic;
        CPWDSelITCMRD   : in     vl_logic;
        CPWDSelHold     : in     vl_logic;
        CPWDCapture     : in     vl_logic;
        DEXTRD          : in     vl_logic_vector(31 downto 0);
        DCRD            : in     vl_logic_vector(31 downto 0);
        DTCMRD          : in     vl_logic_vector(31 downto 0);
        ITCMRD          : in     vl_logic_vector(31 downto 0);
        CP15RD          : in     vl_logic_vector(31 downto 0);
        WDATA           : in     vl_logic_vector(31 downto 0);
        RDATA           : out    vl_logic_vector(31 downto 0);
        CP15WD          : out    vl_logic_vector(31 downto 0);
        DEXTWD          : out    vl_logic_vector(31 downto 0);
        DCWD            : out    vl_logic_vector(31 downto 0);
        DTCMWD          : out    vl_logic_vector(31 downto 0);
        ITCMWD          : out    vl_logic_vector(31 downto 0)
    );
end a926ejsDRoute;
