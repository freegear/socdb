library verilog;
use verilog.vl_types.all;
entity a926ejsSysDebugDisass is
    port(
        decode_instr    : out    vl_logic_vector(2048 downto 1);
        A               : in     vl_logic_vector(31 downto 0);
        I               : in     vl_logic_vector(31 downto 0);
        TBIT            : in     vl_logic;
        JBIT            : in     vl_logic
    );
end a926ejsSysDebugDisass;
