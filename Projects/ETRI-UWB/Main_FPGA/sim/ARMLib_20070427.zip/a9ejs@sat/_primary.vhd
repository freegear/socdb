library verilog;
use verilog.vl_types.all;
entity a9ejsSat is
    generic(
        RGDEL           : integer := 1
    );
    port(
        ALUOutMe        : in     vl_logic_vector(31 downto 0);
        SatEnMe         : in     vl_logic;
        VFlagMe         : in     vl_logic;
        SaturateMe      : out    vl_logic_vector(31 downto 0)
    );
end a9ejsSat;
