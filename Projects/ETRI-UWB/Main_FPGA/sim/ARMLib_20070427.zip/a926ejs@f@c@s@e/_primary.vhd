library verilog;
use verilog.vl_types.all;
entity a926ejsFCSE is
    port(
        GCLK            : in     vl_logic;
        Reset           : in     vl_logic;
        FCSESampleIA    : in     vl_logic;
        FCSESampleDA    : in     vl_logic;
        DVASelDAHeld    : in     vl_logic;
        IVASelIAHeld    : in     vl_logic;
        IA              : in     vl_logic_vector(31 downto 0);
        DA              : in     vl_logic_vector(31 downto 0);
        CP15VA          : in     vl_logic_vector(31 downto 0);
        FCSEPID         : in     vl_logic_vector(31 downto 25);
        DisableFCSE     : in     vl_logic;
        SelCP15VA       : in     vl_logic;
        MMUEn           : in     vl_logic;
        DVA             : out    vl_logic_vector(31 downto 0);
        IVA             : out    vl_logic_vector(31 downto 0);
        DMVA            : out    vl_logic_vector(31 downto 0);
        IMVA            : out    vl_logic_vector(31 downto 0);
        DAME            : out    vl_logic_vector(9 downto 2);
        IAFE            : out    vl_logic_vector(9 downto 2);
        RawIMVA         : out    vl_logic_vector(31 downto 25);
        RawDMVA         : out    vl_logic_vector(31 downto 25)
    );
end a926ejsFCSE;
