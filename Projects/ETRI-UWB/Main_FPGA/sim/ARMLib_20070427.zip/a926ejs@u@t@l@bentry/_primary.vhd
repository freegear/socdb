library verilog;
use verilog.vl_types.all;
entity a926ejsUTLBentry is
    generic(
        pentry          : integer := 0
    );
    port(
        GCLK            : in     vl_logic;
        UTLBnReset      : in     vl_logic;
        A               : in     vl_logic_vector(31 downto 10);
        APselC2         : in     vl_logic_vector(2 downto 0);
        UloadC2         : in     vl_logic;
        UrepcntD1       : in     vl_logic_vector(2 downto 0);
        UinvalC1        : in     vl_logic;
        UmatchEnD1      : in     vl_logic;
        UWD             : in     vl_logic_vector(74 downto 0);
        UhitC1          : out    vl_logic;
        URD             : out    vl_logic_vector(50 downto 0)
    );
end a926ejsUTLBentry;
