library verilog;
use verilog.vl_types.all;
entity a926ejsTCMCtrl is
    port(
        TCMReady        : out    vl_logic;
        TCMRD           : out    vl_logic_vector(31 downto 0);
        TCMBUSY         : out    vl_logic;
        RADDR           : out    vl_logic_vector(17 downto 0);
        RWD             : out    vl_logic_vector(31 downto 0);
        RCS             : out    vl_logic;
        RWBL            : out    vl_logic_vector(3 downto 0);
        RSEQ            : out    vl_logic;
        RnRW            : out    vl_logic;
        RIDLE           : out    vl_logic;
        TCMClk          : in     vl_logic;
        TCMnReset       : in     vl_logic;
        BIGEND          : in     vl_logic;
        TCMCancel       : in     vl_logic;
        TCMSEQ          : in     vl_logic;
        TCMWRREQ        : in     vl_logic;
        TCMRDREQ        : in     vl_logic;
        TCMnRW          : in     vl_logic;
        TCMA            : in     vl_logic_vector(19 downto 0);
        RawCoreA        : in     vl_logic_vector(19 downto 0);
        SelRawCoreA     : in     vl_logic_vector(10 downto 0);
        TCMAS           : in     vl_logic_vector(1 downto 0);
        TCMWD           : in     vl_logic_vector(31 downto 0);
        TCMNoReq        : in     vl_logic;
        RRD             : in     vl_logic_vector(31 downto 0);
        RWAIT           : in     vl_logic;
        RDMAEN          : in     vl_logic;
        RDMAADDR        : in     vl_logic_vector(17 downto 0);
        RDMACS          : in     vl_logic;
        INTEST          : in     vl_logic;
        EXTEST          : in     vl_logic
    );
end a926ejsTCMCtrl;
