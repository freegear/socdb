library verilog;
use verilog.vl_types.all;
entity a9ejsSatTimes2 is
    generic(
        RGDEL           : integer := 1
    );
    port(
        ADataEx         : in     vl_logic_vector(31 downto 0);
        SatTimes2EnDe   : in     vl_logic;
        AddOrSubDe      : in     vl_logic;
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        nRESET          : in     vl_logic;
        SatADataEx      : out    vl_logic_vector(31 downto 0);
        Satx2SFlagEx    : out    vl_logic
    );
end a9ejsSatTimes2;
