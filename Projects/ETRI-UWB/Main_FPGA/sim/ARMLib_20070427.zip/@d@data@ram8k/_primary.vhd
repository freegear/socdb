library verilog;
use verilog.vl_types.all;
entity DDataRam8k is
    port(
        CLK             : in     vl_logic;
        CE              : in     vl_logic;
        WE              : in     vl_logic_vector(3 downto 0);
        A               : in     vl_logic_vector(8 downto 0);
        D               : in     vl_logic_vector(31 downto 0);
        Q               : out    vl_logic_vector(31 downto 0)
    );
end DDataRam8k;
