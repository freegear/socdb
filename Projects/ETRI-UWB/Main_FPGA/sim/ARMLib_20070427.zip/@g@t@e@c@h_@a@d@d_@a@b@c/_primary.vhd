library verilog;
use verilog.vl_types.all;
entity GTECH_ADD_ABC is
    port(
        A               : in     vl_logic;
        B               : in     vl_logic;
        C               : in     vl_logic;
        S               : out    vl_logic;
        COUT            : out    vl_logic
    );
end GTECH_ADD_ABC;
