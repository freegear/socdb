library verilog;
use verilog.vl_types.all;
entity a926CacheUTag is
    port(
        CClk            : in     vl_logic;
        CnReset         : in     vl_logic;
        CacheReady      : in     vl_logic;
        CnRW            : in     vl_logic;
        sNSeqRdMemReq   : in     vl_logic;
        sSeqRdMemReq    : in     vl_logic;
        sRdReCirc       : in     vl_logic;
        InvaluTagAll    : in     vl_logic;
        InvaluTagIndex  : in     vl_logic;
        smTagHitWay     : in     vl_logic_vector(3 downto 0);
        sValidWay       : in     vl_logic_vector(3 downto 0);
        VA              : in     vl_logic_vector(31 downto 5);
        sNSeqVA         : in     vl_logic_vector(31 downto 5);
        uTagHit         : out    vl_logic;
        uTagHitWay      : out    vl_logic_vector(3 downto 0)
    );
end a926CacheUTag;
