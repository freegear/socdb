library verilog;
use verilog.vl_types.all;
entity a926ejsDExtWB is
    port(
        WBOneFree       : out    vl_logic;
        WBTwoFree       : out    vl_logic;
        WBEmpty         : out    vl_logic;
        WBAOut          : out    vl_logic_vector(31 downto 0);
        WBDOut          : out    vl_logic_vector(31 downto 0);
        WBMASOut        : out    vl_logic_vector(1 downto 0);
        WBBurstOut      : out    vl_logic_vector(3 downto 0);
        WBPROTOut       : out    vl_logic_vector(3 downto 0);
        DEXTClk         : in     vl_logic;
        DEXTnReset      : in     vl_logic;
        WBCommitD       : in     vl_logic;
        WBCommitA       : in     vl_logic;
        WBAckData       : in     vl_logic;
        WBAckAddr       : in     vl_logic;
        WBPROTIn        : in     vl_logic_vector(3 downto 0);
        WBAIn           : in     vl_logic_vector(31 downto 0);
        WBDIn           : in     vl_logic_vector(31 downto 0);
        WBMASIn         : in     vl_logic_vector(1 downto 0);
        WBBurstIn       : in     vl_logic_vector(3 downto 0)
    );
end a926ejsDExtWB;
