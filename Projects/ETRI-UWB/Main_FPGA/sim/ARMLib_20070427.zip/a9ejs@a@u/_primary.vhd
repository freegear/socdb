library verilog;
use verilog.vl_types.all;
entity a9ejsAU is
    generic(
        RGDEL           : integer := 1
    );
    port(
        ALUOutEx        : out    vl_logic_vector(31 downto 0);
        ResultMe        : out    vl_logic_vector(31 downto 0);
        ResultWB        : out    vl_logic_vector(31 downto 0);
        FlagsOut        : out    vl_logic_vector(3 downto 0);
        CycleZeroDe     : out    vl_logic;
        CCFailEx        : out    vl_logic;
        CFlagDe         : out    vl_logic;
        CarryInEx       : out    vl_logic;
        SatADataEx      : in     vl_logic_vector(31 downto 0);
        ShiftOut        : in     vl_logic_vector(31 downto 0);
        LUOut           : in     vl_logic_vector(31 downto 0);
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        nRESET          : in     vl_logic;
        AUEnDe          : in     vl_logic;
        LUEnDe          : in     vl_logic;
        SatEnMe         : in     vl_logic;
        AUCarryCtlDe    : in     vl_logic_vector(1 downto 0);
        ShCOut          : in     vl_logic;
        ResultLtEnEx    : in     vl_logic;
        CLZOutEx        : in     vl_logic_vector(5 downto 0);
        CLZEnDe         : in     vl_logic;
        SelMulResMe     : in     vl_logic;
        MulResultMe     : in     vl_logic_vector(31 downto 0);
        CCEn            : in     vl_logic;
        FlagsDe         : in     vl_logic_vector(3 downto 0);
        FwdZNFlag       : in     vl_logic;
        FwdVFlag        : in     vl_logic;
        FwdCFlag        : in     vl_logic;
        MulAdd2Ex       : in     vl_logic;
        CondCodesDe     : in     vl_logic_vector(3 downto 0);
        NonCCFailDe     : in     vl_logic
    );
end a9ejsAU;
