library verilog;
use verilog.vl_types.all;
entity GTECH_MUX2 is
    port(
        A               : in     vl_logic;
        B               : in     vl_logic;
        S               : in     vl_logic;
        Z               : out    vl_logic
    );
end GTECH_MUX2;
