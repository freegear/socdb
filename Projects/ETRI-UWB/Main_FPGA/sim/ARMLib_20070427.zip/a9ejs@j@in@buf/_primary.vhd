library verilog;
use verilog.vl_types.all;
entity a9ejsJInBuf is
    generic(
        RGDEL           : integer := 1
    );
    port(
        Opcode          : out    vl_logic_vector(7 downto 0);
        OpcodeValid     : out    vl_logic;
        Operand1        : out    vl_logic_vector(7 downto 0);
        Op1Valid        : out    vl_logic;
        Operand2        : out    vl_logic_vector(7 downto 0);
        Op2Valid        : out    vl_logic;
        StallJIn        : out    vl_logic;
        JavaPCFe        : out    vl_logic_vector(31 downto 0);
        UpdateRegA      : out    vl_logic;
        UpdateRegB      : out    vl_logic;
        JReadRegA       : out    vl_logic;
        JReadRegB       : out    vl_logic;
        JOp1FWAbort     : out    vl_logic;
        JOp2FWAbort     : out    vl_logic;
        MapFunc         : out    vl_logic_vector(3 downto 0);
        Mapped          : out    vl_logic;
        TranOpcValD     : out    vl_logic;
        CLK             : in     vl_logic;
        CoreClkEn       : in     vl_logic;
        nRESET          : in     vl_logic;
        INSTRint        : in     vl_logic_vector(31 downto 0);
        StoredInstrInt  : in     vl_logic_vector(31 downto 0);
        StoredFlag      : in     vl_logic;
        JDeReady        : in     vl_logic;
        JInstrSize      : in     vl_logic_vector(1 downto 0);
        rawIJBIT        : in     vl_logic;
        ISEQ            : in     vl_logic;
        InMREQ          : in     vl_logic;
        ActiveFe        : in     vl_logic;
        IAint           : in     vl_logic_vector(31 downto 1);
        JIAlsbs         : in     vl_logic_vector(2 downto 0);
        UseOp1          : in     vl_logic;
        UseOp2          : in     vl_logic;
        BIGENDint       : in     vl_logic;
        DbgUpdJPC       : in     vl_logic;
        StallDe         : in     vl_logic;
        ISEQFe          : in     vl_logic;
        IABORTint       : in     vl_logic;
        StoredIAbort    : in     vl_logic;
        ClearTable      : in     vl_logic;
        TableWrite      : in     vl_logic;
        EntryData       : in     vl_logic_vector(3 downto 0);
        CamData         : in     vl_logic_vector(5 downto 0);
        ReTranslate     : in     vl_logic
    );
end a9ejsJInBuf;
