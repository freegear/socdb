library verilog;
use verilog.vl_types.all;
entity GTECH_MUX4 is
    port(
        D0              : in     vl_logic;
        D1              : in     vl_logic;
        D2              : in     vl_logic;
        D3              : in     vl_logic;
        A               : in     vl_logic;
        B               : in     vl_logic;
        Z               : out    vl_logic
    );
end GTECH_MUX4;
