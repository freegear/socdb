library verilog;
use verilog.vl_types.all;
entity a9ejsClkBlk is
    generic(
        RGDEL           : integer := 1
    );
    port(
        CORECLKENOUT    : out    vl_logic;
        CoreClkEn       : out    vl_logic;
        ClkEnData       : out    vl_logic;
        CoreClkEnData   : out    vl_logic;
        TCkEnData       : out    vl_logic;
        CLK             : in     vl_logic;
        nRESET          : in     vl_logic;
        DBGnTRST        : in     vl_logic;
        CLKEN           : in     vl_logic;
        DBGTCKEN        : in     vl_logic;
        DbgClkEnSel     : in     vl_logic;
        DbgClkEn        : in     vl_logic;
        MulClockEn      : in     vl_logic
    );
end a9ejsClkBlk;
