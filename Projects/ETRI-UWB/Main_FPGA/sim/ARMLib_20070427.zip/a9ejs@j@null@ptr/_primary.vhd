library verilog;
use verilog.vl_types.all;
entity a9ejsJNullPtr is
    generic(
        RGDEL           : integer := 1
    );
    port(
        NullPtrEx       : out    vl_logic;
        ADataAGUEx      : in     vl_logic_vector(31 downto 0);
        JBit            : in     vl_logic;
        FirstCycExe     : in     vl_logic;
        NullPtrEnEx     : in     vl_logic
    );
end a9ejsJNullPtr;
