library verilog;
use verilog.vl_types.all;
entity a9ejsArmShifter is
    generic(
        RGDEL           : integer := 1
    );
    port(
        ShiftOut        : out    vl_logic_vector(31 downto 0);
        BDataEx         : in     vl_logic_vector(31 downto 0);
        ShiftDist2Ex    : in     vl_logic_vector(4 downto 0);
        ForceValEx      : in     vl_logic;
        ShiftForceEx    : in     vl_logic_vector(31 downto 0)
    );
end a9ejsArmShifter;
