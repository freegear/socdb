/*----------------------------------------------------------
	 SkyWalker for Navigation
	 Developed by S/W Team, SHMT.Co
	 Copyright @ 2006 SHMT. Co
	 All Rights Reserved.
----------------------------------------------------------*/
/*----------------------------------------------------------
	File name	: memory_test.h
	Description	: SD/MMC test code
	Created by	: SHMT SOC Team
-----------------------------------------------------------*/

/*
/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// 
*/

#include "sysinc.h"
#include "commonmacro.h"

/*
/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// 
*/

/*
/////////////////////////////////////////////////////////
        TYPE DEFINITION
///////////////////////////////////////////////////////// 
*/

//-----------------------------------------------------------
//	ACCESS_TYPE
//-----------------------------------------------------------
typedef enum 
{
	AT_08BITS,
	AT_16BITS,
	AT_32BITS,
	AT_NULL
	
} ACCESS_TYPE;
//-----------------------------------------------------------
//	ACCESS_METHOD
//-----------------------------------------------------------
typedef enum
{
	AM_SEQ,
	AM_NONSEQ,
	AM_BURST,
	AM_NULL
	
} ACCESS_METHOD;
//-----------------------------------------------------------
//	MEM_TEST
//-----------------------------------------------------------
typedef struct 
{
	ACCESS_TYPE		type;
	ACCESS_METHOD	method[3];

} MEM_TEST;

typedef struct 
{
	smtUint32 startAddress;
	smtUint32 endAddress;
	
} MEM_REGION;

/*
/////////////////////////////////////////////////////////
        FUNCTIONS
///////////////////////////////////////////////////////// 
*/

smtBoolean MemRWTest(smtUint32 testTarget, smtUint32	
	testSizeInByte, MEM_TEST *ptestInfo, smtUint32 seed);
