
module I2S_Top ( SYS_CLK, PCLK, PRESETn, PENABLE, PSEL, PWRITE, PADDR, PWDATA, 
        PRDATA, Interrupt, TxDMAReq, RxDMAReq, MCLK, MCLK_OE, BCLK_O, BCLK_I, 
        BCLK_OE, LRCLK_O, LRCLK_I, LRCLK_OE, SDIN, SDOUT );
  input [3:2] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  input SYS_CLK, PCLK, PRESETn, PENABLE, PSEL, PWRITE, BCLK_I, LRCLK_I, SDIN;
  output Interrupt, TxDMAReq, RxDMAReq, MCLK, MCLK_OE, BCLK_O, BCLK_OE,
         LRCLK_O, LRCLK_OE, SDOUT;
  wire   BCLK_OE0, LRClkInv, MClkOn, TxEnabled, TxReset, TxLeftJust,
         TxFifoUnderRun, RxEnabled, RxReset, RxLeftJust, RxFifoOverRun,
         nTxFifoWriteEn, TxFifoFull, TxFifoEmpty, TxFifoAfford2Read,
         nRxFifoReadEn, RxFifoFull, RxFifoEmpty, RxFifoAfford2Write,
         FrameStart, RightStart, BCLKRise, BCLKFall, SDInput, LRCLKInt,
         nTxFifoReadEn, nRxFifoWriteEn;
  wire   [17:0] DTORatio;
  wire   [1:0] TxWordLength;
  wire   [1:0] RxWordLength;
  wire   [31:0] TxFifoWData;
  wire   [4:0] TxFifoLevel;
  wire   [31:0] RxFifoData;
  wire   [4:0] RxFifoLevel;
  wire   [31:0] TxFifoData;
  wire   [31:0] RxFifoWData;
  assign LRCLK_OE = BCLK_OE0;
  assign BCLK_OE = BCLK_OE0;

  I2S_Control_I2S_RFIFO_DEPTH5_I2S_TFIFO_DEPTH5 Ctrl ( .PCLK(PCLK), .PRESETn(
        PRESETn), .PADDR(PADDR), .PENABLE(PENABLE), .PSEL(PSEL), .PWRITE(
        PWRITE), .PWDATA(PWDATA), .PRDATA(PRDATA), .Interrupt(Interrupt), 
        .TxDMAReq(TxDMAReq), .RxDMAReq(RxDMAReq), .ClkMS(BCLK_OE0), .LRClkInv(
        LRClkInv), .MClkOn(MClkOn), .MClkOE(MCLK_OE), .DTORatio(DTORatio), 
        .TxEnabled(TxEnabled), .TxReset(TxReset), .TxWordLength(TxWordLength), 
        .TxLeftJust(TxLeftJust), .TxFifoUnderRun(TxFifoUnderRun), .RxEnabled(
        RxEnabled), .RxReset(RxReset), .RxWordLength(RxWordLength), 
        .RxLeftJust(RxLeftJust), .RxFifoOverRun(RxFifoOverRun), .TxFifoWData(
        TxFifoWData), .nTxFifoWriteEn(nTxFifoWriteEn), .TxFifoFull(TxFifoFull), 
        .TxFifoEmpty(TxFifoEmpty), .TxFifoLevel(TxFifoLevel), 
        .TxFifoAfford2Read(TxFifoAfford2Read), .RxFifoData(RxFifoData), 
        .nRxFifoReadEn(nRxFifoReadEn), .RxFifoFull(RxFifoFull), .RxFifoEmpty(
        RxFifoEmpty), .RxFifoLevel(RxFifoLevel), .RxFifoAfford2Write(
        RxFifoAfford2Write) );
  I2S_DTO DTO ( .SYS_CLK(SYS_CLK), .RESETn(PRESETn), .MCLK(MCLK), .BCLK(BCLK_O), .LRCLK(LRCLK_O), .Enable(MClkOn), .LRClkInv(LRClkInv), .ClkMS(BCLK_OE0), 
        .DTORatio(DTORatio) );
  I2S_ClockMgr ClockMgr ( .CLK(PCLK), .RESETn(PRESETn), .LRCLK_I(LRCLK_I), 
        .BCLK_I(BCLK_I), .SDIN(SDIN), .LeftStart(FrameStart), .RightStart(
        RightStart), .BCLKRise(BCLKRise), .BCLKFall(BCLKFall), .SDInput(
        SDInput), .LRCLK(LRCLKInt), .Master(BCLK_OE0), .LRCLKInvert(LRClkInv)
         );
  I2S_Serializer Serializer ( .CLK(PCLK), .RESETn(PRESETn), .Enabled(TxEnabled), .SyncReset(TxReset), .WordLength(TxWordLength), .LeftJust(TxLeftJust), 
        .FifoUnderRun(TxFifoUnderRun), .FrameStart(FrameStart), .RightStart(
        RightStart), .BCLKFall(BCLKFall), .SDOUT(SDOUT), .FifoData(TxFifoData), 
        .FifoAfford2Read(TxFifoAfford2Read), .FifoEmpty(TxFifoEmpty), 
        .nFifoReadEn(nTxFifoReadEn) );
  I2S_FIFO_1 TxFifo ( .CLK(PCLK), .RESETn(PRESETn), .nReadEnable(nTxFifoReadEn), .ReadData(TxFifoData), .nWriteEnable(nTxFifoWriteEn), .WriteData(TxFifoWData), .SyncReset(TxReset), .Full(TxFifoFull), .Empty(TxFifoEmpty), .Afford2Read(
        TxFifoAfford2Read), .FillLevel(TxFifoLevel) );
  I2S_Deserializer Deserializer ( .CLK(PCLK), .RESETn(PRESETn), .Enabled(
        RxEnabled), .SyncReset(RxReset), .WordLength(RxWordLength), .LeftJust(
        RxLeftJust), .FifoOverRun(RxFifoOverRun), .LRCLK(LRCLKInt), .BCLKRise(
        BCLKRise), .SDIN(SDInput), .FifoWData(RxFifoWData), .FifoAfford2Write(
        RxFifoAfford2Write), .FifoFull(RxFifoFull), .nFifoWriteEn(
        nRxFifoWriteEn) );
  I2S_FIFO_0 RxFifo ( .CLK(PCLK), .RESETn(PRESETn), .nReadEnable(nRxFifoReadEn), .ReadData(RxFifoData), .nWriteEnable(nRxFifoWriteEn), .WriteData(RxFifoWData), .SyncReset(RxReset), .Full(RxFifoFull), .Empty(RxFifoEmpty), .Afford2Write(
        RxFifoAfford2Write), .FillLevel(RxFifoLevel) );
endmodule


module I2S_FIFO_1 ( CLK, RESETn, nReadEnable, ReadData, nWriteEnable, 
        WriteData, SyncReset, Full, Empty, Afford2Write, Afford2Read, 
        FillLevel );
  output [31:0] ReadData;
  input [31:0] WriteData;
  output [4:0] FillLevel;
  input CLK, RESETn, nReadEnable, nWriteEnable, SyncReset;
  output Full, Empty, Afford2Write, Afford2Read;
  wire   n_0_net_, n_1_net_, nextWriteIndex_1_, nextWriteIndex_2_,
         nextWriteIndex_3_, nextReadIndex_1_, nextReadIndex_2_,
         nextReadIndex_3_, n61, n62, n63, n64, n65, n66, n67, n68, n69, n70,
         n71, n72, carry, carry0, n112, n210, n310, carry1, carry2, n110, n2,
         n3, carry_4_, carry_3_, carry_2_, carry_1_, n510, n610, n73, n74, n75,
         n76, n77, n78, n79, n80, n81, n82, n83, n84, n85, n86, n87, n89, n90,
         n91, n92, n95, n96, n97, n99, n100, n101, n102, n104, n105, n106,
         n107, n108, n109, n113, n114, n115, n116, n118, n119, n120, n121,
         n122, n123, n124, n127, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n144;
  wire   [4:0] ReadIndex;
  wire   [4:0] WriteIndex;
  wire   [4:0] RAM_ReadAddr;

  RF2SH32x32 FIFO_RF ( .CENB(n_1_net_), .AB(WriteIndex), .DB(WriteData), 
        .CENA(n_0_net_), .AA(RAM_ReadAddr), .CLKB(CLK), .CLKA(CLK), .QA(
        ReadData) );
  AHHCONX2 U1_1_11 ( .A(ReadIndex[1]), .CI(ReadIndex[0]), .S(nextReadIndex_1_), 
        .CON(n310) );
  AHHCONX2 U1_1_21 ( .A(ReadIndex[2]), .CI(carry0), .S(nextReadIndex_2_), 
        .CON(n210) );
  AHHCONX2 U1_1_31 ( .A(ReadIndex[3]), .CI(carry), .S(nextReadIndex_3_), .CON(
        n112) );
  AHHCONX2 U1_1_1 ( .A(WriteIndex[1]), .CI(WriteIndex[0]), .S(
        nextWriteIndex_1_), .CON(n3) );
  AHHCONX2 U1_1_2 ( .A(WriteIndex[2]), .CI(carry2), .S(nextWriteIndex_2_), 
        .CON(n2) );
  AHHCONX2 U1_1_3 ( .A(WriteIndex[3]), .CI(carry1), .S(nextWriteIndex_3_), 
        .CON(n110) );
  NAND2BX1 U174 ( .AN(nWriteEnable), .B(n138), .Y(n_1_net_) );
  DFFRX1 WriteIndex_reg_4_ ( .D(n71), .CK(CLK), .RN(RESETn), .Q(WriteIndex[4]), 
        .QN(n144) );
  DFFRX1 WriteIndex_reg_2_ ( .D(n69), .CK(CLK), .RN(RESETn), .Q(WriteIndex[2]), 
        .QN(n139) );
  DFFRX1 WriteIndex_reg_3_ ( .D(n70), .CK(CLK), .RN(RESETn), .Q(WriteIndex[3]), 
        .QN(n141) );
  DFFRX1 WriteIndex_reg_1_ ( .D(n68), .CK(CLK), .RN(RESETn), .Q(WriteIndex[1]), 
        .QN(n142) );
  DFFRX1 WriteIndex_reg_0_ ( .D(n67), .CK(CLK), .RN(RESETn), .Q(WriteIndex[0]), 
        .QN(n143) );
  NAND3BX1 U175 ( .AN(n130), .B(n131), .C(n132), .Y(Afford2Read) );
  INVX1 U176 ( .A(FillLevel[1]), .Y(n132) );
  INVX1 U177 ( .A(FillLevel[2]), .Y(n131) );
  NAND3BX1 U178 ( .AN(FillLevel[3]), .B(n133), .C(n138), .Y(n130) );
  XOR2X1 U179 ( .A(n139), .B(RAM_ReadAddr[2]), .Y(n122) );
  INVX1 U180 ( .A(FillLevel[4]), .Y(n133) );
  INVX1 U181 ( .A(n116), .Y(n87) );
  INVX1 U182 ( .A(n105), .Y(n101) );
  INVX1 U183 ( .A(n124), .Y(RAM_ReadAddr[0]) );
  OAI31X1 U184 ( .A0(n74), .A1(n75), .A2(n76), .B0(n77), .Y(n72) );
  INVX1 U185 ( .A(n_1_net_), .Y(n76) );
  OA21X2 U186 ( .A0(n78), .A1(FillLevel[0]), .B0(n79), .Y(n77) );
  NAND3BX1 U187 ( .AN(n85), .B(n86), .C(n87), .Y(n74) );
  XOR2X1 U188 ( .A(n137), .B(n112), .Y(n89) );
  NAND4BX1 U189 ( .AN(n75), .B(n113), .C(n114), .D(n115), .Y(n108) );
  XOR2X1 U190 ( .A(n135), .B(nextWriteIndex_1_), .Y(n114) );
  XOR2X1 U191 ( .A(n134), .B(nextWriteIndex_2_), .Y(n115) );
  XOR2X1 U192 ( .A(n136), .B(nextWriteIndex_3_), .Y(n113) );
  INVX1 U193 ( .A(n100), .Y(n95) );
  INVX1 U194 ( .A(FillLevel[0]), .Y(n75) );
  NAND4X1 U195 ( .A(FillLevel[3]), .B(FillLevel[4]), .C(FillLevel[1]), .D(
        FillLevel[2]), .Y(n127) );
  OA21X2 U196 ( .A0(n127), .A1(n75), .B0(n138), .Y(Afford2Write) );
  AFHCONX2 U2_1 ( .A(WriteIndex[1]), .B(n135), .CI(carry_1_), .S(FillLevel[1]), 
        .CON(n73) );
  AFHCONX2 U2_3 ( .A(WriteIndex[3]), .B(n136), .CI(carry_3_), .S(FillLevel[3]), 
        .CON(n510) );
  INVX1 U197 ( .A(n610), .Y(carry_3_) );
  AFHCONX2 U2_2 ( .A(WriteIndex[2]), .B(n134), .CI(carry_2_), .S(FillLevel[2]), 
        .CON(n610) );
  INVX1 U198 ( .A(n73), .Y(carry_2_) );
  XOR3X1 U2_4 ( .A(WriteIndex[4]), .B(n137), .C(carry_4_), .Y(FillLevel[4]) );
  INVX1 U199 ( .A(n510), .Y(carry_4_) );
  XOR2X1 U200 ( .A(n116), .B(ReadIndex[0]), .Y(n124) );
  OR2X1 U201 ( .A(nReadEnable), .B(Empty), .Y(n116) );
  XOR2X1 U202 ( .A(n124), .B(WriteIndex[0]), .Y(n123) );
  NAND2BX1 U203 ( .AN(WriteIndex[0]), .B(ReadIndex[0]), .Y(carry_1_) );
  XOR2X1 U204 ( .A(RAM_ReadAddr[3]), .B(WriteIndex[3]), .Y(n121) );
  NAND2BX1 U205 ( .AN(SyncReset), .B(n116), .Y(n105) );
  NOR4BX1 U206 ( .AN(n118), .B(n119), .C(Full), .D(n120), .Y(n_0_net_) );
  XOR2X1 U207 ( .A(RAM_ReadAddr[4]), .B(WriteIndex[4]), .Y(n120) );
  XOR2X1 U208 ( .A(n142), .B(RAM_ReadAddr[1]), .Y(n118) );
  NAND3BX1 U209 ( .AN(n121), .B(n122), .C(n123), .Y(n119) );
  AO22X1 U210 ( .A0(n116), .A1(ReadIndex[2]), .B0(n87), .B1(nextReadIndex_2_), 
        .Y(RAM_ReadAddr[2]) );
  AO22X1 U211 ( .A0(n116), .A1(ReadIndex[1]), .B0(n87), .B1(nextReadIndex_1_), 
        .Y(RAM_ReadAddr[1]) );
  AO22X1 U212 ( .A0(n116), .A1(ReadIndex[3]), .B0(n87), .B1(nextReadIndex_3_), 
        .Y(RAM_ReadAddr[3]) );
  AO22X1 U213 ( .A0(n116), .A1(ReadIndex[4]), .B0(n87), .B1(n89), .Y(
        RAM_ReadAddr[4]) );
  AO22X1 U214 ( .A0(n101), .A1(n106), .B0(Full), .B1(n107), .Y(n61) );
  INVX1 U215 ( .A(n106), .Y(n107) );
  OAI31X1 U216 ( .A0(n108), .A1(n_1_net_), .A2(n109), .B0(n101), .Y(n106) );
  XOR2X1 U217 ( .A(n97), .B(ReadIndex[4]), .Y(n109) );
  AO22X1 U218 ( .A0(n101), .A1(ReadIndex[3]), .B0(n102), .B1(nextReadIndex_3_), 
        .Y(n65) );
  AO22X1 U219 ( .A0(n101), .A1(ReadIndex[2]), .B0(n102), .B1(nextReadIndex_2_), 
        .Y(n64) );
  AO22X1 U220 ( .A0(n101), .A1(ReadIndex[4]), .B0(n102), .B1(n89), .Y(n66) );
  AO22X1 U221 ( .A0(n101), .A1(ReadIndex[1]), .B0(n102), .B1(nextReadIndex_1_), 
        .Y(n63) );
  AO22X1 U222 ( .A0(n101), .A1(ReadIndex[0]), .B0(n102), .B1(n140), .Y(n62) );
  INVX1 U223 ( .A(n104), .Y(n102) );
  NAND2BX1 U224 ( .AN(SyncReset), .B(n105), .Y(n104) );
  INVX1 U225 ( .A(n210), .Y(carry) );
  INVX1 U226 ( .A(n2), .Y(carry1) );
  OAI2BB1X1 U227 ( .A0N(WriteIndex[0]), .A1N(n140), .B0(carry_1_), .Y(
        FillLevel[0]) );
  INVX1 U228 ( .A(n3), .Y(carry2) );
  INVX1 U229 ( .A(n310), .Y(carry0) );
  XNOR2X1 U230 ( .A(WriteIndex[4]), .B(n110), .Y(n97) );
  XOR2X1 U231 ( .A(n137), .B(WriteIndex[4]), .Y(n84) );
  XOR2X1 U232 ( .A(n144), .B(n89), .Y(n86) );
  NAND2BX1 U233 ( .AN(SyncReset), .B(n_1_net_), .Y(n100) );
  XOR2X1 U234 ( .A(WriteIndex[3]), .B(ReadIndex[3]), .Y(n82) );
  NAND3BX1 U235 ( .AN(n80), .B(n81), .C(Empty), .Y(n78) );
  XOR2X1 U236 ( .A(n135), .B(WriteIndex[1]), .Y(n81) );
  NAND3BX1 U237 ( .AN(n82), .B(n83), .C(n84), .Y(n80) );
  XOR2X1 U238 ( .A(n134), .B(WriteIndex[2]), .Y(n83) );
  NAND3BX1 U239 ( .AN(n90), .B(n91), .C(n92), .Y(n85) );
  XOR2X1 U240 ( .A(nextReadIndex_1_), .B(WriteIndex[1]), .Y(n90) );
  XOR2X1 U241 ( .A(n139), .B(nextReadIndex_2_), .Y(n92) );
  XOR2X1 U242 ( .A(n141), .B(nextReadIndex_3_), .Y(n91) );
  INVX1 U243 ( .A(SyncReset), .Y(n79) );
  AO22X1 U244 ( .A0(n95), .A1(WriteIndex[1]), .B0(nextWriteIndex_1_), .B1(n96), 
        .Y(n68) );
  AO22X1 U245 ( .A0(n95), .A1(WriteIndex[3]), .B0(nextWriteIndex_3_), .B1(n96), 
        .Y(n70) );
  AO22X1 U246 ( .A0(n95), .A1(WriteIndex[2]), .B0(nextWriteIndex_2_), .B1(n96), 
        .Y(n69) );
  AO22X1 U247 ( .A0(n95), .A1(WriteIndex[0]), .B0(n96), .B1(n143), .Y(n67) );
  AO22X1 U248 ( .A0(n95), .A1(WriteIndex[4]), .B0(n96), .B1(n97), .Y(n71) );
  INVX1 U249 ( .A(n99), .Y(n96) );
  NAND2BX1 U250 ( .AN(SyncReset), .B(n100), .Y(n99) );
  DFFRX1 ReadIndex_reg_0_ ( .D(n62), .CK(CLK), .RN(RESETn), .Q(ReadIndex[0]), 
        .QN(n140) );
  DFFRX1 ReadIndex_reg_1_ ( .D(n63), .CK(CLK), .RN(RESETn), .Q(ReadIndex[1]), 
        .QN(n135) );
  DFFRX1 ReadIndex_reg_3_ ( .D(n65), .CK(CLK), .RN(RESETn), .Q(ReadIndex[3]), 
        .QN(n136) );
  DFFRX1 ReadIndex_reg_4_ ( .D(n66), .CK(CLK), .RN(RESETn), .Q(ReadIndex[4]), 
        .QN(n137) );
  DFFRX1 ReadIndex_reg_2_ ( .D(n64), .CK(CLK), .RN(RESETn), .Q(ReadIndex[2]), 
        .QN(n134) );
  DFFRX1 Full_reg ( .D(n61), .CK(CLK), .RN(RESETn), .Q(Full), .QN(n138) );
  DFFSX1 Empty_reg ( .D(n72), .CK(CLK), .SN(RESETn), .Q(Empty) );
endmodule


module I2S_FIFO_0 ( CLK, RESETn, nReadEnable, ReadData, nWriteEnable, 
        WriteData, SyncReset, Full, Empty, Afford2Write, Afford2Read, 
        FillLevel );
  output [31:0] ReadData;
  input [31:0] WriteData;
  output [4:0] FillLevel;
  input CLK, RESETn, nReadEnable, nWriteEnable, SyncReset;
  output Full, Empty, Afford2Write, Afford2Read;
  wire   n_0_net_, n_1_net_, nextWriteIndex_1_, nextWriteIndex_2_,
         nextWriteIndex_3_, nextReadIndex_1_, nextReadIndex_2_,
         nextReadIndex_3_, n61, n62, n63, n64, n65, n66, n67, n68, n69, n70,
         n71, n72, carry, carry0, n112, n210, n310, carry1, carry2, n110, n2,
         n3, carry_4_, carry_3_, carry_2_, carry_1_, n510, n610, n73, n74, n75,
         n76, n77, n78, n79, n80, n81, n82, n83, n84, n85, n86, n87, n89, n90,
         n91, n92, n95, n96, n97, n99, n100, n101, n102, n104, n105, n106,
         n107, n108, n109, n113, n114, n115, n116, n118, n119, n120, n121,
         n122, n123, n124, n127, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n144;
  wire   [4:0] ReadIndex;
  wire   [4:0] WriteIndex;
  wire   [4:0] RAM_ReadAddr;

  RF2SH32x32 FIFO_RF ( .CENB(n_1_net_), .AB(WriteIndex), .DB(WriteData), 
        .CENA(n_0_net_), .AA(RAM_ReadAddr), .CLKB(CLK), .CLKA(CLK), .QA(
        ReadData) );
  AHHCONX2 U1_1_11 ( .A(ReadIndex[1]), .CI(ReadIndex[0]), .S(nextReadIndex_1_), 
        .CON(n310) );
  AHHCONX2 U1_1_21 ( .A(ReadIndex[2]), .CI(carry0), .S(nextReadIndex_2_), 
        .CON(n210) );
  AHHCONX2 U1_1_31 ( .A(ReadIndex[3]), .CI(carry), .S(nextReadIndex_3_), .CON(
        n112) );
  AHHCONX2 U1_1_1 ( .A(WriteIndex[1]), .CI(WriteIndex[0]), .S(
        nextWriteIndex_1_), .CON(n3) );
  AHHCONX2 U1_1_2 ( .A(WriteIndex[2]), .CI(carry2), .S(nextWriteIndex_2_), 
        .CON(n2) );
  AHHCONX2 U1_1_3 ( .A(WriteIndex[3]), .CI(carry1), .S(nextWriteIndex_3_), 
        .CON(n110) );
  OA21X2 U174 ( .A0(n127), .A1(n75), .B0(n137), .Y(Afford2Write) );
  NAND2BX1 U175 ( .AN(nWriteEnable), .B(n137), .Y(n_1_net_) );
  DFFRX1 WriteIndex_reg_4_ ( .D(n71), .CK(CLK), .RN(RESETn), .Q(WriteIndex[4]), 
        .QN(n144) );
  DFFRX1 WriteIndex_reg_2_ ( .D(n69), .CK(CLK), .RN(RESETn), .Q(WriteIndex[2]), 
        .QN(n139) );
  DFFRX1 WriteIndex_reg_3_ ( .D(n70), .CK(CLK), .RN(RESETn), .Q(WriteIndex[3]), 
        .QN(n141) );
  DFFRX1 WriteIndex_reg_1_ ( .D(n68), .CK(CLK), .RN(RESETn), .Q(WriteIndex[1]), 
        .QN(n142) );
  DFFRX1 WriteIndex_reg_0_ ( .D(n67), .CK(CLK), .RN(RESETn), .Q(WriteIndex[0]), 
        .QN(n143) );
  NAND3BX1 U176 ( .AN(n130), .B(n131), .C(n132), .Y(Afford2Read) );
  XOR2X1 U177 ( .A(n139), .B(RAM_ReadAddr[2]), .Y(n122) );
  INVX1 U178 ( .A(n116), .Y(n87) );
  INVX1 U179 ( .A(n105), .Y(n101) );
  INVX1 U180 ( .A(n124), .Y(RAM_ReadAddr[0]) );
  OAI31X1 U181 ( .A0(n74), .A1(n75), .A2(n76), .B0(n77), .Y(n72) );
  INVX1 U182 ( .A(n_1_net_), .Y(n76) );
  OA21X2 U183 ( .A0(n78), .A1(FillLevel[0]), .B0(n79), .Y(n77) );
  NAND3BX1 U184 ( .AN(n85), .B(n86), .C(n87), .Y(n74) );
  XOR2X1 U185 ( .A(n138), .B(n112), .Y(n89) );
  NAND4BX1 U186 ( .AN(n75), .B(n113), .C(n114), .D(n115), .Y(n108) );
  XOR2X1 U187 ( .A(n135), .B(nextWriteIndex_1_), .Y(n114) );
  XOR2X1 U188 ( .A(n134), .B(nextWriteIndex_2_), .Y(n115) );
  XOR2X1 U189 ( .A(n136), .B(nextWriteIndex_3_), .Y(n113) );
  NAND4X1 U190 ( .A(FillLevel[3]), .B(FillLevel[4]), .C(FillLevel[1]), .D(
        FillLevel[2]), .Y(n127) );
  DFFRX1 Full_reg ( .D(n61), .CK(CLK), .RN(RESETn), .Q(Full), .QN(n137) );
  INVX1 U191 ( .A(n100), .Y(n95) );
  INVX1 U192 ( .A(FillLevel[0]), .Y(n75) );
  NAND3BX1 U193 ( .AN(FillLevel[3]), .B(n133), .C(n137), .Y(n130) );
  INVX1 U194 ( .A(FillLevel[4]), .Y(n133) );
  INVX1 U195 ( .A(FillLevel[2]), .Y(n131) );
  INVX1 U196 ( .A(FillLevel[1]), .Y(n132) );
  XOR2X1 U197 ( .A(n116), .B(ReadIndex[0]), .Y(n124) );
  OR2X1 U198 ( .A(nReadEnable), .B(Empty), .Y(n116) );
  XOR2X1 U199 ( .A(n124), .B(WriteIndex[0]), .Y(n123) );
  XOR2X1 U200 ( .A(RAM_ReadAddr[3]), .B(WriteIndex[3]), .Y(n121) );
  NAND2BX1 U201 ( .AN(SyncReset), .B(n116), .Y(n105) );
  NOR4BX1 U202 ( .AN(n118), .B(n119), .C(Full), .D(n120), .Y(n_0_net_) );
  XOR2X1 U203 ( .A(RAM_ReadAddr[4]), .B(WriteIndex[4]), .Y(n120) );
  XOR2X1 U204 ( .A(n142), .B(RAM_ReadAddr[1]), .Y(n118) );
  NAND3BX1 U205 ( .AN(n121), .B(n122), .C(n123), .Y(n119) );
  AO22X1 U206 ( .A0(n116), .A1(ReadIndex[2]), .B0(n87), .B1(nextReadIndex_2_), 
        .Y(RAM_ReadAddr[2]) );
  AO22X1 U207 ( .A0(n116), .A1(ReadIndex[1]), .B0(n87), .B1(nextReadIndex_1_), 
        .Y(RAM_ReadAddr[1]) );
  AO22X1 U208 ( .A0(n116), .A1(ReadIndex[3]), .B0(n87), .B1(nextReadIndex_3_), 
        .Y(RAM_ReadAddr[3]) );
  AO22X1 U209 ( .A0(n116), .A1(ReadIndex[4]), .B0(n87), .B1(n89), .Y(
        RAM_ReadAddr[4]) );
  AO22X1 U210 ( .A0(n101), .A1(n106), .B0(Full), .B1(n107), .Y(n61) );
  INVX1 U211 ( .A(n106), .Y(n107) );
  OAI31X1 U212 ( .A0(n108), .A1(n_1_net_), .A2(n109), .B0(n101), .Y(n106) );
  XOR2X1 U213 ( .A(n97), .B(ReadIndex[4]), .Y(n109) );
  AO22X1 U214 ( .A0(n101), .A1(ReadIndex[3]), .B0(n102), .B1(nextReadIndex_3_), 
        .Y(n65) );
  AO22X1 U215 ( .A0(n101), .A1(ReadIndex[2]), .B0(n102), .B1(nextReadIndex_2_), 
        .Y(n64) );
  AO22X1 U216 ( .A0(n101), .A1(ReadIndex[4]), .B0(n102), .B1(n89), .Y(n66) );
  AO22X1 U217 ( .A0(n101), .A1(ReadIndex[1]), .B0(n102), .B1(nextReadIndex_1_), 
        .Y(n63) );
  AO22X1 U218 ( .A0(n101), .A1(ReadIndex[0]), .B0(n102), .B1(n140), .Y(n62) );
  INVX1 U219 ( .A(n104), .Y(n102) );
  NAND2BX1 U220 ( .AN(SyncReset), .B(n105), .Y(n104) );
  AFHCONX2 U2_2 ( .A(WriteIndex[2]), .B(n134), .CI(carry_2_), .S(FillLevel[2]), 
        .CON(n610) );
  INVX1 U221 ( .A(n73), .Y(carry_2_) );
  AFHCONX2 U2_1 ( .A(WriteIndex[1]), .B(n135), .CI(carry_1_), .S(FillLevel[1]), 
        .CON(n73) );
  XOR3X1 U2_4 ( .A(WriteIndex[4]), .B(n138), .C(carry_4_), .Y(FillLevel[4]) );
  INVX1 U222 ( .A(n510), .Y(carry_4_) );
  AFHCONX2 U2_3 ( .A(WriteIndex[3]), .B(n136), .CI(carry_3_), .S(FillLevel[3]), 
        .CON(n510) );
  INVX1 U223 ( .A(n610), .Y(carry_3_) );
  INVX1 U224 ( .A(n210), .Y(carry) );
  INVX1 U225 ( .A(n2), .Y(carry1) );
  INVX1 U226 ( .A(n3), .Y(carry2) );
  INVX1 U227 ( .A(n310), .Y(carry0) );
  NAND2BX1 U228 ( .AN(WriteIndex[0]), .B(ReadIndex[0]), .Y(carry_1_) );
  XNOR2X1 U229 ( .A(WriteIndex[4]), .B(n110), .Y(n97) );
  OAI2BB1X1 U230 ( .A0N(WriteIndex[0]), .A1N(n140), .B0(carry_1_), .Y(
        FillLevel[0]) );
  XOR2X1 U231 ( .A(n138), .B(WriteIndex[4]), .Y(n84) );
  NAND2BX1 U232 ( .AN(SyncReset), .B(n_1_net_), .Y(n100) );
  XOR2X1 U233 ( .A(WriteIndex[3]), .B(ReadIndex[3]), .Y(n82) );
  NAND3BX1 U234 ( .AN(n80), .B(n81), .C(Empty), .Y(n78) );
  XOR2X1 U235 ( .A(n135), .B(WriteIndex[1]), .Y(n81) );
  NAND3BX1 U236 ( .AN(n82), .B(n83), .C(n84), .Y(n80) );
  XOR2X1 U237 ( .A(n134), .B(WriteIndex[2]), .Y(n83) );
  NAND3BX1 U238 ( .AN(n90), .B(n91), .C(n92), .Y(n85) );
  XOR2X1 U239 ( .A(nextReadIndex_1_), .B(WriteIndex[1]), .Y(n90) );
  XOR2X1 U240 ( .A(n139), .B(nextReadIndex_2_), .Y(n92) );
  XOR2X1 U241 ( .A(n141), .B(nextReadIndex_3_), .Y(n91) );
  XOR2X1 U242 ( .A(n144), .B(n89), .Y(n86) );
  AO22X1 U243 ( .A0(n95), .A1(WriteIndex[1]), .B0(nextWriteIndex_1_), .B1(n96), 
        .Y(n68) );
  AO22X1 U244 ( .A0(n95), .A1(WriteIndex[3]), .B0(nextWriteIndex_3_), .B1(n96), 
        .Y(n70) );
  AO22X1 U245 ( .A0(n95), .A1(WriteIndex[2]), .B0(nextWriteIndex_2_), .B1(n96), 
        .Y(n69) );
  AO22X1 U246 ( .A0(n95), .A1(WriteIndex[0]), .B0(n96), .B1(n143), .Y(n67) );
  AO22X1 U247 ( .A0(n95), .A1(WriteIndex[4]), .B0(n96), .B1(n97), .Y(n71) );
  INVX1 U248 ( .A(n99), .Y(n96) );
  NAND2BX1 U249 ( .AN(SyncReset), .B(n100), .Y(n99) );
  INVX1 U250 ( .A(SyncReset), .Y(n79) );
  DFFRX1 ReadIndex_reg_0_ ( .D(n62), .CK(CLK), .RN(RESETn), .Q(ReadIndex[0]), 
        .QN(n140) );
  DFFRX1 ReadIndex_reg_3_ ( .D(n65), .CK(CLK), .RN(RESETn), .Q(ReadIndex[3]), 
        .QN(n136) );
  DFFRX1 ReadIndex_reg_1_ ( .D(n63), .CK(CLK), .RN(RESETn), .Q(ReadIndex[1]), 
        .QN(n135) );
  DFFRX1 ReadIndex_reg_2_ ( .D(n64), .CK(CLK), .RN(RESETn), .Q(ReadIndex[2]), 
        .QN(n134) );
  DFFSX1 Empty_reg ( .D(n72), .CK(CLK), .SN(RESETn), .Q(Empty) );
  DFFRX1 ReadIndex_reg_4_ ( .D(n66), .CK(CLK), .RN(RESETn), .Q(ReadIndex[4]), 
        .QN(n138) );
endmodule


module I2S_Deserializer ( CLK, RESETn, Enabled, SyncReset, WordLength, 
        LeftJust, FifoOverRun, LRCLK, BCLKRise, SDIN, FifoWData, 
        FifoAfford2Write, FifoFull, nFifoWriteEn );
  input [1:0] WordLength;
  output [31:0] FifoWData;
  input CLK, RESETn, Enabled, SyncReset, LeftJust, LRCLK, BCLKRise, SDIN,
         FifoAfford2Write, FifoFull;
  output FifoOverRun, nFifoWriteEn;
  wire   SDIN1d, LeftRight, NewChannelStart, N35, RealEnabled, BitCounter_4_,
         BitCounter_0_, BitCounterValid, DataState, FifoWriteEn, N326, N386,
         N387, N388, N389, n244, n245, n246, n247, n248, n249, n250, n251,
         n252, n253, n254, n255, n256, n257, n258, n259, n260, n261, n262,
         n263, n264, n265, n266, n267, n268, n269, n270, n271, n272, n273,
         n274, n275, n276, n277, n278, n279, n280, n281, n282, n283, n284,
         n285, n286, n287, n288, n289, n290, n291, n292, n293, n294, n295,
         n296, n297, n298, n299, n300, n301, n302, n303, n304, n305, n306,
         n307, n308, n309, n310, n311, n312, n313, n314, n315, n316, n317,
         n318, n319, n320, n321, n322, n323, n324, n325, n3260, n327, n328,
         n329, n330, n331, n332, n333, n334, n335, n336, n337, n338, n339,
         n340, n341, n342, n343, n344, n345, n346, n347, n348, n349, n350,
         n351, n352, n353, n354, n355, n356, n357, n358, n359, n360, n361,
         n362, n363, n364, n365, n366, n367, n368, n369, n370, n371, n372,
         n373, n374, n375, n376, n377, n378, n379, n380, n381, n382, n384,
         n385, n3870, carry_4_, carry_3_, carry_2_, n391, n392, n393, n394,
         n395, n396, n397, n398, n399, n401, n402, n404, n405, n406, n408,
         n409, n411, n412, n414, n415, n417, n418, n420, n421, n423, n424,
         n426, n427, n429, n430, n432, n440, n442, n450, n452, n459, n460,
         n461, n462, n463, n465, n467, n475, n476, n478, n486, n488, n496,
         n497, n499, n500, n501, n504, n506, n508, n510, n512, n514, n516,
         n517, n520, n521, n522, n524, n526, n527, n528, n529, n530, n531,
         n532, n533, n534, n535, n536, n537, n538, n539, n540, n541, n542,
         n543, n544, n545, n546, n547, n548, n549, n550, n551, n552, n553,
         n554, n555, n556, n557, n558, n559, n560, n561, n562, n563, n564,
         n565, n566, n567, n568, n569, n570, n571, n572, n573, n574, n575,
         n576, n577, n578, n579, n580, n581, n582, n583, n584, n585, n586,
         n587, n588, n589, n590, n591, n592, n593, n594, n595, n596, n597,
         n598, n599, n600, n601, n602, n603, n604, n605, n606, n607, n608,
         n609, n610, n611, n612, n613, n614, n615, n616, n617, n618, n619,
         n620, n621, n622, n623, n624, n625, n626, n628, n633, n634, n635,
         n636, n637, n638, n639, n640, n641, n642, n643, n644, n645, n646,
         n647, n648, n649, n650, n651, n652, n653, n654, n655, n656, n657,
         n658, n659, n660, n661, n662, n663, n664, n665, n666, n667, n668,
         n669, n670, n671, n672, n673, n674, n675, n676, n677, n678, n679,
         n680, n681, n682, n683, n684, n685, n686, n687, n688, n689, n690,
         n691, n692, n693, n694, n695, n696, n697, n698, n699, n700, n701,
         n702, n703, n704, n705, n706, n707, n708, n709, n710, n711, n712,
         n713;
  wire   [31:0] LeftData;
  wire   [31:0] RightData;

  DFFRX1 FifoWData_reg_0_ ( .D(n276), .CK(CLK), .RN(RESETn), .Q(FifoWData[0]), 
        .QN(n244) );
  DFFRX1 FifoWData_reg_1_ ( .D(n277), .CK(CLK), .RN(RESETn), .Q(FifoWData[1]), 
        .QN(n255) );
  DFFRX1 FifoWData_reg_2_ ( .D(n278), .CK(CLK), .RN(RESETn), .Q(FifoWData[2]), 
        .QN(n266) );
  DFFRX1 FifoWData_reg_3_ ( .D(n279), .CK(CLK), .RN(RESETn), .Q(FifoWData[3]), 
        .QN(n269) );
  DFFRX1 FifoWData_reg_4_ ( .D(n280), .CK(CLK), .RN(RESETn), .Q(FifoWData[4]), 
        .QN(n270) );
  DFFRX1 FifoWData_reg_5_ ( .D(n281), .CK(CLK), .RN(RESETn), .Q(FifoWData[5]), 
        .QN(n271) );
  DFFRX1 FifoWData_reg_6_ ( .D(n282), .CK(CLK), .RN(RESETn), .Q(FifoWData[6]), 
        .QN(n272) );
  DFFRX1 FifoWData_reg_7_ ( .D(n283), .CK(CLK), .RN(RESETn), .Q(FifoWData[7]), 
        .QN(n273) );
  DFFRX1 FifoWData_reg_8_ ( .D(n284), .CK(CLK), .RN(RESETn), .Q(FifoWData[8]), 
        .QN(n274) );
  DFFRX1 FifoWData_reg_9_ ( .D(n285), .CK(CLK), .RN(RESETn), .Q(FifoWData[9]), 
        .QN(n275) );
  DFFRX1 FifoWData_reg_10_ ( .D(n286), .CK(CLK), .RN(RESETn), .Q(FifoWData[10]), .QN(n245) );
  DFFRX1 FifoWData_reg_11_ ( .D(n287), .CK(CLK), .RN(RESETn), .Q(FifoWData[11]), .QN(n246) );
  DFFRX1 FifoWData_reg_12_ ( .D(n288), .CK(CLK), .RN(RESETn), .Q(FifoWData[12]), .QN(n247) );
  DFFRX1 FifoWData_reg_13_ ( .D(n289), .CK(CLK), .RN(RESETn), .Q(FifoWData[13]), .QN(n248) );
  DFFRX1 FifoWData_reg_14_ ( .D(n290), .CK(CLK), .RN(RESETn), .Q(FifoWData[14]), .QN(n249) );
  DFFRX1 FifoWData_reg_15_ ( .D(n291), .CK(CLK), .RN(RESETn), .Q(FifoWData[15]), .QN(n250) );
  DFFRX1 FifoWData_reg_16_ ( .D(n292), .CK(CLK), .RN(RESETn), .Q(FifoWData[16]), .QN(n251) );
  DFFRX1 FifoWData_reg_17_ ( .D(n293), .CK(CLK), .RN(RESETn), .Q(FifoWData[17]), .QN(n252) );
  DFFRX1 FifoWData_reg_18_ ( .D(n294), .CK(CLK), .RN(RESETn), .Q(FifoWData[18]), .QN(n253) );
  DFFRX1 FifoWData_reg_19_ ( .D(n295), .CK(CLK), .RN(RESETn), .Q(FifoWData[19]), .QN(n254) );
  DFFRX1 FifoWData_reg_20_ ( .D(n296), .CK(CLK), .RN(RESETn), .Q(FifoWData[20]), .QN(n256) );
  DFFRX1 FifoWData_reg_21_ ( .D(n297), .CK(CLK), .RN(RESETn), .Q(FifoWData[21]), .QN(n257) );
  DFFRX1 FifoWData_reg_22_ ( .D(n298), .CK(CLK), .RN(RESETn), .Q(FifoWData[22]), .QN(n258) );
  DFFRX1 FifoWData_reg_23_ ( .D(n299), .CK(CLK), .RN(RESETn), .Q(FifoWData[23]), .QN(n259) );
  DFFRX1 FifoWData_reg_24_ ( .D(n300), .CK(CLK), .RN(RESETn), .Q(FifoWData[24]), .QN(n260) );
  DFFRX1 FifoWData_reg_25_ ( .D(n301), .CK(CLK), .RN(RESETn), .Q(FifoWData[25]), .QN(n261) );
  DFFRX1 FifoWData_reg_26_ ( .D(n302), .CK(CLK), .RN(RESETn), .Q(FifoWData[26]), .QN(n262) );
  DFFRX1 FifoWData_reg_27_ ( .D(n303), .CK(CLK), .RN(RESETn), .Q(FifoWData[27]), .QN(n263) );
  DFFRX1 FifoWData_reg_28_ ( .D(n304), .CK(CLK), .RN(RESETn), .Q(FifoWData[28]), .QN(n264) );
  DFFRX1 FifoWData_reg_29_ ( .D(n305), .CK(CLK), .RN(RESETn), .Q(FifoWData[29]), .QN(n265) );
  DFFRX1 FifoWData_reg_30_ ( .D(n306), .CK(CLK), .RN(RESETn), .Q(FifoWData[30]), .QN(n267) );
  DFFRX1 FifoWData_reg_31_ ( .D(n307), .CK(CLK), .RN(RESETn), .Q(FifoWData[31]), .QN(n268) );
  INVX1 U719 ( .A(n545), .Y(n531) );
  INVX1 U720 ( .A(n496), .Y(n426) );
  INVX1 U721 ( .A(n512), .Y(n420) );
  INVX1 U722 ( .A(n508), .Y(n414) );
  INVX1 U723 ( .A(n500), .Y(n499) );
  INVX1 U724 ( .A(n452), .Y(n450) );
  INVX1 U725 ( .A(n401), .Y(n463) );
  NAND2BX1 U726 ( .AN(n562), .B(n528), .Y(n533) );
  NAND2BX1 U727 ( .AN(n564), .B(n707), .Y(n575) );
  NAND2BX1 U728 ( .AN(n549), .B(n708), .Y(n574) );
  NAND2BX1 U729 ( .AN(n644), .B(n522), .Y(n545) );
  NAND2BX1 U730 ( .AN(n532), .B(n553), .Y(n550) );
  INVX1 U731 ( .A(n624), .Y(n569) );
  NAND2BX1 U732 ( .AN(n562), .B(n566), .Y(n624) );
  INVX1 U733 ( .A(n621), .Y(n573) );
  NAND2BX1 U734 ( .AN(n550), .B(n708), .Y(n621) );
  OAI32X1 U735 ( .A0(n564), .A1(n706), .A2(n642), .B0(n565), .B1(n706), .Y(
        n528) );
  OAI32X1 U736 ( .A0(n564), .A1(n706), .A2(n642), .B0(n565), .B1(n706), .Y(
        n709) );
  INVX1 U737 ( .A(n522), .Y(n392) );
  INVX1 U738 ( .A(n549), .Y(n554) );
  INVX1 U739 ( .A(n543), .Y(n536) );
  OAI32X1 U740 ( .A0(n544), .A1(n545), .A2(n546), .B0(n544), .B1(n547), .Y(
        n543) );
  INVX1 U741 ( .A(n710), .Y(n544) );
  OAI32X1 U742 ( .A0(n564), .A1(n706), .A2(n642), .B0(n565), .B1(n706), .Y(
        n710) );
  INVX1 U743 ( .A(n548), .Y(n534) );
  OAI31X1 U744 ( .A0(n544), .A1(n549), .A2(n645), .B0(n530), .Y(n548) );
  INVX1 U745 ( .A(n625), .Y(n565) );
  OAI221X1 U746 ( .A0(n522), .A1(n546), .B0(n522), .B1(n532), .C0(n545), .Y(
        n625) );
  DFFSX1 BitCounter_reg_0_ ( .D(n374), .CK(CLK), .SN(RESETn), .Q(BitCounter_0_), .QN(n654) );
  NAND3BX1 U747 ( .AN(n713), .B(n654), .C(n712), .Y(n512) );
  NAND3BX1 U748 ( .AN(n712), .B(n654), .C(n713), .Y(n508) );
  NAND3BX1 U749 ( .AN(n713), .B(n643), .C(n654), .Y(n496) );
  NAND2BX1 U750 ( .AN(n459), .B(n475), .Y(n500) );
  NAND2BX1 U751 ( .AN(n459), .B(n429), .Y(n452) );
  NAND2BX1 U752 ( .AN(n459), .B(n426), .Y(n401) );
  NAND2BX1 U753 ( .AN(n514), .B(n711), .Y(n424) );
  NAND2BX1 U754 ( .AN(n512), .B(n711), .Y(n421) );
  NAND2BX1 U755 ( .AN(n510), .B(n711), .Y(n418) );
  NAND2BX1 U756 ( .AN(n508), .B(n711), .Y(n415) );
  NAND2BX1 U757 ( .AN(n506), .B(n711), .Y(n412) );
  NAND2BX1 U758 ( .AN(n504), .B(n711), .Y(n409) );
  NAND2BX1 U759 ( .AN(n501), .B(n711), .Y(n406) );
  NAND2BX1 U760 ( .AN(n496), .B(n711), .Y(n427) );
  INVX1 U761 ( .A(n516), .Y(n475) );
  INVX1 U762 ( .A(n461), .Y(n429) );
  INVX1 U763 ( .A(BCLKRise), .Y(n391) );
  INVX1 U764 ( .A(n405), .Y(n402) );
  INVX1 U765 ( .A(n478), .Y(n476) );
  INVX1 U766 ( .A(n432), .Y(n430) );
  INVX1 U767 ( .A(n488), .Y(n486) );
  INVX1 U768 ( .A(n467), .Y(n465) );
  INVX1 U769 ( .A(n442), .Y(n440) );
  INVX1 U770 ( .A(n510), .Y(n417) );
  INVX1 U771 ( .A(n506), .Y(n411) );
  INVX1 U772 ( .A(n514), .Y(n423) );
  INVX1 U773 ( .A(n501), .Y(n404) );
  OR2X1 U1_B_2 ( .A(n713), .B(carry_2_), .Y(carry_3_) );
  INVX1 U774 ( .A(n504), .Y(n408) );
  OAI222X1 U775 ( .A0(n402), .A1(n653), .B0(n404), .B1(n653), .C0(n405), .C1(
        n406), .Y(n373) );
  OAI222X1 U776 ( .A0(n402), .A1(n635), .B0(n426), .B1(n635), .C0(n405), .C1(
        n427), .Y(n366) );
  OAI222X1 U777 ( .A0(n402), .A1(n636), .B0(n423), .B1(n636), .C0(n405), .C1(
        n424), .Y(n367) );
  OAI222X1 U778 ( .A0(n402), .A1(n637), .B0(n420), .B1(n637), .C0(n405), .C1(
        n421), .Y(n368) );
  OAI222X1 U779 ( .A0(n402), .A1(n638), .B0(n417), .B1(n638), .C0(n405), .C1(
        n418), .Y(n369) );
  OAI222X1 U780 ( .A0(n402), .A1(n639), .B0(n414), .B1(n639), .C0(n405), .C1(
        n415), .Y(n370) );
  OAI222X1 U781 ( .A0(n402), .A1(n640), .B0(n411), .B1(n640), .C0(n405), .C1(
        n412), .Y(n371) );
  OAI222X1 U782 ( .A0(n402), .A1(n641), .B0(n408), .B1(n641), .C0(n405), .C1(
        n409), .Y(n372) );
  OAI222X1 U783 ( .A0(n465), .A1(n646), .B0(n426), .B1(n646), .C0(n427), .C1(
        n467), .Y(n334) );
  OAI222X1 U784 ( .A0(n465), .A1(n647), .B0(n423), .B1(n647), .C0(n424), .C1(
        n467), .Y(n335) );
  OAI222X1 U785 ( .A0(n465), .A1(n648), .B0(n420), .B1(n648), .C0(n421), .C1(
        n467), .Y(n336) );
  OAI222X1 U786 ( .A0(n465), .A1(n649), .B0(n417), .B1(n649), .C0(n418), .C1(
        n467), .Y(n337) );
  OAI222X1 U787 ( .A0(n465), .A1(n650), .B0(n414), .B1(n650), .C0(n415), .C1(
        n467), .Y(n338) );
  OAI222X1 U788 ( .A0(n465), .A1(n651), .B0(n411), .B1(n651), .C0(n412), .C1(
        n467), .Y(n339) );
  OAI222X1 U789 ( .A0(n465), .A1(n652), .B0(n408), .B1(n652), .C0(n409), .C1(
        n467), .Y(n340) );
  OAI222X1 U790 ( .A0(n465), .A1(n645), .B0(n404), .B1(n645), .C0(n406), .C1(
        n467), .Y(n341) );
  OAI222X1 U791 ( .A0(n430), .A1(n659), .B0(n426), .B1(n659), .C0(n427), .C1(
        n432), .Y(n358) );
  OAI222X1 U792 ( .A0(n430), .A1(n660), .B0(n423), .B1(n660), .C0(n424), .C1(
        n432), .Y(n359) );
  OAI222X1 U793 ( .A0(n430), .A1(n661), .B0(n420), .B1(n661), .C0(n421), .C1(
        n432), .Y(n360) );
  OAI222X1 U794 ( .A0(n430), .A1(n662), .B0(n417), .B1(n662), .C0(n418), .C1(
        n432), .Y(n361) );
  OAI222X1 U795 ( .A0(n430), .A1(n663), .B0(n414), .B1(n663), .C0(n415), .C1(
        n432), .Y(n362) );
  OAI222X1 U796 ( .A0(n430), .A1(n664), .B0(n411), .B1(n664), .C0(n412), .C1(
        n432), .Y(n363) );
  OAI222X1 U797 ( .A0(n430), .A1(n665), .B0(n408), .B1(n665), .C0(n409), .C1(
        n432), .Y(n364) );
  OAI222X1 U798 ( .A0(n430), .A1(n666), .B0(n404), .B1(n666), .C0(n406), .C1(
        n432), .Y(n365) );
  OAI222X1 U799 ( .A0(n486), .A1(n667), .B0(n426), .B1(n667), .C0(n427), .C1(
        n488), .Y(n318) );
  OAI222X1 U800 ( .A0(n486), .A1(n668), .B0(n423), .B1(n668), .C0(n424), .C1(
        n488), .Y(n319) );
  OAI222X1 U801 ( .A0(n486), .A1(n669), .B0(n420), .B1(n669), .C0(n421), .C1(
        n488), .Y(n320) );
  OAI222X1 U802 ( .A0(n486), .A1(n670), .B0(n417), .B1(n670), .C0(n418), .C1(
        n488), .Y(n321) );
  OAI222X1 U803 ( .A0(n486), .A1(n671), .B0(n414), .B1(n671), .C0(n415), .C1(
        n488), .Y(n322) );
  OAI222X1 U804 ( .A0(n486), .A1(n672), .B0(n411), .B1(n672), .C0(n412), .C1(
        n488), .Y(n323) );
  OAI222X1 U805 ( .A0(n486), .A1(n673), .B0(n408), .B1(n673), .C0(n409), .C1(
        n488), .Y(n324) );
  OAI222X1 U806 ( .A0(n486), .A1(n674), .B0(n404), .B1(n674), .C0(n406), .C1(
        n488), .Y(n325) );
  OAI222X1 U807 ( .A0(n476), .A1(n675), .B0(n426), .B1(n675), .C0(n427), .C1(
        n478), .Y(n3260) );
  OAI222X1 U808 ( .A0(n476), .A1(n676), .B0(n423), .B1(n676), .C0(n424), .C1(
        n478), .Y(n327) );
  OAI222X1 U809 ( .A0(n476), .A1(n677), .B0(n420), .B1(n677), .C0(n421), .C1(
        n478), .Y(n328) );
  OAI222X1 U810 ( .A0(n476), .A1(n678), .B0(n417), .B1(n678), .C0(n418), .C1(
        n478), .Y(n329) );
  OAI222X1 U811 ( .A0(n476), .A1(n679), .B0(n414), .B1(n679), .C0(n415), .C1(
        n478), .Y(n330) );
  OAI222X1 U812 ( .A0(n476), .A1(n680), .B0(n411), .B1(n680), .C0(n412), .C1(
        n478), .Y(n331) );
  OAI222X1 U813 ( .A0(n476), .A1(n681), .B0(n408), .B1(n681), .C0(n409), .C1(
        n478), .Y(n332) );
  OAI222X1 U814 ( .A0(n476), .A1(n682), .B0(n404), .B1(n682), .C0(n406), .C1(
        n478), .Y(n333) );
  INVX1 U815 ( .A(n393), .Y(n394) );
  INVX1 U816 ( .A(n711), .Y(n460) );
  NAND3BX1 U817 ( .AN(n532), .B(WordLength[0]), .C(n392), .Y(n562) );
  NAND2BX1 U818 ( .AN(LRCLK), .B(NewChannelStart), .Y(n522) );
  NAND2BX1 U819 ( .AN(WordLength[1]), .B(n392), .Y(n547) );
  NAND2BX1 U820 ( .AN(WordLength[0]), .B(n531), .Y(n549) );
  INVX1 U821 ( .A(n633), .Y(n553) );
  NAND2BX1 U822 ( .AN(WordLength[0]), .B(n392), .Y(n633) );
  OAI32X1 U823 ( .A0(n564), .A1(DataState), .A2(n706), .B0(n565), .B1(n706), 
        .Y(n708) );
  OAI32X1 U824 ( .A0(n564), .A1(DataState), .A2(n706), .B0(n565), .B1(n706), 
        .Y(n707) );
  OAI32X1 U825 ( .A0(n564), .A1(DataState), .A2(n706), .B0(n565), .B1(n706), 
        .Y(n566) );
  NAND2BX1 U826 ( .AN(WordLength[1]), .B(n553), .Y(n564) );
  AO22X1 U827 ( .A0(n531), .A1(WordLength[0]), .B0(n563), .B1(WordLength[0]), 
        .Y(n552) );
  INVX1 U828 ( .A(n547), .Y(n563) );
  INVX1 U829 ( .A(n622), .Y(n572) );
  NAND3BX1 U830 ( .AN(n547), .B(WordLength[0]), .C(n566), .Y(n622) );
  NAND3BX1 U831 ( .AN(n550), .B(LeftData[31]), .C(n709), .Y(n530) );
  INVX1 U832 ( .A(n623), .Y(n570) );
  NAND3BX1 U833 ( .AN(n545), .B(WordLength[0]), .C(n707), .Y(n623) );
  OAI211X1 U834 ( .A0(n528), .A1(n260), .B0(n534), .C0(n542), .Y(n300) );
  OA22X1 U835 ( .A0(n536), .A1(n646), .B0(n635), .B1(n533), .Y(n542) );
  OAI211X1 U836 ( .A0(n709), .A1(n261), .B0(n534), .C0(n541), .Y(n301) );
  OA22X1 U837 ( .A0(n536), .A1(n647), .B0(n636), .B1(n533), .Y(n541) );
  OAI211X1 U838 ( .A0(n528), .A1(n262), .B0(n534), .C0(n540), .Y(n302) );
  OA22X1 U839 ( .A0(n536), .A1(n648), .B0(n637), .B1(n533), .Y(n540) );
  OAI211X1 U840 ( .A0(n709), .A1(n263), .B0(n534), .C0(n539), .Y(n303) );
  OA22X1 U841 ( .A0(n536), .A1(n649), .B0(n638), .B1(n533), .Y(n539) );
  OAI211X1 U842 ( .A0(n709), .A1(n264), .B0(n534), .C0(n538), .Y(n304) );
  OA22X1 U843 ( .A0(n536), .A1(n650), .B0(n639), .B1(n533), .Y(n538) );
  OAI211X1 U844 ( .A0(n528), .A1(n265), .B0(n534), .C0(n537), .Y(n305) );
  OA22X1 U845 ( .A0(n536), .A1(n651), .B0(n640), .B1(n533), .Y(n537) );
  OAI211X1 U846 ( .A0(n528), .A1(n267), .B0(n534), .C0(n535), .Y(n306) );
  OA22X1 U847 ( .A0(n536), .A1(n652), .B0(n641), .B1(n533), .Y(n535) );
  INVX1 U848 ( .A(WordLength[0]), .Y(n546) );
  OAI222X1 U849 ( .A0(n528), .A1(n251), .B0(n544), .B1(n561), .C0(n659), .C1(
        n533), .Y(n292) );
  AOI222X1 U850 ( .A0(RightData[16]), .A1(n552), .B0(n553), .B1(LeftData[24]), 
        .C0(n554), .C1(RightData[24]), .Y(n561) );
  OAI222X1 U851 ( .A0(n709), .A1(n252), .B0(n544), .B1(n560), .C0(n660), .C1(
        n533), .Y(n293) );
  AOI222X1 U852 ( .A0(RightData[17]), .A1(n552), .B0(n553), .B1(LeftData[25]), 
        .C0(n554), .C1(RightData[25]), .Y(n560) );
  OAI222X1 U853 ( .A0(n709), .A1(n253), .B0(n544), .B1(n559), .C0(n661), .C1(
        n533), .Y(n294) );
  AOI222X1 U854 ( .A0(RightData[18]), .A1(n552), .B0(n553), .B1(LeftData[26]), 
        .C0(n554), .C1(RightData[26]), .Y(n559) );
  OAI222X1 U855 ( .A0(n528), .A1(n254), .B0(n544), .B1(n558), .C0(n662), .C1(
        n533), .Y(n295) );
  AOI222X1 U856 ( .A0(RightData[19]), .A1(n552), .B0(n553), .B1(LeftData[27]), 
        .C0(n554), .C1(RightData[27]), .Y(n558) );
  OAI222X1 U857 ( .A0(n528), .A1(n256), .B0(n544), .B1(n557), .C0(n663), .C1(
        n533), .Y(n296) );
  AOI222X1 U858 ( .A0(RightData[20]), .A1(n552), .B0(n553), .B1(LeftData[28]), 
        .C0(n554), .C1(RightData[28]), .Y(n557) );
  OAI222X1 U859 ( .A0(n709), .A1(n257), .B0(n544), .B1(n556), .C0(n664), .C1(
        n533), .Y(n297) );
  AOI222X1 U860 ( .A0(RightData[21]), .A1(n552), .B0(n553), .B1(LeftData[29]), 
        .C0(n554), .C1(RightData[29]), .Y(n556) );
  OAI222X1 U861 ( .A0(n528), .A1(n258), .B0(n544), .B1(n555), .C0(n665), .C1(
        n533), .Y(n298) );
  AOI222X1 U862 ( .A0(RightData[22]), .A1(n552), .B0(n553), .B1(LeftData[30]), 
        .C0(n554), .C1(RightData[30]), .Y(n555) );
  OAI222X1 U863 ( .A0(n528), .A1(n259), .B0(n544), .B1(n551), .C0(n666), .C1(
        n533), .Y(n299) );
  AOI222X1 U864 ( .A0(RightData[23]), .A1(n552), .B0(n553), .B1(LeftData[31]), 
        .C0(n554), .C1(RightData[31]), .Y(n551) );
  INVX1 U865 ( .A(WordLength[1]), .Y(n532) );
  AO22X1 U866 ( .A0(FifoAfford2Write), .A1(n308), .B0(RealEnabled), .B1(n628), 
        .Y(N326) );
  OAI222X1 U867 ( .A0(n655), .A1(n545), .B0(n546), .B1(n547), .C0(n642), .C1(
        n564), .Y(n628) );
  OAI211X1 U868 ( .A0(n707), .A1(n244), .B0(n618), .C0(n619), .Y(n276) );
  OA22X1 U869 ( .A0(n667), .A1(n574), .B0(n635), .B1(n575), .Y(n618) );
  AOI221X1 U870 ( .A0(n569), .A1(LeftData[0]), .B0(n570), .B1(RightData[0]), 
        .C0(n620), .Y(n619) );
  AO22X1 U871 ( .A0(n572), .A1(LeftData[16]), .B0(n573), .B1(LeftData[8]), .Y(
        n620) );
  OAI211X1 U872 ( .A0(n566), .A1(n255), .B0(n615), .C0(n616), .Y(n277) );
  OA22X1 U873 ( .A0(n668), .A1(n574), .B0(n636), .B1(n575), .Y(n615) );
  AOI221X1 U874 ( .A0(n569), .A1(LeftData[1]), .B0(n570), .B1(RightData[1]), 
        .C0(n617), .Y(n616) );
  AO22X1 U875 ( .A0(n572), .A1(LeftData[17]), .B0(n573), .B1(LeftData[9]), .Y(
        n617) );
  OAI211X1 U876 ( .A0(n708), .A1(n266), .B0(n612), .C0(n613), .Y(n278) );
  OA22X1 U877 ( .A0(n669), .A1(n574), .B0(n637), .B1(n575), .Y(n612) );
  AOI221X1 U878 ( .A0(n569), .A1(LeftData[2]), .B0(n570), .B1(RightData[2]), 
        .C0(n614), .Y(n613) );
  AO22X1 U879 ( .A0(n572), .A1(LeftData[18]), .B0(n573), .B1(LeftData[10]), 
        .Y(n614) );
  OAI211X1 U880 ( .A0(n707), .A1(n269), .B0(n609), .C0(n610), .Y(n279) );
  OA22X1 U881 ( .A0(n670), .A1(n574), .B0(n638), .B1(n575), .Y(n609) );
  AOI221X1 U882 ( .A0(n569), .A1(LeftData[3]), .B0(n570), .B1(RightData[3]), 
        .C0(n611), .Y(n610) );
  AO22X1 U883 ( .A0(n572), .A1(LeftData[19]), .B0(n573), .B1(LeftData[11]), 
        .Y(n611) );
  OAI211X1 U884 ( .A0(n566), .A1(n270), .B0(n606), .C0(n607), .Y(n280) );
  OA22X1 U885 ( .A0(n671), .A1(n574), .B0(n639), .B1(n575), .Y(n606) );
  AOI221X1 U886 ( .A0(n569), .A1(LeftData[4]), .B0(n570), .B1(RightData[4]), 
        .C0(n608), .Y(n607) );
  AO22X1 U887 ( .A0(n572), .A1(LeftData[20]), .B0(n573), .B1(LeftData[12]), 
        .Y(n608) );
  OAI211X1 U888 ( .A0(n708), .A1(n271), .B0(n603), .C0(n604), .Y(n281) );
  OA22X1 U889 ( .A0(n672), .A1(n574), .B0(n640), .B1(n575), .Y(n603) );
  AOI221X1 U890 ( .A0(n569), .A1(LeftData[5]), .B0(n570), .B1(RightData[5]), 
        .C0(n605), .Y(n604) );
  AO22X1 U891 ( .A0(n572), .A1(LeftData[21]), .B0(n573), .B1(LeftData[13]), 
        .Y(n605) );
  OAI211X1 U892 ( .A0(n707), .A1(n272), .B0(n600), .C0(n601), .Y(n282) );
  OA22X1 U893 ( .A0(n673), .A1(n574), .B0(n641), .B1(n575), .Y(n600) );
  AOI221X1 U894 ( .A0(n569), .A1(LeftData[6]), .B0(n570), .B1(RightData[6]), 
        .C0(n602), .Y(n601) );
  AO22X1 U895 ( .A0(n572), .A1(LeftData[22]), .B0(n573), .B1(LeftData[14]), 
        .Y(n602) );
  OAI211X1 U896 ( .A0(n566), .A1(n273), .B0(n597), .C0(n598), .Y(n283) );
  OA22X1 U897 ( .A0(n674), .A1(n574), .B0(n653), .B1(n575), .Y(n597) );
  AOI221X1 U898 ( .A0(n569), .A1(LeftData[7]), .B0(n570), .B1(RightData[7]), 
        .C0(n599), .Y(n598) );
  AO22X1 U899 ( .A0(n572), .A1(LeftData[23]), .B0(n573), .B1(LeftData[15]), 
        .Y(n599) );
  OAI211X1 U900 ( .A0(n708), .A1(n274), .B0(n594), .C0(n595), .Y(n284) );
  OA22X1 U901 ( .A0(n675), .A1(n574), .B0(n646), .B1(n575), .Y(n594) );
  AOI221X1 U902 ( .A0(n569), .A1(LeftData[8]), .B0(n570), .B1(RightData[8]), 
        .C0(n596), .Y(n595) );
  AO22X1 U903 ( .A0(n572), .A1(LeftData[24]), .B0(n573), .B1(LeftData[16]), 
        .Y(n596) );
  OAI211X1 U904 ( .A0(n707), .A1(n275), .B0(n591), .C0(n592), .Y(n285) );
  OA22X1 U905 ( .A0(n676), .A1(n574), .B0(n647), .B1(n575), .Y(n591) );
  AOI221X1 U906 ( .A0(n569), .A1(LeftData[9]), .B0(n570), .B1(RightData[9]), 
        .C0(n593), .Y(n592) );
  AO22X1 U907 ( .A0(n572), .A1(LeftData[25]), .B0(n573), .B1(LeftData[17]), 
        .Y(n593) );
  OAI211X1 U908 ( .A0(n566), .A1(n245), .B0(n588), .C0(n589), .Y(n286) );
  OA22X1 U909 ( .A0(n677), .A1(n574), .B0(n648), .B1(n575), .Y(n588) );
  AOI221X1 U910 ( .A0(n569), .A1(LeftData[10]), .B0(n570), .B1(RightData[10]), 
        .C0(n590), .Y(n589) );
  AO22X1 U911 ( .A0(n572), .A1(LeftData[26]), .B0(n573), .B1(LeftData[18]), 
        .Y(n590) );
  OAI211X1 U912 ( .A0(n708), .A1(n246), .B0(n585), .C0(n586), .Y(n287) );
  OA22X1 U913 ( .A0(n678), .A1(n574), .B0(n649), .B1(n575), .Y(n585) );
  AOI221X1 U914 ( .A0(n569), .A1(LeftData[11]), .B0(n570), .B1(RightData[11]), 
        .C0(n587), .Y(n586) );
  AO22X1 U915 ( .A0(n572), .A1(LeftData[27]), .B0(n573), .B1(LeftData[19]), 
        .Y(n587) );
  OAI211X1 U916 ( .A0(n707), .A1(n247), .B0(n582), .C0(n583), .Y(n288) );
  OA22X1 U917 ( .A0(n679), .A1(n574), .B0(n650), .B1(n575), .Y(n582) );
  AOI221X1 U918 ( .A0(n569), .A1(LeftData[12]), .B0(n570), .B1(RightData[12]), 
        .C0(n584), .Y(n583) );
  AO22X1 U919 ( .A0(n572), .A1(LeftData[28]), .B0(n573), .B1(LeftData[20]), 
        .Y(n584) );
  OAI211X1 U920 ( .A0(n566), .A1(n248), .B0(n579), .C0(n580), .Y(n289) );
  OA22X1 U921 ( .A0(n680), .A1(n574), .B0(n651), .B1(n575), .Y(n579) );
  AOI221X1 U922 ( .A0(n569), .A1(LeftData[13]), .B0(n570), .B1(RightData[13]), 
        .C0(n581), .Y(n580) );
  AO22X1 U923 ( .A0(n572), .A1(LeftData[29]), .B0(n573), .B1(LeftData[21]), 
        .Y(n581) );
  OAI211X1 U924 ( .A0(n708), .A1(n249), .B0(n576), .C0(n577), .Y(n290) );
  OA22X1 U925 ( .A0(n681), .A1(n574), .B0(n652), .B1(n575), .Y(n576) );
  AOI221X1 U926 ( .A0(n569), .A1(LeftData[14]), .B0(n570), .B1(RightData[14]), 
        .C0(n578), .Y(n577) );
  AO22X1 U927 ( .A0(n572), .A1(LeftData[30]), .B0(n573), .B1(LeftData[22]), 
        .Y(n578) );
  OAI211X1 U928 ( .A0(n708), .A1(n250), .B0(n567), .C0(n568), .Y(n291) );
  OA22X1 U929 ( .A0(n682), .A1(n574), .B0(n645), .B1(n575), .Y(n567) );
  AOI221X1 U930 ( .A0(n569), .A1(LeftData[15]), .B0(n570), .B1(RightData[15]), 
        .C0(n571), .Y(n568) );
  AO22X1 U931 ( .A0(n572), .A1(LeftData[31]), .B0(n573), .B1(LeftData[23]), 
        .Y(n571) );
  AO21X1 U932 ( .A0(n526), .A1(LeftData[31]), .B0(n527), .Y(n307) );
  INVX1 U933 ( .A(n533), .Y(n526) );
  OAI211X1 U934 ( .A0(n709), .A1(n268), .B0(n529), .C0(n530), .Y(n527) );
  OAI211X1 U935 ( .A0(n531), .A1(n532), .B0(RightData[31]), .C0(n709), .Y(n529) );
  NAND3BX1 U936 ( .AN(n656), .B(n3870), .C(n429), .Y(n405) );
  NAND3BX1 U937 ( .AN(BitCounter_4_), .B(n3870), .C(n475), .Y(n488) );
  NAND3BX1 U938 ( .AN(n3870), .B(BitCounter_4_), .C(n475), .Y(n478) );
  NAND3BX1 U939 ( .AN(n656), .B(n3870), .C(n475), .Y(n467) );
  NAND3BX1 U940 ( .AN(BitCounter_4_), .B(n3870), .C(n429), .Y(n442) );
  NAND3BX1 U941 ( .AN(n3870), .B(BitCounter_4_), .C(n429), .Y(n432) );
  AO21X1 U942 ( .A0(BCLKRise), .A1(n401), .B0(NewChannelStart), .Y(n393) );
  NAND3BX1 U943 ( .AN(n713), .B(n643), .C(BitCounter_0_), .Y(n514) );
  NAND3X1 U944 ( .A(n713), .B(n712), .C(BitCounter_0_), .Y(n501) );
  NAND3BX1 U945 ( .AN(n713), .B(BitCounter_0_), .C(n712), .Y(n510) );
  NAND3BX1 U946 ( .AN(n712), .B(BitCounter_0_), .C(n713), .Y(n506) );
  NAND3BX1 U947 ( .AN(BitCounter_0_), .B(n713), .C(n712), .Y(n504) );
  NAND2BX1 U948 ( .AN(FifoFull), .B(FifoWriteEn), .Y(nFifoWriteEn) );
  NAND3X1 U949 ( .A(BitCounterValid), .B(LeftRight), .C(BCLKRise), .Y(n516) );
  NAND3BX1 U950 ( .AN(LeftRight), .B(BitCounterValid), .C(BCLKRise), .Y(n461)
         );
  BUFX2 U951 ( .A(n497), .Y(n711) );
  AO22X1 U952 ( .A0(LeftJust), .A1(SDIN1d), .B0(SDIN), .B1(n520), .Y(n497) );
  INVX1 U953 ( .A(LeftJust), .Y(n520) );
  NAND2BX1 U954 ( .AN(n3870), .B(n656), .Y(n459) );
  BUFX2 U955 ( .A(n384), .Y(n712) );
  BUFX2 U956 ( .A(n385), .Y(n713) );
  NOR2BX1 U957 ( .AN(n521), .B(SyncReset), .Y(n309) );
  OAI31X1 U958 ( .A0(n522), .A1(DataState), .A2(n706), .B0(n524), .Y(n521) );
  OA22X1 U959 ( .A0(RealEnabled), .A1(n642), .B0(n392), .B1(n642), .Y(n524) );
  OAI22X1 U960 ( .A0(n550), .A1(n706), .B0(n562), .B1(n706), .Y(n308) );
  OAI33X1 U961 ( .A0(n706), .A1(FifoWriteEn), .A2(n644), .B0(n706), .B1(n655), 
        .B2(n634), .Y(FifoOverRun) );
  INVX1 U962 ( .A(FifoFull), .Y(n634) );
  OR2X1 U1_B_1 ( .A(n712), .B(BitCounter_0_), .Y(carry_2_) );
  NAND2BX1 U963 ( .AN(NewChannelStart), .B(n399), .Y(n374) );
  XOR2X1 U964 ( .A(n654), .B(n393), .Y(n399) );
  OAI33X1 U965 ( .A0(n391), .A1(LeftRight), .A2(n626), .B0(n391), .B1(LRCLK), 
        .B2(n705), .Y(N35) );
  INVX1 U966 ( .A(LRCLK), .Y(n626) );
  OAI222X1 U967 ( .A0(n440), .A1(n683), .B0(n426), .B1(n683), .C0(n427), .C1(
        n442), .Y(n350) );
  OAI222X1 U968 ( .A0(n440), .A1(n684), .B0(n423), .B1(n684), .C0(n424), .C1(
        n442), .Y(n351) );
  OAI222X1 U969 ( .A0(n440), .A1(n685), .B0(n420), .B1(n685), .C0(n421), .C1(
        n442), .Y(n352) );
  OAI222X1 U970 ( .A0(n440), .A1(n686), .B0(n417), .B1(n686), .C0(n418), .C1(
        n442), .Y(n353) );
  OAI222X1 U971 ( .A0(n440), .A1(n687), .B0(n414), .B1(n687), .C0(n415), .C1(
        n442), .Y(n354) );
  OAI222X1 U972 ( .A0(n440), .A1(n688), .B0(n411), .B1(n688), .C0(n412), .C1(
        n442), .Y(n355) );
  OAI222X1 U973 ( .A0(n440), .A1(n689), .B0(n408), .B1(n689), .C0(n409), .C1(
        n442), .Y(n356) );
  OAI222X1 U974 ( .A0(n440), .A1(n690), .B0(n404), .B1(n690), .C0(n406), .C1(
        n442), .Y(n357) );
  OAI222X1 U975 ( .A0(n423), .A1(n691), .B0(n499), .B1(n691), .C0(n424), .C1(
        n500), .Y(n311) );
  OAI222X1 U976 ( .A0(n420), .A1(n692), .B0(n499), .B1(n692), .C0(n421), .C1(
        n500), .Y(n312) );
  OAI222X1 U977 ( .A0(n417), .A1(n693), .B0(n499), .B1(n693), .C0(n418), .C1(
        n500), .Y(n313) );
  OAI222X1 U978 ( .A0(n414), .A1(n694), .B0(n499), .B1(n694), .C0(n415), .C1(
        n500), .Y(n314) );
  OAI222X1 U979 ( .A0(n411), .A1(n695), .B0(n499), .B1(n695), .C0(n412), .C1(
        n500), .Y(n315) );
  OAI222X1 U980 ( .A0(n408), .A1(n696), .B0(n499), .B1(n696), .C0(n409), .C1(
        n500), .Y(n316) );
  OAI222X1 U981 ( .A0(n404), .A1(n697), .B0(n499), .B1(n697), .C0(n406), .C1(
        n500), .Y(n317) );
  OAI222X1 U982 ( .A0(n450), .A1(n698), .B0(n423), .B1(n698), .C0(n424), .C1(
        n452), .Y(n343) );
  OAI222X1 U983 ( .A0(n450), .A1(n699), .B0(n420), .B1(n699), .C0(n421), .C1(
        n452), .Y(n344) );
  OAI222X1 U984 ( .A0(n450), .A1(n700), .B0(n417), .B1(n700), .C0(n418), .C1(
        n452), .Y(n345) );
  OAI222X1 U985 ( .A0(n450), .A1(n701), .B0(n414), .B1(n701), .C0(n415), .C1(
        n452), .Y(n346) );
  OAI222X1 U986 ( .A0(n450), .A1(n702), .B0(n411), .B1(n702), .C0(n412), .C1(
        n452), .Y(n347) );
  OAI222X1 U987 ( .A0(n450), .A1(n703), .B0(n408), .B1(n703), .C0(n409), .C1(
        n452), .Y(n348) );
  OAI222X1 U988 ( .A0(n450), .A1(n704), .B0(n404), .B1(n704), .C0(n406), .C1(
        n452), .Y(n349) );
  AO22X1 U989 ( .A0(LRCLK), .A1(BCLKRise), .B0(LeftRight), .B1(n391), .Y(n381)
         );
  AO22X1 U990 ( .A0(RealEnabled), .A1(Enabled), .B0(Enabled), .B1(n392), .Y(
        n380) );
  AO21X1 U991 ( .A0(n384), .A1(n394), .B0(n398), .Y(n375) );
  AO21X1 U992 ( .A0(N386), .A1(n393), .B0(NewChannelStart), .Y(n398) );
  XNOR2X1 U1_A_1 ( .A(n712), .B(BitCounter_0_), .Y(N386) );
  AO21X1 U993 ( .A0(n385), .A1(n394), .B0(n397), .Y(n376) );
  AO21X1 U994 ( .A0(N387), .A1(n393), .B0(NewChannelStart), .Y(n397) );
  XNOR2X1 U1_A_2 ( .A(n713), .B(carry_2_), .Y(N387) );
  AO21X1 U995 ( .A0(n3870), .A1(n394), .B0(n396), .Y(n377) );
  AO21X1 U996 ( .A0(N388), .A1(n393), .B0(NewChannelStart), .Y(n396) );
  XNOR2X1 U1_A_3 ( .A(n3870), .B(carry_3_), .Y(N388) );
  AO21X1 U997 ( .A0(BitCounter_4_), .A1(n394), .B0(n395), .Y(n378) );
  AO21X1 U998 ( .A0(N389), .A1(n393), .B0(NewChannelStart), .Y(n395) );
  XNOR2X1 U1_A_4 ( .A(BitCounter_4_), .B(carry_4_), .Y(N389) );
  OR2X1 U1_B_3 ( .A(n3870), .B(carry_3_), .Y(carry_4_) );
  AO21X1 U999 ( .A0(BitCounterValid), .A1(n391), .B0(n393), .Y(n379) );
  OAI31X1 U1000 ( .A0(n401), .A1(n460), .A2(n516), .B0(n517), .Y(n310) );
  OA22X1 U1001 ( .A0(n463), .A1(n657), .B0(n475), .B1(n657), .Y(n517) );
  OAI31X1 U1002 ( .A0(n401), .A1(n460), .A2(n461), .B0(n462), .Y(n342) );
  OA22X1 U1003 ( .A0(n463), .A1(n658), .B0(n429), .B1(n658), .Y(n462) );
  AO22X1 U1004 ( .A0(SDIN), .A1(BCLKRise), .B0(SDIN1d), .B1(n391), .Y(n382) );
  DFFRX1 NewChannelStart_reg ( .D(N35), .CK(CLK), .RN(RESETn), .Q(
        NewChannelStart) );
  DFFRX1 RightSave_reg ( .D(n308), .CK(CLK), .RN(RESETn), .QN(n644) );
  DFFSX1 BitCounter_reg_4_ ( .D(n378), .CK(CLK), .SN(RESETn), .Q(BitCounter_4_), .QN(n656) );
  DFFSX1 BitCounter_reg_3_ ( .D(n377), .CK(CLK), .SN(RESETn), .Q(n3870) );
  DFFRX1 RealEnabled_reg ( .D(n380), .CK(CLK), .RN(RESETn), .Q(RealEnabled), 
        .QN(n706) );
  DFFRX1 LeftData_reg_31_ ( .D(n373), .CK(CLK), .RN(RESETn), .Q(LeftData[31]), 
        .QN(n653) );
  DFFRX1 LeftRight_reg ( .D(n381), .CK(CLK), .RN(RESETn), .Q(LeftRight), .QN(
        n705) );
  DFFSX1 BitCounterValid_reg ( .D(n379), .CK(CLK), .SN(RESETn), .Q(
        BitCounterValid) );
  DFFRX1 FifoWriteEn_reg ( .D(N326), .CK(CLK), .RN(RESETn), .Q(FifoWriteEn), 
        .QN(n655) );
  DFFRX1 LeftData_reg_16_ ( .D(n358), .CK(CLK), .RN(RESETn), .Q(LeftData[16]), 
        .QN(n659) );
  DFFRX1 LeftData_reg_17_ ( .D(n359), .CK(CLK), .RN(RESETn), .Q(LeftData[17]), 
        .QN(n660) );
  DFFRX1 LeftData_reg_18_ ( .D(n360), .CK(CLK), .RN(RESETn), .Q(LeftData[18]), 
        .QN(n661) );
  DFFRX1 LeftData_reg_19_ ( .D(n361), .CK(CLK), .RN(RESETn), .Q(LeftData[19]), 
        .QN(n662) );
  DFFRX1 LeftData_reg_20_ ( .D(n362), .CK(CLK), .RN(RESETn), .Q(LeftData[20]), 
        .QN(n663) );
  DFFRX1 LeftData_reg_21_ ( .D(n363), .CK(CLK), .RN(RESETn), .Q(LeftData[21]), 
        .QN(n664) );
  DFFRX1 LeftData_reg_22_ ( .D(n364), .CK(CLK), .RN(RESETn), .Q(LeftData[22]), 
        .QN(n665) );
  DFFRX1 LeftData_reg_23_ ( .D(n365), .CK(CLK), .RN(RESETn), .Q(LeftData[23]), 
        .QN(n666) );
  DFFRX1 DataState_reg ( .D(n309), .CK(CLK), .RN(RESETn), .Q(DataState), .QN(
        n642) );
  DFFRX1 LeftData_reg_24_ ( .D(n366), .CK(CLK), .RN(RESETn), .Q(LeftData[24]), 
        .QN(n635) );
  DFFRX1 LeftData_reg_25_ ( .D(n367), .CK(CLK), .RN(RESETn), .Q(LeftData[25]), 
        .QN(n636) );
  DFFRX1 LeftData_reg_26_ ( .D(n368), .CK(CLK), .RN(RESETn), .Q(LeftData[26]), 
        .QN(n637) );
  DFFRX1 LeftData_reg_27_ ( .D(n369), .CK(CLK), .RN(RESETn), .Q(LeftData[27]), 
        .QN(n638) );
  DFFRX1 LeftData_reg_28_ ( .D(n370), .CK(CLK), .RN(RESETn), .Q(LeftData[28]), 
        .QN(n639) );
  DFFRX1 LeftData_reg_29_ ( .D(n371), .CK(CLK), .RN(RESETn), .Q(LeftData[29]), 
        .QN(n640) );
  DFFRX1 LeftData_reg_30_ ( .D(n372), .CK(CLK), .RN(RESETn), .Q(LeftData[30]), 
        .QN(n641) );
  DFFRX1 LeftData_reg_8_ ( .D(n350), .CK(CLK), .RN(RESETn), .Q(LeftData[8]), 
        .QN(n683) );
  DFFRX1 LeftData_reg_9_ ( .D(n351), .CK(CLK), .RN(RESETn), .Q(LeftData[9]), 
        .QN(n684) );
  DFFRX1 LeftData_reg_10_ ( .D(n352), .CK(CLK), .RN(RESETn), .Q(LeftData[10]), 
        .QN(n685) );
  DFFRX1 LeftData_reg_11_ ( .D(n353), .CK(CLK), .RN(RESETn), .Q(LeftData[11]), 
        .QN(n686) );
  DFFRX1 LeftData_reg_12_ ( .D(n354), .CK(CLK), .RN(RESETn), .Q(LeftData[12]), 
        .QN(n687) );
  DFFRX1 LeftData_reg_13_ ( .D(n355), .CK(CLK), .RN(RESETn), .Q(LeftData[13]), 
        .QN(n688) );
  DFFRX1 LeftData_reg_14_ ( .D(n356), .CK(CLK), .RN(RESETn), .Q(LeftData[14]), 
        .QN(n689) );
  DFFRX1 LeftData_reg_15_ ( .D(n357), .CK(CLK), .RN(RESETn), .Q(LeftData[15]), 
        .QN(n690) );
  DFFRX1 RightData_reg_31_ ( .D(n341), .CK(CLK), .RN(RESETn), .Q(RightData[31]), .QN(n645) );
  DFFSX1 BitCounter_reg_1_ ( .D(n375), .CK(CLK), .SN(RESETn), .Q(n384), .QN(
        n643) );
  DFFSX1 BitCounter_reg_2_ ( .D(n376), .CK(CLK), .SN(RESETn), .Q(n385) );
  DFFRX1 RightData_reg_16_ ( .D(n3260), .CK(CLK), .RN(RESETn), .Q(
        RightData[16]), .QN(n675) );
  DFFRX1 RightData_reg_17_ ( .D(n327), .CK(CLK), .RN(RESETn), .Q(RightData[17]), .QN(n676) );
  DFFRX1 RightData_reg_18_ ( .D(n328), .CK(CLK), .RN(RESETn), .Q(RightData[18]), .QN(n677) );
  DFFRX1 RightData_reg_19_ ( .D(n329), .CK(CLK), .RN(RESETn), .Q(RightData[19]), .QN(n678) );
  DFFRX1 RightData_reg_20_ ( .D(n330), .CK(CLK), .RN(RESETn), .Q(RightData[20]), .QN(n679) );
  DFFRX1 RightData_reg_21_ ( .D(n331), .CK(CLK), .RN(RESETn), .Q(RightData[21]), .QN(n680) );
  DFFRX1 RightData_reg_22_ ( .D(n332), .CK(CLK), .RN(RESETn), .Q(RightData[22]), .QN(n681) );
  DFFRX1 RightData_reg_23_ ( .D(n333), .CK(CLK), .RN(RESETn), .Q(RightData[23]), .QN(n682) );
  DFFRX1 LeftData_reg_0_ ( .D(n342), .CK(CLK), .RN(RESETn), .Q(LeftData[0]), 
        .QN(n658) );
  DFFRX1 LeftData_reg_1_ ( .D(n343), .CK(CLK), .RN(RESETn), .Q(LeftData[1]), 
        .QN(n698) );
  DFFRX1 LeftData_reg_2_ ( .D(n344), .CK(CLK), .RN(RESETn), .Q(LeftData[2]), 
        .QN(n699) );
  DFFRX1 LeftData_reg_3_ ( .D(n345), .CK(CLK), .RN(RESETn), .Q(LeftData[3]), 
        .QN(n700) );
  DFFRX1 LeftData_reg_4_ ( .D(n346), .CK(CLK), .RN(RESETn), .Q(LeftData[4]), 
        .QN(n701) );
  DFFRX1 LeftData_reg_5_ ( .D(n347), .CK(CLK), .RN(RESETn), .Q(LeftData[5]), 
        .QN(n702) );
  DFFRX1 LeftData_reg_6_ ( .D(n348), .CK(CLK), .RN(RESETn), .Q(LeftData[6]), 
        .QN(n703) );
  DFFRX1 LeftData_reg_7_ ( .D(n349), .CK(CLK), .RN(RESETn), .Q(LeftData[7]), 
        .QN(n704) );
  DFFRX1 RightData_reg_24_ ( .D(n334), .CK(CLK), .RN(RESETn), .Q(RightData[24]), .QN(n646) );
  DFFRX1 RightData_reg_25_ ( .D(n335), .CK(CLK), .RN(RESETn), .Q(RightData[25]), .QN(n647) );
  DFFRX1 RightData_reg_26_ ( .D(n336), .CK(CLK), .RN(RESETn), .Q(RightData[26]), .QN(n648) );
  DFFRX1 RightData_reg_27_ ( .D(n337), .CK(CLK), .RN(RESETn), .Q(RightData[27]), .QN(n649) );
  DFFRX1 RightData_reg_28_ ( .D(n338), .CK(CLK), .RN(RESETn), .Q(RightData[28]), .QN(n650) );
  DFFRX1 RightData_reg_29_ ( .D(n339), .CK(CLK), .RN(RESETn), .Q(RightData[29]), .QN(n651) );
  DFFRX1 RightData_reg_30_ ( .D(n340), .CK(CLK), .RN(RESETn), .Q(RightData[30]), .QN(n652) );
  DFFRX1 RightData_reg_0_ ( .D(n310), .CK(CLK), .RN(RESETn), .Q(RightData[0]), 
        .QN(n657) );
  DFFRX1 RightData_reg_1_ ( .D(n311), .CK(CLK), .RN(RESETn), .Q(RightData[1]), 
        .QN(n691) );
  DFFRX1 RightData_reg_2_ ( .D(n312), .CK(CLK), .RN(RESETn), .Q(RightData[2]), 
        .QN(n692) );
  DFFRX1 RightData_reg_3_ ( .D(n313), .CK(CLK), .RN(RESETn), .Q(RightData[3]), 
        .QN(n693) );
  DFFRX1 RightData_reg_4_ ( .D(n314), .CK(CLK), .RN(RESETn), .Q(RightData[4]), 
        .QN(n694) );
  DFFRX1 RightData_reg_5_ ( .D(n315), .CK(CLK), .RN(RESETn), .Q(RightData[5]), 
        .QN(n695) );
  DFFRX1 RightData_reg_6_ ( .D(n316), .CK(CLK), .RN(RESETn), .Q(RightData[6]), 
        .QN(n696) );
  DFFRX1 RightData_reg_7_ ( .D(n317), .CK(CLK), .RN(RESETn), .Q(RightData[7]), 
        .QN(n697) );
  DFFRX1 RightData_reg_8_ ( .D(n318), .CK(CLK), .RN(RESETn), .Q(RightData[8]), 
        .QN(n667) );
  DFFRX1 RightData_reg_9_ ( .D(n319), .CK(CLK), .RN(RESETn), .Q(RightData[9]), 
        .QN(n668) );
  DFFRX1 RightData_reg_10_ ( .D(n320), .CK(CLK), .RN(RESETn), .Q(RightData[10]), .QN(n669) );
  DFFRX1 RightData_reg_11_ ( .D(n321), .CK(CLK), .RN(RESETn), .Q(RightData[11]), .QN(n670) );
  DFFRX1 RightData_reg_12_ ( .D(n322), .CK(CLK), .RN(RESETn), .Q(RightData[12]), .QN(n671) );
  DFFRX1 RightData_reg_13_ ( .D(n323), .CK(CLK), .RN(RESETn), .Q(RightData[13]), .QN(n672) );
  DFFRX1 RightData_reg_14_ ( .D(n324), .CK(CLK), .RN(RESETn), .Q(RightData[14]), .QN(n673) );
  DFFRX1 RightData_reg_15_ ( .D(n325), .CK(CLK), .RN(RESETn), .Q(RightData[15]), .QN(n674) );
  DFFRX1 SDIN1d_reg ( .D(n382), .CK(CLK), .RN(RESETn), .Q(SDIN1d) );
endmodule


module I2S_Serializer ( CLK, RESETn, Enabled, SyncReset, WordLength, LeftJust, 
        FifoUnderRun, FrameStart, RightStart, BCLKFall, SDOUT, FifoData, 
        FifoAfford2Read, FifoEmpty, nFifoReadEn );
  input [1:0] WordLength;
  input [31:0] FifoData;
  input CLK, RESETn, Enabled, SyncReset, LeftJust, FrameStart, RightStart,
         BCLKFall, FifoAfford2Read, FifoEmpty;
  output FifoUnderRun, SDOUT, nFifoReadEn;
  wire   N27, N28, N29, N30, N31, DataRemained, LeftData_31_, LeftData_30_,
         LeftData_29_, LeftData_28_, LeftData_27_, LeftData_26_, LeftData_25_,
         LeftData_24_, LeftData_7_, LeftData_6_, LeftData_5_, LeftData_4_,
         LeftData_3_, LeftData_2_, LeftData_1_, LeftData_0_, RightData_7_,
         RightData_6_, RightData_5_, RightData_4_, RightData_3_, RightData_2_,
         RightData_1_, RightData_0_, RightLoad, N223, LeftRight, N415, N416,
         N417, N418, n178, n179, n180, n181, n182, n183, n184, n185, n186,
         n187, n188, n189, n190, n191, n192, n193, n194, n195, n196, n197,
         n198, n199, n200, n201, n202, n203, n204, n205, n206, n207, n208,
         n209, n210, n211, n212, n213, n214, n215, n216, n217, n218, n219,
         n220, n221, n222, n2230, n224, n225, n226, n227, n228, n229, n230,
         n231, n232, n233, n234, n235, n236, n237, n238, n239, n240, n241,
         n242, n243, n244, n245, n246, n247, n248, n249, n250, n251, n252,
         n253, n254, n255, n256, n257, n258, n259, n260, n261, n262, n263,
         n264, n265, carry_4_, carry_3_, carry_2_, n276, n278, n279, n280,
         n281, n282, n283, n284, n285, n287, n289, n290, n291, n292, n294,
         n295, n296, n297, n298, n300, n301, n303, n304, n306, n307, n309,
         n310, n312, n313, n315, n316, n318, n319, n321, n322, n324, n326,
         n328, n330, n332, n334, n336, n337, n338, n339, n340, n341, n343,
         n345, n347, n349, n351, n353, n355, n357, n358, n359, n360, n361,
         n362, n363, n364, n365, n366, n367, n368, n369, n370, n371, n372,
         n373, n374, n375, n376, n377, n378, n379, n380, n381, n382, n383,
         n384, n385, n386, n387, n388, n389, n390, n391, n392, n394, n396,
         n398, n400, n402, n404, n406, n4160, n4170, n4180, n419, n420, n421,
         n426, n427, n428, n429, n430, n431, n432, n433, n434, n435, n437,
         n439, n441, n442, n443, n444, n447, n448, n449, n450, n452, n454,
         n455, n456, n457, n458, n461, n464, n467, n470, n471, n472, n473,
         n474, n477, n480, n483, n486, n487, n488, n489, n490, n491, n492,
         n493, n494, n495, n496, n497, n498, n499, n500, n501, n502, n505,
         n509, n513, n517, n524, n525, n526, n527, n528, n529, n530, n531,
         n532, n533, n534, n535, n536, n537, n538, n539, n540, n541, n542,
         n543, n544, n545, n546, n547, n548, n549, n550, n551, n552, n553,
         n554, n555, n556, n557, n558, n559, n560, n561, n562, n563, n564,
         n565, n566, n567, n568, n569, n570, n571, n572, n573, n574, n575,
         n576, n577, n578, n579, n580, n581, n582, n583, n584, n585, n586,
         n587, n588, n589, n590, n591, n592, n593, n594, n595, n596, n597,
         n598, n599, n600, n601, n602, n603, n604, n605, n606, n607;
  wire   [15:0] RemainedData;

  INVX1 U573 ( .A(FifoAfford2Read), .Y(n289) );
  INVX1 U574 ( .A(n390), .Y(n365) );
  INVX1 U575 ( .A(n392), .Y(n366) );
  INVX1 U576 ( .A(n603), .Y(n4170) );
  INVX1 U577 ( .A(n295), .Y(n322) );
  INVX1 U578 ( .A(n341), .Y(n338) );
  INVX1 U579 ( .A(n389), .Y(n297) );
  INVX1 U580 ( .A(n607), .Y(nFifoReadEn) );
  NAND2BX1 U581 ( .AN(n4160), .B(n601), .Y(n390) );
  NAND2BX1 U582 ( .AN(n339), .B(n392), .Y(n367) );
  AO21X1 U583 ( .A0(n337), .A1(n604), .B0(n338), .Y(n295) );
  INVX1 U584 ( .A(n339), .Y(n337) );
  NAND2BX1 U585 ( .AN(n4180), .B(n602), .Y(n362) );
  NAND2BX1 U586 ( .AN(n4180), .B(n602), .Y(n603) );
  NAND2BX1 U587 ( .AN(n593), .B(n276), .Y(n389) );
  OAI211X1 U588 ( .A0(n289), .A1(n4180), .B0(n419), .C0(n360), .Y(n392) );
  OAI211X1 U589 ( .A0(n289), .A1(n4180), .B0(n419), .C0(n360), .Y(n602) );
  OAI211X1 U590 ( .A0(n289), .A1(n4180), .B0(n419), .C0(n360), .Y(n601) );
  OAI221X1 U591 ( .A0(n355), .A1(n367), .B0(n316), .B1(n362), .C0(n406), .Y(
        n201) );
  OA22X1 U592 ( .A0(n336), .A1(n390), .B0(n601), .B1(n546), .Y(n406) );
  OAI221X1 U593 ( .A0(n353), .A1(n367), .B0(n313), .B1(n362), .C0(n404), .Y(
        n202) );
  OA22X1 U594 ( .A0(n334), .A1(n390), .B0(n601), .B1(n553), .Y(n404) );
  OAI221X1 U595 ( .A0(n351), .A1(n367), .B0(n310), .B1(n362), .C0(n402), .Y(
        n203) );
  OA22X1 U596 ( .A0(n332), .A1(n390), .B0(n602), .B1(n586), .Y(n402) );
  OAI221X1 U597 ( .A0(n349), .A1(n367), .B0(n307), .B1(n362), .C0(n400), .Y(
        n204) );
  OA22X1 U598 ( .A0(n330), .A1(n390), .B0(n601), .B1(n576), .Y(n400) );
  OAI221X1 U599 ( .A0(n347), .A1(n367), .B0(n304), .B1(n362), .C0(n398), .Y(
        n205) );
  OA22X1 U600 ( .A0(n328), .A1(n390), .B0(n602), .B1(n545), .Y(n398) );
  OAI221X1 U601 ( .A0(n345), .A1(n367), .B0(n301), .B1(n362), .C0(n396), .Y(
        n206) );
  OA22X1 U602 ( .A0(n326), .A1(n390), .B0(n602), .B1(n527), .Y(n396) );
  OAI221X1 U603 ( .A0(n343), .A1(n367), .B0(n298), .B1(n362), .C0(n394), .Y(
        n207) );
  OA22X1 U604 ( .A0(n324), .A1(n390), .B0(n601), .B1(n558), .Y(n394) );
  OAI221X1 U605 ( .A0(n340), .A1(n367), .B0(n290), .B1(n362), .C0(n391), .Y(
        n208) );
  OA22X1 U606 ( .A0(n321), .A1(n390), .B0(n601), .B1(n575), .Y(n391) );
  INVX1 U607 ( .A(n421), .Y(n276) );
  OAI222X1 U608 ( .A0(n600), .A1(n535), .B0(n291), .B1(n336), .C0(n322), .C1(
        n316), .Y(n233) );
  OAI222X1 U609 ( .A0(n600), .A1(n542), .B0(n606), .B1(n334), .C0(n322), .C1(
        n313), .Y(n234) );
  OAI222X1 U610 ( .A0(n604), .A1(n577), .B0(n605), .B1(n332), .C0(n322), .C1(
        n310), .Y(n235) );
  OAI222X1 U611 ( .A0(n600), .A1(n566), .B0(n291), .B1(n330), .C0(n322), .C1(
        n307), .Y(n236) );
  OAI222X1 U612 ( .A0(n604), .A1(n534), .B0(n606), .B1(n328), .C0(n322), .C1(
        n304), .Y(n237) );
  OAI222X1 U613 ( .A0(n600), .A1(n524), .B0(n605), .B1(n326), .C0(n322), .C1(
        n301), .Y(n238) );
  OAI222X1 U614 ( .A0(n604), .A1(n557), .B0(n291), .B1(n324), .C0(n322), .C1(
        n298), .Y(n239) );
  OAI222X1 U615 ( .A0(n600), .A1(n565), .B0(n606), .B1(n321), .C0(n322), .C1(
        n290), .Y(n240) );
  OAI222X1 U616 ( .A0(n355), .A1(n390), .B0(n602), .B1(n536), .C0(n336), .C1(
        n362), .Y(n193) );
  OAI222X1 U617 ( .A0(n353), .A1(n390), .B0(n601), .B1(n571), .C0(n334), .C1(
        n603), .Y(n194) );
  OAI222X1 U618 ( .A0(n351), .A1(n390), .B0(n601), .B1(n525), .C0(n332), .C1(
        n362), .Y(n195) );
  OAI222X1 U619 ( .A0(n349), .A1(n390), .B0(n602), .B1(n567), .C0(n330), .C1(
        n603), .Y(n196) );
  OAI222X1 U620 ( .A0(n347), .A1(n390), .B0(n601), .B1(n537), .C0(n328), .C1(
        n362), .Y(n197) );
  OAI222X1 U621 ( .A0(n345), .A1(n390), .B0(n601), .B1(n543), .C0(n326), .C1(
        n603), .Y(n198) );
  OAI222X1 U622 ( .A0(n343), .A1(n390), .B0(n602), .B1(n578), .C0(n324), .C1(
        n362), .Y(n199) );
  OAI222X1 U623 ( .A0(n340), .A1(n390), .B0(n602), .B1(n568), .C0(n321), .C1(
        n362), .Y(n200) );
  DFFRX1 BitCounter_reg_0_ ( .D(n180), .CK(CLK), .RN(RESETn), .Q(N27) );
  NAND2BX1 U624 ( .AN(n279), .B(n357), .Y(n341) );
  INVX1 U625 ( .A(n359), .Y(n357) );
  INVX1 U626 ( .A(n292), .Y(n358) );
  INVX1 U627 ( .A(n319), .Y(n296) );
  OA22X1 U628 ( .A0(n553), .A1(n457), .B0(n586), .B1(n458), .Y(n464) );
  OA22X1 U629 ( .A0(n543), .A1(n457), .B0(n578), .B1(n458), .Y(n486) );
  OA22X1 U630 ( .A0(n542), .A1(n457), .B0(n577), .B1(n458), .Y(n496) );
  OA22X1 U631 ( .A0(n544), .A1(n457), .B0(n579), .B1(n458), .Y(n497) );
  OA22X1 U632 ( .A0(n540), .A1(n457), .B0(n572), .B1(n458), .Y(n517) );
  OAI222X1 U633 ( .A0(n606), .A1(n355), .B0(n336), .B1(n341), .C0(n292), .C1(
        n532), .Y(n225) );
  OAI222X1 U634 ( .A0(n605), .A1(n353), .B0(n334), .B1(n341), .C0(n604), .C1(
        n541), .Y(n226) );
  OAI222X1 U635 ( .A0(n291), .A1(n351), .B0(n332), .B1(n341), .C0(n292), .C1(
        n573), .Y(n227) );
  OAI222X1 U636 ( .A0(n606), .A1(n349), .B0(n330), .B1(n341), .C0(n600), .C1(
        n563), .Y(n228) );
  OAI222X1 U637 ( .A0(n605), .A1(n347), .B0(n328), .B1(n341), .C0(n292), .C1(
        n533), .Y(n229) );
  OAI222X1 U638 ( .A0(n291), .A1(n345), .B0(n326), .B1(n341), .C0(n604), .C1(
        n540), .Y(n230) );
  OAI222X1 U639 ( .A0(n606), .A1(n343), .B0(n324), .B1(n341), .C0(n292), .C1(
        n572), .Y(n231) );
  OAI222X1 U640 ( .A0(n605), .A1(n340), .B0(n321), .B1(n341), .C0(n600), .C1(
        n564), .Y(n232) );
  OAI221X1 U641 ( .A0(n567), .A1(n455), .B0(n536), .B1(n434), .C0(n480), .Y(
        n473) );
  OA22X1 U642 ( .A0(n571), .A1(n457), .B0(n525), .B1(n458), .Y(n480) );
  OAI221X1 U643 ( .A0(n569), .A1(n455), .B0(n538), .B1(n434), .C0(n495), .Y(
        n492) );
  OA22X1 U644 ( .A0(n574), .A1(n457), .B0(n526), .B1(n458), .Y(n495) );
  OAI221X1 U645 ( .A0(n563), .A1(n455), .B0(n532), .B1(n434), .C0(n509), .Y(
        n501) );
  OA22X1 U646 ( .A0(n541), .A1(n457), .B0(n573), .B1(n458), .Y(n509) );
  OAI221X1 U647 ( .A0(n575), .A1(n455), .B0(n545), .B1(n434), .C0(n456), .Y(
        n454) );
  OA22X1 U648 ( .A0(n527), .A1(n457), .B0(n558), .B1(n458), .Y(n456) );
  OAI221X1 U649 ( .A0(n565), .A1(n455), .B0(n534), .B1(n434), .C0(n494), .Y(
        n493) );
  OA22X1 U650 ( .A0(n524), .A1(n457), .B0(n557), .B1(n458), .Y(n494) );
  AOI221X1 U651 ( .A0(n598), .A1(n447), .B0(n448), .B1(n449), .C0(n450), .Y(
        n444) );
  OAI221X1 U652 ( .A0(n580), .A1(n455), .B0(n547), .B1(n434), .C0(n467), .Y(
        n447) );
  OAI221X1 U653 ( .A0(n576), .A1(n455), .B0(n546), .B1(n434), .C0(n464), .Y(
        n449) );
  AO22X1 U654 ( .A0(n596), .A1(n452), .B0(n594), .B1(n454), .Y(n450) );
  AOI221X1 U655 ( .A0(n598), .A1(n470), .B0(n448), .B1(n471), .C0(n472), .Y(
        n443) );
  OAI221X1 U656 ( .A0(n568), .A1(n455), .B0(n537), .B1(n434), .C0(n486), .Y(
        n470) );
  OAI221X1 U657 ( .A0(n582), .A1(n455), .B0(n549), .B1(n434), .C0(n483), .Y(
        n471) );
  AO22X1 U658 ( .A0(n596), .A1(n473), .B0(n594), .B1(n474), .Y(n472) );
  AOI221X1 U659 ( .A0(n598), .A1(n489), .B0(n448), .B1(n490), .C0(n491), .Y(
        n488) );
  OAI221X1 U660 ( .A0(n570), .A1(n455), .B0(n539), .B1(n434), .C0(n497), .Y(
        n489) );
  OAI221X1 U661 ( .A0(n566), .A1(n455), .B0(n535), .B1(n434), .C0(n496), .Y(
        n490) );
  AO22X1 U662 ( .A0(n596), .A1(n492), .B0(n594), .B1(n493), .Y(n491) );
  AOI221X1 U663 ( .A0(n598), .A1(n498), .B0(n448), .B1(n499), .C0(n500), .Y(
        n487) );
  OAI221X1 U664 ( .A0(n564), .A1(n455), .B0(n533), .B1(n434), .C0(n517), .Y(
        n498) );
  OAI221X1 U665 ( .A0(n584), .A1(n455), .B0(n551), .B1(n434), .C0(n513), .Y(
        n499) );
  AO22X1 U666 ( .A0(n596), .A1(n501), .B0(n594), .B1(n502), .Y(n500) );
  INVX1 U667 ( .A(n428), .Y(n426) );
  INVX1 U668 ( .A(FrameStart), .Y(n437) );
  INVX1 U669 ( .A(n435), .Y(n448) );
  BUFX2 U670 ( .A(n282), .Y(n607) );
  OAI31X1 U671 ( .A0(n283), .A1(n284), .A2(n285), .B0(n559), .Y(n282) );
  INVX1 U672 ( .A(n287), .Y(n285) );
  OA22X1 U673 ( .A0(WordLength[1]), .A1(n592), .B0(n289), .B1(n280), .Y(n283)
         );
  NAND2X1 U674 ( .A(Enabled), .B(FrameStart), .Y(n284) );
  NAND3BX1 U675 ( .AN(WordLength[1]), .B(WordLength[0]), .C(n591), .Y(n339) );
  NAND3BX1 U676 ( .AN(WordLength[1]), .B(n279), .C(n591), .Y(n421) );
  NAND3BX1 U677 ( .AN(SyncReset), .B(n359), .C(n360), .Y(n604) );
  NOR2X1 U678 ( .A(SyncReset), .B(n284), .Y(n591) );
  AOI2BB1X1 U679 ( .A0N(n289), .A1N(n4160), .B0(SyncReset), .Y(n419) );
  AO22X1 U680 ( .A0(LeftData_7_), .A1(n366), .B0(n4170), .B1(FifoData[7]), .Y(
        n192) );
  AO22X1 U681 ( .A0(LeftData_0_), .A1(n366), .B0(n4170), .B1(FifoData[0]), .Y(
        n185) );
  AO22X1 U682 ( .A0(LeftData_1_), .A1(n366), .B0(n4170), .B1(FifoData[1]), .Y(
        n186) );
  AO22X1 U683 ( .A0(LeftData_2_), .A1(n366), .B0(n4170), .B1(FifoData[2]), .Y(
        n187) );
  AO22X1 U684 ( .A0(LeftData_3_), .A1(n366), .B0(n4170), .B1(FifoData[3]), .Y(
        n188) );
  AO22X1 U685 ( .A0(LeftData_4_), .A1(n366), .B0(n4170), .B1(FifoData[4]), .Y(
        n189) );
  AO22X1 U686 ( .A0(LeftData_5_), .A1(n366), .B0(n4170), .B1(FifoData[5]), .Y(
        n190) );
  AO22X1 U687 ( .A0(LeftData_6_), .A1(n366), .B0(n4170), .B1(FifoData[6]), .Y(
        n191) );
  AO22X1 U688 ( .A0(FifoData[16]), .A1(n607), .B0(RemainedData[0]), .B1(
        nFifoReadEn), .Y(n249) );
  AO22X1 U689 ( .A0(FifoData[17]), .A1(n607), .B0(RemainedData[1]), .B1(
        nFifoReadEn), .Y(n250) );
  AO22X1 U690 ( .A0(FifoData[18]), .A1(n607), .B0(RemainedData[2]), .B1(
        nFifoReadEn), .Y(n251) );
  AO22X1 U691 ( .A0(FifoData[19]), .A1(n607), .B0(RemainedData[3]), .B1(
        nFifoReadEn), .Y(n252) );
  AO22X1 U692 ( .A0(FifoData[20]), .A1(n607), .B0(RemainedData[4]), .B1(
        nFifoReadEn), .Y(n253) );
  AO22X1 U693 ( .A0(FifoData[21]), .A1(n607), .B0(RemainedData[5]), .B1(
        nFifoReadEn), .Y(n254) );
  AO22X1 U694 ( .A0(FifoData[22]), .A1(n607), .B0(RemainedData[6]), .B1(
        nFifoReadEn), .Y(n255) );
  AO22X1 U695 ( .A0(FifoData[23]), .A1(n607), .B0(RemainedData[7]), .B1(
        nFifoReadEn), .Y(n256) );
  AO22X1 U696 ( .A0(FifoData[24]), .A1(n607), .B0(RemainedData[8]), .B1(
        nFifoReadEn), .Y(n257) );
  AO22X1 U697 ( .A0(FifoData[25]), .A1(n607), .B0(RemainedData[9]), .B1(
        nFifoReadEn), .Y(n258) );
  AO22X1 U698 ( .A0(FifoData[26]), .A1(n607), .B0(RemainedData[10]), .B1(
        nFifoReadEn), .Y(n259) );
  AO22X1 U699 ( .A0(FifoData[27]), .A1(n607), .B0(RemainedData[11]), .B1(
        nFifoReadEn), .Y(n260) );
  AO22X1 U700 ( .A0(FifoData[28]), .A1(n607), .B0(RemainedData[12]), .B1(
        nFifoReadEn), .Y(n261) );
  AO22X1 U701 ( .A0(FifoData[29]), .A1(n607), .B0(RemainedData[13]), .B1(
        nFifoReadEn), .Y(n262) );
  AO22X1 U702 ( .A0(FifoData[30]), .A1(n607), .B0(RemainedData[14]), .B1(
        nFifoReadEn), .Y(n263) );
  AO22X1 U703 ( .A0(FifoData[31]), .A1(n607), .B0(RemainedData[15]), .B1(
        nFifoReadEn), .Y(n264) );
  INVX1 U704 ( .A(n420), .Y(n360) );
  OAI221X1 U705 ( .A0(FifoEmpty), .A1(n421), .B0(FifoEmpty), .B1(n339), .C0(
        n389), .Y(n420) );
  OAI33X1 U706 ( .A0(n284), .A1(FifoAfford2Read), .A2(n280), .B0(n284), .B1(
        n592), .B2(n287), .Y(FifoUnderRun) );
  OAI221X1 U707 ( .A0(n316), .A1(n605), .B0(n292), .B1(n538), .C0(n318), .Y(
        n241) );
  AOI222X1 U708 ( .A0(FifoData[24]), .A1(n295), .B0(FifoData[8]), .B1(n296), 
        .C0(n297), .C1(RemainedData[8]), .Y(n318) );
  OAI221X1 U709 ( .A0(n313), .A1(n291), .B0(n600), .B1(n574), .C0(n315), .Y(
        n242) );
  AOI222X1 U710 ( .A0(FifoData[25]), .A1(n295), .B0(FifoData[9]), .B1(n296), 
        .C0(n297), .C1(RemainedData[9]), .Y(n315) );
  OAI221X1 U711 ( .A0(n310), .A1(n606), .B0(n604), .B1(n526), .C0(n312), .Y(
        n243) );
  AOI222X1 U712 ( .A0(FifoData[26]), .A1(n295), .B0(FifoData[10]), .B1(n296), 
        .C0(n297), .C1(RemainedData[10]), .Y(n312) );
  OAI221X1 U713 ( .A0(n307), .A1(n605), .B0(n600), .B1(n569), .C0(n309), .Y(
        n244) );
  AOI222X1 U714 ( .A0(FifoData[27]), .A1(n295), .B0(FifoData[11]), .B1(n296), 
        .C0(n297), .C1(RemainedData[11]), .Y(n309) );
  OAI221X1 U715 ( .A0(n304), .A1(n291), .B0(n604), .B1(n539), .C0(n306), .Y(
        n245) );
  AOI222X1 U716 ( .A0(FifoData[28]), .A1(n295), .B0(FifoData[12]), .B1(n296), 
        .C0(n297), .C1(RemainedData[12]), .Y(n306) );
  OAI221X1 U717 ( .A0(n301), .A1(n606), .B0(n600), .B1(n544), .C0(n303), .Y(
        n246) );
  AOI222X1 U718 ( .A0(FifoData[29]), .A1(n295), .B0(FifoData[13]), .B1(n296), 
        .C0(n297), .C1(RemainedData[13]), .Y(n303) );
  OAI221X1 U719 ( .A0(n298), .A1(n605), .B0(n604), .B1(n579), .C0(n300), .Y(
        n247) );
  AOI222X1 U720 ( .A0(FifoData[30]), .A1(n295), .B0(FifoData[14]), .B1(n296), 
        .C0(n297), .C1(RemainedData[14]), .Y(n300) );
  OAI221X1 U721 ( .A0(n290), .A1(n291), .B0(n600), .B1(n570), .C0(n294), .Y(
        n248) );
  AOI222X1 U722 ( .A0(FifoData[31]), .A1(n295), .B0(FifoData[15]), .B1(n296), 
        .C0(n297), .C1(RemainedData[15]), .Y(n294) );
  OAI211X1 U723 ( .A0(n386), .A1(n362), .B0(n387), .C0(n388), .Y(n209) );
  INVX1 U724 ( .A(FifoData[24]), .Y(n386) );
  OA22X1 U725 ( .A0(n319), .A1(n355), .B0(n336), .B1(n367), .Y(n387) );
  AOI222X1 U726 ( .A0(n365), .A1(FifoData[16]), .B0(n297), .B1(RemainedData[0]), .C0(LeftData_24_), .C1(n366), .Y(n388) );
  OAI211X1 U727 ( .A0(n383), .A1(n362), .B0(n384), .C0(n385), .Y(n210) );
  INVX1 U728 ( .A(FifoData[25]), .Y(n383) );
  OA22X1 U729 ( .A0(n319), .A1(n353), .B0(n334), .B1(n367), .Y(n384) );
  AOI222X1 U730 ( .A0(n365), .A1(FifoData[17]), .B0(n297), .B1(RemainedData[1]), .C0(LeftData_25_), .C1(n366), .Y(n385) );
  OAI211X1 U731 ( .A0(n380), .A1(n362), .B0(n381), .C0(n382), .Y(n211) );
  INVX1 U732 ( .A(FifoData[26]), .Y(n380) );
  OA22X1 U733 ( .A0(n319), .A1(n351), .B0(n332), .B1(n367), .Y(n381) );
  AOI222X1 U734 ( .A0(n365), .A1(FifoData[18]), .B0(n297), .B1(RemainedData[2]), .C0(LeftData_26_), .C1(n366), .Y(n382) );
  OAI211X1 U735 ( .A0(n377), .A1(n362), .B0(n378), .C0(n379), .Y(n212) );
  INVX1 U736 ( .A(FifoData[27]), .Y(n377) );
  OA22X1 U737 ( .A0(n319), .A1(n349), .B0(n330), .B1(n367), .Y(n378) );
  AOI222X1 U738 ( .A0(n365), .A1(FifoData[19]), .B0(n297), .B1(RemainedData[3]), .C0(LeftData_27_), .C1(n366), .Y(n379) );
  OAI211X1 U739 ( .A0(n374), .A1(n362), .B0(n375), .C0(n376), .Y(n213) );
  INVX1 U740 ( .A(FifoData[28]), .Y(n374) );
  OA22X1 U741 ( .A0(n319), .A1(n347), .B0(n328), .B1(n367), .Y(n375) );
  AOI222X1 U742 ( .A0(n365), .A1(FifoData[20]), .B0(n297), .B1(RemainedData[4]), .C0(LeftData_28_), .C1(n366), .Y(n376) );
  OAI211X1 U743 ( .A0(n371), .A1(n362), .B0(n372), .C0(n373), .Y(n214) );
  INVX1 U744 ( .A(FifoData[29]), .Y(n371) );
  OA22X1 U745 ( .A0(n319), .A1(n345), .B0(n326), .B1(n367), .Y(n372) );
  AOI222X1 U746 ( .A0(n365), .A1(FifoData[21]), .B0(n297), .B1(RemainedData[5]), .C0(LeftData_29_), .C1(n366), .Y(n373) );
  OAI211X1 U747 ( .A0(n368), .A1(n362), .B0(n369), .C0(n370), .Y(n215) );
  INVX1 U748 ( .A(FifoData[30]), .Y(n368) );
  OA22X1 U749 ( .A0(n319), .A1(n343), .B0(n324), .B1(n367), .Y(n369) );
  AOI222X1 U750 ( .A0(n365), .A1(FifoData[22]), .B0(n297), .B1(RemainedData[6]), .C0(LeftData_30_), .C1(n366), .Y(n370) );
  OAI211X1 U751 ( .A0(n361), .A1(n362), .B0(n363), .C0(n364), .Y(n216) );
  INVX1 U752 ( .A(FifoData[31]), .Y(n361) );
  OA22X1 U753 ( .A0(n319), .A1(n340), .B0(n321), .B1(n367), .Y(n363) );
  AOI222X1 U754 ( .A0(n365), .A1(FifoData[23]), .B0(n297), .B1(RemainedData[7]), .C0(LeftData_31_), .C1(n366), .Y(n364) );
  NAND3BX1 U755 ( .AN(FifoEmpty), .B(n593), .C(n276), .Y(n319) );
  NAND3BX1 U756 ( .AN(SyncReset), .B(RightLoad), .C(n284), .Y(n359) );
  NAND2BX1 U757 ( .AN(N27), .B(N28), .Y(n458) );
  NAND2BX1 U758 ( .AN(N28), .B(N27), .Y(n457) );
  NAND3BX1 U759 ( .AN(SyncReset), .B(n359), .C(n360), .Y(n292) );
  NAND2BX1 U760 ( .AN(WordLength[1]), .B(FifoEmpty), .Y(n287) );
  NAND3BX1 U761 ( .AN(SyncReset), .B(n359), .C(n360), .Y(n600) );
  NAND2X1 U762 ( .A(N28), .B(N27), .Y(n455) );
  OR2X1 U763 ( .A(N28), .B(N27), .Y(n434) );
  NAND3BX1 U764 ( .AN(n280), .B(WordLength[0]), .C(n591), .Y(n4180) );
  NOR3BX1 U765 ( .AN(WordLength[1]), .B(n284), .C(n289), .Y(N223) );
  NAND3BX1 U766 ( .AN(WordLength[0]), .B(WordLength[1]), .C(n591), .Y(n4160)
         );
  NAND2BX1 U767 ( .AN(WordLength[0]), .B(n357), .Y(n291) );
  NAND2BX1 U768 ( .AN(WordLength[0]), .B(n357), .Y(n606) );
  NAND2BX1 U769 ( .AN(WordLength[0]), .B(n357), .Y(n605) );
  INVX1 U770 ( .A(WordLength[0]), .Y(n279) );
  OA22X1 U771 ( .A0(n554), .A1(n457), .B0(n587), .B1(n458), .Y(n467) );
  OA22X1 U772 ( .A0(n555), .A1(n457), .B0(n589), .B1(n458), .Y(n483) );
  OA22X1 U773 ( .A0(n556), .A1(n457), .B0(n590), .B1(n458), .Y(n513) );
  INVX1 U774 ( .A(FifoData[7]), .Y(n340) );
  INVX1 U775 ( .A(FifoData[8]), .Y(n336) );
  INVX1 U776 ( .A(FifoData[9]), .Y(n334) );
  INVX1 U777 ( .A(FifoData[10]), .Y(n332) );
  INVX1 U778 ( .A(FifoData[11]), .Y(n330) );
  INVX1 U779 ( .A(FifoData[12]), .Y(n328) );
  INVX1 U780 ( .A(FifoData[13]), .Y(n326) );
  INVX1 U781 ( .A(FifoData[14]), .Y(n324) );
  INVX1 U782 ( .A(FifoData[15]), .Y(n321) );
  INVX1 U783 ( .A(FifoData[0]), .Y(n355) );
  INVX1 U784 ( .A(FifoData[1]), .Y(n353) );
  INVX1 U785 ( .A(FifoData[2]), .Y(n351) );
  INVX1 U786 ( .A(FifoData[3]), .Y(n349) );
  INVX1 U787 ( .A(FifoData[4]), .Y(n347) );
  INVX1 U788 ( .A(FifoData[5]), .Y(n345) );
  INVX1 U789 ( .A(FifoData[6]), .Y(n343) );
  OAI2BB2X1 U790 ( .A0N(BCLKFall), .A1N(n439), .B0(n599), .B1(BCLKFall), .Y(
        n178) );
  OAI221X1 U791 ( .A0(n581), .A1(n455), .B0(n548), .B1(n434), .C0(n461), .Y(
        n452) );
  OA22X1 U792 ( .A0(n528), .A1(n457), .B0(n560), .B1(n458), .Y(n461) );
  AO22X1 U793 ( .A0(FifoData[0]), .A1(n338), .B0(RightData_0_), .B1(n358), .Y(
        n217) );
  AO22X1 U794 ( .A0(FifoData[1]), .A1(n338), .B0(RightData_1_), .B1(n358), .Y(
        n218) );
  AO22X1 U795 ( .A0(FifoData[2]), .A1(n338), .B0(RightData_2_), .B1(n358), .Y(
        n219) );
  AO22X1 U796 ( .A0(FifoData[3]), .A1(n338), .B0(RightData_3_), .B1(n358), .Y(
        n220) );
  AO22X1 U797 ( .A0(FifoData[4]), .A1(n338), .B0(RightData_4_), .B1(n358), .Y(
        n221) );
  AO22X1 U798 ( .A0(FifoData[5]), .A1(n338), .B0(RightData_5_), .B1(n358), .Y(
        n222) );
  AO22X1 U799 ( .A0(FifoData[6]), .A1(n338), .B0(RightData_6_), .B1(n358), .Y(
        n2230) );
  AO22X1 U800 ( .A0(n338), .A1(FifoData[7]), .B0(RightData_7_), .B1(n358), .Y(
        n224) );
  OAI221X1 U801 ( .A0(n583), .A1(n455), .B0(n550), .B1(n434), .C0(n477), .Y(
        n474) );
  OA22X1 U802 ( .A0(n529), .A1(n457), .B0(n561), .B1(n458), .Y(n477) );
  OAI221X1 U803 ( .A0(n585), .A1(n455), .B0(n552), .B1(n434), .C0(n505), .Y(
        n502) );
  OA22X1 U804 ( .A0(n588), .A1(n457), .B0(n530), .B1(n458), .Y(n505) );
  INVX1 U805 ( .A(WordLength[1]), .Y(n280) );
  INVX1 U806 ( .A(FifoData[16]), .Y(n316) );
  INVX1 U807 ( .A(FifoData[17]), .Y(n313) );
  INVX1 U808 ( .A(FifoData[18]), .Y(n310) );
  INVX1 U809 ( .A(FifoData[19]), .Y(n307) );
  INVX1 U810 ( .A(FifoData[20]), .Y(n304) );
  INVX1 U811 ( .A(FifoData[21]), .Y(n301) );
  INVX1 U812 ( .A(FifoData[22]), .Y(n298) );
  INVX1 U813 ( .A(FifoData[23]), .Y(n290) );
  OR2X1 U814 ( .A(n441), .B(n442), .Y(n439) );
  OAI33X1 U815 ( .A0(n487), .A1(N31), .A2(LeftRight), .B0(n488), .B1(LeftRight), .B2(n562), .Y(n441) );
  OAI33X1 U816 ( .A0(n443), .A1(N31), .A2(n531), .B0(n444), .B1(n531), .B2(
        n562), .Y(n442) );
  NOR2X1 U817 ( .A(WordLength[0]), .B(n593), .Y(n592) );
  OAI31X1 U818 ( .A0(n434), .A1(N31), .A2(n435), .B0(BCLKFall), .Y(n428) );
  OR2X1 U819 ( .A(N30), .B(N29), .Y(n435) );
  NAND2BX1 U820 ( .AN(RightStart), .B(n437), .Y(n429) );
  OR2X1 U1_B_1 ( .A(N28), .B(N27), .Y(carry_2_) );
  NAND2BX1 U821 ( .AN(n429), .B(n433), .Y(n180) );
  XOR2X1 U822 ( .A(n428), .B(N27), .Y(n433) );
  OR2X1 U1_B_2 ( .A(N29), .B(carry_2_), .Y(carry_3_) );
  OAI32X1 U823 ( .A0(n429), .A1(SyncReset), .A2(n531), .B0(SyncReset), .B1(
        n437), .Y(n179) );
  AO21X1 U824 ( .A0(N415), .A1(n426), .B0(n432), .Y(n181) );
  XNOR2X1 U1_A_1 ( .A(N28), .B(N27), .Y(N415) );
  AO21X1 U825 ( .A0(N28), .A1(n428), .B0(n429), .Y(n432) );
  AO21X1 U826 ( .A0(N416), .A1(n426), .B0(n431), .Y(n182) );
  XNOR2X1 U1_A_2 ( .A(N29), .B(carry_2_), .Y(N416) );
  AO21X1 U827 ( .A0(N29), .A1(n428), .B0(n429), .Y(n431) );
  AO21X1 U828 ( .A0(N417), .A1(n426), .B0(n430), .Y(n183) );
  XNOR2X1 U1_A_3 ( .A(N30), .B(carry_3_), .Y(N417) );
  AO21X1 U829 ( .A0(N30), .A1(n428), .B0(n429), .Y(n430) );
  AO21X1 U830 ( .A0(N418), .A1(n426), .B0(n427), .Y(n184) );
  XNOR2X1 U1_A_4 ( .A(N31), .B(carry_4_), .Y(N418) );
  AO21X1 U831 ( .A0(N31), .A1(n428), .B0(n429), .Y(n427) );
  OR2X1 U1_B_3 ( .A(N30), .B(carry_3_), .Y(carry_4_) );
  NOR2X1 U832 ( .A(N30), .B(n595), .Y(n594) );
  NOR2X1 U833 ( .A(N29), .B(n597), .Y(n596) );
  AO21X1 U834 ( .A0(n276), .A1(n593), .B0(n278), .Y(n265) );
  AOI31X1 U835 ( .A0(n279), .A1(n280), .A2(FrameStart), .B0(n281), .Y(n278) );
  NAND3BX1 U836 ( .AN(SyncReset), .B(Enabled), .C(DataRemained), .Y(n281) );
  AND2X2 U837 ( .A(N30), .B(N29), .Y(n598) );
  OAI2BB2X1 U838 ( .A0N(LeftJust), .A1N(n439), .B0(n599), .B1(LeftJust), .Y(
        SDOUT) );
  DFFRX1 BitCounter_reg_1_ ( .D(n181), .CK(CLK), .RN(RESETn), .Q(N28) );
  DFFRX1 DataRemained_reg ( .D(n265), .CK(CLK), .RN(RESETn), .Q(DataRemained), 
        .QN(n593) );
  DFFRX1 RightLoad_reg ( .D(N223), .CK(CLK), .RN(RESETn), .Q(RightLoad), .QN(
        n559) );
  DFFRX1 LeftData_reg_5_ ( .D(n190), .CK(CLK), .RN(RESETn), .Q(LeftData_5_), 
        .QN(n529) );
  DFFRX1 LeftData_reg_6_ ( .D(n191), .CK(CLK), .RN(RESETn), .Q(LeftData_6_), 
        .QN(n561) );
  DFFRX1 RightData_reg_5_ ( .D(n222), .CK(CLK), .RN(RESETn), .Q(RightData_5_), 
        .QN(n588) );
  DFFRX1 RightData_reg_6_ ( .D(n2230), .CK(CLK), .RN(RESETn), .Q(RightData_6_), 
        .QN(n530) );
  DFFRX1 LeftData_reg_25_ ( .D(n210), .CK(CLK), .RN(RESETn), .Q(LeftData_25_), 
        .QN(n528) );
  DFFRX1 LeftData_reg_26_ ( .D(n211), .CK(CLK), .RN(RESETn), .Q(LeftData_26_), 
        .QN(n560) );
  DFFRX1 LeftData_reg_10_ ( .D(n195), .CK(CLK), .RN(RESETn), .QN(n525) );
  DFFRX1 LeftData_reg_21_ ( .D(n206), .CK(CLK), .RN(RESETn), .QN(n527) );
  DFFRX1 LeftData_reg_22_ ( .D(n207), .CK(CLK), .RN(RESETn), .QN(n558) );
  DFFRX1 RightData_reg_21_ ( .D(n238), .CK(CLK), .RN(RESETn), .QN(n524) );
  DFFRX1 RightData_reg_22_ ( .D(n239), .CK(CLK), .RN(RESETn), .QN(n557) );
  DFFRX1 RightData_reg_25_ ( .D(n242), .CK(CLK), .RN(RESETn), .QN(n574) );
  DFFRX1 RightData_reg_26_ ( .D(n243), .CK(CLK), .RN(RESETn), .QN(n526) );
  DFFRX1 BitCounter_reg_2_ ( .D(n182), .CK(CLK), .RN(RESETn), .Q(N29), .QN(
        n595) );
  DFFRX1 BitCounter_reg_3_ ( .D(n183), .CK(CLK), .RN(RESETn), .Q(N30), .QN(
        n597) );
  DFFRX1 BitCounter_reg_4_ ( .D(n184), .CK(CLK), .RN(RESETn), .Q(N31), .QN(
        n562) );
  DFFRX1 LeftRight_reg ( .D(n179), .CK(CLK), .RN(RESETn), .Q(LeftRight), .QN(
        n531) );
  DFFRX1 LeftData_reg_0_ ( .D(n185), .CK(CLK), .RN(RESETn), .Q(LeftData_0_), 
        .QN(n549) );
  DFFRX1 LeftData_reg_1_ ( .D(n186), .CK(CLK), .RN(RESETn), .Q(LeftData_1_), 
        .QN(n555) );
  DFFRX1 LeftData_reg_2_ ( .D(n187), .CK(CLK), .RN(RESETn), .Q(LeftData_2_), 
        .QN(n589) );
  DFFRX1 LeftData_reg_3_ ( .D(n188), .CK(CLK), .RN(RESETn), .Q(LeftData_3_), 
        .QN(n582) );
  DFFRX1 LeftData_reg_4_ ( .D(n189), .CK(CLK), .RN(RESETn), .Q(LeftData_4_), 
        .QN(n550) );
  DFFRX1 LeftData_reg_7_ ( .D(n192), .CK(CLK), .RN(RESETn), .Q(LeftData_7_), 
        .QN(n583) );
  DFFRX1 RightData_reg_0_ ( .D(n217), .CK(CLK), .RN(RESETn), .Q(RightData_0_), 
        .QN(n551) );
  DFFRX1 RightData_reg_1_ ( .D(n218), .CK(CLK), .RN(RESETn), .Q(RightData_1_), 
        .QN(n556) );
  DFFRX1 RightData_reg_2_ ( .D(n219), .CK(CLK), .RN(RESETn), .Q(RightData_2_), 
        .QN(n590) );
  DFFRX1 RightData_reg_3_ ( .D(n220), .CK(CLK), .RN(RESETn), .Q(RightData_3_), 
        .QN(n584) );
  DFFRX1 RightData_reg_4_ ( .D(n221), .CK(CLK), .RN(RESETn), .Q(RightData_4_), 
        .QN(n552) );
  DFFRX1 RightData_reg_7_ ( .D(n224), .CK(CLK), .RN(RESETn), .Q(RightData_7_), 
        .QN(n585) );
  DFFRX1 LeftData_reg_24_ ( .D(n209), .CK(CLK), .RN(RESETn), .Q(LeftData_24_), 
        .QN(n548) );
  DFFRX1 LeftData_reg_27_ ( .D(n212), .CK(CLK), .RN(RESETn), .Q(LeftData_27_), 
        .QN(n581) );
  DFFRX1 LeftData_reg_28_ ( .D(n213), .CK(CLK), .RN(RESETn), .Q(LeftData_28_), 
        .QN(n547) );
  DFFRX1 LeftData_reg_29_ ( .D(n214), .CK(CLK), .RN(RESETn), .Q(LeftData_29_), 
        .QN(n554) );
  DFFRX1 LeftData_reg_30_ ( .D(n215), .CK(CLK), .RN(RESETn), .Q(LeftData_30_), 
        .QN(n587) );
  DFFRX1 LeftData_reg_31_ ( .D(n216), .CK(CLK), .RN(RESETn), .Q(LeftData_31_), 
        .QN(n580) );
  DFFRX1 LeftData_reg_8_ ( .D(n193), .CK(CLK), .RN(RESETn), .QN(n536) );
  DFFRX1 LeftData_reg_9_ ( .D(n194), .CK(CLK), .RN(RESETn), .QN(n571) );
  DFFRX1 LeftData_reg_11_ ( .D(n196), .CK(CLK), .RN(RESETn), .QN(n567) );
  DFFRX1 LeftData_reg_12_ ( .D(n197), .CK(CLK), .RN(RESETn), .QN(n537) );
  DFFRX1 LeftData_reg_13_ ( .D(n198), .CK(CLK), .RN(RESETn), .QN(n543) );
  DFFRX1 LeftData_reg_14_ ( .D(n199), .CK(CLK), .RN(RESETn), .QN(n578) );
  DFFRX1 LeftData_reg_15_ ( .D(n200), .CK(CLK), .RN(RESETn), .QN(n568) );
  DFFRX1 LeftData_reg_16_ ( .D(n201), .CK(CLK), .RN(RESETn), .QN(n546) );
  DFFRX1 LeftData_reg_17_ ( .D(n202), .CK(CLK), .RN(RESETn), .QN(n553) );
  DFFRX1 LeftData_reg_18_ ( .D(n203), .CK(CLK), .RN(RESETn), .QN(n586) );
  DFFRX1 LeftData_reg_19_ ( .D(n204), .CK(CLK), .RN(RESETn), .QN(n576) );
  DFFRX1 LeftData_reg_20_ ( .D(n205), .CK(CLK), .RN(RESETn), .QN(n545) );
  DFFRX1 LeftData_reg_23_ ( .D(n208), .CK(CLK), .RN(RESETn), .QN(n575) );
  DFFRX1 RightData_reg_8_ ( .D(n225), .CK(CLK), .RN(RESETn), .QN(n532) );
  DFFRX1 RightData_reg_9_ ( .D(n226), .CK(CLK), .RN(RESETn), .QN(n541) );
  DFFRX1 RightData_reg_10_ ( .D(n227), .CK(CLK), .RN(RESETn), .QN(n573) );
  DFFRX1 RightData_reg_11_ ( .D(n228), .CK(CLK), .RN(RESETn), .QN(n563) );
  DFFRX1 RightData_reg_12_ ( .D(n229), .CK(CLK), .RN(RESETn), .QN(n533) );
  DFFRX1 RightData_reg_13_ ( .D(n230), .CK(CLK), .RN(RESETn), .QN(n540) );
  DFFRX1 RightData_reg_14_ ( .D(n231), .CK(CLK), .RN(RESETn), .QN(n572) );
  DFFRX1 RightData_reg_15_ ( .D(n232), .CK(CLK), .RN(RESETn), .QN(n564) );
  DFFRX1 RightData_reg_16_ ( .D(n233), .CK(CLK), .RN(RESETn), .QN(n535) );
  DFFRX1 RightData_reg_17_ ( .D(n234), .CK(CLK), .RN(RESETn), .QN(n542) );
  DFFRX1 RightData_reg_18_ ( .D(n235), .CK(CLK), .RN(RESETn), .QN(n577) );
  DFFRX1 RightData_reg_19_ ( .D(n236), .CK(CLK), .RN(RESETn), .QN(n566) );
  DFFRX1 RightData_reg_20_ ( .D(n237), .CK(CLK), .RN(RESETn), .QN(n534) );
  DFFRX1 RightData_reg_23_ ( .D(n240), .CK(CLK), .RN(RESETn), .QN(n565) );
  DFFRX1 RightData_reg_24_ ( .D(n241), .CK(CLK), .RN(RESETn), .QN(n538) );
  DFFRX1 RightData_reg_27_ ( .D(n244), .CK(CLK), .RN(RESETn), .QN(n569) );
  DFFRX1 RightData_reg_28_ ( .D(n245), .CK(CLK), .RN(RESETn), .QN(n539) );
  DFFRX1 RightData_reg_29_ ( .D(n246), .CK(CLK), .RN(RESETn), .QN(n544) );
  DFFRX1 RightData_reg_30_ ( .D(n247), .CK(CLK), .RN(RESETn), .QN(n579) );
  DFFRX1 RightData_reg_31_ ( .D(n248), .CK(CLK), .RN(RESETn), .QN(n570) );
  DFFRX1 RemainedData_reg_0_ ( .D(n249), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[0]) );
  DFFRX1 RemainedData_reg_1_ ( .D(n250), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[1]) );
  DFFRX1 RemainedData_reg_2_ ( .D(n251), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[2]) );
  DFFRX1 RemainedData_reg_3_ ( .D(n252), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[3]) );
  DFFRX1 RemainedData_reg_4_ ( .D(n253), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[4]) );
  DFFRX1 RemainedData_reg_5_ ( .D(n254), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[5]) );
  DFFRX1 RemainedData_reg_6_ ( .D(n255), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[6]) );
  DFFRX1 RemainedData_reg_7_ ( .D(n256), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[7]) );
  DFFRX1 RemainedData_reg_8_ ( .D(n257), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[8]) );
  DFFRX1 RemainedData_reg_9_ ( .D(n258), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[9]) );
  DFFRX1 RemainedData_reg_10_ ( .D(n259), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[10]) );
  DFFRX1 RemainedData_reg_11_ ( .D(n260), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[11]) );
  DFFRX1 RemainedData_reg_12_ ( .D(n261), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[12]) );
  DFFRX1 RemainedData_reg_13_ ( .D(n262), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[13]) );
  DFFRX1 RemainedData_reg_14_ ( .D(n263), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[14]) );
  DFFRX1 RemainedData_reg_15_ ( .D(n264), .CK(CLK), .RN(RESETn), .Q(
        RemainedData[15]) );
  DFFRX1 SDOUT_I2S_reg ( .D(n178), .CK(CLK), .RN(RESETn), .QN(n599) );
endmodule


module I2S_ClockMgr ( CLK, RESETn, LRCLK_I, BCLK_I, SDIN, LeftStart, 
        RightStart, BCLKRise, BCLKFall, SDInput, LRCLK, Master, LRCLKInvert );
  input CLK, RESETn, LRCLK_I, BCLK_I, SDIN, Master, LRCLKInvert;
  output LeftStart, RightStart, BCLKRise, BCLKFall, SDInput, LRCLK;
  wire   BCLKIn1d, LRCLKIn1d, SDIN1d, BCLKIn3d, LRCLKIn3d, SDIN2d, LRCLKIn2d,
         BCLKIn2d, n6, n8, n9;

  DFFSX1 SDIN2d_reg ( .D(SDIN1d), .CK(CLK), .SN(RESETn), .Q(SDIN2d) );
  DFFSX1 SDIN1d_reg ( .D(SDIN), .CK(CLK), .SN(RESETn), .Q(SDIN1d) );
  DFFSX1 LRCLKIn1d_reg ( .D(LRCLK_I), .CK(CLK), .SN(RESETn), .Q(LRCLKIn1d) );
  DFFSX1 BCLKIn1d_reg ( .D(BCLK_I), .CK(CLK), .SN(RESETn), .Q(BCLKIn1d) );
  OAI33X1 U17 ( .A0(n8), .A1(LRCLKIn3d), .A2(n6), .B0(n9), .B1(LRCLKInvert), 
        .B2(LRCLKIn2d), .Y(LeftStart) );
  INVX1 U18 ( .A(LRCLKInvert), .Y(n6) );
  XOR2X1 U19 ( .A(LRCLKInvert), .B(LRCLKIn2d), .Y(LRCLK) );
  NOR2BX1 U20 ( .AN(BCLKIn2d), .B(BCLKIn3d), .Y(BCLKRise) );
  NOR2BX1 U21 ( .AN(BCLKIn3d), .B(BCLKIn2d), .Y(BCLKFall) );
  OAI33X1 U22 ( .A0(n8), .A1(LRCLKInvert), .A2(LRCLKIn3d), .B0(n6), .B1(
        LRCLKIn2d), .B2(n9), .Y(RightStart) );
  DFFSX1 LRCLKIn2d_reg ( .D(LRCLKIn1d), .CK(CLK), .SN(RESETn), .Q(LRCLKIn2d), 
        .QN(n8) );
  DFFSX1 LRCLKIn3d_reg ( .D(LRCLKIn2d), .CK(CLK), .SN(RESETn), .Q(LRCLKIn3d), 
        .QN(n9) );
  DFFSX1 BCLKIn2d_reg ( .D(BCLKIn1d), .CK(CLK), .SN(RESETn), .Q(BCLKIn2d) );
  DFFSX1 BCLKIn3d_reg ( .D(BCLKIn2d), .CK(CLK), .SN(RESETn), .Q(BCLKIn3d) );
  DFFSX1 SDIN3d_reg ( .D(SDIN2d), .CK(CLK), .SN(RESETn), .Q(SDInput) );
endmodule


module I2S_DTO ( SYS_CLK, RESETn, MCLK, BCLK, LRCLK, Enable, LRClkInv, ClkMS, 
        DTORatio );
  input [17:0] DTORatio;
  input SYS_CLK, RESETn, Enable, LRClkInv, ClkMS;
  output MCLK, BCLK, LRCLK;
  wire   DTORegister_16_, DTORegister_15_, DTORegister_14_, DTORegister_13_,
         DTORegister_12_, DTORegister_11_, DTORegister_10_, DTORegister_9_,
         DTORegister_8_, DTORegister_7_, DTORegister_6_, DTORegister_5_,
         DTORegister_4_, DTORegister_3_, DTORegister_2_, DTORegister_1_,
         DTORatio1d_17_, DTORatio1d_16_, DTORatio1d_15_, DTORatio1d_14_,
         DTORatio1d_13_, DTORatio1d_12_, DTORatio1d_11_, DTORatio1d_10_,
         DTORatio1d_9_, DTORatio1d_8_, DTORatio1d_7_, DTORatio1d_6_,
         DTORatio1d_5_, DTORatio1d_4_, DTORatio1d_3_, DTORatio1d_2_,
         DTORatio1d_1_, N9, N10, N11, N12, N13, N14, N15, N16, N17, N18, N19,
         N20, N21, N22, N23, N24, N25, N26, N27, N28, N29, N30, N31, N32, N33,
         N34, N39, N40, N41, N42, N43, N44, N45, N46, N47, N48, N49, N50, N51,
         N52, N53, N54, N55, N56, N57, N58, N59, N60, N61, N62, N63, N64, n100,
         n120, g_array, g_array0, g_array1, g_array2, g_array3, g_array4,
         g_array5, g_array6, g_array7, g_array8, g_array9, g_array10,
         g_array11, g_array12, g_array13, g_array14, g_array15, g_array16,
         g_array17, g_array18, g_array19, g_array20, g_array21, g_array22,
         g_array23, g_array24, g_array25, g_array26, g_array27, g_array28,
         g_array29, g_array30, g_array31, g_array32, g_array33, g_array34,
         g_array35, g_array36, g_array37, g_array38, g_array39, g_array40,
         g_array41, g_array42, g_array43, g_array44, g_array45, g_array46,
         g_array47, g_array48, g_array49, g_array50, g_array51, g_array52,
         g_array53, g_array54, g_array55, g_array56, g_array57, g_array58,
         g_array59, g_array60, g_array61, g_array62, g_array63, g_array64,
         g_array65, g_array66, g_array67, g_array68, g_array69, g_array70,
         g_array71, g_array72, g_array73, g_array74, pog_array, pog_array0,
         pog_array1, pog_array2, pog_array3, pog_array4, pog_array5,
         pog_array6, pog_array7, pog_array8, pog_array9, pog_array10,
         pog_array11, pog_array12, pog_array13, pog_array14, pog_array15,
         pog_array16, pog_array17, pog_array18, pog_array19, pog_array20,
         pog_array21, pog_array22, pog_array23, pog_array24, pog_array25,
         pog_array26, pog_array27, pog_array28, pog_array29, pog_array30,
         pog_array31, pog_array32, pog_array33, pog_array34, pog_array35,
         pog_array36, pog_array37, pog_array38, pog_array39, pog_array40,
         pog_array41, pog_array42, pog_array43, pog_array44, pog_array45,
         pog_array46, pog_array47, pog_array48, pog_array49, pog_array50,
         pog_array51, pog_array52, pog_array53, pog_array54, pog_array55,
         pog_array56, pog_array57, part_sum_25_, part_sum_24_, part_sum_23_,
         part_sum_22_, part_sum_21_, part_sum_20_, part_sum_19_, part_sum_18_,
         part_sum_17_, part_sum_16_, part_sum_15_, part_sum_14_, part_sum_13_,
         part_sum_12_, part_sum_11_, part_sum_10_, part_sum_9_, part_sum_8_,
         part_sum_7_, part_sum_6_, part_sum_5_, part_sum_4_, part_sum_3_,
         part_sum_2_, part_sum_1_, n310, n170, n190, n200, n230, n240, n250,
         n260, n270, n280, n290, n300, n320, n330, n340, n35, n36, n37, n38,
         n390, n400, n410;

  AO21X1 U91 ( .A0(pog_array28), .A1(g_array45), .B0(g_array27), .Y(n230) );
  AO21X1 U92 ( .A0(pog_array29), .A1(g_array45), .B0(g_array28), .Y(n240) );
  OR2X1 U93 ( .A(pog_array35), .B(pog_array), .Y(n290) );
  AO21X1 U94 ( .A0(pog_array48), .A1(g_array45), .B0(g_array44), .Y(n300) );
  AO21X1 U95 ( .A0(pog_array20), .A1(g_array19), .B0(g_array17), .Y(n37) );
  NAND2X1 U1_5_3_12 ( .A(pog_array47), .B(pog_array23), .Y(pog_array56) );
  AOI21X1 U1_4_3_12 ( .A0(pog_array23), .A1(g_array42), .B0(g_array21), .Y(
        g_array54) );
  INVX1 U1_3_2_10 ( .A(pog_array38), .Y(pog_array47) );
  NAND2X1 U1_5_3_13 ( .A(pog_array47), .B(pog_array46), .Y(pog_array55) );
  NOR2X1 U1_5_2_5 ( .A(pog_array41), .B(pog_array11), .Y(pog_array48) );
  OAI21X1 U1_4_2_5 ( .A0(pog_array11), .A1(g_array37), .B0(g_array11), .Y(
        g_array44) );
  NAND2X1 U1_5_1_10 ( .A(pog_array26), .B(pog_array25), .Y(pog_array38) );
  NOR2X1 U1_5_2_13 ( .A(pog_array37), .B(pog_array3), .Y(pog_array46) );
  INVX1 U1_2_3_6 ( .A(g_array43), .Y(g_array56) );
  BUFX2 U96 ( .A(n310), .Y(n410) );
  AOI21X1 U1_4_3_14 ( .A0(pog_array45), .A1(g_array43), .B0(g_array40), .Y(
        n310) );
  NOR2X1 U1_5_2_14 ( .A(pog_array38), .B(pog_array36), .Y(pog_array45) );
  OAI21X1 U1_4_2_14 ( .A0(pog_array36), .A1(g_array34), .B0(g_array32), .Y(
        g_array40) );
  NAND2X1 U1_5_1_14 ( .A(pog_array23), .B(pog_array22), .Y(pog_array36) );
  INVX1 U1_2_2_10 ( .A(g_array34), .Y(g_array42) );
  INVX1 U1_2_2_2 ( .A(g_array38), .Y(g_array45) );
  INVX1 U1_3_2_18 ( .A(pog_array34), .Y(pog_array44) );
  NAND2BX1 U97 ( .AN(n270), .B(g_array39), .Y(g_array48) );
  INVX1 U1_2_1_16 ( .A(g_array19), .Y(g_array31) );
  INVX1 U1_2_1_12 ( .A(g_array21), .Y(g_array33) );
  INVX1 U1_2_1_8 ( .A(g_array25), .Y(g_array35) );
  INVX1 U1_2_1_4 ( .A(g_array27), .Y(g_array37) );
  OAI21X1 U1_4_2_1 ( .A0(pog_array15), .A1(g_array16), .B0(g_array15), .Y(
        g_array46) );
  INVX1 U1_3_1_16 ( .A(pog_array21), .Y(pog_array35) );
  INVX1 U1_3_1_12 ( .A(pog_array23), .Y(pog_array37) );
  INVX1 U1_3_1_8 ( .A(pog_array26), .Y(pog_array39) );
  INVX1 U1_3_1_4 ( .A(pog_array28), .Y(pog_array41) );
  NAND2X1 U1_5_3_11 ( .A(pog_array47), .B(pog_array24), .Y(pog_array57) );
  OR2X1 U98 ( .A(pog_array39), .B(pog_array7), .Y(n38) );
  OAI21X1 U1_4_0_4 ( .A0(pog_array12), .A1(g_array13), .B0(g_array12), .Y(
        g_array27) );
  OAI21X1 U1_4_0_8 ( .A0(pog_array8), .A1(g_array9), .B0(g_array8), .Y(
        g_array25) );
  OAI21X1 U1_4_0_12 ( .A0(pog_array4), .A1(g_array5), .B0(g_array4), .Y(
        g_array21) );
  OAI21X1 U1_4_0_16 ( .A0(pog_array0), .A1(g_array1), .B0(g_array0), .Y(
        g_array19) );
  OAI21X1 U1_4_2_6 ( .A0(pog_array40), .A1(g_array38), .B0(g_array36), .Y(
        g_array43) );
  NAND2X1 U1_5_1_6 ( .A(pog_array28), .B(pog_array27), .Y(pog_array40) );
  AOI21X1 U1_4_1_6 ( .A0(pog_array27), .A1(g_array27), .B0(g_array26), .Y(
        g_array36) );
  NOR2X1 U1_5_0_6 ( .A(pog_array11), .B(pog_array10), .Y(pog_array27) );
  AOI21X1 U1_4_1_2 ( .A0(pog_array30), .A1(g_array30), .B0(g_array29), .Y(
        g_array38) );
  OAI21X1 U1_4_0_2 ( .A0(pog_array14), .A1(g_array15), .B0(g_array14), .Y(
        g_array29) );
  NOR2X1 U1_5_0_2 ( .A(pog_array15), .B(pog_array14), .Y(pog_array30) );
  AOI21X1 U1_4_1_10 ( .A0(pog_array25), .A1(g_array25), .B0(g_array23), .Y(
        g_array34) );
  OAI21X1 U1_4_0_10 ( .A0(pog_array6), .A1(g_array7), .B0(g_array6), .Y(
        g_array23) );
  NOR2X1 U1_5_2_22 ( .A(pog_array34), .B(pog_array32), .Y(pog_array42) );
  NOR2X1 U1_5_0_4 ( .A(pog_array13), .B(pog_array12), .Y(pog_array28) );
  NOR2X1 U1_5_0_8 ( .A(pog_array9), .B(pog_array8), .Y(pog_array26) );
  NOR2X1 U1_5_0_12 ( .A(pog_array5), .B(pog_array4), .Y(pog_array23) );
  NOR2X1 U1_5_0_16 ( .A(pog_array1), .B(pog_array0), .Y(pog_array21) );
  NOR2BX1 U99 ( .AN(N41), .B(n280), .Y(N11) );
  XOR2X1 U0_5_2 ( .A(part_sum_2_), .B(g_array46), .Y(N41) );
  NOR2BX1 U0_3_2 ( .AN(g_array14), .B(pog_array14), .Y(part_sum_2_) );
  INVX1 U100 ( .A(n170), .Y(g_array39) );
  NAND2BX1 U101 ( .AN(pog_array32), .B(n37), .Y(n170) );
  NOR2BX1 U102 ( .AN(N53), .B(n280), .Y(N23) );
  XOR2X1 U0_5_14 ( .A(part_sum_14_), .B(g_array68), .Y(N53) );
  NOR2BX1 U0_3_14 ( .AN(g_array2), .B(pog_array2), .Y(part_sum_14_) );
  OAI21X1 U1_4_4_13 ( .A0(pog_array55), .A1(g_array56), .B0(g_array53), .Y(
        g_array68) );
  NOR2BX1 U103 ( .AN(N52), .B(n280), .Y(N22) );
  XOR2X1 U0_5_13 ( .A(part_sum_13_), .B(g_array69), .Y(N52) );
  NOR2BX1 U0_3_13 ( .AN(g_array3), .B(pog_array3), .Y(part_sum_13_) );
  OAI21X1 U1_4_4_12 ( .A0(pog_array56), .A1(g_array56), .B0(g_array54), .Y(
        g_array69) );
  NOR2BX1 U104 ( .AN(N51), .B(n280), .Y(N21) );
  XOR2X1 U0_5_12 ( .A(part_sum_12_), .B(g_array70), .Y(N51) );
  NOR2BX1 U0_3_12 ( .AN(g_array4), .B(pog_array4), .Y(part_sum_12_) );
  OAI21X1 U1_4_4_11 ( .A0(pog_array57), .A1(g_array56), .B0(g_array55), .Y(
        g_array70) );
  NOR2BX1 U105 ( .AN(N50), .B(n280), .Y(N20) );
  XOR2X1 U0_5_11 ( .A(part_sum_11_), .B(g_array71), .Y(N50) );
  NOR2BX1 U0_3_11 ( .AN(g_array5), .B(pog_array5), .Y(part_sum_11_) );
  OAI21X1 U1_4_4_10 ( .A0(pog_array38), .A1(g_array56), .B0(g_array34), .Y(
        g_array71) );
  NOR2BX1 U106 ( .AN(N49), .B(n280), .Y(N19) );
  XOR2X1 U0_5_10 ( .A(part_sum_10_), .B(g_array72), .Y(N49) );
  NOR2BX1 U0_3_10 ( .AN(g_array6), .B(pog_array6), .Y(part_sum_10_) );
  OAI21X1 U1_4_4_9 ( .A0(n38), .A1(g_array56), .B0(n400), .Y(g_array72) );
  NOR2BX1 U107 ( .AN(N48), .B(n280), .Y(N18) );
  XOR2X1 U0_5_9 ( .A(part_sum_9_), .B(g_array73), .Y(N48) );
  NOR2BX1 U0_3_9 ( .AN(g_array7), .B(pog_array7), .Y(part_sum_9_) );
  OAI21X1 U1_4_4_8 ( .A0(pog_array39), .A1(g_array56), .B0(g_array35), .Y(
        g_array73) );
  NOR2BX1 U108 ( .AN(N47), .B(n280), .Y(N17) );
  XOR2X1 U0_5_8 ( .A(part_sum_8_), .B(g_array74), .Y(N47) );
  NOR2BX1 U0_3_8 ( .AN(g_array8), .B(pog_array8), .Y(part_sum_8_) );
  OAI21X1 U1_4_4_7 ( .A0(pog_array9), .A1(g_array56), .B0(g_array9), .Y(
        g_array74) );
  OAI21X1 U1_4_0_6 ( .A0(pog_array10), .A1(g_array11), .B0(g_array10), .Y(
        g_array26) );
  NAND2X1 U1_5_1_18 ( .A(pog_array21), .B(pog_array20), .Y(pog_array34) );
  AOI21X1 U1_4_1_14 ( .A0(pog_array22), .A1(g_array21), .B0(g_array20), .Y(
        g_array32) );
  OAI21X1 U1_4_0_14 ( .A0(pog_array2), .A1(g_array3), .B0(g_array2), .Y(
        g_array20) );
  AOI21X1 U1_4_3_13 ( .A0(pog_array46), .A1(g_array42), .B0(g_array41), .Y(
        g_array53) );
  OAI21X1 U1_4_2_13 ( .A0(pog_array3), .A1(g_array33), .B0(g_array3), .Y(
        g_array41) );
  AOI21X1 U1_4_3_11 ( .A0(pog_array24), .A1(g_array42), .B0(g_array22), .Y(
        g_array55) );
  INVX1 U1_2_0_11 ( .A(g_array5), .Y(g_array22) );
  NOR2X1 U1_5_0_10 ( .A(pog_array7), .B(pog_array6), .Y(pog_array25) );
  NOR2X1 U1_5_0_14 ( .A(pog_array3), .B(pog_array2), .Y(pog_array22) );
  NOR2X1 U1_5_2_21 ( .A(pog_array33), .B(n340), .Y(pog_array43) );
  NAND2BX1 U109 ( .AN(pog_array33), .B(n37), .Y(g_array50) );
  NAND2BX1 U110 ( .AN(n35), .B(n37), .Y(g_array51) );
  NAND2X1 U111 ( .A(n37), .B(pog_array43), .Y(g_array49) );
  NAND2BX1 U112 ( .AN(pog_array31), .B(g_array39), .Y(g_array47) );
  NOR2BX1 U113 ( .AN(N56), .B(n280), .Y(N26) );
  XOR2X1 U0_5_17 ( .A(part_sum_17_), .B(g_array65), .Y(N56) );
  NOR2BX1 U0_3_17 ( .AN(g_array), .B(pog_array), .Y(part_sum_17_) );
  OAI21X1 U1_4_4_16 ( .A0(pog_array35), .A1(n410), .B0(g_array31), .Y(
        g_array65) );
  NOR2BX1 U114 ( .AN(N55), .B(n280), .Y(N25) );
  XOR2X1 U0_5_16 ( .A(part_sum_16_), .B(g_array66), .Y(N55) );
  NOR2BX1 U0_3_16 ( .AN(g_array0), .B(pog_array0), .Y(part_sum_16_) );
  OAI21X1 U1_4_4_15 ( .A0(pog_array1), .A1(n410), .B0(g_array1), .Y(g_array66)
         );
  NOR2BX1 U115 ( .AN(N54), .B(n280), .Y(N24) );
  XOR2X1 U0_5_15 ( .A(part_sum_15_), .B(g_array67), .Y(N54) );
  NOR2BX1 U0_3_15 ( .AN(g_array1), .B(pog_array1), .Y(part_sum_15_) );
  INVX1 U1_2_4_14 ( .A(n410), .Y(g_array67) );
  NOR2BX1 U116 ( .AN(N46), .B(n280), .Y(N16) );
  XOR2X1 U0_5_7 ( .A(part_sum_7_), .B(g_array43), .Y(N46) );
  NOR2BX1 U0_3_7 ( .AN(g_array9), .B(pog_array9), .Y(part_sum_7_) );
  NOR2BX1 U117 ( .AN(N45), .B(n280), .Y(N15) );
  XOR2X1 U0_5_6 ( .A(part_sum_6_), .B(n300), .Y(N45) );
  NOR2BX1 U0_3_6 ( .AN(g_array10), .B(pog_array10), .Y(part_sum_6_) );
  NOR2BX1 U118 ( .AN(N44), .B(n280), .Y(N14) );
  XOR2X1 U0_5_5 ( .A(part_sum_5_), .B(n230), .Y(N44) );
  NOR2BX1 U0_3_5 ( .AN(g_array11), .B(pog_array11), .Y(part_sum_5_) );
  NOR2BX1 U119 ( .AN(N43), .B(n280), .Y(N13) );
  XOR2X1 U0_5_4 ( .A(part_sum_4_), .B(n240), .Y(N43) );
  NOR2BX1 U0_3_4 ( .AN(g_array12), .B(pog_array12), .Y(part_sum_4_) );
  INVX1 U1_3_1_20 ( .A(pog_array19), .Y(pog_array33) );
  INVX1 U120 ( .A(g_array16), .Y(g_array30) );
  INVX1 U1_2_0_3 ( .A(g_array13), .Y(g_array28) );
  AOI2BB1X1 U121 ( .A0N(pog_array), .A1N(g_array31), .B0(g_array18), .Y(n390)
         );
  INVX1 U1_2_0_17 ( .A(g_array), .Y(g_array18) );
  AOI2BB1X1 U122 ( .A0N(pog_array7), .A1N(g_array35), .B0(g_array24), .Y(n400)
         );
  INVX1 U1_2_0_9 ( .A(g_array7), .Y(g_array24) );
  INVX1 U1_3_0_3 ( .A(pog_array13), .Y(pog_array29) );
  INVX1 U1_3_0_11 ( .A(pog_array5), .Y(pog_array24) );
  INVX1 U1_2_3_18 ( .A(n37), .Y(g_array52) );
  NOR2BX1 U123 ( .AN(N42), .B(n280), .Y(N12) );
  XOR2X1 U0_5_3 ( .A(part_sum_3_), .B(g_array45), .Y(N42) );
  NOR2BX1 U0_3_3 ( .AN(g_array13), .B(pog_array13), .Y(part_sum_3_) );
  NOR2BX1 U124 ( .AN(N40), .B(n280), .Y(N10) );
  XOR2X1 U0_5_1 ( .A(part_sum_1_), .B(g_array30), .Y(N40) );
  NOR2BX1 U0_3_1 ( .AN(g_array15), .B(pog_array15), .Y(part_sum_1_) );
  NOR2X1 U0_2_17 ( .A(MCLK), .B(DTORatio1d_17_), .Y(pog_array) );
  NOR2X1 U0_2_15 ( .A(DTORegister_15_), .B(DTORatio1d_15_), .Y(pog_array1) );
  NOR2X1 U0_2_13 ( .A(DTORegister_13_), .B(DTORatio1d_13_), .Y(pog_array3) );
  NOR2X1 U0_2_11 ( .A(DTORegister_11_), .B(DTORatio1d_11_), .Y(pog_array5) );
  NOR2X1 U0_2_9 ( .A(DTORegister_9_), .B(DTORatio1d_9_), .Y(pog_array7) );
  NOR2X1 U0_2_7 ( .A(DTORegister_7_), .B(DTORatio1d_7_), .Y(pog_array9) );
  NOR2X1 U0_2_5 ( .A(DTORegister_5_), .B(DTORatio1d_5_), .Y(pog_array11) );
  NOR2X1 U0_2_3 ( .A(DTORegister_3_), .B(DTORatio1d_3_), .Y(pog_array13) );
  NOR2X1 U0_2_1 ( .A(DTORegister_1_), .B(DTORatio1d_1_), .Y(pog_array15) );
  NOR2X1 U1_5_0_20 ( .A(n35), .B(n250), .Y(pog_array19) );
  NOR2X1 U0_2_16 ( .A(DTORegister_16_), .B(DTORatio1d_16_), .Y(pog_array0) );
  NOR2X1 U0_2_14 ( .A(DTORegister_14_), .B(DTORatio1d_14_), .Y(pog_array2) );
  NOR2X1 U0_2_12 ( .A(DTORegister_12_), .B(DTORatio1d_12_), .Y(pog_array4) );
  NOR2X1 U0_2_10 ( .A(DTORegister_10_), .B(DTORatio1d_10_), .Y(pog_array6) );
  NOR2X1 U0_2_8 ( .A(DTORegister_8_), .B(DTORatio1d_8_), .Y(pog_array8) );
  NOR2X1 U0_2_6 ( .A(DTORegister_6_), .B(DTORatio1d_6_), .Y(pog_array10) );
  NOR2X1 U0_2_4 ( .A(DTORegister_4_), .B(DTORatio1d_4_), .Y(pog_array12) );
  NOR2X1 U0_2_2 ( .A(DTORegister_2_), .B(DTORatio1d_2_), .Y(pog_array14) );
  NAND2X1 U0_1_15 ( .A(DTORegister_15_), .B(DTORatio1d_15_), .Y(g_array1) );
  NAND2X1 U0_1_13 ( .A(DTORegister_13_), .B(DTORatio1d_13_), .Y(g_array3) );
  NAND2X1 U0_1_11 ( .A(DTORegister_11_), .B(DTORatio1d_11_), .Y(g_array5) );
  NAND2X1 U0_1_9 ( .A(DTORegister_9_), .B(DTORatio1d_9_), .Y(g_array7) );
  NAND2X1 U0_1_7 ( .A(DTORegister_7_), .B(DTORatio1d_7_), .Y(g_array9) );
  NAND2X1 U0_1_5 ( .A(DTORegister_5_), .B(DTORatio1d_5_), .Y(g_array11) );
  NAND2X1 U0_1_3 ( .A(DTORegister_3_), .B(DTORatio1d_3_), .Y(g_array13) );
  NAND2X1 U0_1_1 ( .A(DTORegister_1_), .B(DTORatio1d_1_), .Y(g_array15) );
  NAND2X1 U0_1_17 ( .A(MCLK), .B(DTORatio1d_17_), .Y(g_array) );
  NOR2X1 U1_5_0_18 ( .A(pog_array), .B(n320), .Y(pog_array20) );
  NAND2X1 U0_1_0 ( .A(n120), .B(n100), .Y(g_array16) );
  NOR2BX1 U125 ( .AN(part_sum_18_), .B(g_array), .Y(g_array17) );
  NAND2X1 U1_5_1_22 ( .A(pog_array19), .B(pog_array18), .Y(pog_array32) );
  NOR2X1 U1_5_0_22 ( .A(n340), .B(n330), .Y(pog_array18) );
  NAND2X1 U0_1_16 ( .A(DTORegister_16_), .B(DTORatio1d_16_), .Y(g_array0) );
  NAND2X1 U0_1_14 ( .A(DTORegister_14_), .B(DTORatio1d_14_), .Y(g_array2) );
  NAND2X1 U0_1_12 ( .A(DTORegister_12_), .B(DTORatio1d_12_), .Y(g_array4) );
  NAND2X1 U0_1_10 ( .A(DTORegister_10_), .B(DTORatio1d_10_), .Y(g_array6) );
  NAND2X1 U0_1_8 ( .A(DTORegister_8_), .B(DTORatio1d_8_), .Y(g_array8) );
  NAND2X1 U0_1_6 ( .A(DTORegister_6_), .B(DTORatio1d_6_), .Y(g_array10) );
  NAND2X1 U0_1_4 ( .A(DTORegister_4_), .B(DTORatio1d_4_), .Y(g_array12) );
  NAND2X1 U0_1_2 ( .A(DTORegister_2_), .B(DTORatio1d_2_), .Y(g_array14) );
  NOR2BX1 U126 ( .AN(N64), .B(n280), .Y(N34) );
  XOR2X1 U0_5_25 ( .A(part_sum_25_), .B(g_array57), .Y(N64) );
  OAI21X1 U1_4_4_24 ( .A0(pog_array49), .A1(n410), .B0(g_array47), .Y(
        g_array57) );
  NAND2X1 U1_5_3_24 ( .A(pog_array42), .B(pog_array17), .Y(pog_array49) );
  NOR2BX1 U127 ( .AN(N63), .B(n280), .Y(N33) );
  XOR2X1 U0_5_24 ( .A(part_sum_24_), .B(g_array58), .Y(N63) );
  OAI21X1 U1_4_4_23 ( .A0(pog_array50), .A1(n410), .B0(g_array48), .Y(
        g_array58) );
  NAND2X1 U1_5_3_23 ( .A(pog_array42), .B(part_sum_23_), .Y(pog_array50) );
  NOR2BX1 U128 ( .AN(N62), .B(n280), .Y(N32) );
  XOR2X1 U0_5_23 ( .A(part_sum_23_), .B(g_array59), .Y(N62) );
  OAI21X1 U1_4_4_22 ( .A0(pog_array51), .A1(n410), .B0(n170), .Y(g_array59) );
  INVX1 U1_3_3_22 ( .A(pog_array42), .Y(pog_array51) );
  NOR2BX1 U129 ( .AN(N61), .B(n280), .Y(N31) );
  XOR2X1 U0_5_22 ( .A(part_sum_22_), .B(g_array60), .Y(N61) );
  OAI21X1 U1_4_4_21 ( .A0(pog_array52), .A1(n410), .B0(g_array49), .Y(
        g_array60) );
  NAND2X1 U1_5_3_21 ( .A(pog_array44), .B(pog_array43), .Y(pog_array52) );
  NOR2BX1 U130 ( .AN(N60), .B(n280), .Y(N30) );
  XOR2X1 U0_5_21 ( .A(part_sum_21_), .B(g_array61), .Y(N60) );
  OAI21X1 U1_4_4_20 ( .A0(pog_array53), .A1(n410), .B0(g_array50), .Y(
        g_array61) );
  NAND2X1 U1_5_3_20 ( .A(pog_array44), .B(pog_array19), .Y(pog_array53) );
  NOR2BX1 U131 ( .AN(N59), .B(n280), .Y(N29) );
  XOR2X1 U0_5_20 ( .A(part_sum_20_), .B(g_array62), .Y(N59) );
  OAI21X1 U1_4_4_19 ( .A0(pog_array54), .A1(n410), .B0(g_array51), .Y(
        g_array62) );
  NAND2X1 U1_5_3_19 ( .A(pog_array44), .B(part_sum_19_), .Y(pog_array54) );
  NOR2BX1 U132 ( .AN(N58), .B(n280), .Y(N28) );
  XOR2X1 U0_5_19 ( .A(part_sum_19_), .B(g_array63), .Y(N58) );
  OAI21X1 U1_4_4_18 ( .A0(pog_array34), .A1(n410), .B0(g_array52), .Y(
        g_array63) );
  NOR2BX1 U133 ( .AN(N57), .B(n280), .Y(N27) );
  XOR2X1 U0_5_18 ( .A(part_sum_18_), .B(g_array64), .Y(N57) );
  OAI21X1 U1_4_4_17 ( .A0(n290), .A1(n410), .B0(n390), .Y(g_array64) );
  NOR2BX1 U134 ( .AN(N39), .B(n280), .Y(N9) );
  NOR2BX1 U0_3_0 ( .AN(g_array16), .B(pog_array16), .Y(N39) );
  NOR2X1 U0_2_0 ( .A(n120), .B(n100), .Y(pog_array16) );
  INVX1 U1_3_1_24 ( .A(pog_array17), .Y(pog_array31) );
  NOR2X1 U1_5_0_24 ( .A(n270), .B(n260), .Y(pog_array17) );
  NOR2BX1 U135 ( .AN(ClkMS), .B(n35), .Y(BCLK) );
  OAI33X1 U136 ( .A0(n190), .A1(n200), .A2(n36), .B0(n200), .B1(LRClkInv), 
        .B2(part_sum_25_), .Y(LRCLK) );
  INVX1 U137 ( .A(ClkMS), .Y(n200) );
  INVX1 U138 ( .A(LRClkInv), .Y(n190) );
  DFFRX1 DTORegister_reg_17_ ( .D(N26), .CK(SYS_CLK), .RN(RESETn), .Q(MCLK) );
  DFFRX1 DTORegister_reg_18_ ( .D(N27), .CK(SYS_CLK), .RN(RESETn), .Q(
        part_sum_18_), .QN(n320) );
  DFFRX1 DTORegister_reg_22_ ( .D(N31), .CK(SYS_CLK), .RN(RESETn), .Q(
        part_sum_22_), .QN(n330) );
  DFFRX1 DTORegister_reg_21_ ( .D(N30), .CK(SYS_CLK), .RN(RESETn), .Q(
        part_sum_21_), .QN(n340) );
  DFFRX1 DTORegister_reg_20_ ( .D(N29), .CK(SYS_CLK), .RN(RESETn), .Q(
        part_sum_20_), .QN(n250) );
  DFFRX1 DTORegister_reg_19_ ( .D(N28), .CK(SYS_CLK), .RN(RESETn), .Q(
        part_sum_19_), .QN(n35) );
  DFFRX1 DTORegister_reg_16_ ( .D(N25), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_16_) );
  DFFRX1 DTORegister_reg_15_ ( .D(N24), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_15_) );
  DFFRX1 DTORegister_reg_14_ ( .D(N23), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_14_) );
  DFFRX1 DTORegister_reg_13_ ( .D(N22), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_13_) );
  DFFRX1 DTORegister_reg_12_ ( .D(N21), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_12_) );
  DFFRX1 DTORegister_reg_11_ ( .D(N20), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_11_) );
  DFFRX1 DTORegister_reg_10_ ( .D(N19), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_10_) );
  DFFRX1 DTORegister_reg_9_ ( .D(N18), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_9_) );
  DFFRX1 DTORegister_reg_8_ ( .D(N17), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_8_) );
  DFFRX1 DTORegister_reg_7_ ( .D(N16), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_7_) );
  DFFRX1 DTORegister_reg_6_ ( .D(N15), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_6_) );
  DFFRX1 DTORegister_reg_5_ ( .D(N14), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_5_) );
  DFFRX1 DTORegister_reg_4_ ( .D(N13), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_4_) );
  DFFRX1 DTORegister_reg_3_ ( .D(N12), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_3_) );
  DFFRX1 DTORegister_reg_2_ ( .D(N11), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_2_) );
  DFFRX1 DTORegister_reg_1_ ( .D(N10), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORegister_1_) );
  DFFRX1 DTORegister_reg_0_ ( .D(N9), .CK(SYS_CLK), .RN(RESETn), .Q(n120) );
  DFFRX1 DTORatio1d_reg_17_ ( .D(DTORatio[17]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_17_) );
  DFFRX1 DTORatio1d_reg_16_ ( .D(DTORatio[16]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_16_) );
  DFFRX1 DTORatio1d_reg_15_ ( .D(DTORatio[15]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_15_) );
  DFFRX1 DTORatio1d_reg_14_ ( .D(DTORatio[14]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_14_) );
  DFFRX1 DTORatio1d_reg_13_ ( .D(DTORatio[13]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_13_) );
  DFFRX1 DTORatio1d_reg_12_ ( .D(DTORatio[12]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_12_) );
  DFFRX1 DTORatio1d_reg_11_ ( .D(DTORatio[11]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_11_) );
  DFFRX1 DTORatio1d_reg_10_ ( .D(DTORatio[10]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_10_) );
  DFFRX1 DTORatio1d_reg_9_ ( .D(DTORatio[9]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_9_) );
  DFFRX1 DTORatio1d_reg_8_ ( .D(DTORatio[8]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_8_) );
  DFFRX1 DTORatio1d_reg_7_ ( .D(DTORatio[7]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_7_) );
  DFFRX1 DTORatio1d_reg_6_ ( .D(DTORatio[6]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_6_) );
  DFFRX1 DTORatio1d_reg_5_ ( .D(DTORatio[5]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_5_) );
  DFFRX1 DTORatio1d_reg_4_ ( .D(DTORatio[4]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_4_) );
  DFFRX1 DTORatio1d_reg_3_ ( .D(DTORatio[3]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_3_) );
  DFFRX1 DTORatio1d_reg_2_ ( .D(DTORatio[2]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_2_) );
  DFFRX1 DTORatio1d_reg_1_ ( .D(DTORatio[1]), .CK(SYS_CLK), .RN(RESETn), .Q(
        DTORatio1d_1_) );
  DFFRX1 DTORatio1d_reg_0_ ( .D(DTORatio[0]), .CK(SYS_CLK), .RN(RESETn), .Q(
        n100) );
  DFFRX1 DTORegister_reg_25_ ( .D(N34), .CK(SYS_CLK), .RN(RESETn), .Q(
        part_sum_25_), .QN(n36) );
  DFFRX1 DTORegister_reg_24_ ( .D(N33), .CK(SYS_CLK), .RN(RESETn), .Q(
        part_sum_24_), .QN(n260) );
  DFFRX1 DTORegister_reg_23_ ( .D(N32), .CK(SYS_CLK), .RN(RESETn), .Q(
        part_sum_23_), .QN(n270) );
  DFFRX1 Enable1d_reg ( .D(Enable), .CK(SYS_CLK), .RN(RESETn), .QN(n280) );
endmodule


module I2S_Control_I2S_RFIFO_DEPTH5_I2S_TFIFO_DEPTH5 ( PCLK, PRESETn, PADDR, 
        PENABLE, PSEL, PWRITE, PWDATA, PRDATA, Interrupt, TxDMAReq, RxDMAReq, 
        ClkMS, LRClkInv, MClkOn, MClkOE, DTORatio, TxEnabled, TxReset, 
        TxWordLength, TxLeftJust, TxFifoUnderRun, RxEnabled, RxReset, 
        RxWordLength, RxLeftJust, RxFifoOverRun, TxFifoWData, nTxFifoWriteEn, 
        TxFifoFull, TxFifoEmpty, TxFifoLevel, TxFifoAfford2Read, RxFifoData, 
        nRxFifoReadEn, RxFifoFull, RxFifoEmpty, RxFifoLevel, 
        RxFifoAfford2Write );
  input [3:2] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  output [17:0] DTORatio;
  output [1:0] TxWordLength;
  output [1:0] RxWordLength;
  output [31:0] TxFifoWData;
  input [4:0] TxFifoLevel;
  input [31:0] RxFifoData;
  input [4:0] RxFifoLevel;
  input PCLK, PRESETn, PENABLE, PSEL, PWRITE, TxFifoUnderRun, RxFifoOverRun,
         TxFifoFull, TxFifoEmpty, TxFifoAfford2Read, RxFifoFull, RxFifoEmpty,
         RxFifoAfford2Write;
  output Interrupt, TxDMAReq, RxDMAReq, ClkMS, LRClkInv, MClkOn, MClkOE,
         TxEnabled, TxReset, TxLeftJust, RxEnabled, RxReset, RxLeftJust,
         nTxFifoWriteEn, nRxFifoReadEn;
  wire   N21, N22, CtrlReg_29_, CtrlReg_28_, CtrlReg_15_, CtrlReg_13_,
         CtrlReg_12_, StatusReg_30_, StatusReg_28_, StatusReg_14_,
         StatusReg_12_, N25, N115, N141, N142, n119, n120, n121, n122, n123,
         n124, n125, n126, n127, n128, n129, n130, n131, n132, n133, n134,
         n135, n136, n137, n138, n139, n140, n1410, n1420, n143, n144, n145,
         n146, n147, n148, n149, n150, n151, n152, n153, n154, n155, n156,
         n157, n158, n159, n160, n161, n162, n163, n164, n165, n166, n167,
         n168, n169, n170, n171, n172, n173, n174, n175, n176, n177, n178,
         n179, n180, n181, n182, n183, n184, n185, n186, n187, n188, n189,
         n190, n191, n192, n193, n194, n195, n196, n197, n198, n199, n200,
         n209, n210, n211, n212, n213, n214, n216, n218, n219, n220, n221,
         n223, n225, n228, n231, n233, n234, n235, n237, n238, n239, n241,
         n242, n243, n244, n245, n246, n247, n248, n249, n250, n251, n254,
         n257, n258, n259, n260, n261, n262, n263, n264, n267, n268, n269,
         n270, n271, n273, n274, n275, n276, n277, n278, n279, n280, n281,
         n282, n283, n284, n285, n286, n287, n288, n289, n290, n291, n292,
         n294, n295, n296, n298, n299, n300, n305, n306, n307, n309, n310,
         n311, n312, n315, n318, n319, n320, n321, n322, n325, n326, n328,
         n329, n330, n333, n334, n335, n336, n337, n338, n339, n340, n341,
         n342, n343, n344, n345, n346, n347, n348, n349, n350, n351, n352,
         n353, n354, n355, n356, n357, n358, n359, n360, n361, n362, n363,
         n364, n365, n366, n367, n368, n369, n370, n371, n372, n373;
  wire   [4:0] RxFifoTH;
  wire   [4:0] TxFifoTH;

  DFFRX1 TxFifoWData_reg_31_ ( .D(PWDATA[31]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[31]) );
  DFFRX1 TxFifoWData_reg_30_ ( .D(PWDATA[30]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[30]) );
  DFFRX1 TxFifoWData_reg_29_ ( .D(PWDATA[29]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[29]) );
  DFFRX1 TxFifoWData_reg_28_ ( .D(PWDATA[28]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[28]) );
  DFFRX1 TxFifoWData_reg_27_ ( .D(PWDATA[27]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[27]) );
  DFFRX1 TxFifoWData_reg_26_ ( .D(PWDATA[26]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[26]) );
  DFFRX1 TxFifoWData_reg_25_ ( .D(PWDATA[25]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[25]) );
  DFFRX1 TxFifoWData_reg_24_ ( .D(PWDATA[24]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[24]) );
  DFFRX1 TxFifoWData_reg_23_ ( .D(PWDATA[23]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[23]) );
  DFFRX1 TxFifoWData_reg_22_ ( .D(PWDATA[22]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[22]) );
  DFFRX1 TxFifoWData_reg_21_ ( .D(PWDATA[21]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[21]) );
  DFFRX1 TxFifoWData_reg_20_ ( .D(PWDATA[20]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[20]) );
  DFFRX1 TxFifoWData_reg_19_ ( .D(PWDATA[19]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[19]) );
  DFFRX1 TxFifoWData_reg_18_ ( .D(PWDATA[18]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[18]) );
  DFFRX1 TxFifoWData_reg_17_ ( .D(PWDATA[17]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[17]) );
  DFFRX1 TxFifoWData_reg_16_ ( .D(PWDATA[16]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[16]) );
  DFFRX1 TxFifoWData_reg_15_ ( .D(PWDATA[15]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[15]) );
  DFFRX1 TxFifoWData_reg_14_ ( .D(PWDATA[14]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[14]) );
  DFFRX1 TxFifoWData_reg_13_ ( .D(PWDATA[13]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[13]) );
  DFFRX1 TxFifoWData_reg_12_ ( .D(PWDATA[12]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[12]) );
  DFFRX1 TxFifoWData_reg_11_ ( .D(PWDATA[11]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[11]) );
  DFFRX1 TxFifoWData_reg_10_ ( .D(PWDATA[10]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[10]) );
  DFFRX1 TxFifoWData_reg_9_ ( .D(PWDATA[9]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[9]) );
  DFFRX1 TxFifoWData_reg_8_ ( .D(PWDATA[8]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[8]) );
  DFFRX1 TxFifoWData_reg_7_ ( .D(PWDATA[7]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[7]) );
  DFFRX1 TxFifoWData_reg_6_ ( .D(PWDATA[6]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[6]) );
  DFFRX1 TxFifoWData_reg_5_ ( .D(PWDATA[5]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[5]) );
  DFFRX1 TxFifoWData_reg_4_ ( .D(PWDATA[4]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[4]) );
  DFFRX1 TxFifoWData_reg_3_ ( .D(PWDATA[3]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[3]) );
  DFFRX1 TxFifoWData_reg_2_ ( .D(PWDATA[2]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[2]) );
  DFFRX1 TxFifoWData_reg_1_ ( .D(PWDATA[1]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[1]) );
  DFFRX1 TxFifoWData_reg_0_ ( .D(PWDATA[0]), .CK(PCLK), .RN(PRESETn), .Q(
        TxFifoWData[0]) );
  INVX1 U426 ( .A(n220), .Y(n285) );
  INVX1 U427 ( .A(nRxFifoReadEn), .Y(n221) );
  INVX1 U428 ( .A(n368), .Y(n214) );
  INVX1 U429 ( .A(n373), .Y(n210) );
  INVX1 U430 ( .A(n223), .Y(n238) );
  INVX1 U431 ( .A(n216), .Y(n235) );
  INVX1 U432 ( .A(n218), .Y(n245) );
  NAND2BX1 U433 ( .AN(n211), .B(n363), .Y(N25) );
  DFFRX1 LRClkInv_reg ( .D(n179), .CK(PCLK), .RN(PRESETn), .Q(LRClkInv), .QN(
        n344) );
  DFFSX1 TxReset_reg ( .D(N22), .CK(PCLK), .SN(PRESETn), .Q(TxReset), .QN(n346) );
  DFFSX1 TxWLen_reg_0_ ( .D(n177), .CK(PCLK), .SN(PRESETn), .Q(TxWordLength[0]), .QN(n345) );
  DFFSX1 RxWLen_reg_0_ ( .D(n166), .CK(PCLK), .SN(PRESETn), .Q(RxWordLength[0]) );
  INVX1 U434 ( .A(RxFifoLevel[4]), .Y(n241) );
  INVX1 U435 ( .A(TxFifoLevel[1]), .Y(n328) );
  INVX1 U436 ( .A(TxFifoLevel[3]), .Y(n330) );
  INVX1 U437 ( .A(TxFifoLevel[0]), .Y(n329) );
  DFFRX1 ClkMS_reg ( .D(n180), .CK(PCLK), .RN(PRESETn), .Q(ClkMS), .QN(n338)
         );
  DFFRX1 Interrupt_reg ( .D(N115), .CK(PCLK), .RN(PRESETn), .Q(Interrupt) );
  NAND3BX1 U438 ( .AN(PWRITE), .B(n286), .C(PSEL), .Y(n220) );
  NAND4BX1 U439 ( .AN(RxFifoEmpty), .B(PADDR[3]), .C(PADDR[2]), .D(n285), .Y(
        nRxFifoReadEn) );
  NAND3BX1 U440 ( .AN(PADDR[2]), .B(PWDATA[12]), .C(n363), .Y(n299) );
  INVX1 U441 ( .A(PENABLE), .Y(n286) );
  INVX1 U442 ( .A(n305), .Y(n212) );
  NAND3BX1 U443 ( .AN(PENABLE), .B(PSEL), .C(PWRITE), .Y(n305) );
  INVX1 U444 ( .A(n292), .Y(n289) );
  NAND3BX1 U445 ( .AN(PADDR[2]), .B(PWDATA[28]), .C(n363), .Y(n292) );
  AND2X2 U446 ( .A(PADDR[3]), .B(n212), .Y(n363) );
  OAI32X1 U447 ( .A0(n288), .A1(RxReset), .A2(n289), .B0(n337), .B1(n290), .Y(
        n123) );
  INVX1 U448 ( .A(n290), .Y(n288) );
  NAND2BX1 U449 ( .AN(n289), .B(n291), .Y(n290) );
  AOI31X1 U450 ( .A0(StatusReg_30_), .A1(CtrlReg_28_), .A2(RxFifoOverRun), 
        .B0(RxReset), .Y(n291) );
  OAI32X1 U451 ( .A0(n295), .A1(TxReset), .A2(n296), .B0(n347), .B1(n298), .Y(
        n121) );
  INVX1 U452 ( .A(n299), .Y(n296) );
  INVX1 U453 ( .A(n298), .Y(n295) );
  OAI211X1 U454 ( .A0(n336), .A1(n300), .B0(n346), .C0(n299), .Y(n298) );
  NAND3BX1 U455 ( .AN(PADDR[3]), .B(PADDR[2]), .C(n212), .Y(n368) );
  NAND3BX1 U456 ( .AN(PADDR[3]), .B(PADDR[2]), .C(n212), .Y(n369) );
  NAND3BX1 U457 ( .AN(PADDR[3]), .B(PADDR[2]), .C(n212), .Y(n213) );
  NAND3BX1 U458 ( .AN(PADDR[2]), .B(PADDR[3]), .C(n285), .Y(n223) );
  NAND3BX1 U459 ( .AN(PADDR[3]), .B(PADDR[2]), .C(n285), .Y(n216) );
  NAND3BX1 U460 ( .AN(PADDR[3]), .B(n211), .C(n212), .Y(n209) );
  NAND3BX1 U461 ( .AN(PADDR[3]), .B(n211), .C(n212), .Y(n372) );
  NAND3BX1 U462 ( .AN(PADDR[3]), .B(n211), .C(n285), .Y(n218) );
  NAND3BX1 U463 ( .AN(PADDR[3]), .B(n211), .C(n212), .Y(n373) );
  INVX1 U464 ( .A(PADDR[2]), .Y(n211) );
  NOR2BX1 U465 ( .AN(PWDATA[14]), .B(n369), .Y(N22) );
  NOR2BX1 U466 ( .AN(PWDATA[30]), .B(n213), .Y(N21) );
  BUFX2 U467 ( .A(n371), .Y(n366) );
  NAND3BX1 U468 ( .AN(PWRITE), .B(n286), .C(PSEL), .Y(n371) );
  BUFX2 U469 ( .A(n370), .Y(n367) );
  NAND3BX1 U470 ( .AN(PWRITE), .B(n286), .C(PSEL), .Y(n370) );
  AO22X1 U471 ( .A0(RxWordLength[0]), .A1(n368), .B0(PWDATA[25]), .B1(n214), 
        .Y(n166) );
  AO22X1 U472 ( .A0(RxFifoTH[4]), .A1(n213), .B0(PWDATA[20]), .B1(n214), .Y(
        n164) );
  AO22X1 U473 ( .A0(RxLeftJust), .A1(n369), .B0(PWDATA[24]), .B1(n214), .Y(
        n165) );
  AO22X1 U474 ( .A0(RxWordLength[1]), .A1(n213), .B0(PWDATA[26]), .B1(n214), 
        .Y(n167) );
  AO22X1 U475 ( .A0(CtrlReg_28_), .A1(n369), .B0(PWDATA[28]), .B1(n214), .Y(
        n168) );
  AO22X1 U476 ( .A0(CtrlReg_29_), .A1(n213), .B0(PWDATA[29]), .B1(n214), .Y(
        n169) );
  AO22X1 U477 ( .A0(LRClkInv), .A1(n372), .B0(PWDATA[30]), .B1(n210), .Y(n179)
         );
  AO22X1 U478 ( .A0(ClkMS), .A1(n209), .B0(PWDATA[31]), .B1(n210), .Y(n180) );
  AO22X1 U479 ( .A0(DTORatio[0]), .A1(n373), .B0(PWDATA[0]), .B1(n210), .Y(
        n181) );
  AO22X1 U480 ( .A0(DTORatio[1]), .A1(n372), .B0(PWDATA[1]), .B1(n210), .Y(
        n182) );
  AO22X1 U481 ( .A0(DTORatio[2]), .A1(n209), .B0(PWDATA[2]), .B1(n210), .Y(
        n183) );
  AO22X1 U482 ( .A0(DTORatio[3]), .A1(n373), .B0(PWDATA[3]), .B1(n210), .Y(
        n184) );
  AO22X1 U483 ( .A0(DTORatio[4]), .A1(n372), .B0(PWDATA[4]), .B1(n210), .Y(
        n185) );
  AO22X1 U484 ( .A0(DTORatio[5]), .A1(n209), .B0(PWDATA[5]), .B1(n210), .Y(
        n186) );
  AO22X1 U485 ( .A0(DTORatio[6]), .A1(n209), .B0(PWDATA[6]), .B1(n210), .Y(
        n187) );
  AO22X1 U486 ( .A0(DTORatio[7]), .A1(n372), .B0(PWDATA[7]), .B1(n210), .Y(
        n188) );
  AO22X1 U487 ( .A0(DTORatio[8]), .A1(n209), .B0(PWDATA[8]), .B1(n210), .Y(
        n189) );
  AO22X1 U488 ( .A0(DTORatio[9]), .A1(n372), .B0(PWDATA[9]), .B1(n210), .Y(
        n190) );
  AO22X1 U489 ( .A0(DTORatio[10]), .A1(n372), .B0(PWDATA[10]), .B1(n210), .Y(
        n191) );
  AO22X1 U490 ( .A0(DTORatio[11]), .A1(n209), .B0(PWDATA[11]), .B1(n210), .Y(
        n192) );
  AO22X1 U491 ( .A0(DTORatio[12]), .A1(n209), .B0(PWDATA[12]), .B1(n210), .Y(
        n193) );
  AO22X1 U492 ( .A0(DTORatio[13]), .A1(n372), .B0(PWDATA[13]), .B1(n210), .Y(
        n194) );
  AO22X1 U493 ( .A0(DTORatio[14]), .A1(n209), .B0(PWDATA[14]), .B1(n210), .Y(
        n195) );
  AO22X1 U494 ( .A0(DTORatio[15]), .A1(n372), .B0(PWDATA[15]), .B1(n210), .Y(
        n196) );
  AO22X1 U495 ( .A0(DTORatio[16]), .A1(n372), .B0(PWDATA[16]), .B1(n210), .Y(
        n197) );
  AO22X1 U496 ( .A0(DTORatio[17]), .A1(n209), .B0(PWDATA[17]), .B1(n210), .Y(
        n198) );
  AO22X1 U497 ( .A0(MClkOE), .A1(n209), .B0(PWDATA[19]), .B1(n210), .Y(n199)
         );
  AO22X1 U498 ( .A0(MClkOn), .A1(n372), .B0(PWDATA[18]), .B1(n210), .Y(n200)
         );
  AO22X1 U499 ( .A0(RxFifoTH[0]), .A1(n368), .B0(n214), .B1(PWDATA[16]), .Y(
        n160) );
  AO22X1 U500 ( .A0(TxFifoTH[0]), .A1(n369), .B0(n214), .B1(PWDATA[0]), .Y(
        n171) );
  AO22X1 U501 ( .A0(TxWordLength[0]), .A1(n369), .B0(n214), .B1(PWDATA[9]), 
        .Y(n177) );
  AO22X1 U502 ( .A0(CtrlReg_12_), .A1(n368), .B0(n214), .B1(PWDATA[12]), .Y(
        n157) );
  AO22X1 U503 ( .A0(CtrlReg_13_), .A1(n213), .B0(n214), .B1(PWDATA[13]), .Y(
        n158) );
  AO22X1 U504 ( .A0(CtrlReg_15_), .A1(n369), .B0(n214), .B1(PWDATA[15]), .Y(
        n159) );
  AO22X1 U505 ( .A0(RxFifoTH[1]), .A1(n213), .B0(n214), .B1(PWDATA[17]), .Y(
        n161) );
  AO22X1 U506 ( .A0(RxFifoTH[2]), .A1(n369), .B0(n214), .B1(PWDATA[18]), .Y(
        n162) );
  AO22X1 U507 ( .A0(RxFifoTH[3]), .A1(n368), .B0(n214), .B1(PWDATA[19]), .Y(
        n163) );
  AO22X1 U508 ( .A0(RxEnabled), .A1(n213), .B0(n214), .B1(PWDATA[31]), .Y(n170) );
  AO22X1 U509 ( .A0(TxFifoTH[1]), .A1(n369), .B0(n214), .B1(PWDATA[1]), .Y(
        n172) );
  AO22X1 U510 ( .A0(TxFifoTH[2]), .A1(n213), .B0(n214), .B1(PWDATA[2]), .Y(
        n173) );
  AO22X1 U511 ( .A0(TxFifoTH[3]), .A1(n369), .B0(n214), .B1(PWDATA[3]), .Y(
        n174) );
  AO22X1 U512 ( .A0(TxFifoTH[4]), .A1(n213), .B0(n214), .B1(PWDATA[4]), .Y(
        n175) );
  AO22X1 U513 ( .A0(TxLeftJust), .A1(n213), .B0(n214), .B1(PWDATA[8]), .Y(n176) );
  AO22X1 U514 ( .A0(TxWordLength[1]), .A1(n369), .B0(n214), .B1(PWDATA[10]), 
        .Y(n178) );
  NAND2BX1 U515 ( .AN(n268), .B(n269), .Y(n133) );
  AO22X1 U516 ( .A0(RxFifoData[8]), .A1(n221), .B0(PRDATA[8]), .B1(n366), .Y(
        n268) );
  AOI221X1 U517 ( .A0(n245), .A1(DTORatio[8]), .B0(n235), .B1(TxLeftJust), 
        .C0(n238), .Y(n269) );
  NAND2BX1 U518 ( .AN(n263), .B(n264), .Y(n135) );
  AO22X1 U519 ( .A0(RxFifoData[10]), .A1(n221), .B0(PRDATA[10]), .B1(n367), 
        .Y(n263) );
  AOI221X1 U520 ( .A0(n245), .A1(DTORatio[10]), .B0(n235), .B1(TxWordLength[1]), .C0(n238), .Y(n264) );
  NAND2BX1 U521 ( .AN(n283), .B(n284), .Y(n125) );
  AO22X1 U522 ( .A0(RxFifoData[0]), .A1(n221), .B0(PRDATA[0]), .B1(n367), .Y(
        n283) );
  AOI222X1 U523 ( .A0(TxFifoLevel[0]), .A1(n238), .B0(n235), .B1(TxFifoTH[0]), 
        .C0(n245), .C1(DTORatio[0]), .Y(n284) );
  NAND2BX1 U524 ( .AN(n281), .B(n282), .Y(n126) );
  AO22X1 U525 ( .A0(RxFifoData[1]), .A1(n221), .B0(PRDATA[1]), .B1(n220), .Y(
        n281) );
  AOI222X1 U526 ( .A0(TxFifoLevel[1]), .A1(n238), .B0(n235), .B1(TxFifoTH[1]), 
        .C0(n245), .C1(DTORatio[1]), .Y(n282) );
  NAND2BX1 U527 ( .AN(n279), .B(n280), .Y(n127) );
  AO22X1 U528 ( .A0(RxFifoData[2]), .A1(n221), .B0(PRDATA[2]), .B1(n366), .Y(
        n279) );
  AOI222X1 U529 ( .A0(TxFifoLevel[2]), .A1(n238), .B0(n235), .B1(TxFifoTH[2]), 
        .C0(n245), .C1(DTORatio[2]), .Y(n280) );
  NAND2BX1 U530 ( .AN(n277), .B(n278), .Y(n128) );
  AO22X1 U531 ( .A0(RxFifoData[3]), .A1(n221), .B0(PRDATA[3]), .B1(n367), .Y(
        n277) );
  AOI222X1 U532 ( .A0(TxFifoLevel[3]), .A1(n238), .B0(n235), .B1(TxFifoTH[3]), 
        .C0(n245), .C1(DTORatio[3]), .Y(n278) );
  NAND2BX1 U533 ( .AN(n275), .B(n276), .Y(n129) );
  AO22X1 U534 ( .A0(RxFifoData[4]), .A1(n221), .B0(PRDATA[4]), .B1(n366), .Y(
        n275) );
  AOI222X1 U535 ( .A0(TxFifoLevel[4]), .A1(n238), .B0(n235), .B1(TxFifoTH[4]), 
        .C0(n245), .C1(DTORatio[4]), .Y(n276) );
  NAND2BX1 U536 ( .AN(n260), .B(n261), .Y(n137) );
  AO22X1 U537 ( .A0(RxFifoData[12]), .A1(n221), .B0(PRDATA[12]), .B1(n367), 
        .Y(n260) );
  AOI222X1 U538 ( .A0(StatusReg_12_), .A1(n238), .B0(n235), .B1(CtrlReg_12_), 
        .C0(n245), .C1(DTORatio[12]), .Y(n261) );
  NAND2BX1 U539 ( .AN(n258), .B(n259), .Y(n138) );
  AO22X1 U540 ( .A0(RxFifoData[13]), .A1(n221), .B0(PRDATA[13]), .B1(n366), 
        .Y(n258) );
  AOI222X1 U541 ( .A0(TxDMAReq), .A1(n238), .B0(n235), .B1(CtrlReg_13_), .C0(
        n245), .C1(DTORatio[13]), .Y(n259) );
  NAND2BX1 U542 ( .AN(n250), .B(n251), .Y(n1410) );
  AO22X1 U543 ( .A0(RxFifoData[16]), .A1(n221), .B0(PRDATA[16]), .B1(n367), 
        .Y(n250) );
  AOI222X1 U544 ( .A0(RxFifoLevel[0]), .A1(n238), .B0(n235), .B1(RxFifoTH[0]), 
        .C0(n245), .C1(DTORatio[16]), .Y(n251) );
  NAND2BX1 U545 ( .AN(n248), .B(n249), .Y(n1420) );
  AO22X1 U546 ( .A0(RxFifoData[17]), .A1(n221), .B0(PRDATA[17]), .B1(n366), 
        .Y(n248) );
  AOI222X1 U547 ( .A0(RxFifoLevel[1]), .A1(n238), .B0(n235), .B1(RxFifoTH[1]), 
        .C0(n245), .C1(DTORatio[17]), .Y(n249) );
  NAND2BX1 U548 ( .AN(n246), .B(n247), .Y(n143) );
  AO22X1 U549 ( .A0(RxFifoData[18]), .A1(n221), .B0(PRDATA[18]), .B1(n366), 
        .Y(n246) );
  AOI222X1 U550 ( .A0(RxFifoLevel[2]), .A1(n238), .B0(n235), .B1(RxFifoTH[2]), 
        .C0(n245), .C1(MClkOn), .Y(n247) );
  NAND2BX1 U551 ( .AN(n243), .B(n244), .Y(n144) );
  AO22X1 U552 ( .A0(RxFifoData[19]), .A1(n221), .B0(PRDATA[19]), .B1(n367), 
        .Y(n243) );
  AOI222X1 U553 ( .A0(RxFifoLevel[3]), .A1(n238), .B0(n235), .B1(RxFifoTH[3]), 
        .C0(n245), .C1(MClkOE), .Y(n244) );
  AO22X1 U554 ( .A0(RxFifoData[22]), .A1(n221), .B0(PRDATA[22]), .B1(n367), 
        .Y(n147) );
  AO22X1 U555 ( .A0(RxFifoData[23]), .A1(n221), .B0(PRDATA[23]), .B1(n366), 
        .Y(n148) );
  AO22X1 U556 ( .A0(RxFifoData[27]), .A1(n221), .B0(PRDATA[27]), .B1(n367), 
        .Y(n152) );
  OAI221X1 U557 ( .A0(n345), .A1(n216), .B0(n356), .B1(n218), .C0(n267), .Y(
        n134) );
  AOI22X1 U558 ( .A0(PRDATA[9]), .A1(n367), .B0(RxFifoData[9]), .B1(n221), .Y(
        n267) );
  OAI221X1 U559 ( .A0(n342), .A1(n216), .B0(n357), .B1(n218), .C0(n254), .Y(
        n140) );
  AOI22X1 U560 ( .A0(PRDATA[15]), .A1(n366), .B0(RxFifoData[15]), .B1(n221), 
        .Y(n254) );
  OAI221X1 U561 ( .A0(n353), .A1(n216), .B0(n338), .B1(n218), .C0(n219), .Y(
        n156) );
  AOI22X1 U562 ( .A0(PRDATA[31]), .A1(n367), .B0(RxFifoData[31]), .B1(n221), 
        .Y(n219) );
  OAI221X1 U563 ( .A0(n358), .A1(n218), .B0(n223), .B1(n273), .C0(n274), .Y(
        n130) );
  AOI22X1 U564 ( .A0(PRDATA[5]), .A1(n366), .B0(RxFifoData[5]), .B1(n221), .Y(
        n274) );
  OAI221X1 U565 ( .A0(n355), .A1(n216), .B0(n223), .B1(n337), .C0(n231), .Y(
        n153) );
  AOI22X1 U566 ( .A0(PRDATA[28]), .A1(n367), .B0(RxFifoData[28]), .B1(n221), 
        .Y(n231) );
  OAI221X1 U567 ( .A0(n335), .A1(n216), .B0(n223), .B1(n334), .C0(n228), .Y(
        n154) );
  AOI22X1 U568 ( .A0(PRDATA[29]), .A1(n220), .B0(RxFifoData[29]), .B1(n221), 
        .Y(n228) );
  OAI221X1 U569 ( .A0(n359), .A1(n218), .B0(n223), .B1(n336), .C0(n257), .Y(
        n139) );
  AOI22X1 U570 ( .A0(PRDATA[14]), .A1(n220), .B0(RxFifoData[14]), .B1(n221), 
        .Y(n257) );
  OAI221X1 U571 ( .A0(n339), .A1(n216), .B0(n223), .B1(n241), .C0(n242), .Y(
        n145) );
  AOI22X1 U572 ( .A0(PRDATA[20]), .A1(n367), .B0(RxFifoData[20]), .B1(n221), 
        .Y(n242) );
  OAI221X1 U573 ( .A0(n344), .A1(n218), .B0(n223), .B1(n362), .C0(n225), .Y(
        n155) );
  AOI22X1 U574 ( .A0(PRDATA[30]), .A1(n366), .B0(RxFifoData[30]), .B1(n221), 
        .Y(n225) );
  AO21X1 U575 ( .A0(RxFifoFull), .A1(n238), .B0(n239), .Y(n146) );
  AO22X1 U576 ( .A0(PRDATA[21]), .A1(n220), .B0(RxFifoData[21]), .B1(n221), 
        .Y(n239) );
  AO21X1 U577 ( .A0(RxFifoData[6]), .A1(n221), .B0(n271), .Y(n131) );
  AO22X1 U578 ( .A0(PRDATA[6]), .A1(n220), .B0(n245), .B1(DTORatio[6]), .Y(
        n271) );
  AO21X1 U579 ( .A0(RxFifoData[7]), .A1(n221), .B0(n270), .Y(n132) );
  AO22X1 U580 ( .A0(PRDATA[7]), .A1(n366), .B0(n245), .B1(DTORatio[7]), .Y(
        n270) );
  AO21X1 U581 ( .A0(RxFifoData[11]), .A1(n221), .B0(n262), .Y(n136) );
  AO22X1 U582 ( .A0(PRDATA[11]), .A1(n367), .B0(n245), .B1(DTORatio[11]), .Y(
        n262) );
  AO21X1 U583 ( .A0(RxFifoData[25]), .A1(n221), .B0(n234), .Y(n150) );
  AO22X1 U584 ( .A0(PRDATA[25]), .A1(n366), .B0(n235), .B1(RxWordLength[0]), 
        .Y(n234) );
  OAI211X1 U585 ( .A0(n361), .A1(n216), .B0(n223), .C0(n237), .Y(n149) );
  AOI22X1 U586 ( .A0(PRDATA[24]), .A1(n220), .B0(RxFifoData[24]), .B1(n221), 
        .Y(n237) );
  OAI211X1 U587 ( .A0(n360), .A1(n216), .B0(n223), .C0(n233), .Y(n151) );
  AOI22X1 U588 ( .A0(PRDATA[26]), .A1(n366), .B0(RxFifoData[26]), .B1(n221), 
        .Y(n233) );
  OA22X1 U589 ( .A0(RxFifoLevel[1]), .A1(n340), .B0(RxFifoLevel[2]), .B1(n350), 
        .Y(n315) );
  NAND2BX1 U590 ( .AN(n352), .B(TxFifoUnderRun), .Y(n300) );
  OAI221X1 U591 ( .A0(RxFifoTH[3]), .A1(n310), .B0(RxFifoTH[2]), .B1(n311), 
        .C0(n312), .Y(n309) );
  INVX1 U592 ( .A(RxFifoLevel[2]), .Y(n311) );
  INVX1 U593 ( .A(RxFifoLevel[3]), .Y(n310) );
  OAI221X1 U594 ( .A0(RxFifoLevel[1]), .A1(n364), .B0(n364), .B1(n340), .C0(
        n315), .Y(n312) );
  AOI211X1 U595 ( .A0(n306), .A1(n307), .B0(RxReset), .C0(n353), .Y(N142) );
  OA21X2 U596 ( .A0(RxFifoTH[4]), .A1(n241), .B0(n318), .Y(n306) );
  OAI221X1 U597 ( .A0(RxFifoLevel[4]), .A1(n339), .B0(RxFifoLevel[3]), .B1(
        n348), .C0(n309), .Y(n307) );
  INVX1 U598 ( .A(RxFifoFull), .Y(n318) );
  OAI222X1 U599 ( .A0(TxFifoLevel[2]), .A1(n341), .B0(TxFifoLevel[3]), .B1(
        n349), .C0(n325), .C1(n326), .Y(n321) );
  AOI211X1 U600 ( .A0(TxFifoTH[1]), .A1(n328), .B0(TxFifoTH[0]), .C0(n329), 
        .Y(n325) );
  AO22X1 U601 ( .A0(TxFifoLevel[1]), .A1(n351), .B0(TxFifoLevel[2]), .B1(n341), 
        .Y(n326) );
  OAI32X1 U602 ( .A0(n336), .A1(TxReset), .A2(StatusReg_12_), .B0(TxReset), 
        .B1(n294), .Y(n122) );
  NAND2BX1 U603 ( .AN(StatusReg_14_), .B(TxFifoAfford2Read), .Y(n294) );
  AO21X1 U604 ( .A0(StatusReg_30_), .A1(n337), .B0(n287), .Y(n124) );
  AO21X1 U605 ( .A0(RxFifoAfford2Write), .A1(n337), .B0(RxReset), .Y(n287) );
  AND4X1 U606 ( .A(n273), .B(n346), .C(CtrlReg_15_), .D(n319), .Y(N141) );
  AO22X1 U607 ( .A0(n320), .A1(n321), .B0(TxFifoTH[4]), .B1(n322), .Y(n319) );
  OA22X1 U608 ( .A0(TxFifoTH[4]), .A1(n322), .B0(TxFifoTH[3]), .B1(n330), .Y(
        n320) );
  INVX1 U609 ( .A(TxFifoLevel[4]), .Y(n322) );
  AND2X2 U610 ( .A(n365), .B(RxFifoLevel[0]), .Y(n364) );
  INVX1 U611 ( .A(TxFifoFull), .Y(n273) );
  OAI32X1 U612 ( .A0(TxReset), .A1(n119), .A2(TxFifoEmpty), .B0(TxReset), .B1(
        n342), .Y(n120) );
  OAI221X1 U613 ( .A0(n354), .A1(n343), .B0(n335), .B1(n334), .C0(n333), .Y(
        N115) );
  NOR2BX1 U614 ( .AN(n347), .B(StatusReg_28_), .Y(n333) );
  DFFRX1 DTORatio_reg_5_ ( .D(n186), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[5]), 
        .QN(n358) );
  DFFRX1 DTORatio_reg_9_ ( .D(n190), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[9]), 
        .QN(n356) );
  DFFRX1 DTORatio_reg_14_ ( .D(n195), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[14]), .QN(n359) );
  DFFRX1 DTORatio_reg_15_ ( .D(n196), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[15]), .QN(n357) );
  DFFRX1 DTORatio_reg_6_ ( .D(n187), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[6])
         );
  DFFRX1 DTORatio_reg_7_ ( .D(n188), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[7])
         );
  DFFRX1 DTORatio_reg_11_ ( .D(n192), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[11]) );
  DFFRX1 DTORatio_reg_8_ ( .D(n189), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[8])
         );
  DFFRX1 DTORatio_reg_10_ ( .D(n191), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[10]) );
  DFFRX1 DTORatio_reg_0_ ( .D(n181), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[0])
         );
  DFFRX1 DTORatio_reg_1_ ( .D(n182), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[1])
         );
  DFFRX1 DTORatio_reg_2_ ( .D(n183), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[2])
         );
  DFFRX1 DTORatio_reg_3_ ( .D(n184), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[3])
         );
  DFFRX1 DTORatio_reg_4_ ( .D(n185), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[4])
         );
  DFFRX1 DTORatio_reg_12_ ( .D(n193), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[12]) );
  DFFRX1 DTORatio_reg_13_ ( .D(n194), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[13]) );
  DFFRX1 DTORatio_reg_16_ ( .D(n197), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[16]) );
  DFFRX1 DTORatio_reg_17_ ( .D(n198), .CK(PCLK), .RN(PRESETn), .Q(DTORatio[17]) );
  DFFRX1 MClkOn_reg ( .D(n200), .CK(PCLK), .RN(PRESETn), .Q(MClkOn) );
  DFFRX1 RxWLen_reg_1_ ( .D(n167), .CK(PCLK), .RN(PRESETn), .Q(RxWordLength[1]), .QN(n360) );
  DFFRX1 TxWLen_reg_1_ ( .D(n178), .CK(PCLK), .RN(PRESETn), .Q(TxWordLength[1]) );
  DFFRX1 TxEnabled_reg ( .D(n120), .CK(PCLK), .RN(PRESETn), .Q(TxEnabled), 
        .QN(n119) );
  DFFSX1 RxReset_reg ( .D(N21), .CK(PCLK), .SN(PRESETn), .Q(RxReset) );
  DFFRX1 RxLJust_reg ( .D(n165), .CK(PCLK), .RN(PRESETn), .Q(RxLeftJust), .QN(
        n361) );
  DFFSX1 EnRxFifoORInt_reg ( .D(n124), .CK(PCLK), .SN(PRESETn), .Q(
        StatusReg_30_), .QN(n362) );
  DFFRX1 TxFifoTH_reg_3_ ( .D(n174), .CK(PCLK), .RN(PRESETn), .Q(TxFifoTH[3]), 
        .QN(n349) );
  DFFRX1 RxFifoTH_reg_4_ ( .D(n164), .CK(PCLK), .RN(PRESETn), .Q(RxFifoTH[4]), 
        .QN(n339) );
  DFFRX1 TxFifoTH_reg_1_ ( .D(n172), .CK(PCLK), .RN(PRESETn), .Q(TxFifoTH[1]), 
        .QN(n351) );
  DFFRX1 RxFifoTH_reg_2_ ( .D(n162), .CK(PCLK), .RN(PRESETn), .Q(RxFifoTH[2]), 
        .QN(n350) );
  DFFRX1 RxFifoTH_reg_3_ ( .D(n163), .CK(PCLK), .RN(PRESETn), .Q(RxFifoTH[3]), 
        .QN(n348) );
  DFFRX1 TxFifoURIntEn_reg ( .D(n157), .CK(PCLK), .RN(PRESETn), .Q(CtrlReg_12_), .QN(n352) );
  DFFRX1 TxDMAIntEn_reg ( .D(n158), .CK(PCLK), .RN(PRESETn), .Q(CtrlReg_13_), 
        .QN(n354) );
  DFFRX1 RxFifoTH_reg_1_ ( .D(n161), .CK(PCLK), .RN(PRESETn), .Q(RxFifoTH[1]), 
        .QN(n340) );
  DFFRX1 TxFifoTH_reg_2_ ( .D(n173), .CK(PCLK), .RN(PRESETn), .Q(TxFifoTH[2]), 
        .QN(n341) );
  DFFRX1 RxFifoORIntEn_reg ( .D(n168), .CK(PCLK), .RN(PRESETn), .Q(CtrlReg_28_), .QN(n355) );
  DFFRX1 TxFifoURInt_reg ( .D(n121), .CK(PCLK), .RN(PRESETn), .Q(StatusReg_12_), .QN(n347) );
  DFFRX1 EnTxFifoURInt_reg ( .D(n122), .CK(PCLK), .RN(PRESETn), .Q(
        StatusReg_14_), .QN(n336) );
  DFFRX1 MClkOE_reg ( .D(n199), .CK(PCLK), .RN(PRESETn), .Q(MClkOE) );
  DFFSX1 RxFifoTH_reg_0_ ( .D(n160), .CK(PCLK), .SN(PRESETn), .Q(RxFifoTH[0]), 
        .QN(n365) );
  DFFSX1 TxFifoTH_reg_0_ ( .D(n171), .CK(PCLK), .SN(PRESETn), .Q(TxFifoTH[0])
         );
  DFFSX1 nTxFifoWriteEn_reg ( .D(N25), .CK(PCLK), .SN(PRESETn), .Q(
        nTxFifoWriteEn) );
  DFFRX1 TxDMAReq_reg ( .D(N141), .CK(PCLK), .RN(PRESETn), .Q(TxDMAReq), .QN(
        n343) );
  DFFRX1 RxDMAReq_reg ( .D(N142), .CK(PCLK), .RN(PRESETn), .Q(RxDMAReq), .QN(
        n334) );
  DFFRX1 TxEn_reg ( .D(n159), .CK(PCLK), .RN(PRESETn), .Q(CtrlReg_15_), .QN(
        n342) );
  DFFRX1 RxEn_reg ( .D(n170), .CK(PCLK), .RN(PRESETn), .Q(RxEnabled), .QN(n353) );
  DFFRX1 TxLJust_reg ( .D(n176), .CK(PCLK), .RN(PRESETn), .Q(TxLeftJust) );
  DFFRX1 RxFifoORInt_reg ( .D(n123), .CK(PCLK), .RN(PRESETn), .Q(StatusReg_28_), .QN(n337) );
  DFFRX1 RxDMAIntEn_reg ( .D(n169), .CK(PCLK), .RN(PRESETn), .Q(CtrlReg_29_), 
        .QN(n335) );
  DFFRX1 PRDATA_reg_5_ ( .D(n130), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[5]) );
  DFFRX1 PRDATA_reg_9_ ( .D(n134), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[9]) );
  DFFRX1 PRDATA_reg_14_ ( .D(n139), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[14]) );
  DFFRX1 PRDATA_reg_15_ ( .D(n140), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[15]) );
  DFFRX1 PRDATA_reg_20_ ( .D(n145), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[20]) );
  DFFRX1 PRDATA_reg_24_ ( .D(n149), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[24]) );
  DFFRX1 PRDATA_reg_26_ ( .D(n151), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[26]) );
  DFFRX1 PRDATA_reg_28_ ( .D(n153), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[28]) );
  DFFRX1 PRDATA_reg_29_ ( .D(n154), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[29]) );
  DFFRX1 PRDATA_reg_30_ ( .D(n155), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[30]) );
  DFFRX1 PRDATA_reg_31_ ( .D(n156), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[31]) );
  DFFRX1 PRDATA_reg_6_ ( .D(n131), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[6]) );
  DFFRX1 PRDATA_reg_7_ ( .D(n132), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[7]) );
  DFFRX1 PRDATA_reg_11_ ( .D(n136), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[11]) );
  DFFRX1 PRDATA_reg_21_ ( .D(n146), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[21]) );
  DFFRX1 PRDATA_reg_25_ ( .D(n150), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[25]) );
  DFFRX1 PRDATA_reg_0_ ( .D(n125), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[0]) );
  DFFRX1 PRDATA_reg_1_ ( .D(n126), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[1]) );
  DFFRX1 PRDATA_reg_2_ ( .D(n127), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[2]) );
  DFFRX1 PRDATA_reg_3_ ( .D(n128), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[3]) );
  DFFRX1 PRDATA_reg_4_ ( .D(n129), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[4]) );
  DFFRX1 PRDATA_reg_8_ ( .D(n133), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[8]) );
  DFFRX1 PRDATA_reg_10_ ( .D(n135), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[10]) );
  DFFRX1 PRDATA_reg_12_ ( .D(n137), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[12]) );
  DFFRX1 PRDATA_reg_13_ ( .D(n138), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[13]) );
  DFFRX1 PRDATA_reg_16_ ( .D(n1410), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[16])
         );
  DFFRX1 PRDATA_reg_17_ ( .D(n1420), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[17])
         );
  DFFRX1 PRDATA_reg_18_ ( .D(n143), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[18]) );
  DFFRX1 PRDATA_reg_19_ ( .D(n144), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[19]) );
  DFFRX1 PRDATA_reg_22_ ( .D(n147), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[22]) );
  DFFRX1 PRDATA_reg_23_ ( .D(n148), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[23]) );
  DFFRX1 PRDATA_reg_27_ ( .D(n152), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[27]) );
  DFFRX1 TxFifoTH_reg_4_ ( .D(n175), .CK(PCLK), .RN(PRESETn), .Q(TxFifoTH[4])
         );
endmodule

