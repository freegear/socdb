setMode -acecf
setAttribute -configdevice -attr size -value "0"
setMode -acecf
addConfigDevice  -name "Untitled" -path "C:\project\ETRI_UWB\xlinix_synplify\"
addCollection -name "Untitled"
addDesign -version 0 -name "rev0"
setMode -acecf
addDeviceChain -index 0
setAttribute -configdevice -attr compressed -value "FALSE"
setAttribute -configdevice -attr compressed -value "FALSE"
setMode -acecf
setCurrentCollection -collection "Untitled"
setCurrentDesign -version 0
setCurrentDeviceChain -index 0
setCurrentDeviceChain -index 0
deleteDesign -version 0
setCurrentDesign -version -1
deleteCollection -name "Untitled"
setAttribute -configdevice -attr size -value "128000000"
setMode -acecf
addConfigDevice -size 128000000 -name "XCACECF" -path "C:\project\ETRI_UWB\xlinix_synplify\/Untitled"
addCollection -name "Untitled"
setMode -acecf
setAttribute -configdevice -attr size -value "generaic"
setAttribute -configdevice -attr reserveSize -value "0"
setAttribute -configdevice -attr name -value "XCCACE-AUTO"
addDesign -version 0 -name "rev0"
setMode -acecf
addDeviceChain -index 0
setCurrentDeviceChain -index 0
setCurrentDeviceChain -index 0
addDevice -p 1 -file "C:/project/ETRI_UWB/xlinix_synplify/xcf32p.bsd"
addDevice -p 2 -file "C:/project/ETRI_UWB/xlinix_synplify/pci_fpga.bit"
setAttribute -configdevice -attr path -value "C:\project\ETRI_UWB\xlinix_synplify"
generate -active Untitled
setMode -acecf
setMode -acecf
setMode -acecf
setAttribute -configdevice -attr size -value "0"
setMode -acecf
addConfigDevice  -name "PCI_FPGA" -path "C:\project\ETRI_UWB\xlinix_synplify\"
addCollection -name "PCI_FPGA"
addDesign -version 0 -name "rev0"
setMode -acecf
addDeviceChain -index 0
setAttribute -configdevice -attr compressed -value "FALSE"
setAttribute -configdevice -attr compressed -value "FALSE"
setMode -acecf
setCurrentCollection -collection "PCI_FPGA"
setCurrentDesign -version 0
setCurrentDeviceChain -index 0
setCurrentDeviceChain -index 0
deleteDesign -version 0
setCurrentDesign -version -1
deleteCollection -name "PCI_FPGA"
setAttribute -configdevice -attr size -value "128000000"
setMode -acecf
addConfigDevice -size 128000000 -name "XCACECF" -path "C:\project\ETRI_UWB\xlinix_synplify\/PCI_FPGA"
addCollection -name "PCI_FPGA"
setMode -acecf
setAttribute -configdevice -attr size -value "generaic"
setAttribute -configdevice -attr reserveSize -value "0"
setAttribute -configdevice -attr name -value "XCCACE-AUTO"
addDesign -version 0 -name "rev0"
setMode -acecf
addDeviceChain -index 0
setCurrentDeviceChain -index 0
setCurrentDeviceChain -index 0
addDevice -p 1 -file "C:/project/ETRI_UWB/xlinix_synplify/xcf32p.bsd"
addDevice -p 2 -file "C:/project/ETRI_UWB/xlinix_synplify/pci_fpga.bit"
setAttribute -configdevice -attr path -value "C:\project\ETRI_UWB\xlinix_synplify"
generate -active PCI_FPGA
setAttribute -configdevice -attr path -value "C:\project\ETRI_UWB\xlinix_synplify"
generate -active PCI_FPGA
setMode -acecf
setMode -acecf
setMode -acecf
setAttribute -configdevice -attr size -value "0"
setMode -acecf
addConfigDevice  -name "PCIFPGA" -path "C:\project\ETRI_UWB\xlinix_synplify\"
addCollection -name "PCIFPGA"
addDesign -version 0 -name "rev0"
setMode -acecf
addDeviceChain -index 0
setAttribute -configdevice -attr compressed -value "FALSE"
setAttribute -configdevice -attr compressed -value "FALSE"
setMode -acecf
setCurrentCollection -collection "PCIFPGA"
setCurrentDesign -version 0
setCurrentDeviceChain -index 0
setCurrentDeviceChain -index 0
deleteDesign -version 0
setCurrentDesign -version -1
deleteCollection -name "PCIFPGA"
setAttribute -configdevice -attr size -value "128000000"
setMode -acecf
addConfigDevice -size 128000000 -name "XCACECF" -path "C:\project\ETRI_UWB\xlinix_synplify\/PCIFPGA"
addCollection -name "PCIFPGA"
setMode -acecf
setAttribute -configdevice -attr size -value "generaic"
setAttribute -configdevice -attr reserveSize -value "0"
setAttribute -configdevice -attr name -value "XCCACE-AUTO"
addDesign -version 0 -name "rev0"
setMode -acecf
addDeviceChain -index 0
setCurrentDeviceChain -index 0
setCurrentDeviceChain -index 0
addDevice -p 1 -file "C:/project/ETRI_UWB/xlinix_synplify/xcf32p.bsd"
addDevice -p 2 -file "C:/project/ETRI_UWB/xlinix_synplify/pci_fpga.bit"
setAttribute -configdevice -attr path -value "C:\project\ETRI_UWB\xlinix_synplify"
generate -active PCIFPGA
setMode -bs
setMode -ss
setMode -sm
setMode -hw140
setMode -spi
setMode -acecf
setCurrentCollection -collection "PCIFPGA"
setCurrentDesign -version 0
setCurrentDeviceChain -index 0
deleteDevice -position 1
deleteDevice -position 1
setCurrentDeviceChain -index 0
deleteDesign -version 0
setCurrentDesign -version -1
deleteCollection -name "PCIFPGA"
setAttribute -configdevice -attr size -value "0"
setMode -acecf
setMode -acempm
setMode -pff
setMode -acecf
setMode -pff
