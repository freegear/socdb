/*----------------------------------------------------------
	File Name   : apimmc.c 
	Description : MMCSD test code
	Created by  : SHMT SoC Team
-----------------------------------------------------------*/

/*/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// */
#include "sysinc.h"
#include "lib.h"
#include "irq.h"
#include "uart.h"
#include "dmac.h"
#include "gpio.h"

/*/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// */
/*
#define	MMCSD_BASE		0x40000000
#define SDCON             	(*(volatile unsigned *)(MMCSD_BASE+0x00000000))
#define SDPRE             	(*(volatile unsigned *)(MMCSD_BASE+0x00000004))
#define SDCmdArg		(*(volatile unsigned *)(MMCSD_BASE+0x00000008))
#define SDCmdCon          	(*(volatile unsigned *)(MMCSD_BASE+0x0000000C))
#define SDCmdSta          	(*(volatile unsigned *)(MMCSD_BASE+0x00000010))
#define SDRSP0	       		(*(volatile unsigned *)(MMCSD_BASE+0x00000014))
#define SDRSP1	        	(*(volatile unsigned *)(MMCSD_BASE+0x00000018))
#define SDRSP2	        	(*(volatile unsigned *)(MMCSD_BASE+0x0000001C))
#define SDRSP3	        	(*(volatile unsigned *)(MMCSD_BASE+0x00000020))
#define SDDTimer        	(*(volatile unsigned *)(MMCSD_BASE+0x00000024))
#define SDBSize        		(*(volatile unsigned *)(MMCSD_BASE+0x00000028))
#define SDDatCon        	(*(volatile unsigned *)(MMCSD_BASE+0x0000002C))
#define SDDatSta        	(*(volatile unsigned *)(MMCSD_BASE+0x00000030))
#define SDFSTA	        	(*(volatile unsigned *)(MMCSD_BASE+0x00000034))
#define SDIntMsk        	(*(volatile unsigned *)(MMCSD_BASE+0x00000038))
#define SDDAT	        	(*(volatile unsigned *)(MMCSD_BASE+0x0000003C)
*/
#define SDINTSTA       	(*(volatile unsigned *)(0x40000000+0x00000040))
#define SDFBCLKCON       	(*(volatile unsigned *)(0x40000000+0x00000054))

// SDCON register
#define	SDreset			(0x1Ul)<<8 
#define ENCLK			(0x1Ul)<<0
#define PSAVEON			(0x1Ul)<<1
// SDPRE register
#define	PrescalerVal	(0xfUl)<<0

// SDCmdArg
#define	CmdArg			(0xffffUl)<<0

// SDCmdCon
#define	BusyRsp			(0x1Ul)<<14
#define	NoCRCRsp		(0x1Ul)<<13
#define	AbortCmd		(0x1Ul)<<12
#define WithData		(0x1Ul)<<11
#define LongRsp			(0x1Ul)<<10
#define	WaitRsp			(0x1Ul)<<9
#define	CMST			(0x1Ul)<<8
#define	CmdIndex		(0x7fUl)<<0
#define	CmdIndexVal		0x40

// SDCmdSta
#define	RspCrc			(0x1Ul)<<12
#define	CmdSent			(0x1Ul)<<11
#define	CmdTout			(0x1Ul)<<10
#define RspFin			(0x1Ul)<<9
#define	CmdOn			(0x1Ul)<<8
#define	RspIndex		(0x1Ul)<<0

//SDRSP0
#define	Response0		(0xffffUl)<<0
//SDRSP1
#define	Response1		(0xffffUl)<<0
#define	RCRC7			(0xffUl)<<24

//SDRSP2
#define	Response2		(0xffffUl)<<0
//SDRSP3
#define	Response3		(0xffffUl)<<0

//SDDTimer Register
#define	DataTimer		(0x1Ul)<<0

//SDBSize Register
#define BlkSize			(0xfffUl)<<0

//SDDatCon (revision for ETPlatform)
#define	DMASize			(0x3fUl)<<26
#define	TARSP			(0x1Ul)<<25
#define	RACMD			(0x1Ul)<<24
#define	ByteOrder		(0x1Ul)<<23
#define	BlkMode			(0x1Ul)<<22
#define	MMCPlus			(0x1Ul)<<21
#define	WideBus			(0x1Ul)<<20
#define	EnDMA			(0x1Ul)<<19
#define	DTST			(0x1Ul)<<18
#define	DatMode			(0x3Ul)<<16
#define	DataRx			(0x2Ul)<<16 
#define	DataTx			(0x3Ul)<<16
#define	DataNOP			(0x0Ul)<<16
#define	BlkNum			(0xffffUl)<<0

//SDDatCnt register (revision for ETplatform)
#define	BlkNumCnt		(0xffffUl)<<16
#define	BlkCnt			(0xffffUl)<<0

//SDDatSta
#define	NoBusy			(0x1Ul)<<11
#define	CrcSta			(0x1Ul)<<7
#define	DatCrc			(0x1Ul)<<6
#define	DatTout			(0x1Ul)<<5
#define	DatFin			(0x1Ul)<<4
#define	BusyFin			(0x1Ul)<<3
#define	BusyFin2		(0x1Ul)<<2
#define TxDatOn			(0x1Ul)<<1
#define	RxDatOn			(0x1Ul)<<0

//SDFSTA register
#define	FRST			(0x1Ul)<<16
#define	FFfail			(0x1Ul)<<14
#define	TFDET			(0x1Ul)<<13
#define	RFDET			(0x1Ul)<<12
#define	TFHalf			(0x1Ul)<<11
#define	TFEmpty			(0x1Ul)<<10
#define	RFFull			(0x1Ul)<<8
#define	RFHalf			(0x1Ul)<<7
#define	FFCNT			(0x3fUl)<<0

//SDIntMsk register
#define	AutoReadCompInt		(0x1Ul)<<18
#define	AutoCMD12ErrorInt	(0x1Ul)<<17
#define	AutoCMD18ErrorInt	(0x1Ul)<<16
#define	NoBusyInt		(0x1Ul)<<15
#define	RspCrcInt		(0x1Ul)<<14
#define	CmdSentInt		(0x1Ul)<<13
#define	CmdToutInt		(0x1Ul)<<12
#define	RspEndInt		(0x1Ul)<<11
#define	FFfailInt		(0x1Ul)<<10
#define	CrcStaInt		(0x1Ul)<<9
#define	DatCrcInt		(0x1Ul)<<8
#define	DatToutInt		(0x1Ul)<<7
#define	DatFinInt		(0x1Ul)<<6
#define	BusyFinInt		(0x1Ul)<<5
#define	BusyFin2Int		(0x1Ul)<<4
#define	TFHalfInt		(0x1Ul)<<3
#define	TFEmptyInt		(0x1Ul)<<2
#define	RFFullInt		(0x1Ul)<<1
#define	RFHalfInt		(0x1Ul)<<0	


#define	SD			1		
#define IncAdrType	1
#define NoIncAdrType	0
#define WidthBYTE	0x0
#define WidthHWORD	0x1
#define WidthWORD	0x2
#define TSize1B		0x0
#define TSize2B		0x1
#define TSize4B		0x2
#define TSize8B		0x3
#define TSize16B	0x4
#define TSize32B	0x5

#define MMCDMACH	0x0b 
// MMC DMA Number

/*/////////////////////////////////////////////////////////
        FUNCTION DECLARATION
///////////////////////////////////////////////////////// */
static void MMCSDIsrHandler(smtUint32 IRQ);

int SDMMCReadSingle(smtUint32 BlockSize, smtUint32 BlockAddress);
void SDMMCWriteSingle(smtUint32 BlockSize, smtUint32 BlockAddress);
void AbortCommandSend(void);
smtUint32 MMCTest(void);
smtUint32 SDMMCClockFreqSet(smtUint8 Prescaler);
smtUint32 SDMMCCmdSend(smtUint32 CmdArgValue, smtUint32 CmdConValue);
smtBoolean SDMMCInitialize(void);
smtUint32 SDMMCWaitRsp(void);
//------------simulation function----------------------------------------------------
void SDMMCWriteDMAtest(smtUint32 BlockCount, smtUint32 BlockSize, smtUint32 BlockAddress);
int SDMMCReadDMAtest(smtUint32 BlockCount, smtUint32 BlockSize, smtUint32 BlockAddress);

extern int DMAChannelAlloc(smtUint16 dma_device);
extern void DMAChannelFree(smtInt32 channelNo);

extern void Enable_IRQ(void);
extern void Disable_IRQ(void);

/*/////////////////////////////////////////////////////////
        VARIABLE DECLARATION
///////////////////////////////////////////////////////// */
smtBoolean CardType=0;
smtBoolean BitMode8=0;
smtBoolean BitMode4=0;
smtBoolean BitMode1=1;
volatile int process =1;
smtUint32 SDDATA[128*4]={0,};

/*/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////// */
/*-----------------------------------------------------------------------
    Function name   : MMCTest()
    Prototype       : smtUint32 MMCTest(void)
    Return          : 
    Argument        :
    Comments        : 
-----------------------------------------------------------------------*/
smtUint32 MMCTest(void)
{
	// interrupt enable
	//
	EnableVIC(VIC_POLARITY, VIC_LEVEL, VIC_INTMOD);
	Enable_IRQ();

	RequestIRQ(IRQ_MMC,MMCSDIsrHandler);
	SMT_WRITE(SDIntMsk, 0x00002000); //all interrupt enable // RspFin disable
//	SMT_WRITE(SDFBCLKCON, 0x00000002); // Delay Cell Select
	DPRINTF(">> MMC/SD Initialize \n\r");

	SDMMCInitialize();
	SDMMCWriteSingle(512, 0);
	SDMMCReadSingle(512, 0);
	SDMMCWriteDMAtest(4, 512, 0);
	AbortCommandSend();
	SDMMCReadDMAtest(1 , 512, 0);
	AbortCommandSend();
	Disable_IRQ();
	DisableVIC();


}

void SDMMCWriteDMAtest(smtUint32 BlockCount, smtUint32 BlockSize, smtUint32 BlockAddress)
{
	int i, dma_ch;
	for (i=0; i<(128*4) ; i++)
	{
		SDDATA[i] = i+100;
	}
	SMT_WRITE(SDBSize,(BlockSize-1));
	SMT_WRITE(SDDatCon,RACMD|TARSP);// Data NoOperation
	SMT_WRITE(SDFSTA, 0xFFFFFFFF); // FIFO reset

	SMT_WRITE(SDBSize,511);

		do 
		{
			dma_ch =DMAChannelAlloc( MMCDMACH); // 0x0b
			DPRINTF(" %d \n\r ", dma_ch);
		}
		while(dma_ch==-1);

		SMT_WRITE(SDDatCon,((0x08)<<26)|DTST|WideBus|EnDMA|DataTx|RACMD|TARSP|((4-1)&0xFFFF));// 4bit mode


	SDMMCCmdSend(BlockAddress, CMST|WaitRsp|(CmdIndexVal|25));

	for ( i =0 ; i < 4 ; i++)
	{
	
		//DMACNoDescrp(dma_ch,(unsigned int)SDDATA, IncAdrType, WidthWORD, (MMC_BASEADDR+0x44), NoIncAdrType, WidthWORD, TSize32B, BlockSize*BlockCount);
		DMACNoDescrp(dma_ch,(unsigned int)SDDATA, IncAdrType, WidthWORD, (MMC_BASEADDR+0x44), NoIncAdrType, WidthWORD, TSize32B, BlockSize);

		//DMACEnable(dma_ch);
		while((SMT_READ(DMACSta(dma_ch))&0x08)!=0x08);

//	DMACDisable(dma_ch); // Disable DMAC
	}	
//	DMACDisable(dma_ch); // Disable DMAC
	DMAChannelFree(dma_ch);

	while ((SMT_READ(SDDatSta)&0x0010) != 0x0010); // DatFin interrupt
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDDatSta,0xFFFF); // Clear DatFin bit
	SMT_WRITE(SDIntMsk,0x00002000);
}



int SDMMCReadDMAtest(smtUint32 BlockCount, smtUint32 BlockSize, smtUint32 BlockAddress)
{
	int i, dma_ch;
	int data_expected;

	// Data Nooperation setting for FIFO Flush (because of DMA signal)
	SMT_WRITE(SDDatCon,RACMD|TARSP);// Data NoOperation
	SMT_WRITE(SDFSTA, 0xFFFFFFFF); // FIFO reset

	//DMACNoDescrp(CH0, &SDDAT, NoIncAdrType, WidthWORD, SDDATA, IncAdrType, WidthWORD, TSize32B, 512);
	SMT_WRITE(SDBSize,(BlockSize-1));
	SMT_WRITE(SDDatCon,((0x08)<<26)|DTST|WideBus|EnDMA|DataRx|RACMD|TARSP|((BlockCount-1)&0xFFFF));// 4bit mode
	for (i=0 ; i< 128; i++)
	{
		SDDATA[i]=0;
	}
	
	do 
	{
		dma_ch =DMAChannelAlloc( MMCDMACH); // 0x0b
		DPRINTF(" %d \n\r ", dma_ch);
	}
	while(dma_ch==-1);


	//CMD17(READ_SINGLE_BLOCK)	
	SDMMCCmdSend(BlockAddress, CMST|WaitRsp|(CmdIndexVal|18)); // SD�� ���ؼ� CMD18�� ����
	DMACNoDescrp(dma_ch, (MMC_BASEADDR+0x44), NoIncAdrType, WidthWORD, (unsigned int) SDDATA, IncAdrType, WidthWORD, TSize32B, BlockSize*BlockCount);
	//DMACEnable(dma_ch);
		while((SMT_READ(DMACSta(dma_ch))&0x08)!=0x08);

	while ((SMT_READ(SDDatSta)&0x0010) != 0x0010); // DatFin interrupt detect
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDIntMsk,0x00002000);
	SMT_WRITE(SDDatSta,0xFFFF); // Clear DatFin bit
	DMACDisable(dma_ch);
	DMAChannelFree(dma_ch);
	

	for (i=0; i<128 ; i++)
		{
			data_expected = i+100;
			if (data_expected != SDDATA[i])
				goto error;
		}
	return 0;
error :
	GPIOWrite(0xAde00|((SDDATA[i])&0xff));
	return 0;
//	GPIOWrite(0xAde03);

}
/*-----------------------------------------------------------------------
    Function name   : SDMMCClockFreqSet()
    Prototype       : smtUint32 SDMMCClockFreqSet(smtUint8 Prescaler)
    Return          : 
    Argument        :
    Comments        : Prescaler Setting
-----------------------------------------------------------------------*/
smtUint32 SDMMCClockFreqSet(smtUint8 Prescaler)
{
	SMT_WRITE(SDPRE,Prescaler);
	return 0;
}
/*-----------------------------------------------------------------------
    Function name   : SDMMCCmdSend()
    Prototype       : smtUint32 SDMMCCmdSend(int CmdArgValue, int CmdConValue)
    Return          : 
    Argument        :
    Comments        : command argument setting and command control reg set

-----------------------------------------------------------------------*/

smtUint32 SDMMCCmdSend(smtUint32 CmdArgValue, smtUint32 CmdConValue)
{
	SMT_WRITE(SDCmdArg, CmdArgValue); 
	SMT_WRITE(SDCmdCon, CmdConValue);
  	//Command Sent Check(falling checking)
	//while((SMT_READ(SDCmdSta)&CmdSent)!=CmdSent);
	return 0;
}

/*-----------------------------------------------------------------------
    Function name   : SDMMCWaitRsp()
    Prototype       : smtUint32 SDMMCWaitRsp(void)
    Return          : SDCmdSta Value
    Argument        :
    Comments        : Return a error-code

-----------------------------------------------------------------------*/
smtUint32 SDMMCWaitRsp(void)
{
	while(((SMT_READ(SDCmdSta)&RspFin)!=RspFin)&&((SMT_READ(SDCmdSta)&CmdTout)!=CmdTout));
	return 0;
}

/*-----------------------------------------------------------------------
    Function name   : SDMMCInitialize()
    Prototype       : smtBoolean SDMMCInitialize(void)
    Return          : error code
    Argument        :
    Comments        : Return a error-code

-----------------------------------------------------------------------*/
smtBoolean SDMMCInitialize(void)
{
	smtUint32 	OCR_Register=0;
	smtUint32	CID_Register0=0;
	smtUint32	CID_Register1=0;
	smtUint32	CID_Register2=0;
	smtUint32	CID_Register3=0;
	smtUint32	CSD_Register0=0;
	smtUint32	CSD_Register1=0;
	smtUint32	CSD_Register2=0;
	smtUint32	CSD_Register3=0;
	//smtUint32	CardStatus=0;
 	smtUint32	APP_CMD41arg=0x00000000;
	smtUint32	RCA_ADDRESS=0;	
	smtUint32	SCRH=0;	
	smtUint32	SCRL=0;	
	//smtUint32	multply_val, i, j, k;
	//smtUint32	C_SIZE_MULT, C_SIZE;
	smtUint32	received_status;
	smtBoolean CardType=0;
	smtBoolean BitMode8=0;
	smtBoolean BitMode4=0;
	smtBoolean BitMode1=1;

	// MMC Power ON
	GPIOOutputEnable(SMT_READ(GPIO0_OE)|0x80000000);
	GPIOWrite(SMT_READ(GPIO0_OUT)&0x7FFFFFFF);


	// Prescaler setting 
	SDMMCClockFreqSet(0x0);  // Low Frequecy  (spec. 400KHz)
	DPRINTF("0");
	
	// Clock Enable
	//SMT_WRITE(SDCON, ENCLK|PSAVEON);
	SMT_WRITE(SDCON, ENCLK);
	DPRINTF("0x%08x ", SMT_READ(SDCON));
	DPRINTF("0x%08x ", SMT_READ(SDPRE));
	
	// Interrupt Enable or Disable
	//SMT_WRITE(SDIntMsk,0x00000000); // ALL interrupt disable
	process = 1;	
// CMD0 (GO_IDLE_STATE) No response Command 
	SDMMCCmdSend(0x00000000, CMST|(CmdIndexVal|0));
	while(process);
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDIntMsk,0x00002000);


	//------------ACMD41------------
APP_CMD41:	//CMD55
	process =1;
	SDMMCCmdSend(0x00000000, CMST|WaitRsp|(CmdIndexVal|55)); // 0x37 == 55
	while(process);
	SDMMCWaitRsp();
	received_status = SMT_READ(SDCmdSta);
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDIntMsk,0x00002000);


	if ((received_status&RspFin)==RspFin) // CMD55�� ���� ������ �ִ� ���
	{
		
		//CMD41
		process = 1;
		SDMMCCmdSend(APP_CMD41arg, NoCRCRsp|CMST|WaitRsp|(CmdIndexVal|41));
		while(process);
		SDMMCWaitRsp();
		received_status = SMT_READ(SDCmdSta);
		SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
		SMT_WRITE(SDIntMsk,0x00002000);
	
		if  ((received_status&RspFin)==RspFin)
		{
			if((SMT_READ(SDRSP0)&0x80000000)==0x00000000)	// ī�尡 initialize�� ���� �ʾ����� Ŀ�ǵ� ������
			{
				APP_CMD41arg= SDRSP0; // OCR���� ���־�� busy flag�� clear��
				goto APP_CMD41;
			}
			else
			{
				CardType =1; // SD Card
			}
		}
	
		else if ((received_status&CmdTout)==CmdTout) // CMD41�� ���� ������ ���� ���
		{
			// response time out
			//CMD1
			process = 1;
			SDMMCCmdSend(0x00000000, CMST|WaitRsp|NoCRCRsp|(CmdIndexVal|1));
			while(process);
			SDMMCWaitRsp();
			received_status = SMT_READ(SDCmdSta);
			SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
			SMT_WRITE(SDIntMsk,0x00002000);
			if ((received_status&CmdTout)==CmdTout)
			{
				DPRINTF("Check the Card Socket: Card Present Not Insert\n\r");
				
				return 0; // No card 
			}
			else
			{
				CardType=0; // MMC CardType
			}
		}

	}
	else if ((received_status&CmdTout)==CmdTout) // ACMD41�� ���� ������ ���� ���
	{
		DPRINTF("Response not receive\n\r");

CMD1:		//CMD1
		process = 1;
		SDMMCCmdSend(0x00ff8000, NoCRCRsp|CMST|WaitRsp|(CmdIndexVal|1));
		// voltage range�� ���� ������ ������ busy�� ���ƿ��� ������ ��
		while(process);
		SDMMCWaitRsp();
		received_status = SMT_READ(SDCmdSta);
		SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
		SMT_WRITE(SDIntMsk,0x00002000);

		if ((received_status&CmdTout)==CmdTout)
		{
			DPRINTF("Check the Card Socket: Card Present Not Insert\n\r");
			return 0; // No card 
		}
	}

	OCR_Register = SMT_READ(SDRSP0);
	DPRINTF("	OCR_Register: 0x%08x \n\r" ,OCR_Register);
	if ((OCR_Register & 0x80000000)==0x00000000) // Card Busy Check
	{
		DPRINTF("Card is Busy \n\r");
		if (CardType ==1) // SD 
		goto APP_CMD41;
		else		// MMC
		goto CMD1;
	}
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// CARD Support Voltage range check
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	DPRINTF("CARD Support Voltage >> ");
	if ((OCR_Register & 0x00000080)==0x80) // Card Voltage Check
	DPRINTF("Dual Voltage Card\n\r");
	else 
	DPRINTF("High Voltage Only Card\n\r");

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	//CMD2
	process = 1;
	SDMMCCmdSend(0x00000000, CMST|WaitRsp|LongRsp|(CmdIndexVal|2));
	while(process);
	SDMMCWaitRsp();
	received_status = SMT_READ(SDCmdSta);
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDIntMsk,0x00002000);


	DPRINTF("0x%08x \n\r",SMT_READ(SDCmdSta));

	CID_Register0 = SMT_READ(SDRSP0);
	CID_Register1 = SMT_READ(SDRSP1);
	CID_Register2 = SMT_READ(SDRSP2);
	CID_Register3 = SMT_READ(SDRSP3);
	DPRINTF("---CID_Register0: 0x%08x \n\r",CID_Register0);
	DPRINTF("---CID_Register1: 0x%08x \n\r",CID_Register1);
	DPRINTF("---CID_Register2: 0x%08x \n\r",CID_Register2);
	DPRINTF("---CID_Register3: 0x%08x \n\r",CID_Register3);

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	if (CardType)// SD Card
	{	
		//CMD3
		DPRINTF(">> Send CMD3 (Set RCA)\n\r");

		// RCA address ������  ��û�ؾ��Ѵ�..
		// Argument�� 0���� �Ͽ� RCA�� �����.
		// Response�� R6 ����
		SDMMCCmdSend(0x00000000, CMST|NoCRCRsp|WaitRsp|(CmdIndexVal|3));
		SDMMCWaitRsp();
		SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
		DPRINTF("---CardStatus:  ");
		RCA_ADDRESS =SMT_READ(SDRSP0);
		DPRINTF("0x%08x \n\r",RCA_ADDRESS);
	}

	else // MMC card
	{
		DPRINTF(">> Send CMD3 (Set RCA)\n\r");
		process = 1;
		SDMMCCmdSend(0x00010000, CMST|WaitRsp|(CmdIndexVal|3));
		//������  RCA ����
		while(process);
		SDMMCWaitRsp();
		SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
		SMT_WRITE(SDIntMsk,0x00002000);
		RCA_ADDRESS = 0x00010000;
	}

	//CMD9
	DPRINTF(">> Send CMD9 (Send Card Specific Data)\n\r");

	process= 1;

	SDMMCCmdSend(RCA_ADDRESS, CMST|WaitRsp|LongRsp|(CmdIndexVal|9));
	while(process);
	SDMMCWaitRsp();
	received_status = SMT_READ(SDCmdSta);
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDIntMsk,0x00002000);

	CSD_Register0 = SMT_READ(SDRSP0);
	CSD_Register1 = SMT_READ(SDRSP1);
	CSD_Register2 = SMT_READ(SDRSP2);
	CSD_Register3 = SMT_READ(SDRSP3);

	DPRINTF("---CSD_Register0: 0x%08x \n\r",CSD_Register0);
	DPRINTF("---CSD_Register1: 0x%08x \n\r",CSD_Register1);
	DPRINTF("---CSD_Register2: 0x%08x \n\r",CSD_Register2);
	DPRINTF("---CSD_Register3: 0x%08x \n\r",CSD_Register3);

//---------------------------------------------------------------------------------------------------
	
	// CMD7
	// ADDRESS ����.. SD�� ���, ����� address�� �ִ´�.
	process= 1;	
	DPRINTF(">> Send CMD7 (Send Select Card)\n\r");
	SDMMCCmdSend(RCA_ADDRESS, CMST|WaitRsp|(CmdIndexVal|7));
	while(process);
	SDMMCWaitRsp();
	received_status = SMT_READ(SDCmdSta);
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDIntMsk,0x00002000);
	DPRINTF("---CardStatus: 0x%08x \n\r", SMT_READ(SDRSP0));


	// READ SCR Register
	if (CardType)
	{
		// Read SCR register
		//
		// Don't Using Interrrupt Because 64bit SCR register data does not check CRC
		DPRINTF(">> Send ACMD51 (Send SCR)\n\r");
		process =1;
		SDMMCCmdSend(RCA_ADDRESS, CMST|WaitRsp|(CmdIndexVal|55)); // 0x37 == 55
		while(process);
		DPRINTF(">> Wait CMD55 Response \n\r");

		SDMMCWaitRsp();
		received_status = SMT_READ(SDCmdSta);
		SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
		SMT_WRITE(SDIntMsk,0x00002000);

		SMT_WRITE(SDBSize,7); // SCR register size is 64 bit
		// Data Nooperation setting for FIFO Flush (because of DMA signal)
		SMT_WRITE(SDDatCon,TARSP|RACMD);// Data NoOperation
		SMT_WRITE(SDFSTA, 0xFFFFFFFF); // FIFO reset
		SMT_WRITE(SDDatCon,DTST|ByteOrder|DataRx|BlkMode);// SCR�� ��� �д� ����� �ٸ�
		DPRINTF(">> Send CMD51 for SCR Register Read (ACMD51) \n\r");
		SDMMCCmdSend(0x00000000, CMST|WaitRsp|(CmdIndexVal|51));
		DPRINTF(">> Wait CMD51 Response \n\r");
		SDMMCWaitRsp();
		DPRINTF("---Response CardStatus:  0x%08x \n\r", SMT_READ(SDRSP0));


		while ((SMT_READ(SDDatSta)&DatFin) != DatFin)// FIFO Cnt check 64 bit get?
		{

		DPRINTF("DATA STATUS : 0x%08d\n\r",SMT_READ(SDDatSta)); //
		DPRINTF("FIFO STATUS : 0x%08d\n\r",SMT_READ(SDFSTA)); //
		DPRINTF("DATA COUNT	 : 0x%08d\n\r",SMT_READ(SDDatCnt)); // 
		}
		SMT_WRITE(SDDatSta,0xFFFFFFFF)
		DPRINTF("SCR Value : ");
		SCRH=(SMT_READ(SDDAT)); // 
		SCRL=(SMT_READ(SDDAT)); // 
		DPRINTF("0x%08x ", SCRH); // 
		DPRINTF("  0x%08x \n\r", SCRL); // 
	}


	// CARD Detect Pin Pull-up resistor Off Command 
	if (CardType)
	{	// Pull up register �� ���� ���� command ACMD42�� �������ߵȴ�.
		DPRINTF(">> Send CMD55 (APP_CMD)\n\r");
		SDMMCCmdSend(RCA_ADDRESS, CMST|WaitRsp|(CmdIndexVal|55));
		SDMMCWaitRsp();
		DPRINTF("---Response CardStatus:  0x%08x \n\r", SMT_READ(SDRSP0));

		SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
		DPRINTF(">> Send CMD42 (Pull-up resistor OFF)\n\r");
		SDMMCCmdSend(0x00000000, CMST|WaitRsp|(CmdIndexVal|42));
		SDMMCWaitRsp();
		DPRINTF("---Response CardStatus:  0x%08x \n\r", SMT_READ(SDRSP0));
		SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	}

	// Card Bus Width Select (8bit, 4bit, 1bit)
	// SD Card�� ��� SCR register�� �о� �����Ǵ� ������ �˼� �ִ�.
	// MMC�� spec version(?)���� �� �� �ִ�.
	// SD�� ACMD6�� ������
	// MMC�� CMD6�� ������.
	if (CardType)
	{
		// SD CARD �� ACMD6�� ���� Bus Width�� ������ �ȴ�.
		DPRINTF(">> Send CMD55 (APP_CMD)\n\r");
		SDMMCCmdSend(RCA_ADDRESS, CMST|WaitRsp|(CmdIndexVal|55));
		SDMMCWaitRsp();
		DPRINTF("---Response CardStatus: 0x%08x \n\r", SMT_READ(SDRSP0));
		SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	}
	//CMD6(SWITCH) select bus width
	DPRINTF(">> Send CMD6 (Switch CMD)\n\r");
	DPRINTF("4Bit DataWidth transmit\n\r");
	if (CardType)
		{
			SDMMCCmdSend(0x00000002, CMST|WaitRsp|BusyRsp|(CmdIndexVal|6));
		//	SDMMCCmdSend(0x00000000, CMST|WaitRsp|(CmdIndexVal|6));// 1bit Bus
			BitMode8=0;
			BitMode4=1;
			BitMode1=0;
		}
	else
	{	
		if ((CSD_Register0 &0x3c000000)>>26 == 0x0004)// spec version 4.0-4.1 
		{
			//	{SDMMCCmdSend(0x03B70200, CMST|WaitRsp|BusyRsp|(CmdIndexVal|6));}// 8Bit bus   // Busy response �߰� 
			process = 1;
			SDMMCCmdSend(0x03B70100, CMST|WaitRsp|(CmdIndexVal|6));// 4Bit bus for ETPlatform
			while(process);

			//	{SDMMCCmdSend(0x03B70000, CMST|WaitRsp|(CmdIndexVal|6));}// 1Bit bus
			BitMode8=0;
			DPRINTF("MMC 4 bit MODE \n\r");
			BitMode4=1;
			BitMode1=0;

		}
		else
		{
			process = 1;
			SDMMCCmdSend(0x03B70000, CMST|WaitRsp|(CmdIndexVal|6));
			while(process);
			BitMode8=0;
			BitMode4=0;
			BitMode1=1;
		}// 1Bit bus

	}
	SDMMCWaitRsp();
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDIntMsk,0x00002000);
	DPRINTF("---Response CardStatus:  0x%08x \n\r", SMT_READ(SDRSP0));
	process =1;
	SDMMCCmdSend(RCA_ADDRESS, CMST|WaitRsp|(CmdIndexVal|13));
	while(process);
	SDMMCWaitRsp();
	DPRINTF("0x%08x\n\r",SMT_READ(SDRSP0));
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDIntMsk,0x00002000);
	// Block length setting
	if (!CardType)
	{
		//CMD16(Set Block length)
		process = 1;
		DPRINTF("Block Length setting  512byte block\n\r");
		SDMMCCmdSend(512, CMST|WaitRsp|(CmdIndexVal|16));
		while(process);
		SDMMCWaitRsp();
		SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
		SMT_WRITE(SDIntMsk,0x00002000);
		DPRINTF("	CardStatus:  0x%08x\n\r",SMT_READ(SDRSP0));
	}


	// Power Save Mode On
	SMT_WRITE(SDCON, ENCLK|PSAVEON);
	// Fast Clock Change 
	SDMMCClockFreqSet(0x0);  

	return 0;
}
/*-----------------------------------------------------------------------
    Function name   : SDMMCReadSingle()
    Prototype       : void SDMMCReadSingle(smtUint32 BlockSize, smtUint32 BlockAddress)
    Return          : 
    Argument        :
    Comments        :  MMC Single Block Read function
-----------------------------------------------------------------------*/
int SDMMCReadSingle(smtUint32 BlockSize, smtUint32 BlockAddress)
{
	int i;
	int data, data_expected;
	//Block Size Setting
	SMT_WRITE(SDBSize,(BlockSize-1));

	SMT_WRITE(SDDTimer,0x001fffff);

	// Data Nooperation setting for FIFO Flush (because of DMA signal)
	SMT_WRITE(SDDatCon,RACMD|TARSP);// Data NoOperation
	SMT_WRITE(SDFSTA, 0xFFFFFFFF); // FIFO reset

	// ���� ������� bus width ������ start
//	if (BitMode8)
//	{	
//		SMT_WRITE(SDDatCon,DTST|MMCPlus|WideBus|DataRx|RACMD|BlkMode|TARSP);// 8bit mode
//	}
//	else if (BitMode4)
//	{	
		SMT_WRITE(SDDatCon,DTST|WideBus|DataRx|RACMD|BlkMode|TARSP);// 4bit mode
//	}
//	else if (BitMode1)
//	{
//		SMT_WRITE(SDDatCon,DTST|DataRx|RACMD|BlkMode|TARSP);// 1bit mode
//	}

	//CMD17(READ_SINGLE_BLOCK)	
	process = 1;
	SDMMCCmdSend(BlockAddress, CMST|WaitRsp|(CmdIndexVal|17));
	while(process);
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDIntMsk,0x00002000);
	while((SMT_READ(SDFSTA)&0x1000)!=0x1000);  // RX Available Check
	while((SMT_READ(SDFSTA)&0x100)!=0x100);		// RX FULL
		DPRINTF("0x%08x\n\r", SMT_READ(SDFSTA));
	for (i=1; i<33 ; i++)
	{
		data_expected = i;
		data = SMT_READ(SDDAT);
		if(data != data_expected)
		goto error;
	}


	while((SMT_READ(SDFSTA)&0x100)!=0x100);		// RX FULL
	for (i=1; i<33 ; i++)
	{
		data_expected = i+32;
		data = SMT_READ(SDDAT);
		if(data != data_expected)
		goto error;

	}

	while((SMT_READ(SDFSTA)&0x100)!=0x100);		// RX FULL
	for (i=1; i<33 ; i++)
	{
		data_expected = i+64;
		data = SMT_READ(SDDAT);
		if(data != data_expected)
		goto error;

	}

	while((SMT_READ(SDFSTA)&0x100)!=0x100);		// RX FULL
	for (i=1; i<33 ; i++)
	{
		data_expected = i+96;
		data = SMT_READ(SDDAT);
		if(data != data_expected)
		goto error;
	}

	while((SMT_READ(SDDatSta)&0x00000010) !=0x00000010);
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDDatSta,0xFFFF); // Clear DatFin bit

	return 0;
error :
	GPIOWrite(0xAde03);
	return 0;

}
/*-----------------------------------------------------------------------
    Function name   : SDMMCWriteSingle()
    Prototype       : smtUint32 MMCWriteSingle(void)
    Return          : 
    Argument        :
    Comments        :  MMC Single Block Write function
-----------------------------------------------------------------------*/
void SDMMCWriteSingle(smtUint32 BlockSize,  smtUint32 BlockAddress)
{
	// Block ��  1-128���� ����.
	int i;
	// Data Nooperation setting for FIFO Flush (because of DMA signal)
	SMT_WRITE(SDDatCon,0x00000000);// Data NoOperation
	SMT_WRITE(SDFSTA, 0xFFFFFFFF); // FIFO reset
	//Block Size Setting
	SMT_WRITE(SDBSize,(BlockSize-1));
//	if (BitMode8)
//	{
//		SMT_WRITE(SDDatCon,DTST|MMCPlus|WideBus|DataTx|RACMD|BlkMode|TARSP);// 8bit mode
//	}
//	else if (BitMode4)
//	{
		SMT_WRITE(SDDatCon,DTST|WideBus|DataTx|RACMD|BlkMode|TARSP);// 4bit mode
//	}
//	else if (BitMode1)
//	{
//		SMT_WRITE(SDDatCon,DTST|DataTx|RACMD|BlkMode|TARSP);// 1bit mode
//	}

	while((SMT_READ(SDFSTA)&0x2000) != 0x2000);// FIFO available check


	// fifo Depth is 32
	for (i=1; i<33 ; i++)
	{
		SMT_WRITE(SDDAT,i);
	}

	process = 1;
	SDMMCCmdSend(BlockAddress, CMST|WaitRsp|(CmdIndexVal|24));//Single Write Command Send
	while(process);
	while((SMT_READ(SDFSTA)&0x400) != 0x400);


	for (i=33; i<65 ; i++)
	{
		SMT_WRITE(SDDAT,i);

		DPRINTF("0x%08x ", SMT_READ(SDFSTA));
		DPRINTF(" : %d \n\r ",i);
	}
	while((SMT_READ(SDFSTA)&0x400) != 0x400);

	for (i=65; i<97 ; i++)
	{
		SMT_WRITE(SDDAT,i);

		DPRINTF("0x%08x ", SMT_READ(SDFSTA));
		DPRINTF(" : %d \n\r ",i);
	}
	while((SMT_READ(SDFSTA)&0x400) != 0x400);

	for (i=97; i<129; i++)
	{
		SMT_WRITE(SDDAT,i);

		DPRINTF("0x%08x ",SMT_READ(SDFSTA));
		DPRINTF(" : %d \n\r ",i);
	}
	while((SMT_READ(SDFSTA)&0x400) != 0x400);

	SDMMCWaitRsp();
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDIntMsk,0x00002000);

	DPRINTF("	CardStatus:  ");
	DPRINTF("0x%08x ",SMT_READ(SDRSP0));
	DPRINTF("\n\r");
	
	while(SMT_READ(SDDatCnt)!=0x00000000);
	DPRINTF("	DATA Status Register:  ");
	DPRINTF("0x%08x ",SMT_READ(SDDatSta));
	DPRINTF("\n\r");

	while((SMT_READ(SDDatSta)&0x00000010) !=0x00000010)
	{
		DPRINTF("	DATA Status Register:  ");
		DPRINTF("0x%08x ",SMT_READ(SDDatSta));
		DPRINTF("\n\r");
		DPRINTF("	DatCount Register:  ");
		DPRINTF("0x%08x ",SMT_READ(SDDatCnt));
		DPRINTF("\n\r");
		DPRINTF("FIFO STATUS: ");
		DPRINTF("0x%08x ",SMT_READ(SDFSTA));
		DPRINTF("\n\r");
	}

	SMT_WRITE(SDDatSta,0xFFFFFFFF);// SDDatSta register Clear
	DPRINTF("	DATA Status Register:  ");
	DPRINTF("0x%08x ",SMT_READ(SDDatSta));
	DPRINTF("\n\r");
	DPRINTF("FIFO STATUS: ");
	DPRINTF("0x%08x ",SMT_READ(SDFSTA));
	DPRINTF("\n\r");

	DPRINTF("Single Block Write Command Transmit : CMD24\n\r");

}

void AbortCommandSend(void)
{
	SMT_WRITE(SDCmdArg, 0x00000000); 
	process = 1;
	SMT_WRITE(SDCmdCon, CMST|WaitRsp|BusyRsp|0x4C);
	while(process);
	while((SMT_READ(SDCmdSta)&0x200)!=0x200);
	SMT_WRITE(SDCmdSta,0xFFFF); // Clear CmdSent bit
	SMT_WRITE(SDIntMsk,0x00002000);
}

/*-----------------------------------------------------------------------
    Function name   : MMCSDIsr()
    Prototype       : static void MMCSDIsr(smtUint32 IRQ)
    Return          : 
    Argument        :
    Comments        :  MMC interrupt handle function
-----------------------------------------------------------------------*/
static void MMCSDIsrHandler(smtUint32 IRQ)
{
	DPRINTF("SDCmdSta register: 0x%08x \n\r",SMT_READ(SDCmdSta));
	DPRINTF("SDDatSta register: 0x%08x \n\r",SMT_READ(SDDatSta));
	DPRINTF("SDFSTA register: 0x%08x \n\r",SMT_READ(SDFSTA));
	SMT_WRITE(GPIO1_OUT, SMT_READ(SDINTSTA));  //
	GPIOWrite(0xAdd00);
	process = 0;
	SMT_WRITE(SDIntMsk,0x00000000);
	GPIOWrite(0xAd100);
}

