#include "Commonmacro.h"
#include "i2c.h"
#include "irq.h"
#include "gpio.h"

// 
//
//

extern void Enable_IRQ(void);
extern void Disable_IRQ(void);


int I2CTest(void) // EEPROM Model Simulation
{
	unsigned char data;
	unsigned char data_expected;
	
	EnableVIC(VIC_POLARITY, VIC_LEVEL, VIC_INTMOD);
	Enable_IRQ();

	RequestIRQ(IRQ_I2C, I2CIsrHandler);

	I2CInit(0x10); // Clock Setting
	data =0;
	data_expected = 0x32;

	I2C1ByteWrite(0x50,0x01,data_expected);
	I2C1ByteRead(0x50, 0x01, &data);
	if(data != data_expected)
	goto error;

	data_expected = 0x54;
	I2C1ByteWrite(0x50,0x01,data_expected);
	I2C1ByteRead(0x50, 0x01,  &data);
	if(data != data_expected)
	goto error;

	Disable_IRQ();
	DisableVIC();
	return 0;
error:
	// GPIO Write
	// Read Data and Write Data Not Matched
	GPIOWrite(0xAde00|(data &0xff));
//	GPIOWrite(0xAde02);
	return 0;


}
