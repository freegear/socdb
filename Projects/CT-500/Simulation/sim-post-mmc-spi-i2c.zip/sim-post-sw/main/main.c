/*----------------------------------------------------------
	File Name   : main.c 
	Description : Application Entry Point File
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/

/*/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// */
#define  __GCC_ARM__  1
#include "sysinc.h"
#include "Commonmacro.h"

#include "gpio.h"
#include "uart.h"
#include "dmac.h"

#include "memorymap.h"
/*/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// */
#define BLACK	0xff000000
#define BLUE	0xffff0000
#define GREEN	0xff00ff00
#define CYAN	0xffffff00
#define RED		0xff0000ff
#define MAGENTA	0xffff00ff
#define YELLOW	0xff00ffff
#define WHITE	0xffffffff

/*/////////////////////////////////////////////////////////
        FUNCTION DECLARATION
///////////////////////////////////////////////////////// */
extern int SPITest(void);
extern smtUint32 MMCTest(void);
extern int I2CTest(void);


/*/////////////////////////////////////////////////////////
        VARIABLE DECLARATION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////// */
/*-----------------------------------------------------------------------
    Function name   : main()
    Prototype           : void main(void)
    Return              : void
    Argument        :
    Comments        :
-----------------------------------------------------------------------*/
int main(void)
{
	GPIOOutputEnable(0x800fffff);
	GPIOWrite(0xA4321);

	GPIOWrite(0xA4322);

	DPRINTF("Power On Self Test Start\n");

	SMT_WRITE(SYSTEMMUXCON,0x00000030);// System controller mux setting 0x5000_4010
	SMT_WRITE(GPIO0MUXCON,0x00100000);// System controller mux setting 0x5000_4014
	SMT_WRITE(ICCR0_0,0x00010000); // I2C Reset
	SPITest(); // SPI Test
	MMCTest();
	I2CTest();
	GPIOWrite(0xAd122);

    while(1);

	return 0;
}

void UndefHandler(unsigned *sp, unsigned spsr, unsigned lr)
{
	int i;
	UartPrintf("Register Dump at 0x%08x(SPSR:0x%08x LR:0x%08x)\n", (unsigned)sp, spsr, lr);
	for(i = 0; i < 15; i++)
		UartPrintf("0x%08x\n", *(sp+i));
}
