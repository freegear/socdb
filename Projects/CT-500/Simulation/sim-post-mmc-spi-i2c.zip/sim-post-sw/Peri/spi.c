/*----------------------------------------------------------
	File Name   : spi.c 
	Description : spi API code
	Created by  : SHMT SoC Team
-----------------------------------------------------------*/

/*/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// */
#include "Commonmacro.h"
#include "spi.h"
/*/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// */

// register MAP
#define SPI_BASEADDR		(APB1_STARTADDR+0x8000)
#define SPICON(x)			(*(volatile unsigned *)(SPI_BASEADDR+0x000+((x)*0x20)))
#define SPIPRE(x)			(*(volatile unsigned *)(SPI_BASEADDR+0x004+((x)*0x20)))
#define SPISTA(x)			(*(volatile unsigned *)(SPI_BASEADDR+0x008+((x)*0x20)))
#define SPIINTDMA(x)		(*(volatile unsigned *)(SPI_BASEADDR+0x00C+((x)*0x20)))
#define SPIINTSTA(x)		(*(volatile unsigned *)(SPI_BASEADDR+0x010+((x)*0x20)))
#define SPITXDAT(x)			(*(volatile unsigned *)(SPI_BASEADDR+0x014+((x)*0x20)))
#define SPIRXDAT(x)			(*(volatile unsigned *)(SPI_BASEADDR+0x018+((x)*0x20)))
// This Hidden register (confidential)
#define SPIHIDDEN(x)		(*(volatile unsigned *)(SPI_BASEADDR+0x01C+((x)*0x20)))

/*
// register MAP
#define SPI1_BASEADDR			(APB1_STARTADDR+0x8020)
#define SPICON1				(*(volatile unsigned *)(SPI1_BASEADDR+0x000))
#define SPIPRE1				(*(volatile unsigned *)(SPI1_BASEADDR+0x004))
#define SPISTA1				(*(volatile unsigned *)(SPI1_BASEADDR+0x008))
#define SPIINTDMA1			(*(volatile unsigned *)(SPI1_BASEADDR+0x00C))
#define SPIINTSTA1			(*(volatile unsigned *)(SPI1_BASEADDR+0x010))
#define SPITXDAT1			(*(volatile unsigned *)(SPI1_BASEADDR+0x014))
#define SPIRXDAT1			(*(volatile unsigned *)(SPI1_BASEADDR+0x018))
// This Hidden register (confidential)
#define SPIHIDDEN1			(*(volatile unsigned *)(SPI1_BASEADDR+0x01C))
*/

// SPICON register
#define SPIENABLE			(0x1Ul)<<3
#define	MS					(0x1Ul)<<2


// SPICON register
#define SPIENABLE			(0x1Ul)<<3
#define	MS					(0x1Ul)<<2
#define CPOL				(0x1Ul)<<1
#define	CPHA				(0x1Ul)<<0

// SPIPRE register
#define	SPIPRESCALER		(0xffUl)<<0
#define SPIDIVIDER			(0xffUl)<<8
	// PCLK/(SPIDIVIDE*(SPIRESCALER+1))

// SPISTA register
#define SPITXFIFOFULL		(0x1Ul)<<5
#define SPITXFIFOEMPTY		(0x1Ul)<<4
#define SPIRXFIFOFULL		(0x1Ul)<<3
#define SPIRXFIFOEMPTY		(0x1Ul)<<2
#define SPIBUSY				(0x1Ul)<<1
#define	SPIERROR			(0x1Ul)<<0

// SPIINTDMA
#define SPITXFINTEN			(0x1Ul)<<13
#define SPIRXFINTEN			(0x1Ul)<<12
#define SPIRXTOUTINTEN		(0x1Ul)<<11
#define SPIRXFOVRINTEN		(0x1Ul)<<10
#define SPITXDMAREQEN		(0x1Ul)<<9
#define SPITXDMALEVEL		(0xFUl)<<5
#define SPIRXDMAREQEN		(0x1Ul)<<4
#define SPIRXDMALEVEL		(0xFUl)<<0

// SPIINTSTA
#define RTIC				(0x1Ul)<<5
#define RORIC				(0x1Ul)<<4
#define TXFIFOINTSTA		(0x1Ul)<<3
#define RXFIFOINTSTA		(0x1Ul)<<2
#define RXTOUTINTSTA		(0x1Ul)<<1
#define RXOVRINTSTA			(0x1Ul)<<0

// SPITXDAT
#define TXDAT				(0xFFFFUl)<<0

// SPIRXDAT
#define	RXDAT				(0xFFFFUl)<<0

// SPIHIDDEN
#define DATASIZE			(0xFUl)<<4
#define	MODE				(0x3Ul)<<2
#define	SLAVEOEN			(0x1Ul)<<1
#define	LBM					(0x1Ul)<<0

// SPI DMA Channel
#define SPIRXDMACH			0 			// DMAREQ0
#define SPITXDMACH			1			// DMAREQ1


#define IncAdrType			1
#define NoIncAdrType		0
#define WidthBYTE			0x0
#define WidthHWORD			0x1
#define WidthWORD			0x2
#define TSize1B				0x0
#define TSize2B				0x1
#define TSize4B				0x2
#define TSize8B				0x3
#define TSize16B			0x4
#define TSize32B			0x5

/*/////////////////////////////////////////////////////////
        FUNCTION DECLARATION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        VARIABLE DECLARATION
///////////////////////////////////////////////////////// */


/*/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////// */

/*-----------------------------------------------------------------------
    Function name   : void SPIInit(char channel, smtUint32 PreVal, smtUint32 DivVal)
    Prototype       : SPIInit(char channel, smtUint32 PreVal, smtUint32 DivVal)
    Return          : void
    Argument        :
    Comments        : SPI Initialize
-----------------------------------------------------------------------*/
void SPIInit(char channel, smtUint32 PreVal, smtUint32 DivVal)
{
		//PCLK/(SPIDIVIDE*(SPIRESCALER+1))
		SMT_WRITE(SPIPRE(channel), 	(PreVal & SPIPRESCALER )|(DivVal& SPIDIVIDER)); 	// Prescaler Setting


		
	/*	SMT_WRITE(SPIINTDMA(channel),	
							  ( ((1<<13)&SPITXFINTEN) 	|	// Tx FIFO Interrupt
								((1<<12)&SPIRXFINTEN)	|	// RX FIFO Interrupt
                                ((1<<11)&SPIRXTOUTINTEN)|	// RX Time Out Interrupt
                                ((1<<10)&SPIRXFOVRINTEN)|	// RX FIFO Overrun Interrupt	
                                ((1<<9)&SPITXDMAREQEN)	|	// TX DMA Request Enable
                                ((1<<5)&SPITXDMALEVEL)	|	// TX DMA Request Level Setting
                                ((1<<4)&SPIRXDMAREQEN)	|	// RX DMA Request Enable
                                ((1<<0)&SPIRXDMALEVEL)	));	// RX DMA Request Level Setting
	*/							

		SMT_WRITE(SPIINTDMA(channel),	
							  ( ((0<<13)&SPITXFINTEN) 	|	// Tx FIFO Interrupt
								((0<<12)&SPIRXFINTEN)	|	// RX FIFO Interrupt
                                ((0<<11)&SPIRXTOUTINTEN)|	// RX Time Out Interrupt
                                ((0<<10)&SPIRXFOVRINTEN)|	// RX FIFO Overrun Interrupt	
                                ((0<<9)&SPITXDMAREQEN)	|	// TX DMA Request Enable
                                ((1<<5)&SPITXDMALEVEL)	|	// TX DMA Request Level Setting
                                ((0<<4)&SPIRXDMAREQEN)	|	// RX DMA Request Enable
                                ((1<<0)&SPIRXDMALEVEL)	));	// RX DMA Request Level Setting

		/*SMT_WRITE(SPICON(channel), 	((1<<3)&SPIENABLE)| // SPI Enable  0: Disable 1: Enable
									((0<<2)&MS)|		// SPI Master/Slave Mode Select 0: Master 1: Slave
									((1<<1)&CPOL)|		// SPI Mode3 Setting
									((1<<1)&CPHA)
								); 						// Control Register Setting
		*/
		SMT_WRITE(SPICON(channel), 	((1<<3)&SPIENABLE)| // SPI Enable  0: Disable 1: Enable
									((0<<2)&MS)|		// SPI Master/Slave Mode Select 0: Master 1: Slave
									((0<<1)&CPOL)|		// SPI Mode0 Setting
									((0<<1)&CPHA)
								); 						// Control Register Setting
		
}


/*void SPIDMAInit()
{


}
*/

void SPIOnebyteWrite(char channel, char data)
{
	SMT_WRITE(SPITXDAT(channel),data);
}

char SPIOnebyteRead(char channel)
{
		return SMT_READ(SPIRXDAT(channel));
}

