/*----------------------------------------------------------
	File Name   : s25fl008a.c
	Description : s25fl008 Test code
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/
#include "Commonmacro.h"
#include "spi.h"
#include "uart.h"
#include "sysinc.h"
#include "lib.h"
#include "irq.h"
#include "dmac.h"
#include "gpio.h"

extern int DMAChannelAlloc(smtUint16 dma_device);
extern void DMAChannelFree(smtInt32 channelNo);


static void SSPinOutputEn(void);
static void SSPinLow(void);
static void SSPinHigh(void);
static void SPISel(unsigned ch);


static char SPI0ReadID(void);
static char SPI0ReadIDDMA(void);

int SPITest(void);

int SPITest(void)
{

	SSPinOutputEn() ; 
	char Check;
	SPIInit(0, 0x02, 0x2);

	SSPinOutputEn(); // GPIO Output Mode for SS pin

	SPISel(0);
//	Check = SPI0ReadID();
	Check = SPI0ReadIDDMA();
	if (Check==0x00)// SPIO ID Read
		goto error;
	return 0;
error:
	// Error Code
	GPIOWrite(0xAde01);
	return 0;
}


static void SSPinOutputEn(void)
{
	SMT_WRITE(GPIO0_OE, SMT_READ(GPIO0_OE)|0x00100000); // /SS pin is GPIO0 
}

static void SSPinLow(void)
{
	SMT_WRITE(GPIO0_OUT, (SMT_READ(GPIO0_OUT)&0xFFEFFFFF));  //
}

static void SSPinHigh(void)
{
	SMT_WRITE(GPIO0_OUT, SMT_READ(GPIO0_OUT)|0x00100000);  //HIGH

}
static void SPISel(unsigned ch)
{

	SMT_WRITE(GPIO1_OE, SMT_READ(GPIO1_OE)|0x00000002); 
	if (ch == 1)
	{
		SMT_WRITE(GPIO1_OUT, SMT_READ(GPIO1_OUT)&0xFFFFFFFD);  //LOW
	}	
	else
	{
		SMT_WRITE(GPIO1_OUT, SMT_READ(GPIO1_OUT)|0x00000002);  //HIGH
	}
}
//--------------channel 0 test-----------------------
static char SPI0ReadID(void)
{
	unsigned int data;
	SSPinLow(); // Slave Select Low
	SPIOnebyteWrite(0, 0x9f);
	SPIOnebyteWrite(0, 0x00);
	SPIOnebyteWrite(0, 0x00);
	SPIOnebyteWrite(0, 0x00);
	SPIOnebyteWrite(0, 0x00);
	SPIOnebyteWrite(0, 0x00);
	SPIOnebyteWrite(0, 0x00);
	SPIOnebyteWrite(0, 0x00);

	while((SMT_READ(SPISTA(0))&0x08)==0x00);// Rx Full??

	SSPinHigh(); // Slave Select Low
	
	SPIOnebyteRead(0);		/* Dummy Remove */ 
//	SPIOnebyteRead(0);		/* Dummy Remove */ 
//	SPIOnebyteRead(0);		/* Dummy Remove */ 
//	SPIOnebyteRead(0);		/* Dummy Remove */ 


	//S25FL008a ID is 0x01 0x02 0x07
	data = SPIOnebyteRead(0);		/* receive byte */
	if (data != 0x01)
			return 0;
	data = SPIOnebyteRead(0);		/* receive byte */
	if (data != 0x02)
			return 0;
	data = SPIOnebyteRead(0);		/* receive byte */
	if (data != 0x07)
			return 0;
	return 1;
	
}


static char SPI0ReadIDDMA(void)
{

	int rxdma_ch;
	int txdma_ch;
	unsigned int SPITxData[8];
	unsigned int SPIRxData[8];
	do 
	{
	rxdma_ch =DMAChannelAlloc(6);
	}
	while(rxdma_ch==-1);
	do 
	{
	txdma_ch =DMAChannelAlloc(5);
	}
	while(txdma_ch==-1);

	SPITxData[0] = 0x9f;
	SPITxData[1] = 0x00;
	SPITxData[2] = 0x00;
	SPITxData[3] = 0x00;
	SPITxData[4] = 0x00;
	SPITxData[5] = 0x00;
	SPITxData[6] = 0x00;
	SPITxData[7] = 0x00;

	SMT_WRITE(SPIINTDMA(0),0x318); // RX TX DMA Setting
	SSPinLow(); // Slave Select Low

	DMACNoDescrp(txdma_ch,(unsigned int)SPITxData, IncAdrType, WidthWORD, (SPI_BASEADDR+0x14), NoIncAdrType, WidthWORD, TSize32B, 32);
	DMACNoDescrp(rxdma_ch, (SPI_BASEADDR+0x18), NoIncAdrType, WidthWORD, (unsigned int) SPIRxData, IncAdrType, WidthWORD, TSize32B, 32);
//	DMACEnable(rxdma_ch);
//	DMACEnable(txdma_ch);

	while((SMT_READ(DMACSta(txdma_ch))&0x08)!=0x08);
	while((SMT_READ(DMACSta(rxdma_ch))&0x08)!=0x08);

	DMACDisable(txdma_ch); // Disable DMAC
	DMAChannelFree(txdma_ch);
	DMACDisable(rxdma_ch); // Disable DMAC
	DMAChannelFree(rxdma_ch);

	SSPinHigh(); // Slave Select Low
	
	if (SPIRxData[1] != 0x01)
			return 0;
	if (SPIRxData[2] != 0x02)
			return 0;
	if (SPIRxData[3] != 0x07)
			return 0;
	return 1;
	
}
