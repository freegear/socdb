#ifndef _DMAC_INTERNAL_H
#define _DMAC_INTERNAL_H
// DMASAdr
#define SourceAddr	(0xffffffff)<<0
// DMADAdr
#define DestinationAddr	(0xffffffff)<<0

// DMACCon
#define StartIntEn	(0x01Ul)<<31
#define EndIntEn	(0x01Ul)<<30
#define M2M		(0x01Ul)<<29
#define SrcIncr		(0x01Ul)<<28
#define SrcWidth	(0x03Ul)<<26
#define DstIncr		(0x01Ul)<<25
#define DstWidth	(0x03Ul)<<23
#define Size		(0x07Ul)<<20
#define TransferLength	(0xfffffUl)<<0

// DMACDescrp
#define DescrAddr	(0xffffffffUl)<<2
#define DescrEnd	(0x1Ul)<<0

// DMACSta
#define	Enable		(0x1Ul)<<31
#define	Active		(0x1Ul)<<27
#define	StopIntEn	(0x1Ul)<<4
#define	StopInt		(0x1Ul)<<3
#define	StartInt	(0x1Ul)<<2
#define	EndInt		(0x1Ul)<<1
#define	ErrorInt	(0x1Ul)<<0

#endif
