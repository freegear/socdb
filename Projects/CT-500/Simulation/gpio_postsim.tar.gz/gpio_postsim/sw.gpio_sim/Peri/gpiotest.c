/*----------------------------------------------------------
	File Name   : i2s.c 
	Description : i2s Controller test code
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/
#include "sysinc.h"
#include "Commonmacro.h"
#include "irq.h"

#define REG_READ_WRITE_ERR	0xa0
#define INT_TEST_ERR	0xa1

static void inline GPIODie(unsigned data)
{
	SMT_WRITE(GPIO1_OE, 0x00000000);
	SMT_WRITE(GPIO0_OE, 0xffffffff);
	SMT_WRITE(GPIO0_OUT, data);
	while(1)
		;
}

static void RegCheck(volatile unsigned *addr, unsigned reset_value)
{
	int i;
	unsigned data;

	data = *addr;
	if(data != reset_value)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);

	*addr = 0xffffffff;
	data = *addr;
	if(data != 0xffffffff)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);

	*addr = 0xaaaaaaaa;
	data = *addr;
	if(data != 0xaaaaaaaa)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);

	*addr = 0x55555555;
	data = *addr;
	if(data != 0x55555555)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);

	for(i = 0; i < 32; i++)
	{
		*addr = (1UL<<i);
		data = *addr;
		if(data != (1UL<<i))
			GPIODie(0xde00 | REG_READ_WRITE_ERR);
	}

	*addr = reset_value;
	data = *addr;
	if(data != reset_value)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);
}

static void GPIORegReadWriteTest(void)
{
	int i;
	unsigned data0, data1, data2;

	RegCheck(&GPIO0_OE, 0x00000000);
	RegCheck(&GPIO0_INTLEVEL, 0x00000000);
	RegCheck(&GPIO0_INTPOL, 0x00000000);
	RegCheck(&GPIO0_INTBEDGE, 0x00000000);
	RegCheck(&GPIO0_INTEN, 0x00000000);
	SMT_WRITE(GPIO0_INTSTAT, 0xffffffff);	// clear all interrupts

	SMT_WRITE(GPIO0_OE, 0xffffffff);		// output enable

	data0 = SMT_READ(GPIO0_OUT);
	data1 = SMT_READ(GPIO0_IN);
	data2 = SMT_READ(GPIO1_IN);
	if(data0 != 0x00005678 || data1 != 0x00005678 || data2 != 0x00005678)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);
	
	SMT_WRITE(GPIO0_OUT, 0xffffffff);
	data0 = SMT_READ(GPIO0_OUT);
	data1 = SMT_READ(GPIO0_IN);
	data2 = SMT_READ(GPIO1_IN);
	if(data0 != 0xffffffff || data1 != 0xffffffff || data2 != 0xffffffff)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);
	
	SMT_WRITE(GPIO0_OUT, 0xaaaaaaaa);
	data0 = SMT_READ(GPIO0_OUT);
	data1 = SMT_READ(GPIO0_IN);
	data2 = SMT_READ(GPIO1_IN);
	if(data0 != 0xaaaaaaaa || data1 != 0xaaaaaaaa || data2 != 0xaaaaaaaa)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);

	SMT_WRITE(GPIO0_OUT, 0x55555555);
	data0 = SMT_READ(GPIO0_OUT);
	data1 = SMT_READ(GPIO0_IN);
	data2 = SMT_READ(GPIO1_IN);
	if(data0 != 0x55555555 || data1 != 0x55555555 || data2 != 0x55555555)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);

	for(i = 0; i < 32; i++)
	{
		SMT_WRITE(GPIO0_OUT, (1UL<<i));
		data0 = SMT_READ(GPIO0_OUT);
		data1 = SMT_READ(GPIO0_IN);
		data2 = SMT_READ(GPIO1_IN);
		if(data0 != (1UL<<i) || data1 != (1UL<<i) || data2 != (1UL<<i))
			GPIODie(0xde00 | REG_READ_WRITE_ERR);
	}

	SMT_WRITE(GPIO0_OUT, 0x00000000);
	data0 = SMT_READ(GPIO0_OUT);
	data1 = SMT_READ(GPIO0_IN);
	data2 = SMT_READ(GPIO1_IN);
	if(data0 != 0x00000000 || data1 != 0x00000000 || data2 != 0x00000000)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);

	SMT_WRITE(GPIO0_OE, 0x00000000);		// output disable

	RegCheck(&GPIO1_OE, 0x00000000);
	RegCheck(&GPIO1_INTLEVEL, 0x00000000);
	RegCheck(&GPIO1_INTPOL, 0x00000000);
	RegCheck(&GPIO1_INTBEDGE, 0x00000000);
	RegCheck(&GPIO1_INTEN, 0x00000000);
	SMT_WRITE(GPIO1_INTSTAT, 0xffffffff);	// clear all interrupts

	SMT_WRITE(GPIO1_OE, 0xffffffff);		// output enable

	data0 = SMT_READ(GPIO1_OUT);
	data1 = SMT_READ(GPIO1_IN);
	data2 = SMT_READ(GPIO0_IN);
	if(data0 != 0x00005678 || data1 != 0x00005678 || data2 != 0x00005678)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);
	
	SMT_WRITE(GPIO1_OUT, 0xffffffff);
	data0 = SMT_READ(GPIO1_OUT);
	data1 = SMT_READ(GPIO1_IN);
	data2 = SMT_READ(GPIO0_IN);
	if(data0 != 0xffffffff || data1 != 0xffffffff || data2 != 0xffffffff)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);
	
	SMT_WRITE(GPIO1_OUT, 0xaaaaaaaa);
	data0 = SMT_READ(GPIO1_OUT);
	data1 = SMT_READ(GPIO1_IN);
	data2 = SMT_READ(GPIO0_IN);
	if(data0 != 0xaaaaaaaa || data1 != 0xaaaaaaaa || data2 != 0xaaaaaaaa)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);

	SMT_WRITE(GPIO1_OUT, 0x55555555);
	data0 = SMT_READ(GPIO1_OUT);
	data1 = SMT_READ(GPIO1_IN);
	data2 = SMT_READ(GPIO0_IN);
	if(data0 != 0x55555555 || data1 != 0x55555555 || data2 != 0x55555555)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);

	for(i = 0; i < 32; i++)
	{
		SMT_WRITE(GPIO1_OUT, (1UL<<i));
		data0 = SMT_READ(GPIO1_OUT);
		data1 = SMT_READ(GPIO1_IN);
		data2 = SMT_READ(GPIO0_IN);
		if(data0 != (1UL<<i) || data1 != (1UL<<i) || data2 != (1UL<<i))
			GPIODie(0xde00 | REG_READ_WRITE_ERR);
	}

	SMT_WRITE(GPIO1_OUT, 0x00000000);
	data0 = SMT_READ(GPIO1_OUT);
	data1 = SMT_READ(GPIO1_IN);
	data2 = SMT_READ(GPIO0_IN);
	if(data0 != 0x00000000 || data1 != 0x00000000 || data2 != 0x00000000)
		GPIODie(0xde00 | REG_READ_WRITE_ERR);

	SMT_WRITE(GPIO1_OE, 0x00000000);		// output disable
}

static volatile unsigned interrupted_pin[2];
static volatile unsigned allowed_level_pin[2];
static volatile unsigned allowed_edge_pin[2];

static void GPIOISR(unsigned irq)
{
	int ch;
	unsigned inten, intstat, intlevel, interrupt_pin, data, temp;

	switch(irq)
	{
	case IRQ_GPIO0:
		ch = 0;
		break;
	case IRQ_GPIO1:
		ch = 1;
		break;
	default:
		GPIODie(0xde00 | INT_TEST_ERR);
	}

	inten = SMT_READ(GPIO_INTEN(ch));
	intstat = SMT_READ(GPIO_INTSTAT(ch));
	intlevel = SMT_READ(GPIO_INTLEVEL(ch));

	interrupt_pin = inten&intstat;
	if(interrupt_pin == 0)	// something wrong
		GPIODie(0xde00 | INT_TEST_ERR);
	
	if((interrupt_pin & interrupted_pin[ch]) != 0)	// already interrupted pin
		GPIODie(0xde00 | INT_TEST_ERR);

	interrupted_pin[ch] |= interrupt_pin;	// add to already interrupted pin

	data = interrupt_pin & intlevel;

	if(data != 0)	// level interrupt acknowledge
	{
		temp = SMT_READ(GPIO_OUT(ch^0x01));
		temp ^= data;
		SMT_WRITE(GPIO_OUT(ch^0x01), temp);
	}

	if(allowed_level_pin[ch] != 0 && (data & allowed_level_pin[ch]) == 0)	// wrong pin
		GPIODie(0xde00 | (INT_TEST_ERR+1));

	if((data^allowed_level_pin[ch])&(~allowed_level_pin[ch]))	// wrong pin
		GPIODie(0xde00 | (INT_TEST_ERR+2));

	// edge interrupt acknowledge
	data = interrupt_pin & (~intlevel);
	SMT_WRITE(GPIO_INTSTAT(ch), data);

	if(allowed_edge_pin[ch] != 0 && (data & allowed_edge_pin[ch]) == 0)	// wrong pin
		GPIODie(0xde00 | (INT_TEST_ERR+3));

	if((data^allowed_edge_pin[ch])&(~allowed_edge_pin[ch]))	// wrong pin
		GPIODie(0xde00 | (INT_TEST_ERR+3));
}

static int  WaitForInterrupt(int ch, unsigned prev_value)
{
	int i;
	for(i = 0; i < 20; i++)
	{
		if(prev_value != interrupted_pin[ch])
			return 1;	// interrupt occured
	}

	return 0;	// interrupt not occured
}

static void GPIOIntrTest(void)
{
	int ch, nch;
	int i, j;
	unsigned data, prev;
	unsigned active_high_level;
	unsigned active_low_level;
	unsigned active_high_edge;
	unsigned active_low_edge;
	unsigned active_both_edge;

	for(ch = 0; ch < 2; ch++)
	{
		allowed_level_pin[ch] = 0;
		allowed_edge_pin[ch] = 0;
		interrupted_pin[ch] = 0;
		SMT_WRITE(GPIO_INTEN(ch), 0);	// interrupt disable NOW
		SMT_WRITE(GPIO_OE(ch), 0);
	}

	EnableVIC(VIC_POLARITY, VIC_LEVEL, VIC_INTMOD);
	Enable_IRQ();
	RequestIRQ(IRQ_GPIO0, GPIOISR);
	RequestIRQ(IRQ_GPIO1, GPIOISR);

	for(ch = 0; ch < 2; ch++)
	{
		nch = ch ^ 0x01;
		SMT_WRITE(GPIO_OE(ch), 0);
		SMT_WRITE(GPIO_OE(nch), 0);

		// Interrupt Mask Test
		SMT_WRITE(GPIO_INTEN(ch), 0x00000000);
		SMT_WRITE(GPIO_INTPOL(ch), 0xffffffff);		// active high
		SMT_WRITE(GPIO_INTLEVEL(ch), 0xffffffff);		// level interrupt

		SMT_WRITE(GPIO_OUT(nch), 0x00000000);
		SMT_WRITE(GPIO_OE(nch), 0xffffffff);

		for(i = 0; i < 32; i++)
		{
			allowed_level_pin[ch] = 1UL<<i;
			interrupted_pin[ch] = 0;
			prev = 0;
			SMT_WRITE(GPIO_OUT(nch), 1UL<<i);
			SMT_WRITE(GPIO_INTEN(ch), 1UL<<i);

			if(!WaitForInterrupt(ch, prev))
				GPIODie(0xde00 | INT_TEST_ERR);
			if(SMT_READ(GPIO_OUT(nch)) != 0)
				GPIODie(0xde00 | INT_TEST_ERR);

			if(interrupted_pin[ch] != (1UL<<i))
				GPIODie(0xde00 | INT_TEST_ERR);

			prev = 0;
			interrupted_pin[ch] = 0;

			if(i != 31)
			{
				SMT_WRITE(GPIO_OUT(nch), 1UL<<(i+1));
			}
			else
			{
				SMT_WRITE(GPIO_OUT(nch), 1UL);
			}

			if(WaitForInterrupt(ch, prev))
				GPIODie(0xde00 | INT_TEST_ERR);

			if(interrupted_pin[ch] != 0)
				GPIODie(0xde00 | INT_TEST_ERR);

			allowed_level_pin[ch] = 0;
		}
		SMT_WRITE(GPIO_INTEN(ch), 0x00000000);
		SMT_WRITE(GPIO_INTEN(nch), 0x00000000);

		// Each Interrupt test
		for(i = 0; i < 32; i++)
		{
			active_high_level = (1UL<<i);

			if((i+1) >= 32)
				active_low_level = (1UL<<(i+1-32));
			else
				active_low_level = (1UL<<(i+1));

			if((i+2) >= 32)
				active_high_edge = (1UL<<(i+2-32));
			else
				active_high_edge = (1UL<<(i+2));

			if((i+3) >= 32)
				active_low_edge = (1UL<<(i+3-32));
			else
				active_low_edge = (1UL<<(i+3));

			if((i+4) >= 32)
				active_both_edge = (1UL<<(i+4-32));
			else
				active_both_edge = (1UL<<(i+4));

			data = active_high_level|active_low_level|active_high_edge|active_low_edge|active_both_edge;
			SMT_WRITE(GPIO_OUT(nch), 0x00000000);	// low first
			prev = 0;
			interrupted_pin[ch] = 0;
			allowed_level_pin[ch] = 0;
			allowed_edge_pin[ch] = 0;

			SMT_WRITE(GPIO_INTLEVEL(ch), active_high_level|active_low_level);
			SMT_WRITE(GPIO_INTPOL(ch), active_high_level|active_high_edge);
			SMT_WRITE(GPIO_INTBEDGE(ch), active_both_edge);

			allowed_level_pin[ch] = active_low_level;
			SMT_WRITE(GPIO_INTEN(ch), data);

			if(!WaitForInterrupt(ch, prev))
				GPIODie(0xde00 | INT_TEST_ERR);
			if(interrupted_pin[ch] != active_low_level)
				GPIODie(0xde00 | INT_TEST_ERR);

			allowed_level_pin[ch] = active_high_level;
			allowed_edge_pin[ch] = active_high_edge | active_both_edge;
			interrupted_pin[ch] = 0;
			prev = 0;

//			SMT_WRITE(GPIO_OUT(nch), data);		// toggle bit
			SMT_WRITE(GPIO_OUT(nch), 0xffffffff);		// toggle bit
			if(!WaitForInterrupt(ch, prev))
				GPIODie(0xde00 | INT_TEST_ERR);
			if(interrupted_pin[ch] != (allowed_level_pin[ch]|allowed_edge_pin[ch]))
				GPIODie(0xde00 | INT_TEST_ERR);

			allowed_level_pin[ch] = active_low_level;
			allowed_edge_pin[ch] = active_low_edge | active_both_edge;
			interrupted_pin[ch] = 0;
			prev = 0;

			SMT_WRITE(GPIO_OUT(nch), 0);		// toggle bit
			if(!WaitForInterrupt(ch, prev))
				GPIODie(0xde00 | INT_TEST_ERR);
			if(interrupted_pin[ch] != (allowed_level_pin[ch]|allowed_edge_pin[ch]))
				GPIODie(0xde00 | INT_TEST_ERR);

			// clean up
			allowed_level_pin[ch] = 0;
			allowed_edge_pin[ch] = 0;
			interrupted_pin[ch] = 0;
			prev = 0;
			SMT_WRITE(GPIO_INTEN(ch), 0);
			if((i+5) >= 32)
			{
				SMT_WRITE(GPIO_INTSTAT(ch), (1UL<<(i+5-32)));
			}
			else
			{
				SMT_WRITE(GPIO_INTSTAT(ch), (1UL<<(i+5)));
			}
		}
	}

	ReleaseIRQ(IRQ_GPIO0);
	ReleaseIRQ(IRQ_GPIO1);
	Disable_IRQ();
	DisableVIC();
}

void GPIOTest(void)
{
	SMT_WRITE(RS_PINMUX1, 0xffffffff);		// All GPIO0
	SMT_WRITE(RS_PINMUX2, 0xffffffff);		// All GPIO1
	GPIORegReadWriteTest();
	GPIOIntrTest();
}
