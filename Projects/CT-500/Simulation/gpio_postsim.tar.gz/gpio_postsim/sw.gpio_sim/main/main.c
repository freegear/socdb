/*----------------------------------------------------------
	File Name   : main.c 
	Description : Application Entry Point File
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/

/*/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// */
#define  __GCC_ARM__  1
#include "sysinc.h"
#include "Commonmacro.h"
#include "gpio.h"
#include "memorymap.h"
/*/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION DECLARATION
///////////////////////////////////////////////////////// */
void GPIOTest(void);

/*/////////////////////////////////////////////////////////
        VARIABLE DECLARATION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////// */
/*-----------------------------------------------------------------------
    Function name   : main()
    Prototype           : void main(void)
    Return              : void
    Argument        :
    Comments        :
-----------------------------------------------------------------------*/
int main(void)
{
	GPIOTest();

	SMT_WRITE(GPIO1_OE, 0x00000000);
	SMT_WRITE(GPIO0_OE, 0xffffffff);
	SMT_WRITE(GPIO0_OUT, 0xAde00);
    while(1);
//___________________FPGA test end

	return 0;
}

void UndefHandler(unsigned *sp, unsigned spsr, unsigned lr)
{
	int i;
//	UartPrintf("Register Dump at 0x%08x(SPSR:0x%08x LR:0x%08x)\n", (unsigned)sp, spsr, lr);
//	for(i = 0; i < 15; i++)
//		UartPrintf("0x%08x\n", *(sp+i));
	SMT_WRITE(GPIO1_OE, 0x00000000);
	SMT_WRITE(GPIO0_OE, 0xffffffff);
	SMT_WRITE(GPIO0_OUT, 0xAdeaf);
	while(1);
}
