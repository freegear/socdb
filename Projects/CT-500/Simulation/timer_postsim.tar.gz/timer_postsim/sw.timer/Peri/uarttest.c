/*----------------------------------------------------------
	File Name   : i2s.c 
	Description : i2s Controller test code
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/
#include "sysinc.h"
#include "Commonmacro.h"
#include "uart.h"
#include "dmac.h"
#include "irq.h"
#include "dma_mux.h"

#define BAUDRATE_2400	2400
#define BRD_2400	(unsigned)(((float)(BAUDRATE_2400*16))*65536.0/((float)50*1000*1000) + 0.5)

#define BAUDRATE_4800	4800
#define BRD_4800	(unsigned)(((float)(BAUDRATE_4800*16))*65536.0/((float)50*1000*1000) + 0.5)

#define BAUDRATE_9600	9600
#define BRD_9600	(unsigned)(((float)(BAUDRATE_9600*16))*65536.0/((float)50*1000*1000) + 0.5)

#define BAUDRATE_19200	19200
#define BRD_19200	(unsigned)(((float)(BAUDRATE_19200*16))*65536.0/((float)50*1000*1000) + 0.5)

#define BAUDRATE_38400	38400
#define BRD_38400	(unsigned)(((float)(BAUDRATE_38400*16))*65536.0/((float)50*1000*1000) + 0.5)

#define BAUDRATE_115200	115200
#define BRD_115200	(unsigned)(((float)(BAUDRATE_115200*16))*65536.0/((float)50*1000*1000) + 0.5)

#define DATABIT_7	0
#define DATABIT_8	1

#define PARITY_NONE	1
#define PARITY_EVEN	2
#define PARITY_ODD	3

#define STOPBIT_1	0
#define STOPBIT_2	1

#define TEST_DATA_NUM 12
static unsigned char test_data[TEST_DATA_NUM] =
{ 0x00, 0xAA, 0x55, 0xFF, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80 };

static struct uart_ch_data_ 
{
	int fifo_depth_encoded;
	int fifo_depth;
	int tx_dma_ch;
	int rx_dma_ch;
	int tx_count;
	int rx_count;
} uart_ch_data[4] = {{3, 32, -1, -1, 0, 0}, {3, 32, -1, -1, 0, 0}, {1, 8, -1, -1, 0, 0}, {1, 8, -1, -1, 0, 0}};

static void UARTSetBaudRate(int ch, int baudrate)
{
	switch(baudrate)
	{
	case BAUDRATE_4800:
		SMT_WRITE(UART_BRD(ch), BRD_4800);
		break;
	case BAUDRATE_9600:
		SMT_WRITE(UART_BRD(ch), BRD_9600);
		break;
	case BAUDRATE_19200:
		SMT_WRITE(UART_BRD(ch), BRD_19200);
		break;
	case BAUDRATE_38400:
		SMT_WRITE(UART_BRD(ch), BRD_38400);
		break;
	case BAUDRATE_115200:
		SMT_WRITE(UART_BRD(ch), BRD_115200);
		break;
	case BAUDRATE_2400:
	default:
		SMT_WRITE(UART_BRD(ch), BRD_2400);
		break;
	}
}

static void UARTDeinit(int ch)
{
	SMT_WRITE(UART_CMD(ch), 0);
	SMT_WRITE(UART_CMD(ch), (1UL<<28));
}

void UARTInit(int ch, int baudrate, int dma, int databit, int parity, int stopbit)
{
	UARTSetBaudRate(ch, baudrate);

	SMT_WRITE(UART_TIMEOUT(ch), 16*8*5);		// timout when 5 byte idle

	SMT_WRITE(UART_CMD(ch),
			(1UL<<31)			// enable UART
			| (1UL<<30)			// Enable Interrupt
			| (1UL<<29)			// Enable Receive TimeOut
			| (0UL<<28)			// No Software Reset
			| (dma<<27)			// DMA Request
			| (parity<<25)		// Parity
			| (databit<<24)		// Data Bit
			| (stopbit<<23)		// Stop Bit
//			| (1UL<<22)			// Enable loopback
			| (0UL<<22)			// Disable loopback(Pin Connected outside chip)
			| (1UL<<15)			// TxFIFOIntEn
			| (4<<8)			// TxWaterLevel
			| (1UL<<7)			// RxFIFOIntEn
			| (7<<0));			// RxWaterLevel
}

static void inline UARTDie(unsigned data)
{
	GPIOWrite(data);
	while(1)
		;
}

static int inline RxFifoCount(int ch)
{
	unsigned data;
	data = SMT_READ(UART_SR(ch));
	
	return (data & 0x3f);
}

static int inline TxFifoCount(int ch)
{
	unsigned data;
	data = SMT_READ(UART_SR(ch));
	
	return ((data>>8) & 0x3f);
}

static void UARTRegReadWriteTest(void)
{
	int ch;
	int j;
	unsigned data;
	unsigned mask;

	for(ch = 0; ch < 4; ch++)
	{
		data = SMT_READ(UART_CMD(ch));
		if(data != 0)
			UARTDie(0xdead);

		SMT_WRITE(UART_CMD(ch), 0xffffffff);
		data = SMT_READ(UART_CMD(ch));
		if(data != 0)
			UARTDie(0xdead);

//		mask = (((uart_ch_data[ch].fifo_depth<<1)-1)<<8)|((uart_ch_data[ch].fifo_depth<<1)-1);
//		mask = mask ^ 0x00003F3F;
		mask = 0xffc0bfbf;

		SMT_WRITE(UART_CMD(ch), 0xAAAAAAAA);
		data = SMT_READ(UART_CMD(ch));
		if(data != (0xAAAAAAAA&mask))
			UARTDie(0xdead);

		SMT_WRITE(UART_CMD(ch), 0x45555555);
		data = SMT_READ(UART_CMD(ch));
		if(data != (0x45555555&mask))
			UARTDie(0xdead);

		SMT_WRITE(UART_CMD(ch), 0x00000000);
		data = SMT_READ(UART_CMD(ch));
		if(data != 0)
			UARTDie(0xdead);

		data = SMT_READ(UART_BRD(ch));
		if(data != 0)
			UARTDie(0xdead);

		SMT_WRITE(UART_BRD(ch), 0xAAAAAAAA);
		data = SMT_READ(UART_BRD(ch));
		if(data != (0xAAAAAAAA&0x0000ffff))
			UARTDie(0xdead);

		SMT_WRITE(UART_BRD(ch), 0x55555555);
		data = SMT_READ(UART_BRD(ch));
		if(data != (0x55555555&0x0000ffff))
			UARTDie(0xdead);

		SMT_WRITE(UART_BRD(ch), 0x00000000);
		data = SMT_READ(UART_BRD(ch));
		if(data != 0)
			UARTDie(0xdead);

		data = SMT_READ(UART_TIMEOUT(ch));
		if(data != 0)
			UARTDie(0xdead);

		SMT_WRITE(UART_TIMEOUT(ch), 0xAAAAAAAA);
		data = SMT_READ(UART_TIMEOUT(ch));
		if(data != (0xAAAAAAAA&0x000fffff))
			UARTDie(0xdead);

		SMT_WRITE(UART_TIMEOUT(ch), 0x55555555);
		data = SMT_READ(UART_TIMEOUT(ch));
		if(data != (0x55555555&0x000fffff))
			UARTDie(0xdead);

		SMT_WRITE(UART_TIMEOUT(ch), 0x00000000);
		data = SMT_READ(UART_TIMEOUT(ch));
		if(data != 0)
			UARTDie(0xdead);

		data = SMT_READ(UART_SR(ch));
		if(data != (uart_ch_data[ch].fifo_depth_encoded<<28))
			UARTDie(0xdead);

		for(j = 0; j < uart_ch_data[ch].fifo_depth; j++)
		{
			SMT_WRITE(UART_TX(ch), 0x00);
			data = SMT_READ(UART_SR(ch));
			if(data != ((uart_ch_data[ch].fifo_depth_encoded<<28)|((j+1)<<8)))
				UARTDie(0xdead);
		}

		SMT_WRITE(UART_CMD(ch), (1UL<<28));
		data = SMT_READ(UART_SR(ch));
		if(data != (uart_ch_data[ch].fifo_depth_encoded<<28))
			UARTDie(0xdead);
	}
}

static void UARTPollingTest(void)
{
	int ch;
	int baudrate = BAUDRATE_38400;
	int databit = DATABIT_8;
	int parity = PARITY_NONE;
	int stopbit = STOPBIT_1;
	unsigned char receive_data[4][TEST_DATA_NUM];
	int rx_count[4];
	int tx_count[4];
	int j;

	for(ch = 0; ch < 4; ch++)
	{
		rx_count[ch] = 0;
		tx_count[ch] = 0;
		for(j = 0; j < TEST_DATA_NUM; j++)
			receive_data[ch][j] = 0xff;
	}

	for(ch = 0; ch < 4; ch++)
		UARTInit(ch, baudrate, 0, databit, parity, stopbit);

	while(1)
	{
		for(ch = 0; ch < 4; ch++)
		{
			// Fill Tx
			if(TxFifoCount(ch) != uart_ch_data[ch].fifo_depth
				&& tx_count[ch] != TEST_DATA_NUM)
			{
				SMT_WRITE(UART_TX(ch), test_data[tx_count[ch]]);
				tx_count[ch] += 1;
			}

			// Check Rx
			if(RxFifoCount(ch) != 0)
			{
				receive_data[ch][rx_count[ch]] = SMT_READ(UART_RX(ch));
				rx_count[ch] += 1;
			}
		}

		if(rx_count[0] >= TEST_DATA_NUM && rx_count[1] >= TEST_DATA_NUM
			&& rx_count[2] >= TEST_DATA_NUM && rx_count[3] >= TEST_DATA_NUM)
			break;
	}

	for(ch = 0; ch < 4; ch++)
	{
		if(SMT_READ(UART_SR(ch)) & 0x03800000)	// Parity/Frame/Overrun
			UARTDie(0xdeaa);

		UARTDeinit(ch);
	}

	for(ch = 0; ch < 4; ch++)
	{
		for(j = 0; j < TEST_DATA_NUM; j++)
			if(receive_data[ch][j] != test_data[j])
				UARTDie(0xdea0);
	}
}

static void UARTDMATest(void)
{
	int ch;
	int baudrate = BAUDRATE_115200;
	int databit = DATABIT_8;
	int parity = PARITY_ODD;
	int stopbit = STOPBIT_2;
	unsigned char receive_data[4][(TEST_DATA_NUM+7)&0xfffffff8];
	int rx_count[4];
	int tx_count[4];
	int j;

	for(ch = 0; ch < 4; ch++)
	{
		rx_count[ch] = 0;
		tx_count[ch] = 0;
		for(j = 0; j < TEST_DATA_NUM; j++)
			receive_data[ch][j] = 0xff;
	}

	for(ch = 0; ch < 2; ch++)
		UARTInit(ch, baudrate, 1, databit, parity, stopbit);

	for(ch = 2; ch < 4; ch++)
		UARTInit(ch, baudrate, 0, DATABIT_7, parity, stopbit);

	uart_ch_data[0].rx_dma_ch = DMAChannelAlloc(DMA_UART0RX);
	uart_ch_data[0].tx_dma_ch = DMAChannelAlloc(DMA_UART0TX);

	uart_ch_data[1].rx_dma_ch = DMAChannelAlloc(DMA_UART1RX);
	uart_ch_data[1].tx_dma_ch = DMAChannelAlloc(DMA_UART1TX);

	DMACNoDescrp(uart_ch_data[0].rx_dma_ch,
			(unsigned)(&UART0_RX), 0, 0 /* byte */, receive_data[0], 1, 2, 3, (TEST_DATA_NUM+7)&0xfffffff8);
	DMACNoDescrp(uart_ch_data[0].tx_dma_ch,
			test_data, 1, 2, (unsigned)(&UART0_TX), 0, 0 /* byte */, 3, (TEST_DATA_NUM+7)&0xfffffff8);

	DMACNoDescrp(uart_ch_data[1].rx_dma_ch,
			(unsigned)(&UART1_RX), 0, 0 /* byte */, receive_data[1], 1, 2, 3, (TEST_DATA_NUM+7)&0xfffffff8);
	DMACNoDescrp(uart_ch_data[1].tx_dma_ch,
			test_data, 1, 2, (unsigned)(&UART1_TX), 0, 0 /* byte */, 3, (TEST_DATA_NUM+7)&0xfffffff8);

	while(1)
	{
		for(ch = 2; ch < 4; ch++)
		{
			// Fill Tx
			if(TxFifoCount(ch) != uart_ch_data[ch].fifo_depth
				&& tx_count[ch] != TEST_DATA_NUM)
			{
				SMT_WRITE(UART_TX(ch), test_data[tx_count[ch]]);
				tx_count[ch] += 1;
			}

			// Check Rx
			if(RxFifoCount(ch) != 0)
			{
				receive_data[ch][rx_count[ch]] = SMT_READ(UART_RX(ch));
				rx_count[ch] += 1;
			}
		}

		if(rx_count[2] >= TEST_DATA_NUM && rx_count[3] >= TEST_DATA_NUM)
			break;
	}
	while(1)
	{
		if((SMT_READ(DMACSta(uart_ch_data[0].rx_dma_ch))&0x00000009)
			&& (SMT_READ(DMACSta(uart_ch_data[1].rx_dma_ch))&0x00000009))
				break;
	}

	DMAChannelFree(uart_ch_data[0].rx_dma_ch);
	DMAChannelFree(uart_ch_data[0].tx_dma_ch);
	DMAChannelFree(uart_ch_data[1].rx_dma_ch);
	DMAChannelFree(uart_ch_data[1].tx_dma_ch);

	for(ch = 0; ch < 4; ch++)
	{
		if(SMT_READ(UART_SR(ch)) & 0x03800000)	// Parity/Frame/Overrun
			UARTDie(0xdea9);

		UARTDeinit(ch);
	}

	for(ch = 0; ch < 4; ch++)
	{
		if(ch < 2)
		{
			for(j = 0; j < TEST_DATA_NUM; j++)
			{
				if(receive_data[ch][j] != test_data[j])
					UARTDie(0xdea1);
			}
		}
		else
		{
			for(j = 0; j < TEST_DATA_NUM; j++)
			{
				if(receive_data[ch][j] != ((test_data[j])&0x7F))
					UARTDie(0xdea1);
			}
		}
	}
}

static unsigned char rx_data[4][TEST_DATA_NUM*2];
static volatile unsigned ch_disabled[4];
static void UARTISR(unsigned irq)
{
	int ch;
	int i;
	unsigned status;
	unsigned command;

	switch(irq)
	{
	case IRQ_UART0:
		ch = 0;
		break;
	case IRQ_UART1:
		ch = 1;
		break;
	case IRQ_UART2:
		ch = 2;
		break;
	case IRQ_UART3:
		ch = 3;
		break;
	default:
		UARTDie(0xdea3);
	}

	status = SMT_READ(UART_SR(ch));
	if(!(status & 0x80000000))
		UARTDie(0xdea4);

	if(status & 0x03800000)		// Parity/Frame/Overrrun
		UARTDie(0xdea5);

	if(status & (1UL<<15))	// TxFIFOInt
	{
		for(i = 0; i < 4; i++)
		{
			if(uart_ch_data[ch].tx_count < TEST_DATA_NUM)
			{
				SMT_WRITE(UART_TX(ch), test_data[uart_ch_data[ch].tx_count++]);
			}
			else
			{
				command = SMT_READ(UART_CMD(ch));
				if(command & (0x1UL<<15))
				{
					SMT_WRITE(UART_CMD(ch), command & (~(1UL<<15)));
					break;
				}
				else
					UARTDie(0xdea6);
			}
		}
	}

	if(status & (1UL<<7))	// RxFIFOInt
	{
		for(i = 0; i < 8; i++)
			rx_data[ch][uart_ch_data[ch].rx_count++] = SMT_READ(UART_RX(ch));
	}

	if(status & (1UL<<22))	// Receive TimeOut
	{
		while(1)
		{
			rx_data[ch][uart_ch_data[ch].rx_count++] = SMT_READ(UART_RX(ch));

			if((SMT_READ(UART_SR(ch))&0x0000003f) == 0)
				break;
		}
		UARTDeinit(ch);
		ch_disabled[ch] = 1;
	}
}

static void UARTIntrTest(void)
{
	int ch;
	int baudrate = BAUDRATE_19200;
	int databit = DATABIT_8;
	int parity = PARITY_EVEN;
	int stopbit = STOPBIT_1;
	int j;

	for(ch = 0; ch < 4; ch++)
	{
		uart_ch_data[ch].rx_count = 0;
		uart_ch_data[ch].tx_count = 0;
		ch_disabled[ch] = 0;
		for(j = 0; j < TEST_DATA_NUM*2; j++)
			rx_data[ch][j] = 0xff;
	}

	for(ch = 0; ch < 4; ch++)
		UARTInit(ch, baudrate, 0, databit, parity, stopbit);

	EnableVIC(VIC_POLARITY, VIC_LEVEL, VIC_INTMOD);
	Enable_IRQ();
	RequestIRQ(IRQ_UART0, UARTISR);
	RequestIRQ(IRQ_UART1, UARTISR);
	RequestIRQ(IRQ_UART2, UARTISR);
	RequestIRQ(IRQ_UART3, UARTISR);

	while(1)
	{
		if(ch_disabled[0] && ch_disabled[1] && ch_disabled[2] && ch_disabled[3])
			break;
	}

	ReleaseIRQ(IRQ_UART0);
	ReleaseIRQ(IRQ_UART1);
	ReleaseIRQ(IRQ_UART2);
	ReleaseIRQ(IRQ_UART3);
	Disable_IRQ();
	DisableVIC();

	for(ch = 0; ch < 4; ch++)
	{
		if(uart_ch_data[ch].rx_count != TEST_DATA_NUM)
			UARTDie(0xdea7);

		for(j = 0; j < TEST_DATA_NUM; j++)
			if(rx_data[ch][j] != test_data[j])
				UARTDie(0xdea8);
	}
}

void UARTTest(void)
{
	SMT_WRITE(RS_PINMUX0, (1UL<<9)	// UART3_TXD
					| (1UL<<8));	// UART3_RXD

	SMT_WRITE(RS_PINMUX2, 0);	// UART2_TXD/UART2_RXD

	UARTRegReadWriteTest();
	UARTPollingTest();
	UARTDMATest();
	UARTIntrTest();
}
