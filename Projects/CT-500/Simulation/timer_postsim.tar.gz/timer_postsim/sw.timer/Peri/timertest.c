/*----------------------------------------------------------
	File Name   : main.c 
	Description : Application Entry Point File
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/

/*/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// */
#include "sysinc.h"
#include "Commonmacro.h"
#include "lib.h"
#include "irq.h"

#include "gpio.h"

/*/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// */
#define TIMER_REG_READ_WRITE_ERR 0xa0
#define TIMER_INTR_ERR 0xa1
/*/////////////////////////////////////////////////////////
        FUNCTION DECLARATION
///////////////////////////////////////////////////////// */
extern void Enable_IRQ(void);
extern void Disable_IRQ(void);
void TimerTest(void);

/*/////////////////////////////////////////////////////////
        VARIABLE DECLARATION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////// */
static void TimerDie(unsigned data)
{
	GPIOWrite(data);
	while(1)
		;
}

static void TimerRegReadWriteTest(void)
{
	int ch;
	int i;
	unsigned data;

	for(ch = 0; ch < 4; ch++)
	{
		data = SMT_READ(TIMER_DAT(ch));
		if(data != 0xffffffff)
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		SMT_WRITE(TIMER_DAT(ch), 0x55555555);
		data = SMT_READ(TIMER_DAT(ch));
		if(data != 0x55555555)
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		SMT_WRITE(TIMER_DAT(ch), 0xAAAAAAAA);
		data = SMT_READ(TIMER_DAT(ch));
		if(data != 0xAAAAAAAA)
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		SMT_WRITE(TIMER_DAT(ch), 0x00000000);
		data = SMT_READ(TIMER_DAT(ch));
		if(data != 0x00000000)
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		for(i = 0; i < 32; i++)
		{
			SMT_WRITE(TIMER_DAT(ch), (1UL<<i));
			data = SMT_READ(TIMER_DAT(ch));
			if(data != (1UL<<i))
				TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);
		}

		SMT_WRITE(TIMER_DAT(ch), 0xffffffff);
		data = SMT_READ(TIMER_DAT(ch));
		if(data != 0xffffffff)
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		data = SMT_READ(TIMER_CNT(ch));
		if(data != 0x00000000)
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		data = SMT_READ(TIMER_PRE(ch));
		if(data != 0x000003ff)
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		SMT_WRITE(TIMER_PRE(ch), 0x55555555);
		data = SMT_READ(TIMER_PRE(ch));
		if(data != (0x55555555&0x000003ff))
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		SMT_WRITE(TIMER_PRE(ch), 0xAAAAAAAA);
		data = SMT_READ(TIMER_PRE(ch));
		if(data != (0xAAAAAAAA&0x000003ff))
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		SMT_WRITE(TIMER_PRE(ch), 0x00000000);
		data = SMT_READ(TIMER_PRE(ch));
		if(data != (0x00000000&0x000003ff))
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		for(i = 0; i < 32; i++)
		{
			SMT_WRITE(TIMER_PRE(ch), (1UL<<i));
			data = SMT_READ(TIMER_PRE(ch));
			if(data != ((1UL<<i)&0x000003ff))
				TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);
		}

		SMT_WRITE(TIMER_PRE(ch), 0x000003ff);
		data = SMT_READ(TIMER_PRE(ch));
		if(data != (0x000003ff&0x000003ff))
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		data = SMT_READ(TIMER_CON(ch));
		if(data != 0x0000000)
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);
		
		// Enable Timer & Read Counter !!
		SMT_WRITE(TIMER_PRE(ch), 0x00000000);	// Maximum Speed
		SMT_WRITE(TIMER_CON(ch), 0x00000005);
		data = SMT_READ(TIMER_CON(ch));
		if(data != 0x0000005)
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		// Check Timer Counter
		for(i = 0; i < 10; i++)
		{
			data = SMT_READ(TIMER_CNT(ch));
			if(data != 0)
				break;
		}

		if(i == 10)
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		SMT_WRITE(TIMER_CON(ch), 0x00000002);
		data = SMT_READ(TIMER_CNT(ch));
		if(data != 0)
			TimerDie(0xde00 | TIMER_REG_READ_WRITE_ERR);

		SMT_WRITE(TIMER_CON(ch), 0x00000000);
		SMT_WRITE(TIMER_PRE(ch), 0x000003ff);
	}
}

static int volatile timer_int_count[4] = { 0, 0, 0, 0 };
static void TimerISR(unsigned irq)
{
	int ch;
	switch(irq)
	{
	case IRQ_TIMER0:	ch = 0; break;
	case IRQ_TIMER1:	ch = 1; break;
	case IRQ_TIMER2:	ch = 2; break;
	case IRQ_TIMER3:	ch = 3; break;
	default:	TimerDie(0xde00 | TIMER_INTR_ERR);	break;
	}

	timer_int_count[ch]++;
}

static void TimerIntrTest(void)
{
	EnableVIC(VIC_POLARITY, VIC_LEVEL, VIC_INTMOD);
	Enable_IRQ();
	SMT_WRITE(TIMER0_DAT, 0x0800);
	SMT_WRITE(TIMER1_DAT, 0x1000);
	SMT_WRITE(TIMER2_DAT, 0x2000);
	SMT_WRITE(TIMER3_DAT, 0x2000);
//	SMT_WRITE(TIMER0_PRE, 0x03ff);
//	SMT_WRITE(TIMER1_PRE, 0x03ff);
//	SMT_WRITE(TIMER2_PRE, 0x03ff);
//	SMT_WRITE(TIMER3_PRE, 0x03ff);
	SMT_WRITE(TIMER0_PRE, 0x0002);
	SMT_WRITE(TIMER1_PRE, 0x0002);
	SMT_WRITE(TIMER2_PRE, 0x0002);
	SMT_WRITE(TIMER3_PRE, 0x0002);
	SMT_WRITE(TIMER0_CON, 0x0001);
	SMT_WRITE(TIMER1_CON, 0x0001);
	SMT_WRITE(TIMER2_CON, 0x0001);
	SMT_WRITE(TIMER3_CON, 0x0001);

	RequestIRQ(IRQ_TIMER0, TimerISR);
	RequestIRQ(IRQ_TIMER1, TimerISR);
	RequestIRQ(IRQ_TIMER2, TimerISR);
	RequestIRQ(IRQ_TIMER3, TimerISR);

	while(timer_int_count[3] < 16)
			;

	ReleaseIRQ(IRQ_TIMER0);
	ReleaseIRQ(IRQ_TIMER1);
	ReleaseIRQ(IRQ_TIMER2);
	ReleaseIRQ(IRQ_TIMER3);

	Disable_IRQ();
	DisableVIC();

	if(timer_int_count[0] < (timer_int_count[3]*4)
			|| timer_int_count[0] > ((timer_int_count[3]+1)*4+1))
		TimerDie(0xde00 | TIMER_INTR_ERR);

	if(timer_int_count[1] < (timer_int_count[3]*2)
			|| timer_int_count[1] > ((timer_int_count[3]+1)*2+1))
		TimerDie(0xde00 | TIMER_INTR_ERR);

	if(timer_int_count[2] < (timer_int_count[3])
			|| timer_int_count[2] > ((timer_int_count[3]+1)))
		TimerDie(0xde00 | TIMER_INTR_ERR);
}

void TimerTest(void)
{
	TimerRegReadWriteTest();
	TimerIntrTest();
}
