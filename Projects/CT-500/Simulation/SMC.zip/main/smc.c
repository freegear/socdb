/*----------------------------------------------------------
	File Name   : main.c 
	Description : Application Entry Point File
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/

/*/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// */
#define  __GCC_ARM__  1
#include "sysinc.h"
#include "Commonmacro.h"

#include "gpio.h"
#include "uart.h"
#include "dmac.h"

#include "memorymap.h"
/*/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION DECLARATION
///////////////////////////////////////////////////////// */
//void SMCTest(void);

/*/////////////////////////////////////////////////////////
        VARIABLE DECLARATION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////// */

#define SMC_TEST_COUNT 1024		/* 1K WORD */
//volatile unsigned *test_temp = ((volatile unsigned *)0x20000000);
//static unsigned test_temp[SMC_TEST_COUNT];
#define DATA0(x) (((x)&0xff)|((((x+1)&0xff)^0xff)<<8)|((((x+2)&0xff)^0xff)<<16)|(((x+1)&0xff)<<24))
#define DATA1 0x55aaaa55
#define DATA2 0xaa5555aa

void SMCTest(smtUint32 SMC_TESTREGION)
{
	int i;
	volatile smtUint8 * sram_testregion_byte = (volatile smtUint8 *)(SMC_TESTREGION);
	unsigned data;
	unsigned expected_data;

	// single write
	for(i = 0; i < SMC_TEST_COUNT; i++)
//		sram_testregion_byte[i*4] = DATA0(i);
		sram_testregion_byte[i] = DATA1;

	// single read
	for(i = 0; i < SMC_TEST_COUNT; i++)
	{
		data = sram_testregion_byte[i];
		if(data != 0x55)
		{
			expected_data = DATA1;
			goto error;
		}
/*		if(data != DATA0(i))
		{
			expected_data = DATA0(i);
			goto error;
		}*/
	}
	DPRINTF("Done\n");
	return;

error:
	DPRINTF("Error(Read %08x when expected %08x)\n", data, expected_data);
	GPIOWrite(0x5dead);
	while(1);
}


