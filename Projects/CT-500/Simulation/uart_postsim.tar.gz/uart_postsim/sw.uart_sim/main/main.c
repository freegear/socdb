/*----------------------------------------------------------
	File Name   : main.c 
	Description : Application Entry Point File
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/

/*/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// */
#define  __GCC_ARM__  1
#include "sysinc.h"
#include "Commonmacro.h"
#include "gpio.h"
#include "memorymap.h"
/*/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION DECLARATION
///////////////////////////////////////////////////////// */
void UARTTest(void);

/*/////////////////////////////////////////////////////////
        VARIABLE DECLARATION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////// */
/*-----------------------------------------------------------------------
    Function name   : main()
    Prototype           : void main(void)
    Return              : void
    Argument        :
    Comments        :
-----------------------------------------------------------------------*/
int main(void)
{
	GPIOOutputEnable(0x800fffff);
	GPIOWrite(0xA4321);
	UARTTest();

//	DDRTest();
	
//	NandTest();
//	DDRInit();

	GPIOWrite(0xAde00);
    while(1);
//___________________FPGA test end

	return 0;
}

void UndefHandler(unsigned *sp, unsigned spsr, unsigned lr)
{
	int i;
//	UartPrintf("Register Dump at 0x%08x(SPSR:0x%08x LR:0x%08x)\n", (unsigned)sp, spsr, lr);
//	for(i = 0; i < 15; i++)
//		UartPrintf("0x%08x\n", *(sp+i));
	GPIOWrite(0xdeaf);
	while(1);
}
