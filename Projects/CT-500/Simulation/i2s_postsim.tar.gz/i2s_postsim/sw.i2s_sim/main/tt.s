	.file	"tt.c"
	.text
	.align	2
	.global	test
	.type	test, %function
test:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 1, uses_anonymous_args = 0
	mov	ip, sp
	stmfd	sp!, {fp, ip, lr, pc}
	sub	fp, ip, #4
	ldr	r3, .L2
	ldr	r3, [r3, #0]
	mov	lr, pc
	mov	pc, r3
	mov	r3, r0
	add	r3, r3, #1
	mov	r0, r3
	ldmfd	sp, {fp, sp, pc}
.L3:
	.align	2
.L2:
	.word	testfuncp
	.size	test, .-test
	.ident	"GCC: (GNU) 3.4.4"
