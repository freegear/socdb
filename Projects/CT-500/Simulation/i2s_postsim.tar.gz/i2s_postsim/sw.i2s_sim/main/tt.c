int test(void)
{
	extern int (*testfuncp)(void);

	return (*testfuncp)()+1;
}
