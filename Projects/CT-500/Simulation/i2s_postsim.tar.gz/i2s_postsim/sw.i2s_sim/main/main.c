/*----------------------------------------------------------
	File Name   : main.c 
	Description : Application Entry Point File
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/

/*/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// */
#define  __GCC_ARM__  1
#include "sysinc.h"
#include "Commonmacro.h"

#include "gpio.h"
#include "uart.h"
#include "dmac.h"

#include "memorymap.h"
/*/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION DECLARATION
///////////////////////////////////////////////////////// */
void DDRTest(void);
void I2SCtrlSimTest(void);

/*/////////////////////////////////////////////////////////
        VARIABLE DECLARATION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////// */
/*-----------------------------------------------------------------------
    Function name   : main()
    Prototype           : void main(void)
    Return              : void
    Argument        :
    Comments        :
-----------------------------------------------------------------------*/
int main(void)
{
	GPIOOutputEnable(0x800fffff);
	GPIOWrite(0xA4321);
	I2SCtrlSimTest();

	GPIOWrite(0xA4322);
//	DDRTest();
	GPIOWrite(0xA4323);

	GPIOWrite(0xde00);
	
	while(1);
//___________________FPGA test end

	return 0;
}

void UndefHandler(unsigned *sp, unsigned spsr, unsigned lr)
{
	GPIOWrite(0xdead);
	while(1);
}
