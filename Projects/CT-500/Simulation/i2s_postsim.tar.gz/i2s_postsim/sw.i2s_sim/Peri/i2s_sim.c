/*----------------------------------------------------------
	File Name   : i2s.c 
	Description : i2s Controller test code
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/
#include "sysinc.h"
#include "Commonmacro.h"
#include "gpio.h"
#include "dmac.h"
#include "dma_mux.h"
#include "memorymap.h"
#include "irq.h"

#define I2S_ERROR 1
#define I2S_NOERROR 0

#define I2S_REG_READ_WRITE_TEST 1

#define I2S_TX_FIFODEPTH_CONF	5
#define I2S_RX_FIFODEPTH_CONF	5

#define SYS_CLK		(200*1000*1000)		// 200 MHz

#define SAMPLING_RATE_8	(8*1000)		// 8 KHz
#define DTO_RATIO_8	((unsigned)(((float)(256*SAMPLING_RATE_8))*((float)(0x00040000))/((float)SYS_CLK)))

#define SAMPLING_RATE_16	(16*1000)		// 16 KHz
#define DTO_RATIO_16	((unsigned)(((float)(256*SAMPLING_RATE_16))*((float)(0x00040000))/((float)SYS_CLK)))

#define SAMPLING_RATE_22_05	(22.05*1000)		// 22.05 KHz
#define DTO_RATIO_22_05	((unsigned)(((float)(256*SAMPLING_RATE_22_05))*((float)(0x00040000))/((float)SYS_CLK)))

#define SAMPLING_RATE_32	(32*1000)		// 32 KHz
#define DTO_RATIO_32	((unsigned)(((float)(256*SAMPLING_RATE_32))*((float)(0x00040000))/((float)SYS_CLK)))

#define SAMPLING_RATE_44_1	(44.1*1000)		// 44.1 KHz
#define DTO_RATIO_44_1	((unsigned)(((float)(256*SAMPLING_RATE_44_1))*((float)(0x00040000))/((float)SYS_CLK)))

#define SAMPLING_RATE_48	(48*1000)		// 48 KHz
#define DTO_RATIO_48	((unsigned)(((float)(256*SAMPLING_RATE_48))*((float)(0x00040000))/((float)SYS_CLK)))

#define MASTER_SLAVE	1		// master mode
#define LRCLK_INV		0		// Normal mode
#define MCLK_ON			1		// should be 1 when master mode
#define MCLK_OE			1		// MCLK Output Enable

#define I2S_RX_EN		1
#define RX_RESET		0
#define RX_DMAINTEN		0
#define RX_FIFOORINTEN	1
#define RX_WLEN			1		// 1 : 16bit per sample
#define RX_LJUST		0		// 0 : I2S compatible mode
#define RX_FIFOTH		8		// Fifo Threshold

#define USE_DMA
#define I2S_TX_EN		1
#define TX_RESET		0
#define TX_DMAINTEN		0
#define TX_FIFOURINTEN	1
#define TX_WLEN			1		// 1 : 16bit per sample
#define TX_LJUST		0		// 0 : I2S compatible mode
#define TX_FIFOTH		8		// Fifo Threshold

#define WORD_LEN_8		0
#define WORD_LEN_16		1
#define WORD_LEN_24		2
#define WORD_LEN_32		3

#define DAC_ENABLE()	\
	do {				\
		unsigned gpio_temp;		\
		gpio_temp = SMT_READ(GPIO1_OUT);	\
		SMT_WRITE(GPIO1_OUT, gpio_temp | 0x10);	\
	} while(0)

#define ADC_ENABLE()	\
	do {				\
		unsigned gpio_temp;		\
		gpio_temp = SMT_READ(GPIO1_OUT);	\
		SMT_WRITE(GPIO1_OUT, gpio_temp | 0x20);	\
	} while(0)

#define DAC_DISABLE()	\
	do {				\
		unsigned gpio_temp;		\
		gpio_temp = SMT_READ(GPIO1_OUT);	\
		SMT_WRITE(GPIO1_OUT, gpio_temp & ~(0x10UL));	\
	} while(0)

#define ADC_DISABLE()	\
	do {				\
		unsigned gpio_temp;		\
		gpio_temp = SMT_READ(GPIO1_OUT);	\
		SMT_WRITE(GPIO1_OUT, gpio_temp & ~(0x20UL));	\
	} while(0)

#define DAC_SETWLEN(x)	\
	do {				\
		unsigned gpio_temp;		\
		gpio_temp = SMT_READ(GPIO1_OUT);	\
		SMT_WRITE(GPIO1_OUT, (gpio_temp & ~(0x6UL))|(x<<1));	\
	} while(0)

#define DAC_SETLJUST(x)	\
	do {				\
		unsigned gpio_temp;		\
		gpio_temp = SMT_READ(GPIO1_OUT);	\
		SMT_WRITE(GPIO1_OUT, (gpio_temp & ~(0x8UL))|(x<<3));	\
	} while(0)

#define DAC_SETMASTER(x)	\
	do {				\
		unsigned gpio_temp;		\
		gpio_temp = SMT_READ(GPIO1_OUT);	\
		SMT_WRITE(GPIO1_OUT, (gpio_temp & ~(0x1UL))|(x));	\
	} while(0)

#define DAC_SAMPLEFREQ_48	5
#define DAC_SAMPLEFREQ_44_1	4
#define DAC_SAMPLEFREQ_32	3
#define DAC_SAMPLEFREQ_22_05	2
#define DAC_SAMPLEFREQ_16	1
#define DAC_SAMPLEFREQ_8	0

#define DAC_SAMPLEFREQ(x)	\
	do {				\
		unsigned gpio_temp;		\
		gpio_temp = SMT_READ(GPIO1_OUT);	\
		SMT_WRITE(GPIO1_OUT, (gpio_temp & ~(0x1C0UL))|(x<<6));	\
	} while(0)

static unsigned sound_data[256];
static unsigned receive_data[256];

static int i2s_rx_dmach, i2s_tx_dmach;

static inline void I2SCtrlReset(void)
{
	SMT_WRITE(I2S_CTRL,	(1<<14)|(1<<30));		// Tx Reset & Rx Reset
}

static int RegReadWriteTest(void)
{
	unsigned status;
	unsigned tx_fifodepth, rx_fifodepth;
	unsigned control_mask;
	int i;

	I2SCtrlReset();

	SMT_WRITE(I2S_CLKCTRL, 0x800AAAAA);
	if(SMT_READ(I2S_CLKCTRL) != 0x800AAAAA)
		return I2S_ERROR;
	SMT_WRITE(I2S_CLKCTRL, 0x40055555);
	if(SMT_READ(I2S_CLKCTRL) != 0x40055555)
		return I2S_ERROR;

	SMT_WRITE(I2S_CLKCTRL, 0x00000000);
	if(SMT_READ(I2S_CLKCTRL) != 0x00000000)
		return I2S_ERROR;

	status = SMT_READ(I2S_STATUS);
	if((status & 0xF0FFF0FF) != 0x40000000)
		return I2S_ERROR;

	tx_fifodepth = (status & 0x0F00UL)>>8;
	rx_fifodepth = (status & 0x0F000000UL)>>24;

	if(tx_fifodepth != I2S_TX_FIFODEPTH_CONF)
		return I2S_ERROR;

	if(rx_fifodepth != I2S_RX_FIFODEPTH_CONF)
		return I2S_ERROR;

	control_mask = (1<<30)|(1<<27)|(3<<22)|(1<<14)|(1<<11)|(3<<6);
	control_mask |= (0xffffffff<<tx_fifodepth)&(0x0000003f);
	control_mask |= (0xffff0000<<rx_fifodepth)&(0x003f0000);
	control_mask = ~control_mask;

	SMT_WRITE(I2S_CTRL, 0x2AAA2AAA);
	if(SMT_READ(I2S_CTRL) != (0x2AAA2AAA&control_mask))
		return I2S_ERROR;

	SMT_WRITE(I2S_CTRL, 0x55555555);
	if(SMT_READ(I2S_CTRL) != (0x55555555&control_mask))
		return I2S_ERROR;

	SMT_WRITE(I2S_CTRL, 0x00000000);
	if(SMT_READ(I2S_CTRL) != (0x00000000&control_mask))
		return I2S_ERROR;

	// Check Tx FIFO Grow
	for(i = 0; i < (1UL<<tx_fifodepth); i++)
	{
		SMT_WRITE(I2S_DATA, 0);
		if(SMT_READ(I2S_STATUS & 0x0000007F) != (i+1))
			return I2S_ERROR;
	}
	SMT_WRITE(I2S_DATA, 0);
	if(SMT_READ(I2S_STATUS & 0x0000007F) != i)
		return I2S_ERROR;

	I2SCtrlReset();
	if(SMT_READ(I2S_STATUS & 0x0000007F) != 0)
		return I2S_ERROR;

	return I2S_NOERROR;
}

static inline void SetDTO(unsigned dto_ratio, int master, int lrclkinv)
{
	DAC_SETMASTER(!master);
	SMT_WRITE(I2S_CLKCTRL, (master<<31)|(lrclkinv<<30)|(MCLK_ON<<18)|(master<<19)|(0x0003ffff & dto_ratio));
}

static void RunTx(unsigned wordlength, unsigned ljust, unsigned dma)
{
	unsigned ctrl;
	unsigned tx_fifodepth;
	int i;
	unsigned trans_size;

	DAC_SETWLEN(wordlength);
	DAC_SETLJUST(ljust);
	DAC_ENABLE();

	ctrl = SMT_READ(I2S_CTRL);
	ctrl &= 0xffff0000;

	SMT_WRITE(I2S_CTRL, ctrl | 0x00004000);	// Tx RESET

	trans_size = 256;

	if(dma)
	{
		i2s_tx_dmach = DMAChannelAlloc(DMA_I2STX);
		DMACNoDescrp(i2s_tx_dmach, (unsigned)sound_data, 1/*srcIncr*/, 2/*32bit*/, (unsigned)(&I2S_DATA), 0/*dstIncr*/, 2/*word*/, 5, trans_size);
	}

	ctrl |= (1<<15)		// Enable TX
		| (((!dma)&0x01)<<13)	// DMA
		| (1<<12)			// FifoURIntEn
		| ((wordlength&0x03)<<9)
		| ((ljust&0x01)<<8)
		| TX_FIFOTH;

	SMT_WRITE(I2S_CTRL, ctrl);

	if(dma)
	{
		while(!(SMT_READ(DMACSta(i2s_tx_dmach))&0x00000009))
					;
		DMACDisable(i2s_tx_dmach);
		DMAChannelFree(i2s_tx_dmach);
	}
	else
	{
		tx_fifodepth = (SMT_READ(I2S_STATUS)&0x0F00)>>8;
		trans_size >>=2;

		i = 0;
		while(1)
		{
			if((SMT_READ(I2S_STATUS) & 0x0000007f) != 1<<(tx_fifodepth))
			{
				SMT_WRITE(I2S_DATA, sound_data[i]);
				i++;
				if(i >= trans_size)
					break;
			}
		}
	}
}

static void RunRx(unsigned wordlength, unsigned ljust, unsigned dma)
{
	unsigned ctrl;
	unsigned rx_fifodepth;
	int i;
	unsigned trans_size;

	DAC_SETWLEN(wordlength);
	DAC_SETLJUST(ljust);

	ctrl = SMT_READ(I2S_CTRL);
	ctrl &= 0x0000ffff;

	SMT_WRITE(I2S_CTRL, ctrl | 0x40000000);	// Rx RESET

	trans_size = 256;

	if(dma)
	{
		i2s_rx_dmach = DMAChannelAlloc(DMA_I2SRX);
		DMACNoDescrp(i2s_rx_dmach, (unsigned)(&I2S_DATA), 0/*dstIncr*/, 2/*word*/, (unsigned)receive_data, 1/*srcIncr*/, 2/*32bit*/, 5, trans_size);
	}

	ctrl |= (1<<31)		// Enable TX
		| (((!dma)&0x01)<<29)	// DMA
		| (1<<28)			// FifoORIntEn
		| ((wordlength&0x03)<<25)
		| ((ljust&0x01)<<24)
		| (RX_FIFOTH<<16);

	SMT_WRITE(I2S_CTRL, ctrl);

	ADC_ENABLE();
#if 0
	if(dma)
	{
		while(!(SMT_READ(DMACSta(i2s_rx_dmach))&0x00000009))
					;
		DMACDisable(i2s_rx_dmach);
		DMAChannelFree(i2s_rx_dmach);
	}
	else
	{
		rx_fifodepth = (SMT_READ(I2S_STATUS)&0x0F000000)>>24;
		trans_size >>=2;

		i = 0;
		while(1)
		{
			if(((SMT_READ(I2S_STATUS) & 0x007f0000)>>16) != 0)
			{
				receive_data[i] = SMT_READ(I2S_DATA);
				i++;
				if(i >= trans_size)
					break;
			}
		}
	}
#endif
}

static void WaitUntilTxFinished(void)
{
	while((SMT_READ(I2S_STATUS) & (1<<12)) == 0)
		;
}

static void WaitUntilRxDMAFinished(void)
{
	while(!(SMT_READ(DMACSta(i2s_rx_dmach))&0x00000009))
		;
}

static void WaitUntilRxFinished(void)
{
	while((SMT_READ(I2S_STATUS) & (1<<28)) == 0)
		;
}

static inline void StopRxTx(void)
{
	DAC_DISABLE();
	ADC_DISABLE();
	I2SCtrlReset();
}

unsigned temp_data[2];
static void CheckRxData(unsigned wordlength)
{
	int i, j;
	unsigned short *receive_data_short = (unsigned short *)receive_data;
	int temp;
	unsigned data_temp = 0;

	switch(wordlength)
	{
	case WORD_LEN_8:	// 8bit
		for(i = 0; i < 128; i++)
			if(receive_data_short[i] != 0)
				break;

		if(i == 128)	goto error;
		j = 0;
		for(;i < 128; i++)
		{
			data_temp = (((255UL-(j+1))<<8)|(255UL-j));
			if(receive_data_short[i] != data_temp)
				goto error1;
			j += 2;
		}
		return;
	case WORD_LEN_16:	// 16bit
		for(i = 0; i < 64; i++)
			if(receive_data[i] != 0)
				break;
		if(i == 64)	goto error;
		j = 0;
		for(; i < 64; i++)
		{
			data_temp = (((255-(j+1))<<24)|((j+1)<<16) | ((255-j)<<8) | (j));
			if(receive_data[i] != data_temp)
				goto error;
			j += 2;
		}
		return;
	case WORD_LEN_24:	// 24bit
		for(i = 0; i < 64; i++)
			if(receive_data[i] != 0)
				break;
		if(i == 64)	goto error;
		j = 0;
		for(; i < 64; i++)
		{
			temp = (((255-j)<<16) | (j<<8) | (j << 0));
			temp <<= 8;
			temp >>= 8;
			j++;
			if(receive_data[i] != temp)
				goto error;
		}
		return;
	case WORD_LEN_32:	// 32bit
		for(i = 0; i < 64; i++)
			if(receive_data[i] != 0)
				break;
		if(i == 64)	goto error;
		j = 0;
		for(; i < 64; i++)
		{
			data_temp = (((255-j)<<24) | (j<<16) | (j << 8) | (255-j));
			if(receive_data[i] != data_temp)
				goto error;
			j++;
		}
		return;
	}
	return;
error:
	temp_data[0] = receive_data[i];
	temp_data[1] = data_temp;
	GPIOWrite(0xdeaf);
	while(1);
error1:
	temp_data[0] = receive_data_short[i];
	temp_data[1] = data_temp;
	GPIOWrite(0xdeaf);
	while(1);
}

static void Wait1SampleDelay(void)
{
	int count = 10000;

	while(count--)
		;
}

volatile static int interrupt_canbe_asserted = 0;
volatile static int interrupt_asserted = 0;
static void I2SIRQ(unsigned irq)
{
	unsigned status;
	if(!interrupt_canbe_asserted)
	{
		GPIOWrite(0xdea0);
		while(1);
	}

	status = SMT_READ(I2S_STATUS);
	if(!(status & ((0x1UL<<28)|(0x1UL<<12))))
	{
		GPIOWrite(0xdea4);
		while(1);
	}
	
	if(status & (0x1UL<<28))	// Rx FIFO OR Int
	{
		SMT_WRITE(I2S_STATUS, status & (~(0x1UL<<12)));
		status = SMT_READ(I2S_STATUS);
		if(status & (0x1UL<<28))
		{
			GPIOWrite(0xdea1);
			while(1);
		}
		interrupt_asserted++;
	}

	if(status & (0x1UL<<12))	// Rx FIFO OR Int
	{
		SMT_WRITE(I2S_STATUS, status & (~(0x1UL<<28)));
		status = SMT_READ(I2S_STATUS);
		if(status & (0x1UL<<12))
		{
			GPIOWrite(0xdea2);
			while(1);
		}
		interrupt_asserted++;
	}
}

void I2SCtrlSimTest(void)
{
	int i;

	SMT_WRITE(RS_PINMUX0, 0xffffffff);		// all I2S
	SMT_WRITE(RS_PINMUX2, 0xffffffff);		// all GPIO1
	SMT_WRITE(GPIO1_OUT, 0x00000000);
	SMT_WRITE(GPIO1_OE, 0xffffffff);
	for(i = 0; i < 256; i++)
		sound_data[i] = ((255-i)<<24) | (i<<16) | (i<<8) | (255-i);

#if I2S_REG_READ_WRITE_TEST
	if(RegReadWriteTest() != I2S_NOERROR)
	{
		GPIOWrite(0xdeae);
		while(1);
	}
#endif
#if 1
	SetDTO(DTO_RATIO_48, 1, 0);
	DAC_SAMPLEFREQ(DAC_SAMPLEFREQ_48);

	RunRx(WORD_LEN_16, 0, 1);
	RunTx(WORD_LEN_16, 0, 1);
	WaitUntilTxFinished();
	WaitUntilRxDMAFinished();
	StopRxTx();
	CheckRxData(WORD_LEN_16);
	Wait1SampleDelay();

	SetDTO(DTO_RATIO_44_1, 1, 0);
	DAC_SAMPLEFREQ(DAC_SAMPLEFREQ_44_1);
	RunRx(WORD_LEN_24, 0, 1);
	RunTx(WORD_LEN_24, 0, 1);
	WaitUntilTxFinished();
	WaitUntilRxDMAFinished();
	StopRxTx();
	CheckRxData(WORD_LEN_24);
	Wait1SampleDelay();

	SetDTO(DTO_RATIO_32, 1, 0);
	DAC_SAMPLEFREQ(DAC_SAMPLEFREQ_32);
	RunRx(WORD_LEN_8, 0, 1);
	RunTx(WORD_LEN_8, 0, 1);
	WaitUntilTxFinished();
	WaitUntilRxDMAFinished();
	StopRxTx();
	CheckRxData(WORD_LEN_8);
	Wait1SampleDelay();

	SetDTO(DTO_RATIO_16, 1, 0);
	DAC_SAMPLEFREQ(DAC_SAMPLEFREQ_16);
	RunRx(WORD_LEN_32, 0, 1);
	RunTx(WORD_LEN_32, 0, 1);
	WaitUntilTxFinished();
	WaitUntilRxDMAFinished();
	StopRxTx();
	CheckRxData(WORD_LEN_32);
	Wait1SampleDelay();

	SetDTO(DTO_RATIO_22_05, 1, 0);
	DAC_SAMPLEFREQ(DAC_SAMPLEFREQ_22_05);

	RunRx(WORD_LEN_16, 1, 1);
	RunTx(WORD_LEN_16, 1, 1);
	WaitUntilTxFinished();
	WaitUntilRxDMAFinished();
	StopRxTx();
	CheckRxData(WORD_LEN_16);
	Wait1SampleDelay();

	SetDTO(DTO_RATIO_8, 1, 0);
	DAC_SAMPLEFREQ(DAC_SAMPLEFREQ_8);

	RunRx(WORD_LEN_24, 1, 1);
	RunTx(WORD_LEN_24, 1, 1);
	WaitUntilTxFinished();
	WaitUntilRxDMAFinished();
	StopRxTx();
	CheckRxData(WORD_LEN_24);
	Wait1SampleDelay();
#endif

	// Slave Mode & Interrupt Test
	EnableVIC(VIC_POLARITY, VIC_LEVEL, VIC_INTMOD);
	Enable_IRQ();
	RequestIRQ(IRQ_I2S, I2SIRQ);

	SetDTO(DTO_RATIO_48, 0, 0);	// Slave
	DAC_SAMPLEFREQ(DAC_SAMPLEFREQ_48);
	interrupt_asserted = 0;
	interrupt_canbe_asserted = 1;
	RunRx(WORD_LEN_24, 1, 1);
	RunTx(WORD_LEN_24, 1, 1);
	while(interrupt_asserted != 2)
			;
//	WaitUntilTxFinished();
//	WaitUntilRxFinished();
	StopRxTx();
	CheckRxData(WORD_LEN_24);

	if(interrupt_asserted != 2)
	{
		GPIOWrite(0xdea3);
		while(1);
	}

	ReleaseIRQ(IRQ_I2S);

	Disable_IRQ();
	DisableVIC();
}

