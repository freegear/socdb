/*----------------------------------------------------------
	File Name   : i2s.c 
	Description : i2s Controller test code
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/
#include "sysinc.h"
#include "Commonmacro.h"
#include "uart.h"
#include "dmac.h"
#include "irq.h"

#define REG_READ_WRITE_ERR	0xa0
#define INT_TEST_ERR	0xa1
#define COPY_ERR	0xa2

static void inline DMA2DDie(unsigned data)
{
	GPIOWrite(data);
	while(1)
		;
}

static void RegCheck(volatile unsigned *addr, unsigned reset_value, unsigned mask)
{
	int i;
	unsigned data;

	data = *addr;
	if(data != reset_value)
		DMA2DDie(0xde00 | REG_READ_WRITE_ERR);

	*addr = 0xffffffff;
	data = *addr;
	if(data != (0xffffffff&mask))
		DMA2DDie(0xde00 | REG_READ_WRITE_ERR);

	*addr = 0xaaaaaaaa;
	data = *addr;
	if(data != (0xaaaaaaaa&mask))
		DMA2DDie(0xde00 | REG_READ_WRITE_ERR);

	*addr = 0x55555555;
	data = *addr;
	if(data != (0x55555555&mask))
		DMA2DDie(0xde00 | REG_READ_WRITE_ERR);

	for(i = 0; i < 32; i++)
	{
		*addr = (1UL<<i);
		data = *addr;
		if(data != ((1UL<<i)&mask))
			DMA2DDie(0xde00 | REG_READ_WRITE_ERR);
	}

	*addr = reset_value;
	data = *addr;
	if(data != reset_value)
		DMA2DDie(0xde00 | REG_READ_WRITE_ERR);
}

static void DMA2DRegReadWriteTest(void)
{
	int ch;
	unsigned data;

	RegCheck(&DMA2D_SRCADDR, 0x00000000, 0xffffffff);
	RegCheck(&DMA2D_DSTADDR, 0x00000000, 0xffffffff);
	RegCheck(&DMA2D_SIZE, 0x00000000, 0x0000ffff);
	RegCheck(&DMA2D_CNT, 0x00000000, 0xffffffff);
	RegCheck(&DMA2D_ADDRUPD, 0x00000000, 0xffffffff);

	data = SMT_READ(DMA2D_STATUS);
	if(data != 0)
		DMA2DDie(0xde00 | REG_READ_WRITE_ERR);

	SMT_WRITE(DMA2D_STATUS, 0x00000010);
	data = SMT_READ(DMA2D_STATUS);
	if(data != 0x00000010)
		DMA2DDie(0xde00 | REG_READ_WRITE_ERR);

	SMT_WRITE(DMA2D_STATUS, 0x00000000);
	data = SMT_READ(DMA2D_STATUS);
	if(data != 0)
		DMA2DDie(0xde00 | REG_READ_WRITE_ERR);
}

static volatile unsigned dma2d_interrupted;
static volatile unsigned dma2d_interrupt_allowed;
static void DMA2DISR(unsigned irq)
{
	int ch;
	unsigned status;

	status = SMT_READ(DMA2D_STATUS);
	if(!(status & 0x80000000))
//	if(!(status & 0x40000000))	// 2D DMA controller bug!!
		DMA2DDie(0xde00 | INT_TEST_ERR);	// Something wrong : not enabled channel
		
	if(!(status & 0x00000003))
		DMA2DDie(0xde00 | INT_TEST_ERR);	// Something wrong

	if(status & 0x00000001)
		DMA2DDie(0xde00 | INT_TEST_ERR);	// Error interrupt !!

	if(!dma2d_interrupt_allowed)
		DMA2DDie(0xde00 | INT_TEST_ERR);	// Other interrupt channel

	if(dma2d_interrupted)
		DMA2DDie(0xde00 | INT_TEST_ERR);	// Already interrupted channel

	dma2d_interrupted = 1;

	// clear pending
	SMT_WRITE(DMA2D_STATUS, 0x00000003);
	status = SMT_READ(DMA2D_STATUS);
	if(status != 0)
		DMA2DDie(0xde00 | INT_TEST_ERR);	// Not cleared !!!
}

void DMA2DCopy(unsigned char *dest, unsigned char *src, unsigned nbytes, unsigned nlines, int srcupd, int dstupd)
{
	if(nbytes == 0)
		return;

	SMT_WRITE(DMA2D_SRCADDR, (unsigned)src);
	SMT_WRITE(DMA2D_DSTADDR, (unsigned)dest);
	SMT_WRITE(DMA2D_SIZE, nbytes);
	SMT_WRITE(DMA2D_CNT, (nlines<<16) | nbytes);
	SMT_WRITE(DMA2D_ADDRUPD, (srcupd<<16) | (dstupd & 0x0000ffff));
	SMT_WRITE(DMA2D_STATUS, (1UL<<31) | (1UL<<4) | (0x03));
}

#define DST_OFFSET 4
static volatile unsigned char test_data[32*32];
static volatile unsigned char copy_region[32*32];
static void DMA2DCopyTest(void)
{
	int src_addr, dst_addr, bytecnt, linecnt, src_addr_upd, dst_addr_upd;

	int i, j, k;

	for(i = 0; i < 32*32; i++)
		test_data[i] = i;

	EnableVIC(VIC_POLARITY, VIC_LEVEL, VIC_INTMOD);
	Enable_IRQ();

	for(src_addr = 0; src_addr < 4; src_addr++)
	for(dst_addr = 0; dst_addr < 4; dst_addr++)
	for(bytecnt = 8; bytecnt < (8+4); bytecnt++)
	for(linecnt = 0; linecnt < 2; linecnt++)
	for(src_addr_upd = 0; src_addr_upd < 4; src_addr_upd++)
	for(dst_addr_upd = 0; dst_addr_upd < 4; dst_addr_upd++)
	{
		for(i = 0; i < 16*2+4; i++)
			copy_region[i] = 0xff;
		
		RequestIRQ(IRQ_DMA2D, DMA2DISR);
		dma2d_interrupted = 0;
		dma2d_interrupt_allowed = 1;
		DMA2DCopy(copy_region+DST_OFFSET+dst_addr, test_data+src_addr,
			bytecnt, linecnt, src_addr_upd, dst_addr_upd);

		while(dma2d_interrupted == 0) ;

		dma2d_interrupt_allowed = 0;

		for(i = 0; i < DST_OFFSET+dst_addr; i++)
			if(copy_region[i] != 0xff)
				DMA2DDie(0xde00 | COPY_ERR);

		for(j = 0; j <= linecnt; j++)
		{
			for(k = 0; k < bytecnt; k++)
				if(copy_region[i+k+j*(dst_addr_upd+bytecnt)] != test_data[k+src_addr+j*(src_addr_upd+bytecnt)])
					DMA2DDie(0xde00 | COPY_ERR);
			for(; k < bytecnt+dst_addr_upd; k++)
				if(copy_region[i+k+j*(dst_addr_upd+bytecnt)] != 0xff)
					DMA2DDie(0xde00 | COPY_ERR);
		}

		i += j*(bytecnt+dst_addr_upd);
		for(; i < 16*2+4; i++)
			if(copy_region[i] != 0xff)
				DMA2DDie(0xde00 | COPY_ERR);
		ReleaseIRQ(IRQ_DMA2D);
	}

	Disable_IRQ();
	DisableVIC();
}

void DMA2DTest(void)
{
	DMA2DRegReadWriteTest();
	DMA2DCopyTest();
}
