/*----------------------------------------------------------
	File Name   : i2s.c 
	Description : i2s Controller test code
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/
#include "sysinc.h"
#include "Commonmacro.h"
#include "uart.h"
#include "dmac.h"
#include "irq.h"

#define REG_READ_WRITE_ERR	0xa0
#define INT_TEST_ERR	0xa1
#define COPY_ERR	0xa2

static void inline DMADie(unsigned data)
{
	GPIOWrite(data);
	while(1)
		;
}

static void RegCheck(volatile unsigned *addr, unsigned reset_value, unsigned mask)
{
	int i;
	unsigned data;

	data = *addr;
	if(data != reset_value)
		DMADie(0xde00 | REG_READ_WRITE_ERR);

	*addr = 0xffffffff;
	data = *addr;
	if(data != (0xffffffff&mask))
		DMADie(0xde00 | REG_READ_WRITE_ERR);

	*addr = 0xaaaaaaaa;
	data = *addr;
	if(data != (0xaaaaaaaa&mask))
		DMADie(0xde00 | REG_READ_WRITE_ERR);

	*addr = 0x55555555;
	data = *addr;
	if(data != (0x55555555&mask))
		DMADie(0xde00 | REG_READ_WRITE_ERR);

	for(i = 0; i < 32; i++)
	{
		*addr = (1UL<<i);
		data = *addr;
		if(data != ((1UL<<i)&mask))
			DMADie(0xde00 | REG_READ_WRITE_ERR);
	}

	*addr = reset_value;
	data = *addr;
	if(data != reset_value)
		DMADie(0xde00 | REG_READ_WRITE_ERR);
}

static void DMARegReadWriteTest(void)
{
	int ch;
	unsigned data;

	for(ch = 0; ch < 8; ch++)
	{
		RegCheck(&DMACSAdr(ch), 0x00000000, 0xffffffff);
		RegCheck(&DMACDAdr(ch), 0x00000000, 0xffffffff);
		RegCheck(&DMACCon(ch), 0x00000000, 0xffffffff);
		RegCheck(&DMACDescrp(ch), 0x00000000, 0xfffffffd);

		data = SMT_READ(DMACSta(ch));
		if((data&0xf3ffffff) != 0)
			DMADie(0xde00 | REG_READ_WRITE_ERR);

		SMT_WRITE(DMACSta(ch), 0x00000010)
		data = SMT_READ(DMACSta(ch));
		if((data&0xf3ffffff) != 0x00000010)
			DMADie(0xde00 | REG_READ_WRITE_ERR);

		SMT_WRITE(DMACSta(ch), 0x00000000)
		data = SMT_READ(DMACSta(ch));
		if((data&0xf3ffffff) != 0)
			DMADie(0xde00 | REG_READ_WRITE_ERR);
	}
}

static volatile unsigned dmach_interrupted;
static volatile unsigned dmach_interrupt_expected;
static void DMAISR(unsigned irq)
{
	int ch;
	unsigned status;

	switch(irq)
	{
	case IRQ_DMA0:
		ch = 0;
		break;
	case IRQ_DMA1:
		ch = 1;
		break;
	case IRQ_DMA2:
		ch = 2;
		break;
	case IRQ_DMA3:
		ch = 3;
		break;
	case IRQ_DMA4:
		ch = 4;
		break;
	case IRQ_DMA5:
		ch = 5;
		break;
	case IRQ_DMA6:
		ch = 6;
		break;
	case IRQ_DMA7:
		ch = 7;
		break;
	default:
		DMADie(0xde00 | INT_TEST_ERR);
	}

	status = SMT_READ(DMACSta(ch));
	if(!(status & 0x80000000))
		DMADie(0xde00 | INT_TEST_ERR);	// Something wrong : not enabled channel
		
	if(!(status & 0x0000000f))
		DMADie(0xde00 | INT_TEST_ERR);	// Something wrong

	if(status & 0x00000001)
		DMADie(0xde00 | INT_TEST_ERR);	// Error interrupt !!

	if(!(dmach_interrupt_expected & (1UL<<ch)))
		DMADie(0xde00 | INT_TEST_ERR);	// Other interrupt channel

	if(dmach_interrupted & (1UL<<ch))
		DMADie(0xde00 | INT_TEST_ERR);	// Already interrupted channel

	dmach_interrupted |= (1UL<<ch);

	// clear pending
	SMT_WRITE(DMACSta(ch), 0x0000000f);
	status = SMT_READ(DMACSta(ch));
	if((status & 0x8000000f) != 0)
		DMADie(0xde00 | INT_TEST_ERR);	// Not cleared !!!
}

void DMACopy(smtUint8 channel, unsigned char *dest, unsigned char *src, unsigned nbytes)
{
	unsigned int m2m = 1;		// Memory2Memory Transfer
	unsigned int srcIncr = 1;	// Source Increment
	unsigned int destIncr = 1;	// Destination Increment
	unsigned int Width = 2;		// WORD
	unsigned int size = 5;		// 32 byte
	unsigned int transferLen;

	if(nbytes == 0)
		return;

	transferLen = nbytes;
	SMT_WRITE(DMACSAdr(channel), (unsigned)src);
	SMT_WRITE(DMACDAdr(channel), (unsigned)dest);
	SMT_WRITE(DMACCon(channel), (m2m<<29)|(Width<<26)|(srcIncr<<28)|(destIncr<<25)|(Width<<23)|(size<<20)|transferLen);
	SMT_WRITE(DMACDescrp(channel), 1);
	SMT_WRITE(DMACSta(channel), 0x8000001F);
}

static volatile unsigned char test_data[32];
static volatile unsigned char copy_region[32];
static int channel_to_IRQ(int ch)
{
	int irq_num;
	if(ch >= 4)
	{
		ch -=4 ;
		irq_num = 7;
	}
	else
		irq_num = 6;

	return irq_num + (ch*2);
}

static void DMACopyTest(void)
{
	int i, j, ch, irq, sa, da, ss;

	for(i = 0; i < 32; i++)
		test_data[i] = i;

	EnableVIC(VIC_POLARITY, VIC_LEVEL, VIC_INTMOD);
	Enable_IRQ();

	for(j = 0; j < 64; j++)
	{
		ch = j & 0x07;
		sa = j & 0x03;
		da = (j & 0x0c)>>2;
		ss = (j & 0x30)>>4;

		for(i = 0; i < 20; i++)
			copy_region[i] = 0xff;

		dmach_interrupted = 0;
		dmach_interrupt_expected = 1UL<<ch;
		irq = channel_to_IRQ(ch);
		RequestIRQ(irq, DMAISR);
		DMACopy(ch, copy_region+4+da, test_data+sa, 8+ss);
		while(dmach_interrupted == 0);

		for(i = 0; i < 4+da; i++)
			if(copy_region[i] != 0xff)
				DMADie(0xde00 | COPY_ERR);

		for(; i < 4+8+ss+da; i++)
		{
			if(copy_region[i] != (i-da+sa-4))
				DMADie(0xde00 | COPY_ERR);
		}

		for(; i < 20; i++)
			if(copy_region[i] != 0xff)
				DMADie(0xde00 | COPY_ERR);

		ReleaseIRQ(irq);
	}
	Disable_IRQ();
	DisableVIC();
}


#if 0
static void UARTIntrTest(void)
{
	int ch;
	int baudrate = BAUDRATE_115200;
	int databit = DATABIT_8;
	int parity = PARITY_EVEN;
	int stopbit = STOPBIT_1;
	int j;
	int count = 100000;

	for(ch = 0; ch < 4; ch++)
	{
		uart_ch_data[ch].rx_count = 0;
		uart_ch_data[ch].tx_count = 0;
		ch_disabled[ch] = 0;
		for(j = 0; j < TEST_DATA_NUM*2; j++)
			rx_data[ch][j] = 0xff;
	}

	for(ch = 0; ch < 4; ch++)
		UARTInit(ch, baudrate, 0, databit, parity, stopbit);

	RequestIRQ(IRQ_UART1, UARTISR);
	RequestIRQ(IRQ_UART2, UARTISR);
	RequestIRQ(IRQ_UART3, UARTISR);

	while(1)
	{
		if(ch_disabled[0] && ch_disabled[1] && ch_disabled[2] && ch_disabled[3])
			break;
	}

	while(count--)
		;

	for(ch = 0; ch < 4; ch++)
		UARTDeinit(ch);

	ReleaseIRQ(IRQ_UART0);
	ReleaseIRQ(IRQ_UART1);
	ReleaseIRQ(IRQ_UART2);
	ReleaseIRQ(IRQ_UART3);
	Disable_IRQ();
	DisableVIC();

	for(ch = 0; ch < 4; ch++)
	{
		if(uart_ch_data[ch].rx_count != TEST_DATA_NUM)
			UARTDie(0xdea7);

		for(j = 0; j < TEST_DATA_NUM; j++)
			if(rx_data[ch][j] != test_data[j])
				UARTDie(0xdea8);
	}
}

#endif
void DMATest(void)
{
	DMARegReadWriteTest();
	DMACopyTest();
}
