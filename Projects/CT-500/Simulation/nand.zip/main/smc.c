/*----------------------------------------------------------
	File Name   : main.c 
	Description : Application Entry Point File
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/

/*/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// */
#define  __GCC_ARM__  1
#include "sysinc.h"
#include "Commonmacro.h"

#include "gpio.h"
#include "uart.h"
#include "dmac.h"

#include "memorymap.h"
/*/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION DECLARATION
///////////////////////////////////////////////////////// */
void SMCTest(void);

/*/////////////////////////////////////////////////////////
        VARIABLE DECLARATION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////// */

#define SMC_TEST_COUNT 1024		/* 1K WORD */
//volatile unsigned *test_temp = ((volatile unsigned *)0x20000000);
static unsigned test_temp[SMC_TEST_COUNT];
#define DATA0(x) (((x)&0xff)|((((x+1)&0xff)^0xff)<<8)|((((x+2)&0xff)^0xff)<<16)|(((x+1)&0xff)<<24))
#define DATA1(x) 0x55aaaa55
#define DATA2(x) 0xaa5555aa

void SMCTest(smtUint32 SMC_TESTREGION)
{
	int i;
	volatile smtUint8 * sram_testregion_byte = (volatile smtUint8 *)(SMC_TESTREGION);
	unsigned data;
	unsigned expected_data;

	// PHASE 0 : single write => single/burst read
	// single write
	for(i = 0; i < SMC_TEST_COUNT; i++)
		sram_testregion[i] = DATA0(i);

	// single read
	for(i = 0; i < SMC_TEST_COUNT; i++)
	{
		data = sram_testregion[i];
		if(data != DATA0(i))
		{
			expected_data = DATA0(i);
			goto error;
		}
	}

	// burst read using DMA
	DMACMemCopy(0, (unsigned char *)test_temp, (unsigned char *)sram_testregion, SMC_TEST_COUNT*4);
	for(i = 0; i < SMC_TEST_COUNT; i++)
	{
		data = test_temp[i];
		if(data != DATA0(i))
		{
			expected_data = DATA0(i);
			goto error;
		}
	}


	// PHASE 1 : burst write => single/burst read
	// burst write DDR region
	for(i = 0; i < SMC_TEST_COUNT; i++)
		test_temp[i] = DATA1(i);
	DMACMemCopy(0, (unsigned char *)sram_testregion, (unsigned char *)test_temp, SMC_TEST_COUNT*4);

	// single read
	for(i = 0; i < SMC_TEST_COUNT; i++)
	{
		data = sram_testregion[i];
		if(data != DATA1(i))
		{
			expected_data = DATA1(i);
			goto error;
		}
	}

	// burst read
	for(i = 0; i < SMC_TEST_COUNT; i++)
		test_temp[i] = 0xffffffff;
	DMACMemCopy(0, (unsigned char *)test_temp, (unsigned char *)sram_testregion, SMC_TEST_COUNT*4);
	for(i = 0; i < SMC_TEST_COUNT; i++)
	{
		data = test_temp[i];
		if(data != DATA1(i))
		{
			expected_data = DATA1(i);
			goto error;
		}
	}


	// PHASE 2 : single write => single/burst read
	// single write
	for(i = 0; i < SMC_TEST_COUNT; i++)
		sram_testregion[i] = DATA2(i);

	// single read
	for(i = 0; i < SMC_TEST_COUNT; i++)
	{
		data = sram_testregion[i];
		if(data != DATA2(i))
		{
			expected_data = DATA2(i);
			goto error;
		}
	}

	// burst read using DMA
	DMACMemCopy(0, (unsigned char *)test_temp, (unsigned char *)sram_testregion, SMC_TEST_COUNT*4);
	for(i = 0; i < SMC_TEST_COUNT; i++)
	{
		data = test_temp[i];
		if(data != DATA2(i))
		{
			expected_data = DATA2(i);
			goto error;
		}
	}

	// PHASE 3 : single write => single/burst read(byte)
	// single write(byte)
	for(i = 0; i < SMC_TEST_COUNT*4; i++)
		sram_testregion_byte[i] = i&0xff;

	// single read
	for(i = 0; i < SMC_TEST_COUNT*4; i++)
	{
		data = sram_testregion_byte[i];
		if(data != (i & 0xff))
		{
			expected_data = i & 0xff;
			goto error;
		}
	}
	DMACMemCopy(0, (unsigned char *)test_temp, (unsigned char *)sram_testregion, SMC_TEST_COUNT*4);
	for(i = 0; i < SMC_TEST_COUNT*4; i++)
	{
		data = ((smtUint8*)test_temp)[i];
		if(data != (i & 0xff))
		{
			expected_data = i & 0xff;
			goto error;
		}
	}

	DPRINTF("Done\n");
	return;

error:
	DPRINTF("Error(Read %08x when expected %08x)\n", data, expected_data);
	GPIOWrite(0x5dead);
	while(1);
}

void EthernetReadWriteTest(void)
{
	unsigned short data;
	unsigned short data_expected;
#define DEFAULT_LAN91C111_BASE		0x0300
#define LAN91C111_BANK_REG	(*(volatile unsigned short *)(EXT_STARTADDR2+DEFAULT_LAN91C111_BASE+0x0e))
#define LAN91C111_IA0_REG	(*(volatile unsigned short *)(EXT_STARTADDR2+DEFAULT_LAN91C111_BASE+0x04))
#define LAN91C111_IA1_REG	(*(volatile unsigned short *)(EXT_STARTADDR2+DEFAULT_LAN91C111_BASE+0x06))
#define LAN91C111_IA2_REG	(*(volatile unsigned short *)(EXT_STARTADDR2+DEFAULT_LAN91C111_BASE+0x08))
#define LAN91C111_GPR_REG	(*(volatile unsigned short *)(EXT_STARTADDR2+DEFAULT_LAN91C111_BASE+0x0a))

	// Ethernet Connected at Extenral SMC ChipSelect 1)
	DPRINTF("LAN91C111 Register Read/Write Test...");
	SMT_WRITE(ESMC_B2_CON,
			0xfffffff0			// extremely slow timing
			| (1 << 2)			// 16bit
			| 0					// address shift : 0
	);

	data_expected = 0x3300;
	data = SMT_READ(LAN91C111_BANK_REG);
	if((data & 0xff00) != 0x3300)
	{
		data &= 0xff00;
		goto error;
	}
	SMT_WRITE(LAN91C111_BANK_REG, 0x01);

	SMT_WRITE(LAN91C111_IA0_REG, 0xAAAA);
	SMT_WRITE(LAN91C111_IA1_REG, 0x5555);
	SMT_WRITE(LAN91C111_IA2_REG, 0xAAAA);
	SMT_WRITE(LAN91C111_GPR_REG, 0x5555);

	data_expected = 0xaaaa;
	data = SMT_READ(LAN91C111_IA0_REG);
	if(data != 0xaaaa)
		goto error;
	data_expected = 0x5555;
	data = SMT_READ(LAN91C111_IA1_REG);
	if(data != 0x5555)
		goto error;
	data_expected = 0xaaaa;
	data = SMT_READ(LAN91C111_IA2_REG);
	if(data != 0xaaaa)
		goto error;
	data_expected = 0x5555;
	data = SMT_READ(LAN91C111_GPR_REG);
	if(data != 0x5555)
		goto error;

	DPRINTF("Done\n");
	return;
error:
	DPRINTF("Error : Read 0x%04x when 0x%04x expected\n", data , data_expected);
	return;
}

static unsigned char NORRead(int addr)
{
	return *((volatile unsigned char *)(EXT_STARTADDR1+addr));
}

static void NORWrite(int addr, unsigned char data)
{
	*((volatile unsigned char *)(EXT_STARTADDR1+addr)) = data;
}

void NORTest(void)
{
	int i;
	unsigned char data;
	unsigned char expected_data;

	UartPuts("NOR Test...");
	SMT_WRITE(ESMC_B1_CON,
			0xfffffff0			// extremely slow timing
			| (0 << 2)			// 8bit
			| 0					// No address shift
	);

	NORWrite(0x55<<1, 0x98);

	data = NORRead(0x20);
	expected_data = 0x51;
	if(data != expected_data)
		goto error;

	data = NORRead(0x22);
	expected_data = 0x52;
	if(data != expected_data)
		goto error;

	data = NORRead(0x24);
	expected_data = 0x59;
	if(data != expected_data)
		goto error;

	UartPuts("Done\n");
	return;
error:
	UartPrintf("Error(Read %02x when %02x expected)\n", data, expected_data);
	return;
}
