/*----------------------------------------------------------
	File Name   : main.c 
	Description : Application Entry Point File
	Created by  : SHMT SOC Team
-----------------------------------------------------------*/

/*/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// */
#define  __GCC_ARM__  1
#include "sysinc.h"
#include "Commonmacro.h"

#include "gpio.h"
#include "uart.h"
#include "dmac.h"

#include "memorymap.h"
/*/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// */
#define BLACK	0xff000000
#define BLUE	0xffff0000
#define GREEN	0xff00ff00
#define CYAN	0xffffff00
#define RED		0xff0000ff
#define MAGENTA	0xffff00ff
#define YELLOW	0xff00ffff
#define WHITE	0xffffffff

/*/////////////////////////////////////////////////////////
        FUNCTION DECLARATION
///////////////////////////////////////////////////////// */
void DDRTest(void);
void EthernetReadWriteTest(void);
void VideoEncoderEnable(void);
void InterruptTest(void);
void BGMTest(void);
void AudioDelayedLoopback(void);
void VideoTest(void);
void NandTest(void);
void ADV7181BTest(void);
void SEIPReadWriteTest(void);
static void Menu(void);

/*/////////////////////////////////////////////////////////
        VARIABLE DECLARATION
///////////////////////////////////////////////////////// */

/*/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////// */
/*-----------------------------------------------------------------------
    Function name   : main()
    Prototype           : void main(void)
    Return              : void
    Argument        :
    Comments        :
-----------------------------------------------------------------------*/
#define MODE         0
#define EN_DAC0             1
#define EN_DAC1             1
#define EN_DAC2             1
#define EN_SQPIXEL          0
#define EN_NONINTERLACE     0
int main(void)
{
	int count = 1000;
	int ch;
	volatile smtUint32 * ddram_testregion = (volatile smtUint32 *)(DDR_TESTREGION);
	GPIOOutputEnable(0x800fffff);
	GPIOWrite(0xA4321);

#ifndef SIMUL
	UartInit();
#endif

	GPIOWrite(0xA4322);

	//DPRINTF("Power On Self Test Start\n");
	NandTest();
//	DDRTest();
	
//	DDRInit();

	GPIOWrite(0xA4323);
//	EthernetReadWriteTest();

	GPIOWrite(0xA4324);
//	ADV7181BTest();		// I2C test

	GPIOWrite(0xA4325);
//	SEIPReadWriteTest();

//	VideoInputTest();
    while(1);
//___________________FPGA test end

	return 0;
}
/*
static void Menu(void)
{
	char user_input;
	unsigned char *backToMain = "Type '0' to return Menu\n";

	while(1)
	{
		DPRINTF("==== Test Menu ====\n");
		DPRINTF("1. Back Ground Music Play\n");
		DPRINTF("2. Audio Delayed Loop Back\n");
		DPRINTF("3. Video Test\n");
		DPRINTF("4. Interrupt Test\n");

		do {
			user_input = UartGetch();
		} while(user_input < '1' && user_input > '4');

		switch(user_input)
		{
		case '1':
			DPRINTF("Back Ground Music Play Start\n");
			DPRINTF(backToMain);
			BGMTest();
			break;
		case '2':
			DPRINTF("Audio Delayed Loop Back Start\n");
			DPRINTF(backToMain);
			AudioDelayedLoopback();
			break;
		case '3':
			DPRINTF("Video Output Test\n");
			DPRINTF(backToMain);
			VideoTest();
			break;
		case '4':
			DPRINTF("Interrupt Test Start\n");
			DPRINTF(backToMain);
			InterruptTest();
			break;
		}
	}
}
*/
void UndefHandler(unsigned *sp, unsigned spsr, unsigned lr)
{
	int i;
	UartPrintf("Register Dump at 0x%08x(SPSR:0x%08x LR:0x%08x)\n", (unsigned)sp, spsr, lr);
	for(i = 0; i < 15; i++)
		UartPrintf("0x%08x\n", *(sp+i));
}
