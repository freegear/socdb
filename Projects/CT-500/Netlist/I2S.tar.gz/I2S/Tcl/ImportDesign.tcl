analyze -f verilog -lib WORK I2S_ClockMgr.v
analyze -f verilog -lib WORK I2S_Control.v
analyze -f verilog -lib WORK I2S_Deserializer.v
analyze -f verilog -lib WORK I2S_DTO.v
analyze -f verilog -lib WORK I2S_FIFO.v
analyze -f verilog -lib WORK I2S_Serializer.v
analyze -f verilog -lib WORK I2S_Top.v

set TopDesign I2S_Top
elaborate $TopDesign -lib WORK
