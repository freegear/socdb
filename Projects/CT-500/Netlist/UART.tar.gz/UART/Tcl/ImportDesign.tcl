analyze -f verilog -lib WORK RxBlock.v
analyze -f verilog -lib WORK TxBlock.v
analyze -f verilog -lib WORK RegBlk.v
analyze -f verilog -lib WORK UartTop.v
analyze -f verilog -lib WORK Uart4Ch.v

set TopDesign Uart4Ch
elaborate $TopDesign -lib WORK
