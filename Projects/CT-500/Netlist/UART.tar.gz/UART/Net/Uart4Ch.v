
module Uart4Ch ( PCLK, PRESETn, PENABLE, PSEL, PWRITE, PADDR, PWDATA, PRDATA, 
        TXD, RXD, Interrupt, RxDMAReq, TxDMAReq );
  input [6:2] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  output [3:0] TXD;
  input [3:0] RXD;
  output [3:0] Interrupt;
  output [3:0] RxDMAReq;
  output [3:0] TxDMAReq;
  input PCLK, PRESETn, PENABLE, PSEL, PWRITE;
  wire   PSELUart0, PSELUart1, PSELUart2, PSELUart3, PRDATAUart0_31_,
         PRDATAUart0_30_, PRDATAUart0_29_, PRDATAUart0_28_, PRDATAUart0_27_,
         PRDATAUart0_26_, PRDATAUart0_25_, PRDATAUart0_24_, PRDATAUart0_23_,
         PRDATAUart0_22_, PRDATAUart0_19_, PRDATAUart0_18_, PRDATAUart0_17_,
         PRDATAUart0_16_, PRDATAUart0_15_, PRDATAUart0_14_, PRDATAUart0_13_,
         PRDATAUart0_12_, PRDATAUart0_11_, PRDATAUart0_10_, PRDATAUart0_9_,
         PRDATAUart0_8_, PRDATAUart0_7_, PRDATAUart0_6_, PRDATAUart0_5_,
         PRDATAUart0_4_, PRDATAUart0_3_, PRDATAUart0_2_, PRDATAUart0_1_,
         PRDATAUart0_0_, PRDATAUart1_31_, PRDATAUart1_30_, PRDATAUart1_29_,
         PRDATAUart1_28_, PRDATAUart1_27_, PRDATAUart1_26_, PRDATAUart1_25_,
         PRDATAUart1_24_, PRDATAUart1_23_, PRDATAUart1_22_, PRDATAUart1_19_,
         PRDATAUart1_18_, PRDATAUart1_17_, PRDATAUart1_16_, PRDATAUart1_15_,
         PRDATAUart1_14_, PRDATAUart1_13_, PRDATAUart1_12_, PRDATAUart1_11_,
         PRDATAUart1_10_, PRDATAUart1_9_, PRDATAUart1_8_, PRDATAUart1_7_,
         PRDATAUart1_6_, PRDATAUart1_5_, PRDATAUart1_4_, PRDATAUart1_3_,
         PRDATAUart1_2_, PRDATAUart1_1_, PRDATAUart1_0_, PRDATAUart2_31_,
         PRDATAUart2_30_, PRDATAUart2_29_, PRDATAUart2_28_, PRDATAUart2_27_,
         PRDATAUart2_26_, PRDATAUart2_25_, PRDATAUart2_24_, PRDATAUart2_23_,
         PRDATAUart2_22_, PRDATAUart2_19_, PRDATAUart2_18_, PRDATAUart2_17_,
         PRDATAUart2_16_, PRDATAUart2_15_, PRDATAUart2_14_, PRDATAUart2_13_,
         PRDATAUart2_12_, PRDATAUart2_11_, PRDATAUart2_10_, PRDATAUart2_9_,
         PRDATAUart2_8_, PRDATAUart2_7_, PRDATAUart2_6_, PRDATAUart2_5_,
         PRDATAUart2_4_, PRDATAUart2_3_, PRDATAUart2_2_, PRDATAUart2_1_,
         PRDATAUart2_0_, PRDATAUart3_31_, PRDATAUart3_30_, PRDATAUart3_29_,
         PRDATAUart3_28_, PRDATAUart3_27_, PRDATAUart3_26_, PRDATAUart3_25_,
         PRDATAUart3_24_, PRDATAUart3_23_, PRDATAUart3_22_, PRDATAUart3_19_,
         PRDATAUart3_18_, PRDATAUart3_17_, PRDATAUart3_16_, PRDATAUart3_15_,
         PRDATAUart3_14_, PRDATAUart3_13_, PRDATAUart3_12_, PRDATAUart3_11_,
         PRDATAUart3_10_, PRDATAUart3_9_, PRDATAUart3_8_, PRDATAUart3_7_,
         PRDATAUart3_6_, PRDATAUart3_5_, PRDATAUart3_4_, PRDATAUart3_3_,
         PRDATAUart3_2_, PRDATAUart3_1_, PRDATAUart3_0_, n72, n73, n74, n75,
         n76, n77, n78, n79, n80, n81, n82, n83, n84, n85, n86, n87, n88, n89,
         n90, n91, n92, n93, n96, n97, n98, n99, n100, n101, n102, n103, n104,
         n105, n106, n107, n108, n109, n110, n111, n112, n113, n114, n115,
         n116, n117, n118, n119, n120, n121, n122, n123, n124, n125, n126,
         n127, n128, n129, n130, n131, n132, n133, n134, n135, n136, n137,
         n138;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1, 
        SYNOPSYS_UNCONNECTED__2, SYNOPSYS_UNCONNECTED__3, 
        SYNOPSYS_UNCONNECTED__4, SYNOPSYS_UNCONNECTED__5, 
        SYNOPSYS_UNCONNECTED__6, SYNOPSYS_UNCONNECTED__7;
  assign PRDATA[21] = 1'b0;
  assign PRDATA[20] = 1'b0;

  UartTop_3_1 Uart0 ( .PADDR(PADDR[4:2]), .PENABLE(PENABLE), .PSEL(PSELUart0), 
        .PWDATA(PWDATA), .PWRITE(PWRITE), .clk(PCLK), .rstb(PRESETn), .rxd(
        RXD[0]), .PRDATA({PRDATAUart0_31_, PRDATAUart0_30_, PRDATAUart0_29_, 
        PRDATAUart0_28_, PRDATAUart0_27_, PRDATAUart0_26_, PRDATAUart0_25_, 
        PRDATAUart0_24_, PRDATAUart0_23_, PRDATAUart0_22_, 
        SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1, PRDATAUart0_19_, 
        PRDATAUart0_18_, PRDATAUart0_17_, PRDATAUart0_16_, PRDATAUart0_15_, 
        PRDATAUart0_14_, PRDATAUart0_13_, PRDATAUart0_12_, PRDATAUart0_11_, 
        PRDATAUart0_10_, PRDATAUart0_9_, PRDATAUart0_8_, PRDATAUart0_7_, 
        PRDATAUart0_6_, PRDATAUart0_5_, PRDATAUart0_4_, PRDATAUart0_3_, 
        PRDATAUart0_2_, PRDATAUart0_1_, PRDATAUart0_0_}), .int(Interrupt[0]), 
        .rxdmareq(RxDMAReq[0]), .txd(TXD[0]), .txdmareq(TxDMAReq[0]) );
  UartTop_3_0 Uart1 ( .PADDR(PADDR[4:2]), .PENABLE(PENABLE), .PSEL(PSELUart1), 
        .PWDATA(PWDATA), .PWRITE(PWRITE), .clk(PCLK), .rstb(PRESETn), .rxd(
        RXD[1]), .PRDATA({PRDATAUart1_31_, PRDATAUart1_30_, PRDATAUart1_29_, 
        PRDATAUart1_28_, PRDATAUart1_27_, PRDATAUart1_26_, PRDATAUart1_25_, 
        PRDATAUart1_24_, PRDATAUart1_23_, PRDATAUart1_22_, 
        SYNOPSYS_UNCONNECTED__2, SYNOPSYS_UNCONNECTED__3, PRDATAUart1_19_, 
        PRDATAUart1_18_, PRDATAUart1_17_, PRDATAUart1_16_, PRDATAUart1_15_, 
        PRDATAUart1_14_, PRDATAUart1_13_, PRDATAUart1_12_, PRDATAUart1_11_, 
        PRDATAUart1_10_, PRDATAUart1_9_, PRDATAUart1_8_, PRDATAUart1_7_, 
        PRDATAUart1_6_, PRDATAUart1_5_, PRDATAUart1_4_, PRDATAUart1_3_, 
        PRDATAUart1_2_, PRDATAUart1_1_, PRDATAUart1_0_}), .int(Interrupt[1]), 
        .rxdmareq(RxDMAReq[1]), .txd(TXD[1]), .txdmareq(TxDMAReq[1]) );
  UartTop_1_1 Uart2 ( .PADDR(PADDR[4:2]), .PENABLE(PENABLE), .PSEL(PSELUart2), 
        .PWDATA(PWDATA), .PWRITE(PWRITE), .clk(PCLK), .rstb(PRESETn), .rxd(
        RXD[2]), .PRDATA({PRDATAUart2_31_, PRDATAUart2_30_, PRDATAUart2_29_, 
        PRDATAUart2_28_, PRDATAUart2_27_, PRDATAUart2_26_, PRDATAUart2_25_, 
        PRDATAUart2_24_, PRDATAUart2_23_, PRDATAUart2_22_, 
        SYNOPSYS_UNCONNECTED__4, SYNOPSYS_UNCONNECTED__5, PRDATAUart2_19_, 
        PRDATAUart2_18_, PRDATAUart2_17_, PRDATAUart2_16_, PRDATAUart2_15_, 
        PRDATAUart2_14_, PRDATAUart2_13_, PRDATAUart2_12_, PRDATAUart2_11_, 
        PRDATAUart2_10_, PRDATAUart2_9_, PRDATAUart2_8_, PRDATAUart2_7_, 
        PRDATAUart2_6_, PRDATAUart2_5_, PRDATAUart2_4_, PRDATAUart2_3_, 
        PRDATAUart2_2_, PRDATAUart2_1_, PRDATAUart2_0_}), .int(Interrupt[2]), 
        .rxdmareq(RxDMAReq[2]), .txd(TXD[2]), .txdmareq(TxDMAReq[2]) );
  UartTop_1_0 Uart3 ( .PADDR(PADDR[4:2]), .PENABLE(PENABLE), .PSEL(PSELUart3), 
        .PWDATA(PWDATA), .PWRITE(PWRITE), .clk(PCLK), .rstb(PRESETn), .rxd(
        RXD[3]), .PRDATA({PRDATAUart3_31_, PRDATAUart3_30_, PRDATAUart3_29_, 
        PRDATAUart3_28_, PRDATAUart3_27_, PRDATAUart3_26_, PRDATAUart3_25_, 
        PRDATAUart3_24_, PRDATAUart3_23_, PRDATAUart3_22_, 
        SYNOPSYS_UNCONNECTED__6, SYNOPSYS_UNCONNECTED__7, PRDATAUart3_19_, 
        PRDATAUart3_18_, PRDATAUart3_17_, PRDATAUart3_16_, PRDATAUart3_15_, 
        PRDATAUart3_14_, PRDATAUart3_13_, PRDATAUart3_12_, PRDATAUart3_11_, 
        PRDATAUart3_10_, PRDATAUart3_9_, PRDATAUart3_8_, PRDATAUart3_7_, 
        PRDATAUart3_6_, PRDATAUart3_5_, PRDATAUart3_4_, PRDATAUart3_3_, 
        PRDATAUart3_2_, PRDATAUart3_1_, PRDATAUart3_0_}), .int(Interrupt[3]), 
        .rxdmareq(RxDMAReq[3]), .txd(TXD[3]), .txdmareq(TxDMAReq[3]) );
  INVX1 U207 ( .A(n134), .Y(PSELUart1) );
  INVX1 U208 ( .A(n136), .Y(PSELUart3) );
  INVX1 U209 ( .A(n135), .Y(PSELUart2) );
  INVX1 U210 ( .A(n132), .Y(PSELUart0) );
  OR2X1 U211 ( .A(n130), .B(n131), .Y(PRDATA[0]) );
  AO22X1 U212 ( .A0(PRDATAUart3_0_), .A1(PSELUart3), .B0(PRDATAUart2_0_), .B1(
        PSELUart2), .Y(n130) );
  AO22X1 U213 ( .A0(PRDATAUart1_0_), .A1(PSELUart1), .B0(PRDATAUart0_0_), .B1(
        PSELUart0), .Y(n131) );
  OR2X1 U214 ( .A(n108), .B(n109), .Y(PRDATA[1]) );
  AO22X1 U215 ( .A0(PRDATAUart3_1_), .A1(PSELUart3), .B0(PRDATAUart2_1_), .B1(
        PSELUart2), .Y(n108) );
  AO22X1 U216 ( .A0(PRDATAUart1_1_), .A1(PSELUart1), .B0(PRDATAUart0_1_), .B1(
        PSELUart0), .Y(n109) );
  OR2X1 U217 ( .A(n90), .B(n91), .Y(PRDATA[2]) );
  AO22X1 U218 ( .A0(PRDATAUart3_2_), .A1(PSELUart3), .B0(PRDATAUart2_2_), .B1(
        PSELUart2), .Y(n90) );
  AO22X1 U219 ( .A0(PRDATAUart1_2_), .A1(PSELUart1), .B0(PRDATAUart0_2_), .B1(
        PSELUart0), .Y(n91) );
  OR2X1 U220 ( .A(n84), .B(n85), .Y(PRDATA[3]) );
  AO22X1 U221 ( .A0(PRDATAUart3_3_), .A1(PSELUart3), .B0(PRDATAUart2_3_), .B1(
        PSELUart2), .Y(n84) );
  AO22X1 U222 ( .A0(PRDATAUart1_3_), .A1(PSELUart1), .B0(PRDATAUart0_3_), .B1(
        PSELUart0), .Y(n85) );
  OR2X1 U223 ( .A(n82), .B(n83), .Y(PRDATA[4]) );
  AO22X1 U224 ( .A0(PRDATAUart3_4_), .A1(PSELUart3), .B0(PRDATAUart2_4_), .B1(
        PSELUart2), .Y(n82) );
  AO22X1 U225 ( .A0(PRDATAUart1_4_), .A1(PSELUart1), .B0(PRDATAUart0_4_), .B1(
        PSELUart0), .Y(n83) );
  OR2X1 U226 ( .A(n80), .B(n81), .Y(PRDATA[5]) );
  AO22X1 U227 ( .A0(PRDATAUart3_5_), .A1(PSELUart3), .B0(PRDATAUart2_5_), .B1(
        PSELUart2), .Y(n80) );
  AO22X1 U228 ( .A0(PRDATAUart1_5_), .A1(PSELUart1), .B0(PRDATAUart0_5_), .B1(
        PSELUart0), .Y(n81) );
  OR2X1 U229 ( .A(n78), .B(n79), .Y(PRDATA[6]) );
  AO22X1 U230 ( .A0(PRDATAUart3_6_), .A1(PSELUart3), .B0(PRDATAUart2_6_), .B1(
        PSELUart2), .Y(n78) );
  AO22X1 U231 ( .A0(PRDATAUart1_6_), .A1(PSELUart1), .B0(PRDATAUart0_6_), .B1(
        PSELUart0), .Y(n79) );
  OR2X1 U232 ( .A(n76), .B(n77), .Y(PRDATA[7]) );
  AO22X1 U233 ( .A0(PRDATAUart3_7_), .A1(PSELUart3), .B0(PRDATAUart2_7_), .B1(
        PSELUart2), .Y(n76) );
  AO22X1 U234 ( .A0(PRDATAUart1_7_), .A1(PSELUart1), .B0(PRDATAUart0_7_), .B1(
        PSELUart0), .Y(n77) );
  OR2X1 U235 ( .A(n74), .B(n75), .Y(PRDATA[8]) );
  AO22X1 U236 ( .A0(PRDATAUart3_8_), .A1(PSELUart3), .B0(PRDATAUart2_8_), .B1(
        PSELUart2), .Y(n74) );
  AO22X1 U237 ( .A0(PRDATAUart1_8_), .A1(PSELUart1), .B0(PRDATAUart0_8_), .B1(
        PSELUart0), .Y(n75) );
  OR2X1 U238 ( .A(n72), .B(n73), .Y(PRDATA[9]) );
  AO22X1 U239 ( .A0(PRDATAUart3_9_), .A1(PSELUart3), .B0(PRDATAUart2_9_), .B1(
        PSELUart2), .Y(n72) );
  AO22X1 U240 ( .A0(PRDATAUart1_9_), .A1(PSELUart1), .B0(PRDATAUart0_9_), .B1(
        PSELUart0), .Y(n73) );
  OR2X1 U241 ( .A(n128), .B(n129), .Y(PRDATA[10]) );
  AO22X1 U242 ( .A0(PRDATAUart3_10_), .A1(PSELUart3), .B0(PRDATAUart2_10_), 
        .B1(PSELUart2), .Y(n128) );
  AO22X1 U243 ( .A0(PRDATAUart1_10_), .A1(PSELUart1), .B0(PRDATAUart0_10_), 
        .B1(PSELUart0), .Y(n129) );
  OR2X1 U244 ( .A(n126), .B(n127), .Y(PRDATA[11]) );
  AO22X1 U245 ( .A0(PRDATAUart3_11_), .A1(PSELUart3), .B0(PRDATAUart2_11_), 
        .B1(PSELUart2), .Y(n126) );
  AO22X1 U246 ( .A0(PRDATAUart1_11_), .A1(PSELUart1), .B0(PRDATAUart0_11_), 
        .B1(PSELUart0), .Y(n127) );
  OR2X1 U247 ( .A(n124), .B(n125), .Y(PRDATA[12]) );
  AO22X1 U248 ( .A0(PRDATAUart3_12_), .A1(PSELUart3), .B0(PRDATAUart2_12_), 
        .B1(PSELUart2), .Y(n124) );
  AO22X1 U249 ( .A0(PRDATAUart1_12_), .A1(PSELUart1), .B0(PRDATAUart0_12_), 
        .B1(PSELUart0), .Y(n125) );
  OR2X1 U250 ( .A(n122), .B(n123), .Y(PRDATA[13]) );
  AO22X1 U251 ( .A0(PRDATAUart3_13_), .A1(PSELUart3), .B0(PRDATAUart2_13_), 
        .B1(PSELUart2), .Y(n122) );
  AO22X1 U252 ( .A0(PRDATAUart1_13_), .A1(PSELUart1), .B0(PRDATAUart0_13_), 
        .B1(PSELUart0), .Y(n123) );
  OR2X1 U253 ( .A(n120), .B(n121), .Y(PRDATA[14]) );
  AO22X1 U254 ( .A0(PRDATAUart3_14_), .A1(PSELUart3), .B0(PRDATAUart2_14_), 
        .B1(PSELUart2), .Y(n120) );
  AO22X1 U255 ( .A0(PRDATAUart1_14_), .A1(PSELUart1), .B0(PRDATAUart0_14_), 
        .B1(PSELUart0), .Y(n121) );
  OR2X1 U256 ( .A(n118), .B(n119), .Y(PRDATA[15]) );
  AO22X1 U257 ( .A0(PRDATAUart3_15_), .A1(PSELUart3), .B0(PRDATAUart2_15_), 
        .B1(PSELUart2), .Y(n118) );
  AO22X1 U258 ( .A0(PRDATAUart1_15_), .A1(PSELUart1), .B0(PRDATAUart0_15_), 
        .B1(PSELUart0), .Y(n119) );
  NAND2X1 U259 ( .A(n137), .B(n138), .Y(PRDATA[28]) );
  AOI22X1 U260 ( .A0(PRDATAUart3_28_), .A1(PSELUart3), .B0(PRDATAUart2_28_), 
        .B1(PSELUart2), .Y(n137) );
  AOI22X1 U261 ( .A0(PRDATAUart1_28_), .A1(PSELUart1), .B0(PRDATAUart0_28_), 
        .B1(PSELUart0), .Y(n138) );
  NAND3BX1 U262 ( .AN(PADDR[6]), .B(n133), .C(PSEL), .Y(n132) );
  NAND3BX1 U263 ( .AN(PADDR[5]), .B(PSEL), .C(PADDR[6]), .Y(n135) );
  NAND3BX1 U264 ( .AN(PADDR[6]), .B(PSEL), .C(PADDR[5]), .Y(n134) );
  NAND3BX1 U265 ( .AN(n133), .B(PADDR[6]), .C(PSEL), .Y(n136) );
  INVX1 U266 ( .A(PADDR[5]), .Y(n133) );
  OR2X1 U267 ( .A(n116), .B(n117), .Y(PRDATA[16]) );
  AO22X1 U268 ( .A0(PRDATAUart3_16_), .A1(PSELUart3), .B0(PRDATAUart2_16_), 
        .B1(PSELUart2), .Y(n116) );
  AO22X1 U269 ( .A0(PRDATAUart1_16_), .A1(PSELUart1), .B0(PRDATAUart0_16_), 
        .B1(PSELUart0), .Y(n117) );
  OR2X1 U270 ( .A(n114), .B(n115), .Y(PRDATA[17]) );
  AO22X1 U271 ( .A0(PRDATAUart3_17_), .A1(PSELUart3), .B0(PRDATAUart2_17_), 
        .B1(PSELUart2), .Y(n114) );
  AO22X1 U272 ( .A0(PRDATAUart1_17_), .A1(PSELUart1), .B0(PRDATAUart0_17_), 
        .B1(PSELUart0), .Y(n115) );
  OR2X1 U273 ( .A(n112), .B(n113), .Y(PRDATA[18]) );
  AO22X1 U274 ( .A0(PRDATAUart3_18_), .A1(PSELUart3), .B0(PRDATAUart2_18_), 
        .B1(PSELUart2), .Y(n112) );
  AO22X1 U275 ( .A0(PRDATAUart1_18_), .A1(PSELUart1), .B0(PRDATAUart0_18_), 
        .B1(PSELUart0), .Y(n113) );
  OR2X1 U276 ( .A(n110), .B(n111), .Y(PRDATA[19]) );
  AO22X1 U277 ( .A0(PRDATAUart3_19_), .A1(PSELUart3), .B0(PRDATAUart2_19_), 
        .B1(PSELUart2), .Y(n110) );
  AO22X1 U278 ( .A0(PRDATAUart1_19_), .A1(PSELUart1), .B0(PRDATAUart0_19_), 
        .B1(PSELUart0), .Y(n111) );
  OR2X1 U279 ( .A(n106), .B(n107), .Y(PRDATA[22]) );
  AO22X1 U280 ( .A0(PRDATAUart3_22_), .A1(PSELUart3), .B0(PRDATAUart2_22_), 
        .B1(PSELUart2), .Y(n106) );
  AO22X1 U281 ( .A0(PRDATAUart1_22_), .A1(PSELUart1), .B0(PRDATAUart0_22_), 
        .B1(PSELUart0), .Y(n107) );
  OR2X1 U282 ( .A(n104), .B(n105), .Y(PRDATA[23]) );
  AO22X1 U283 ( .A0(PRDATAUart3_23_), .A1(PSELUart3), .B0(PRDATAUart2_23_), 
        .B1(PSELUart2), .Y(n104) );
  AO22X1 U284 ( .A0(PRDATAUart1_23_), .A1(PSELUart1), .B0(PRDATAUart0_23_), 
        .B1(PSELUart0), .Y(n105) );
  OR2X1 U285 ( .A(n102), .B(n103), .Y(PRDATA[24]) );
  AO22X1 U286 ( .A0(PRDATAUart3_24_), .A1(PSELUart3), .B0(PRDATAUart2_24_), 
        .B1(PSELUart2), .Y(n102) );
  AO22X1 U287 ( .A0(PRDATAUart1_24_), .A1(PSELUart1), .B0(PRDATAUart0_24_), 
        .B1(PSELUart0), .Y(n103) );
  OR2X1 U288 ( .A(n100), .B(n101), .Y(PRDATA[25]) );
  AO22X1 U289 ( .A0(PRDATAUart3_25_), .A1(PSELUart3), .B0(PRDATAUart2_25_), 
        .B1(PSELUart2), .Y(n100) );
  AO22X1 U290 ( .A0(PRDATAUart1_25_), .A1(PSELUart1), .B0(PRDATAUart0_25_), 
        .B1(PSELUart0), .Y(n101) );
  OR2X1 U291 ( .A(n98), .B(n99), .Y(PRDATA[26]) );
  AO22X1 U292 ( .A0(PRDATAUart3_26_), .A1(PSELUart3), .B0(PRDATAUart2_26_), 
        .B1(PSELUart2), .Y(n98) );
  AO22X1 U293 ( .A0(PRDATAUart1_26_), .A1(PSELUart1), .B0(PRDATAUart0_26_), 
        .B1(PSELUart0), .Y(n99) );
  OR2X1 U294 ( .A(n96), .B(n97), .Y(PRDATA[27]) );
  AO22X1 U295 ( .A0(PRDATAUart3_27_), .A1(PSELUart3), .B0(PRDATAUart2_27_), 
        .B1(PSELUart2), .Y(n96) );
  AO22X1 U296 ( .A0(PRDATAUart1_27_), .A1(PSELUart1), .B0(PRDATAUart0_27_), 
        .B1(PSELUart0), .Y(n97) );
  OR2X1 U297 ( .A(n92), .B(n93), .Y(PRDATA[29]) );
  AO22X1 U298 ( .A0(PRDATAUart3_29_), .A1(PSELUart3), .B0(PRDATAUart2_29_), 
        .B1(PSELUart2), .Y(n92) );
  AO22X1 U299 ( .A0(PRDATAUart1_29_), .A1(PSELUart1), .B0(PRDATAUart0_29_), 
        .B1(PSELUart0), .Y(n93) );
  OR2X1 U300 ( .A(n88), .B(n89), .Y(PRDATA[30]) );
  AO22X1 U301 ( .A0(PRDATAUart3_30_), .A1(PSELUart3), .B0(PRDATAUart2_30_), 
        .B1(PSELUart2), .Y(n88) );
  AO22X1 U302 ( .A0(PRDATAUart1_30_), .A1(PSELUart1), .B0(PRDATAUart0_30_), 
        .B1(PSELUart0), .Y(n89) );
  OR2X1 U303 ( .A(n86), .B(n87), .Y(PRDATA[31]) );
  AO22X1 U304 ( .A0(PRDATAUart3_31_), .A1(PSELUart3), .B0(PRDATAUart2_31_), 
        .B1(PSELUart2), .Y(n86) );
  AO22X1 U305 ( .A0(PRDATAUart1_31_), .A1(PSELUart1), .B0(PRDATAUart0_31_), 
        .B1(PSELUart0), .Y(n87) );
endmodule


module UartTop_1_1 ( PADDR, PENABLE, PSEL, PWDATA, PWRITE, clk, rstb, rxd, 
        PRDATA, int, rxdmareq, txd, txdmareq );
  input [4:2] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  input PENABLE, PSEL, PWRITE, clk, rstb, rxd;
  output int, rxdmareq, txd, txdmareq;
  wire   bytereceivedb, frameerror, overrunerror, parityerror, rxbusy,
         rxfifoempty, txbusy, txfifo_emptyb, txfifo_fillb, txfifo_fullb,
         baudx16clk, databit, fifordb, fifowrb, loopbacken, stopbit, swrst,
         uarten, frameerr_clear, parityerr_clear, overrunerr_clear;
  wire   [7:0] fifodata_rx;
  wire   [3:0] rxfifocnt;
  wire   [3:0] txfifocnt;
  wire   [7:0] fifodata_tx;
  wire   [1:0] parity;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1;
  assign PRDATA[21] = 1'b0;
  assign PRDATA[20] = 1'b0;

  RegBlk_1_3_1 RegBlock ( .PADDR(PADDR), .PENABLE(PENABLE), .PSEL(PSEL), 
        .PWDATA(PWDATA), .PWRITE(PWRITE), .bytereceivedb(bytereceivedb), .clk(
        clk), .fifodata_rx(fifodata_rx), .frameerror(frameerror), 
        .overrunerror(overrunerror), .parityerror(parityerror), .rstb(rstb), 
        .rxbusy(rxbusy), .rxfifocnt(rxfifocnt), .rxfifoempty(rxfifoempty), 
        .txbusy(txbusy), .txfifo_emptyb(txfifo_emptyb), .txfifo_fillb(
        txfifo_fillb), .txfifo_fullb(txfifo_fullb), .txfifocnt(txfifocnt), 
        .PRDATA({PRDATA[31:22], SYNOPSYS_UNCONNECTED__0, 
        SYNOPSYS_UNCONNECTED__1, PRDATA[19:0]}), .baudx16clk(baudx16clk), 
        .databit(databit), .fifodata_tx(fifodata_tx), .fifordb(fifordb), 
        .fifowrb(fifowrb), .int(int), .loopbacken(loopbacken), .parity(parity), 
        .rxdmareq(rxdmareq), .stopbit(stopbit), .swrst(swrst), .txdmareq(
        txdmareq), .uarten(uarten), .frameerr_clear(frameerr_clear), 
        .parityerr_clear(parityerr_clear), .overrunerr_clear(overrunerr_clear)
         );
  RxBlock_UART_FIFO_WIDTH3_1 RxBLK ( .baudx16clk(baudx16clk), .clk(clk), 
        .databit(databit), .fifordb(fifordb), .loopbacken(loopbacken), 
        .parity(parity), .rstb(rstb), .rxd(rxd), .stopbit(stopbit), .swrst(
        swrst), .txd(txd), .uarten(uarten), .bytereceivedb(bytereceivedb), 
        .fifodata_rx(fifodata_rx), .frameerror(frameerror), .overrunerror(
        overrunerror), .parityerror(parityerror), .rxbusy(rxbusy), .rxfifocnt(
        rxfifocnt), .rxfifoempty(rxfifoempty), .frameerr_clear(frameerr_clear), 
        .parityerr_clear(parityerr_clear), .overrunerr_clear(overrunerr_clear)
         );
  TxBlock_UART_FIFO_WIDTH3_1 TxBLK ( .baudx16clk(baudx16clk), .clk(clk), 
        .databit(databit), .fifodata_tx(fifodata_tx), .fifowrb(fifowrb), 
        .parity(parity), .rstb(rstb), .stopbit(stopbit), .swrst(swrst), 
        .uarten(uarten), .txbusy(txbusy), .txd(txd), .txfifo_emptyb(
        txfifo_emptyb), .txfifo_fillb(txfifo_fillb), .txfifo_fullb(
        txfifo_fullb), .txfifocnt(txfifocnt) );
endmodule


module TxBlock_UART_FIFO_WIDTH3_1 ( baudx16clk, clk, databit, fifodata_tx, 
        fifowrb, parity, rstb, stopbit, swrst, uarten, txbusy, txd, 
        txfifo_emptyb, txfifo_fillb, txfifo_fullb, txfifocnt );
  input [7:0] fifodata_tx;
  input [1:0] parity;
  output [3:0] txfifocnt;
  input baudx16clk, clk, databit, fifowrb, rstb, stopbit, swrst, uarten;
  output txbusy, txd, txfifo_emptyb, txfifo_fillb, txfifo_fullb;
  wire   N72, N73, N74, current_state_10_, current_state_9_, current_state_8_,
         current_state_7_, current_state_6_, current_state_5_,
         current_state_4_, current_state_3_, current_state_2_,
         current_state_1_, dtxclk, txclk, parity_int, fifordb, shiftenb,
         shiftreg_0_, N106, N107, N108, N110, N112, N113, N114, N115, N116,
         N117, N118, N119, N120, N121, N122, N123, N124, N125, N126, N127,
         N128, \txfifo[7][7] , \txfifo[7][6] , \txfifo[7][5] , \txfifo[7][4] ,
         \txfifo[7][3] , \txfifo[7][2] , \txfifo[7][1] , \txfifo[7][0] ,
         \txfifo[6][7] , \txfifo[6][6] , \txfifo[6][5] , \txfifo[6][4] ,
         \txfifo[6][3] , \txfifo[6][2] , \txfifo[6][1] , \txfifo[6][0] ,
         \txfifo[5][7] , \txfifo[5][6] , \txfifo[5][5] , \txfifo[5][4] ,
         \txfifo[5][3] , \txfifo[5][2] , \txfifo[5][1] , \txfifo[5][0] ,
         \txfifo[4][7] , \txfifo[4][6] , \txfifo[4][5] , \txfifo[4][4] ,
         \txfifo[4][3] , \txfifo[4][2] , \txfifo[4][1] , \txfifo[4][0] ,
         \txfifo[3][7] , \txfifo[3][6] , \txfifo[3][5] , \txfifo[3][4] ,
         \txfifo[3][3] , \txfifo[3][2] , \txfifo[3][1] , \txfifo[3][0] ,
         \txfifo[2][7] , \txfifo[2][6] , \txfifo[2][5] , \txfifo[2][4] ,
         \txfifo[2][3] , \txfifo[2][2] , \txfifo[2][1] , \txfifo[2][0] ,
         \txfifo[1][7] , \txfifo[1][6] , \txfifo[1][5] , \txfifo[1][4] ,
         \txfifo[1][3] , \txfifo[1][2] , \txfifo[1][1] , \txfifo[1][0] ,
         \txfifo[0][7] , \txfifo[0][6] , \txfifo[0][5] , \txfifo[0][4] ,
         \txfifo[0][3] , \txfifo[0][2] , \txfifo[0][1] , \txfifo[0][0] , N291,
         n5, n8, n131, n132, n133, n134, n135, n136, n137, n138, n139, n140,
         n141, n142, n143, n144, n145, n146, n147, n148, n149, n150, n151,
         n152, n153, n154, n155, n156, n157, n158, n159, n160, n161, n162,
         n163, n164, n165, n166, n167, n168, n169, n170, n171, n172, n173,
         n174, n175, n176, n177, n178, n179, n180, n181, n182, n183, n184,
         n185, n186, n187, n188, n189, n190, n191, n192, n193, n194, n195,
         n196, n197, n198, n199, n200, n201, n202, n203, n204, n205, n206,
         n207, n208, n209, n210, n211, n212, n213, n214, n249, n250, n251,
         n254, n256, n257, n258, n259, n260, n262, n263, n264, n265, n267,
         n268, n269, n270, n271, n272, n273, n274, n276, n277, n278, n279,
         n280, n283, n285, n289, n293, n294, n295, n296, n297, n304, n308,
         n309, n310, n311, n312, n319, n323, n324, n325, n326, n327, n334,
         n338, n339, n340, n341, n342, n349, n353, n354, n355, n356, n357,
         n364, n368, n369, n370, n371, n372, n379, n384, n385, n386, n388,
         n390, n392, n393, n395, n396, n398, n399, n400, n401, n402, n403,
         n405, n407, n408, n409, n410, n411, n412, n413, n414, n415, n416,
         n417, n418, n419, n422, n423, n424, n425, n427, n428, n429, n430,
         n431, n432, n434, n435, n436, n437, n439, n440, n441, n443, n445,
         n446, n447, n448, n451, n452, n453, n455, n456, n457, n458, n459,
         n460, n461, n462, n463, n464, n465, n466, n467, n469, n474, n476,
         n477, n478, n479, n482, n484, n485, n487, n488, n489, n490, n491,
         n492, n494, n495, n497, n498, n500, n501, n502, n503, n504, n505,
         n506, n507, n508, n509, n510, n511, n512, n513, n514, n515, n516,
         n517, n518, n519, n520, n521, n522, n523, n524, n525, n526, n527,
         n528, n529, n530, n531, n532, n533, n534, n535, n536, n537, n538,
         n539, n540, n541, n542, n543, n544, n545, n546, n548, n549, n550,
         n551, n552, n553, n554, n555, n556, n557, n558, n559, n560, n561,
         n562, n563, n564, n565, n566, n567, n568, n569, n570, n571, n572,
         n573, n574, n575, n576, n577, n578, n579, n580, n581, n582, n583,
         n584, n585, n586, n587, n588, n589, n590, n591, n592, n593, n594;
  wire   [3:0] txclkcnt;
  wire   [2:0] fifo_wrpos;

  AOI31X1 U643 ( .A0(N72), .A1(n504), .A2(n354), .B0(n355), .Y(n353) );
  AOI211X1 U644 ( .A0(n356), .A1(n357), .B0(fifordb), .C0(N72), .Y(n355) );
  AOI31X1 U645 ( .A0(N72), .A1(n504), .A2(n324), .B0(n325), .Y(n323) );
  AOI211X1 U646 ( .A0(n326), .A1(n327), .B0(fifordb), .C0(N72), .Y(n325) );
  AOI31X1 U647 ( .A0(N72), .A1(n504), .A2(n369), .B0(n370), .Y(n368) );
  AOI31X1 U648 ( .A0(N72), .A1(n504), .A2(n339), .B0(n340), .Y(n338) );
  AOI211X1 U649 ( .A0(n341), .A1(n342), .B0(fifordb), .C0(N72), .Y(n340) );
  AOI31X1 U650 ( .A0(N72), .A1(n504), .A2(n309), .B0(n310), .Y(n308) );
  AOI211X1 U651 ( .A0(n311), .A1(n312), .B0(fifordb), .C0(N72), .Y(n310) );
  INVX1 U652 ( .A(n436), .Y(n437) );
  INVX1 U653 ( .A(n434), .Y(n435) );
  INVX1 U654 ( .A(n431), .Y(n432) );
  INVX1 U655 ( .A(n429), .Y(n430) );
  INVX1 U656 ( .A(n427), .Y(n428) );
  INVX1 U657 ( .A(n424), .Y(n425) );
  INVX1 U658 ( .A(n422), .Y(n423) );
  INVX1 U659 ( .A(n418), .Y(n419) );
  INVX1 U660 ( .A(fifowrb), .Y(n408) );
  NAND2BX1 U661 ( .AN(n455), .B(n459), .Y(N107) );
  INVX1 U662 ( .A(N114), .Y(n459) );
  NAND3BX1 U663 ( .AN(n594), .B(n513), .C(n588), .Y(n436) );
  NAND3BX1 U664 ( .AN(n594), .B(n593), .C(n588), .Y(n434) );
  NAND3BX1 U665 ( .AN(n594), .B(n513), .C(n589), .Y(n431) );
  NAND3BX1 U666 ( .AN(n594), .B(n593), .C(n589), .Y(n429) );
  NAND3BX1 U667 ( .AN(n593), .B(n594), .C(n588), .Y(n427) );
  NAND3BX1 U668 ( .AN(n506), .B(n593), .C(n588), .Y(n424) );
  NAND3BX1 U669 ( .AN(n593), .B(n594), .C(n589), .Y(n422) );
  NAND3BX1 U670 ( .AN(n506), .B(n593), .C(n589), .Y(n418) );
  AO22X1 U671 ( .A0(n405), .A1(n399), .B0(n403), .B1(n513), .Y(n400) );
  INVX1 U672 ( .A(n405), .Y(n403) );
  OR2X1 U673 ( .A(N112), .B(n460), .Y(N108) );
  AO22X1 U674 ( .A0(n412), .A1(n399), .B0(n411), .B1(n592), .Y(n409) );
  OAI221X1 U675 ( .A0(uarten), .A1(n484), .B0(txfifo_emptyb), .B1(n484), .C0(
        n399), .Y(N114) );
  INVX1 U676 ( .A(n457), .Y(n484) );
  NAND3BX1 U677 ( .AN(n462), .B(n461), .C(n474), .Y(N106) );
  INVX1 U678 ( .A(N108), .Y(n474) );
  NAND2BX1 U679 ( .AN(n457), .B(n459), .Y(N112) );
  INVX1 U680 ( .A(n412), .Y(n411) );
  AO21X1 U681 ( .A0(n455), .A1(n399), .B0(N115), .Y(N113) );
  AO21X1 U682 ( .A0(n593), .A1(n592), .B0(n591), .Y(txfifocnt[0]) );
  DFFRX1 fifofull_reg ( .D(n195), .CK(clk), .RN(rstb), .Q(txfifocnt[3]), .QN(
        txfifo_fullb) );
  AO21X1 U683 ( .A0(n392), .A1(n503), .B0(n396), .Y(n393) );
  NAND4BX1 U684 ( .AN(n460), .B(n458), .C(n446), .D(n461), .Y(n455) );
  INVX1 U685 ( .A(n283), .Y(n271) );
  INVX1 U686 ( .A(n285), .Y(n270) );
  AO21X1 U687 ( .A0(n392), .A1(n554), .B0(n393), .Y(n384) );
  INVX1 U688 ( .A(n386), .Y(n392) );
  INVX1 U689 ( .A(txfifocnt[1]), .Y(n416) );
  INVX1 U690 ( .A(n398), .Y(n396) );
  INVX1 U691 ( .A(n274), .Y(n267) );
  OAI31X1 U692 ( .A0(n257), .A1(n258), .A2(n259), .B0(n260), .Y(n213) );
  INVX1 U693 ( .A(n262), .Y(n258) );
  INVX1 U694 ( .A(n263), .Y(n259) );
  OA22X1 U695 ( .A0(n514), .A1(n262), .B0(n263), .B1(n514), .Y(n260) );
  NAND2BX1 U696 ( .AN(n504), .B(n262), .Y(n263) );
  NOR2BX1 U697 ( .AN(n399), .B(n446), .Y(N126) );
  NOR2BX1 U698 ( .AN(n399), .B(n458), .Y(N110) );
  NOR2BX1 U699 ( .AN(n399), .B(n445), .Y(N127) );
  INVX1 U700 ( .A(n443), .Y(n452) );
  INVX1 U701 ( .A(n440), .Y(n451) );
  OAI32X1 U702 ( .A0(n440), .A1(n441), .A2(n501), .B0(n443), .B1(n507), .Y(
        N128) );
  INVX1 U703 ( .A(n453), .Y(n461) );
  INVX1 U704 ( .A(n462), .Y(n446) );
  INVX1 U705 ( .A(n447), .Y(n466) );
  INVX1 U706 ( .A(txfifo_emptyb), .Y(txfifo_fillb) );
  NAND3BX1 U707 ( .AN(txfifocnt[3]), .B(n408), .C(n399), .Y(n405) );
  AND2X2 U708 ( .A(n590), .B(n408), .Y(n588) );
  OAI31X1 U709 ( .A0(n414), .A1(n415), .A2(n416), .B0(n417), .Y(n195) );
  INVX1 U710 ( .A(txfifocnt[2]), .Y(n414) );
  OAI211X1 U711 ( .A0(fifordb), .A1(n408), .B0(txfifocnt[3]), .C0(n399), .Y(
        n417) );
  NAND4BX1 U712 ( .AN(n504), .B(txfifocnt[0]), .C(n408), .D(n399), .Y(n415) );
  AO22X1 U713 ( .A0(\txfifo[7][0] ), .A1(n418), .B0(fifodata_tx[0]), .B1(n419), 
        .Y(n187) );
  AO22X1 U714 ( .A0(\txfifo[7][1] ), .A1(n418), .B0(fifodata_tx[1]), .B1(n419), 
        .Y(n188) );
  AO22X1 U715 ( .A0(\txfifo[7][2] ), .A1(n418), .B0(fifodata_tx[2]), .B1(n419), 
        .Y(n189) );
  AO22X1 U716 ( .A0(\txfifo[7][3] ), .A1(n418), .B0(fifodata_tx[3]), .B1(n419), 
        .Y(n190) );
  AO22X1 U717 ( .A0(\txfifo[7][4] ), .A1(n418), .B0(fifodata_tx[4]), .B1(n419), 
        .Y(n191) );
  AO22X1 U718 ( .A0(\txfifo[7][5] ), .A1(n418), .B0(fifodata_tx[5]), .B1(n419), 
        .Y(n192) );
  AO22X1 U719 ( .A0(\txfifo[7][6] ), .A1(n418), .B0(fifodata_tx[6]), .B1(n419), 
        .Y(n193) );
  AO22X1 U720 ( .A0(\txfifo[7][7] ), .A1(n418), .B0(fifodata_tx[7]), .B1(n419), 
        .Y(n194) );
  AO22X1 U721 ( .A0(\txfifo[0][0] ), .A1(n436), .B0(n437), .B1(fifodata_tx[0]), 
        .Y(n131) );
  AO22X1 U722 ( .A0(\txfifo[0][1] ), .A1(n436), .B0(n437), .B1(fifodata_tx[1]), 
        .Y(n132) );
  AO22X1 U723 ( .A0(\txfifo[0][2] ), .A1(n436), .B0(n437), .B1(fifodata_tx[2]), 
        .Y(n133) );
  AO22X1 U724 ( .A0(\txfifo[0][3] ), .A1(n436), .B0(n437), .B1(fifodata_tx[3]), 
        .Y(n134) );
  AO22X1 U725 ( .A0(\txfifo[0][4] ), .A1(n436), .B0(n437), .B1(fifodata_tx[4]), 
        .Y(n135) );
  AO22X1 U726 ( .A0(\txfifo[0][5] ), .A1(n436), .B0(n437), .B1(fifodata_tx[5]), 
        .Y(n136) );
  AO22X1 U727 ( .A0(\txfifo[0][6] ), .A1(n436), .B0(n437), .B1(fifodata_tx[6]), 
        .Y(n137) );
  AO22X1 U728 ( .A0(\txfifo[0][7] ), .A1(n436), .B0(n437), .B1(fifodata_tx[7]), 
        .Y(n138) );
  AO22X1 U729 ( .A0(\txfifo[1][0] ), .A1(n434), .B0(n435), .B1(fifodata_tx[0]), 
        .Y(n139) );
  AO22X1 U730 ( .A0(\txfifo[1][1] ), .A1(n434), .B0(n435), .B1(fifodata_tx[1]), 
        .Y(n140) );
  AO22X1 U731 ( .A0(\txfifo[1][2] ), .A1(n434), .B0(n435), .B1(fifodata_tx[2]), 
        .Y(n141) );
  AO22X1 U732 ( .A0(\txfifo[1][3] ), .A1(n434), .B0(n435), .B1(fifodata_tx[3]), 
        .Y(n142) );
  AO22X1 U733 ( .A0(\txfifo[1][4] ), .A1(n434), .B0(n435), .B1(fifodata_tx[4]), 
        .Y(n143) );
  AO22X1 U734 ( .A0(\txfifo[1][5] ), .A1(n434), .B0(n435), .B1(fifodata_tx[5]), 
        .Y(n144) );
  AO22X1 U735 ( .A0(\txfifo[1][6] ), .A1(n434), .B0(n435), .B1(fifodata_tx[6]), 
        .Y(n145) );
  AO22X1 U736 ( .A0(\txfifo[1][7] ), .A1(n434), .B0(n435), .B1(fifodata_tx[7]), 
        .Y(n146) );
  AO22X1 U737 ( .A0(\txfifo[2][0] ), .A1(n431), .B0(n432), .B1(fifodata_tx[0]), 
        .Y(n147) );
  AO22X1 U738 ( .A0(\txfifo[2][1] ), .A1(n431), .B0(n432), .B1(fifodata_tx[1]), 
        .Y(n148) );
  AO22X1 U739 ( .A0(\txfifo[2][2] ), .A1(n431), .B0(n432), .B1(fifodata_tx[2]), 
        .Y(n149) );
  AO22X1 U740 ( .A0(\txfifo[2][3] ), .A1(n431), .B0(n432), .B1(fifodata_tx[3]), 
        .Y(n150) );
  AO22X1 U741 ( .A0(\txfifo[2][4] ), .A1(n431), .B0(n432), .B1(fifodata_tx[4]), 
        .Y(n151) );
  AO22X1 U742 ( .A0(\txfifo[2][5] ), .A1(n431), .B0(n432), .B1(fifodata_tx[5]), 
        .Y(n152) );
  AO22X1 U743 ( .A0(\txfifo[2][6] ), .A1(n431), .B0(n432), .B1(fifodata_tx[6]), 
        .Y(n153) );
  AO22X1 U744 ( .A0(\txfifo[2][7] ), .A1(n431), .B0(n432), .B1(fifodata_tx[7]), 
        .Y(n154) );
  AO22X1 U745 ( .A0(\txfifo[3][0] ), .A1(n429), .B0(n430), .B1(fifodata_tx[0]), 
        .Y(n155) );
  AO22X1 U746 ( .A0(\txfifo[3][1] ), .A1(n429), .B0(n430), .B1(fifodata_tx[1]), 
        .Y(n156) );
  AO22X1 U747 ( .A0(\txfifo[3][2] ), .A1(n429), .B0(n430), .B1(fifodata_tx[2]), 
        .Y(n157) );
  AO22X1 U748 ( .A0(\txfifo[3][3] ), .A1(n429), .B0(n430), .B1(fifodata_tx[3]), 
        .Y(n158) );
  AO22X1 U749 ( .A0(\txfifo[3][4] ), .A1(n429), .B0(n430), .B1(fifodata_tx[4]), 
        .Y(n159) );
  AO22X1 U750 ( .A0(\txfifo[3][5] ), .A1(n429), .B0(n430), .B1(fifodata_tx[5]), 
        .Y(n160) );
  AO22X1 U751 ( .A0(\txfifo[3][6] ), .A1(n429), .B0(n430), .B1(fifodata_tx[6]), 
        .Y(n161) );
  AO22X1 U752 ( .A0(\txfifo[3][7] ), .A1(n429), .B0(n430), .B1(fifodata_tx[7]), 
        .Y(n162) );
  AO22X1 U753 ( .A0(\txfifo[4][0] ), .A1(n427), .B0(n428), .B1(fifodata_tx[0]), 
        .Y(n163) );
  AO22X1 U754 ( .A0(\txfifo[4][1] ), .A1(n427), .B0(n428), .B1(fifodata_tx[1]), 
        .Y(n164) );
  AO22X1 U755 ( .A0(\txfifo[4][2] ), .A1(n427), .B0(n428), .B1(fifodata_tx[2]), 
        .Y(n165) );
  AO22X1 U756 ( .A0(\txfifo[4][3] ), .A1(n427), .B0(n428), .B1(fifodata_tx[3]), 
        .Y(n166) );
  AO22X1 U757 ( .A0(\txfifo[4][4] ), .A1(n427), .B0(n428), .B1(fifodata_tx[4]), 
        .Y(n167) );
  AO22X1 U758 ( .A0(\txfifo[4][5] ), .A1(n427), .B0(n428), .B1(fifodata_tx[5]), 
        .Y(n168) );
  AO22X1 U759 ( .A0(\txfifo[4][6] ), .A1(n427), .B0(n428), .B1(fifodata_tx[6]), 
        .Y(n169) );
  AO22X1 U760 ( .A0(\txfifo[4][7] ), .A1(n427), .B0(n428), .B1(fifodata_tx[7]), 
        .Y(n170) );
  AO22X1 U761 ( .A0(\txfifo[5][0] ), .A1(n424), .B0(n425), .B1(fifodata_tx[0]), 
        .Y(n171) );
  AO22X1 U762 ( .A0(\txfifo[5][1] ), .A1(n424), .B0(n425), .B1(fifodata_tx[1]), 
        .Y(n172) );
  AO22X1 U763 ( .A0(\txfifo[5][2] ), .A1(n424), .B0(n425), .B1(fifodata_tx[2]), 
        .Y(n173) );
  AO22X1 U764 ( .A0(\txfifo[5][3] ), .A1(n424), .B0(n425), .B1(fifodata_tx[3]), 
        .Y(n174) );
  AO22X1 U765 ( .A0(\txfifo[5][4] ), .A1(n424), .B0(n425), .B1(fifodata_tx[4]), 
        .Y(n175) );
  AO22X1 U766 ( .A0(\txfifo[5][5] ), .A1(n424), .B0(n425), .B1(fifodata_tx[5]), 
        .Y(n176) );
  AO22X1 U767 ( .A0(\txfifo[5][6] ), .A1(n424), .B0(n425), .B1(fifodata_tx[6]), 
        .Y(n177) );
  AO22X1 U768 ( .A0(\txfifo[5][7] ), .A1(n424), .B0(n425), .B1(fifodata_tx[7]), 
        .Y(n178) );
  AO22X1 U769 ( .A0(\txfifo[6][0] ), .A1(n422), .B0(n423), .B1(fifodata_tx[0]), 
        .Y(n179) );
  AO22X1 U770 ( .A0(\txfifo[6][1] ), .A1(n422), .B0(n423), .B1(fifodata_tx[1]), 
        .Y(n180) );
  AO22X1 U771 ( .A0(\txfifo[6][2] ), .A1(n422), .B0(n423), .B1(fifodata_tx[2]), 
        .Y(n181) );
  AO22X1 U772 ( .A0(\txfifo[6][3] ), .A1(n422), .B0(n423), .B1(fifodata_tx[3]), 
        .Y(n182) );
  AO22X1 U773 ( .A0(\txfifo[6][4] ), .A1(n422), .B0(n423), .B1(fifodata_tx[4]), 
        .Y(n183) );
  AO22X1 U774 ( .A0(\txfifo[6][5] ), .A1(n422), .B0(n423), .B1(fifodata_tx[5]), 
        .Y(n184) );
  AO22X1 U775 ( .A0(\txfifo[6][6] ), .A1(n422), .B0(n423), .B1(fifodata_tx[6]), 
        .Y(n185) );
  AO22X1 U776 ( .A0(\txfifo[6][7] ), .A1(n422), .B0(n423), .B1(fifodata_tx[7]), 
        .Y(n186) );
  NOR2X1 U777 ( .A(fifowrb), .B(n590), .Y(n589) );
  OAI2BB1X1 U778 ( .A0N(n594), .A1N(n400), .B0(n401), .Y(n201) );
  AOI33X1 U779 ( .A0(n402), .A1(n593), .A2(n403), .B0(n594), .B1(n590), .B2(
        n403), .Y(n401) );
  NOR2BX1 U780 ( .AN(fifo_wrpos[1]), .B(n594), .Y(n402) );
  OAI32X1 U781 ( .A0(n403), .A1(swrst), .A2(n513), .B0(n593), .B1(n405), .Y(
        n199) );
  OAI32X1 U782 ( .A0(n405), .A1(fifo_wrpos[1]), .A2(n513), .B0(n407), .B1(n590), .Y(n200) );
  INVX1 U783 ( .A(n400), .Y(n407) );
  NAND2BX1 U784 ( .AN(n489), .B(n490), .Y(txfifocnt[2]) );
  OAI33X1 U785 ( .A0(n491), .A1(n594), .A2(n544), .B0(n491), .B1(N74), .B2(
        n506), .Y(n489) );
  AOI33X1 U786 ( .A0(n544), .A1(n506), .A2(n491), .B0(N74), .B1(n594), .B2(
        n491), .Y(n490) );
  INVX1 U787 ( .A(n492), .Y(n491) );
  NAND4BX1 U788 ( .AN(txfifocnt[2]), .B(txfifo_fullb), .C(n416), .D(n485), .Y(
        txfifo_emptyb) );
  INVX1 U789 ( .A(txfifocnt[0]), .Y(n485) );
  NAND3BX1 U790 ( .AN(swrst), .B(n504), .C(txfifo_emptyb), .Y(n412) );
  OAI222X1 U791 ( .A0(n591), .A1(n590), .B0(N73), .B1(n591), .C0(N73), .C1(
        n590), .Y(n492) );
  BUFX2 U792 ( .A(fifo_wrpos[0]), .Y(n593) );
  OAI2BB1X1 U793 ( .A0N(N74), .A1N(n409), .B0(n410), .Y(n198) );
  AOI32X1 U794 ( .A0(n271), .A1(N72), .A2(n411), .B0(n411), .B1(n270), .Y(n410) );
  INVX1 U795 ( .A(n456), .Y(N115) );
  NAND4BX1 U796 ( .AN(swrst), .B(uarten), .C(n457), .D(txfifo_emptyb), .Y(n456) );
  OAI32X1 U797 ( .A0(n411), .A1(swrst), .A2(n592), .B0(N72), .B1(n412), .Y(
        n196) );
  OAI32X1 U798 ( .A0(n412), .A1(N73), .A2(n592), .B0(n413), .B1(n505), .Y(n197) );
  INVX1 U799 ( .A(n409), .Y(n413) );
  NOR2X1 U800 ( .A(n593), .B(n592), .Y(n591) );
  NAND2BX1 U801 ( .AN(N74), .B(N73), .Y(n283) );
  NAND2BX1 U802 ( .AN(N73), .B(N74), .Y(n285) );
  NAND2BX1 U803 ( .AN(N74), .B(n505), .Y(n274) );
  NAND2BX1 U804 ( .AN(n544), .B(N73), .Y(n273) );
  NAND2BX1 U805 ( .AN(n487), .B(n488), .Y(txfifocnt[1]) );
  OAI33X1 U806 ( .A0(n591), .A1(fifo_wrpos[1]), .A2(n505), .B0(n591), .B1(N73), 
        .B2(n590), .Y(n487) );
  AOI33X1 U807 ( .A0(n505), .A1(n590), .A2(n591), .B0(N73), .B1(fifo_wrpos[1]), 
        .B2(n591), .Y(n488) );
  NAND3BX1 U808 ( .AN(baudx16clk), .B(n545), .C(n399), .Y(n398) );
  NAND3BX1 U809 ( .AN(swrst), .B(n545), .C(n398), .Y(n386) );
  NAND3BX1 U810 ( .AN(n554), .B(txclkcnt[0]), .C(n392), .Y(n388) );
  OAI31X1 U811 ( .A0(n500), .A1(stopbit), .A2(n501), .B0(n494), .Y(n457) );
  OA21X2 U812 ( .A0(n500), .A1(n507), .B0(n8), .Y(n494) );
  NAND2BX1 U813 ( .AN(n476), .B(n445), .Y(n460) );
  OAI211X1 U814 ( .A0(txclk), .A1(n507), .B0(n565), .C0(n482), .Y(n476) );
  OA22X1 U815 ( .A0(n501), .A1(n441), .B0(txclk), .B1(n548), .Y(n482) );
  OR2X1 U816 ( .A(parity[0]), .B(parity[1]), .Y(n478) );
  INVX1 U817 ( .A(swrst), .Y(n399) );
  OAI211X1 U818 ( .A0(n249), .A1(n250), .B0(n5), .C0(n251), .Y(txd) );
  NAND2BX1 U819 ( .AN(n549), .B(parity_int), .Y(n250) );
  AOI32X1 U820 ( .A0(n497), .A1(n546), .A2(n249), .B0(shiftreg_0_), .B1(n498), 
        .Y(n251) );
  NAND2BX1 U821 ( .AN(parity[0]), .B(parity[1]), .Y(n249) );
  BUFX2 U822 ( .A(fifo_wrpos[2]), .Y(n594) );
  OA22X1 U823 ( .A0(N72), .A1(n264), .B0(n265), .B1(n592), .Y(n257) );
  AOI221X1 U824 ( .A0(\txfifo[0][7] ), .A1(n267), .B0(\txfifo[6][7] ), .B1(
        n268), .C0(n272), .Y(n264) );
  AOI221X1 U825 ( .A0(\txfifo[1][7] ), .A1(n267), .B0(\txfifo[7][7] ), .B1(
        n268), .C0(n269), .Y(n265) );
  INVX1 U826 ( .A(n273), .Y(n268) );
  OA22X1 U827 ( .A0(n283), .A1(n527), .B0(n285), .B1(n571), .Y(n356) );
  OA22X1 U828 ( .A0(n283), .A1(n528), .B0(n285), .B1(n572), .Y(n341) );
  OA22X1 U829 ( .A0(n283), .A1(n529), .B0(n285), .B1(n573), .Y(n326) );
  OA22X1 U830 ( .A0(n283), .A1(n530), .B0(n285), .B1(n574), .Y(n311) );
  OA22X1 U831 ( .A0(n283), .A1(n531), .B0(n285), .B1(n575), .Y(n296) );
  OA22X1 U832 ( .A0(n283), .A1(n532), .B0(n285), .B1(n576), .Y(n279) );
  AOI211X1 U833 ( .A0(n371), .A1(n372), .B0(fifordb), .C0(N72), .Y(n370) );
  OA22X1 U834 ( .A0(n274), .A1(n534), .B0(n273), .B1(n578), .Y(n372) );
  OA22X1 U835 ( .A0(n283), .A1(n533), .B0(n285), .B1(n577), .Y(n371) );
  OA22X1 U836 ( .A0(n283), .A1(n535), .B0(n285), .B1(n579), .Y(n379) );
  OA22X1 U837 ( .A0(n283), .A1(n536), .B0(n285), .B1(n580), .Y(n364) );
  OA22X1 U838 ( .A0(n283), .A1(n537), .B0(n285), .B1(n581), .Y(n349) );
  OA22X1 U839 ( .A0(n283), .A1(n538), .B0(n285), .B1(n582), .Y(n334) );
  OA22X1 U840 ( .A0(n283), .A1(n539), .B0(n285), .B1(n583), .Y(n319) );
  OA22X1 U841 ( .A0(n283), .A1(n540), .B0(n285), .B1(n584), .Y(n304) );
  OA22X1 U842 ( .A0(n283), .A1(n541), .B0(n285), .B1(n585), .Y(n289) );
  OA22X1 U843 ( .A0(n274), .A1(n567), .B0(n273), .B1(n509), .Y(n357) );
  OA22X1 U844 ( .A0(n274), .A1(n568), .B0(n273), .B1(n510), .Y(n342) );
  OA22X1 U845 ( .A0(n274), .A1(n569), .B0(n273), .B1(n511), .Y(n327) );
  OA22X1 U846 ( .A0(n274), .A1(n570), .B0(n273), .B1(n512), .Y(n312) );
  OA22X1 U847 ( .A0(n274), .A1(n542), .B0(n273), .B1(n586), .Y(n297) );
  OA22X1 U848 ( .A0(n274), .A1(n543), .B0(n273), .B1(n587), .Y(n280) );
  AO22X1 U849 ( .A0(txclkcnt[2]), .A1(n384), .B0(n390), .B1(n518), .Y(n204) );
  INVX1 U850 ( .A(n388), .Y(n390) );
  AO22X1 U851 ( .A0(\txfifo[5][7] ), .A1(n270), .B0(\txfifo[3][7] ), .B1(n271), 
        .Y(n269) );
  AO22X1 U852 ( .A0(\txfifo[4][7] ), .A1(n270), .B0(\txfifo[2][7] ), .B1(n271), 
        .Y(n272) );
  OAI32X1 U853 ( .A0(n386), .A1(txclkcnt[1]), .A2(n503), .B0(n395), .B1(n554), 
        .Y(n203) );
  INVX1 U854 ( .A(n393), .Y(n395) );
  OAI221X1 U855 ( .A0(n557), .A1(n263), .B0(n262), .B1(n515), .C0(n368), .Y(
        n206) );
  OAI221X1 U856 ( .A0(n274), .A1(n519), .B0(n273), .B1(n558), .C0(n379), .Y(
        n369) );
  OAI221X1 U857 ( .A0(n263), .A1(n515), .B0(n262), .B1(n551), .C0(n353), .Y(
        n207) );
  OAI221X1 U858 ( .A0(n274), .A1(n520), .B0(n273), .B1(n559), .C0(n364), .Y(
        n354) );
  OAI221X1 U859 ( .A0(n263), .A1(n551), .B0(n262), .B1(n516), .C0(n338), .Y(
        n208) );
  OAI221X1 U860 ( .A0(n274), .A1(n521), .B0(n273), .B1(n560), .C0(n349), .Y(
        n339) );
  OAI221X1 U861 ( .A0(n263), .A1(n516), .B0(n262), .B1(n552), .C0(n323), .Y(
        n209) );
  OAI221X1 U862 ( .A0(n274), .A1(n522), .B0(n273), .B1(n561), .C0(n334), .Y(
        n324) );
  OAI221X1 U863 ( .A0(n263), .A1(n552), .B0(n262), .B1(n517), .C0(n308), .Y(
        n210) );
  OAI221X1 U864 ( .A0(n274), .A1(n523), .B0(n273), .B1(n562), .C0(n319), .Y(
        n309) );
  OAI221X1 U865 ( .A0(n263), .A1(n517), .B0(n262), .B1(n553), .C0(n293), .Y(
        n211) );
  AOI31X1 U866 ( .A0(N72), .A1(n504), .A2(n294), .B0(n295), .Y(n293) );
  OAI221X1 U867 ( .A0(n274), .A1(n524), .B0(n273), .B1(n563), .C0(n304), .Y(
        n294) );
  AOI211X1 U868 ( .A0(n296), .A1(n297), .B0(fifordb), .C0(N72), .Y(n295) );
  OAI221X1 U869 ( .A0(n263), .A1(n553), .B0(n514), .B1(n262), .C0(n276), .Y(
        n212) );
  AOI31X1 U870 ( .A0(N72), .A1(n504), .A2(n277), .B0(n278), .Y(n276) );
  OAI221X1 U871 ( .A0(n274), .A1(n525), .B0(n273), .B1(n564), .C0(n289), .Y(
        n277) );
  AOI211X1 U872 ( .A0(n279), .A1(n280), .B0(fifordb), .C0(N72), .Y(n278) );
  AO21X1 U873 ( .A0(txclkcnt[3]), .A1(n384), .B0(n385), .Y(n205) );
  OAI33X1 U874 ( .A0(n386), .A1(txclkcnt[2]), .A2(n555), .B0(n388), .B1(
        txclkcnt[3]), .B2(n518), .Y(n385) );
  INVX1 U875 ( .A(n477), .Y(n445) );
  OAI31X1 U876 ( .A0(n500), .A1(n502), .A2(n478), .B0(n479), .Y(n477) );
  OA22X1 U877 ( .A0(n500), .A1(n556), .B0(txclk), .B1(n501), .Y(n479) );
  NAND3BX1 U878 ( .AN(shiftenb), .B(fifordb), .C(txclk), .Y(n262) );
  NAND2BX1 U879 ( .AN(swrst), .B(txclk), .Y(n440) );
  NAND2BX1 U880 ( .AN(swrst), .B(n500), .Y(n443) );
  AO22X1 U881 ( .A0(current_state_3_), .A1(n500), .B0(current_state_2_), .B1(
        txclk), .Y(n453) );
  OAI32X1 U882 ( .A0(n500), .A1(n495), .A2(n502), .B0(txclk), .B1(n556), .Y(
        n462) );
  INVX1 U883 ( .A(n478), .Y(n495) );
  OAI31X1 U884 ( .A0(n500), .A1(databit), .A2(n550), .B0(n467), .Y(n447) );
  OA22X1 U885 ( .A0(txclk), .A1(n502), .B0(n500), .B1(n508), .Y(n467) );
  NOR2BX1 U886 ( .AN(n447), .B(swrst), .Y(N125) );
  NOR2BX1 U887 ( .AN(n453), .B(swrst), .Y(N117) );
  OR3X2 U888 ( .A(current_state_9_), .B(current_state_8_), .C(current_state_7_), .Y(n469) );
  INVX1 U889 ( .A(n463), .Y(n458) );
  NAND3BX1 U890 ( .AN(n464), .B(n465), .C(n466), .Y(n463) );
  NAND3BX1 U891 ( .AN(n469), .B(n526), .C(n566), .Y(n464) );
  AOI211X1 U892 ( .A0(current_state_3_), .A1(txclk), .B0(current_state_4_), 
        .C0(current_state_10_), .Y(n465) );
  OAI33X1 U893 ( .A0(n254), .A1(n504), .A2(n546), .B0(n256), .B1(parity_int), 
        .B2(n504), .Y(n214) );
  INVX1 U894 ( .A(n256), .Y(n254) );
  NAND3BX1 U895 ( .AN(shiftenb), .B(dtxclk), .C(shiftreg_0_), .Y(n256) );
  AO22X1 U896 ( .A0(n396), .A1(txclkcnt[0]), .B0(n392), .B1(n503), .Y(n202) );
  AO22X1 U897 ( .A0(current_state_8_), .A1(n451), .B0(current_state_9_), .B1(
        n452), .Y(N123) );
  AO22X1 U898 ( .A0(current_state_7_), .A1(n451), .B0(current_state_8_), .B1(
        n452), .Y(N122) );
  AO22X1 U899 ( .A0(current_state_6_), .A1(n451), .B0(current_state_7_), .B1(
        n452), .Y(N121) );
  AO22X1 U900 ( .A0(current_state_5_), .A1(n451), .B0(current_state_6_), .B1(
        n452), .Y(N120) );
  AO22X1 U901 ( .A0(current_state_4_), .A1(n451), .B0(current_state_5_), .B1(
        n452), .Y(N119) );
  AO22X1 U902 ( .A0(current_state_3_), .A1(n451), .B0(current_state_4_), .B1(
        n452), .Y(N118) );
  AO22X1 U903 ( .A0(current_state_1_), .A1(n399), .B0(current_state_2_), .B1(
        n452), .Y(N116) );
  AND4X1 U904 ( .A(baudx16clk), .B(n545), .C(txclkcnt[1]), .D(n439), .Y(N291)
         );
  AND4X1 U905 ( .A(n399), .B(n503), .C(n518), .D(n555), .Y(n439) );
  OAI32X1 U906 ( .A0(n440), .A1(n448), .A2(n550), .B0(n443), .B1(n508), .Y(
        N124) );
  INVX1 U907 ( .A(databit), .Y(n448) );
  INVX1 U908 ( .A(stopbit), .Y(n441) );
  DFFRX1 fifo_rdpos_reg_0_ ( .D(n196), .CK(clk), .RN(rstb), .Q(N72), .QN(n592)
         );
  DFFRX1 fifo_rdpos_reg_1_ ( .D(n197), .CK(clk), .RN(rstb), .Q(N73), .QN(n505)
         );
  DFFRX1 fifo_wrpos_reg_1_ ( .D(n200), .CK(clk), .RN(rstb), .Q(fifo_wrpos[1]), 
        .QN(n590) );
  DFFRX1 fifo_wrpos_reg_0_ ( .D(n199), .CK(clk), .RN(rstb), .Q(fifo_wrpos[0]), 
        .QN(n513) );
  DFFRX1 txclk_reg ( .D(N291), .CK(clk), .RN(rstb), .Q(txclk), .QN(n500) );
  DFFRX1 fifo_rdpos_reg_2_ ( .D(n198), .CK(clk), .RN(rstb), .Q(N74), .QN(n544)
         );
  DFFRX1 shiftreg_reg_0_ ( .D(n206), .CK(clk), .RN(rstb), .Q(shiftreg_0_), 
        .QN(n557) );
  DFFRX1 parity_int_reg ( .D(n214), .CK(clk), .RN(rstb), .Q(parity_int), .QN(
        n546) );
  DFFRX1 txdoutsel_reg_3_ ( .D(N126), .CK(clk), .RN(rstb), .Q(n497), .QN(n549)
         );
  DFFRX1 current_state_reg_14_ ( .D(N128), .CK(clk), .RN(rstb), .QN(n507) );
  DFFRX1 current_state_reg_13_ ( .D(N127), .CK(clk), .RN(rstb), .QN(n501) );
  DFFRX1 fifo_wrpos_reg_2_ ( .D(n201), .CK(clk), .RN(rstb), .Q(fifo_wrpos[2]), 
        .QN(n506) );
  DFFSX1 txdoutsel_reg_0_ ( .D(N108), .CK(clk), .SN(rstb), .QN(n5) );
  DFFRX1 txdoutsel_reg_2_ ( .D(N110), .CK(clk), .RN(rstb), .Q(n498) );
  DFFSX1 fifordb_reg ( .D(N107), .CK(clk), .SN(rstb), .Q(fifordb), .QN(n504)
         );
  DFFRX1 txclkcnt_reg_0_ ( .D(n202), .CK(clk), .RN(rstb), .Q(txclkcnt[0]), 
        .QN(n503) );
  DFFRX1 txclkcnt_reg_1_ ( .D(n203), .CK(clk), .RN(rstb), .Q(txclkcnt[1]), 
        .QN(n554) );
  DFFRX1 current_state_reg_8_ ( .D(N122), .CK(clk), .RN(rstb), .Q(
        current_state_8_) );
  DFFRX1 current_state_reg_7_ ( .D(N121), .CK(clk), .RN(rstb), .Q(
        current_state_7_) );
  DFFRX1 current_state_reg_6_ ( .D(N120), .CK(clk), .RN(rstb), .Q(
        current_state_6_), .QN(n526) );
  DFFRX1 current_state_reg_5_ ( .D(N119), .CK(clk), .RN(rstb), .Q(
        current_state_5_), .QN(n566) );
  DFFRX1 current_state_reg_2_ ( .D(N116), .CK(clk), .RN(rstb), .Q(
        current_state_2_), .QN(n548) );
  DFFRX1 current_state_reg_9_ ( .D(N123), .CK(clk), .RN(rstb), .Q(
        current_state_9_), .QN(n550) );
  DFFRX1 txclkcnt_reg_2_ ( .D(n204), .CK(clk), .RN(rstb), .Q(txclkcnt[2]), 
        .QN(n518) );
  DFFRX1 txclkcnt_reg_3_ ( .D(n205), .CK(clk), .RN(rstb), .Q(txclkcnt[3]), 
        .QN(n555) );
  DFFRX1 txfifo_reg ( .D(n131), .CK(clk), .RN(rstb), .Q(\txfifo[0][0] ), .QN(
        n534) );
  DFFRX1 txfifo_reg0 ( .D(n132), .CK(clk), .RN(rstb), .Q(\txfifo[0][1] ), .QN(
        n567) );
  DFFRX1 txfifo_reg1 ( .D(n133), .CK(clk), .RN(rstb), .Q(\txfifo[0][2] ), .QN(
        n568) );
  DFFRX1 txfifo_reg2 ( .D(n134), .CK(clk), .RN(rstb), .Q(\txfifo[0][3] ), .QN(
        n569) );
  DFFRX1 txfifo_reg3 ( .D(n135), .CK(clk), .RN(rstb), .Q(\txfifo[0][4] ), .QN(
        n570) );
  DFFRX1 txfifo_reg4 ( .D(n136), .CK(clk), .RN(rstb), .Q(\txfifo[0][5] ), .QN(
        n542) );
  DFFRX1 txfifo_reg5 ( .D(n137), .CK(clk), .RN(rstb), .Q(\txfifo[0][6] ), .QN(
        n543) );
  DFFRX1 txfifo_reg6 ( .D(n139), .CK(clk), .RN(rstb), .Q(\txfifo[1][0] ), .QN(
        n519) );
  DFFRX1 txfifo_reg7 ( .D(n140), .CK(clk), .RN(rstb), .Q(\txfifo[1][1] ), .QN(
        n520) );
  DFFRX1 txfifo_reg8 ( .D(n141), .CK(clk), .RN(rstb), .Q(\txfifo[1][2] ), .QN(
        n521) );
  DFFRX1 txfifo_reg9 ( .D(n142), .CK(clk), .RN(rstb), .Q(\txfifo[1][3] ), .QN(
        n522) );
  DFFRX1 txfifo_reg10 ( .D(n143), .CK(clk), .RN(rstb), .Q(\txfifo[1][4] ), 
        .QN(n523) );
  DFFRX1 txfifo_reg11 ( .D(n144), .CK(clk), .RN(rstb), .Q(\txfifo[1][5] ), 
        .QN(n524) );
  DFFRX1 txfifo_reg12 ( .D(n145), .CK(clk), .RN(rstb), .Q(\txfifo[1][6] ), 
        .QN(n525) );
  DFFRX1 txfifo_reg13 ( .D(n147), .CK(clk), .RN(rstb), .Q(\txfifo[2][0] ), 
        .QN(n533) );
  DFFRX1 txfifo_reg14 ( .D(n148), .CK(clk), .RN(rstb), .Q(\txfifo[2][1] ), 
        .QN(n527) );
  DFFRX1 txfifo_reg15 ( .D(n149), .CK(clk), .RN(rstb), .Q(\txfifo[2][2] ), 
        .QN(n528) );
  DFFRX1 txfifo_reg16 ( .D(n150), .CK(clk), .RN(rstb), .Q(\txfifo[2][3] ), 
        .QN(n529) );
  DFFRX1 txfifo_reg17 ( .D(n151), .CK(clk), .RN(rstb), .Q(\txfifo[2][4] ), 
        .QN(n530) );
  DFFRX1 txfifo_reg18 ( .D(n152), .CK(clk), .RN(rstb), .Q(\txfifo[2][5] ), 
        .QN(n531) );
  DFFRX1 txfifo_reg19 ( .D(n153), .CK(clk), .RN(rstb), .Q(\txfifo[2][6] ), 
        .QN(n532) );
  DFFRX1 txfifo_reg20 ( .D(n155), .CK(clk), .RN(rstb), .Q(\txfifo[3][0] ), 
        .QN(n535) );
  DFFRX1 txfifo_reg21 ( .D(n156), .CK(clk), .RN(rstb), .Q(\txfifo[3][1] ), 
        .QN(n536) );
  DFFRX1 txfifo_reg22 ( .D(n157), .CK(clk), .RN(rstb), .Q(\txfifo[3][2] ), 
        .QN(n537) );
  DFFRX1 txfifo_reg23 ( .D(n158), .CK(clk), .RN(rstb), .Q(\txfifo[3][3] ), 
        .QN(n538) );
  DFFRX1 txfifo_reg24 ( .D(n159), .CK(clk), .RN(rstb), .Q(\txfifo[3][4] ), 
        .QN(n539) );
  DFFRX1 txfifo_reg25 ( .D(n160), .CK(clk), .RN(rstb), .Q(\txfifo[3][5] ), 
        .QN(n540) );
  DFFRX1 txfifo_reg26 ( .D(n161), .CK(clk), .RN(rstb), .Q(\txfifo[3][6] ), 
        .QN(n541) );
  DFFRX1 txfifo_reg27 ( .D(n163), .CK(clk), .RN(rstb), .Q(\txfifo[4][0] ), 
        .QN(n577) );
  DFFRX1 txfifo_reg28 ( .D(n164), .CK(clk), .RN(rstb), .Q(\txfifo[4][1] ), 
        .QN(n571) );
  DFFRX1 txfifo_reg29 ( .D(n165), .CK(clk), .RN(rstb), .Q(\txfifo[4][2] ), 
        .QN(n572) );
  DFFRX1 txfifo_reg30 ( .D(n166), .CK(clk), .RN(rstb), .Q(\txfifo[4][3] ), 
        .QN(n573) );
  DFFRX1 txfifo_reg31 ( .D(n167), .CK(clk), .RN(rstb), .Q(\txfifo[4][4] ), 
        .QN(n574) );
  DFFRX1 txfifo_reg32 ( .D(n168), .CK(clk), .RN(rstb), .Q(\txfifo[4][5] ), 
        .QN(n575) );
  DFFRX1 txfifo_reg33 ( .D(n169), .CK(clk), .RN(rstb), .Q(\txfifo[4][6] ), 
        .QN(n576) );
  DFFRX1 txfifo_reg34 ( .D(n171), .CK(clk), .RN(rstb), .Q(\txfifo[5][0] ), 
        .QN(n579) );
  DFFRX1 txfifo_reg35 ( .D(n172), .CK(clk), .RN(rstb), .Q(\txfifo[5][1] ), 
        .QN(n580) );
  DFFRX1 txfifo_reg36 ( .D(n173), .CK(clk), .RN(rstb), .Q(\txfifo[5][2] ), 
        .QN(n581) );
  DFFRX1 txfifo_reg37 ( .D(n174), .CK(clk), .RN(rstb), .Q(\txfifo[5][3] ), 
        .QN(n582) );
  DFFRX1 txfifo_reg38 ( .D(n175), .CK(clk), .RN(rstb), .Q(\txfifo[5][4] ), 
        .QN(n583) );
  DFFRX1 txfifo_reg39 ( .D(n176), .CK(clk), .RN(rstb), .Q(\txfifo[5][5] ), 
        .QN(n584) );
  DFFRX1 txfifo_reg40 ( .D(n177), .CK(clk), .RN(rstb), .Q(\txfifo[5][6] ), 
        .QN(n585) );
  DFFRX1 txfifo_reg41 ( .D(n179), .CK(clk), .RN(rstb), .Q(\txfifo[6][0] ), 
        .QN(n578) );
  DFFRX1 txfifo_reg42 ( .D(n180), .CK(clk), .RN(rstb), .Q(\txfifo[6][1] ), 
        .QN(n509) );
  DFFRX1 txfifo_reg43 ( .D(n181), .CK(clk), .RN(rstb), .Q(\txfifo[6][2] ), 
        .QN(n510) );
  DFFRX1 txfifo_reg44 ( .D(n182), .CK(clk), .RN(rstb), .Q(\txfifo[6][3] ), 
        .QN(n511) );
  DFFRX1 txfifo_reg45 ( .D(n183), .CK(clk), .RN(rstb), .Q(\txfifo[6][4] ), 
        .QN(n512) );
  DFFRX1 txfifo_reg46 ( .D(n184), .CK(clk), .RN(rstb), .Q(\txfifo[6][5] ), 
        .QN(n586) );
  DFFRX1 txfifo_reg47 ( .D(n185), .CK(clk), .RN(rstb), .Q(\txfifo[6][6] ), 
        .QN(n587) );
  DFFRX1 txfifo_reg48 ( .D(n187), .CK(clk), .RN(rstb), .Q(\txfifo[7][0] ), 
        .QN(n558) );
  DFFRX1 txfifo_reg49 ( .D(n188), .CK(clk), .RN(rstb), .Q(\txfifo[7][1] ), 
        .QN(n559) );
  DFFRX1 txfifo_reg50 ( .D(n189), .CK(clk), .RN(rstb), .Q(\txfifo[7][2] ), 
        .QN(n560) );
  DFFRX1 txfifo_reg51 ( .D(n190), .CK(clk), .RN(rstb), .Q(\txfifo[7][3] ), 
        .QN(n561) );
  DFFRX1 txfifo_reg52 ( .D(n191), .CK(clk), .RN(rstb), .Q(\txfifo[7][4] ), 
        .QN(n562) );
  DFFRX1 txfifo_reg53 ( .D(n192), .CK(clk), .RN(rstb), .Q(\txfifo[7][5] ), 
        .QN(n563) );
  DFFRX1 txfifo_reg54 ( .D(n193), .CK(clk), .RN(rstb), .Q(\txfifo[7][6] ), 
        .QN(n564) );
  DFFRX1 current_state_reg_1_ ( .D(N115), .CK(clk), .RN(rstb), .Q(
        current_state_1_), .QN(n565) );
  DFFSX1 txclkcntenb_reg ( .D(N112), .CK(clk), .SN(rstb), .QN(n545) );
  DFFRX1 current_state_reg_10_ ( .D(N124), .CK(clk), .RN(rstb), .Q(
        current_state_10_), .QN(n508) );
  DFFRX1 shiftreg_reg_1_ ( .D(n207), .CK(clk), .RN(rstb), .QN(n515) );
  DFFRX1 shiftreg_reg_2_ ( .D(n208), .CK(clk), .RN(rstb), .QN(n551) );
  DFFRX1 shiftreg_reg_3_ ( .D(n209), .CK(clk), .RN(rstb), .QN(n516) );
  DFFRX1 shiftreg_reg_4_ ( .D(n210), .CK(clk), .RN(rstb), .QN(n552) );
  DFFRX1 shiftreg_reg_5_ ( .D(n211), .CK(clk), .RN(rstb), .QN(n517) );
  DFFRX1 shiftreg_reg_6_ ( .D(n212), .CK(clk), .RN(rstb), .QN(n553) );
  DFFRX1 shiftreg_reg_7_ ( .D(n213), .CK(clk), .RN(rstb), .QN(n514) );
  DFFRX1 current_state_reg_12_ ( .D(N126), .CK(clk), .RN(rstb), .QN(n556) );
  DFFRX1 current_state_reg_11_ ( .D(N125), .CK(clk), .RN(rstb), .QN(n502) );
  DFFRX1 current_state_reg_3_ ( .D(N117), .CK(clk), .RN(rstb), .Q(
        current_state_3_) );
  DFFRX1 current_state_reg_4_ ( .D(N118), .CK(clk), .RN(rstb), .Q(
        current_state_4_) );
  DFFRX1 dtxclk_reg ( .D(txclk), .CK(clk), .RN(rstb), .Q(dtxclk) );
  DFFRX1 txfifo_reg55 ( .D(n170), .CK(clk), .RN(rstb), .Q(\txfifo[4][7] ) );
  DFFRX1 txfifo_reg56 ( .D(n178), .CK(clk), .RN(rstb), .Q(\txfifo[5][7] ) );
  DFFRX1 txfifo_reg57 ( .D(n154), .CK(clk), .RN(rstb), .Q(\txfifo[2][7] ) );
  DFFRX1 txfifo_reg58 ( .D(n162), .CK(clk), .RN(rstb), .Q(\txfifo[3][7] ) );
  DFFSX1 current_state_reg_0_ ( .D(N114), .CK(clk), .SN(rstb), .QN(n8) );
  DFFSX1 shiftenb_reg ( .D(N106), .CK(clk), .SN(rstb), .Q(shiftenb) );
  DFFRX1 txfifo_reg59 ( .D(n138), .CK(clk), .RN(rstb), .Q(\txfifo[0][7] ) );
  DFFRX1 txfifo_reg60 ( .D(n146), .CK(clk), .RN(rstb), .Q(\txfifo[1][7] ) );
  DFFRX1 txfifo_reg61 ( .D(n186), .CK(clk), .RN(rstb), .Q(\txfifo[6][7] ) );
  DFFRX1 txfifo_reg62 ( .D(n194), .CK(clk), .RN(rstb), .Q(\txfifo[7][7] ) );
  DFFRX1 txbusy_int_reg ( .D(N113), .CK(clk), .RN(rstb), .Q(txbusy) );
endmodule


module RxBlock_UART_FIFO_WIDTH3_1 ( baudx16clk, clk, databit, fifordb, 
        loopbacken, parity, rstb, rxd, stopbit, swrst, txd, uarten, 
        bytereceivedb, fifodata_rx, frameerror, overrunerror, parityerror, 
        rxbusy, rxfifocnt, rxfifoempty, frameerr_clear, parityerr_clear, 
        overrunerr_clear );
  input [1:0] parity;
  output [7:0] fifodata_rx;
  output [3:0] rxfifocnt;
  input baudx16clk, clk, databit, fifordb, loopbacken, rstb, rxd, stopbit,
         swrst, txd, uarten, frameerr_clear, parityerr_clear, overrunerr_clear;
  output bytereceivedb, frameerror, overrunerror, parityerror, rxbusy,
         rxfifoempty;
  wire   N68, N69, N70, current_state_16_, current_state_14_,
         current_state_13_, current_state_11_, current_state_10_,
         current_state_9_, current_state_8_, current_state_7_,
         current_state_6_, current_state_5_, current_state_4_,
         current_state_3_, current_state_2_, current_state_1_, \rxfifo[7][7] ,
         \rxfifo[7][6] , \rxfifo[7][5] , \rxfifo[7][4] , \rxfifo[7][3] ,
         \rxfifo[7][2] , \rxfifo[7][1] , \rxfifo[7][0] , \rxfifo[6][7] ,
         \rxfifo[6][6] , \rxfifo[6][5] , \rxfifo[6][4] , \rxfifo[6][3] ,
         \rxfifo[6][2] , \rxfifo[6][1] , \rxfifo[6][0] , \rxfifo[5][7] ,
         \rxfifo[5][6] , \rxfifo[5][5] , \rxfifo[5][4] , \rxfifo[5][3] ,
         \rxfifo[5][2] , \rxfifo[5][1] , \rxfifo[5][0] , \rxfifo[4][7] ,
         \rxfifo[4][6] , \rxfifo[4][5] , \rxfifo[4][4] , \rxfifo[4][3] ,
         \rxfifo[4][2] , \rxfifo[4][1] , \rxfifo[4][0] , \rxfifo[3][7] ,
         \rxfifo[3][6] , \rxfifo[3][5] , \rxfifo[3][4] , \rxfifo[3][3] ,
         \rxfifo[3][2] , \rxfifo[3][1] , \rxfifo[3][0] , \rxfifo[2][7] ,
         \rxfifo[2][6] , \rxfifo[2][5] , \rxfifo[2][4] , \rxfifo[2][3] ,
         \rxfifo[2][2] , \rxfifo[2][1] , \rxfifo[2][0] , \rxfifo[1][7] ,
         \rxfifo[1][6] , \rxfifo[1][5] , \rxfifo[1][4] , \rxfifo[1][3] ,
         \rxfifo[1][2] , \rxfifo[1][1] , \rxfifo[1][0] , \rxfifo[0][7] ,
         \rxfifo[0][6] , \rxfifo[0][5] , \rxfifo[0][4] , \rxfifo[0][3] ,
         \rxfifo[0][2] , \rxfifo[0][1] , \rxfifo[0][0] , rx_lpfd, rxsftenb,
         rxclk, framechkb, paritychkb, parity_int, dataphaseb, rxclkenb, N223,
         N291, N292, N293, N294, N295, N296, N297, N298, N299, N300, N301,
         N302, N303, N304, N305, N306, N307, N308, n17, n18, n208, n209, n210,
         n211, n212, n213, n214, n215, n216, n217, n218, n219, n220, n221,
         n222, n2230, n224, n225, n226, n227, n228, n229, n230, n231, n232,
         n233, n234, n235, n236, n237, n238, n239, n240, n241, n242, n243,
         n244, n245, n246, n247, n248, n249, n250, n251, n252, n253, n254,
         n255, n256, n257, n258, n259, n260, n261, n262, n263, n264, n265,
         n266, n267, n268, n269, n270, n271, n272, n273, n274, n275, n276,
         n277, n278, n279, n280, n281, n282, n283, n284, n285, n286, n287,
         n288, n289, n290, n2910, n2920, n2930, n2940, n2950, n2960, n2970,
         n2980, n2990, n3000, n3010, n3020, n3030, n3040, n3050, n3060, n3070,
         n3080, n309, n310, n311, n312, n367, n368, n369, n371, n372, n373,
         n374, n375, n376, n378, n380, n381, n382, n383, n384, n385, n386,
         n387, n388, n390, n392, n393, n394, n395, n396, n398, n399, n400,
         n401, n404, n405, n406, n407, n408, n409, n410, n412, n413, n414,
         n415, n416, n417, n418, n419, n421, n422, n423, n424, n426, n427,
         n428, n429, n430, n431, n433, n434, n435, n436, n438, n440, n441,
         n442, n443, n444, n445, n446, n447, n448, n452, n453, n458, n459,
         n460, n461, n462, n463, n465, n466, n467, n468, n469, n470, n471,
         n472, n473, n475, n476, n477, n478, n480, n481, n482, n483, n484,
         n485, n488, n489, n490, n492, n493, n495, n496, n499, n500, n501,
         n502, n503, n504, n505, n506, n507, n509, n511, n512, n513, n514,
         n516, n517, n518, n519, n522, n523, n524, n525, n526, n527, n528,
         n530, n531, n532, n533, n534, n535, n540, n541, n542, n543, n544,
         n545, n546, n547, n550, n551, n555, n557, n558, n559, n560, n561,
         n564, n565, n567, n569, n570, n575, n578, n579, n582, n587, n590,
         n591, n594, n599, n602, n603, n606, n611, n614, n615, n618, n623,
         n626, n627, n630, n635, n638, n639, n642, n647, n650, n651, n654,
         n659, n662, n664, n666, n667, n669, n670, n673, n674, n682, n683,
         n684, n685, n688, n689, n690, n691, n692, n693, n694, n695, n696,
         n697, n698, n699, n700, n701, n702, n703, n704, n705, n706, n707,
         n708, n709, n710, n711, n712, n713, n714, n715, n716, n717, n718,
         n719, n720, n721, n722, n723, n724, n725, n726, n727, n728, n729,
         n730, n731, n732, n733, n734, n735, n736, n737, n738, n739, n740,
         n741, n742, n743, n744, n745, n746, n747, n748, n749, n750, n751,
         n752, n753, n754, n755, n756, n757, n758, n759, n760, n761, n762,
         n763, n764, n765, n766, n767, n768, n769, n770, n771, n772, n773,
         n774, n775, n776, n777, n778, n779, n780, n781, n782, n783, n784,
         n785, n786, n787, n788, n789, n790, n791, n792, n793, n794, n795,
         n796, n797, n798, n799;
  wire   [2:0] fifo_wrpos;
  wire   [7:0] rxsftreg;
  wire   [5:0] in_dly;
  wire   [3:0] rxclkcnt;

  INVX1 U846 ( .A(n505), .Y(n500) );
  NAND3BX1 U847 ( .AN(n514), .B(n535), .C(n781), .Y(n526) );
  OA22X1 U848 ( .A0(n519), .A1(n527), .B0(n518), .B1(n542), .Y(n535) );
  NAND2BX1 U849 ( .AN(n526), .B(n522), .Y(n505) );
  AO22X1 U850 ( .A0(n532), .A1(n541), .B0(n545), .B1(n546), .Y(n514) );
  INVX1 U851 ( .A(n541), .Y(n530) );
  INVX1 U852 ( .A(n527), .Y(n528) );
  AND2X2 U853 ( .A(n523), .B(n513), .Y(n781) );
  INVX1 U854 ( .A(n542), .Y(n545) );
  INVX1 U855 ( .A(n517), .Y(n512) );
  NAND3BX1 U856 ( .AN(n509), .B(n518), .C(n519), .Y(n517) );
  INVX1 U857 ( .A(n509), .Y(n499) );
  INVX1 U858 ( .A(rxfifocnt[0]), .Y(n394) );
  INVX1 U859 ( .A(n435), .Y(n436) );
  INVX1 U860 ( .A(n433), .Y(n434) );
  INVX1 U861 ( .A(n430), .Y(n431) );
  INVX1 U862 ( .A(n428), .Y(n429) );
  INVX1 U863 ( .A(n426), .Y(n427) );
  INVX1 U864 ( .A(n423), .Y(n424) );
  INVX1 U865 ( .A(n421), .Y(n422) );
  INVX1 U866 ( .A(n410), .Y(n412) );
  NAND4BX1 U867 ( .AN(n394), .B(fifordb), .C(n794), .D(rxfifocnt[1]), .Y(n398)
         );
  AO22X1 U868 ( .A0(n388), .A1(n372), .B0(n384), .B1(n693), .Y(n381) );
  OAI222X1 U869 ( .A0(n452), .A1(n741), .B0(n452), .B1(n697), .C0(n741), .C1(
        n697), .Y(n446) );
  INVX1 U870 ( .A(n388), .Y(n384) );
  INVX1 U871 ( .A(n441), .Y(n452) );
  DFFRX1 rxclk_reg ( .D(N223), .CK(clk), .RN(rstb), .Q(rxclk), .QN(n688) );
  NAND4BX1 U872 ( .AN(rxfifocnt[2]), .B(n736), .C(n393), .D(n394), .Y(n367) );
  INVX1 U873 ( .A(rxfifocnt[1]), .Y(n393) );
  NAND4BX1 U874 ( .AN(n740), .B(n530), .C(n531), .D(n532), .Y(n522) );
  NOR2BX1 U875 ( .AN(n533), .B(n534), .Y(n531) );
  NAND3BX1 U876 ( .AN(n547), .B(n689), .C(n737), .Y(n541) );
  NAND3BX1 U877 ( .AN(n533), .B(n530), .C(n532), .Y(n523) );
  NAND3X1 U878 ( .A(n522), .B(n372), .C(n502), .Y(n507) );
  NAND2BX1 U879 ( .AN(n503), .B(n502), .Y(n527) );
  NAND3BX1 U880 ( .AN(n561), .B(n786), .C(n785), .Y(n504) );
  INVX1 U881 ( .A(n557), .Y(n502) );
  NAND3BX1 U882 ( .AN(n558), .B(n559), .C(n560), .Y(n557) );
  INVX1 U883 ( .A(n504), .Y(n560) );
  NAND2BX1 U884 ( .AN(n555), .B(n787), .Y(n546) );
  NAND2BX1 U885 ( .AN(n544), .B(n528), .Y(n542) );
  INVX1 U886 ( .A(n409), .Y(n406) );
  NAND2BX1 U887 ( .AN(n798), .B(n797), .Y(n409) );
  NAND4X1 U888 ( .A(n534), .B(n533), .C(n530), .D(n532), .Y(n513) );
  INVX1 U889 ( .A(n550), .Y(n532) );
  NAND3BX1 U890 ( .AN(n543), .B(n551), .C(n545), .Y(n550) );
  INVX1 U891 ( .A(n546), .Y(n551) );
  INVX1 U892 ( .A(n496), .Y(n506) );
  OR2X1 U893 ( .A(n503), .B(n507), .Y(n509) );
  OAI211X1 U894 ( .A0(n794), .A1(n496), .B0(n524), .C0(n525), .Y(n211) );
  NOR2BX1 U895 ( .AN(n372), .B(n527), .Y(n524) );
  INVX1 U896 ( .A(n526), .Y(n525) );
  OAI211X1 U897 ( .A0(n698), .A1(n496), .B0(n500), .C0(n501), .Y(n217) );
  AOI211X1 U898 ( .A0(n502), .A1(n503), .B0(n504), .C0(N291), .Y(n501) );
  INVX1 U899 ( .A(n685), .Y(n559) );
  INVX1 U900 ( .A(uarten), .Y(n682) );
  AO21X1 U901 ( .A0(n798), .A1(n693), .B0(n406), .Y(rxfifocnt[0]) );
  AO22X1 U902 ( .A0(n378), .A1(n372), .B0(n376), .B1(n696), .Y(n373) );
  AO21X1 U903 ( .A0(n699), .A1(n691), .B0(n489), .Y(n492) );
  AO21X1 U904 ( .A0(n742), .A1(n691), .B0(n492), .Y(n481) );
  INVX1 U905 ( .A(n544), .Y(n519) );
  INVX1 U906 ( .A(n462), .Y(n471) );
  INVX1 U907 ( .A(n378), .Y(n376) );
  INVX1 U908 ( .A(n667), .Y(n472) );
  INVX1 U909 ( .A(n543), .Y(n518) );
  INVX1 U910 ( .A(n483), .Y(n489) );
  INVX1 U911 ( .A(n473), .Y(n470) );
  NAND3BX1 U912 ( .AN(n799), .B(n696), .C(n793), .Y(n435) );
  NAND3BX1 U913 ( .AN(n799), .B(n798), .C(n793), .Y(n433) );
  NAND3BX1 U914 ( .AN(n799), .B(n696), .C(n791), .Y(n430) );
  NAND3BX1 U915 ( .AN(n799), .B(n798), .C(n791), .Y(n428) );
  NAND3BX1 U916 ( .AN(n798), .B(n799), .C(n793), .Y(n426) );
  NAND3BX1 U917 ( .AN(n694), .B(n798), .C(n793), .Y(n423) );
  NAND3BX1 U918 ( .AN(n798), .B(n799), .C(n791), .Y(n421) );
  NAND3BX1 U919 ( .AN(n694), .B(n798), .C(n791), .Y(n410) );
  INVX1 U920 ( .A(n459), .Y(n460) );
  NOR2BX1 U921 ( .AN(n372), .B(n540), .Y(N307) );
  NOR2BX1 U922 ( .AN(n372), .B(n533), .Y(N305) );
  NOR2BX1 U923 ( .AN(n372), .B(n787), .Y(N301) );
  AND2X2 U924 ( .A(n372), .B(n503), .Y(N296) );
  AND2X2 U925 ( .A(n372), .B(n558), .Y(N295) );
  NOR2BX1 U926 ( .AN(n372), .B(n785), .Y(N294) );
  NOR2BX1 U927 ( .AN(n372), .B(n786), .Y(N293) );
  INVX1 U928 ( .A(n488), .Y(n485) );
  OAI32X1 U929 ( .A0(n462), .A1(n438), .A2(n737), .B0(n689), .B1(n667), .Y(
        N303) );
  OAI32X1 U930 ( .A0(n395), .A1(swrst), .A2(bytereceivedb), .B0(n736), .B1(
        n396), .Y(n3050) );
  INVX1 U931 ( .A(n396), .Y(n395) );
  OAI221X1 U932 ( .A0(fifordb), .A1(n794), .B0(n398), .B1(n399), .C0(n372), 
        .Y(n396) );
  INVX1 U933 ( .A(rxfifocnt[2]), .Y(n399) );
  NAND3BX1 U934 ( .AN(swrst), .B(n392), .C(n367), .Y(n388) );
  INVX1 U935 ( .A(fifordb), .Y(n392) );
  AO22X1 U936 ( .A0(txd), .A1(loopbacken), .B0(rxd), .B1(n458), .Y(n441) );
  INVX1 U937 ( .A(loopbacken), .Y(n458) );
  AO22X1 U938 ( .A0(in_dly[0]), .A1(n440), .B0(baudx16clk), .B1(n441), .Y(n235) );
  OAI33X1 U939 ( .A0(n441), .A1(in_dly[1]), .A2(n697), .B0(n441), .B1(
        in_dly[0]), .B2(n741), .Y(n448) );
  OAI2BB1X1 U940 ( .A0N(n442), .A1N(n443), .B0(n444), .Y(n234) );
  OA21X2 U941 ( .A0(n446), .A1(n445), .B0(baudx16clk), .Y(n442) );
  AOI32X1 U942 ( .A0(baudx16clk), .A1(n445), .A2(n446), .B0(rx_lpfd), .B1(n440), .Y(n444) );
  OA22X1 U943 ( .A0(n447), .A1(n448), .B0(in_dly[5]), .B1(n789), .Y(n443) );
  OAI2BB1X1 U944 ( .A0N(N70), .A1N(n381), .B0(n382), .Y(n3080) );
  AOI32X1 U945 ( .A0(n383), .A1(n797), .A2(n384), .B0(n385), .B1(n384), .Y(
        n382) );
  INVX1 U946 ( .A(n386), .Y(n385) );
  INVX1 U947 ( .A(n387), .Y(n383) );
  OAI32X1 U948 ( .A0(n384), .A1(swrst), .A2(n693), .B0(n797), .B1(n388), .Y(
        n3060) );
  OAI32X1 U949 ( .A0(n388), .A1(N69), .A2(n693), .B0(n390), .B1(n735), .Y(
        n3070) );
  INVX1 U950 ( .A(n381), .Y(n390) );
  OAI31X1 U951 ( .A0(n452), .A1(in_dly[1]), .A2(in_dly[0]), .B0(n453), .Y(n447) );
  AOI32X1 U952 ( .A0(in_dly[1]), .A1(in_dly[0]), .A2(n441), .B0(in_dly[5]), 
        .B1(n789), .Y(n453) );
  NAND2BX1 U953 ( .AN(n407), .B(n408), .Y(rxfifocnt[1]) );
  OAI33X1 U954 ( .A0(n406), .A1(fifo_wrpos[1]), .A2(n735), .B0(n406), .B1(N69), 
        .B2(n792), .Y(n407) );
  AOI33X1 U955 ( .A0(n735), .A1(n792), .A2(n406), .B0(N69), .B1(fifo_wrpos[1]), 
        .B2(n406), .Y(n408) );
  NAND2BX1 U956 ( .AN(n400), .B(n401), .Y(rxfifocnt[2]) );
  OAI33X1 U957 ( .A0(n404), .A1(n799), .A2(n738), .B0(n404), .B1(N70), .B2(
        n694), .Y(n400) );
  AOI33X1 U958 ( .A0(n738), .A1(n694), .A2(n404), .B0(N70), .B1(n799), .B2(
        n404), .Y(n401) );
  INVX1 U959 ( .A(n405), .Y(n404) );
  NAND3BX1 U960 ( .AN(swrst), .B(n528), .C(n500), .Y(n496) );
  NAND3BX1 U961 ( .AN(n18), .B(n788), .C(n540), .Y(n534) );
  AO22X1 U962 ( .A0(current_state_5_), .A1(n688), .B0(current_state_4_), .B1(
        n783), .Y(n503) );
  NAND2X1 U963 ( .A(n782), .B(n17), .Y(n685) );
  AO22X1 U964 ( .A0(current_state_4_), .A1(n440), .B0(current_state_3_), .B1(
        n783), .Y(n558) );
  OAI222X1 U965 ( .A0(n406), .A1(n792), .B0(N69), .B1(n406), .C0(N69), .C1(
        n792), .Y(n405) );
  INVX1 U966 ( .A(n367), .Y(rxfifoempty) );
  INVX1 U967 ( .A(baudx16clk), .Y(n440) );
  BUFX2 U968 ( .A(fifo_wrpos[0]), .Y(n798) );
  BUFX2 U969 ( .A(N68), .Y(n797) );
  BUFX2 U970 ( .A(fifo_wrpos[2]), .Y(n799) );
  OAI221X1 U971 ( .A0(n783), .A1(n734), .B0(n559), .B1(n682), .C0(n683), .Y(
        n561) );
  OAI31X1 U972 ( .A0(current_state_2_), .A1(current_state_4_), .A2(
        current_state_3_), .B0(n684), .Y(n683) );
  NOR2BX1 U973 ( .AN(baudx16clk), .B(n784), .Y(n684) );
  OAI31X1 U974 ( .A0(n688), .A1(databit), .A2(n737), .B0(n674), .Y(n547) );
  OA22X1 U975 ( .A0(rxclk), .A1(n692), .B0(n688), .B1(n689), .Y(n674) );
  INVX1 U976 ( .A(parity[1]), .Y(n475) );
  AND2X2 U977 ( .A(n784), .B(baudx16clk), .Y(n783) );
  AO22X1 U978 ( .A0(n505), .A1(n372), .B0(rxbusy), .B1(n506), .Y(n216) );
  AO21X1 U979 ( .A0(rxclkenb), .A1(n506), .B0(n507), .Y(n215) );
  OAI211X1 U980 ( .A0(n747), .A1(n496), .B0(n511), .C0(n512), .Y(n213) );
  NOR2BX1 U981 ( .AN(n513), .B(n514), .Y(n511) );
  OAI211X1 U982 ( .A0(n496), .A1(n744), .B0(n516), .C0(n512), .Y(n212) );
  NOR2BX1 U983 ( .AN(n523), .B(n514), .Y(n516) );
  OAI211X1 U984 ( .A0(n496), .A1(n746), .B0(n781), .C0(n499), .Y(n214) );
  OAI211X1 U985 ( .A0(n496), .A1(n745), .B0(n781), .C0(n499), .Y(n218) );
  AOI22X1 U986 ( .A0(current_state_3_), .A1(n440), .B0(current_state_2_), .B1(
        n783), .Y(n785) );
  AOI22X1 U987 ( .A0(current_state_2_), .A1(n440), .B0(current_state_1_), .B1(
        n783), .Y(n786) );
  AOI22X1 U988 ( .A0(current_state_9_), .A1(rxclk), .B0(current_state_10_), 
        .B1(n688), .Y(n787) );
  AOI21X1 U989 ( .A0(n669), .A1(current_state_13_), .B0(current_state_14_), 
        .Y(n788) );
  INVX1 U990 ( .A(n662), .Y(n540) );
  OAI31X1 U991 ( .A0(n788), .A1(stopbit), .A2(n688), .B0(n664), .Y(n662) );
  OA22X1 U992 ( .A0(n688), .A1(n695), .B0(rxclk), .B1(n740), .Y(n664) );
  INVX1 U993 ( .A(n673), .Y(n669) );
  NAND2BX1 U994 ( .AN(parity[0]), .B(n475), .Y(n673) );
  NAND3BX1 U995 ( .AN(bytereceivedb), .B(n736), .C(n372), .Y(n378) );
  NAND2BX1 U996 ( .AN(swrst), .B(rxclk), .Y(n462) );
  OR4X1 U997 ( .A(current_state_7_), .B(current_state_6_), .C(current_state_5_), .D(current_state_8_), .Y(n544) );
  NAND2BX1 U998 ( .AN(baudx16clk), .B(n691), .Y(n483) );
  AO22X1 U999 ( .A0(current_state_9_), .A1(n688), .B0(current_state_8_), .B1(
        rxclk), .Y(n543) );
  NAND2BX1 U1000 ( .AN(swrst), .B(n688), .Y(n667) );
  INVX1 U1001 ( .A(swrst), .Y(n372) );
  OAI32X1 U1002 ( .A0(n466), .A1(parityerr_clear), .A2(n462), .B0(n467), .B1(
        n210), .Y(n224) );
  INVX1 U1003 ( .A(n467), .Y(n466) );
  AO21X1 U1004 ( .A0(n468), .A1(n469), .B0(parityerr_clear), .Y(n467) );
  AOI31X1 U1005 ( .A0(n470), .A1(n784), .A2(n471), .B0(n472), .Y(n469) );
  AO22X1 U1006 ( .A0(current_state_11_), .A1(n688), .B0(current_state_10_), 
        .B1(rxclk), .Y(n555) );
  OAI31X1 U1007 ( .A0(n743), .A1(parity[0]), .A2(n475), .B0(n476), .Y(n473) );
  OA22X1 U1008 ( .A0(parity_int), .A1(parity[1]), .B0(parity_int), .B1(n477), 
        .Y(n476) );
  INVX1 U1009 ( .A(parity[0]), .Y(n477) );
  OAI32X1 U1010 ( .A0(n461), .A1(frameerr_clear), .A2(n462), .B0(n463), .B1(
        n208), .Y(n225) );
  INVX1 U1011 ( .A(n461), .Y(n463) );
  OAI33X1 U1012 ( .A0(n462), .A1(frameerr_clear), .A2(n784), .B0(n465), .B1(
        swrst), .B2(frameerr_clear), .Y(n461) );
  NOR2BX1 U1013 ( .AN(rxclk), .B(framechkb), .Y(n465) );
  OAI32X1 U1014 ( .A0(n488), .A1(rxclkcnt[2]), .A2(n489), .B0(n490), .B1(n700), 
        .Y(n221) );
  INVX1 U1015 ( .A(n481), .Y(n490) );
  OAI32X1 U1016 ( .A0(n378), .A1(fifo_wrpos[1]), .A2(n696), .B0(n380), .B1(
        n792), .Y(n310) );
  INVX1 U1017 ( .A(n373), .Y(n380) );
  AOI32X1 U1018 ( .A0(rx_lpfd), .A1(n473), .A2(n471), .B0(paritychkb), .B1(
        n372), .Y(n468) );
  INVX1 U1019 ( .A(n670), .Y(n533) );
  OAI32X1 U1020 ( .A0(n688), .A1(n669), .A2(n692), .B0(rxclk), .B1(n739), .Y(
        n670) );
  XOR3X1 U1021 ( .A(n790), .B(in_dly[3]), .C(n690), .Y(n789) );
  OAI32X1 U1022 ( .A0(n368), .A1(swrst), .A2(overrunerr_clear), .B0(n369), 
        .B1(n209), .Y(n312) );
  INVX1 U1023 ( .A(n369), .Y(n368) );
  OAI211X1 U1024 ( .A0(bytereceivedb), .A1(n736), .B0(n371), .C0(n372), .Y(
        n369) );
  INVX1 U1025 ( .A(overrunerr_clear), .Y(n371) );
  NAND2BX1 U1026 ( .AN(N70), .B(N69), .Y(n387) );
  NAND2BX1 U1027 ( .AN(N69), .B(N70), .Y(n386) );
  NAND2BX1 U1028 ( .AN(rxsftenb), .B(rxclk), .Y(n459) );
  OAI33X1 U1029 ( .A0(n478), .A1(n698), .A2(n743), .B0(n480), .B1(parity_int), 
        .B2(n698), .Y(n2230) );
  INVX1 U1030 ( .A(n480), .Y(n478) );
  NAND3BX1 U1031 ( .AN(dataphaseb), .B(rx_lpfd), .C(rxclk), .Y(n480) );
  NAND3BX1 U1032 ( .AN(rxclkenb), .B(rxclkcnt[1]), .C(rxclkcnt[0]), .Y(n488)
         );
  AO22X1 U1033 ( .A0(rxsftreg[0]), .A1(databit), .B0(rxsftreg[1]), .B1(n438), 
        .Y(n419) );
  AO22X1 U1034 ( .A0(rxsftreg[1]), .A1(databit), .B0(rxsftreg[2]), .B1(n438), 
        .Y(n418) );
  AO22X1 U1035 ( .A0(rxsftreg[2]), .A1(databit), .B0(rxsftreg[3]), .B1(n438), 
        .Y(n417) );
  AO22X1 U1036 ( .A0(rxsftreg[3]), .A1(databit), .B0(rxsftreg[4]), .B1(n438), 
        .Y(n416) );
  AO22X1 U1037 ( .A0(rxsftreg[4]), .A1(databit), .B0(rxsftreg[5]), .B1(n438), 
        .Y(n415) );
  AO22X1 U1038 ( .A0(rxsftreg[5]), .A1(databit), .B0(rxsftreg[6]), .B1(n438), 
        .Y(n414) );
  AO22X1 U1039 ( .A0(rxsftreg[6]), .A1(databit), .B0(rxsftreg[7]), .B1(n438), 
        .Y(n413) );
  NOR2BX1 U1040 ( .AN(n547), .B(swrst), .Y(N304) );
  NOR2BX1 U1041 ( .AN(n555), .B(swrst), .Y(N302) );
  NOR2BX1 U1042 ( .AN(n543), .B(swrst), .Y(N300) );
  NOR2BX1 U1043 ( .AN(n561), .B(swrst), .Y(N292) );
  INVX1 U1044 ( .A(databit), .Y(n438) );
  NOR2BX1 U1045 ( .AN(current_state_16_), .B(n462), .Y(N308) );
  AO21X1 U1046 ( .A0(n685), .A1(n682), .B0(swrst), .Y(N291) );
  OAI222X1 U1047 ( .A0(n790), .A1(n690), .B0(n701), .B1(n690), .C0(n790), .C1(
        n701), .Y(n445) );
  NOR2X1 U1048 ( .A(bytereceivedb), .B(n792), .Y(n791) );
  AND2X2 U1049 ( .A(n794), .B(n792), .Y(n793) );
  AO22X1 U1050 ( .A0(in_dly[0]), .A1(baudx16clk), .B0(in_dly[1]), .B1(n440), 
        .Y(n236) );
  AO22X1 U1051 ( .A0(in_dly[1]), .A1(baudx16clk), .B0(in_dly[2]), .B1(n440), 
        .Y(n237) );
  AO22X1 U1052 ( .A0(in_dly[2]), .A1(baudx16clk), .B0(in_dly[3]), .B1(n440), 
        .Y(n238) );
  AO22X1 U1053 ( .A0(in_dly[3]), .A1(baudx16clk), .B0(in_dly[4]), .B1(n440), 
        .Y(n239) );
  AO22X1 U1054 ( .A0(in_dly[4]), .A1(baudx16clk), .B0(in_dly[5]), .B1(n440), 
        .Y(n240) );
  NOR2X1 U1055 ( .A(n438), .B(n796), .Y(n795) );
  OAI2BB1X1 U1056 ( .A0N(rxclkcnt[3]), .A1N(n481), .B0(n482), .Y(n222) );
  AOI33X1 U1057 ( .A0(n483), .A1(n484), .A2(n485), .B0(n700), .B1(n691), .B2(
        rxclkcnt[3]), .Y(n482) );
  NOR2BX1 U1058 ( .AN(rxclkcnt[2]), .B(rxclkcnt[3]), .Y(n484) );
  AO22X1 U1059 ( .A0(rxsftreg[7]), .A1(n459), .B0(n460), .B1(rx_lpfd), .Y(n233) );
  AO22X1 U1060 ( .A0(current_state_7_), .A1(n471), .B0(n472), .B1(
        current_state_8_), .Y(N299) );
  AO22X1 U1061 ( .A0(\rxfifo[7][7] ), .A1(n410), .B0(n795), .B1(n412), .Y(
        n3040) );
  AO22X1 U1062 ( .A0(\rxfifo[0][7] ), .A1(n435), .B0(n436), .B1(n795), .Y(n248) );
  AO22X1 U1063 ( .A0(\rxfifo[1][7] ), .A1(n433), .B0(n434), .B1(n795), .Y(n256) );
  AO22X1 U1064 ( .A0(\rxfifo[2][7] ), .A1(n430), .B0(n431), .B1(n795), .Y(n264) );
  AO22X1 U1065 ( .A0(\rxfifo[3][7] ), .A1(n428), .B0(n429), .B1(n795), .Y(n272) );
  AO22X1 U1066 ( .A0(\rxfifo[4][7] ), .A1(n426), .B0(n427), .B1(n795), .Y(n280) );
  AO22X1 U1067 ( .A0(\rxfifo[5][7] ), .A1(n423), .B0(n424), .B1(n795), .Y(n288) );
  AO22X1 U1068 ( .A0(\rxfifo[6][7] ), .A1(n421), .B0(n422), .B1(n795), .Y(
        n2960) );
  AO22X1 U1069 ( .A0(current_state_6_), .A1(n471), .B0(current_state_7_), .B1(
        n472), .Y(N298) );
  AO22X1 U1070 ( .A0(current_state_5_), .A1(n471), .B0(current_state_6_), .B1(
        n472), .Y(N297) );
  AO22X1 U1071 ( .A0(rxsftreg[0]), .A1(n459), .B0(n460), .B1(rxsftreg[1]), .Y(
        n226) );
  AO22X1 U1072 ( .A0(rxsftreg[1]), .A1(n459), .B0(n460), .B1(rxsftreg[2]), .Y(
        n227) );
  AO22X1 U1073 ( .A0(rxsftreg[2]), .A1(n459), .B0(n460), .B1(rxsftreg[3]), .Y(
        n228) );
  AO22X1 U1074 ( .A0(rxsftreg[3]), .A1(n459), .B0(n460), .B1(rxsftreg[4]), .Y(
        n229) );
  AO22X1 U1075 ( .A0(rxsftreg[4]), .A1(n459), .B0(n460), .B1(rxsftreg[5]), .Y(
        n230) );
  AO22X1 U1076 ( .A0(rxsftreg[5]), .A1(n459), .B0(n460), .B1(rxsftreg[6]), .Y(
        n231) );
  AO22X1 U1077 ( .A0(rxsftreg[6]), .A1(n459), .B0(n460), .B1(rxsftreg[7]), .Y(
        n232) );
  OAI2BB1X1 U1078 ( .A0N(n799), .A1N(n373), .B0(n374), .Y(n311) );
  AOI33X1 U1079 ( .A0(n375), .A1(n798), .A2(n376), .B0(n799), .B1(n792), .B2(
        n376), .Y(n374) );
  NOR2BX1 U1080 ( .AN(fifo_wrpos[1]), .B(n799), .Y(n375) );
  AO22X1 U1081 ( .A0(\rxfifo[0][0] ), .A1(n435), .B0(n436), .B1(n419), .Y(n241) );
  AO22X1 U1082 ( .A0(\rxfifo[0][1] ), .A1(n435), .B0(n436), .B1(n418), .Y(n242) );
  AO22X1 U1083 ( .A0(\rxfifo[0][2] ), .A1(n435), .B0(n436), .B1(n417), .Y(n243) );
  AO22X1 U1084 ( .A0(\rxfifo[0][3] ), .A1(n435), .B0(n436), .B1(n416), .Y(n244) );
  AO22X1 U1085 ( .A0(\rxfifo[0][4] ), .A1(n435), .B0(n436), .B1(n415), .Y(n245) );
  AO22X1 U1086 ( .A0(\rxfifo[0][5] ), .A1(n435), .B0(n436), .B1(n414), .Y(n246) );
  AO22X1 U1087 ( .A0(\rxfifo[0][6] ), .A1(n435), .B0(n436), .B1(n413), .Y(n247) );
  AO22X1 U1088 ( .A0(\rxfifo[1][0] ), .A1(n433), .B0(n434), .B1(n419), .Y(n249) );
  AO22X1 U1089 ( .A0(\rxfifo[1][1] ), .A1(n433), .B0(n434), .B1(n418), .Y(n250) );
  AO22X1 U1090 ( .A0(\rxfifo[1][2] ), .A1(n433), .B0(n434), .B1(n417), .Y(n251) );
  AO22X1 U1091 ( .A0(\rxfifo[1][3] ), .A1(n433), .B0(n434), .B1(n416), .Y(n252) );
  AO22X1 U1092 ( .A0(\rxfifo[1][4] ), .A1(n433), .B0(n434), .B1(n415), .Y(n253) );
  AO22X1 U1093 ( .A0(\rxfifo[1][5] ), .A1(n433), .B0(n434), .B1(n414), .Y(n254) );
  AO22X1 U1094 ( .A0(\rxfifo[1][6] ), .A1(n433), .B0(n434), .B1(n413), .Y(n255) );
  AO22X1 U1095 ( .A0(\rxfifo[2][0] ), .A1(n430), .B0(n431), .B1(n419), .Y(n257) );
  AO22X1 U1096 ( .A0(\rxfifo[2][1] ), .A1(n430), .B0(n431), .B1(n418), .Y(n258) );
  AO22X1 U1097 ( .A0(\rxfifo[2][2] ), .A1(n430), .B0(n431), .B1(n417), .Y(n259) );
  AO22X1 U1098 ( .A0(\rxfifo[2][3] ), .A1(n430), .B0(n431), .B1(n416), .Y(n260) );
  AO22X1 U1099 ( .A0(\rxfifo[2][4] ), .A1(n430), .B0(n431), .B1(n415), .Y(n261) );
  AO22X1 U1100 ( .A0(\rxfifo[2][5] ), .A1(n430), .B0(n431), .B1(n414), .Y(n262) );
  AO22X1 U1101 ( .A0(\rxfifo[2][6] ), .A1(n430), .B0(n431), .B1(n413), .Y(n263) );
  AO22X1 U1102 ( .A0(\rxfifo[3][0] ), .A1(n428), .B0(n429), .B1(n419), .Y(n265) );
  AO22X1 U1103 ( .A0(\rxfifo[3][1] ), .A1(n428), .B0(n429), .B1(n418), .Y(n266) );
  AO22X1 U1104 ( .A0(\rxfifo[3][2] ), .A1(n428), .B0(n429), .B1(n417), .Y(n267) );
  AO22X1 U1105 ( .A0(\rxfifo[3][3] ), .A1(n428), .B0(n429), .B1(n416), .Y(n268) );
  AO22X1 U1106 ( .A0(\rxfifo[3][4] ), .A1(n428), .B0(n429), .B1(n415), .Y(n269) );
  AO22X1 U1107 ( .A0(\rxfifo[3][5] ), .A1(n428), .B0(n429), .B1(n414), .Y(n270) );
  AO22X1 U1108 ( .A0(\rxfifo[3][6] ), .A1(n428), .B0(n429), .B1(n413), .Y(n271) );
  AO22X1 U1109 ( .A0(\rxfifo[4][0] ), .A1(n426), .B0(n427), .B1(n419), .Y(n273) );
  AO22X1 U1110 ( .A0(\rxfifo[4][1] ), .A1(n426), .B0(n427), .B1(n418), .Y(n274) );
  AO22X1 U1111 ( .A0(\rxfifo[4][2] ), .A1(n426), .B0(n427), .B1(n417), .Y(n275) );
  AO22X1 U1112 ( .A0(\rxfifo[4][3] ), .A1(n426), .B0(n427), .B1(n416), .Y(n276) );
  AO22X1 U1113 ( .A0(\rxfifo[4][4] ), .A1(n426), .B0(n427), .B1(n415), .Y(n277) );
  AO22X1 U1114 ( .A0(\rxfifo[4][5] ), .A1(n426), .B0(n427), .B1(n414), .Y(n278) );
  AO22X1 U1115 ( .A0(\rxfifo[4][6] ), .A1(n426), .B0(n427), .B1(n413), .Y(n279) );
  AO22X1 U1116 ( .A0(\rxfifo[5][0] ), .A1(n423), .B0(n424), .B1(n419), .Y(n281) );
  AO22X1 U1117 ( .A0(\rxfifo[5][1] ), .A1(n423), .B0(n424), .B1(n418), .Y(n282) );
  AO22X1 U1118 ( .A0(\rxfifo[5][2] ), .A1(n423), .B0(n424), .B1(n417), .Y(n283) );
  AO22X1 U1119 ( .A0(\rxfifo[5][3] ), .A1(n423), .B0(n424), .B1(n416), .Y(n284) );
  AO22X1 U1120 ( .A0(\rxfifo[5][4] ), .A1(n423), .B0(n424), .B1(n415), .Y(n285) );
  AO22X1 U1121 ( .A0(\rxfifo[5][5] ), .A1(n423), .B0(n424), .B1(n414), .Y(n286) );
  AO22X1 U1122 ( .A0(\rxfifo[5][6] ), .A1(n423), .B0(n424), .B1(n413), .Y(n287) );
  AO22X1 U1123 ( .A0(\rxfifo[6][0] ), .A1(n421), .B0(n422), .B1(n419), .Y(n289) );
  AO22X1 U1124 ( .A0(\rxfifo[6][1] ), .A1(n421), .B0(n422), .B1(n418), .Y(n290) );
  AO22X1 U1125 ( .A0(\rxfifo[6][2] ), .A1(n421), .B0(n422), .B1(n417), .Y(
        n2910) );
  AO22X1 U1126 ( .A0(\rxfifo[6][3] ), .A1(n421), .B0(n422), .B1(n416), .Y(
        n2920) );
  AO22X1 U1127 ( .A0(\rxfifo[6][4] ), .A1(n421), .B0(n422), .B1(n415), .Y(
        n2930) );
  AO22X1 U1128 ( .A0(\rxfifo[6][5] ), .A1(n421), .B0(n422), .B1(n414), .Y(
        n2940) );
  AO22X1 U1129 ( .A0(\rxfifo[6][6] ), .A1(n421), .B0(n422), .B1(n413), .Y(
        n2950) );
  AO22X1 U1130 ( .A0(\rxfifo[7][0] ), .A1(n410), .B0(n412), .B1(n419), .Y(
        n2970) );
  AO22X1 U1131 ( .A0(\rxfifo[7][1] ), .A1(n410), .B0(n412), .B1(n418), .Y(
        n2980) );
  AO22X1 U1132 ( .A0(\rxfifo[7][2] ), .A1(n410), .B0(n412), .B1(n417), .Y(
        n2990) );
  AO22X1 U1133 ( .A0(\rxfifo[7][3] ), .A1(n410), .B0(n412), .B1(n416), .Y(
        n3000) );
  AO22X1 U1134 ( .A0(\rxfifo[7][4] ), .A1(n410), .B0(n412), .B1(n415), .Y(
        n3010) );
  AO22X1 U1135 ( .A0(\rxfifo[7][5] ), .A1(n410), .B0(n412), .B1(n414), .Y(
        n3020) );
  AO22X1 U1136 ( .A0(\rxfifo[7][6] ), .A1(n410), .B0(n412), .B1(n413), .Y(
        n3030) );
  AND4X1 U1137 ( .A(n700), .B(n748), .C(baudx16clk), .D(n485), .Y(N223) );
  OAI32X1 U1138 ( .A0(n376), .A1(swrst), .A2(n696), .B0(n798), .B1(n378), .Y(
        n309) );
  OAI32X1 U1139 ( .A0(n489), .A1(rxclkenb), .A2(rxclkcnt[0]), .B0(n699), .B1(
        n483), .Y(n219) );
  OAI32X1 U1140 ( .A0(n489), .A1(n493), .A2(n699), .B0(n495), .B1(n742), .Y(
        n220) );
  NAND2BX1 U1141 ( .AN(rxclkenb), .B(n742), .Y(n493) );
  INVX1 U1142 ( .A(n492), .Y(n495) );
  OAI32X1 U1143 ( .A0(n462), .A1(n788), .A2(n666), .B0(n695), .B1(n667), .Y(
        N306) );
  INVX1 U1144 ( .A(stopbit), .Y(n666) );
  NAND2BX1 U1145 ( .AN(N70), .B(n735), .Y(n567) );
  NAND2BX1 U1146 ( .AN(n738), .B(N69), .Y(n569) );
  AO22X1 U1147 ( .A0(n797), .A1(n602), .B0(n603), .B1(n693), .Y(fifodata_rx[4]) );
  OAI221X1 U1148 ( .A0(n750), .A1(n567), .B0(n703), .B1(n569), .C0(n606), .Y(
        n603) );
  OAI221X1 U1149 ( .A0(n749), .A1(n567), .B0(n702), .B1(n569), .C0(n611), .Y(
        n602) );
  AO22X1 U1150 ( .A0(n797), .A1(n590), .B0(n591), .B1(n693), .Y(fifodata_rx[5]) );
  OAI221X1 U1151 ( .A0(n752), .A1(n567), .B0(n705), .B1(n569), .C0(n594), .Y(
        n591) );
  OAI221X1 U1152 ( .A0(n751), .A1(n567), .B0(n704), .B1(n569), .C0(n599), .Y(
        n590) );
  AO22X1 U1153 ( .A0(n797), .A1(n578), .B0(n579), .B1(n693), .Y(fifodata_rx[6]) );
  OAI221X1 U1154 ( .A0(n754), .A1(n567), .B0(n707), .B1(n569), .C0(n582), .Y(
        n579) );
  OAI221X1 U1155 ( .A0(n753), .A1(n567), .B0(n706), .B1(n569), .C0(n587), .Y(
        n578) );
  OA22X1 U1156 ( .A0(n387), .A1(n718), .B0(n386), .B1(n765), .Y(n659) );
  OA22X1 U1157 ( .A0(n387), .A1(n719), .B0(n386), .B1(n766), .Y(n654) );
  OA22X1 U1158 ( .A0(n387), .A1(n720), .B0(n386), .B1(n767), .Y(n647) );
  OA22X1 U1159 ( .A0(n387), .A1(n721), .B0(n386), .B1(n768), .Y(n642) );
  OA22X1 U1160 ( .A0(n387), .A1(n722), .B0(n386), .B1(n769), .Y(n635) );
  OA22X1 U1161 ( .A0(n387), .A1(n723), .B0(n386), .B1(n770), .Y(n630) );
  OA22X1 U1162 ( .A0(n387), .A1(n724), .B0(n386), .B1(n771), .Y(n623) );
  OA22X1 U1163 ( .A0(n387), .A1(n725), .B0(n386), .B1(n772), .Y(n618) );
  OA22X1 U1164 ( .A0(n387), .A1(n726), .B0(n386), .B1(n773), .Y(n611) );
  OA22X1 U1165 ( .A0(n387), .A1(n727), .B0(n386), .B1(n774), .Y(n606) );
  OA22X1 U1166 ( .A0(n387), .A1(n728), .B0(n386), .B1(n775), .Y(n599) );
  OA22X1 U1167 ( .A0(n387), .A1(n729), .B0(n386), .B1(n776), .Y(n594) );
  OA22X1 U1168 ( .A0(n387), .A1(n730), .B0(n386), .B1(n777), .Y(n587) );
  OA22X1 U1169 ( .A0(n387), .A1(n731), .B0(n386), .B1(n778), .Y(n582) );
  OA22X1 U1170 ( .A0(n387), .A1(n732), .B0(n386), .B1(n779), .Y(n575) );
  OA22X1 U1171 ( .A0(n387), .A1(n733), .B0(n386), .B1(n780), .Y(n570) );
  AO22X1 U1172 ( .A0(n797), .A1(n650), .B0(n651), .B1(n693), .Y(fifodata_rx[0]) );
  OAI221X1 U1173 ( .A0(n756), .A1(n567), .B0(n709), .B1(n569), .C0(n654), .Y(
        n651) );
  OAI221X1 U1174 ( .A0(n755), .A1(n567), .B0(n708), .B1(n569), .C0(n659), .Y(
        n650) );
  AO22X1 U1175 ( .A0(n797), .A1(n638), .B0(n639), .B1(n693), .Y(fifodata_rx[1]) );
  OAI221X1 U1176 ( .A0(n758), .A1(n567), .B0(n711), .B1(n569), .C0(n642), .Y(
        n639) );
  OAI221X1 U1177 ( .A0(n757), .A1(n567), .B0(n710), .B1(n569), .C0(n647), .Y(
        n638) );
  AO22X1 U1178 ( .A0(n797), .A1(n626), .B0(n627), .B1(n693), .Y(fifodata_rx[2]) );
  OAI221X1 U1179 ( .A0(n760), .A1(n567), .B0(n713), .B1(n569), .C0(n630), .Y(
        n627) );
  OAI221X1 U1180 ( .A0(n759), .A1(n567), .B0(n712), .B1(n569), .C0(n635), .Y(
        n626) );
  AO22X1 U1181 ( .A0(n797), .A1(n614), .B0(n615), .B1(n693), .Y(fifodata_rx[3]) );
  OAI221X1 U1182 ( .A0(n762), .A1(n567), .B0(n715), .B1(n569), .C0(n618), .Y(
        n615) );
  OAI221X1 U1183 ( .A0(n761), .A1(n567), .B0(n714), .B1(n569), .C0(n623), .Y(
        n614) );
  AO22X1 U1184 ( .A0(n797), .A1(n564), .B0(n565), .B1(n693), .Y(fifodata_rx[7]) );
  OAI221X1 U1185 ( .A0(n764), .A1(n567), .B0(n717), .B1(n569), .C0(n570), .Y(
        n565) );
  OAI221X1 U1186 ( .A0(n763), .A1(n567), .B0(n716), .B1(n569), .C0(n575), .Y(
        n564) );
  DFFRX1 fifo_rdpos_reg_1_ ( .D(n3070), .CK(clk), .RN(rstb), .Q(N69), .QN(n735) );
  DFFSX1 rx_lpfd_reg ( .D(n234), .CK(clk), .SN(rstb), .Q(rx_lpfd), .QN(n784)
         );
  DFFRX1 fifo_wrpos_reg_1_ ( .D(n310), .CK(clk), .RN(rstb), .Q(fifo_wrpos[1]), 
        .QN(n792) );
  DFFRX1 current_state_reg_1_ ( .D(N292), .CK(clk), .RN(rstb), .Q(
        current_state_1_), .QN(n734) );
  DFFRX1 fifo_wrpos_reg_0_ ( .D(n309), .CK(clk), .RN(rstb), .Q(fifo_wrpos[0]), 
        .QN(n696) );
  DFFRX1 fifo_wrpos_reg_2_ ( .D(n311), .CK(clk), .RN(rstb), .Q(fifo_wrpos[2]), 
        .QN(n694) );
  DFFRX1 fifo_rdpos_reg_0_ ( .D(n3060), .CK(clk), .RN(rstb), .Q(N68), .QN(n693) );
  DFFRX1 current_state_reg_17_ ( .D(N308), .CK(clk), .RN(rstb), .QN(n17) );
  DFFRX1 current_state_reg_2_ ( .D(N293), .CK(clk), .RN(rstb), .Q(
        current_state_2_) );
  DFFRX1 current_state_reg_4_ ( .D(N295), .CK(clk), .RN(rstb), .Q(
        current_state_4_) );
  DFFRX1 current_state_reg_3_ ( .D(N294), .CK(clk), .RN(rstb), .Q(
        current_state_3_) );
  DFFSX1 current_state_reg_0_ ( .D(N291), .CK(clk), .SN(rstb), .QN(n782) );
  DFFRX1 fifofull_reg ( .D(n3050), .CK(clk), .RN(rstb), .Q(rxfifocnt[3]), .QN(
        n736) );
  DFFSX1 in_dly_reg_3_ ( .D(n238), .CK(clk), .SN(rstb), .Q(in_dly[3]), .QN(
        n701) );
  DFFRX1 fifo_rdpos_reg_2_ ( .D(n3080), .CK(clk), .RN(rstb), .Q(N70), .QN(n738) );
  DFFSX1 in_dly_reg_4_ ( .D(n239), .CK(clk), .SN(rstb), .Q(in_dly[4]), .QN(
        n790) );
  DFFRX1 parity_int_reg ( .D(n2230), .CK(clk), .RN(rstb), .Q(parity_int), .QN(
        n743) );
  DFFRX1 current_state_reg_5_ ( .D(N296), .CK(clk), .RN(rstb), .Q(
        current_state_5_) );
  DFFRX1 current_state_reg_6_ ( .D(N297), .CK(clk), .RN(rstb), .Q(
        current_state_6_) );
  DFFRX1 current_state_reg_8_ ( .D(N299), .CK(clk), .RN(rstb), .Q(
        current_state_8_) );
  DFFRX1 current_state_reg_11_ ( .D(N302), .CK(clk), .RN(rstb), .Q(
        current_state_11_), .QN(n737) );
  DFFRX1 current_state_reg_13_ ( .D(N304), .CK(clk), .RN(rstb), .Q(
        current_state_13_), .QN(n692) );
  DFFRX1 current_state_reg_16_ ( .D(N307), .CK(clk), .RN(rstb), .Q(
        current_state_16_), .QN(n740) );
  DFFRX1 current_state_reg_15_ ( .D(N306), .CK(clk), .RN(rstb), .Q(n18), .QN(
        n695) );
  DFFRX1 current_state_reg_14_ ( .D(N305), .CK(clk), .RN(rstb), .Q(
        current_state_14_), .QN(n739) );
  DFFRX1 current_state_reg_12_ ( .D(N303), .CK(clk), .RN(rstb), .QN(n689) );
  DFFRX1 current_state_reg_7_ ( .D(N298), .CK(clk), .RN(rstb), .Q(
        current_state_7_) );
  DFFRX1 current_state_reg_9_ ( .D(N300), .CK(clk), .RN(rstb), .Q(
        current_state_9_) );
  DFFRX1 current_state_reg_10_ ( .D(N301), .CK(clk), .RN(rstb), .Q(
        current_state_10_) );
  DFFSX1 fifowrb_reg ( .D(n211), .CK(clk), .SN(rstb), .Q(bytereceivedb), .QN(
        n794) );
  DFFSX1 in_dly_reg_1_ ( .D(n236), .CK(clk), .SN(rstb), .Q(in_dly[1]), .QN(
        n741) );
  DFFSX1 in_dly_reg_0_ ( .D(n235), .CK(clk), .SN(rstb), .Q(in_dly[0]), .QN(
        n697) );
  DFFSX1 rxclkenb_reg ( .D(n215), .CK(clk), .SN(rstb), .Q(rxclkenb), .QN(n691)
         );
  DFFRX1 rxclkcnt_reg_3_ ( .D(n222), .CK(clk), .RN(rstb), .Q(rxclkcnt[3]), 
        .QN(n748) );
  DFFSX1 framechkb_reg ( .D(n212), .CK(clk), .SN(rstb), .Q(framechkb), .QN(
        n744) );
  DFFSX1 in_dly_reg_2_ ( .D(n237), .CK(clk), .SN(rstb), .Q(in_dly[2]), .QN(
        n690) );
  DFFRX1 rxclkcnt_reg_0_ ( .D(n219), .CK(clk), .RN(rstb), .Q(rxclkcnt[0]), 
        .QN(n699) );
  DFFRX1 rxclkcnt_reg_1_ ( .D(n220), .CK(clk), .RN(rstb), .Q(rxclkcnt[1]), 
        .QN(n742) );
  DFFSX1 dataphaseb_reg ( .D(n218), .CK(clk), .SN(rstb), .Q(dataphaseb), .QN(
        n745) );
  DFFSX1 rxsftenb_reg ( .D(n214), .CK(clk), .SN(rstb), .Q(rxsftenb), .QN(n746)
         );
  DFFSX1 paritychkb_reg ( .D(n213), .CK(clk), .SN(rstb), .Q(paritychkb), .QN(
        n747) );
  DFFRX1 rxclkcnt_reg_2_ ( .D(n221), .CK(clk), .RN(rstb), .Q(rxclkcnt[2]), 
        .QN(n700) );
  DFFRX1 rxfifo_reg ( .D(n241), .CK(clk), .RN(rstb), .Q(\rxfifo[0][0] ), .QN(
        n756) );
  DFFRX1 rxfifo_reg0 ( .D(n242), .CK(clk), .RN(rstb), .Q(\rxfifo[0][1] ), .QN(
        n758) );
  DFFRX1 rxfifo_reg1 ( .D(n243), .CK(clk), .RN(rstb), .Q(\rxfifo[0][2] ), .QN(
        n760) );
  DFFRX1 rxfifo_reg2 ( .D(n244), .CK(clk), .RN(rstb), .Q(\rxfifo[0][3] ), .QN(
        n762) );
  DFFRX1 rxfifo_reg3 ( .D(n245), .CK(clk), .RN(rstb), .Q(\rxfifo[0][4] ), .QN(
        n750) );
  DFFRX1 rxfifo_reg4 ( .D(n246), .CK(clk), .RN(rstb), .Q(\rxfifo[0][5] ), .QN(
        n752) );
  DFFRX1 rxfifo_reg5 ( .D(n247), .CK(clk), .RN(rstb), .Q(\rxfifo[0][6] ), .QN(
        n754) );
  DFFRX1 rxfifo_reg6 ( .D(n248), .CK(clk), .RN(rstb), .Q(\rxfifo[0][7] ), .QN(
        n764) );
  DFFRX1 rxfifo_reg7 ( .D(n249), .CK(clk), .RN(rstb), .Q(\rxfifo[1][0] ), .QN(
        n755) );
  DFFRX1 rxfifo_reg8 ( .D(n250), .CK(clk), .RN(rstb), .Q(\rxfifo[1][1] ), .QN(
        n757) );
  DFFRX1 rxfifo_reg9 ( .D(n251), .CK(clk), .RN(rstb), .Q(\rxfifo[1][2] ), .QN(
        n759) );
  DFFRX1 rxfifo_reg10 ( .D(n252), .CK(clk), .RN(rstb), .Q(\rxfifo[1][3] ), 
        .QN(n761) );
  DFFRX1 rxfifo_reg11 ( .D(n253), .CK(clk), .RN(rstb), .Q(\rxfifo[1][4] ), 
        .QN(n749) );
  DFFRX1 rxfifo_reg12 ( .D(n254), .CK(clk), .RN(rstb), .Q(\rxfifo[1][5] ), 
        .QN(n751) );
  DFFRX1 rxfifo_reg13 ( .D(n255), .CK(clk), .RN(rstb), .Q(\rxfifo[1][6] ), 
        .QN(n753) );
  DFFRX1 rxfifo_reg14 ( .D(n256), .CK(clk), .RN(rstb), .Q(\rxfifo[1][7] ), 
        .QN(n763) );
  DFFRX1 rxfifo_reg15 ( .D(n257), .CK(clk), .RN(rstb), .Q(\rxfifo[2][0] ), 
        .QN(n719) );
  DFFRX1 rxfifo_reg16 ( .D(n258), .CK(clk), .RN(rstb), .Q(\rxfifo[2][1] ), 
        .QN(n721) );
  DFFRX1 rxfifo_reg17 ( .D(n259), .CK(clk), .RN(rstb), .Q(\rxfifo[2][2] ), 
        .QN(n723) );
  DFFRX1 rxfifo_reg18 ( .D(n260), .CK(clk), .RN(rstb), .Q(\rxfifo[2][3] ), 
        .QN(n725) );
  DFFRX1 rxfifo_reg19 ( .D(n261), .CK(clk), .RN(rstb), .Q(\rxfifo[2][4] ), 
        .QN(n727) );
  DFFRX1 rxfifo_reg20 ( .D(n262), .CK(clk), .RN(rstb), .Q(\rxfifo[2][5] ), 
        .QN(n729) );
  DFFRX1 rxfifo_reg21 ( .D(n263), .CK(clk), .RN(rstb), .Q(\rxfifo[2][6] ), 
        .QN(n731) );
  DFFRX1 rxfifo_reg22 ( .D(n264), .CK(clk), .RN(rstb), .Q(\rxfifo[2][7] ), 
        .QN(n733) );
  DFFRX1 rxfifo_reg23 ( .D(n265), .CK(clk), .RN(rstb), .Q(\rxfifo[3][0] ), 
        .QN(n718) );
  DFFRX1 rxfifo_reg24 ( .D(n266), .CK(clk), .RN(rstb), .Q(\rxfifo[3][1] ), 
        .QN(n720) );
  DFFRX1 rxfifo_reg25 ( .D(n267), .CK(clk), .RN(rstb), .Q(\rxfifo[3][2] ), 
        .QN(n722) );
  DFFRX1 rxfifo_reg26 ( .D(n268), .CK(clk), .RN(rstb), .Q(\rxfifo[3][3] ), 
        .QN(n724) );
  DFFRX1 rxfifo_reg27 ( .D(n269), .CK(clk), .RN(rstb), .Q(\rxfifo[3][4] ), 
        .QN(n726) );
  DFFRX1 rxfifo_reg28 ( .D(n270), .CK(clk), .RN(rstb), .Q(\rxfifo[3][5] ), 
        .QN(n728) );
  DFFRX1 rxfifo_reg29 ( .D(n271), .CK(clk), .RN(rstb), .Q(\rxfifo[3][6] ), 
        .QN(n730) );
  DFFRX1 rxfifo_reg30 ( .D(n272), .CK(clk), .RN(rstb), .Q(\rxfifo[3][7] ), 
        .QN(n732) );
  DFFRX1 rxfifo_reg31 ( .D(n273), .CK(clk), .RN(rstb), .Q(\rxfifo[4][0] ), 
        .QN(n766) );
  DFFRX1 rxfifo_reg32 ( .D(n274), .CK(clk), .RN(rstb), .Q(\rxfifo[4][1] ), 
        .QN(n768) );
  DFFRX1 rxfifo_reg33 ( .D(n275), .CK(clk), .RN(rstb), .Q(\rxfifo[4][2] ), 
        .QN(n770) );
  DFFRX1 rxfifo_reg34 ( .D(n276), .CK(clk), .RN(rstb), .Q(\rxfifo[4][3] ), 
        .QN(n772) );
  DFFRX1 rxfifo_reg35 ( .D(n277), .CK(clk), .RN(rstb), .Q(\rxfifo[4][4] ), 
        .QN(n774) );
  DFFRX1 rxfifo_reg36 ( .D(n278), .CK(clk), .RN(rstb), .Q(\rxfifo[4][5] ), 
        .QN(n776) );
  DFFRX1 rxfifo_reg37 ( .D(n279), .CK(clk), .RN(rstb), .Q(\rxfifo[4][6] ), 
        .QN(n778) );
  DFFRX1 rxfifo_reg38 ( .D(n280), .CK(clk), .RN(rstb), .Q(\rxfifo[4][7] ), 
        .QN(n780) );
  DFFRX1 rxfifo_reg39 ( .D(n281), .CK(clk), .RN(rstb), .Q(\rxfifo[5][0] ), 
        .QN(n765) );
  DFFRX1 rxfifo_reg40 ( .D(n282), .CK(clk), .RN(rstb), .Q(\rxfifo[5][1] ), 
        .QN(n767) );
  DFFRX1 rxfifo_reg41 ( .D(n283), .CK(clk), .RN(rstb), .Q(\rxfifo[5][2] ), 
        .QN(n769) );
  DFFRX1 rxfifo_reg42 ( .D(n284), .CK(clk), .RN(rstb), .Q(\rxfifo[5][3] ), 
        .QN(n771) );
  DFFRX1 rxfifo_reg43 ( .D(n285), .CK(clk), .RN(rstb), .Q(\rxfifo[5][4] ), 
        .QN(n773) );
  DFFRX1 rxfifo_reg44 ( .D(n286), .CK(clk), .RN(rstb), .Q(\rxfifo[5][5] ), 
        .QN(n775) );
  DFFRX1 rxfifo_reg45 ( .D(n287), .CK(clk), .RN(rstb), .Q(\rxfifo[5][6] ), 
        .QN(n777) );
  DFFRX1 rxfifo_reg46 ( .D(n288), .CK(clk), .RN(rstb), .Q(\rxfifo[5][7] ), 
        .QN(n779) );
  DFFRX1 rxfifo_reg47 ( .D(n289), .CK(clk), .RN(rstb), .Q(\rxfifo[6][0] ), 
        .QN(n709) );
  DFFRX1 rxfifo_reg48 ( .D(n290), .CK(clk), .RN(rstb), .Q(\rxfifo[6][1] ), 
        .QN(n711) );
  DFFRX1 rxfifo_reg49 ( .D(n2910), .CK(clk), .RN(rstb), .Q(\rxfifo[6][2] ), 
        .QN(n713) );
  DFFRX1 rxfifo_reg50 ( .D(n2920), .CK(clk), .RN(rstb), .Q(\rxfifo[6][3] ), 
        .QN(n715) );
  DFFRX1 rxfifo_reg51 ( .D(n2930), .CK(clk), .RN(rstb), .Q(\rxfifo[6][4] ), 
        .QN(n703) );
  DFFRX1 rxfifo_reg52 ( .D(n2940), .CK(clk), .RN(rstb), .Q(\rxfifo[6][5] ), 
        .QN(n705) );
  DFFRX1 rxfifo_reg53 ( .D(n2950), .CK(clk), .RN(rstb), .Q(\rxfifo[6][6] ), 
        .QN(n707) );
  DFFRX1 rxfifo_reg54 ( .D(n2960), .CK(clk), .RN(rstb), .Q(\rxfifo[6][7] ), 
        .QN(n717) );
  DFFRX1 rxfifo_reg55 ( .D(n2970), .CK(clk), .RN(rstb), .Q(\rxfifo[7][0] ), 
        .QN(n708) );
  DFFRX1 rxfifo_reg56 ( .D(n2980), .CK(clk), .RN(rstb), .Q(\rxfifo[7][1] ), 
        .QN(n710) );
  DFFRX1 rxfifo_reg57 ( .D(n2990), .CK(clk), .RN(rstb), .Q(\rxfifo[7][2] ), 
        .QN(n712) );
  DFFRX1 rxfifo_reg58 ( .D(n3000), .CK(clk), .RN(rstb), .Q(\rxfifo[7][3] ), 
        .QN(n714) );
  DFFRX1 rxfifo_reg59 ( .D(n3010), .CK(clk), .RN(rstb), .Q(\rxfifo[7][4] ), 
        .QN(n702) );
  DFFRX1 rxfifo_reg60 ( .D(n3020), .CK(clk), .RN(rstb), .Q(\rxfifo[7][5] ), 
        .QN(n704) );
  DFFRX1 rxfifo_reg61 ( .D(n3030), .CK(clk), .RN(rstb), .Q(\rxfifo[7][6] ), 
        .QN(n706) );
  DFFRX1 rxfifo_reg62 ( .D(n3040), .CK(clk), .RN(rstb), .Q(\rxfifo[7][7] ), 
        .QN(n716) );
  DFFRX1 parityerror_int_reg ( .D(n224), .CK(clk), .RN(rstb), .Q(parityerror), 
        .QN(n210) );
  DFFRX1 frameerror_int_reg ( .D(n225), .CK(clk), .RN(rstb), .Q(frameerror), 
        .QN(n208) );
  DFFSX1 rstparityb_reg ( .D(n217), .CK(clk), .SN(rstb), .QN(n698) );
  DFFRX1 rxsftreg_reg_7_ ( .D(n233), .CK(clk), .RN(rstb), .Q(rxsftreg[7]), 
        .QN(n796) );
  DFFRX1 overrunerror_int_reg ( .D(n312), .CK(clk), .RN(rstb), .Q(overrunerror), .QN(n209) );
  DFFRX1 rxsftreg_reg_1_ ( .D(n227), .CK(clk), .RN(rstb), .Q(rxsftreg[1]) );
  DFFRX1 rxsftreg_reg_2_ ( .D(n228), .CK(clk), .RN(rstb), .Q(rxsftreg[2]) );
  DFFRX1 rxsftreg_reg_3_ ( .D(n229), .CK(clk), .RN(rstb), .Q(rxsftreg[3]) );
  DFFRX1 rxsftreg_reg_4_ ( .D(n230), .CK(clk), .RN(rstb), .Q(rxsftreg[4]) );
  DFFRX1 rxsftreg_reg_5_ ( .D(n231), .CK(clk), .RN(rstb), .Q(rxsftreg[5]) );
  DFFRX1 rxsftreg_reg_6_ ( .D(n232), .CK(clk), .RN(rstb), .Q(rxsftreg[6]) );
  DFFSX1 in_dly_reg_5_ ( .D(n240), .CK(clk), .SN(rstb), .Q(in_dly[5]) );
  DFFRX1 rxsftreg_reg_0_ ( .D(n226), .CK(clk), .RN(rstb), .Q(rxsftreg[0]) );
  DFFRX1 rxbusy_int_reg ( .D(n216), .CK(clk), .RN(rstb), .Q(rxbusy) );
endmodule


module RegBlk_1_3_1 ( PADDR, PENABLE, PSEL, PWDATA, PWRITE, bytereceivedb, clk, 
        fifodata_rx, frameerror, overrunerror, parityerror, rstb, rxbusy, 
        rxfifocnt, rxfifoempty, txbusy, txfifo_emptyb, txfifo_fillb, 
        txfifo_fullb, txfifocnt, PRDATA, baudx16clk, databit, fifodata_tx, 
        fifordb, fifowrb, int, loopbacken, parity, rxdmareq, stopbit, swrst, 
        txdmareq, uarten, frameerr_clear, parityerr_clear, overrunerr_clear );
  input [4:2] PADDR;
  input [31:0] PWDATA;
  input [7:0] fifodata_rx;
  input [3:0] rxfifocnt;
  input [3:0] txfifocnt;
  output [31:0] PRDATA;
  output [7:0] fifodata_tx;
  output [1:0] parity;
  input PENABLE, PSEL, PWRITE, bytereceivedb, clk, frameerror, overrunerror,
         parityerror, rstb, rxbusy, rxfifoempty, txbusy, txfifo_emptyb,
         txfifo_fillb, txfifo_fullb;
  output baudx16clk, databit, fifordb, fifowrb, int, loopbacken, rxdmareq,
         stopbit, swrst, txdmareq, uarten, frameerr_clear, parityerr_clear,
         overrunerr_clear;
  wire   n288, n289, n290, n291, n292, n293, n294, n295, reg_0x0000_30_,
         reg_0x0000_29_, reg_0x0000_27_, reg_0x0000_15_, reg_0x0000_7_,
         reg_0x0004_22_, reg_0x0004_7_, N50, N52, N53, N61, N62, N63,
         clkdivcnt_msb_dly, N91, N92, N93, N94, N95, N96, N97, N98, N99, N100,
         N101, N102, N103, N104, N105, N110, N113, N114, N115, N116, N117,
         N118, N119, N120, N121, N122, N123, N124, N125, N126, N127, N128,
         N129, N130, n10, n134, n135, n136, n137, n138, n139, n140, n141, n142,
         n143, n144, n145, n146, n147, n148, n149, n150, n151, n152, n153,
         n154, n155, n156, n157, n158, n159, n160, n161, n162, n163, n164,
         n165, n166, n167, n168, n169, n170, n171, n172, n173, n174, n175,
         n176, n177, n178, n179, n180, n181, n182, n183, n184, n185, n186,
         n187, n188, n189, n190, n191, n192, n193, n194, n195, n196, n197,
         n198, n199, n200, n201, n202, n203, n204, n205, n206, n207, n208,
         n209, n210, n211, n212, n213, n214, n215, n216, n217, n218, n219,
         n220, n221, n222, n223, n224, n225, n226, n227, n228, n229, n230,
         n231, n517, carry, carry0, carry1, carry2, carry3, carry4, carry5,
         carry6, carry7, carry8, carry9, carry10, carry11, carry12, carry_1_,
         n1101, n233, n310, n410, n510, n610, n710, n810, n910, n1011, n1111,
         n1211, n1311, n1411, carry_18_, carry_17_, carry_16_, carry_15_,
         carry_14_, carry_13_, carry_12_, carry_11_, carry_10_, carry_9_,
         carry_8_, carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_,
         n1100, n2, n3, n4, n5, n6, n7, n8, n9, n1010, n1110, n1210, n1310,
         n1410, n1510, n1610, n1710, n1810, n297, n298, n299, n301, n302, n303,
         n304, n307, n312, n313, n314, n315, n316, n317, n319, n320, n322,
         n323, n325, n327, n329, n330, n331, n332, n333, n334, n335, n336,
         n337, n340, n341, n342, n345, n346, n347, n350, n351, n352, n353,
         n354, n355, n356, n359, n360, n361, n364, n365, n366, n369, n370,
         n371, n372, n373, n375, n376, n379, n381, n386, n387, n388, n389,
         n391, n393, n395, n396, n398, n399, n401, n402, n404, n407, n412,
         n417, n419, n422, n424, n426, n428, n429, n430, n431, n432, n433,
         n434, n435, n436, n437, n438, n439, n442, n443, n444, n445, n446,
         n447, n448, n451, n452, n454, n455, n456, n457, n458, n459, n460,
         n461, n462, n463, n464, n465, n466, n467, n468, n469, n470, n471,
         n472, n473, n474, n475, n476, n477, n478, n479, n480, n481, n482,
         n483, n484, n485, n486, n487, n488, n489, n490, n491, n492, n493,
         n494, n495, n496, n497, n498, n499, n500, n501, n502, n503, n504,
         n505, n507, n508, n509, n511, n512, n513, n514, n515;
  wire   [5:0] txwaterlevel_int;
  wire   [5:0] rxwaterlevel_int;
  wire   [15:0] clkdiv;
  wire   [15:0] clkdivcnt;
  wire   [19:0] timeoutcnt;
  wire   [19:0] timeoutcnt_int;
  assign PRDATA[20] = 1'b0;
  assign PRDATA[21] = 1'b0;
  assign fifodata_tx[7] = n288;
  assign n288 = PWDATA[7];
  assign fifodata_tx[6] = n289;
  assign n289 = PWDATA[6];
  assign fifodata_tx[5] = n290;
  assign n290 = PWDATA[5];
  assign fifodata_tx[4] = n291;
  assign n291 = PWDATA[4];
  assign fifodata_tx[3] = n292;
  assign n292 = PWDATA[3];
  assign fifodata_tx[2] = n293;
  assign n293 = PWDATA[2];
  assign fifodata_tx[1] = n294;
  assign n294 = PWDATA[1];
  assign fifodata_tx[0] = n295;
  assign n295 = PWDATA[0];

  AHHCONX2 U1_1_1 ( .A(timeoutcnt_int[1]), .CI(timeoutcnt_int[0]), .S(N113), 
        .CON(n1810) );
  AHHCONX2 U1_1_2 ( .A(timeoutcnt_int[2]), .CI(carry_2_), .S(N114), .CON(n1710) );
  AHHCONX2 U1_1_3 ( .A(timeoutcnt_int[3]), .CI(carry_3_), .S(N115), .CON(n1610) );
  AHHCONX2 U1_1_4 ( .A(timeoutcnt_int[4]), .CI(carry_4_), .S(N116), .CON(n1510) );
  AHHCONX2 U1_1_5 ( .A(timeoutcnt_int[5]), .CI(carry_5_), .S(N117), .CON(n1410) );
  AHHCONX2 U1_1_6 ( .A(timeoutcnt_int[6]), .CI(carry_6_), .S(N118), .CON(n1310) );
  AHHCONX2 U1_1_7 ( .A(timeoutcnt_int[7]), .CI(carry_7_), .S(N119), .CON(n1210) );
  AHHCONX2 U1_1_8 ( .A(timeoutcnt_int[8]), .CI(carry_8_), .S(N120), .CON(n1110) );
  AHHCONX2 U1_1_9 ( .A(timeoutcnt_int[9]), .CI(carry_9_), .S(N121), .CON(n1010) );
  AHHCONX2 U1_1_10 ( .A(timeoutcnt_int[10]), .CI(carry_10_), .S(N122), .CON(n9) );
  AHHCONX2 U1_1_11 ( .A(timeoutcnt_int[11]), .CI(carry_11_), .S(N123), .CON(n8) );
  AHHCONX2 U1_1_12 ( .A(timeoutcnt_int[12]), .CI(carry_12_), .S(N124), .CON(n7) );
  AHHCONX2 U1_1_13 ( .A(timeoutcnt_int[13]), .CI(carry_13_), .S(N125), .CON(n6) );
  AHHCONX2 U1_1_14 ( .A(timeoutcnt_int[14]), .CI(carry_14_), .S(N126), .CON(n5) );
  AHHCONX2 U1_1_15 ( .A(timeoutcnt_int[15]), .CI(carry_15_), .S(N127), .CON(n4) );
  AHHCONX2 U1_1_16 ( .A(timeoutcnt_int[16]), .CI(carry_16_), .S(N128), .CON(n3) );
  AHHCONX2 U1_1_17 ( .A(timeoutcnt_int[17]), .CI(carry_17_), .S(N129), .CON(n2) );
  AHHCONX2 U1_1_18 ( .A(timeoutcnt_int[18]), .CI(carry_18_), .S(N130), .CON(
        n1100) );
  DFFRX1 swrst_int_reg ( .D(N50), .CK(clk), .RN(rstb), .Q(swrst), .QN(n476) );
  INVX1 U647 ( .A(n312), .Y(n313) );
  INVX1 U648 ( .A(n513), .Y(n303) );
  INVX1 U649 ( .A(n323), .Y(n315) );
  INVX1 U650 ( .A(n317), .Y(n320) );
  INVX1 U651 ( .A(txfifocnt[0]), .Y(n379) );
  INVX1 U652 ( .A(rxfifocnt[0]), .Y(n426) );
  NAND2BX1 U653 ( .AN(n369), .B(n370), .Y(fifowrb) );
  NAND2BX1 U654 ( .AN(n509), .B(n500), .Y(n312) );
  NAND2BX1 U655 ( .AN(n509), .B(n500), .Y(n512) );
  NAND2BX1 U656 ( .AN(n509), .B(n500), .Y(n511) );
  INVX1 U657 ( .A(n298), .Y(n299) );
  BUFX2 U658 ( .A(n302), .Y(n513) );
  NAND2BX1 U659 ( .AN(n304), .B(n500), .Y(n302) );
  INVX1 U660 ( .A(n508), .Y(n301) );
  DFFRX1 baudx16clk_int_reg ( .D(n175), .CK(clk), .RN(rstb), .Q(baudx16clk), 
        .QN(n456) );
  DFFRX1 databit_int_reg ( .D(n217), .CK(clk), .RN(rstb), .Q(databit) );
  DFFRX1 parity_int_reg_1_ ( .D(n219), .CK(clk), .RN(rstb), .Q(parity[1]) );
  NAND2BX1 U661 ( .AN(n322), .B(n456), .Y(n323) );
  NAND2BX1 U662 ( .AN(n322), .B(n323), .Y(n317) );
  OAI221X1 U663 ( .A0(rxfifocnt[2]), .A1(n480), .B0(rxfifocnt[1]), .B1(n465), 
        .C0(n437), .Y(n439) );
  NOR2BX1 U664 ( .AN(n412), .B(n468), .Y(N52) );
  AO22X1 U665 ( .A0(txfifocnt[1]), .A1(n469), .B0(txfifocnt[2]), .B1(n483), 
        .Y(n442) );
  INVX1 U666 ( .A(txfifocnt[2]), .Y(n422) );
  INVX1 U667 ( .A(rxfifocnt[2]), .Y(n399) );
  INVX1 U668 ( .A(txfifocnt[1]), .Y(n373) );
  INVX1 U669 ( .A(n437), .Y(n436) );
  INVX1 U670 ( .A(n304), .Y(n388) );
  INVX1 U671 ( .A(PRDATA[28]), .Y(n372) );
  OAI221X1 U672 ( .A0(n372), .A1(n426), .B0(n508), .B1(n505), .C0(n428), .Y(
        PRDATA[0]) );
  OAI221X1 U673 ( .A0(n372), .A1(n402), .B0(n465), .B1(n508), .C0(n404), .Y(
        PRDATA[1]) );
  OAI221X1 U674 ( .A0(n372), .A1(n399), .B0(n480), .B1(n508), .C0(n401), .Y(
        PRDATA[2]) );
  OAI221X1 U675 ( .A0(n372), .A1(n396), .B0(n491), .B1(n508), .C0(n398), .Y(
        PRDATA[3]) );
  OAI221X1 U676 ( .A0(n509), .A1(n477), .B0(n508), .B1(n467), .C0(n395), .Y(
        PRDATA[4]) );
  OAI221X1 U677 ( .A0(n509), .A1(n459), .B0(n508), .B1(n482), .C0(n393), .Y(
        PRDATA[5]) );
  OAI2BB1X1 U678 ( .A0N(rxdmareq), .A1N(PRDATA[28]), .B0(n389), .Y(PRDATA[6])
         );
  OAI221X1 U679 ( .A0(n372), .A1(n471), .B0(n508), .B1(n495), .C0(n386), .Y(
        PRDATA[7]) );
  OAI221X1 U680 ( .A0(n372), .A1(n379), .B0(n508), .B1(n493), .C0(n381), .Y(
        PRDATA[8]) );
  OAI221X1 U681 ( .A0(n372), .A1(n373), .B0(n469), .B1(n508), .C0(n376), .Y(
        PRDATA[9]) );
  OAI221X1 U682 ( .A0(n372), .A1(n422), .B0(n483), .B1(n508), .C0(n424), .Y(
        PRDATA[10]) );
  OAI221X1 U683 ( .A0(n372), .A1(n417), .B0(n481), .B1(n508), .C0(n419), .Y(
        PRDATA[11]) );
  OAI222X1 U684 ( .A0(n508), .A1(n458), .B0(n304), .B1(n488), .C0(n509), .C1(
        n460), .Y(PRDATA[12]) );
  OAI222X1 U685 ( .A0(n508), .A1(n466), .B0(n304), .B1(n489), .C0(n509), .C1(
        n457), .Y(PRDATA[13]) );
  OAI222X1 U686 ( .A0(n509), .A1(n461), .B0(n304), .B1(n490), .C0(n372), .C1(
        n297), .Y(PRDATA[14]) );
  OAI221X1 U687 ( .A0(n372), .A1(n492), .B0(n508), .B1(n468), .C0(n407), .Y(
        PRDATA[15]) );
  INVX1 U688 ( .A(rxfifocnt[1]), .Y(n402) );
  INVX1 U689 ( .A(n297), .Y(txdmareq) );
  INVX1 U690 ( .A(n509), .Y(n387) );
  NAND4BX1 U691 ( .AN(PWRITE), .B(PENABLE), .C(PSEL), .D(n371), .Y(fifordb) );
  INVX1 U692 ( .A(n433), .Y(n370) );
  NAND3BX1 U693 ( .AN(PADDR[4]), .B(PADDR[2]), .C(n500), .Y(n433) );
  AND3X2 U694 ( .A(PENABLE), .B(PSEL), .C(PWRITE), .Y(n500) );
  INVX1 U695 ( .A(n429), .Y(n371) );
  NAND3BX1 U696 ( .AN(PADDR[3]), .B(n430), .C(PADDR[4]), .Y(n429) );
  NAND3BX1 U697 ( .AN(PADDR[4]), .B(n430), .C(PADDR[3]), .Y(n304) );
  NAND3BX1 U698 ( .AN(PWDATA[28]), .B(n500), .C(n301), .Y(n298) );
  NAND3BX1 U699 ( .AN(PWDATA[28]), .B(n500), .C(n301), .Y(n515) );
  NAND3BX1 U700 ( .AN(PWDATA[28]), .B(n500), .C(n301), .Y(n514) );
  INVX1 U701 ( .A(PADDR[2]), .Y(n430) );
  NAND2BX1 U702 ( .AN(PADDR[3]), .B(n370), .Y(n432) );
  INVX1 U703 ( .A(PADDR[3]), .Y(n369) );
  BUFX2 U704 ( .A(n375), .Y(n508) );
  NAND3BX1 U705 ( .AN(PADDR[4]), .B(n369), .C(n430), .Y(n375) );
  NOR3BX1 U706 ( .AN(n500), .B(n508), .C(n448), .Y(N50) );
  INVX1 U707 ( .A(PWDATA[28]), .Y(n448) );
  BUFX2 U708 ( .A(n314), .Y(n509) );
  NAND3BX1 U709 ( .AN(PADDR[3]), .B(PADDR[2]), .C(PADDR[4]), .Y(n314) );
  NOR2BX1 U710 ( .AN(PWDATA[24]), .B(n432), .Y(N61) );
  NOR2BX1 U711 ( .AN(PWDATA[25]), .B(n432), .Y(N62) );
  NOR2BX1 U712 ( .AN(PWDATA[23]), .B(n432), .Y(N63) );
  AO22X1 U713 ( .A0(timeoutcnt[16]), .A1(n511), .B0(PWDATA[16]), .B1(n313), 
        .Y(n171) );
  AO22X1 U714 ( .A0(timeoutcnt[17]), .A1(n511), .B0(PWDATA[17]), .B1(n313), 
        .Y(n172) );
  AO22X1 U715 ( .A0(timeoutcnt[18]), .A1(n512), .B0(PWDATA[18]), .B1(n313), 
        .Y(n173) );
  AO22X1 U716 ( .A0(timeoutcnt[19]), .A1(n511), .B0(PWDATA[19]), .B1(n313), 
        .Y(n174) );
  AO22X1 U717 ( .A0(clkdiv[6]), .A1(n513), .B0(n289), .B1(n303), .Y(n199) );
  AO22X1 U718 ( .A0(clkdiv[14]), .A1(n513), .B0(PWDATA[14]), .B1(n303), .Y(
        n207) );
  AO22X1 U719 ( .A0(txwaterlevel_int[0]), .A1(n515), .B0(PWDATA[8]), .B1(n299), 
        .Y(n209) );
  AO22X1 U720 ( .A0(txwaterlevel_int[1]), .A1(n514), .B0(PWDATA[9]), .B1(n299), 
        .Y(n210) );
  AO22X1 U721 ( .A0(txwaterlevel_int[2]), .A1(n298), .B0(PWDATA[10]), .B1(n299), .Y(n211) );
  AO22X1 U722 ( .A0(txwaterlevel_int[3]), .A1(n515), .B0(PWDATA[11]), .B1(n299), .Y(n212) );
  AO22X1 U723 ( .A0(txwaterlevel_int[4]), .A1(n514), .B0(PWDATA[12]), .B1(n299), .Y(n213) );
  AO22X1 U724 ( .A0(txwaterlevel_int[5]), .A1(n298), .B0(PWDATA[13]), .B1(n299), .Y(n214) );
  AO22X1 U725 ( .A0(loopbacken), .A1(n515), .B0(PWDATA[22]), .B1(n299), .Y(
        n215) );
  AO22X1 U726 ( .A0(stopbit), .A1(n514), .B0(PWDATA[23]), .B1(n299), .Y(n216)
         );
  AO22X1 U727 ( .A0(databit), .A1(n298), .B0(PWDATA[24]), .B1(n299), .Y(n217)
         );
  AO22X1 U728 ( .A0(parity[0]), .A1(n515), .B0(PWDATA[25]), .B1(n299), .Y(n218) );
  AO22X1 U729 ( .A0(parity[1]), .A1(n514), .B0(PWDATA[26]), .B1(n299), .Y(n219) );
  AO22X1 U730 ( .A0(reg_0x0000_27_), .A1(n515), .B0(PWDATA[27]), .B1(n299), 
        .Y(n220) );
  AO22X1 U731 ( .A0(reg_0x0000_29_), .A1(n515), .B0(PWDATA[29]), .B1(n299), 
        .Y(n221) );
  AO22X1 U732 ( .A0(reg_0x0000_30_), .A1(n514), .B0(PWDATA[30]), .B1(n299), 
        .Y(n222) );
  AO22X1 U733 ( .A0(n517), .A1(n514), .B0(PWDATA[31]), .B1(n299), .Y(n223) );
  AO22X1 U734 ( .A0(reg_0x0000_7_), .A1(n515), .B0(n288), .B1(n299), .Y(n224)
         );
  AO22X1 U735 ( .A0(reg_0x0000_15_), .A1(n514), .B0(PWDATA[15]), .B1(n299), 
        .Y(n225) );
  AO22X1 U736 ( .A0(rxwaterlevel_int[0]), .A1(n515), .B0(n295), .B1(n299), .Y(
        n226) );
  AO22X1 U737 ( .A0(rxwaterlevel_int[1]), .A1(n515), .B0(n294), .B1(n299), .Y(
        n227) );
  AO22X1 U738 ( .A0(rxwaterlevel_int[2]), .A1(n514), .B0(n293), .B1(n299), .Y(
        n228) );
  AO22X1 U739 ( .A0(rxwaterlevel_int[3]), .A1(n514), .B0(n292), .B1(n299), .Y(
        n229) );
  AO22X1 U740 ( .A0(rxwaterlevel_int[4]), .A1(n515), .B0(n291), .B1(n299), .Y(
        n230) );
  AO22X1 U741 ( .A0(rxwaterlevel_int[5]), .A1(n514), .B0(n290), .B1(n299), .Y(
        n231) );
  AO22X1 U742 ( .A0(timeoutcnt[0]), .A1(n512), .B0(n313), .B1(n295), .Y(n155)
         );
  AO22X1 U743 ( .A0(timeoutcnt[1]), .A1(n511), .B0(n313), .B1(n294), .Y(n156)
         );
  AO22X1 U744 ( .A0(timeoutcnt[2]), .A1(n312), .B0(n313), .B1(n293), .Y(n157)
         );
  AO22X1 U745 ( .A0(timeoutcnt[3]), .A1(n512), .B0(n313), .B1(n292), .Y(n158)
         );
  AO22X1 U746 ( .A0(timeoutcnt[4]), .A1(n511), .B0(n313), .B1(n291), .Y(n159)
         );
  AO22X1 U747 ( .A0(timeoutcnt[5]), .A1(n312), .B0(n313), .B1(n290), .Y(n160)
         );
  AO22X1 U748 ( .A0(timeoutcnt[6]), .A1(n512), .B0(n313), .B1(n289), .Y(n161)
         );
  AO22X1 U749 ( .A0(timeoutcnt[7]), .A1(n511), .B0(n313), .B1(n288), .Y(n162)
         );
  AO22X1 U750 ( .A0(timeoutcnt[8]), .A1(n512), .B0(n313), .B1(PWDATA[8]), .Y(
        n163) );
  AO22X1 U751 ( .A0(timeoutcnt[9]), .A1(n512), .B0(n313), .B1(PWDATA[9]), .Y(
        n164) );
  AO22X1 U752 ( .A0(timeoutcnt[10]), .A1(n511), .B0(n313), .B1(PWDATA[10]), 
        .Y(n165) );
  AO22X1 U753 ( .A0(timeoutcnt[11]), .A1(n511), .B0(n313), .B1(PWDATA[11]), 
        .Y(n166) );
  AO22X1 U754 ( .A0(timeoutcnt[12]), .A1(n512), .B0(n313), .B1(PWDATA[12]), 
        .Y(n167) );
  AO22X1 U755 ( .A0(timeoutcnt[13]), .A1(n511), .B0(n313), .B1(PWDATA[13]), 
        .Y(n168) );
  AO22X1 U756 ( .A0(timeoutcnt[14]), .A1(n512), .B0(n313), .B1(PWDATA[14]), 
        .Y(n169) );
  AO22X1 U757 ( .A0(timeoutcnt[15]), .A1(n512), .B0(n313), .B1(PWDATA[15]), 
        .Y(n170) );
  AO22X1 U758 ( .A0(clkdiv[0]), .A1(n513), .B0(n303), .B1(n295), .Y(n193) );
  AO22X1 U759 ( .A0(clkdiv[1]), .A1(n513), .B0(n303), .B1(n294), .Y(n194) );
  AO22X1 U760 ( .A0(clkdiv[2]), .A1(n513), .B0(n303), .B1(n293), .Y(n195) );
  AO22X1 U761 ( .A0(clkdiv[3]), .A1(n513), .B0(n303), .B1(n292), .Y(n196) );
  AO22X1 U762 ( .A0(clkdiv[4]), .A1(n513), .B0(n303), .B1(n291), .Y(n197) );
  AO22X1 U763 ( .A0(clkdiv[5]), .A1(n513), .B0(n303), .B1(n290), .Y(n198) );
  AO22X1 U764 ( .A0(clkdiv[7]), .A1(n513), .B0(n303), .B1(n288), .Y(n200) );
  AO22X1 U765 ( .A0(clkdiv[8]), .A1(n513), .B0(n303), .B1(PWDATA[8]), .Y(n201)
         );
  AO22X1 U766 ( .A0(clkdiv[9]), .A1(n513), .B0(n303), .B1(PWDATA[9]), .Y(n202)
         );
  AO22X1 U767 ( .A0(clkdiv[10]), .A1(n513), .B0(n303), .B1(PWDATA[10]), .Y(
        n203) );
  AO22X1 U768 ( .A0(clkdiv[11]), .A1(n513), .B0(n303), .B1(PWDATA[11]), .Y(
        n204) );
  AO22X1 U769 ( .A0(clkdiv[12]), .A1(n513), .B0(n303), .B1(PWDATA[12]), .Y(
        n205) );
  AO22X1 U770 ( .A0(clkdiv[13]), .A1(n513), .B0(n303), .B1(PWDATA[13]), .Y(
        n206) );
  AO22X1 U771 ( .A0(clkdiv[15]), .A1(n513), .B0(n303), .B1(PWDATA[15]), .Y(
        n208) );
  INVX1 U772 ( .A(n2), .Y(carry_18_) );
  INVX1 U773 ( .A(n1810), .Y(carry_2_) );
  INVX1 U774 ( .A(n1710), .Y(carry_3_) );
  INVX1 U775 ( .A(n1610), .Y(carry_4_) );
  INVX1 U776 ( .A(n1510), .Y(carry_5_) );
  INVX1 U777 ( .A(n1410), .Y(carry_6_) );
  INVX1 U778 ( .A(n1310), .Y(carry_7_) );
  INVX1 U779 ( .A(n1210), .Y(carry_8_) );
  INVX1 U780 ( .A(n1110), .Y(carry_9_) );
  INVX1 U781 ( .A(n9), .Y(carry_11_) );
  INVX1 U782 ( .A(n7), .Y(carry_13_) );
  INVX1 U783 ( .A(n5), .Y(carry_15_) );
  INVX1 U784 ( .A(n3), .Y(carry_17_) );
  INVX1 U785 ( .A(n1010), .Y(carry_10_) );
  INVX1 U786 ( .A(n8), .Y(carry_12_) );
  INVX1 U787 ( .A(n6), .Y(carry_14_) );
  INVX1 U788 ( .A(n4), .Y(carry_16_) );
  AO21X1 U789 ( .A0(n315), .A1(timeoutcnt_int[19]), .B0(n316), .Y(n154) );
  OAI33X1 U790 ( .A0(n317), .A1(n502), .A2(n319), .B0(n317), .B1(
        timeoutcnt_int[19]), .B2(n1100), .Y(n316) );
  INVX1 U791 ( .A(n1100), .Y(n319) );
  AFHCONX2 U1_1 ( .A(clkdivcnt[1]), .B(clkdiv[1]), .CI(carry_1_), .S(N91), 
        .CON(n1411) );
  NOR2BX1 U792 ( .AN(clkdivcnt[0]), .B(n475), .Y(carry_1_) );
  AFHCONX2 U1_2 ( .A(clkdivcnt[2]), .B(clkdiv[2]), .CI(carry12), .S(N92), 
        .CON(n1311) );
  INVX1 U793 ( .A(n1411), .Y(carry12) );
  AFHCONX2 U1_3 ( .A(clkdivcnt[3]), .B(clkdiv[3]), .CI(carry11), .S(N93), 
        .CON(n1211) );
  INVX1 U794 ( .A(n1311), .Y(carry11) );
  AFHCONX2 U1_4 ( .A(clkdivcnt[4]), .B(clkdiv[4]), .CI(carry10), .S(N94), 
        .CON(n1111) );
  INVX1 U795 ( .A(n1211), .Y(carry10) );
  AFHCONX2 U1_5 ( .A(clkdivcnt[5]), .B(clkdiv[5]), .CI(carry9), .S(N95), .CON(
        n1011) );
  INVX1 U796 ( .A(n1111), .Y(carry9) );
  AFHCONX2 U1_6 ( .A(clkdivcnt[6]), .B(clkdiv[6]), .CI(carry8), .S(N96), .CON(
        n910) );
  INVX1 U797 ( .A(n1011), .Y(carry8) );
  AFHCONX2 U1_7 ( .A(clkdivcnt[7]), .B(clkdiv[7]), .CI(carry7), .S(N97), .CON(
        n810) );
  INVX1 U798 ( .A(n910), .Y(carry7) );
  AFHCONX2 U1_8 ( .A(clkdivcnt[8]), .B(clkdiv[8]), .CI(carry6), .S(N98), .CON(
        n710) );
  INVX1 U799 ( .A(n810), .Y(carry6) );
  AFHCONX2 U1_9 ( .A(clkdivcnt[9]), .B(clkdiv[9]), .CI(carry5), .S(N99), .CON(
        n610) );
  INVX1 U800 ( .A(n710), .Y(carry5) );
  AFHCONX2 U1_10 ( .A(clkdivcnt[10]), .B(clkdiv[10]), .CI(carry4), .S(N100), 
        .CON(n510) );
  INVX1 U801 ( .A(n610), .Y(carry4) );
  AFHCONX2 U1_11 ( .A(clkdivcnt[11]), .B(clkdiv[11]), .CI(carry3), .S(N101), 
        .CON(n410) );
  INVX1 U802 ( .A(n510), .Y(carry3) );
  AFHCONX2 U1_12 ( .A(clkdivcnt[12]), .B(clkdiv[12]), .CI(carry2), .S(N102), 
        .CON(n310) );
  INVX1 U803 ( .A(n410), .Y(carry2) );
  AFHCONX2 U1_13 ( .A(clkdivcnt[13]), .B(clkdiv[13]), .CI(carry1), .S(N103), 
        .CON(n233) );
  INVX1 U804 ( .A(n310), .Y(carry1) );
  AFHCONX2 U1_14 ( .A(clkdivcnt[14]), .B(clkdiv[14]), .CI(carry0), .S(N104), 
        .CON(n1101) );
  INVX1 U805 ( .A(n233), .Y(carry0) );
  AO22X1 U806 ( .A0(clkdivcnt[13]), .A1(n464), .B0(N103), .B1(uarten), .Y(n189) );
  AO22X1 U807 ( .A0(clkdivcnt[14]), .A1(n464), .B0(N104), .B1(uarten), .Y(n190) );
  AO22X1 U808 ( .A0(clkdivcnt[15]), .A1(n464), .B0(N105), .B1(uarten), .Y(n191) );
  XOR3X1 U1_15 ( .A(clkdivcnt[15]), .B(clkdiv[15]), .C(carry), .Y(N105) );
  INVX1 U809 ( .A(n1101), .Y(carry) );
  AO22X1 U810 ( .A0(timeoutcnt_int[15]), .A1(n315), .B0(N127), .B1(n320), .Y(
        n150) );
  AO22X1 U811 ( .A0(timeoutcnt_int[16]), .A1(n315), .B0(N128), .B1(n320), .Y(
        n151) );
  AO22X1 U812 ( .A0(timeoutcnt_int[17]), .A1(n315), .B0(N129), .B1(n320), .Y(
        n152) );
  AO22X1 U813 ( .A0(timeoutcnt_int[18]), .A1(n315), .B0(N130), .B1(n320), .Y(
        n153) );
  NAND4BX1 U814 ( .AN(rxfifoempty), .B(n476), .C(bytereceivedb), .D(
        reg_0x0000_29_), .Y(n322) );
  BUFX2 U815 ( .A(n517), .Y(uarten) );
  OAI31X1 U816 ( .A0(n442), .A1(n443), .A2(n444), .B0(n445), .Y(n412) );
  INVX1 U817 ( .A(n446), .Y(n444) );
  AOI211X1 U818 ( .A0(txwaterlevel_int[1]), .A1(n373), .B0(txwaterlevel_int[0]), .C0(n379), .Y(n443) );
  AOI31X1 U819 ( .A0(txwaterlevel_int[2]), .A1(n422), .A2(n446), .B0(n447), 
        .Y(n445) );
  OAI211X1 U820 ( .A0(n434), .A1(n435), .B0(n467), .C0(n482), .Y(n391) );
  NOR2BX1 U821 ( .AN(n438), .B(n439), .Y(n434) );
  OAI32X1 U822 ( .A0(n436), .A1(rxwaterlevel_int[2]), .A2(n399), .B0(
        rxwaterlevel_int[3]), .B1(n396), .Y(n435) );
  OA22X1 U823 ( .A0(rxfifocnt[1]), .A1(n504), .B0(n504), .B1(n465), .Y(n438)
         );
  NOR2BX1 U824 ( .AN(reg_0x0000_7_), .B(n391), .Y(N53) );
  AO22X1 U825 ( .A0(clkdivcnt[8]), .A1(n464), .B0(N98), .B1(uarten), .Y(n184)
         );
  AO22X1 U826 ( .A0(clkdivcnt[9]), .A1(n464), .B0(N99), .B1(uarten), .Y(n185)
         );
  AO22X1 U827 ( .A0(clkdivcnt[10]), .A1(n464), .B0(N100), .B1(uarten), .Y(n186) );
  AO22X1 U828 ( .A0(clkdivcnt[11]), .A1(n464), .B0(N101), .B1(uarten), .Y(n187) );
  AO22X1 U829 ( .A0(clkdivcnt[12]), .A1(n464), .B0(N102), .B1(uarten), .Y(n188) );
  AO22X1 U830 ( .A0(timeoutcnt_int[0]), .A1(n315), .B0(n320), .B1(n501), .Y(
        n135) );
  AO22X1 U831 ( .A0(timeoutcnt_int[1]), .A1(n315), .B0(N113), .B1(n320), .Y(
        n136) );
  AO22X1 U832 ( .A0(timeoutcnt_int[2]), .A1(n315), .B0(N114), .B1(n320), .Y(
        n137) );
  AO22X1 U833 ( .A0(timeoutcnt_int[3]), .A1(n315), .B0(N115), .B1(n320), .Y(
        n138) );
  AO22X1 U834 ( .A0(timeoutcnt_int[4]), .A1(n315), .B0(N116), .B1(n320), .Y(
        n139) );
  AO22X1 U835 ( .A0(timeoutcnt_int[5]), .A1(n315), .B0(N117), .B1(n320), .Y(
        n140) );
  AO22X1 U836 ( .A0(timeoutcnt_int[6]), .A1(n315), .B0(N118), .B1(n320), .Y(
        n141) );
  AO22X1 U837 ( .A0(timeoutcnt_int[7]), .A1(n315), .B0(N119), .B1(n320), .Y(
        n142) );
  AO22X1 U838 ( .A0(timeoutcnt_int[8]), .A1(n315), .B0(N120), .B1(n320), .Y(
        n143) );
  AO22X1 U839 ( .A0(timeoutcnt_int[9]), .A1(n315), .B0(N121), .B1(n320), .Y(
        n144) );
  AO22X1 U840 ( .A0(timeoutcnt_int[10]), .A1(n315), .B0(N122), .B1(n320), .Y(
        n145) );
  AO22X1 U841 ( .A0(timeoutcnt_int[11]), .A1(n315), .B0(N123), .B1(n320), .Y(
        n146) );
  AO22X1 U842 ( .A0(timeoutcnt_int[12]), .A1(n315), .B0(N124), .B1(n320), .Y(
        n147) );
  AO22X1 U843 ( .A0(timeoutcnt_int[13]), .A1(n315), .B0(N125), .B1(n320), .Y(
        n148) );
  AO22X1 U844 ( .A0(timeoutcnt_int[14]), .A1(n315), .B0(N126), .B1(n320), .Y(
        n149) );
  XOR2X1 U845 ( .A(timeoutcnt[0]), .B(n501), .Y(n361) );
  XOR2X1 U846 ( .A(timeoutcnt[19]), .B(n502), .Y(n342) );
  XOR2X1 U847 ( .A(timeoutcnt_int[9]), .B(timeoutcnt[9]), .Y(n332) );
  XOR2X1 U848 ( .A(timeoutcnt_int[18]), .B(timeoutcnt[18]), .Y(n351) );
  XOR2X1 U849 ( .A(n462), .B(timeoutcnt_int[10]), .Y(n360) );
  XOR2X1 U850 ( .A(timeoutcnt[1]), .B(n503), .Y(n341) );
  XOR2X1 U851 ( .A(timeoutcnt_int[17]), .B(timeoutcnt[17]), .Y(n350) );
  XOR2X1 U852 ( .A(timeoutcnt_int[11]), .B(timeoutcnt[11]), .Y(n359) );
  XOR2X1 U853 ( .A(timeoutcnt_int[2]), .B(timeoutcnt[2]), .Y(n340) );
  AND2X2 U854 ( .A(n505), .B(rxfifocnt[0]), .Y(n504) );
  OAI211X1 U855 ( .A0(n329), .A1(n330), .B0(reg_0x0000_29_), .C0(n476), .Y(
        n327) );
  OR4X1 U856 ( .A(n331), .B(n332), .C(n333), .D(n334), .Y(n330) );
  OR4X1 U857 ( .A(n350), .B(n351), .C(n352), .D(n353), .Y(n329) );
  XOR2X1 U858 ( .A(timeoutcnt_int[8]), .B(timeoutcnt[8]), .Y(n331) );
  NAND3BX1 U859 ( .AN(n354), .B(n355), .C(n356), .Y(n353) );
  XOR2X1 U860 ( .A(n460), .B(timeoutcnt_int[12]), .Y(n355) );
  XOR2X1 U861 ( .A(n457), .B(timeoutcnt_int[13]), .Y(n356) );
  NAND3BX1 U862 ( .AN(n359), .B(n360), .C(n361), .Y(n354) );
  NAND3BX1 U863 ( .AN(n335), .B(n336), .C(n337), .Y(n334) );
  XOR2X1 U864 ( .A(n478), .B(timeoutcnt_int[3]), .Y(n336) );
  XOR2X1 U865 ( .A(n477), .B(timeoutcnt_int[4]), .Y(n337) );
  NAND3BX1 U866 ( .AN(n340), .B(n341), .C(n342), .Y(n335) );
  NAND3BX1 U867 ( .AN(n364), .B(n365), .C(n366), .Y(n352) );
  XOR2X1 U868 ( .A(n461), .B(timeoutcnt_int[14]), .Y(n365) );
  XOR2X1 U869 ( .A(n463), .B(timeoutcnt_int[15]), .Y(n366) );
  XOR2X1 U870 ( .A(timeoutcnt_int[16]), .B(timeoutcnt[16]), .Y(n364) );
  NAND3BX1 U871 ( .AN(n345), .B(n346), .C(n347), .Y(n333) );
  XOR2X1 U872 ( .A(n459), .B(timeoutcnt_int[5]), .Y(n346) );
  XOR2X1 U873 ( .A(n479), .B(timeoutcnt_int[6]), .Y(n347) );
  XOR2X1 U874 ( .A(timeoutcnt_int[7]), .B(timeoutcnt[7]), .Y(n345) );
  AO22X1 U875 ( .A0(clkdivcnt[3]), .A1(n464), .B0(N93), .B1(uarten), .Y(n179)
         );
  AO22X1 U876 ( .A0(clkdivcnt[4]), .A1(n464), .B0(N94), .B1(uarten), .Y(n180)
         );
  AO22X1 U877 ( .A0(clkdivcnt[5]), .A1(n464), .B0(N95), .B1(uarten), .Y(n181)
         );
  AO22X1 U878 ( .A0(clkdivcnt[6]), .A1(n464), .B0(N96), .B1(uarten), .Y(n182)
         );
  AO22X1 U879 ( .A0(clkdivcnt[7]), .A1(n464), .B0(N97), .B1(uarten), .Y(n183)
         );
  OAI32X1 U880 ( .A0(n325), .A1(swrst), .A2(n470), .B0(n327), .B1(n486), .Y(
        n134) );
  INVX1 U881 ( .A(n327), .Y(n325) );
  NAND2BX1 U882 ( .AN(txwaterlevel_int[3]), .B(txfifocnt[3]), .Y(n446) );
  NAND2BX1 U883 ( .AN(rxfifocnt[3]), .B(rxwaterlevel_int[3]), .Y(n437) );
  AO22X1 U884 ( .A0(clkdivcnt[1]), .A1(n464), .B0(N91), .B1(uarten), .Y(n177)
         );
  AO22X1 U885 ( .A0(clkdivcnt[2]), .A1(n464), .B0(N92), .B1(uarten), .Y(n178)
         );
  AO22X1 U886 ( .A0(clkdivcnt_msb_dly), .A1(n464), .B0(clkdivcnt[15]), .B1(
        uarten), .Y(n192) );
  OAI32X1 U887 ( .A0(n464), .A1(clkdivcnt_msb_dly), .A2(n484), .B0(uarten), 
        .B1(n456), .Y(n175) );
  OAI31X1 U888 ( .A0(n464), .A1(clkdivcnt[0]), .A2(n475), .B0(n307), .Y(n176)
         );
  OA22X1 U889 ( .A0(uarten), .A1(n485), .B0(clkdiv[0]), .B1(n485), .Y(n307) );
  INVX1 U890 ( .A(rxfifocnt[3]), .Y(n396) );
  AOI211X1 U891 ( .A0(n451), .A1(n452), .B0(swrst), .C0(n487), .Y(N110) );
  NOR3BX1 U892 ( .AN(n455), .B(overrunerror), .C(n10), .Y(n451) );
  NOR3BX1 U893 ( .AN(n454), .B(reg_0x0004_7_), .C(reg_0x0004_22_), .Y(n452) );
  OAI211X1 U894 ( .A0(txfifocnt[3]), .A1(n481), .B0(n458), .C0(n466), .Y(n447)
         );
  INVX1 U895 ( .A(parityerror), .Y(n454) );
  INVX1 U896 ( .A(frameerror), .Y(n455) );
  AO22X1 U897 ( .A0(PADDR[4]), .A1(PADDR[3]), .B0(PADDR[2]), .B1(n431), .Y(
        PRDATA[28]) );
  INVX1 U898 ( .A(PADDR[4]), .Y(n431) );
  NAND2X1 U899 ( .A(reg_0x0000_27_), .B(n412), .Y(n297) );
  AOI22X1 U900 ( .A0(clkdiv[4]), .A1(n388), .B0(fifodata_rx[4]), .B1(n371), 
        .Y(n395) );
  AOI22X1 U901 ( .A0(clkdiv[5]), .A1(n388), .B0(fifodata_rx[5]), .B1(n371), 
        .Y(n393) );
  AOI222X1 U902 ( .A0(timeoutcnt[6]), .A1(n387), .B0(clkdiv[6]), .B1(n388), 
        .C0(fifodata_rx[6]), .C1(n371), .Y(n389) );
  OA22X1 U903 ( .A0(n304), .A1(n472), .B0(n509), .B1(n497), .Y(n381) );
  OA22X1 U904 ( .A0(n304), .A1(n473), .B0(n509), .B1(n498), .Y(n376) );
  OA22X1 U905 ( .A0(n304), .A1(n494), .B0(n509), .B1(n462), .Y(n424) );
  OA22X1 U906 ( .A0(n304), .A1(n474), .B0(n509), .B1(n499), .Y(n419) );
  OA22X1 U907 ( .A0(n304), .A1(n496), .B0(n509), .B1(n463), .Y(n407) );
  NOR2BX1 U908 ( .AN(timeoutcnt[16]), .B(n509), .Y(PRDATA[16]) );
  NOR2BX1 U909 ( .AN(timeoutcnt[17]), .B(n509), .Y(PRDATA[17]) );
  NOR2BX1 U910 ( .AN(timeoutcnt[18]), .B(n509), .Y(PRDATA[18]) );
  NOR2BX1 U911 ( .AN(timeoutcnt[19]), .B(n509), .Y(PRDATA[19]) );
  AO22X1 U912 ( .A0(loopbacken), .A1(n301), .B0(reg_0x0004_22_), .B1(
        PRDATA[28]), .Y(PRDATA[22]) );
  AO22X1 U913 ( .A0(stopbit), .A1(n301), .B0(overrunerror), .B1(PRDATA[28]), 
        .Y(PRDATA[23]) );
  AO22X1 U914 ( .A0(databit), .A1(n301), .B0(frameerror), .B1(PRDATA[28]), .Y(
        PRDATA[24]) );
  AO22X1 U915 ( .A0(parity[0]), .A1(n301), .B0(parityerror), .B1(PRDATA[28]), 
        .Y(PRDATA[25]) );
  AO22X1 U916 ( .A0(parity[1]), .A1(n301), .B0(rxbusy), .B1(PRDATA[28]), .Y(
        PRDATA[26]) );
  AO22X1 U917 ( .A0(n301), .A1(reg_0x0000_27_), .B0(txbusy), .B1(PRDATA[28]), 
        .Y(PRDATA[27]) );
  NOR2BX1 U918 ( .AN(reg_0x0000_29_), .B(n508), .Y(PRDATA[29]) );
  NOR2BX1 U919 ( .AN(reg_0x0000_30_), .B(n508), .Y(PRDATA[30]) );
  AO22X1 U920 ( .A0(uarten), .A1(n301), .B0(int), .B1(PRDATA[28]), .Y(
        PRDATA[31]) );
  INVX1 U921 ( .A(txfifocnt[3]), .Y(n417) );
  NOR2X1 U922 ( .A(n391), .B(n507), .Y(rxdmareq) );
  AOI222X1 U923 ( .A0(timeoutcnt[0]), .A1(n387), .B0(clkdiv[0]), .B1(n388), 
        .C0(fifodata_rx[0]), .C1(n371), .Y(n428) );
  AOI222X1 U924 ( .A0(timeoutcnt[1]), .A1(n387), .B0(clkdiv[1]), .B1(n388), 
        .C0(fifodata_rx[1]), .C1(n371), .Y(n404) );
  AOI222X1 U925 ( .A0(timeoutcnt[2]), .A1(n387), .B0(clkdiv[2]), .B1(n388), 
        .C0(fifodata_rx[2]), .C1(n371), .Y(n401) );
  AOI222X1 U926 ( .A0(timeoutcnt[3]), .A1(n387), .B0(clkdiv[3]), .B1(n388), 
        .C0(fifodata_rx[3]), .C1(n371), .Y(n398) );
  AOI222X1 U927 ( .A0(timeoutcnt[7]), .A1(n387), .B0(clkdiv[7]), .B1(n388), 
        .C0(fifodata_rx[7]), .C1(n371), .Y(n386) );
  DFFRX1 timeoutcnt_int_reg_0_ ( .D(n135), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[0]), .QN(n501) );
  DFFRX1 clkdiv_reg_0_ ( .D(n193), .CK(clk), .RN(rstb), .Q(clkdiv[0]), .QN(
        n475) );
  DFFRX1 clkdivcnt_reg_0_ ( .D(n176), .CK(clk), .RN(rstb), .Q(clkdivcnt[0]), 
        .QN(n485) );
  DFFRX1 timeoutcnt_int_reg_1_ ( .D(n136), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[1]), .QN(n503) );
  DFFRX1 timeoutcnt_int_reg_3_ ( .D(n138), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[3]) );
  DFFRX1 timeoutcnt_int_reg_4_ ( .D(n139), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[4]) );
  DFFRX1 timeoutcnt_int_reg_5_ ( .D(n140), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[5]) );
  DFFRX1 timeoutcnt_int_reg_2_ ( .D(n137), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[2]) );
  DFFRX1 clkdiv_reg_1_ ( .D(n194), .CK(clk), .RN(rstb), .Q(clkdiv[1]) );
  DFFRX1 clkdiv_reg_2_ ( .D(n195), .CK(clk), .RN(rstb), .Q(clkdiv[2]) );
  DFFRX1 clkdiv_reg_3_ ( .D(n196), .CK(clk), .RN(rstb), .Q(clkdiv[3]) );
  DFFRX1 clkdivcnt_reg_1_ ( .D(n177), .CK(clk), .RN(rstb), .Q(clkdivcnt[1]) );
  DFFRX1 clkdivcnt_reg_2_ ( .D(n178), .CK(clk), .RN(rstb), .Q(clkdivcnt[2]) );
  DFFRX1 clkdivcnt_reg_3_ ( .D(n179), .CK(clk), .RN(rstb), .Q(clkdivcnt[3]) );
  DFFRX1 parity_int_reg_0_ ( .D(n218), .CK(clk), .RN(rstb), .Q(parity[0]) );
  DFFRX1 clkdiv_reg_8_ ( .D(n201), .CK(clk), .RN(rstb), .Q(clkdiv[8]), .QN(
        n472) );
  DFFRX1 uarten_int_reg ( .D(n223), .CK(clk), .RN(rstb), .Q(n517), .QN(n464)
         );
  DFFRX1 clkdiv_reg_4_ ( .D(n197), .CK(clk), .RN(rstb), .Q(clkdiv[4]) );
  DFFRX1 clkdiv_reg_5_ ( .D(n198), .CK(clk), .RN(rstb), .Q(clkdiv[5]) );
  DFFRX1 timeoutcnt_int_reg_6_ ( .D(n141), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[6]) );
  DFFRX1 timeoutcnt_int_reg_10_ ( .D(n145), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[10]) );
  DFFRX1 timeoutcnt_int_reg_7_ ( .D(n142), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[7]) );
  DFFRX1 timeoutcnt_int_reg_8_ ( .D(n143), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[8]) );
  DFFRX1 timeoutcnt_int_reg_9_ ( .D(n144), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[9]) );
  DFFRX1 timeoutcnt_int_reg_11_ ( .D(n146), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[11]) );
  DFFRX1 clkdiv_reg_6_ ( .D(n199), .CK(clk), .RN(rstb), .Q(clkdiv[6]) );
  DFFRX1 clkdiv_reg_7_ ( .D(n200), .CK(clk), .RN(rstb), .Q(clkdiv[7]) );
  DFFRX1 clkdivcnt_reg_4_ ( .D(n180), .CK(clk), .RN(rstb), .Q(clkdivcnt[4]) );
  DFFRX1 clkdivcnt_reg_5_ ( .D(n181), .CK(clk), .RN(rstb), .Q(clkdivcnt[5]) );
  DFFRX1 clkdivcnt_reg_6_ ( .D(n182), .CK(clk), .RN(rstb), .Q(clkdivcnt[6]) );
  DFFRX1 clkdivcnt_reg_7_ ( .D(n183), .CK(clk), .RN(rstb), .Q(clkdivcnt[7]) );
  DFFRX1 clkdivcnt_reg_8_ ( .D(n184), .CK(clk), .RN(rstb), .Q(clkdivcnt[8]) );
  DFFRX1 stopbit_int_reg ( .D(n216), .CK(clk), .RN(rstb), .Q(stopbit) );
  DFFRX1 clkdiv_reg_9_ ( .D(n202), .CK(clk), .RN(rstb), .Q(clkdiv[9]), .QN(
        n473) );
  DFFRX1 clkdiv_reg_10_ ( .D(n203), .CK(clk), .RN(rstb), .Q(clkdiv[10]), .QN(
        n494) );
  DFFRX1 clkdiv_reg_11_ ( .D(n204), .CK(clk), .RN(rstb), .Q(clkdiv[11]), .QN(
        n474) );
  DFFRX1 clkdiv_reg_12_ ( .D(n205), .CK(clk), .RN(rstb), .Q(clkdiv[12]), .QN(
        n488) );
  DFFRX1 timeoutcnt_int_reg_19_ ( .D(n154), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[19]), .QN(n502) );
  DFFRX1 timeoutcnt_reg_8_ ( .D(n163), .CK(clk), .RN(rstb), .Q(timeoutcnt[8]), 
        .QN(n497) );
  DFFRX1 timeoutcnt_reg_9_ ( .D(n164), .CK(clk), .RN(rstb), .Q(timeoutcnt[9]), 
        .QN(n498) );
  DFFRX1 timeoutcnt_reg_11_ ( .D(n166), .CK(clk), .RN(rstb), .Q(timeoutcnt[11]), .QN(n499) );
  DFFRX1 loopbacken_int_reg ( .D(n215), .CK(clk), .RN(rstb), .Q(loopbacken) );
  DFFRX1 timeoutcnt_reg_19_ ( .D(n174), .CK(clk), .RN(rstb), .Q(timeoutcnt[19]) );
  DFFRX1 timeoutcnt_reg_0_ ( .D(n155), .CK(clk), .RN(rstb), .Q(timeoutcnt[0])
         );
  DFFRX1 timeoutcnt_reg_1_ ( .D(n156), .CK(clk), .RN(rstb), .Q(timeoutcnt[1])
         );
  DFFRX1 timeoutcnt_reg_3_ ( .D(n158), .CK(clk), .RN(rstb), .Q(timeoutcnt[3]), 
        .QN(n478) );
  DFFRX1 timeoutcnt_reg_6_ ( .D(n161), .CK(clk), .RN(rstb), .Q(timeoutcnt[6]), 
        .QN(n479) );
  DFFRX1 timeoutcnt_reg_4_ ( .D(n159), .CK(clk), .RN(rstb), .Q(timeoutcnt[4]), 
        .QN(n477) );
  DFFRX1 timeoutcnt_reg_5_ ( .D(n160), .CK(clk), .RN(rstb), .Q(timeoutcnt[5]), 
        .QN(n459) );
  DFFRX1 timeoutcnt_reg_10_ ( .D(n165), .CK(clk), .RN(rstb), .Q(timeoutcnt[10]), .QN(n462) );
  DFFRX1 timeoutcnt_reg_12_ ( .D(n167), .CK(clk), .RN(rstb), .Q(timeoutcnt[12]), .QN(n460) );
  DFFRX1 timeoutcnt_reg_13_ ( .D(n168), .CK(clk), .RN(rstb), .Q(timeoutcnt[13]), .QN(n457) );
  DFFRX1 timeoutcnt_reg_14_ ( .D(n169), .CK(clk), .RN(rstb), .Q(timeoutcnt[14]), .QN(n461) );
  DFFRX1 timeoutcnt_reg_15_ ( .D(n170), .CK(clk), .RN(rstb), .Q(timeoutcnt[15]), .QN(n463) );
  DFFRX1 timeoutcnt_int_reg_12_ ( .D(n147), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[12]) );
  DFFRX1 timeoutcnt_int_reg_13_ ( .D(n148), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[13]) );
  DFFRX1 timeoutcnt_int_reg_14_ ( .D(n149), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[14]) );
  DFFRX1 timeoutcnt_int_reg_15_ ( .D(n150), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[15]) );
  DFFRX1 timeoutcnt_int_reg_16_ ( .D(n151), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[16]) );
  DFFRX1 timeoutcnt_int_reg_17_ ( .D(n152), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[17]) );
  DFFRX1 timeoutcnt_int_reg_18_ ( .D(n153), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[18]) );
  DFFRX1 timeoutcnt_reg_16_ ( .D(n171), .CK(clk), .RN(rstb), .Q(timeoutcnt[16]) );
  DFFRX1 timeoutcnt_reg_17_ ( .D(n172), .CK(clk), .RN(rstb), .Q(timeoutcnt[17]) );
  DFFRX1 timeoutcnt_reg_18_ ( .D(n173), .CK(clk), .RN(rstb), .Q(timeoutcnt[18]) );
  DFFRX1 timeoutcnt_reg_2_ ( .D(n157), .CK(clk), .RN(rstb), .Q(timeoutcnt[2])
         );
  DFFRX1 timeoutcnt_reg_7_ ( .D(n162), .CK(clk), .RN(rstb), .Q(timeoutcnt[7])
         );
  DFFRX1 clkdivcnt_reg_9_ ( .D(n185), .CK(clk), .RN(rstb), .Q(clkdivcnt[9]) );
  DFFRX1 clkdivcnt_reg_10_ ( .D(n186), .CK(clk), .RN(rstb), .Q(clkdivcnt[10])
         );
  DFFRX1 clkdivcnt_reg_11_ ( .D(n187), .CK(clk), .RN(rstb), .Q(clkdivcnt[11])
         );
  DFFRX1 clkdivcnt_reg_12_ ( .D(n188), .CK(clk), .RN(rstb), .Q(clkdivcnt[12])
         );
  DFFRX1 clkdivcnt_reg_13_ ( .D(n189), .CK(clk), .RN(rstb), .Q(clkdivcnt[13])
         );
  DFFRX1 timeoutinten_int_reg ( .D(n221), .CK(clk), .RN(rstb), .Q(
        reg_0x0000_29_), .QN(n470) );
  DFFRX1 clkdiv_reg_13_ ( .D(n206), .CK(clk), .RN(rstb), .Q(clkdiv[13]), .QN(
        n489) );
  DFFRX1 clkdiv_reg_14_ ( .D(n207), .CK(clk), .RN(rstb), .Q(clkdiv[14]), .QN(
        n490) );
  DFFRX1 clkdiv_reg_15_ ( .D(n208), .CK(clk), .RN(rstb), .Q(clkdiv[15]), .QN(
        n496) );
  DFFRX1 dmareqen_int_reg ( .D(n220), .CK(clk), .RN(rstb), .Q(reg_0x0000_27_), 
        .QN(n507) );
  DFFRX1 receivetimeout_reg ( .D(n134), .CK(clk), .RN(rstb), .Q(reg_0x0004_22_), .QN(n486) );
  DFFRX1 rxwaterlevel_int_reg_3_ ( .D(n229), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[3]), .QN(n491) );
  DFFRX1 rxfifo_interrupt_reg ( .D(N53), .CK(clk), .RN(rstb), .Q(reg_0x0004_7_), .QN(n471) );
  DFFRX1 clkdivcnt_reg_15_ ( .D(n191), .CK(clk), .RN(rstb), .Q(clkdivcnt[15]), 
        .QN(n484) );
  DFFRX1 txfifo_interrupt_reg ( .D(N52), .CK(clk), .RN(rstb), .Q(n10), .QN(
        n492) );
  DFFRX1 intgenen_int_reg ( .D(n222), .CK(clk), .RN(rstb), .Q(reg_0x0000_30_), 
        .QN(n487) );
  DFFRX1 rxfifo_inten_reg ( .D(n224), .CK(clk), .RN(rstb), .Q(reg_0x0000_7_), 
        .QN(n495) );
  DFFRX1 txwaterlevel_int_reg_3_ ( .D(n212), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[3]), .QN(n481) );
  DFFRX1 rxwaterlevel_int_reg_0_ ( .D(n226), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[0]), .QN(n505) );
  DFFRX1 txwaterlevel_int_reg_1_ ( .D(n210), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[1]), .QN(n469) );
  DFFRX1 rxwaterlevel_int_reg_2_ ( .D(n228), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[2]), .QN(n480) );
  DFFRX1 txwaterlevel_int_reg_0_ ( .D(n209), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[0]), .QN(n493) );
  DFFRX1 txwaterlevel_int_reg_2_ ( .D(n211), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[2]), .QN(n483) );
  DFFRX1 txwaterlevel_int_reg_4_ ( .D(n213), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[4]), .QN(n458) );
  DFFRX1 txwaterlevel_int_reg_5_ ( .D(n214), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[5]), .QN(n466) );
  DFFRX1 txfifo_inten_reg ( .D(n225), .CK(clk), .RN(rstb), .Q(reg_0x0000_15_), 
        .QN(n468) );
  DFFRX1 rxwaterlevel_int_reg_1_ ( .D(n227), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[1]), .QN(n465) );
  DFFRX1 rxwaterlevel_int_reg_4_ ( .D(n230), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[4]), .QN(n467) );
  DFFRX1 rxwaterlevel_int_reg_5_ ( .D(n231), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[5]), .QN(n482) );
  DFFRX1 overrunerr_clear_reg ( .D(N63), .CK(clk), .RN(rstb), .Q(
        overrunerr_clear) );
  DFFRX1 clkdivcnt_reg_14_ ( .D(n190), .CK(clk), .RN(rstb), .Q(clkdivcnt[14])
         );
  DFFRX1 clkdivcnt_msb_dly_reg ( .D(n192), .CK(clk), .RN(rstb), .Q(
        clkdivcnt_msb_dly) );
  DFFRX1 frameerr_clear_reg ( .D(N61), .CK(clk), .RN(rstb), .Q(frameerr_clear)
         );
  DFFRX1 parityerr_clear_reg ( .D(N62), .CK(clk), .RN(rstb), .Q(
        parityerr_clear) );
  DFFRX1 interrupt_status_reg ( .D(N110), .CK(clk), .RN(rstb), .Q(int) );
endmodule


module UartTop_3_1 ( PADDR, PENABLE, PSEL, PWDATA, PWRITE, clk, rstb, rxd, 
        PRDATA, int, rxdmareq, txd, txdmareq );
  input [4:2] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  input PENABLE, PSEL, PWRITE, clk, rstb, rxd;
  output int, rxdmareq, txd, txdmareq;
  wire   bytereceivedb, frameerror, overrunerror, parityerror, rxbusy,
         rxfifoempty, txbusy, txfifo_emptyb, txfifo_fillb, txfifo_fullb,
         baudx16clk, databit, fifordb, fifowrb, loopbacken, stopbit, swrst,
         uarten, frameerr_clear, parityerr_clear, overrunerr_clear;
  wire   [7:0] fifodata_rx;
  wire   [5:0] rxfifocnt;
  wire   [5:0] txfifocnt;
  wire   [7:0] fifodata_tx;
  wire   [1:0] parity;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1;
  assign PRDATA[21] = 1'b0;
  assign PRDATA[20] = 1'b0;

  RegBlk_3_5_1 RegBlock ( .PADDR(PADDR), .PENABLE(PENABLE), .PSEL(PSEL), 
        .PWDATA(PWDATA), .PWRITE(PWRITE), .bytereceivedb(bytereceivedb), .clk(
        clk), .fifodata_rx(fifodata_rx), .frameerror(frameerror), 
        .overrunerror(overrunerror), .parityerror(parityerror), .rstb(rstb), 
        .rxbusy(rxbusy), .rxfifocnt(rxfifocnt), .rxfifoempty(rxfifoempty), 
        .txbusy(txbusy), .txfifo_emptyb(txfifo_emptyb), .txfifo_fillb(
        txfifo_fillb), .txfifo_fullb(txfifo_fullb), .txfifocnt(txfifocnt), 
        .PRDATA({PRDATA[31:22], SYNOPSYS_UNCONNECTED__0, 
        SYNOPSYS_UNCONNECTED__1, PRDATA[19:0]}), .baudx16clk(baudx16clk), 
        .databit(databit), .fifodata_tx(fifodata_tx), .fifordb(fifordb), 
        .fifowrb(fifowrb), .int(int), .loopbacken(loopbacken), .parity(parity), 
        .rxdmareq(rxdmareq), .stopbit(stopbit), .swrst(swrst), .txdmareq(
        txdmareq), .uarten(uarten), .frameerr_clear(frameerr_clear), 
        .parityerr_clear(parityerr_clear), .overrunerr_clear(overrunerr_clear)
         );
  RxBlock_UART_FIFO_WIDTH5_1 RxBLK ( .baudx16clk(baudx16clk), .clk(clk), 
        .databit(databit), .fifordb(fifordb), .loopbacken(loopbacken), 
        .parity(parity), .rstb(rstb), .rxd(rxd), .stopbit(stopbit), .swrst(
        swrst), .txd(txd), .uarten(uarten), .bytereceivedb(bytereceivedb), 
        .fifodata_rx(fifodata_rx), .frameerror(frameerror), .overrunerror(
        overrunerror), .parityerror(parityerror), .rxbusy(rxbusy), .rxfifocnt(
        rxfifocnt), .rxfifoempty(rxfifoempty), .frameerr_clear(frameerr_clear), 
        .parityerr_clear(parityerr_clear), .overrunerr_clear(overrunerr_clear)
         );
  TxBlock_UART_FIFO_WIDTH5_1 TxBLK ( .baudx16clk(baudx16clk), .clk(clk), 
        .databit(databit), .fifodata_tx(fifodata_tx), .fifowrb(fifowrb), 
        .parity(parity), .rstb(rstb), .stopbit(stopbit), .swrst(swrst), 
        .uarten(uarten), .txbusy(txbusy), .txd(txd), .txfifo_emptyb(
        txfifo_emptyb), .txfifo_fillb(txfifo_fillb), .txfifo_fullb(
        txfifo_fullb), .txfifocnt(txfifocnt) );
endmodule


module TxBlock_UART_FIFO_WIDTH5_1 ( baudx16clk, clk, databit, fifodata_tx, 
        fifowrb, parity, rstb, stopbit, swrst, uarten, txbusy, txd, 
        txfifo_emptyb, txfifo_fillb, txfifo_fullb, txfifocnt );
  input [7:0] fifodata_tx;
  input [1:0] parity;
  output [5:0] txfifocnt;
  input baudx16clk, clk, databit, fifowrb, rstb, stopbit, swrst, uarten;
  output txbusy, txd, txfifo_emptyb, txfifo_fillb, txfifo_fullb;
  wire   N74, N75, N76, N77, N78, current_state_10_, current_state_9_,
         current_state_8_, current_state_7_, current_state_6_,
         current_state_5_, current_state_4_, current_state_3_,
         current_state_2_, current_state_1_, dtxclk, txclk, parity_int,
         fifordb, shiftenb, shiftreg_0_, N110, N111, N112, N114, N116, N117,
         N118, N120, N121, N122, N123, N124, N125, N126, N127, N128, N129,
         N130, N131, N132, fifo_wrpos_4_, fifo_wrpos_3_, fifo_wrpos_2_,
         fifo_wrpos_0_, \txfifo[31][7] , \txfifo[31][6] , \txfifo[31][5] ,
         \txfifo[31][4] , \txfifo[31][3] , \txfifo[31][2] , \txfifo[31][1] ,
         \txfifo[31][0] , \txfifo[30][7] , \txfifo[30][6] , \txfifo[30][5] ,
         \txfifo[30][4] , \txfifo[30][3] , \txfifo[30][2] , \txfifo[30][1] ,
         \txfifo[30][0] , \txfifo[29][7] , \txfifo[29][6] , \txfifo[29][5] ,
         \txfifo[29][4] , \txfifo[29][3] , \txfifo[29][2] , \txfifo[29][1] ,
         \txfifo[29][0] , \txfifo[28][7] , \txfifo[28][6] , \txfifo[28][5] ,
         \txfifo[28][4] , \txfifo[28][3] , \txfifo[28][2] , \txfifo[28][1] ,
         \txfifo[28][0] , \txfifo[27][7] , \txfifo[27][6] , \txfifo[27][5] ,
         \txfifo[27][4] , \txfifo[27][3] , \txfifo[27][2] , \txfifo[27][1] ,
         \txfifo[27][0] , \txfifo[26][7] , \txfifo[26][6] , \txfifo[26][5] ,
         \txfifo[26][4] , \txfifo[26][3] , \txfifo[26][2] , \txfifo[26][1] ,
         \txfifo[26][0] , \txfifo[25][7] , \txfifo[25][6] , \txfifo[25][5] ,
         \txfifo[25][4] , \txfifo[25][3] , \txfifo[25][2] , \txfifo[25][1] ,
         \txfifo[25][0] , \txfifo[24][7] , \txfifo[24][6] , \txfifo[24][5] ,
         \txfifo[24][4] , \txfifo[24][3] , \txfifo[24][2] , \txfifo[24][1] ,
         \txfifo[24][0] , \txfifo[23][7] , \txfifo[23][6] , \txfifo[23][5] ,
         \txfifo[23][4] , \txfifo[23][3] , \txfifo[23][2] , \txfifo[23][1] ,
         \txfifo[23][0] , \txfifo[22][7] , \txfifo[22][6] , \txfifo[22][5] ,
         \txfifo[22][4] , \txfifo[22][3] , \txfifo[22][2] , \txfifo[22][1] ,
         \txfifo[22][0] , \txfifo[21][7] , \txfifo[21][6] , \txfifo[21][5] ,
         \txfifo[21][4] , \txfifo[21][3] , \txfifo[21][2] , \txfifo[21][1] ,
         \txfifo[21][0] , \txfifo[20][7] , \txfifo[20][6] , \txfifo[20][5] ,
         \txfifo[20][4] , \txfifo[20][3] , \txfifo[20][2] , \txfifo[20][1] ,
         \txfifo[20][0] , \txfifo[19][7] , \txfifo[19][6] , \txfifo[19][5] ,
         \txfifo[19][4] , \txfifo[19][3] , \txfifo[19][2] , \txfifo[19][1] ,
         \txfifo[19][0] , \txfifo[18][7] , \txfifo[18][6] , \txfifo[18][5] ,
         \txfifo[18][4] , \txfifo[18][3] , \txfifo[18][2] , \txfifo[18][1] ,
         \txfifo[18][0] , \txfifo[17][7] , \txfifo[17][6] , \txfifo[17][5] ,
         \txfifo[17][4] , \txfifo[17][3] , \txfifo[17][2] , \txfifo[17][1] ,
         \txfifo[17][0] , \txfifo[16][7] , \txfifo[16][6] , \txfifo[16][5] ,
         \txfifo[16][4] , \txfifo[16][3] , \txfifo[16][2] , \txfifo[16][1] ,
         \txfifo[16][0] , \txfifo[15][7] , \txfifo[15][6] , \txfifo[15][5] ,
         \txfifo[15][4] , \txfifo[15][3] , \txfifo[15][2] , \txfifo[15][1] ,
         \txfifo[15][0] , \txfifo[14][7] , \txfifo[14][6] , \txfifo[14][5] ,
         \txfifo[14][4] , \txfifo[14][3] , \txfifo[14][2] , \txfifo[14][1] ,
         \txfifo[14][0] , \txfifo[13][7] , \txfifo[13][6] , \txfifo[13][5] ,
         \txfifo[13][4] , \txfifo[13][3] , \txfifo[13][2] , \txfifo[13][1] ,
         \txfifo[13][0] , \txfifo[12][7] , \txfifo[12][6] , \txfifo[12][5] ,
         \txfifo[12][4] , \txfifo[12][3] , \txfifo[12][2] , \txfifo[12][1] ,
         \txfifo[12][0] , \txfifo[11][7] , \txfifo[11][6] , \txfifo[11][5] ,
         \txfifo[11][4] , \txfifo[11][3] , \txfifo[11][2] , \txfifo[11][1] ,
         \txfifo[11][0] , \txfifo[10][7] , \txfifo[10][6] , \txfifo[10][5] ,
         \txfifo[10][4] , \txfifo[10][3] , \txfifo[10][2] , \txfifo[10][1] ,
         \txfifo[10][0] , \txfifo[9][7] , \txfifo[9][6] , \txfifo[9][5] ,
         \txfifo[9][4] , \txfifo[9][3] , \txfifo[9][2] , \txfifo[9][1] ,
         \txfifo[9][0] , \txfifo[8][7] , \txfifo[8][6] , \txfifo[8][5] ,
         \txfifo[8][4] , \txfifo[8][3] , \txfifo[8][2] , \txfifo[8][1] ,
         \txfifo[8][0] , \txfifo[7][7] , \txfifo[7][6] , \txfifo[7][5] ,
         \txfifo[7][4] , \txfifo[7][3] , \txfifo[7][2] , \txfifo[7][1] ,
         \txfifo[7][0] , \txfifo[6][7] , \txfifo[6][6] , \txfifo[6][5] ,
         \txfifo[6][4] , \txfifo[6][3] , \txfifo[6][2] , \txfifo[6][1] ,
         \txfifo[6][0] , \txfifo[5][7] , \txfifo[5][6] , \txfifo[5][5] ,
         \txfifo[5][4] , \txfifo[5][3] , \txfifo[5][2] , \txfifo[5][1] ,
         \txfifo[5][0] , \txfifo[4][7] , \txfifo[4][6] , \txfifo[4][5] ,
         \txfifo[4][4] , \txfifo[4][3] , \txfifo[4][2] , \txfifo[4][1] ,
         \txfifo[4][0] , \txfifo[3][7] , \txfifo[3][6] , \txfifo[3][5] ,
         \txfifo[3][4] , \txfifo[3][3] , \txfifo[3][2] , \txfifo[3][1] ,
         \txfifo[3][0] , \txfifo[2][7] , \txfifo[2][6] , \txfifo[2][5] ,
         \txfifo[2][4] , \txfifo[2][3] , \txfifo[2][2] , \txfifo[2][1] ,
         \txfifo[2][0] , \txfifo[1][7] , \txfifo[1][6] , \txfifo[1][5] ,
         \txfifo[1][4] , \txfifo[1][3] , \txfifo[1][2] , \txfifo[1][1] ,
         \txfifo[1][0] , \txfifo[0][7] , \txfifo[0][6] , \txfifo[0][5] ,
         \txfifo[0][4] , \txfifo[0][3] , \txfifo[0][2] , \txfifo[0][1] ,
         \txfifo[0][0] , N504, N505, N506, N513, N522, N523, N524, n6, n9,
         n202, n203, n204, n205, n206, n207, n208, n209, n210, n211, n212,
         n213, n214, n215, n216, n217, n218, n219, n220, n221, n222, n223,
         n224, n225, n226, n227, n228, n229, n230, n231, n232, n233, n234,
         n235, n236, n237, n238, n239, n240, n241, n242, n243, n244, n245,
         n246, n247, n248, n249, n250, n251, n252, n253, n254, n255, n256,
         n257, n258, n259, n260, n261, n262, n263, n264, n265, n266, n267,
         n268, n269, n270, n271, n272, n273, n274, n275, n276, n277, n278,
         n279, n280, n281, n282, n283, n284, n285, n286, n287, n288, n289,
         n290, n291, n292, n293, n294, n295, n296, n297, n298, n299, n300,
         n301, n302, n303, n304, n305, n306, n307, n308, n309, n310, n311,
         n312, n313, n314, n315, n316, n317, n318, n319, n320, n321, n322,
         n323, n324, n325, n326, n327, n328, n329, n330, n331, n332, n333,
         n334, n335, n336, n337, n338, n339, n340, n341, n342, n343, n344,
         n345, n346, n347, n348, n349, n350, n351, n352, n353, n354, n355,
         n356, n357, n358, n359, n360, n361, n362, n363, n364, n365, n366,
         n367, n368, n369, n370, n371, n372, n373, n374, n375, n376, n377,
         n378, n379, n380, n381, n382, n383, n384, n385, n386, n387, n388,
         n389, n390, n391, n392, n393, n394, n395, n396, n397, n398, n399,
         n400, n401, n402, n403, n404, n405, n406, n407, n408, n409, n410,
         n411, n412, n413, n414, n415, n416, n417, n418, n419, n420, n421,
         n422, n423, n424, n425, n426, n427, n428, n429, n430, n431, n432,
         n433, n434, n435, n436, n437, n438, n439, n440, n441, n442, n443,
         n444, n445, n446, n447, n448, n449, n450, n451, n452, n453, n454,
         n455, n456, n457, n458, n459, n460, n461, n462, n463, n464, n465,
         n466, n467, n468, n469, n470, n471, n472, n473, n474, n475, n476,
         n477, n478, n479, n480, n481, n483, carry_4_, carry, carry0, carry_1_,
         n511, n610, n710, carry1, carry2, n1101, n2100, n3100, carry_3_,
         carry_2_, n1100, n2, n3, n489, n490, n491, n494, n496, n498, n499,
         n500, n501, n502, n503, n5040, n5050, n5060, n507, n508, n510, n5130,
         n514, n516, n518, n519, n520, n521, n5220, n5230, n5240, n525, n526,
         n527, n528, n529, n530, n531, n532, n533, n534, n535, n536, n537,
         n540, n543, n544, n545, n546, n547, n548, n549, n550, n551, n552,
         n553, n554, n555, n556, n557, n559, n560, n561, n565, n570, n573,
         n574, n575, n576, n578, n580, n582, n586, n589, n590, n591, n592,
         n595, n600, n605, n608, n609, n611, n612, n614, n615, n616, n619,
         n624, n627, n628, n629, n636, n639, n640, n641, n642, n645, n650,
         n655, n658, n659, n660, n661, n663, n664, n665, n668, n673, n676,
         n677, n678, n685, n688, n689, n690, n691, n694, n699, n704, n707,
         n708, n709, n711, n713, n714, n715, n718, n723, n726, n727, n728,
         n735, n738, n739, n740, n741, n744, n749, n754, n757, n758, n759,
         n760, n762, n763, n764, n767, n772, n775, n776, n777, n784, n787,
         n788, n789, n790, n793, n798, n803, n806, n807, n808, n809, n811,
         n812, n813, n816, n821, n824, n825, n826, n833, n836, n837, n838,
         n839, n842, n847, n852, n855, n856, n857, n858, n860, n861, n862,
         n866, n871, n874, n875, n876, n883, n886, n887, n888, n889, n892,
         n895, n896, n897, n898, n899, n900, n903, n906, n907, n910, n913,
         n916, n918, n922, n923, n924, n926, n928, n930, n931, n933, n934,
         n936, n937, n938, n939, n940, n941, n943, n945, n946, n947, n948,
         n949, n950, n951, n952, n953, n954, n955, n956, n957, n958, n959,
         n960, n961, n962, n963, n965, n966, n967, n969, n970, n971, n973,
         n974, n975, n977, n978, n979, n981, n982, n983, n985, n986, n987,
         n989, n990, n991, n992, n993, n994, n995, n996, n997, n998, n999,
         n1000, n1001, n1002, n1003, n1004, n1005, n1006, n1007, n1009, n1010,
         n1011, n1012, n1013, n1014, n1015, n1016, n1017, n1018, n1019, n1020,
         n1021, n1022, n1023, n1024, n1025, n1026, n1027, n1028, n1029, n1030,
         n1032, n1033, n1034, n1035, n1036, n1037, n1038, n1039, n1040, n1041,
         n1042, n1043, n1044, n1045, n1046, n1047, n1048, n1049, n1051, n1053,
         n1054, n1055, n1056, n1059, n1060, n1061, n1063, n1066, n1067, n1068,
         n1069, n1070, n1071, n1072, n1073, n1074, n1075, n1076, n1078, n1083,
         n1085, n1086, n1087, n1088, n1091, n1093, n1094, n1095, n1097, n1098,
         n1099, n1103, n1104, n1106, n1107, n1108, n1109, n1110, n1111, n1112,
         n1113, n1114, n1115, n1116, n1117, n1118, n1119, n1120, n1121, n1122,
         n1123, n1124, n1125, n1126, n1127, n1128, n1129, n1130, n1131, n1132,
         n1133, n1134, n1135, n1136, n1137, n1138, n1139, n1140, n1141, n1142,
         n1143, n1144, n1145, n1146, n1147, n1148, n1149, n1150, n1151, n1152,
         n1153, n1154, n1155, n1156, n1157, n1158, n1159, n1160, n1161, n1162,
         n1163, n1164, n1165, n1166, n1167, n1168, n1169, n1170, n1171, n1172,
         n1173, n1174, n1175, n1176, n1177, n1178, n1179, n1180, n1181, n1182,
         n1183, n1184, n1185, n1186, n1187, n1188, n1189, n1190, n1191, n1192,
         n1193, n1194, n1195, n1196, n1197, n1198, n1199, n1200, n1201, n1202,
         n1203, n1204, n1205, n1206, n1207, n1208, n1209, n1210, n1211, n1212,
         n1213, n1214, n1215, n1216, n1217, n1218, n1219, n1220, n1221, n1222,
         n1223, n1224, n1225, n1226, n1227, n1229, n1230, n1231, n1232, n1233,
         n1234, n1235, n1236, n1237, n1238, n1239, n1240, n1241, n1242, n1243,
         n1244, n1245, n1246, n1247, n1248, n1249, n1250, n1251, n1252, n1253,
         n1254, n1255, n1256, n1257, n1258, n1259, n1260, n1261, n1262, n1263,
         n1264, n1265, n1266, n1267, n1268, n1269, n1270, n1271, n1272, n1273,
         n1274, n1275, n1276, n1277, n1278, n1279, n1280, n1281, n1282, n1283,
         n1284, n1285, n1286, n1287, n1288, n1289, n1290, n1291, n1292, n1293,
         n1294, n1295, n1296, n1297, n1298, n1299, n1300, n1301, n1302, n1303,
         n1304, n1305, n1306, n1307, n1308, n1309, n1310, n1311, n1312, n1313,
         n1314, n1315, n1316, n1317, n1318, n1319, n1320, n1321, n1322, n1323,
         n1324, n1325, n1326, n1327, n1328, n1329, n1330, n1331, n1332, n1333,
         n1334, n1335, n1336, n1337, n1338, n1339, n1340, n1341, n1342, n1343,
         n1344, n1345, n1346, n1347, n1348, n1349, n1350, n1351, n1352;
  wire   [3:0] txclkcnt;

  AHHCONX2 U1_1_11 ( .A(n1352), .CI(n1351), .S(N504), .CON(n3100) );
  AHHCONX2 U1_1_21 ( .A(fifo_wrpos_2_), .CI(carry2), .S(N505), .CON(n2100) );
  AHHCONX2 U1_1_31 ( .A(fifo_wrpos_3_), .CI(carry1), .S(N506), .CON(n1101) );
  AHHCONX2 U1_1_1 ( .A(N75), .CI(N74), .S(N522), .CON(n3) );
  AHHCONX2 U1_1_2 ( .A(N76), .CI(carry_2_), .S(N523), .CON(n2) );
  AHHCONX2 U1_1_3 ( .A(N77), .CI(carry_3_), .S(N524), .CON(n1100) );
  INVX1 U1441 ( .A(n1035), .Y(n1036) );
  INVX1 U1442 ( .A(n1032), .Y(n1033) );
  INVX1 U1443 ( .A(n1015), .Y(n1016) );
  INVX1 U1444 ( .A(n1012), .Y(n1013) );
  INVX1 U1445 ( .A(n996), .Y(n997) );
  INVX1 U1446 ( .A(n993), .Y(n994) );
  INVX1 U1447 ( .A(n1037), .Y(n1038) );
  INVX1 U1448 ( .A(n1017), .Y(n1018) );
  INVX1 U1449 ( .A(n998), .Y(n999) );
  INVX1 U1450 ( .A(n1045), .Y(n1046) );
  INVX1 U1451 ( .A(n1043), .Y(n1044) );
  INVX1 U1452 ( .A(n1041), .Y(n1042) );
  INVX1 U1453 ( .A(n1039), .Y(n1040) );
  INVX1 U1454 ( .A(n1025), .Y(n1026) );
  INVX1 U1455 ( .A(n1023), .Y(n1024) );
  INVX1 U1456 ( .A(n1021), .Y(n1022) );
  INVX1 U1457 ( .A(n1019), .Y(n1020) );
  INVX1 U1458 ( .A(n1006), .Y(n1007) );
  INVX1 U1459 ( .A(n1004), .Y(n1005) );
  INVX1 U1460 ( .A(n1002), .Y(n1003) );
  INVX1 U1461 ( .A(n1000), .Y(n1001) );
  INVX1 U1462 ( .A(n1027), .Y(n1028) );
  INVX1 U1463 ( .A(n1009), .Y(n1010) );
  INVX1 U1464 ( .A(n990), .Y(n991) );
  INVX1 U1465 ( .A(n986), .Y(n987) );
  INVX1 U1466 ( .A(n982), .Y(n983) );
  INVX1 U1467 ( .A(n978), .Y(n979) );
  INVX1 U1468 ( .A(n974), .Y(n975) );
  INVX1 U1469 ( .A(n970), .Y(n971) );
  INVX1 U1470 ( .A(n966), .Y(n967) );
  INVX1 U1471 ( .A(n962), .Y(n963) );
  INVX1 U1472 ( .A(n958), .Y(n959) );
  INVX1 U1473 ( .A(fifowrb), .Y(n946) );
  NAND2BX1 U1474 ( .AN(n1063), .B(n1068), .Y(N111) );
  INVX1 U1475 ( .A(N118), .Y(n1068) );
  INVX1 U1476 ( .A(txfifocnt[1]), .Y(n957) );
  INVX1 U1477 ( .A(n578), .Y(n531) );
  INVX1 U1478 ( .A(n576), .Y(n532) );
  INVX1 U1479 ( .A(n580), .Y(n528) );
  INVX1 U1480 ( .A(n582), .Y(n529) );
  INVX1 U1481 ( .A(n547), .Y(n518) );
  INVX1 U1482 ( .A(n552), .Y(n5230) );
  INVX1 U1483 ( .A(txfifocnt[0]), .Y(n953) );
  INVX1 U1484 ( .A(n545), .Y(n521) );
  INVX1 U1485 ( .A(n550), .Y(n526) );
  INVX1 U1486 ( .A(n544), .Y(n5220) );
  INVX1 U1487 ( .A(n549), .Y(n527) );
  INVX1 U1488 ( .A(n1349), .Y(n519) );
  INVX1 U1489 ( .A(n1350), .Y(n5240) );
  NAND2BX1 U1490 ( .AN(n1029), .B(n961), .Y(n1027) );
  NAND2BX1 U1491 ( .AN(n1011), .B(n961), .Y(n1009) );
  NAND2BX1 U1492 ( .AN(n992), .B(n961), .Y(n990) );
  OR2X1 U1493 ( .A(n960), .B(n989), .Y(n986) );
  OR2X1 U1494 ( .A(n960), .B(n985), .Y(n982) );
  OR2X1 U1495 ( .A(n960), .B(n981), .Y(n978) );
  OR2X1 U1496 ( .A(n960), .B(n977), .Y(n974) );
  OR2X1 U1497 ( .A(n960), .B(n973), .Y(n970) );
  OR2X1 U1498 ( .A(n960), .B(n969), .Y(n966) );
  OR2X1 U1499 ( .A(n960), .B(n965), .Y(n962) );
  NAND2BX1 U1500 ( .AN(n960), .B(n961), .Y(n958) );
  NAND2BX1 U1501 ( .AN(n989), .B(n1034), .Y(n1045) );
  NAND2BX1 U1502 ( .AN(n985), .B(n1034), .Y(n1043) );
  NAND2BX1 U1503 ( .AN(n981), .B(n1034), .Y(n1041) );
  NAND2BX1 U1504 ( .AN(n977), .B(n1034), .Y(n1039) );
  NAND2BX1 U1505 ( .AN(n973), .B(n1034), .Y(n1037) );
  NAND2BX1 U1506 ( .AN(n969), .B(n1034), .Y(n1035) );
  NAND2BX1 U1507 ( .AN(n965), .B(n1034), .Y(n1032) );
  NAND2BX1 U1508 ( .AN(n989), .B(n1014), .Y(n1025) );
  NAND2BX1 U1509 ( .AN(n985), .B(n1014), .Y(n1023) );
  NAND2BX1 U1510 ( .AN(n981), .B(n1014), .Y(n1021) );
  NAND2BX1 U1511 ( .AN(n977), .B(n1014), .Y(n1019) );
  NAND2BX1 U1512 ( .AN(n973), .B(n1014), .Y(n1017) );
  NAND2BX1 U1513 ( .AN(n969), .B(n1014), .Y(n1015) );
  NAND2BX1 U1514 ( .AN(n965), .B(n1014), .Y(n1012) );
  NAND2BX1 U1515 ( .AN(n989), .B(n995), .Y(n1006) );
  NAND2BX1 U1516 ( .AN(n985), .B(n995), .Y(n1004) );
  NAND2BX1 U1517 ( .AN(n981), .B(n995), .Y(n1002) );
  NAND2BX1 U1518 ( .AN(n977), .B(n995), .Y(n1000) );
  NAND2BX1 U1519 ( .AN(n973), .B(n995), .Y(n998) );
  NAND2BX1 U1520 ( .AN(n969), .B(n995), .Y(n996) );
  NAND2BX1 U1521 ( .AN(n965), .B(n995), .Y(n993) );
  INVX1 U1522 ( .A(n1011), .Y(n1014) );
  INVX1 U1523 ( .A(n992), .Y(n995) );
  INVX1 U1524 ( .A(n1029), .Y(n1034) );
  INVX1 U1525 ( .A(n940), .Y(n943) );
  AFHCONX2 U2_1 ( .A(n1352), .B(n1223), .CI(carry_1_), .S(txfifocnt[1]), .CON(
        n710) );
  OR2X1 U1526 ( .A(N116), .B(n1069), .Y(N112) );
  OAI221X1 U1527 ( .A0(uarten), .A1(n1093), .B0(txfifo_emptyb), .B1(n1093), 
        .C0(n937), .Y(N118) );
  INVX1 U1528 ( .A(n1066), .Y(n1093) );
  NAND3BX1 U1529 ( .AN(n1071), .B(n1070), .C(n1083), .Y(N110) );
  INVX1 U1530 ( .A(N112), .Y(n1083) );
  INVX1 U1531 ( .A(txfifocnt[4]), .Y(n1097) );
  NAND2BX1 U1532 ( .AN(n1066), .B(n1068), .Y(N116) );
  INVX1 U1533 ( .A(n949), .Y(n951) );
  AND4X1 U1534 ( .A(uarten), .B(n1066), .C(txfifo_emptyb), .D(n937), .Y(n1343)
         );
  AO21X1 U1535 ( .A0(n1063), .A1(n937), .B0(n1343), .Y(N117) );
  NAND2BX1 U1536 ( .AN(n897), .B(n896), .Y(n552) );
  NAND2BX1 U1537 ( .AN(n897), .B(n906), .Y(n547) );
  OR2X1 U1538 ( .A(n897), .B(n913), .Y(n514) );
  OR2X1 U1539 ( .A(n913), .B(n895), .Y(n516) );
  NAND2BX1 U1540 ( .AN(n900), .B(n1345), .Y(n576) );
  NAND2BX1 U1541 ( .AN(n897), .B(n1345), .Y(n580) );
  NAND2BX1 U1542 ( .AN(n916), .B(n1345), .Y(n578) );
  NAND2BX1 U1543 ( .AN(n895), .B(n1345), .Y(n582) );
  NAND2BX1 U1544 ( .AN(n898), .B(n899), .Y(n550) );
  NAND2BX1 U1545 ( .AN(n907), .B(n899), .Y(n545) );
  NAND2BX1 U1546 ( .AN(n900), .B(n896), .Y(n549) );
  NAND2BX1 U1547 ( .AN(n900), .B(n906), .Y(n544) );
  OAI2BB1X1 U1548 ( .A0N(n1351), .A1N(n1227), .B0(carry_1_), .Y(txfifocnt[0])
         );
  NAND2BX1 U1549 ( .AN(n913), .B(n899), .Y(n510) );
  OR2X1 U1550 ( .A(n913), .B(n900), .Y(n508) );
  AO21X1 U1551 ( .A0(n930), .A1(n1110), .B0(n934), .Y(n931) );
  NAND4BX1 U1552 ( .AN(n1069), .B(n1067), .C(n1054), .D(n1070), .Y(n1063) );
  BUFX2 U1553 ( .A(n551), .Y(n1350) );
  NAND2BX1 U1554 ( .AN(n895), .B(n896), .Y(n551) );
  BUFX2 U1555 ( .A(n546), .Y(n1349) );
  NAND2BX1 U1556 ( .AN(n895), .B(n906), .Y(n546) );
  NAND3BX1 U1557 ( .AN(n874), .B(n875), .C(n876), .Y(n860) );
  OA22X1 U1558 ( .A0(n580), .A1(n1166), .B0(n582), .B1(n1286), .Y(n875) );
  OA22X1 U1559 ( .A0(n576), .A1(n1165), .B0(n578), .B1(n1285), .Y(n876) );
  OAI221X1 U1560 ( .A0(n549), .A1(n1117), .B0(n550), .B1(n1235), .C0(n883), 
        .Y(n874) );
  NAND3BX1 U1561 ( .AN(n824), .B(n825), .C(n826), .Y(n811) );
  OA22X1 U1562 ( .A0(n580), .A1(n1168), .B0(n582), .B1(n1288), .Y(n825) );
  OA22X1 U1563 ( .A0(n576), .A1(n1167), .B0(n578), .B1(n1287), .Y(n826) );
  OAI221X1 U1564 ( .A0(n549), .A1(n1118), .B0(n550), .B1(n1236), .C0(n833), 
        .Y(n824) );
  NAND3BX1 U1565 ( .AN(n775), .B(n776), .C(n777), .Y(n762) );
  OA22X1 U1566 ( .A0(n580), .A1(n1170), .B0(n582), .B1(n1290), .Y(n776) );
  OA22X1 U1567 ( .A0(n576), .A1(n1169), .B0(n578), .B1(n1289), .Y(n777) );
  OAI221X1 U1568 ( .A0(n549), .A1(n1119), .B0(n550), .B1(n1237), .C0(n784), 
        .Y(n775) );
  NAND3BX1 U1569 ( .AN(n726), .B(n727), .C(n728), .Y(n713) );
  OA22X1 U1570 ( .A0(n580), .A1(n1172), .B0(n582), .B1(n1292), .Y(n727) );
  OA22X1 U1571 ( .A0(n576), .A1(n1171), .B0(n578), .B1(n1291), .Y(n728) );
  OAI221X1 U1572 ( .A0(n549), .A1(n1120), .B0(n550), .B1(n1238), .C0(n735), 
        .Y(n726) );
  NAND3BX1 U1573 ( .AN(n676), .B(n677), .C(n678), .Y(n663) );
  OA22X1 U1574 ( .A0(n580), .A1(n1174), .B0(n582), .B1(n1294), .Y(n677) );
  OA22X1 U1575 ( .A0(n576), .A1(n1173), .B0(n578), .B1(n1293), .Y(n678) );
  OAI221X1 U1576 ( .A0(n549), .A1(n1121), .B0(n550), .B1(n1239), .C0(n685), 
        .Y(n676) );
  NAND3BX1 U1577 ( .AN(n627), .B(n628), .C(n629), .Y(n614) );
  OA22X1 U1578 ( .A0(n580), .A1(n1176), .B0(n582), .B1(n1296), .Y(n628) );
  OA22X1 U1579 ( .A0(n576), .A1(n1175), .B0(n578), .B1(n1295), .Y(n629) );
  OAI221X1 U1580 ( .A0(n549), .A1(n1122), .B0(n550), .B1(n1240), .C0(n636), 
        .Y(n627) );
  NAND3BX1 U1581 ( .AN(n573), .B(n574), .C(n575), .Y(n559) );
  OA22X1 U1582 ( .A0(n580), .A1(n1178), .B0(n582), .B1(n1298), .Y(n574) );
  OA22X1 U1583 ( .A0(n576), .A1(n1177), .B0(n578), .B1(n1297), .Y(n575) );
  OAI221X1 U1584 ( .A0(n549), .A1(n1123), .B0(n550), .B1(n1241), .C0(n586), 
        .Y(n573) );
  AO21X1 U1585 ( .A0(n930), .A1(n1232), .B0(n931), .Y(n922) );
  INVX1 U1586 ( .A(n924), .Y(n930) );
  INVX1 U1587 ( .A(n916), .Y(n899) );
  INVX1 U1588 ( .A(n907), .Y(n906) );
  INVX1 U1589 ( .A(n898), .Y(n896) );
  INVX1 U1590 ( .A(n936), .Y(n934) );
  OAI211X1 U1591 ( .A0(n856), .A1(n555), .B0(n857), .C0(n858), .Y(n473) );
  OA22X1 U1592 ( .A0(n1284), .A1(n499), .B0(n498), .B1(n1161), .Y(n858) );
  NOR4BX1 U1593 ( .AN(n886), .B(n887), .C(n888), .D(n889), .Y(n856) );
  OAI31X1 U1594 ( .A0(n860), .A1(n861), .A2(n862), .B0(n1347), .Y(n857) );
  OAI211X1 U1595 ( .A0(n807), .A1(n555), .B0(n808), .C0(n809), .Y(n474) );
  OA22X1 U1596 ( .A0(n499), .A1(n1161), .B0(n498), .B1(n1279), .Y(n809) );
  NOR4BX1 U1597 ( .AN(n836), .B(n837), .C(n838), .D(n839), .Y(n807) );
  OAI31X1 U1598 ( .A0(n811), .A1(n812), .A2(n813), .B0(n1347), .Y(n808) );
  OAI211X1 U1599 ( .A0(n758), .A1(n555), .B0(n759), .C0(n760), .Y(n475) );
  OA22X1 U1600 ( .A0(n499), .A1(n1279), .B0(n498), .B1(n1162), .Y(n760) );
  NOR4BX1 U1601 ( .AN(n787), .B(n788), .C(n789), .D(n790), .Y(n758) );
  OAI31X1 U1602 ( .A0(n762), .A1(n763), .A2(n764), .B0(n1347), .Y(n759) );
  OAI211X1 U1603 ( .A0(n708), .A1(n555), .B0(n709), .C0(n711), .Y(n476) );
  OA22X1 U1604 ( .A0(n499), .A1(n1162), .B0(n498), .B1(n1280), .Y(n711) );
  NOR4BX1 U1605 ( .AN(n738), .B(n739), .C(n740), .D(n741), .Y(n708) );
  OAI31X1 U1606 ( .A0(n713), .A1(n714), .A2(n715), .B0(n1347), .Y(n709) );
  OAI211X1 U1607 ( .A0(n659), .A1(n555), .B0(n660), .C0(n661), .Y(n477) );
  OA22X1 U1608 ( .A0(n499), .A1(n1280), .B0(n498), .B1(n1163), .Y(n661) );
  NOR4BX1 U1609 ( .AN(n688), .B(n689), .C(n690), .D(n691), .Y(n659) );
  OAI31X1 U1610 ( .A0(n663), .A1(n664), .A2(n665), .B0(n1347), .Y(n660) );
  OAI211X1 U1611 ( .A0(n609), .A1(n555), .B0(n611), .C0(n612), .Y(n478) );
  OA22X1 U1612 ( .A0(n499), .A1(n1163), .B0(n498), .B1(n1281), .Y(n612) );
  NOR4BX1 U1613 ( .AN(n639), .B(n640), .C(n641), .D(n642), .Y(n609) );
  OAI31X1 U1614 ( .A0(n614), .A1(n615), .A2(n616), .B0(n1347), .Y(n611) );
  OAI211X1 U1615 ( .A0(n554), .A1(n555), .B0(n556), .C0(n557), .Y(n479) );
  OA22X1 U1616 ( .A0(n499), .A1(n1281), .B0(n1115), .B1(n498), .Y(n557) );
  NOR4BX1 U1617 ( .AN(n589), .B(n590), .C(n591), .D(n592), .Y(n554) );
  OAI31X1 U1618 ( .A0(n559), .A1(n560), .A2(n561), .B0(n1347), .Y(n556) );
  INVX1 U1619 ( .A(n1055), .Y(n1075) );
  NAND2BX1 U1620 ( .AN(n1348), .B(n498), .Y(n499) );
  NOR2BX1 U1621 ( .AN(n937), .B(n1054), .Y(N130) );
  NOR2BX1 U1622 ( .AN(n937), .B(n1067), .Y(N114) );
  NOR2BX1 U1623 ( .AN(n937), .B(n1053), .Y(N131) );
  INVX1 U1624 ( .A(n1051), .Y(n1060) );
  INVX1 U1625 ( .A(n1048), .Y(n1059) );
  OAI32X1 U1626 ( .A0(n1048), .A1(n1049), .A2(n1107), .B0(n1051), .B1(n1111), 
        .Y(N132) );
  INVX1 U1627 ( .A(n1061), .Y(n1070) );
  INVX1 U1628 ( .A(n1071), .Y(n1054) );
  INVX1 U1629 ( .A(txfifo_emptyb), .Y(txfifo_fillb) );
  NAND3BX1 U1630 ( .AN(txfifocnt[5]), .B(n946), .C(n937), .Y(n940) );
  NAND3BX1 U1631 ( .AN(fifo_wrpos_3_), .B(n1344), .C(n946), .Y(n1029) );
  NAND3BX1 U1632 ( .AN(fifowrb), .B(n1344), .C(fifo_wrpos_3_), .Y(n1011) );
  OR3X2 U1633 ( .A(fifowrb), .B(fifo_wrpos_3_), .C(n1344), .Y(n992) );
  NAND3BX1 U1634 ( .AN(fifowrb), .B(fifo_wrpos_3_), .C(fifo_wrpos_4_), .Y(n960) );
  AO22X1 U1635 ( .A0(\txfifo[31][0] ), .A1(n958), .B0(fifodata_tx[0]), .B1(
        n959), .Y(n450) );
  AO22X1 U1636 ( .A0(\txfifo[31][1] ), .A1(n958), .B0(fifodata_tx[1]), .B1(
        n959), .Y(n451) );
  AO22X1 U1637 ( .A0(\txfifo[31][2] ), .A1(n958), .B0(fifodata_tx[2]), .B1(
        n959), .Y(n452) );
  AO22X1 U1638 ( .A0(\txfifo[31][3] ), .A1(n958), .B0(fifodata_tx[3]), .B1(
        n959), .Y(n453) );
  AO22X1 U1639 ( .A0(\txfifo[31][4] ), .A1(n958), .B0(fifodata_tx[4]), .B1(
        n959), .Y(n454) );
  AO22X1 U1640 ( .A0(\txfifo[31][5] ), .A1(n958), .B0(fifodata_tx[5]), .B1(
        n959), .Y(n455) );
  AO22X1 U1641 ( .A0(\txfifo[31][6] ), .A1(n958), .B0(fifodata_tx[6]), .B1(
        n959), .Y(n456) );
  AO22X1 U1642 ( .A0(\txfifo[31][7] ), .A1(n958), .B0(fifodata_tx[7]), .B1(
        n959), .Y(n457) );
  AO22X1 U1643 ( .A0(\txfifo[0][0] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[0]), .Y(n202) );
  AO22X1 U1644 ( .A0(\txfifo[0][1] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[1]), .Y(n203) );
  AO22X1 U1645 ( .A0(\txfifo[0][2] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[2]), .Y(n204) );
  AO22X1 U1646 ( .A0(\txfifo[0][3] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[3]), .Y(n205) );
  AO22X1 U1647 ( .A0(\txfifo[0][4] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[4]), .Y(n206) );
  AO22X1 U1648 ( .A0(\txfifo[0][5] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[5]), .Y(n207) );
  AO22X1 U1649 ( .A0(\txfifo[0][6] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[6]), .Y(n208) );
  AO22X1 U1650 ( .A0(\txfifo[0][7] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[7]), .Y(n209) );
  AO22X1 U1651 ( .A0(\txfifo[1][0] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[0]), .Y(n210) );
  AO22X1 U1652 ( .A0(\txfifo[1][1] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[1]), .Y(n211) );
  AO22X1 U1653 ( .A0(\txfifo[1][2] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[2]), .Y(n212) );
  AO22X1 U1654 ( .A0(\txfifo[1][3] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[3]), .Y(n213) );
  AO22X1 U1655 ( .A0(\txfifo[1][4] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[4]), .Y(n214) );
  AO22X1 U1656 ( .A0(\txfifo[1][5] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[5]), .Y(n215) );
  AO22X1 U1657 ( .A0(\txfifo[1][6] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[6]), .Y(n216) );
  AO22X1 U1658 ( .A0(\txfifo[1][7] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[7]), .Y(n217) );
  AO22X1 U1659 ( .A0(\txfifo[2][0] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[0]), .Y(n218) );
  AO22X1 U1660 ( .A0(\txfifo[2][1] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[1]), .Y(n219) );
  AO22X1 U1661 ( .A0(\txfifo[2][2] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[2]), .Y(n220) );
  AO22X1 U1662 ( .A0(\txfifo[2][3] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[3]), .Y(n221) );
  AO22X1 U1663 ( .A0(\txfifo[2][4] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[4]), .Y(n222) );
  AO22X1 U1664 ( .A0(\txfifo[2][5] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[5]), .Y(n223) );
  AO22X1 U1665 ( .A0(\txfifo[2][6] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[6]), .Y(n224) );
  AO22X1 U1666 ( .A0(\txfifo[2][7] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[7]), .Y(n225) );
  AO22X1 U1667 ( .A0(\txfifo[3][0] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[0]), .Y(n226) );
  AO22X1 U1668 ( .A0(\txfifo[3][1] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[1]), .Y(n227) );
  AO22X1 U1669 ( .A0(\txfifo[3][2] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[2]), .Y(n228) );
  AO22X1 U1670 ( .A0(\txfifo[3][3] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[3]), .Y(n229) );
  AO22X1 U1671 ( .A0(\txfifo[3][4] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[4]), .Y(n230) );
  AO22X1 U1672 ( .A0(\txfifo[3][5] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[5]), .Y(n231) );
  AO22X1 U1673 ( .A0(\txfifo[3][6] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[6]), .Y(n232) );
  AO22X1 U1674 ( .A0(\txfifo[3][7] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[7]), .Y(n233) );
  AO22X1 U1675 ( .A0(\txfifo[4][0] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[0]), .Y(n234) );
  AO22X1 U1676 ( .A0(\txfifo[4][1] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[1]), .Y(n235) );
  AO22X1 U1677 ( .A0(\txfifo[4][2] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[2]), .Y(n236) );
  AO22X1 U1678 ( .A0(\txfifo[4][3] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[3]), .Y(n237) );
  AO22X1 U1679 ( .A0(\txfifo[4][4] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[4]), .Y(n238) );
  AO22X1 U1680 ( .A0(\txfifo[4][5] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[5]), .Y(n239) );
  AO22X1 U1681 ( .A0(\txfifo[4][6] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[6]), .Y(n240) );
  AO22X1 U1682 ( .A0(\txfifo[4][7] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[7]), .Y(n241) );
  AO22X1 U1683 ( .A0(\txfifo[5][0] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[0]), .Y(n242) );
  AO22X1 U1684 ( .A0(\txfifo[5][1] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[1]), .Y(n243) );
  AO22X1 U1685 ( .A0(\txfifo[5][2] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[2]), .Y(n244) );
  AO22X1 U1686 ( .A0(\txfifo[5][3] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[3]), .Y(n245) );
  AO22X1 U1687 ( .A0(\txfifo[5][4] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[4]), .Y(n246) );
  AO22X1 U1688 ( .A0(\txfifo[5][5] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[5]), .Y(n247) );
  AO22X1 U1689 ( .A0(\txfifo[5][6] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[6]), .Y(n248) );
  AO22X1 U1690 ( .A0(\txfifo[5][7] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[7]), .Y(n249) );
  AO22X1 U1691 ( .A0(\txfifo[6][0] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[0]), .Y(n250) );
  AO22X1 U1692 ( .A0(\txfifo[6][1] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[1]), .Y(n251) );
  AO22X1 U1693 ( .A0(\txfifo[6][2] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[2]), .Y(n252) );
  AO22X1 U1694 ( .A0(\txfifo[6][3] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[3]), .Y(n253) );
  AO22X1 U1695 ( .A0(\txfifo[6][4] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[4]), .Y(n254) );
  AO22X1 U1696 ( .A0(\txfifo[6][5] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[5]), .Y(n255) );
  AO22X1 U1697 ( .A0(\txfifo[6][6] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[6]), .Y(n256) );
  AO22X1 U1698 ( .A0(\txfifo[6][7] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[7]), .Y(n257) );
  AO22X1 U1699 ( .A0(\txfifo[7][0] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[0]), .Y(n258) );
  AO22X1 U1700 ( .A0(\txfifo[7][1] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[1]), .Y(n259) );
  AO22X1 U1701 ( .A0(\txfifo[7][2] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[2]), .Y(n260) );
  AO22X1 U1702 ( .A0(\txfifo[7][3] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[3]), .Y(n261) );
  AO22X1 U1703 ( .A0(\txfifo[7][4] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[4]), .Y(n262) );
  AO22X1 U1704 ( .A0(\txfifo[7][5] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[5]), .Y(n263) );
  AO22X1 U1705 ( .A0(\txfifo[7][6] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[6]), .Y(n264) );
  AO22X1 U1706 ( .A0(\txfifo[7][7] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[7]), .Y(n265) );
  AO22X1 U1707 ( .A0(\txfifo[8][0] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[0]), .Y(n266) );
  AO22X1 U1708 ( .A0(\txfifo[8][1] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[1]), .Y(n267) );
  AO22X1 U1709 ( .A0(\txfifo[8][2] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[2]), .Y(n268) );
  AO22X1 U1710 ( .A0(\txfifo[8][3] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[3]), .Y(n269) );
  AO22X1 U1711 ( .A0(\txfifo[8][4] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[4]), .Y(n270) );
  AO22X1 U1712 ( .A0(\txfifo[8][5] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[5]), .Y(n271) );
  AO22X1 U1713 ( .A0(\txfifo[8][6] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[6]), .Y(n272) );
  AO22X1 U1714 ( .A0(\txfifo[8][7] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[7]), .Y(n273) );
  AO22X1 U1715 ( .A0(\txfifo[9][0] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[0]), .Y(n274) );
  AO22X1 U1716 ( .A0(\txfifo[9][1] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[1]), .Y(n275) );
  AO22X1 U1717 ( .A0(\txfifo[9][2] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[2]), .Y(n276) );
  AO22X1 U1718 ( .A0(\txfifo[9][3] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[3]), .Y(n277) );
  AO22X1 U1719 ( .A0(\txfifo[9][4] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[4]), .Y(n278) );
  AO22X1 U1720 ( .A0(\txfifo[9][5] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[5]), .Y(n279) );
  AO22X1 U1721 ( .A0(\txfifo[9][6] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[6]), .Y(n280) );
  AO22X1 U1722 ( .A0(\txfifo[9][7] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[7]), .Y(n281) );
  AO22X1 U1723 ( .A0(\txfifo[10][0] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[0]), .Y(n282) );
  AO22X1 U1724 ( .A0(\txfifo[10][1] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[1]), .Y(n283) );
  AO22X1 U1725 ( .A0(\txfifo[10][2] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[2]), .Y(n284) );
  AO22X1 U1726 ( .A0(\txfifo[10][3] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[3]), .Y(n285) );
  AO22X1 U1727 ( .A0(\txfifo[10][4] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[4]), .Y(n286) );
  AO22X1 U1728 ( .A0(\txfifo[10][5] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[5]), .Y(n287) );
  AO22X1 U1729 ( .A0(\txfifo[10][6] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[6]), .Y(n288) );
  AO22X1 U1730 ( .A0(\txfifo[10][7] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[7]), .Y(n289) );
  AO22X1 U1731 ( .A0(\txfifo[11][0] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[0]), .Y(n290) );
  AO22X1 U1732 ( .A0(\txfifo[11][1] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[1]), .Y(n291) );
  AO22X1 U1733 ( .A0(\txfifo[11][2] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[2]), .Y(n292) );
  AO22X1 U1734 ( .A0(\txfifo[11][3] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[3]), .Y(n293) );
  AO22X1 U1735 ( .A0(\txfifo[11][4] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[4]), .Y(n294) );
  AO22X1 U1736 ( .A0(\txfifo[11][5] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[5]), .Y(n295) );
  AO22X1 U1737 ( .A0(\txfifo[11][6] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[6]), .Y(n296) );
  AO22X1 U1738 ( .A0(\txfifo[11][7] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[7]), .Y(n297) );
  AO22X1 U1739 ( .A0(\txfifo[12][0] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[0]), .Y(n298) );
  AO22X1 U1740 ( .A0(\txfifo[12][1] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[1]), .Y(n299) );
  AO22X1 U1741 ( .A0(\txfifo[12][2] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[2]), .Y(n300) );
  AO22X1 U1742 ( .A0(\txfifo[12][3] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[3]), .Y(n301) );
  AO22X1 U1743 ( .A0(\txfifo[12][4] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[4]), .Y(n302) );
  AO22X1 U1744 ( .A0(\txfifo[12][5] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[5]), .Y(n303) );
  AO22X1 U1745 ( .A0(\txfifo[12][6] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[6]), .Y(n304) );
  AO22X1 U1746 ( .A0(\txfifo[12][7] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[7]), .Y(n305) );
  AO22X1 U1747 ( .A0(\txfifo[13][0] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[0]), .Y(n306) );
  AO22X1 U1748 ( .A0(\txfifo[13][1] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[1]), .Y(n307) );
  AO22X1 U1749 ( .A0(\txfifo[13][2] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[2]), .Y(n308) );
  AO22X1 U1750 ( .A0(\txfifo[13][3] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[3]), .Y(n309) );
  AO22X1 U1751 ( .A0(\txfifo[13][4] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[4]), .Y(n310) );
  AO22X1 U1752 ( .A0(\txfifo[13][5] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[5]), .Y(n311) );
  AO22X1 U1753 ( .A0(\txfifo[13][6] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[6]), .Y(n312) );
  AO22X1 U1754 ( .A0(\txfifo[13][7] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[7]), .Y(n313) );
  AO22X1 U1755 ( .A0(\txfifo[14][0] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[0]), .Y(n314) );
  AO22X1 U1756 ( .A0(\txfifo[14][1] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[1]), .Y(n315) );
  AO22X1 U1757 ( .A0(\txfifo[14][2] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[2]), .Y(n316) );
  AO22X1 U1758 ( .A0(\txfifo[14][3] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[3]), .Y(n317) );
  AO22X1 U1759 ( .A0(\txfifo[14][4] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[4]), .Y(n318) );
  AO22X1 U1760 ( .A0(\txfifo[14][5] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[5]), .Y(n319) );
  AO22X1 U1761 ( .A0(\txfifo[14][6] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[6]), .Y(n320) );
  AO22X1 U1762 ( .A0(\txfifo[14][7] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[7]), .Y(n321) );
  AO22X1 U1763 ( .A0(\txfifo[15][0] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[0]), .Y(n322) );
  AO22X1 U1764 ( .A0(\txfifo[15][1] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[1]), .Y(n323) );
  AO22X1 U1765 ( .A0(\txfifo[15][2] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[2]), .Y(n324) );
  AO22X1 U1766 ( .A0(\txfifo[15][3] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[3]), .Y(n325) );
  AO22X1 U1767 ( .A0(\txfifo[15][4] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[4]), .Y(n326) );
  AO22X1 U1768 ( .A0(\txfifo[15][5] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[5]), .Y(n327) );
  AO22X1 U1769 ( .A0(\txfifo[15][6] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[6]), .Y(n328) );
  AO22X1 U1770 ( .A0(\txfifo[15][7] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[7]), .Y(n329) );
  AO22X1 U1771 ( .A0(\txfifo[16][0] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[0]), .Y(n330) );
  AO22X1 U1772 ( .A0(\txfifo[16][1] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[1]), .Y(n331) );
  AO22X1 U1773 ( .A0(\txfifo[16][2] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[2]), .Y(n332) );
  AO22X1 U1774 ( .A0(\txfifo[16][3] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[3]), .Y(n333) );
  AO22X1 U1775 ( .A0(\txfifo[16][4] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[4]), .Y(n334) );
  AO22X1 U1776 ( .A0(\txfifo[16][5] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[5]), .Y(n335) );
  AO22X1 U1777 ( .A0(\txfifo[16][6] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[6]), .Y(n336) );
  AO22X1 U1778 ( .A0(\txfifo[16][7] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[7]), .Y(n337) );
  AO22X1 U1779 ( .A0(\txfifo[17][0] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[0]), .Y(n338) );
  AO22X1 U1780 ( .A0(\txfifo[17][1] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[1]), .Y(n339) );
  AO22X1 U1781 ( .A0(\txfifo[17][2] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[2]), .Y(n340) );
  AO22X1 U1782 ( .A0(\txfifo[17][3] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[3]), .Y(n341) );
  AO22X1 U1783 ( .A0(\txfifo[17][4] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[4]), .Y(n342) );
  AO22X1 U1784 ( .A0(\txfifo[17][5] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[5]), .Y(n343) );
  AO22X1 U1785 ( .A0(\txfifo[17][6] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[6]), .Y(n344) );
  AO22X1 U1786 ( .A0(\txfifo[17][7] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[7]), .Y(n345) );
  AO22X1 U1787 ( .A0(\txfifo[18][0] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[0]), .Y(n346) );
  AO22X1 U1788 ( .A0(\txfifo[18][1] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[1]), .Y(n347) );
  AO22X1 U1789 ( .A0(\txfifo[18][2] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[2]), .Y(n348) );
  AO22X1 U1790 ( .A0(\txfifo[18][3] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[3]), .Y(n349) );
  AO22X1 U1791 ( .A0(\txfifo[18][4] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[4]), .Y(n350) );
  AO22X1 U1792 ( .A0(\txfifo[18][5] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[5]), .Y(n351) );
  AO22X1 U1793 ( .A0(\txfifo[18][6] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[6]), .Y(n352) );
  AO22X1 U1794 ( .A0(\txfifo[18][7] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[7]), .Y(n353) );
  AO22X1 U1795 ( .A0(\txfifo[19][0] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[0]), .Y(n354) );
  AO22X1 U1796 ( .A0(\txfifo[19][1] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[1]), .Y(n355) );
  AO22X1 U1797 ( .A0(\txfifo[19][2] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[2]), .Y(n356) );
  AO22X1 U1798 ( .A0(\txfifo[19][3] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[3]), .Y(n357) );
  AO22X1 U1799 ( .A0(\txfifo[19][4] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[4]), .Y(n358) );
  AO22X1 U1800 ( .A0(\txfifo[19][5] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[5]), .Y(n359) );
  AO22X1 U1801 ( .A0(\txfifo[19][6] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[6]), .Y(n360) );
  AO22X1 U1802 ( .A0(\txfifo[19][7] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[7]), .Y(n361) );
  AO22X1 U1803 ( .A0(\txfifo[20][0] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[0]), .Y(n362) );
  AO22X1 U1804 ( .A0(\txfifo[20][1] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[1]), .Y(n363) );
  AO22X1 U1805 ( .A0(\txfifo[20][2] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[2]), .Y(n364) );
  AO22X1 U1806 ( .A0(\txfifo[20][3] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[3]), .Y(n365) );
  AO22X1 U1807 ( .A0(\txfifo[20][4] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[4]), .Y(n366) );
  AO22X1 U1808 ( .A0(\txfifo[20][5] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[5]), .Y(n367) );
  AO22X1 U1809 ( .A0(\txfifo[20][6] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[6]), .Y(n368) );
  AO22X1 U1810 ( .A0(\txfifo[20][7] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[7]), .Y(n369) );
  AO22X1 U1811 ( .A0(\txfifo[21][0] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[0]), .Y(n370) );
  AO22X1 U1812 ( .A0(\txfifo[21][1] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[1]), .Y(n371) );
  AO22X1 U1813 ( .A0(\txfifo[21][2] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[2]), .Y(n372) );
  AO22X1 U1814 ( .A0(\txfifo[21][3] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[3]), .Y(n373) );
  AO22X1 U1815 ( .A0(\txfifo[21][4] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[4]), .Y(n374) );
  AO22X1 U1816 ( .A0(\txfifo[21][5] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[5]), .Y(n375) );
  AO22X1 U1817 ( .A0(\txfifo[21][6] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[6]), .Y(n376) );
  AO22X1 U1818 ( .A0(\txfifo[21][7] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[7]), .Y(n377) );
  AO22X1 U1819 ( .A0(\txfifo[22][0] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[0]), .Y(n378) );
  AO22X1 U1820 ( .A0(\txfifo[22][1] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[1]), .Y(n379) );
  AO22X1 U1821 ( .A0(\txfifo[22][2] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[2]), .Y(n380) );
  AO22X1 U1822 ( .A0(\txfifo[22][3] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[3]), .Y(n381) );
  AO22X1 U1823 ( .A0(\txfifo[22][4] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[4]), .Y(n382) );
  AO22X1 U1824 ( .A0(\txfifo[22][5] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[5]), .Y(n383) );
  AO22X1 U1825 ( .A0(\txfifo[22][6] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[6]), .Y(n384) );
  AO22X1 U1826 ( .A0(\txfifo[22][7] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[7]), .Y(n385) );
  AO22X1 U1827 ( .A0(\txfifo[23][0] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[0]), .Y(n386) );
  AO22X1 U1828 ( .A0(\txfifo[23][1] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[1]), .Y(n387) );
  AO22X1 U1829 ( .A0(\txfifo[23][2] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[2]), .Y(n388) );
  AO22X1 U1830 ( .A0(\txfifo[23][3] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[3]), .Y(n389) );
  AO22X1 U1831 ( .A0(\txfifo[23][4] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[4]), .Y(n390) );
  AO22X1 U1832 ( .A0(\txfifo[23][5] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[5]), .Y(n391) );
  AO22X1 U1833 ( .A0(\txfifo[23][6] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[6]), .Y(n392) );
  AO22X1 U1834 ( .A0(\txfifo[23][7] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[7]), .Y(n393) );
  AO22X1 U1835 ( .A0(\txfifo[24][0] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[0]), .Y(n394) );
  AO22X1 U1836 ( .A0(\txfifo[24][1] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[1]), .Y(n395) );
  AO22X1 U1837 ( .A0(\txfifo[24][2] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[2]), .Y(n396) );
  AO22X1 U1838 ( .A0(\txfifo[24][3] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[3]), .Y(n397) );
  AO22X1 U1839 ( .A0(\txfifo[24][4] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[4]), .Y(n398) );
  AO22X1 U1840 ( .A0(\txfifo[24][5] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[5]), .Y(n399) );
  AO22X1 U1841 ( .A0(\txfifo[24][6] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[6]), .Y(n400) );
  AO22X1 U1842 ( .A0(\txfifo[24][7] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[7]), .Y(n401) );
  AO22X1 U1843 ( .A0(\txfifo[25][0] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[0]), .Y(n402) );
  AO22X1 U1844 ( .A0(\txfifo[25][1] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[1]), .Y(n403) );
  AO22X1 U1845 ( .A0(\txfifo[25][2] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[2]), .Y(n404) );
  AO22X1 U1846 ( .A0(\txfifo[25][3] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[3]), .Y(n405) );
  AO22X1 U1847 ( .A0(\txfifo[25][4] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[4]), .Y(n406) );
  AO22X1 U1848 ( .A0(\txfifo[25][5] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[5]), .Y(n407) );
  AO22X1 U1849 ( .A0(\txfifo[25][6] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[6]), .Y(n408) );
  AO22X1 U1850 ( .A0(\txfifo[25][7] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[7]), .Y(n409) );
  AO22X1 U1851 ( .A0(\txfifo[26][0] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[0]), .Y(n410) );
  AO22X1 U1852 ( .A0(\txfifo[26][1] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[1]), .Y(n411) );
  AO22X1 U1853 ( .A0(\txfifo[26][2] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[2]), .Y(n412) );
  AO22X1 U1854 ( .A0(\txfifo[26][3] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[3]), .Y(n413) );
  AO22X1 U1855 ( .A0(\txfifo[26][4] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[4]), .Y(n414) );
  AO22X1 U1856 ( .A0(\txfifo[26][5] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[5]), .Y(n415) );
  AO22X1 U1857 ( .A0(\txfifo[26][6] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[6]), .Y(n416) );
  AO22X1 U1858 ( .A0(\txfifo[26][7] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[7]), .Y(n417) );
  AO22X1 U1859 ( .A0(\txfifo[27][0] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[0]), .Y(n418) );
  AO22X1 U1860 ( .A0(\txfifo[27][1] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[1]), .Y(n419) );
  AO22X1 U1861 ( .A0(\txfifo[27][2] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[2]), .Y(n420) );
  AO22X1 U1862 ( .A0(\txfifo[27][3] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[3]), .Y(n421) );
  AO22X1 U1863 ( .A0(\txfifo[27][4] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[4]), .Y(n422) );
  AO22X1 U1864 ( .A0(\txfifo[27][5] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[5]), .Y(n423) );
  AO22X1 U1865 ( .A0(\txfifo[27][6] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[6]), .Y(n424) );
  AO22X1 U1866 ( .A0(\txfifo[27][7] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[7]), .Y(n425) );
  AO22X1 U1867 ( .A0(\txfifo[28][0] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[0]), .Y(n426) );
  AO22X1 U1868 ( .A0(\txfifo[28][1] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[1]), .Y(n427) );
  AO22X1 U1869 ( .A0(\txfifo[28][2] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[2]), .Y(n428) );
  AO22X1 U1870 ( .A0(\txfifo[28][3] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[3]), .Y(n429) );
  AO22X1 U1871 ( .A0(\txfifo[28][4] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[4]), .Y(n430) );
  AO22X1 U1872 ( .A0(\txfifo[28][5] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[5]), .Y(n431) );
  AO22X1 U1873 ( .A0(\txfifo[28][6] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[6]), .Y(n432) );
  AO22X1 U1874 ( .A0(\txfifo[28][7] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[7]), .Y(n433) );
  AO22X1 U1875 ( .A0(\txfifo[29][0] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[0]), .Y(n434) );
  AO22X1 U1876 ( .A0(\txfifo[29][1] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[1]), .Y(n435) );
  AO22X1 U1877 ( .A0(\txfifo[29][2] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[2]), .Y(n436) );
  AO22X1 U1878 ( .A0(\txfifo[29][3] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[3]), .Y(n437) );
  AO22X1 U1879 ( .A0(\txfifo[29][4] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[4]), .Y(n438) );
  AO22X1 U1880 ( .A0(\txfifo[29][5] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[5]), .Y(n439) );
  AO22X1 U1881 ( .A0(\txfifo[29][6] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[6]), .Y(n440) );
  AO22X1 U1882 ( .A0(\txfifo[29][7] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[7]), .Y(n441) );
  AO22X1 U1883 ( .A0(\txfifo[30][0] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[0]), .Y(n442) );
  AO22X1 U1884 ( .A0(\txfifo[30][1] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[1]), .Y(n443) );
  AO22X1 U1885 ( .A0(\txfifo[30][2] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[2]), .Y(n444) );
  AO22X1 U1886 ( .A0(\txfifo[30][3] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[3]), .Y(n445) );
  AO22X1 U1887 ( .A0(\txfifo[30][4] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[4]), .Y(n446) );
  AO22X1 U1888 ( .A0(\txfifo[30][5] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[5]), .Y(n447) );
  AO22X1 U1889 ( .A0(\txfifo[30][6] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[6]), .Y(n448) );
  AO22X1 U1890 ( .A0(\txfifo[30][7] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[7]), .Y(n449) );
  AO22X1 U1891 ( .A0(N506), .A1(n943), .B0(fifo_wrpos_3_), .B1(n938), .Y(n467)
         );
  AO22X1 U1892 ( .A0(N505), .A1(n943), .B0(fifo_wrpos_2_), .B1(n938), .Y(n466)
         );
  AO22X1 U1893 ( .A0(N504), .A1(n943), .B0(n1352), .B1(n938), .Y(n465) );
  AO22X1 U1894 ( .A0(n943), .A1(n1108), .B0(n938), .B1(n1351), .Y(n464) );
  INVX1 U1895 ( .A(n945), .Y(n938) );
  NAND2BX1 U1896 ( .AN(swrst), .B(n940), .Y(n945) );
  AO21X1 U1897 ( .A0(n938), .A1(fifo_wrpos_4_), .B0(n939), .Y(n468) );
  OAI33X1 U1898 ( .A0(n940), .A1(n941), .A2(n1344), .B0(n940), .B1(n1101), 
        .B2(fifo_wrpos_4_), .Y(n939) );
  INVX1 U1899 ( .A(n1101), .Y(n941) );
  OAI31X1 U1900 ( .A0(n953), .A1(n954), .A2(n955), .B0(n956), .Y(n458) );
  NAND4BX1 U1901 ( .AN(n957), .B(txfifocnt[2]), .C(txfifocnt[4]), .D(
        txfifocnt[3]), .Y(n954) );
  NAND3BX1 U1902 ( .AN(swrst), .B(n946), .C(fifordb), .Y(n955) );
  OAI211X1 U1903 ( .A0(fifordb), .A1(n946), .B0(txfifocnt[5]), .C0(n937), .Y(
        n956) );
  AFHCONX2 U2_3 ( .A(fifo_wrpos_3_), .B(n1224), .CI(carry), .S(txfifocnt[3]), 
        .CON(n511) );
  INVX1 U1904 ( .A(n610), .Y(carry) );
  AFHCONX2 U2_2 ( .A(fifo_wrpos_2_), .B(n1346), .CI(carry0), .S(txfifocnt[2]), 
        .CON(n610) );
  INVX1 U1905 ( .A(n710), .Y(carry0) );
  XOR3X1 U2_4 ( .A(fifo_wrpos_4_), .B(n1225), .C(carry_4_), .Y(txfifocnt[4])
         );
  INVX1 U1906 ( .A(n511), .Y(carry_4_) );
  NAND3BX1 U1907 ( .AN(swrst), .B(n1348), .C(txfifo_emptyb), .Y(n949) );
  NAND2BX1 U1908 ( .AN(n1351), .B(N74), .Y(carry_1_) );
  NAND4BX1 U1909 ( .AN(n1094), .B(n1095), .C(n957), .D(n953), .Y(txfifo_emptyb) );
  INVX1 U1910 ( .A(txfifocnt[2]), .Y(n1095) );
  NAND3BX1 U1911 ( .AN(txfifocnt[3]), .B(n1097), .C(txfifo_fullb), .Y(n1094)
         );
  BUFX2 U1912 ( .A(fifo_wrpos_0_), .Y(n1351) );
  BUFX2 U1913 ( .A(n483), .Y(n1352) );
  AO21X1 U1914 ( .A0(n947), .A1(N78), .B0(n948), .Y(n463) );
  OAI33X1 U1915 ( .A0(n949), .A1(n1225), .A2(n950), .B0(n949), .B1(n1100), 
        .B2(N78), .Y(n948) );
  INVX1 U1916 ( .A(n1100), .Y(n950) );
  AO22X1 U1917 ( .A0(n951), .A1(n1227), .B0(n947), .B1(N74), .Y(n459) );
  AO22X1 U1918 ( .A0(N523), .A1(n951), .B0(n947), .B1(N76), .Y(n461) );
  AO22X1 U1919 ( .A0(N522), .A1(n951), .B0(n947), .B1(N75), .Y(n460) );
  AO22X1 U1920 ( .A0(N524), .A1(n951), .B0(n947), .B1(N77), .Y(n462) );
  INVX1 U1921 ( .A(n952), .Y(n947) );
  NAND2BX1 U1922 ( .AN(swrst), .B(n949), .Y(n952) );
  INVX1 U1923 ( .A(n2100), .Y(carry1) );
  INVX1 U1924 ( .A(n2), .Y(carry_3_) );
  INVX1 U1925 ( .A(n3100), .Y(carry2) );
  INVX1 U1926 ( .A(n3), .Y(carry_2_) );
  NAND3BX1 U1927 ( .AN(baudx16clk), .B(n1226), .C(n937), .Y(n936) );
  NAND3BX1 U1928 ( .AN(swrst), .B(n1226), .C(n936), .Y(n924) );
  NAND3BX1 U1929 ( .AN(n1232), .B(txclkcnt[0]), .C(n930), .Y(n926) );
  NAND2BX1 U1930 ( .AN(N75), .B(N74), .Y(n895) );
  NAND2BX1 U1931 ( .AN(N77), .B(n1346), .Y(n913) );
  NAND2BX1 U1932 ( .AN(N74), .B(N75), .Y(n900) );
  OAI31X1 U1933 ( .A0(n1106), .A1(stopbit), .A2(n1107), .B0(n1098), .Y(n1066)
         );
  OA21X2 U1934 ( .A0(n1106), .A1(n1111), .B0(n9), .Y(n1098) );
  NAND2BX1 U1935 ( .AN(n1085), .B(n1053), .Y(n1069) );
  OAI211X1 U1936 ( .A0(txclk), .A1(n1111), .B0(n1282), .C0(n1091), .Y(n1085)
         );
  OA22X1 U1937 ( .A0(n1107), .A1(n1049), .B0(txclk), .B1(n1229), .Y(n1091) );
  NAND2BX1 U1938 ( .AN(n1223), .B(N74), .Y(n916) );
  NAND2BX1 U1939 ( .AN(N77), .B(N76), .Y(n907) );
  NAND2BX1 U1940 ( .AN(N76), .B(N77), .Y(n898) );
  OR2X1 U1941 ( .A(parity[0]), .B(parity[1]), .Y(n1087) );
  INVX1 U1942 ( .A(swrst), .Y(n937) );
  OAI31X1 U1943 ( .A0(n1106), .A1(databit), .A2(n1231), .B0(n1076), .Y(n1055)
         );
  OA22X1 U1944 ( .A0(txclk), .A1(n1109), .B0(n1106), .B1(n1114), .Y(n1076) );
  NAND2BX1 U1945 ( .AN(N75), .B(n1227), .Y(n897) );
  OAI211X1 U1946 ( .A0(n489), .A1(n490), .B0(n6), .C0(n491), .Y(txd) );
  NAND2BX1 U1947 ( .AN(n1230), .B(parity_int), .Y(n490) );
  AOI32X1 U1948 ( .A0(n1103), .A1(n1113), .A2(n489), .B0(shiftreg_0_), .B1(
        n1104), .Y(n491) );
  NAND2BX1 U1949 ( .AN(parity[0]), .B(parity[1]), .Y(n489) );
  OAI221X1 U1950 ( .A0(n508), .A1(n1124), .B0(n510), .B1(n1242), .C0(n910), 
        .Y(n887) );
  OA22X1 U1951 ( .A0(n514), .A1(n1179), .B0(n516), .B1(n1299), .Y(n910) );
  OAI221X1 U1952 ( .A0(n508), .A1(n1125), .B0(n510), .B1(n1243), .C0(n852), 
        .Y(n837) );
  OA22X1 U1953 ( .A0(n514), .A1(n1180), .B0(n516), .B1(n1300), .Y(n852) );
  OAI221X1 U1954 ( .A0(n508), .A1(n1126), .B0(n510), .B1(n1244), .C0(n803), 
        .Y(n788) );
  OA22X1 U1955 ( .A0(n514), .A1(n1181), .B0(n516), .B1(n1301), .Y(n803) );
  OAI221X1 U1956 ( .A0(n508), .A1(n1127), .B0(n510), .B1(n1245), .C0(n754), 
        .Y(n739) );
  OA22X1 U1957 ( .A0(n514), .A1(n1182), .B0(n516), .B1(n1302), .Y(n754) );
  OAI221X1 U1958 ( .A0(n508), .A1(n1128), .B0(n510), .B1(n1246), .C0(n704), 
        .Y(n689) );
  OA22X1 U1959 ( .A0(n514), .A1(n1183), .B0(n516), .B1(n1303), .Y(n704) );
  OAI221X1 U1960 ( .A0(n508), .A1(n1129), .B0(n510), .B1(n1247), .C0(n655), 
        .Y(n640) );
  OA22X1 U1961 ( .A0(n514), .A1(n1184), .B0(n516), .B1(n1304), .Y(n655) );
  OAI221X1 U1962 ( .A0(n508), .A1(n1130), .B0(n510), .B1(n1248), .C0(n605), 
        .Y(n590) );
  OA22X1 U1963 ( .A0(n514), .A1(n1185), .B0(n516), .B1(n1305), .Y(n605) );
  OA22X1 U1964 ( .A0(n552), .A1(n1186), .B0(n1350), .B1(n1306), .Y(n883) );
  OA22X1 U1965 ( .A0(n552), .A1(n1187), .B0(n1350), .B1(n1307), .Y(n833) );
  OA22X1 U1966 ( .A0(n552), .A1(n1188), .B0(n1350), .B1(n1308), .Y(n784) );
  OA22X1 U1967 ( .A0(n552), .A1(n1189), .B0(n1350), .B1(n1309), .Y(n735) );
  OA22X1 U1968 ( .A0(n552), .A1(n1190), .B0(n1350), .B1(n1310), .Y(n685) );
  OA22X1 U1969 ( .A0(n552), .A1(n1191), .B0(n1350), .B1(n1311), .Y(n636) );
  OA22X1 U1970 ( .A0(n552), .A1(n1192), .B0(n1350), .B1(n1312), .Y(n586) );
  OAI221X1 U1971 ( .A0(n544), .A1(n1131), .B0(n545), .B1(n1249), .C0(n866), 
        .Y(n862) );
  OA22X1 U1972 ( .A0(n547), .A1(n1193), .B0(n1349), .B1(n1313), .Y(n866) );
  OAI221X1 U1973 ( .A0(n549), .A1(n1132), .B0(n550), .B1(n1250), .C0(n892), 
        .Y(n889) );
  OA22X1 U1974 ( .A0(n552), .A1(n1194), .B0(n1350), .B1(n1314), .Y(n892) );
  OAI221X1 U1975 ( .A0(n544), .A1(n1133), .B0(n545), .B1(n1251), .C0(n903), 
        .Y(n888) );
  OA22X1 U1976 ( .A0(n547), .A1(n1195), .B0(n1349), .B1(n1315), .Y(n903) );
  OAI221X1 U1977 ( .A0(n544), .A1(n1134), .B0(n545), .B1(n1252), .C0(n816), 
        .Y(n813) );
  OA22X1 U1978 ( .A0(n547), .A1(n1196), .B0(n1349), .B1(n1316), .Y(n816) );
  OAI221X1 U1979 ( .A0(n549), .A1(n1135), .B0(n550), .B1(n1253), .C0(n842), 
        .Y(n839) );
  OA22X1 U1980 ( .A0(n552), .A1(n1197), .B0(n1350), .B1(n1317), .Y(n842) );
  OAI221X1 U1981 ( .A0(n544), .A1(n1136), .B0(n545), .B1(n1254), .C0(n847), 
        .Y(n838) );
  OA22X1 U1982 ( .A0(n547), .A1(n1198), .B0(n1349), .B1(n1318), .Y(n847) );
  OAI221X1 U1983 ( .A0(n544), .A1(n1137), .B0(n545), .B1(n1255), .C0(n767), 
        .Y(n764) );
  OA22X1 U1984 ( .A0(n547), .A1(n1199), .B0(n1349), .B1(n1319), .Y(n767) );
  OAI221X1 U1985 ( .A0(n549), .A1(n1138), .B0(n550), .B1(n1256), .C0(n793), 
        .Y(n790) );
  OA22X1 U1986 ( .A0(n552), .A1(n1200), .B0(n1350), .B1(n1320), .Y(n793) );
  OAI221X1 U1987 ( .A0(n544), .A1(n1139), .B0(n545), .B1(n1257), .C0(n798), 
        .Y(n789) );
  OA22X1 U1988 ( .A0(n547), .A1(n1201), .B0(n1349), .B1(n1321), .Y(n798) );
  OAI221X1 U1989 ( .A0(n544), .A1(n1140), .B0(n545), .B1(n1258), .C0(n718), 
        .Y(n715) );
  OA22X1 U1990 ( .A0(n547), .A1(n1202), .B0(n1349), .B1(n1322), .Y(n718) );
  OAI221X1 U1991 ( .A0(n549), .A1(n1141), .B0(n550), .B1(n1259), .C0(n744), 
        .Y(n741) );
  OA22X1 U1992 ( .A0(n552), .A1(n1203), .B0(n1350), .B1(n1323), .Y(n744) );
  OAI221X1 U1993 ( .A0(n544), .A1(n1142), .B0(n545), .B1(n1260), .C0(n749), 
        .Y(n740) );
  OA22X1 U1994 ( .A0(n547), .A1(n1204), .B0(n1349), .B1(n1324), .Y(n749) );
  OAI221X1 U1995 ( .A0(n544), .A1(n1143), .B0(n545), .B1(n1261), .C0(n668), 
        .Y(n665) );
  OA22X1 U1996 ( .A0(n547), .A1(n1205), .B0(n1349), .B1(n1325), .Y(n668) );
  OAI221X1 U1997 ( .A0(n549), .A1(n1144), .B0(n550), .B1(n1262), .C0(n694), 
        .Y(n691) );
  OA22X1 U1998 ( .A0(n552), .A1(n1206), .B0(n1350), .B1(n1326), .Y(n694) );
  OAI221X1 U1999 ( .A0(n544), .A1(n1145), .B0(n545), .B1(n1263), .C0(n699), 
        .Y(n690) );
  OA22X1 U2000 ( .A0(n547), .A1(n1207), .B0(n1349), .B1(n1327), .Y(n699) );
  OAI221X1 U2001 ( .A0(n544), .A1(n1146), .B0(n545), .B1(n1264), .C0(n619), 
        .Y(n616) );
  OA22X1 U2002 ( .A0(n547), .A1(n1208), .B0(n1349), .B1(n1328), .Y(n619) );
  OAI221X1 U2003 ( .A0(n549), .A1(n1147), .B0(n550), .B1(n1265), .C0(n645), 
        .Y(n642) );
  OA22X1 U2004 ( .A0(n552), .A1(n1209), .B0(n1350), .B1(n1329), .Y(n645) );
  OAI221X1 U2005 ( .A0(n544), .A1(n1148), .B0(n545), .B1(n1266), .C0(n650), 
        .Y(n641) );
  OA22X1 U2006 ( .A0(n547), .A1(n1210), .B0(n1349), .B1(n1330), .Y(n650) );
  OAI221X1 U2007 ( .A0(n544), .A1(n1149), .B0(n545), .B1(n1267), .C0(n565), 
        .Y(n561) );
  OA22X1 U2008 ( .A0(n547), .A1(n1211), .B0(n1349), .B1(n1331), .Y(n565) );
  OAI221X1 U2009 ( .A0(n549), .A1(n1150), .B0(n550), .B1(n1268), .C0(n595), 
        .Y(n592) );
  OA22X1 U2010 ( .A0(n552), .A1(n1212), .B0(n1350), .B1(n1332), .Y(n595) );
  OAI221X1 U2011 ( .A0(n544), .A1(n1151), .B0(n545), .B1(n1269), .C0(n600), 
        .Y(n591) );
  OA22X1 U2012 ( .A0(n547), .A1(n1213), .B0(n1349), .B1(n1333), .Y(n600) );
  OA22X1 U2013 ( .A0(n514), .A1(n1214), .B0(n516), .B1(n1334), .Y(n5130) );
  OA22X1 U2014 ( .A0(n514), .A1(n1215), .B0(n516), .B1(n1335), .Y(n540) );
  NOR2X1 U2015 ( .A(n1224), .B(n1346), .Y(n1345) );
  INVX1 U2016 ( .A(n1072), .Y(n1067) );
  NAND3BX1 U2017 ( .AN(n1073), .B(n1074), .C(n1075), .Y(n1072) );
  NAND3BX1 U2018 ( .AN(n1078), .B(n1164), .C(n1283), .Y(n1073) );
  AOI211X1 U2019 ( .A0(current_state_3_), .A1(txclk), .B0(current_state_4_), 
        .C0(current_state_10_), .Y(n1074) );
  NOR2BX1 U2020 ( .AN(n5060), .B(n507), .Y(n5050) );
  OAI221X1 U2021 ( .A0(n508), .A1(n1152), .B0(n510), .B1(n1270), .C0(n5130), 
        .Y(n507) );
  AOI221X1 U2022 ( .A0(\txfifo[4][7] ), .A1(n518), .B0(\txfifo[5][7] ), .B1(
        n519), .C0(n520), .Y(n5060) );
  NOR2BX1 U2023 ( .AN(n536), .B(n537), .Y(n535) );
  OAI221X1 U2024 ( .A0(n508), .A1(n1153), .B0(n510), .B1(n1271), .C0(n540), 
        .Y(n537) );
  AOI221X1 U2025 ( .A0(\txfifo[20][7] ), .A1(n518), .B0(\txfifo[21][7] ), .B1(
        n519), .C0(n543), .Y(n536) );
  AO22X1 U2026 ( .A0(txclkcnt[2]), .A1(n922), .B0(n928), .B1(n1116), .Y(n471)
         );
  INVX1 U2027 ( .A(n926), .Y(n928) );
  AO22X1 U2028 ( .A0(\txfifo[7][7] ), .A1(n521), .B0(\txfifo[6][7] ), .B1(
        n5220), .Y(n520) );
  AO22X1 U2029 ( .A0(\txfifo[23][7] ), .A1(n521), .B0(\txfifo[22][7] ), .B1(
        n5220), .Y(n543) );
  AOI221X1 U2030 ( .A0(\txfifo[28][0] ), .A1(n528), .B0(\txfifo[29][0] ), .B1(
        n529), .C0(n918), .Y(n886) );
  AO22X1 U2031 ( .A0(\txfifo[31][0] ), .A1(n531), .B0(\txfifo[30][0] ), .B1(
        n532), .Y(n918) );
  AOI221X1 U2032 ( .A0(\txfifo[28][1] ), .A1(n528), .B0(\txfifo[29][1] ), .B1(
        n529), .C0(n855), .Y(n836) );
  AO22X1 U2033 ( .A0(\txfifo[31][1] ), .A1(n531), .B0(\txfifo[30][1] ), .B1(
        n532), .Y(n855) );
  AOI221X1 U2034 ( .A0(\txfifo[28][2] ), .A1(n528), .B0(\txfifo[29][2] ), .B1(
        n529), .C0(n806), .Y(n787) );
  AO22X1 U2035 ( .A0(\txfifo[31][2] ), .A1(n531), .B0(\txfifo[30][2] ), .B1(
        n532), .Y(n806) );
  AOI221X1 U2036 ( .A0(\txfifo[28][3] ), .A1(n528), .B0(\txfifo[29][3] ), .B1(
        n529), .C0(n757), .Y(n738) );
  AO22X1 U2037 ( .A0(\txfifo[31][3] ), .A1(n531), .B0(\txfifo[30][3] ), .B1(
        n532), .Y(n757) );
  AOI221X1 U2038 ( .A0(\txfifo[28][4] ), .A1(n528), .B0(\txfifo[29][4] ), .B1(
        n529), .C0(n707), .Y(n688) );
  AO22X1 U2039 ( .A0(\txfifo[31][4] ), .A1(n531), .B0(\txfifo[30][4] ), .B1(
        n532), .Y(n707) );
  AOI221X1 U2040 ( .A0(\txfifo[28][5] ), .A1(n528), .B0(\txfifo[29][5] ), .B1(
        n529), .C0(n658), .Y(n639) );
  AO22X1 U2041 ( .A0(\txfifo[31][5] ), .A1(n531), .B0(\txfifo[30][5] ), .B1(
        n532), .Y(n658) );
  AOI221X1 U2042 ( .A0(\txfifo[28][6] ), .A1(n528), .B0(\txfifo[29][6] ), .B1(
        n529), .C0(n608), .Y(n589) );
  AO22X1 U2043 ( .A0(\txfifo[31][6] ), .A1(n531), .B0(\txfifo[30][6] ), .B1(
        n532), .Y(n608) );
  OAI32X1 U2044 ( .A0(n924), .A1(txclkcnt[1]), .A2(n1110), .B0(n933), .B1(
        n1232), .Y(n470) );
  INVX1 U2045 ( .A(n931), .Y(n933) );
  OAI221X1 U2046 ( .A0(n1115), .A1(n498), .B0(n499), .B1(n1115), .C0(n500), 
        .Y(n480) );
  OAI211X1 U2047 ( .A0(n501), .A1(n502), .B0(n499), .C0(n498), .Y(n500) );
  AOI31X1 U2048 ( .A0(n533), .A1(n534), .A2(n535), .B0(n1225), .Y(n501) );
  AOI31X1 U2049 ( .A0(n503), .A1(n5040), .A2(n5050), .B0(N78), .Y(n502) );
  OAI221X1 U2050 ( .A0(n508), .A1(n1154), .B0(n510), .B1(n1272), .C0(n871), 
        .Y(n861) );
  OA22X1 U2051 ( .A0(n514), .A1(n1216), .B0(n516), .B1(n1336), .Y(n871) );
  OAI221X1 U2052 ( .A0(n508), .A1(n1155), .B0(n510), .B1(n1273), .C0(n821), 
        .Y(n812) );
  OA22X1 U2053 ( .A0(n514), .A1(n1217), .B0(n516), .B1(n1337), .Y(n821) );
  OAI221X1 U2054 ( .A0(n508), .A1(n1156), .B0(n510), .B1(n1274), .C0(n772), 
        .Y(n763) );
  OA22X1 U2055 ( .A0(n514), .A1(n1218), .B0(n516), .B1(n1338), .Y(n772) );
  OAI221X1 U2056 ( .A0(n508), .A1(n1157), .B0(n510), .B1(n1275), .C0(n723), 
        .Y(n714) );
  OA22X1 U2057 ( .A0(n514), .A1(n1219), .B0(n516), .B1(n1339), .Y(n723) );
  OAI221X1 U2058 ( .A0(n508), .A1(n1158), .B0(n510), .B1(n1276), .C0(n673), 
        .Y(n664) );
  OA22X1 U2059 ( .A0(n514), .A1(n1220), .B0(n516), .B1(n1340), .Y(n673) );
  OAI221X1 U2060 ( .A0(n508), .A1(n1159), .B0(n510), .B1(n1277), .C0(n624), 
        .Y(n615) );
  OA22X1 U2061 ( .A0(n514), .A1(n1221), .B0(n516), .B1(n1341), .Y(n624) );
  OAI221X1 U2062 ( .A0(n508), .A1(n1160), .B0(n510), .B1(n1278), .C0(n570), 
        .Y(n560) );
  OA22X1 U2063 ( .A0(n514), .A1(n1222), .B0(n516), .B1(n1342), .Y(n570) );
  AO21X1 U2064 ( .A0(txclkcnt[3]), .A1(n922), .B0(n923), .Y(n472) );
  OAI33X1 U2065 ( .A0(n924), .A1(txclkcnt[2]), .A2(n1233), .B0(n926), .B1(
        txclkcnt[3]), .B2(n1116), .Y(n923) );
  AOI221X1 U2066 ( .A0(\txfifo[12][7] ), .A1(n528), .B0(\txfifo[13][7] ), .B1(
        n529), .C0(n530), .Y(n503) );
  AO22X1 U2067 ( .A0(\txfifo[15][7] ), .A1(n531), .B0(\txfifo[14][7] ), .B1(
        n532), .Y(n530) );
  AOI221X1 U2068 ( .A0(\txfifo[28][7] ), .A1(n528), .B0(\txfifo[29][7] ), .B1(
        n529), .C0(n553), .Y(n533) );
  AO22X1 U2069 ( .A0(\txfifo[31][7] ), .A1(n531), .B0(\txfifo[30][7] ), .B1(
        n532), .Y(n553) );
  AOI221X1 U2070 ( .A0(\txfifo[8][7] ), .A1(n5230), .B0(\txfifo[9][7] ), .B1(
        n5240), .C0(n525), .Y(n5040) );
  AO22X1 U2071 ( .A0(\txfifo[11][7] ), .A1(n526), .B0(\txfifo[10][7] ), .B1(
        n527), .Y(n525) );
  AOI221X1 U2072 ( .A0(\txfifo[24][7] ), .A1(n5230), .B0(\txfifo[25][7] ), 
        .B1(n5240), .C0(n548), .Y(n534) );
  AO22X1 U2073 ( .A0(\txfifo[27][7] ), .A1(n526), .B0(\txfifo[26][7] ), .B1(
        n527), .Y(n548) );
  INVX1 U2074 ( .A(n1086), .Y(n1053) );
  OAI31X1 U2075 ( .A0(n1106), .A1(n1109), .A2(n1087), .B0(n1088), .Y(n1086) );
  OA22X1 U2076 ( .A0(n1106), .A1(n1234), .B0(txclk), .B1(n1107), .Y(n1088) );
  NAND3BX1 U2077 ( .AN(fifo_wrpos_2_), .B(n1112), .C(n1108), .Y(n989) );
  NAND3BX1 U2078 ( .AN(fifo_wrpos_2_), .B(n1112), .C(n1351), .Y(n985) );
  NAND3BX1 U2079 ( .AN(fifo_wrpos_2_), .B(n1108), .C(n1352), .Y(n981) );
  NAND3BX1 U2080 ( .AN(fifo_wrpos_2_), .B(n1352), .C(n1351), .Y(n977) );
  NAND3BX1 U2081 ( .AN(n1352), .B(fifo_wrpos_2_), .C(n1351), .Y(n969) );
  NAND3BX1 U2082 ( .AN(n1351), .B(fifo_wrpos_2_), .C(n1352), .Y(n965) );
  NAND3BX1 U2083 ( .AN(n1352), .B(n1108), .C(fifo_wrpos_2_), .Y(n973) );
  NAND3BX1 U2084 ( .AN(shiftenb), .B(fifordb), .C(txclk), .Y(n498) );
  NAND2BX1 U2085 ( .AN(swrst), .B(txclk), .Y(n1048) );
  NAND2BX1 U2086 ( .AN(swrst), .B(n1106), .Y(n1051) );
  AO22X1 U2087 ( .A0(current_state_3_), .A1(n1106), .B0(current_state_2_), 
        .B1(txclk), .Y(n1061) );
  OAI32X1 U2088 ( .A0(n1106), .A1(n1099), .A2(n1109), .B0(txclk), .B1(n1234), 
        .Y(n1071) );
  INVX1 U2089 ( .A(n1087), .Y(n1099) );
  NOR2BX1 U2090 ( .AN(n1055), .B(swrst), .Y(N129) );
  NOR2BX1 U2091 ( .AN(n1061), .B(swrst), .Y(N121) );
  NAND2BX1 U2092 ( .AN(fifordb), .B(N78), .Y(n555) );
  OR3X2 U2093 ( .A(current_state_9_), .B(current_state_8_), .C(
        current_state_7_), .Y(n1078) );
  INVX1 U2094 ( .A(n1030), .Y(n961) );
  NAND3BX1 U2095 ( .AN(n1112), .B(fifo_wrpos_2_), .C(n1351), .Y(n1030) );
  OAI33X1 U2096 ( .A0(n494), .A1(n1348), .A2(n1113), .B0(n496), .B1(parity_int), .B2(n1348), .Y(n481) );
  INVX1 U2097 ( .A(n496), .Y(n494) );
  NAND3BX1 U2098 ( .AN(shiftenb), .B(dtxclk), .C(shiftreg_0_), .Y(n496) );
  AO22X1 U2099 ( .A0(n934), .A1(txclkcnt[0]), .B0(n930), .B1(n1110), .Y(n469)
         );
  AO22X1 U2100 ( .A0(current_state_8_), .A1(n1059), .B0(current_state_9_), 
        .B1(n1060), .Y(N127) );
  AO22X1 U2101 ( .A0(current_state_7_), .A1(n1059), .B0(current_state_8_), 
        .B1(n1060), .Y(N126) );
  AO22X1 U2102 ( .A0(current_state_6_), .A1(n1059), .B0(current_state_7_), 
        .B1(n1060), .Y(N125) );
  AO22X1 U2103 ( .A0(current_state_5_), .A1(n1059), .B0(current_state_6_), 
        .B1(n1060), .Y(N124) );
  AO22X1 U2104 ( .A0(current_state_4_), .A1(n1059), .B0(current_state_5_), 
        .B1(n1060), .Y(N123) );
  AO22X1 U2105 ( .A0(current_state_3_), .A1(n1059), .B0(current_state_4_), 
        .B1(n1060), .Y(N122) );
  AO22X1 U2106 ( .A0(current_state_1_), .A1(n937), .B0(current_state_2_), .B1(
        n1060), .Y(N120) );
  AND4X1 U2107 ( .A(baudx16clk), .B(n1226), .C(txclkcnt[1]), .D(n1047), .Y(
        N513) );
  AND4X1 U2108 ( .A(n937), .B(n1110), .C(n1116), .D(n1233), .Y(n1047) );
  OAI32X1 U2109 ( .A0(n1048), .A1(n1056), .A2(n1231), .B0(n1051), .B1(n1114), 
        .Y(N128) );
  INVX1 U2110 ( .A(databit), .Y(n1056) );
  INVX1 U2111 ( .A(stopbit), .Y(n1049) );
  AND2X2 U2112 ( .A(n1348), .B(n1225), .Y(n1347) );
  DFFRX1 fifo_rdpos_reg_0_ ( .D(n459), .CK(clk), .RN(rstb), .Q(N74), .QN(n1227) );
  DFFRX1 fifo_wrpos_reg_3_ ( .D(n467), .CK(clk), .RN(rstb), .Q(fifo_wrpos_3_)
         );
  DFFRX1 fifo_wrpos_reg_2_ ( .D(n466), .CK(clk), .RN(rstb), .Q(fifo_wrpos_2_)
         );
  DFFRX1 fifo_rdpos_reg_2_ ( .D(n461), .CK(clk), .RN(rstb), .Q(N76), .QN(n1346) );
  DFFRX1 fifo_rdpos_reg_1_ ( .D(n460), .CK(clk), .RN(rstb), .Q(N75), .QN(n1223) );
  DFFRX1 fifo_rdpos_reg_3_ ( .D(n462), .CK(clk), .RN(rstb), .Q(N77), .QN(n1224) );
  DFFRX1 fifo_wrpos_reg_0_ ( .D(n464), .CK(clk), .RN(rstb), .Q(fifo_wrpos_0_), 
        .QN(n1108) );
  DFFRX1 fifo_wrpos_reg_1_ ( .D(n465), .CK(clk), .RN(rstb), .Q(n483), .QN(
        n1112) );
  DFFRX1 fifofull_reg ( .D(n458), .CK(clk), .RN(rstb), .Q(txfifocnt[5]), .QN(
        txfifo_fullb) );
  DFFRX1 txclk_reg ( .D(N513), .CK(clk), .RN(rstb), .Q(txclk), .QN(n1106) );
  DFFRX1 fifo_wrpos_reg_4_ ( .D(n468), .CK(clk), .RN(rstb), .Q(fifo_wrpos_4_), 
        .QN(n1344) );
  DFFRX1 fifo_rdpos_reg_4_ ( .D(n463), .CK(clk), .RN(rstb), .Q(N78), .QN(n1225) );
  DFFRX1 shiftreg_reg_0_ ( .D(n473), .CK(clk), .RN(rstb), .Q(shiftreg_0_), 
        .QN(n1284) );
  DFFRX1 parity_int_reg ( .D(n481), .CK(clk), .RN(rstb), .Q(parity_int), .QN(
        n1113) );
  DFFRX1 txfifo_reg ( .D(n209), .CK(clk), .RN(rstb), .Q(\txfifo[0][7] ), .QN(
        n1214) );
  DFFRX1 txfifo_reg0 ( .D(n217), .CK(clk), .RN(rstb), .Q(\txfifo[1][7] ), .QN(
        n1334) );
  DFFRX1 txfifo_reg1 ( .D(n225), .CK(clk), .RN(rstb), .Q(\txfifo[2][7] ), .QN(
        n1152) );
  DFFRX1 txfifo_reg2 ( .D(n233), .CK(clk), .RN(rstb), .Q(\txfifo[3][7] ), .QN(
        n1270) );
  DFFRX1 txfifo_reg3 ( .D(n337), .CK(clk), .RN(rstb), .Q(\txfifo[16][7] ), 
        .QN(n1215) );
  DFFRX1 txfifo_reg4 ( .D(n345), .CK(clk), .RN(rstb), .Q(\txfifo[17][7] ), 
        .QN(n1335) );
  DFFRX1 txfifo_reg5 ( .D(n353), .CK(clk), .RN(rstb), .Q(\txfifo[18][7] ), 
        .QN(n1153) );
  DFFRX1 txfifo_reg6 ( .D(n361), .CK(clk), .RN(rstb), .Q(\txfifo[19][7] ), 
        .QN(n1271) );
  DFFRX1 txdoutsel_reg_3_ ( .D(N130), .CK(clk), .RN(rstb), .Q(n1103), .QN(
        n1230) );
  DFFRX1 current_state_reg_14_ ( .D(N132), .CK(clk), .RN(rstb), .QN(n1111) );
  DFFRX1 current_state_reg_13_ ( .D(N131), .CK(clk), .RN(rstb), .QN(n1107) );
  DFFRX1 txfifo_reg7 ( .D(n265), .CK(clk), .RN(rstb), .Q(\txfifo[7][7] ) );
  DFFRX1 txfifo_reg8 ( .D(n297), .CK(clk), .RN(rstb), .Q(\txfifo[11][7] ) );
  DFFRX1 txfifo_reg9 ( .D(n329), .CK(clk), .RN(rstb), .Q(\txfifo[15][7] ) );
  DFFRX1 txfifo_reg10 ( .D(n393), .CK(clk), .RN(rstb), .Q(\txfifo[23][7] ) );
  DFFRX1 txfifo_reg11 ( .D(n425), .CK(clk), .RN(rstb), .Q(\txfifo[27][7] ) );
  DFFRX1 txfifo_reg12 ( .D(n457), .CK(clk), .RN(rstb), .Q(\txfifo[31][7] ) );
  DFFRX1 txfifo_reg13 ( .D(n257), .CK(clk), .RN(rstb), .Q(\txfifo[6][7] ) );
  DFFRX1 txfifo_reg14 ( .D(n289), .CK(clk), .RN(rstb), .Q(\txfifo[10][7] ) );
  DFFRX1 txfifo_reg15 ( .D(n321), .CK(clk), .RN(rstb), .Q(\txfifo[14][7] ) );
  DFFRX1 txfifo_reg16 ( .D(n385), .CK(clk), .RN(rstb), .Q(\txfifo[22][7] ) );
  DFFRX1 txfifo_reg17 ( .D(n417), .CK(clk), .RN(rstb), .Q(\txfifo[26][7] ) );
  DFFRX1 txfifo_reg18 ( .D(n449), .CK(clk), .RN(rstb), .Q(\txfifo[30][7] ) );
  DFFRX1 txfifo_reg19 ( .D(n241), .CK(clk), .RN(rstb), .Q(\txfifo[4][7] ) );
  DFFRX1 txfifo_reg20 ( .D(n273), .CK(clk), .RN(rstb), .Q(\txfifo[8][7] ) );
  DFFRX1 txfifo_reg21 ( .D(n305), .CK(clk), .RN(rstb), .Q(\txfifo[12][7] ) );
  DFFRX1 txfifo_reg22 ( .D(n369), .CK(clk), .RN(rstb), .Q(\txfifo[20][7] ) );
  DFFRX1 txfifo_reg23 ( .D(n401), .CK(clk), .RN(rstb), .Q(\txfifo[24][7] ) );
  DFFRX1 txfifo_reg24 ( .D(n433), .CK(clk), .RN(rstb), .Q(\txfifo[28][7] ) );
  DFFRX1 txfifo_reg25 ( .D(n249), .CK(clk), .RN(rstb), .Q(\txfifo[5][7] ) );
  DFFRX1 txfifo_reg26 ( .D(n281), .CK(clk), .RN(rstb), .Q(\txfifo[9][7] ) );
  DFFRX1 txfifo_reg27 ( .D(n313), .CK(clk), .RN(rstb), .Q(\txfifo[13][7] ) );
  DFFRX1 txfifo_reg28 ( .D(n377), .CK(clk), .RN(rstb), .Q(\txfifo[21][7] ) );
  DFFRX1 txfifo_reg29 ( .D(n409), .CK(clk), .RN(rstb), .Q(\txfifo[25][7] ) );
  DFFRX1 txfifo_reg30 ( .D(n441), .CK(clk), .RN(rstb), .Q(\txfifo[29][7] ) );
  DFFSX1 txdoutsel_reg_0_ ( .D(N112), .CK(clk), .SN(rstb), .QN(n6) );
  DFFRX1 txdoutsel_reg_2_ ( .D(N114), .CK(clk), .RN(rstb), .Q(n1104) );
  DFFSX1 fifordb_reg ( .D(N111), .CK(clk), .SN(rstb), .Q(fifordb), .QN(n1348)
         );
  DFFRX1 txclkcnt_reg_0_ ( .D(n469), .CK(clk), .RN(rstb), .Q(txclkcnt[0]), 
        .QN(n1110) );
  DFFRX1 txclkcnt_reg_1_ ( .D(n470), .CK(clk), .RN(rstb), .Q(txclkcnt[1]), 
        .QN(n1232) );
  DFFRX1 current_state_reg_8_ ( .D(N126), .CK(clk), .RN(rstb), .Q(
        current_state_8_) );
  DFFRX1 current_state_reg_7_ ( .D(N125), .CK(clk), .RN(rstb), .Q(
        current_state_7_) );
  DFFRX1 current_state_reg_6_ ( .D(N124), .CK(clk), .RN(rstb), .Q(
        current_state_6_), .QN(n1164) );
  DFFRX1 current_state_reg_5_ ( .D(N123), .CK(clk), .RN(rstb), .Q(
        current_state_5_), .QN(n1283) );
  DFFRX1 current_state_reg_2_ ( .D(N120), .CK(clk), .RN(rstb), .Q(
        current_state_2_), .QN(n1229) );
  DFFRX1 current_state_reg_9_ ( .D(N127), .CK(clk), .RN(rstb), .Q(
        current_state_9_), .QN(n1231) );
  DFFRX1 txclkcnt_reg_2_ ( .D(n471), .CK(clk), .RN(rstb), .Q(txclkcnt[2]), 
        .QN(n1116) );
  DFFRX1 txclkcnt_reg_3_ ( .D(n472), .CK(clk), .RN(rstb), .Q(txclkcnt[3]), 
        .QN(n1233) );
  DFFRX1 txfifo_reg31 ( .D(n202), .CK(clk), .RN(rstb), .Q(\txfifo[0][0] ), 
        .QN(n1216) );
  DFFRX1 txfifo_reg32 ( .D(n203), .CK(clk), .RN(rstb), .Q(\txfifo[0][1] ), 
        .QN(n1217) );
  DFFRX1 txfifo_reg33 ( .D(n204), .CK(clk), .RN(rstb), .Q(\txfifo[0][2] ), 
        .QN(n1218) );
  DFFRX1 txfifo_reg34 ( .D(n205), .CK(clk), .RN(rstb), .Q(\txfifo[0][3] ), 
        .QN(n1219) );
  DFFRX1 txfifo_reg35 ( .D(n206), .CK(clk), .RN(rstb), .Q(\txfifo[0][4] ), 
        .QN(n1220) );
  DFFRX1 txfifo_reg36 ( .D(n207), .CK(clk), .RN(rstb), .Q(\txfifo[0][5] ), 
        .QN(n1221) );
  DFFRX1 txfifo_reg37 ( .D(n208), .CK(clk), .RN(rstb), .Q(\txfifo[0][6] ), 
        .QN(n1222) );
  DFFRX1 txfifo_reg38 ( .D(n210), .CK(clk), .RN(rstb), .Q(\txfifo[1][0] ), 
        .QN(n1336) );
  DFFRX1 txfifo_reg39 ( .D(n211), .CK(clk), .RN(rstb), .Q(\txfifo[1][1] ), 
        .QN(n1337) );
  DFFRX1 txfifo_reg40 ( .D(n212), .CK(clk), .RN(rstb), .Q(\txfifo[1][2] ), 
        .QN(n1338) );
  DFFRX1 txfifo_reg41 ( .D(n213), .CK(clk), .RN(rstb), .Q(\txfifo[1][3] ), 
        .QN(n1339) );
  DFFRX1 txfifo_reg42 ( .D(n214), .CK(clk), .RN(rstb), .Q(\txfifo[1][4] ), 
        .QN(n1340) );
  DFFRX1 txfifo_reg43 ( .D(n215), .CK(clk), .RN(rstb), .Q(\txfifo[1][5] ), 
        .QN(n1341) );
  DFFRX1 txfifo_reg44 ( .D(n216), .CK(clk), .RN(rstb), .Q(\txfifo[1][6] ), 
        .QN(n1342) );
  DFFRX1 txfifo_reg45 ( .D(n218), .CK(clk), .RN(rstb), .Q(\txfifo[2][0] ), 
        .QN(n1154) );
  DFFRX1 txfifo_reg46 ( .D(n219), .CK(clk), .RN(rstb), .Q(\txfifo[2][1] ), 
        .QN(n1155) );
  DFFRX1 txfifo_reg47 ( .D(n220), .CK(clk), .RN(rstb), .Q(\txfifo[2][2] ), 
        .QN(n1156) );
  DFFRX1 txfifo_reg48 ( .D(n221), .CK(clk), .RN(rstb), .Q(\txfifo[2][3] ), 
        .QN(n1157) );
  DFFRX1 txfifo_reg49 ( .D(n222), .CK(clk), .RN(rstb), .Q(\txfifo[2][4] ), 
        .QN(n1158) );
  DFFRX1 txfifo_reg50 ( .D(n223), .CK(clk), .RN(rstb), .Q(\txfifo[2][5] ), 
        .QN(n1159) );
  DFFRX1 txfifo_reg51 ( .D(n224), .CK(clk), .RN(rstb), .Q(\txfifo[2][6] ), 
        .QN(n1160) );
  DFFRX1 txfifo_reg52 ( .D(n226), .CK(clk), .RN(rstb), .Q(\txfifo[3][0] ), 
        .QN(n1272) );
  DFFRX1 txfifo_reg53 ( .D(n227), .CK(clk), .RN(rstb), .Q(\txfifo[3][1] ), 
        .QN(n1273) );
  DFFRX1 txfifo_reg54 ( .D(n228), .CK(clk), .RN(rstb), .Q(\txfifo[3][2] ), 
        .QN(n1274) );
  DFFRX1 txfifo_reg55 ( .D(n229), .CK(clk), .RN(rstb), .Q(\txfifo[3][3] ), 
        .QN(n1275) );
  DFFRX1 txfifo_reg56 ( .D(n230), .CK(clk), .RN(rstb), .Q(\txfifo[3][4] ), 
        .QN(n1276) );
  DFFRX1 txfifo_reg57 ( .D(n231), .CK(clk), .RN(rstb), .Q(\txfifo[3][5] ), 
        .QN(n1277) );
  DFFRX1 txfifo_reg58 ( .D(n232), .CK(clk), .RN(rstb), .Q(\txfifo[3][6] ), 
        .QN(n1278) );
  DFFRX1 txfifo_reg59 ( .D(n234), .CK(clk), .RN(rstb), .Q(\txfifo[4][0] ), 
        .QN(n1193) );
  DFFRX1 txfifo_reg60 ( .D(n235), .CK(clk), .RN(rstb), .Q(\txfifo[4][1] ), 
        .QN(n1196) );
  DFFRX1 txfifo_reg61 ( .D(n236), .CK(clk), .RN(rstb), .Q(\txfifo[4][2] ), 
        .QN(n1199) );
  DFFRX1 txfifo_reg62 ( .D(n237), .CK(clk), .RN(rstb), .Q(\txfifo[4][3] ), 
        .QN(n1202) );
  DFFRX1 txfifo_reg63 ( .D(n238), .CK(clk), .RN(rstb), .Q(\txfifo[4][4] ), 
        .QN(n1205) );
  DFFRX1 txfifo_reg64 ( .D(n239), .CK(clk), .RN(rstb), .Q(\txfifo[4][5] ), 
        .QN(n1208) );
  DFFRX1 txfifo_reg65 ( .D(n240), .CK(clk), .RN(rstb), .Q(\txfifo[4][6] ), 
        .QN(n1211) );
  DFFRX1 txfifo_reg66 ( .D(n242), .CK(clk), .RN(rstb), .Q(\txfifo[5][0] ), 
        .QN(n1313) );
  DFFRX1 txfifo_reg67 ( .D(n243), .CK(clk), .RN(rstb), .Q(\txfifo[5][1] ), 
        .QN(n1316) );
  DFFRX1 txfifo_reg68 ( .D(n244), .CK(clk), .RN(rstb), .Q(\txfifo[5][2] ), 
        .QN(n1319) );
  DFFRX1 txfifo_reg69 ( .D(n245), .CK(clk), .RN(rstb), .Q(\txfifo[5][3] ), 
        .QN(n1322) );
  DFFRX1 txfifo_reg70 ( .D(n246), .CK(clk), .RN(rstb), .Q(\txfifo[5][4] ), 
        .QN(n1325) );
  DFFRX1 txfifo_reg71 ( .D(n247), .CK(clk), .RN(rstb), .Q(\txfifo[5][5] ), 
        .QN(n1328) );
  DFFRX1 txfifo_reg72 ( .D(n248), .CK(clk), .RN(rstb), .Q(\txfifo[5][6] ), 
        .QN(n1331) );
  DFFRX1 txfifo_reg73 ( .D(n250), .CK(clk), .RN(rstb), .Q(\txfifo[6][0] ), 
        .QN(n1131) );
  DFFRX1 txfifo_reg74 ( .D(n251), .CK(clk), .RN(rstb), .Q(\txfifo[6][1] ), 
        .QN(n1134) );
  DFFRX1 txfifo_reg75 ( .D(n252), .CK(clk), .RN(rstb), .Q(\txfifo[6][2] ), 
        .QN(n1137) );
  DFFRX1 txfifo_reg76 ( .D(n253), .CK(clk), .RN(rstb), .Q(\txfifo[6][3] ), 
        .QN(n1140) );
  DFFRX1 txfifo_reg77 ( .D(n254), .CK(clk), .RN(rstb), .Q(\txfifo[6][4] ), 
        .QN(n1143) );
  DFFRX1 txfifo_reg78 ( .D(n255), .CK(clk), .RN(rstb), .Q(\txfifo[6][5] ), 
        .QN(n1146) );
  DFFRX1 txfifo_reg79 ( .D(n256), .CK(clk), .RN(rstb), .Q(\txfifo[6][6] ), 
        .QN(n1149) );
  DFFRX1 txfifo_reg80 ( .D(n258), .CK(clk), .RN(rstb), .Q(\txfifo[7][0] ), 
        .QN(n1249) );
  DFFRX1 txfifo_reg81 ( .D(n259), .CK(clk), .RN(rstb), .Q(\txfifo[7][1] ), 
        .QN(n1252) );
  DFFRX1 txfifo_reg82 ( .D(n260), .CK(clk), .RN(rstb), .Q(\txfifo[7][2] ), 
        .QN(n1255) );
  DFFRX1 txfifo_reg83 ( .D(n261), .CK(clk), .RN(rstb), .Q(\txfifo[7][3] ), 
        .QN(n1258) );
  DFFRX1 txfifo_reg84 ( .D(n262), .CK(clk), .RN(rstb), .Q(\txfifo[7][4] ), 
        .QN(n1261) );
  DFFRX1 txfifo_reg85 ( .D(n263), .CK(clk), .RN(rstb), .Q(\txfifo[7][5] ), 
        .QN(n1264) );
  DFFRX1 txfifo_reg86 ( .D(n264), .CK(clk), .RN(rstb), .Q(\txfifo[7][6] ), 
        .QN(n1267) );
  DFFRX1 txfifo_reg87 ( .D(n266), .CK(clk), .RN(rstb), .Q(\txfifo[8][0] ), 
        .QN(n1186) );
  DFFRX1 txfifo_reg88 ( .D(n267), .CK(clk), .RN(rstb), .Q(\txfifo[8][1] ), 
        .QN(n1187) );
  DFFRX1 txfifo_reg89 ( .D(n268), .CK(clk), .RN(rstb), .Q(\txfifo[8][2] ), 
        .QN(n1188) );
  DFFRX1 txfifo_reg90 ( .D(n269), .CK(clk), .RN(rstb), .Q(\txfifo[8][3] ), 
        .QN(n1189) );
  DFFRX1 txfifo_reg91 ( .D(n270), .CK(clk), .RN(rstb), .Q(\txfifo[8][4] ), 
        .QN(n1190) );
  DFFRX1 txfifo_reg92 ( .D(n271), .CK(clk), .RN(rstb), .Q(\txfifo[8][5] ), 
        .QN(n1191) );
  DFFRX1 txfifo_reg93 ( .D(n272), .CK(clk), .RN(rstb), .Q(\txfifo[8][6] ), 
        .QN(n1192) );
  DFFRX1 txfifo_reg94 ( .D(n274), .CK(clk), .RN(rstb), .Q(\txfifo[9][0] ), 
        .QN(n1306) );
  DFFRX1 txfifo_reg95 ( .D(n275), .CK(clk), .RN(rstb), .Q(\txfifo[9][1] ), 
        .QN(n1307) );
  DFFRX1 txfifo_reg96 ( .D(n276), .CK(clk), .RN(rstb), .Q(\txfifo[9][2] ), 
        .QN(n1308) );
  DFFRX1 txfifo_reg97 ( .D(n277), .CK(clk), .RN(rstb), .Q(\txfifo[9][3] ), 
        .QN(n1309) );
  DFFRX1 txfifo_reg98 ( .D(n278), .CK(clk), .RN(rstb), .Q(\txfifo[9][4] ), 
        .QN(n1310) );
  DFFRX1 txfifo_reg99 ( .D(n279), .CK(clk), .RN(rstb), .Q(\txfifo[9][5] ), 
        .QN(n1311) );
  DFFRX1 txfifo_reg100 ( .D(n280), .CK(clk), .RN(rstb), .Q(\txfifo[9][6] ), 
        .QN(n1312) );
  DFFRX1 txfifo_reg101 ( .D(n282), .CK(clk), .RN(rstb), .Q(\txfifo[10][0] ), 
        .QN(n1117) );
  DFFRX1 txfifo_reg102 ( .D(n283), .CK(clk), .RN(rstb), .Q(\txfifo[10][1] ), 
        .QN(n1118) );
  DFFRX1 txfifo_reg103 ( .D(n284), .CK(clk), .RN(rstb), .Q(\txfifo[10][2] ), 
        .QN(n1119) );
  DFFRX1 txfifo_reg104 ( .D(n285), .CK(clk), .RN(rstb), .Q(\txfifo[10][3] ), 
        .QN(n1120) );
  DFFRX1 txfifo_reg105 ( .D(n286), .CK(clk), .RN(rstb), .Q(\txfifo[10][4] ), 
        .QN(n1121) );
  DFFRX1 txfifo_reg106 ( .D(n287), .CK(clk), .RN(rstb), .Q(\txfifo[10][5] ), 
        .QN(n1122) );
  DFFRX1 txfifo_reg107 ( .D(n288), .CK(clk), .RN(rstb), .Q(\txfifo[10][6] ), 
        .QN(n1123) );
  DFFRX1 txfifo_reg108 ( .D(n290), .CK(clk), .RN(rstb), .Q(\txfifo[11][0] ), 
        .QN(n1235) );
  DFFRX1 txfifo_reg109 ( .D(n291), .CK(clk), .RN(rstb), .Q(\txfifo[11][1] ), 
        .QN(n1236) );
  DFFRX1 txfifo_reg110 ( .D(n292), .CK(clk), .RN(rstb), .Q(\txfifo[11][2] ), 
        .QN(n1237) );
  DFFRX1 txfifo_reg111 ( .D(n293), .CK(clk), .RN(rstb), .Q(\txfifo[11][3] ), 
        .QN(n1238) );
  DFFRX1 txfifo_reg112 ( .D(n294), .CK(clk), .RN(rstb), .Q(\txfifo[11][4] ), 
        .QN(n1239) );
  DFFRX1 txfifo_reg113 ( .D(n295), .CK(clk), .RN(rstb), .Q(\txfifo[11][5] ), 
        .QN(n1240) );
  DFFRX1 txfifo_reg114 ( .D(n296), .CK(clk), .RN(rstb), .Q(\txfifo[11][6] ), 
        .QN(n1241) );
  DFFRX1 txfifo_reg115 ( .D(n298), .CK(clk), .RN(rstb), .Q(\txfifo[12][0] ), 
        .QN(n1166) );
  DFFRX1 txfifo_reg116 ( .D(n299), .CK(clk), .RN(rstb), .Q(\txfifo[12][1] ), 
        .QN(n1168) );
  DFFRX1 txfifo_reg117 ( .D(n300), .CK(clk), .RN(rstb), .Q(\txfifo[12][2] ), 
        .QN(n1170) );
  DFFRX1 txfifo_reg118 ( .D(n301), .CK(clk), .RN(rstb), .Q(\txfifo[12][3] ), 
        .QN(n1172) );
  DFFRX1 txfifo_reg119 ( .D(n302), .CK(clk), .RN(rstb), .Q(\txfifo[12][4] ), 
        .QN(n1174) );
  DFFRX1 txfifo_reg120 ( .D(n303), .CK(clk), .RN(rstb), .Q(\txfifo[12][5] ), 
        .QN(n1176) );
  DFFRX1 txfifo_reg121 ( .D(n304), .CK(clk), .RN(rstb), .Q(\txfifo[12][6] ), 
        .QN(n1178) );
  DFFRX1 txfifo_reg122 ( .D(n306), .CK(clk), .RN(rstb), .Q(\txfifo[13][0] ), 
        .QN(n1286) );
  DFFRX1 txfifo_reg123 ( .D(n307), .CK(clk), .RN(rstb), .Q(\txfifo[13][1] ), 
        .QN(n1288) );
  DFFRX1 txfifo_reg124 ( .D(n308), .CK(clk), .RN(rstb), .Q(\txfifo[13][2] ), 
        .QN(n1290) );
  DFFRX1 txfifo_reg125 ( .D(n309), .CK(clk), .RN(rstb), .Q(\txfifo[13][3] ), 
        .QN(n1292) );
  DFFRX1 txfifo_reg126 ( .D(n310), .CK(clk), .RN(rstb), .Q(\txfifo[13][4] ), 
        .QN(n1294) );
  DFFRX1 txfifo_reg127 ( .D(n311), .CK(clk), .RN(rstb), .Q(\txfifo[13][5] ), 
        .QN(n1296) );
  DFFRX1 txfifo_reg128 ( .D(n312), .CK(clk), .RN(rstb), .Q(\txfifo[13][6] ), 
        .QN(n1298) );
  DFFRX1 txfifo_reg129 ( .D(n314), .CK(clk), .RN(rstb), .Q(\txfifo[14][0] ), 
        .QN(n1165) );
  DFFRX1 txfifo_reg130 ( .D(n315), .CK(clk), .RN(rstb), .Q(\txfifo[14][1] ), 
        .QN(n1167) );
  DFFRX1 txfifo_reg131 ( .D(n316), .CK(clk), .RN(rstb), .Q(\txfifo[14][2] ), 
        .QN(n1169) );
  DFFRX1 txfifo_reg132 ( .D(n317), .CK(clk), .RN(rstb), .Q(\txfifo[14][3] ), 
        .QN(n1171) );
  DFFRX1 txfifo_reg133 ( .D(n318), .CK(clk), .RN(rstb), .Q(\txfifo[14][4] ), 
        .QN(n1173) );
  DFFRX1 txfifo_reg134 ( .D(n319), .CK(clk), .RN(rstb), .Q(\txfifo[14][5] ), 
        .QN(n1175) );
  DFFRX1 txfifo_reg135 ( .D(n320), .CK(clk), .RN(rstb), .Q(\txfifo[14][6] ), 
        .QN(n1177) );
  DFFRX1 txfifo_reg136 ( .D(n322), .CK(clk), .RN(rstb), .Q(\txfifo[15][0] ), 
        .QN(n1285) );
  DFFRX1 txfifo_reg137 ( .D(n323), .CK(clk), .RN(rstb), .Q(\txfifo[15][1] ), 
        .QN(n1287) );
  DFFRX1 txfifo_reg138 ( .D(n324), .CK(clk), .RN(rstb), .Q(\txfifo[15][2] ), 
        .QN(n1289) );
  DFFRX1 txfifo_reg139 ( .D(n325), .CK(clk), .RN(rstb), .Q(\txfifo[15][3] ), 
        .QN(n1291) );
  DFFRX1 txfifo_reg140 ( .D(n326), .CK(clk), .RN(rstb), .Q(\txfifo[15][4] ), 
        .QN(n1293) );
  DFFRX1 txfifo_reg141 ( .D(n327), .CK(clk), .RN(rstb), .Q(\txfifo[15][5] ), 
        .QN(n1295) );
  DFFRX1 txfifo_reg142 ( .D(n328), .CK(clk), .RN(rstb), .Q(\txfifo[15][6] ), 
        .QN(n1297) );
  DFFRX1 txfifo_reg143 ( .D(n330), .CK(clk), .RN(rstb), .Q(\txfifo[16][0] ), 
        .QN(n1179) );
  DFFRX1 txfifo_reg144 ( .D(n331), .CK(clk), .RN(rstb), .Q(\txfifo[16][1] ), 
        .QN(n1180) );
  DFFRX1 txfifo_reg145 ( .D(n332), .CK(clk), .RN(rstb), .Q(\txfifo[16][2] ), 
        .QN(n1181) );
  DFFRX1 txfifo_reg146 ( .D(n333), .CK(clk), .RN(rstb), .Q(\txfifo[16][3] ), 
        .QN(n1182) );
  DFFRX1 txfifo_reg147 ( .D(n334), .CK(clk), .RN(rstb), .Q(\txfifo[16][4] ), 
        .QN(n1183) );
  DFFRX1 txfifo_reg148 ( .D(n335), .CK(clk), .RN(rstb), .Q(\txfifo[16][5] ), 
        .QN(n1184) );
  DFFRX1 txfifo_reg149 ( .D(n336), .CK(clk), .RN(rstb), .Q(\txfifo[16][6] ), 
        .QN(n1185) );
  DFFRX1 txfifo_reg150 ( .D(n338), .CK(clk), .RN(rstb), .Q(\txfifo[17][0] ), 
        .QN(n1299) );
  DFFRX1 txfifo_reg151 ( .D(n339), .CK(clk), .RN(rstb), .Q(\txfifo[17][1] ), 
        .QN(n1300) );
  DFFRX1 txfifo_reg152 ( .D(n340), .CK(clk), .RN(rstb), .Q(\txfifo[17][2] ), 
        .QN(n1301) );
  DFFRX1 txfifo_reg153 ( .D(n341), .CK(clk), .RN(rstb), .Q(\txfifo[17][3] ), 
        .QN(n1302) );
  DFFRX1 txfifo_reg154 ( .D(n342), .CK(clk), .RN(rstb), .Q(\txfifo[17][4] ), 
        .QN(n1303) );
  DFFRX1 txfifo_reg155 ( .D(n343), .CK(clk), .RN(rstb), .Q(\txfifo[17][5] ), 
        .QN(n1304) );
  DFFRX1 txfifo_reg156 ( .D(n344), .CK(clk), .RN(rstb), .Q(\txfifo[17][6] ), 
        .QN(n1305) );
  DFFRX1 txfifo_reg157 ( .D(n346), .CK(clk), .RN(rstb), .Q(\txfifo[18][0] ), 
        .QN(n1124) );
  DFFRX1 txfifo_reg158 ( .D(n347), .CK(clk), .RN(rstb), .Q(\txfifo[18][1] ), 
        .QN(n1125) );
  DFFRX1 txfifo_reg159 ( .D(n348), .CK(clk), .RN(rstb), .Q(\txfifo[18][2] ), 
        .QN(n1126) );
  DFFRX1 txfifo_reg160 ( .D(n349), .CK(clk), .RN(rstb), .Q(\txfifo[18][3] ), 
        .QN(n1127) );
  DFFRX1 txfifo_reg161 ( .D(n350), .CK(clk), .RN(rstb), .Q(\txfifo[18][4] ), 
        .QN(n1128) );
  DFFRX1 txfifo_reg162 ( .D(n351), .CK(clk), .RN(rstb), .Q(\txfifo[18][5] ), 
        .QN(n1129) );
  DFFRX1 txfifo_reg163 ( .D(n352), .CK(clk), .RN(rstb), .Q(\txfifo[18][6] ), 
        .QN(n1130) );
  DFFRX1 txfifo_reg164 ( .D(n354), .CK(clk), .RN(rstb), .Q(\txfifo[19][0] ), 
        .QN(n1242) );
  DFFRX1 txfifo_reg165 ( .D(n355), .CK(clk), .RN(rstb), .Q(\txfifo[19][1] ), 
        .QN(n1243) );
  DFFRX1 txfifo_reg166 ( .D(n356), .CK(clk), .RN(rstb), .Q(\txfifo[19][2] ), 
        .QN(n1244) );
  DFFRX1 txfifo_reg167 ( .D(n357), .CK(clk), .RN(rstb), .Q(\txfifo[19][3] ), 
        .QN(n1245) );
  DFFRX1 txfifo_reg168 ( .D(n358), .CK(clk), .RN(rstb), .Q(\txfifo[19][4] ), 
        .QN(n1246) );
  DFFRX1 txfifo_reg169 ( .D(n359), .CK(clk), .RN(rstb), .Q(\txfifo[19][5] ), 
        .QN(n1247) );
  DFFRX1 txfifo_reg170 ( .D(n360), .CK(clk), .RN(rstb), .Q(\txfifo[19][6] ), 
        .QN(n1248) );
  DFFRX1 txfifo_reg171 ( .D(n362), .CK(clk), .RN(rstb), .Q(\txfifo[20][0] ), 
        .QN(n1195) );
  DFFRX1 txfifo_reg172 ( .D(n363), .CK(clk), .RN(rstb), .Q(\txfifo[20][1] ), 
        .QN(n1198) );
  DFFRX1 txfifo_reg173 ( .D(n364), .CK(clk), .RN(rstb), .Q(\txfifo[20][2] ), 
        .QN(n1201) );
  DFFRX1 txfifo_reg174 ( .D(n365), .CK(clk), .RN(rstb), .Q(\txfifo[20][3] ), 
        .QN(n1204) );
  DFFRX1 txfifo_reg175 ( .D(n366), .CK(clk), .RN(rstb), .Q(\txfifo[20][4] ), 
        .QN(n1207) );
  DFFRX1 txfifo_reg176 ( .D(n367), .CK(clk), .RN(rstb), .Q(\txfifo[20][5] ), 
        .QN(n1210) );
  DFFRX1 txfifo_reg177 ( .D(n368), .CK(clk), .RN(rstb), .Q(\txfifo[20][6] ), 
        .QN(n1213) );
  DFFRX1 txfifo_reg178 ( .D(n370), .CK(clk), .RN(rstb), .Q(\txfifo[21][0] ), 
        .QN(n1315) );
  DFFRX1 txfifo_reg179 ( .D(n371), .CK(clk), .RN(rstb), .Q(\txfifo[21][1] ), 
        .QN(n1318) );
  DFFRX1 txfifo_reg180 ( .D(n372), .CK(clk), .RN(rstb), .Q(\txfifo[21][2] ), 
        .QN(n1321) );
  DFFRX1 txfifo_reg181 ( .D(n373), .CK(clk), .RN(rstb), .Q(\txfifo[21][3] ), 
        .QN(n1324) );
  DFFRX1 txfifo_reg182 ( .D(n374), .CK(clk), .RN(rstb), .Q(\txfifo[21][4] ), 
        .QN(n1327) );
  DFFRX1 txfifo_reg183 ( .D(n375), .CK(clk), .RN(rstb), .Q(\txfifo[21][5] ), 
        .QN(n1330) );
  DFFRX1 txfifo_reg184 ( .D(n376), .CK(clk), .RN(rstb), .Q(\txfifo[21][6] ), 
        .QN(n1333) );
  DFFRX1 txfifo_reg185 ( .D(n378), .CK(clk), .RN(rstb), .Q(\txfifo[22][0] ), 
        .QN(n1133) );
  DFFRX1 txfifo_reg186 ( .D(n379), .CK(clk), .RN(rstb), .Q(\txfifo[22][1] ), 
        .QN(n1136) );
  DFFRX1 txfifo_reg187 ( .D(n380), .CK(clk), .RN(rstb), .Q(\txfifo[22][2] ), 
        .QN(n1139) );
  DFFRX1 txfifo_reg188 ( .D(n381), .CK(clk), .RN(rstb), .Q(\txfifo[22][3] ), 
        .QN(n1142) );
  DFFRX1 txfifo_reg189 ( .D(n382), .CK(clk), .RN(rstb), .Q(\txfifo[22][4] ), 
        .QN(n1145) );
  DFFRX1 txfifo_reg190 ( .D(n383), .CK(clk), .RN(rstb), .Q(\txfifo[22][5] ), 
        .QN(n1148) );
  DFFRX1 txfifo_reg191 ( .D(n384), .CK(clk), .RN(rstb), .Q(\txfifo[22][6] ), 
        .QN(n1151) );
  DFFRX1 txfifo_reg192 ( .D(n386), .CK(clk), .RN(rstb), .Q(\txfifo[23][0] ), 
        .QN(n1251) );
  DFFRX1 txfifo_reg193 ( .D(n387), .CK(clk), .RN(rstb), .Q(\txfifo[23][1] ), 
        .QN(n1254) );
  DFFRX1 txfifo_reg194 ( .D(n388), .CK(clk), .RN(rstb), .Q(\txfifo[23][2] ), 
        .QN(n1257) );
  DFFRX1 txfifo_reg195 ( .D(n389), .CK(clk), .RN(rstb), .Q(\txfifo[23][3] ), 
        .QN(n1260) );
  DFFRX1 txfifo_reg196 ( .D(n390), .CK(clk), .RN(rstb), .Q(\txfifo[23][4] ), 
        .QN(n1263) );
  DFFRX1 txfifo_reg197 ( .D(n391), .CK(clk), .RN(rstb), .Q(\txfifo[23][5] ), 
        .QN(n1266) );
  DFFRX1 txfifo_reg198 ( .D(n392), .CK(clk), .RN(rstb), .Q(\txfifo[23][6] ), 
        .QN(n1269) );
  DFFRX1 txfifo_reg199 ( .D(n394), .CK(clk), .RN(rstb), .Q(\txfifo[24][0] ), 
        .QN(n1194) );
  DFFRX1 txfifo_reg200 ( .D(n395), .CK(clk), .RN(rstb), .Q(\txfifo[24][1] ), 
        .QN(n1197) );
  DFFRX1 txfifo_reg201 ( .D(n396), .CK(clk), .RN(rstb), .Q(\txfifo[24][2] ), 
        .QN(n1200) );
  DFFRX1 txfifo_reg202 ( .D(n397), .CK(clk), .RN(rstb), .Q(\txfifo[24][3] ), 
        .QN(n1203) );
  DFFRX1 txfifo_reg203 ( .D(n398), .CK(clk), .RN(rstb), .Q(\txfifo[24][4] ), 
        .QN(n1206) );
  DFFRX1 txfifo_reg204 ( .D(n399), .CK(clk), .RN(rstb), .Q(\txfifo[24][5] ), 
        .QN(n1209) );
  DFFRX1 txfifo_reg205 ( .D(n400), .CK(clk), .RN(rstb), .Q(\txfifo[24][6] ), 
        .QN(n1212) );
  DFFRX1 txfifo_reg206 ( .D(n402), .CK(clk), .RN(rstb), .Q(\txfifo[25][0] ), 
        .QN(n1314) );
  DFFRX1 txfifo_reg207 ( .D(n403), .CK(clk), .RN(rstb), .Q(\txfifo[25][1] ), 
        .QN(n1317) );
  DFFRX1 txfifo_reg208 ( .D(n404), .CK(clk), .RN(rstb), .Q(\txfifo[25][2] ), 
        .QN(n1320) );
  DFFRX1 txfifo_reg209 ( .D(n405), .CK(clk), .RN(rstb), .Q(\txfifo[25][3] ), 
        .QN(n1323) );
  DFFRX1 txfifo_reg210 ( .D(n406), .CK(clk), .RN(rstb), .Q(\txfifo[25][4] ), 
        .QN(n1326) );
  DFFRX1 txfifo_reg211 ( .D(n407), .CK(clk), .RN(rstb), .Q(\txfifo[25][5] ), 
        .QN(n1329) );
  DFFRX1 txfifo_reg212 ( .D(n408), .CK(clk), .RN(rstb), .Q(\txfifo[25][6] ), 
        .QN(n1332) );
  DFFRX1 txfifo_reg213 ( .D(n410), .CK(clk), .RN(rstb), .Q(\txfifo[26][0] ), 
        .QN(n1132) );
  DFFRX1 txfifo_reg214 ( .D(n411), .CK(clk), .RN(rstb), .Q(\txfifo[26][1] ), 
        .QN(n1135) );
  DFFRX1 txfifo_reg215 ( .D(n412), .CK(clk), .RN(rstb), .Q(\txfifo[26][2] ), 
        .QN(n1138) );
  DFFRX1 txfifo_reg216 ( .D(n413), .CK(clk), .RN(rstb), .Q(\txfifo[26][3] ), 
        .QN(n1141) );
  DFFRX1 txfifo_reg217 ( .D(n414), .CK(clk), .RN(rstb), .Q(\txfifo[26][4] ), 
        .QN(n1144) );
  DFFRX1 txfifo_reg218 ( .D(n415), .CK(clk), .RN(rstb), .Q(\txfifo[26][5] ), 
        .QN(n1147) );
  DFFRX1 txfifo_reg219 ( .D(n416), .CK(clk), .RN(rstb), .Q(\txfifo[26][6] ), 
        .QN(n1150) );
  DFFRX1 txfifo_reg220 ( .D(n418), .CK(clk), .RN(rstb), .Q(\txfifo[27][0] ), 
        .QN(n1250) );
  DFFRX1 txfifo_reg221 ( .D(n419), .CK(clk), .RN(rstb), .Q(\txfifo[27][1] ), 
        .QN(n1253) );
  DFFRX1 txfifo_reg222 ( .D(n420), .CK(clk), .RN(rstb), .Q(\txfifo[27][2] ), 
        .QN(n1256) );
  DFFRX1 txfifo_reg223 ( .D(n421), .CK(clk), .RN(rstb), .Q(\txfifo[27][3] ), 
        .QN(n1259) );
  DFFRX1 txfifo_reg224 ( .D(n422), .CK(clk), .RN(rstb), .Q(\txfifo[27][4] ), 
        .QN(n1262) );
  DFFRX1 txfifo_reg225 ( .D(n423), .CK(clk), .RN(rstb), .Q(\txfifo[27][5] ), 
        .QN(n1265) );
  DFFRX1 txfifo_reg226 ( .D(n424), .CK(clk), .RN(rstb), .Q(\txfifo[27][6] ), 
        .QN(n1268) );
  DFFRX1 current_state_reg_1_ ( .D(n1343), .CK(clk), .RN(rstb), .Q(
        current_state_1_), .QN(n1282) );
  DFFSX1 txclkcntenb_reg ( .D(N116), .CK(clk), .SN(rstb), .QN(n1226) );
  DFFRX1 current_state_reg_10_ ( .D(N128), .CK(clk), .RN(rstb), .Q(
        current_state_10_), .QN(n1114) );
  DFFRX1 shiftreg_reg_1_ ( .D(n474), .CK(clk), .RN(rstb), .QN(n1161) );
  DFFRX1 shiftreg_reg_2_ ( .D(n475), .CK(clk), .RN(rstb), .QN(n1279) );
  DFFRX1 shiftreg_reg_3_ ( .D(n476), .CK(clk), .RN(rstb), .QN(n1162) );
  DFFRX1 shiftreg_reg_4_ ( .D(n477), .CK(clk), .RN(rstb), .QN(n1280) );
  DFFRX1 shiftreg_reg_5_ ( .D(n478), .CK(clk), .RN(rstb), .QN(n1163) );
  DFFRX1 shiftreg_reg_6_ ( .D(n479), .CK(clk), .RN(rstb), .QN(n1281) );
  DFFRX1 shiftreg_reg_7_ ( .D(n480), .CK(clk), .RN(rstb), .QN(n1115) );
  DFFRX1 current_state_reg_12_ ( .D(N130), .CK(clk), .RN(rstb), .QN(n1234) );
  DFFRX1 current_state_reg_11_ ( .D(N129), .CK(clk), .RN(rstb), .QN(n1109) );
  DFFRX1 current_state_reg_3_ ( .D(N121), .CK(clk), .RN(rstb), .Q(
        current_state_3_) );
  DFFRX1 current_state_reg_4_ ( .D(N122), .CK(clk), .RN(rstb), .Q(
        current_state_4_) );
  DFFRX1 dtxclk_reg ( .D(txclk), .CK(clk), .RN(rstb), .Q(dtxclk) );
  DFFRX1 txfifo_reg227 ( .D(n450), .CK(clk), .RN(rstb), .Q(\txfifo[31][0] ) );
  DFFRX1 txfifo_reg228 ( .D(n451), .CK(clk), .RN(rstb), .Q(\txfifo[31][1] ) );
  DFFRX1 txfifo_reg229 ( .D(n452), .CK(clk), .RN(rstb), .Q(\txfifo[31][2] ) );
  DFFRX1 txfifo_reg230 ( .D(n453), .CK(clk), .RN(rstb), .Q(\txfifo[31][3] ) );
  DFFRX1 txfifo_reg231 ( .D(n454), .CK(clk), .RN(rstb), .Q(\txfifo[31][4] ) );
  DFFRX1 txfifo_reg232 ( .D(n455), .CK(clk), .RN(rstb), .Q(\txfifo[31][5] ) );
  DFFRX1 txfifo_reg233 ( .D(n456), .CK(clk), .RN(rstb), .Q(\txfifo[31][6] ) );
  DFFRX1 txfifo_reg234 ( .D(n442), .CK(clk), .RN(rstb), .Q(\txfifo[30][0] ) );
  DFFRX1 txfifo_reg235 ( .D(n443), .CK(clk), .RN(rstb), .Q(\txfifo[30][1] ) );
  DFFRX1 txfifo_reg236 ( .D(n444), .CK(clk), .RN(rstb), .Q(\txfifo[30][2] ) );
  DFFRX1 txfifo_reg237 ( .D(n445), .CK(clk), .RN(rstb), .Q(\txfifo[30][3] ) );
  DFFRX1 txfifo_reg238 ( .D(n446), .CK(clk), .RN(rstb), .Q(\txfifo[30][4] ) );
  DFFRX1 txfifo_reg239 ( .D(n447), .CK(clk), .RN(rstb), .Q(\txfifo[30][5] ) );
  DFFRX1 txfifo_reg240 ( .D(n448), .CK(clk), .RN(rstb), .Q(\txfifo[30][6] ) );
  DFFSX1 current_state_reg_0_ ( .D(N118), .CK(clk), .SN(rstb), .QN(n9) );
  DFFSX1 shiftenb_reg ( .D(N110), .CK(clk), .SN(rstb), .Q(shiftenb) );
  DFFRX1 txfifo_reg241 ( .D(n426), .CK(clk), .RN(rstb), .Q(\txfifo[28][0] ) );
  DFFRX1 txfifo_reg242 ( .D(n427), .CK(clk), .RN(rstb), .Q(\txfifo[28][1] ) );
  DFFRX1 txfifo_reg243 ( .D(n428), .CK(clk), .RN(rstb), .Q(\txfifo[28][2] ) );
  DFFRX1 txfifo_reg244 ( .D(n429), .CK(clk), .RN(rstb), .Q(\txfifo[28][3] ) );
  DFFRX1 txfifo_reg245 ( .D(n430), .CK(clk), .RN(rstb), .Q(\txfifo[28][4] ) );
  DFFRX1 txfifo_reg246 ( .D(n431), .CK(clk), .RN(rstb), .Q(\txfifo[28][5] ) );
  DFFRX1 txfifo_reg247 ( .D(n432), .CK(clk), .RN(rstb), .Q(\txfifo[28][6] ) );
  DFFRX1 txfifo_reg248 ( .D(n434), .CK(clk), .RN(rstb), .Q(\txfifo[29][0] ) );
  DFFRX1 txfifo_reg249 ( .D(n435), .CK(clk), .RN(rstb), .Q(\txfifo[29][1] ) );
  DFFRX1 txfifo_reg250 ( .D(n436), .CK(clk), .RN(rstb), .Q(\txfifo[29][2] ) );
  DFFRX1 txfifo_reg251 ( .D(n437), .CK(clk), .RN(rstb), .Q(\txfifo[29][3] ) );
  DFFRX1 txfifo_reg252 ( .D(n438), .CK(clk), .RN(rstb), .Q(\txfifo[29][4] ) );
  DFFRX1 txfifo_reg253 ( .D(n439), .CK(clk), .RN(rstb), .Q(\txfifo[29][5] ) );
  DFFRX1 txfifo_reg254 ( .D(n440), .CK(clk), .RN(rstb), .Q(\txfifo[29][6] ) );
  DFFRX1 txbusy_int_reg ( .D(N117), .CK(clk), .RN(rstb), .Q(txbusy) );
endmodule


module RxBlock_UART_FIFO_WIDTH5_1 ( baudx16clk, clk, databit, fifordb, 
        loopbacken, parity, rstb, rxd, stopbit, swrst, txd, uarten, 
        bytereceivedb, fifodata_rx, frameerror, overrunerror, parityerror, 
        rxbusy, rxfifocnt, rxfifoempty, frameerr_clear, parityerr_clear, 
        overrunerr_clear );
  input [1:0] parity;
  output [7:0] fifodata_rx;
  output [5:0] rxfifocnt;
  input baudx16clk, clk, databit, fifordb, loopbacken, rstb, rxd, stopbit,
         swrst, txd, uarten, frameerr_clear, parityerr_clear, overrunerr_clear;
  output bytereceivedb, frameerror, overrunerror, parityerror, rxbusy,
         rxfifoempty;
  wire   N70, N71, N72, N73, N74, current_state_16_, current_state_14_,
         current_state_13_, current_state_11_, current_state_10_,
         current_state_9_, current_state_8_, current_state_7_,
         current_state_6_, current_state_5_, current_state_4_,
         current_state_3_, current_state_2_, current_state_1_, fifo_wrpos_4_,
         fifo_wrpos_3_, fifo_wrpos_2_, fifo_wrpos_0_, \rxfifo[31][7] ,
         \rxfifo[31][6] , \rxfifo[31][5] , \rxfifo[31][4] , \rxfifo[31][3] ,
         \rxfifo[31][2] , \rxfifo[31][1] , \rxfifo[31][0] , \rxfifo[30][7] ,
         \rxfifo[30][6] , \rxfifo[30][5] , \rxfifo[30][4] , \rxfifo[30][3] ,
         \rxfifo[30][2] , \rxfifo[30][1] , \rxfifo[30][0] , \rxfifo[29][7] ,
         \rxfifo[29][6] , \rxfifo[29][5] , \rxfifo[29][4] , \rxfifo[29][3] ,
         \rxfifo[29][2] , \rxfifo[29][1] , \rxfifo[29][0] , \rxfifo[28][7] ,
         \rxfifo[28][6] , \rxfifo[28][5] , \rxfifo[28][4] , \rxfifo[28][3] ,
         \rxfifo[28][2] , \rxfifo[28][1] , \rxfifo[28][0] , \rxfifo[27][7] ,
         \rxfifo[27][6] , \rxfifo[27][5] , \rxfifo[27][4] , \rxfifo[27][3] ,
         \rxfifo[27][2] , \rxfifo[27][1] , \rxfifo[27][0] , \rxfifo[26][7] ,
         \rxfifo[26][6] , \rxfifo[26][5] , \rxfifo[26][4] , \rxfifo[26][3] ,
         \rxfifo[26][2] , \rxfifo[26][1] , \rxfifo[26][0] , \rxfifo[25][7] ,
         \rxfifo[25][6] , \rxfifo[25][5] , \rxfifo[25][4] , \rxfifo[25][3] ,
         \rxfifo[25][2] , \rxfifo[25][1] , \rxfifo[25][0] , \rxfifo[24][7] ,
         \rxfifo[24][6] , \rxfifo[24][5] , \rxfifo[24][4] , \rxfifo[24][3] ,
         \rxfifo[24][2] , \rxfifo[24][1] , \rxfifo[24][0] , \rxfifo[23][7] ,
         \rxfifo[23][6] , \rxfifo[23][5] , \rxfifo[23][4] , \rxfifo[23][3] ,
         \rxfifo[23][2] , \rxfifo[23][1] , \rxfifo[23][0] , \rxfifo[22][7] ,
         \rxfifo[22][6] , \rxfifo[22][5] , \rxfifo[22][4] , \rxfifo[22][3] ,
         \rxfifo[22][2] , \rxfifo[22][1] , \rxfifo[22][0] , \rxfifo[21][7] ,
         \rxfifo[21][6] , \rxfifo[21][5] , \rxfifo[21][4] , \rxfifo[21][3] ,
         \rxfifo[21][2] , \rxfifo[21][1] , \rxfifo[21][0] , \rxfifo[20][7] ,
         \rxfifo[20][6] , \rxfifo[20][5] , \rxfifo[20][4] , \rxfifo[20][3] ,
         \rxfifo[20][2] , \rxfifo[20][1] , \rxfifo[20][0] , \rxfifo[19][7] ,
         \rxfifo[19][6] , \rxfifo[19][5] , \rxfifo[19][4] , \rxfifo[19][3] ,
         \rxfifo[19][2] , \rxfifo[19][1] , \rxfifo[19][0] , \rxfifo[18][7] ,
         \rxfifo[18][6] , \rxfifo[18][5] , \rxfifo[18][4] , \rxfifo[18][3] ,
         \rxfifo[18][2] , \rxfifo[18][1] , \rxfifo[18][0] , \rxfifo[17][7] ,
         \rxfifo[17][6] , \rxfifo[17][5] , \rxfifo[17][4] , \rxfifo[17][3] ,
         \rxfifo[17][2] , \rxfifo[17][1] , \rxfifo[17][0] , \rxfifo[16][7] ,
         \rxfifo[16][6] , \rxfifo[16][5] , \rxfifo[16][4] , \rxfifo[16][3] ,
         \rxfifo[16][2] , \rxfifo[16][1] , \rxfifo[16][0] , \rxfifo[15][7] ,
         \rxfifo[15][6] , \rxfifo[15][5] , \rxfifo[15][4] , \rxfifo[15][3] ,
         \rxfifo[15][2] , \rxfifo[15][1] , \rxfifo[15][0] , \rxfifo[14][7] ,
         \rxfifo[14][6] , \rxfifo[14][5] , \rxfifo[14][4] , \rxfifo[14][3] ,
         \rxfifo[14][2] , \rxfifo[14][1] , \rxfifo[14][0] , \rxfifo[13][7] ,
         \rxfifo[13][6] , \rxfifo[13][5] , \rxfifo[13][4] , \rxfifo[13][3] ,
         \rxfifo[13][2] , \rxfifo[13][1] , \rxfifo[13][0] , \rxfifo[12][7] ,
         \rxfifo[12][6] , \rxfifo[12][5] , \rxfifo[12][4] , \rxfifo[12][3] ,
         \rxfifo[12][2] , \rxfifo[12][1] , \rxfifo[12][0] , \rxfifo[11][7] ,
         \rxfifo[11][6] , \rxfifo[11][5] , \rxfifo[11][4] , \rxfifo[11][3] ,
         \rxfifo[11][2] , \rxfifo[11][1] , \rxfifo[11][0] , \rxfifo[10][7] ,
         \rxfifo[10][6] , \rxfifo[10][5] , \rxfifo[10][4] , \rxfifo[10][3] ,
         \rxfifo[10][2] , \rxfifo[10][1] , \rxfifo[10][0] , \rxfifo[9][7] ,
         \rxfifo[9][6] , \rxfifo[9][5] , \rxfifo[9][4] , \rxfifo[9][3] ,
         \rxfifo[9][2] , \rxfifo[9][1] , \rxfifo[9][0] , \rxfifo[8][7] ,
         \rxfifo[8][6] , \rxfifo[8][5] , \rxfifo[8][4] , \rxfifo[8][3] ,
         \rxfifo[8][2] , \rxfifo[8][1] , \rxfifo[8][0] , \rxfifo[7][7] ,
         \rxfifo[7][6] , \rxfifo[7][5] , \rxfifo[7][4] , \rxfifo[7][3] ,
         \rxfifo[7][2] , \rxfifo[7][1] , \rxfifo[7][0] , \rxfifo[6][7] ,
         \rxfifo[6][6] , \rxfifo[6][5] , \rxfifo[6][4] , \rxfifo[6][3] ,
         \rxfifo[6][2] , \rxfifo[6][1] , \rxfifo[6][0] , \rxfifo[5][7] ,
         \rxfifo[5][6] , \rxfifo[5][5] , \rxfifo[5][4] , \rxfifo[5][3] ,
         \rxfifo[5][2] , \rxfifo[5][1] , \rxfifo[5][0] , \rxfifo[4][7] ,
         \rxfifo[4][6] , \rxfifo[4][5] , \rxfifo[4][4] , \rxfifo[4][3] ,
         \rxfifo[4][2] , \rxfifo[4][1] , \rxfifo[4][0] , \rxfifo[3][7] ,
         \rxfifo[3][6] , \rxfifo[3][5] , \rxfifo[3][4] , \rxfifo[3][3] ,
         \rxfifo[3][2] , \rxfifo[3][1] , \rxfifo[3][0] , \rxfifo[2][7] ,
         \rxfifo[2][6] , \rxfifo[2][5] , \rxfifo[2][4] , \rxfifo[2][3] ,
         \rxfifo[2][2] , \rxfifo[2][1] , \rxfifo[2][0] , \rxfifo[1][7] ,
         \rxfifo[1][6] , \rxfifo[1][5] , \rxfifo[1][4] , \rxfifo[1][3] ,
         \rxfifo[1][2] , \rxfifo[1][1] , \rxfifo[1][0] , \rxfifo[0][7] ,
         \rxfifo[0][6] , \rxfifo[0][5] , \rxfifo[0][4] , \rxfifo[0][3] ,
         \rxfifo[0][2] , \rxfifo[0][1] , \rxfifo[0][0] , rx_lpfd, rxsftenb,
         rxclk, framechkb, paritychkb, parity_int, dataphaseb, rxclkenb, N443,
         N511, N512, N513, N514, N515, N516, N517, N518, N519, N520, N521,
         N522, N523, N524, N525, N526, N527, N528, N622, N623, N624, N633,
         N634, N635, n17, n18, n276, n277, n278, n279, n280, n281, n282, n283,
         n284, n285, n286, n287, n288, n289, n290, n291, n292, n293, n294,
         n295, n296, n297, n298, n299, n300, n301, n302, n303, n304, n305,
         n306, n307, n308, n309, n310, n311, n312, n313, n314, n315, n316,
         n317, n318, n319, n320, n321, n322, n323, n324, n325, n326, n327,
         n328, n329, n330, n331, n332, n333, n334, n335, n336, n337, n338,
         n339, n340, n341, n342, n343, n344, n345, n346, n347, n348, n349,
         n350, n351, n352, n353, n354, n355, n356, n357, n358, n359, n360,
         n361, n362, n363, n364, n365, n366, n367, n368, n369, n370, n371,
         n372, n373, n374, n375, n376, n377, n378, n379, n380, n381, n382,
         n383, n384, n385, n386, n387, n388, n389, n390, n391, n392, n393,
         n394, n395, n396, n397, n398, n399, n400, n401, n402, n403, n404,
         n405, n406, n407, n408, n409, n410, n411, n412, n413, n414, n415,
         n416, n417, n418, n419, n420, n421, n422, n423, n424, n425, n426,
         n427, n428, n429, n430, n431, n432, n433, n434, n435, n436, n437,
         n438, n439, n440, n441, n442, n4430, n444, n445, n446, n447, n448,
         n449, n450, n451, n452, n453, n454, n455, n456, n457, n458, n459,
         n460, n461, n462, n463, n464, n465, n466, n467, n468, n469, n470,
         n471, n472, n473, n474, n475, n476, n477, n478, n479, n480, n481,
         n482, n483, n484, n485, n486, n487, n488, n489, n490, n491, n492,
         n493, n494, n495, n496, n497, n498, n499, n500, n501, n502, n503,
         n504, n505, n506, n507, n508, n509, n510, n5110, n5120, n5130, n5140,
         n5150, n5160, n5170, n5180, n5190, n5200, n5210, n5220, n5230, n5240,
         n5250, n5260, n5270, n5280, n529, n530, n531, n532, n533, n534, n535,
         n536, n537, n538, n539, n540, n541, n542, n543, n544, n545, n546,
         n547, n548, n549, n550, n551, n552, n553, n554, n555, n556, n557,
         n558, n559, n560, n561, n562, n563, n564, n565, n566, n567, n568,
         n569, n570, n571, n572, n573, n574, n575, n576, n578, carry_4_, carry,
         carry0, carry_1_, n5, n6, n7, carry1, carry2, n11, n2100, n3100,
         carry_3_, carry_2_, n1, n2, n3, n617, n618, n619, n621, n6220, n6230,
         n6240, n625, n626, n628, n630, n631, n632, n6330, n6340, n6350, n637,
         n638, n639, n640, n641, n642, n643, n644, n645, n647, n648, n650,
         n651, n652, n653, n654, n655, n656, n657, n658, n659, n660, n661,
         n663, n664, n665, n667, n668, n669, n671, n672, n673, n675, n676,
         n677, n679, n680, n681, n683, n684, n685, n687, n688, n689, n690,
         n691, n692, n693, n694, n695, n696, n697, n698, n699, n700, n701,
         n702, n703, n704, n705, n707, n708, n709, n710, n711, n712, n713,
         n714, n715, n716, n717, n718, n719, n720, n721, n722, n723, n724,
         n725, n726, n727, n728, n730, n731, n732, n733, n734, n735, n736,
         n737, n738, n739, n740, n741, n742, n743, n744, n746, n748, n749,
         n750, n751, n752, n753, n754, n755, n756, n760, n761, n766, n767,
         n768, n769, n770, n771, n773, n774, n775, n776, n777, n778, n779,
         n780, n781, n783, n784, n785, n786, n788, n789, n790, n791, n792,
         n793, n796, n797, n798, n800, n801, n803, n804, n807, n808, n809,
         n810, n811, n812, n813, n814, n815, n817, n819, n820, n821, n822,
         n824, n825, n826, n827, n830, n831, n832, n833, n834, n835, n836,
         n838, n839, n840, n841, n842, n843, n848, n849, n850, n851, n852,
         n853, n854, n855, n858, n859, n863, n865, n866, n867, n868, n869,
         n872, n873, n874, n875, n876, n877, n879, n881, n882, n884, n886,
         n888, n890, n891, n893, n895, n897, n899, n900, n902, n904, n906,
         n908, n909, n911, n913, n914, n915, n916, n917, n920, n925, n930,
         n935, n938, n939, n940, n941, n942, n943, n946, n951, n956, n961,
         n964, n965, n966, n967, n970, n975, n980, n985, n988, n989, n990,
         n991, n992, n993, n996, n1001, n1006, n1011, n1014, n1015, n1016,
         n1017, n1020, n1025, n1030, n1035, n1038, n1039, n1040, n1041, n1042,
         n1043, n1046, n1051, n1056, n1061, n1064, n1065, n1066, n1067, n1070,
         n1075, n1080, n1085, n1088, n1089, n1090, n1091, n1092, n1093, n1096,
         n1101, n1106, n1111, n1114, n1115, n1116, n1117, n1120, n1125, n1130,
         n1135, n1138, n1139, n1140, n1141, n1142, n1143, n1146, n1151, n1156,
         n1161, n1164, n1165, n1166, n1167, n1170, n1175, n1180, n1185, n1188,
         n1189, n1190, n1191, n1192, n1193, n1196, n1201, n1206, n1211, n1214,
         n1215, n1216, n1217, n1220, n1225, n1230, n1235, n1238, n1239, n1240,
         n1241, n1242, n1243, n1246, n1251, n1256, n1261, n1264, n1265, n1266,
         n1267, n1270, n1273, n1274, n1275, n1276, n1277, n1278, n1281, n1284,
         n1290, n1294, n1298, n1301, n1302, n1303, n1305, n1307, n1308, n1310,
         n1311, n1314, n1315, n1323, n1324, n1325, n1326, n1329, n1330, n1331,
         n1332, n1333, n1334, n1335, n1336, n1337, n1338, n1339, n1340, n1341,
         n1342, n1343, n1344, n1345, n1346, n1347, n1348, n1349, n1350, n1351,
         n1352, n1353, n1354, n1355, n1356, n1357, n1358, n1359, n1360, n1361,
         n1362, n1363, n1364, n1365, n1366, n1367, n1368, n1369, n1370, n1371,
         n1372, n1373, n1374, n1375, n1376, n1377, n1378, n1379, n1380, n1381,
         n1382, n1383, n1384, n1385, n1386, n1387, n1388, n1389, n1390, n1391,
         n1392, n1393, n1394, n1395, n1396, n1397, n1398, n1399, n1400, n1401,
         n1402, n1403, n1404, n1405, n1406, n1407, n1408, n1409, n1410, n1411,
         n1412, n1413, n1414, n1415, n1416, n1417, n1418, n1419, n1420, n1421,
         n1422, n1423, n1424, n1425, n1426, n1427, n1428, n1429, n1430, n1431,
         n1432, n1433, n1434, n1435, n1436, n1437, n1438, n1439, n1440, n1441,
         n1442, n1443, n1444, n1445, n1446, n1447, n1448, n1449, n1450, n1451,
         n1452, n1453, n1454, n1455, n1456, n1457, n1458, n1459, n1460, n1461,
         n1462, n1463, n1464, n1465, n1466, n1467, n1468, n1469, n1470, n1471,
         n1472, n1473, n1474, n1475, n1476, n1477, n1478, n1479, n1480, n1481,
         n1482, n1483, n1484, n1485, n1486, n1487, n1488, n1489, n1490, n1491,
         n1492, n1493, n1494, n1495, n1496, n1497, n1498, n1499, n1500, n1501,
         n1502, n1503, n1504, n1505, n1506, n1507, n1508, n1509, n1510, n1511,
         n1512, n1513, n1514, n1515, n1516, n1517, n1518, n1519, n1520, n1521,
         n1522, n1523, n1524, n1525, n1526, n1527, n1528, n1529, n1530, n1531,
         n1532, n1533, n1534, n1535, n1536, n1537, n1538, n1539, n1540, n1541,
         n1542, n1543, n1544, n1545, n1546, n1547, n1548, n1549, n1550, n1551,
         n1552, n1553, n1554, n1555, n1556, n1557, n1558, n1559, n1560, n1561,
         n1562, n1563, n1564, n1565, n1566, n1567, n1568, n1569, n1570, n1571,
         n1572, n1573, n1574, n1575, n1576, n1577, n1578, n1579, n1580, n1581,
         n1582, n1583, n1584, n1585, n1586, n1587, n1588, n1589, n1590, n1591,
         n1592, n1593, n1594, n1595, n1596, n1597, n1598, n1599, n1600, n1601,
         n1602, n1603, n1604, n1605, n1606, n1607, n1608, n1609, n1610, n1611,
         n1612, n1613, n1614, n1615, n1616, n1617, n1618, n1619, n1620, n1621,
         n1622, n1623, n1624, n1625, n1626, n1627, n1628, n1629, n1630, n1631,
         n1632, n1633, n1634, n1635, n1636, n1637, n1638, n1639, n1640, n1641,
         n1642, n1643, n1644, n1645, n1646, n1647;
  wire   [7:0] rxsftreg;
  wire   [5:0] in_dly;
  wire   [3:0] rxclkcnt;

  AHHCONX2 U1_1_11 ( .A(n1647), .CI(n1646), .S(N622), .CON(n3100) );
  AHHCONX2 U1_1_21 ( .A(fifo_wrpos_2_), .CI(carry2), .S(N623), .CON(n2100) );
  AHHCONX2 U1_1_31 ( .A(fifo_wrpos_3_), .CI(carry1), .S(N624), .CON(n11) );
  AHHCONX2 U1_1_1 ( .A(N71), .CI(N70), .S(N633), .CON(n3) );
  AHHCONX2 U1_1_2 ( .A(N72), .CI(carry_2_), .S(N634), .CON(n2) );
  AHHCONX2 U1_1_3 ( .A(N73), .CI(carry_3_), .S(N635), .CON(n1) );
  INVX1 U1684 ( .A(databit), .Y(n746) );
  INVX1 U1685 ( .A(n813), .Y(n808) );
  NAND3BX1 U1686 ( .AN(n822), .B(n843), .C(n1618), .Y(n834) );
  OA22X1 U1687 ( .A0(n827), .A1(n835), .B0(n826), .B1(n850), .Y(n843) );
  NAND2BX1 U1688 ( .AN(n834), .B(n830), .Y(n813) );
  AO22X1 U1689 ( .A0(n840), .A1(n849), .B0(n853), .B1(n854), .Y(n822) );
  INVX1 U1690 ( .A(n849), .Y(n838) );
  INVX1 U1691 ( .A(n835), .Y(n836) );
  AND2X2 U1692 ( .A(n831), .B(n821), .Y(n1618) );
  INVX1 U1693 ( .A(n850), .Y(n853) );
  INVX1 U1694 ( .A(n825), .Y(n820) );
  NAND3BX1 U1695 ( .AN(n817), .B(n826), .C(n827), .Y(n825) );
  INVX1 U1696 ( .A(n817), .Y(n807) );
  INVX1 U1697 ( .A(rxfifocnt[0]), .Y(n642) );
  INVX1 U1698 ( .A(n733), .Y(n734) );
  INVX1 U1699 ( .A(n730), .Y(n731) );
  INVX1 U1700 ( .A(n713), .Y(n714) );
  INVX1 U1701 ( .A(n710), .Y(n711) );
  INVX1 U1702 ( .A(n694), .Y(n695) );
  INVX1 U1703 ( .A(n691), .Y(n692) );
  INVX1 U1704 ( .A(n735), .Y(n736) );
  INVX1 U1705 ( .A(n715), .Y(n716) );
  INVX1 U1706 ( .A(n696), .Y(n697) );
  INVX1 U1707 ( .A(n743), .Y(n744) );
  INVX1 U1708 ( .A(n741), .Y(n742) );
  INVX1 U1709 ( .A(n739), .Y(n740) );
  INVX1 U1710 ( .A(n737), .Y(n738) );
  INVX1 U1711 ( .A(n723), .Y(n724) );
  INVX1 U1712 ( .A(n721), .Y(n722) );
  INVX1 U1713 ( .A(n719), .Y(n720) );
  INVX1 U1714 ( .A(n717), .Y(n718) );
  INVX1 U1715 ( .A(n704), .Y(n705) );
  INVX1 U1716 ( .A(n702), .Y(n703) );
  INVX1 U1717 ( .A(n700), .Y(n701) );
  INVX1 U1718 ( .A(n698), .Y(n699) );
  INVX1 U1719 ( .A(n725), .Y(n726) );
  INVX1 U1720 ( .A(n707), .Y(n708) );
  INVX1 U1721 ( .A(n688), .Y(n689) );
  INVX1 U1722 ( .A(n684), .Y(n685) );
  INVX1 U1723 ( .A(n680), .Y(n681) );
  INVX1 U1724 ( .A(n676), .Y(n677) );
  INVX1 U1725 ( .A(n672), .Y(n673) );
  INVX1 U1726 ( .A(n668), .Y(n669) );
  INVX1 U1727 ( .A(n664), .Y(n665) );
  INVX1 U1728 ( .A(n660), .Y(n661) );
  INVX1 U1729 ( .A(n648), .Y(n650) );
  INVX1 U1730 ( .A(fifordb), .Y(n638) );
  OAI222X1 U1731 ( .A0(n760), .A1(n1481), .B0(n760), .B1(n1338), .C0(n1481), 
        .C1(n1338), .Y(n754) );
  INVX1 U1732 ( .A(n6330), .Y(n6350) );
  INVX1 U1733 ( .A(n749), .Y(n760) );
  AFHCONX2 U2_1 ( .A(n1647), .B(n1473), .CI(carry_1_), .S(rxfifocnt[1]), .CON(
        n7) );
  DFFRX1 rxclk_reg ( .D(N443), .CK(clk), .RN(rstb), .Q(rxclk), .QN(n1329) );
  NAND4BX1 U1734 ( .AN(n639), .B(n640), .C(n641), .D(n642), .Y(n617) );
  INVX1 U1735 ( .A(rxfifocnt[1]), .Y(n641) );
  INVX1 U1736 ( .A(rxfifocnt[2]), .Y(n640) );
  NAND3BX1 U1737 ( .AN(rxfifocnt[3]), .B(n643), .C(n1475), .Y(n639) );
  NAND4BX1 U1738 ( .AN(n1480), .B(n838), .C(n839), .D(n840), .Y(n830) );
  NOR2BX1 U1739 ( .AN(n841), .B(n842), .Y(n839) );
  NAND3BX1 U1740 ( .AN(n855), .B(n1330), .C(n1476), .Y(n849) );
  NAND3BX1 U1741 ( .AN(n841), .B(n838), .C(n840), .Y(n831) );
  NAND3X1 U1742 ( .A(n830), .B(n6220), .C(n810), .Y(n815) );
  NAND2BX1 U1743 ( .AN(n811), .B(n810), .Y(n835) );
  NAND3BX1 U1744 ( .AN(n869), .B(n1624), .C(n1623), .Y(n812) );
  INVX1 U1745 ( .A(n865), .Y(n810) );
  NAND3BX1 U1746 ( .AN(n866), .B(n867), .C(n868), .Y(n865) );
  INVX1 U1747 ( .A(n812), .Y(n868) );
  NAND2BX1 U1748 ( .AN(n863), .B(n1625), .Y(n854) );
  NAND2BX1 U1749 ( .AN(n852), .B(n836), .Y(n850) );
  NAND4X1 U1750 ( .A(n842), .B(n841), .C(n838), .D(n840), .Y(n821) );
  INVX1 U1751 ( .A(rxfifocnt[4]), .Y(n643) );
  INVX1 U1752 ( .A(n858), .Y(n840) );
  NAND3BX1 U1753 ( .AN(n851), .B(n859), .C(n853), .Y(n858) );
  INVX1 U1754 ( .A(n854), .Y(n859) );
  INVX1 U1755 ( .A(n804), .Y(n814) );
  OR2X1 U1756 ( .A(n811), .B(n815), .Y(n817) );
  OAI211X1 U1757 ( .A0(n1339), .A1(n804), .B0(n808), .C0(n809), .Y(n285) );
  AOI211X1 U1758 ( .A0(n810), .A1(n811), .B0(n812), .C0(N511), .Y(n809) );
  OAI211X1 U1759 ( .A0(n804), .A1(n1335), .B0(n832), .C0(n833), .Y(n279) );
  NOR2BX1 U1760 ( .AN(n6220), .B(n835), .Y(n832) );
  INVX1 U1761 ( .A(n834), .Y(n833) );
  INVX1 U1762 ( .A(n1326), .Y(n867) );
  INVX1 U1763 ( .A(uarten), .Y(n1323) );
  OAI2BB1X1 U1764 ( .A0N(n1646), .A1N(n1477), .B0(carry_1_), .Y(rxfifocnt[0])
         );
  AO21X1 U1765 ( .A0(n1340), .A1(n1333), .B0(n797), .Y(n800) );
  AO21X1 U1766 ( .A0(n1482), .A1(n1333), .B0(n800), .Y(n789) );
  INVX1 U1767 ( .A(n852), .Y(n827) );
  INVX1 U1768 ( .A(n770), .Y(n779) );
  INVX1 U1769 ( .A(n1308), .Y(n780) );
  INVX1 U1770 ( .A(n851), .Y(n826) );
  INVX1 U1771 ( .A(n791), .Y(n797) );
  INVX1 U1772 ( .A(n781), .Y(n778) );
  NAND2BX1 U1773 ( .AN(n727), .B(n659), .Y(n725) );
  NAND2BX1 U1774 ( .AN(n709), .B(n659), .Y(n707) );
  NAND2BX1 U1775 ( .AN(n690), .B(n659), .Y(n688) );
  OR2X1 U1776 ( .A(n658), .B(n687), .Y(n684) );
  OR2X1 U1777 ( .A(n658), .B(n683), .Y(n680) );
  OR2X1 U1778 ( .A(n658), .B(n679), .Y(n676) );
  OR2X1 U1779 ( .A(n658), .B(n675), .Y(n672) );
  OR2X1 U1780 ( .A(n658), .B(n663), .Y(n660) );
  NAND2BX1 U1781 ( .AN(n658), .B(n659), .Y(n648) );
  NAND2BX1 U1782 ( .AN(n687), .B(n732), .Y(n743) );
  NAND2BX1 U1783 ( .AN(n683), .B(n732), .Y(n741) );
  NAND2BX1 U1784 ( .AN(n679), .B(n732), .Y(n739) );
  NAND2BX1 U1785 ( .AN(n675), .B(n732), .Y(n737) );
  NAND2BX1 U1786 ( .AN(n671), .B(n732), .Y(n735) );
  NAND2BX1 U1787 ( .AN(n667), .B(n732), .Y(n733) );
  NAND2BX1 U1788 ( .AN(n663), .B(n732), .Y(n730) );
  NAND2BX1 U1789 ( .AN(n687), .B(n712), .Y(n723) );
  NAND2BX1 U1790 ( .AN(n683), .B(n712), .Y(n721) );
  NAND2BX1 U1791 ( .AN(n679), .B(n712), .Y(n719) );
  NAND2BX1 U1792 ( .AN(n675), .B(n712), .Y(n717) );
  NAND2BX1 U1793 ( .AN(n671), .B(n712), .Y(n715) );
  NAND2BX1 U1794 ( .AN(n667), .B(n712), .Y(n713) );
  NAND2BX1 U1795 ( .AN(n663), .B(n712), .Y(n710) );
  NAND2BX1 U1796 ( .AN(n687), .B(n693), .Y(n704) );
  NAND2BX1 U1797 ( .AN(n683), .B(n693), .Y(n702) );
  NAND2BX1 U1798 ( .AN(n679), .B(n693), .Y(n700) );
  NAND2BX1 U1799 ( .AN(n675), .B(n693), .Y(n698) );
  NAND2BX1 U1800 ( .AN(n671), .B(n693), .Y(n696) );
  NAND2BX1 U1801 ( .AN(n667), .B(n693), .Y(n694) );
  NAND2BX1 U1802 ( .AN(n663), .B(n693), .Y(n691) );
  INVX1 U1803 ( .A(n709), .Y(n712) );
  INVX1 U1804 ( .A(n690), .Y(n693) );
  INVX1 U1805 ( .A(n727), .Y(n732) );
  INVX1 U1806 ( .A(n767), .Y(n768) );
  INVX1 U1807 ( .A(n625), .Y(n628) );
  NOR2BX1 U1808 ( .AN(n6220), .B(n848), .Y(N527) );
  NOR2BX1 U1809 ( .AN(n6220), .B(n841), .Y(N525) );
  NOR2BX1 U1810 ( .AN(n6220), .B(n1625), .Y(N521) );
  AND2X2 U1811 ( .A(n6220), .B(n811), .Y(N516) );
  AND2X2 U1812 ( .A(n6220), .B(n866), .Y(N515) );
  NOR2BX1 U1813 ( .AN(n6220), .B(n1623), .Y(N514) );
  NOR2BX1 U1814 ( .AN(n6220), .B(n1624), .Y(N513) );
  OR2X1 U1815 ( .A(n658), .B(n667), .Y(n664) );
  OR2X1 U1816 ( .A(n658), .B(n671), .Y(n668) );
  INVX1 U1817 ( .A(n796), .Y(n793) );
  OAI32X1 U1818 ( .A0(n770), .A1(n746), .A2(n1476), .B0(n1330), .B1(n1308), 
        .Y(N523) );
  NAND2BX1 U1819 ( .AN(n1273), .B(n1630), .Y(n904) );
  NAND2BX1 U1820 ( .AN(n1273), .B(n1274), .Y(n886) );
  OR2X1 U1821 ( .A(n1284), .B(n1273), .Y(n895) );
  NAND2BX1 U1822 ( .AN(n1273), .B(n1301), .Y(n913) );
  NAND2BX1 U1823 ( .AN(n1275), .B(n1630), .Y(n902) );
  NAND2BX1 U1824 ( .AN(n1275), .B(n1274), .Y(n884) );
  OR2X1 U1825 ( .A(n1275), .B(n1284), .Y(n893) );
  NAND2BX1 U1826 ( .AN(n1275), .B(n1301), .Y(n911) );
  OR2X1 U1827 ( .A(n1284), .B(n1278), .Y(n888) );
  NAND2BX1 U1828 ( .AN(n1278), .B(n1630), .Y(n897) );
  NAND2BX1 U1829 ( .AN(n1278), .B(n1274), .Y(n879) );
  NAND2BX1 U1830 ( .AN(n1278), .B(n1301), .Y(n906) );
  NAND2BX1 U1831 ( .AN(n1276), .B(n1277), .Y(n881) );
  NAND2BX1 U1832 ( .AN(n1284), .B(n1277), .Y(n890) );
  NAND2BX1 U1833 ( .AN(n1302), .B(n1277), .Y(n908) );
  NAND2BX1 U1834 ( .AN(n1294), .B(n1630), .Y(n899) );
  OR4X1 U1835 ( .A(n1214), .B(n1215), .C(n1216), .D(n1217), .Y(n1188) );
  OAI221X1 U1836 ( .A0(n1492), .A1(n906), .B0(n1345), .B1(n908), .C0(n1235), 
        .Y(n1214) );
  OAI221X1 U1837 ( .A0(n1491), .A1(n888), .B0(n1344), .B1(n890), .C0(n1225), 
        .Y(n1216) );
  OAI221X1 U1838 ( .A0(n1490), .A1(n879), .B0(n1343), .B1(n881), .C0(n1220), 
        .Y(n1217) );
  OR4X1 U1839 ( .A(n1164), .B(n1165), .C(n1166), .D(n1167), .Y(n1138) );
  OAI221X1 U1840 ( .A0(n1495), .A1(n906), .B0(n1348), .B1(n908), .C0(n1185), 
        .Y(n1164) );
  OAI221X1 U1841 ( .A0(n1494), .A1(n888), .B0(n1347), .B1(n890), .C0(n1175), 
        .Y(n1166) );
  OAI221X1 U1842 ( .A0(n1493), .A1(n879), .B0(n1346), .B1(n881), .C0(n1170), 
        .Y(n1167) );
  OR4X1 U1843 ( .A(n1114), .B(n1115), .C(n1116), .D(n1117), .Y(n1088) );
  OAI221X1 U1844 ( .A0(n1498), .A1(n906), .B0(n1351), .B1(n908), .C0(n1135), 
        .Y(n1114) );
  OAI221X1 U1845 ( .A0(n1497), .A1(n888), .B0(n1350), .B1(n890), .C0(n1125), 
        .Y(n1116) );
  OAI221X1 U1846 ( .A0(n1496), .A1(n879), .B0(n1349), .B1(n881), .C0(n1120), 
        .Y(n1117) );
  OR4X1 U1847 ( .A(n1064), .B(n1065), .C(n1066), .D(n1067), .Y(n1038) );
  OAI221X1 U1848 ( .A0(n1501), .A1(n906), .B0(n1354), .B1(n908), .C0(n1085), 
        .Y(n1064) );
  OAI221X1 U1849 ( .A0(n1500), .A1(n888), .B0(n1353), .B1(n890), .C0(n1075), 
        .Y(n1066) );
  OAI221X1 U1850 ( .A0(n1499), .A1(n879), .B0(n1352), .B1(n881), .C0(n1070), 
        .Y(n1067) );
  OR4X1 U1851 ( .A(n1014), .B(n1015), .C(n1016), .D(n1017), .Y(n988) );
  OAI221X1 U1852 ( .A0(n1504), .A1(n906), .B0(n1357), .B1(n908), .C0(n1035), 
        .Y(n1014) );
  OAI221X1 U1853 ( .A0(n1503), .A1(n888), .B0(n1356), .B1(n890), .C0(n1025), 
        .Y(n1016) );
  OAI221X1 U1854 ( .A0(n1502), .A1(n879), .B0(n1355), .B1(n881), .C0(n1020), 
        .Y(n1017) );
  OR4X1 U1855 ( .A(n964), .B(n965), .C(n966), .D(n967), .Y(n938) );
  OAI221X1 U1856 ( .A0(n1507), .A1(n906), .B0(n1360), .B1(n908), .C0(n985), 
        .Y(n964) );
  OAI221X1 U1857 ( .A0(n1506), .A1(n888), .B0(n1359), .B1(n890), .C0(n975), 
        .Y(n966) );
  OAI221X1 U1858 ( .A0(n1505), .A1(n879), .B0(n1358), .B1(n881), .C0(n970), 
        .Y(n967) );
  OR4X1 U1859 ( .A(n1190), .B(n1191), .C(n1192), .D(n1193), .Y(n1189) );
  OAI221X1 U1860 ( .A0(n1510), .A1(n906), .B0(n1363), .B1(n908), .C0(n1211), 
        .Y(n1190) );
  OAI221X1 U1861 ( .A0(n1509), .A1(n888), .B0(n1362), .B1(n890), .C0(n1201), 
        .Y(n1192) );
  OAI221X1 U1862 ( .A0(n1508), .A1(n879), .B0(n1361), .B1(n881), .C0(n1196), 
        .Y(n1193) );
  OR4X1 U1863 ( .A(n1140), .B(n1141), .C(n1142), .D(n1143), .Y(n1139) );
  OAI221X1 U1864 ( .A0(n1513), .A1(n906), .B0(n1366), .B1(n908), .C0(n1161), 
        .Y(n1140) );
  OAI221X1 U1865 ( .A0(n1512), .A1(n888), .B0(n1365), .B1(n890), .C0(n1151), 
        .Y(n1142) );
  OAI221X1 U1866 ( .A0(n1511), .A1(n879), .B0(n1364), .B1(n881), .C0(n1146), 
        .Y(n1143) );
  OR4X1 U1867 ( .A(n990), .B(n991), .C(n992), .D(n993), .Y(n989) );
  OAI221X1 U1868 ( .A0(n1516), .A1(n906), .B0(n1369), .B1(n908), .C0(n1011), 
        .Y(n990) );
  OAI221X1 U1869 ( .A0(n1515), .A1(n888), .B0(n1368), .B1(n890), .C0(n1001), 
        .Y(n992) );
  OAI221X1 U1870 ( .A0(n1514), .A1(n879), .B0(n1367), .B1(n881), .C0(n996), 
        .Y(n993) );
  INVX1 U1871 ( .A(n1294), .Y(n1277) );
  INVX1 U1872 ( .A(n1276), .Y(n1274) );
  INVX1 U1873 ( .A(n1302), .Y(n1301) );
  NAND3BX1 U1874 ( .AN(swrst), .B(n638), .C(n617), .Y(n6330) );
  AO22X1 U1875 ( .A0(txd), .A1(loopbacken), .B0(rxd), .B1(n766), .Y(n749) );
  INVX1 U1876 ( .A(loopbacken), .Y(n766) );
  NOR2BX1 U1877 ( .AN(n644), .B(swrst), .Y(n565) );
  OAI222X1 U1878 ( .A0(bytereceivedb), .A1(n1475), .B0(n1475), .B1(n638), .C0(
        n645), .C1(n642), .Y(n644) );
  NAND4BX1 U1879 ( .AN(n647), .B(rxfifocnt[2]), .C(rxfifocnt[4]), .D(
        rxfifocnt[3]), .Y(n645) );
  NAND3BX1 U1880 ( .AN(bytereceivedb), .B(rxfifocnt[1]), .C(fifordb), .Y(n647)
         );
  AO22X1 U1881 ( .A0(in_dly[0]), .A1(n748), .B0(baudx16clk), .B1(n749), .Y(
        n303) );
  OAI33X1 U1882 ( .A0(n749), .A1(in_dly[1]), .A2(n1338), .B0(n749), .B1(
        in_dly[0]), .B2(n1481), .Y(n756) );
  OAI2BB1X1 U1883 ( .A0N(n750), .A1N(n751), .B0(n752), .Y(n302) );
  OA21X2 U1884 ( .A0(n754), .A1(n753), .B0(baudx16clk), .Y(n750) );
  AOI32X1 U1885 ( .A0(baudx16clk), .A1(n753), .A2(n754), .B0(rx_lpfd), .B1(
        n748), .Y(n752) );
  OA22X1 U1886 ( .A0(n755), .A1(n756), .B0(in_dly[5]), .B1(n1626), .Y(n751) );
  AO22X1 U1887 ( .A0(n6350), .A1(n1477), .B0(n631), .B1(N70), .Y(n566) );
  AO22X1 U1888 ( .A0(N634), .A1(n6350), .B0(n631), .B1(N72), .Y(n568) );
  AO22X1 U1889 ( .A0(N633), .A1(n6350), .B0(n631), .B1(N71), .Y(n567) );
  AO22X1 U1890 ( .A0(N635), .A1(n6350), .B0(n631), .B1(N73), .Y(n569) );
  INVX1 U1891 ( .A(n637), .Y(n631) );
  NAND2BX1 U1892 ( .AN(swrst), .B(n6330), .Y(n637) );
  AO21X1 U1893 ( .A0(n631), .A1(N74), .B0(n632), .Y(n570) );
  OAI33X1 U1894 ( .A0(n6330), .A1(n1471), .A2(n6340), .B0(n6330), .B1(n1), 
        .B2(N74), .Y(n632) );
  INVX1 U1895 ( .A(n1), .Y(n6340) );
  OAI31X1 U1896 ( .A0(n760), .A1(in_dly[1]), .A2(in_dly[0]), .B0(n761), .Y(
        n755) );
  AOI32X1 U1897 ( .A0(in_dly[1]), .A1(in_dly[0]), .A2(n749), .B0(in_dly[5]), 
        .B1(n1626), .Y(n761) );
  AFHCONX2 U2_3 ( .A(fifo_wrpos_3_), .B(n1472), .CI(carry), .S(rxfifocnt[3]), 
        .CON(n5) );
  INVX1 U1898 ( .A(n6), .Y(carry) );
  AFHCONX2 U2_2 ( .A(fifo_wrpos_2_), .B(n1631), .CI(carry0), .S(rxfifocnt[2]), 
        .CON(n6) );
  INVX1 U1899 ( .A(n7), .Y(carry0) );
  XOR3X1 U2_4 ( .A(fifo_wrpos_4_), .B(n1471), .C(carry_4_), .Y(rxfifocnt[4])
         );
  INVX1 U1900 ( .A(n5), .Y(carry_4_) );
  NAND3BX1 U1901 ( .AN(swrst), .B(n836), .C(n808), .Y(n804) );
  NAND3BX1 U1902 ( .AN(n18), .B(n1620), .C(n848), .Y(n842) );
  NAND2BX1 U1903 ( .AN(n1646), .B(N70), .Y(carry_1_) );
  AO22X1 U1904 ( .A0(current_state_5_), .A1(n1329), .B0(current_state_4_), 
        .B1(n1621), .Y(n811) );
  NAND2X1 U1905 ( .A(n1619), .B(n17), .Y(n1326) );
  AO22X1 U1906 ( .A0(current_state_4_), .A1(n748), .B0(current_state_3_), .B1(
        n1621), .Y(n866) );
  AOI21X1 U1907 ( .A0(n1310), .A1(current_state_13_), .B0(current_state_14_), 
        .Y(n1620) );
  INVX1 U1908 ( .A(n617), .Y(rxfifoempty) );
  INVX1 U1909 ( .A(baudx16clk), .Y(n748) );
  BUFX2 U1910 ( .A(fifo_wrpos_0_), .Y(n1646) );
  BUFX2 U1911 ( .A(n578), .Y(n1647) );
  OAI221X1 U1912 ( .A0(n1621), .A1(n1474), .B0(n867), .B1(n1323), .C0(n1324), 
        .Y(n869) );
  OAI31X1 U1913 ( .A0(current_state_2_), .A1(current_state_4_), .A2(
        current_state_3_), .B0(n1325), .Y(n1324) );
  NOR2BX1 U1914 ( .AN(baudx16clk), .B(n1622), .Y(n1325) );
  OAI31X1 U1915 ( .A0(n1329), .A1(databit), .A2(n1476), .B0(n1315), .Y(n855)
         );
  OA22X1 U1916 ( .A0(rxclk), .A1(n1334), .B0(n1329), .B1(n1330), .Y(n1315) );
  INVX1 U1917 ( .A(parity[1]), .Y(n783) );
  AND2X2 U1918 ( .A(n1622), .B(baudx16clk), .Y(n1621) );
  AO22X1 U1919 ( .A0(n813), .A1(n6220), .B0(rxbusy), .B1(n814), .Y(n284) );
  AO21X1 U1920 ( .A0(rxclkenb), .A1(n814), .B0(n815), .Y(n283) );
  OAI211X1 U1921 ( .A0(n1488), .A1(n804), .B0(n819), .C0(n820), .Y(n281) );
  NOR2BX1 U1922 ( .AN(n821), .B(n822), .Y(n819) );
  OAI211X1 U1923 ( .A0(n804), .A1(n1485), .B0(n824), .C0(n820), .Y(n280) );
  NOR2BX1 U1924 ( .AN(n831), .B(n822), .Y(n824) );
  OAI211X1 U1925 ( .A0(n804), .A1(n1487), .B0(n1618), .C0(n807), .Y(n282) );
  OAI211X1 U1926 ( .A0(n804), .A1(n1486), .B0(n1618), .C0(n807), .Y(n286) );
  AOI22X1 U1927 ( .A0(current_state_3_), .A1(n748), .B0(current_state_2_), 
        .B1(n1621), .Y(n1623) );
  AOI22X1 U1928 ( .A0(current_state_2_), .A1(n748), .B0(current_state_1_), 
        .B1(n1621), .Y(n1624) );
  AOI22X1 U1929 ( .A0(current_state_9_), .A1(rxclk), .B0(current_state_10_), 
        .B1(n1329), .Y(n1625) );
  INVX1 U1930 ( .A(n1303), .Y(n848) );
  OAI31X1 U1931 ( .A0(n1620), .A1(stopbit), .A2(n1329), .B0(n1305), .Y(n1303)
         );
  OA22X1 U1932 ( .A0(n1329), .A1(n1337), .B0(rxclk), .B1(n1480), .Y(n1305) );
  INVX1 U1933 ( .A(n1314), .Y(n1310) );
  NAND2BX1 U1934 ( .AN(parity[0]), .B(n783), .Y(n1314) );
  INVX1 U1935 ( .A(n2100), .Y(carry1) );
  INVX1 U1936 ( .A(n2), .Y(carry_3_) );
  NAND3BX1 U1937 ( .AN(bytereceivedb), .B(n1475), .C(n6220), .Y(n625) );
  INVX1 U1938 ( .A(n3100), .Y(carry2) );
  INVX1 U1939 ( .A(n3), .Y(carry_2_) );
  NAND2BX1 U1940 ( .AN(swrst), .B(rxclk), .Y(n770) );
  OR4X1 U1941 ( .A(current_state_7_), .B(current_state_6_), .C(
        current_state_5_), .D(current_state_8_), .Y(n852) );
  NAND2BX1 U1942 ( .AN(baudx16clk), .B(n1333), .Y(n791) );
  AO22X1 U1943 ( .A0(current_state_9_), .A1(n1329), .B0(current_state_8_), 
        .B1(rxclk), .Y(n851) );
  NAND2BX1 U1944 ( .AN(swrst), .B(n1329), .Y(n1308) );
  INVX1 U1945 ( .A(swrst), .Y(n6220) );
  OAI31X1 U1946 ( .A0(n1483), .A1(parity[0]), .A2(n783), .B0(n784), .Y(n781)
         );
  OA22X1 U1947 ( .A0(parity_int), .A1(parity[1]), .B0(parity_int), .B1(n785), 
        .Y(n784) );
  INVX1 U1948 ( .A(parity[0]), .Y(n785) );
  AO22X1 U1949 ( .A0(current_state_11_), .A1(n1329), .B0(current_state_10_), 
        .B1(rxclk), .Y(n863) );
  OAI32X1 U1950 ( .A0(n774), .A1(parityerr_clear), .A2(n770), .B0(n775), .B1(
        n278), .Y(n292) );
  INVX1 U1951 ( .A(n775), .Y(n774) );
  AO21X1 U1952 ( .A0(n776), .A1(n777), .B0(parityerr_clear), .Y(n775) );
  AOI31X1 U1953 ( .A0(n778), .A1(n1622), .A2(n779), .B0(n780), .Y(n777) );
  OAI32X1 U1954 ( .A0(n769), .A1(frameerr_clear), .A2(n770), .B0(n771), .B1(
        n276), .Y(n293) );
  INVX1 U1955 ( .A(n769), .Y(n771) );
  OAI33X1 U1956 ( .A0(n770), .A1(frameerr_clear), .A2(n1622), .B0(n773), .B1(
        swrst), .B2(frameerr_clear), .Y(n769) );
  NOR2BX1 U1957 ( .AN(rxclk), .B(framechkb), .Y(n773) );
  OAI32X1 U1958 ( .A0(n796), .A1(rxclkcnt[2]), .A2(n797), .B0(n798), .B1(n1341), .Y(n289) );
  INVX1 U1959 ( .A(n789), .Y(n798) );
  AOI32X1 U1960 ( .A0(rx_lpfd), .A1(n781), .A2(n779), .B0(paritychkb), .B1(
        n6220), .Y(n776) );
  INVX1 U1961 ( .A(n1311), .Y(n841) );
  OAI32X1 U1962 ( .A0(n1329), .A1(n1310), .A2(n1334), .B0(rxclk), .B1(n1479), 
        .Y(n1311) );
  AO21X1 U1963 ( .A0(n6230), .A1(fifo_wrpos_4_), .B0(n6240), .Y(n575) );
  OAI33X1 U1964 ( .A0(n625), .A1(n626), .A2(n1484), .B0(n625), .B1(n11), .B2(
        fifo_wrpos_4_), .Y(n6240) );
  INVX1 U1965 ( .A(n11), .Y(n626) );
  XOR3X1 U1966 ( .A(n1627), .B(in_dly[3]), .C(n1331), .Y(n1626) );
  OAI32X1 U1967 ( .A0(n618), .A1(swrst), .A2(overrunerr_clear), .B0(n619), 
        .B1(n277), .Y(n576) );
  INVX1 U1968 ( .A(n619), .Y(n618) );
  OAI211X1 U1969 ( .A0(bytereceivedb), .A1(n1475), .B0(n621), .C0(n6220), .Y(
        n619) );
  INVX1 U1970 ( .A(overrunerr_clear), .Y(n621) );
  NAND2BX1 U1971 ( .AN(rxsftenb), .B(rxclk), .Y(n767) );
  NAND3BX1 U1972 ( .AN(fifo_wrpos_2_), .B(n1336), .C(n1332), .Y(n687) );
  NAND3BX1 U1973 ( .AN(fifo_wrpos_2_), .B(n1336), .C(n1646), .Y(n683) );
  NAND3BX1 U1974 ( .AN(fifo_wrpos_2_), .B(n1332), .C(n1647), .Y(n679) );
  NAND3BX1 U1975 ( .AN(fifo_wrpos_2_), .B(n1647), .C(n1646), .Y(n675) );
  NAND3BX1 U1976 ( .AN(n1647), .B(fifo_wrpos_2_), .C(n1646), .Y(n667) );
  NAND3BX1 U1977 ( .AN(n1646), .B(fifo_wrpos_2_), .C(n1647), .Y(n663) );
  NAND3BX1 U1978 ( .AN(n1647), .B(n1332), .C(fifo_wrpos_2_), .Y(n671) );
  NAND3BX1 U1979 ( .AN(fifo_wrpos_4_), .B(n1478), .C(n1335), .Y(n727) );
  NAND3BX1 U1980 ( .AN(fifo_wrpos_4_), .B(n1335), .C(fifo_wrpos_3_), .Y(n709)
         );
  NAND3BX1 U1981 ( .AN(fifo_wrpos_3_), .B(n1335), .C(fifo_wrpos_4_), .Y(n690)
         );
  OAI33X1 U1982 ( .A0(n786), .A1(n1339), .A2(n1483), .B0(n788), .B1(parity_int), .B2(n1339), .Y(n291) );
  INVX1 U1983 ( .A(n788), .Y(n786) );
  NAND3BX1 U1984 ( .AN(dataphaseb), .B(rx_lpfd), .C(rxclk), .Y(n788) );
  NAND3BX1 U1985 ( .AN(rxclkenb), .B(rxclkcnt[1]), .C(rxclkcnt[0]), .Y(n796)
         );
  NAND3BX1 U1986 ( .AN(bytereceivedb), .B(fifo_wrpos_3_), .C(fifo_wrpos_4_), 
        .Y(n658) );
  AO22X1 U1987 ( .A0(rxsftreg[0]), .A1(databit), .B0(rxsftreg[1]), .B1(n746), 
        .Y(n1633) );
  AO22X1 U1988 ( .A0(rxsftreg[1]), .A1(databit), .B0(rxsftreg[2]), .B1(n746), 
        .Y(n1635) );
  AO22X1 U1989 ( .A0(rxsftreg[2]), .A1(databit), .B0(rxsftreg[3]), .B1(n746), 
        .Y(n1637) );
  AO22X1 U1990 ( .A0(rxsftreg[3]), .A1(databit), .B0(rxsftreg[4]), .B1(n746), 
        .Y(n1639) );
  AO22X1 U1991 ( .A0(rxsftreg[4]), .A1(databit), .B0(rxsftreg[5]), .B1(n746), 
        .Y(n1641) );
  AO22X1 U1992 ( .A0(rxsftreg[5]), .A1(databit), .B0(rxsftreg[6]), .B1(n746), 
        .Y(n1643) );
  AO22X1 U1993 ( .A0(rxsftreg[6]), .A1(databit), .B0(rxsftreg[7]), .B1(n746), 
        .Y(n1645) );
  AO22X1 U1994 ( .A0(rxsftreg[0]), .A1(databit), .B0(rxsftreg[1]), .B1(n746), 
        .Y(n1632) );
  AO22X1 U1995 ( .A0(rxsftreg[1]), .A1(databit), .B0(rxsftreg[2]), .B1(n746), 
        .Y(n1634) );
  AO22X1 U1996 ( .A0(rxsftreg[2]), .A1(databit), .B0(rxsftreg[3]), .B1(n746), 
        .Y(n1636) );
  AO22X1 U1997 ( .A0(rxsftreg[3]), .A1(databit), .B0(rxsftreg[4]), .B1(n746), 
        .Y(n1638) );
  AO22X1 U1998 ( .A0(rxsftreg[4]), .A1(databit), .B0(rxsftreg[5]), .B1(n746), 
        .Y(n1640) );
  AO22X1 U1999 ( .A0(rxsftreg[5]), .A1(databit), .B0(rxsftreg[6]), .B1(n746), 
        .Y(n1642) );
  AO22X1 U2000 ( .A0(rxsftreg[6]), .A1(databit), .B0(rxsftreg[7]), .B1(n746), 
        .Y(n1644) );
  AO22X1 U2001 ( .A0(rxsftreg[0]), .A1(databit), .B0(rxsftreg[1]), .B1(n746), 
        .Y(n657) );
  AO22X1 U2002 ( .A0(rxsftreg[1]), .A1(databit), .B0(rxsftreg[2]), .B1(n746), 
        .Y(n656) );
  AO22X1 U2003 ( .A0(rxsftreg[2]), .A1(databit), .B0(rxsftreg[3]), .B1(n746), 
        .Y(n655) );
  AO22X1 U2004 ( .A0(rxsftreg[3]), .A1(databit), .B0(rxsftreg[4]), .B1(n746), 
        .Y(n654) );
  AO22X1 U2005 ( .A0(rxsftreg[4]), .A1(databit), .B0(rxsftreg[5]), .B1(n746), 
        .Y(n653) );
  AO22X1 U2006 ( .A0(rxsftreg[5]), .A1(databit), .B0(rxsftreg[6]), .B1(n746), 
        .Y(n652) );
  AO22X1 U2007 ( .A0(rxsftreg[6]), .A1(databit), .B0(rxsftreg[7]), .B1(n746), 
        .Y(n651) );
  INVX1 U2008 ( .A(n630), .Y(n6230) );
  NAND2BX1 U2009 ( .AN(swrst), .B(n625), .Y(n630) );
  NOR2BX1 U2010 ( .AN(n855), .B(swrst), .Y(N524) );
  NOR2BX1 U2011 ( .AN(n863), .B(swrst), .Y(N522) );
  NOR2BX1 U2012 ( .AN(n851), .B(swrst), .Y(N520) );
  NOR2BX1 U2013 ( .AN(n869), .B(swrst), .Y(N512) );
  NOR2X1 U2014 ( .A(n746), .B(n1629), .Y(n1628) );
  NOR2BX1 U2015 ( .AN(current_state_16_), .B(n770), .Y(N528) );
  AO21X1 U2016 ( .A0(n1326), .A1(n1323), .B0(swrst), .Y(N511) );
  INVX1 U2017 ( .A(n728), .Y(n659) );
  NAND3BX1 U2018 ( .AN(n1336), .B(fifo_wrpos_2_), .C(n1646), .Y(n728) );
  OAI222X1 U2019 ( .A0(n1627), .A1(n1331), .B0(n1342), .B1(n1331), .C0(n1627), 
        .C1(n1342), .Y(n753) );
  AO22X1 U2020 ( .A0(in_dly[0]), .A1(baudx16clk), .B0(in_dly[1]), .B1(n748), 
        .Y(n304) );
  AO22X1 U2021 ( .A0(in_dly[1]), .A1(baudx16clk), .B0(in_dly[2]), .B1(n748), 
        .Y(n305) );
  AO22X1 U2022 ( .A0(in_dly[2]), .A1(baudx16clk), .B0(in_dly[3]), .B1(n748), 
        .Y(n306) );
  AO22X1 U2023 ( .A0(in_dly[3]), .A1(baudx16clk), .B0(in_dly[4]), .B1(n748), 
        .Y(n307) );
  AO22X1 U2024 ( .A0(in_dly[4]), .A1(baudx16clk), .B0(in_dly[5]), .B1(n748), 
        .Y(n308) );
  AO22X1 U2025 ( .A0(N624), .A1(n628), .B0(fifo_wrpos_3_), .B1(n6230), .Y(n574) );
  AO22X1 U2026 ( .A0(N623), .A1(n628), .B0(fifo_wrpos_2_), .B1(n6230), .Y(n573) );
  OAI2BB1X1 U2027 ( .A0N(rxclkcnt[3]), .A1N(n789), .B0(n790), .Y(n290) );
  AOI33X1 U2028 ( .A0(n791), .A1(n792), .A2(n793), .B0(n1341), .B1(n1333), 
        .B2(rxclkcnt[3]), .Y(n790) );
  NOR2BX1 U2029 ( .AN(rxclkcnt[2]), .B(rxclkcnt[3]), .Y(n792) );
  AO22X1 U2030 ( .A0(rxsftreg[7]), .A1(n767), .B0(n768), .B1(rx_lpfd), .Y(n301) );
  AO22X1 U2031 ( .A0(N622), .A1(n628), .B0(n1647), .B1(n6230), .Y(n572) );
  AO22X1 U2032 ( .A0(n628), .A1(n1332), .B0(n6230), .B1(n1646), .Y(n571) );
  AO22X1 U2033 ( .A0(current_state_7_), .A1(n779), .B0(n780), .B1(
        current_state_8_), .Y(N519) );
  AO22X1 U2034 ( .A0(current_state_6_), .A1(n779), .B0(current_state_7_), .B1(
        n780), .Y(N518) );
  AO22X1 U2035 ( .A0(current_state_5_), .A1(n779), .B0(current_state_6_), .B1(
        n780), .Y(N517) );
  AO22X1 U2036 ( .A0(\rxfifo[31][7] ), .A1(n648), .B0(n1628), .B1(n650), .Y(
        n564) );
  AO22X1 U2037 ( .A0(\rxfifo[0][0] ), .A1(n743), .B0(n744), .B1(n1633), .Y(
        n309) );
  AO22X1 U2038 ( .A0(\rxfifo[0][1] ), .A1(n743), .B0(n744), .B1(n1635), .Y(
        n310) );
  AO22X1 U2039 ( .A0(\rxfifo[0][2] ), .A1(n743), .B0(n744), .B1(n1637), .Y(
        n311) );
  AO22X1 U2040 ( .A0(\rxfifo[0][3] ), .A1(n743), .B0(n744), .B1(n1639), .Y(
        n312) );
  AO22X1 U2041 ( .A0(\rxfifo[0][4] ), .A1(n743), .B0(n744), .B1(n1641), .Y(
        n313) );
  AO22X1 U2042 ( .A0(\rxfifo[0][5] ), .A1(n743), .B0(n744), .B1(n1643), .Y(
        n314) );
  AO22X1 U2043 ( .A0(\rxfifo[0][6] ), .A1(n743), .B0(n744), .B1(n1645), .Y(
        n315) );
  AO22X1 U2044 ( .A0(\rxfifo[0][7] ), .A1(n743), .B0(n744), .B1(n1628), .Y(
        n316) );
  AO22X1 U2045 ( .A0(\rxfifo[1][0] ), .A1(n741), .B0(n742), .B1(n1632), .Y(
        n317) );
  AO22X1 U2046 ( .A0(\rxfifo[1][1] ), .A1(n741), .B0(n742), .B1(n1634), .Y(
        n318) );
  AO22X1 U2047 ( .A0(\rxfifo[1][2] ), .A1(n741), .B0(n742), .B1(n1636), .Y(
        n319) );
  AO22X1 U2048 ( .A0(\rxfifo[1][3] ), .A1(n741), .B0(n742), .B1(n1638), .Y(
        n320) );
  AO22X1 U2049 ( .A0(\rxfifo[1][4] ), .A1(n741), .B0(n742), .B1(n1640), .Y(
        n321) );
  AO22X1 U2050 ( .A0(\rxfifo[1][5] ), .A1(n741), .B0(n742), .B1(n1642), .Y(
        n322) );
  AO22X1 U2051 ( .A0(\rxfifo[1][6] ), .A1(n741), .B0(n742), .B1(n1644), .Y(
        n323) );
  AO22X1 U2052 ( .A0(\rxfifo[1][7] ), .A1(n741), .B0(n742), .B1(n1628), .Y(
        n324) );
  AO22X1 U2053 ( .A0(\rxfifo[2][0] ), .A1(n739), .B0(n740), .B1(n657), .Y(n325) );
  AO22X1 U2054 ( .A0(\rxfifo[2][1] ), .A1(n739), .B0(n740), .B1(n656), .Y(n326) );
  AO22X1 U2055 ( .A0(\rxfifo[2][2] ), .A1(n739), .B0(n740), .B1(n655), .Y(n327) );
  AO22X1 U2056 ( .A0(\rxfifo[2][3] ), .A1(n739), .B0(n740), .B1(n654), .Y(n328) );
  AO22X1 U2057 ( .A0(\rxfifo[2][4] ), .A1(n739), .B0(n740), .B1(n653), .Y(n329) );
  AO22X1 U2058 ( .A0(\rxfifo[2][5] ), .A1(n739), .B0(n740), .B1(n652), .Y(n330) );
  AO22X1 U2059 ( .A0(\rxfifo[2][6] ), .A1(n739), .B0(n740), .B1(n651), .Y(n331) );
  AO22X1 U2060 ( .A0(\rxfifo[2][7] ), .A1(n739), .B0(n740), .B1(n1628), .Y(
        n332) );
  AO22X1 U2061 ( .A0(\rxfifo[3][0] ), .A1(n737), .B0(n738), .B1(n1633), .Y(
        n333) );
  AO22X1 U2062 ( .A0(\rxfifo[3][1] ), .A1(n737), .B0(n738), .B1(n1635), .Y(
        n334) );
  AO22X1 U2063 ( .A0(\rxfifo[3][2] ), .A1(n737), .B0(n738), .B1(n1637), .Y(
        n335) );
  AO22X1 U2064 ( .A0(\rxfifo[3][3] ), .A1(n737), .B0(n738), .B1(n1639), .Y(
        n336) );
  AO22X1 U2065 ( .A0(\rxfifo[3][4] ), .A1(n737), .B0(n738), .B1(n1641), .Y(
        n337) );
  AO22X1 U2066 ( .A0(\rxfifo[3][5] ), .A1(n737), .B0(n738), .B1(n1643), .Y(
        n338) );
  AO22X1 U2067 ( .A0(\rxfifo[3][6] ), .A1(n737), .B0(n738), .B1(n1645), .Y(
        n339) );
  AO22X1 U2068 ( .A0(\rxfifo[3][7] ), .A1(n737), .B0(n738), .B1(n1628), .Y(
        n340) );
  AO22X1 U2069 ( .A0(\rxfifo[4][0] ), .A1(n735), .B0(n736), .B1(n1632), .Y(
        n341) );
  AO22X1 U2070 ( .A0(\rxfifo[4][1] ), .A1(n735), .B0(n736), .B1(n1634), .Y(
        n342) );
  AO22X1 U2071 ( .A0(\rxfifo[4][2] ), .A1(n735), .B0(n736), .B1(n1636), .Y(
        n343) );
  AO22X1 U2072 ( .A0(\rxfifo[4][3] ), .A1(n735), .B0(n736), .B1(n1638), .Y(
        n344) );
  AO22X1 U2073 ( .A0(\rxfifo[4][4] ), .A1(n735), .B0(n736), .B1(n1640), .Y(
        n345) );
  AO22X1 U2074 ( .A0(\rxfifo[4][5] ), .A1(n735), .B0(n736), .B1(n1642), .Y(
        n346) );
  AO22X1 U2075 ( .A0(\rxfifo[4][6] ), .A1(n735), .B0(n736), .B1(n1644), .Y(
        n347) );
  AO22X1 U2076 ( .A0(\rxfifo[4][7] ), .A1(n735), .B0(n736), .B1(n1628), .Y(
        n348) );
  AO22X1 U2077 ( .A0(\rxfifo[5][0] ), .A1(n733), .B0(n734), .B1(n657), .Y(n349) );
  AO22X1 U2078 ( .A0(\rxfifo[5][1] ), .A1(n733), .B0(n734), .B1(n656), .Y(n350) );
  AO22X1 U2079 ( .A0(\rxfifo[5][2] ), .A1(n733), .B0(n734), .B1(n655), .Y(n351) );
  AO22X1 U2080 ( .A0(\rxfifo[5][3] ), .A1(n733), .B0(n734), .B1(n654), .Y(n352) );
  AO22X1 U2081 ( .A0(\rxfifo[5][4] ), .A1(n733), .B0(n734), .B1(n653), .Y(n353) );
  AO22X1 U2082 ( .A0(\rxfifo[5][5] ), .A1(n733), .B0(n734), .B1(n652), .Y(n354) );
  AO22X1 U2083 ( .A0(\rxfifo[5][6] ), .A1(n733), .B0(n734), .B1(n651), .Y(n355) );
  AO22X1 U2084 ( .A0(\rxfifo[5][7] ), .A1(n733), .B0(n734), .B1(n1628), .Y(
        n356) );
  AO22X1 U2085 ( .A0(\rxfifo[6][0] ), .A1(n730), .B0(n731), .B1(n1633), .Y(
        n357) );
  AO22X1 U2086 ( .A0(\rxfifo[6][1] ), .A1(n730), .B0(n731), .B1(n1635), .Y(
        n358) );
  AO22X1 U2087 ( .A0(\rxfifo[6][2] ), .A1(n730), .B0(n731), .B1(n1637), .Y(
        n359) );
  AO22X1 U2088 ( .A0(\rxfifo[6][3] ), .A1(n730), .B0(n731), .B1(n1639), .Y(
        n360) );
  AO22X1 U2089 ( .A0(\rxfifo[6][4] ), .A1(n730), .B0(n731), .B1(n1641), .Y(
        n361) );
  AO22X1 U2090 ( .A0(\rxfifo[6][5] ), .A1(n730), .B0(n731), .B1(n1643), .Y(
        n362) );
  AO22X1 U2091 ( .A0(\rxfifo[6][6] ), .A1(n730), .B0(n731), .B1(n1645), .Y(
        n363) );
  AO22X1 U2092 ( .A0(\rxfifo[6][7] ), .A1(n730), .B0(n731), .B1(n1628), .Y(
        n364) );
  AO22X1 U2093 ( .A0(\rxfifo[7][0] ), .A1(n725), .B0(n726), .B1(n1632), .Y(
        n365) );
  AO22X1 U2094 ( .A0(\rxfifo[7][1] ), .A1(n725), .B0(n726), .B1(n1634), .Y(
        n366) );
  AO22X1 U2095 ( .A0(\rxfifo[7][2] ), .A1(n725), .B0(n726), .B1(n1636), .Y(
        n367) );
  AO22X1 U2096 ( .A0(\rxfifo[7][3] ), .A1(n725), .B0(n726), .B1(n1638), .Y(
        n368) );
  AO22X1 U2097 ( .A0(\rxfifo[7][4] ), .A1(n725), .B0(n726), .B1(n1640), .Y(
        n369) );
  AO22X1 U2098 ( .A0(\rxfifo[7][5] ), .A1(n725), .B0(n726), .B1(n1642), .Y(
        n370) );
  AO22X1 U2099 ( .A0(\rxfifo[7][6] ), .A1(n725), .B0(n726), .B1(n1644), .Y(
        n371) );
  AO22X1 U2100 ( .A0(\rxfifo[7][7] ), .A1(n725), .B0(n726), .B1(n1628), .Y(
        n372) );
  AO22X1 U2101 ( .A0(\rxfifo[8][0] ), .A1(n723), .B0(n724), .B1(n657), .Y(n373) );
  AO22X1 U2102 ( .A0(\rxfifo[8][1] ), .A1(n723), .B0(n724), .B1(n656), .Y(n374) );
  AO22X1 U2103 ( .A0(\rxfifo[8][2] ), .A1(n723), .B0(n724), .B1(n655), .Y(n375) );
  AO22X1 U2104 ( .A0(\rxfifo[8][3] ), .A1(n723), .B0(n724), .B1(n654), .Y(n376) );
  AO22X1 U2105 ( .A0(\rxfifo[8][4] ), .A1(n723), .B0(n724), .B1(n653), .Y(n377) );
  AO22X1 U2106 ( .A0(\rxfifo[8][5] ), .A1(n723), .B0(n724), .B1(n652), .Y(n378) );
  AO22X1 U2107 ( .A0(\rxfifo[8][6] ), .A1(n723), .B0(n724), .B1(n651), .Y(n379) );
  AO22X1 U2108 ( .A0(\rxfifo[8][7] ), .A1(n723), .B0(n724), .B1(n1628), .Y(
        n380) );
  AO22X1 U2109 ( .A0(\rxfifo[9][0] ), .A1(n721), .B0(n722), .B1(n1633), .Y(
        n381) );
  AO22X1 U2110 ( .A0(\rxfifo[9][1] ), .A1(n721), .B0(n722), .B1(n1635), .Y(
        n382) );
  AO22X1 U2111 ( .A0(\rxfifo[9][2] ), .A1(n721), .B0(n722), .B1(n1637), .Y(
        n383) );
  AO22X1 U2112 ( .A0(\rxfifo[9][3] ), .A1(n721), .B0(n722), .B1(n1639), .Y(
        n384) );
  AO22X1 U2113 ( .A0(\rxfifo[9][4] ), .A1(n721), .B0(n722), .B1(n1641), .Y(
        n385) );
  AO22X1 U2114 ( .A0(\rxfifo[9][5] ), .A1(n721), .B0(n722), .B1(n1643), .Y(
        n386) );
  AO22X1 U2115 ( .A0(\rxfifo[9][6] ), .A1(n721), .B0(n722), .B1(n1645), .Y(
        n387) );
  AO22X1 U2116 ( .A0(\rxfifo[9][7] ), .A1(n721), .B0(n722), .B1(n1628), .Y(
        n388) );
  AO22X1 U2117 ( .A0(\rxfifo[10][0] ), .A1(n719), .B0(n720), .B1(n1632), .Y(
        n389) );
  AO22X1 U2118 ( .A0(\rxfifo[10][1] ), .A1(n719), .B0(n720), .B1(n1634), .Y(
        n390) );
  AO22X1 U2119 ( .A0(\rxfifo[10][2] ), .A1(n719), .B0(n720), .B1(n1636), .Y(
        n391) );
  AO22X1 U2120 ( .A0(\rxfifo[10][3] ), .A1(n719), .B0(n720), .B1(n1638), .Y(
        n392) );
  AO22X1 U2121 ( .A0(\rxfifo[10][4] ), .A1(n719), .B0(n720), .B1(n1640), .Y(
        n393) );
  AO22X1 U2122 ( .A0(\rxfifo[10][5] ), .A1(n719), .B0(n720), .B1(n1642), .Y(
        n394) );
  AO22X1 U2123 ( .A0(\rxfifo[10][6] ), .A1(n719), .B0(n720), .B1(n1644), .Y(
        n395) );
  AO22X1 U2124 ( .A0(\rxfifo[10][7] ), .A1(n719), .B0(n720), .B1(n1628), .Y(
        n396) );
  AO22X1 U2125 ( .A0(\rxfifo[11][0] ), .A1(n717), .B0(n718), .B1(n657), .Y(
        n397) );
  AO22X1 U2126 ( .A0(\rxfifo[11][1] ), .A1(n717), .B0(n718), .B1(n656), .Y(
        n398) );
  AO22X1 U2127 ( .A0(\rxfifo[11][2] ), .A1(n717), .B0(n718), .B1(n655), .Y(
        n399) );
  AO22X1 U2128 ( .A0(\rxfifo[11][3] ), .A1(n717), .B0(n718), .B1(n654), .Y(
        n400) );
  AO22X1 U2129 ( .A0(\rxfifo[11][4] ), .A1(n717), .B0(n718), .B1(n653), .Y(
        n401) );
  AO22X1 U2130 ( .A0(\rxfifo[11][5] ), .A1(n717), .B0(n718), .B1(n652), .Y(
        n402) );
  AO22X1 U2131 ( .A0(\rxfifo[11][6] ), .A1(n717), .B0(n718), .B1(n651), .Y(
        n403) );
  AO22X1 U2132 ( .A0(\rxfifo[11][7] ), .A1(n717), .B0(n718), .B1(n1628), .Y(
        n404) );
  AO22X1 U2133 ( .A0(\rxfifo[12][0] ), .A1(n715), .B0(n716), .B1(n1633), .Y(
        n405) );
  AO22X1 U2134 ( .A0(\rxfifo[12][1] ), .A1(n715), .B0(n716), .B1(n1635), .Y(
        n406) );
  AO22X1 U2135 ( .A0(\rxfifo[12][2] ), .A1(n715), .B0(n716), .B1(n1637), .Y(
        n407) );
  AO22X1 U2136 ( .A0(\rxfifo[12][3] ), .A1(n715), .B0(n716), .B1(n1639), .Y(
        n408) );
  AO22X1 U2137 ( .A0(\rxfifo[12][4] ), .A1(n715), .B0(n716), .B1(n1641), .Y(
        n409) );
  AO22X1 U2138 ( .A0(\rxfifo[12][5] ), .A1(n715), .B0(n716), .B1(n1643), .Y(
        n410) );
  AO22X1 U2139 ( .A0(\rxfifo[12][6] ), .A1(n715), .B0(n716), .B1(n1645), .Y(
        n411) );
  AO22X1 U2140 ( .A0(\rxfifo[12][7] ), .A1(n715), .B0(n716), .B1(n1628), .Y(
        n412) );
  AO22X1 U2141 ( .A0(\rxfifo[13][0] ), .A1(n713), .B0(n714), .B1(n1632), .Y(
        n413) );
  AO22X1 U2142 ( .A0(\rxfifo[13][1] ), .A1(n713), .B0(n714), .B1(n1634), .Y(
        n414) );
  AO22X1 U2143 ( .A0(\rxfifo[13][2] ), .A1(n713), .B0(n714), .B1(n1636), .Y(
        n415) );
  AO22X1 U2144 ( .A0(\rxfifo[13][3] ), .A1(n713), .B0(n714), .B1(n1638), .Y(
        n416) );
  AO22X1 U2145 ( .A0(\rxfifo[13][4] ), .A1(n713), .B0(n714), .B1(n1640), .Y(
        n417) );
  AO22X1 U2146 ( .A0(\rxfifo[13][5] ), .A1(n713), .B0(n714), .B1(n1642), .Y(
        n418) );
  AO22X1 U2147 ( .A0(\rxfifo[13][6] ), .A1(n713), .B0(n714), .B1(n1644), .Y(
        n419) );
  AO22X1 U2148 ( .A0(\rxfifo[13][7] ), .A1(n713), .B0(n714), .B1(n1628), .Y(
        n420) );
  AO22X1 U2149 ( .A0(\rxfifo[14][0] ), .A1(n710), .B0(n711), .B1(n657), .Y(
        n421) );
  AO22X1 U2150 ( .A0(\rxfifo[14][1] ), .A1(n710), .B0(n711), .B1(n656), .Y(
        n422) );
  AO22X1 U2151 ( .A0(\rxfifo[14][2] ), .A1(n710), .B0(n711), .B1(n655), .Y(
        n423) );
  AO22X1 U2152 ( .A0(\rxfifo[14][3] ), .A1(n710), .B0(n711), .B1(n654), .Y(
        n424) );
  AO22X1 U2153 ( .A0(\rxfifo[14][4] ), .A1(n710), .B0(n711), .B1(n653), .Y(
        n425) );
  AO22X1 U2154 ( .A0(\rxfifo[14][5] ), .A1(n710), .B0(n711), .B1(n652), .Y(
        n426) );
  AO22X1 U2155 ( .A0(\rxfifo[14][6] ), .A1(n710), .B0(n711), .B1(n651), .Y(
        n427) );
  AO22X1 U2156 ( .A0(\rxfifo[14][7] ), .A1(n710), .B0(n711), .B1(n1628), .Y(
        n428) );
  AO22X1 U2157 ( .A0(\rxfifo[15][0] ), .A1(n707), .B0(n708), .B1(n1633), .Y(
        n429) );
  AO22X1 U2158 ( .A0(\rxfifo[15][1] ), .A1(n707), .B0(n708), .B1(n1635), .Y(
        n430) );
  AO22X1 U2159 ( .A0(\rxfifo[15][2] ), .A1(n707), .B0(n708), .B1(n1637), .Y(
        n431) );
  AO22X1 U2160 ( .A0(\rxfifo[15][3] ), .A1(n707), .B0(n708), .B1(n1639), .Y(
        n432) );
  AO22X1 U2161 ( .A0(\rxfifo[15][4] ), .A1(n707), .B0(n708), .B1(n1641), .Y(
        n433) );
  AO22X1 U2162 ( .A0(\rxfifo[15][5] ), .A1(n707), .B0(n708), .B1(n1643), .Y(
        n434) );
  AO22X1 U2163 ( .A0(\rxfifo[15][6] ), .A1(n707), .B0(n708), .B1(n1645), .Y(
        n435) );
  AO22X1 U2164 ( .A0(\rxfifo[15][7] ), .A1(n707), .B0(n708), .B1(n1628), .Y(
        n436) );
  AO22X1 U2165 ( .A0(\rxfifo[16][0] ), .A1(n704), .B0(n705), .B1(n1632), .Y(
        n437) );
  AO22X1 U2166 ( .A0(\rxfifo[16][1] ), .A1(n704), .B0(n705), .B1(n1634), .Y(
        n438) );
  AO22X1 U2167 ( .A0(\rxfifo[16][2] ), .A1(n704), .B0(n705), .B1(n1636), .Y(
        n439) );
  AO22X1 U2168 ( .A0(\rxfifo[16][3] ), .A1(n704), .B0(n705), .B1(n1638), .Y(
        n440) );
  AO22X1 U2169 ( .A0(\rxfifo[16][4] ), .A1(n704), .B0(n705), .B1(n1640), .Y(
        n441) );
  AO22X1 U2170 ( .A0(\rxfifo[16][5] ), .A1(n704), .B0(n705), .B1(n1642), .Y(
        n442) );
  AO22X1 U2171 ( .A0(\rxfifo[16][6] ), .A1(n704), .B0(n705), .B1(n1644), .Y(
        n4430) );
  AO22X1 U2172 ( .A0(\rxfifo[16][7] ), .A1(n704), .B0(n705), .B1(n1628), .Y(
        n444) );
  AO22X1 U2173 ( .A0(\rxfifo[17][0] ), .A1(n702), .B0(n703), .B1(n657), .Y(
        n445) );
  AO22X1 U2174 ( .A0(\rxfifo[17][1] ), .A1(n702), .B0(n703), .B1(n656), .Y(
        n446) );
  AO22X1 U2175 ( .A0(\rxfifo[17][2] ), .A1(n702), .B0(n703), .B1(n655), .Y(
        n447) );
  AO22X1 U2176 ( .A0(\rxfifo[17][3] ), .A1(n702), .B0(n703), .B1(n654), .Y(
        n448) );
  AO22X1 U2177 ( .A0(\rxfifo[17][4] ), .A1(n702), .B0(n703), .B1(n653), .Y(
        n449) );
  AO22X1 U2178 ( .A0(\rxfifo[17][5] ), .A1(n702), .B0(n703), .B1(n652), .Y(
        n450) );
  AO22X1 U2179 ( .A0(\rxfifo[17][6] ), .A1(n702), .B0(n703), .B1(n651), .Y(
        n451) );
  AO22X1 U2180 ( .A0(\rxfifo[17][7] ), .A1(n702), .B0(n703), .B1(n1628), .Y(
        n452) );
  AO22X1 U2181 ( .A0(\rxfifo[18][0] ), .A1(n700), .B0(n701), .B1(n1633), .Y(
        n453) );
  AO22X1 U2182 ( .A0(\rxfifo[18][1] ), .A1(n700), .B0(n701), .B1(n1635), .Y(
        n454) );
  AO22X1 U2183 ( .A0(\rxfifo[18][2] ), .A1(n700), .B0(n701), .B1(n1637), .Y(
        n455) );
  AO22X1 U2184 ( .A0(\rxfifo[18][3] ), .A1(n700), .B0(n701), .B1(n1639), .Y(
        n456) );
  AO22X1 U2185 ( .A0(\rxfifo[18][4] ), .A1(n700), .B0(n701), .B1(n1641), .Y(
        n457) );
  AO22X1 U2186 ( .A0(\rxfifo[18][5] ), .A1(n700), .B0(n701), .B1(n1643), .Y(
        n458) );
  AO22X1 U2187 ( .A0(\rxfifo[18][6] ), .A1(n700), .B0(n701), .B1(n1645), .Y(
        n459) );
  AO22X1 U2188 ( .A0(\rxfifo[18][7] ), .A1(n700), .B0(n701), .B1(n1628), .Y(
        n460) );
  AO22X1 U2189 ( .A0(\rxfifo[19][0] ), .A1(n698), .B0(n699), .B1(n1632), .Y(
        n461) );
  AO22X1 U2190 ( .A0(\rxfifo[19][1] ), .A1(n698), .B0(n699), .B1(n1634), .Y(
        n462) );
  AO22X1 U2191 ( .A0(\rxfifo[19][2] ), .A1(n698), .B0(n699), .B1(n1636), .Y(
        n463) );
  AO22X1 U2192 ( .A0(\rxfifo[19][3] ), .A1(n698), .B0(n699), .B1(n1638), .Y(
        n464) );
  AO22X1 U2193 ( .A0(\rxfifo[19][4] ), .A1(n698), .B0(n699), .B1(n1640), .Y(
        n465) );
  AO22X1 U2194 ( .A0(\rxfifo[19][5] ), .A1(n698), .B0(n699), .B1(n1642), .Y(
        n466) );
  AO22X1 U2195 ( .A0(\rxfifo[19][6] ), .A1(n698), .B0(n699), .B1(n1644), .Y(
        n467) );
  AO22X1 U2196 ( .A0(\rxfifo[19][7] ), .A1(n698), .B0(n699), .B1(n1628), .Y(
        n468) );
  AO22X1 U2197 ( .A0(\rxfifo[20][0] ), .A1(n696), .B0(n697), .B1(n657), .Y(
        n469) );
  AO22X1 U2198 ( .A0(\rxfifo[20][1] ), .A1(n696), .B0(n697), .B1(n656), .Y(
        n470) );
  AO22X1 U2199 ( .A0(\rxfifo[20][2] ), .A1(n696), .B0(n697), .B1(n655), .Y(
        n471) );
  AO22X1 U2200 ( .A0(\rxfifo[20][3] ), .A1(n696), .B0(n697), .B1(n654), .Y(
        n472) );
  AO22X1 U2201 ( .A0(\rxfifo[20][4] ), .A1(n696), .B0(n697), .B1(n653), .Y(
        n473) );
  AO22X1 U2202 ( .A0(\rxfifo[20][5] ), .A1(n696), .B0(n697), .B1(n652), .Y(
        n474) );
  AO22X1 U2203 ( .A0(\rxfifo[20][6] ), .A1(n696), .B0(n697), .B1(n651), .Y(
        n475) );
  AO22X1 U2204 ( .A0(\rxfifo[20][7] ), .A1(n696), .B0(n697), .B1(n1628), .Y(
        n476) );
  AO22X1 U2205 ( .A0(\rxfifo[21][0] ), .A1(n694), .B0(n695), .B1(n1633), .Y(
        n477) );
  AO22X1 U2206 ( .A0(\rxfifo[21][1] ), .A1(n694), .B0(n695), .B1(n1635), .Y(
        n478) );
  AO22X1 U2207 ( .A0(\rxfifo[21][2] ), .A1(n694), .B0(n695), .B1(n1637), .Y(
        n479) );
  AO22X1 U2208 ( .A0(\rxfifo[21][3] ), .A1(n694), .B0(n695), .B1(n1639), .Y(
        n480) );
  AO22X1 U2209 ( .A0(\rxfifo[21][4] ), .A1(n694), .B0(n695), .B1(n1641), .Y(
        n481) );
  AO22X1 U2210 ( .A0(\rxfifo[21][5] ), .A1(n694), .B0(n695), .B1(n1643), .Y(
        n482) );
  AO22X1 U2211 ( .A0(\rxfifo[21][6] ), .A1(n694), .B0(n695), .B1(n1645), .Y(
        n483) );
  AO22X1 U2212 ( .A0(\rxfifo[21][7] ), .A1(n694), .B0(n695), .B1(n1628), .Y(
        n484) );
  AO22X1 U2213 ( .A0(\rxfifo[22][0] ), .A1(n691), .B0(n692), .B1(n1632), .Y(
        n485) );
  AO22X1 U2214 ( .A0(\rxfifo[22][1] ), .A1(n691), .B0(n692), .B1(n1634), .Y(
        n486) );
  AO22X1 U2215 ( .A0(\rxfifo[22][2] ), .A1(n691), .B0(n692), .B1(n1636), .Y(
        n487) );
  AO22X1 U2216 ( .A0(\rxfifo[22][3] ), .A1(n691), .B0(n692), .B1(n1638), .Y(
        n488) );
  AO22X1 U2217 ( .A0(\rxfifo[22][4] ), .A1(n691), .B0(n692), .B1(n1640), .Y(
        n489) );
  AO22X1 U2218 ( .A0(\rxfifo[22][5] ), .A1(n691), .B0(n692), .B1(n1642), .Y(
        n490) );
  AO22X1 U2219 ( .A0(\rxfifo[22][6] ), .A1(n691), .B0(n692), .B1(n1644), .Y(
        n491) );
  AO22X1 U2220 ( .A0(\rxfifo[22][7] ), .A1(n691), .B0(n692), .B1(n1628), .Y(
        n492) );
  AO22X1 U2221 ( .A0(\rxfifo[23][0] ), .A1(n688), .B0(n689), .B1(n657), .Y(
        n493) );
  AO22X1 U2222 ( .A0(\rxfifo[23][1] ), .A1(n688), .B0(n689), .B1(n656), .Y(
        n494) );
  AO22X1 U2223 ( .A0(\rxfifo[23][2] ), .A1(n688), .B0(n689), .B1(n655), .Y(
        n495) );
  AO22X1 U2224 ( .A0(\rxfifo[23][3] ), .A1(n688), .B0(n689), .B1(n654), .Y(
        n496) );
  AO22X1 U2225 ( .A0(\rxfifo[23][4] ), .A1(n688), .B0(n689), .B1(n653), .Y(
        n497) );
  AO22X1 U2226 ( .A0(\rxfifo[23][5] ), .A1(n688), .B0(n689), .B1(n652), .Y(
        n498) );
  AO22X1 U2227 ( .A0(\rxfifo[23][6] ), .A1(n688), .B0(n689), .B1(n651), .Y(
        n499) );
  AO22X1 U2228 ( .A0(\rxfifo[23][7] ), .A1(n688), .B0(n689), .B1(n1628), .Y(
        n500) );
  AO22X1 U2229 ( .A0(\rxfifo[24][0] ), .A1(n684), .B0(n685), .B1(n1633), .Y(
        n501) );
  AO22X1 U2230 ( .A0(\rxfifo[24][1] ), .A1(n684), .B0(n685), .B1(n1635), .Y(
        n502) );
  AO22X1 U2231 ( .A0(\rxfifo[24][2] ), .A1(n684), .B0(n685), .B1(n1637), .Y(
        n503) );
  AO22X1 U2232 ( .A0(\rxfifo[24][3] ), .A1(n684), .B0(n685), .B1(n1639), .Y(
        n504) );
  AO22X1 U2233 ( .A0(\rxfifo[24][4] ), .A1(n684), .B0(n685), .B1(n1641), .Y(
        n505) );
  AO22X1 U2234 ( .A0(\rxfifo[24][5] ), .A1(n684), .B0(n685), .B1(n1643), .Y(
        n506) );
  AO22X1 U2235 ( .A0(\rxfifo[24][6] ), .A1(n684), .B0(n685), .B1(n1645), .Y(
        n507) );
  AO22X1 U2236 ( .A0(\rxfifo[24][7] ), .A1(n684), .B0(n685), .B1(n1628), .Y(
        n508) );
  AO22X1 U2237 ( .A0(\rxfifo[25][0] ), .A1(n680), .B0(n681), .B1(n1632), .Y(
        n509) );
  AO22X1 U2238 ( .A0(\rxfifo[25][1] ), .A1(n680), .B0(n681), .B1(n1634), .Y(
        n510) );
  AO22X1 U2239 ( .A0(\rxfifo[25][2] ), .A1(n680), .B0(n681), .B1(n1636), .Y(
        n5110) );
  AO22X1 U2240 ( .A0(\rxfifo[25][3] ), .A1(n680), .B0(n681), .B1(n1638), .Y(
        n5120) );
  AO22X1 U2241 ( .A0(\rxfifo[25][4] ), .A1(n680), .B0(n681), .B1(n1640), .Y(
        n5130) );
  AO22X1 U2242 ( .A0(\rxfifo[25][5] ), .A1(n680), .B0(n681), .B1(n1642), .Y(
        n5140) );
  AO22X1 U2243 ( .A0(\rxfifo[25][6] ), .A1(n680), .B0(n681), .B1(n1644), .Y(
        n5150) );
  AO22X1 U2244 ( .A0(\rxfifo[25][7] ), .A1(n680), .B0(n681), .B1(n1628), .Y(
        n5160) );
  AO22X1 U2245 ( .A0(\rxfifo[26][0] ), .A1(n676), .B0(n677), .B1(n657), .Y(
        n5170) );
  AO22X1 U2246 ( .A0(\rxfifo[26][1] ), .A1(n676), .B0(n677), .B1(n656), .Y(
        n5180) );
  AO22X1 U2247 ( .A0(\rxfifo[26][2] ), .A1(n676), .B0(n677), .B1(n655), .Y(
        n5190) );
  AO22X1 U2248 ( .A0(\rxfifo[26][3] ), .A1(n676), .B0(n677), .B1(n654), .Y(
        n5200) );
  AO22X1 U2249 ( .A0(\rxfifo[26][4] ), .A1(n676), .B0(n677), .B1(n653), .Y(
        n5210) );
  AO22X1 U2250 ( .A0(\rxfifo[26][5] ), .A1(n676), .B0(n677), .B1(n652), .Y(
        n5220) );
  AO22X1 U2251 ( .A0(\rxfifo[26][6] ), .A1(n676), .B0(n677), .B1(n651), .Y(
        n5230) );
  AO22X1 U2252 ( .A0(\rxfifo[26][7] ), .A1(n676), .B0(n677), .B1(n1628), .Y(
        n5240) );
  AO22X1 U2253 ( .A0(\rxfifo[27][0] ), .A1(n672), .B0(n673), .B1(n1633), .Y(
        n5250) );
  AO22X1 U2254 ( .A0(\rxfifo[27][1] ), .A1(n672), .B0(n673), .B1(n1635), .Y(
        n5260) );
  AO22X1 U2255 ( .A0(\rxfifo[27][2] ), .A1(n672), .B0(n673), .B1(n1637), .Y(
        n5270) );
  AO22X1 U2256 ( .A0(\rxfifo[27][3] ), .A1(n672), .B0(n673), .B1(n1639), .Y(
        n5280) );
  AO22X1 U2257 ( .A0(\rxfifo[27][4] ), .A1(n672), .B0(n673), .B1(n1641), .Y(
        n529) );
  AO22X1 U2258 ( .A0(\rxfifo[27][5] ), .A1(n672), .B0(n673), .B1(n1643), .Y(
        n530) );
  AO22X1 U2259 ( .A0(\rxfifo[27][6] ), .A1(n672), .B0(n673), .B1(n1645), .Y(
        n531) );
  AO22X1 U2260 ( .A0(\rxfifo[27][7] ), .A1(n672), .B0(n673), .B1(n1628), .Y(
        n532) );
  AO22X1 U2261 ( .A0(\rxfifo[28][0] ), .A1(n668), .B0(n669), .B1(n1632), .Y(
        n533) );
  AO22X1 U2262 ( .A0(\rxfifo[28][1] ), .A1(n668), .B0(n669), .B1(n1634), .Y(
        n534) );
  AO22X1 U2263 ( .A0(\rxfifo[28][2] ), .A1(n668), .B0(n669), .B1(n1636), .Y(
        n535) );
  AO22X1 U2264 ( .A0(\rxfifo[28][3] ), .A1(n668), .B0(n669), .B1(n1638), .Y(
        n536) );
  AO22X1 U2265 ( .A0(\rxfifo[28][4] ), .A1(n668), .B0(n669), .B1(n1640), .Y(
        n537) );
  AO22X1 U2266 ( .A0(\rxfifo[28][5] ), .A1(n668), .B0(n669), .B1(n1642), .Y(
        n538) );
  AO22X1 U2267 ( .A0(\rxfifo[28][6] ), .A1(n668), .B0(n669), .B1(n1644), .Y(
        n539) );
  AO22X1 U2268 ( .A0(\rxfifo[28][7] ), .A1(n668), .B0(n669), .B1(n1628), .Y(
        n540) );
  AO22X1 U2269 ( .A0(\rxfifo[29][0] ), .A1(n664), .B0(n665), .B1(n657), .Y(
        n541) );
  AO22X1 U2270 ( .A0(\rxfifo[29][1] ), .A1(n664), .B0(n665), .B1(n656), .Y(
        n542) );
  AO22X1 U2271 ( .A0(\rxfifo[29][2] ), .A1(n664), .B0(n665), .B1(n655), .Y(
        n543) );
  AO22X1 U2272 ( .A0(\rxfifo[29][3] ), .A1(n664), .B0(n665), .B1(n654), .Y(
        n544) );
  AO22X1 U2273 ( .A0(\rxfifo[29][4] ), .A1(n664), .B0(n665), .B1(n653), .Y(
        n545) );
  AO22X1 U2274 ( .A0(\rxfifo[29][5] ), .A1(n664), .B0(n665), .B1(n652), .Y(
        n546) );
  AO22X1 U2275 ( .A0(\rxfifo[29][6] ), .A1(n664), .B0(n665), .B1(n651), .Y(
        n547) );
  AO22X1 U2276 ( .A0(\rxfifo[29][7] ), .A1(n664), .B0(n665), .B1(n1628), .Y(
        n548) );
  AO22X1 U2277 ( .A0(\rxfifo[30][0] ), .A1(n660), .B0(n661), .B1(n1633), .Y(
        n549) );
  AO22X1 U2278 ( .A0(\rxfifo[30][1] ), .A1(n660), .B0(n661), .B1(n1635), .Y(
        n550) );
  AO22X1 U2279 ( .A0(\rxfifo[30][2] ), .A1(n660), .B0(n661), .B1(n1637), .Y(
        n551) );
  AO22X1 U2280 ( .A0(\rxfifo[30][3] ), .A1(n660), .B0(n661), .B1(n1639), .Y(
        n552) );
  AO22X1 U2281 ( .A0(\rxfifo[30][4] ), .A1(n660), .B0(n661), .B1(n1641), .Y(
        n553) );
  AO22X1 U2282 ( .A0(\rxfifo[30][5] ), .A1(n660), .B0(n661), .B1(n1643), .Y(
        n554) );
  AO22X1 U2283 ( .A0(\rxfifo[30][6] ), .A1(n660), .B0(n661), .B1(n1645), .Y(
        n555) );
  AO22X1 U2284 ( .A0(\rxfifo[30][7] ), .A1(n660), .B0(n661), .B1(n1628), .Y(
        n556) );
  AO22X1 U2285 ( .A0(\rxfifo[31][0] ), .A1(n648), .B0(n650), .B1(n1632), .Y(
        n557) );
  AO22X1 U2286 ( .A0(\rxfifo[31][1] ), .A1(n648), .B0(n650), .B1(n1634), .Y(
        n558) );
  AO22X1 U2287 ( .A0(\rxfifo[31][2] ), .A1(n648), .B0(n650), .B1(n1636), .Y(
        n559) );
  AO22X1 U2288 ( .A0(\rxfifo[31][3] ), .A1(n648), .B0(n650), .B1(n1638), .Y(
        n560) );
  AO22X1 U2289 ( .A0(\rxfifo[31][4] ), .A1(n648), .B0(n650), .B1(n1640), .Y(
        n561) );
  AO22X1 U2290 ( .A0(\rxfifo[31][5] ), .A1(n648), .B0(n650), .B1(n1642), .Y(
        n562) );
  AO22X1 U2291 ( .A0(\rxfifo[31][6] ), .A1(n648), .B0(n650), .B1(n1644), .Y(
        n563) );
  AO22X1 U2292 ( .A0(rxsftreg[0]), .A1(n767), .B0(n768), .B1(rxsftreg[1]), .Y(
        n294) );
  AO22X1 U2293 ( .A0(rxsftreg[1]), .A1(n767), .B0(n768), .B1(rxsftreg[2]), .Y(
        n295) );
  AO22X1 U2294 ( .A0(rxsftreg[2]), .A1(n767), .B0(n768), .B1(rxsftreg[3]), .Y(
        n296) );
  AO22X1 U2295 ( .A0(rxsftreg[3]), .A1(n767), .B0(n768), .B1(rxsftreg[4]), .Y(
        n297) );
  AO22X1 U2296 ( .A0(rxsftreg[4]), .A1(n767), .B0(n768), .B1(rxsftreg[5]), .Y(
        n298) );
  AO22X1 U2297 ( .A0(rxsftreg[5]), .A1(n767), .B0(n768), .B1(rxsftreg[6]), .Y(
        n299) );
  AO22X1 U2298 ( .A0(rxsftreg[6]), .A1(n767), .B0(n768), .B1(rxsftreg[7]), .Y(
        n300) );
  AND4X1 U2299 ( .A(n1341), .B(n1489), .C(baudx16clk), .D(n793), .Y(N443) );
  OAI32X1 U2300 ( .A0(n797), .A1(rxclkenb), .A2(rxclkcnt[0]), .B0(n1340), .B1(
        n791), .Y(n287) );
  OAI32X1 U2301 ( .A0(n797), .A1(n801), .A2(n1340), .B0(n803), .B1(n1482), .Y(
        n288) );
  NAND2BX1 U2302 ( .AN(rxclkenb), .B(n1482), .Y(n801) );
  INVX1 U2303 ( .A(n800), .Y(n803) );
  OAI32X1 U2304 ( .A0(n770), .A1(n1620), .A2(n1307), .B0(n1337), .B1(n1308), 
        .Y(N526) );
  INVX1 U2305 ( .A(stopbit), .Y(n1307) );
  NAND2BX1 U2306 ( .AN(N71), .B(N70), .Y(n1273) );
  NAND2BX1 U2307 ( .AN(N73), .B(n1631), .Y(n1284) );
  NAND2BX1 U2308 ( .AN(N70), .B(N71), .Y(n1278) );
  NAND2BX1 U2309 ( .AN(n1473), .B(N70), .Y(n1294) );
  NAND2BX1 U2310 ( .AN(N73), .B(N72), .Y(n1276) );
  NAND2BX1 U2311 ( .AN(N72), .B(N73), .Y(n1302) );
  NAND2BX1 U2312 ( .AN(N71), .B(n1477), .Y(n1275) );
  OAI221X1 U2313 ( .A0(n1517), .A1(n897), .B0(n1370), .B1(n899), .C0(n1290), 
        .Y(n1265) );
  OA22X1 U2314 ( .A0(n1407), .A1(n902), .B0(n1554), .B1(n904), .Y(n1290) );
  OAI221X1 U2315 ( .A0(n1518), .A1(n897), .B0(n1371), .B1(n899), .C0(n1256), 
        .Y(n1241) );
  OA22X1 U2316 ( .A0(n1408), .A1(n902), .B0(n1555), .B1(n904), .Y(n1256) );
  OAI221X1 U2317 ( .A0(n1519), .A1(n897), .B0(n1372), .B1(n899), .C0(n1230), 
        .Y(n1215) );
  OA22X1 U2318 ( .A0(n1409), .A1(n902), .B0(n1556), .B1(n904), .Y(n1230) );
  OAI221X1 U2319 ( .A0(n1520), .A1(n897), .B0(n1373), .B1(n899), .C0(n1206), 
        .Y(n1191) );
  OA22X1 U2320 ( .A0(n1410), .A1(n902), .B0(n1557), .B1(n904), .Y(n1206) );
  OAI221X1 U2321 ( .A0(n1521), .A1(n897), .B0(n1374), .B1(n899), .C0(n1180), 
        .Y(n1165) );
  OA22X1 U2322 ( .A0(n1411), .A1(n902), .B0(n1558), .B1(n904), .Y(n1180) );
  OAI221X1 U2323 ( .A0(n1522), .A1(n897), .B0(n1375), .B1(n899), .C0(n1156), 
        .Y(n1141) );
  OA22X1 U2324 ( .A0(n1412), .A1(n902), .B0(n1559), .B1(n904), .Y(n1156) );
  OAI221X1 U2325 ( .A0(n1523), .A1(n897), .B0(n1376), .B1(n899), .C0(n1130), 
        .Y(n1115) );
  OA22X1 U2326 ( .A0(n1413), .A1(n902), .B0(n1560), .B1(n904), .Y(n1130) );
  OAI221X1 U2327 ( .A0(n1524), .A1(n897), .B0(n1377), .B1(n899), .C0(n1106), 
        .Y(n1091) );
  OA22X1 U2328 ( .A0(n1414), .A1(n902), .B0(n1561), .B1(n904), .Y(n1106) );
  OAI221X1 U2329 ( .A0(n1525), .A1(n897), .B0(n1378), .B1(n899), .C0(n1080), 
        .Y(n1065) );
  OA22X1 U2330 ( .A0(n1415), .A1(n902), .B0(n1562), .B1(n904), .Y(n1080) );
  OAI221X1 U2331 ( .A0(n1526), .A1(n897), .B0(n1379), .B1(n899), .C0(n1056), 
        .Y(n1041) );
  OA22X1 U2332 ( .A0(n1416), .A1(n902), .B0(n1563), .B1(n904), .Y(n1056) );
  OAI221X1 U2333 ( .A0(n1527), .A1(n897), .B0(n1380), .B1(n899), .C0(n1030), 
        .Y(n1015) );
  OA22X1 U2334 ( .A0(n1417), .A1(n902), .B0(n1564), .B1(n904), .Y(n1030) );
  OAI221X1 U2335 ( .A0(n1528), .A1(n897), .B0(n1381), .B1(n899), .C0(n1006), 
        .Y(n991) );
  OA22X1 U2336 ( .A0(n1418), .A1(n902), .B0(n1565), .B1(n904), .Y(n1006) );
  OAI221X1 U2337 ( .A0(n1529), .A1(n897), .B0(n1382), .B1(n899), .C0(n980), 
        .Y(n965) );
  OA22X1 U2338 ( .A0(n1419), .A1(n902), .B0(n1566), .B1(n904), .Y(n980) );
  OAI221X1 U2339 ( .A0(n1530), .A1(n897), .B0(n1383), .B1(n899), .C0(n956), 
        .Y(n941) );
  OA22X1 U2340 ( .A0(n1420), .A1(n902), .B0(n1567), .B1(n904), .Y(n956) );
  OAI221X1 U2341 ( .A0(n1531), .A1(n897), .B0(n1384), .B1(n899), .C0(n930), 
        .Y(n915) );
  OA22X1 U2342 ( .A0(n1421), .A1(n902), .B0(n1568), .B1(n904), .Y(n930) );
  OAI221X1 U2343 ( .A0(n1532), .A1(n897), .B0(n1385), .B1(n899), .C0(n900), 
        .Y(n875) );
  OA22X1 U2344 ( .A0(n1422), .A1(n902), .B0(n1569), .B1(n904), .Y(n900) );
  OAI221X1 U2345 ( .A0(n1533), .A1(n879), .B0(n1386), .B1(n881), .C0(n1270), 
        .Y(n1267) );
  OA22X1 U2346 ( .A0(n1423), .A1(n884), .B0(n1570), .B1(n886), .Y(n1270) );
  OAI221X1 U2347 ( .A0(n1534), .A1(n879), .B0(n1387), .B1(n881), .C0(n1246), 
        .Y(n1243) );
  OA22X1 U2348 ( .A0(n1424), .A1(n884), .B0(n1571), .B1(n886), .Y(n1246) );
  OAI221X1 U2349 ( .A0(n1535), .A1(n879), .B0(n1388), .B1(n881), .C0(n1096), 
        .Y(n1093) );
  OA22X1 U2350 ( .A0(n1425), .A1(n884), .B0(n1572), .B1(n886), .Y(n1096) );
  OAI221X1 U2351 ( .A0(n1536), .A1(n879), .B0(n1389), .B1(n881), .C0(n1046), 
        .Y(n1043) );
  OA22X1 U2352 ( .A0(n1426), .A1(n884), .B0(n1573), .B1(n886), .Y(n1046) );
  OAI221X1 U2353 ( .A0(n1537), .A1(n879), .B0(n1390), .B1(n881), .C0(n946), 
        .Y(n943) );
  OA22X1 U2354 ( .A0(n1427), .A1(n884), .B0(n1574), .B1(n886), .Y(n946) );
  OAI221X1 U2355 ( .A0(n1538), .A1(n879), .B0(n1391), .B1(n881), .C0(n920), 
        .Y(n917) );
  OA22X1 U2356 ( .A0(n1428), .A1(n884), .B0(n1575), .B1(n886), .Y(n920) );
  OAI221X1 U2357 ( .A0(n1539), .A1(n879), .B0(n1392), .B1(n881), .C0(n882), 
        .Y(n877) );
  OA22X1 U2358 ( .A0(n1429), .A1(n884), .B0(n1576), .B1(n886), .Y(n882) );
  OAI221X1 U2359 ( .A0(n1540), .A1(n888), .B0(n1393), .B1(n890), .C0(n1281), 
        .Y(n1266) );
  OA22X1 U2360 ( .A0(n1430), .A1(n893), .B0(n1577), .B1(n895), .Y(n1281) );
  OAI221X1 U2361 ( .A0(n1541), .A1(n888), .B0(n1394), .B1(n890), .C0(n1251), 
        .Y(n1242) );
  OA22X1 U2362 ( .A0(n1431), .A1(n893), .B0(n1578), .B1(n895), .Y(n1251) );
  OAI221X1 U2363 ( .A0(n1542), .A1(n888), .B0(n1395), .B1(n890), .C0(n1101), 
        .Y(n1092) );
  OA22X1 U2364 ( .A0(n1432), .A1(n893), .B0(n1579), .B1(n895), .Y(n1101) );
  OAI221X1 U2365 ( .A0(n1543), .A1(n888), .B0(n1396), .B1(n890), .C0(n1051), 
        .Y(n1042) );
  OA22X1 U2366 ( .A0(n1433), .A1(n893), .B0(n1580), .B1(n895), .Y(n1051) );
  OAI221X1 U2367 ( .A0(n1544), .A1(n888), .B0(n1397), .B1(n890), .C0(n951), 
        .Y(n942) );
  OA22X1 U2368 ( .A0(n1434), .A1(n893), .B0(n1581), .B1(n895), .Y(n951) );
  OAI221X1 U2369 ( .A0(n1545), .A1(n888), .B0(n1398), .B1(n890), .C0(n925), 
        .Y(n916) );
  OA22X1 U2370 ( .A0(n1435), .A1(n893), .B0(n1582), .B1(n895), .Y(n925) );
  OAI221X1 U2371 ( .A0(n1546), .A1(n888), .B0(n1399), .B1(n890), .C0(n891), 
        .Y(n876) );
  OA22X1 U2372 ( .A0(n1436), .A1(n893), .B0(n1583), .B1(n895), .Y(n891) );
  OAI221X1 U2373 ( .A0(n1547), .A1(n906), .B0(n1400), .B1(n908), .C0(n1298), 
        .Y(n1264) );
  OA22X1 U2374 ( .A0(n1437), .A1(n911), .B0(n1584), .B1(n913), .Y(n1298) );
  OAI221X1 U2375 ( .A0(n1548), .A1(n906), .B0(n1401), .B1(n908), .C0(n1111), 
        .Y(n1090) );
  OA22X1 U2376 ( .A0(n1438), .A1(n911), .B0(n1585), .B1(n913), .Y(n1111) );
  OAI221X1 U2377 ( .A0(n1549), .A1(n906), .B0(n1402), .B1(n908), .C0(n1061), 
        .Y(n1040) );
  OA22X1 U2378 ( .A0(n1439), .A1(n911), .B0(n1586), .B1(n913), .Y(n1061) );
  OAI221X1 U2379 ( .A0(n1550), .A1(n906), .B0(n1403), .B1(n908), .C0(n961), 
        .Y(n940) );
  OA22X1 U2380 ( .A0(n1440), .A1(n911), .B0(n1587), .B1(n913), .Y(n961) );
  OAI221X1 U2381 ( .A0(n1551), .A1(n906), .B0(n1404), .B1(n908), .C0(n935), 
        .Y(n914) );
  OA22X1 U2382 ( .A0(n1441), .A1(n911), .B0(n1588), .B1(n913), .Y(n935) );
  OA22X1 U2383 ( .A0(n1442), .A1(n911), .B0(n1589), .B1(n913), .Y(n1261) );
  OA22X1 U2384 ( .A0(n1443), .A1(n884), .B0(n1590), .B1(n886), .Y(n1220) );
  OA22X1 U2385 ( .A0(n1444), .A1(n893), .B0(n1591), .B1(n895), .Y(n1225) );
  OA22X1 U2386 ( .A0(n1445), .A1(n911), .B0(n1592), .B1(n913), .Y(n1235) );
  OA22X1 U2387 ( .A0(n1446), .A1(n884), .B0(n1593), .B1(n886), .Y(n1196) );
  OA22X1 U2388 ( .A0(n1447), .A1(n893), .B0(n1594), .B1(n895), .Y(n1201) );
  OA22X1 U2389 ( .A0(n1448), .A1(n911), .B0(n1595), .B1(n913), .Y(n1211) );
  OA22X1 U2390 ( .A0(n1449), .A1(n884), .B0(n1596), .B1(n886), .Y(n1170) );
  OA22X1 U2391 ( .A0(n1450), .A1(n893), .B0(n1597), .B1(n895), .Y(n1175) );
  OA22X1 U2392 ( .A0(n1451), .A1(n911), .B0(n1598), .B1(n913), .Y(n1185) );
  OA22X1 U2393 ( .A0(n1452), .A1(n884), .B0(n1599), .B1(n886), .Y(n1146) );
  OA22X1 U2394 ( .A0(n1453), .A1(n893), .B0(n1600), .B1(n895), .Y(n1151) );
  OA22X1 U2395 ( .A0(n1454), .A1(n911), .B0(n1601), .B1(n913), .Y(n1161) );
  OA22X1 U2396 ( .A0(n1455), .A1(n884), .B0(n1602), .B1(n886), .Y(n1120) );
  OA22X1 U2397 ( .A0(n1456), .A1(n893), .B0(n1603), .B1(n895), .Y(n1125) );
  OA22X1 U2398 ( .A0(n1457), .A1(n911), .B0(n1604), .B1(n913), .Y(n1135) );
  OA22X1 U2399 ( .A0(n1458), .A1(n884), .B0(n1605), .B1(n886), .Y(n1070) );
  OA22X1 U2400 ( .A0(n1459), .A1(n893), .B0(n1606), .B1(n895), .Y(n1075) );
  OA22X1 U2401 ( .A0(n1460), .A1(n911), .B0(n1607), .B1(n913), .Y(n1085) );
  OA22X1 U2402 ( .A0(n1461), .A1(n884), .B0(n1608), .B1(n886), .Y(n1020) );
  OA22X1 U2403 ( .A0(n1462), .A1(n893), .B0(n1609), .B1(n895), .Y(n1025) );
  OA22X1 U2404 ( .A0(n1463), .A1(n911), .B0(n1610), .B1(n913), .Y(n1035) );
  OA22X1 U2405 ( .A0(n1464), .A1(n884), .B0(n1611), .B1(n886), .Y(n996) );
  OA22X1 U2406 ( .A0(n1465), .A1(n893), .B0(n1612), .B1(n895), .Y(n1001) );
  OA22X1 U2407 ( .A0(n1466), .A1(n911), .B0(n1613), .B1(n913), .Y(n1011) );
  OA22X1 U2408 ( .A0(n1467), .A1(n884), .B0(n1614), .B1(n886), .Y(n970) );
  OA22X1 U2409 ( .A0(n1468), .A1(n893), .B0(n1615), .B1(n895), .Y(n975) );
  OA22X1 U2410 ( .A0(n1469), .A1(n911), .B0(n1616), .B1(n913), .Y(n985) );
  OA22X1 U2411 ( .A0(n1470), .A1(n911), .B0(n1617), .B1(n913), .Y(n909) );
  AO22X1 U2412 ( .A0(n938), .A1(n1471), .B0(n939), .B1(N74), .Y(fifodata_rx[6]) );
  OR4X1 U2413 ( .A(n940), .B(n941), .C(n942), .D(n943), .Y(n939) );
  NOR2X1 U2414 ( .A(n1472), .B(n1631), .Y(n1630) );
  AO22X1 U2415 ( .A0(n1088), .A1(n1471), .B0(n1089), .B1(N74), .Y(
        fifodata_rx[3]) );
  OR4X1 U2416 ( .A(n1090), .B(n1091), .C(n1092), .D(n1093), .Y(n1089) );
  AO22X1 U2417 ( .A0(n988), .A1(n1471), .B0(n989), .B1(N74), .Y(fifodata_rx[5]) );
  AO22X1 U2418 ( .A0(n1138), .A1(n1471), .B0(n1139), .B1(N74), .Y(
        fifodata_rx[2]) );
  AO22X1 U2419 ( .A0(n1188), .A1(n1471), .B0(n1189), .B1(N74), .Y(
        fifodata_rx[1]) );
  AO22X1 U2420 ( .A0(n1038), .A1(n1471), .B0(n1039), .B1(N74), .Y(
        fifodata_rx[4]) );
  OR4X1 U2421 ( .A(n1040), .B(n1041), .C(n1042), .D(n1043), .Y(n1039) );
  AO22X1 U2422 ( .A0(n1238), .A1(n1471), .B0(n1239), .B1(N74), .Y(
        fifodata_rx[0]) );
  OR4X1 U2423 ( .A(n1240), .B(n1241), .C(n1242), .D(n1243), .Y(n1239) );
  OR4X1 U2424 ( .A(n1264), .B(n1265), .C(n1266), .D(n1267), .Y(n1238) );
  OAI221X1 U2425 ( .A0(n1552), .A1(n906), .B0(n1405), .B1(n908), .C0(n1261), 
        .Y(n1240) );
  AO22X1 U2426 ( .A0(n872), .A1(n1471), .B0(n873), .B1(N74), .Y(fifodata_rx[7]) );
  OR4X1 U2427 ( .A(n874), .B(n875), .C(n876), .D(n877), .Y(n873) );
  OR4X1 U2428 ( .A(n914), .B(n915), .C(n916), .D(n917), .Y(n872) );
  OAI221X1 U2429 ( .A0(n1553), .A1(n906), .B0(n1406), .B1(n908), .C0(n909), 
        .Y(n874) );
  DFFRX1 fifo_rdpos_reg_0_ ( .D(n566), .CK(clk), .RN(rstb), .Q(N70), .QN(n1477) );
  DFFRX1 fifo_wrpos_reg_3_ ( .D(n574), .CK(clk), .RN(rstb), .Q(fifo_wrpos_3_), 
        .QN(n1478) );
  DFFRX1 fifo_wrpos_reg_2_ ( .D(n573), .CK(clk), .RN(rstb), .Q(fifo_wrpos_2_)
         );
  DFFRX1 fifo_wrpos_reg_4_ ( .D(n575), .CK(clk), .RN(rstb), .Q(fifo_wrpos_4_), 
        .QN(n1484) );
  DFFRX1 fifo_rdpos_reg_2_ ( .D(n568), .CK(clk), .RN(rstb), .Q(N72), .QN(n1631) );
  DFFRX1 fifo_rdpos_reg_1_ ( .D(n567), .CK(clk), .RN(rstb), .Q(N71), .QN(n1473) );
  DFFRX1 fifo_rdpos_reg_3_ ( .D(n569), .CK(clk), .RN(rstb), .Q(N73), .QN(n1472) );
  DFFSX1 rx_lpfd_reg ( .D(n302), .CK(clk), .SN(rstb), .Q(rx_lpfd), .QN(n1622)
         );
  DFFRX1 current_state_reg_1_ ( .D(N512), .CK(clk), .RN(rstb), .Q(
        current_state_1_), .QN(n1474) );
  DFFRX1 fifo_wrpos_reg_0_ ( .D(n571), .CK(clk), .RN(rstb), .Q(fifo_wrpos_0_), 
        .QN(n1332) );
  DFFRX1 fifo_wrpos_reg_1_ ( .D(n572), .CK(clk), .RN(rstb), .Q(n578), .QN(
        n1336) );
  DFFRX1 current_state_reg_17_ ( .D(N528), .CK(clk), .RN(rstb), .QN(n17) );
  DFFRX1 current_state_reg_2_ ( .D(N513), .CK(clk), .RN(rstb), .Q(
        current_state_2_) );
  DFFRX1 current_state_reg_4_ ( .D(N515), .CK(clk), .RN(rstb), .Q(
        current_state_4_) );
  DFFRX1 current_state_reg_3_ ( .D(N514), .CK(clk), .RN(rstb), .Q(
        current_state_3_) );
  DFFSX1 current_state_reg_0_ ( .D(N511), .CK(clk), .SN(rstb), .QN(n1619) );
  DFFRX1 fifo_rdpos_reg_4_ ( .D(n570), .CK(clk), .RN(rstb), .Q(N74), .QN(n1471) );
  DFFRX1 fifofull_reg ( .D(n565), .CK(clk), .RN(rstb), .Q(rxfifocnt[5]), .QN(
        n1475) );
  DFFSX1 in_dly_reg_3_ ( .D(n306), .CK(clk), .SN(rstb), .Q(in_dly[3]), .QN(
        n1342) );
  DFFSX1 in_dly_reg_4_ ( .D(n307), .CK(clk), .SN(rstb), .Q(in_dly[4]), .QN(
        n1627) );
  DFFRX1 parity_int_reg ( .D(n291), .CK(clk), .RN(rstb), .Q(parity_int), .QN(
        n1483) );
  DFFRX1 current_state_reg_5_ ( .D(N516), .CK(clk), .RN(rstb), .Q(
        current_state_5_) );
  DFFRX1 current_state_reg_6_ ( .D(N517), .CK(clk), .RN(rstb), .Q(
        current_state_6_) );
  DFFRX1 current_state_reg_8_ ( .D(N519), .CK(clk), .RN(rstb), .Q(
        current_state_8_) );
  DFFRX1 current_state_reg_11_ ( .D(N522), .CK(clk), .RN(rstb), .Q(
        current_state_11_), .QN(n1476) );
  DFFRX1 current_state_reg_13_ ( .D(N524), .CK(clk), .RN(rstb), .Q(
        current_state_13_), .QN(n1334) );
  DFFRX1 current_state_reg_16_ ( .D(N527), .CK(clk), .RN(rstb), .Q(
        current_state_16_), .QN(n1480) );
  DFFRX1 current_state_reg_15_ ( .D(N526), .CK(clk), .RN(rstb), .Q(n18), .QN(
        n1337) );
  DFFRX1 current_state_reg_14_ ( .D(N525), .CK(clk), .RN(rstb), .Q(
        current_state_14_), .QN(n1479) );
  DFFRX1 current_state_reg_12_ ( .D(N523), .CK(clk), .RN(rstb), .QN(n1330) );
  DFFRX1 current_state_reg_7_ ( .D(N518), .CK(clk), .RN(rstb), .Q(
        current_state_7_) );
  DFFRX1 current_state_reg_9_ ( .D(N520), .CK(clk), .RN(rstb), .Q(
        current_state_9_) );
  DFFRX1 current_state_reg_10_ ( .D(N521), .CK(clk), .RN(rstb), .Q(
        current_state_10_) );
  DFFSX1 fifowrb_reg ( .D(n279), .CK(clk), .SN(rstb), .Q(bytereceivedb), .QN(
        n1335) );
  DFFSX1 in_dly_reg_1_ ( .D(n304), .CK(clk), .SN(rstb), .Q(in_dly[1]), .QN(
        n1481) );
  DFFSX1 in_dly_reg_0_ ( .D(n303), .CK(clk), .SN(rstb), .Q(in_dly[0]), .QN(
        n1338) );
  DFFSX1 rxclkenb_reg ( .D(n283), .CK(clk), .SN(rstb), .Q(rxclkenb), .QN(n1333) );
  DFFRX1 rxclkcnt_reg_3_ ( .D(n290), .CK(clk), .RN(rstb), .Q(rxclkcnt[3]), 
        .QN(n1489) );
  DFFSX1 framechkb_reg ( .D(n280), .CK(clk), .SN(rstb), .Q(framechkb), .QN(
        n1485) );
  DFFSX1 in_dly_reg_2_ ( .D(n305), .CK(clk), .SN(rstb), .Q(in_dly[2]), .QN(
        n1331) );
  DFFRX1 rxclkcnt_reg_0_ ( .D(n287), .CK(clk), .RN(rstb), .Q(rxclkcnt[0]), 
        .QN(n1340) );
  DFFRX1 rxclkcnt_reg_1_ ( .D(n288), .CK(clk), .RN(rstb), .Q(rxclkcnt[1]), 
        .QN(n1482) );
  DFFSX1 dataphaseb_reg ( .D(n286), .CK(clk), .SN(rstb), .Q(dataphaseb), .QN(
        n1486) );
  DFFSX1 rxsftenb_reg ( .D(n282), .CK(clk), .SN(rstb), .Q(rxsftenb), .QN(n1487) );
  DFFSX1 paritychkb_reg ( .D(n281), .CK(clk), .SN(rstb), .Q(paritychkb), .QN(
        n1488) );
  DFFRX1 rxclkcnt_reg_2_ ( .D(n289), .CK(clk), .RN(rstb), .Q(rxclkcnt[2]), 
        .QN(n1341) );
  DFFRX1 parityerror_int_reg ( .D(n292), .CK(clk), .RN(rstb), .Q(parityerror), 
        .QN(n278) );
  DFFRX1 frameerror_int_reg ( .D(n293), .CK(clk), .RN(rstb), .Q(frameerror), 
        .QN(n276) );
  DFFRX1 rxfifo_reg ( .D(n309), .CK(clk), .RN(rstb), .Q(\rxfifo[0][0] ), .QN(
        n1430) );
  DFFRX1 rxfifo_reg0 ( .D(n310), .CK(clk), .RN(rstb), .Q(\rxfifo[0][1] ), .QN(
        n1444) );
  DFFRX1 rxfifo_reg1 ( .D(n311), .CK(clk), .RN(rstb), .Q(\rxfifo[0][2] ), .QN(
        n1450) );
  DFFRX1 rxfifo_reg2 ( .D(n312), .CK(clk), .RN(rstb), .Q(\rxfifo[0][3] ), .QN(
        n1456) );
  DFFRX1 rxfifo_reg3 ( .D(n313), .CK(clk), .RN(rstb), .Q(\rxfifo[0][4] ), .QN(
        n1459) );
  DFFRX1 rxfifo_reg4 ( .D(n314), .CK(clk), .RN(rstb), .Q(\rxfifo[0][5] ), .QN(
        n1462) );
  DFFRX1 rxfifo_reg5 ( .D(n315), .CK(clk), .RN(rstb), .Q(\rxfifo[0][6] ), .QN(
        n1468) );
  DFFRX1 rxfifo_reg6 ( .D(n316), .CK(clk), .RN(rstb), .Q(\rxfifo[0][7] ), .QN(
        n1435) );
  DFFRX1 rxfifo_reg7 ( .D(n317), .CK(clk), .RN(rstb), .Q(\rxfifo[1][0] ), .QN(
        n1577) );
  DFFRX1 rxfifo_reg8 ( .D(n318), .CK(clk), .RN(rstb), .Q(\rxfifo[1][1] ), .QN(
        n1591) );
  DFFRX1 rxfifo_reg9 ( .D(n319), .CK(clk), .RN(rstb), .Q(\rxfifo[1][2] ), .QN(
        n1597) );
  DFFRX1 rxfifo_reg10 ( .D(n320), .CK(clk), .RN(rstb), .Q(\rxfifo[1][3] ), 
        .QN(n1603) );
  DFFRX1 rxfifo_reg11 ( .D(n321), .CK(clk), .RN(rstb), .Q(\rxfifo[1][4] ), 
        .QN(n1606) );
  DFFRX1 rxfifo_reg12 ( .D(n322), .CK(clk), .RN(rstb), .Q(\rxfifo[1][5] ), 
        .QN(n1609) );
  DFFRX1 rxfifo_reg13 ( .D(n323), .CK(clk), .RN(rstb), .Q(\rxfifo[1][6] ), 
        .QN(n1615) );
  DFFRX1 rxfifo_reg14 ( .D(n324), .CK(clk), .RN(rstb), .Q(\rxfifo[1][7] ), 
        .QN(n1582) );
  DFFRX1 rxfifo_reg15 ( .D(n325), .CK(clk), .RN(rstb), .Q(\rxfifo[2][0] ), 
        .QN(n1540) );
  DFFRX1 rxfifo_reg16 ( .D(n326), .CK(clk), .RN(rstb), .Q(\rxfifo[2][1] ), 
        .QN(n1491) );
  DFFRX1 rxfifo_reg17 ( .D(n327), .CK(clk), .RN(rstb), .Q(\rxfifo[2][2] ), 
        .QN(n1494) );
  DFFRX1 rxfifo_reg18 ( .D(n328), .CK(clk), .RN(rstb), .Q(\rxfifo[2][3] ), 
        .QN(n1497) );
  DFFRX1 rxfifo_reg19 ( .D(n329), .CK(clk), .RN(rstb), .Q(\rxfifo[2][4] ), 
        .QN(n1500) );
  DFFRX1 rxfifo_reg20 ( .D(n330), .CK(clk), .RN(rstb), .Q(\rxfifo[2][5] ), 
        .QN(n1503) );
  DFFRX1 rxfifo_reg21 ( .D(n331), .CK(clk), .RN(rstb), .Q(\rxfifo[2][6] ), 
        .QN(n1506) );
  DFFRX1 rxfifo_reg22 ( .D(n332), .CK(clk), .RN(rstb), .Q(\rxfifo[2][7] ), 
        .QN(n1545) );
  DFFRX1 rxfifo_reg23 ( .D(n333), .CK(clk), .RN(rstb), .Q(\rxfifo[3][0] ), 
        .QN(n1393) );
  DFFRX1 rxfifo_reg24 ( .D(n334), .CK(clk), .RN(rstb), .Q(\rxfifo[3][1] ), 
        .QN(n1344) );
  DFFRX1 rxfifo_reg25 ( .D(n335), .CK(clk), .RN(rstb), .Q(\rxfifo[3][2] ), 
        .QN(n1347) );
  DFFRX1 rxfifo_reg26 ( .D(n336), .CK(clk), .RN(rstb), .Q(\rxfifo[3][3] ), 
        .QN(n1350) );
  DFFRX1 rxfifo_reg27 ( .D(n337), .CK(clk), .RN(rstb), .Q(\rxfifo[3][4] ), 
        .QN(n1353) );
  DFFRX1 rxfifo_reg28 ( .D(n338), .CK(clk), .RN(rstb), .Q(\rxfifo[3][5] ), 
        .QN(n1356) );
  DFFRX1 rxfifo_reg29 ( .D(n339), .CK(clk), .RN(rstb), .Q(\rxfifo[3][6] ), 
        .QN(n1359) );
  DFFRX1 rxfifo_reg30 ( .D(n340), .CK(clk), .RN(rstb), .Q(\rxfifo[3][7] ), 
        .QN(n1398) );
  DFFRX1 rxfifo_reg31 ( .D(n341), .CK(clk), .RN(rstb), .Q(\rxfifo[4][0] ), 
        .QN(n1423) );
  DFFRX1 rxfifo_reg32 ( .D(n342), .CK(clk), .RN(rstb), .Q(\rxfifo[4][1] ), 
        .QN(n1443) );
  DFFRX1 rxfifo_reg33 ( .D(n343), .CK(clk), .RN(rstb), .Q(\rxfifo[4][2] ), 
        .QN(n1449) );
  DFFRX1 rxfifo_reg34 ( .D(n344), .CK(clk), .RN(rstb), .Q(\rxfifo[4][3] ), 
        .QN(n1455) );
  DFFRX1 rxfifo_reg35 ( .D(n345), .CK(clk), .RN(rstb), .Q(\rxfifo[4][4] ), 
        .QN(n1458) );
  DFFRX1 rxfifo_reg36 ( .D(n346), .CK(clk), .RN(rstb), .Q(\rxfifo[4][5] ), 
        .QN(n1461) );
  DFFRX1 rxfifo_reg37 ( .D(n347), .CK(clk), .RN(rstb), .Q(\rxfifo[4][6] ), 
        .QN(n1467) );
  DFFRX1 rxfifo_reg38 ( .D(n348), .CK(clk), .RN(rstb), .Q(\rxfifo[4][7] ), 
        .QN(n1428) );
  DFFRX1 rxfifo_reg39 ( .D(n349), .CK(clk), .RN(rstb), .Q(\rxfifo[5][0] ), 
        .QN(n1570) );
  DFFRX1 rxfifo_reg40 ( .D(n350), .CK(clk), .RN(rstb), .Q(\rxfifo[5][1] ), 
        .QN(n1590) );
  DFFRX1 rxfifo_reg41 ( .D(n351), .CK(clk), .RN(rstb), .Q(\rxfifo[5][2] ), 
        .QN(n1596) );
  DFFRX1 rxfifo_reg42 ( .D(n352), .CK(clk), .RN(rstb), .Q(\rxfifo[5][3] ), 
        .QN(n1602) );
  DFFRX1 rxfifo_reg43 ( .D(n353), .CK(clk), .RN(rstb), .Q(\rxfifo[5][4] ), 
        .QN(n1605) );
  DFFRX1 rxfifo_reg44 ( .D(n354), .CK(clk), .RN(rstb), .Q(\rxfifo[5][5] ), 
        .QN(n1608) );
  DFFRX1 rxfifo_reg45 ( .D(n355), .CK(clk), .RN(rstb), .Q(\rxfifo[5][6] ), 
        .QN(n1614) );
  DFFRX1 rxfifo_reg46 ( .D(n356), .CK(clk), .RN(rstb), .Q(\rxfifo[5][7] ), 
        .QN(n1575) );
  DFFRX1 rxfifo_reg47 ( .D(n357), .CK(clk), .RN(rstb), .Q(\rxfifo[6][0] ), 
        .QN(n1533) );
  DFFRX1 rxfifo_reg48 ( .D(n358), .CK(clk), .RN(rstb), .Q(\rxfifo[6][1] ), 
        .QN(n1490) );
  DFFRX1 rxfifo_reg49 ( .D(n359), .CK(clk), .RN(rstb), .Q(\rxfifo[6][2] ), 
        .QN(n1493) );
  DFFRX1 rxfifo_reg50 ( .D(n360), .CK(clk), .RN(rstb), .Q(\rxfifo[6][3] ), 
        .QN(n1496) );
  DFFRX1 rxfifo_reg51 ( .D(n361), .CK(clk), .RN(rstb), .Q(\rxfifo[6][4] ), 
        .QN(n1499) );
  DFFRX1 rxfifo_reg52 ( .D(n362), .CK(clk), .RN(rstb), .Q(\rxfifo[6][5] ), 
        .QN(n1502) );
  DFFRX1 rxfifo_reg53 ( .D(n363), .CK(clk), .RN(rstb), .Q(\rxfifo[6][6] ), 
        .QN(n1505) );
  DFFRX1 rxfifo_reg54 ( .D(n364), .CK(clk), .RN(rstb), .Q(\rxfifo[6][7] ), 
        .QN(n1538) );
  DFFRX1 rxfifo_reg55 ( .D(n365), .CK(clk), .RN(rstb), .Q(\rxfifo[7][0] ), 
        .QN(n1386) );
  DFFRX1 rxfifo_reg56 ( .D(n366), .CK(clk), .RN(rstb), .Q(\rxfifo[7][1] ), 
        .QN(n1343) );
  DFFRX1 rxfifo_reg57 ( .D(n367), .CK(clk), .RN(rstb), .Q(\rxfifo[7][2] ), 
        .QN(n1346) );
  DFFRX1 rxfifo_reg58 ( .D(n368), .CK(clk), .RN(rstb), .Q(\rxfifo[7][3] ), 
        .QN(n1349) );
  DFFRX1 rxfifo_reg59 ( .D(n369), .CK(clk), .RN(rstb), .Q(\rxfifo[7][4] ), 
        .QN(n1352) );
  DFFRX1 rxfifo_reg60 ( .D(n370), .CK(clk), .RN(rstb), .Q(\rxfifo[7][5] ), 
        .QN(n1355) );
  DFFRX1 rxfifo_reg61 ( .D(n371), .CK(clk), .RN(rstb), .Q(\rxfifo[7][6] ), 
        .QN(n1358) );
  DFFRX1 rxfifo_reg62 ( .D(n372), .CK(clk), .RN(rstb), .Q(\rxfifo[7][7] ), 
        .QN(n1391) );
  DFFRX1 rxfifo_reg63 ( .D(n373), .CK(clk), .RN(rstb), .Q(\rxfifo[8][0] ), 
        .QN(n1437) );
  DFFRX1 rxfifo_reg64 ( .D(n374), .CK(clk), .RN(rstb), .Q(\rxfifo[8][1] ), 
        .QN(n1445) );
  DFFRX1 rxfifo_reg65 ( .D(n375), .CK(clk), .RN(rstb), .Q(\rxfifo[8][2] ), 
        .QN(n1451) );
  DFFRX1 rxfifo_reg66 ( .D(n376), .CK(clk), .RN(rstb), .Q(\rxfifo[8][3] ), 
        .QN(n1457) );
  DFFRX1 rxfifo_reg67 ( .D(n377), .CK(clk), .RN(rstb), .Q(\rxfifo[8][4] ), 
        .QN(n1460) );
  DFFRX1 rxfifo_reg68 ( .D(n378), .CK(clk), .RN(rstb), .Q(\rxfifo[8][5] ), 
        .QN(n1463) );
  DFFRX1 rxfifo_reg69 ( .D(n379), .CK(clk), .RN(rstb), .Q(\rxfifo[8][6] ), 
        .QN(n1469) );
  DFFRX1 rxfifo_reg70 ( .D(n380), .CK(clk), .RN(rstb), .Q(\rxfifo[8][7] ), 
        .QN(n1441) );
  DFFRX1 rxfifo_reg71 ( .D(n381), .CK(clk), .RN(rstb), .Q(\rxfifo[9][0] ), 
        .QN(n1584) );
  DFFRX1 rxfifo_reg72 ( .D(n382), .CK(clk), .RN(rstb), .Q(\rxfifo[9][1] ), 
        .QN(n1592) );
  DFFRX1 rxfifo_reg73 ( .D(n383), .CK(clk), .RN(rstb), .Q(\rxfifo[9][2] ), 
        .QN(n1598) );
  DFFRX1 rxfifo_reg74 ( .D(n384), .CK(clk), .RN(rstb), .Q(\rxfifo[9][3] ), 
        .QN(n1604) );
  DFFRX1 rxfifo_reg75 ( .D(n385), .CK(clk), .RN(rstb), .Q(\rxfifo[9][4] ), 
        .QN(n1607) );
  DFFRX1 rxfifo_reg76 ( .D(n386), .CK(clk), .RN(rstb), .Q(\rxfifo[9][5] ), 
        .QN(n1610) );
  DFFRX1 rxfifo_reg77 ( .D(n387), .CK(clk), .RN(rstb), .Q(\rxfifo[9][6] ), 
        .QN(n1616) );
  DFFRX1 rxfifo_reg78 ( .D(n388), .CK(clk), .RN(rstb), .Q(\rxfifo[9][7] ), 
        .QN(n1588) );
  DFFRX1 rxfifo_reg79 ( .D(n389), .CK(clk), .RN(rstb), .Q(\rxfifo[10][0] ), 
        .QN(n1547) );
  DFFRX1 rxfifo_reg80 ( .D(n390), .CK(clk), .RN(rstb), .Q(\rxfifo[10][1] ), 
        .QN(n1492) );
  DFFRX1 rxfifo_reg81 ( .D(n391), .CK(clk), .RN(rstb), .Q(\rxfifo[10][2] ), 
        .QN(n1495) );
  DFFRX1 rxfifo_reg82 ( .D(n392), .CK(clk), .RN(rstb), .Q(\rxfifo[10][3] ), 
        .QN(n1498) );
  DFFRX1 rxfifo_reg83 ( .D(n393), .CK(clk), .RN(rstb), .Q(\rxfifo[10][4] ), 
        .QN(n1501) );
  DFFRX1 rxfifo_reg84 ( .D(n394), .CK(clk), .RN(rstb), .Q(\rxfifo[10][5] ), 
        .QN(n1504) );
  DFFRX1 rxfifo_reg85 ( .D(n395), .CK(clk), .RN(rstb), .Q(\rxfifo[10][6] ), 
        .QN(n1507) );
  DFFRX1 rxfifo_reg86 ( .D(n396), .CK(clk), .RN(rstb), .Q(\rxfifo[10][7] ), 
        .QN(n1551) );
  DFFRX1 rxfifo_reg87 ( .D(n397), .CK(clk), .RN(rstb), .Q(\rxfifo[11][0] ), 
        .QN(n1400) );
  DFFRX1 rxfifo_reg88 ( .D(n398), .CK(clk), .RN(rstb), .Q(\rxfifo[11][1] ), 
        .QN(n1345) );
  DFFRX1 rxfifo_reg89 ( .D(n399), .CK(clk), .RN(rstb), .Q(\rxfifo[11][2] ), 
        .QN(n1348) );
  DFFRX1 rxfifo_reg90 ( .D(n400), .CK(clk), .RN(rstb), .Q(\rxfifo[11][3] ), 
        .QN(n1351) );
  DFFRX1 rxfifo_reg91 ( .D(n401), .CK(clk), .RN(rstb), .Q(\rxfifo[11][4] ), 
        .QN(n1354) );
  DFFRX1 rxfifo_reg92 ( .D(n402), .CK(clk), .RN(rstb), .Q(\rxfifo[11][5] ), 
        .QN(n1357) );
  DFFRX1 rxfifo_reg93 ( .D(n403), .CK(clk), .RN(rstb), .Q(\rxfifo[11][6] ), 
        .QN(n1360) );
  DFFRX1 rxfifo_reg94 ( .D(n404), .CK(clk), .RN(rstb), .Q(\rxfifo[11][7] ), 
        .QN(n1404) );
  DFFRX1 rxfifo_reg95 ( .D(n405), .CK(clk), .RN(rstb), .Q(\rxfifo[12][0] ), 
        .QN(n1407) );
  DFFRX1 rxfifo_reg96 ( .D(n406), .CK(clk), .RN(rstb), .Q(\rxfifo[12][1] ), 
        .QN(n1409) );
  DFFRX1 rxfifo_reg97 ( .D(n407), .CK(clk), .RN(rstb), .Q(\rxfifo[12][2] ), 
        .QN(n1411) );
  DFFRX1 rxfifo_reg98 ( .D(n408), .CK(clk), .RN(rstb), .Q(\rxfifo[12][3] ), 
        .QN(n1413) );
  DFFRX1 rxfifo_reg99 ( .D(n409), .CK(clk), .RN(rstb), .Q(\rxfifo[12][4] ), 
        .QN(n1415) );
  DFFRX1 rxfifo_reg100 ( .D(n410), .CK(clk), .RN(rstb), .Q(\rxfifo[12][5] ), 
        .QN(n1417) );
  DFFRX1 rxfifo_reg101 ( .D(n411), .CK(clk), .RN(rstb), .Q(\rxfifo[12][6] ), 
        .QN(n1419) );
  DFFRX1 rxfifo_reg102 ( .D(n412), .CK(clk), .RN(rstb), .Q(\rxfifo[12][7] ), 
        .QN(n1421) );
  DFFRX1 rxfifo_reg103 ( .D(n413), .CK(clk), .RN(rstb), .Q(\rxfifo[13][0] ), 
        .QN(n1554) );
  DFFRX1 rxfifo_reg104 ( .D(n414), .CK(clk), .RN(rstb), .Q(\rxfifo[13][1] ), 
        .QN(n1556) );
  DFFRX1 rxfifo_reg105 ( .D(n415), .CK(clk), .RN(rstb), .Q(\rxfifo[13][2] ), 
        .QN(n1558) );
  DFFRX1 rxfifo_reg106 ( .D(n416), .CK(clk), .RN(rstb), .Q(\rxfifo[13][3] ), 
        .QN(n1560) );
  DFFRX1 rxfifo_reg107 ( .D(n417), .CK(clk), .RN(rstb), .Q(\rxfifo[13][4] ), 
        .QN(n1562) );
  DFFRX1 rxfifo_reg108 ( .D(n418), .CK(clk), .RN(rstb), .Q(\rxfifo[13][5] ), 
        .QN(n1564) );
  DFFRX1 rxfifo_reg109 ( .D(n419), .CK(clk), .RN(rstb), .Q(\rxfifo[13][6] ), 
        .QN(n1566) );
  DFFRX1 rxfifo_reg110 ( .D(n420), .CK(clk), .RN(rstb), .Q(\rxfifo[13][7] ), 
        .QN(n1568) );
  DFFRX1 rxfifo_reg111 ( .D(n421), .CK(clk), .RN(rstb), .Q(\rxfifo[14][0] ), 
        .QN(n1517) );
  DFFRX1 rxfifo_reg112 ( .D(n422), .CK(clk), .RN(rstb), .Q(\rxfifo[14][1] ), 
        .QN(n1519) );
  DFFRX1 rxfifo_reg113 ( .D(n423), .CK(clk), .RN(rstb), .Q(\rxfifo[14][2] ), 
        .QN(n1521) );
  DFFRX1 rxfifo_reg114 ( .D(n424), .CK(clk), .RN(rstb), .Q(\rxfifo[14][3] ), 
        .QN(n1523) );
  DFFRX1 rxfifo_reg115 ( .D(n425), .CK(clk), .RN(rstb), .Q(\rxfifo[14][4] ), 
        .QN(n1525) );
  DFFRX1 rxfifo_reg116 ( .D(n426), .CK(clk), .RN(rstb), .Q(\rxfifo[14][5] ), 
        .QN(n1527) );
  DFFRX1 rxfifo_reg117 ( .D(n427), .CK(clk), .RN(rstb), .Q(\rxfifo[14][6] ), 
        .QN(n1529) );
  DFFRX1 rxfifo_reg118 ( .D(n428), .CK(clk), .RN(rstb), .Q(\rxfifo[14][7] ), 
        .QN(n1531) );
  DFFRX1 rxfifo_reg119 ( .D(n429), .CK(clk), .RN(rstb), .Q(\rxfifo[15][0] ), 
        .QN(n1370) );
  DFFRX1 rxfifo_reg120 ( .D(n430), .CK(clk), .RN(rstb), .Q(\rxfifo[15][1] ), 
        .QN(n1372) );
  DFFRX1 rxfifo_reg121 ( .D(n431), .CK(clk), .RN(rstb), .Q(\rxfifo[15][2] ), 
        .QN(n1374) );
  DFFRX1 rxfifo_reg122 ( .D(n432), .CK(clk), .RN(rstb), .Q(\rxfifo[15][3] ), 
        .QN(n1376) );
  DFFRX1 rxfifo_reg123 ( .D(n433), .CK(clk), .RN(rstb), .Q(\rxfifo[15][4] ), 
        .QN(n1378) );
  DFFRX1 rxfifo_reg124 ( .D(n434), .CK(clk), .RN(rstb), .Q(\rxfifo[15][5] ), 
        .QN(n1380) );
  DFFRX1 rxfifo_reg125 ( .D(n435), .CK(clk), .RN(rstb), .Q(\rxfifo[15][6] ), 
        .QN(n1382) );
  DFFRX1 rxfifo_reg126 ( .D(n436), .CK(clk), .RN(rstb), .Q(\rxfifo[15][7] ), 
        .QN(n1384) );
  DFFRX1 rxfifo_reg127 ( .D(n437), .CK(clk), .RN(rstb), .Q(\rxfifo[16][0] ), 
        .QN(n1431) );
  DFFRX1 rxfifo_reg128 ( .D(n438), .CK(clk), .RN(rstb), .Q(\rxfifo[16][1] ), 
        .QN(n1447) );
  DFFRX1 rxfifo_reg129 ( .D(n439), .CK(clk), .RN(rstb), .Q(\rxfifo[16][2] ), 
        .QN(n1453) );
  DFFRX1 rxfifo_reg130 ( .D(n440), .CK(clk), .RN(rstb), .Q(\rxfifo[16][3] ), 
        .QN(n1432) );
  DFFRX1 rxfifo_reg131 ( .D(n441), .CK(clk), .RN(rstb), .Q(\rxfifo[16][4] ), 
        .QN(n1433) );
  DFFRX1 rxfifo_reg132 ( .D(n442), .CK(clk), .RN(rstb), .Q(\rxfifo[16][5] ), 
        .QN(n1465) );
  DFFRX1 rxfifo_reg133 ( .D(n4430), .CK(clk), .RN(rstb), .Q(\rxfifo[16][6] ), 
        .QN(n1434) );
  DFFRX1 rxfifo_reg134 ( .D(n444), .CK(clk), .RN(rstb), .Q(\rxfifo[16][7] ), 
        .QN(n1436) );
  DFFRX1 rxfifo_reg135 ( .D(n445), .CK(clk), .RN(rstb), .Q(\rxfifo[17][0] ), 
        .QN(n1578) );
  DFFRX1 rxfifo_reg136 ( .D(n446), .CK(clk), .RN(rstb), .Q(\rxfifo[17][1] ), 
        .QN(n1594) );
  DFFRX1 rxfifo_reg137 ( .D(n447), .CK(clk), .RN(rstb), .Q(\rxfifo[17][2] ), 
        .QN(n1600) );
  DFFRX1 rxfifo_reg138 ( .D(n448), .CK(clk), .RN(rstb), .Q(\rxfifo[17][3] ), 
        .QN(n1579) );
  DFFRX1 rxfifo_reg139 ( .D(n449), .CK(clk), .RN(rstb), .Q(\rxfifo[17][4] ), 
        .QN(n1580) );
  DFFRX1 rxfifo_reg140 ( .D(n450), .CK(clk), .RN(rstb), .Q(\rxfifo[17][5] ), 
        .QN(n1612) );
  DFFRX1 rxfifo_reg141 ( .D(n451), .CK(clk), .RN(rstb), .Q(\rxfifo[17][6] ), 
        .QN(n1581) );
  DFFRX1 rxfifo_reg142 ( .D(n452), .CK(clk), .RN(rstb), .Q(\rxfifo[17][7] ), 
        .QN(n1583) );
  DFFRX1 rxfifo_reg143 ( .D(n453), .CK(clk), .RN(rstb), .Q(\rxfifo[18][0] ), 
        .QN(n1541) );
  DFFRX1 rxfifo_reg144 ( .D(n454), .CK(clk), .RN(rstb), .Q(\rxfifo[18][1] ), 
        .QN(n1509) );
  DFFRX1 rxfifo_reg145 ( .D(n455), .CK(clk), .RN(rstb), .Q(\rxfifo[18][2] ), 
        .QN(n1512) );
  DFFRX1 rxfifo_reg146 ( .D(n456), .CK(clk), .RN(rstb), .Q(\rxfifo[18][3] ), 
        .QN(n1542) );
  DFFRX1 rxfifo_reg147 ( .D(n457), .CK(clk), .RN(rstb), .Q(\rxfifo[18][4] ), 
        .QN(n1543) );
  DFFRX1 rxfifo_reg148 ( .D(n458), .CK(clk), .RN(rstb), .Q(\rxfifo[18][5] ), 
        .QN(n1515) );
  DFFRX1 rxfifo_reg149 ( .D(n459), .CK(clk), .RN(rstb), .Q(\rxfifo[18][6] ), 
        .QN(n1544) );
  DFFRX1 rxfifo_reg150 ( .D(n460), .CK(clk), .RN(rstb), .Q(\rxfifo[18][7] ), 
        .QN(n1546) );
  DFFRX1 rxfifo_reg151 ( .D(n461), .CK(clk), .RN(rstb), .Q(\rxfifo[19][0] ), 
        .QN(n1394) );
  DFFRX1 rxfifo_reg152 ( .D(n462), .CK(clk), .RN(rstb), .Q(\rxfifo[19][1] ), 
        .QN(n1362) );
  DFFRX1 rxfifo_reg153 ( .D(n463), .CK(clk), .RN(rstb), .Q(\rxfifo[19][2] ), 
        .QN(n1365) );
  DFFRX1 rxfifo_reg154 ( .D(n464), .CK(clk), .RN(rstb), .Q(\rxfifo[19][3] ), 
        .QN(n1395) );
  DFFRX1 rxfifo_reg155 ( .D(n465), .CK(clk), .RN(rstb), .Q(\rxfifo[19][4] ), 
        .QN(n1396) );
  DFFRX1 rxfifo_reg156 ( .D(n466), .CK(clk), .RN(rstb), .Q(\rxfifo[19][5] ), 
        .QN(n1368) );
  DFFRX1 rxfifo_reg157 ( .D(n467), .CK(clk), .RN(rstb), .Q(\rxfifo[19][6] ), 
        .QN(n1397) );
  DFFRX1 rxfifo_reg158 ( .D(n468), .CK(clk), .RN(rstb), .Q(\rxfifo[19][7] ), 
        .QN(n1399) );
  DFFRX1 rxfifo_reg159 ( .D(n469), .CK(clk), .RN(rstb), .Q(\rxfifo[20][0] ), 
        .QN(n1424) );
  DFFRX1 rxfifo_reg160 ( .D(n470), .CK(clk), .RN(rstb), .Q(\rxfifo[20][1] ), 
        .QN(n1446) );
  DFFRX1 rxfifo_reg161 ( .D(n471), .CK(clk), .RN(rstb), .Q(\rxfifo[20][2] ), 
        .QN(n1452) );
  DFFRX1 rxfifo_reg162 ( .D(n472), .CK(clk), .RN(rstb), .Q(\rxfifo[20][3] ), 
        .QN(n1425) );
  DFFRX1 rxfifo_reg163 ( .D(n473), .CK(clk), .RN(rstb), .Q(\rxfifo[20][4] ), 
        .QN(n1426) );
  DFFRX1 rxfifo_reg164 ( .D(n474), .CK(clk), .RN(rstb), .Q(\rxfifo[20][5] ), 
        .QN(n1464) );
  DFFRX1 rxfifo_reg165 ( .D(n475), .CK(clk), .RN(rstb), .Q(\rxfifo[20][6] ), 
        .QN(n1427) );
  DFFRX1 rxfifo_reg166 ( .D(n476), .CK(clk), .RN(rstb), .Q(\rxfifo[20][7] ), 
        .QN(n1429) );
  DFFRX1 rxfifo_reg167 ( .D(n477), .CK(clk), .RN(rstb), .Q(\rxfifo[21][0] ), 
        .QN(n1571) );
  DFFRX1 rxfifo_reg168 ( .D(n478), .CK(clk), .RN(rstb), .Q(\rxfifo[21][1] ), 
        .QN(n1593) );
  DFFRX1 rxfifo_reg169 ( .D(n479), .CK(clk), .RN(rstb), .Q(\rxfifo[21][2] ), 
        .QN(n1599) );
  DFFRX1 rxfifo_reg170 ( .D(n480), .CK(clk), .RN(rstb), .Q(\rxfifo[21][3] ), 
        .QN(n1572) );
  DFFRX1 rxfifo_reg171 ( .D(n481), .CK(clk), .RN(rstb), .Q(\rxfifo[21][4] ), 
        .QN(n1573) );
  DFFRX1 rxfifo_reg172 ( .D(n482), .CK(clk), .RN(rstb), .Q(\rxfifo[21][5] ), 
        .QN(n1611) );
  DFFRX1 rxfifo_reg173 ( .D(n483), .CK(clk), .RN(rstb), .Q(\rxfifo[21][6] ), 
        .QN(n1574) );
  DFFRX1 rxfifo_reg174 ( .D(n484), .CK(clk), .RN(rstb), .Q(\rxfifo[21][7] ), 
        .QN(n1576) );
  DFFRX1 rxfifo_reg175 ( .D(n485), .CK(clk), .RN(rstb), .Q(\rxfifo[22][0] ), 
        .QN(n1534) );
  DFFRX1 rxfifo_reg176 ( .D(n486), .CK(clk), .RN(rstb), .Q(\rxfifo[22][1] ), 
        .QN(n1508) );
  DFFRX1 rxfifo_reg177 ( .D(n487), .CK(clk), .RN(rstb), .Q(\rxfifo[22][2] ), 
        .QN(n1511) );
  DFFRX1 rxfifo_reg178 ( .D(n488), .CK(clk), .RN(rstb), .Q(\rxfifo[22][3] ), 
        .QN(n1535) );
  DFFRX1 rxfifo_reg179 ( .D(n489), .CK(clk), .RN(rstb), .Q(\rxfifo[22][4] ), 
        .QN(n1536) );
  DFFRX1 rxfifo_reg180 ( .D(n490), .CK(clk), .RN(rstb), .Q(\rxfifo[22][5] ), 
        .QN(n1514) );
  DFFRX1 rxfifo_reg181 ( .D(n491), .CK(clk), .RN(rstb), .Q(\rxfifo[22][6] ), 
        .QN(n1537) );
  DFFRX1 rxfifo_reg182 ( .D(n492), .CK(clk), .RN(rstb), .Q(\rxfifo[22][7] ), 
        .QN(n1539) );
  DFFRX1 rxfifo_reg183 ( .D(n493), .CK(clk), .RN(rstb), .Q(\rxfifo[23][0] ), 
        .QN(n1387) );
  DFFRX1 rxfifo_reg184 ( .D(n494), .CK(clk), .RN(rstb), .Q(\rxfifo[23][1] ), 
        .QN(n1361) );
  DFFRX1 rxfifo_reg185 ( .D(n495), .CK(clk), .RN(rstb), .Q(\rxfifo[23][2] ), 
        .QN(n1364) );
  DFFRX1 rxfifo_reg186 ( .D(n496), .CK(clk), .RN(rstb), .Q(\rxfifo[23][3] ), 
        .QN(n1388) );
  DFFRX1 rxfifo_reg187 ( .D(n497), .CK(clk), .RN(rstb), .Q(\rxfifo[23][4] ), 
        .QN(n1389) );
  DFFRX1 rxfifo_reg188 ( .D(n498), .CK(clk), .RN(rstb), .Q(\rxfifo[23][5] ), 
        .QN(n1367) );
  DFFRX1 rxfifo_reg189 ( .D(n499), .CK(clk), .RN(rstb), .Q(\rxfifo[23][6] ), 
        .QN(n1390) );
  DFFRX1 rxfifo_reg190 ( .D(n500), .CK(clk), .RN(rstb), .Q(\rxfifo[23][7] ), 
        .QN(n1392) );
  DFFRX1 rxfifo_reg191 ( .D(n501), .CK(clk), .RN(rstb), .Q(\rxfifo[24][0] ), 
        .QN(n1442) );
  DFFRX1 rxfifo_reg192 ( .D(n502), .CK(clk), .RN(rstb), .Q(\rxfifo[24][1] ), 
        .QN(n1448) );
  DFFRX1 rxfifo_reg193 ( .D(n503), .CK(clk), .RN(rstb), .Q(\rxfifo[24][2] ), 
        .QN(n1454) );
  DFFRX1 rxfifo_reg194 ( .D(n504), .CK(clk), .RN(rstb), .Q(\rxfifo[24][3] ), 
        .QN(n1438) );
  DFFRX1 rxfifo_reg195 ( .D(n505), .CK(clk), .RN(rstb), .Q(\rxfifo[24][4] ), 
        .QN(n1439) );
  DFFRX1 rxfifo_reg196 ( .D(n506), .CK(clk), .RN(rstb), .Q(\rxfifo[24][5] ), 
        .QN(n1466) );
  DFFRX1 rxfifo_reg197 ( .D(n507), .CK(clk), .RN(rstb), .Q(\rxfifo[24][6] ), 
        .QN(n1440) );
  DFFRX1 rxfifo_reg198 ( .D(n508), .CK(clk), .RN(rstb), .Q(\rxfifo[24][7] ), 
        .QN(n1470) );
  DFFRX1 rxfifo_reg199 ( .D(n509), .CK(clk), .RN(rstb), .Q(\rxfifo[25][0] ), 
        .QN(n1589) );
  DFFRX1 rxfifo_reg200 ( .D(n510), .CK(clk), .RN(rstb), .Q(\rxfifo[25][1] ), 
        .QN(n1595) );
  DFFRX1 rxfifo_reg201 ( .D(n5110), .CK(clk), .RN(rstb), .Q(\rxfifo[25][2] ), 
        .QN(n1601) );
  DFFRX1 rxfifo_reg202 ( .D(n5120), .CK(clk), .RN(rstb), .Q(\rxfifo[25][3] ), 
        .QN(n1585) );
  DFFRX1 rxfifo_reg203 ( .D(n5130), .CK(clk), .RN(rstb), .Q(\rxfifo[25][4] ), 
        .QN(n1586) );
  DFFRX1 rxfifo_reg204 ( .D(n5140), .CK(clk), .RN(rstb), .Q(\rxfifo[25][5] ), 
        .QN(n1613) );
  DFFRX1 rxfifo_reg205 ( .D(n5150), .CK(clk), .RN(rstb), .Q(\rxfifo[25][6] ), 
        .QN(n1587) );
  DFFRX1 rxfifo_reg206 ( .D(n5160), .CK(clk), .RN(rstb), .Q(\rxfifo[25][7] ), 
        .QN(n1617) );
  DFFRX1 rxfifo_reg207 ( .D(n5170), .CK(clk), .RN(rstb), .Q(\rxfifo[26][0] ), 
        .QN(n1552) );
  DFFRX1 rxfifo_reg208 ( .D(n5180), .CK(clk), .RN(rstb), .Q(\rxfifo[26][1] ), 
        .QN(n1510) );
  DFFRX1 rxfifo_reg209 ( .D(n5190), .CK(clk), .RN(rstb), .Q(\rxfifo[26][2] ), 
        .QN(n1513) );
  DFFRX1 rxfifo_reg210 ( .D(n5200), .CK(clk), .RN(rstb), .Q(\rxfifo[26][3] ), 
        .QN(n1548) );
  DFFRX1 rxfifo_reg211 ( .D(n5210), .CK(clk), .RN(rstb), .Q(\rxfifo[26][4] ), 
        .QN(n1549) );
  DFFRX1 rxfifo_reg212 ( .D(n5220), .CK(clk), .RN(rstb), .Q(\rxfifo[26][5] ), 
        .QN(n1516) );
  DFFRX1 rxfifo_reg213 ( .D(n5230), .CK(clk), .RN(rstb), .Q(\rxfifo[26][6] ), 
        .QN(n1550) );
  DFFRX1 rxfifo_reg214 ( .D(n5240), .CK(clk), .RN(rstb), .Q(\rxfifo[26][7] ), 
        .QN(n1553) );
  DFFRX1 rxfifo_reg215 ( .D(n5250), .CK(clk), .RN(rstb), .Q(\rxfifo[27][0] ), 
        .QN(n1405) );
  DFFRX1 rxfifo_reg216 ( .D(n5260), .CK(clk), .RN(rstb), .Q(\rxfifo[27][1] ), 
        .QN(n1363) );
  DFFRX1 rxfifo_reg217 ( .D(n5270), .CK(clk), .RN(rstb), .Q(\rxfifo[27][2] ), 
        .QN(n1366) );
  DFFRX1 rxfifo_reg218 ( .D(n5280), .CK(clk), .RN(rstb), .Q(\rxfifo[27][3] ), 
        .QN(n1401) );
  DFFRX1 rxfifo_reg219 ( .D(n529), .CK(clk), .RN(rstb), .Q(\rxfifo[27][4] ), 
        .QN(n1402) );
  DFFRX1 rxfifo_reg220 ( .D(n530), .CK(clk), .RN(rstb), .Q(\rxfifo[27][5] ), 
        .QN(n1369) );
  DFFRX1 rxfifo_reg221 ( .D(n531), .CK(clk), .RN(rstb), .Q(\rxfifo[27][6] ), 
        .QN(n1403) );
  DFFRX1 rxfifo_reg222 ( .D(n532), .CK(clk), .RN(rstb), .Q(\rxfifo[27][7] ), 
        .QN(n1406) );
  DFFRX1 rxfifo_reg223 ( .D(n533), .CK(clk), .RN(rstb), .Q(\rxfifo[28][0] ), 
        .QN(n1408) );
  DFFRX1 rxfifo_reg224 ( .D(n534), .CK(clk), .RN(rstb), .Q(\rxfifo[28][1] ), 
        .QN(n1410) );
  DFFRX1 rxfifo_reg225 ( .D(n535), .CK(clk), .RN(rstb), .Q(\rxfifo[28][2] ), 
        .QN(n1412) );
  DFFRX1 rxfifo_reg226 ( .D(n536), .CK(clk), .RN(rstb), .Q(\rxfifo[28][3] ), 
        .QN(n1414) );
  DFFRX1 rxfifo_reg227 ( .D(n537), .CK(clk), .RN(rstb), .Q(\rxfifo[28][4] ), 
        .QN(n1416) );
  DFFRX1 rxfifo_reg228 ( .D(n538), .CK(clk), .RN(rstb), .Q(\rxfifo[28][5] ), 
        .QN(n1418) );
  DFFRX1 rxfifo_reg229 ( .D(n539), .CK(clk), .RN(rstb), .Q(\rxfifo[28][6] ), 
        .QN(n1420) );
  DFFRX1 rxfifo_reg230 ( .D(n540), .CK(clk), .RN(rstb), .Q(\rxfifo[28][7] ), 
        .QN(n1422) );
  DFFRX1 rxfifo_reg231 ( .D(n541), .CK(clk), .RN(rstb), .Q(\rxfifo[29][0] ), 
        .QN(n1555) );
  DFFRX1 rxfifo_reg232 ( .D(n542), .CK(clk), .RN(rstb), .Q(\rxfifo[29][1] ), 
        .QN(n1557) );
  DFFRX1 rxfifo_reg233 ( .D(n543), .CK(clk), .RN(rstb), .Q(\rxfifo[29][2] ), 
        .QN(n1559) );
  DFFRX1 rxfifo_reg234 ( .D(n544), .CK(clk), .RN(rstb), .Q(\rxfifo[29][3] ), 
        .QN(n1561) );
  DFFRX1 rxfifo_reg235 ( .D(n545), .CK(clk), .RN(rstb), .Q(\rxfifo[29][4] ), 
        .QN(n1563) );
  DFFRX1 rxfifo_reg236 ( .D(n546), .CK(clk), .RN(rstb), .Q(\rxfifo[29][5] ), 
        .QN(n1565) );
  DFFRX1 rxfifo_reg237 ( .D(n547), .CK(clk), .RN(rstb), .Q(\rxfifo[29][6] ), 
        .QN(n1567) );
  DFFRX1 rxfifo_reg238 ( .D(n548), .CK(clk), .RN(rstb), .Q(\rxfifo[29][7] ), 
        .QN(n1569) );
  DFFRX1 rxfifo_reg239 ( .D(n549), .CK(clk), .RN(rstb), .Q(\rxfifo[30][0] ), 
        .QN(n1518) );
  DFFRX1 rxfifo_reg240 ( .D(n550), .CK(clk), .RN(rstb), .Q(\rxfifo[30][1] ), 
        .QN(n1520) );
  DFFRX1 rxfifo_reg241 ( .D(n551), .CK(clk), .RN(rstb), .Q(\rxfifo[30][2] ), 
        .QN(n1522) );
  DFFRX1 rxfifo_reg242 ( .D(n552), .CK(clk), .RN(rstb), .Q(\rxfifo[30][3] ), 
        .QN(n1524) );
  DFFRX1 rxfifo_reg243 ( .D(n553), .CK(clk), .RN(rstb), .Q(\rxfifo[30][4] ), 
        .QN(n1526) );
  DFFRX1 rxfifo_reg244 ( .D(n554), .CK(clk), .RN(rstb), .Q(\rxfifo[30][5] ), 
        .QN(n1528) );
  DFFRX1 rxfifo_reg245 ( .D(n555), .CK(clk), .RN(rstb), .Q(\rxfifo[30][6] ), 
        .QN(n1530) );
  DFFRX1 rxfifo_reg246 ( .D(n556), .CK(clk), .RN(rstb), .Q(\rxfifo[30][7] ), 
        .QN(n1532) );
  DFFRX1 rxfifo_reg247 ( .D(n557), .CK(clk), .RN(rstb), .Q(\rxfifo[31][0] ), 
        .QN(n1371) );
  DFFRX1 rxfifo_reg248 ( .D(n558), .CK(clk), .RN(rstb), .Q(\rxfifo[31][1] ), 
        .QN(n1373) );
  DFFRX1 rxfifo_reg249 ( .D(n559), .CK(clk), .RN(rstb), .Q(\rxfifo[31][2] ), 
        .QN(n1375) );
  DFFRX1 rxfifo_reg250 ( .D(n560), .CK(clk), .RN(rstb), .Q(\rxfifo[31][3] ), 
        .QN(n1377) );
  DFFRX1 rxfifo_reg251 ( .D(n561), .CK(clk), .RN(rstb), .Q(\rxfifo[31][4] ), 
        .QN(n1379) );
  DFFRX1 rxfifo_reg252 ( .D(n562), .CK(clk), .RN(rstb), .Q(\rxfifo[31][5] ), 
        .QN(n1381) );
  DFFRX1 rxfifo_reg253 ( .D(n563), .CK(clk), .RN(rstb), .Q(\rxfifo[31][6] ), 
        .QN(n1383) );
  DFFRX1 rxfifo_reg254 ( .D(n564), .CK(clk), .RN(rstb), .Q(\rxfifo[31][7] ), 
        .QN(n1385) );
  DFFSX1 rstparityb_reg ( .D(n285), .CK(clk), .SN(rstb), .QN(n1339) );
  DFFRX1 rxsftreg_reg_1_ ( .D(n295), .CK(clk), .RN(rstb), .Q(rxsftreg[1]) );
  DFFRX1 rxsftreg_reg_2_ ( .D(n296), .CK(clk), .RN(rstb), .Q(rxsftreg[2]) );
  DFFRX1 rxsftreg_reg_3_ ( .D(n297), .CK(clk), .RN(rstb), .Q(rxsftreg[3]) );
  DFFRX1 rxsftreg_reg_4_ ( .D(n298), .CK(clk), .RN(rstb), .Q(rxsftreg[4]) );
  DFFRX1 rxsftreg_reg_5_ ( .D(n299), .CK(clk), .RN(rstb), .Q(rxsftreg[5]) );
  DFFRX1 rxsftreg_reg_6_ ( .D(n300), .CK(clk), .RN(rstb), .Q(rxsftreg[6]) );
  DFFRX1 rxsftreg_reg_7_ ( .D(n301), .CK(clk), .RN(rstb), .Q(rxsftreg[7]), 
        .QN(n1629) );
  DFFRX1 overrunerror_int_reg ( .D(n576), .CK(clk), .RN(rstb), .Q(overrunerror), .QN(n277) );
  DFFRX1 rxsftreg_reg_0_ ( .D(n294), .CK(clk), .RN(rstb), .Q(rxsftreg[0]) );
  DFFSX1 in_dly_reg_5_ ( .D(n308), .CK(clk), .SN(rstb), .Q(in_dly[5]) );
  DFFRX1 rxbusy_int_reg ( .D(n284), .CK(clk), .RN(rstb), .Q(rxbusy) );
endmodule


module RegBlk_3_5_1 ( PADDR, PENABLE, PSEL, PWDATA, PWRITE, bytereceivedb, clk, 
        fifodata_rx, frameerror, overrunerror, parityerror, rstb, rxbusy, 
        rxfifocnt, rxfifoempty, txbusy, txfifo_emptyb, txfifo_fillb, 
        txfifo_fullb, txfifocnt, PRDATA, baudx16clk, databit, fifodata_tx, 
        fifordb, fifowrb, int, loopbacken, parity, rxdmareq, stopbit, swrst, 
        txdmareq, uarten, frameerr_clear, parityerr_clear, overrunerr_clear );
  input [4:2] PADDR;
  input [31:0] PWDATA;
  input [7:0] fifodata_rx;
  input [5:0] rxfifocnt;
  input [5:0] txfifocnt;
  output [31:0] PRDATA;
  output [7:0] fifodata_tx;
  output [1:0] parity;
  input PENABLE, PSEL, PWRITE, bytereceivedb, clk, frameerror, overrunerror,
         parityerror, rstb, rxbusy, rxfifoempty, txbusy, txfifo_emptyb,
         txfifo_fillb, txfifo_fullb;
  output baudx16clk, databit, fifordb, fifowrb, int, loopbacken, rxdmareq,
         stopbit, swrst, txdmareq, uarten, frameerr_clear, parityerr_clear,
         overrunerr_clear;
  wire   n252, n253, n254, n255, n256, n257, n258, n259, reg_0x0000_30_,
         reg_0x0000_29_, reg_0x0000_27_, reg_0x0000_15_, reg_0x0000_7_,
         reg_0x0004_22_, reg_0x0004_7_, N49, N51, N52, N60, N61, N62,
         clkdivcnt_msb_dly, N90, N91, N92, N93, N94, N95, N96, N97, N98, N99,
         N100, N101, N102, N103, N104, N108, N112, N113, N114, N115, N116,
         N117, N118, N119, N120, N121, N122, N123, N124, N125, N126, N127,
         N128, N129, n10, n134, n135, n136, n137, n138, n139, n140, n141, n142,
         n143, n144, n145, n146, n147, n148, n149, n150, n151, n152, n153,
         n154, n155, n156, n157, n158, n159, n160, n161, n162, n163, n164,
         n165, n166, n167, n168, n169, n170, n171, n172, n173, n174, n175,
         n176, n177, n178, n179, n180, n181, n182, n183, n184, n185, n186,
         n187, n188, n189, n190, n191, n192, n193, n194, n195, n196, n197,
         n198, n199, n200, n201, n202, n203, n204, n205, n206, n207, n208,
         n209, n210, n211, n212, n213, n214, n215, n216, n217, n218, n219,
         n220, n221, n222, n223, n224, n225, n226, n227, n228, n229, n230,
         n231, n490, carry, carry0, carry1, carry2, carry3, carry4, carry5,
         carry6, carry7, carry8, carry9, carry10, carry11, carry12, carry_1_,
         n1101, n234, n311, n411, n510, n610, n710, n810, n910, n1011, n1111,
         n1211, n1311, n1411, carry_18_, carry_17_, carry_16_, carry_15_,
         carry_14_, carry_13_, carry_12_, carry_11_, carry_10_, carry_9_,
         carry_8_, carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_,
         n1100, n233, n310, n410, n5, n6, n7, n8, n9, n1010, n1110, n1210,
         n1310, n1410, n1510, n1610, n1710, n1810, n261, n262, n263, n265,
         n266, n267, n268, n271, n275, n276, n277, n278, n279, n280, n282,
         n283, n285, n286, n288, n290, n292, n293, n294, n295, n296, n297,
         n298, n299, n300, n303, n304, n305, n308, n309, n312, n315, n316,
         n317, n318, n319, n320, n321, n324, n325, n326, n329, n330, n331,
         n334, n335, n336, n338, n339, n340, n341, n345, n346, n351, n352,
         n353, n354, n356, n358, n359, n361, n362, n364, n365, n367, n368,
         n370, n371, n374, n377, n379, n380, n383, n384, n387, n388, n392,
         n393, n396, n397, n398, n399, n400, n401, n402, n403, n404, n405,
         n406, n407, n408, n409, n412, n413, n414, n415, n416, n417, n418,
         n419, n420, n421, n422, n423, n426, n427, n429, n430, n431, n432,
         n433, n434, n435, n436, n437, n438, n439, n440, n441, n442, n443,
         n444, n445, n446, n447, n448, n449, n450, n451, n452, n453, n454,
         n455, n456, n457, n458, n459, n460, n461, n462, n463, n464, n465,
         n466, n467, n468, n469, n470, n471, n472, n473, n474, n475, n476,
         n477, n478, n479, n481, n482, n483, n484, n485, n486, n487, n488;
  wire   [5:0] txwaterlevel_int;
  wire   [5:0] rxwaterlevel_int;
  wire   [15:0] clkdiv;
  wire   [15:0] clkdivcnt;
  wire   [19:0] timeoutcnt;
  wire   [19:0] timeoutcnt_int;
  assign PRDATA[20] = 1'b0;
  assign PRDATA[21] = 1'b0;
  assign fifodata_tx[7] = n252;
  assign n252 = PWDATA[7];
  assign fifodata_tx[6] = n253;
  assign n253 = PWDATA[6];
  assign fifodata_tx[5] = n254;
  assign n254 = PWDATA[5];
  assign fifodata_tx[4] = n255;
  assign n255 = PWDATA[4];
  assign fifodata_tx[3] = n256;
  assign n256 = PWDATA[3];
  assign fifodata_tx[2] = n257;
  assign n257 = PWDATA[2];
  assign fifodata_tx[1] = n258;
  assign n258 = PWDATA[1];
  assign fifodata_tx[0] = n259;
  assign n259 = PWDATA[0];

  AHHCONX2 U1_1_1 ( .A(timeoutcnt_int[1]), .CI(timeoutcnt_int[0]), .S(N112), 
        .CON(n1810) );
  AHHCONX2 U1_1_2 ( .A(timeoutcnt_int[2]), .CI(carry_2_), .S(N113), .CON(n1710) );
  AHHCONX2 U1_1_3 ( .A(timeoutcnt_int[3]), .CI(carry_3_), .S(N114), .CON(n1610) );
  AHHCONX2 U1_1_4 ( .A(timeoutcnt_int[4]), .CI(carry_4_), .S(N115), .CON(n1510) );
  AHHCONX2 U1_1_5 ( .A(timeoutcnt_int[5]), .CI(carry_5_), .S(N116), .CON(n1410) );
  AHHCONX2 U1_1_6 ( .A(timeoutcnt_int[6]), .CI(carry_6_), .S(N117), .CON(n1310) );
  AHHCONX2 U1_1_7 ( .A(timeoutcnt_int[7]), .CI(carry_7_), .S(N118), .CON(n1210) );
  AHHCONX2 U1_1_8 ( .A(timeoutcnt_int[8]), .CI(carry_8_), .S(N119), .CON(n1110) );
  AHHCONX2 U1_1_9 ( .A(timeoutcnt_int[9]), .CI(carry_9_), .S(N120), .CON(n1010) );
  AHHCONX2 U1_1_10 ( .A(timeoutcnt_int[10]), .CI(carry_10_), .S(N121), .CON(n9) );
  AHHCONX2 U1_1_11 ( .A(timeoutcnt_int[11]), .CI(carry_11_), .S(N122), .CON(n8) );
  AHHCONX2 U1_1_12 ( .A(timeoutcnt_int[12]), .CI(carry_12_), .S(N123), .CON(n7) );
  AHHCONX2 U1_1_13 ( .A(timeoutcnt_int[13]), .CI(carry_13_), .S(N124), .CON(n6) );
  AHHCONX2 U1_1_14 ( .A(timeoutcnt_int[14]), .CI(carry_14_), .S(N125), .CON(n5) );
  AHHCONX2 U1_1_15 ( .A(timeoutcnt_int[15]), .CI(carry_15_), .S(N126), .CON(
        n410) );
  AHHCONX2 U1_1_16 ( .A(timeoutcnt_int[16]), .CI(carry_16_), .S(N127), .CON(
        n310) );
  AHHCONX2 U1_1_17 ( .A(timeoutcnt_int[17]), .CI(carry_17_), .S(N128), .CON(
        n233) );
  AHHCONX2 U1_1_18 ( .A(timeoutcnt_int[18]), .CI(carry_18_), .S(N129), .CON(
        n1100) );
  DFFRX1 databit_int_reg ( .D(n217), .CK(clk), .RN(rstb), .Q(databit) );
  DFFRX1 swrst_int_reg ( .D(N49), .CK(clk), .RN(rstb), .Q(swrst), .QN(n449) );
  INVX1 U618 ( .A(n275), .Y(n276) );
  INVX1 U619 ( .A(n486), .Y(n267) );
  INVX1 U620 ( .A(n286), .Y(n278) );
  INVX1 U621 ( .A(n280), .Y(n283) );
  INVX1 U622 ( .A(txfifocnt[1]), .Y(n340) );
  NAND2BX1 U623 ( .AN(n334), .B(n335), .Y(fifowrb) );
  NAND2BX1 U624 ( .AN(n483), .B(n476), .Y(n275) );
  NAND2BX1 U625 ( .AN(n483), .B(n476), .Y(n485) );
  NAND2BX1 U626 ( .AN(n483), .B(n476), .Y(n484) );
  INVX1 U627 ( .A(n262), .Y(n263) );
  BUFX2 U628 ( .A(n266), .Y(n486) );
  NAND2BX1 U629 ( .AN(n268), .B(n476), .Y(n266) );
  INVX1 U630 ( .A(n482), .Y(n265) );
  DFFRX1 baudx16clk_int_reg ( .D(n175), .CK(clk), .RN(rstb), .Q(baudx16clk), 
        .QN(n431) );
  DFFRX1 parity_int_reg_1_ ( .D(n219), .CK(clk), .RN(rstb), .Q(parity[1]) );
  NAND2BX1 U631 ( .AN(n285), .B(n431), .Y(n286) );
  NAND2BX1 U632 ( .AN(n285), .B(n286), .Y(n280) );
  INVX1 U633 ( .A(n403), .Y(n356) );
  OAI31X1 U634 ( .A0(n404), .A1(n405), .A2(n406), .B0(n407), .Y(n403) );
  INVX1 U635 ( .A(n408), .Y(n406) );
  AOI222X1 U636 ( .A0(n409), .A1(n412), .B0(rxfifocnt[3]), .B1(n454), .C0(
        rxfifocnt[2]), .C1(n438), .Y(n404) );
  INVX1 U637 ( .A(rxfifocnt[4]), .Y(n361) );
  INVX1 U638 ( .A(txfifocnt[4]), .Y(n383) );
  OA22X1 U639 ( .A0(rxfifocnt[1]), .A1(n456), .B0(rxfifocnt[2]), .B1(n438), 
        .Y(n409) );
  INVX1 U640 ( .A(txfifocnt[3]), .Y(n387) );
  AO22X1 U641 ( .A0(txfifocnt[3]), .A1(n441), .B0(txfifocnt[4]), .B1(n458), 
        .Y(n417) );
  INVX1 U642 ( .A(txfifocnt[2]), .Y(n392) );
  INVX1 U643 ( .A(rxfifocnt[3]), .Y(n364) );
  OAI211X1 U644 ( .A0(txfifocnt[1]), .A1(n440), .B0(txfifocnt[0]), .C0(n457), 
        .Y(n422) );
  INVX1 U645 ( .A(n268), .Y(n353) );
  INVX1 U646 ( .A(PRDATA[28]), .Y(n339) );
  INVX1 U647 ( .A(n261), .Y(txdmareq) );
  INVX1 U648 ( .A(n483), .Y(n352) );
  INVX1 U649 ( .A(n402), .Y(n335) );
  NAND3BX1 U650 ( .AN(PADDR[4]), .B(PADDR[2]), .C(n476), .Y(n402) );
  AND3X2 U651 ( .A(PENABLE), .B(PSEL), .C(PWRITE), .Y(n476) );
  NAND3BX1 U652 ( .AN(PADDR[4]), .B(n399), .C(PADDR[3]), .Y(n268) );
  NAND4BX1 U653 ( .AN(PWRITE), .B(PENABLE), .C(PSEL), .D(n336), .Y(fifordb) );
  NAND3BX1 U654 ( .AN(PWDATA[28]), .B(n476), .C(n265), .Y(n262) );
  NAND3BX1 U655 ( .AN(PWDATA[28]), .B(n476), .C(n265), .Y(n488) );
  NAND3BX1 U656 ( .AN(PWDATA[28]), .B(n476), .C(n265), .Y(n487) );
  INVX1 U657 ( .A(PADDR[2]), .Y(n399) );
  NAND2BX1 U658 ( .AN(PADDR[3]), .B(n335), .Y(n401) );
  INVX1 U659 ( .A(PADDR[3]), .Y(n334) );
  BUFX2 U660 ( .A(n338), .Y(n482) );
  NAND3BX1 U661 ( .AN(PADDR[4]), .B(n334), .C(n399), .Y(n338) );
  NOR3BX1 U662 ( .AN(n476), .B(n482), .C(n423), .Y(N49) );
  INVX1 U663 ( .A(PWDATA[28]), .Y(n423) );
  BUFX2 U664 ( .A(n277), .Y(n483) );
  NAND3BX1 U665 ( .AN(PADDR[3]), .B(PADDR[2]), .C(PADDR[4]), .Y(n277) );
  NOR2BX1 U666 ( .AN(PWDATA[24]), .B(n401), .Y(N60) );
  NOR2BX1 U667 ( .AN(PWDATA[25]), .B(n401), .Y(N61) );
  NOR2BX1 U668 ( .AN(PWDATA[23]), .B(n401), .Y(N62) );
  INVX1 U669 ( .A(n398), .Y(n336) );
  NAND3BX1 U670 ( .AN(PADDR[3]), .B(n399), .C(PADDR[4]), .Y(n398) );
  AO22X1 U671 ( .A0(timeoutcnt[16]), .A1(n484), .B0(PWDATA[16]), .B1(n276), 
        .Y(n171) );
  AO22X1 U672 ( .A0(timeoutcnt[17]), .A1(n484), .B0(PWDATA[17]), .B1(n276), 
        .Y(n172) );
  AO22X1 U673 ( .A0(timeoutcnt[18]), .A1(n485), .B0(PWDATA[18]), .B1(n276), 
        .Y(n173) );
  AO22X1 U674 ( .A0(timeoutcnt[19]), .A1(n484), .B0(PWDATA[19]), .B1(n276), 
        .Y(n174) );
  AO22X1 U675 ( .A0(clkdiv[6]), .A1(n486), .B0(n253), .B1(n267), .Y(n199) );
  AO22X1 U676 ( .A0(clkdiv[14]), .A1(n486), .B0(PWDATA[14]), .B1(n267), .Y(
        n207) );
  AO22X1 U677 ( .A0(txwaterlevel_int[0]), .A1(n488), .B0(PWDATA[8]), .B1(n263), 
        .Y(n209) );
  AO22X1 U678 ( .A0(txwaterlevel_int[1]), .A1(n487), .B0(PWDATA[9]), .B1(n263), 
        .Y(n210) );
  AO22X1 U679 ( .A0(txwaterlevel_int[2]), .A1(n262), .B0(PWDATA[10]), .B1(n263), .Y(n211) );
  AO22X1 U680 ( .A0(txwaterlevel_int[3]), .A1(n488), .B0(PWDATA[11]), .B1(n263), .Y(n212) );
  AO22X1 U681 ( .A0(txwaterlevel_int[4]), .A1(n487), .B0(PWDATA[12]), .B1(n263), .Y(n213) );
  AO22X1 U682 ( .A0(txwaterlevel_int[5]), .A1(n262), .B0(PWDATA[13]), .B1(n263), .Y(n214) );
  AO22X1 U683 ( .A0(loopbacken), .A1(n488), .B0(PWDATA[22]), .B1(n263), .Y(
        n215) );
  AO22X1 U684 ( .A0(stopbit), .A1(n487), .B0(PWDATA[23]), .B1(n263), .Y(n216)
         );
  AO22X1 U685 ( .A0(databit), .A1(n262), .B0(PWDATA[24]), .B1(n263), .Y(n217)
         );
  AO22X1 U686 ( .A0(parity[0]), .A1(n488), .B0(PWDATA[25]), .B1(n263), .Y(n218) );
  AO22X1 U687 ( .A0(parity[1]), .A1(n487), .B0(PWDATA[26]), .B1(n263), .Y(n219) );
  AO22X1 U688 ( .A0(reg_0x0000_27_), .A1(n488), .B0(PWDATA[27]), .B1(n263), 
        .Y(n220) );
  AO22X1 U689 ( .A0(reg_0x0000_29_), .A1(n488), .B0(PWDATA[29]), .B1(n263), 
        .Y(n221) );
  AO22X1 U690 ( .A0(reg_0x0000_30_), .A1(n487), .B0(PWDATA[30]), .B1(n263), 
        .Y(n222) );
  AO22X1 U691 ( .A0(n490), .A1(n487), .B0(PWDATA[31]), .B1(n263), .Y(n223) );
  AO22X1 U692 ( .A0(reg_0x0000_7_), .A1(n488), .B0(n252), .B1(n263), .Y(n224)
         );
  AO22X1 U693 ( .A0(reg_0x0000_15_), .A1(n487), .B0(PWDATA[15]), .B1(n263), 
        .Y(n225) );
  AO22X1 U694 ( .A0(rxwaterlevel_int[0]), .A1(n488), .B0(n259), .B1(n263), .Y(
        n226) );
  AO22X1 U695 ( .A0(rxwaterlevel_int[1]), .A1(n488), .B0(n258), .B1(n263), .Y(
        n227) );
  AO22X1 U696 ( .A0(rxwaterlevel_int[2]), .A1(n487), .B0(n257), .B1(n263), .Y(
        n228) );
  AO22X1 U697 ( .A0(rxwaterlevel_int[3]), .A1(n487), .B0(n256), .B1(n263), .Y(
        n229) );
  AO22X1 U698 ( .A0(rxwaterlevel_int[4]), .A1(n488), .B0(n255), .B1(n263), .Y(
        n230) );
  AO22X1 U699 ( .A0(rxwaterlevel_int[5]), .A1(n487), .B0(n254), .B1(n263), .Y(
        n231) );
  AO22X1 U700 ( .A0(timeoutcnt[0]), .A1(n485), .B0(n276), .B1(n259), .Y(n155)
         );
  AO22X1 U701 ( .A0(timeoutcnt[1]), .A1(n484), .B0(n276), .B1(n258), .Y(n156)
         );
  AO22X1 U702 ( .A0(timeoutcnt[2]), .A1(n275), .B0(n276), .B1(n257), .Y(n157)
         );
  AO22X1 U703 ( .A0(timeoutcnt[3]), .A1(n485), .B0(n276), .B1(n256), .Y(n158)
         );
  AO22X1 U704 ( .A0(timeoutcnt[4]), .A1(n484), .B0(n276), .B1(n255), .Y(n159)
         );
  AO22X1 U705 ( .A0(timeoutcnt[5]), .A1(n275), .B0(n276), .B1(n254), .Y(n160)
         );
  AO22X1 U706 ( .A0(timeoutcnt[6]), .A1(n485), .B0(n276), .B1(n253), .Y(n161)
         );
  AO22X1 U707 ( .A0(timeoutcnt[7]), .A1(n484), .B0(n276), .B1(n252), .Y(n162)
         );
  AO22X1 U708 ( .A0(timeoutcnt[8]), .A1(n485), .B0(n276), .B1(PWDATA[8]), .Y(
        n163) );
  AO22X1 U709 ( .A0(timeoutcnt[9]), .A1(n485), .B0(n276), .B1(PWDATA[9]), .Y(
        n164) );
  AO22X1 U710 ( .A0(timeoutcnt[10]), .A1(n484), .B0(n276), .B1(PWDATA[10]), 
        .Y(n165) );
  AO22X1 U711 ( .A0(timeoutcnt[11]), .A1(n484), .B0(n276), .B1(PWDATA[11]), 
        .Y(n166) );
  AO22X1 U712 ( .A0(timeoutcnt[12]), .A1(n485), .B0(n276), .B1(PWDATA[12]), 
        .Y(n167) );
  AO22X1 U713 ( .A0(timeoutcnt[13]), .A1(n484), .B0(n276), .B1(PWDATA[13]), 
        .Y(n168) );
  AO22X1 U714 ( .A0(timeoutcnt[14]), .A1(n485), .B0(n276), .B1(PWDATA[14]), 
        .Y(n169) );
  AO22X1 U715 ( .A0(timeoutcnt[15]), .A1(n485), .B0(n276), .B1(PWDATA[15]), 
        .Y(n170) );
  AO22X1 U716 ( .A0(clkdiv[0]), .A1(n486), .B0(n267), .B1(n259), .Y(n193) );
  AO22X1 U717 ( .A0(clkdiv[1]), .A1(n486), .B0(n267), .B1(n258), .Y(n194) );
  AO22X1 U718 ( .A0(clkdiv[2]), .A1(n486), .B0(n267), .B1(n257), .Y(n195) );
  AO22X1 U719 ( .A0(clkdiv[3]), .A1(n486), .B0(n267), .B1(n256), .Y(n196) );
  AO22X1 U720 ( .A0(clkdiv[4]), .A1(n486), .B0(n267), .B1(n255), .Y(n197) );
  AO22X1 U721 ( .A0(clkdiv[5]), .A1(n486), .B0(n267), .B1(n254), .Y(n198) );
  AO22X1 U722 ( .A0(clkdiv[7]), .A1(n486), .B0(n267), .B1(n252), .Y(n200) );
  AO22X1 U723 ( .A0(clkdiv[8]), .A1(n486), .B0(n267), .B1(PWDATA[8]), .Y(n201)
         );
  AO22X1 U724 ( .A0(clkdiv[9]), .A1(n486), .B0(n267), .B1(PWDATA[9]), .Y(n202)
         );
  AO22X1 U725 ( .A0(clkdiv[10]), .A1(n486), .B0(n267), .B1(PWDATA[10]), .Y(
        n203) );
  AO22X1 U726 ( .A0(clkdiv[11]), .A1(n486), .B0(n267), .B1(PWDATA[11]), .Y(
        n204) );
  AO22X1 U727 ( .A0(clkdiv[12]), .A1(n486), .B0(n267), .B1(PWDATA[12]), .Y(
        n205) );
  AO22X1 U728 ( .A0(clkdiv[13]), .A1(n486), .B0(n267), .B1(PWDATA[13]), .Y(
        n206) );
  AO22X1 U729 ( .A0(clkdiv[15]), .A1(n486), .B0(n267), .B1(PWDATA[15]), .Y(
        n208) );
  INVX1 U730 ( .A(n233), .Y(carry_18_) );
  INVX1 U731 ( .A(n1810), .Y(carry_2_) );
  INVX1 U732 ( .A(n1710), .Y(carry_3_) );
  INVX1 U733 ( .A(n1610), .Y(carry_4_) );
  INVX1 U734 ( .A(n1510), .Y(carry_5_) );
  INVX1 U735 ( .A(n1410), .Y(carry_6_) );
  INVX1 U736 ( .A(n1310), .Y(carry_7_) );
  INVX1 U737 ( .A(n1210), .Y(carry_8_) );
  INVX1 U738 ( .A(n1110), .Y(carry_9_) );
  INVX1 U739 ( .A(n9), .Y(carry_11_) );
  INVX1 U740 ( .A(n7), .Y(carry_13_) );
  INVX1 U741 ( .A(n5), .Y(carry_15_) );
  INVX1 U742 ( .A(n310), .Y(carry_17_) );
  INVX1 U743 ( .A(n1010), .Y(carry_10_) );
  INVX1 U744 ( .A(n8), .Y(carry_12_) );
  INVX1 U745 ( .A(n6), .Y(carry_14_) );
  INVX1 U746 ( .A(n410), .Y(carry_16_) );
  AO21X1 U747 ( .A0(n278), .A1(timeoutcnt_int[19]), .B0(n279), .Y(n154) );
  OAI33X1 U748 ( .A0(n280), .A1(n478), .A2(n282), .B0(n280), .B1(
        timeoutcnt_int[19]), .B2(n1100), .Y(n279) );
  INVX1 U749 ( .A(n1100), .Y(n282) );
  AFHCONX2 U1_1 ( .A(clkdivcnt[1]), .B(clkdiv[1]), .CI(carry_1_), .S(N90), 
        .CON(n1411) );
  NOR2BX1 U750 ( .AN(clkdivcnt[0]), .B(n448), .Y(carry_1_) );
  AFHCONX2 U1_2 ( .A(clkdivcnt[2]), .B(clkdiv[2]), .CI(carry12), .S(N91), 
        .CON(n1311) );
  INVX1 U751 ( .A(n1411), .Y(carry12) );
  AFHCONX2 U1_3 ( .A(clkdivcnt[3]), .B(clkdiv[3]), .CI(carry11), .S(N92), 
        .CON(n1211) );
  INVX1 U752 ( .A(n1311), .Y(carry11) );
  AFHCONX2 U1_4 ( .A(clkdivcnt[4]), .B(clkdiv[4]), .CI(carry10), .S(N93), 
        .CON(n1111) );
  INVX1 U753 ( .A(n1211), .Y(carry10) );
  AFHCONX2 U1_5 ( .A(clkdivcnt[5]), .B(clkdiv[5]), .CI(carry9), .S(N94), .CON(
        n1011) );
  INVX1 U754 ( .A(n1111), .Y(carry9) );
  AFHCONX2 U1_6 ( .A(clkdivcnt[6]), .B(clkdiv[6]), .CI(carry8), .S(N95), .CON(
        n910) );
  INVX1 U755 ( .A(n1011), .Y(carry8) );
  AFHCONX2 U1_7 ( .A(clkdivcnt[7]), .B(clkdiv[7]), .CI(carry7), .S(N96), .CON(
        n810) );
  INVX1 U756 ( .A(n910), .Y(carry7) );
  AFHCONX2 U1_8 ( .A(clkdivcnt[8]), .B(clkdiv[8]), .CI(carry6), .S(N97), .CON(
        n710) );
  INVX1 U757 ( .A(n810), .Y(carry6) );
  AFHCONX2 U1_9 ( .A(clkdivcnt[9]), .B(clkdiv[9]), .CI(carry5), .S(N98), .CON(
        n610) );
  INVX1 U758 ( .A(n710), .Y(carry5) );
  AFHCONX2 U1_10 ( .A(clkdivcnt[10]), .B(clkdiv[10]), .CI(carry4), .S(N99), 
        .CON(n510) );
  INVX1 U759 ( .A(n610), .Y(carry4) );
  AFHCONX2 U1_11 ( .A(clkdivcnt[11]), .B(clkdiv[11]), .CI(carry3), .S(N100), 
        .CON(n411) );
  INVX1 U760 ( .A(n510), .Y(carry3) );
  AFHCONX2 U1_12 ( .A(clkdivcnt[12]), .B(clkdiv[12]), .CI(carry2), .S(N101), 
        .CON(n311) );
  INVX1 U761 ( .A(n411), .Y(carry2) );
  AFHCONX2 U1_13 ( .A(clkdivcnt[13]), .B(clkdiv[13]), .CI(carry1), .S(N102), 
        .CON(n234) );
  INVX1 U762 ( .A(n311), .Y(carry1) );
  AFHCONX2 U1_14 ( .A(clkdivcnt[14]), .B(clkdiv[14]), .CI(carry0), .S(N103), 
        .CON(n1101) );
  INVX1 U763 ( .A(n234), .Y(carry0) );
  AO22X1 U764 ( .A0(clkdivcnt[13]), .A1(n437), .B0(N102), .B1(uarten), .Y(n189) );
  AO22X1 U765 ( .A0(clkdivcnt[14]), .A1(n437), .B0(N103), .B1(uarten), .Y(n190) );
  AO22X1 U766 ( .A0(clkdivcnt[15]), .A1(n437), .B0(N104), .B1(uarten), .Y(n191) );
  XOR3X1 U1_15 ( .A(clkdivcnt[15]), .B(clkdiv[15]), .C(carry), .Y(N104) );
  INVX1 U767 ( .A(n1101), .Y(carry) );
  AO22X1 U768 ( .A0(timeoutcnt_int[15]), .A1(n278), .B0(N126), .B1(n283), .Y(
        n150) );
  AO22X1 U769 ( .A0(timeoutcnt_int[16]), .A1(n278), .B0(N127), .B1(n283), .Y(
        n151) );
  AO22X1 U770 ( .A0(timeoutcnt_int[17]), .A1(n278), .B0(N128), .B1(n283), .Y(
        n152) );
  AO22X1 U771 ( .A0(timeoutcnt_int[18]), .A1(n278), .B0(N129), .B1(n283), .Y(
        n153) );
  BUFX2 U772 ( .A(n490), .Y(uarten) );
  INVX1 U773 ( .A(n415), .Y(n377) );
  OAI31X1 U774 ( .A0(n416), .A1(n417), .A2(n418), .B0(n419), .Y(n415) );
  INVX1 U775 ( .A(n420), .Y(n418) );
  AOI222X1 U776 ( .A0(n421), .A1(n422), .B0(txwaterlevel_int[3]), .B1(n387), 
        .C0(txwaterlevel_int[2]), .C1(n392), .Y(n416) );
  NAND4BX1 U777 ( .AN(rxfifoempty), .B(n449), .C(bytereceivedb), .D(
        reg_0x0000_29_), .Y(n285) );
  NOR2BX1 U778 ( .AN(reg_0x0000_15_), .B(n377), .Y(N51) );
  NOR2BX1 U779 ( .AN(reg_0x0000_7_), .B(n356), .Y(N52) );
  AO22X1 U780 ( .A0(clkdivcnt[8]), .A1(n437), .B0(N97), .B1(uarten), .Y(n184)
         );
  AO22X1 U781 ( .A0(clkdivcnt[9]), .A1(n437), .B0(N98), .B1(uarten), .Y(n185)
         );
  AO22X1 U782 ( .A0(clkdivcnt[10]), .A1(n437), .B0(N99), .B1(uarten), .Y(n186)
         );
  AO22X1 U783 ( .A0(clkdivcnt[11]), .A1(n437), .B0(N100), .B1(uarten), .Y(n187) );
  AO22X1 U784 ( .A0(clkdivcnt[12]), .A1(n437), .B0(N101), .B1(uarten), .Y(n188) );
  AO22X1 U785 ( .A0(timeoutcnt_int[0]), .A1(n278), .B0(n283), .B1(n477), .Y(
        n135) );
  AO22X1 U786 ( .A0(timeoutcnt_int[1]), .A1(n278), .B0(N112), .B1(n283), .Y(
        n136) );
  AO22X1 U787 ( .A0(timeoutcnt_int[2]), .A1(n278), .B0(N113), .B1(n283), .Y(
        n137) );
  AO22X1 U788 ( .A0(timeoutcnt_int[3]), .A1(n278), .B0(N114), .B1(n283), .Y(
        n138) );
  AO22X1 U789 ( .A0(timeoutcnt_int[4]), .A1(n278), .B0(N115), .B1(n283), .Y(
        n139) );
  AO22X1 U790 ( .A0(timeoutcnt_int[5]), .A1(n278), .B0(N116), .B1(n283), .Y(
        n140) );
  AO22X1 U791 ( .A0(timeoutcnt_int[6]), .A1(n278), .B0(N117), .B1(n283), .Y(
        n141) );
  AO22X1 U792 ( .A0(timeoutcnt_int[7]), .A1(n278), .B0(N118), .B1(n283), .Y(
        n142) );
  AO22X1 U793 ( .A0(timeoutcnt_int[8]), .A1(n278), .B0(N119), .B1(n283), .Y(
        n143) );
  AO22X1 U794 ( .A0(timeoutcnt_int[9]), .A1(n278), .B0(N120), .B1(n283), .Y(
        n144) );
  AO22X1 U795 ( .A0(timeoutcnt_int[10]), .A1(n278), .B0(N121), .B1(n283), .Y(
        n145) );
  AO22X1 U796 ( .A0(timeoutcnt_int[11]), .A1(n278), .B0(N122), .B1(n283), .Y(
        n146) );
  AO22X1 U797 ( .A0(timeoutcnt_int[12]), .A1(n278), .B0(N123), .B1(n283), .Y(
        n147) );
  AO22X1 U798 ( .A0(timeoutcnt_int[13]), .A1(n278), .B0(N124), .B1(n283), .Y(
        n148) );
  AO22X1 U799 ( .A0(timeoutcnt_int[14]), .A1(n278), .B0(N125), .B1(n283), .Y(
        n149) );
  AO22X1 U800 ( .A0(rxwaterlevel_int[3]), .A1(n364), .B0(rxwaterlevel_int[4]), 
        .B1(n361), .Y(n405) );
  AOI32X1 U801 ( .A0(rxfifocnt[4]), .A1(n455), .A2(n408), .B0(rxfifocnt[5]), 
        .B1(n439), .Y(n407) );
  AOI32X1 U802 ( .A0(txwaterlevel_int[4]), .A1(n383), .A2(n420), .B0(
        txwaterlevel_int[5]), .B1(n379), .Y(n419) );
  XOR2X1 U803 ( .A(timeoutcnt[0]), .B(n477), .Y(n326) );
  XOR2X1 U804 ( .A(timeoutcnt[19]), .B(n478), .Y(n305) );
  XOR2X1 U805 ( .A(timeoutcnt_int[9]), .B(timeoutcnt[9]), .Y(n295) );
  XOR2X1 U806 ( .A(timeoutcnt_int[18]), .B(timeoutcnt[18]), .Y(n316) );
  XOR2X1 U807 ( .A(n435), .B(timeoutcnt_int[10]), .Y(n325) );
  XOR2X1 U808 ( .A(timeoutcnt[1]), .B(n479), .Y(n304) );
  XOR2X1 U809 ( .A(timeoutcnt_int[17]), .B(timeoutcnt[17]), .Y(n315) );
  XOR2X1 U810 ( .A(timeoutcnt_int[11]), .B(timeoutcnt[11]), .Y(n324) );
  XOR2X1 U811 ( .A(timeoutcnt_int[2]), .B(timeoutcnt[2]), .Y(n303) );
  OAI211X1 U812 ( .A0(n292), .A1(n293), .B0(reg_0x0000_29_), .C0(n449), .Y(
        n290) );
  OR4X1 U813 ( .A(n294), .B(n295), .C(n296), .D(n297), .Y(n293) );
  OR4X1 U814 ( .A(n315), .B(n316), .C(n317), .D(n318), .Y(n292) );
  XOR2X1 U815 ( .A(timeoutcnt_int[8]), .B(timeoutcnt[8]), .Y(n294) );
  NAND3BX1 U816 ( .AN(n319), .B(n320), .C(n321), .Y(n318) );
  XOR2X1 U817 ( .A(n434), .B(timeoutcnt_int[12]), .Y(n320) );
  XOR2X1 U818 ( .A(n433), .B(timeoutcnt_int[13]), .Y(n321) );
  NAND3BX1 U819 ( .AN(n324), .B(n325), .C(n326), .Y(n319) );
  NAND3BX1 U820 ( .AN(n298), .B(n299), .C(n300), .Y(n297) );
  XOR2X1 U821 ( .A(n451), .B(timeoutcnt_int[3]), .Y(n299) );
  XOR2X1 U822 ( .A(n450), .B(timeoutcnt_int[4]), .Y(n300) );
  NAND3BX1 U823 ( .AN(n303), .B(n304), .C(n305), .Y(n298) );
  NAND3BX1 U824 ( .AN(n329), .B(n330), .C(n331), .Y(n317) );
  XOR2X1 U825 ( .A(n432), .B(timeoutcnt_int[14]), .Y(n330) );
  XOR2X1 U826 ( .A(n436), .B(timeoutcnt_int[15]), .Y(n331) );
  XOR2X1 U827 ( .A(timeoutcnt_int[16]), .B(timeoutcnt[16]), .Y(n329) );
  NAND3BX1 U828 ( .AN(n308), .B(n309), .C(n312), .Y(n296) );
  XOR2X1 U829 ( .A(n453), .B(timeoutcnt_int[5]), .Y(n309) );
  XOR2X1 U830 ( .A(n452), .B(timeoutcnt_int[6]), .Y(n312) );
  XOR2X1 U831 ( .A(timeoutcnt_int[7]), .B(timeoutcnt[7]), .Y(n308) );
  OA22X1 U832 ( .A0(rxfifocnt[1]), .A1(n413), .B0(n413), .B1(n456), .Y(n412)
         );
  INVX1 U833 ( .A(n414), .Y(n413) );
  NAND2BX1 U834 ( .AN(rxwaterlevel_int[0]), .B(rxfifocnt[0]), .Y(n414) );
  OA22X1 U835 ( .A0(txwaterlevel_int[2]), .A1(n392), .B0(txwaterlevel_int[1]), 
        .B1(n340), .Y(n421) );
  AO22X1 U836 ( .A0(clkdivcnt[3]), .A1(n437), .B0(N92), .B1(uarten), .Y(n179)
         );
  AO22X1 U837 ( .A0(clkdivcnt[4]), .A1(n437), .B0(N93), .B1(uarten), .Y(n180)
         );
  AO22X1 U838 ( .A0(clkdivcnt[5]), .A1(n437), .B0(N94), .B1(uarten), .Y(n181)
         );
  AO22X1 U839 ( .A0(clkdivcnt[6]), .A1(n437), .B0(N95), .B1(uarten), .Y(n182)
         );
  AO22X1 U840 ( .A0(clkdivcnt[7]), .A1(n437), .B0(N96), .B1(uarten), .Y(n183)
         );
  OAI32X1 U841 ( .A0(n288), .A1(swrst), .A2(n442), .B0(n290), .B1(n460), .Y(
        n134) );
  INVX1 U842 ( .A(n290), .Y(n288) );
  NAND2BX1 U843 ( .AN(txwaterlevel_int[5]), .B(txfifocnt[5]), .Y(n420) );
  NAND2BX1 U844 ( .AN(rxfifocnt[5]), .B(rxwaterlevel_int[5]), .Y(n408) );
  AO22X1 U845 ( .A0(clkdivcnt[1]), .A1(n437), .B0(N90), .B1(uarten), .Y(n177)
         );
  AO22X1 U846 ( .A0(clkdivcnt[2]), .A1(n437), .B0(N91), .B1(uarten), .Y(n178)
         );
  AO22X1 U847 ( .A0(clkdivcnt_msb_dly), .A1(n437), .B0(clkdivcnt[15]), .B1(
        uarten), .Y(n192) );
  OAI32X1 U848 ( .A0(n437), .A1(clkdivcnt_msb_dly), .A2(n459), .B0(uarten), 
        .B1(n431), .Y(n175) );
  INVX1 U849 ( .A(txfifocnt[5]), .Y(n379) );
  OAI31X1 U850 ( .A0(n437), .A1(clkdivcnt[0]), .A2(n448), .B0(n271), .Y(n176)
         );
  OA22X1 U851 ( .A0(uarten), .A1(n461), .B0(clkdiv[0]), .B1(n461), .Y(n271) );
  AOI211X1 U852 ( .A0(n426), .A1(n427), .B0(swrst), .C0(n462), .Y(N108) );
  NOR3BX1 U853 ( .AN(n430), .B(overrunerror), .C(n10), .Y(n426) );
  NOR3BX1 U854 ( .AN(n429), .B(reg_0x0004_7_), .C(reg_0x0004_22_), .Y(n427) );
  INVX1 U855 ( .A(parityerror), .Y(n429) );
  INVX1 U856 ( .A(frameerror), .Y(n430) );
  AO22X1 U857 ( .A0(PADDR[4]), .A1(PADDR[3]), .B0(PADDR[2]), .B1(n400), .Y(
        PRDATA[28]) );
  INVX1 U858 ( .A(PADDR[4]), .Y(n400) );
  NAND2BX1 U859 ( .AN(n377), .B(reg_0x0000_27_), .Y(n261) );
  NOR2BX1 U860 ( .AN(timeoutcnt[19]), .B(n483), .Y(PRDATA[19]) );
  NOR2BX1 U861 ( .AN(reg_0x0000_30_), .B(n482), .Y(PRDATA[30]) );
  NOR2BX1 U862 ( .AN(timeoutcnt[16]), .B(n483), .Y(PRDATA[16]) );
  NOR2BX1 U863 ( .AN(timeoutcnt[17]), .B(n483), .Y(PRDATA[17]) );
  NOR2BX1 U864 ( .AN(timeoutcnt[18]), .B(n483), .Y(PRDATA[18]) );
  AO22X1 U865 ( .A0(frameerror), .A1(PRDATA[28]), .B0(databit), .B1(n265), .Y(
        PRDATA[24]) );
  OAI2BB1X1 U866 ( .A0N(rxdmareq), .A1N(PRDATA[28]), .B0(n354), .Y(PRDATA[6])
         );
  AOI222X1 U867 ( .A0(timeoutcnt[6]), .A1(n352), .B0(clkdiv[6]), .B1(n353), 
        .C0(fifodata_rx[6]), .C1(n336), .Y(n354) );
  AO22X1 U868 ( .A0(rxbusy), .A1(PRDATA[28]), .B0(parity[1]), .B1(n265), .Y(
        PRDATA[26]) );
  OAI222X1 U869 ( .A0(n483), .A1(n432), .B0(n268), .B1(n463), .C0(n339), .C1(
        n261), .Y(PRDATA[14]) );
  AO22X1 U870 ( .A0(overrunerror), .A1(PRDATA[28]), .B0(stopbit), .B1(n265), 
        .Y(PRDATA[23]) );
  AO22X1 U871 ( .A0(txbusy), .A1(PRDATA[28]), .B0(n265), .B1(reg_0x0000_27_), 
        .Y(PRDATA[27]) );
  AO22X1 U872 ( .A0(reg_0x0004_22_), .A1(PRDATA[28]), .B0(loopbacken), .B1(
        n265), .Y(PRDATA[22]) );
  AO22X1 U873 ( .A0(parityerror), .A1(PRDATA[28]), .B0(parity[0]), .B1(n265), 
        .Y(PRDATA[25]) );
  AO22X1 U874 ( .A0(int), .A1(PRDATA[28]), .B0(uarten), .B1(n265), .Y(
        PRDATA[31]) );
  OAI221X1 U875 ( .A0(n440), .A1(n482), .B0(n339), .B1(n340), .C0(n341), .Y(
        PRDATA[9]) );
  OA22X1 U876 ( .A0(n268), .A1(n445), .B0(n483), .B1(n473), .Y(n341) );
  OAI221X1 U877 ( .A0(n454), .A1(n482), .B0(n339), .B1(n364), .C0(n365), .Y(
        PRDATA[3]) );
  AOI222X1 U878 ( .A0(timeoutcnt[3]), .A1(n352), .B0(clkdiv[3]), .B1(n353), 
        .C0(fifodata_rx[3]), .C1(n336), .Y(n365) );
  OAI221X1 U879 ( .A0(n441), .A1(n482), .B0(n339), .B1(n387), .C0(n388), .Y(
        PRDATA[11]) );
  OA22X1 U880 ( .A0(n268), .A1(n446), .B0(n483), .B1(n474), .Y(n388) );
  OAI221X1 U881 ( .A0(n465), .A1(n482), .B0(n339), .B1(n379), .C0(n380), .Y(
        PRDATA[13]) );
  OA22X1 U882 ( .A0(n268), .A1(n467), .B0(n483), .B1(n433), .Y(n380) );
  OAI221X1 U883 ( .A0(n482), .A1(n466), .B0(n339), .B1(n396), .C0(n397), .Y(
        PRDATA[0]) );
  AOI222X1 U884 ( .A0(timeoutcnt[0]), .A1(n352), .B0(clkdiv[0]), .B1(n353), 
        .C0(fifodata_rx[0]), .C1(n336), .Y(n397) );
  INVX1 U885 ( .A(rxfifocnt[0]), .Y(n396) );
  OAI221X1 U886 ( .A0(n439), .A1(n482), .B0(n339), .B1(n358), .C0(n359), .Y(
        PRDATA[5]) );
  INVX1 U887 ( .A(rxfifocnt[5]), .Y(n358) );
  AOI222X1 U888 ( .A0(timeoutcnt[5]), .A1(n352), .B0(clkdiv[5]), .B1(n353), 
        .C0(fifodata_rx[5]), .C1(n336), .Y(n359) );
  OAI221X1 U889 ( .A0(n482), .A1(n457), .B0(n339), .B1(n345), .C0(n346), .Y(
        PRDATA[8]) );
  INVX1 U890 ( .A(txfifocnt[0]), .Y(n345) );
  OA22X1 U891 ( .A0(n268), .A1(n447), .B0(n483), .B1(n475), .Y(n346) );
  OAI221X1 U892 ( .A0(n438), .A1(n482), .B0(n339), .B1(n367), .C0(n368), .Y(
        PRDATA[2]) );
  AOI222X1 U893 ( .A0(timeoutcnt[2]), .A1(n352), .B0(clkdiv[2]), .B1(n353), 
        .C0(fifodata_rx[2]), .C1(n336), .Y(n368) );
  INVX1 U894 ( .A(rxfifocnt[2]), .Y(n367) );
  OAI221X1 U895 ( .A0(n456), .A1(n482), .B0(n339), .B1(n370), .C0(n371), .Y(
        PRDATA[1]) );
  AOI222X1 U896 ( .A0(timeoutcnt[1]), .A1(n352), .B0(clkdiv[1]), .B1(n353), 
        .C0(fifodata_rx[1]), .C1(n336), .Y(n371) );
  INVX1 U897 ( .A(rxfifocnt[1]), .Y(n370) );
  OAI221X1 U898 ( .A0(n458), .A1(n482), .B0(n339), .B1(n383), .C0(n384), .Y(
        PRDATA[12]) );
  OA22X1 U899 ( .A0(n268), .A1(n468), .B0(n483), .B1(n434), .Y(n384) );
  OAI221X1 U900 ( .A0(n455), .A1(n482), .B0(n339), .B1(n361), .C0(n362), .Y(
        PRDATA[4]) );
  AOI222X1 U901 ( .A0(timeoutcnt[4]), .A1(n352), .B0(clkdiv[4]), .B1(n353), 
        .C0(fifodata_rx[4]), .C1(n336), .Y(n362) );
  OAI221X1 U902 ( .A0(n482), .A1(n443), .B0(n339), .B1(n470), .C0(n351), .Y(
        PRDATA[7]) );
  AOI222X1 U903 ( .A0(timeoutcnt[7]), .A1(n352), .B0(clkdiv[7]), .B1(n353), 
        .C0(fifodata_rx[7]), .C1(n336), .Y(n351) );
  OAI221X1 U904 ( .A0(n464), .A1(n482), .B0(n339), .B1(n392), .C0(n393), .Y(
        PRDATA[10]) );
  OA22X1 U905 ( .A0(n268), .A1(n469), .B0(n483), .B1(n435), .Y(n393) );
  OAI221X1 U906 ( .A0(n482), .A1(n444), .B0(n339), .B1(n471), .C0(n374), .Y(
        PRDATA[15]) );
  OA22X1 U907 ( .A0(n268), .A1(n472), .B0(n483), .B1(n436), .Y(n374) );
  AO21X1 U908 ( .A0(reg_0x0000_29_), .A1(n265), .B0(PRDATA[28]), .Y(PRDATA[29]) );
  NOR2X1 U909 ( .A(n356), .B(n481), .Y(rxdmareq) );
  DFFRX1 timeoutcnt_int_reg_0_ ( .D(n135), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[0]), .QN(n477) );
  DFFRX1 clkdiv_reg_0_ ( .D(n193), .CK(clk), .RN(rstb), .Q(clkdiv[0]), .QN(
        n448) );
  DFFRX1 clkdivcnt_reg_0_ ( .D(n176), .CK(clk), .RN(rstb), .Q(clkdivcnt[0]), 
        .QN(n461) );
  DFFRX1 timeoutcnt_int_reg_1_ ( .D(n136), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[1]), .QN(n479) );
  DFFRX1 timeoutcnt_int_reg_3_ ( .D(n138), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[3]) );
  DFFRX1 timeoutcnt_int_reg_4_ ( .D(n139), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[4]) );
  DFFRX1 timeoutcnt_int_reg_5_ ( .D(n140), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[5]) );
  DFFRX1 timeoutcnt_int_reg_2_ ( .D(n137), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[2]) );
  DFFRX1 clkdiv_reg_1_ ( .D(n194), .CK(clk), .RN(rstb), .Q(clkdiv[1]) );
  DFFRX1 clkdiv_reg_2_ ( .D(n195), .CK(clk), .RN(rstb), .Q(clkdiv[2]) );
  DFFRX1 clkdiv_reg_3_ ( .D(n196), .CK(clk), .RN(rstb), .Q(clkdiv[3]) );
  DFFRX1 clkdivcnt_reg_1_ ( .D(n177), .CK(clk), .RN(rstb), .Q(clkdivcnt[1]) );
  DFFRX1 clkdivcnt_reg_2_ ( .D(n178), .CK(clk), .RN(rstb), .Q(clkdivcnt[2]) );
  DFFRX1 clkdivcnt_reg_3_ ( .D(n179), .CK(clk), .RN(rstb), .Q(clkdivcnt[3]) );
  DFFRX1 parity_int_reg_0_ ( .D(n218), .CK(clk), .RN(rstb), .Q(parity[0]) );
  DFFRX1 clkdiv_reg_8_ ( .D(n201), .CK(clk), .RN(rstb), .Q(clkdiv[8]), .QN(
        n447) );
  DFFRX1 uarten_int_reg ( .D(n223), .CK(clk), .RN(rstb), .Q(n490), .QN(n437)
         );
  DFFRX1 timeoutcnt_int_reg_6_ ( .D(n141), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[6]) );
  DFFRX1 timeoutcnt_int_reg_10_ ( .D(n145), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[10]) );
  DFFRX1 timeoutcnt_int_reg_7_ ( .D(n142), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[7]) );
  DFFRX1 timeoutcnt_int_reg_8_ ( .D(n143), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[8]) );
  DFFRX1 timeoutcnt_int_reg_9_ ( .D(n144), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[9]) );
  DFFRX1 timeoutcnt_int_reg_11_ ( .D(n146), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[11]) );
  DFFRX1 clkdiv_reg_4_ ( .D(n197), .CK(clk), .RN(rstb), .Q(clkdiv[4]) );
  DFFRX1 clkdiv_reg_5_ ( .D(n198), .CK(clk), .RN(rstb), .Q(clkdiv[5]) );
  DFFRX1 clkdiv_reg_6_ ( .D(n199), .CK(clk), .RN(rstb), .Q(clkdiv[6]) );
  DFFRX1 clkdiv_reg_7_ ( .D(n200), .CK(clk), .RN(rstb), .Q(clkdiv[7]) );
  DFFRX1 clkdivcnt_reg_4_ ( .D(n180), .CK(clk), .RN(rstb), .Q(clkdivcnt[4]) );
  DFFRX1 clkdivcnt_reg_5_ ( .D(n181), .CK(clk), .RN(rstb), .Q(clkdivcnt[5]) );
  DFFRX1 clkdivcnt_reg_6_ ( .D(n182), .CK(clk), .RN(rstb), .Q(clkdivcnt[6]) );
  DFFRX1 clkdivcnt_reg_7_ ( .D(n183), .CK(clk), .RN(rstb), .Q(clkdivcnt[7]) );
  DFFRX1 clkdivcnt_reg_8_ ( .D(n184), .CK(clk), .RN(rstb), .Q(clkdivcnt[8]) );
  DFFRX1 stopbit_int_reg ( .D(n216), .CK(clk), .RN(rstb), .Q(stopbit) );
  DFFRX1 timeoutinten_int_reg ( .D(n221), .CK(clk), .RN(rstb), .Q(
        reg_0x0000_29_), .QN(n442) );
  DFFRX1 clkdiv_reg_9_ ( .D(n202), .CK(clk), .RN(rstb), .Q(clkdiv[9]), .QN(
        n445) );
  DFFRX1 clkdiv_reg_10_ ( .D(n203), .CK(clk), .RN(rstb), .Q(clkdiv[10]), .QN(
        n469) );
  DFFRX1 clkdiv_reg_11_ ( .D(n204), .CK(clk), .RN(rstb), .Q(clkdiv[11]), .QN(
        n446) );
  DFFRX1 clkdiv_reg_12_ ( .D(n205), .CK(clk), .RN(rstb), .Q(clkdiv[12]), .QN(
        n468) );
  DFFRX1 timeoutcnt_int_reg_19_ ( .D(n154), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[19]), .QN(n478) );
  DFFRX1 timeoutcnt_reg_8_ ( .D(n163), .CK(clk), .RN(rstb), .Q(timeoutcnt[8]), 
        .QN(n475) );
  DFFRX1 timeoutcnt_reg_9_ ( .D(n164), .CK(clk), .RN(rstb), .Q(timeoutcnt[9]), 
        .QN(n473) );
  DFFRX1 timeoutcnt_reg_11_ ( .D(n166), .CK(clk), .RN(rstb), .Q(timeoutcnt[11]), .QN(n474) );
  DFFRX1 loopbacken_int_reg ( .D(n215), .CK(clk), .RN(rstb), .Q(loopbacken) );
  DFFRX1 timeoutcnt_reg_19_ ( .D(n174), .CK(clk), .RN(rstb), .Q(timeoutcnt[19]) );
  DFFRX1 rxwaterlevel_int_reg_0_ ( .D(n226), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[0]), .QN(n466) );
  DFFRX1 timeoutcnt_reg_0_ ( .D(n155), .CK(clk), .RN(rstb), .Q(timeoutcnt[0])
         );
  DFFRX1 timeoutcnt_reg_1_ ( .D(n156), .CK(clk), .RN(rstb), .Q(timeoutcnt[1])
         );
  DFFRX1 timeoutcnt_reg_3_ ( .D(n158), .CK(clk), .RN(rstb), .Q(timeoutcnt[3]), 
        .QN(n451) );
  DFFRX1 timeoutcnt_reg_4_ ( .D(n159), .CK(clk), .RN(rstb), .Q(timeoutcnt[4]), 
        .QN(n450) );
  DFFRX1 timeoutcnt_reg_5_ ( .D(n160), .CK(clk), .RN(rstb), .Q(timeoutcnt[5]), 
        .QN(n453) );
  DFFRX1 timeoutcnt_reg_6_ ( .D(n161), .CK(clk), .RN(rstb), .Q(timeoutcnt[6]), 
        .QN(n452) );
  DFFRX1 timeoutcnt_reg_10_ ( .D(n165), .CK(clk), .RN(rstb), .Q(timeoutcnt[10]), .QN(n435) );
  DFFRX1 timeoutcnt_reg_12_ ( .D(n167), .CK(clk), .RN(rstb), .Q(timeoutcnt[12]), .QN(n434) );
  DFFRX1 timeoutcnt_reg_13_ ( .D(n168), .CK(clk), .RN(rstb), .Q(timeoutcnt[13]), .QN(n433) );
  DFFRX1 timeoutcnt_reg_14_ ( .D(n169), .CK(clk), .RN(rstb), .Q(timeoutcnt[14]), .QN(n432) );
  DFFRX1 timeoutcnt_reg_15_ ( .D(n170), .CK(clk), .RN(rstb), .Q(timeoutcnt[15]), .QN(n436) );
  DFFRX1 timeoutcnt_int_reg_12_ ( .D(n147), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[12]) );
  DFFRX1 timeoutcnt_int_reg_13_ ( .D(n148), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[13]) );
  DFFRX1 timeoutcnt_int_reg_14_ ( .D(n149), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[14]) );
  DFFRX1 timeoutcnt_int_reg_15_ ( .D(n150), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[15]) );
  DFFRX1 timeoutcnt_int_reg_16_ ( .D(n151), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[16]) );
  DFFRX1 timeoutcnt_int_reg_17_ ( .D(n152), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[17]) );
  DFFRX1 timeoutcnt_int_reg_18_ ( .D(n153), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[18]) );
  DFFRX1 timeoutcnt_reg_16_ ( .D(n171), .CK(clk), .RN(rstb), .Q(timeoutcnt[16]) );
  DFFRX1 timeoutcnt_reg_17_ ( .D(n172), .CK(clk), .RN(rstb), .Q(timeoutcnt[17]) );
  DFFRX1 timeoutcnt_reg_18_ ( .D(n173), .CK(clk), .RN(rstb), .Q(timeoutcnt[18]) );
  DFFRX1 timeoutcnt_reg_2_ ( .D(n157), .CK(clk), .RN(rstb), .Q(timeoutcnt[2])
         );
  DFFRX1 timeoutcnt_reg_7_ ( .D(n162), .CK(clk), .RN(rstb), .Q(timeoutcnt[7])
         );
  DFFRX1 clkdivcnt_reg_9_ ( .D(n185), .CK(clk), .RN(rstb), .Q(clkdivcnt[9]) );
  DFFRX1 clkdivcnt_reg_10_ ( .D(n186), .CK(clk), .RN(rstb), .Q(clkdivcnt[10])
         );
  DFFRX1 clkdivcnt_reg_11_ ( .D(n187), .CK(clk), .RN(rstb), .Q(clkdivcnt[11])
         );
  DFFRX1 clkdivcnt_reg_12_ ( .D(n188), .CK(clk), .RN(rstb), .Q(clkdivcnt[12])
         );
  DFFRX1 clkdivcnt_reg_13_ ( .D(n189), .CK(clk), .RN(rstb), .Q(clkdivcnt[13])
         );
  DFFRX1 clkdiv_reg_13_ ( .D(n206), .CK(clk), .RN(rstb), .Q(clkdiv[13]), .QN(
        n467) );
  DFFRX1 clkdiv_reg_14_ ( .D(n207), .CK(clk), .RN(rstb), .Q(clkdiv[14]), .QN(
        n463) );
  DFFRX1 clkdiv_reg_15_ ( .D(n208), .CK(clk), .RN(rstb), .Q(clkdiv[15]), .QN(
        n472) );
  DFFRX1 receivetimeout_reg ( .D(n134), .CK(clk), .RN(rstb), .Q(reg_0x0004_22_), .QN(n460) );
  DFFRX1 rxwaterlevel_int_reg_5_ ( .D(n231), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[5]), .QN(n439) );
  DFFRX1 rxfifo_interrupt_reg ( .D(N52), .CK(clk), .RN(rstb), .Q(reg_0x0004_7_), .QN(n470) );
  DFFRX1 clkdivcnt_reg_15_ ( .D(n191), .CK(clk), .RN(rstb), .Q(clkdivcnt[15]), 
        .QN(n459) );
  DFFRX1 txfifo_interrupt_reg ( .D(N51), .CK(clk), .RN(rstb), .Q(n10), .QN(
        n471) );
  DFFRX1 txwaterlevel_int_reg_2_ ( .D(n211), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[2]), .QN(n464) );
  DFFRX1 txwaterlevel_int_reg_5_ ( .D(n214), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[5]), .QN(n465) );
  DFFRX1 rxwaterlevel_int_reg_3_ ( .D(n229), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[3]), .QN(n454) );
  DFFRX1 rxwaterlevel_int_reg_4_ ( .D(n230), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[4]), .QN(n455) );
  DFFRX1 txwaterlevel_int_reg_1_ ( .D(n210), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[1]), .QN(n440) );
  DFFRX1 intgenen_int_reg ( .D(n222), .CK(clk), .RN(rstb), .Q(reg_0x0000_30_), 
        .QN(n462) );
  DFFRX1 rxfifo_inten_reg ( .D(n224), .CK(clk), .RN(rstb), .Q(reg_0x0000_7_), 
        .QN(n443) );
  DFFRX1 txfifo_inten_reg ( .D(n225), .CK(clk), .RN(rstb), .Q(reg_0x0000_15_), 
        .QN(n444) );
  DFFRX1 txwaterlevel_int_reg_4_ ( .D(n213), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[4]), .QN(n458) );
  DFFRX1 txwaterlevel_int_reg_3_ ( .D(n212), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[3]), .QN(n441) );
  DFFRX1 txwaterlevel_int_reg_0_ ( .D(n209), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[0]), .QN(n457) );
  DFFRX1 rxwaterlevel_int_reg_1_ ( .D(n227), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[1]), .QN(n456) );
  DFFRX1 rxwaterlevel_int_reg_2_ ( .D(n228), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[2]), .QN(n438) );
  DFFRX1 overrunerr_clear_reg ( .D(N62), .CK(clk), .RN(rstb), .Q(
        overrunerr_clear) );
  DFFRX1 clkdivcnt_reg_14_ ( .D(n190), .CK(clk), .RN(rstb), .Q(clkdivcnt[14])
         );
  DFFRX1 clkdivcnt_msb_dly_reg ( .D(n192), .CK(clk), .RN(rstb), .Q(
        clkdivcnt_msb_dly) );
  DFFRX1 frameerr_clear_reg ( .D(N60), .CK(clk), .RN(rstb), .Q(frameerr_clear)
         );
  DFFRX1 parityerr_clear_reg ( .D(N61), .CK(clk), .RN(rstb), .Q(
        parityerr_clear) );
  DFFRX1 dmareqen_int_reg ( .D(n220), .CK(clk), .RN(rstb), .Q(reg_0x0000_27_), 
        .QN(n481) );
  DFFRX1 interrupt_status_reg ( .D(N108), .CK(clk), .RN(rstb), .Q(int) );
endmodule


module UartTop_1_0 ( PADDR, PENABLE, PSEL, PWDATA, PWRITE, clk, rstb, rxd, 
        PRDATA, int, rxdmareq, txd, txdmareq );
  input [4:2] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  input PENABLE, PSEL, PWRITE, clk, rstb, rxd;
  output int, rxdmareq, txd, txdmareq;
  wire   bytereceivedb, frameerror, overrunerror, parityerror, rxbusy,
         rxfifoempty, txbusy, txfifo_emptyb, txfifo_fillb, txfifo_fullb,
         baudx16clk, databit, fifordb, fifowrb, loopbacken, stopbit, swrst,
         uarten, frameerr_clear, parityerr_clear, overrunerr_clear;
  wire   [7:0] fifodata_rx;
  wire   [3:0] rxfifocnt;
  wire   [3:0] txfifocnt;
  wire   [7:0] fifodata_tx;
  wire   [1:0] parity;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1;
  assign PRDATA[21] = 1'b0;
  assign PRDATA[20] = 1'b0;

  RegBlk_1_3_0 RegBlock ( .PADDR(PADDR), .PENABLE(PENABLE), .PSEL(PSEL), 
        .PWDATA(PWDATA), .PWRITE(PWRITE), .bytereceivedb(bytereceivedb), .clk(
        clk), .fifodata_rx(fifodata_rx), .frameerror(frameerror), 
        .overrunerror(overrunerror), .parityerror(parityerror), .rstb(rstb), 
        .rxbusy(rxbusy), .rxfifocnt(rxfifocnt), .rxfifoempty(rxfifoempty), 
        .txbusy(txbusy), .txfifo_emptyb(txfifo_emptyb), .txfifo_fillb(
        txfifo_fillb), .txfifo_fullb(txfifo_fullb), .txfifocnt(txfifocnt), 
        .PRDATA({PRDATA[31:22], SYNOPSYS_UNCONNECTED__0, 
        SYNOPSYS_UNCONNECTED__1, PRDATA[19:0]}), .baudx16clk(baudx16clk), 
        .databit(databit), .fifodata_tx(fifodata_tx), .fifordb(fifordb), 
        .fifowrb(fifowrb), .int(int), .loopbacken(loopbacken), .parity(parity), 
        .rxdmareq(rxdmareq), .stopbit(stopbit), .swrst(swrst), .txdmareq(
        txdmareq), .uarten(uarten), .frameerr_clear(frameerr_clear), 
        .parityerr_clear(parityerr_clear), .overrunerr_clear(overrunerr_clear)
         );
  RxBlock_UART_FIFO_WIDTH3_0 RxBLK ( .baudx16clk(baudx16clk), .clk(clk), 
        .databit(databit), .fifordb(fifordb), .loopbacken(loopbacken), 
        .parity(parity), .rstb(rstb), .rxd(rxd), .stopbit(stopbit), .swrst(
        swrst), .txd(txd), .uarten(uarten), .bytereceivedb(bytereceivedb), 
        .fifodata_rx(fifodata_rx), .frameerror(frameerror), .overrunerror(
        overrunerror), .parityerror(parityerror), .rxbusy(rxbusy), .rxfifocnt(
        rxfifocnt), .rxfifoempty(rxfifoempty), .frameerr_clear(frameerr_clear), 
        .parityerr_clear(parityerr_clear), .overrunerr_clear(overrunerr_clear)
         );
  TxBlock_UART_FIFO_WIDTH3_0 TxBLK ( .baudx16clk(baudx16clk), .clk(clk), 
        .databit(databit), .fifodata_tx(fifodata_tx), .fifowrb(fifowrb), 
        .parity(parity), .rstb(rstb), .stopbit(stopbit), .swrst(swrst), 
        .uarten(uarten), .txbusy(txbusy), .txd(txd), .txfifo_emptyb(
        txfifo_emptyb), .txfifo_fillb(txfifo_fillb), .txfifo_fullb(
        txfifo_fullb), .txfifocnt(txfifocnt) );
endmodule


module TxBlock_UART_FIFO_WIDTH3_0 ( baudx16clk, clk, databit, fifodata_tx, 
        fifowrb, parity, rstb, stopbit, swrst, uarten, txbusy, txd, 
        txfifo_emptyb, txfifo_fillb, txfifo_fullb, txfifocnt );
  input [7:0] fifodata_tx;
  input [1:0] parity;
  output [3:0] txfifocnt;
  input baudx16clk, clk, databit, fifowrb, rstb, stopbit, swrst, uarten;
  output txbusy, txd, txfifo_emptyb, txfifo_fillb, txfifo_fullb;
  wire   N72, N73, N74, current_state_10_, current_state_9_, current_state_8_,
         current_state_7_, current_state_6_, current_state_5_,
         current_state_4_, current_state_3_, current_state_2_,
         current_state_1_, dtxclk, txclk, parity_int, fifordb, shiftenb,
         shiftreg_0_, N106, N107, N108, N110, N112, N113, N114, N115, N116,
         N117, N118, N119, N120, N121, N122, N123, N124, N125, N126, N127,
         N128, \txfifo[7][7] , \txfifo[7][6] , \txfifo[7][5] , \txfifo[7][4] ,
         \txfifo[7][3] , \txfifo[7][2] , \txfifo[7][1] , \txfifo[7][0] ,
         \txfifo[6][7] , \txfifo[6][6] , \txfifo[6][5] , \txfifo[6][4] ,
         \txfifo[6][3] , \txfifo[6][2] , \txfifo[6][1] , \txfifo[6][0] ,
         \txfifo[5][7] , \txfifo[5][6] , \txfifo[5][5] , \txfifo[5][4] ,
         \txfifo[5][3] , \txfifo[5][2] , \txfifo[5][1] , \txfifo[5][0] ,
         \txfifo[4][7] , \txfifo[4][6] , \txfifo[4][5] , \txfifo[4][4] ,
         \txfifo[4][3] , \txfifo[4][2] , \txfifo[4][1] , \txfifo[4][0] ,
         \txfifo[3][7] , \txfifo[3][6] , \txfifo[3][5] , \txfifo[3][4] ,
         \txfifo[3][3] , \txfifo[3][2] , \txfifo[3][1] , \txfifo[3][0] ,
         \txfifo[2][7] , \txfifo[2][6] , \txfifo[2][5] , \txfifo[2][4] ,
         \txfifo[2][3] , \txfifo[2][2] , \txfifo[2][1] , \txfifo[2][0] ,
         \txfifo[1][7] , \txfifo[1][6] , \txfifo[1][5] , \txfifo[1][4] ,
         \txfifo[1][3] , \txfifo[1][2] , \txfifo[1][1] , \txfifo[1][0] ,
         \txfifo[0][7] , \txfifo[0][6] , \txfifo[0][5] , \txfifo[0][4] ,
         \txfifo[0][3] , \txfifo[0][2] , \txfifo[0][1] , \txfifo[0][0] , N291,
         n5, n8, n131, n132, n133, n134, n135, n136, n137, n138, n139, n140,
         n141, n142, n143, n144, n145, n146, n147, n148, n149, n150, n151,
         n152, n153, n154, n155, n156, n157, n158, n159, n160, n161, n162,
         n163, n164, n165, n166, n167, n168, n169, n170, n171, n172, n173,
         n174, n175, n176, n177, n178, n179, n180, n181, n182, n183, n184,
         n185, n186, n187, n188, n189, n190, n191, n192, n193, n194, n195,
         n196, n197, n198, n199, n200, n201, n202, n203, n204, n205, n206,
         n207, n208, n209, n210, n211, n212, n213, n214, n249, n250, n251,
         n254, n256, n257, n258, n259, n260, n262, n263, n264, n265, n267,
         n268, n269, n270, n271, n272, n273, n274, n276, n277, n278, n279,
         n280, n283, n285, n289, n293, n294, n295, n296, n297, n304, n308,
         n309, n310, n311, n312, n319, n323, n324, n325, n326, n327, n334,
         n338, n339, n340, n341, n342, n349, n353, n354, n355, n356, n357,
         n364, n368, n369, n370, n371, n372, n379, n384, n385, n386, n388,
         n390, n392, n393, n395, n396, n398, n399, n400, n401, n402, n403,
         n405, n407, n408, n409, n410, n411, n412, n413, n414, n415, n416,
         n417, n418, n419, n422, n423, n424, n425, n427, n428, n429, n430,
         n431, n432, n434, n435, n436, n437, n439, n440, n441, n443, n445,
         n446, n447, n448, n451, n452, n453, n455, n456, n457, n458, n459,
         n460, n461, n462, n463, n464, n465, n466, n467, n469, n474, n476,
         n477, n478, n479, n482, n484, n485, n487, n488, n489, n490, n491,
         n492, n494, n495, n497, n498, n500, n501, n502, n503, n504, n505,
         n506, n507, n508, n509, n510, n511, n512, n513, n514, n515, n516,
         n517, n518, n519, n520, n521, n522, n523, n524, n525, n526, n527,
         n528, n529, n530, n531, n532, n533, n534, n535, n536, n537, n538,
         n539, n540, n541, n542, n543, n544, n545, n546, n548, n549, n550,
         n551, n552, n553, n554, n555, n556, n557, n558, n559, n560, n561,
         n562, n563, n564, n565, n566, n567, n568, n569, n570, n571, n572,
         n573, n574, n575, n576, n577, n578, n579, n580, n581, n582, n583,
         n584, n585, n586, n587, n588, n589, n590, n591, n592, n593, n594;
  wire   [3:0] txclkcnt;
  wire   [2:0] fifo_wrpos;

  AOI31X1 U643 ( .A0(N72), .A1(n504), .A2(n354), .B0(n355), .Y(n353) );
  AOI211X1 U644 ( .A0(n356), .A1(n357), .B0(fifordb), .C0(N72), .Y(n355) );
  AOI31X1 U645 ( .A0(N72), .A1(n504), .A2(n324), .B0(n325), .Y(n323) );
  AOI211X1 U646 ( .A0(n326), .A1(n327), .B0(fifordb), .C0(N72), .Y(n325) );
  AOI31X1 U647 ( .A0(N72), .A1(n504), .A2(n369), .B0(n370), .Y(n368) );
  AOI31X1 U648 ( .A0(N72), .A1(n504), .A2(n339), .B0(n340), .Y(n338) );
  AOI211X1 U649 ( .A0(n341), .A1(n342), .B0(fifordb), .C0(N72), .Y(n340) );
  AOI31X1 U650 ( .A0(N72), .A1(n504), .A2(n309), .B0(n310), .Y(n308) );
  AOI211X1 U651 ( .A0(n311), .A1(n312), .B0(fifordb), .C0(N72), .Y(n310) );
  INVX1 U652 ( .A(n436), .Y(n437) );
  INVX1 U653 ( .A(n434), .Y(n435) );
  INVX1 U654 ( .A(n431), .Y(n432) );
  INVX1 U655 ( .A(n429), .Y(n430) );
  INVX1 U656 ( .A(n427), .Y(n428) );
  INVX1 U657 ( .A(n424), .Y(n425) );
  INVX1 U658 ( .A(n422), .Y(n423) );
  INVX1 U659 ( .A(n418), .Y(n419) );
  INVX1 U660 ( .A(fifowrb), .Y(n408) );
  NAND2BX1 U661 ( .AN(n455), .B(n459), .Y(N107) );
  INVX1 U662 ( .A(N114), .Y(n459) );
  NAND3BX1 U663 ( .AN(n594), .B(n513), .C(n588), .Y(n436) );
  NAND3BX1 U664 ( .AN(n594), .B(n593), .C(n588), .Y(n434) );
  NAND3BX1 U665 ( .AN(n594), .B(n513), .C(n589), .Y(n431) );
  NAND3BX1 U666 ( .AN(n594), .B(n593), .C(n589), .Y(n429) );
  NAND3BX1 U667 ( .AN(n593), .B(n594), .C(n588), .Y(n427) );
  NAND3BX1 U668 ( .AN(n506), .B(n593), .C(n588), .Y(n424) );
  NAND3BX1 U669 ( .AN(n593), .B(n594), .C(n589), .Y(n422) );
  NAND3BX1 U670 ( .AN(n506), .B(n593), .C(n589), .Y(n418) );
  AO22X1 U671 ( .A0(n405), .A1(n399), .B0(n403), .B1(n513), .Y(n400) );
  INVX1 U672 ( .A(n405), .Y(n403) );
  OR2X1 U673 ( .A(N112), .B(n460), .Y(N108) );
  AO22X1 U674 ( .A0(n412), .A1(n399), .B0(n411), .B1(n592), .Y(n409) );
  OAI221X1 U675 ( .A0(uarten), .A1(n484), .B0(txfifo_emptyb), .B1(n484), .C0(
        n399), .Y(N114) );
  INVX1 U676 ( .A(n457), .Y(n484) );
  NAND3BX1 U677 ( .AN(n462), .B(n461), .C(n474), .Y(N106) );
  INVX1 U678 ( .A(N108), .Y(n474) );
  NAND2BX1 U679 ( .AN(n457), .B(n459), .Y(N112) );
  INVX1 U680 ( .A(n412), .Y(n411) );
  AO21X1 U681 ( .A0(n455), .A1(n399), .B0(N115), .Y(N113) );
  AO21X1 U682 ( .A0(n593), .A1(n592), .B0(n591), .Y(txfifocnt[0]) );
  DFFRX1 fifofull_reg ( .D(n195), .CK(clk), .RN(rstb), .Q(txfifocnt[3]), .QN(
        txfifo_fullb) );
  AO21X1 U683 ( .A0(n392), .A1(n503), .B0(n396), .Y(n393) );
  NAND4BX1 U684 ( .AN(n460), .B(n458), .C(n446), .D(n461), .Y(n455) );
  INVX1 U685 ( .A(n283), .Y(n271) );
  INVX1 U686 ( .A(n285), .Y(n270) );
  AO21X1 U687 ( .A0(n392), .A1(n554), .B0(n393), .Y(n384) );
  INVX1 U688 ( .A(n386), .Y(n392) );
  INVX1 U689 ( .A(txfifocnt[1]), .Y(n416) );
  INVX1 U690 ( .A(n398), .Y(n396) );
  INVX1 U691 ( .A(n274), .Y(n267) );
  OAI31X1 U692 ( .A0(n257), .A1(n258), .A2(n259), .B0(n260), .Y(n213) );
  INVX1 U693 ( .A(n262), .Y(n258) );
  INVX1 U694 ( .A(n263), .Y(n259) );
  OA22X1 U695 ( .A0(n514), .A1(n262), .B0(n263), .B1(n514), .Y(n260) );
  NAND2BX1 U696 ( .AN(n504), .B(n262), .Y(n263) );
  NOR2BX1 U697 ( .AN(n399), .B(n446), .Y(N126) );
  NOR2BX1 U698 ( .AN(n399), .B(n458), .Y(N110) );
  NOR2BX1 U699 ( .AN(n399), .B(n445), .Y(N127) );
  INVX1 U700 ( .A(n443), .Y(n452) );
  INVX1 U701 ( .A(n440), .Y(n451) );
  OAI32X1 U702 ( .A0(n440), .A1(n441), .A2(n501), .B0(n443), .B1(n507), .Y(
        N128) );
  INVX1 U703 ( .A(n453), .Y(n461) );
  INVX1 U704 ( .A(n462), .Y(n446) );
  INVX1 U705 ( .A(n447), .Y(n466) );
  INVX1 U706 ( .A(txfifo_emptyb), .Y(txfifo_fillb) );
  NAND3BX1 U707 ( .AN(txfifocnt[3]), .B(n408), .C(n399), .Y(n405) );
  AND2X2 U708 ( .A(n590), .B(n408), .Y(n588) );
  AO22X1 U709 ( .A0(\txfifo[7][0] ), .A1(n418), .B0(fifodata_tx[0]), .B1(n419), 
        .Y(n187) );
  AO22X1 U710 ( .A0(\txfifo[7][1] ), .A1(n418), .B0(fifodata_tx[1]), .B1(n419), 
        .Y(n188) );
  AO22X1 U711 ( .A0(\txfifo[7][2] ), .A1(n418), .B0(fifodata_tx[2]), .B1(n419), 
        .Y(n189) );
  AO22X1 U712 ( .A0(\txfifo[7][3] ), .A1(n418), .B0(fifodata_tx[3]), .B1(n419), 
        .Y(n190) );
  AO22X1 U713 ( .A0(\txfifo[7][4] ), .A1(n418), .B0(fifodata_tx[4]), .B1(n419), 
        .Y(n191) );
  AO22X1 U714 ( .A0(\txfifo[7][5] ), .A1(n418), .B0(fifodata_tx[5]), .B1(n419), 
        .Y(n192) );
  AO22X1 U715 ( .A0(\txfifo[7][6] ), .A1(n418), .B0(fifodata_tx[6]), .B1(n419), 
        .Y(n193) );
  AO22X1 U716 ( .A0(\txfifo[7][7] ), .A1(n418), .B0(fifodata_tx[7]), .B1(n419), 
        .Y(n194) );
  AO22X1 U717 ( .A0(\txfifo[0][0] ), .A1(n436), .B0(n437), .B1(fifodata_tx[0]), 
        .Y(n131) );
  AO22X1 U718 ( .A0(\txfifo[0][1] ), .A1(n436), .B0(n437), .B1(fifodata_tx[1]), 
        .Y(n132) );
  AO22X1 U719 ( .A0(\txfifo[0][2] ), .A1(n436), .B0(n437), .B1(fifodata_tx[2]), 
        .Y(n133) );
  AO22X1 U720 ( .A0(\txfifo[0][3] ), .A1(n436), .B0(n437), .B1(fifodata_tx[3]), 
        .Y(n134) );
  AO22X1 U721 ( .A0(\txfifo[0][4] ), .A1(n436), .B0(n437), .B1(fifodata_tx[4]), 
        .Y(n135) );
  AO22X1 U722 ( .A0(\txfifo[0][5] ), .A1(n436), .B0(n437), .B1(fifodata_tx[5]), 
        .Y(n136) );
  AO22X1 U723 ( .A0(\txfifo[0][6] ), .A1(n436), .B0(n437), .B1(fifodata_tx[6]), 
        .Y(n137) );
  AO22X1 U724 ( .A0(\txfifo[0][7] ), .A1(n436), .B0(n437), .B1(fifodata_tx[7]), 
        .Y(n138) );
  AO22X1 U725 ( .A0(\txfifo[1][0] ), .A1(n434), .B0(n435), .B1(fifodata_tx[0]), 
        .Y(n139) );
  AO22X1 U726 ( .A0(\txfifo[1][1] ), .A1(n434), .B0(n435), .B1(fifodata_tx[1]), 
        .Y(n140) );
  AO22X1 U727 ( .A0(\txfifo[1][2] ), .A1(n434), .B0(n435), .B1(fifodata_tx[2]), 
        .Y(n141) );
  AO22X1 U728 ( .A0(\txfifo[1][3] ), .A1(n434), .B0(n435), .B1(fifodata_tx[3]), 
        .Y(n142) );
  AO22X1 U729 ( .A0(\txfifo[1][4] ), .A1(n434), .B0(n435), .B1(fifodata_tx[4]), 
        .Y(n143) );
  AO22X1 U730 ( .A0(\txfifo[1][5] ), .A1(n434), .B0(n435), .B1(fifodata_tx[5]), 
        .Y(n144) );
  AO22X1 U731 ( .A0(\txfifo[1][6] ), .A1(n434), .B0(n435), .B1(fifodata_tx[6]), 
        .Y(n145) );
  AO22X1 U732 ( .A0(\txfifo[1][7] ), .A1(n434), .B0(n435), .B1(fifodata_tx[7]), 
        .Y(n146) );
  AO22X1 U733 ( .A0(\txfifo[2][0] ), .A1(n431), .B0(n432), .B1(fifodata_tx[0]), 
        .Y(n147) );
  AO22X1 U734 ( .A0(\txfifo[2][1] ), .A1(n431), .B0(n432), .B1(fifodata_tx[1]), 
        .Y(n148) );
  AO22X1 U735 ( .A0(\txfifo[2][2] ), .A1(n431), .B0(n432), .B1(fifodata_tx[2]), 
        .Y(n149) );
  AO22X1 U736 ( .A0(\txfifo[2][3] ), .A1(n431), .B0(n432), .B1(fifodata_tx[3]), 
        .Y(n150) );
  AO22X1 U737 ( .A0(\txfifo[2][4] ), .A1(n431), .B0(n432), .B1(fifodata_tx[4]), 
        .Y(n151) );
  AO22X1 U738 ( .A0(\txfifo[2][5] ), .A1(n431), .B0(n432), .B1(fifodata_tx[5]), 
        .Y(n152) );
  AO22X1 U739 ( .A0(\txfifo[2][6] ), .A1(n431), .B0(n432), .B1(fifodata_tx[6]), 
        .Y(n153) );
  AO22X1 U740 ( .A0(\txfifo[2][7] ), .A1(n431), .B0(n432), .B1(fifodata_tx[7]), 
        .Y(n154) );
  AO22X1 U741 ( .A0(\txfifo[3][0] ), .A1(n429), .B0(n430), .B1(fifodata_tx[0]), 
        .Y(n155) );
  AO22X1 U742 ( .A0(\txfifo[3][1] ), .A1(n429), .B0(n430), .B1(fifodata_tx[1]), 
        .Y(n156) );
  AO22X1 U743 ( .A0(\txfifo[3][2] ), .A1(n429), .B0(n430), .B1(fifodata_tx[2]), 
        .Y(n157) );
  AO22X1 U744 ( .A0(\txfifo[3][3] ), .A1(n429), .B0(n430), .B1(fifodata_tx[3]), 
        .Y(n158) );
  AO22X1 U745 ( .A0(\txfifo[3][4] ), .A1(n429), .B0(n430), .B1(fifodata_tx[4]), 
        .Y(n159) );
  AO22X1 U746 ( .A0(\txfifo[3][5] ), .A1(n429), .B0(n430), .B1(fifodata_tx[5]), 
        .Y(n160) );
  AO22X1 U747 ( .A0(\txfifo[3][6] ), .A1(n429), .B0(n430), .B1(fifodata_tx[6]), 
        .Y(n161) );
  AO22X1 U748 ( .A0(\txfifo[3][7] ), .A1(n429), .B0(n430), .B1(fifodata_tx[7]), 
        .Y(n162) );
  AO22X1 U749 ( .A0(\txfifo[4][0] ), .A1(n427), .B0(n428), .B1(fifodata_tx[0]), 
        .Y(n163) );
  AO22X1 U750 ( .A0(\txfifo[4][1] ), .A1(n427), .B0(n428), .B1(fifodata_tx[1]), 
        .Y(n164) );
  AO22X1 U751 ( .A0(\txfifo[4][2] ), .A1(n427), .B0(n428), .B1(fifodata_tx[2]), 
        .Y(n165) );
  AO22X1 U752 ( .A0(\txfifo[4][3] ), .A1(n427), .B0(n428), .B1(fifodata_tx[3]), 
        .Y(n166) );
  AO22X1 U753 ( .A0(\txfifo[4][4] ), .A1(n427), .B0(n428), .B1(fifodata_tx[4]), 
        .Y(n167) );
  AO22X1 U754 ( .A0(\txfifo[4][5] ), .A1(n427), .B0(n428), .B1(fifodata_tx[5]), 
        .Y(n168) );
  AO22X1 U755 ( .A0(\txfifo[4][6] ), .A1(n427), .B0(n428), .B1(fifodata_tx[6]), 
        .Y(n169) );
  AO22X1 U756 ( .A0(\txfifo[4][7] ), .A1(n427), .B0(n428), .B1(fifodata_tx[7]), 
        .Y(n170) );
  AO22X1 U757 ( .A0(\txfifo[5][0] ), .A1(n424), .B0(n425), .B1(fifodata_tx[0]), 
        .Y(n171) );
  AO22X1 U758 ( .A0(\txfifo[5][1] ), .A1(n424), .B0(n425), .B1(fifodata_tx[1]), 
        .Y(n172) );
  AO22X1 U759 ( .A0(\txfifo[5][2] ), .A1(n424), .B0(n425), .B1(fifodata_tx[2]), 
        .Y(n173) );
  AO22X1 U760 ( .A0(\txfifo[5][3] ), .A1(n424), .B0(n425), .B1(fifodata_tx[3]), 
        .Y(n174) );
  AO22X1 U761 ( .A0(\txfifo[5][4] ), .A1(n424), .B0(n425), .B1(fifodata_tx[4]), 
        .Y(n175) );
  AO22X1 U762 ( .A0(\txfifo[5][5] ), .A1(n424), .B0(n425), .B1(fifodata_tx[5]), 
        .Y(n176) );
  AO22X1 U763 ( .A0(\txfifo[5][6] ), .A1(n424), .B0(n425), .B1(fifodata_tx[6]), 
        .Y(n177) );
  AO22X1 U764 ( .A0(\txfifo[5][7] ), .A1(n424), .B0(n425), .B1(fifodata_tx[7]), 
        .Y(n178) );
  AO22X1 U765 ( .A0(\txfifo[6][0] ), .A1(n422), .B0(n423), .B1(fifodata_tx[0]), 
        .Y(n179) );
  AO22X1 U766 ( .A0(\txfifo[6][1] ), .A1(n422), .B0(n423), .B1(fifodata_tx[1]), 
        .Y(n180) );
  AO22X1 U767 ( .A0(\txfifo[6][2] ), .A1(n422), .B0(n423), .B1(fifodata_tx[2]), 
        .Y(n181) );
  AO22X1 U768 ( .A0(\txfifo[6][3] ), .A1(n422), .B0(n423), .B1(fifodata_tx[3]), 
        .Y(n182) );
  AO22X1 U769 ( .A0(\txfifo[6][4] ), .A1(n422), .B0(n423), .B1(fifodata_tx[4]), 
        .Y(n183) );
  AO22X1 U770 ( .A0(\txfifo[6][5] ), .A1(n422), .B0(n423), .B1(fifodata_tx[5]), 
        .Y(n184) );
  AO22X1 U771 ( .A0(\txfifo[6][6] ), .A1(n422), .B0(n423), .B1(fifodata_tx[6]), 
        .Y(n185) );
  AO22X1 U772 ( .A0(\txfifo[6][7] ), .A1(n422), .B0(n423), .B1(fifodata_tx[7]), 
        .Y(n186) );
  NOR2X1 U773 ( .A(fifowrb), .B(n590), .Y(n589) );
  OAI2BB1X1 U774 ( .A0N(n594), .A1N(n400), .B0(n401), .Y(n201) );
  AOI33X1 U775 ( .A0(n402), .A1(n593), .A2(n403), .B0(n594), .B1(n590), .B2(
        n403), .Y(n401) );
  NOR2BX1 U776 ( .AN(fifo_wrpos[1]), .B(n594), .Y(n402) );
  OAI32X1 U777 ( .A0(n403), .A1(swrst), .A2(n513), .B0(n593), .B1(n405), .Y(
        n199) );
  OAI32X1 U778 ( .A0(n405), .A1(fifo_wrpos[1]), .A2(n513), .B0(n407), .B1(n590), .Y(n200) );
  INVX1 U779 ( .A(n400), .Y(n407) );
  OAI31X1 U780 ( .A0(n414), .A1(n415), .A2(n416), .B0(n417), .Y(n195) );
  INVX1 U781 ( .A(txfifocnt[2]), .Y(n414) );
  NAND4BX1 U782 ( .AN(n504), .B(txfifocnt[0]), .C(n408), .D(n399), .Y(n415) );
  OAI211X1 U783 ( .A0(fifordb), .A1(n408), .B0(txfifocnt[3]), .C0(n399), .Y(
        n417) );
  NAND2BX1 U784 ( .AN(n489), .B(n490), .Y(txfifocnt[2]) );
  OAI33X1 U785 ( .A0(n491), .A1(n594), .A2(n544), .B0(n491), .B1(N74), .B2(
        n506), .Y(n489) );
  AOI33X1 U786 ( .A0(n544), .A1(n506), .A2(n491), .B0(N74), .B1(n594), .B2(
        n491), .Y(n490) );
  INVX1 U787 ( .A(n492), .Y(n491) );
  NAND4BX1 U788 ( .AN(txfifocnt[2]), .B(txfifo_fullb), .C(n416), .D(n485), .Y(
        txfifo_emptyb) );
  INVX1 U789 ( .A(txfifocnt[0]), .Y(n485) );
  NAND3BX1 U790 ( .AN(swrst), .B(n504), .C(txfifo_emptyb), .Y(n412) );
  OAI222X1 U791 ( .A0(n591), .A1(n590), .B0(N73), .B1(n591), .C0(N73), .C1(
        n590), .Y(n492) );
  BUFX2 U792 ( .A(fifo_wrpos[0]), .Y(n593) );
  OAI2BB1X1 U793 ( .A0N(N74), .A1N(n409), .B0(n410), .Y(n198) );
  AOI32X1 U794 ( .A0(n271), .A1(N72), .A2(n411), .B0(n411), .B1(n270), .Y(n410) );
  INVX1 U795 ( .A(n456), .Y(N115) );
  NAND4BX1 U796 ( .AN(swrst), .B(uarten), .C(n457), .D(txfifo_emptyb), .Y(n456) );
  OAI32X1 U797 ( .A0(n411), .A1(swrst), .A2(n592), .B0(N72), .B1(n412), .Y(
        n196) );
  OAI32X1 U798 ( .A0(n412), .A1(N73), .A2(n592), .B0(n413), .B1(n505), .Y(n197) );
  INVX1 U799 ( .A(n409), .Y(n413) );
  NOR2X1 U800 ( .A(n593), .B(n592), .Y(n591) );
  NAND2BX1 U801 ( .AN(N74), .B(N73), .Y(n283) );
  NAND2BX1 U802 ( .AN(N73), .B(N74), .Y(n285) );
  NAND2BX1 U803 ( .AN(N74), .B(n505), .Y(n274) );
  NAND2BX1 U804 ( .AN(n544), .B(N73), .Y(n273) );
  NAND2BX1 U805 ( .AN(n487), .B(n488), .Y(txfifocnt[1]) );
  OAI33X1 U806 ( .A0(n591), .A1(fifo_wrpos[1]), .A2(n505), .B0(n591), .B1(N73), 
        .B2(n590), .Y(n487) );
  AOI33X1 U807 ( .A0(n505), .A1(n590), .A2(n591), .B0(N73), .B1(fifo_wrpos[1]), 
        .B2(n591), .Y(n488) );
  NAND3BX1 U808 ( .AN(baudx16clk), .B(n545), .C(n399), .Y(n398) );
  NAND3BX1 U809 ( .AN(swrst), .B(n545), .C(n398), .Y(n386) );
  NAND3BX1 U810 ( .AN(n554), .B(txclkcnt[0]), .C(n392), .Y(n388) );
  OAI31X1 U811 ( .A0(n500), .A1(stopbit), .A2(n501), .B0(n494), .Y(n457) );
  OA21X2 U812 ( .A0(n500), .A1(n507), .B0(n8), .Y(n494) );
  NAND2BX1 U813 ( .AN(n476), .B(n445), .Y(n460) );
  OAI211X1 U814 ( .A0(txclk), .A1(n507), .B0(n565), .C0(n482), .Y(n476) );
  OA22X1 U815 ( .A0(n501), .A1(n441), .B0(txclk), .B1(n548), .Y(n482) );
  OR2X1 U816 ( .A(parity[0]), .B(parity[1]), .Y(n478) );
  INVX1 U817 ( .A(swrst), .Y(n399) );
  OAI211X1 U818 ( .A0(n249), .A1(n250), .B0(n5), .C0(n251), .Y(txd) );
  NAND2BX1 U819 ( .AN(n549), .B(parity_int), .Y(n250) );
  AOI32X1 U820 ( .A0(n497), .A1(n546), .A2(n249), .B0(shiftreg_0_), .B1(n498), 
        .Y(n251) );
  NAND2BX1 U821 ( .AN(parity[0]), .B(parity[1]), .Y(n249) );
  BUFX2 U822 ( .A(fifo_wrpos[2]), .Y(n594) );
  OA22X1 U823 ( .A0(N72), .A1(n264), .B0(n265), .B1(n592), .Y(n257) );
  AOI221X1 U824 ( .A0(\txfifo[0][7] ), .A1(n267), .B0(\txfifo[6][7] ), .B1(
        n268), .C0(n272), .Y(n264) );
  AOI221X1 U825 ( .A0(\txfifo[1][7] ), .A1(n267), .B0(\txfifo[7][7] ), .B1(
        n268), .C0(n269), .Y(n265) );
  INVX1 U826 ( .A(n273), .Y(n268) );
  OA22X1 U827 ( .A0(n283), .A1(n527), .B0(n285), .B1(n571), .Y(n356) );
  OA22X1 U828 ( .A0(n283), .A1(n528), .B0(n285), .B1(n572), .Y(n341) );
  OA22X1 U829 ( .A0(n283), .A1(n529), .B0(n285), .B1(n573), .Y(n326) );
  OA22X1 U830 ( .A0(n283), .A1(n530), .B0(n285), .B1(n574), .Y(n311) );
  OA22X1 U831 ( .A0(n283), .A1(n531), .B0(n285), .B1(n575), .Y(n296) );
  OA22X1 U832 ( .A0(n283), .A1(n532), .B0(n285), .B1(n576), .Y(n279) );
  AOI211X1 U833 ( .A0(n371), .A1(n372), .B0(fifordb), .C0(N72), .Y(n370) );
  OA22X1 U834 ( .A0(n274), .A1(n534), .B0(n273), .B1(n578), .Y(n372) );
  OA22X1 U835 ( .A0(n283), .A1(n533), .B0(n285), .B1(n577), .Y(n371) );
  OA22X1 U836 ( .A0(n283), .A1(n535), .B0(n285), .B1(n579), .Y(n379) );
  OA22X1 U837 ( .A0(n283), .A1(n536), .B0(n285), .B1(n580), .Y(n364) );
  OA22X1 U838 ( .A0(n283), .A1(n537), .B0(n285), .B1(n581), .Y(n349) );
  OA22X1 U839 ( .A0(n283), .A1(n538), .B0(n285), .B1(n582), .Y(n334) );
  OA22X1 U840 ( .A0(n283), .A1(n539), .B0(n285), .B1(n583), .Y(n319) );
  OA22X1 U841 ( .A0(n283), .A1(n540), .B0(n285), .B1(n584), .Y(n304) );
  OA22X1 U842 ( .A0(n283), .A1(n541), .B0(n285), .B1(n585), .Y(n289) );
  OA22X1 U843 ( .A0(n274), .A1(n567), .B0(n273), .B1(n509), .Y(n357) );
  OA22X1 U844 ( .A0(n274), .A1(n568), .B0(n273), .B1(n510), .Y(n342) );
  OA22X1 U845 ( .A0(n274), .A1(n569), .B0(n273), .B1(n511), .Y(n327) );
  OA22X1 U846 ( .A0(n274), .A1(n570), .B0(n273), .B1(n512), .Y(n312) );
  OA22X1 U847 ( .A0(n274), .A1(n542), .B0(n273), .B1(n586), .Y(n297) );
  OA22X1 U848 ( .A0(n274), .A1(n543), .B0(n273), .B1(n587), .Y(n280) );
  AO22X1 U849 ( .A0(txclkcnt[2]), .A1(n384), .B0(n390), .B1(n518), .Y(n204) );
  INVX1 U850 ( .A(n388), .Y(n390) );
  AO22X1 U851 ( .A0(\txfifo[5][7] ), .A1(n270), .B0(\txfifo[3][7] ), .B1(n271), 
        .Y(n269) );
  AO22X1 U852 ( .A0(\txfifo[4][7] ), .A1(n270), .B0(\txfifo[2][7] ), .B1(n271), 
        .Y(n272) );
  OAI32X1 U853 ( .A0(n386), .A1(txclkcnt[1]), .A2(n503), .B0(n395), .B1(n554), 
        .Y(n203) );
  INVX1 U854 ( .A(n393), .Y(n395) );
  OAI221X1 U855 ( .A0(n557), .A1(n263), .B0(n262), .B1(n515), .C0(n368), .Y(
        n206) );
  OAI221X1 U856 ( .A0(n274), .A1(n519), .B0(n273), .B1(n558), .C0(n379), .Y(
        n369) );
  OAI221X1 U857 ( .A0(n263), .A1(n515), .B0(n262), .B1(n551), .C0(n353), .Y(
        n207) );
  OAI221X1 U858 ( .A0(n274), .A1(n520), .B0(n273), .B1(n559), .C0(n364), .Y(
        n354) );
  OAI221X1 U859 ( .A0(n263), .A1(n551), .B0(n262), .B1(n516), .C0(n338), .Y(
        n208) );
  OAI221X1 U860 ( .A0(n274), .A1(n521), .B0(n273), .B1(n560), .C0(n349), .Y(
        n339) );
  OAI221X1 U861 ( .A0(n263), .A1(n516), .B0(n262), .B1(n552), .C0(n323), .Y(
        n209) );
  OAI221X1 U862 ( .A0(n274), .A1(n522), .B0(n273), .B1(n561), .C0(n334), .Y(
        n324) );
  OAI221X1 U863 ( .A0(n263), .A1(n552), .B0(n262), .B1(n517), .C0(n308), .Y(
        n210) );
  OAI221X1 U864 ( .A0(n274), .A1(n523), .B0(n273), .B1(n562), .C0(n319), .Y(
        n309) );
  OAI221X1 U865 ( .A0(n263), .A1(n517), .B0(n262), .B1(n553), .C0(n293), .Y(
        n211) );
  AOI31X1 U866 ( .A0(N72), .A1(n504), .A2(n294), .B0(n295), .Y(n293) );
  OAI221X1 U867 ( .A0(n274), .A1(n524), .B0(n273), .B1(n563), .C0(n304), .Y(
        n294) );
  AOI211X1 U868 ( .A0(n296), .A1(n297), .B0(fifordb), .C0(N72), .Y(n295) );
  OAI221X1 U869 ( .A0(n263), .A1(n553), .B0(n514), .B1(n262), .C0(n276), .Y(
        n212) );
  AOI31X1 U870 ( .A0(N72), .A1(n504), .A2(n277), .B0(n278), .Y(n276) );
  OAI221X1 U871 ( .A0(n274), .A1(n525), .B0(n273), .B1(n564), .C0(n289), .Y(
        n277) );
  AOI211X1 U872 ( .A0(n279), .A1(n280), .B0(fifordb), .C0(N72), .Y(n278) );
  AO21X1 U873 ( .A0(txclkcnt[3]), .A1(n384), .B0(n385), .Y(n205) );
  OAI33X1 U874 ( .A0(n386), .A1(txclkcnt[2]), .A2(n555), .B0(n388), .B1(
        txclkcnt[3]), .B2(n518), .Y(n385) );
  INVX1 U875 ( .A(n477), .Y(n445) );
  OAI31X1 U876 ( .A0(n500), .A1(n502), .A2(n478), .B0(n479), .Y(n477) );
  OA22X1 U877 ( .A0(n500), .A1(n556), .B0(txclk), .B1(n501), .Y(n479) );
  NAND3BX1 U878 ( .AN(shiftenb), .B(fifordb), .C(txclk), .Y(n262) );
  NAND2BX1 U879 ( .AN(swrst), .B(txclk), .Y(n440) );
  NAND2BX1 U880 ( .AN(swrst), .B(n500), .Y(n443) );
  AO22X1 U881 ( .A0(current_state_3_), .A1(n500), .B0(current_state_2_), .B1(
        txclk), .Y(n453) );
  OAI32X1 U882 ( .A0(n500), .A1(n495), .A2(n502), .B0(txclk), .B1(n556), .Y(
        n462) );
  INVX1 U883 ( .A(n478), .Y(n495) );
  OAI31X1 U884 ( .A0(n500), .A1(databit), .A2(n550), .B0(n467), .Y(n447) );
  OA22X1 U885 ( .A0(txclk), .A1(n502), .B0(n500), .B1(n508), .Y(n467) );
  NOR2BX1 U886 ( .AN(n447), .B(swrst), .Y(N125) );
  NOR2BX1 U887 ( .AN(n453), .B(swrst), .Y(N117) );
  OR3X2 U888 ( .A(current_state_9_), .B(current_state_8_), .C(current_state_7_), .Y(n469) );
  INVX1 U889 ( .A(n463), .Y(n458) );
  NAND3BX1 U890 ( .AN(n464), .B(n465), .C(n466), .Y(n463) );
  NAND3BX1 U891 ( .AN(n469), .B(n526), .C(n566), .Y(n464) );
  AOI211X1 U892 ( .A0(current_state_3_), .A1(txclk), .B0(current_state_4_), 
        .C0(current_state_10_), .Y(n465) );
  OAI33X1 U893 ( .A0(n254), .A1(n504), .A2(n546), .B0(n256), .B1(parity_int), 
        .B2(n504), .Y(n214) );
  INVX1 U894 ( .A(n256), .Y(n254) );
  NAND3BX1 U895 ( .AN(shiftenb), .B(dtxclk), .C(shiftreg_0_), .Y(n256) );
  AO22X1 U896 ( .A0(n396), .A1(txclkcnt[0]), .B0(n392), .B1(n503), .Y(n202) );
  AO22X1 U897 ( .A0(current_state_8_), .A1(n451), .B0(current_state_9_), .B1(
        n452), .Y(N123) );
  AO22X1 U898 ( .A0(current_state_7_), .A1(n451), .B0(current_state_8_), .B1(
        n452), .Y(N122) );
  AO22X1 U899 ( .A0(current_state_6_), .A1(n451), .B0(current_state_7_), .B1(
        n452), .Y(N121) );
  AO22X1 U900 ( .A0(current_state_5_), .A1(n451), .B0(current_state_6_), .B1(
        n452), .Y(N120) );
  AO22X1 U901 ( .A0(current_state_4_), .A1(n451), .B0(current_state_5_), .B1(
        n452), .Y(N119) );
  AO22X1 U902 ( .A0(current_state_3_), .A1(n451), .B0(current_state_4_), .B1(
        n452), .Y(N118) );
  AO22X1 U903 ( .A0(current_state_1_), .A1(n399), .B0(current_state_2_), .B1(
        n452), .Y(N116) );
  AND4X1 U904 ( .A(baudx16clk), .B(n545), .C(txclkcnt[1]), .D(n439), .Y(N291)
         );
  AND4X1 U905 ( .A(n399), .B(n503), .C(n518), .D(n555), .Y(n439) );
  OAI32X1 U906 ( .A0(n440), .A1(n448), .A2(n550), .B0(n443), .B1(n508), .Y(
        N124) );
  INVX1 U907 ( .A(databit), .Y(n448) );
  INVX1 U908 ( .A(stopbit), .Y(n441) );
  DFFRX1 fifo_rdpos_reg_0_ ( .D(n196), .CK(clk), .RN(rstb), .Q(N72), .QN(n592)
         );
  DFFRX1 fifo_rdpos_reg_1_ ( .D(n197), .CK(clk), .RN(rstb), .Q(N73), .QN(n505)
         );
  DFFRX1 fifo_wrpos_reg_1_ ( .D(n200), .CK(clk), .RN(rstb), .Q(fifo_wrpos[1]), 
        .QN(n590) );
  DFFRX1 fifo_wrpos_reg_0_ ( .D(n199), .CK(clk), .RN(rstb), .Q(fifo_wrpos[0]), 
        .QN(n513) );
  DFFRX1 txclk_reg ( .D(N291), .CK(clk), .RN(rstb), .Q(txclk), .QN(n500) );
  DFFRX1 fifo_rdpos_reg_2_ ( .D(n198), .CK(clk), .RN(rstb), .Q(N74), .QN(n544)
         );
  DFFRX1 shiftreg_reg_0_ ( .D(n206), .CK(clk), .RN(rstb), .Q(shiftreg_0_), 
        .QN(n557) );
  DFFRX1 parity_int_reg ( .D(n214), .CK(clk), .RN(rstb), .Q(parity_int), .QN(
        n546) );
  DFFRX1 txdoutsel_reg_3_ ( .D(N126), .CK(clk), .RN(rstb), .Q(n497), .QN(n549)
         );
  DFFRX1 current_state_reg_14_ ( .D(N128), .CK(clk), .RN(rstb), .QN(n507) );
  DFFRX1 current_state_reg_13_ ( .D(N127), .CK(clk), .RN(rstb), .QN(n501) );
  DFFRX1 fifo_wrpos_reg_2_ ( .D(n201), .CK(clk), .RN(rstb), .Q(fifo_wrpos[2]), 
        .QN(n506) );
  DFFSX1 txdoutsel_reg_0_ ( .D(N108), .CK(clk), .SN(rstb), .QN(n5) );
  DFFRX1 txdoutsel_reg_2_ ( .D(N110), .CK(clk), .RN(rstb), .Q(n498) );
  DFFSX1 fifordb_reg ( .D(N107), .CK(clk), .SN(rstb), .Q(fifordb), .QN(n504)
         );
  DFFRX1 txclkcnt_reg_0_ ( .D(n202), .CK(clk), .RN(rstb), .Q(txclkcnt[0]), 
        .QN(n503) );
  DFFRX1 txclkcnt_reg_1_ ( .D(n203), .CK(clk), .RN(rstb), .Q(txclkcnt[1]), 
        .QN(n554) );
  DFFRX1 current_state_reg_8_ ( .D(N122), .CK(clk), .RN(rstb), .Q(
        current_state_8_) );
  DFFRX1 current_state_reg_7_ ( .D(N121), .CK(clk), .RN(rstb), .Q(
        current_state_7_) );
  DFFRX1 current_state_reg_6_ ( .D(N120), .CK(clk), .RN(rstb), .Q(
        current_state_6_), .QN(n526) );
  DFFRX1 current_state_reg_5_ ( .D(N119), .CK(clk), .RN(rstb), .Q(
        current_state_5_), .QN(n566) );
  DFFRX1 current_state_reg_2_ ( .D(N116), .CK(clk), .RN(rstb), .Q(
        current_state_2_), .QN(n548) );
  DFFRX1 current_state_reg_9_ ( .D(N123), .CK(clk), .RN(rstb), .Q(
        current_state_9_), .QN(n550) );
  DFFRX1 txclkcnt_reg_2_ ( .D(n204), .CK(clk), .RN(rstb), .Q(txclkcnt[2]), 
        .QN(n518) );
  DFFRX1 txclkcnt_reg_3_ ( .D(n205), .CK(clk), .RN(rstb), .Q(txclkcnt[3]), 
        .QN(n555) );
  DFFRX1 txfifo_reg ( .D(n131), .CK(clk), .RN(rstb), .Q(\txfifo[0][0] ), .QN(
        n534) );
  DFFRX1 txfifo_reg0 ( .D(n132), .CK(clk), .RN(rstb), .Q(\txfifo[0][1] ), .QN(
        n567) );
  DFFRX1 txfifo_reg1 ( .D(n133), .CK(clk), .RN(rstb), .Q(\txfifo[0][2] ), .QN(
        n568) );
  DFFRX1 txfifo_reg2 ( .D(n134), .CK(clk), .RN(rstb), .Q(\txfifo[0][3] ), .QN(
        n569) );
  DFFRX1 txfifo_reg3 ( .D(n135), .CK(clk), .RN(rstb), .Q(\txfifo[0][4] ), .QN(
        n570) );
  DFFRX1 txfifo_reg4 ( .D(n136), .CK(clk), .RN(rstb), .Q(\txfifo[0][5] ), .QN(
        n542) );
  DFFRX1 txfifo_reg5 ( .D(n137), .CK(clk), .RN(rstb), .Q(\txfifo[0][6] ), .QN(
        n543) );
  DFFRX1 txfifo_reg6 ( .D(n139), .CK(clk), .RN(rstb), .Q(\txfifo[1][0] ), .QN(
        n519) );
  DFFRX1 txfifo_reg7 ( .D(n140), .CK(clk), .RN(rstb), .Q(\txfifo[1][1] ), .QN(
        n520) );
  DFFRX1 txfifo_reg8 ( .D(n141), .CK(clk), .RN(rstb), .Q(\txfifo[1][2] ), .QN(
        n521) );
  DFFRX1 txfifo_reg9 ( .D(n142), .CK(clk), .RN(rstb), .Q(\txfifo[1][3] ), .QN(
        n522) );
  DFFRX1 txfifo_reg10 ( .D(n143), .CK(clk), .RN(rstb), .Q(\txfifo[1][4] ), 
        .QN(n523) );
  DFFRX1 txfifo_reg11 ( .D(n144), .CK(clk), .RN(rstb), .Q(\txfifo[1][5] ), 
        .QN(n524) );
  DFFRX1 txfifo_reg12 ( .D(n145), .CK(clk), .RN(rstb), .Q(\txfifo[1][6] ), 
        .QN(n525) );
  DFFRX1 txfifo_reg13 ( .D(n147), .CK(clk), .RN(rstb), .Q(\txfifo[2][0] ), 
        .QN(n533) );
  DFFRX1 txfifo_reg14 ( .D(n148), .CK(clk), .RN(rstb), .Q(\txfifo[2][1] ), 
        .QN(n527) );
  DFFRX1 txfifo_reg15 ( .D(n149), .CK(clk), .RN(rstb), .Q(\txfifo[2][2] ), 
        .QN(n528) );
  DFFRX1 txfifo_reg16 ( .D(n150), .CK(clk), .RN(rstb), .Q(\txfifo[2][3] ), 
        .QN(n529) );
  DFFRX1 txfifo_reg17 ( .D(n151), .CK(clk), .RN(rstb), .Q(\txfifo[2][4] ), 
        .QN(n530) );
  DFFRX1 txfifo_reg18 ( .D(n152), .CK(clk), .RN(rstb), .Q(\txfifo[2][5] ), 
        .QN(n531) );
  DFFRX1 txfifo_reg19 ( .D(n153), .CK(clk), .RN(rstb), .Q(\txfifo[2][6] ), 
        .QN(n532) );
  DFFRX1 txfifo_reg20 ( .D(n155), .CK(clk), .RN(rstb), .Q(\txfifo[3][0] ), 
        .QN(n535) );
  DFFRX1 txfifo_reg21 ( .D(n156), .CK(clk), .RN(rstb), .Q(\txfifo[3][1] ), 
        .QN(n536) );
  DFFRX1 txfifo_reg22 ( .D(n157), .CK(clk), .RN(rstb), .Q(\txfifo[3][2] ), 
        .QN(n537) );
  DFFRX1 txfifo_reg23 ( .D(n158), .CK(clk), .RN(rstb), .Q(\txfifo[3][3] ), 
        .QN(n538) );
  DFFRX1 txfifo_reg24 ( .D(n159), .CK(clk), .RN(rstb), .Q(\txfifo[3][4] ), 
        .QN(n539) );
  DFFRX1 txfifo_reg25 ( .D(n160), .CK(clk), .RN(rstb), .Q(\txfifo[3][5] ), 
        .QN(n540) );
  DFFRX1 txfifo_reg26 ( .D(n161), .CK(clk), .RN(rstb), .Q(\txfifo[3][6] ), 
        .QN(n541) );
  DFFRX1 txfifo_reg27 ( .D(n163), .CK(clk), .RN(rstb), .Q(\txfifo[4][0] ), 
        .QN(n577) );
  DFFRX1 txfifo_reg28 ( .D(n164), .CK(clk), .RN(rstb), .Q(\txfifo[4][1] ), 
        .QN(n571) );
  DFFRX1 txfifo_reg29 ( .D(n165), .CK(clk), .RN(rstb), .Q(\txfifo[4][2] ), 
        .QN(n572) );
  DFFRX1 txfifo_reg30 ( .D(n166), .CK(clk), .RN(rstb), .Q(\txfifo[4][3] ), 
        .QN(n573) );
  DFFRX1 txfifo_reg31 ( .D(n167), .CK(clk), .RN(rstb), .Q(\txfifo[4][4] ), 
        .QN(n574) );
  DFFRX1 txfifo_reg32 ( .D(n168), .CK(clk), .RN(rstb), .Q(\txfifo[4][5] ), 
        .QN(n575) );
  DFFRX1 txfifo_reg33 ( .D(n169), .CK(clk), .RN(rstb), .Q(\txfifo[4][6] ), 
        .QN(n576) );
  DFFRX1 txfifo_reg34 ( .D(n171), .CK(clk), .RN(rstb), .Q(\txfifo[5][0] ), 
        .QN(n579) );
  DFFRX1 txfifo_reg35 ( .D(n172), .CK(clk), .RN(rstb), .Q(\txfifo[5][1] ), 
        .QN(n580) );
  DFFRX1 txfifo_reg36 ( .D(n173), .CK(clk), .RN(rstb), .Q(\txfifo[5][2] ), 
        .QN(n581) );
  DFFRX1 txfifo_reg37 ( .D(n174), .CK(clk), .RN(rstb), .Q(\txfifo[5][3] ), 
        .QN(n582) );
  DFFRX1 txfifo_reg38 ( .D(n175), .CK(clk), .RN(rstb), .Q(\txfifo[5][4] ), 
        .QN(n583) );
  DFFRX1 txfifo_reg39 ( .D(n176), .CK(clk), .RN(rstb), .Q(\txfifo[5][5] ), 
        .QN(n584) );
  DFFRX1 txfifo_reg40 ( .D(n177), .CK(clk), .RN(rstb), .Q(\txfifo[5][6] ), 
        .QN(n585) );
  DFFRX1 txfifo_reg41 ( .D(n179), .CK(clk), .RN(rstb), .Q(\txfifo[6][0] ), 
        .QN(n578) );
  DFFRX1 txfifo_reg42 ( .D(n180), .CK(clk), .RN(rstb), .Q(\txfifo[6][1] ), 
        .QN(n509) );
  DFFRX1 txfifo_reg43 ( .D(n181), .CK(clk), .RN(rstb), .Q(\txfifo[6][2] ), 
        .QN(n510) );
  DFFRX1 txfifo_reg44 ( .D(n182), .CK(clk), .RN(rstb), .Q(\txfifo[6][3] ), 
        .QN(n511) );
  DFFRX1 txfifo_reg45 ( .D(n183), .CK(clk), .RN(rstb), .Q(\txfifo[6][4] ), 
        .QN(n512) );
  DFFRX1 txfifo_reg46 ( .D(n184), .CK(clk), .RN(rstb), .Q(\txfifo[6][5] ), 
        .QN(n586) );
  DFFRX1 txfifo_reg47 ( .D(n185), .CK(clk), .RN(rstb), .Q(\txfifo[6][6] ), 
        .QN(n587) );
  DFFRX1 txfifo_reg48 ( .D(n187), .CK(clk), .RN(rstb), .Q(\txfifo[7][0] ), 
        .QN(n558) );
  DFFRX1 txfifo_reg49 ( .D(n188), .CK(clk), .RN(rstb), .Q(\txfifo[7][1] ), 
        .QN(n559) );
  DFFRX1 txfifo_reg50 ( .D(n189), .CK(clk), .RN(rstb), .Q(\txfifo[7][2] ), 
        .QN(n560) );
  DFFRX1 txfifo_reg51 ( .D(n190), .CK(clk), .RN(rstb), .Q(\txfifo[7][3] ), 
        .QN(n561) );
  DFFRX1 txfifo_reg52 ( .D(n191), .CK(clk), .RN(rstb), .Q(\txfifo[7][4] ), 
        .QN(n562) );
  DFFRX1 txfifo_reg53 ( .D(n192), .CK(clk), .RN(rstb), .Q(\txfifo[7][5] ), 
        .QN(n563) );
  DFFRX1 txfifo_reg54 ( .D(n193), .CK(clk), .RN(rstb), .Q(\txfifo[7][6] ), 
        .QN(n564) );
  DFFRX1 current_state_reg_1_ ( .D(N115), .CK(clk), .RN(rstb), .Q(
        current_state_1_), .QN(n565) );
  DFFSX1 txclkcntenb_reg ( .D(N112), .CK(clk), .SN(rstb), .QN(n545) );
  DFFRX1 current_state_reg_10_ ( .D(N124), .CK(clk), .RN(rstb), .Q(
        current_state_10_), .QN(n508) );
  DFFRX1 shiftreg_reg_1_ ( .D(n207), .CK(clk), .RN(rstb), .QN(n515) );
  DFFRX1 shiftreg_reg_2_ ( .D(n208), .CK(clk), .RN(rstb), .QN(n551) );
  DFFRX1 shiftreg_reg_3_ ( .D(n209), .CK(clk), .RN(rstb), .QN(n516) );
  DFFRX1 shiftreg_reg_4_ ( .D(n210), .CK(clk), .RN(rstb), .QN(n552) );
  DFFRX1 shiftreg_reg_5_ ( .D(n211), .CK(clk), .RN(rstb), .QN(n517) );
  DFFRX1 shiftreg_reg_6_ ( .D(n212), .CK(clk), .RN(rstb), .QN(n553) );
  DFFRX1 shiftreg_reg_7_ ( .D(n213), .CK(clk), .RN(rstb), .QN(n514) );
  DFFRX1 current_state_reg_12_ ( .D(N126), .CK(clk), .RN(rstb), .QN(n556) );
  DFFRX1 current_state_reg_11_ ( .D(N125), .CK(clk), .RN(rstb), .QN(n502) );
  DFFRX1 current_state_reg_3_ ( .D(N117), .CK(clk), .RN(rstb), .Q(
        current_state_3_) );
  DFFRX1 current_state_reg_4_ ( .D(N118), .CK(clk), .RN(rstb), .Q(
        current_state_4_) );
  DFFRX1 dtxclk_reg ( .D(txclk), .CK(clk), .RN(rstb), .Q(dtxclk) );
  DFFRX1 txfifo_reg55 ( .D(n170), .CK(clk), .RN(rstb), .Q(\txfifo[4][7] ) );
  DFFRX1 txfifo_reg56 ( .D(n178), .CK(clk), .RN(rstb), .Q(\txfifo[5][7] ) );
  DFFRX1 txfifo_reg57 ( .D(n154), .CK(clk), .RN(rstb), .Q(\txfifo[2][7] ) );
  DFFRX1 txfifo_reg58 ( .D(n162), .CK(clk), .RN(rstb), .Q(\txfifo[3][7] ) );
  DFFSX1 current_state_reg_0_ ( .D(N114), .CK(clk), .SN(rstb), .QN(n8) );
  DFFSX1 shiftenb_reg ( .D(N106), .CK(clk), .SN(rstb), .Q(shiftenb) );
  DFFRX1 txfifo_reg59 ( .D(n138), .CK(clk), .RN(rstb), .Q(\txfifo[0][7] ) );
  DFFRX1 txfifo_reg60 ( .D(n146), .CK(clk), .RN(rstb), .Q(\txfifo[1][7] ) );
  DFFRX1 txfifo_reg61 ( .D(n186), .CK(clk), .RN(rstb), .Q(\txfifo[6][7] ) );
  DFFRX1 txfifo_reg62 ( .D(n194), .CK(clk), .RN(rstb), .Q(\txfifo[7][7] ) );
  DFFRX1 txbusy_int_reg ( .D(N113), .CK(clk), .RN(rstb), .Q(txbusy) );
endmodule


module RxBlock_UART_FIFO_WIDTH3_0 ( baudx16clk, clk, databit, fifordb, 
        loopbacken, parity, rstb, rxd, stopbit, swrst, txd, uarten, 
        bytereceivedb, fifodata_rx, frameerror, overrunerror, parityerror, 
        rxbusy, rxfifocnt, rxfifoempty, frameerr_clear, parityerr_clear, 
        overrunerr_clear );
  input [1:0] parity;
  output [7:0] fifodata_rx;
  output [3:0] rxfifocnt;
  input baudx16clk, clk, databit, fifordb, loopbacken, rstb, rxd, stopbit,
         swrst, txd, uarten, frameerr_clear, parityerr_clear, overrunerr_clear;
  output bytereceivedb, frameerror, overrunerror, parityerror, rxbusy,
         rxfifoempty;
  wire   N68, N69, N70, current_state_16_, current_state_14_,
         current_state_13_, current_state_11_, current_state_10_,
         current_state_9_, current_state_8_, current_state_7_,
         current_state_6_, current_state_5_, current_state_4_,
         current_state_3_, current_state_2_, current_state_1_, \rxfifo[7][7] ,
         \rxfifo[7][6] , \rxfifo[7][5] , \rxfifo[7][4] , \rxfifo[7][3] ,
         \rxfifo[7][2] , \rxfifo[7][1] , \rxfifo[7][0] , \rxfifo[6][7] ,
         \rxfifo[6][6] , \rxfifo[6][5] , \rxfifo[6][4] , \rxfifo[6][3] ,
         \rxfifo[6][2] , \rxfifo[6][1] , \rxfifo[6][0] , \rxfifo[5][7] ,
         \rxfifo[5][6] , \rxfifo[5][5] , \rxfifo[5][4] , \rxfifo[5][3] ,
         \rxfifo[5][2] , \rxfifo[5][1] , \rxfifo[5][0] , \rxfifo[4][7] ,
         \rxfifo[4][6] , \rxfifo[4][5] , \rxfifo[4][4] , \rxfifo[4][3] ,
         \rxfifo[4][2] , \rxfifo[4][1] , \rxfifo[4][0] , \rxfifo[3][7] ,
         \rxfifo[3][6] , \rxfifo[3][5] , \rxfifo[3][4] , \rxfifo[3][3] ,
         \rxfifo[3][2] , \rxfifo[3][1] , \rxfifo[3][0] , \rxfifo[2][7] ,
         \rxfifo[2][6] , \rxfifo[2][5] , \rxfifo[2][4] , \rxfifo[2][3] ,
         \rxfifo[2][2] , \rxfifo[2][1] , \rxfifo[2][0] , \rxfifo[1][7] ,
         \rxfifo[1][6] , \rxfifo[1][5] , \rxfifo[1][4] , \rxfifo[1][3] ,
         \rxfifo[1][2] , \rxfifo[1][1] , \rxfifo[1][0] , \rxfifo[0][7] ,
         \rxfifo[0][6] , \rxfifo[0][5] , \rxfifo[0][4] , \rxfifo[0][3] ,
         \rxfifo[0][2] , \rxfifo[0][1] , \rxfifo[0][0] , rx_lpfd, rxsftenb,
         rxclk, framechkb, paritychkb, parity_int, dataphaseb, rxclkenb, N223,
         N291, N292, N293, N294, N295, N296, N297, N298, N299, N300, N301,
         N302, N303, N304, N305, N306, N307, N308, n17, n18, n208, n209, n210,
         n211, n212, n213, n214, n215, n216, n217, n218, n219, n220, n221,
         n222, n2230, n224, n225, n226, n227, n228, n229, n230, n231, n232,
         n233, n234, n235, n236, n237, n238, n239, n240, n241, n242, n243,
         n244, n245, n246, n247, n248, n249, n250, n251, n252, n253, n254,
         n255, n256, n257, n258, n259, n260, n261, n262, n263, n264, n265,
         n266, n267, n268, n269, n270, n271, n272, n273, n274, n275, n276,
         n277, n278, n279, n280, n281, n282, n283, n284, n285, n286, n287,
         n288, n289, n290, n2910, n2920, n2930, n2940, n2950, n2960, n2970,
         n2980, n2990, n3000, n3010, n3020, n3030, n3040, n3050, n3060, n3070,
         n3080, n309, n310, n311, n312, n367, n368, n369, n371, n372, n373,
         n374, n375, n376, n378, n380, n381, n382, n383, n384, n385, n386,
         n387, n388, n390, n392, n393, n394, n395, n396, n398, n399, n400,
         n401, n404, n405, n406, n407, n408, n409, n410, n412, n413, n414,
         n415, n416, n417, n418, n419, n421, n422, n423, n424, n426, n427,
         n428, n429, n430, n431, n433, n434, n435, n436, n438, n440, n441,
         n442, n443, n444, n445, n446, n447, n448, n452, n453, n458, n459,
         n460, n461, n462, n463, n465, n466, n467, n468, n469, n470, n471,
         n472, n473, n475, n476, n477, n478, n480, n481, n482, n483, n484,
         n485, n488, n489, n490, n492, n493, n495, n496, n499, n500, n501,
         n502, n503, n504, n505, n506, n507, n509, n511, n512, n513, n514,
         n516, n517, n518, n519, n522, n523, n524, n525, n526, n527, n528,
         n530, n531, n532, n533, n534, n535, n540, n541, n542, n543, n544,
         n545, n546, n547, n550, n551, n555, n557, n558, n559, n560, n561,
         n564, n565, n567, n569, n570, n575, n578, n579, n582, n587, n590,
         n591, n594, n599, n602, n603, n606, n611, n614, n615, n618, n623,
         n626, n627, n630, n635, n638, n639, n642, n647, n650, n651, n654,
         n659, n662, n664, n666, n667, n669, n670, n673, n674, n682, n683,
         n684, n685, n688, n689, n690, n691, n692, n693, n694, n695, n696,
         n697, n698, n699, n700, n701, n702, n703, n704, n705, n706, n707,
         n708, n709, n710, n711, n712, n713, n714, n715, n716, n717, n718,
         n719, n720, n721, n722, n723, n724, n725, n726, n727, n728, n729,
         n730, n731, n732, n733, n734, n735, n736, n737, n738, n739, n740,
         n741, n742, n743, n744, n745, n746, n747, n748, n749, n750, n751,
         n752, n753, n754, n755, n756, n757, n758, n759, n760, n761, n762,
         n763, n764, n765, n766, n767, n768, n769, n770, n771, n772, n773,
         n774, n775, n776, n777, n778, n779, n780, n781, n782, n783, n784,
         n785, n786, n787, n788, n789, n790, n791, n792, n793, n794, n795,
         n796, n797, n798, n799;
  wire   [2:0] fifo_wrpos;
  wire   [7:0] rxsftreg;
  wire   [5:0] in_dly;
  wire   [3:0] rxclkcnt;

  INVX1 U846 ( .A(n505), .Y(n500) );
  NAND3BX1 U847 ( .AN(n514), .B(n535), .C(n781), .Y(n526) );
  OA22X1 U848 ( .A0(n519), .A1(n527), .B0(n518), .B1(n542), .Y(n535) );
  NAND2BX1 U849 ( .AN(n526), .B(n522), .Y(n505) );
  AO22X1 U850 ( .A0(n532), .A1(n541), .B0(n545), .B1(n546), .Y(n514) );
  INVX1 U851 ( .A(n541), .Y(n530) );
  INVX1 U852 ( .A(n527), .Y(n528) );
  AND2X2 U853 ( .A(n523), .B(n513), .Y(n781) );
  INVX1 U854 ( .A(n542), .Y(n545) );
  INVX1 U855 ( .A(n517), .Y(n512) );
  NAND3BX1 U856 ( .AN(n509), .B(n518), .C(n519), .Y(n517) );
  INVX1 U857 ( .A(n509), .Y(n499) );
  INVX1 U858 ( .A(rxfifocnt[0]), .Y(n394) );
  INVX1 U859 ( .A(n435), .Y(n436) );
  INVX1 U860 ( .A(n433), .Y(n434) );
  INVX1 U861 ( .A(n430), .Y(n431) );
  INVX1 U862 ( .A(n428), .Y(n429) );
  INVX1 U863 ( .A(n426), .Y(n427) );
  INVX1 U864 ( .A(n423), .Y(n424) );
  INVX1 U865 ( .A(n421), .Y(n422) );
  INVX1 U866 ( .A(n410), .Y(n412) );
  NAND4BX1 U867 ( .AN(n394), .B(fifordb), .C(n794), .D(rxfifocnt[1]), .Y(n398)
         );
  AO22X1 U868 ( .A0(n388), .A1(n372), .B0(n384), .B1(n693), .Y(n381) );
  OAI222X1 U869 ( .A0(n452), .A1(n741), .B0(n452), .B1(n697), .C0(n741), .C1(
        n697), .Y(n446) );
  INVX1 U870 ( .A(n388), .Y(n384) );
  INVX1 U871 ( .A(n441), .Y(n452) );
  DFFRX1 rxclk_reg ( .D(N223), .CK(clk), .RN(rstb), .Q(rxclk), .QN(n688) );
  NAND4BX1 U872 ( .AN(rxfifocnt[2]), .B(n736), .C(n393), .D(n394), .Y(n367) );
  INVX1 U873 ( .A(rxfifocnt[1]), .Y(n393) );
  NAND4BX1 U874 ( .AN(n740), .B(n530), .C(n531), .D(n532), .Y(n522) );
  NOR2BX1 U875 ( .AN(n533), .B(n534), .Y(n531) );
  NAND3BX1 U876 ( .AN(n547), .B(n689), .C(n737), .Y(n541) );
  NAND3BX1 U877 ( .AN(n533), .B(n530), .C(n532), .Y(n523) );
  NAND3X1 U878 ( .A(n522), .B(n372), .C(n502), .Y(n507) );
  NAND2BX1 U879 ( .AN(n503), .B(n502), .Y(n527) );
  NAND3BX1 U880 ( .AN(n561), .B(n786), .C(n785), .Y(n504) );
  INVX1 U881 ( .A(n557), .Y(n502) );
  NAND3BX1 U882 ( .AN(n558), .B(n559), .C(n560), .Y(n557) );
  INVX1 U883 ( .A(n504), .Y(n560) );
  NAND2BX1 U884 ( .AN(n555), .B(n787), .Y(n546) );
  NAND2BX1 U885 ( .AN(n544), .B(n528), .Y(n542) );
  INVX1 U886 ( .A(n409), .Y(n406) );
  NAND2BX1 U887 ( .AN(n798), .B(n797), .Y(n409) );
  NAND4X1 U888 ( .A(n534), .B(n533), .C(n530), .D(n532), .Y(n513) );
  INVX1 U889 ( .A(n550), .Y(n532) );
  NAND3BX1 U890 ( .AN(n543), .B(n551), .C(n545), .Y(n550) );
  INVX1 U891 ( .A(n546), .Y(n551) );
  INVX1 U892 ( .A(n496), .Y(n506) );
  OR2X1 U893 ( .A(n503), .B(n507), .Y(n509) );
  OAI211X1 U894 ( .A0(n794), .A1(n496), .B0(n524), .C0(n525), .Y(n211) );
  NOR2BX1 U895 ( .AN(n372), .B(n527), .Y(n524) );
  INVX1 U896 ( .A(n526), .Y(n525) );
  OAI211X1 U897 ( .A0(n698), .A1(n496), .B0(n500), .C0(n501), .Y(n217) );
  AOI211X1 U898 ( .A0(n502), .A1(n503), .B0(n504), .C0(N291), .Y(n501) );
  INVX1 U899 ( .A(n685), .Y(n559) );
  INVX1 U900 ( .A(uarten), .Y(n682) );
  AO21X1 U901 ( .A0(n798), .A1(n693), .B0(n406), .Y(rxfifocnt[0]) );
  AO22X1 U902 ( .A0(n378), .A1(n372), .B0(n376), .B1(n696), .Y(n373) );
  AO21X1 U903 ( .A0(n699), .A1(n691), .B0(n489), .Y(n492) );
  AO21X1 U904 ( .A0(n742), .A1(n691), .B0(n492), .Y(n481) );
  INVX1 U905 ( .A(n544), .Y(n519) );
  INVX1 U906 ( .A(n462), .Y(n471) );
  INVX1 U907 ( .A(n378), .Y(n376) );
  INVX1 U908 ( .A(n667), .Y(n472) );
  INVX1 U909 ( .A(n543), .Y(n518) );
  INVX1 U910 ( .A(n483), .Y(n489) );
  INVX1 U911 ( .A(n473), .Y(n470) );
  NAND3BX1 U912 ( .AN(n799), .B(n696), .C(n793), .Y(n435) );
  NAND3BX1 U913 ( .AN(n799), .B(n798), .C(n793), .Y(n433) );
  NAND3BX1 U914 ( .AN(n799), .B(n696), .C(n791), .Y(n430) );
  NAND3BX1 U915 ( .AN(n799), .B(n798), .C(n791), .Y(n428) );
  NAND3BX1 U916 ( .AN(n798), .B(n799), .C(n793), .Y(n426) );
  NAND3BX1 U917 ( .AN(n694), .B(n798), .C(n793), .Y(n423) );
  NAND3BX1 U918 ( .AN(n798), .B(n799), .C(n791), .Y(n421) );
  NAND3BX1 U919 ( .AN(n694), .B(n798), .C(n791), .Y(n410) );
  INVX1 U920 ( .A(n459), .Y(n460) );
  NOR2BX1 U921 ( .AN(n372), .B(n540), .Y(N307) );
  NOR2BX1 U922 ( .AN(n372), .B(n533), .Y(N305) );
  NOR2BX1 U923 ( .AN(n372), .B(n787), .Y(N301) );
  AND2X2 U924 ( .A(n372), .B(n503), .Y(N296) );
  AND2X2 U925 ( .A(n372), .B(n558), .Y(N295) );
  NOR2BX1 U926 ( .AN(n372), .B(n785), .Y(N294) );
  NOR2BX1 U927 ( .AN(n372), .B(n786), .Y(N293) );
  INVX1 U928 ( .A(n488), .Y(n485) );
  OAI32X1 U929 ( .A0(n462), .A1(n438), .A2(n737), .B0(n689), .B1(n667), .Y(
        N303) );
  OAI32X1 U930 ( .A0(n395), .A1(swrst), .A2(bytereceivedb), .B0(n736), .B1(
        n396), .Y(n3050) );
  INVX1 U931 ( .A(n396), .Y(n395) );
  OAI221X1 U932 ( .A0(fifordb), .A1(n794), .B0(n398), .B1(n399), .C0(n372), 
        .Y(n396) );
  INVX1 U933 ( .A(rxfifocnt[2]), .Y(n399) );
  NAND3BX1 U934 ( .AN(swrst), .B(n392), .C(n367), .Y(n388) );
  INVX1 U935 ( .A(fifordb), .Y(n392) );
  AO22X1 U936 ( .A0(txd), .A1(loopbacken), .B0(rxd), .B1(n458), .Y(n441) );
  INVX1 U937 ( .A(loopbacken), .Y(n458) );
  AO22X1 U938 ( .A0(in_dly[0]), .A1(n440), .B0(baudx16clk), .B1(n441), .Y(n235) );
  OAI2BB1X1 U939 ( .A0N(N70), .A1N(n381), .B0(n382), .Y(n3080) );
  AOI32X1 U940 ( .A0(n383), .A1(n797), .A2(n384), .B0(n385), .B1(n384), .Y(
        n382) );
  INVX1 U941 ( .A(n386), .Y(n385) );
  INVX1 U942 ( .A(n387), .Y(n383) );
  OAI33X1 U943 ( .A0(n441), .A1(in_dly[1]), .A2(n697), .B0(n441), .B1(
        in_dly[0]), .B2(n741), .Y(n448) );
  OAI2BB1X1 U944 ( .A0N(n442), .A1N(n443), .B0(n444), .Y(n234) );
  OA21X2 U945 ( .A0(n446), .A1(n445), .B0(baudx16clk), .Y(n442) );
  AOI32X1 U946 ( .A0(baudx16clk), .A1(n445), .A2(n446), .B0(rx_lpfd), .B1(n440), .Y(n444) );
  OA22X1 U947 ( .A0(n447), .A1(n448), .B0(in_dly[5]), .B1(n789), .Y(n443) );
  OAI32X1 U948 ( .A0(n384), .A1(swrst), .A2(n693), .B0(n797), .B1(n388), .Y(
        n3060) );
  OAI32X1 U949 ( .A0(n388), .A1(N69), .A2(n693), .B0(n390), .B1(n735), .Y(
        n3070) );
  INVX1 U950 ( .A(n381), .Y(n390) );
  OAI31X1 U951 ( .A0(n452), .A1(in_dly[1]), .A2(in_dly[0]), .B0(n453), .Y(n447) );
  AOI32X1 U952 ( .A0(in_dly[1]), .A1(in_dly[0]), .A2(n441), .B0(in_dly[5]), 
        .B1(n789), .Y(n453) );
  NAND2BX1 U953 ( .AN(n407), .B(n408), .Y(rxfifocnt[1]) );
  OAI33X1 U954 ( .A0(n406), .A1(fifo_wrpos[1]), .A2(n735), .B0(n406), .B1(N69), 
        .B2(n792), .Y(n407) );
  AOI33X1 U955 ( .A0(n735), .A1(n792), .A2(n406), .B0(N69), .B1(fifo_wrpos[1]), 
        .B2(n406), .Y(n408) );
  NAND2BX1 U956 ( .AN(n400), .B(n401), .Y(rxfifocnt[2]) );
  OAI33X1 U957 ( .A0(n404), .A1(n799), .A2(n738), .B0(n404), .B1(N70), .B2(
        n694), .Y(n400) );
  AOI33X1 U958 ( .A0(n738), .A1(n694), .A2(n404), .B0(N70), .B1(n799), .B2(
        n404), .Y(n401) );
  INVX1 U959 ( .A(n405), .Y(n404) );
  NAND3BX1 U960 ( .AN(swrst), .B(n528), .C(n500), .Y(n496) );
  NAND3BX1 U961 ( .AN(n18), .B(n788), .C(n540), .Y(n534) );
  AO22X1 U962 ( .A0(current_state_5_), .A1(n688), .B0(current_state_4_), .B1(
        n783), .Y(n503) );
  NAND2X1 U963 ( .A(n782), .B(n17), .Y(n685) );
  AO22X1 U964 ( .A0(current_state_4_), .A1(n440), .B0(current_state_3_), .B1(
        n783), .Y(n558) );
  OAI222X1 U965 ( .A0(n406), .A1(n792), .B0(N69), .B1(n406), .C0(N69), .C1(
        n792), .Y(n405) );
  INVX1 U966 ( .A(n367), .Y(rxfifoempty) );
  INVX1 U967 ( .A(baudx16clk), .Y(n440) );
  BUFX2 U968 ( .A(fifo_wrpos[0]), .Y(n798) );
  BUFX2 U969 ( .A(N68), .Y(n797) );
  BUFX2 U970 ( .A(fifo_wrpos[2]), .Y(n799) );
  OAI221X1 U971 ( .A0(n783), .A1(n734), .B0(n559), .B1(n682), .C0(n683), .Y(
        n561) );
  OAI31X1 U972 ( .A0(current_state_2_), .A1(current_state_4_), .A2(
        current_state_3_), .B0(n684), .Y(n683) );
  NOR2BX1 U973 ( .AN(baudx16clk), .B(n784), .Y(n684) );
  OAI31X1 U974 ( .A0(n688), .A1(databit), .A2(n737), .B0(n674), .Y(n547) );
  OA22X1 U975 ( .A0(rxclk), .A1(n692), .B0(n688), .B1(n689), .Y(n674) );
  INVX1 U976 ( .A(parity[1]), .Y(n475) );
  AND2X2 U977 ( .A(n784), .B(baudx16clk), .Y(n783) );
  AO22X1 U978 ( .A0(n505), .A1(n372), .B0(rxbusy), .B1(n506), .Y(n216) );
  AO21X1 U979 ( .A0(rxclkenb), .A1(n506), .B0(n507), .Y(n215) );
  OAI211X1 U980 ( .A0(n747), .A1(n496), .B0(n511), .C0(n512), .Y(n213) );
  NOR2BX1 U981 ( .AN(n513), .B(n514), .Y(n511) );
  OAI211X1 U982 ( .A0(n496), .A1(n744), .B0(n516), .C0(n512), .Y(n212) );
  NOR2BX1 U983 ( .AN(n523), .B(n514), .Y(n516) );
  OAI211X1 U984 ( .A0(n496), .A1(n746), .B0(n781), .C0(n499), .Y(n214) );
  OAI211X1 U985 ( .A0(n496), .A1(n745), .B0(n781), .C0(n499), .Y(n218) );
  AOI22X1 U986 ( .A0(current_state_3_), .A1(n440), .B0(current_state_2_), .B1(
        n783), .Y(n785) );
  AOI22X1 U987 ( .A0(current_state_2_), .A1(n440), .B0(current_state_1_), .B1(
        n783), .Y(n786) );
  AOI22X1 U988 ( .A0(current_state_9_), .A1(rxclk), .B0(current_state_10_), 
        .B1(n688), .Y(n787) );
  AOI21X1 U989 ( .A0(n669), .A1(current_state_13_), .B0(current_state_14_), 
        .Y(n788) );
  INVX1 U990 ( .A(n662), .Y(n540) );
  OAI31X1 U991 ( .A0(n788), .A1(stopbit), .A2(n688), .B0(n664), .Y(n662) );
  OA22X1 U992 ( .A0(n688), .A1(n695), .B0(rxclk), .B1(n740), .Y(n664) );
  INVX1 U993 ( .A(n673), .Y(n669) );
  NAND2BX1 U994 ( .AN(parity[0]), .B(n475), .Y(n673) );
  NAND3BX1 U995 ( .AN(bytereceivedb), .B(n736), .C(n372), .Y(n378) );
  NAND2BX1 U996 ( .AN(swrst), .B(rxclk), .Y(n462) );
  OR4X1 U997 ( .A(current_state_7_), .B(current_state_6_), .C(current_state_5_), .D(current_state_8_), .Y(n544) );
  NAND2BX1 U998 ( .AN(baudx16clk), .B(n691), .Y(n483) );
  AO22X1 U999 ( .A0(current_state_9_), .A1(n688), .B0(current_state_8_), .B1(
        rxclk), .Y(n543) );
  NAND2BX1 U1000 ( .AN(swrst), .B(n688), .Y(n667) );
  INVX1 U1001 ( .A(swrst), .Y(n372) );
  OAI32X1 U1002 ( .A0(n466), .A1(parityerr_clear), .A2(n462), .B0(n467), .B1(
        n210), .Y(n224) );
  INVX1 U1003 ( .A(n467), .Y(n466) );
  AO21X1 U1004 ( .A0(n468), .A1(n469), .B0(parityerr_clear), .Y(n467) );
  AOI31X1 U1005 ( .A0(n470), .A1(n784), .A2(n471), .B0(n472), .Y(n469) );
  AO22X1 U1006 ( .A0(current_state_11_), .A1(n688), .B0(current_state_10_), 
        .B1(rxclk), .Y(n555) );
  OAI31X1 U1007 ( .A0(n743), .A1(parity[0]), .A2(n475), .B0(n476), .Y(n473) );
  OA22X1 U1008 ( .A0(parity_int), .A1(parity[1]), .B0(parity_int), .B1(n477), 
        .Y(n476) );
  INVX1 U1009 ( .A(parity[0]), .Y(n477) );
  OAI32X1 U1010 ( .A0(n461), .A1(frameerr_clear), .A2(n462), .B0(n463), .B1(
        n208), .Y(n225) );
  INVX1 U1011 ( .A(n461), .Y(n463) );
  OAI33X1 U1012 ( .A0(n462), .A1(frameerr_clear), .A2(n784), .B0(n465), .B1(
        swrst), .B2(frameerr_clear), .Y(n461) );
  NOR2BX1 U1013 ( .AN(rxclk), .B(framechkb), .Y(n465) );
  OAI32X1 U1014 ( .A0(n488), .A1(rxclkcnt[2]), .A2(n489), .B0(n490), .B1(n700), 
        .Y(n221) );
  INVX1 U1015 ( .A(n481), .Y(n490) );
  OAI32X1 U1016 ( .A0(n378), .A1(fifo_wrpos[1]), .A2(n696), .B0(n380), .B1(
        n792), .Y(n310) );
  INVX1 U1017 ( .A(n373), .Y(n380) );
  AOI32X1 U1018 ( .A0(rx_lpfd), .A1(n473), .A2(n471), .B0(paritychkb), .B1(
        n372), .Y(n468) );
  INVX1 U1019 ( .A(n670), .Y(n533) );
  OAI32X1 U1020 ( .A0(n688), .A1(n669), .A2(n692), .B0(rxclk), .B1(n739), .Y(
        n670) );
  XOR3X1 U1021 ( .A(n790), .B(in_dly[3]), .C(n690), .Y(n789) );
  OAI32X1 U1022 ( .A0(n368), .A1(swrst), .A2(overrunerr_clear), .B0(n369), 
        .B1(n209), .Y(n312) );
  INVX1 U1023 ( .A(n369), .Y(n368) );
  OAI211X1 U1024 ( .A0(bytereceivedb), .A1(n736), .B0(n371), .C0(n372), .Y(
        n369) );
  INVX1 U1025 ( .A(overrunerr_clear), .Y(n371) );
  NAND2BX1 U1026 ( .AN(N70), .B(N69), .Y(n387) );
  NAND2BX1 U1027 ( .AN(N69), .B(N70), .Y(n386) );
  NAND2BX1 U1028 ( .AN(rxsftenb), .B(rxclk), .Y(n459) );
  OAI33X1 U1029 ( .A0(n478), .A1(n698), .A2(n743), .B0(n480), .B1(parity_int), 
        .B2(n698), .Y(n2230) );
  INVX1 U1030 ( .A(n480), .Y(n478) );
  NAND3BX1 U1031 ( .AN(dataphaseb), .B(rx_lpfd), .C(rxclk), .Y(n480) );
  NAND3BX1 U1032 ( .AN(rxclkenb), .B(rxclkcnt[1]), .C(rxclkcnt[0]), .Y(n488)
         );
  AO22X1 U1033 ( .A0(rxsftreg[0]), .A1(databit), .B0(rxsftreg[1]), .B1(n438), 
        .Y(n419) );
  AO22X1 U1034 ( .A0(rxsftreg[1]), .A1(databit), .B0(rxsftreg[2]), .B1(n438), 
        .Y(n418) );
  AO22X1 U1035 ( .A0(rxsftreg[2]), .A1(databit), .B0(rxsftreg[3]), .B1(n438), 
        .Y(n417) );
  AO22X1 U1036 ( .A0(rxsftreg[3]), .A1(databit), .B0(rxsftreg[4]), .B1(n438), 
        .Y(n416) );
  AO22X1 U1037 ( .A0(rxsftreg[4]), .A1(databit), .B0(rxsftreg[5]), .B1(n438), 
        .Y(n415) );
  AO22X1 U1038 ( .A0(rxsftreg[5]), .A1(databit), .B0(rxsftreg[6]), .B1(n438), 
        .Y(n414) );
  AO22X1 U1039 ( .A0(rxsftreg[6]), .A1(databit), .B0(rxsftreg[7]), .B1(n438), 
        .Y(n413) );
  NOR2BX1 U1040 ( .AN(n547), .B(swrst), .Y(N304) );
  NOR2BX1 U1041 ( .AN(n555), .B(swrst), .Y(N302) );
  NOR2BX1 U1042 ( .AN(n543), .B(swrst), .Y(N300) );
  NOR2BX1 U1043 ( .AN(n561), .B(swrst), .Y(N292) );
  INVX1 U1044 ( .A(databit), .Y(n438) );
  NOR2BX1 U1045 ( .AN(current_state_16_), .B(n462), .Y(N308) );
  AO21X1 U1046 ( .A0(n685), .A1(n682), .B0(swrst), .Y(N291) );
  OAI222X1 U1047 ( .A0(n790), .A1(n690), .B0(n701), .B1(n690), .C0(n790), .C1(
        n701), .Y(n445) );
  NOR2X1 U1048 ( .A(bytereceivedb), .B(n792), .Y(n791) );
  AND2X2 U1049 ( .A(n794), .B(n792), .Y(n793) );
  AO22X1 U1050 ( .A0(in_dly[0]), .A1(baudx16clk), .B0(in_dly[1]), .B1(n440), 
        .Y(n236) );
  AO22X1 U1051 ( .A0(in_dly[1]), .A1(baudx16clk), .B0(in_dly[2]), .B1(n440), 
        .Y(n237) );
  AO22X1 U1052 ( .A0(in_dly[2]), .A1(baudx16clk), .B0(in_dly[3]), .B1(n440), 
        .Y(n238) );
  AO22X1 U1053 ( .A0(in_dly[3]), .A1(baudx16clk), .B0(in_dly[4]), .B1(n440), 
        .Y(n239) );
  AO22X1 U1054 ( .A0(in_dly[4]), .A1(baudx16clk), .B0(in_dly[5]), .B1(n440), 
        .Y(n240) );
  NOR2X1 U1055 ( .A(n438), .B(n796), .Y(n795) );
  OAI2BB1X1 U1056 ( .A0N(rxclkcnt[3]), .A1N(n481), .B0(n482), .Y(n222) );
  AOI33X1 U1057 ( .A0(n483), .A1(n484), .A2(n485), .B0(n700), .B1(n691), .B2(
        rxclkcnt[3]), .Y(n482) );
  NOR2BX1 U1058 ( .AN(rxclkcnt[2]), .B(rxclkcnt[3]), .Y(n484) );
  AO22X1 U1059 ( .A0(rxsftreg[7]), .A1(n459), .B0(n460), .B1(rx_lpfd), .Y(n233) );
  AO22X1 U1060 ( .A0(current_state_7_), .A1(n471), .B0(n472), .B1(
        current_state_8_), .Y(N299) );
  AO22X1 U1061 ( .A0(\rxfifo[7][7] ), .A1(n410), .B0(n795), .B1(n412), .Y(
        n3040) );
  AO22X1 U1062 ( .A0(\rxfifo[0][7] ), .A1(n435), .B0(n436), .B1(n795), .Y(n248) );
  AO22X1 U1063 ( .A0(\rxfifo[1][7] ), .A1(n433), .B0(n434), .B1(n795), .Y(n256) );
  AO22X1 U1064 ( .A0(\rxfifo[2][7] ), .A1(n430), .B0(n431), .B1(n795), .Y(n264) );
  AO22X1 U1065 ( .A0(\rxfifo[3][7] ), .A1(n428), .B0(n429), .B1(n795), .Y(n272) );
  AO22X1 U1066 ( .A0(\rxfifo[4][7] ), .A1(n426), .B0(n427), .B1(n795), .Y(n280) );
  AO22X1 U1067 ( .A0(\rxfifo[5][7] ), .A1(n423), .B0(n424), .B1(n795), .Y(n288) );
  AO22X1 U1068 ( .A0(\rxfifo[6][7] ), .A1(n421), .B0(n422), .B1(n795), .Y(
        n2960) );
  AO22X1 U1069 ( .A0(current_state_6_), .A1(n471), .B0(current_state_7_), .B1(
        n472), .Y(N298) );
  AO22X1 U1070 ( .A0(current_state_5_), .A1(n471), .B0(current_state_6_), .B1(
        n472), .Y(N297) );
  AO22X1 U1071 ( .A0(rxsftreg[0]), .A1(n459), .B0(n460), .B1(rxsftreg[1]), .Y(
        n226) );
  AO22X1 U1072 ( .A0(rxsftreg[1]), .A1(n459), .B0(n460), .B1(rxsftreg[2]), .Y(
        n227) );
  AO22X1 U1073 ( .A0(rxsftreg[2]), .A1(n459), .B0(n460), .B1(rxsftreg[3]), .Y(
        n228) );
  AO22X1 U1074 ( .A0(rxsftreg[3]), .A1(n459), .B0(n460), .B1(rxsftreg[4]), .Y(
        n229) );
  AO22X1 U1075 ( .A0(rxsftreg[4]), .A1(n459), .B0(n460), .B1(rxsftreg[5]), .Y(
        n230) );
  AO22X1 U1076 ( .A0(rxsftreg[5]), .A1(n459), .B0(n460), .B1(rxsftreg[6]), .Y(
        n231) );
  AO22X1 U1077 ( .A0(rxsftreg[6]), .A1(n459), .B0(n460), .B1(rxsftreg[7]), .Y(
        n232) );
  OAI2BB1X1 U1078 ( .A0N(n799), .A1N(n373), .B0(n374), .Y(n311) );
  AOI33X1 U1079 ( .A0(n375), .A1(n798), .A2(n376), .B0(n799), .B1(n792), .B2(
        n376), .Y(n374) );
  NOR2BX1 U1080 ( .AN(fifo_wrpos[1]), .B(n799), .Y(n375) );
  AO22X1 U1081 ( .A0(\rxfifo[0][0] ), .A1(n435), .B0(n436), .B1(n419), .Y(n241) );
  AO22X1 U1082 ( .A0(\rxfifo[0][1] ), .A1(n435), .B0(n436), .B1(n418), .Y(n242) );
  AO22X1 U1083 ( .A0(\rxfifo[0][2] ), .A1(n435), .B0(n436), .B1(n417), .Y(n243) );
  AO22X1 U1084 ( .A0(\rxfifo[0][3] ), .A1(n435), .B0(n436), .B1(n416), .Y(n244) );
  AO22X1 U1085 ( .A0(\rxfifo[0][4] ), .A1(n435), .B0(n436), .B1(n415), .Y(n245) );
  AO22X1 U1086 ( .A0(\rxfifo[0][5] ), .A1(n435), .B0(n436), .B1(n414), .Y(n246) );
  AO22X1 U1087 ( .A0(\rxfifo[0][6] ), .A1(n435), .B0(n436), .B1(n413), .Y(n247) );
  AO22X1 U1088 ( .A0(\rxfifo[1][0] ), .A1(n433), .B0(n434), .B1(n419), .Y(n249) );
  AO22X1 U1089 ( .A0(\rxfifo[1][1] ), .A1(n433), .B0(n434), .B1(n418), .Y(n250) );
  AO22X1 U1090 ( .A0(\rxfifo[1][2] ), .A1(n433), .B0(n434), .B1(n417), .Y(n251) );
  AO22X1 U1091 ( .A0(\rxfifo[1][3] ), .A1(n433), .B0(n434), .B1(n416), .Y(n252) );
  AO22X1 U1092 ( .A0(\rxfifo[1][4] ), .A1(n433), .B0(n434), .B1(n415), .Y(n253) );
  AO22X1 U1093 ( .A0(\rxfifo[1][5] ), .A1(n433), .B0(n434), .B1(n414), .Y(n254) );
  AO22X1 U1094 ( .A0(\rxfifo[1][6] ), .A1(n433), .B0(n434), .B1(n413), .Y(n255) );
  AO22X1 U1095 ( .A0(\rxfifo[2][0] ), .A1(n430), .B0(n431), .B1(n419), .Y(n257) );
  AO22X1 U1096 ( .A0(\rxfifo[2][1] ), .A1(n430), .B0(n431), .B1(n418), .Y(n258) );
  AO22X1 U1097 ( .A0(\rxfifo[2][2] ), .A1(n430), .B0(n431), .B1(n417), .Y(n259) );
  AO22X1 U1098 ( .A0(\rxfifo[2][3] ), .A1(n430), .B0(n431), .B1(n416), .Y(n260) );
  AO22X1 U1099 ( .A0(\rxfifo[2][4] ), .A1(n430), .B0(n431), .B1(n415), .Y(n261) );
  AO22X1 U1100 ( .A0(\rxfifo[2][5] ), .A1(n430), .B0(n431), .B1(n414), .Y(n262) );
  AO22X1 U1101 ( .A0(\rxfifo[2][6] ), .A1(n430), .B0(n431), .B1(n413), .Y(n263) );
  AO22X1 U1102 ( .A0(\rxfifo[3][0] ), .A1(n428), .B0(n429), .B1(n419), .Y(n265) );
  AO22X1 U1103 ( .A0(\rxfifo[3][1] ), .A1(n428), .B0(n429), .B1(n418), .Y(n266) );
  AO22X1 U1104 ( .A0(\rxfifo[3][2] ), .A1(n428), .B0(n429), .B1(n417), .Y(n267) );
  AO22X1 U1105 ( .A0(\rxfifo[3][3] ), .A1(n428), .B0(n429), .B1(n416), .Y(n268) );
  AO22X1 U1106 ( .A0(\rxfifo[3][4] ), .A1(n428), .B0(n429), .B1(n415), .Y(n269) );
  AO22X1 U1107 ( .A0(\rxfifo[3][5] ), .A1(n428), .B0(n429), .B1(n414), .Y(n270) );
  AO22X1 U1108 ( .A0(\rxfifo[3][6] ), .A1(n428), .B0(n429), .B1(n413), .Y(n271) );
  AO22X1 U1109 ( .A0(\rxfifo[4][0] ), .A1(n426), .B0(n427), .B1(n419), .Y(n273) );
  AO22X1 U1110 ( .A0(\rxfifo[4][1] ), .A1(n426), .B0(n427), .B1(n418), .Y(n274) );
  AO22X1 U1111 ( .A0(\rxfifo[4][2] ), .A1(n426), .B0(n427), .B1(n417), .Y(n275) );
  AO22X1 U1112 ( .A0(\rxfifo[4][3] ), .A1(n426), .B0(n427), .B1(n416), .Y(n276) );
  AO22X1 U1113 ( .A0(\rxfifo[4][4] ), .A1(n426), .B0(n427), .B1(n415), .Y(n277) );
  AO22X1 U1114 ( .A0(\rxfifo[4][5] ), .A1(n426), .B0(n427), .B1(n414), .Y(n278) );
  AO22X1 U1115 ( .A0(\rxfifo[4][6] ), .A1(n426), .B0(n427), .B1(n413), .Y(n279) );
  AO22X1 U1116 ( .A0(\rxfifo[5][0] ), .A1(n423), .B0(n424), .B1(n419), .Y(n281) );
  AO22X1 U1117 ( .A0(\rxfifo[5][1] ), .A1(n423), .B0(n424), .B1(n418), .Y(n282) );
  AO22X1 U1118 ( .A0(\rxfifo[5][2] ), .A1(n423), .B0(n424), .B1(n417), .Y(n283) );
  AO22X1 U1119 ( .A0(\rxfifo[5][3] ), .A1(n423), .B0(n424), .B1(n416), .Y(n284) );
  AO22X1 U1120 ( .A0(\rxfifo[5][4] ), .A1(n423), .B0(n424), .B1(n415), .Y(n285) );
  AO22X1 U1121 ( .A0(\rxfifo[5][5] ), .A1(n423), .B0(n424), .B1(n414), .Y(n286) );
  AO22X1 U1122 ( .A0(\rxfifo[5][6] ), .A1(n423), .B0(n424), .B1(n413), .Y(n287) );
  AO22X1 U1123 ( .A0(\rxfifo[6][0] ), .A1(n421), .B0(n422), .B1(n419), .Y(n289) );
  AO22X1 U1124 ( .A0(\rxfifo[6][1] ), .A1(n421), .B0(n422), .B1(n418), .Y(n290) );
  AO22X1 U1125 ( .A0(\rxfifo[6][2] ), .A1(n421), .B0(n422), .B1(n417), .Y(
        n2910) );
  AO22X1 U1126 ( .A0(\rxfifo[6][3] ), .A1(n421), .B0(n422), .B1(n416), .Y(
        n2920) );
  AO22X1 U1127 ( .A0(\rxfifo[6][4] ), .A1(n421), .B0(n422), .B1(n415), .Y(
        n2930) );
  AO22X1 U1128 ( .A0(\rxfifo[6][5] ), .A1(n421), .B0(n422), .B1(n414), .Y(
        n2940) );
  AO22X1 U1129 ( .A0(\rxfifo[6][6] ), .A1(n421), .B0(n422), .B1(n413), .Y(
        n2950) );
  AO22X1 U1130 ( .A0(\rxfifo[7][0] ), .A1(n410), .B0(n412), .B1(n419), .Y(
        n2970) );
  AO22X1 U1131 ( .A0(\rxfifo[7][1] ), .A1(n410), .B0(n412), .B1(n418), .Y(
        n2980) );
  AO22X1 U1132 ( .A0(\rxfifo[7][2] ), .A1(n410), .B0(n412), .B1(n417), .Y(
        n2990) );
  AO22X1 U1133 ( .A0(\rxfifo[7][3] ), .A1(n410), .B0(n412), .B1(n416), .Y(
        n3000) );
  AO22X1 U1134 ( .A0(\rxfifo[7][4] ), .A1(n410), .B0(n412), .B1(n415), .Y(
        n3010) );
  AO22X1 U1135 ( .A0(\rxfifo[7][5] ), .A1(n410), .B0(n412), .B1(n414), .Y(
        n3020) );
  AO22X1 U1136 ( .A0(\rxfifo[7][6] ), .A1(n410), .B0(n412), .B1(n413), .Y(
        n3030) );
  AND4X1 U1137 ( .A(n700), .B(n748), .C(baudx16clk), .D(n485), .Y(N223) );
  OAI32X1 U1138 ( .A0(n376), .A1(swrst), .A2(n696), .B0(n798), .B1(n378), .Y(
        n309) );
  OAI32X1 U1139 ( .A0(n489), .A1(rxclkenb), .A2(rxclkcnt[0]), .B0(n699), .B1(
        n483), .Y(n219) );
  OAI32X1 U1140 ( .A0(n489), .A1(n493), .A2(n699), .B0(n495), .B1(n742), .Y(
        n220) );
  NAND2BX1 U1141 ( .AN(rxclkenb), .B(n742), .Y(n493) );
  INVX1 U1142 ( .A(n492), .Y(n495) );
  OAI32X1 U1143 ( .A0(n462), .A1(n788), .A2(n666), .B0(n695), .B1(n667), .Y(
        N306) );
  INVX1 U1144 ( .A(stopbit), .Y(n666) );
  NAND2BX1 U1145 ( .AN(N70), .B(n735), .Y(n567) );
  NAND2BX1 U1146 ( .AN(n738), .B(N69), .Y(n569) );
  OA22X1 U1147 ( .A0(n387), .A1(n718), .B0(n386), .B1(n765), .Y(n659) );
  OA22X1 U1148 ( .A0(n387), .A1(n719), .B0(n386), .B1(n766), .Y(n654) );
  OA22X1 U1149 ( .A0(n387), .A1(n720), .B0(n386), .B1(n767), .Y(n630) );
  OA22X1 U1150 ( .A0(n387), .A1(n721), .B0(n386), .B1(n768), .Y(n606) );
  OA22X1 U1151 ( .A0(n387), .A1(n722), .B0(n386), .B1(n769), .Y(n594) );
  OA22X1 U1152 ( .A0(n387), .A1(n723), .B0(n386), .B1(n770), .Y(n582) );
  OA22X1 U1153 ( .A0(n387), .A1(n724), .B0(n386), .B1(n771), .Y(n575) );
  OA22X1 U1154 ( .A0(n387), .A1(n725), .B0(n386), .B1(n772), .Y(n570) );
  AO22X1 U1155 ( .A0(n797), .A1(n578), .B0(n579), .B1(n693), .Y(fifodata_rx[6]) );
  OAI221X1 U1156 ( .A0(n749), .A1(n567), .B0(n702), .B1(n569), .C0(n582), .Y(
        n579) );
  OAI221X1 U1157 ( .A0(n750), .A1(n567), .B0(n703), .B1(n569), .C0(n647), .Y(
        n638) );
  OA22X1 U1158 ( .A0(n387), .A1(n726), .B0(n386), .B1(n773), .Y(n647) );
  OAI221X1 U1159 ( .A0(n751), .A1(n567), .B0(n704), .B1(n569), .C0(n635), .Y(
        n626) );
  OA22X1 U1160 ( .A0(n387), .A1(n727), .B0(n386), .B1(n774), .Y(n635) );
  OAI221X1 U1161 ( .A0(n752), .A1(n567), .B0(n705), .B1(n569), .C0(n623), .Y(
        n614) );
  OA22X1 U1162 ( .A0(n387), .A1(n728), .B0(n386), .B1(n775), .Y(n623) );
  OAI221X1 U1163 ( .A0(n753), .A1(n567), .B0(n706), .B1(n569), .C0(n611), .Y(
        n602) );
  OA22X1 U1164 ( .A0(n387), .A1(n729), .B0(n386), .B1(n776), .Y(n611) );
  OAI221X1 U1165 ( .A0(n754), .A1(n567), .B0(n707), .B1(n569), .C0(n599), .Y(
        n590) );
  OA22X1 U1166 ( .A0(n387), .A1(n730), .B0(n386), .B1(n777), .Y(n599) );
  OAI221X1 U1167 ( .A0(n755), .A1(n567), .B0(n708), .B1(n569), .C0(n587), .Y(
        n578) );
  OA22X1 U1168 ( .A0(n387), .A1(n731), .B0(n386), .B1(n778), .Y(n587) );
  AO22X1 U1169 ( .A0(n797), .A1(n638), .B0(n639), .B1(n693), .Y(fifodata_rx[1]) );
  AO22X1 U1170 ( .A0(n797), .A1(n626), .B0(n627), .B1(n693), .Y(fifodata_rx[2]) );
  OAI221X1 U1171 ( .A0(n756), .A1(n567), .B0(n709), .B1(n569), .C0(n630), .Y(
        n627) );
  AO22X1 U1172 ( .A0(n797), .A1(n614), .B0(n615), .B1(n693), .Y(fifodata_rx[3]) );
  AO22X1 U1173 ( .A0(n797), .A1(n602), .B0(n603), .B1(n693), .Y(fifodata_rx[4]) );
  OAI221X1 U1174 ( .A0(n757), .A1(n567), .B0(n710), .B1(n569), .C0(n606), .Y(
        n603) );
  AO22X1 U1175 ( .A0(n797), .A1(n590), .B0(n591), .B1(n693), .Y(fifodata_rx[5]) );
  OAI221X1 U1176 ( .A0(n758), .A1(n567), .B0(n711), .B1(n569), .C0(n594), .Y(
        n591) );
  OAI221X1 U1177 ( .A0(n759), .A1(n567), .B0(n712), .B1(n569), .C0(n642), .Y(
        n639) );
  OA22X1 U1178 ( .A0(n387), .A1(n732), .B0(n386), .B1(n779), .Y(n642) );
  OAI221X1 U1179 ( .A0(n760), .A1(n567), .B0(n713), .B1(n569), .C0(n618), .Y(
        n615) );
  OA22X1 U1180 ( .A0(n387), .A1(n733), .B0(n386), .B1(n780), .Y(n618) );
  AO22X1 U1181 ( .A0(n797), .A1(n650), .B0(n651), .B1(n693), .Y(fifodata_rx[0]) );
  OAI221X1 U1182 ( .A0(n762), .A1(n567), .B0(n715), .B1(n569), .C0(n654), .Y(
        n651) );
  OAI221X1 U1183 ( .A0(n761), .A1(n567), .B0(n714), .B1(n569), .C0(n659), .Y(
        n650) );
  AO22X1 U1184 ( .A0(n797), .A1(n564), .B0(n565), .B1(n693), .Y(fifodata_rx[7]) );
  OAI221X1 U1185 ( .A0(n764), .A1(n567), .B0(n717), .B1(n569), .C0(n570), .Y(
        n565) );
  OAI221X1 U1186 ( .A0(n763), .A1(n567), .B0(n716), .B1(n569), .C0(n575), .Y(
        n564) );
  DFFRX1 fifo_rdpos_reg_1_ ( .D(n3070), .CK(clk), .RN(rstb), .Q(N69), .QN(n735) );
  DFFSX1 rx_lpfd_reg ( .D(n234), .CK(clk), .SN(rstb), .Q(rx_lpfd), .QN(n784)
         );
  DFFRX1 fifo_wrpos_reg_1_ ( .D(n310), .CK(clk), .RN(rstb), .Q(fifo_wrpos[1]), 
        .QN(n792) );
  DFFRX1 current_state_reg_1_ ( .D(N292), .CK(clk), .RN(rstb), .Q(
        current_state_1_), .QN(n734) );
  DFFRX1 fifo_wrpos_reg_0_ ( .D(n309), .CK(clk), .RN(rstb), .Q(fifo_wrpos[0]), 
        .QN(n696) );
  DFFRX1 fifo_wrpos_reg_2_ ( .D(n311), .CK(clk), .RN(rstb), .Q(fifo_wrpos[2]), 
        .QN(n694) );
  DFFRX1 fifo_rdpos_reg_0_ ( .D(n3060), .CK(clk), .RN(rstb), .Q(N68), .QN(n693) );
  DFFRX1 current_state_reg_17_ ( .D(N308), .CK(clk), .RN(rstb), .QN(n17) );
  DFFRX1 current_state_reg_2_ ( .D(N293), .CK(clk), .RN(rstb), .Q(
        current_state_2_) );
  DFFRX1 current_state_reg_4_ ( .D(N295), .CK(clk), .RN(rstb), .Q(
        current_state_4_) );
  DFFRX1 current_state_reg_3_ ( .D(N294), .CK(clk), .RN(rstb), .Q(
        current_state_3_) );
  DFFSX1 current_state_reg_0_ ( .D(N291), .CK(clk), .SN(rstb), .QN(n782) );
  DFFRX1 fifofull_reg ( .D(n3050), .CK(clk), .RN(rstb), .Q(rxfifocnt[3]), .QN(
        n736) );
  DFFSX1 in_dly_reg_3_ ( .D(n238), .CK(clk), .SN(rstb), .Q(in_dly[3]), .QN(
        n701) );
  DFFRX1 fifo_rdpos_reg_2_ ( .D(n3080), .CK(clk), .RN(rstb), .Q(N70), .QN(n738) );
  DFFSX1 in_dly_reg_4_ ( .D(n239), .CK(clk), .SN(rstb), .Q(in_dly[4]), .QN(
        n790) );
  DFFRX1 parity_int_reg ( .D(n2230), .CK(clk), .RN(rstb), .Q(parity_int), .QN(
        n743) );
  DFFRX1 current_state_reg_5_ ( .D(N296), .CK(clk), .RN(rstb), .Q(
        current_state_5_) );
  DFFRX1 current_state_reg_6_ ( .D(N297), .CK(clk), .RN(rstb), .Q(
        current_state_6_) );
  DFFRX1 current_state_reg_8_ ( .D(N299), .CK(clk), .RN(rstb), .Q(
        current_state_8_) );
  DFFRX1 current_state_reg_11_ ( .D(N302), .CK(clk), .RN(rstb), .Q(
        current_state_11_), .QN(n737) );
  DFFRX1 current_state_reg_13_ ( .D(N304), .CK(clk), .RN(rstb), .Q(
        current_state_13_), .QN(n692) );
  DFFRX1 current_state_reg_16_ ( .D(N307), .CK(clk), .RN(rstb), .Q(
        current_state_16_), .QN(n740) );
  DFFRX1 current_state_reg_15_ ( .D(N306), .CK(clk), .RN(rstb), .Q(n18), .QN(
        n695) );
  DFFRX1 current_state_reg_14_ ( .D(N305), .CK(clk), .RN(rstb), .Q(
        current_state_14_), .QN(n739) );
  DFFRX1 current_state_reg_12_ ( .D(N303), .CK(clk), .RN(rstb), .QN(n689) );
  DFFRX1 current_state_reg_7_ ( .D(N298), .CK(clk), .RN(rstb), .Q(
        current_state_7_) );
  DFFRX1 current_state_reg_9_ ( .D(N300), .CK(clk), .RN(rstb), .Q(
        current_state_9_) );
  DFFRX1 current_state_reg_10_ ( .D(N301), .CK(clk), .RN(rstb), .Q(
        current_state_10_) );
  DFFSX1 fifowrb_reg ( .D(n211), .CK(clk), .SN(rstb), .Q(bytereceivedb), .QN(
        n794) );
  DFFSX1 in_dly_reg_1_ ( .D(n236), .CK(clk), .SN(rstb), .Q(in_dly[1]), .QN(
        n741) );
  DFFSX1 in_dly_reg_0_ ( .D(n235), .CK(clk), .SN(rstb), .Q(in_dly[0]), .QN(
        n697) );
  DFFSX1 rxclkenb_reg ( .D(n215), .CK(clk), .SN(rstb), .Q(rxclkenb), .QN(n691)
         );
  DFFRX1 rxclkcnt_reg_3_ ( .D(n222), .CK(clk), .RN(rstb), .Q(rxclkcnt[3]), 
        .QN(n748) );
  DFFSX1 framechkb_reg ( .D(n212), .CK(clk), .SN(rstb), .Q(framechkb), .QN(
        n744) );
  DFFSX1 in_dly_reg_2_ ( .D(n237), .CK(clk), .SN(rstb), .Q(in_dly[2]), .QN(
        n690) );
  DFFRX1 rxclkcnt_reg_0_ ( .D(n219), .CK(clk), .RN(rstb), .Q(rxclkcnt[0]), 
        .QN(n699) );
  DFFRX1 rxclkcnt_reg_1_ ( .D(n220), .CK(clk), .RN(rstb), .Q(rxclkcnt[1]), 
        .QN(n742) );
  DFFSX1 dataphaseb_reg ( .D(n218), .CK(clk), .SN(rstb), .Q(dataphaseb), .QN(
        n745) );
  DFFSX1 rxsftenb_reg ( .D(n214), .CK(clk), .SN(rstb), .Q(rxsftenb), .QN(n746)
         );
  DFFSX1 paritychkb_reg ( .D(n213), .CK(clk), .SN(rstb), .Q(paritychkb), .QN(
        n747) );
  DFFRX1 rxclkcnt_reg_2_ ( .D(n221), .CK(clk), .RN(rstb), .Q(rxclkcnt[2]), 
        .QN(n700) );
  DFFRX1 rxfifo_reg ( .D(n241), .CK(clk), .RN(rstb), .Q(\rxfifo[0][0] ), .QN(
        n762) );
  DFFRX1 rxfifo_reg0 ( .D(n242), .CK(clk), .RN(rstb), .Q(\rxfifo[0][1] ), .QN(
        n759) );
  DFFRX1 rxfifo_reg1 ( .D(n243), .CK(clk), .RN(rstb), .Q(\rxfifo[0][2] ), .QN(
        n756) );
  DFFRX1 rxfifo_reg2 ( .D(n244), .CK(clk), .RN(rstb), .Q(\rxfifo[0][3] ), .QN(
        n760) );
  DFFRX1 rxfifo_reg3 ( .D(n245), .CK(clk), .RN(rstb), .Q(\rxfifo[0][4] ), .QN(
        n757) );
  DFFRX1 rxfifo_reg4 ( .D(n246), .CK(clk), .RN(rstb), .Q(\rxfifo[0][5] ), .QN(
        n758) );
  DFFRX1 rxfifo_reg5 ( .D(n247), .CK(clk), .RN(rstb), .Q(\rxfifo[0][6] ), .QN(
        n749) );
  DFFRX1 rxfifo_reg6 ( .D(n248), .CK(clk), .RN(rstb), .Q(\rxfifo[0][7] ), .QN(
        n764) );
  DFFRX1 rxfifo_reg7 ( .D(n249), .CK(clk), .RN(rstb), .Q(\rxfifo[1][0] ), .QN(
        n761) );
  DFFRX1 rxfifo_reg8 ( .D(n250), .CK(clk), .RN(rstb), .Q(\rxfifo[1][1] ), .QN(
        n750) );
  DFFRX1 rxfifo_reg9 ( .D(n251), .CK(clk), .RN(rstb), .Q(\rxfifo[1][2] ), .QN(
        n751) );
  DFFRX1 rxfifo_reg10 ( .D(n252), .CK(clk), .RN(rstb), .Q(\rxfifo[1][3] ), 
        .QN(n752) );
  DFFRX1 rxfifo_reg11 ( .D(n253), .CK(clk), .RN(rstb), .Q(\rxfifo[1][4] ), 
        .QN(n753) );
  DFFRX1 rxfifo_reg12 ( .D(n254), .CK(clk), .RN(rstb), .Q(\rxfifo[1][5] ), 
        .QN(n754) );
  DFFRX1 rxfifo_reg13 ( .D(n255), .CK(clk), .RN(rstb), .Q(\rxfifo[1][6] ), 
        .QN(n755) );
  DFFRX1 rxfifo_reg14 ( .D(n256), .CK(clk), .RN(rstb), .Q(\rxfifo[1][7] ), 
        .QN(n763) );
  DFFRX1 rxfifo_reg15 ( .D(n257), .CK(clk), .RN(rstb), .Q(\rxfifo[2][0] ), 
        .QN(n719) );
  DFFRX1 rxfifo_reg16 ( .D(n258), .CK(clk), .RN(rstb), .Q(\rxfifo[2][1] ), 
        .QN(n732) );
  DFFRX1 rxfifo_reg17 ( .D(n259), .CK(clk), .RN(rstb), .Q(\rxfifo[2][2] ), 
        .QN(n720) );
  DFFRX1 rxfifo_reg18 ( .D(n260), .CK(clk), .RN(rstb), .Q(\rxfifo[2][3] ), 
        .QN(n733) );
  DFFRX1 rxfifo_reg19 ( .D(n261), .CK(clk), .RN(rstb), .Q(\rxfifo[2][4] ), 
        .QN(n721) );
  DFFRX1 rxfifo_reg20 ( .D(n262), .CK(clk), .RN(rstb), .Q(\rxfifo[2][5] ), 
        .QN(n722) );
  DFFRX1 rxfifo_reg21 ( .D(n263), .CK(clk), .RN(rstb), .Q(\rxfifo[2][6] ), 
        .QN(n723) );
  DFFRX1 rxfifo_reg22 ( .D(n264), .CK(clk), .RN(rstb), .Q(\rxfifo[2][7] ), 
        .QN(n725) );
  DFFRX1 rxfifo_reg23 ( .D(n265), .CK(clk), .RN(rstb), .Q(\rxfifo[3][0] ), 
        .QN(n718) );
  DFFRX1 rxfifo_reg24 ( .D(n266), .CK(clk), .RN(rstb), .Q(\rxfifo[3][1] ), 
        .QN(n726) );
  DFFRX1 rxfifo_reg25 ( .D(n267), .CK(clk), .RN(rstb), .Q(\rxfifo[3][2] ), 
        .QN(n727) );
  DFFRX1 rxfifo_reg26 ( .D(n268), .CK(clk), .RN(rstb), .Q(\rxfifo[3][3] ), 
        .QN(n728) );
  DFFRX1 rxfifo_reg27 ( .D(n269), .CK(clk), .RN(rstb), .Q(\rxfifo[3][4] ), 
        .QN(n729) );
  DFFRX1 rxfifo_reg28 ( .D(n270), .CK(clk), .RN(rstb), .Q(\rxfifo[3][5] ), 
        .QN(n730) );
  DFFRX1 rxfifo_reg29 ( .D(n271), .CK(clk), .RN(rstb), .Q(\rxfifo[3][6] ), 
        .QN(n731) );
  DFFRX1 rxfifo_reg30 ( .D(n272), .CK(clk), .RN(rstb), .Q(\rxfifo[3][7] ), 
        .QN(n724) );
  DFFRX1 rxfifo_reg31 ( .D(n273), .CK(clk), .RN(rstb), .Q(\rxfifo[4][0] ), 
        .QN(n766) );
  DFFRX1 rxfifo_reg32 ( .D(n274), .CK(clk), .RN(rstb), .Q(\rxfifo[4][1] ), 
        .QN(n779) );
  DFFRX1 rxfifo_reg33 ( .D(n275), .CK(clk), .RN(rstb), .Q(\rxfifo[4][2] ), 
        .QN(n767) );
  DFFRX1 rxfifo_reg34 ( .D(n276), .CK(clk), .RN(rstb), .Q(\rxfifo[4][3] ), 
        .QN(n780) );
  DFFRX1 rxfifo_reg35 ( .D(n277), .CK(clk), .RN(rstb), .Q(\rxfifo[4][4] ), 
        .QN(n768) );
  DFFRX1 rxfifo_reg36 ( .D(n278), .CK(clk), .RN(rstb), .Q(\rxfifo[4][5] ), 
        .QN(n769) );
  DFFRX1 rxfifo_reg37 ( .D(n279), .CK(clk), .RN(rstb), .Q(\rxfifo[4][6] ), 
        .QN(n770) );
  DFFRX1 rxfifo_reg38 ( .D(n280), .CK(clk), .RN(rstb), .Q(\rxfifo[4][7] ), 
        .QN(n772) );
  DFFRX1 rxfifo_reg39 ( .D(n281), .CK(clk), .RN(rstb), .Q(\rxfifo[5][0] ), 
        .QN(n765) );
  DFFRX1 rxfifo_reg40 ( .D(n282), .CK(clk), .RN(rstb), .Q(\rxfifo[5][1] ), 
        .QN(n773) );
  DFFRX1 rxfifo_reg41 ( .D(n283), .CK(clk), .RN(rstb), .Q(\rxfifo[5][2] ), 
        .QN(n774) );
  DFFRX1 rxfifo_reg42 ( .D(n284), .CK(clk), .RN(rstb), .Q(\rxfifo[5][3] ), 
        .QN(n775) );
  DFFRX1 rxfifo_reg43 ( .D(n285), .CK(clk), .RN(rstb), .Q(\rxfifo[5][4] ), 
        .QN(n776) );
  DFFRX1 rxfifo_reg44 ( .D(n286), .CK(clk), .RN(rstb), .Q(\rxfifo[5][5] ), 
        .QN(n777) );
  DFFRX1 rxfifo_reg45 ( .D(n287), .CK(clk), .RN(rstb), .Q(\rxfifo[5][6] ), 
        .QN(n778) );
  DFFRX1 rxfifo_reg46 ( .D(n288), .CK(clk), .RN(rstb), .Q(\rxfifo[5][7] ), 
        .QN(n771) );
  DFFRX1 rxfifo_reg47 ( .D(n289), .CK(clk), .RN(rstb), .Q(\rxfifo[6][0] ), 
        .QN(n715) );
  DFFRX1 rxfifo_reg48 ( .D(n290), .CK(clk), .RN(rstb), .Q(\rxfifo[6][1] ), 
        .QN(n712) );
  DFFRX1 rxfifo_reg49 ( .D(n2910), .CK(clk), .RN(rstb), .Q(\rxfifo[6][2] ), 
        .QN(n709) );
  DFFRX1 rxfifo_reg50 ( .D(n2920), .CK(clk), .RN(rstb), .Q(\rxfifo[6][3] ), 
        .QN(n713) );
  DFFRX1 rxfifo_reg51 ( .D(n2930), .CK(clk), .RN(rstb), .Q(\rxfifo[6][4] ), 
        .QN(n710) );
  DFFRX1 rxfifo_reg52 ( .D(n2940), .CK(clk), .RN(rstb), .Q(\rxfifo[6][5] ), 
        .QN(n711) );
  DFFRX1 rxfifo_reg53 ( .D(n2950), .CK(clk), .RN(rstb), .Q(\rxfifo[6][6] ), 
        .QN(n702) );
  DFFRX1 rxfifo_reg54 ( .D(n2960), .CK(clk), .RN(rstb), .Q(\rxfifo[6][7] ), 
        .QN(n717) );
  DFFRX1 rxfifo_reg55 ( .D(n2970), .CK(clk), .RN(rstb), .Q(\rxfifo[7][0] ), 
        .QN(n714) );
  DFFRX1 rxfifo_reg56 ( .D(n2980), .CK(clk), .RN(rstb), .Q(\rxfifo[7][1] ), 
        .QN(n703) );
  DFFRX1 rxfifo_reg57 ( .D(n2990), .CK(clk), .RN(rstb), .Q(\rxfifo[7][2] ), 
        .QN(n704) );
  DFFRX1 rxfifo_reg58 ( .D(n3000), .CK(clk), .RN(rstb), .Q(\rxfifo[7][3] ), 
        .QN(n705) );
  DFFRX1 rxfifo_reg59 ( .D(n3010), .CK(clk), .RN(rstb), .Q(\rxfifo[7][4] ), 
        .QN(n706) );
  DFFRX1 rxfifo_reg60 ( .D(n3020), .CK(clk), .RN(rstb), .Q(\rxfifo[7][5] ), 
        .QN(n707) );
  DFFRX1 rxfifo_reg61 ( .D(n3030), .CK(clk), .RN(rstb), .Q(\rxfifo[7][6] ), 
        .QN(n708) );
  DFFRX1 rxfifo_reg62 ( .D(n3040), .CK(clk), .RN(rstb), .Q(\rxfifo[7][7] ), 
        .QN(n716) );
  DFFRX1 parityerror_int_reg ( .D(n224), .CK(clk), .RN(rstb), .Q(parityerror), 
        .QN(n210) );
  DFFRX1 frameerror_int_reg ( .D(n225), .CK(clk), .RN(rstb), .Q(frameerror), 
        .QN(n208) );
  DFFSX1 rstparityb_reg ( .D(n217), .CK(clk), .SN(rstb), .QN(n698) );
  DFFRX1 rxsftreg_reg_7_ ( .D(n233), .CK(clk), .RN(rstb), .Q(rxsftreg[7]), 
        .QN(n796) );
  DFFRX1 overrunerror_int_reg ( .D(n312), .CK(clk), .RN(rstb), .Q(overrunerror), .QN(n209) );
  DFFRX1 rxsftreg_reg_1_ ( .D(n227), .CK(clk), .RN(rstb), .Q(rxsftreg[1]) );
  DFFRX1 rxsftreg_reg_2_ ( .D(n228), .CK(clk), .RN(rstb), .Q(rxsftreg[2]) );
  DFFRX1 rxsftreg_reg_3_ ( .D(n229), .CK(clk), .RN(rstb), .Q(rxsftreg[3]) );
  DFFRX1 rxsftreg_reg_4_ ( .D(n230), .CK(clk), .RN(rstb), .Q(rxsftreg[4]) );
  DFFRX1 rxsftreg_reg_5_ ( .D(n231), .CK(clk), .RN(rstb), .Q(rxsftreg[5]) );
  DFFRX1 rxsftreg_reg_6_ ( .D(n232), .CK(clk), .RN(rstb), .Q(rxsftreg[6]) );
  DFFSX1 in_dly_reg_5_ ( .D(n240), .CK(clk), .SN(rstb), .Q(in_dly[5]) );
  DFFRX1 rxsftreg_reg_0_ ( .D(n226), .CK(clk), .RN(rstb), .Q(rxsftreg[0]) );
  DFFRX1 rxbusy_int_reg ( .D(n216), .CK(clk), .RN(rstb), .Q(rxbusy) );
endmodule


module RegBlk_1_3_0 ( PADDR, PENABLE, PSEL, PWDATA, PWRITE, bytereceivedb, clk, 
        fifodata_rx, frameerror, overrunerror, parityerror, rstb, rxbusy, 
        rxfifocnt, rxfifoempty, txbusy, txfifo_emptyb, txfifo_fillb, 
        txfifo_fullb, txfifocnt, PRDATA, baudx16clk, databit, fifodata_tx, 
        fifordb, fifowrb, int, loopbacken, parity, rxdmareq, stopbit, swrst, 
        txdmareq, uarten, frameerr_clear, parityerr_clear, overrunerr_clear );
  input [4:2] PADDR;
  input [31:0] PWDATA;
  input [7:0] fifodata_rx;
  input [3:0] rxfifocnt;
  input [3:0] txfifocnt;
  output [31:0] PRDATA;
  output [7:0] fifodata_tx;
  output [1:0] parity;
  input PENABLE, PSEL, PWRITE, bytereceivedb, clk, frameerror, overrunerror,
         parityerror, rstb, rxbusy, rxfifoempty, txbusy, txfifo_emptyb,
         txfifo_fillb, txfifo_fullb;
  output baudx16clk, databit, fifordb, fifowrb, int, loopbacken, rxdmareq,
         stopbit, swrst, txdmareq, uarten, frameerr_clear, parityerr_clear,
         overrunerr_clear;
  wire   n288, n289, n290, n291, n292, n293, n294, n295, reg_0x0000_30_,
         reg_0x0000_29_, reg_0x0000_27_, reg_0x0000_15_, reg_0x0000_7_,
         reg_0x0004_22_, reg_0x0004_7_, N50, N52, N53, N61, N62, N63,
         clkdivcnt_msb_dly, N91, N92, N93, N94, N95, N96, N97, N98, N99, N100,
         N101, N102, N103, N104, N105, N110, N113, N114, N115, N116, N117,
         N118, N119, N120, N121, N122, N123, N124, N125, N126, N127, N128,
         N129, N130, n10, n134, n135, n136, n137, n138, n139, n140, n141, n142,
         n143, n144, n145, n146, n147, n148, n149, n150, n151, n152, n153,
         n154, n155, n156, n157, n158, n159, n160, n161, n162, n163, n164,
         n165, n166, n167, n168, n169, n170, n171, n172, n173, n174, n175,
         n176, n177, n178, n179, n180, n181, n182, n183, n184, n185, n186,
         n187, n188, n189, n190, n191, n192, n193, n194, n195, n196, n197,
         n198, n199, n200, n201, n202, n203, n204, n205, n206, n207, n208,
         n209, n210, n211, n212, n213, n214, n215, n216, n217, n218, n219,
         n220, n221, n222, n223, n224, n225, n226, n227, n228, n229, n230,
         n231, n517, carry, carry0, carry1, carry2, carry3, carry4, carry5,
         carry6, carry7, carry8, carry9, carry10, carry11, carry12, carry_1_,
         n1101, n233, n310, n410, n510, n610, n710, n810, n910, n1011, n1111,
         n1211, n1311, n1411, carry_18_, carry_17_, carry_16_, carry_15_,
         carry_14_, carry_13_, carry_12_, carry_11_, carry_10_, carry_9_,
         carry_8_, carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_,
         n1100, n2, n3, n4, n5, n6, n7, n8, n9, n1010, n1110, n1210, n1310,
         n1410, n1510, n1610, n1710, n1810, n297, n298, n299, n301, n302, n303,
         n304, n307, n312, n313, n314, n315, n316, n317, n319, n320, n322,
         n323, n325, n327, n329, n330, n331, n332, n333, n334, n335, n336,
         n337, n340, n341, n342, n345, n346, n347, n350, n351, n352, n353,
         n354, n355, n356, n359, n360, n361, n364, n365, n366, n369, n370,
         n371, n372, n373, n375, n376, n379, n381, n386, n387, n388, n389,
         n391, n393, n395, n396, n398, n399, n401, n402, n404, n407, n412,
         n417, n419, n422, n424, n426, n428, n429, n430, n431, n432, n433,
         n434, n435, n436, n437, n438, n439, n442, n443, n444, n445, n446,
         n447, n448, n451, n452, n454, n455, n456, n457, n458, n459, n460,
         n461, n462, n463, n464, n465, n466, n467, n468, n469, n470, n471,
         n472, n473, n474, n475, n476, n477, n478, n479, n480, n481, n482,
         n483, n484, n485, n486, n487, n488, n489, n490, n491, n492, n493,
         n494, n495, n496, n497, n498, n499, n500, n501, n502, n503, n504,
         n505, n507, n508, n509, n511, n512, n513, n514, n515;
  wire   [5:0] txwaterlevel_int;
  wire   [5:0] rxwaterlevel_int;
  wire   [15:0] clkdiv;
  wire   [15:0] clkdivcnt;
  wire   [19:0] timeoutcnt;
  wire   [19:0] timeoutcnt_int;
  assign PRDATA[20] = 1'b0;
  assign PRDATA[21] = 1'b0;
  assign fifodata_tx[7] = n288;
  assign n288 = PWDATA[7];
  assign fifodata_tx[6] = n289;
  assign n289 = PWDATA[6];
  assign fifodata_tx[5] = n290;
  assign n290 = PWDATA[5];
  assign fifodata_tx[4] = n291;
  assign n291 = PWDATA[4];
  assign fifodata_tx[3] = n292;
  assign n292 = PWDATA[3];
  assign fifodata_tx[2] = n293;
  assign n293 = PWDATA[2];
  assign fifodata_tx[1] = n294;
  assign n294 = PWDATA[1];
  assign fifodata_tx[0] = n295;
  assign n295 = PWDATA[0];

  AHHCONX2 U1_1_1 ( .A(timeoutcnt_int[1]), .CI(timeoutcnt_int[0]), .S(N113), 
        .CON(n1810) );
  AHHCONX2 U1_1_2 ( .A(timeoutcnt_int[2]), .CI(carry_2_), .S(N114), .CON(n1710) );
  AHHCONX2 U1_1_3 ( .A(timeoutcnt_int[3]), .CI(carry_3_), .S(N115), .CON(n1610) );
  AHHCONX2 U1_1_4 ( .A(timeoutcnt_int[4]), .CI(carry_4_), .S(N116), .CON(n1510) );
  AHHCONX2 U1_1_5 ( .A(timeoutcnt_int[5]), .CI(carry_5_), .S(N117), .CON(n1410) );
  AHHCONX2 U1_1_6 ( .A(timeoutcnt_int[6]), .CI(carry_6_), .S(N118), .CON(n1310) );
  AHHCONX2 U1_1_7 ( .A(timeoutcnt_int[7]), .CI(carry_7_), .S(N119), .CON(n1210) );
  AHHCONX2 U1_1_8 ( .A(timeoutcnt_int[8]), .CI(carry_8_), .S(N120), .CON(n1110) );
  AHHCONX2 U1_1_9 ( .A(timeoutcnt_int[9]), .CI(carry_9_), .S(N121), .CON(n1010) );
  AHHCONX2 U1_1_10 ( .A(timeoutcnt_int[10]), .CI(carry_10_), .S(N122), .CON(n9) );
  AHHCONX2 U1_1_11 ( .A(timeoutcnt_int[11]), .CI(carry_11_), .S(N123), .CON(n8) );
  AHHCONX2 U1_1_12 ( .A(timeoutcnt_int[12]), .CI(carry_12_), .S(N124), .CON(n7) );
  AHHCONX2 U1_1_13 ( .A(timeoutcnt_int[13]), .CI(carry_13_), .S(N125), .CON(n6) );
  AHHCONX2 U1_1_14 ( .A(timeoutcnt_int[14]), .CI(carry_14_), .S(N126), .CON(n5) );
  AHHCONX2 U1_1_15 ( .A(timeoutcnt_int[15]), .CI(carry_15_), .S(N127), .CON(n4) );
  AHHCONX2 U1_1_16 ( .A(timeoutcnt_int[16]), .CI(carry_16_), .S(N128), .CON(n3) );
  AHHCONX2 U1_1_17 ( .A(timeoutcnt_int[17]), .CI(carry_17_), .S(N129), .CON(n2) );
  AHHCONX2 U1_1_18 ( .A(timeoutcnt_int[18]), .CI(carry_18_), .S(N130), .CON(
        n1100) );
  DFFRX1 swrst_int_reg ( .D(N50), .CK(clk), .RN(rstb), .Q(swrst), .QN(n476) );
  INVX1 U647 ( .A(n312), .Y(n313) );
  INVX1 U648 ( .A(n513), .Y(n303) );
  INVX1 U649 ( .A(n323), .Y(n315) );
  INVX1 U650 ( .A(n317), .Y(n320) );
  INVX1 U651 ( .A(txfifocnt[0]), .Y(n379) );
  NAND2BX1 U652 ( .AN(n369), .B(n370), .Y(fifowrb) );
  NAND2BX1 U653 ( .AN(n509), .B(n500), .Y(n312) );
  NAND2BX1 U654 ( .AN(n509), .B(n500), .Y(n512) );
  NAND2BX1 U655 ( .AN(n509), .B(n500), .Y(n511) );
  INVX1 U656 ( .A(n298), .Y(n299) );
  BUFX2 U657 ( .A(n302), .Y(n513) );
  NAND2BX1 U658 ( .AN(n304), .B(n500), .Y(n302) );
  INVX1 U659 ( .A(n508), .Y(n301) );
  DFFRX1 baudx16clk_int_reg ( .D(n175), .CK(clk), .RN(rstb), .Q(baudx16clk), 
        .QN(n456) );
  DFFRX1 databit_int_reg ( .D(n217), .CK(clk), .RN(rstb), .Q(databit) );
  DFFRX1 parity_int_reg_1_ ( .D(n219), .CK(clk), .RN(rstb), .Q(parity[1]) );
  NAND2BX1 U660 ( .AN(n322), .B(n456), .Y(n323) );
  NAND2BX1 U661 ( .AN(n322), .B(n323), .Y(n317) );
  OAI221X1 U662 ( .A0(rxfifocnt[2]), .A1(n480), .B0(rxfifocnt[1]), .B1(n465), 
        .C0(n437), .Y(n439) );
  NOR2BX1 U663 ( .AN(n412), .B(n468), .Y(N52) );
  AO22X1 U664 ( .A0(txfifocnt[1]), .A1(n469), .B0(txfifocnt[2]), .B1(n483), 
        .Y(n442) );
  INVX1 U665 ( .A(txfifocnt[2]), .Y(n422) );
  INVX1 U666 ( .A(rxfifocnt[2]), .Y(n399) );
  INVX1 U667 ( .A(txfifocnt[1]), .Y(n373) );
  INVX1 U668 ( .A(n437), .Y(n436) );
  INVX1 U669 ( .A(n304), .Y(n388) );
  INVX1 U670 ( .A(PRDATA[28]), .Y(n372) );
  INVX1 U671 ( .A(n297), .Y(txdmareq) );
  INVX1 U672 ( .A(n509), .Y(n387) );
  NAND4BX1 U673 ( .AN(PWRITE), .B(PENABLE), .C(PSEL), .D(n371), .Y(fifordb) );
  AND3X2 U674 ( .A(PENABLE), .B(PSEL), .C(PWRITE), .Y(n500) );
  INVX1 U675 ( .A(n429), .Y(n371) );
  NAND3BX1 U676 ( .AN(PADDR[3]), .B(n430), .C(PADDR[4]), .Y(n429) );
  INVX1 U677 ( .A(n433), .Y(n370) );
  NAND3BX1 U678 ( .AN(PADDR[4]), .B(PADDR[2]), .C(n500), .Y(n433) );
  NAND3BX1 U679 ( .AN(PADDR[4]), .B(n430), .C(PADDR[3]), .Y(n304) );
  NAND3BX1 U680 ( .AN(PWDATA[28]), .B(n500), .C(n301), .Y(n298) );
  NAND3BX1 U681 ( .AN(PWDATA[28]), .B(n500), .C(n301), .Y(n515) );
  NAND3BX1 U682 ( .AN(PWDATA[28]), .B(n500), .C(n301), .Y(n514) );
  INVX1 U683 ( .A(PADDR[2]), .Y(n430) );
  NAND2BX1 U684 ( .AN(PADDR[3]), .B(n370), .Y(n432) );
  INVX1 U685 ( .A(PADDR[3]), .Y(n369) );
  BUFX2 U686 ( .A(n375), .Y(n508) );
  NAND3BX1 U687 ( .AN(PADDR[4]), .B(n369), .C(n430), .Y(n375) );
  NOR3BX1 U688 ( .AN(n500), .B(n508), .C(n448), .Y(N50) );
  INVX1 U689 ( .A(PWDATA[28]), .Y(n448) );
  BUFX2 U690 ( .A(n314), .Y(n509) );
  NAND3BX1 U691 ( .AN(PADDR[3]), .B(PADDR[2]), .C(PADDR[4]), .Y(n314) );
  NOR2BX1 U692 ( .AN(PWDATA[24]), .B(n432), .Y(N61) );
  NOR2BX1 U693 ( .AN(PWDATA[25]), .B(n432), .Y(N62) );
  NOR2BX1 U694 ( .AN(PWDATA[23]), .B(n432), .Y(N63) );
  AO22X1 U695 ( .A0(timeoutcnt[16]), .A1(n511), .B0(PWDATA[16]), .B1(n313), 
        .Y(n171) );
  AO22X1 U696 ( .A0(timeoutcnt[17]), .A1(n511), .B0(PWDATA[17]), .B1(n313), 
        .Y(n172) );
  AO22X1 U697 ( .A0(timeoutcnt[18]), .A1(n512), .B0(PWDATA[18]), .B1(n313), 
        .Y(n173) );
  AO22X1 U698 ( .A0(timeoutcnt[19]), .A1(n511), .B0(PWDATA[19]), .B1(n313), 
        .Y(n174) );
  AO22X1 U699 ( .A0(clkdiv[6]), .A1(n513), .B0(n289), .B1(n303), .Y(n199) );
  AO22X1 U700 ( .A0(clkdiv[14]), .A1(n513), .B0(PWDATA[14]), .B1(n303), .Y(
        n207) );
  AO22X1 U701 ( .A0(txwaterlevel_int[0]), .A1(n515), .B0(PWDATA[8]), .B1(n299), 
        .Y(n209) );
  AO22X1 U702 ( .A0(txwaterlevel_int[1]), .A1(n514), .B0(PWDATA[9]), .B1(n299), 
        .Y(n210) );
  AO22X1 U703 ( .A0(txwaterlevel_int[2]), .A1(n298), .B0(PWDATA[10]), .B1(n299), .Y(n211) );
  AO22X1 U704 ( .A0(txwaterlevel_int[3]), .A1(n515), .B0(PWDATA[11]), .B1(n299), .Y(n212) );
  AO22X1 U705 ( .A0(txwaterlevel_int[4]), .A1(n514), .B0(PWDATA[12]), .B1(n299), .Y(n213) );
  AO22X1 U706 ( .A0(txwaterlevel_int[5]), .A1(n298), .B0(PWDATA[13]), .B1(n299), .Y(n214) );
  AO22X1 U707 ( .A0(loopbacken), .A1(n515), .B0(PWDATA[22]), .B1(n299), .Y(
        n215) );
  AO22X1 U708 ( .A0(stopbit), .A1(n514), .B0(PWDATA[23]), .B1(n299), .Y(n216)
         );
  AO22X1 U709 ( .A0(databit), .A1(n298), .B0(PWDATA[24]), .B1(n299), .Y(n217)
         );
  AO22X1 U710 ( .A0(parity[0]), .A1(n515), .B0(PWDATA[25]), .B1(n299), .Y(n218) );
  AO22X1 U711 ( .A0(parity[1]), .A1(n514), .B0(PWDATA[26]), .B1(n299), .Y(n219) );
  AO22X1 U712 ( .A0(reg_0x0000_27_), .A1(n515), .B0(PWDATA[27]), .B1(n299), 
        .Y(n220) );
  AO22X1 U713 ( .A0(reg_0x0000_29_), .A1(n515), .B0(PWDATA[29]), .B1(n299), 
        .Y(n221) );
  AO22X1 U714 ( .A0(reg_0x0000_30_), .A1(n514), .B0(PWDATA[30]), .B1(n299), 
        .Y(n222) );
  AO22X1 U715 ( .A0(n517), .A1(n514), .B0(PWDATA[31]), .B1(n299), .Y(n223) );
  AO22X1 U716 ( .A0(reg_0x0000_7_), .A1(n515), .B0(n288), .B1(n299), .Y(n224)
         );
  AO22X1 U717 ( .A0(reg_0x0000_15_), .A1(n514), .B0(PWDATA[15]), .B1(n299), 
        .Y(n225) );
  AO22X1 U718 ( .A0(rxwaterlevel_int[0]), .A1(n515), .B0(n295), .B1(n299), .Y(
        n226) );
  AO22X1 U719 ( .A0(rxwaterlevel_int[1]), .A1(n515), .B0(n294), .B1(n299), .Y(
        n227) );
  AO22X1 U720 ( .A0(rxwaterlevel_int[2]), .A1(n514), .B0(n293), .B1(n299), .Y(
        n228) );
  AO22X1 U721 ( .A0(rxwaterlevel_int[3]), .A1(n514), .B0(n292), .B1(n299), .Y(
        n229) );
  AO22X1 U722 ( .A0(rxwaterlevel_int[4]), .A1(n515), .B0(n291), .B1(n299), .Y(
        n230) );
  AO22X1 U723 ( .A0(rxwaterlevel_int[5]), .A1(n514), .B0(n290), .B1(n299), .Y(
        n231) );
  AO22X1 U724 ( .A0(timeoutcnt[0]), .A1(n512), .B0(n313), .B1(n295), .Y(n155)
         );
  AO22X1 U725 ( .A0(timeoutcnt[1]), .A1(n511), .B0(n313), .B1(n294), .Y(n156)
         );
  AO22X1 U726 ( .A0(timeoutcnt[2]), .A1(n312), .B0(n313), .B1(n293), .Y(n157)
         );
  AO22X1 U727 ( .A0(timeoutcnt[3]), .A1(n512), .B0(n313), .B1(n292), .Y(n158)
         );
  AO22X1 U728 ( .A0(timeoutcnt[4]), .A1(n511), .B0(n313), .B1(n291), .Y(n159)
         );
  AO22X1 U729 ( .A0(timeoutcnt[5]), .A1(n312), .B0(n313), .B1(n290), .Y(n160)
         );
  AO22X1 U730 ( .A0(timeoutcnt[6]), .A1(n512), .B0(n313), .B1(n289), .Y(n161)
         );
  AO22X1 U731 ( .A0(timeoutcnt[7]), .A1(n511), .B0(n313), .B1(n288), .Y(n162)
         );
  AO22X1 U732 ( .A0(timeoutcnt[8]), .A1(n512), .B0(n313), .B1(PWDATA[8]), .Y(
        n163) );
  AO22X1 U733 ( .A0(timeoutcnt[9]), .A1(n512), .B0(n313), .B1(PWDATA[9]), .Y(
        n164) );
  AO22X1 U734 ( .A0(timeoutcnt[10]), .A1(n511), .B0(n313), .B1(PWDATA[10]), 
        .Y(n165) );
  AO22X1 U735 ( .A0(timeoutcnt[11]), .A1(n511), .B0(n313), .B1(PWDATA[11]), 
        .Y(n166) );
  AO22X1 U736 ( .A0(timeoutcnt[12]), .A1(n512), .B0(n313), .B1(PWDATA[12]), 
        .Y(n167) );
  AO22X1 U737 ( .A0(timeoutcnt[13]), .A1(n511), .B0(n313), .B1(PWDATA[13]), 
        .Y(n168) );
  AO22X1 U738 ( .A0(timeoutcnt[14]), .A1(n512), .B0(n313), .B1(PWDATA[14]), 
        .Y(n169) );
  AO22X1 U739 ( .A0(timeoutcnt[15]), .A1(n512), .B0(n313), .B1(PWDATA[15]), 
        .Y(n170) );
  AO22X1 U740 ( .A0(clkdiv[0]), .A1(n513), .B0(n303), .B1(n295), .Y(n193) );
  AO22X1 U741 ( .A0(clkdiv[1]), .A1(n513), .B0(n303), .B1(n294), .Y(n194) );
  AO22X1 U742 ( .A0(clkdiv[2]), .A1(n513), .B0(n303), .B1(n293), .Y(n195) );
  AO22X1 U743 ( .A0(clkdiv[3]), .A1(n513), .B0(n303), .B1(n292), .Y(n196) );
  AO22X1 U744 ( .A0(clkdiv[4]), .A1(n513), .B0(n303), .B1(n291), .Y(n197) );
  AO22X1 U745 ( .A0(clkdiv[5]), .A1(n513), .B0(n303), .B1(n290), .Y(n198) );
  AO22X1 U746 ( .A0(clkdiv[7]), .A1(n513), .B0(n303), .B1(n288), .Y(n200) );
  AO22X1 U747 ( .A0(clkdiv[8]), .A1(n513), .B0(n303), .B1(PWDATA[8]), .Y(n201)
         );
  AO22X1 U748 ( .A0(clkdiv[9]), .A1(n513), .B0(n303), .B1(PWDATA[9]), .Y(n202)
         );
  AO22X1 U749 ( .A0(clkdiv[10]), .A1(n513), .B0(n303), .B1(PWDATA[10]), .Y(
        n203) );
  AO22X1 U750 ( .A0(clkdiv[11]), .A1(n513), .B0(n303), .B1(PWDATA[11]), .Y(
        n204) );
  AO22X1 U751 ( .A0(clkdiv[12]), .A1(n513), .B0(n303), .B1(PWDATA[12]), .Y(
        n205) );
  AO22X1 U752 ( .A0(clkdiv[13]), .A1(n513), .B0(n303), .B1(PWDATA[13]), .Y(
        n206) );
  AO22X1 U753 ( .A0(clkdiv[15]), .A1(n513), .B0(n303), .B1(PWDATA[15]), .Y(
        n208) );
  INVX1 U754 ( .A(n2), .Y(carry_18_) );
  INVX1 U755 ( .A(n1810), .Y(carry_2_) );
  INVX1 U756 ( .A(n1710), .Y(carry_3_) );
  INVX1 U757 ( .A(n1610), .Y(carry_4_) );
  INVX1 U758 ( .A(n1510), .Y(carry_5_) );
  INVX1 U759 ( .A(n1410), .Y(carry_6_) );
  INVX1 U760 ( .A(n1310), .Y(carry_7_) );
  INVX1 U761 ( .A(n1210), .Y(carry_8_) );
  INVX1 U762 ( .A(n1110), .Y(carry_9_) );
  INVX1 U763 ( .A(n9), .Y(carry_11_) );
  INVX1 U764 ( .A(n7), .Y(carry_13_) );
  INVX1 U765 ( .A(n5), .Y(carry_15_) );
  INVX1 U766 ( .A(n3), .Y(carry_17_) );
  INVX1 U767 ( .A(n1010), .Y(carry_10_) );
  INVX1 U768 ( .A(n8), .Y(carry_12_) );
  INVX1 U769 ( .A(n6), .Y(carry_14_) );
  INVX1 U770 ( .A(n4), .Y(carry_16_) );
  AO21X1 U771 ( .A0(n315), .A1(timeoutcnt_int[19]), .B0(n316), .Y(n154) );
  OAI33X1 U772 ( .A0(n317), .A1(n502), .A2(n319), .B0(n317), .B1(
        timeoutcnt_int[19]), .B2(n1100), .Y(n316) );
  INVX1 U773 ( .A(n1100), .Y(n319) );
  AFHCONX2 U1_1 ( .A(clkdivcnt[1]), .B(clkdiv[1]), .CI(carry_1_), .S(N91), 
        .CON(n1411) );
  NOR2BX1 U774 ( .AN(clkdivcnt[0]), .B(n475), .Y(carry_1_) );
  AFHCONX2 U1_2 ( .A(clkdivcnt[2]), .B(clkdiv[2]), .CI(carry12), .S(N92), 
        .CON(n1311) );
  INVX1 U775 ( .A(n1411), .Y(carry12) );
  AFHCONX2 U1_3 ( .A(clkdivcnt[3]), .B(clkdiv[3]), .CI(carry11), .S(N93), 
        .CON(n1211) );
  INVX1 U776 ( .A(n1311), .Y(carry11) );
  AFHCONX2 U1_4 ( .A(clkdivcnt[4]), .B(clkdiv[4]), .CI(carry10), .S(N94), 
        .CON(n1111) );
  INVX1 U777 ( .A(n1211), .Y(carry10) );
  AFHCONX2 U1_5 ( .A(clkdivcnt[5]), .B(clkdiv[5]), .CI(carry9), .S(N95), .CON(
        n1011) );
  INVX1 U778 ( .A(n1111), .Y(carry9) );
  AFHCONX2 U1_6 ( .A(clkdivcnt[6]), .B(clkdiv[6]), .CI(carry8), .S(N96), .CON(
        n910) );
  INVX1 U779 ( .A(n1011), .Y(carry8) );
  AFHCONX2 U1_7 ( .A(clkdivcnt[7]), .B(clkdiv[7]), .CI(carry7), .S(N97), .CON(
        n810) );
  INVX1 U780 ( .A(n910), .Y(carry7) );
  AFHCONX2 U1_8 ( .A(clkdivcnt[8]), .B(clkdiv[8]), .CI(carry6), .S(N98), .CON(
        n710) );
  INVX1 U781 ( .A(n810), .Y(carry6) );
  AFHCONX2 U1_9 ( .A(clkdivcnt[9]), .B(clkdiv[9]), .CI(carry5), .S(N99), .CON(
        n610) );
  INVX1 U782 ( .A(n710), .Y(carry5) );
  AFHCONX2 U1_10 ( .A(clkdivcnt[10]), .B(clkdiv[10]), .CI(carry4), .S(N100), 
        .CON(n510) );
  INVX1 U783 ( .A(n610), .Y(carry4) );
  AFHCONX2 U1_11 ( .A(clkdivcnt[11]), .B(clkdiv[11]), .CI(carry3), .S(N101), 
        .CON(n410) );
  INVX1 U784 ( .A(n510), .Y(carry3) );
  AFHCONX2 U1_12 ( .A(clkdivcnt[12]), .B(clkdiv[12]), .CI(carry2), .S(N102), 
        .CON(n310) );
  INVX1 U785 ( .A(n410), .Y(carry2) );
  AFHCONX2 U1_13 ( .A(clkdivcnt[13]), .B(clkdiv[13]), .CI(carry1), .S(N103), 
        .CON(n233) );
  INVX1 U786 ( .A(n310), .Y(carry1) );
  AFHCONX2 U1_14 ( .A(clkdivcnt[14]), .B(clkdiv[14]), .CI(carry0), .S(N104), 
        .CON(n1101) );
  INVX1 U787 ( .A(n233), .Y(carry0) );
  AO22X1 U788 ( .A0(clkdivcnt[13]), .A1(n464), .B0(N103), .B1(uarten), .Y(n189) );
  AO22X1 U789 ( .A0(clkdivcnt[14]), .A1(n464), .B0(N104), .B1(uarten), .Y(n190) );
  AO22X1 U790 ( .A0(clkdivcnt[15]), .A1(n464), .B0(N105), .B1(uarten), .Y(n191) );
  XOR3X1 U1_15 ( .A(clkdivcnt[15]), .B(clkdiv[15]), .C(carry), .Y(N105) );
  INVX1 U791 ( .A(n1101), .Y(carry) );
  AO22X1 U792 ( .A0(timeoutcnt_int[15]), .A1(n315), .B0(N127), .B1(n320), .Y(
        n150) );
  AO22X1 U793 ( .A0(timeoutcnt_int[16]), .A1(n315), .B0(N128), .B1(n320), .Y(
        n151) );
  AO22X1 U794 ( .A0(timeoutcnt_int[17]), .A1(n315), .B0(N129), .B1(n320), .Y(
        n152) );
  AO22X1 U795 ( .A0(timeoutcnt_int[18]), .A1(n315), .B0(N130), .B1(n320), .Y(
        n153) );
  NAND4BX1 U796 ( .AN(rxfifoempty), .B(n476), .C(bytereceivedb), .D(
        reg_0x0000_29_), .Y(n322) );
  BUFX2 U797 ( .A(n517), .Y(uarten) );
  OAI31X1 U798 ( .A0(n442), .A1(n443), .A2(n444), .B0(n445), .Y(n412) );
  INVX1 U799 ( .A(n446), .Y(n444) );
  AOI211X1 U800 ( .A0(txwaterlevel_int[1]), .A1(n373), .B0(txwaterlevel_int[0]), .C0(n379), .Y(n443) );
  AOI31X1 U801 ( .A0(txwaterlevel_int[2]), .A1(n422), .A2(n446), .B0(n447), 
        .Y(n445) );
  OAI211X1 U802 ( .A0(n434), .A1(n435), .B0(n467), .C0(n482), .Y(n391) );
  NOR2BX1 U803 ( .AN(n438), .B(n439), .Y(n434) );
  OAI32X1 U804 ( .A0(n436), .A1(rxwaterlevel_int[2]), .A2(n399), .B0(
        rxwaterlevel_int[3]), .B1(n396), .Y(n435) );
  OA22X1 U805 ( .A0(rxfifocnt[1]), .A1(n504), .B0(n504), .B1(n465), .Y(n438)
         );
  NOR2BX1 U806 ( .AN(reg_0x0000_7_), .B(n391), .Y(N53) );
  AO22X1 U807 ( .A0(clkdivcnt[8]), .A1(n464), .B0(N98), .B1(uarten), .Y(n184)
         );
  AO22X1 U808 ( .A0(clkdivcnt[9]), .A1(n464), .B0(N99), .B1(uarten), .Y(n185)
         );
  AO22X1 U809 ( .A0(clkdivcnt[10]), .A1(n464), .B0(N100), .B1(uarten), .Y(n186) );
  AO22X1 U810 ( .A0(clkdivcnt[11]), .A1(n464), .B0(N101), .B1(uarten), .Y(n187) );
  AO22X1 U811 ( .A0(clkdivcnt[12]), .A1(n464), .B0(N102), .B1(uarten), .Y(n188) );
  AO22X1 U812 ( .A0(timeoutcnt_int[0]), .A1(n315), .B0(n320), .B1(n501), .Y(
        n135) );
  AO22X1 U813 ( .A0(timeoutcnt_int[1]), .A1(n315), .B0(N113), .B1(n320), .Y(
        n136) );
  AO22X1 U814 ( .A0(timeoutcnt_int[2]), .A1(n315), .B0(N114), .B1(n320), .Y(
        n137) );
  AO22X1 U815 ( .A0(timeoutcnt_int[3]), .A1(n315), .B0(N115), .B1(n320), .Y(
        n138) );
  AO22X1 U816 ( .A0(timeoutcnt_int[4]), .A1(n315), .B0(N116), .B1(n320), .Y(
        n139) );
  AO22X1 U817 ( .A0(timeoutcnt_int[5]), .A1(n315), .B0(N117), .B1(n320), .Y(
        n140) );
  AO22X1 U818 ( .A0(timeoutcnt_int[6]), .A1(n315), .B0(N118), .B1(n320), .Y(
        n141) );
  AO22X1 U819 ( .A0(timeoutcnt_int[7]), .A1(n315), .B0(N119), .B1(n320), .Y(
        n142) );
  AO22X1 U820 ( .A0(timeoutcnt_int[8]), .A1(n315), .B0(N120), .B1(n320), .Y(
        n143) );
  AO22X1 U821 ( .A0(timeoutcnt_int[9]), .A1(n315), .B0(N121), .B1(n320), .Y(
        n144) );
  AO22X1 U822 ( .A0(timeoutcnt_int[10]), .A1(n315), .B0(N122), .B1(n320), .Y(
        n145) );
  AO22X1 U823 ( .A0(timeoutcnt_int[11]), .A1(n315), .B0(N123), .B1(n320), .Y(
        n146) );
  AO22X1 U824 ( .A0(timeoutcnt_int[12]), .A1(n315), .B0(N124), .B1(n320), .Y(
        n147) );
  AO22X1 U825 ( .A0(timeoutcnt_int[13]), .A1(n315), .B0(N125), .B1(n320), .Y(
        n148) );
  AO22X1 U826 ( .A0(timeoutcnt_int[14]), .A1(n315), .B0(N126), .B1(n320), .Y(
        n149) );
  XOR2X1 U827 ( .A(timeoutcnt[0]), .B(n501), .Y(n361) );
  XOR2X1 U828 ( .A(timeoutcnt[19]), .B(n502), .Y(n342) );
  XOR2X1 U829 ( .A(timeoutcnt_int[9]), .B(timeoutcnt[9]), .Y(n332) );
  XOR2X1 U830 ( .A(timeoutcnt_int[18]), .B(timeoutcnt[18]), .Y(n351) );
  XOR2X1 U831 ( .A(n462), .B(timeoutcnt_int[10]), .Y(n360) );
  XOR2X1 U832 ( .A(timeoutcnt[1]), .B(n503), .Y(n341) );
  XOR2X1 U833 ( .A(timeoutcnt_int[17]), .B(timeoutcnt[17]), .Y(n350) );
  XOR2X1 U834 ( .A(timeoutcnt_int[11]), .B(timeoutcnt[11]), .Y(n359) );
  XOR2X1 U835 ( .A(timeoutcnt_int[2]), .B(timeoutcnt[2]), .Y(n340) );
  AND2X2 U836 ( .A(n505), .B(rxfifocnt[0]), .Y(n504) );
  OAI211X1 U837 ( .A0(n329), .A1(n330), .B0(reg_0x0000_29_), .C0(n476), .Y(
        n327) );
  OR4X1 U838 ( .A(n331), .B(n332), .C(n333), .D(n334), .Y(n330) );
  OR4X1 U839 ( .A(n350), .B(n351), .C(n352), .D(n353), .Y(n329) );
  XOR2X1 U840 ( .A(timeoutcnt_int[8]), .B(timeoutcnt[8]), .Y(n331) );
  NAND3BX1 U841 ( .AN(n354), .B(n355), .C(n356), .Y(n353) );
  XOR2X1 U842 ( .A(n460), .B(timeoutcnt_int[12]), .Y(n355) );
  XOR2X1 U843 ( .A(n457), .B(timeoutcnt_int[13]), .Y(n356) );
  NAND3BX1 U844 ( .AN(n359), .B(n360), .C(n361), .Y(n354) );
  NAND3BX1 U845 ( .AN(n335), .B(n336), .C(n337), .Y(n334) );
  XOR2X1 U846 ( .A(n478), .B(timeoutcnt_int[3]), .Y(n336) );
  XOR2X1 U847 ( .A(n477), .B(timeoutcnt_int[4]), .Y(n337) );
  NAND3BX1 U848 ( .AN(n340), .B(n341), .C(n342), .Y(n335) );
  NAND3BX1 U849 ( .AN(n364), .B(n365), .C(n366), .Y(n352) );
  XOR2X1 U850 ( .A(n461), .B(timeoutcnt_int[14]), .Y(n365) );
  XOR2X1 U851 ( .A(n463), .B(timeoutcnt_int[15]), .Y(n366) );
  XOR2X1 U852 ( .A(timeoutcnt_int[16]), .B(timeoutcnt[16]), .Y(n364) );
  NAND3BX1 U853 ( .AN(n345), .B(n346), .C(n347), .Y(n333) );
  XOR2X1 U854 ( .A(n459), .B(timeoutcnt_int[5]), .Y(n346) );
  XOR2X1 U855 ( .A(n479), .B(timeoutcnt_int[6]), .Y(n347) );
  XOR2X1 U856 ( .A(timeoutcnt_int[7]), .B(timeoutcnt[7]), .Y(n345) );
  AO22X1 U857 ( .A0(clkdivcnt[3]), .A1(n464), .B0(N93), .B1(uarten), .Y(n179)
         );
  AO22X1 U858 ( .A0(clkdivcnt[4]), .A1(n464), .B0(N94), .B1(uarten), .Y(n180)
         );
  AO22X1 U859 ( .A0(clkdivcnt[5]), .A1(n464), .B0(N95), .B1(uarten), .Y(n181)
         );
  AO22X1 U860 ( .A0(clkdivcnt[6]), .A1(n464), .B0(N96), .B1(uarten), .Y(n182)
         );
  AO22X1 U861 ( .A0(clkdivcnt[7]), .A1(n464), .B0(N97), .B1(uarten), .Y(n183)
         );
  OAI32X1 U862 ( .A0(n325), .A1(swrst), .A2(n470), .B0(n327), .B1(n486), .Y(
        n134) );
  INVX1 U863 ( .A(n327), .Y(n325) );
  NAND2BX1 U864 ( .AN(txwaterlevel_int[3]), .B(txfifocnt[3]), .Y(n446) );
  NAND2BX1 U865 ( .AN(rxfifocnt[3]), .B(rxwaterlevel_int[3]), .Y(n437) );
  AO22X1 U866 ( .A0(clkdivcnt[1]), .A1(n464), .B0(N91), .B1(uarten), .Y(n177)
         );
  AO22X1 U867 ( .A0(clkdivcnt[2]), .A1(n464), .B0(N92), .B1(uarten), .Y(n178)
         );
  AO22X1 U868 ( .A0(clkdivcnt_msb_dly), .A1(n464), .B0(clkdivcnt[15]), .B1(
        uarten), .Y(n192) );
  OAI32X1 U869 ( .A0(n464), .A1(clkdivcnt_msb_dly), .A2(n484), .B0(uarten), 
        .B1(n456), .Y(n175) );
  OAI31X1 U870 ( .A0(n464), .A1(clkdivcnt[0]), .A2(n475), .B0(n307), .Y(n176)
         );
  OA22X1 U871 ( .A0(uarten), .A1(n485), .B0(clkdiv[0]), .B1(n485), .Y(n307) );
  INVX1 U872 ( .A(rxfifocnt[3]), .Y(n396) );
  AOI211X1 U873 ( .A0(n451), .A1(n452), .B0(swrst), .C0(n487), .Y(N110) );
  NOR3BX1 U874 ( .AN(n455), .B(overrunerror), .C(n10), .Y(n451) );
  NOR3BX1 U875 ( .AN(n454), .B(reg_0x0004_7_), .C(reg_0x0004_22_), .Y(n452) );
  OAI211X1 U876 ( .A0(txfifocnt[3]), .A1(n481), .B0(n458), .C0(n466), .Y(n447)
         );
  INVX1 U877 ( .A(parityerror), .Y(n454) );
  INVX1 U878 ( .A(frameerror), .Y(n455) );
  AO22X1 U879 ( .A0(PADDR[4]), .A1(PADDR[3]), .B0(PADDR[2]), .B1(n431), .Y(
        PRDATA[28]) );
  INVX1 U880 ( .A(PADDR[4]), .Y(n431) );
  NAND2X1 U881 ( .A(reg_0x0000_27_), .B(n412), .Y(n297) );
  NOR2BX1 U882 ( .AN(reg_0x0000_29_), .B(n508), .Y(PRDATA[29]) );
  NOR2BX1 U883 ( .AN(timeoutcnt[19]), .B(n509), .Y(PRDATA[19]) );
  NOR2BX1 U884 ( .AN(reg_0x0000_30_), .B(n508), .Y(PRDATA[30]) );
  NOR2BX1 U885 ( .AN(timeoutcnt[16]), .B(n509), .Y(PRDATA[16]) );
  NOR2BX1 U886 ( .AN(timeoutcnt[17]), .B(n509), .Y(PRDATA[17]) );
  NOR2BX1 U887 ( .AN(timeoutcnt[18]), .B(n509), .Y(PRDATA[18]) );
  AO22X1 U888 ( .A0(databit), .A1(n301), .B0(frameerror), .B1(PRDATA[28]), .Y(
        PRDATA[24]) );
  OAI2BB1X1 U889 ( .A0N(rxdmareq), .A1N(PRDATA[28]), .B0(n389), .Y(PRDATA[6])
         );
  AOI222X1 U890 ( .A0(timeoutcnt[6]), .A1(n387), .B0(clkdiv[6]), .B1(n388), 
        .C0(fifodata_rx[6]), .C1(n371), .Y(n389) );
  OAI222X1 U891 ( .A0(n508), .A1(n458), .B0(n304), .B1(n488), .C0(n509), .C1(
        n460), .Y(PRDATA[12]) );
  OAI222X1 U892 ( .A0(n508), .A1(n466), .B0(n304), .B1(n489), .C0(n509), .C1(
        n457), .Y(PRDATA[13]) );
  OAI222X1 U893 ( .A0(n509), .A1(n461), .B0(n304), .B1(n490), .C0(n372), .C1(
        n297), .Y(PRDATA[14]) );
  AO22X1 U894 ( .A0(loopbacken), .A1(n301), .B0(reg_0x0004_22_), .B1(
        PRDATA[28]), .Y(PRDATA[22]) );
  AO22X1 U895 ( .A0(stopbit), .A1(n301), .B0(overrunerror), .B1(PRDATA[28]), 
        .Y(PRDATA[23]) );
  AO22X1 U896 ( .A0(parity[0]), .A1(n301), .B0(parityerror), .B1(PRDATA[28]), 
        .Y(PRDATA[25]) );
  AO22X1 U897 ( .A0(parity[1]), .A1(n301), .B0(rxbusy), .B1(PRDATA[28]), .Y(
        PRDATA[26]) );
  AO22X1 U898 ( .A0(n301), .A1(reg_0x0000_27_), .B0(txbusy), .B1(PRDATA[28]), 
        .Y(PRDATA[27]) );
  AO22X1 U899 ( .A0(uarten), .A1(n301), .B0(int), .B1(PRDATA[28]), .Y(
        PRDATA[31]) );
  OAI221X1 U900 ( .A0(n372), .A1(n402), .B0(n465), .B1(n508), .C0(n404), .Y(
        PRDATA[1]) );
  AOI222X1 U901 ( .A0(timeoutcnt[1]), .A1(n387), .B0(clkdiv[1]), .B1(n388), 
        .C0(fifodata_rx[1]), .C1(n371), .Y(n404) );
  INVX1 U902 ( .A(rxfifocnt[1]), .Y(n402) );
  OAI221X1 U903 ( .A0(n372), .A1(n399), .B0(n480), .B1(n508), .C0(n401), .Y(
        PRDATA[2]) );
  AOI222X1 U904 ( .A0(timeoutcnt[2]), .A1(n387), .B0(clkdiv[2]), .B1(n388), 
        .C0(fifodata_rx[2]), .C1(n371), .Y(n401) );
  OAI221X1 U905 ( .A0(n372), .A1(n396), .B0(n491), .B1(n508), .C0(n398), .Y(
        PRDATA[3]) );
  AOI222X1 U906 ( .A0(timeoutcnt[3]), .A1(n387), .B0(clkdiv[3]), .B1(n388), 
        .C0(fifodata_rx[3]), .C1(n371), .Y(n398) );
  OAI221X1 U907 ( .A0(n372), .A1(n373), .B0(n469), .B1(n508), .C0(n376), .Y(
        PRDATA[9]) );
  OA22X1 U908 ( .A0(n304), .A1(n472), .B0(n509), .B1(n497), .Y(n376) );
  OAI221X1 U909 ( .A0(n372), .A1(n422), .B0(n483), .B1(n508), .C0(n424), .Y(
        PRDATA[10]) );
  OA22X1 U910 ( .A0(n304), .A1(n494), .B0(n509), .B1(n462), .Y(n424) );
  OAI221X1 U911 ( .A0(n372), .A1(n417), .B0(n481), .B1(n508), .C0(n419), .Y(
        PRDATA[11]) );
  INVX1 U912 ( .A(txfifocnt[3]), .Y(n417) );
  OA22X1 U913 ( .A0(n304), .A1(n473), .B0(n509), .B1(n498), .Y(n419) );
  OAI221X1 U914 ( .A0(n372), .A1(n426), .B0(n508), .B1(n505), .C0(n428), .Y(
        PRDATA[0]) );
  AOI222X1 U915 ( .A0(timeoutcnt[0]), .A1(n387), .B0(clkdiv[0]), .B1(n388), 
        .C0(fifodata_rx[0]), .C1(n371), .Y(n428) );
  INVX1 U916 ( .A(rxfifocnt[0]), .Y(n426) );
  OAI221X1 U917 ( .A0(n509), .A1(n477), .B0(n508), .B1(n467), .C0(n395), .Y(
        PRDATA[4]) );
  AOI22X1 U918 ( .A0(clkdiv[4]), .A1(n388), .B0(fifodata_rx[4]), .B1(n371), 
        .Y(n395) );
  OAI221X1 U919 ( .A0(n509), .A1(n459), .B0(n508), .B1(n482), .C0(n393), .Y(
        PRDATA[5]) );
  AOI22X1 U920 ( .A0(clkdiv[5]), .A1(n388), .B0(fifodata_rx[5]), .B1(n371), 
        .Y(n393) );
  OAI221X1 U921 ( .A0(n372), .A1(n471), .B0(n508), .B1(n495), .C0(n386), .Y(
        PRDATA[7]) );
  AOI222X1 U922 ( .A0(timeoutcnt[7]), .A1(n387), .B0(clkdiv[7]), .B1(n388), 
        .C0(fifodata_rx[7]), .C1(n371), .Y(n386) );
  OAI221X1 U923 ( .A0(n372), .A1(n379), .B0(n508), .B1(n493), .C0(n381), .Y(
        PRDATA[8]) );
  OA22X1 U924 ( .A0(n304), .A1(n474), .B0(n509), .B1(n499), .Y(n381) );
  OAI221X1 U925 ( .A0(n372), .A1(n492), .B0(n508), .B1(n468), .C0(n407), .Y(
        PRDATA[15]) );
  OA22X1 U926 ( .A0(n304), .A1(n496), .B0(n509), .B1(n463), .Y(n407) );
  NOR2X1 U927 ( .A(n391), .B(n507), .Y(rxdmareq) );
  DFFRX1 timeoutcnt_int_reg_0_ ( .D(n135), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[0]), .QN(n501) );
  DFFRX1 clkdiv_reg_0_ ( .D(n193), .CK(clk), .RN(rstb), .Q(clkdiv[0]), .QN(
        n475) );
  DFFRX1 clkdivcnt_reg_0_ ( .D(n176), .CK(clk), .RN(rstb), .Q(clkdivcnt[0]), 
        .QN(n485) );
  DFFRX1 timeoutcnt_int_reg_1_ ( .D(n136), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[1]), .QN(n503) );
  DFFRX1 timeoutcnt_int_reg_3_ ( .D(n138), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[3]) );
  DFFRX1 timeoutcnt_int_reg_4_ ( .D(n139), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[4]) );
  DFFRX1 timeoutcnt_int_reg_5_ ( .D(n140), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[5]) );
  DFFRX1 timeoutcnt_int_reg_2_ ( .D(n137), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[2]) );
  DFFRX1 clkdiv_reg_1_ ( .D(n194), .CK(clk), .RN(rstb), .Q(clkdiv[1]) );
  DFFRX1 clkdiv_reg_2_ ( .D(n195), .CK(clk), .RN(rstb), .Q(clkdiv[2]) );
  DFFRX1 clkdiv_reg_3_ ( .D(n196), .CK(clk), .RN(rstb), .Q(clkdiv[3]) );
  DFFRX1 clkdivcnt_reg_1_ ( .D(n177), .CK(clk), .RN(rstb), .Q(clkdivcnt[1]) );
  DFFRX1 clkdivcnt_reg_2_ ( .D(n178), .CK(clk), .RN(rstb), .Q(clkdivcnt[2]) );
  DFFRX1 clkdivcnt_reg_3_ ( .D(n179), .CK(clk), .RN(rstb), .Q(clkdivcnt[3]) );
  DFFRX1 parity_int_reg_0_ ( .D(n218), .CK(clk), .RN(rstb), .Q(parity[0]) );
  DFFRX1 clkdiv_reg_8_ ( .D(n201), .CK(clk), .RN(rstb), .Q(clkdiv[8]), .QN(
        n474) );
  DFFRX1 uarten_int_reg ( .D(n223), .CK(clk), .RN(rstb), .Q(n517), .QN(n464)
         );
  DFFRX1 clkdiv_reg_4_ ( .D(n197), .CK(clk), .RN(rstb), .Q(clkdiv[4]) );
  DFFRX1 clkdiv_reg_5_ ( .D(n198), .CK(clk), .RN(rstb), .Q(clkdiv[5]) );
  DFFRX1 timeoutcnt_int_reg_6_ ( .D(n141), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[6]) );
  DFFRX1 timeoutcnt_int_reg_10_ ( .D(n145), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[10]) );
  DFFRX1 timeoutcnt_int_reg_7_ ( .D(n142), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[7]) );
  DFFRX1 timeoutcnt_int_reg_8_ ( .D(n143), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[8]) );
  DFFRX1 timeoutcnt_int_reg_9_ ( .D(n144), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[9]) );
  DFFRX1 timeoutcnt_int_reg_11_ ( .D(n146), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[11]) );
  DFFRX1 clkdiv_reg_6_ ( .D(n199), .CK(clk), .RN(rstb), .Q(clkdiv[6]) );
  DFFRX1 clkdiv_reg_7_ ( .D(n200), .CK(clk), .RN(rstb), .Q(clkdiv[7]) );
  DFFRX1 clkdivcnt_reg_4_ ( .D(n180), .CK(clk), .RN(rstb), .Q(clkdivcnt[4]) );
  DFFRX1 clkdivcnt_reg_5_ ( .D(n181), .CK(clk), .RN(rstb), .Q(clkdivcnt[5]) );
  DFFRX1 clkdivcnt_reg_6_ ( .D(n182), .CK(clk), .RN(rstb), .Q(clkdivcnt[6]) );
  DFFRX1 clkdivcnt_reg_7_ ( .D(n183), .CK(clk), .RN(rstb), .Q(clkdivcnt[7]) );
  DFFRX1 clkdivcnt_reg_8_ ( .D(n184), .CK(clk), .RN(rstb), .Q(clkdivcnt[8]) );
  DFFRX1 stopbit_int_reg ( .D(n216), .CK(clk), .RN(rstb), .Q(stopbit) );
  DFFRX1 clkdiv_reg_9_ ( .D(n202), .CK(clk), .RN(rstb), .Q(clkdiv[9]), .QN(
        n472) );
  DFFRX1 clkdiv_reg_10_ ( .D(n203), .CK(clk), .RN(rstb), .Q(clkdiv[10]), .QN(
        n494) );
  DFFRX1 clkdiv_reg_11_ ( .D(n204), .CK(clk), .RN(rstb), .Q(clkdiv[11]), .QN(
        n473) );
  DFFRX1 clkdiv_reg_12_ ( .D(n205), .CK(clk), .RN(rstb), .Q(clkdiv[12]), .QN(
        n488) );
  DFFRX1 timeoutcnt_int_reg_19_ ( .D(n154), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[19]), .QN(n502) );
  DFFRX1 timeoutcnt_reg_8_ ( .D(n163), .CK(clk), .RN(rstb), .Q(timeoutcnt[8]), 
        .QN(n499) );
  DFFRX1 timeoutcnt_reg_9_ ( .D(n164), .CK(clk), .RN(rstb), .Q(timeoutcnt[9]), 
        .QN(n497) );
  DFFRX1 timeoutcnt_reg_11_ ( .D(n166), .CK(clk), .RN(rstb), .Q(timeoutcnt[11]), .QN(n498) );
  DFFRX1 loopbacken_int_reg ( .D(n215), .CK(clk), .RN(rstb), .Q(loopbacken) );
  DFFRX1 timeoutcnt_reg_19_ ( .D(n174), .CK(clk), .RN(rstb), .Q(timeoutcnt[19]) );
  DFFRX1 timeoutcnt_reg_0_ ( .D(n155), .CK(clk), .RN(rstb), .Q(timeoutcnt[0])
         );
  DFFRX1 timeoutcnt_reg_1_ ( .D(n156), .CK(clk), .RN(rstb), .Q(timeoutcnt[1])
         );
  DFFRX1 timeoutcnt_reg_3_ ( .D(n158), .CK(clk), .RN(rstb), .Q(timeoutcnt[3]), 
        .QN(n478) );
  DFFRX1 timeoutcnt_reg_6_ ( .D(n161), .CK(clk), .RN(rstb), .Q(timeoutcnt[6]), 
        .QN(n479) );
  DFFRX1 timeoutcnt_reg_4_ ( .D(n159), .CK(clk), .RN(rstb), .Q(timeoutcnt[4]), 
        .QN(n477) );
  DFFRX1 timeoutcnt_reg_5_ ( .D(n160), .CK(clk), .RN(rstb), .Q(timeoutcnt[5]), 
        .QN(n459) );
  DFFRX1 timeoutcnt_reg_10_ ( .D(n165), .CK(clk), .RN(rstb), .Q(timeoutcnt[10]), .QN(n462) );
  DFFRX1 timeoutcnt_reg_12_ ( .D(n167), .CK(clk), .RN(rstb), .Q(timeoutcnt[12]), .QN(n460) );
  DFFRX1 timeoutcnt_reg_13_ ( .D(n168), .CK(clk), .RN(rstb), .Q(timeoutcnt[13]), .QN(n457) );
  DFFRX1 timeoutcnt_reg_14_ ( .D(n169), .CK(clk), .RN(rstb), .Q(timeoutcnt[14]), .QN(n461) );
  DFFRX1 timeoutcnt_reg_15_ ( .D(n170), .CK(clk), .RN(rstb), .Q(timeoutcnt[15]), .QN(n463) );
  DFFRX1 timeoutcnt_int_reg_12_ ( .D(n147), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[12]) );
  DFFRX1 timeoutcnt_int_reg_13_ ( .D(n148), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[13]) );
  DFFRX1 timeoutcnt_int_reg_14_ ( .D(n149), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[14]) );
  DFFRX1 timeoutcnt_int_reg_15_ ( .D(n150), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[15]) );
  DFFRX1 timeoutcnt_int_reg_16_ ( .D(n151), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[16]) );
  DFFRX1 timeoutcnt_int_reg_17_ ( .D(n152), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[17]) );
  DFFRX1 timeoutcnt_int_reg_18_ ( .D(n153), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[18]) );
  DFFRX1 timeoutcnt_reg_16_ ( .D(n171), .CK(clk), .RN(rstb), .Q(timeoutcnt[16]) );
  DFFRX1 timeoutcnt_reg_17_ ( .D(n172), .CK(clk), .RN(rstb), .Q(timeoutcnt[17]) );
  DFFRX1 timeoutcnt_reg_18_ ( .D(n173), .CK(clk), .RN(rstb), .Q(timeoutcnt[18]) );
  DFFRX1 timeoutcnt_reg_2_ ( .D(n157), .CK(clk), .RN(rstb), .Q(timeoutcnt[2])
         );
  DFFRX1 timeoutcnt_reg_7_ ( .D(n162), .CK(clk), .RN(rstb), .Q(timeoutcnt[7])
         );
  DFFRX1 clkdivcnt_reg_9_ ( .D(n185), .CK(clk), .RN(rstb), .Q(clkdivcnt[9]) );
  DFFRX1 clkdivcnt_reg_10_ ( .D(n186), .CK(clk), .RN(rstb), .Q(clkdivcnt[10])
         );
  DFFRX1 clkdivcnt_reg_11_ ( .D(n187), .CK(clk), .RN(rstb), .Q(clkdivcnt[11])
         );
  DFFRX1 clkdivcnt_reg_12_ ( .D(n188), .CK(clk), .RN(rstb), .Q(clkdivcnt[12])
         );
  DFFRX1 clkdivcnt_reg_13_ ( .D(n189), .CK(clk), .RN(rstb), .Q(clkdivcnt[13])
         );
  DFFRX1 timeoutinten_int_reg ( .D(n221), .CK(clk), .RN(rstb), .Q(
        reg_0x0000_29_), .QN(n470) );
  DFFRX1 clkdiv_reg_13_ ( .D(n206), .CK(clk), .RN(rstb), .Q(clkdiv[13]), .QN(
        n489) );
  DFFRX1 clkdiv_reg_14_ ( .D(n207), .CK(clk), .RN(rstb), .Q(clkdiv[14]), .QN(
        n490) );
  DFFRX1 clkdiv_reg_15_ ( .D(n208), .CK(clk), .RN(rstb), .Q(clkdiv[15]), .QN(
        n496) );
  DFFRX1 dmareqen_int_reg ( .D(n220), .CK(clk), .RN(rstb), .Q(reg_0x0000_27_), 
        .QN(n507) );
  DFFRX1 receivetimeout_reg ( .D(n134), .CK(clk), .RN(rstb), .Q(reg_0x0004_22_), .QN(n486) );
  DFFRX1 rxwaterlevel_int_reg_3_ ( .D(n229), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[3]), .QN(n491) );
  DFFRX1 rxfifo_interrupt_reg ( .D(N53), .CK(clk), .RN(rstb), .Q(reg_0x0004_7_), .QN(n471) );
  DFFRX1 clkdivcnt_reg_15_ ( .D(n191), .CK(clk), .RN(rstb), .Q(clkdivcnt[15]), 
        .QN(n484) );
  DFFRX1 txfifo_interrupt_reg ( .D(N52), .CK(clk), .RN(rstb), .Q(n10), .QN(
        n492) );
  DFFRX1 intgenen_int_reg ( .D(n222), .CK(clk), .RN(rstb), .Q(reg_0x0000_30_), 
        .QN(n487) );
  DFFRX1 rxfifo_inten_reg ( .D(n224), .CK(clk), .RN(rstb), .Q(reg_0x0000_7_), 
        .QN(n495) );
  DFFRX1 txwaterlevel_int_reg_3_ ( .D(n212), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[3]), .QN(n481) );
  DFFRX1 rxwaterlevel_int_reg_0_ ( .D(n226), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[0]), .QN(n505) );
  DFFRX1 txwaterlevel_int_reg_1_ ( .D(n210), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[1]), .QN(n469) );
  DFFRX1 rxwaterlevel_int_reg_2_ ( .D(n228), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[2]), .QN(n480) );
  DFFRX1 txwaterlevel_int_reg_0_ ( .D(n209), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[0]), .QN(n493) );
  DFFRX1 txwaterlevel_int_reg_2_ ( .D(n211), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[2]), .QN(n483) );
  DFFRX1 txwaterlevel_int_reg_4_ ( .D(n213), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[4]), .QN(n458) );
  DFFRX1 txwaterlevel_int_reg_5_ ( .D(n214), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[5]), .QN(n466) );
  DFFRX1 txfifo_inten_reg ( .D(n225), .CK(clk), .RN(rstb), .Q(reg_0x0000_15_), 
        .QN(n468) );
  DFFRX1 rxwaterlevel_int_reg_1_ ( .D(n227), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[1]), .QN(n465) );
  DFFRX1 rxwaterlevel_int_reg_4_ ( .D(n230), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[4]), .QN(n467) );
  DFFRX1 rxwaterlevel_int_reg_5_ ( .D(n231), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[5]), .QN(n482) );
  DFFRX1 overrunerr_clear_reg ( .D(N63), .CK(clk), .RN(rstb), .Q(
        overrunerr_clear) );
  DFFRX1 clkdivcnt_reg_14_ ( .D(n190), .CK(clk), .RN(rstb), .Q(clkdivcnt[14])
         );
  DFFRX1 clkdivcnt_msb_dly_reg ( .D(n192), .CK(clk), .RN(rstb), .Q(
        clkdivcnt_msb_dly) );
  DFFRX1 frameerr_clear_reg ( .D(N61), .CK(clk), .RN(rstb), .Q(frameerr_clear)
         );
  DFFRX1 parityerr_clear_reg ( .D(N62), .CK(clk), .RN(rstb), .Q(
        parityerr_clear) );
  DFFRX1 interrupt_status_reg ( .D(N110), .CK(clk), .RN(rstb), .Q(int) );
endmodule


module UartTop_3_0 ( PADDR, PENABLE, PSEL, PWDATA, PWRITE, clk, rstb, rxd, 
        PRDATA, int, rxdmareq, txd, txdmareq );
  input [4:2] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  input PENABLE, PSEL, PWRITE, clk, rstb, rxd;
  output int, rxdmareq, txd, txdmareq;
  wire   bytereceivedb, frameerror, overrunerror, parityerror, rxbusy,
         rxfifoempty, txbusy, txfifo_emptyb, txfifo_fillb, txfifo_fullb,
         baudx16clk, databit, fifordb, fifowrb, loopbacken, stopbit, swrst,
         uarten, frameerr_clear, parityerr_clear, overrunerr_clear;
  wire   [7:0] fifodata_rx;
  wire   [5:0] rxfifocnt;
  wire   [5:0] txfifocnt;
  wire   [7:0] fifodata_tx;
  wire   [1:0] parity;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1;
  assign PRDATA[21] = 1'b0;
  assign PRDATA[20] = 1'b0;

  RegBlk_3_5_0 RegBlock ( .PADDR(PADDR), .PENABLE(PENABLE), .PSEL(PSEL), 
        .PWDATA(PWDATA), .PWRITE(PWRITE), .bytereceivedb(bytereceivedb), .clk(
        clk), .fifodata_rx(fifodata_rx), .frameerror(frameerror), 
        .overrunerror(overrunerror), .parityerror(parityerror), .rstb(rstb), 
        .rxbusy(rxbusy), .rxfifocnt(rxfifocnt), .rxfifoempty(rxfifoempty), 
        .txbusy(txbusy), .txfifo_emptyb(txfifo_emptyb), .txfifo_fillb(
        txfifo_fillb), .txfifo_fullb(txfifo_fullb), .txfifocnt(txfifocnt), 
        .PRDATA({PRDATA[31:22], SYNOPSYS_UNCONNECTED__0, 
        SYNOPSYS_UNCONNECTED__1, PRDATA[19:0]}), .baudx16clk(baudx16clk), 
        .databit(databit), .fifodata_tx(fifodata_tx), .fifordb(fifordb), 
        .fifowrb(fifowrb), .int(int), .loopbacken(loopbacken), .parity(parity), 
        .rxdmareq(rxdmareq), .stopbit(stopbit), .swrst(swrst), .txdmareq(
        txdmareq), .uarten(uarten), .frameerr_clear(frameerr_clear), 
        .parityerr_clear(parityerr_clear), .overrunerr_clear(overrunerr_clear)
         );
  RxBlock_UART_FIFO_WIDTH5_0 RxBLK ( .baudx16clk(baudx16clk), .clk(clk), 
        .databit(databit), .fifordb(fifordb), .loopbacken(loopbacken), 
        .parity(parity), .rstb(rstb), .rxd(rxd), .stopbit(stopbit), .swrst(
        swrst), .txd(txd), .uarten(uarten), .bytereceivedb(bytereceivedb), 
        .fifodata_rx(fifodata_rx), .frameerror(frameerror), .overrunerror(
        overrunerror), .parityerror(parityerror), .rxbusy(rxbusy), .rxfifocnt(
        rxfifocnt), .rxfifoempty(rxfifoempty), .frameerr_clear(frameerr_clear), 
        .parityerr_clear(parityerr_clear), .overrunerr_clear(overrunerr_clear)
         );
  TxBlock_UART_FIFO_WIDTH5_0 TxBLK ( .baudx16clk(baudx16clk), .clk(clk), 
        .databit(databit), .fifodata_tx(fifodata_tx), .fifowrb(fifowrb), 
        .parity(parity), .rstb(rstb), .stopbit(stopbit), .swrst(swrst), 
        .uarten(uarten), .txbusy(txbusy), .txd(txd), .txfifo_emptyb(
        txfifo_emptyb), .txfifo_fillb(txfifo_fillb), .txfifo_fullb(
        txfifo_fullb), .txfifocnt(txfifocnt) );
endmodule


module TxBlock_UART_FIFO_WIDTH5_0 ( baudx16clk, clk, databit, fifodata_tx, 
        fifowrb, parity, rstb, stopbit, swrst, uarten, txbusy, txd, 
        txfifo_emptyb, txfifo_fillb, txfifo_fullb, txfifocnt );
  input [7:0] fifodata_tx;
  input [1:0] parity;
  output [5:0] txfifocnt;
  input baudx16clk, clk, databit, fifowrb, rstb, stopbit, swrst, uarten;
  output txbusy, txd, txfifo_emptyb, txfifo_fillb, txfifo_fullb;
  wire   N74, N75, N76, N77, N78, current_state_10_, current_state_9_,
         current_state_8_, current_state_7_, current_state_6_,
         current_state_5_, current_state_4_, current_state_3_,
         current_state_2_, current_state_1_, dtxclk, txclk, parity_int,
         fifordb, shiftenb, shiftreg_0_, N110, N111, N112, N114, N116, N117,
         N118, N120, N121, N122, N123, N124, N125, N126, N127, N128, N129,
         N130, N131, N132, fifo_wrpos_4_, fifo_wrpos_3_, fifo_wrpos_2_,
         fifo_wrpos_0_, \txfifo[31][7] , \txfifo[31][6] , \txfifo[31][5] ,
         \txfifo[31][4] , \txfifo[31][3] , \txfifo[31][2] , \txfifo[31][1] ,
         \txfifo[31][0] , \txfifo[30][7] , \txfifo[30][6] , \txfifo[30][5] ,
         \txfifo[30][4] , \txfifo[30][3] , \txfifo[30][2] , \txfifo[30][1] ,
         \txfifo[30][0] , \txfifo[29][7] , \txfifo[29][6] , \txfifo[29][5] ,
         \txfifo[29][4] , \txfifo[29][3] , \txfifo[29][2] , \txfifo[29][1] ,
         \txfifo[29][0] , \txfifo[28][7] , \txfifo[28][6] , \txfifo[28][5] ,
         \txfifo[28][4] , \txfifo[28][3] , \txfifo[28][2] , \txfifo[28][1] ,
         \txfifo[28][0] , \txfifo[27][7] , \txfifo[27][6] , \txfifo[27][5] ,
         \txfifo[27][4] , \txfifo[27][3] , \txfifo[27][2] , \txfifo[27][1] ,
         \txfifo[27][0] , \txfifo[26][7] , \txfifo[26][6] , \txfifo[26][5] ,
         \txfifo[26][4] , \txfifo[26][3] , \txfifo[26][2] , \txfifo[26][1] ,
         \txfifo[26][0] , \txfifo[25][7] , \txfifo[25][6] , \txfifo[25][5] ,
         \txfifo[25][4] , \txfifo[25][3] , \txfifo[25][2] , \txfifo[25][1] ,
         \txfifo[25][0] , \txfifo[24][7] , \txfifo[24][6] , \txfifo[24][5] ,
         \txfifo[24][4] , \txfifo[24][3] , \txfifo[24][2] , \txfifo[24][1] ,
         \txfifo[24][0] , \txfifo[23][7] , \txfifo[23][6] , \txfifo[23][5] ,
         \txfifo[23][4] , \txfifo[23][3] , \txfifo[23][2] , \txfifo[23][1] ,
         \txfifo[23][0] , \txfifo[22][7] , \txfifo[22][6] , \txfifo[22][5] ,
         \txfifo[22][4] , \txfifo[22][3] , \txfifo[22][2] , \txfifo[22][1] ,
         \txfifo[22][0] , \txfifo[21][7] , \txfifo[21][6] , \txfifo[21][5] ,
         \txfifo[21][4] , \txfifo[21][3] , \txfifo[21][2] , \txfifo[21][1] ,
         \txfifo[21][0] , \txfifo[20][7] , \txfifo[20][6] , \txfifo[20][5] ,
         \txfifo[20][4] , \txfifo[20][3] , \txfifo[20][2] , \txfifo[20][1] ,
         \txfifo[20][0] , \txfifo[19][7] , \txfifo[19][6] , \txfifo[19][5] ,
         \txfifo[19][4] , \txfifo[19][3] , \txfifo[19][2] , \txfifo[19][1] ,
         \txfifo[19][0] , \txfifo[18][7] , \txfifo[18][6] , \txfifo[18][5] ,
         \txfifo[18][4] , \txfifo[18][3] , \txfifo[18][2] , \txfifo[18][1] ,
         \txfifo[18][0] , \txfifo[17][7] , \txfifo[17][6] , \txfifo[17][5] ,
         \txfifo[17][4] , \txfifo[17][3] , \txfifo[17][2] , \txfifo[17][1] ,
         \txfifo[17][0] , \txfifo[16][7] , \txfifo[16][6] , \txfifo[16][5] ,
         \txfifo[16][4] , \txfifo[16][3] , \txfifo[16][2] , \txfifo[16][1] ,
         \txfifo[16][0] , \txfifo[15][7] , \txfifo[15][6] , \txfifo[15][5] ,
         \txfifo[15][4] , \txfifo[15][3] , \txfifo[15][2] , \txfifo[15][1] ,
         \txfifo[15][0] , \txfifo[14][7] , \txfifo[14][6] , \txfifo[14][5] ,
         \txfifo[14][4] , \txfifo[14][3] , \txfifo[14][2] , \txfifo[14][1] ,
         \txfifo[14][0] , \txfifo[13][7] , \txfifo[13][6] , \txfifo[13][5] ,
         \txfifo[13][4] , \txfifo[13][3] , \txfifo[13][2] , \txfifo[13][1] ,
         \txfifo[13][0] , \txfifo[12][7] , \txfifo[12][6] , \txfifo[12][5] ,
         \txfifo[12][4] , \txfifo[12][3] , \txfifo[12][2] , \txfifo[12][1] ,
         \txfifo[12][0] , \txfifo[11][7] , \txfifo[11][6] , \txfifo[11][5] ,
         \txfifo[11][4] , \txfifo[11][3] , \txfifo[11][2] , \txfifo[11][1] ,
         \txfifo[11][0] , \txfifo[10][7] , \txfifo[10][6] , \txfifo[10][5] ,
         \txfifo[10][4] , \txfifo[10][3] , \txfifo[10][2] , \txfifo[10][1] ,
         \txfifo[10][0] , \txfifo[9][7] , \txfifo[9][6] , \txfifo[9][5] ,
         \txfifo[9][4] , \txfifo[9][3] , \txfifo[9][2] , \txfifo[9][1] ,
         \txfifo[9][0] , \txfifo[8][7] , \txfifo[8][6] , \txfifo[8][5] ,
         \txfifo[8][4] , \txfifo[8][3] , \txfifo[8][2] , \txfifo[8][1] ,
         \txfifo[8][0] , \txfifo[7][7] , \txfifo[7][6] , \txfifo[7][5] ,
         \txfifo[7][4] , \txfifo[7][3] , \txfifo[7][2] , \txfifo[7][1] ,
         \txfifo[7][0] , \txfifo[6][7] , \txfifo[6][6] , \txfifo[6][5] ,
         \txfifo[6][4] , \txfifo[6][3] , \txfifo[6][2] , \txfifo[6][1] ,
         \txfifo[6][0] , \txfifo[5][7] , \txfifo[5][6] , \txfifo[5][5] ,
         \txfifo[5][4] , \txfifo[5][3] , \txfifo[5][2] , \txfifo[5][1] ,
         \txfifo[5][0] , \txfifo[4][7] , \txfifo[4][6] , \txfifo[4][5] ,
         \txfifo[4][4] , \txfifo[4][3] , \txfifo[4][2] , \txfifo[4][1] ,
         \txfifo[4][0] , \txfifo[3][7] , \txfifo[3][6] , \txfifo[3][5] ,
         \txfifo[3][4] , \txfifo[3][3] , \txfifo[3][2] , \txfifo[3][1] ,
         \txfifo[3][0] , \txfifo[2][7] , \txfifo[2][6] , \txfifo[2][5] ,
         \txfifo[2][4] , \txfifo[2][3] , \txfifo[2][2] , \txfifo[2][1] ,
         \txfifo[2][0] , \txfifo[1][7] , \txfifo[1][6] , \txfifo[1][5] ,
         \txfifo[1][4] , \txfifo[1][3] , \txfifo[1][2] , \txfifo[1][1] ,
         \txfifo[1][0] , \txfifo[0][7] , \txfifo[0][6] , \txfifo[0][5] ,
         \txfifo[0][4] , \txfifo[0][3] , \txfifo[0][2] , \txfifo[0][1] ,
         \txfifo[0][0] , N504, N505, N506, N513, N522, N523, N524, n6, n9,
         n202, n203, n204, n205, n206, n207, n208, n209, n210, n211, n212,
         n213, n214, n215, n216, n217, n218, n219, n220, n221, n222, n223,
         n224, n225, n226, n227, n228, n229, n230, n231, n232, n233, n234,
         n235, n236, n237, n238, n239, n240, n241, n242, n243, n244, n245,
         n246, n247, n248, n249, n250, n251, n252, n253, n254, n255, n256,
         n257, n258, n259, n260, n261, n262, n263, n264, n265, n266, n267,
         n268, n269, n270, n271, n272, n273, n274, n275, n276, n277, n278,
         n279, n280, n281, n282, n283, n284, n285, n286, n287, n288, n289,
         n290, n291, n292, n293, n294, n295, n296, n297, n298, n299, n300,
         n301, n302, n303, n304, n305, n306, n307, n308, n309, n310, n311,
         n312, n313, n314, n315, n316, n317, n318, n319, n320, n321, n322,
         n323, n324, n325, n326, n327, n328, n329, n330, n331, n332, n333,
         n334, n335, n336, n337, n338, n339, n340, n341, n342, n343, n344,
         n345, n346, n347, n348, n349, n350, n351, n352, n353, n354, n355,
         n356, n357, n358, n359, n360, n361, n362, n363, n364, n365, n366,
         n367, n368, n369, n370, n371, n372, n373, n374, n375, n376, n377,
         n378, n379, n380, n381, n382, n383, n384, n385, n386, n387, n388,
         n389, n390, n391, n392, n393, n394, n395, n396, n397, n398, n399,
         n400, n401, n402, n403, n404, n405, n406, n407, n408, n409, n410,
         n411, n412, n413, n414, n415, n416, n417, n418, n419, n420, n421,
         n422, n423, n424, n425, n426, n427, n428, n429, n430, n431, n432,
         n433, n434, n435, n436, n437, n438, n439, n440, n441, n442, n443,
         n444, n445, n446, n447, n448, n449, n450, n451, n452, n453, n454,
         n455, n456, n457, n458, n459, n460, n461, n462, n463, n464, n465,
         n466, n467, n468, n469, n470, n471, n472, n473, n474, n475, n476,
         n477, n478, n479, n480, n481, n483, carry_4_, carry, carry0, carry_1_,
         n511, n610, n710, carry1, carry2, n1101, n2100, n3100, carry_3_,
         carry_2_, n1100, n2, n3, n489, n490, n491, n494, n496, n498, n499,
         n500, n501, n502, n503, n5040, n5050, n5060, n507, n508, n510, n5130,
         n514, n516, n518, n519, n520, n521, n5220, n5230, n5240, n525, n526,
         n527, n528, n529, n530, n531, n532, n533, n534, n535, n536, n537,
         n540, n543, n544, n545, n546, n547, n548, n549, n550, n551, n552,
         n553, n554, n555, n556, n557, n559, n560, n561, n565, n570, n573,
         n574, n575, n576, n578, n580, n582, n586, n589, n590, n591, n592,
         n595, n600, n605, n608, n609, n611, n612, n614, n615, n616, n619,
         n624, n627, n628, n629, n636, n639, n640, n641, n642, n645, n650,
         n655, n658, n659, n660, n661, n663, n664, n665, n668, n673, n676,
         n677, n678, n685, n688, n689, n690, n691, n694, n699, n704, n707,
         n708, n709, n711, n713, n714, n715, n718, n723, n726, n727, n728,
         n735, n738, n739, n740, n741, n744, n749, n754, n757, n758, n759,
         n760, n762, n763, n764, n767, n772, n775, n776, n777, n784, n787,
         n788, n789, n790, n793, n798, n803, n806, n807, n808, n809, n811,
         n812, n813, n816, n821, n824, n825, n826, n833, n836, n837, n838,
         n839, n842, n847, n852, n855, n856, n857, n858, n860, n861, n862,
         n866, n871, n874, n875, n876, n883, n886, n887, n888, n889, n892,
         n895, n896, n897, n898, n899, n900, n903, n906, n907, n910, n913,
         n916, n918, n922, n923, n924, n926, n928, n930, n931, n933, n934,
         n936, n937, n938, n939, n940, n941, n943, n945, n946, n947, n948,
         n949, n950, n951, n952, n953, n954, n955, n956, n957, n958, n959,
         n960, n961, n962, n963, n965, n966, n967, n969, n970, n971, n973,
         n974, n975, n977, n978, n979, n981, n982, n983, n985, n986, n987,
         n989, n990, n991, n992, n993, n994, n995, n996, n997, n998, n999,
         n1000, n1001, n1002, n1003, n1004, n1005, n1006, n1007, n1009, n1010,
         n1011, n1012, n1013, n1014, n1015, n1016, n1017, n1018, n1019, n1020,
         n1021, n1022, n1023, n1024, n1025, n1026, n1027, n1028, n1029, n1030,
         n1032, n1033, n1034, n1035, n1036, n1037, n1038, n1039, n1040, n1041,
         n1042, n1043, n1044, n1045, n1046, n1047, n1048, n1049, n1051, n1053,
         n1054, n1055, n1056, n1059, n1060, n1061, n1063, n1066, n1067, n1068,
         n1069, n1070, n1071, n1072, n1073, n1074, n1075, n1076, n1078, n1083,
         n1085, n1086, n1087, n1088, n1091, n1093, n1094, n1095, n1097, n1098,
         n1099, n1103, n1104, n1106, n1107, n1108, n1109, n1110, n1111, n1112,
         n1113, n1114, n1115, n1116, n1117, n1118, n1119, n1120, n1121, n1122,
         n1123, n1124, n1125, n1126, n1127, n1128, n1129, n1130, n1131, n1132,
         n1133, n1134, n1135, n1136, n1137, n1138, n1139, n1140, n1141, n1142,
         n1143, n1144, n1145, n1146, n1147, n1148, n1149, n1150, n1151, n1152,
         n1153, n1154, n1155, n1156, n1157, n1158, n1159, n1160, n1161, n1162,
         n1163, n1164, n1165, n1166, n1167, n1168, n1169, n1170, n1171, n1172,
         n1173, n1174, n1175, n1176, n1177, n1178, n1179, n1180, n1181, n1182,
         n1183, n1184, n1185, n1186, n1187, n1188, n1189, n1190, n1191, n1192,
         n1193, n1194, n1195, n1196, n1197, n1198, n1199, n1200, n1201, n1202,
         n1203, n1204, n1205, n1206, n1207, n1208, n1209, n1210, n1211, n1212,
         n1213, n1214, n1215, n1216, n1217, n1218, n1219, n1220, n1221, n1222,
         n1223, n1224, n1225, n1226, n1227, n1229, n1230, n1231, n1232, n1233,
         n1234, n1235, n1236, n1237, n1238, n1239, n1240, n1241, n1242, n1243,
         n1244, n1245, n1246, n1247, n1248, n1249, n1250, n1251, n1252, n1253,
         n1254, n1255, n1256, n1257, n1258, n1259, n1260, n1261, n1262, n1263,
         n1264, n1265, n1266, n1267, n1268, n1269, n1270, n1271, n1272, n1273,
         n1274, n1275, n1276, n1277, n1278, n1279, n1280, n1281, n1282, n1283,
         n1284, n1285, n1286, n1287, n1288, n1289, n1290, n1291, n1292, n1293,
         n1294, n1295, n1296, n1297, n1298, n1299, n1300, n1301, n1302, n1303,
         n1304, n1305, n1306, n1307, n1308, n1309, n1310, n1311, n1312, n1313,
         n1314, n1315, n1316, n1317, n1318, n1319, n1320, n1321, n1322, n1323,
         n1324, n1325, n1326, n1327, n1328, n1329, n1330, n1331, n1332, n1333,
         n1334, n1335, n1336, n1337, n1338, n1339, n1340, n1341, n1342, n1343,
         n1344, n1345, n1346, n1347, n1348, n1349, n1350, n1351, n1352;
  wire   [3:0] txclkcnt;

  AHHCONX2 U1_1_11 ( .A(n1352), .CI(n1351), .S(N504), .CON(n3100) );
  AHHCONX2 U1_1_21 ( .A(fifo_wrpos_2_), .CI(carry2), .S(N505), .CON(n2100) );
  AHHCONX2 U1_1_31 ( .A(fifo_wrpos_3_), .CI(carry1), .S(N506), .CON(n1101) );
  AHHCONX2 U1_1_1 ( .A(N75), .CI(N74), .S(N522), .CON(n3) );
  AHHCONX2 U1_1_2 ( .A(N76), .CI(carry_2_), .S(N523), .CON(n2) );
  AHHCONX2 U1_1_3 ( .A(N77), .CI(carry_3_), .S(N524), .CON(n1100) );
  INVX1 U1441 ( .A(n1035), .Y(n1036) );
  INVX1 U1442 ( .A(n1032), .Y(n1033) );
  INVX1 U1443 ( .A(n1015), .Y(n1016) );
  INVX1 U1444 ( .A(n1012), .Y(n1013) );
  INVX1 U1445 ( .A(n996), .Y(n997) );
  INVX1 U1446 ( .A(n993), .Y(n994) );
  INVX1 U1447 ( .A(n1037), .Y(n1038) );
  INVX1 U1448 ( .A(n1017), .Y(n1018) );
  INVX1 U1449 ( .A(n998), .Y(n999) );
  INVX1 U1450 ( .A(n1045), .Y(n1046) );
  INVX1 U1451 ( .A(n1043), .Y(n1044) );
  INVX1 U1452 ( .A(n1041), .Y(n1042) );
  INVX1 U1453 ( .A(n1039), .Y(n1040) );
  INVX1 U1454 ( .A(n1025), .Y(n1026) );
  INVX1 U1455 ( .A(n1023), .Y(n1024) );
  INVX1 U1456 ( .A(n1021), .Y(n1022) );
  INVX1 U1457 ( .A(n1019), .Y(n1020) );
  INVX1 U1458 ( .A(n1006), .Y(n1007) );
  INVX1 U1459 ( .A(n1004), .Y(n1005) );
  INVX1 U1460 ( .A(n1002), .Y(n1003) );
  INVX1 U1461 ( .A(n1000), .Y(n1001) );
  INVX1 U1462 ( .A(n1027), .Y(n1028) );
  INVX1 U1463 ( .A(n1009), .Y(n1010) );
  INVX1 U1464 ( .A(n990), .Y(n991) );
  INVX1 U1465 ( .A(n986), .Y(n987) );
  INVX1 U1466 ( .A(n982), .Y(n983) );
  INVX1 U1467 ( .A(n978), .Y(n979) );
  INVX1 U1468 ( .A(n974), .Y(n975) );
  INVX1 U1469 ( .A(n970), .Y(n971) );
  INVX1 U1470 ( .A(n966), .Y(n967) );
  INVX1 U1471 ( .A(n962), .Y(n963) );
  INVX1 U1472 ( .A(n958), .Y(n959) );
  INVX1 U1473 ( .A(fifowrb), .Y(n946) );
  NAND2BX1 U1474 ( .AN(n1063), .B(n1068), .Y(N111) );
  INVX1 U1475 ( .A(N118), .Y(n1068) );
  INVX1 U1476 ( .A(txfifocnt[1]), .Y(n957) );
  INVX1 U1477 ( .A(n578), .Y(n531) );
  INVX1 U1478 ( .A(n576), .Y(n532) );
  INVX1 U1479 ( .A(n580), .Y(n528) );
  INVX1 U1480 ( .A(n582), .Y(n529) );
  INVX1 U1481 ( .A(n547), .Y(n518) );
  INVX1 U1482 ( .A(n552), .Y(n5230) );
  INVX1 U1483 ( .A(txfifocnt[0]), .Y(n953) );
  INVX1 U1484 ( .A(n545), .Y(n521) );
  INVX1 U1485 ( .A(n550), .Y(n526) );
  INVX1 U1486 ( .A(n544), .Y(n5220) );
  INVX1 U1487 ( .A(n549), .Y(n527) );
  INVX1 U1488 ( .A(n1349), .Y(n519) );
  INVX1 U1489 ( .A(n1350), .Y(n5240) );
  NAND2BX1 U1490 ( .AN(n1029), .B(n961), .Y(n1027) );
  NAND2BX1 U1491 ( .AN(n1011), .B(n961), .Y(n1009) );
  NAND2BX1 U1492 ( .AN(n992), .B(n961), .Y(n990) );
  OR2X1 U1493 ( .A(n960), .B(n989), .Y(n986) );
  OR2X1 U1494 ( .A(n960), .B(n985), .Y(n982) );
  OR2X1 U1495 ( .A(n960), .B(n981), .Y(n978) );
  OR2X1 U1496 ( .A(n960), .B(n977), .Y(n974) );
  OR2X1 U1497 ( .A(n960), .B(n973), .Y(n970) );
  OR2X1 U1498 ( .A(n960), .B(n969), .Y(n966) );
  OR2X1 U1499 ( .A(n960), .B(n965), .Y(n962) );
  NAND2BX1 U1500 ( .AN(n960), .B(n961), .Y(n958) );
  NAND2BX1 U1501 ( .AN(n989), .B(n1034), .Y(n1045) );
  NAND2BX1 U1502 ( .AN(n985), .B(n1034), .Y(n1043) );
  NAND2BX1 U1503 ( .AN(n981), .B(n1034), .Y(n1041) );
  NAND2BX1 U1504 ( .AN(n977), .B(n1034), .Y(n1039) );
  NAND2BX1 U1505 ( .AN(n973), .B(n1034), .Y(n1037) );
  NAND2BX1 U1506 ( .AN(n969), .B(n1034), .Y(n1035) );
  NAND2BX1 U1507 ( .AN(n965), .B(n1034), .Y(n1032) );
  NAND2BX1 U1508 ( .AN(n989), .B(n1014), .Y(n1025) );
  NAND2BX1 U1509 ( .AN(n985), .B(n1014), .Y(n1023) );
  NAND2BX1 U1510 ( .AN(n981), .B(n1014), .Y(n1021) );
  NAND2BX1 U1511 ( .AN(n977), .B(n1014), .Y(n1019) );
  NAND2BX1 U1512 ( .AN(n973), .B(n1014), .Y(n1017) );
  NAND2BX1 U1513 ( .AN(n969), .B(n1014), .Y(n1015) );
  NAND2BX1 U1514 ( .AN(n965), .B(n1014), .Y(n1012) );
  NAND2BX1 U1515 ( .AN(n989), .B(n995), .Y(n1006) );
  NAND2BX1 U1516 ( .AN(n985), .B(n995), .Y(n1004) );
  NAND2BX1 U1517 ( .AN(n981), .B(n995), .Y(n1002) );
  NAND2BX1 U1518 ( .AN(n977), .B(n995), .Y(n1000) );
  NAND2BX1 U1519 ( .AN(n973), .B(n995), .Y(n998) );
  NAND2BX1 U1520 ( .AN(n969), .B(n995), .Y(n996) );
  NAND2BX1 U1521 ( .AN(n965), .B(n995), .Y(n993) );
  INVX1 U1522 ( .A(n1011), .Y(n1014) );
  INVX1 U1523 ( .A(n992), .Y(n995) );
  INVX1 U1524 ( .A(n1029), .Y(n1034) );
  INVX1 U1525 ( .A(n940), .Y(n943) );
  AFHCONX2 U2_1 ( .A(n1352), .B(n1223), .CI(carry_1_), .S(txfifocnt[1]), .CON(
        n710) );
  OR2X1 U1526 ( .A(N116), .B(n1069), .Y(N112) );
  OAI221X1 U1527 ( .A0(uarten), .A1(n1093), .B0(txfifo_emptyb), .B1(n1093), 
        .C0(n937), .Y(N118) );
  INVX1 U1528 ( .A(n1066), .Y(n1093) );
  NAND3BX1 U1529 ( .AN(n1071), .B(n1070), .C(n1083), .Y(N110) );
  INVX1 U1530 ( .A(N112), .Y(n1083) );
  INVX1 U1531 ( .A(txfifocnt[4]), .Y(n1097) );
  NAND2BX1 U1532 ( .AN(n1066), .B(n1068), .Y(N116) );
  INVX1 U1533 ( .A(n949), .Y(n951) );
  AND4X1 U1534 ( .A(uarten), .B(n1066), .C(txfifo_emptyb), .D(n937), .Y(n1343)
         );
  AO21X1 U1535 ( .A0(n1063), .A1(n937), .B0(n1343), .Y(N117) );
  NAND2BX1 U1536 ( .AN(n897), .B(n896), .Y(n552) );
  NAND2BX1 U1537 ( .AN(n897), .B(n906), .Y(n547) );
  OR2X1 U1538 ( .A(n897), .B(n913), .Y(n514) );
  OR2X1 U1539 ( .A(n913), .B(n895), .Y(n516) );
  NAND2BX1 U1540 ( .AN(n900), .B(n1345), .Y(n576) );
  NAND2BX1 U1541 ( .AN(n897), .B(n1345), .Y(n580) );
  NAND2BX1 U1542 ( .AN(n916), .B(n1345), .Y(n578) );
  NAND2BX1 U1543 ( .AN(n895), .B(n1345), .Y(n582) );
  NAND2BX1 U1544 ( .AN(n898), .B(n899), .Y(n550) );
  NAND2BX1 U1545 ( .AN(n907), .B(n899), .Y(n545) );
  NAND2BX1 U1546 ( .AN(n900), .B(n896), .Y(n549) );
  NAND2BX1 U1547 ( .AN(n900), .B(n906), .Y(n544) );
  OAI2BB1X1 U1548 ( .A0N(n1351), .A1N(n1227), .B0(carry_1_), .Y(txfifocnt[0])
         );
  NAND2BX1 U1549 ( .AN(n913), .B(n899), .Y(n510) );
  OR2X1 U1550 ( .A(n913), .B(n900), .Y(n508) );
  AO21X1 U1551 ( .A0(n930), .A1(n1110), .B0(n934), .Y(n931) );
  NAND4BX1 U1552 ( .AN(n1069), .B(n1067), .C(n1054), .D(n1070), .Y(n1063) );
  BUFX2 U1553 ( .A(n551), .Y(n1350) );
  NAND2BX1 U1554 ( .AN(n895), .B(n896), .Y(n551) );
  BUFX2 U1555 ( .A(n546), .Y(n1349) );
  NAND2BX1 U1556 ( .AN(n895), .B(n906), .Y(n546) );
  NAND3BX1 U1557 ( .AN(n874), .B(n875), .C(n876), .Y(n860) );
  OA22X1 U1558 ( .A0(n580), .A1(n1166), .B0(n582), .B1(n1286), .Y(n875) );
  OA22X1 U1559 ( .A0(n576), .A1(n1165), .B0(n578), .B1(n1285), .Y(n876) );
  OAI221X1 U1560 ( .A0(n549), .A1(n1117), .B0(n550), .B1(n1235), .C0(n883), 
        .Y(n874) );
  NAND3BX1 U1561 ( .AN(n824), .B(n825), .C(n826), .Y(n811) );
  OA22X1 U1562 ( .A0(n580), .A1(n1168), .B0(n582), .B1(n1288), .Y(n825) );
  OA22X1 U1563 ( .A0(n576), .A1(n1167), .B0(n578), .B1(n1287), .Y(n826) );
  OAI221X1 U1564 ( .A0(n549), .A1(n1118), .B0(n550), .B1(n1236), .C0(n833), 
        .Y(n824) );
  NAND3BX1 U1565 ( .AN(n775), .B(n776), .C(n777), .Y(n762) );
  OA22X1 U1566 ( .A0(n580), .A1(n1170), .B0(n582), .B1(n1290), .Y(n776) );
  OA22X1 U1567 ( .A0(n576), .A1(n1169), .B0(n578), .B1(n1289), .Y(n777) );
  OAI221X1 U1568 ( .A0(n549), .A1(n1119), .B0(n550), .B1(n1237), .C0(n784), 
        .Y(n775) );
  NAND3BX1 U1569 ( .AN(n726), .B(n727), .C(n728), .Y(n713) );
  OA22X1 U1570 ( .A0(n580), .A1(n1172), .B0(n582), .B1(n1292), .Y(n727) );
  OA22X1 U1571 ( .A0(n576), .A1(n1171), .B0(n578), .B1(n1291), .Y(n728) );
  OAI221X1 U1572 ( .A0(n549), .A1(n1120), .B0(n550), .B1(n1238), .C0(n735), 
        .Y(n726) );
  NAND3BX1 U1573 ( .AN(n676), .B(n677), .C(n678), .Y(n663) );
  OA22X1 U1574 ( .A0(n580), .A1(n1174), .B0(n582), .B1(n1294), .Y(n677) );
  OA22X1 U1575 ( .A0(n576), .A1(n1173), .B0(n578), .B1(n1293), .Y(n678) );
  OAI221X1 U1576 ( .A0(n549), .A1(n1121), .B0(n550), .B1(n1239), .C0(n685), 
        .Y(n676) );
  NAND3BX1 U1577 ( .AN(n627), .B(n628), .C(n629), .Y(n614) );
  OA22X1 U1578 ( .A0(n580), .A1(n1176), .B0(n582), .B1(n1296), .Y(n628) );
  OA22X1 U1579 ( .A0(n576), .A1(n1175), .B0(n578), .B1(n1295), .Y(n629) );
  OAI221X1 U1580 ( .A0(n549), .A1(n1122), .B0(n550), .B1(n1240), .C0(n636), 
        .Y(n627) );
  NAND3BX1 U1581 ( .AN(n573), .B(n574), .C(n575), .Y(n559) );
  OA22X1 U1582 ( .A0(n580), .A1(n1178), .B0(n582), .B1(n1298), .Y(n574) );
  OA22X1 U1583 ( .A0(n576), .A1(n1177), .B0(n578), .B1(n1297), .Y(n575) );
  OAI221X1 U1584 ( .A0(n549), .A1(n1123), .B0(n550), .B1(n1241), .C0(n586), 
        .Y(n573) );
  AO21X1 U1585 ( .A0(n930), .A1(n1232), .B0(n931), .Y(n922) );
  INVX1 U1586 ( .A(n924), .Y(n930) );
  INVX1 U1587 ( .A(n916), .Y(n899) );
  INVX1 U1588 ( .A(n907), .Y(n906) );
  INVX1 U1589 ( .A(n898), .Y(n896) );
  INVX1 U1590 ( .A(n936), .Y(n934) );
  OAI211X1 U1591 ( .A0(n856), .A1(n555), .B0(n857), .C0(n858), .Y(n473) );
  OA22X1 U1592 ( .A0(n1284), .A1(n499), .B0(n498), .B1(n1161), .Y(n858) );
  NOR4BX1 U1593 ( .AN(n886), .B(n887), .C(n888), .D(n889), .Y(n856) );
  OAI31X1 U1594 ( .A0(n860), .A1(n861), .A2(n862), .B0(n1347), .Y(n857) );
  OAI211X1 U1595 ( .A0(n807), .A1(n555), .B0(n808), .C0(n809), .Y(n474) );
  OA22X1 U1596 ( .A0(n499), .A1(n1161), .B0(n498), .B1(n1279), .Y(n809) );
  NOR4BX1 U1597 ( .AN(n836), .B(n837), .C(n838), .D(n839), .Y(n807) );
  OAI31X1 U1598 ( .A0(n811), .A1(n812), .A2(n813), .B0(n1347), .Y(n808) );
  OAI211X1 U1599 ( .A0(n758), .A1(n555), .B0(n759), .C0(n760), .Y(n475) );
  OA22X1 U1600 ( .A0(n499), .A1(n1279), .B0(n498), .B1(n1162), .Y(n760) );
  NOR4BX1 U1601 ( .AN(n787), .B(n788), .C(n789), .D(n790), .Y(n758) );
  OAI31X1 U1602 ( .A0(n762), .A1(n763), .A2(n764), .B0(n1347), .Y(n759) );
  OAI211X1 U1603 ( .A0(n708), .A1(n555), .B0(n709), .C0(n711), .Y(n476) );
  OA22X1 U1604 ( .A0(n499), .A1(n1162), .B0(n498), .B1(n1280), .Y(n711) );
  NOR4BX1 U1605 ( .AN(n738), .B(n739), .C(n740), .D(n741), .Y(n708) );
  OAI31X1 U1606 ( .A0(n713), .A1(n714), .A2(n715), .B0(n1347), .Y(n709) );
  OAI211X1 U1607 ( .A0(n659), .A1(n555), .B0(n660), .C0(n661), .Y(n477) );
  OA22X1 U1608 ( .A0(n499), .A1(n1280), .B0(n498), .B1(n1163), .Y(n661) );
  NOR4BX1 U1609 ( .AN(n688), .B(n689), .C(n690), .D(n691), .Y(n659) );
  OAI31X1 U1610 ( .A0(n663), .A1(n664), .A2(n665), .B0(n1347), .Y(n660) );
  OAI211X1 U1611 ( .A0(n609), .A1(n555), .B0(n611), .C0(n612), .Y(n478) );
  OA22X1 U1612 ( .A0(n499), .A1(n1163), .B0(n498), .B1(n1281), .Y(n612) );
  NOR4BX1 U1613 ( .AN(n639), .B(n640), .C(n641), .D(n642), .Y(n609) );
  OAI31X1 U1614 ( .A0(n614), .A1(n615), .A2(n616), .B0(n1347), .Y(n611) );
  OAI211X1 U1615 ( .A0(n554), .A1(n555), .B0(n556), .C0(n557), .Y(n479) );
  OA22X1 U1616 ( .A0(n499), .A1(n1281), .B0(n1115), .B1(n498), .Y(n557) );
  NOR4BX1 U1617 ( .AN(n589), .B(n590), .C(n591), .D(n592), .Y(n554) );
  OAI31X1 U1618 ( .A0(n559), .A1(n560), .A2(n561), .B0(n1347), .Y(n556) );
  INVX1 U1619 ( .A(n1055), .Y(n1075) );
  NAND2BX1 U1620 ( .AN(n1348), .B(n498), .Y(n499) );
  NOR2BX1 U1621 ( .AN(n937), .B(n1054), .Y(N130) );
  NOR2BX1 U1622 ( .AN(n937), .B(n1067), .Y(N114) );
  NOR2BX1 U1623 ( .AN(n937), .B(n1053), .Y(N131) );
  INVX1 U1624 ( .A(n1051), .Y(n1060) );
  INVX1 U1625 ( .A(n1048), .Y(n1059) );
  OAI32X1 U1626 ( .A0(n1048), .A1(n1049), .A2(n1107), .B0(n1051), .B1(n1111), 
        .Y(N132) );
  INVX1 U1627 ( .A(n1061), .Y(n1070) );
  INVX1 U1628 ( .A(n1071), .Y(n1054) );
  INVX1 U1629 ( .A(txfifo_emptyb), .Y(txfifo_fillb) );
  NAND3BX1 U1630 ( .AN(txfifocnt[5]), .B(n946), .C(n937), .Y(n940) );
  NAND3BX1 U1631 ( .AN(fifo_wrpos_3_), .B(n1344), .C(n946), .Y(n1029) );
  NAND3BX1 U1632 ( .AN(fifowrb), .B(n1344), .C(fifo_wrpos_3_), .Y(n1011) );
  OR3X2 U1633 ( .A(fifowrb), .B(fifo_wrpos_3_), .C(n1344), .Y(n992) );
  NAND3BX1 U1634 ( .AN(fifowrb), .B(fifo_wrpos_3_), .C(fifo_wrpos_4_), .Y(n960) );
  AO22X1 U1635 ( .A0(\txfifo[31][0] ), .A1(n958), .B0(fifodata_tx[0]), .B1(
        n959), .Y(n450) );
  AO22X1 U1636 ( .A0(\txfifo[31][1] ), .A1(n958), .B0(fifodata_tx[1]), .B1(
        n959), .Y(n451) );
  AO22X1 U1637 ( .A0(\txfifo[31][2] ), .A1(n958), .B0(fifodata_tx[2]), .B1(
        n959), .Y(n452) );
  AO22X1 U1638 ( .A0(\txfifo[31][3] ), .A1(n958), .B0(fifodata_tx[3]), .B1(
        n959), .Y(n453) );
  AO22X1 U1639 ( .A0(\txfifo[31][4] ), .A1(n958), .B0(fifodata_tx[4]), .B1(
        n959), .Y(n454) );
  AO22X1 U1640 ( .A0(\txfifo[31][5] ), .A1(n958), .B0(fifodata_tx[5]), .B1(
        n959), .Y(n455) );
  AO22X1 U1641 ( .A0(\txfifo[31][6] ), .A1(n958), .B0(fifodata_tx[6]), .B1(
        n959), .Y(n456) );
  AO22X1 U1642 ( .A0(\txfifo[31][7] ), .A1(n958), .B0(fifodata_tx[7]), .B1(
        n959), .Y(n457) );
  AO22X1 U1643 ( .A0(\txfifo[0][0] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[0]), .Y(n202) );
  AO22X1 U1644 ( .A0(\txfifo[0][1] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[1]), .Y(n203) );
  AO22X1 U1645 ( .A0(\txfifo[0][2] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[2]), .Y(n204) );
  AO22X1 U1646 ( .A0(\txfifo[0][3] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[3]), .Y(n205) );
  AO22X1 U1647 ( .A0(\txfifo[0][4] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[4]), .Y(n206) );
  AO22X1 U1648 ( .A0(\txfifo[0][5] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[5]), .Y(n207) );
  AO22X1 U1649 ( .A0(\txfifo[0][6] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[6]), .Y(n208) );
  AO22X1 U1650 ( .A0(\txfifo[0][7] ), .A1(n1045), .B0(n1046), .B1(
        fifodata_tx[7]), .Y(n209) );
  AO22X1 U1651 ( .A0(\txfifo[1][0] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[0]), .Y(n210) );
  AO22X1 U1652 ( .A0(\txfifo[1][1] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[1]), .Y(n211) );
  AO22X1 U1653 ( .A0(\txfifo[1][2] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[2]), .Y(n212) );
  AO22X1 U1654 ( .A0(\txfifo[1][3] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[3]), .Y(n213) );
  AO22X1 U1655 ( .A0(\txfifo[1][4] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[4]), .Y(n214) );
  AO22X1 U1656 ( .A0(\txfifo[1][5] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[5]), .Y(n215) );
  AO22X1 U1657 ( .A0(\txfifo[1][6] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[6]), .Y(n216) );
  AO22X1 U1658 ( .A0(\txfifo[1][7] ), .A1(n1043), .B0(n1044), .B1(
        fifodata_tx[7]), .Y(n217) );
  AO22X1 U1659 ( .A0(\txfifo[2][0] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[0]), .Y(n218) );
  AO22X1 U1660 ( .A0(\txfifo[2][1] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[1]), .Y(n219) );
  AO22X1 U1661 ( .A0(\txfifo[2][2] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[2]), .Y(n220) );
  AO22X1 U1662 ( .A0(\txfifo[2][3] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[3]), .Y(n221) );
  AO22X1 U1663 ( .A0(\txfifo[2][4] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[4]), .Y(n222) );
  AO22X1 U1664 ( .A0(\txfifo[2][5] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[5]), .Y(n223) );
  AO22X1 U1665 ( .A0(\txfifo[2][6] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[6]), .Y(n224) );
  AO22X1 U1666 ( .A0(\txfifo[2][7] ), .A1(n1041), .B0(n1042), .B1(
        fifodata_tx[7]), .Y(n225) );
  AO22X1 U1667 ( .A0(\txfifo[3][0] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[0]), .Y(n226) );
  AO22X1 U1668 ( .A0(\txfifo[3][1] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[1]), .Y(n227) );
  AO22X1 U1669 ( .A0(\txfifo[3][2] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[2]), .Y(n228) );
  AO22X1 U1670 ( .A0(\txfifo[3][3] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[3]), .Y(n229) );
  AO22X1 U1671 ( .A0(\txfifo[3][4] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[4]), .Y(n230) );
  AO22X1 U1672 ( .A0(\txfifo[3][5] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[5]), .Y(n231) );
  AO22X1 U1673 ( .A0(\txfifo[3][6] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[6]), .Y(n232) );
  AO22X1 U1674 ( .A0(\txfifo[3][7] ), .A1(n1039), .B0(n1040), .B1(
        fifodata_tx[7]), .Y(n233) );
  AO22X1 U1675 ( .A0(\txfifo[4][0] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[0]), .Y(n234) );
  AO22X1 U1676 ( .A0(\txfifo[4][1] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[1]), .Y(n235) );
  AO22X1 U1677 ( .A0(\txfifo[4][2] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[2]), .Y(n236) );
  AO22X1 U1678 ( .A0(\txfifo[4][3] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[3]), .Y(n237) );
  AO22X1 U1679 ( .A0(\txfifo[4][4] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[4]), .Y(n238) );
  AO22X1 U1680 ( .A0(\txfifo[4][5] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[5]), .Y(n239) );
  AO22X1 U1681 ( .A0(\txfifo[4][6] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[6]), .Y(n240) );
  AO22X1 U1682 ( .A0(\txfifo[4][7] ), .A1(n1037), .B0(n1038), .B1(
        fifodata_tx[7]), .Y(n241) );
  AO22X1 U1683 ( .A0(\txfifo[5][0] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[0]), .Y(n242) );
  AO22X1 U1684 ( .A0(\txfifo[5][1] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[1]), .Y(n243) );
  AO22X1 U1685 ( .A0(\txfifo[5][2] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[2]), .Y(n244) );
  AO22X1 U1686 ( .A0(\txfifo[5][3] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[3]), .Y(n245) );
  AO22X1 U1687 ( .A0(\txfifo[5][4] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[4]), .Y(n246) );
  AO22X1 U1688 ( .A0(\txfifo[5][5] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[5]), .Y(n247) );
  AO22X1 U1689 ( .A0(\txfifo[5][6] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[6]), .Y(n248) );
  AO22X1 U1690 ( .A0(\txfifo[5][7] ), .A1(n1035), .B0(n1036), .B1(
        fifodata_tx[7]), .Y(n249) );
  AO22X1 U1691 ( .A0(\txfifo[6][0] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[0]), .Y(n250) );
  AO22X1 U1692 ( .A0(\txfifo[6][1] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[1]), .Y(n251) );
  AO22X1 U1693 ( .A0(\txfifo[6][2] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[2]), .Y(n252) );
  AO22X1 U1694 ( .A0(\txfifo[6][3] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[3]), .Y(n253) );
  AO22X1 U1695 ( .A0(\txfifo[6][4] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[4]), .Y(n254) );
  AO22X1 U1696 ( .A0(\txfifo[6][5] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[5]), .Y(n255) );
  AO22X1 U1697 ( .A0(\txfifo[6][6] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[6]), .Y(n256) );
  AO22X1 U1698 ( .A0(\txfifo[6][7] ), .A1(n1032), .B0(n1033), .B1(
        fifodata_tx[7]), .Y(n257) );
  AO22X1 U1699 ( .A0(\txfifo[7][0] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[0]), .Y(n258) );
  AO22X1 U1700 ( .A0(\txfifo[7][1] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[1]), .Y(n259) );
  AO22X1 U1701 ( .A0(\txfifo[7][2] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[2]), .Y(n260) );
  AO22X1 U1702 ( .A0(\txfifo[7][3] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[3]), .Y(n261) );
  AO22X1 U1703 ( .A0(\txfifo[7][4] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[4]), .Y(n262) );
  AO22X1 U1704 ( .A0(\txfifo[7][5] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[5]), .Y(n263) );
  AO22X1 U1705 ( .A0(\txfifo[7][6] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[6]), .Y(n264) );
  AO22X1 U1706 ( .A0(\txfifo[7][7] ), .A1(n1027), .B0(n1028), .B1(
        fifodata_tx[7]), .Y(n265) );
  AO22X1 U1707 ( .A0(\txfifo[8][0] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[0]), .Y(n266) );
  AO22X1 U1708 ( .A0(\txfifo[8][1] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[1]), .Y(n267) );
  AO22X1 U1709 ( .A0(\txfifo[8][2] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[2]), .Y(n268) );
  AO22X1 U1710 ( .A0(\txfifo[8][3] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[3]), .Y(n269) );
  AO22X1 U1711 ( .A0(\txfifo[8][4] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[4]), .Y(n270) );
  AO22X1 U1712 ( .A0(\txfifo[8][5] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[5]), .Y(n271) );
  AO22X1 U1713 ( .A0(\txfifo[8][6] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[6]), .Y(n272) );
  AO22X1 U1714 ( .A0(\txfifo[8][7] ), .A1(n1025), .B0(n1026), .B1(
        fifodata_tx[7]), .Y(n273) );
  AO22X1 U1715 ( .A0(\txfifo[9][0] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[0]), .Y(n274) );
  AO22X1 U1716 ( .A0(\txfifo[9][1] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[1]), .Y(n275) );
  AO22X1 U1717 ( .A0(\txfifo[9][2] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[2]), .Y(n276) );
  AO22X1 U1718 ( .A0(\txfifo[9][3] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[3]), .Y(n277) );
  AO22X1 U1719 ( .A0(\txfifo[9][4] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[4]), .Y(n278) );
  AO22X1 U1720 ( .A0(\txfifo[9][5] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[5]), .Y(n279) );
  AO22X1 U1721 ( .A0(\txfifo[9][6] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[6]), .Y(n280) );
  AO22X1 U1722 ( .A0(\txfifo[9][7] ), .A1(n1023), .B0(n1024), .B1(
        fifodata_tx[7]), .Y(n281) );
  AO22X1 U1723 ( .A0(\txfifo[10][0] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[0]), .Y(n282) );
  AO22X1 U1724 ( .A0(\txfifo[10][1] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[1]), .Y(n283) );
  AO22X1 U1725 ( .A0(\txfifo[10][2] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[2]), .Y(n284) );
  AO22X1 U1726 ( .A0(\txfifo[10][3] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[3]), .Y(n285) );
  AO22X1 U1727 ( .A0(\txfifo[10][4] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[4]), .Y(n286) );
  AO22X1 U1728 ( .A0(\txfifo[10][5] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[5]), .Y(n287) );
  AO22X1 U1729 ( .A0(\txfifo[10][6] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[6]), .Y(n288) );
  AO22X1 U1730 ( .A0(\txfifo[10][7] ), .A1(n1021), .B0(n1022), .B1(
        fifodata_tx[7]), .Y(n289) );
  AO22X1 U1731 ( .A0(\txfifo[11][0] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[0]), .Y(n290) );
  AO22X1 U1732 ( .A0(\txfifo[11][1] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[1]), .Y(n291) );
  AO22X1 U1733 ( .A0(\txfifo[11][2] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[2]), .Y(n292) );
  AO22X1 U1734 ( .A0(\txfifo[11][3] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[3]), .Y(n293) );
  AO22X1 U1735 ( .A0(\txfifo[11][4] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[4]), .Y(n294) );
  AO22X1 U1736 ( .A0(\txfifo[11][5] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[5]), .Y(n295) );
  AO22X1 U1737 ( .A0(\txfifo[11][6] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[6]), .Y(n296) );
  AO22X1 U1738 ( .A0(\txfifo[11][7] ), .A1(n1019), .B0(n1020), .B1(
        fifodata_tx[7]), .Y(n297) );
  AO22X1 U1739 ( .A0(\txfifo[12][0] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[0]), .Y(n298) );
  AO22X1 U1740 ( .A0(\txfifo[12][1] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[1]), .Y(n299) );
  AO22X1 U1741 ( .A0(\txfifo[12][2] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[2]), .Y(n300) );
  AO22X1 U1742 ( .A0(\txfifo[12][3] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[3]), .Y(n301) );
  AO22X1 U1743 ( .A0(\txfifo[12][4] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[4]), .Y(n302) );
  AO22X1 U1744 ( .A0(\txfifo[12][5] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[5]), .Y(n303) );
  AO22X1 U1745 ( .A0(\txfifo[12][6] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[6]), .Y(n304) );
  AO22X1 U1746 ( .A0(\txfifo[12][7] ), .A1(n1017), .B0(n1018), .B1(
        fifodata_tx[7]), .Y(n305) );
  AO22X1 U1747 ( .A0(\txfifo[13][0] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[0]), .Y(n306) );
  AO22X1 U1748 ( .A0(\txfifo[13][1] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[1]), .Y(n307) );
  AO22X1 U1749 ( .A0(\txfifo[13][2] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[2]), .Y(n308) );
  AO22X1 U1750 ( .A0(\txfifo[13][3] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[3]), .Y(n309) );
  AO22X1 U1751 ( .A0(\txfifo[13][4] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[4]), .Y(n310) );
  AO22X1 U1752 ( .A0(\txfifo[13][5] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[5]), .Y(n311) );
  AO22X1 U1753 ( .A0(\txfifo[13][6] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[6]), .Y(n312) );
  AO22X1 U1754 ( .A0(\txfifo[13][7] ), .A1(n1015), .B0(n1016), .B1(
        fifodata_tx[7]), .Y(n313) );
  AO22X1 U1755 ( .A0(\txfifo[14][0] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[0]), .Y(n314) );
  AO22X1 U1756 ( .A0(\txfifo[14][1] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[1]), .Y(n315) );
  AO22X1 U1757 ( .A0(\txfifo[14][2] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[2]), .Y(n316) );
  AO22X1 U1758 ( .A0(\txfifo[14][3] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[3]), .Y(n317) );
  AO22X1 U1759 ( .A0(\txfifo[14][4] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[4]), .Y(n318) );
  AO22X1 U1760 ( .A0(\txfifo[14][5] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[5]), .Y(n319) );
  AO22X1 U1761 ( .A0(\txfifo[14][6] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[6]), .Y(n320) );
  AO22X1 U1762 ( .A0(\txfifo[14][7] ), .A1(n1012), .B0(n1013), .B1(
        fifodata_tx[7]), .Y(n321) );
  AO22X1 U1763 ( .A0(\txfifo[15][0] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[0]), .Y(n322) );
  AO22X1 U1764 ( .A0(\txfifo[15][1] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[1]), .Y(n323) );
  AO22X1 U1765 ( .A0(\txfifo[15][2] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[2]), .Y(n324) );
  AO22X1 U1766 ( .A0(\txfifo[15][3] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[3]), .Y(n325) );
  AO22X1 U1767 ( .A0(\txfifo[15][4] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[4]), .Y(n326) );
  AO22X1 U1768 ( .A0(\txfifo[15][5] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[5]), .Y(n327) );
  AO22X1 U1769 ( .A0(\txfifo[15][6] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[6]), .Y(n328) );
  AO22X1 U1770 ( .A0(\txfifo[15][7] ), .A1(n1009), .B0(n1010), .B1(
        fifodata_tx[7]), .Y(n329) );
  AO22X1 U1771 ( .A0(\txfifo[16][0] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[0]), .Y(n330) );
  AO22X1 U1772 ( .A0(\txfifo[16][1] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[1]), .Y(n331) );
  AO22X1 U1773 ( .A0(\txfifo[16][2] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[2]), .Y(n332) );
  AO22X1 U1774 ( .A0(\txfifo[16][3] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[3]), .Y(n333) );
  AO22X1 U1775 ( .A0(\txfifo[16][4] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[4]), .Y(n334) );
  AO22X1 U1776 ( .A0(\txfifo[16][5] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[5]), .Y(n335) );
  AO22X1 U1777 ( .A0(\txfifo[16][6] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[6]), .Y(n336) );
  AO22X1 U1778 ( .A0(\txfifo[16][7] ), .A1(n1006), .B0(n1007), .B1(
        fifodata_tx[7]), .Y(n337) );
  AO22X1 U1779 ( .A0(\txfifo[17][0] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[0]), .Y(n338) );
  AO22X1 U1780 ( .A0(\txfifo[17][1] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[1]), .Y(n339) );
  AO22X1 U1781 ( .A0(\txfifo[17][2] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[2]), .Y(n340) );
  AO22X1 U1782 ( .A0(\txfifo[17][3] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[3]), .Y(n341) );
  AO22X1 U1783 ( .A0(\txfifo[17][4] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[4]), .Y(n342) );
  AO22X1 U1784 ( .A0(\txfifo[17][5] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[5]), .Y(n343) );
  AO22X1 U1785 ( .A0(\txfifo[17][6] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[6]), .Y(n344) );
  AO22X1 U1786 ( .A0(\txfifo[17][7] ), .A1(n1004), .B0(n1005), .B1(
        fifodata_tx[7]), .Y(n345) );
  AO22X1 U1787 ( .A0(\txfifo[18][0] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[0]), .Y(n346) );
  AO22X1 U1788 ( .A0(\txfifo[18][1] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[1]), .Y(n347) );
  AO22X1 U1789 ( .A0(\txfifo[18][2] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[2]), .Y(n348) );
  AO22X1 U1790 ( .A0(\txfifo[18][3] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[3]), .Y(n349) );
  AO22X1 U1791 ( .A0(\txfifo[18][4] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[4]), .Y(n350) );
  AO22X1 U1792 ( .A0(\txfifo[18][5] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[5]), .Y(n351) );
  AO22X1 U1793 ( .A0(\txfifo[18][6] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[6]), .Y(n352) );
  AO22X1 U1794 ( .A0(\txfifo[18][7] ), .A1(n1002), .B0(n1003), .B1(
        fifodata_tx[7]), .Y(n353) );
  AO22X1 U1795 ( .A0(\txfifo[19][0] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[0]), .Y(n354) );
  AO22X1 U1796 ( .A0(\txfifo[19][1] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[1]), .Y(n355) );
  AO22X1 U1797 ( .A0(\txfifo[19][2] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[2]), .Y(n356) );
  AO22X1 U1798 ( .A0(\txfifo[19][3] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[3]), .Y(n357) );
  AO22X1 U1799 ( .A0(\txfifo[19][4] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[4]), .Y(n358) );
  AO22X1 U1800 ( .A0(\txfifo[19][5] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[5]), .Y(n359) );
  AO22X1 U1801 ( .A0(\txfifo[19][6] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[6]), .Y(n360) );
  AO22X1 U1802 ( .A0(\txfifo[19][7] ), .A1(n1000), .B0(n1001), .B1(
        fifodata_tx[7]), .Y(n361) );
  AO22X1 U1803 ( .A0(\txfifo[20][0] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[0]), .Y(n362) );
  AO22X1 U1804 ( .A0(\txfifo[20][1] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[1]), .Y(n363) );
  AO22X1 U1805 ( .A0(\txfifo[20][2] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[2]), .Y(n364) );
  AO22X1 U1806 ( .A0(\txfifo[20][3] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[3]), .Y(n365) );
  AO22X1 U1807 ( .A0(\txfifo[20][4] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[4]), .Y(n366) );
  AO22X1 U1808 ( .A0(\txfifo[20][5] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[5]), .Y(n367) );
  AO22X1 U1809 ( .A0(\txfifo[20][6] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[6]), .Y(n368) );
  AO22X1 U1810 ( .A0(\txfifo[20][7] ), .A1(n998), .B0(n999), .B1(
        fifodata_tx[7]), .Y(n369) );
  AO22X1 U1811 ( .A0(\txfifo[21][0] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[0]), .Y(n370) );
  AO22X1 U1812 ( .A0(\txfifo[21][1] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[1]), .Y(n371) );
  AO22X1 U1813 ( .A0(\txfifo[21][2] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[2]), .Y(n372) );
  AO22X1 U1814 ( .A0(\txfifo[21][3] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[3]), .Y(n373) );
  AO22X1 U1815 ( .A0(\txfifo[21][4] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[4]), .Y(n374) );
  AO22X1 U1816 ( .A0(\txfifo[21][5] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[5]), .Y(n375) );
  AO22X1 U1817 ( .A0(\txfifo[21][6] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[6]), .Y(n376) );
  AO22X1 U1818 ( .A0(\txfifo[21][7] ), .A1(n996), .B0(n997), .B1(
        fifodata_tx[7]), .Y(n377) );
  AO22X1 U1819 ( .A0(\txfifo[22][0] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[0]), .Y(n378) );
  AO22X1 U1820 ( .A0(\txfifo[22][1] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[1]), .Y(n379) );
  AO22X1 U1821 ( .A0(\txfifo[22][2] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[2]), .Y(n380) );
  AO22X1 U1822 ( .A0(\txfifo[22][3] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[3]), .Y(n381) );
  AO22X1 U1823 ( .A0(\txfifo[22][4] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[4]), .Y(n382) );
  AO22X1 U1824 ( .A0(\txfifo[22][5] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[5]), .Y(n383) );
  AO22X1 U1825 ( .A0(\txfifo[22][6] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[6]), .Y(n384) );
  AO22X1 U1826 ( .A0(\txfifo[22][7] ), .A1(n993), .B0(n994), .B1(
        fifodata_tx[7]), .Y(n385) );
  AO22X1 U1827 ( .A0(\txfifo[23][0] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[0]), .Y(n386) );
  AO22X1 U1828 ( .A0(\txfifo[23][1] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[1]), .Y(n387) );
  AO22X1 U1829 ( .A0(\txfifo[23][2] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[2]), .Y(n388) );
  AO22X1 U1830 ( .A0(\txfifo[23][3] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[3]), .Y(n389) );
  AO22X1 U1831 ( .A0(\txfifo[23][4] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[4]), .Y(n390) );
  AO22X1 U1832 ( .A0(\txfifo[23][5] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[5]), .Y(n391) );
  AO22X1 U1833 ( .A0(\txfifo[23][6] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[6]), .Y(n392) );
  AO22X1 U1834 ( .A0(\txfifo[23][7] ), .A1(n990), .B0(n991), .B1(
        fifodata_tx[7]), .Y(n393) );
  AO22X1 U1835 ( .A0(\txfifo[24][0] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[0]), .Y(n394) );
  AO22X1 U1836 ( .A0(\txfifo[24][1] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[1]), .Y(n395) );
  AO22X1 U1837 ( .A0(\txfifo[24][2] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[2]), .Y(n396) );
  AO22X1 U1838 ( .A0(\txfifo[24][3] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[3]), .Y(n397) );
  AO22X1 U1839 ( .A0(\txfifo[24][4] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[4]), .Y(n398) );
  AO22X1 U1840 ( .A0(\txfifo[24][5] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[5]), .Y(n399) );
  AO22X1 U1841 ( .A0(\txfifo[24][6] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[6]), .Y(n400) );
  AO22X1 U1842 ( .A0(\txfifo[24][7] ), .A1(n986), .B0(n987), .B1(
        fifodata_tx[7]), .Y(n401) );
  AO22X1 U1843 ( .A0(\txfifo[25][0] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[0]), .Y(n402) );
  AO22X1 U1844 ( .A0(\txfifo[25][1] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[1]), .Y(n403) );
  AO22X1 U1845 ( .A0(\txfifo[25][2] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[2]), .Y(n404) );
  AO22X1 U1846 ( .A0(\txfifo[25][3] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[3]), .Y(n405) );
  AO22X1 U1847 ( .A0(\txfifo[25][4] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[4]), .Y(n406) );
  AO22X1 U1848 ( .A0(\txfifo[25][5] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[5]), .Y(n407) );
  AO22X1 U1849 ( .A0(\txfifo[25][6] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[6]), .Y(n408) );
  AO22X1 U1850 ( .A0(\txfifo[25][7] ), .A1(n982), .B0(n983), .B1(
        fifodata_tx[7]), .Y(n409) );
  AO22X1 U1851 ( .A0(\txfifo[26][0] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[0]), .Y(n410) );
  AO22X1 U1852 ( .A0(\txfifo[26][1] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[1]), .Y(n411) );
  AO22X1 U1853 ( .A0(\txfifo[26][2] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[2]), .Y(n412) );
  AO22X1 U1854 ( .A0(\txfifo[26][3] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[3]), .Y(n413) );
  AO22X1 U1855 ( .A0(\txfifo[26][4] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[4]), .Y(n414) );
  AO22X1 U1856 ( .A0(\txfifo[26][5] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[5]), .Y(n415) );
  AO22X1 U1857 ( .A0(\txfifo[26][6] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[6]), .Y(n416) );
  AO22X1 U1858 ( .A0(\txfifo[26][7] ), .A1(n978), .B0(n979), .B1(
        fifodata_tx[7]), .Y(n417) );
  AO22X1 U1859 ( .A0(\txfifo[27][0] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[0]), .Y(n418) );
  AO22X1 U1860 ( .A0(\txfifo[27][1] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[1]), .Y(n419) );
  AO22X1 U1861 ( .A0(\txfifo[27][2] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[2]), .Y(n420) );
  AO22X1 U1862 ( .A0(\txfifo[27][3] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[3]), .Y(n421) );
  AO22X1 U1863 ( .A0(\txfifo[27][4] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[4]), .Y(n422) );
  AO22X1 U1864 ( .A0(\txfifo[27][5] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[5]), .Y(n423) );
  AO22X1 U1865 ( .A0(\txfifo[27][6] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[6]), .Y(n424) );
  AO22X1 U1866 ( .A0(\txfifo[27][7] ), .A1(n974), .B0(n975), .B1(
        fifodata_tx[7]), .Y(n425) );
  AO22X1 U1867 ( .A0(\txfifo[28][0] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[0]), .Y(n426) );
  AO22X1 U1868 ( .A0(\txfifo[28][1] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[1]), .Y(n427) );
  AO22X1 U1869 ( .A0(\txfifo[28][2] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[2]), .Y(n428) );
  AO22X1 U1870 ( .A0(\txfifo[28][3] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[3]), .Y(n429) );
  AO22X1 U1871 ( .A0(\txfifo[28][4] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[4]), .Y(n430) );
  AO22X1 U1872 ( .A0(\txfifo[28][5] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[5]), .Y(n431) );
  AO22X1 U1873 ( .A0(\txfifo[28][6] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[6]), .Y(n432) );
  AO22X1 U1874 ( .A0(\txfifo[28][7] ), .A1(n970), .B0(n971), .B1(
        fifodata_tx[7]), .Y(n433) );
  AO22X1 U1875 ( .A0(\txfifo[29][0] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[0]), .Y(n434) );
  AO22X1 U1876 ( .A0(\txfifo[29][1] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[1]), .Y(n435) );
  AO22X1 U1877 ( .A0(\txfifo[29][2] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[2]), .Y(n436) );
  AO22X1 U1878 ( .A0(\txfifo[29][3] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[3]), .Y(n437) );
  AO22X1 U1879 ( .A0(\txfifo[29][4] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[4]), .Y(n438) );
  AO22X1 U1880 ( .A0(\txfifo[29][5] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[5]), .Y(n439) );
  AO22X1 U1881 ( .A0(\txfifo[29][6] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[6]), .Y(n440) );
  AO22X1 U1882 ( .A0(\txfifo[29][7] ), .A1(n966), .B0(n967), .B1(
        fifodata_tx[7]), .Y(n441) );
  AO22X1 U1883 ( .A0(\txfifo[30][0] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[0]), .Y(n442) );
  AO22X1 U1884 ( .A0(\txfifo[30][1] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[1]), .Y(n443) );
  AO22X1 U1885 ( .A0(\txfifo[30][2] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[2]), .Y(n444) );
  AO22X1 U1886 ( .A0(\txfifo[30][3] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[3]), .Y(n445) );
  AO22X1 U1887 ( .A0(\txfifo[30][4] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[4]), .Y(n446) );
  AO22X1 U1888 ( .A0(\txfifo[30][5] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[5]), .Y(n447) );
  AO22X1 U1889 ( .A0(\txfifo[30][6] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[6]), .Y(n448) );
  AO22X1 U1890 ( .A0(\txfifo[30][7] ), .A1(n962), .B0(n963), .B1(
        fifodata_tx[7]), .Y(n449) );
  AO22X1 U1891 ( .A0(N506), .A1(n943), .B0(fifo_wrpos_3_), .B1(n938), .Y(n467)
         );
  AO22X1 U1892 ( .A0(N505), .A1(n943), .B0(fifo_wrpos_2_), .B1(n938), .Y(n466)
         );
  AO22X1 U1893 ( .A0(N504), .A1(n943), .B0(n1352), .B1(n938), .Y(n465) );
  AO22X1 U1894 ( .A0(n943), .A1(n1108), .B0(n938), .B1(n1351), .Y(n464) );
  INVX1 U1895 ( .A(n945), .Y(n938) );
  NAND2BX1 U1896 ( .AN(swrst), .B(n940), .Y(n945) );
  AO21X1 U1897 ( .A0(n938), .A1(fifo_wrpos_4_), .B0(n939), .Y(n468) );
  OAI33X1 U1898 ( .A0(n940), .A1(n941), .A2(n1344), .B0(n940), .B1(n1101), 
        .B2(fifo_wrpos_4_), .Y(n939) );
  INVX1 U1899 ( .A(n1101), .Y(n941) );
  OAI31X1 U1900 ( .A0(n953), .A1(n954), .A2(n955), .B0(n956), .Y(n458) );
  NAND4BX1 U1901 ( .AN(n957), .B(txfifocnt[2]), .C(txfifocnt[4]), .D(
        txfifocnt[3]), .Y(n954) );
  NAND3BX1 U1902 ( .AN(swrst), .B(n946), .C(fifordb), .Y(n955) );
  OAI211X1 U1903 ( .A0(fifordb), .A1(n946), .B0(txfifocnt[5]), .C0(n937), .Y(
        n956) );
  AFHCONX2 U2_3 ( .A(fifo_wrpos_3_), .B(n1224), .CI(carry), .S(txfifocnt[3]), 
        .CON(n511) );
  INVX1 U1904 ( .A(n610), .Y(carry) );
  AFHCONX2 U2_2 ( .A(fifo_wrpos_2_), .B(n1346), .CI(carry0), .S(txfifocnt[2]), 
        .CON(n610) );
  INVX1 U1905 ( .A(n710), .Y(carry0) );
  XOR3X1 U2_4 ( .A(fifo_wrpos_4_), .B(n1225), .C(carry_4_), .Y(txfifocnt[4])
         );
  INVX1 U1906 ( .A(n511), .Y(carry_4_) );
  NAND3BX1 U1907 ( .AN(swrst), .B(n1348), .C(txfifo_emptyb), .Y(n949) );
  NAND2BX1 U1908 ( .AN(n1351), .B(N74), .Y(carry_1_) );
  NAND4BX1 U1909 ( .AN(n1094), .B(n1095), .C(n957), .D(n953), .Y(txfifo_emptyb) );
  INVX1 U1910 ( .A(txfifocnt[2]), .Y(n1095) );
  NAND3BX1 U1911 ( .AN(txfifocnt[3]), .B(n1097), .C(txfifo_fullb), .Y(n1094)
         );
  BUFX2 U1912 ( .A(fifo_wrpos_0_), .Y(n1351) );
  BUFX2 U1913 ( .A(n483), .Y(n1352) );
  AO21X1 U1914 ( .A0(n947), .A1(N78), .B0(n948), .Y(n463) );
  OAI33X1 U1915 ( .A0(n949), .A1(n1225), .A2(n950), .B0(n949), .B1(n1100), 
        .B2(N78), .Y(n948) );
  INVX1 U1916 ( .A(n1100), .Y(n950) );
  AO22X1 U1917 ( .A0(n951), .A1(n1227), .B0(n947), .B1(N74), .Y(n459) );
  AO22X1 U1918 ( .A0(N523), .A1(n951), .B0(n947), .B1(N76), .Y(n461) );
  AO22X1 U1919 ( .A0(N522), .A1(n951), .B0(n947), .B1(N75), .Y(n460) );
  AO22X1 U1920 ( .A0(N524), .A1(n951), .B0(n947), .B1(N77), .Y(n462) );
  INVX1 U1921 ( .A(n952), .Y(n947) );
  NAND2BX1 U1922 ( .AN(swrst), .B(n949), .Y(n952) );
  INVX1 U1923 ( .A(n2100), .Y(carry1) );
  INVX1 U1924 ( .A(n2), .Y(carry_3_) );
  INVX1 U1925 ( .A(n3100), .Y(carry2) );
  INVX1 U1926 ( .A(n3), .Y(carry_2_) );
  NAND3BX1 U1927 ( .AN(baudx16clk), .B(n1226), .C(n937), .Y(n936) );
  NAND3BX1 U1928 ( .AN(swrst), .B(n1226), .C(n936), .Y(n924) );
  NAND3BX1 U1929 ( .AN(n1232), .B(txclkcnt[0]), .C(n930), .Y(n926) );
  NAND2BX1 U1930 ( .AN(N75), .B(N74), .Y(n895) );
  NAND2BX1 U1931 ( .AN(N77), .B(n1346), .Y(n913) );
  NAND2BX1 U1932 ( .AN(N74), .B(N75), .Y(n900) );
  OAI31X1 U1933 ( .A0(n1106), .A1(stopbit), .A2(n1107), .B0(n1098), .Y(n1066)
         );
  OA21X2 U1934 ( .A0(n1106), .A1(n1111), .B0(n9), .Y(n1098) );
  NAND2BX1 U1935 ( .AN(n1085), .B(n1053), .Y(n1069) );
  OAI211X1 U1936 ( .A0(txclk), .A1(n1111), .B0(n1282), .C0(n1091), .Y(n1085)
         );
  OA22X1 U1937 ( .A0(n1107), .A1(n1049), .B0(txclk), .B1(n1229), .Y(n1091) );
  NAND2BX1 U1938 ( .AN(n1223), .B(N74), .Y(n916) );
  NAND2BX1 U1939 ( .AN(N77), .B(N76), .Y(n907) );
  NAND2BX1 U1940 ( .AN(N76), .B(N77), .Y(n898) );
  OR2X1 U1941 ( .A(parity[0]), .B(parity[1]), .Y(n1087) );
  INVX1 U1942 ( .A(swrst), .Y(n937) );
  OAI31X1 U1943 ( .A0(n1106), .A1(databit), .A2(n1231), .B0(n1076), .Y(n1055)
         );
  OA22X1 U1944 ( .A0(txclk), .A1(n1109), .B0(n1106), .B1(n1114), .Y(n1076) );
  NAND2BX1 U1945 ( .AN(N75), .B(n1227), .Y(n897) );
  OAI211X1 U1946 ( .A0(n489), .A1(n490), .B0(n6), .C0(n491), .Y(txd) );
  NAND2BX1 U1947 ( .AN(n1230), .B(parity_int), .Y(n490) );
  AOI32X1 U1948 ( .A0(n1103), .A1(n1113), .A2(n489), .B0(shiftreg_0_), .B1(
        n1104), .Y(n491) );
  NAND2BX1 U1949 ( .AN(parity[0]), .B(parity[1]), .Y(n489) );
  OAI221X1 U1950 ( .A0(n508), .A1(n1124), .B0(n510), .B1(n1242), .C0(n910), 
        .Y(n887) );
  OA22X1 U1951 ( .A0(n514), .A1(n1179), .B0(n516), .B1(n1299), .Y(n910) );
  OAI221X1 U1952 ( .A0(n508), .A1(n1125), .B0(n510), .B1(n1243), .C0(n852), 
        .Y(n837) );
  OA22X1 U1953 ( .A0(n514), .A1(n1180), .B0(n516), .B1(n1300), .Y(n852) );
  OAI221X1 U1954 ( .A0(n508), .A1(n1126), .B0(n510), .B1(n1244), .C0(n803), 
        .Y(n788) );
  OA22X1 U1955 ( .A0(n514), .A1(n1181), .B0(n516), .B1(n1301), .Y(n803) );
  OAI221X1 U1956 ( .A0(n508), .A1(n1127), .B0(n510), .B1(n1245), .C0(n754), 
        .Y(n739) );
  OA22X1 U1957 ( .A0(n514), .A1(n1182), .B0(n516), .B1(n1302), .Y(n754) );
  OAI221X1 U1958 ( .A0(n508), .A1(n1128), .B0(n510), .B1(n1246), .C0(n704), 
        .Y(n689) );
  OA22X1 U1959 ( .A0(n514), .A1(n1183), .B0(n516), .B1(n1303), .Y(n704) );
  OAI221X1 U1960 ( .A0(n508), .A1(n1129), .B0(n510), .B1(n1247), .C0(n655), 
        .Y(n640) );
  OA22X1 U1961 ( .A0(n514), .A1(n1184), .B0(n516), .B1(n1304), .Y(n655) );
  OAI221X1 U1962 ( .A0(n508), .A1(n1130), .B0(n510), .B1(n1248), .C0(n605), 
        .Y(n590) );
  OA22X1 U1963 ( .A0(n514), .A1(n1185), .B0(n516), .B1(n1305), .Y(n605) );
  OA22X1 U1964 ( .A0(n552), .A1(n1186), .B0(n1350), .B1(n1306), .Y(n883) );
  OA22X1 U1965 ( .A0(n552), .A1(n1187), .B0(n1350), .B1(n1307), .Y(n833) );
  OA22X1 U1966 ( .A0(n552), .A1(n1188), .B0(n1350), .B1(n1308), .Y(n784) );
  OA22X1 U1967 ( .A0(n552), .A1(n1189), .B0(n1350), .B1(n1309), .Y(n735) );
  OA22X1 U1968 ( .A0(n552), .A1(n1190), .B0(n1350), .B1(n1310), .Y(n685) );
  OA22X1 U1969 ( .A0(n552), .A1(n1191), .B0(n1350), .B1(n1311), .Y(n636) );
  OA22X1 U1970 ( .A0(n552), .A1(n1192), .B0(n1350), .B1(n1312), .Y(n586) );
  OAI221X1 U1971 ( .A0(n544), .A1(n1131), .B0(n545), .B1(n1249), .C0(n866), 
        .Y(n862) );
  OA22X1 U1972 ( .A0(n547), .A1(n1193), .B0(n1349), .B1(n1313), .Y(n866) );
  OAI221X1 U1973 ( .A0(n549), .A1(n1132), .B0(n550), .B1(n1250), .C0(n892), 
        .Y(n889) );
  OA22X1 U1974 ( .A0(n552), .A1(n1194), .B0(n1350), .B1(n1314), .Y(n892) );
  OAI221X1 U1975 ( .A0(n544), .A1(n1133), .B0(n545), .B1(n1251), .C0(n903), 
        .Y(n888) );
  OA22X1 U1976 ( .A0(n547), .A1(n1195), .B0(n1349), .B1(n1315), .Y(n903) );
  OAI221X1 U1977 ( .A0(n544), .A1(n1134), .B0(n545), .B1(n1252), .C0(n816), 
        .Y(n813) );
  OA22X1 U1978 ( .A0(n547), .A1(n1196), .B0(n1349), .B1(n1316), .Y(n816) );
  OAI221X1 U1979 ( .A0(n549), .A1(n1135), .B0(n550), .B1(n1253), .C0(n842), 
        .Y(n839) );
  OA22X1 U1980 ( .A0(n552), .A1(n1197), .B0(n1350), .B1(n1317), .Y(n842) );
  OAI221X1 U1981 ( .A0(n544), .A1(n1136), .B0(n545), .B1(n1254), .C0(n847), 
        .Y(n838) );
  OA22X1 U1982 ( .A0(n547), .A1(n1198), .B0(n1349), .B1(n1318), .Y(n847) );
  OAI221X1 U1983 ( .A0(n544), .A1(n1137), .B0(n545), .B1(n1255), .C0(n767), 
        .Y(n764) );
  OA22X1 U1984 ( .A0(n547), .A1(n1199), .B0(n1349), .B1(n1319), .Y(n767) );
  OAI221X1 U1985 ( .A0(n549), .A1(n1138), .B0(n550), .B1(n1256), .C0(n793), 
        .Y(n790) );
  OA22X1 U1986 ( .A0(n552), .A1(n1200), .B0(n1350), .B1(n1320), .Y(n793) );
  OAI221X1 U1987 ( .A0(n544), .A1(n1139), .B0(n545), .B1(n1257), .C0(n798), 
        .Y(n789) );
  OA22X1 U1988 ( .A0(n547), .A1(n1201), .B0(n1349), .B1(n1321), .Y(n798) );
  OAI221X1 U1989 ( .A0(n544), .A1(n1140), .B0(n545), .B1(n1258), .C0(n718), 
        .Y(n715) );
  OA22X1 U1990 ( .A0(n547), .A1(n1202), .B0(n1349), .B1(n1322), .Y(n718) );
  OAI221X1 U1991 ( .A0(n549), .A1(n1141), .B0(n550), .B1(n1259), .C0(n744), 
        .Y(n741) );
  OA22X1 U1992 ( .A0(n552), .A1(n1203), .B0(n1350), .B1(n1323), .Y(n744) );
  OAI221X1 U1993 ( .A0(n544), .A1(n1142), .B0(n545), .B1(n1260), .C0(n749), 
        .Y(n740) );
  OA22X1 U1994 ( .A0(n547), .A1(n1204), .B0(n1349), .B1(n1324), .Y(n749) );
  OAI221X1 U1995 ( .A0(n544), .A1(n1143), .B0(n545), .B1(n1261), .C0(n668), 
        .Y(n665) );
  OA22X1 U1996 ( .A0(n547), .A1(n1205), .B0(n1349), .B1(n1325), .Y(n668) );
  OAI221X1 U1997 ( .A0(n549), .A1(n1144), .B0(n550), .B1(n1262), .C0(n694), 
        .Y(n691) );
  OA22X1 U1998 ( .A0(n552), .A1(n1206), .B0(n1350), .B1(n1326), .Y(n694) );
  OAI221X1 U1999 ( .A0(n544), .A1(n1145), .B0(n545), .B1(n1263), .C0(n699), 
        .Y(n690) );
  OA22X1 U2000 ( .A0(n547), .A1(n1207), .B0(n1349), .B1(n1327), .Y(n699) );
  OAI221X1 U2001 ( .A0(n544), .A1(n1146), .B0(n545), .B1(n1264), .C0(n619), 
        .Y(n616) );
  OA22X1 U2002 ( .A0(n547), .A1(n1208), .B0(n1349), .B1(n1328), .Y(n619) );
  OAI221X1 U2003 ( .A0(n549), .A1(n1147), .B0(n550), .B1(n1265), .C0(n645), 
        .Y(n642) );
  OA22X1 U2004 ( .A0(n552), .A1(n1209), .B0(n1350), .B1(n1329), .Y(n645) );
  OAI221X1 U2005 ( .A0(n544), .A1(n1148), .B0(n545), .B1(n1266), .C0(n650), 
        .Y(n641) );
  OA22X1 U2006 ( .A0(n547), .A1(n1210), .B0(n1349), .B1(n1330), .Y(n650) );
  OAI221X1 U2007 ( .A0(n544), .A1(n1149), .B0(n545), .B1(n1267), .C0(n565), 
        .Y(n561) );
  OA22X1 U2008 ( .A0(n547), .A1(n1211), .B0(n1349), .B1(n1331), .Y(n565) );
  OAI221X1 U2009 ( .A0(n549), .A1(n1150), .B0(n550), .B1(n1268), .C0(n595), 
        .Y(n592) );
  OA22X1 U2010 ( .A0(n552), .A1(n1212), .B0(n1350), .B1(n1332), .Y(n595) );
  OAI221X1 U2011 ( .A0(n544), .A1(n1151), .B0(n545), .B1(n1269), .C0(n600), 
        .Y(n591) );
  OA22X1 U2012 ( .A0(n547), .A1(n1213), .B0(n1349), .B1(n1333), .Y(n600) );
  OA22X1 U2013 ( .A0(n514), .A1(n1214), .B0(n516), .B1(n1334), .Y(n5130) );
  OA22X1 U2014 ( .A0(n514), .A1(n1215), .B0(n516), .B1(n1335), .Y(n540) );
  NOR2X1 U2015 ( .A(n1224), .B(n1346), .Y(n1345) );
  INVX1 U2016 ( .A(n1072), .Y(n1067) );
  NAND3BX1 U2017 ( .AN(n1073), .B(n1074), .C(n1075), .Y(n1072) );
  NAND3BX1 U2018 ( .AN(n1078), .B(n1164), .C(n1283), .Y(n1073) );
  AOI211X1 U2019 ( .A0(current_state_3_), .A1(txclk), .B0(current_state_4_), 
        .C0(current_state_10_), .Y(n1074) );
  NOR2BX1 U2020 ( .AN(n5060), .B(n507), .Y(n5050) );
  OAI221X1 U2021 ( .A0(n508), .A1(n1152), .B0(n510), .B1(n1270), .C0(n5130), 
        .Y(n507) );
  AOI221X1 U2022 ( .A0(\txfifo[4][7] ), .A1(n518), .B0(\txfifo[5][7] ), .B1(
        n519), .C0(n520), .Y(n5060) );
  NOR2BX1 U2023 ( .AN(n536), .B(n537), .Y(n535) );
  OAI221X1 U2024 ( .A0(n508), .A1(n1153), .B0(n510), .B1(n1271), .C0(n540), 
        .Y(n537) );
  AOI221X1 U2025 ( .A0(\txfifo[20][7] ), .A1(n518), .B0(\txfifo[21][7] ), .B1(
        n519), .C0(n543), .Y(n536) );
  AO22X1 U2026 ( .A0(txclkcnt[2]), .A1(n922), .B0(n928), .B1(n1116), .Y(n471)
         );
  INVX1 U2027 ( .A(n926), .Y(n928) );
  AO22X1 U2028 ( .A0(\txfifo[7][7] ), .A1(n521), .B0(\txfifo[6][7] ), .B1(
        n5220), .Y(n520) );
  AO22X1 U2029 ( .A0(\txfifo[23][7] ), .A1(n521), .B0(\txfifo[22][7] ), .B1(
        n5220), .Y(n543) );
  AOI221X1 U2030 ( .A0(\txfifo[28][0] ), .A1(n528), .B0(\txfifo[29][0] ), .B1(
        n529), .C0(n918), .Y(n886) );
  AO22X1 U2031 ( .A0(\txfifo[31][0] ), .A1(n531), .B0(\txfifo[30][0] ), .B1(
        n532), .Y(n918) );
  AOI221X1 U2032 ( .A0(\txfifo[28][1] ), .A1(n528), .B0(\txfifo[29][1] ), .B1(
        n529), .C0(n855), .Y(n836) );
  AO22X1 U2033 ( .A0(\txfifo[31][1] ), .A1(n531), .B0(\txfifo[30][1] ), .B1(
        n532), .Y(n855) );
  AOI221X1 U2034 ( .A0(\txfifo[28][2] ), .A1(n528), .B0(\txfifo[29][2] ), .B1(
        n529), .C0(n806), .Y(n787) );
  AO22X1 U2035 ( .A0(\txfifo[31][2] ), .A1(n531), .B0(\txfifo[30][2] ), .B1(
        n532), .Y(n806) );
  AOI221X1 U2036 ( .A0(\txfifo[28][3] ), .A1(n528), .B0(\txfifo[29][3] ), .B1(
        n529), .C0(n757), .Y(n738) );
  AO22X1 U2037 ( .A0(\txfifo[31][3] ), .A1(n531), .B0(\txfifo[30][3] ), .B1(
        n532), .Y(n757) );
  AOI221X1 U2038 ( .A0(\txfifo[28][4] ), .A1(n528), .B0(\txfifo[29][4] ), .B1(
        n529), .C0(n707), .Y(n688) );
  AO22X1 U2039 ( .A0(\txfifo[31][4] ), .A1(n531), .B0(\txfifo[30][4] ), .B1(
        n532), .Y(n707) );
  AOI221X1 U2040 ( .A0(\txfifo[28][5] ), .A1(n528), .B0(\txfifo[29][5] ), .B1(
        n529), .C0(n658), .Y(n639) );
  AO22X1 U2041 ( .A0(\txfifo[31][5] ), .A1(n531), .B0(\txfifo[30][5] ), .B1(
        n532), .Y(n658) );
  AOI221X1 U2042 ( .A0(\txfifo[28][6] ), .A1(n528), .B0(\txfifo[29][6] ), .B1(
        n529), .C0(n608), .Y(n589) );
  AO22X1 U2043 ( .A0(\txfifo[31][6] ), .A1(n531), .B0(\txfifo[30][6] ), .B1(
        n532), .Y(n608) );
  OAI32X1 U2044 ( .A0(n924), .A1(txclkcnt[1]), .A2(n1110), .B0(n933), .B1(
        n1232), .Y(n470) );
  INVX1 U2045 ( .A(n931), .Y(n933) );
  OAI221X1 U2046 ( .A0(n1115), .A1(n498), .B0(n499), .B1(n1115), .C0(n500), 
        .Y(n480) );
  OAI211X1 U2047 ( .A0(n501), .A1(n502), .B0(n499), .C0(n498), .Y(n500) );
  AOI31X1 U2048 ( .A0(n533), .A1(n534), .A2(n535), .B0(n1225), .Y(n501) );
  AOI31X1 U2049 ( .A0(n503), .A1(n5040), .A2(n5050), .B0(N78), .Y(n502) );
  OAI221X1 U2050 ( .A0(n508), .A1(n1154), .B0(n510), .B1(n1272), .C0(n871), 
        .Y(n861) );
  OA22X1 U2051 ( .A0(n514), .A1(n1216), .B0(n516), .B1(n1336), .Y(n871) );
  OAI221X1 U2052 ( .A0(n508), .A1(n1155), .B0(n510), .B1(n1273), .C0(n821), 
        .Y(n812) );
  OA22X1 U2053 ( .A0(n514), .A1(n1217), .B0(n516), .B1(n1337), .Y(n821) );
  OAI221X1 U2054 ( .A0(n508), .A1(n1156), .B0(n510), .B1(n1274), .C0(n772), 
        .Y(n763) );
  OA22X1 U2055 ( .A0(n514), .A1(n1218), .B0(n516), .B1(n1338), .Y(n772) );
  OAI221X1 U2056 ( .A0(n508), .A1(n1157), .B0(n510), .B1(n1275), .C0(n723), 
        .Y(n714) );
  OA22X1 U2057 ( .A0(n514), .A1(n1219), .B0(n516), .B1(n1339), .Y(n723) );
  OAI221X1 U2058 ( .A0(n508), .A1(n1158), .B0(n510), .B1(n1276), .C0(n673), 
        .Y(n664) );
  OA22X1 U2059 ( .A0(n514), .A1(n1220), .B0(n516), .B1(n1340), .Y(n673) );
  OAI221X1 U2060 ( .A0(n508), .A1(n1159), .B0(n510), .B1(n1277), .C0(n624), 
        .Y(n615) );
  OA22X1 U2061 ( .A0(n514), .A1(n1221), .B0(n516), .B1(n1341), .Y(n624) );
  OAI221X1 U2062 ( .A0(n508), .A1(n1160), .B0(n510), .B1(n1278), .C0(n570), 
        .Y(n560) );
  OA22X1 U2063 ( .A0(n514), .A1(n1222), .B0(n516), .B1(n1342), .Y(n570) );
  AO21X1 U2064 ( .A0(txclkcnt[3]), .A1(n922), .B0(n923), .Y(n472) );
  OAI33X1 U2065 ( .A0(n924), .A1(txclkcnt[2]), .A2(n1233), .B0(n926), .B1(
        txclkcnt[3]), .B2(n1116), .Y(n923) );
  AOI221X1 U2066 ( .A0(\txfifo[12][7] ), .A1(n528), .B0(\txfifo[13][7] ), .B1(
        n529), .C0(n530), .Y(n503) );
  AO22X1 U2067 ( .A0(\txfifo[15][7] ), .A1(n531), .B0(\txfifo[14][7] ), .B1(
        n532), .Y(n530) );
  AOI221X1 U2068 ( .A0(\txfifo[28][7] ), .A1(n528), .B0(\txfifo[29][7] ), .B1(
        n529), .C0(n553), .Y(n533) );
  AO22X1 U2069 ( .A0(\txfifo[31][7] ), .A1(n531), .B0(\txfifo[30][7] ), .B1(
        n532), .Y(n553) );
  AOI221X1 U2070 ( .A0(\txfifo[8][7] ), .A1(n5230), .B0(\txfifo[9][7] ), .B1(
        n5240), .C0(n525), .Y(n5040) );
  AO22X1 U2071 ( .A0(\txfifo[11][7] ), .A1(n526), .B0(\txfifo[10][7] ), .B1(
        n527), .Y(n525) );
  AOI221X1 U2072 ( .A0(\txfifo[24][7] ), .A1(n5230), .B0(\txfifo[25][7] ), 
        .B1(n5240), .C0(n548), .Y(n534) );
  AO22X1 U2073 ( .A0(\txfifo[27][7] ), .A1(n526), .B0(\txfifo[26][7] ), .B1(
        n527), .Y(n548) );
  INVX1 U2074 ( .A(n1086), .Y(n1053) );
  OAI31X1 U2075 ( .A0(n1106), .A1(n1109), .A2(n1087), .B0(n1088), .Y(n1086) );
  OA22X1 U2076 ( .A0(n1106), .A1(n1234), .B0(txclk), .B1(n1107), .Y(n1088) );
  NAND3BX1 U2077 ( .AN(fifo_wrpos_2_), .B(n1112), .C(n1108), .Y(n989) );
  NAND3BX1 U2078 ( .AN(fifo_wrpos_2_), .B(n1112), .C(n1351), .Y(n985) );
  NAND3BX1 U2079 ( .AN(fifo_wrpos_2_), .B(n1108), .C(n1352), .Y(n981) );
  NAND3BX1 U2080 ( .AN(fifo_wrpos_2_), .B(n1352), .C(n1351), .Y(n977) );
  NAND3BX1 U2081 ( .AN(n1352), .B(fifo_wrpos_2_), .C(n1351), .Y(n969) );
  NAND3BX1 U2082 ( .AN(n1351), .B(fifo_wrpos_2_), .C(n1352), .Y(n965) );
  NAND3BX1 U2083 ( .AN(n1352), .B(n1108), .C(fifo_wrpos_2_), .Y(n973) );
  NAND3BX1 U2084 ( .AN(shiftenb), .B(fifordb), .C(txclk), .Y(n498) );
  NAND2BX1 U2085 ( .AN(swrst), .B(txclk), .Y(n1048) );
  NAND2BX1 U2086 ( .AN(swrst), .B(n1106), .Y(n1051) );
  AO22X1 U2087 ( .A0(current_state_3_), .A1(n1106), .B0(current_state_2_), 
        .B1(txclk), .Y(n1061) );
  OAI32X1 U2088 ( .A0(n1106), .A1(n1099), .A2(n1109), .B0(txclk), .B1(n1234), 
        .Y(n1071) );
  INVX1 U2089 ( .A(n1087), .Y(n1099) );
  NOR2BX1 U2090 ( .AN(n1055), .B(swrst), .Y(N129) );
  NOR2BX1 U2091 ( .AN(n1061), .B(swrst), .Y(N121) );
  NAND2BX1 U2092 ( .AN(fifordb), .B(N78), .Y(n555) );
  OR3X2 U2093 ( .A(current_state_9_), .B(current_state_8_), .C(
        current_state_7_), .Y(n1078) );
  INVX1 U2094 ( .A(n1030), .Y(n961) );
  NAND3BX1 U2095 ( .AN(n1112), .B(fifo_wrpos_2_), .C(n1351), .Y(n1030) );
  OAI33X1 U2096 ( .A0(n494), .A1(n1348), .A2(n1113), .B0(n496), .B1(parity_int), .B2(n1348), .Y(n481) );
  INVX1 U2097 ( .A(n496), .Y(n494) );
  NAND3BX1 U2098 ( .AN(shiftenb), .B(dtxclk), .C(shiftreg_0_), .Y(n496) );
  AO22X1 U2099 ( .A0(n934), .A1(txclkcnt[0]), .B0(n930), .B1(n1110), .Y(n469)
         );
  AO22X1 U2100 ( .A0(current_state_8_), .A1(n1059), .B0(current_state_9_), 
        .B1(n1060), .Y(N127) );
  AO22X1 U2101 ( .A0(current_state_7_), .A1(n1059), .B0(current_state_8_), 
        .B1(n1060), .Y(N126) );
  AO22X1 U2102 ( .A0(current_state_6_), .A1(n1059), .B0(current_state_7_), 
        .B1(n1060), .Y(N125) );
  AO22X1 U2103 ( .A0(current_state_5_), .A1(n1059), .B0(current_state_6_), 
        .B1(n1060), .Y(N124) );
  AO22X1 U2104 ( .A0(current_state_4_), .A1(n1059), .B0(current_state_5_), 
        .B1(n1060), .Y(N123) );
  AO22X1 U2105 ( .A0(current_state_3_), .A1(n1059), .B0(current_state_4_), 
        .B1(n1060), .Y(N122) );
  AO22X1 U2106 ( .A0(current_state_1_), .A1(n937), .B0(current_state_2_), .B1(
        n1060), .Y(N120) );
  AND4X1 U2107 ( .A(baudx16clk), .B(n1226), .C(txclkcnt[1]), .D(n1047), .Y(
        N513) );
  AND4X1 U2108 ( .A(n937), .B(n1110), .C(n1116), .D(n1233), .Y(n1047) );
  OAI32X1 U2109 ( .A0(n1048), .A1(n1056), .A2(n1231), .B0(n1051), .B1(n1114), 
        .Y(N128) );
  INVX1 U2110 ( .A(databit), .Y(n1056) );
  INVX1 U2111 ( .A(stopbit), .Y(n1049) );
  AND2X2 U2112 ( .A(n1348), .B(n1225), .Y(n1347) );
  DFFRX1 fifo_rdpos_reg_0_ ( .D(n459), .CK(clk), .RN(rstb), .Q(N74), .QN(n1227) );
  DFFRX1 fifo_wrpos_reg_3_ ( .D(n467), .CK(clk), .RN(rstb), .Q(fifo_wrpos_3_)
         );
  DFFRX1 fifo_wrpos_reg_2_ ( .D(n466), .CK(clk), .RN(rstb), .Q(fifo_wrpos_2_)
         );
  DFFRX1 fifo_rdpos_reg_2_ ( .D(n461), .CK(clk), .RN(rstb), .Q(N76), .QN(n1346) );
  DFFRX1 fifo_rdpos_reg_1_ ( .D(n460), .CK(clk), .RN(rstb), .Q(N75), .QN(n1223) );
  DFFRX1 fifo_rdpos_reg_3_ ( .D(n462), .CK(clk), .RN(rstb), .Q(N77), .QN(n1224) );
  DFFRX1 fifo_wrpos_reg_0_ ( .D(n464), .CK(clk), .RN(rstb), .Q(fifo_wrpos_0_), 
        .QN(n1108) );
  DFFRX1 fifo_wrpos_reg_1_ ( .D(n465), .CK(clk), .RN(rstb), .Q(n483), .QN(
        n1112) );
  DFFRX1 fifofull_reg ( .D(n458), .CK(clk), .RN(rstb), .Q(txfifocnt[5]), .QN(
        txfifo_fullb) );
  DFFRX1 txclk_reg ( .D(N513), .CK(clk), .RN(rstb), .Q(txclk), .QN(n1106) );
  DFFRX1 fifo_wrpos_reg_4_ ( .D(n468), .CK(clk), .RN(rstb), .Q(fifo_wrpos_4_), 
        .QN(n1344) );
  DFFRX1 fifo_rdpos_reg_4_ ( .D(n463), .CK(clk), .RN(rstb), .Q(N78), .QN(n1225) );
  DFFRX1 shiftreg_reg_0_ ( .D(n473), .CK(clk), .RN(rstb), .Q(shiftreg_0_), 
        .QN(n1284) );
  DFFRX1 parity_int_reg ( .D(n481), .CK(clk), .RN(rstb), .Q(parity_int), .QN(
        n1113) );
  DFFRX1 txfifo_reg ( .D(n209), .CK(clk), .RN(rstb), .Q(\txfifo[0][7] ), .QN(
        n1214) );
  DFFRX1 txfifo_reg0 ( .D(n217), .CK(clk), .RN(rstb), .Q(\txfifo[1][7] ), .QN(
        n1334) );
  DFFRX1 txfifo_reg1 ( .D(n225), .CK(clk), .RN(rstb), .Q(\txfifo[2][7] ), .QN(
        n1152) );
  DFFRX1 txfifo_reg2 ( .D(n233), .CK(clk), .RN(rstb), .Q(\txfifo[3][7] ), .QN(
        n1270) );
  DFFRX1 txfifo_reg3 ( .D(n337), .CK(clk), .RN(rstb), .Q(\txfifo[16][7] ), 
        .QN(n1215) );
  DFFRX1 txfifo_reg4 ( .D(n345), .CK(clk), .RN(rstb), .Q(\txfifo[17][7] ), 
        .QN(n1335) );
  DFFRX1 txfifo_reg5 ( .D(n353), .CK(clk), .RN(rstb), .Q(\txfifo[18][7] ), 
        .QN(n1153) );
  DFFRX1 txfifo_reg6 ( .D(n361), .CK(clk), .RN(rstb), .Q(\txfifo[19][7] ), 
        .QN(n1271) );
  DFFRX1 txdoutsel_reg_3_ ( .D(N130), .CK(clk), .RN(rstb), .Q(n1103), .QN(
        n1230) );
  DFFRX1 current_state_reg_14_ ( .D(N132), .CK(clk), .RN(rstb), .QN(n1111) );
  DFFRX1 current_state_reg_13_ ( .D(N131), .CK(clk), .RN(rstb), .QN(n1107) );
  DFFRX1 txfifo_reg7 ( .D(n265), .CK(clk), .RN(rstb), .Q(\txfifo[7][7] ) );
  DFFRX1 txfifo_reg8 ( .D(n297), .CK(clk), .RN(rstb), .Q(\txfifo[11][7] ) );
  DFFRX1 txfifo_reg9 ( .D(n329), .CK(clk), .RN(rstb), .Q(\txfifo[15][7] ) );
  DFFRX1 txfifo_reg10 ( .D(n393), .CK(clk), .RN(rstb), .Q(\txfifo[23][7] ) );
  DFFRX1 txfifo_reg11 ( .D(n425), .CK(clk), .RN(rstb), .Q(\txfifo[27][7] ) );
  DFFRX1 txfifo_reg12 ( .D(n457), .CK(clk), .RN(rstb), .Q(\txfifo[31][7] ) );
  DFFRX1 txfifo_reg13 ( .D(n257), .CK(clk), .RN(rstb), .Q(\txfifo[6][7] ) );
  DFFRX1 txfifo_reg14 ( .D(n289), .CK(clk), .RN(rstb), .Q(\txfifo[10][7] ) );
  DFFRX1 txfifo_reg15 ( .D(n321), .CK(clk), .RN(rstb), .Q(\txfifo[14][7] ) );
  DFFRX1 txfifo_reg16 ( .D(n385), .CK(clk), .RN(rstb), .Q(\txfifo[22][7] ) );
  DFFRX1 txfifo_reg17 ( .D(n417), .CK(clk), .RN(rstb), .Q(\txfifo[26][7] ) );
  DFFRX1 txfifo_reg18 ( .D(n449), .CK(clk), .RN(rstb), .Q(\txfifo[30][7] ) );
  DFFRX1 txfifo_reg19 ( .D(n241), .CK(clk), .RN(rstb), .Q(\txfifo[4][7] ) );
  DFFRX1 txfifo_reg20 ( .D(n273), .CK(clk), .RN(rstb), .Q(\txfifo[8][7] ) );
  DFFRX1 txfifo_reg21 ( .D(n305), .CK(clk), .RN(rstb), .Q(\txfifo[12][7] ) );
  DFFRX1 txfifo_reg22 ( .D(n369), .CK(clk), .RN(rstb), .Q(\txfifo[20][7] ) );
  DFFRX1 txfifo_reg23 ( .D(n401), .CK(clk), .RN(rstb), .Q(\txfifo[24][7] ) );
  DFFRX1 txfifo_reg24 ( .D(n433), .CK(clk), .RN(rstb), .Q(\txfifo[28][7] ) );
  DFFRX1 txfifo_reg25 ( .D(n249), .CK(clk), .RN(rstb), .Q(\txfifo[5][7] ) );
  DFFRX1 txfifo_reg26 ( .D(n281), .CK(clk), .RN(rstb), .Q(\txfifo[9][7] ) );
  DFFRX1 txfifo_reg27 ( .D(n313), .CK(clk), .RN(rstb), .Q(\txfifo[13][7] ) );
  DFFRX1 txfifo_reg28 ( .D(n377), .CK(clk), .RN(rstb), .Q(\txfifo[21][7] ) );
  DFFRX1 txfifo_reg29 ( .D(n409), .CK(clk), .RN(rstb), .Q(\txfifo[25][7] ) );
  DFFRX1 txfifo_reg30 ( .D(n441), .CK(clk), .RN(rstb), .Q(\txfifo[29][7] ) );
  DFFSX1 txdoutsel_reg_0_ ( .D(N112), .CK(clk), .SN(rstb), .QN(n6) );
  DFFRX1 txdoutsel_reg_2_ ( .D(N114), .CK(clk), .RN(rstb), .Q(n1104) );
  DFFSX1 fifordb_reg ( .D(N111), .CK(clk), .SN(rstb), .Q(fifordb), .QN(n1348)
         );
  DFFRX1 txclkcnt_reg_0_ ( .D(n469), .CK(clk), .RN(rstb), .Q(txclkcnt[0]), 
        .QN(n1110) );
  DFFRX1 txclkcnt_reg_1_ ( .D(n470), .CK(clk), .RN(rstb), .Q(txclkcnt[1]), 
        .QN(n1232) );
  DFFRX1 current_state_reg_8_ ( .D(N126), .CK(clk), .RN(rstb), .Q(
        current_state_8_) );
  DFFRX1 current_state_reg_7_ ( .D(N125), .CK(clk), .RN(rstb), .Q(
        current_state_7_) );
  DFFRX1 current_state_reg_6_ ( .D(N124), .CK(clk), .RN(rstb), .Q(
        current_state_6_), .QN(n1164) );
  DFFRX1 current_state_reg_5_ ( .D(N123), .CK(clk), .RN(rstb), .Q(
        current_state_5_), .QN(n1283) );
  DFFRX1 current_state_reg_2_ ( .D(N120), .CK(clk), .RN(rstb), .Q(
        current_state_2_), .QN(n1229) );
  DFFRX1 current_state_reg_9_ ( .D(N127), .CK(clk), .RN(rstb), .Q(
        current_state_9_), .QN(n1231) );
  DFFRX1 txclkcnt_reg_2_ ( .D(n471), .CK(clk), .RN(rstb), .Q(txclkcnt[2]), 
        .QN(n1116) );
  DFFRX1 txclkcnt_reg_3_ ( .D(n472), .CK(clk), .RN(rstb), .Q(txclkcnt[3]), 
        .QN(n1233) );
  DFFRX1 txfifo_reg31 ( .D(n202), .CK(clk), .RN(rstb), .Q(\txfifo[0][0] ), 
        .QN(n1216) );
  DFFRX1 txfifo_reg32 ( .D(n203), .CK(clk), .RN(rstb), .Q(\txfifo[0][1] ), 
        .QN(n1217) );
  DFFRX1 txfifo_reg33 ( .D(n204), .CK(clk), .RN(rstb), .Q(\txfifo[0][2] ), 
        .QN(n1218) );
  DFFRX1 txfifo_reg34 ( .D(n205), .CK(clk), .RN(rstb), .Q(\txfifo[0][3] ), 
        .QN(n1219) );
  DFFRX1 txfifo_reg35 ( .D(n206), .CK(clk), .RN(rstb), .Q(\txfifo[0][4] ), 
        .QN(n1220) );
  DFFRX1 txfifo_reg36 ( .D(n207), .CK(clk), .RN(rstb), .Q(\txfifo[0][5] ), 
        .QN(n1221) );
  DFFRX1 txfifo_reg37 ( .D(n208), .CK(clk), .RN(rstb), .Q(\txfifo[0][6] ), 
        .QN(n1222) );
  DFFRX1 txfifo_reg38 ( .D(n210), .CK(clk), .RN(rstb), .Q(\txfifo[1][0] ), 
        .QN(n1336) );
  DFFRX1 txfifo_reg39 ( .D(n211), .CK(clk), .RN(rstb), .Q(\txfifo[1][1] ), 
        .QN(n1337) );
  DFFRX1 txfifo_reg40 ( .D(n212), .CK(clk), .RN(rstb), .Q(\txfifo[1][2] ), 
        .QN(n1338) );
  DFFRX1 txfifo_reg41 ( .D(n213), .CK(clk), .RN(rstb), .Q(\txfifo[1][3] ), 
        .QN(n1339) );
  DFFRX1 txfifo_reg42 ( .D(n214), .CK(clk), .RN(rstb), .Q(\txfifo[1][4] ), 
        .QN(n1340) );
  DFFRX1 txfifo_reg43 ( .D(n215), .CK(clk), .RN(rstb), .Q(\txfifo[1][5] ), 
        .QN(n1341) );
  DFFRX1 txfifo_reg44 ( .D(n216), .CK(clk), .RN(rstb), .Q(\txfifo[1][6] ), 
        .QN(n1342) );
  DFFRX1 txfifo_reg45 ( .D(n218), .CK(clk), .RN(rstb), .Q(\txfifo[2][0] ), 
        .QN(n1154) );
  DFFRX1 txfifo_reg46 ( .D(n219), .CK(clk), .RN(rstb), .Q(\txfifo[2][1] ), 
        .QN(n1155) );
  DFFRX1 txfifo_reg47 ( .D(n220), .CK(clk), .RN(rstb), .Q(\txfifo[2][2] ), 
        .QN(n1156) );
  DFFRX1 txfifo_reg48 ( .D(n221), .CK(clk), .RN(rstb), .Q(\txfifo[2][3] ), 
        .QN(n1157) );
  DFFRX1 txfifo_reg49 ( .D(n222), .CK(clk), .RN(rstb), .Q(\txfifo[2][4] ), 
        .QN(n1158) );
  DFFRX1 txfifo_reg50 ( .D(n223), .CK(clk), .RN(rstb), .Q(\txfifo[2][5] ), 
        .QN(n1159) );
  DFFRX1 txfifo_reg51 ( .D(n224), .CK(clk), .RN(rstb), .Q(\txfifo[2][6] ), 
        .QN(n1160) );
  DFFRX1 txfifo_reg52 ( .D(n226), .CK(clk), .RN(rstb), .Q(\txfifo[3][0] ), 
        .QN(n1272) );
  DFFRX1 txfifo_reg53 ( .D(n227), .CK(clk), .RN(rstb), .Q(\txfifo[3][1] ), 
        .QN(n1273) );
  DFFRX1 txfifo_reg54 ( .D(n228), .CK(clk), .RN(rstb), .Q(\txfifo[3][2] ), 
        .QN(n1274) );
  DFFRX1 txfifo_reg55 ( .D(n229), .CK(clk), .RN(rstb), .Q(\txfifo[3][3] ), 
        .QN(n1275) );
  DFFRX1 txfifo_reg56 ( .D(n230), .CK(clk), .RN(rstb), .Q(\txfifo[3][4] ), 
        .QN(n1276) );
  DFFRX1 txfifo_reg57 ( .D(n231), .CK(clk), .RN(rstb), .Q(\txfifo[3][5] ), 
        .QN(n1277) );
  DFFRX1 txfifo_reg58 ( .D(n232), .CK(clk), .RN(rstb), .Q(\txfifo[3][6] ), 
        .QN(n1278) );
  DFFRX1 txfifo_reg59 ( .D(n234), .CK(clk), .RN(rstb), .Q(\txfifo[4][0] ), 
        .QN(n1193) );
  DFFRX1 txfifo_reg60 ( .D(n235), .CK(clk), .RN(rstb), .Q(\txfifo[4][1] ), 
        .QN(n1196) );
  DFFRX1 txfifo_reg61 ( .D(n236), .CK(clk), .RN(rstb), .Q(\txfifo[4][2] ), 
        .QN(n1199) );
  DFFRX1 txfifo_reg62 ( .D(n237), .CK(clk), .RN(rstb), .Q(\txfifo[4][3] ), 
        .QN(n1202) );
  DFFRX1 txfifo_reg63 ( .D(n238), .CK(clk), .RN(rstb), .Q(\txfifo[4][4] ), 
        .QN(n1205) );
  DFFRX1 txfifo_reg64 ( .D(n239), .CK(clk), .RN(rstb), .Q(\txfifo[4][5] ), 
        .QN(n1208) );
  DFFRX1 txfifo_reg65 ( .D(n240), .CK(clk), .RN(rstb), .Q(\txfifo[4][6] ), 
        .QN(n1211) );
  DFFRX1 txfifo_reg66 ( .D(n242), .CK(clk), .RN(rstb), .Q(\txfifo[5][0] ), 
        .QN(n1313) );
  DFFRX1 txfifo_reg67 ( .D(n243), .CK(clk), .RN(rstb), .Q(\txfifo[5][1] ), 
        .QN(n1316) );
  DFFRX1 txfifo_reg68 ( .D(n244), .CK(clk), .RN(rstb), .Q(\txfifo[5][2] ), 
        .QN(n1319) );
  DFFRX1 txfifo_reg69 ( .D(n245), .CK(clk), .RN(rstb), .Q(\txfifo[5][3] ), 
        .QN(n1322) );
  DFFRX1 txfifo_reg70 ( .D(n246), .CK(clk), .RN(rstb), .Q(\txfifo[5][4] ), 
        .QN(n1325) );
  DFFRX1 txfifo_reg71 ( .D(n247), .CK(clk), .RN(rstb), .Q(\txfifo[5][5] ), 
        .QN(n1328) );
  DFFRX1 txfifo_reg72 ( .D(n248), .CK(clk), .RN(rstb), .Q(\txfifo[5][6] ), 
        .QN(n1331) );
  DFFRX1 txfifo_reg73 ( .D(n250), .CK(clk), .RN(rstb), .Q(\txfifo[6][0] ), 
        .QN(n1131) );
  DFFRX1 txfifo_reg74 ( .D(n251), .CK(clk), .RN(rstb), .Q(\txfifo[6][1] ), 
        .QN(n1134) );
  DFFRX1 txfifo_reg75 ( .D(n252), .CK(clk), .RN(rstb), .Q(\txfifo[6][2] ), 
        .QN(n1137) );
  DFFRX1 txfifo_reg76 ( .D(n253), .CK(clk), .RN(rstb), .Q(\txfifo[6][3] ), 
        .QN(n1140) );
  DFFRX1 txfifo_reg77 ( .D(n254), .CK(clk), .RN(rstb), .Q(\txfifo[6][4] ), 
        .QN(n1143) );
  DFFRX1 txfifo_reg78 ( .D(n255), .CK(clk), .RN(rstb), .Q(\txfifo[6][5] ), 
        .QN(n1146) );
  DFFRX1 txfifo_reg79 ( .D(n256), .CK(clk), .RN(rstb), .Q(\txfifo[6][6] ), 
        .QN(n1149) );
  DFFRX1 txfifo_reg80 ( .D(n258), .CK(clk), .RN(rstb), .Q(\txfifo[7][0] ), 
        .QN(n1249) );
  DFFRX1 txfifo_reg81 ( .D(n259), .CK(clk), .RN(rstb), .Q(\txfifo[7][1] ), 
        .QN(n1252) );
  DFFRX1 txfifo_reg82 ( .D(n260), .CK(clk), .RN(rstb), .Q(\txfifo[7][2] ), 
        .QN(n1255) );
  DFFRX1 txfifo_reg83 ( .D(n261), .CK(clk), .RN(rstb), .Q(\txfifo[7][3] ), 
        .QN(n1258) );
  DFFRX1 txfifo_reg84 ( .D(n262), .CK(clk), .RN(rstb), .Q(\txfifo[7][4] ), 
        .QN(n1261) );
  DFFRX1 txfifo_reg85 ( .D(n263), .CK(clk), .RN(rstb), .Q(\txfifo[7][5] ), 
        .QN(n1264) );
  DFFRX1 txfifo_reg86 ( .D(n264), .CK(clk), .RN(rstb), .Q(\txfifo[7][6] ), 
        .QN(n1267) );
  DFFRX1 txfifo_reg87 ( .D(n266), .CK(clk), .RN(rstb), .Q(\txfifo[8][0] ), 
        .QN(n1186) );
  DFFRX1 txfifo_reg88 ( .D(n267), .CK(clk), .RN(rstb), .Q(\txfifo[8][1] ), 
        .QN(n1187) );
  DFFRX1 txfifo_reg89 ( .D(n268), .CK(clk), .RN(rstb), .Q(\txfifo[8][2] ), 
        .QN(n1188) );
  DFFRX1 txfifo_reg90 ( .D(n269), .CK(clk), .RN(rstb), .Q(\txfifo[8][3] ), 
        .QN(n1189) );
  DFFRX1 txfifo_reg91 ( .D(n270), .CK(clk), .RN(rstb), .Q(\txfifo[8][4] ), 
        .QN(n1190) );
  DFFRX1 txfifo_reg92 ( .D(n271), .CK(clk), .RN(rstb), .Q(\txfifo[8][5] ), 
        .QN(n1191) );
  DFFRX1 txfifo_reg93 ( .D(n272), .CK(clk), .RN(rstb), .Q(\txfifo[8][6] ), 
        .QN(n1192) );
  DFFRX1 txfifo_reg94 ( .D(n274), .CK(clk), .RN(rstb), .Q(\txfifo[9][0] ), 
        .QN(n1306) );
  DFFRX1 txfifo_reg95 ( .D(n275), .CK(clk), .RN(rstb), .Q(\txfifo[9][1] ), 
        .QN(n1307) );
  DFFRX1 txfifo_reg96 ( .D(n276), .CK(clk), .RN(rstb), .Q(\txfifo[9][2] ), 
        .QN(n1308) );
  DFFRX1 txfifo_reg97 ( .D(n277), .CK(clk), .RN(rstb), .Q(\txfifo[9][3] ), 
        .QN(n1309) );
  DFFRX1 txfifo_reg98 ( .D(n278), .CK(clk), .RN(rstb), .Q(\txfifo[9][4] ), 
        .QN(n1310) );
  DFFRX1 txfifo_reg99 ( .D(n279), .CK(clk), .RN(rstb), .Q(\txfifo[9][5] ), 
        .QN(n1311) );
  DFFRX1 txfifo_reg100 ( .D(n280), .CK(clk), .RN(rstb), .Q(\txfifo[9][6] ), 
        .QN(n1312) );
  DFFRX1 txfifo_reg101 ( .D(n282), .CK(clk), .RN(rstb), .Q(\txfifo[10][0] ), 
        .QN(n1117) );
  DFFRX1 txfifo_reg102 ( .D(n283), .CK(clk), .RN(rstb), .Q(\txfifo[10][1] ), 
        .QN(n1118) );
  DFFRX1 txfifo_reg103 ( .D(n284), .CK(clk), .RN(rstb), .Q(\txfifo[10][2] ), 
        .QN(n1119) );
  DFFRX1 txfifo_reg104 ( .D(n285), .CK(clk), .RN(rstb), .Q(\txfifo[10][3] ), 
        .QN(n1120) );
  DFFRX1 txfifo_reg105 ( .D(n286), .CK(clk), .RN(rstb), .Q(\txfifo[10][4] ), 
        .QN(n1121) );
  DFFRX1 txfifo_reg106 ( .D(n287), .CK(clk), .RN(rstb), .Q(\txfifo[10][5] ), 
        .QN(n1122) );
  DFFRX1 txfifo_reg107 ( .D(n288), .CK(clk), .RN(rstb), .Q(\txfifo[10][6] ), 
        .QN(n1123) );
  DFFRX1 txfifo_reg108 ( .D(n290), .CK(clk), .RN(rstb), .Q(\txfifo[11][0] ), 
        .QN(n1235) );
  DFFRX1 txfifo_reg109 ( .D(n291), .CK(clk), .RN(rstb), .Q(\txfifo[11][1] ), 
        .QN(n1236) );
  DFFRX1 txfifo_reg110 ( .D(n292), .CK(clk), .RN(rstb), .Q(\txfifo[11][2] ), 
        .QN(n1237) );
  DFFRX1 txfifo_reg111 ( .D(n293), .CK(clk), .RN(rstb), .Q(\txfifo[11][3] ), 
        .QN(n1238) );
  DFFRX1 txfifo_reg112 ( .D(n294), .CK(clk), .RN(rstb), .Q(\txfifo[11][4] ), 
        .QN(n1239) );
  DFFRX1 txfifo_reg113 ( .D(n295), .CK(clk), .RN(rstb), .Q(\txfifo[11][5] ), 
        .QN(n1240) );
  DFFRX1 txfifo_reg114 ( .D(n296), .CK(clk), .RN(rstb), .Q(\txfifo[11][6] ), 
        .QN(n1241) );
  DFFRX1 txfifo_reg115 ( .D(n298), .CK(clk), .RN(rstb), .Q(\txfifo[12][0] ), 
        .QN(n1166) );
  DFFRX1 txfifo_reg116 ( .D(n299), .CK(clk), .RN(rstb), .Q(\txfifo[12][1] ), 
        .QN(n1168) );
  DFFRX1 txfifo_reg117 ( .D(n300), .CK(clk), .RN(rstb), .Q(\txfifo[12][2] ), 
        .QN(n1170) );
  DFFRX1 txfifo_reg118 ( .D(n301), .CK(clk), .RN(rstb), .Q(\txfifo[12][3] ), 
        .QN(n1172) );
  DFFRX1 txfifo_reg119 ( .D(n302), .CK(clk), .RN(rstb), .Q(\txfifo[12][4] ), 
        .QN(n1174) );
  DFFRX1 txfifo_reg120 ( .D(n303), .CK(clk), .RN(rstb), .Q(\txfifo[12][5] ), 
        .QN(n1176) );
  DFFRX1 txfifo_reg121 ( .D(n304), .CK(clk), .RN(rstb), .Q(\txfifo[12][6] ), 
        .QN(n1178) );
  DFFRX1 txfifo_reg122 ( .D(n306), .CK(clk), .RN(rstb), .Q(\txfifo[13][0] ), 
        .QN(n1286) );
  DFFRX1 txfifo_reg123 ( .D(n307), .CK(clk), .RN(rstb), .Q(\txfifo[13][1] ), 
        .QN(n1288) );
  DFFRX1 txfifo_reg124 ( .D(n308), .CK(clk), .RN(rstb), .Q(\txfifo[13][2] ), 
        .QN(n1290) );
  DFFRX1 txfifo_reg125 ( .D(n309), .CK(clk), .RN(rstb), .Q(\txfifo[13][3] ), 
        .QN(n1292) );
  DFFRX1 txfifo_reg126 ( .D(n310), .CK(clk), .RN(rstb), .Q(\txfifo[13][4] ), 
        .QN(n1294) );
  DFFRX1 txfifo_reg127 ( .D(n311), .CK(clk), .RN(rstb), .Q(\txfifo[13][5] ), 
        .QN(n1296) );
  DFFRX1 txfifo_reg128 ( .D(n312), .CK(clk), .RN(rstb), .Q(\txfifo[13][6] ), 
        .QN(n1298) );
  DFFRX1 txfifo_reg129 ( .D(n314), .CK(clk), .RN(rstb), .Q(\txfifo[14][0] ), 
        .QN(n1165) );
  DFFRX1 txfifo_reg130 ( .D(n315), .CK(clk), .RN(rstb), .Q(\txfifo[14][1] ), 
        .QN(n1167) );
  DFFRX1 txfifo_reg131 ( .D(n316), .CK(clk), .RN(rstb), .Q(\txfifo[14][2] ), 
        .QN(n1169) );
  DFFRX1 txfifo_reg132 ( .D(n317), .CK(clk), .RN(rstb), .Q(\txfifo[14][3] ), 
        .QN(n1171) );
  DFFRX1 txfifo_reg133 ( .D(n318), .CK(clk), .RN(rstb), .Q(\txfifo[14][4] ), 
        .QN(n1173) );
  DFFRX1 txfifo_reg134 ( .D(n319), .CK(clk), .RN(rstb), .Q(\txfifo[14][5] ), 
        .QN(n1175) );
  DFFRX1 txfifo_reg135 ( .D(n320), .CK(clk), .RN(rstb), .Q(\txfifo[14][6] ), 
        .QN(n1177) );
  DFFRX1 txfifo_reg136 ( .D(n322), .CK(clk), .RN(rstb), .Q(\txfifo[15][0] ), 
        .QN(n1285) );
  DFFRX1 txfifo_reg137 ( .D(n323), .CK(clk), .RN(rstb), .Q(\txfifo[15][1] ), 
        .QN(n1287) );
  DFFRX1 txfifo_reg138 ( .D(n324), .CK(clk), .RN(rstb), .Q(\txfifo[15][2] ), 
        .QN(n1289) );
  DFFRX1 txfifo_reg139 ( .D(n325), .CK(clk), .RN(rstb), .Q(\txfifo[15][3] ), 
        .QN(n1291) );
  DFFRX1 txfifo_reg140 ( .D(n326), .CK(clk), .RN(rstb), .Q(\txfifo[15][4] ), 
        .QN(n1293) );
  DFFRX1 txfifo_reg141 ( .D(n327), .CK(clk), .RN(rstb), .Q(\txfifo[15][5] ), 
        .QN(n1295) );
  DFFRX1 txfifo_reg142 ( .D(n328), .CK(clk), .RN(rstb), .Q(\txfifo[15][6] ), 
        .QN(n1297) );
  DFFRX1 txfifo_reg143 ( .D(n330), .CK(clk), .RN(rstb), .Q(\txfifo[16][0] ), 
        .QN(n1179) );
  DFFRX1 txfifo_reg144 ( .D(n331), .CK(clk), .RN(rstb), .Q(\txfifo[16][1] ), 
        .QN(n1180) );
  DFFRX1 txfifo_reg145 ( .D(n332), .CK(clk), .RN(rstb), .Q(\txfifo[16][2] ), 
        .QN(n1181) );
  DFFRX1 txfifo_reg146 ( .D(n333), .CK(clk), .RN(rstb), .Q(\txfifo[16][3] ), 
        .QN(n1182) );
  DFFRX1 txfifo_reg147 ( .D(n334), .CK(clk), .RN(rstb), .Q(\txfifo[16][4] ), 
        .QN(n1183) );
  DFFRX1 txfifo_reg148 ( .D(n335), .CK(clk), .RN(rstb), .Q(\txfifo[16][5] ), 
        .QN(n1184) );
  DFFRX1 txfifo_reg149 ( .D(n336), .CK(clk), .RN(rstb), .Q(\txfifo[16][6] ), 
        .QN(n1185) );
  DFFRX1 txfifo_reg150 ( .D(n338), .CK(clk), .RN(rstb), .Q(\txfifo[17][0] ), 
        .QN(n1299) );
  DFFRX1 txfifo_reg151 ( .D(n339), .CK(clk), .RN(rstb), .Q(\txfifo[17][1] ), 
        .QN(n1300) );
  DFFRX1 txfifo_reg152 ( .D(n340), .CK(clk), .RN(rstb), .Q(\txfifo[17][2] ), 
        .QN(n1301) );
  DFFRX1 txfifo_reg153 ( .D(n341), .CK(clk), .RN(rstb), .Q(\txfifo[17][3] ), 
        .QN(n1302) );
  DFFRX1 txfifo_reg154 ( .D(n342), .CK(clk), .RN(rstb), .Q(\txfifo[17][4] ), 
        .QN(n1303) );
  DFFRX1 txfifo_reg155 ( .D(n343), .CK(clk), .RN(rstb), .Q(\txfifo[17][5] ), 
        .QN(n1304) );
  DFFRX1 txfifo_reg156 ( .D(n344), .CK(clk), .RN(rstb), .Q(\txfifo[17][6] ), 
        .QN(n1305) );
  DFFRX1 txfifo_reg157 ( .D(n346), .CK(clk), .RN(rstb), .Q(\txfifo[18][0] ), 
        .QN(n1124) );
  DFFRX1 txfifo_reg158 ( .D(n347), .CK(clk), .RN(rstb), .Q(\txfifo[18][1] ), 
        .QN(n1125) );
  DFFRX1 txfifo_reg159 ( .D(n348), .CK(clk), .RN(rstb), .Q(\txfifo[18][2] ), 
        .QN(n1126) );
  DFFRX1 txfifo_reg160 ( .D(n349), .CK(clk), .RN(rstb), .Q(\txfifo[18][3] ), 
        .QN(n1127) );
  DFFRX1 txfifo_reg161 ( .D(n350), .CK(clk), .RN(rstb), .Q(\txfifo[18][4] ), 
        .QN(n1128) );
  DFFRX1 txfifo_reg162 ( .D(n351), .CK(clk), .RN(rstb), .Q(\txfifo[18][5] ), 
        .QN(n1129) );
  DFFRX1 txfifo_reg163 ( .D(n352), .CK(clk), .RN(rstb), .Q(\txfifo[18][6] ), 
        .QN(n1130) );
  DFFRX1 txfifo_reg164 ( .D(n354), .CK(clk), .RN(rstb), .Q(\txfifo[19][0] ), 
        .QN(n1242) );
  DFFRX1 txfifo_reg165 ( .D(n355), .CK(clk), .RN(rstb), .Q(\txfifo[19][1] ), 
        .QN(n1243) );
  DFFRX1 txfifo_reg166 ( .D(n356), .CK(clk), .RN(rstb), .Q(\txfifo[19][2] ), 
        .QN(n1244) );
  DFFRX1 txfifo_reg167 ( .D(n357), .CK(clk), .RN(rstb), .Q(\txfifo[19][3] ), 
        .QN(n1245) );
  DFFRX1 txfifo_reg168 ( .D(n358), .CK(clk), .RN(rstb), .Q(\txfifo[19][4] ), 
        .QN(n1246) );
  DFFRX1 txfifo_reg169 ( .D(n359), .CK(clk), .RN(rstb), .Q(\txfifo[19][5] ), 
        .QN(n1247) );
  DFFRX1 txfifo_reg170 ( .D(n360), .CK(clk), .RN(rstb), .Q(\txfifo[19][6] ), 
        .QN(n1248) );
  DFFRX1 txfifo_reg171 ( .D(n362), .CK(clk), .RN(rstb), .Q(\txfifo[20][0] ), 
        .QN(n1195) );
  DFFRX1 txfifo_reg172 ( .D(n363), .CK(clk), .RN(rstb), .Q(\txfifo[20][1] ), 
        .QN(n1198) );
  DFFRX1 txfifo_reg173 ( .D(n364), .CK(clk), .RN(rstb), .Q(\txfifo[20][2] ), 
        .QN(n1201) );
  DFFRX1 txfifo_reg174 ( .D(n365), .CK(clk), .RN(rstb), .Q(\txfifo[20][3] ), 
        .QN(n1204) );
  DFFRX1 txfifo_reg175 ( .D(n366), .CK(clk), .RN(rstb), .Q(\txfifo[20][4] ), 
        .QN(n1207) );
  DFFRX1 txfifo_reg176 ( .D(n367), .CK(clk), .RN(rstb), .Q(\txfifo[20][5] ), 
        .QN(n1210) );
  DFFRX1 txfifo_reg177 ( .D(n368), .CK(clk), .RN(rstb), .Q(\txfifo[20][6] ), 
        .QN(n1213) );
  DFFRX1 txfifo_reg178 ( .D(n370), .CK(clk), .RN(rstb), .Q(\txfifo[21][0] ), 
        .QN(n1315) );
  DFFRX1 txfifo_reg179 ( .D(n371), .CK(clk), .RN(rstb), .Q(\txfifo[21][1] ), 
        .QN(n1318) );
  DFFRX1 txfifo_reg180 ( .D(n372), .CK(clk), .RN(rstb), .Q(\txfifo[21][2] ), 
        .QN(n1321) );
  DFFRX1 txfifo_reg181 ( .D(n373), .CK(clk), .RN(rstb), .Q(\txfifo[21][3] ), 
        .QN(n1324) );
  DFFRX1 txfifo_reg182 ( .D(n374), .CK(clk), .RN(rstb), .Q(\txfifo[21][4] ), 
        .QN(n1327) );
  DFFRX1 txfifo_reg183 ( .D(n375), .CK(clk), .RN(rstb), .Q(\txfifo[21][5] ), 
        .QN(n1330) );
  DFFRX1 txfifo_reg184 ( .D(n376), .CK(clk), .RN(rstb), .Q(\txfifo[21][6] ), 
        .QN(n1333) );
  DFFRX1 txfifo_reg185 ( .D(n378), .CK(clk), .RN(rstb), .Q(\txfifo[22][0] ), 
        .QN(n1133) );
  DFFRX1 txfifo_reg186 ( .D(n379), .CK(clk), .RN(rstb), .Q(\txfifo[22][1] ), 
        .QN(n1136) );
  DFFRX1 txfifo_reg187 ( .D(n380), .CK(clk), .RN(rstb), .Q(\txfifo[22][2] ), 
        .QN(n1139) );
  DFFRX1 txfifo_reg188 ( .D(n381), .CK(clk), .RN(rstb), .Q(\txfifo[22][3] ), 
        .QN(n1142) );
  DFFRX1 txfifo_reg189 ( .D(n382), .CK(clk), .RN(rstb), .Q(\txfifo[22][4] ), 
        .QN(n1145) );
  DFFRX1 txfifo_reg190 ( .D(n383), .CK(clk), .RN(rstb), .Q(\txfifo[22][5] ), 
        .QN(n1148) );
  DFFRX1 txfifo_reg191 ( .D(n384), .CK(clk), .RN(rstb), .Q(\txfifo[22][6] ), 
        .QN(n1151) );
  DFFRX1 txfifo_reg192 ( .D(n386), .CK(clk), .RN(rstb), .Q(\txfifo[23][0] ), 
        .QN(n1251) );
  DFFRX1 txfifo_reg193 ( .D(n387), .CK(clk), .RN(rstb), .Q(\txfifo[23][1] ), 
        .QN(n1254) );
  DFFRX1 txfifo_reg194 ( .D(n388), .CK(clk), .RN(rstb), .Q(\txfifo[23][2] ), 
        .QN(n1257) );
  DFFRX1 txfifo_reg195 ( .D(n389), .CK(clk), .RN(rstb), .Q(\txfifo[23][3] ), 
        .QN(n1260) );
  DFFRX1 txfifo_reg196 ( .D(n390), .CK(clk), .RN(rstb), .Q(\txfifo[23][4] ), 
        .QN(n1263) );
  DFFRX1 txfifo_reg197 ( .D(n391), .CK(clk), .RN(rstb), .Q(\txfifo[23][5] ), 
        .QN(n1266) );
  DFFRX1 txfifo_reg198 ( .D(n392), .CK(clk), .RN(rstb), .Q(\txfifo[23][6] ), 
        .QN(n1269) );
  DFFRX1 txfifo_reg199 ( .D(n394), .CK(clk), .RN(rstb), .Q(\txfifo[24][0] ), 
        .QN(n1194) );
  DFFRX1 txfifo_reg200 ( .D(n395), .CK(clk), .RN(rstb), .Q(\txfifo[24][1] ), 
        .QN(n1197) );
  DFFRX1 txfifo_reg201 ( .D(n396), .CK(clk), .RN(rstb), .Q(\txfifo[24][2] ), 
        .QN(n1200) );
  DFFRX1 txfifo_reg202 ( .D(n397), .CK(clk), .RN(rstb), .Q(\txfifo[24][3] ), 
        .QN(n1203) );
  DFFRX1 txfifo_reg203 ( .D(n398), .CK(clk), .RN(rstb), .Q(\txfifo[24][4] ), 
        .QN(n1206) );
  DFFRX1 txfifo_reg204 ( .D(n399), .CK(clk), .RN(rstb), .Q(\txfifo[24][5] ), 
        .QN(n1209) );
  DFFRX1 txfifo_reg205 ( .D(n400), .CK(clk), .RN(rstb), .Q(\txfifo[24][6] ), 
        .QN(n1212) );
  DFFRX1 txfifo_reg206 ( .D(n402), .CK(clk), .RN(rstb), .Q(\txfifo[25][0] ), 
        .QN(n1314) );
  DFFRX1 txfifo_reg207 ( .D(n403), .CK(clk), .RN(rstb), .Q(\txfifo[25][1] ), 
        .QN(n1317) );
  DFFRX1 txfifo_reg208 ( .D(n404), .CK(clk), .RN(rstb), .Q(\txfifo[25][2] ), 
        .QN(n1320) );
  DFFRX1 txfifo_reg209 ( .D(n405), .CK(clk), .RN(rstb), .Q(\txfifo[25][3] ), 
        .QN(n1323) );
  DFFRX1 txfifo_reg210 ( .D(n406), .CK(clk), .RN(rstb), .Q(\txfifo[25][4] ), 
        .QN(n1326) );
  DFFRX1 txfifo_reg211 ( .D(n407), .CK(clk), .RN(rstb), .Q(\txfifo[25][5] ), 
        .QN(n1329) );
  DFFRX1 txfifo_reg212 ( .D(n408), .CK(clk), .RN(rstb), .Q(\txfifo[25][6] ), 
        .QN(n1332) );
  DFFRX1 txfifo_reg213 ( .D(n410), .CK(clk), .RN(rstb), .Q(\txfifo[26][0] ), 
        .QN(n1132) );
  DFFRX1 txfifo_reg214 ( .D(n411), .CK(clk), .RN(rstb), .Q(\txfifo[26][1] ), 
        .QN(n1135) );
  DFFRX1 txfifo_reg215 ( .D(n412), .CK(clk), .RN(rstb), .Q(\txfifo[26][2] ), 
        .QN(n1138) );
  DFFRX1 txfifo_reg216 ( .D(n413), .CK(clk), .RN(rstb), .Q(\txfifo[26][3] ), 
        .QN(n1141) );
  DFFRX1 txfifo_reg217 ( .D(n414), .CK(clk), .RN(rstb), .Q(\txfifo[26][4] ), 
        .QN(n1144) );
  DFFRX1 txfifo_reg218 ( .D(n415), .CK(clk), .RN(rstb), .Q(\txfifo[26][5] ), 
        .QN(n1147) );
  DFFRX1 txfifo_reg219 ( .D(n416), .CK(clk), .RN(rstb), .Q(\txfifo[26][6] ), 
        .QN(n1150) );
  DFFRX1 txfifo_reg220 ( .D(n418), .CK(clk), .RN(rstb), .Q(\txfifo[27][0] ), 
        .QN(n1250) );
  DFFRX1 txfifo_reg221 ( .D(n419), .CK(clk), .RN(rstb), .Q(\txfifo[27][1] ), 
        .QN(n1253) );
  DFFRX1 txfifo_reg222 ( .D(n420), .CK(clk), .RN(rstb), .Q(\txfifo[27][2] ), 
        .QN(n1256) );
  DFFRX1 txfifo_reg223 ( .D(n421), .CK(clk), .RN(rstb), .Q(\txfifo[27][3] ), 
        .QN(n1259) );
  DFFRX1 txfifo_reg224 ( .D(n422), .CK(clk), .RN(rstb), .Q(\txfifo[27][4] ), 
        .QN(n1262) );
  DFFRX1 txfifo_reg225 ( .D(n423), .CK(clk), .RN(rstb), .Q(\txfifo[27][5] ), 
        .QN(n1265) );
  DFFRX1 txfifo_reg226 ( .D(n424), .CK(clk), .RN(rstb), .Q(\txfifo[27][6] ), 
        .QN(n1268) );
  DFFRX1 current_state_reg_1_ ( .D(n1343), .CK(clk), .RN(rstb), .Q(
        current_state_1_), .QN(n1282) );
  DFFSX1 txclkcntenb_reg ( .D(N116), .CK(clk), .SN(rstb), .QN(n1226) );
  DFFRX1 current_state_reg_10_ ( .D(N128), .CK(clk), .RN(rstb), .Q(
        current_state_10_), .QN(n1114) );
  DFFRX1 shiftreg_reg_1_ ( .D(n474), .CK(clk), .RN(rstb), .QN(n1161) );
  DFFRX1 shiftreg_reg_2_ ( .D(n475), .CK(clk), .RN(rstb), .QN(n1279) );
  DFFRX1 shiftreg_reg_3_ ( .D(n476), .CK(clk), .RN(rstb), .QN(n1162) );
  DFFRX1 shiftreg_reg_4_ ( .D(n477), .CK(clk), .RN(rstb), .QN(n1280) );
  DFFRX1 shiftreg_reg_5_ ( .D(n478), .CK(clk), .RN(rstb), .QN(n1163) );
  DFFRX1 shiftreg_reg_6_ ( .D(n479), .CK(clk), .RN(rstb), .QN(n1281) );
  DFFRX1 shiftreg_reg_7_ ( .D(n480), .CK(clk), .RN(rstb), .QN(n1115) );
  DFFRX1 current_state_reg_12_ ( .D(N130), .CK(clk), .RN(rstb), .QN(n1234) );
  DFFRX1 current_state_reg_11_ ( .D(N129), .CK(clk), .RN(rstb), .QN(n1109) );
  DFFRX1 current_state_reg_3_ ( .D(N121), .CK(clk), .RN(rstb), .Q(
        current_state_3_) );
  DFFRX1 current_state_reg_4_ ( .D(N122), .CK(clk), .RN(rstb), .Q(
        current_state_4_) );
  DFFRX1 dtxclk_reg ( .D(txclk), .CK(clk), .RN(rstb), .Q(dtxclk) );
  DFFRX1 txfifo_reg227 ( .D(n450), .CK(clk), .RN(rstb), .Q(\txfifo[31][0] ) );
  DFFRX1 txfifo_reg228 ( .D(n451), .CK(clk), .RN(rstb), .Q(\txfifo[31][1] ) );
  DFFRX1 txfifo_reg229 ( .D(n452), .CK(clk), .RN(rstb), .Q(\txfifo[31][2] ) );
  DFFRX1 txfifo_reg230 ( .D(n453), .CK(clk), .RN(rstb), .Q(\txfifo[31][3] ) );
  DFFRX1 txfifo_reg231 ( .D(n454), .CK(clk), .RN(rstb), .Q(\txfifo[31][4] ) );
  DFFRX1 txfifo_reg232 ( .D(n455), .CK(clk), .RN(rstb), .Q(\txfifo[31][5] ) );
  DFFRX1 txfifo_reg233 ( .D(n456), .CK(clk), .RN(rstb), .Q(\txfifo[31][6] ) );
  DFFRX1 txfifo_reg234 ( .D(n442), .CK(clk), .RN(rstb), .Q(\txfifo[30][0] ) );
  DFFRX1 txfifo_reg235 ( .D(n443), .CK(clk), .RN(rstb), .Q(\txfifo[30][1] ) );
  DFFRX1 txfifo_reg236 ( .D(n444), .CK(clk), .RN(rstb), .Q(\txfifo[30][2] ) );
  DFFRX1 txfifo_reg237 ( .D(n445), .CK(clk), .RN(rstb), .Q(\txfifo[30][3] ) );
  DFFRX1 txfifo_reg238 ( .D(n446), .CK(clk), .RN(rstb), .Q(\txfifo[30][4] ) );
  DFFRX1 txfifo_reg239 ( .D(n447), .CK(clk), .RN(rstb), .Q(\txfifo[30][5] ) );
  DFFRX1 txfifo_reg240 ( .D(n448), .CK(clk), .RN(rstb), .Q(\txfifo[30][6] ) );
  DFFSX1 current_state_reg_0_ ( .D(N118), .CK(clk), .SN(rstb), .QN(n9) );
  DFFSX1 shiftenb_reg ( .D(N110), .CK(clk), .SN(rstb), .Q(shiftenb) );
  DFFRX1 txfifo_reg241 ( .D(n426), .CK(clk), .RN(rstb), .Q(\txfifo[28][0] ) );
  DFFRX1 txfifo_reg242 ( .D(n427), .CK(clk), .RN(rstb), .Q(\txfifo[28][1] ) );
  DFFRX1 txfifo_reg243 ( .D(n428), .CK(clk), .RN(rstb), .Q(\txfifo[28][2] ) );
  DFFRX1 txfifo_reg244 ( .D(n429), .CK(clk), .RN(rstb), .Q(\txfifo[28][3] ) );
  DFFRX1 txfifo_reg245 ( .D(n430), .CK(clk), .RN(rstb), .Q(\txfifo[28][4] ) );
  DFFRX1 txfifo_reg246 ( .D(n431), .CK(clk), .RN(rstb), .Q(\txfifo[28][5] ) );
  DFFRX1 txfifo_reg247 ( .D(n432), .CK(clk), .RN(rstb), .Q(\txfifo[28][6] ) );
  DFFRX1 txfifo_reg248 ( .D(n434), .CK(clk), .RN(rstb), .Q(\txfifo[29][0] ) );
  DFFRX1 txfifo_reg249 ( .D(n435), .CK(clk), .RN(rstb), .Q(\txfifo[29][1] ) );
  DFFRX1 txfifo_reg250 ( .D(n436), .CK(clk), .RN(rstb), .Q(\txfifo[29][2] ) );
  DFFRX1 txfifo_reg251 ( .D(n437), .CK(clk), .RN(rstb), .Q(\txfifo[29][3] ) );
  DFFRX1 txfifo_reg252 ( .D(n438), .CK(clk), .RN(rstb), .Q(\txfifo[29][4] ) );
  DFFRX1 txfifo_reg253 ( .D(n439), .CK(clk), .RN(rstb), .Q(\txfifo[29][5] ) );
  DFFRX1 txfifo_reg254 ( .D(n440), .CK(clk), .RN(rstb), .Q(\txfifo[29][6] ) );
  DFFRX1 txbusy_int_reg ( .D(N117), .CK(clk), .RN(rstb), .Q(txbusy) );
endmodule


module RxBlock_UART_FIFO_WIDTH5_0 ( baudx16clk, clk, databit, fifordb, 
        loopbacken, parity, rstb, rxd, stopbit, swrst, txd, uarten, 
        bytereceivedb, fifodata_rx, frameerror, overrunerror, parityerror, 
        rxbusy, rxfifocnt, rxfifoempty, frameerr_clear, parityerr_clear, 
        overrunerr_clear );
  input [1:0] parity;
  output [7:0] fifodata_rx;
  output [5:0] rxfifocnt;
  input baudx16clk, clk, databit, fifordb, loopbacken, rstb, rxd, stopbit,
         swrst, txd, uarten, frameerr_clear, parityerr_clear, overrunerr_clear;
  output bytereceivedb, frameerror, overrunerror, parityerror, rxbusy,
         rxfifoempty;
  wire   N70, N71, N72, N73, N74, current_state_16_, current_state_14_,
         current_state_13_, current_state_11_, current_state_10_,
         current_state_9_, current_state_8_, current_state_7_,
         current_state_6_, current_state_5_, current_state_4_,
         current_state_3_, current_state_2_, current_state_1_, fifo_wrpos_4_,
         fifo_wrpos_3_, fifo_wrpos_2_, fifo_wrpos_0_, \rxfifo[31][7] ,
         \rxfifo[31][6] , \rxfifo[31][5] , \rxfifo[31][4] , \rxfifo[31][3] ,
         \rxfifo[31][2] , \rxfifo[31][1] , \rxfifo[31][0] , \rxfifo[30][7] ,
         \rxfifo[30][6] , \rxfifo[30][5] , \rxfifo[30][4] , \rxfifo[30][3] ,
         \rxfifo[30][2] , \rxfifo[30][1] , \rxfifo[30][0] , \rxfifo[29][7] ,
         \rxfifo[29][6] , \rxfifo[29][5] , \rxfifo[29][4] , \rxfifo[29][3] ,
         \rxfifo[29][2] , \rxfifo[29][1] , \rxfifo[29][0] , \rxfifo[28][7] ,
         \rxfifo[28][6] , \rxfifo[28][5] , \rxfifo[28][4] , \rxfifo[28][3] ,
         \rxfifo[28][2] , \rxfifo[28][1] , \rxfifo[28][0] , \rxfifo[27][7] ,
         \rxfifo[27][6] , \rxfifo[27][5] , \rxfifo[27][4] , \rxfifo[27][3] ,
         \rxfifo[27][2] , \rxfifo[27][1] , \rxfifo[27][0] , \rxfifo[26][7] ,
         \rxfifo[26][6] , \rxfifo[26][5] , \rxfifo[26][4] , \rxfifo[26][3] ,
         \rxfifo[26][2] , \rxfifo[26][1] , \rxfifo[26][0] , \rxfifo[25][7] ,
         \rxfifo[25][6] , \rxfifo[25][5] , \rxfifo[25][4] , \rxfifo[25][3] ,
         \rxfifo[25][2] , \rxfifo[25][1] , \rxfifo[25][0] , \rxfifo[24][7] ,
         \rxfifo[24][6] , \rxfifo[24][5] , \rxfifo[24][4] , \rxfifo[24][3] ,
         \rxfifo[24][2] , \rxfifo[24][1] , \rxfifo[24][0] , \rxfifo[23][7] ,
         \rxfifo[23][6] , \rxfifo[23][5] , \rxfifo[23][4] , \rxfifo[23][3] ,
         \rxfifo[23][2] , \rxfifo[23][1] , \rxfifo[23][0] , \rxfifo[22][7] ,
         \rxfifo[22][6] , \rxfifo[22][5] , \rxfifo[22][4] , \rxfifo[22][3] ,
         \rxfifo[22][2] , \rxfifo[22][1] , \rxfifo[22][0] , \rxfifo[21][7] ,
         \rxfifo[21][6] , \rxfifo[21][5] , \rxfifo[21][4] , \rxfifo[21][3] ,
         \rxfifo[21][2] , \rxfifo[21][1] , \rxfifo[21][0] , \rxfifo[20][7] ,
         \rxfifo[20][6] , \rxfifo[20][5] , \rxfifo[20][4] , \rxfifo[20][3] ,
         \rxfifo[20][2] , \rxfifo[20][1] , \rxfifo[20][0] , \rxfifo[19][7] ,
         \rxfifo[19][6] , \rxfifo[19][5] , \rxfifo[19][4] , \rxfifo[19][3] ,
         \rxfifo[19][2] , \rxfifo[19][1] , \rxfifo[19][0] , \rxfifo[18][7] ,
         \rxfifo[18][6] , \rxfifo[18][5] , \rxfifo[18][4] , \rxfifo[18][3] ,
         \rxfifo[18][2] , \rxfifo[18][1] , \rxfifo[18][0] , \rxfifo[17][7] ,
         \rxfifo[17][6] , \rxfifo[17][5] , \rxfifo[17][4] , \rxfifo[17][3] ,
         \rxfifo[17][2] , \rxfifo[17][1] , \rxfifo[17][0] , \rxfifo[16][7] ,
         \rxfifo[16][6] , \rxfifo[16][5] , \rxfifo[16][4] , \rxfifo[16][3] ,
         \rxfifo[16][2] , \rxfifo[16][1] , \rxfifo[16][0] , \rxfifo[15][7] ,
         \rxfifo[15][6] , \rxfifo[15][5] , \rxfifo[15][4] , \rxfifo[15][3] ,
         \rxfifo[15][2] , \rxfifo[15][1] , \rxfifo[15][0] , \rxfifo[14][7] ,
         \rxfifo[14][6] , \rxfifo[14][5] , \rxfifo[14][4] , \rxfifo[14][3] ,
         \rxfifo[14][2] , \rxfifo[14][1] , \rxfifo[14][0] , \rxfifo[13][7] ,
         \rxfifo[13][6] , \rxfifo[13][5] , \rxfifo[13][4] , \rxfifo[13][3] ,
         \rxfifo[13][2] , \rxfifo[13][1] , \rxfifo[13][0] , \rxfifo[12][7] ,
         \rxfifo[12][6] , \rxfifo[12][5] , \rxfifo[12][4] , \rxfifo[12][3] ,
         \rxfifo[12][2] , \rxfifo[12][1] , \rxfifo[12][0] , \rxfifo[11][7] ,
         \rxfifo[11][6] , \rxfifo[11][5] , \rxfifo[11][4] , \rxfifo[11][3] ,
         \rxfifo[11][2] , \rxfifo[11][1] , \rxfifo[11][0] , \rxfifo[10][7] ,
         \rxfifo[10][6] , \rxfifo[10][5] , \rxfifo[10][4] , \rxfifo[10][3] ,
         \rxfifo[10][2] , \rxfifo[10][1] , \rxfifo[10][0] , \rxfifo[9][7] ,
         \rxfifo[9][6] , \rxfifo[9][5] , \rxfifo[9][4] , \rxfifo[9][3] ,
         \rxfifo[9][2] , \rxfifo[9][1] , \rxfifo[9][0] , \rxfifo[8][7] ,
         \rxfifo[8][6] , \rxfifo[8][5] , \rxfifo[8][4] , \rxfifo[8][3] ,
         \rxfifo[8][2] , \rxfifo[8][1] , \rxfifo[8][0] , \rxfifo[7][7] ,
         \rxfifo[7][6] , \rxfifo[7][5] , \rxfifo[7][4] , \rxfifo[7][3] ,
         \rxfifo[7][2] , \rxfifo[7][1] , \rxfifo[7][0] , \rxfifo[6][7] ,
         \rxfifo[6][6] , \rxfifo[6][5] , \rxfifo[6][4] , \rxfifo[6][3] ,
         \rxfifo[6][2] , \rxfifo[6][1] , \rxfifo[6][0] , \rxfifo[5][7] ,
         \rxfifo[5][6] , \rxfifo[5][5] , \rxfifo[5][4] , \rxfifo[5][3] ,
         \rxfifo[5][2] , \rxfifo[5][1] , \rxfifo[5][0] , \rxfifo[4][7] ,
         \rxfifo[4][6] , \rxfifo[4][5] , \rxfifo[4][4] , \rxfifo[4][3] ,
         \rxfifo[4][2] , \rxfifo[4][1] , \rxfifo[4][0] , \rxfifo[3][7] ,
         \rxfifo[3][6] , \rxfifo[3][5] , \rxfifo[3][4] , \rxfifo[3][3] ,
         \rxfifo[3][2] , \rxfifo[3][1] , \rxfifo[3][0] , \rxfifo[2][7] ,
         \rxfifo[2][6] , \rxfifo[2][5] , \rxfifo[2][4] , \rxfifo[2][3] ,
         \rxfifo[2][2] , \rxfifo[2][1] , \rxfifo[2][0] , \rxfifo[1][7] ,
         \rxfifo[1][6] , \rxfifo[1][5] , \rxfifo[1][4] , \rxfifo[1][3] ,
         \rxfifo[1][2] , \rxfifo[1][1] , \rxfifo[1][0] , \rxfifo[0][7] ,
         \rxfifo[0][6] , \rxfifo[0][5] , \rxfifo[0][4] , \rxfifo[0][3] ,
         \rxfifo[0][2] , \rxfifo[0][1] , \rxfifo[0][0] , rx_lpfd, rxsftenb,
         rxclk, framechkb, paritychkb, parity_int, dataphaseb, rxclkenb, N443,
         N511, N512, N513, N514, N515, N516, N517, N518, N519, N520, N521,
         N522, N523, N524, N525, N526, N527, N528, N622, N623, N624, N633,
         N634, N635, n17, n18, n276, n277, n278, n279, n280, n281, n282, n283,
         n284, n285, n286, n287, n288, n289, n290, n291, n292, n293, n294,
         n295, n296, n297, n298, n299, n300, n301, n302, n303, n304, n305,
         n306, n307, n308, n309, n310, n311, n312, n313, n314, n315, n316,
         n317, n318, n319, n320, n321, n322, n323, n324, n325, n326, n327,
         n328, n329, n330, n331, n332, n333, n334, n335, n336, n337, n338,
         n339, n340, n341, n342, n343, n344, n345, n346, n347, n348, n349,
         n350, n351, n352, n353, n354, n355, n356, n357, n358, n359, n360,
         n361, n362, n363, n364, n365, n366, n367, n368, n369, n370, n371,
         n372, n373, n374, n375, n376, n377, n378, n379, n380, n381, n382,
         n383, n384, n385, n386, n387, n388, n389, n390, n391, n392, n393,
         n394, n395, n396, n397, n398, n399, n400, n401, n402, n403, n404,
         n405, n406, n407, n408, n409, n410, n411, n412, n413, n414, n415,
         n416, n417, n418, n419, n420, n421, n422, n423, n424, n425, n426,
         n427, n428, n429, n430, n431, n432, n433, n434, n435, n436, n437,
         n438, n439, n440, n441, n442, n4430, n444, n445, n446, n447, n448,
         n449, n450, n451, n452, n453, n454, n455, n456, n457, n458, n459,
         n460, n461, n462, n463, n464, n465, n466, n467, n468, n469, n470,
         n471, n472, n473, n474, n475, n476, n477, n478, n479, n480, n481,
         n482, n483, n484, n485, n486, n487, n488, n489, n490, n491, n492,
         n493, n494, n495, n496, n497, n498, n499, n500, n501, n502, n503,
         n504, n505, n506, n507, n508, n509, n510, n5110, n5120, n5130, n5140,
         n5150, n5160, n5170, n5180, n5190, n5200, n5210, n5220, n5230, n5240,
         n5250, n5260, n5270, n5280, n529, n530, n531, n532, n533, n534, n535,
         n536, n537, n538, n539, n540, n541, n542, n543, n544, n545, n546,
         n547, n548, n549, n550, n551, n552, n553, n554, n555, n556, n557,
         n558, n559, n560, n561, n562, n563, n564, n565, n566, n567, n568,
         n569, n570, n571, n572, n573, n574, n575, n576, n578, carry_4_, carry,
         carry0, carry_1_, n5, n6, n7, carry1, carry2, n11, n2100, n3100,
         carry_3_, carry_2_, n1, n2, n3, n617, n618, n619, n621, n6220, n6230,
         n6240, n625, n626, n628, n630, n631, n632, n6330, n6340, n6350, n637,
         n638, n639, n640, n641, n642, n643, n644, n645, n647, n648, n650,
         n651, n652, n653, n654, n655, n656, n657, n658, n659, n660, n661,
         n663, n664, n665, n667, n668, n669, n671, n672, n673, n675, n676,
         n677, n679, n680, n681, n683, n684, n685, n687, n688, n689, n690,
         n691, n692, n693, n694, n695, n696, n697, n698, n699, n700, n701,
         n702, n703, n704, n705, n707, n708, n709, n710, n711, n712, n713,
         n714, n715, n716, n717, n718, n719, n720, n721, n722, n723, n724,
         n725, n726, n727, n728, n730, n731, n732, n733, n734, n735, n736,
         n737, n738, n739, n740, n741, n742, n743, n744, n746, n748, n749,
         n750, n751, n752, n753, n754, n755, n756, n760, n761, n766, n767,
         n768, n769, n770, n771, n773, n774, n775, n776, n777, n778, n779,
         n780, n781, n783, n784, n785, n786, n788, n789, n790, n791, n792,
         n793, n796, n797, n798, n800, n801, n803, n804, n807, n808, n809,
         n810, n811, n812, n813, n814, n815, n817, n819, n820, n821, n822,
         n824, n825, n826, n827, n830, n831, n832, n833, n834, n835, n836,
         n838, n839, n840, n841, n842, n843, n848, n849, n850, n851, n852,
         n853, n854, n855, n858, n859, n863, n865, n866, n867, n868, n869,
         n872, n873, n874, n875, n876, n877, n879, n881, n882, n884, n886,
         n888, n890, n891, n893, n895, n897, n899, n900, n902, n904, n906,
         n908, n909, n911, n913, n914, n915, n916, n917, n920, n925, n930,
         n935, n938, n939, n940, n941, n942, n943, n946, n951, n956, n961,
         n964, n965, n966, n967, n970, n975, n980, n985, n988, n989, n990,
         n991, n992, n993, n996, n1001, n1006, n1011, n1014, n1015, n1016,
         n1017, n1020, n1025, n1030, n1035, n1038, n1039, n1040, n1041, n1042,
         n1043, n1046, n1051, n1056, n1061, n1064, n1065, n1066, n1067, n1070,
         n1075, n1080, n1085, n1088, n1089, n1090, n1091, n1092, n1093, n1096,
         n1101, n1106, n1111, n1114, n1115, n1116, n1117, n1120, n1125, n1130,
         n1135, n1138, n1139, n1140, n1141, n1142, n1143, n1146, n1151, n1156,
         n1161, n1164, n1165, n1166, n1167, n1170, n1175, n1180, n1185, n1188,
         n1189, n1190, n1191, n1192, n1193, n1196, n1201, n1206, n1211, n1214,
         n1215, n1216, n1217, n1220, n1225, n1230, n1235, n1238, n1239, n1240,
         n1241, n1242, n1243, n1246, n1251, n1256, n1261, n1264, n1265, n1266,
         n1267, n1270, n1273, n1274, n1275, n1276, n1277, n1278, n1281, n1284,
         n1290, n1294, n1298, n1301, n1302, n1303, n1305, n1307, n1308, n1310,
         n1311, n1314, n1315, n1323, n1324, n1325, n1326, n1329, n1330, n1331,
         n1332, n1333, n1334, n1335, n1336, n1337, n1338, n1339, n1340, n1341,
         n1342, n1343, n1344, n1345, n1346, n1347, n1348, n1349, n1350, n1351,
         n1352, n1353, n1354, n1355, n1356, n1357, n1358, n1359, n1360, n1361,
         n1362, n1363, n1364, n1365, n1366, n1367, n1368, n1369, n1370, n1371,
         n1372, n1373, n1374, n1375, n1376, n1377, n1378, n1379, n1380, n1381,
         n1382, n1383, n1384, n1385, n1386, n1387, n1388, n1389, n1390, n1391,
         n1392, n1393, n1394, n1395, n1396, n1397, n1398, n1399, n1400, n1401,
         n1402, n1403, n1404, n1405, n1406, n1407, n1408, n1409, n1410, n1411,
         n1412, n1413, n1414, n1415, n1416, n1417, n1418, n1419, n1420, n1421,
         n1422, n1423, n1424, n1425, n1426, n1427, n1428, n1429, n1430, n1431,
         n1432, n1433, n1434, n1435, n1436, n1437, n1438, n1439, n1440, n1441,
         n1442, n1443, n1444, n1445, n1446, n1447, n1448, n1449, n1450, n1451,
         n1452, n1453, n1454, n1455, n1456, n1457, n1458, n1459, n1460, n1461,
         n1462, n1463, n1464, n1465, n1466, n1467, n1468, n1469, n1470, n1471,
         n1472, n1473, n1474, n1475, n1476, n1477, n1478, n1479, n1480, n1481,
         n1482, n1483, n1484, n1485, n1486, n1487, n1488, n1489, n1490, n1491,
         n1492, n1493, n1494, n1495, n1496, n1497, n1498, n1499, n1500, n1501,
         n1502, n1503, n1504, n1505, n1506, n1507, n1508, n1509, n1510, n1511,
         n1512, n1513, n1514, n1515, n1516, n1517, n1518, n1519, n1520, n1521,
         n1522, n1523, n1524, n1525, n1526, n1527, n1528, n1529, n1530, n1531,
         n1532, n1533, n1534, n1535, n1536, n1537, n1538, n1539, n1540, n1541,
         n1542, n1543, n1544, n1545, n1546, n1547, n1548, n1549, n1550, n1551,
         n1552, n1553, n1554, n1555, n1556, n1557, n1558, n1559, n1560, n1561,
         n1562, n1563, n1564, n1565, n1566, n1567, n1568, n1569, n1570, n1571,
         n1572, n1573, n1574, n1575, n1576, n1577, n1578, n1579, n1580, n1581,
         n1582, n1583, n1584, n1585, n1586, n1587, n1588, n1589, n1590, n1591,
         n1592, n1593, n1594, n1595, n1596, n1597, n1598, n1599, n1600, n1601,
         n1602, n1603, n1604, n1605, n1606, n1607, n1608, n1609, n1610, n1611,
         n1612, n1613, n1614, n1615, n1616, n1617, n1618, n1619, n1620, n1621,
         n1622, n1623, n1624, n1625, n1626, n1627, n1628, n1629, n1630, n1631,
         n1632, n1633, n1634, n1635, n1636, n1637, n1638, n1639, n1640, n1641,
         n1642, n1643, n1644, n1645, n1646, n1647;
  wire   [7:0] rxsftreg;
  wire   [5:0] in_dly;
  wire   [3:0] rxclkcnt;

  AHHCONX2 U1_1_11 ( .A(n1647), .CI(n1646), .S(N622), .CON(n3100) );
  AHHCONX2 U1_1_21 ( .A(fifo_wrpos_2_), .CI(carry2), .S(N623), .CON(n2100) );
  AHHCONX2 U1_1_31 ( .A(fifo_wrpos_3_), .CI(carry1), .S(N624), .CON(n11) );
  AHHCONX2 U1_1_1 ( .A(N71), .CI(N70), .S(N633), .CON(n3) );
  AHHCONX2 U1_1_2 ( .A(N72), .CI(carry_2_), .S(N634), .CON(n2) );
  AHHCONX2 U1_1_3 ( .A(N73), .CI(carry_3_), .S(N635), .CON(n1) );
  INVX1 U1684 ( .A(databit), .Y(n746) );
  INVX1 U1685 ( .A(n813), .Y(n808) );
  NAND3BX1 U1686 ( .AN(n822), .B(n843), .C(n1618), .Y(n834) );
  OA22X1 U1687 ( .A0(n827), .A1(n835), .B0(n826), .B1(n850), .Y(n843) );
  NAND2BX1 U1688 ( .AN(n834), .B(n830), .Y(n813) );
  AO22X1 U1689 ( .A0(n840), .A1(n849), .B0(n853), .B1(n854), .Y(n822) );
  INVX1 U1690 ( .A(n849), .Y(n838) );
  INVX1 U1691 ( .A(n835), .Y(n836) );
  AND2X2 U1692 ( .A(n831), .B(n821), .Y(n1618) );
  INVX1 U1693 ( .A(n850), .Y(n853) );
  INVX1 U1694 ( .A(n825), .Y(n820) );
  NAND3BX1 U1695 ( .AN(n817), .B(n826), .C(n827), .Y(n825) );
  INVX1 U1696 ( .A(n817), .Y(n807) );
  INVX1 U1697 ( .A(rxfifocnt[0]), .Y(n642) );
  INVX1 U1698 ( .A(n733), .Y(n734) );
  INVX1 U1699 ( .A(n730), .Y(n731) );
  INVX1 U1700 ( .A(n713), .Y(n714) );
  INVX1 U1701 ( .A(n710), .Y(n711) );
  INVX1 U1702 ( .A(n694), .Y(n695) );
  INVX1 U1703 ( .A(n691), .Y(n692) );
  INVX1 U1704 ( .A(n735), .Y(n736) );
  INVX1 U1705 ( .A(n715), .Y(n716) );
  INVX1 U1706 ( .A(n696), .Y(n697) );
  INVX1 U1707 ( .A(n743), .Y(n744) );
  INVX1 U1708 ( .A(n741), .Y(n742) );
  INVX1 U1709 ( .A(n739), .Y(n740) );
  INVX1 U1710 ( .A(n737), .Y(n738) );
  INVX1 U1711 ( .A(n723), .Y(n724) );
  INVX1 U1712 ( .A(n721), .Y(n722) );
  INVX1 U1713 ( .A(n719), .Y(n720) );
  INVX1 U1714 ( .A(n717), .Y(n718) );
  INVX1 U1715 ( .A(n704), .Y(n705) );
  INVX1 U1716 ( .A(n702), .Y(n703) );
  INVX1 U1717 ( .A(n700), .Y(n701) );
  INVX1 U1718 ( .A(n698), .Y(n699) );
  INVX1 U1719 ( .A(n725), .Y(n726) );
  INVX1 U1720 ( .A(n707), .Y(n708) );
  INVX1 U1721 ( .A(n688), .Y(n689) );
  INVX1 U1722 ( .A(n684), .Y(n685) );
  INVX1 U1723 ( .A(n680), .Y(n681) );
  INVX1 U1724 ( .A(n676), .Y(n677) );
  INVX1 U1725 ( .A(n672), .Y(n673) );
  INVX1 U1726 ( .A(n668), .Y(n669) );
  INVX1 U1727 ( .A(n664), .Y(n665) );
  INVX1 U1728 ( .A(n660), .Y(n661) );
  INVX1 U1729 ( .A(n648), .Y(n650) );
  INVX1 U1730 ( .A(fifordb), .Y(n638) );
  OAI222X1 U1731 ( .A0(n760), .A1(n1481), .B0(n760), .B1(n1338), .C0(n1481), 
        .C1(n1338), .Y(n754) );
  INVX1 U1732 ( .A(n6330), .Y(n6350) );
  INVX1 U1733 ( .A(n749), .Y(n760) );
  AFHCONX2 U2_1 ( .A(n1647), .B(n1473), .CI(carry_1_), .S(rxfifocnt[1]), .CON(
        n7) );
  DFFRX1 rxclk_reg ( .D(N443), .CK(clk), .RN(rstb), .Q(rxclk), .QN(n1329) );
  NAND4BX1 U1734 ( .AN(n639), .B(n640), .C(n641), .D(n642), .Y(n617) );
  INVX1 U1735 ( .A(rxfifocnt[1]), .Y(n641) );
  INVX1 U1736 ( .A(rxfifocnt[2]), .Y(n640) );
  NAND3BX1 U1737 ( .AN(rxfifocnt[3]), .B(n643), .C(n1475), .Y(n639) );
  NAND4BX1 U1738 ( .AN(n1480), .B(n838), .C(n839), .D(n840), .Y(n830) );
  NOR2BX1 U1739 ( .AN(n841), .B(n842), .Y(n839) );
  NAND3BX1 U1740 ( .AN(n855), .B(n1330), .C(n1476), .Y(n849) );
  NAND3BX1 U1741 ( .AN(n841), .B(n838), .C(n840), .Y(n831) );
  NAND3X1 U1742 ( .A(n830), .B(n6220), .C(n810), .Y(n815) );
  NAND2BX1 U1743 ( .AN(n811), .B(n810), .Y(n835) );
  NAND3BX1 U1744 ( .AN(n869), .B(n1624), .C(n1623), .Y(n812) );
  INVX1 U1745 ( .A(n865), .Y(n810) );
  NAND3BX1 U1746 ( .AN(n866), .B(n867), .C(n868), .Y(n865) );
  INVX1 U1747 ( .A(n812), .Y(n868) );
  NAND2BX1 U1748 ( .AN(n863), .B(n1625), .Y(n854) );
  NAND2BX1 U1749 ( .AN(n852), .B(n836), .Y(n850) );
  NAND4X1 U1750 ( .A(n842), .B(n841), .C(n838), .D(n840), .Y(n821) );
  INVX1 U1751 ( .A(rxfifocnt[4]), .Y(n643) );
  INVX1 U1752 ( .A(n858), .Y(n840) );
  NAND3BX1 U1753 ( .AN(n851), .B(n859), .C(n853), .Y(n858) );
  INVX1 U1754 ( .A(n854), .Y(n859) );
  INVX1 U1755 ( .A(n804), .Y(n814) );
  OR2X1 U1756 ( .A(n811), .B(n815), .Y(n817) );
  OAI211X1 U1757 ( .A0(n1339), .A1(n804), .B0(n808), .C0(n809), .Y(n285) );
  AOI211X1 U1758 ( .A0(n810), .A1(n811), .B0(n812), .C0(N511), .Y(n809) );
  OAI211X1 U1759 ( .A0(n804), .A1(n1335), .B0(n832), .C0(n833), .Y(n279) );
  NOR2BX1 U1760 ( .AN(n6220), .B(n835), .Y(n832) );
  INVX1 U1761 ( .A(n834), .Y(n833) );
  INVX1 U1762 ( .A(n1326), .Y(n867) );
  INVX1 U1763 ( .A(uarten), .Y(n1323) );
  OAI2BB1X1 U1764 ( .A0N(n1646), .A1N(n1477), .B0(carry_1_), .Y(rxfifocnt[0])
         );
  AO21X1 U1765 ( .A0(n1340), .A1(n1333), .B0(n797), .Y(n800) );
  AO21X1 U1766 ( .A0(n1482), .A1(n1333), .B0(n800), .Y(n789) );
  INVX1 U1767 ( .A(n852), .Y(n827) );
  INVX1 U1768 ( .A(n770), .Y(n779) );
  INVX1 U1769 ( .A(n1308), .Y(n780) );
  INVX1 U1770 ( .A(n851), .Y(n826) );
  INVX1 U1771 ( .A(n791), .Y(n797) );
  INVX1 U1772 ( .A(n781), .Y(n778) );
  NAND2BX1 U1773 ( .AN(n727), .B(n659), .Y(n725) );
  NAND2BX1 U1774 ( .AN(n709), .B(n659), .Y(n707) );
  NAND2BX1 U1775 ( .AN(n690), .B(n659), .Y(n688) );
  OR2X1 U1776 ( .A(n658), .B(n687), .Y(n684) );
  OR2X1 U1777 ( .A(n658), .B(n683), .Y(n680) );
  OR2X1 U1778 ( .A(n658), .B(n679), .Y(n676) );
  OR2X1 U1779 ( .A(n658), .B(n675), .Y(n672) );
  OR2X1 U1780 ( .A(n658), .B(n663), .Y(n660) );
  NAND2BX1 U1781 ( .AN(n658), .B(n659), .Y(n648) );
  NAND2BX1 U1782 ( .AN(n687), .B(n732), .Y(n743) );
  NAND2BX1 U1783 ( .AN(n683), .B(n732), .Y(n741) );
  NAND2BX1 U1784 ( .AN(n679), .B(n732), .Y(n739) );
  NAND2BX1 U1785 ( .AN(n675), .B(n732), .Y(n737) );
  NAND2BX1 U1786 ( .AN(n671), .B(n732), .Y(n735) );
  NAND2BX1 U1787 ( .AN(n667), .B(n732), .Y(n733) );
  NAND2BX1 U1788 ( .AN(n663), .B(n732), .Y(n730) );
  NAND2BX1 U1789 ( .AN(n687), .B(n712), .Y(n723) );
  NAND2BX1 U1790 ( .AN(n683), .B(n712), .Y(n721) );
  NAND2BX1 U1791 ( .AN(n679), .B(n712), .Y(n719) );
  NAND2BX1 U1792 ( .AN(n675), .B(n712), .Y(n717) );
  NAND2BX1 U1793 ( .AN(n671), .B(n712), .Y(n715) );
  NAND2BX1 U1794 ( .AN(n667), .B(n712), .Y(n713) );
  NAND2BX1 U1795 ( .AN(n663), .B(n712), .Y(n710) );
  NAND2BX1 U1796 ( .AN(n687), .B(n693), .Y(n704) );
  NAND2BX1 U1797 ( .AN(n683), .B(n693), .Y(n702) );
  NAND2BX1 U1798 ( .AN(n679), .B(n693), .Y(n700) );
  NAND2BX1 U1799 ( .AN(n675), .B(n693), .Y(n698) );
  NAND2BX1 U1800 ( .AN(n671), .B(n693), .Y(n696) );
  NAND2BX1 U1801 ( .AN(n667), .B(n693), .Y(n694) );
  NAND2BX1 U1802 ( .AN(n663), .B(n693), .Y(n691) );
  INVX1 U1803 ( .A(n709), .Y(n712) );
  INVX1 U1804 ( .A(n690), .Y(n693) );
  INVX1 U1805 ( .A(n727), .Y(n732) );
  INVX1 U1806 ( .A(n767), .Y(n768) );
  INVX1 U1807 ( .A(n625), .Y(n628) );
  NOR2BX1 U1808 ( .AN(n6220), .B(n848), .Y(N527) );
  NOR2BX1 U1809 ( .AN(n6220), .B(n841), .Y(N525) );
  NOR2BX1 U1810 ( .AN(n6220), .B(n1625), .Y(N521) );
  AND2X2 U1811 ( .A(n6220), .B(n811), .Y(N516) );
  AND2X2 U1812 ( .A(n6220), .B(n866), .Y(N515) );
  NOR2BX1 U1813 ( .AN(n6220), .B(n1623), .Y(N514) );
  NOR2BX1 U1814 ( .AN(n6220), .B(n1624), .Y(N513) );
  OR2X1 U1815 ( .A(n658), .B(n667), .Y(n664) );
  OR2X1 U1816 ( .A(n658), .B(n671), .Y(n668) );
  INVX1 U1817 ( .A(n796), .Y(n793) );
  OAI32X1 U1818 ( .A0(n770), .A1(n746), .A2(n1476), .B0(n1330), .B1(n1308), 
        .Y(N523) );
  NAND2BX1 U1819 ( .AN(n1273), .B(n1630), .Y(n904) );
  NAND2BX1 U1820 ( .AN(n1273), .B(n1274), .Y(n886) );
  OR2X1 U1821 ( .A(n1284), .B(n1273), .Y(n895) );
  NAND2BX1 U1822 ( .AN(n1273), .B(n1301), .Y(n913) );
  NAND2BX1 U1823 ( .AN(n1275), .B(n1630), .Y(n902) );
  NAND2BX1 U1824 ( .AN(n1275), .B(n1274), .Y(n884) );
  OR2X1 U1825 ( .A(n1275), .B(n1284), .Y(n893) );
  NAND2BX1 U1826 ( .AN(n1275), .B(n1301), .Y(n911) );
  OR2X1 U1827 ( .A(n1284), .B(n1278), .Y(n888) );
  NAND2BX1 U1828 ( .AN(n1278), .B(n1630), .Y(n897) );
  NAND2BX1 U1829 ( .AN(n1278), .B(n1274), .Y(n879) );
  NAND2BX1 U1830 ( .AN(n1278), .B(n1301), .Y(n906) );
  NAND2BX1 U1831 ( .AN(n1276), .B(n1277), .Y(n881) );
  NAND2BX1 U1832 ( .AN(n1284), .B(n1277), .Y(n890) );
  NAND2BX1 U1833 ( .AN(n1302), .B(n1277), .Y(n908) );
  NAND2BX1 U1834 ( .AN(n1294), .B(n1630), .Y(n899) );
  OR4X1 U1835 ( .A(n1214), .B(n1215), .C(n1216), .D(n1217), .Y(n1188) );
  OAI221X1 U1836 ( .A0(n1492), .A1(n906), .B0(n1345), .B1(n908), .C0(n1235), 
        .Y(n1214) );
  OAI221X1 U1837 ( .A0(n1491), .A1(n888), .B0(n1344), .B1(n890), .C0(n1225), 
        .Y(n1216) );
  OAI221X1 U1838 ( .A0(n1490), .A1(n879), .B0(n1343), .B1(n881), .C0(n1220), 
        .Y(n1217) );
  OR4X1 U1839 ( .A(n1164), .B(n1165), .C(n1166), .D(n1167), .Y(n1138) );
  OAI221X1 U1840 ( .A0(n1495), .A1(n906), .B0(n1348), .B1(n908), .C0(n1185), 
        .Y(n1164) );
  OAI221X1 U1841 ( .A0(n1494), .A1(n888), .B0(n1347), .B1(n890), .C0(n1175), 
        .Y(n1166) );
  OAI221X1 U1842 ( .A0(n1493), .A1(n879), .B0(n1346), .B1(n881), .C0(n1170), 
        .Y(n1167) );
  OR4X1 U1843 ( .A(n1114), .B(n1115), .C(n1116), .D(n1117), .Y(n1088) );
  OAI221X1 U1844 ( .A0(n1498), .A1(n906), .B0(n1351), .B1(n908), .C0(n1135), 
        .Y(n1114) );
  OAI221X1 U1845 ( .A0(n1497), .A1(n888), .B0(n1350), .B1(n890), .C0(n1125), 
        .Y(n1116) );
  OAI221X1 U1846 ( .A0(n1496), .A1(n879), .B0(n1349), .B1(n881), .C0(n1120), 
        .Y(n1117) );
  OR4X1 U1847 ( .A(n1064), .B(n1065), .C(n1066), .D(n1067), .Y(n1038) );
  OAI221X1 U1848 ( .A0(n1501), .A1(n906), .B0(n1354), .B1(n908), .C0(n1085), 
        .Y(n1064) );
  OAI221X1 U1849 ( .A0(n1500), .A1(n888), .B0(n1353), .B1(n890), .C0(n1075), 
        .Y(n1066) );
  OAI221X1 U1850 ( .A0(n1499), .A1(n879), .B0(n1352), .B1(n881), .C0(n1070), 
        .Y(n1067) );
  OR4X1 U1851 ( .A(n1014), .B(n1015), .C(n1016), .D(n1017), .Y(n988) );
  OAI221X1 U1852 ( .A0(n1504), .A1(n906), .B0(n1357), .B1(n908), .C0(n1035), 
        .Y(n1014) );
  OAI221X1 U1853 ( .A0(n1503), .A1(n888), .B0(n1356), .B1(n890), .C0(n1025), 
        .Y(n1016) );
  OAI221X1 U1854 ( .A0(n1502), .A1(n879), .B0(n1355), .B1(n881), .C0(n1020), 
        .Y(n1017) );
  OR4X1 U1855 ( .A(n964), .B(n965), .C(n966), .D(n967), .Y(n938) );
  OAI221X1 U1856 ( .A0(n1507), .A1(n906), .B0(n1360), .B1(n908), .C0(n985), 
        .Y(n964) );
  OAI221X1 U1857 ( .A0(n1506), .A1(n888), .B0(n1359), .B1(n890), .C0(n975), 
        .Y(n966) );
  OAI221X1 U1858 ( .A0(n1505), .A1(n879), .B0(n1358), .B1(n881), .C0(n970), 
        .Y(n967) );
  OR4X1 U1859 ( .A(n1190), .B(n1191), .C(n1192), .D(n1193), .Y(n1189) );
  OAI221X1 U1860 ( .A0(n1510), .A1(n906), .B0(n1363), .B1(n908), .C0(n1211), 
        .Y(n1190) );
  OAI221X1 U1861 ( .A0(n1509), .A1(n888), .B0(n1362), .B1(n890), .C0(n1201), 
        .Y(n1192) );
  OAI221X1 U1862 ( .A0(n1508), .A1(n879), .B0(n1361), .B1(n881), .C0(n1196), 
        .Y(n1193) );
  OR4X1 U1863 ( .A(n1140), .B(n1141), .C(n1142), .D(n1143), .Y(n1139) );
  OAI221X1 U1864 ( .A0(n1513), .A1(n906), .B0(n1366), .B1(n908), .C0(n1161), 
        .Y(n1140) );
  OAI221X1 U1865 ( .A0(n1512), .A1(n888), .B0(n1365), .B1(n890), .C0(n1151), 
        .Y(n1142) );
  OAI221X1 U1866 ( .A0(n1511), .A1(n879), .B0(n1364), .B1(n881), .C0(n1146), 
        .Y(n1143) );
  OR4X1 U1867 ( .A(n990), .B(n991), .C(n992), .D(n993), .Y(n989) );
  OAI221X1 U1868 ( .A0(n1516), .A1(n906), .B0(n1369), .B1(n908), .C0(n1011), 
        .Y(n990) );
  OAI221X1 U1869 ( .A0(n1515), .A1(n888), .B0(n1368), .B1(n890), .C0(n1001), 
        .Y(n992) );
  OAI221X1 U1870 ( .A0(n1514), .A1(n879), .B0(n1367), .B1(n881), .C0(n996), 
        .Y(n993) );
  INVX1 U1871 ( .A(n1294), .Y(n1277) );
  INVX1 U1872 ( .A(n1276), .Y(n1274) );
  INVX1 U1873 ( .A(n1302), .Y(n1301) );
  NAND3BX1 U1874 ( .AN(swrst), .B(n638), .C(n617), .Y(n6330) );
  AO22X1 U1875 ( .A0(txd), .A1(loopbacken), .B0(rxd), .B1(n766), .Y(n749) );
  INVX1 U1876 ( .A(loopbacken), .Y(n766) );
  NOR2BX1 U1877 ( .AN(n644), .B(swrst), .Y(n565) );
  OAI222X1 U1878 ( .A0(bytereceivedb), .A1(n1475), .B0(n1475), .B1(n638), .C0(
        n645), .C1(n642), .Y(n644) );
  NAND4BX1 U1879 ( .AN(n647), .B(rxfifocnt[2]), .C(rxfifocnt[4]), .D(
        rxfifocnt[3]), .Y(n645) );
  NAND3BX1 U1880 ( .AN(bytereceivedb), .B(rxfifocnt[1]), .C(fifordb), .Y(n647)
         );
  AO22X1 U1881 ( .A0(in_dly[0]), .A1(n748), .B0(baudx16clk), .B1(n749), .Y(
        n303) );
  OAI33X1 U1882 ( .A0(n749), .A1(in_dly[1]), .A2(n1338), .B0(n749), .B1(
        in_dly[0]), .B2(n1481), .Y(n756) );
  OAI2BB1X1 U1883 ( .A0N(n750), .A1N(n751), .B0(n752), .Y(n302) );
  OA21X2 U1884 ( .A0(n754), .A1(n753), .B0(baudx16clk), .Y(n750) );
  AOI32X1 U1885 ( .A0(baudx16clk), .A1(n753), .A2(n754), .B0(rx_lpfd), .B1(
        n748), .Y(n752) );
  OA22X1 U1886 ( .A0(n755), .A1(n756), .B0(in_dly[5]), .B1(n1626), .Y(n751) );
  AO22X1 U1887 ( .A0(n6350), .A1(n1477), .B0(n631), .B1(N70), .Y(n566) );
  AO22X1 U1888 ( .A0(N634), .A1(n6350), .B0(n631), .B1(N72), .Y(n568) );
  AO22X1 U1889 ( .A0(N633), .A1(n6350), .B0(n631), .B1(N71), .Y(n567) );
  AO22X1 U1890 ( .A0(N635), .A1(n6350), .B0(n631), .B1(N73), .Y(n569) );
  INVX1 U1891 ( .A(n637), .Y(n631) );
  NAND2BX1 U1892 ( .AN(swrst), .B(n6330), .Y(n637) );
  AO21X1 U1893 ( .A0(n631), .A1(N74), .B0(n632), .Y(n570) );
  OAI33X1 U1894 ( .A0(n6330), .A1(n1471), .A2(n6340), .B0(n6330), .B1(n1), 
        .B2(N74), .Y(n632) );
  INVX1 U1895 ( .A(n1), .Y(n6340) );
  OAI31X1 U1896 ( .A0(n760), .A1(in_dly[1]), .A2(in_dly[0]), .B0(n761), .Y(
        n755) );
  AOI32X1 U1897 ( .A0(in_dly[1]), .A1(in_dly[0]), .A2(n749), .B0(in_dly[5]), 
        .B1(n1626), .Y(n761) );
  AFHCONX2 U2_3 ( .A(fifo_wrpos_3_), .B(n1472), .CI(carry), .S(rxfifocnt[3]), 
        .CON(n5) );
  INVX1 U1898 ( .A(n6), .Y(carry) );
  AFHCONX2 U2_2 ( .A(fifo_wrpos_2_), .B(n1631), .CI(carry0), .S(rxfifocnt[2]), 
        .CON(n6) );
  INVX1 U1899 ( .A(n7), .Y(carry0) );
  XOR3X1 U2_4 ( .A(fifo_wrpos_4_), .B(n1471), .C(carry_4_), .Y(rxfifocnt[4])
         );
  INVX1 U1900 ( .A(n5), .Y(carry_4_) );
  NAND3BX1 U1901 ( .AN(swrst), .B(n836), .C(n808), .Y(n804) );
  NAND3BX1 U1902 ( .AN(n18), .B(n1620), .C(n848), .Y(n842) );
  NAND2BX1 U1903 ( .AN(n1646), .B(N70), .Y(carry_1_) );
  AO22X1 U1904 ( .A0(current_state_5_), .A1(n1329), .B0(current_state_4_), 
        .B1(n1621), .Y(n811) );
  NAND2X1 U1905 ( .A(n1619), .B(n17), .Y(n1326) );
  AO22X1 U1906 ( .A0(current_state_4_), .A1(n748), .B0(current_state_3_), .B1(
        n1621), .Y(n866) );
  AOI21X1 U1907 ( .A0(n1310), .A1(current_state_13_), .B0(current_state_14_), 
        .Y(n1620) );
  INVX1 U1908 ( .A(n617), .Y(rxfifoempty) );
  INVX1 U1909 ( .A(baudx16clk), .Y(n748) );
  BUFX2 U1910 ( .A(fifo_wrpos_0_), .Y(n1646) );
  BUFX2 U1911 ( .A(n578), .Y(n1647) );
  OAI221X1 U1912 ( .A0(n1621), .A1(n1474), .B0(n867), .B1(n1323), .C0(n1324), 
        .Y(n869) );
  OAI31X1 U1913 ( .A0(current_state_2_), .A1(current_state_4_), .A2(
        current_state_3_), .B0(n1325), .Y(n1324) );
  NOR2BX1 U1914 ( .AN(baudx16clk), .B(n1622), .Y(n1325) );
  OAI31X1 U1915 ( .A0(n1329), .A1(databit), .A2(n1476), .B0(n1315), .Y(n855)
         );
  OA22X1 U1916 ( .A0(rxclk), .A1(n1334), .B0(n1329), .B1(n1330), .Y(n1315) );
  INVX1 U1917 ( .A(parity[1]), .Y(n783) );
  AND2X2 U1918 ( .A(n1622), .B(baudx16clk), .Y(n1621) );
  AO22X1 U1919 ( .A0(n813), .A1(n6220), .B0(rxbusy), .B1(n814), .Y(n284) );
  AO21X1 U1920 ( .A0(rxclkenb), .A1(n814), .B0(n815), .Y(n283) );
  OAI211X1 U1921 ( .A0(n1488), .A1(n804), .B0(n819), .C0(n820), .Y(n281) );
  NOR2BX1 U1922 ( .AN(n821), .B(n822), .Y(n819) );
  OAI211X1 U1923 ( .A0(n804), .A1(n1485), .B0(n824), .C0(n820), .Y(n280) );
  NOR2BX1 U1924 ( .AN(n831), .B(n822), .Y(n824) );
  OAI211X1 U1925 ( .A0(n804), .A1(n1487), .B0(n1618), .C0(n807), .Y(n282) );
  OAI211X1 U1926 ( .A0(n804), .A1(n1486), .B0(n1618), .C0(n807), .Y(n286) );
  AOI22X1 U1927 ( .A0(current_state_3_), .A1(n748), .B0(current_state_2_), 
        .B1(n1621), .Y(n1623) );
  AOI22X1 U1928 ( .A0(current_state_2_), .A1(n748), .B0(current_state_1_), 
        .B1(n1621), .Y(n1624) );
  AOI22X1 U1929 ( .A0(current_state_9_), .A1(rxclk), .B0(current_state_10_), 
        .B1(n1329), .Y(n1625) );
  INVX1 U1930 ( .A(n1303), .Y(n848) );
  OAI31X1 U1931 ( .A0(n1620), .A1(stopbit), .A2(n1329), .B0(n1305), .Y(n1303)
         );
  OA22X1 U1932 ( .A0(n1329), .A1(n1337), .B0(rxclk), .B1(n1480), .Y(n1305) );
  INVX1 U1933 ( .A(n1314), .Y(n1310) );
  NAND2BX1 U1934 ( .AN(parity[0]), .B(n783), .Y(n1314) );
  INVX1 U1935 ( .A(n2100), .Y(carry1) );
  INVX1 U1936 ( .A(n2), .Y(carry_3_) );
  NAND3BX1 U1937 ( .AN(bytereceivedb), .B(n1475), .C(n6220), .Y(n625) );
  INVX1 U1938 ( .A(n3100), .Y(carry2) );
  INVX1 U1939 ( .A(n3), .Y(carry_2_) );
  NAND2BX1 U1940 ( .AN(swrst), .B(rxclk), .Y(n770) );
  OR4X1 U1941 ( .A(current_state_7_), .B(current_state_6_), .C(
        current_state_5_), .D(current_state_8_), .Y(n852) );
  NAND2BX1 U1942 ( .AN(baudx16clk), .B(n1333), .Y(n791) );
  AO22X1 U1943 ( .A0(current_state_9_), .A1(n1329), .B0(current_state_8_), 
        .B1(rxclk), .Y(n851) );
  NAND2BX1 U1944 ( .AN(swrst), .B(n1329), .Y(n1308) );
  INVX1 U1945 ( .A(swrst), .Y(n6220) );
  OAI31X1 U1946 ( .A0(n1483), .A1(parity[0]), .A2(n783), .B0(n784), .Y(n781)
         );
  OA22X1 U1947 ( .A0(parity_int), .A1(parity[1]), .B0(parity_int), .B1(n785), 
        .Y(n784) );
  INVX1 U1948 ( .A(parity[0]), .Y(n785) );
  AO22X1 U1949 ( .A0(current_state_11_), .A1(n1329), .B0(current_state_10_), 
        .B1(rxclk), .Y(n863) );
  OAI32X1 U1950 ( .A0(n774), .A1(parityerr_clear), .A2(n770), .B0(n775), .B1(
        n278), .Y(n292) );
  INVX1 U1951 ( .A(n775), .Y(n774) );
  AO21X1 U1952 ( .A0(n776), .A1(n777), .B0(parityerr_clear), .Y(n775) );
  AOI31X1 U1953 ( .A0(n778), .A1(n1622), .A2(n779), .B0(n780), .Y(n777) );
  OAI32X1 U1954 ( .A0(n769), .A1(frameerr_clear), .A2(n770), .B0(n771), .B1(
        n276), .Y(n293) );
  INVX1 U1955 ( .A(n769), .Y(n771) );
  OAI33X1 U1956 ( .A0(n770), .A1(frameerr_clear), .A2(n1622), .B0(n773), .B1(
        swrst), .B2(frameerr_clear), .Y(n769) );
  NOR2BX1 U1957 ( .AN(rxclk), .B(framechkb), .Y(n773) );
  OAI32X1 U1958 ( .A0(n796), .A1(rxclkcnt[2]), .A2(n797), .B0(n798), .B1(n1341), .Y(n289) );
  INVX1 U1959 ( .A(n789), .Y(n798) );
  AOI32X1 U1960 ( .A0(rx_lpfd), .A1(n781), .A2(n779), .B0(paritychkb), .B1(
        n6220), .Y(n776) );
  INVX1 U1961 ( .A(n1311), .Y(n841) );
  OAI32X1 U1962 ( .A0(n1329), .A1(n1310), .A2(n1334), .B0(rxclk), .B1(n1479), 
        .Y(n1311) );
  AO21X1 U1963 ( .A0(n6230), .A1(fifo_wrpos_4_), .B0(n6240), .Y(n575) );
  OAI33X1 U1964 ( .A0(n625), .A1(n626), .A2(n1484), .B0(n625), .B1(n11), .B2(
        fifo_wrpos_4_), .Y(n6240) );
  INVX1 U1965 ( .A(n11), .Y(n626) );
  XOR3X1 U1966 ( .A(n1627), .B(in_dly[3]), .C(n1331), .Y(n1626) );
  OAI32X1 U1967 ( .A0(n618), .A1(swrst), .A2(overrunerr_clear), .B0(n619), 
        .B1(n277), .Y(n576) );
  INVX1 U1968 ( .A(n619), .Y(n618) );
  OAI211X1 U1969 ( .A0(bytereceivedb), .A1(n1475), .B0(n621), .C0(n6220), .Y(
        n619) );
  INVX1 U1970 ( .A(overrunerr_clear), .Y(n621) );
  NAND2BX1 U1971 ( .AN(rxsftenb), .B(rxclk), .Y(n767) );
  NAND3BX1 U1972 ( .AN(fifo_wrpos_2_), .B(n1336), .C(n1332), .Y(n687) );
  NAND3BX1 U1973 ( .AN(fifo_wrpos_2_), .B(n1336), .C(n1646), .Y(n683) );
  NAND3BX1 U1974 ( .AN(fifo_wrpos_2_), .B(n1332), .C(n1647), .Y(n679) );
  NAND3BX1 U1975 ( .AN(fifo_wrpos_2_), .B(n1647), .C(n1646), .Y(n675) );
  NAND3BX1 U1976 ( .AN(n1647), .B(fifo_wrpos_2_), .C(n1646), .Y(n667) );
  NAND3BX1 U1977 ( .AN(n1646), .B(fifo_wrpos_2_), .C(n1647), .Y(n663) );
  NAND3BX1 U1978 ( .AN(n1647), .B(n1332), .C(fifo_wrpos_2_), .Y(n671) );
  NAND3BX1 U1979 ( .AN(fifo_wrpos_4_), .B(n1478), .C(n1335), .Y(n727) );
  NAND3BX1 U1980 ( .AN(fifo_wrpos_4_), .B(n1335), .C(fifo_wrpos_3_), .Y(n709)
         );
  NAND3BX1 U1981 ( .AN(fifo_wrpos_3_), .B(n1335), .C(fifo_wrpos_4_), .Y(n690)
         );
  OAI33X1 U1982 ( .A0(n786), .A1(n1339), .A2(n1483), .B0(n788), .B1(parity_int), .B2(n1339), .Y(n291) );
  INVX1 U1983 ( .A(n788), .Y(n786) );
  NAND3BX1 U1984 ( .AN(dataphaseb), .B(rx_lpfd), .C(rxclk), .Y(n788) );
  NAND3BX1 U1985 ( .AN(rxclkenb), .B(rxclkcnt[1]), .C(rxclkcnt[0]), .Y(n796)
         );
  NAND3BX1 U1986 ( .AN(bytereceivedb), .B(fifo_wrpos_3_), .C(fifo_wrpos_4_), 
        .Y(n658) );
  AO22X1 U1987 ( .A0(rxsftreg[0]), .A1(databit), .B0(rxsftreg[1]), .B1(n746), 
        .Y(n1633) );
  AO22X1 U1988 ( .A0(rxsftreg[1]), .A1(databit), .B0(rxsftreg[2]), .B1(n746), 
        .Y(n1635) );
  AO22X1 U1989 ( .A0(rxsftreg[2]), .A1(databit), .B0(rxsftreg[3]), .B1(n746), 
        .Y(n1637) );
  AO22X1 U1990 ( .A0(rxsftreg[3]), .A1(databit), .B0(rxsftreg[4]), .B1(n746), 
        .Y(n1639) );
  AO22X1 U1991 ( .A0(rxsftreg[4]), .A1(databit), .B0(rxsftreg[5]), .B1(n746), 
        .Y(n1641) );
  AO22X1 U1992 ( .A0(rxsftreg[5]), .A1(databit), .B0(rxsftreg[6]), .B1(n746), 
        .Y(n1643) );
  AO22X1 U1993 ( .A0(rxsftreg[6]), .A1(databit), .B0(rxsftreg[7]), .B1(n746), 
        .Y(n1645) );
  AO22X1 U1994 ( .A0(rxsftreg[0]), .A1(databit), .B0(rxsftreg[1]), .B1(n746), 
        .Y(n1632) );
  AO22X1 U1995 ( .A0(rxsftreg[1]), .A1(databit), .B0(rxsftreg[2]), .B1(n746), 
        .Y(n1634) );
  AO22X1 U1996 ( .A0(rxsftreg[2]), .A1(databit), .B0(rxsftreg[3]), .B1(n746), 
        .Y(n1636) );
  AO22X1 U1997 ( .A0(rxsftreg[3]), .A1(databit), .B0(rxsftreg[4]), .B1(n746), 
        .Y(n1638) );
  AO22X1 U1998 ( .A0(rxsftreg[4]), .A1(databit), .B0(rxsftreg[5]), .B1(n746), 
        .Y(n1640) );
  AO22X1 U1999 ( .A0(rxsftreg[5]), .A1(databit), .B0(rxsftreg[6]), .B1(n746), 
        .Y(n1642) );
  AO22X1 U2000 ( .A0(rxsftreg[6]), .A1(databit), .B0(rxsftreg[7]), .B1(n746), 
        .Y(n1644) );
  AO22X1 U2001 ( .A0(rxsftreg[0]), .A1(databit), .B0(rxsftreg[1]), .B1(n746), 
        .Y(n657) );
  AO22X1 U2002 ( .A0(rxsftreg[1]), .A1(databit), .B0(rxsftreg[2]), .B1(n746), 
        .Y(n656) );
  AO22X1 U2003 ( .A0(rxsftreg[2]), .A1(databit), .B0(rxsftreg[3]), .B1(n746), 
        .Y(n655) );
  AO22X1 U2004 ( .A0(rxsftreg[3]), .A1(databit), .B0(rxsftreg[4]), .B1(n746), 
        .Y(n654) );
  AO22X1 U2005 ( .A0(rxsftreg[4]), .A1(databit), .B0(rxsftreg[5]), .B1(n746), 
        .Y(n653) );
  AO22X1 U2006 ( .A0(rxsftreg[5]), .A1(databit), .B0(rxsftreg[6]), .B1(n746), 
        .Y(n652) );
  AO22X1 U2007 ( .A0(rxsftreg[6]), .A1(databit), .B0(rxsftreg[7]), .B1(n746), 
        .Y(n651) );
  INVX1 U2008 ( .A(n630), .Y(n6230) );
  NAND2BX1 U2009 ( .AN(swrst), .B(n625), .Y(n630) );
  NOR2BX1 U2010 ( .AN(n855), .B(swrst), .Y(N524) );
  NOR2BX1 U2011 ( .AN(n863), .B(swrst), .Y(N522) );
  NOR2BX1 U2012 ( .AN(n851), .B(swrst), .Y(N520) );
  NOR2BX1 U2013 ( .AN(n869), .B(swrst), .Y(N512) );
  NOR2X1 U2014 ( .A(n746), .B(n1629), .Y(n1628) );
  NOR2BX1 U2015 ( .AN(current_state_16_), .B(n770), .Y(N528) );
  AO21X1 U2016 ( .A0(n1326), .A1(n1323), .B0(swrst), .Y(N511) );
  INVX1 U2017 ( .A(n728), .Y(n659) );
  NAND3BX1 U2018 ( .AN(n1336), .B(fifo_wrpos_2_), .C(n1646), .Y(n728) );
  OAI222X1 U2019 ( .A0(n1627), .A1(n1331), .B0(n1342), .B1(n1331), .C0(n1627), 
        .C1(n1342), .Y(n753) );
  AO22X1 U2020 ( .A0(in_dly[0]), .A1(baudx16clk), .B0(in_dly[1]), .B1(n748), 
        .Y(n304) );
  AO22X1 U2021 ( .A0(in_dly[1]), .A1(baudx16clk), .B0(in_dly[2]), .B1(n748), 
        .Y(n305) );
  AO22X1 U2022 ( .A0(in_dly[2]), .A1(baudx16clk), .B0(in_dly[3]), .B1(n748), 
        .Y(n306) );
  AO22X1 U2023 ( .A0(in_dly[3]), .A1(baudx16clk), .B0(in_dly[4]), .B1(n748), 
        .Y(n307) );
  AO22X1 U2024 ( .A0(in_dly[4]), .A1(baudx16clk), .B0(in_dly[5]), .B1(n748), 
        .Y(n308) );
  AO22X1 U2025 ( .A0(N624), .A1(n628), .B0(fifo_wrpos_3_), .B1(n6230), .Y(n574) );
  AO22X1 U2026 ( .A0(N623), .A1(n628), .B0(fifo_wrpos_2_), .B1(n6230), .Y(n573) );
  OAI2BB1X1 U2027 ( .A0N(rxclkcnt[3]), .A1N(n789), .B0(n790), .Y(n290) );
  AOI33X1 U2028 ( .A0(n791), .A1(n792), .A2(n793), .B0(n1341), .B1(n1333), 
        .B2(rxclkcnt[3]), .Y(n790) );
  NOR2BX1 U2029 ( .AN(rxclkcnt[2]), .B(rxclkcnt[3]), .Y(n792) );
  AO22X1 U2030 ( .A0(rxsftreg[7]), .A1(n767), .B0(n768), .B1(rx_lpfd), .Y(n301) );
  AO22X1 U2031 ( .A0(N622), .A1(n628), .B0(n1647), .B1(n6230), .Y(n572) );
  AO22X1 U2032 ( .A0(n628), .A1(n1332), .B0(n6230), .B1(n1646), .Y(n571) );
  AO22X1 U2033 ( .A0(current_state_7_), .A1(n779), .B0(n780), .B1(
        current_state_8_), .Y(N519) );
  AO22X1 U2034 ( .A0(current_state_6_), .A1(n779), .B0(current_state_7_), .B1(
        n780), .Y(N518) );
  AO22X1 U2035 ( .A0(current_state_5_), .A1(n779), .B0(current_state_6_), .B1(
        n780), .Y(N517) );
  AO22X1 U2036 ( .A0(\rxfifo[31][7] ), .A1(n648), .B0(n1628), .B1(n650), .Y(
        n564) );
  AO22X1 U2037 ( .A0(\rxfifo[0][0] ), .A1(n743), .B0(n744), .B1(n1633), .Y(
        n309) );
  AO22X1 U2038 ( .A0(\rxfifo[0][1] ), .A1(n743), .B0(n744), .B1(n1635), .Y(
        n310) );
  AO22X1 U2039 ( .A0(\rxfifo[0][2] ), .A1(n743), .B0(n744), .B1(n1637), .Y(
        n311) );
  AO22X1 U2040 ( .A0(\rxfifo[0][3] ), .A1(n743), .B0(n744), .B1(n1639), .Y(
        n312) );
  AO22X1 U2041 ( .A0(\rxfifo[0][4] ), .A1(n743), .B0(n744), .B1(n1641), .Y(
        n313) );
  AO22X1 U2042 ( .A0(\rxfifo[0][5] ), .A1(n743), .B0(n744), .B1(n1643), .Y(
        n314) );
  AO22X1 U2043 ( .A0(\rxfifo[0][6] ), .A1(n743), .B0(n744), .B1(n1645), .Y(
        n315) );
  AO22X1 U2044 ( .A0(\rxfifo[0][7] ), .A1(n743), .B0(n744), .B1(n1628), .Y(
        n316) );
  AO22X1 U2045 ( .A0(\rxfifo[1][0] ), .A1(n741), .B0(n742), .B1(n1632), .Y(
        n317) );
  AO22X1 U2046 ( .A0(\rxfifo[1][1] ), .A1(n741), .B0(n742), .B1(n1634), .Y(
        n318) );
  AO22X1 U2047 ( .A0(\rxfifo[1][2] ), .A1(n741), .B0(n742), .B1(n1636), .Y(
        n319) );
  AO22X1 U2048 ( .A0(\rxfifo[1][3] ), .A1(n741), .B0(n742), .B1(n1638), .Y(
        n320) );
  AO22X1 U2049 ( .A0(\rxfifo[1][4] ), .A1(n741), .B0(n742), .B1(n1640), .Y(
        n321) );
  AO22X1 U2050 ( .A0(\rxfifo[1][5] ), .A1(n741), .B0(n742), .B1(n1642), .Y(
        n322) );
  AO22X1 U2051 ( .A0(\rxfifo[1][6] ), .A1(n741), .B0(n742), .B1(n1644), .Y(
        n323) );
  AO22X1 U2052 ( .A0(\rxfifo[1][7] ), .A1(n741), .B0(n742), .B1(n1628), .Y(
        n324) );
  AO22X1 U2053 ( .A0(\rxfifo[2][0] ), .A1(n739), .B0(n740), .B1(n657), .Y(n325) );
  AO22X1 U2054 ( .A0(\rxfifo[2][1] ), .A1(n739), .B0(n740), .B1(n656), .Y(n326) );
  AO22X1 U2055 ( .A0(\rxfifo[2][2] ), .A1(n739), .B0(n740), .B1(n655), .Y(n327) );
  AO22X1 U2056 ( .A0(\rxfifo[2][3] ), .A1(n739), .B0(n740), .B1(n654), .Y(n328) );
  AO22X1 U2057 ( .A0(\rxfifo[2][4] ), .A1(n739), .B0(n740), .B1(n653), .Y(n329) );
  AO22X1 U2058 ( .A0(\rxfifo[2][5] ), .A1(n739), .B0(n740), .B1(n652), .Y(n330) );
  AO22X1 U2059 ( .A0(\rxfifo[2][6] ), .A1(n739), .B0(n740), .B1(n651), .Y(n331) );
  AO22X1 U2060 ( .A0(\rxfifo[2][7] ), .A1(n739), .B0(n740), .B1(n1628), .Y(
        n332) );
  AO22X1 U2061 ( .A0(\rxfifo[3][0] ), .A1(n737), .B0(n738), .B1(n1633), .Y(
        n333) );
  AO22X1 U2062 ( .A0(\rxfifo[3][1] ), .A1(n737), .B0(n738), .B1(n1635), .Y(
        n334) );
  AO22X1 U2063 ( .A0(\rxfifo[3][2] ), .A1(n737), .B0(n738), .B1(n1637), .Y(
        n335) );
  AO22X1 U2064 ( .A0(\rxfifo[3][3] ), .A1(n737), .B0(n738), .B1(n1639), .Y(
        n336) );
  AO22X1 U2065 ( .A0(\rxfifo[3][4] ), .A1(n737), .B0(n738), .B1(n1641), .Y(
        n337) );
  AO22X1 U2066 ( .A0(\rxfifo[3][5] ), .A1(n737), .B0(n738), .B1(n1643), .Y(
        n338) );
  AO22X1 U2067 ( .A0(\rxfifo[3][6] ), .A1(n737), .B0(n738), .B1(n1645), .Y(
        n339) );
  AO22X1 U2068 ( .A0(\rxfifo[3][7] ), .A1(n737), .B0(n738), .B1(n1628), .Y(
        n340) );
  AO22X1 U2069 ( .A0(\rxfifo[4][0] ), .A1(n735), .B0(n736), .B1(n1632), .Y(
        n341) );
  AO22X1 U2070 ( .A0(\rxfifo[4][1] ), .A1(n735), .B0(n736), .B1(n1634), .Y(
        n342) );
  AO22X1 U2071 ( .A0(\rxfifo[4][2] ), .A1(n735), .B0(n736), .B1(n1636), .Y(
        n343) );
  AO22X1 U2072 ( .A0(\rxfifo[4][3] ), .A1(n735), .B0(n736), .B1(n1638), .Y(
        n344) );
  AO22X1 U2073 ( .A0(\rxfifo[4][4] ), .A1(n735), .B0(n736), .B1(n1640), .Y(
        n345) );
  AO22X1 U2074 ( .A0(\rxfifo[4][5] ), .A1(n735), .B0(n736), .B1(n1642), .Y(
        n346) );
  AO22X1 U2075 ( .A0(\rxfifo[4][6] ), .A1(n735), .B0(n736), .B1(n1644), .Y(
        n347) );
  AO22X1 U2076 ( .A0(\rxfifo[4][7] ), .A1(n735), .B0(n736), .B1(n1628), .Y(
        n348) );
  AO22X1 U2077 ( .A0(\rxfifo[5][0] ), .A1(n733), .B0(n734), .B1(n657), .Y(n349) );
  AO22X1 U2078 ( .A0(\rxfifo[5][1] ), .A1(n733), .B0(n734), .B1(n656), .Y(n350) );
  AO22X1 U2079 ( .A0(\rxfifo[5][2] ), .A1(n733), .B0(n734), .B1(n655), .Y(n351) );
  AO22X1 U2080 ( .A0(\rxfifo[5][3] ), .A1(n733), .B0(n734), .B1(n654), .Y(n352) );
  AO22X1 U2081 ( .A0(\rxfifo[5][4] ), .A1(n733), .B0(n734), .B1(n653), .Y(n353) );
  AO22X1 U2082 ( .A0(\rxfifo[5][5] ), .A1(n733), .B0(n734), .B1(n652), .Y(n354) );
  AO22X1 U2083 ( .A0(\rxfifo[5][6] ), .A1(n733), .B0(n734), .B1(n651), .Y(n355) );
  AO22X1 U2084 ( .A0(\rxfifo[5][7] ), .A1(n733), .B0(n734), .B1(n1628), .Y(
        n356) );
  AO22X1 U2085 ( .A0(\rxfifo[6][0] ), .A1(n730), .B0(n731), .B1(n1633), .Y(
        n357) );
  AO22X1 U2086 ( .A0(\rxfifo[6][1] ), .A1(n730), .B0(n731), .B1(n1635), .Y(
        n358) );
  AO22X1 U2087 ( .A0(\rxfifo[6][2] ), .A1(n730), .B0(n731), .B1(n1637), .Y(
        n359) );
  AO22X1 U2088 ( .A0(\rxfifo[6][3] ), .A1(n730), .B0(n731), .B1(n1639), .Y(
        n360) );
  AO22X1 U2089 ( .A0(\rxfifo[6][4] ), .A1(n730), .B0(n731), .B1(n1641), .Y(
        n361) );
  AO22X1 U2090 ( .A0(\rxfifo[6][5] ), .A1(n730), .B0(n731), .B1(n1643), .Y(
        n362) );
  AO22X1 U2091 ( .A0(\rxfifo[6][6] ), .A1(n730), .B0(n731), .B1(n1645), .Y(
        n363) );
  AO22X1 U2092 ( .A0(\rxfifo[6][7] ), .A1(n730), .B0(n731), .B1(n1628), .Y(
        n364) );
  AO22X1 U2093 ( .A0(\rxfifo[7][0] ), .A1(n725), .B0(n726), .B1(n1632), .Y(
        n365) );
  AO22X1 U2094 ( .A0(\rxfifo[7][1] ), .A1(n725), .B0(n726), .B1(n1634), .Y(
        n366) );
  AO22X1 U2095 ( .A0(\rxfifo[7][2] ), .A1(n725), .B0(n726), .B1(n1636), .Y(
        n367) );
  AO22X1 U2096 ( .A0(\rxfifo[7][3] ), .A1(n725), .B0(n726), .B1(n1638), .Y(
        n368) );
  AO22X1 U2097 ( .A0(\rxfifo[7][4] ), .A1(n725), .B0(n726), .B1(n1640), .Y(
        n369) );
  AO22X1 U2098 ( .A0(\rxfifo[7][5] ), .A1(n725), .B0(n726), .B1(n1642), .Y(
        n370) );
  AO22X1 U2099 ( .A0(\rxfifo[7][6] ), .A1(n725), .B0(n726), .B1(n1644), .Y(
        n371) );
  AO22X1 U2100 ( .A0(\rxfifo[7][7] ), .A1(n725), .B0(n726), .B1(n1628), .Y(
        n372) );
  AO22X1 U2101 ( .A0(\rxfifo[8][0] ), .A1(n723), .B0(n724), .B1(n657), .Y(n373) );
  AO22X1 U2102 ( .A0(\rxfifo[8][1] ), .A1(n723), .B0(n724), .B1(n656), .Y(n374) );
  AO22X1 U2103 ( .A0(\rxfifo[8][2] ), .A1(n723), .B0(n724), .B1(n655), .Y(n375) );
  AO22X1 U2104 ( .A0(\rxfifo[8][3] ), .A1(n723), .B0(n724), .B1(n654), .Y(n376) );
  AO22X1 U2105 ( .A0(\rxfifo[8][4] ), .A1(n723), .B0(n724), .B1(n653), .Y(n377) );
  AO22X1 U2106 ( .A0(\rxfifo[8][5] ), .A1(n723), .B0(n724), .B1(n652), .Y(n378) );
  AO22X1 U2107 ( .A0(\rxfifo[8][6] ), .A1(n723), .B0(n724), .B1(n651), .Y(n379) );
  AO22X1 U2108 ( .A0(\rxfifo[8][7] ), .A1(n723), .B0(n724), .B1(n1628), .Y(
        n380) );
  AO22X1 U2109 ( .A0(\rxfifo[9][0] ), .A1(n721), .B0(n722), .B1(n1633), .Y(
        n381) );
  AO22X1 U2110 ( .A0(\rxfifo[9][1] ), .A1(n721), .B0(n722), .B1(n1635), .Y(
        n382) );
  AO22X1 U2111 ( .A0(\rxfifo[9][2] ), .A1(n721), .B0(n722), .B1(n1637), .Y(
        n383) );
  AO22X1 U2112 ( .A0(\rxfifo[9][3] ), .A1(n721), .B0(n722), .B1(n1639), .Y(
        n384) );
  AO22X1 U2113 ( .A0(\rxfifo[9][4] ), .A1(n721), .B0(n722), .B1(n1641), .Y(
        n385) );
  AO22X1 U2114 ( .A0(\rxfifo[9][5] ), .A1(n721), .B0(n722), .B1(n1643), .Y(
        n386) );
  AO22X1 U2115 ( .A0(\rxfifo[9][6] ), .A1(n721), .B0(n722), .B1(n1645), .Y(
        n387) );
  AO22X1 U2116 ( .A0(\rxfifo[9][7] ), .A1(n721), .B0(n722), .B1(n1628), .Y(
        n388) );
  AO22X1 U2117 ( .A0(\rxfifo[10][0] ), .A1(n719), .B0(n720), .B1(n1632), .Y(
        n389) );
  AO22X1 U2118 ( .A0(\rxfifo[10][1] ), .A1(n719), .B0(n720), .B1(n1634), .Y(
        n390) );
  AO22X1 U2119 ( .A0(\rxfifo[10][2] ), .A1(n719), .B0(n720), .B1(n1636), .Y(
        n391) );
  AO22X1 U2120 ( .A0(\rxfifo[10][3] ), .A1(n719), .B0(n720), .B1(n1638), .Y(
        n392) );
  AO22X1 U2121 ( .A0(\rxfifo[10][4] ), .A1(n719), .B0(n720), .B1(n1640), .Y(
        n393) );
  AO22X1 U2122 ( .A0(\rxfifo[10][5] ), .A1(n719), .B0(n720), .B1(n1642), .Y(
        n394) );
  AO22X1 U2123 ( .A0(\rxfifo[10][6] ), .A1(n719), .B0(n720), .B1(n1644), .Y(
        n395) );
  AO22X1 U2124 ( .A0(\rxfifo[10][7] ), .A1(n719), .B0(n720), .B1(n1628), .Y(
        n396) );
  AO22X1 U2125 ( .A0(\rxfifo[11][0] ), .A1(n717), .B0(n718), .B1(n657), .Y(
        n397) );
  AO22X1 U2126 ( .A0(\rxfifo[11][1] ), .A1(n717), .B0(n718), .B1(n656), .Y(
        n398) );
  AO22X1 U2127 ( .A0(\rxfifo[11][2] ), .A1(n717), .B0(n718), .B1(n655), .Y(
        n399) );
  AO22X1 U2128 ( .A0(\rxfifo[11][3] ), .A1(n717), .B0(n718), .B1(n654), .Y(
        n400) );
  AO22X1 U2129 ( .A0(\rxfifo[11][4] ), .A1(n717), .B0(n718), .B1(n653), .Y(
        n401) );
  AO22X1 U2130 ( .A0(\rxfifo[11][5] ), .A1(n717), .B0(n718), .B1(n652), .Y(
        n402) );
  AO22X1 U2131 ( .A0(\rxfifo[11][6] ), .A1(n717), .B0(n718), .B1(n651), .Y(
        n403) );
  AO22X1 U2132 ( .A0(\rxfifo[11][7] ), .A1(n717), .B0(n718), .B1(n1628), .Y(
        n404) );
  AO22X1 U2133 ( .A0(\rxfifo[12][0] ), .A1(n715), .B0(n716), .B1(n1633), .Y(
        n405) );
  AO22X1 U2134 ( .A0(\rxfifo[12][1] ), .A1(n715), .B0(n716), .B1(n1635), .Y(
        n406) );
  AO22X1 U2135 ( .A0(\rxfifo[12][2] ), .A1(n715), .B0(n716), .B1(n1637), .Y(
        n407) );
  AO22X1 U2136 ( .A0(\rxfifo[12][3] ), .A1(n715), .B0(n716), .B1(n1639), .Y(
        n408) );
  AO22X1 U2137 ( .A0(\rxfifo[12][4] ), .A1(n715), .B0(n716), .B1(n1641), .Y(
        n409) );
  AO22X1 U2138 ( .A0(\rxfifo[12][5] ), .A1(n715), .B0(n716), .B1(n1643), .Y(
        n410) );
  AO22X1 U2139 ( .A0(\rxfifo[12][6] ), .A1(n715), .B0(n716), .B1(n1645), .Y(
        n411) );
  AO22X1 U2140 ( .A0(\rxfifo[12][7] ), .A1(n715), .B0(n716), .B1(n1628), .Y(
        n412) );
  AO22X1 U2141 ( .A0(\rxfifo[13][0] ), .A1(n713), .B0(n714), .B1(n1632), .Y(
        n413) );
  AO22X1 U2142 ( .A0(\rxfifo[13][1] ), .A1(n713), .B0(n714), .B1(n1634), .Y(
        n414) );
  AO22X1 U2143 ( .A0(\rxfifo[13][2] ), .A1(n713), .B0(n714), .B1(n1636), .Y(
        n415) );
  AO22X1 U2144 ( .A0(\rxfifo[13][3] ), .A1(n713), .B0(n714), .B1(n1638), .Y(
        n416) );
  AO22X1 U2145 ( .A0(\rxfifo[13][4] ), .A1(n713), .B0(n714), .B1(n1640), .Y(
        n417) );
  AO22X1 U2146 ( .A0(\rxfifo[13][5] ), .A1(n713), .B0(n714), .B1(n1642), .Y(
        n418) );
  AO22X1 U2147 ( .A0(\rxfifo[13][6] ), .A1(n713), .B0(n714), .B1(n1644), .Y(
        n419) );
  AO22X1 U2148 ( .A0(\rxfifo[13][7] ), .A1(n713), .B0(n714), .B1(n1628), .Y(
        n420) );
  AO22X1 U2149 ( .A0(\rxfifo[14][0] ), .A1(n710), .B0(n711), .B1(n657), .Y(
        n421) );
  AO22X1 U2150 ( .A0(\rxfifo[14][1] ), .A1(n710), .B0(n711), .B1(n656), .Y(
        n422) );
  AO22X1 U2151 ( .A0(\rxfifo[14][2] ), .A1(n710), .B0(n711), .B1(n655), .Y(
        n423) );
  AO22X1 U2152 ( .A0(\rxfifo[14][3] ), .A1(n710), .B0(n711), .B1(n654), .Y(
        n424) );
  AO22X1 U2153 ( .A0(\rxfifo[14][4] ), .A1(n710), .B0(n711), .B1(n653), .Y(
        n425) );
  AO22X1 U2154 ( .A0(\rxfifo[14][5] ), .A1(n710), .B0(n711), .B1(n652), .Y(
        n426) );
  AO22X1 U2155 ( .A0(\rxfifo[14][6] ), .A1(n710), .B0(n711), .B1(n651), .Y(
        n427) );
  AO22X1 U2156 ( .A0(\rxfifo[14][7] ), .A1(n710), .B0(n711), .B1(n1628), .Y(
        n428) );
  AO22X1 U2157 ( .A0(\rxfifo[15][0] ), .A1(n707), .B0(n708), .B1(n1633), .Y(
        n429) );
  AO22X1 U2158 ( .A0(\rxfifo[15][1] ), .A1(n707), .B0(n708), .B1(n1635), .Y(
        n430) );
  AO22X1 U2159 ( .A0(\rxfifo[15][2] ), .A1(n707), .B0(n708), .B1(n1637), .Y(
        n431) );
  AO22X1 U2160 ( .A0(\rxfifo[15][3] ), .A1(n707), .B0(n708), .B1(n1639), .Y(
        n432) );
  AO22X1 U2161 ( .A0(\rxfifo[15][4] ), .A1(n707), .B0(n708), .B1(n1641), .Y(
        n433) );
  AO22X1 U2162 ( .A0(\rxfifo[15][5] ), .A1(n707), .B0(n708), .B1(n1643), .Y(
        n434) );
  AO22X1 U2163 ( .A0(\rxfifo[15][6] ), .A1(n707), .B0(n708), .B1(n1645), .Y(
        n435) );
  AO22X1 U2164 ( .A0(\rxfifo[15][7] ), .A1(n707), .B0(n708), .B1(n1628), .Y(
        n436) );
  AO22X1 U2165 ( .A0(\rxfifo[16][0] ), .A1(n704), .B0(n705), .B1(n1632), .Y(
        n437) );
  AO22X1 U2166 ( .A0(\rxfifo[16][1] ), .A1(n704), .B0(n705), .B1(n1634), .Y(
        n438) );
  AO22X1 U2167 ( .A0(\rxfifo[16][2] ), .A1(n704), .B0(n705), .B1(n1636), .Y(
        n439) );
  AO22X1 U2168 ( .A0(\rxfifo[16][3] ), .A1(n704), .B0(n705), .B1(n1638), .Y(
        n440) );
  AO22X1 U2169 ( .A0(\rxfifo[16][4] ), .A1(n704), .B0(n705), .B1(n1640), .Y(
        n441) );
  AO22X1 U2170 ( .A0(\rxfifo[16][5] ), .A1(n704), .B0(n705), .B1(n1642), .Y(
        n442) );
  AO22X1 U2171 ( .A0(\rxfifo[16][6] ), .A1(n704), .B0(n705), .B1(n1644), .Y(
        n4430) );
  AO22X1 U2172 ( .A0(\rxfifo[16][7] ), .A1(n704), .B0(n705), .B1(n1628), .Y(
        n444) );
  AO22X1 U2173 ( .A0(\rxfifo[17][0] ), .A1(n702), .B0(n703), .B1(n657), .Y(
        n445) );
  AO22X1 U2174 ( .A0(\rxfifo[17][1] ), .A1(n702), .B0(n703), .B1(n656), .Y(
        n446) );
  AO22X1 U2175 ( .A0(\rxfifo[17][2] ), .A1(n702), .B0(n703), .B1(n655), .Y(
        n447) );
  AO22X1 U2176 ( .A0(\rxfifo[17][3] ), .A1(n702), .B0(n703), .B1(n654), .Y(
        n448) );
  AO22X1 U2177 ( .A0(\rxfifo[17][4] ), .A1(n702), .B0(n703), .B1(n653), .Y(
        n449) );
  AO22X1 U2178 ( .A0(\rxfifo[17][5] ), .A1(n702), .B0(n703), .B1(n652), .Y(
        n450) );
  AO22X1 U2179 ( .A0(\rxfifo[17][6] ), .A1(n702), .B0(n703), .B1(n651), .Y(
        n451) );
  AO22X1 U2180 ( .A0(\rxfifo[17][7] ), .A1(n702), .B0(n703), .B1(n1628), .Y(
        n452) );
  AO22X1 U2181 ( .A0(\rxfifo[18][0] ), .A1(n700), .B0(n701), .B1(n1633), .Y(
        n453) );
  AO22X1 U2182 ( .A0(\rxfifo[18][1] ), .A1(n700), .B0(n701), .B1(n1635), .Y(
        n454) );
  AO22X1 U2183 ( .A0(\rxfifo[18][2] ), .A1(n700), .B0(n701), .B1(n1637), .Y(
        n455) );
  AO22X1 U2184 ( .A0(\rxfifo[18][3] ), .A1(n700), .B0(n701), .B1(n1639), .Y(
        n456) );
  AO22X1 U2185 ( .A0(\rxfifo[18][4] ), .A1(n700), .B0(n701), .B1(n1641), .Y(
        n457) );
  AO22X1 U2186 ( .A0(\rxfifo[18][5] ), .A1(n700), .B0(n701), .B1(n1643), .Y(
        n458) );
  AO22X1 U2187 ( .A0(\rxfifo[18][6] ), .A1(n700), .B0(n701), .B1(n1645), .Y(
        n459) );
  AO22X1 U2188 ( .A0(\rxfifo[18][7] ), .A1(n700), .B0(n701), .B1(n1628), .Y(
        n460) );
  AO22X1 U2189 ( .A0(\rxfifo[19][0] ), .A1(n698), .B0(n699), .B1(n1632), .Y(
        n461) );
  AO22X1 U2190 ( .A0(\rxfifo[19][1] ), .A1(n698), .B0(n699), .B1(n1634), .Y(
        n462) );
  AO22X1 U2191 ( .A0(\rxfifo[19][2] ), .A1(n698), .B0(n699), .B1(n1636), .Y(
        n463) );
  AO22X1 U2192 ( .A0(\rxfifo[19][3] ), .A1(n698), .B0(n699), .B1(n1638), .Y(
        n464) );
  AO22X1 U2193 ( .A0(\rxfifo[19][4] ), .A1(n698), .B0(n699), .B1(n1640), .Y(
        n465) );
  AO22X1 U2194 ( .A0(\rxfifo[19][5] ), .A1(n698), .B0(n699), .B1(n1642), .Y(
        n466) );
  AO22X1 U2195 ( .A0(\rxfifo[19][6] ), .A1(n698), .B0(n699), .B1(n1644), .Y(
        n467) );
  AO22X1 U2196 ( .A0(\rxfifo[19][7] ), .A1(n698), .B0(n699), .B1(n1628), .Y(
        n468) );
  AO22X1 U2197 ( .A0(\rxfifo[20][0] ), .A1(n696), .B0(n697), .B1(n657), .Y(
        n469) );
  AO22X1 U2198 ( .A0(\rxfifo[20][1] ), .A1(n696), .B0(n697), .B1(n656), .Y(
        n470) );
  AO22X1 U2199 ( .A0(\rxfifo[20][2] ), .A1(n696), .B0(n697), .B1(n655), .Y(
        n471) );
  AO22X1 U2200 ( .A0(\rxfifo[20][3] ), .A1(n696), .B0(n697), .B1(n654), .Y(
        n472) );
  AO22X1 U2201 ( .A0(\rxfifo[20][4] ), .A1(n696), .B0(n697), .B1(n653), .Y(
        n473) );
  AO22X1 U2202 ( .A0(\rxfifo[20][5] ), .A1(n696), .B0(n697), .B1(n652), .Y(
        n474) );
  AO22X1 U2203 ( .A0(\rxfifo[20][6] ), .A1(n696), .B0(n697), .B1(n651), .Y(
        n475) );
  AO22X1 U2204 ( .A0(\rxfifo[20][7] ), .A1(n696), .B0(n697), .B1(n1628), .Y(
        n476) );
  AO22X1 U2205 ( .A0(\rxfifo[21][0] ), .A1(n694), .B0(n695), .B1(n1633), .Y(
        n477) );
  AO22X1 U2206 ( .A0(\rxfifo[21][1] ), .A1(n694), .B0(n695), .B1(n1635), .Y(
        n478) );
  AO22X1 U2207 ( .A0(\rxfifo[21][2] ), .A1(n694), .B0(n695), .B1(n1637), .Y(
        n479) );
  AO22X1 U2208 ( .A0(\rxfifo[21][3] ), .A1(n694), .B0(n695), .B1(n1639), .Y(
        n480) );
  AO22X1 U2209 ( .A0(\rxfifo[21][4] ), .A1(n694), .B0(n695), .B1(n1641), .Y(
        n481) );
  AO22X1 U2210 ( .A0(\rxfifo[21][5] ), .A1(n694), .B0(n695), .B1(n1643), .Y(
        n482) );
  AO22X1 U2211 ( .A0(\rxfifo[21][6] ), .A1(n694), .B0(n695), .B1(n1645), .Y(
        n483) );
  AO22X1 U2212 ( .A0(\rxfifo[21][7] ), .A1(n694), .B0(n695), .B1(n1628), .Y(
        n484) );
  AO22X1 U2213 ( .A0(\rxfifo[22][0] ), .A1(n691), .B0(n692), .B1(n1632), .Y(
        n485) );
  AO22X1 U2214 ( .A0(\rxfifo[22][1] ), .A1(n691), .B0(n692), .B1(n1634), .Y(
        n486) );
  AO22X1 U2215 ( .A0(\rxfifo[22][2] ), .A1(n691), .B0(n692), .B1(n1636), .Y(
        n487) );
  AO22X1 U2216 ( .A0(\rxfifo[22][3] ), .A1(n691), .B0(n692), .B1(n1638), .Y(
        n488) );
  AO22X1 U2217 ( .A0(\rxfifo[22][4] ), .A1(n691), .B0(n692), .B1(n1640), .Y(
        n489) );
  AO22X1 U2218 ( .A0(\rxfifo[22][5] ), .A1(n691), .B0(n692), .B1(n1642), .Y(
        n490) );
  AO22X1 U2219 ( .A0(\rxfifo[22][6] ), .A1(n691), .B0(n692), .B1(n1644), .Y(
        n491) );
  AO22X1 U2220 ( .A0(\rxfifo[22][7] ), .A1(n691), .B0(n692), .B1(n1628), .Y(
        n492) );
  AO22X1 U2221 ( .A0(\rxfifo[23][0] ), .A1(n688), .B0(n689), .B1(n657), .Y(
        n493) );
  AO22X1 U2222 ( .A0(\rxfifo[23][1] ), .A1(n688), .B0(n689), .B1(n656), .Y(
        n494) );
  AO22X1 U2223 ( .A0(\rxfifo[23][2] ), .A1(n688), .B0(n689), .B1(n655), .Y(
        n495) );
  AO22X1 U2224 ( .A0(\rxfifo[23][3] ), .A1(n688), .B0(n689), .B1(n654), .Y(
        n496) );
  AO22X1 U2225 ( .A0(\rxfifo[23][4] ), .A1(n688), .B0(n689), .B1(n653), .Y(
        n497) );
  AO22X1 U2226 ( .A0(\rxfifo[23][5] ), .A1(n688), .B0(n689), .B1(n652), .Y(
        n498) );
  AO22X1 U2227 ( .A0(\rxfifo[23][6] ), .A1(n688), .B0(n689), .B1(n651), .Y(
        n499) );
  AO22X1 U2228 ( .A0(\rxfifo[23][7] ), .A1(n688), .B0(n689), .B1(n1628), .Y(
        n500) );
  AO22X1 U2229 ( .A0(\rxfifo[24][0] ), .A1(n684), .B0(n685), .B1(n1633), .Y(
        n501) );
  AO22X1 U2230 ( .A0(\rxfifo[24][1] ), .A1(n684), .B0(n685), .B1(n1635), .Y(
        n502) );
  AO22X1 U2231 ( .A0(\rxfifo[24][2] ), .A1(n684), .B0(n685), .B1(n1637), .Y(
        n503) );
  AO22X1 U2232 ( .A0(\rxfifo[24][3] ), .A1(n684), .B0(n685), .B1(n1639), .Y(
        n504) );
  AO22X1 U2233 ( .A0(\rxfifo[24][4] ), .A1(n684), .B0(n685), .B1(n1641), .Y(
        n505) );
  AO22X1 U2234 ( .A0(\rxfifo[24][5] ), .A1(n684), .B0(n685), .B1(n1643), .Y(
        n506) );
  AO22X1 U2235 ( .A0(\rxfifo[24][6] ), .A1(n684), .B0(n685), .B1(n1645), .Y(
        n507) );
  AO22X1 U2236 ( .A0(\rxfifo[24][7] ), .A1(n684), .B0(n685), .B1(n1628), .Y(
        n508) );
  AO22X1 U2237 ( .A0(\rxfifo[25][0] ), .A1(n680), .B0(n681), .B1(n1632), .Y(
        n509) );
  AO22X1 U2238 ( .A0(\rxfifo[25][1] ), .A1(n680), .B0(n681), .B1(n1634), .Y(
        n510) );
  AO22X1 U2239 ( .A0(\rxfifo[25][2] ), .A1(n680), .B0(n681), .B1(n1636), .Y(
        n5110) );
  AO22X1 U2240 ( .A0(\rxfifo[25][3] ), .A1(n680), .B0(n681), .B1(n1638), .Y(
        n5120) );
  AO22X1 U2241 ( .A0(\rxfifo[25][4] ), .A1(n680), .B0(n681), .B1(n1640), .Y(
        n5130) );
  AO22X1 U2242 ( .A0(\rxfifo[25][5] ), .A1(n680), .B0(n681), .B1(n1642), .Y(
        n5140) );
  AO22X1 U2243 ( .A0(\rxfifo[25][6] ), .A1(n680), .B0(n681), .B1(n1644), .Y(
        n5150) );
  AO22X1 U2244 ( .A0(\rxfifo[25][7] ), .A1(n680), .B0(n681), .B1(n1628), .Y(
        n5160) );
  AO22X1 U2245 ( .A0(\rxfifo[26][0] ), .A1(n676), .B0(n677), .B1(n657), .Y(
        n5170) );
  AO22X1 U2246 ( .A0(\rxfifo[26][1] ), .A1(n676), .B0(n677), .B1(n656), .Y(
        n5180) );
  AO22X1 U2247 ( .A0(\rxfifo[26][2] ), .A1(n676), .B0(n677), .B1(n655), .Y(
        n5190) );
  AO22X1 U2248 ( .A0(\rxfifo[26][3] ), .A1(n676), .B0(n677), .B1(n654), .Y(
        n5200) );
  AO22X1 U2249 ( .A0(\rxfifo[26][4] ), .A1(n676), .B0(n677), .B1(n653), .Y(
        n5210) );
  AO22X1 U2250 ( .A0(\rxfifo[26][5] ), .A1(n676), .B0(n677), .B1(n652), .Y(
        n5220) );
  AO22X1 U2251 ( .A0(\rxfifo[26][6] ), .A1(n676), .B0(n677), .B1(n651), .Y(
        n5230) );
  AO22X1 U2252 ( .A0(\rxfifo[26][7] ), .A1(n676), .B0(n677), .B1(n1628), .Y(
        n5240) );
  AO22X1 U2253 ( .A0(\rxfifo[27][0] ), .A1(n672), .B0(n673), .B1(n1633), .Y(
        n5250) );
  AO22X1 U2254 ( .A0(\rxfifo[27][1] ), .A1(n672), .B0(n673), .B1(n1635), .Y(
        n5260) );
  AO22X1 U2255 ( .A0(\rxfifo[27][2] ), .A1(n672), .B0(n673), .B1(n1637), .Y(
        n5270) );
  AO22X1 U2256 ( .A0(\rxfifo[27][3] ), .A1(n672), .B0(n673), .B1(n1639), .Y(
        n5280) );
  AO22X1 U2257 ( .A0(\rxfifo[27][4] ), .A1(n672), .B0(n673), .B1(n1641), .Y(
        n529) );
  AO22X1 U2258 ( .A0(\rxfifo[27][5] ), .A1(n672), .B0(n673), .B1(n1643), .Y(
        n530) );
  AO22X1 U2259 ( .A0(\rxfifo[27][6] ), .A1(n672), .B0(n673), .B1(n1645), .Y(
        n531) );
  AO22X1 U2260 ( .A0(\rxfifo[27][7] ), .A1(n672), .B0(n673), .B1(n1628), .Y(
        n532) );
  AO22X1 U2261 ( .A0(\rxfifo[28][0] ), .A1(n668), .B0(n669), .B1(n1632), .Y(
        n533) );
  AO22X1 U2262 ( .A0(\rxfifo[28][1] ), .A1(n668), .B0(n669), .B1(n1634), .Y(
        n534) );
  AO22X1 U2263 ( .A0(\rxfifo[28][2] ), .A1(n668), .B0(n669), .B1(n1636), .Y(
        n535) );
  AO22X1 U2264 ( .A0(\rxfifo[28][3] ), .A1(n668), .B0(n669), .B1(n1638), .Y(
        n536) );
  AO22X1 U2265 ( .A0(\rxfifo[28][4] ), .A1(n668), .B0(n669), .B1(n1640), .Y(
        n537) );
  AO22X1 U2266 ( .A0(\rxfifo[28][5] ), .A1(n668), .B0(n669), .B1(n1642), .Y(
        n538) );
  AO22X1 U2267 ( .A0(\rxfifo[28][6] ), .A1(n668), .B0(n669), .B1(n1644), .Y(
        n539) );
  AO22X1 U2268 ( .A0(\rxfifo[28][7] ), .A1(n668), .B0(n669), .B1(n1628), .Y(
        n540) );
  AO22X1 U2269 ( .A0(\rxfifo[29][0] ), .A1(n664), .B0(n665), .B1(n657), .Y(
        n541) );
  AO22X1 U2270 ( .A0(\rxfifo[29][1] ), .A1(n664), .B0(n665), .B1(n656), .Y(
        n542) );
  AO22X1 U2271 ( .A0(\rxfifo[29][2] ), .A1(n664), .B0(n665), .B1(n655), .Y(
        n543) );
  AO22X1 U2272 ( .A0(\rxfifo[29][3] ), .A1(n664), .B0(n665), .B1(n654), .Y(
        n544) );
  AO22X1 U2273 ( .A0(\rxfifo[29][4] ), .A1(n664), .B0(n665), .B1(n653), .Y(
        n545) );
  AO22X1 U2274 ( .A0(\rxfifo[29][5] ), .A1(n664), .B0(n665), .B1(n652), .Y(
        n546) );
  AO22X1 U2275 ( .A0(\rxfifo[29][6] ), .A1(n664), .B0(n665), .B1(n651), .Y(
        n547) );
  AO22X1 U2276 ( .A0(\rxfifo[29][7] ), .A1(n664), .B0(n665), .B1(n1628), .Y(
        n548) );
  AO22X1 U2277 ( .A0(\rxfifo[30][0] ), .A1(n660), .B0(n661), .B1(n1633), .Y(
        n549) );
  AO22X1 U2278 ( .A0(\rxfifo[30][1] ), .A1(n660), .B0(n661), .B1(n1635), .Y(
        n550) );
  AO22X1 U2279 ( .A0(\rxfifo[30][2] ), .A1(n660), .B0(n661), .B1(n1637), .Y(
        n551) );
  AO22X1 U2280 ( .A0(\rxfifo[30][3] ), .A1(n660), .B0(n661), .B1(n1639), .Y(
        n552) );
  AO22X1 U2281 ( .A0(\rxfifo[30][4] ), .A1(n660), .B0(n661), .B1(n1641), .Y(
        n553) );
  AO22X1 U2282 ( .A0(\rxfifo[30][5] ), .A1(n660), .B0(n661), .B1(n1643), .Y(
        n554) );
  AO22X1 U2283 ( .A0(\rxfifo[30][6] ), .A1(n660), .B0(n661), .B1(n1645), .Y(
        n555) );
  AO22X1 U2284 ( .A0(\rxfifo[30][7] ), .A1(n660), .B0(n661), .B1(n1628), .Y(
        n556) );
  AO22X1 U2285 ( .A0(\rxfifo[31][0] ), .A1(n648), .B0(n650), .B1(n1632), .Y(
        n557) );
  AO22X1 U2286 ( .A0(\rxfifo[31][1] ), .A1(n648), .B0(n650), .B1(n1634), .Y(
        n558) );
  AO22X1 U2287 ( .A0(\rxfifo[31][2] ), .A1(n648), .B0(n650), .B1(n1636), .Y(
        n559) );
  AO22X1 U2288 ( .A0(\rxfifo[31][3] ), .A1(n648), .B0(n650), .B1(n1638), .Y(
        n560) );
  AO22X1 U2289 ( .A0(\rxfifo[31][4] ), .A1(n648), .B0(n650), .B1(n1640), .Y(
        n561) );
  AO22X1 U2290 ( .A0(\rxfifo[31][5] ), .A1(n648), .B0(n650), .B1(n1642), .Y(
        n562) );
  AO22X1 U2291 ( .A0(\rxfifo[31][6] ), .A1(n648), .B0(n650), .B1(n1644), .Y(
        n563) );
  AO22X1 U2292 ( .A0(rxsftreg[0]), .A1(n767), .B0(n768), .B1(rxsftreg[1]), .Y(
        n294) );
  AO22X1 U2293 ( .A0(rxsftreg[1]), .A1(n767), .B0(n768), .B1(rxsftreg[2]), .Y(
        n295) );
  AO22X1 U2294 ( .A0(rxsftreg[2]), .A1(n767), .B0(n768), .B1(rxsftreg[3]), .Y(
        n296) );
  AO22X1 U2295 ( .A0(rxsftreg[3]), .A1(n767), .B0(n768), .B1(rxsftreg[4]), .Y(
        n297) );
  AO22X1 U2296 ( .A0(rxsftreg[4]), .A1(n767), .B0(n768), .B1(rxsftreg[5]), .Y(
        n298) );
  AO22X1 U2297 ( .A0(rxsftreg[5]), .A1(n767), .B0(n768), .B1(rxsftreg[6]), .Y(
        n299) );
  AO22X1 U2298 ( .A0(rxsftreg[6]), .A1(n767), .B0(n768), .B1(rxsftreg[7]), .Y(
        n300) );
  AND4X1 U2299 ( .A(n1341), .B(n1489), .C(baudx16clk), .D(n793), .Y(N443) );
  OAI32X1 U2300 ( .A0(n797), .A1(rxclkenb), .A2(rxclkcnt[0]), .B0(n1340), .B1(
        n791), .Y(n287) );
  OAI32X1 U2301 ( .A0(n797), .A1(n801), .A2(n1340), .B0(n803), .B1(n1482), .Y(
        n288) );
  NAND2BX1 U2302 ( .AN(rxclkenb), .B(n1482), .Y(n801) );
  INVX1 U2303 ( .A(n800), .Y(n803) );
  OAI32X1 U2304 ( .A0(n770), .A1(n1620), .A2(n1307), .B0(n1337), .B1(n1308), 
        .Y(N526) );
  INVX1 U2305 ( .A(stopbit), .Y(n1307) );
  NAND2BX1 U2306 ( .AN(N71), .B(N70), .Y(n1273) );
  NAND2BX1 U2307 ( .AN(N73), .B(n1631), .Y(n1284) );
  NAND2BX1 U2308 ( .AN(N70), .B(N71), .Y(n1278) );
  NAND2BX1 U2309 ( .AN(n1473), .B(N70), .Y(n1294) );
  NAND2BX1 U2310 ( .AN(N73), .B(N72), .Y(n1276) );
  NAND2BX1 U2311 ( .AN(N72), .B(N73), .Y(n1302) );
  NAND2BX1 U2312 ( .AN(N71), .B(n1477), .Y(n1275) );
  OAI221X1 U2313 ( .A0(n1517), .A1(n897), .B0(n1370), .B1(n899), .C0(n1290), 
        .Y(n1265) );
  OA22X1 U2314 ( .A0(n1407), .A1(n902), .B0(n1554), .B1(n904), .Y(n1290) );
  OAI221X1 U2315 ( .A0(n1518), .A1(n897), .B0(n1371), .B1(n899), .C0(n1256), 
        .Y(n1241) );
  OA22X1 U2316 ( .A0(n1408), .A1(n902), .B0(n1555), .B1(n904), .Y(n1256) );
  OAI221X1 U2317 ( .A0(n1519), .A1(n897), .B0(n1372), .B1(n899), .C0(n1230), 
        .Y(n1215) );
  OA22X1 U2318 ( .A0(n1409), .A1(n902), .B0(n1556), .B1(n904), .Y(n1230) );
  OAI221X1 U2319 ( .A0(n1520), .A1(n897), .B0(n1373), .B1(n899), .C0(n1206), 
        .Y(n1191) );
  OA22X1 U2320 ( .A0(n1410), .A1(n902), .B0(n1557), .B1(n904), .Y(n1206) );
  OAI221X1 U2321 ( .A0(n1521), .A1(n897), .B0(n1374), .B1(n899), .C0(n1180), 
        .Y(n1165) );
  OA22X1 U2322 ( .A0(n1411), .A1(n902), .B0(n1558), .B1(n904), .Y(n1180) );
  OAI221X1 U2323 ( .A0(n1522), .A1(n897), .B0(n1375), .B1(n899), .C0(n1156), 
        .Y(n1141) );
  OA22X1 U2324 ( .A0(n1412), .A1(n902), .B0(n1559), .B1(n904), .Y(n1156) );
  OAI221X1 U2325 ( .A0(n1523), .A1(n897), .B0(n1376), .B1(n899), .C0(n1130), 
        .Y(n1115) );
  OA22X1 U2326 ( .A0(n1413), .A1(n902), .B0(n1560), .B1(n904), .Y(n1130) );
  OAI221X1 U2327 ( .A0(n1524), .A1(n897), .B0(n1377), .B1(n899), .C0(n1106), 
        .Y(n1091) );
  OA22X1 U2328 ( .A0(n1414), .A1(n902), .B0(n1561), .B1(n904), .Y(n1106) );
  OAI221X1 U2329 ( .A0(n1525), .A1(n897), .B0(n1378), .B1(n899), .C0(n1080), 
        .Y(n1065) );
  OA22X1 U2330 ( .A0(n1415), .A1(n902), .B0(n1562), .B1(n904), .Y(n1080) );
  OAI221X1 U2331 ( .A0(n1526), .A1(n897), .B0(n1379), .B1(n899), .C0(n1056), 
        .Y(n1041) );
  OA22X1 U2332 ( .A0(n1416), .A1(n902), .B0(n1563), .B1(n904), .Y(n1056) );
  OAI221X1 U2333 ( .A0(n1527), .A1(n897), .B0(n1380), .B1(n899), .C0(n1030), 
        .Y(n1015) );
  OA22X1 U2334 ( .A0(n1417), .A1(n902), .B0(n1564), .B1(n904), .Y(n1030) );
  OAI221X1 U2335 ( .A0(n1528), .A1(n897), .B0(n1381), .B1(n899), .C0(n1006), 
        .Y(n991) );
  OA22X1 U2336 ( .A0(n1418), .A1(n902), .B0(n1565), .B1(n904), .Y(n1006) );
  OAI221X1 U2337 ( .A0(n1529), .A1(n897), .B0(n1382), .B1(n899), .C0(n980), 
        .Y(n965) );
  OA22X1 U2338 ( .A0(n1419), .A1(n902), .B0(n1566), .B1(n904), .Y(n980) );
  OAI221X1 U2339 ( .A0(n1530), .A1(n897), .B0(n1383), .B1(n899), .C0(n956), 
        .Y(n941) );
  OA22X1 U2340 ( .A0(n1420), .A1(n902), .B0(n1567), .B1(n904), .Y(n956) );
  OAI221X1 U2341 ( .A0(n1531), .A1(n897), .B0(n1384), .B1(n899), .C0(n930), 
        .Y(n915) );
  OA22X1 U2342 ( .A0(n1421), .A1(n902), .B0(n1568), .B1(n904), .Y(n930) );
  OAI221X1 U2343 ( .A0(n1532), .A1(n897), .B0(n1385), .B1(n899), .C0(n900), 
        .Y(n875) );
  OA22X1 U2344 ( .A0(n1422), .A1(n902), .B0(n1569), .B1(n904), .Y(n900) );
  OAI221X1 U2345 ( .A0(n1533), .A1(n879), .B0(n1386), .B1(n881), .C0(n1270), 
        .Y(n1267) );
  OA22X1 U2346 ( .A0(n1423), .A1(n884), .B0(n1570), .B1(n886), .Y(n1270) );
  OAI221X1 U2347 ( .A0(n1534), .A1(n879), .B0(n1387), .B1(n881), .C0(n1246), 
        .Y(n1243) );
  OA22X1 U2348 ( .A0(n1424), .A1(n884), .B0(n1571), .B1(n886), .Y(n1246) );
  OAI221X1 U2349 ( .A0(n1535), .A1(n879), .B0(n1388), .B1(n881), .C0(n1096), 
        .Y(n1093) );
  OA22X1 U2350 ( .A0(n1425), .A1(n884), .B0(n1572), .B1(n886), .Y(n1096) );
  OAI221X1 U2351 ( .A0(n1536), .A1(n879), .B0(n1389), .B1(n881), .C0(n1046), 
        .Y(n1043) );
  OA22X1 U2352 ( .A0(n1426), .A1(n884), .B0(n1573), .B1(n886), .Y(n1046) );
  OAI221X1 U2353 ( .A0(n1537), .A1(n879), .B0(n1390), .B1(n881), .C0(n946), 
        .Y(n943) );
  OA22X1 U2354 ( .A0(n1427), .A1(n884), .B0(n1574), .B1(n886), .Y(n946) );
  OAI221X1 U2355 ( .A0(n1538), .A1(n879), .B0(n1391), .B1(n881), .C0(n920), 
        .Y(n917) );
  OA22X1 U2356 ( .A0(n1428), .A1(n884), .B0(n1575), .B1(n886), .Y(n920) );
  OAI221X1 U2357 ( .A0(n1539), .A1(n879), .B0(n1392), .B1(n881), .C0(n882), 
        .Y(n877) );
  OA22X1 U2358 ( .A0(n1429), .A1(n884), .B0(n1576), .B1(n886), .Y(n882) );
  OAI221X1 U2359 ( .A0(n1540), .A1(n888), .B0(n1393), .B1(n890), .C0(n1281), 
        .Y(n1266) );
  OA22X1 U2360 ( .A0(n1430), .A1(n893), .B0(n1577), .B1(n895), .Y(n1281) );
  OAI221X1 U2361 ( .A0(n1541), .A1(n888), .B0(n1394), .B1(n890), .C0(n1251), 
        .Y(n1242) );
  OA22X1 U2362 ( .A0(n1431), .A1(n893), .B0(n1578), .B1(n895), .Y(n1251) );
  OAI221X1 U2363 ( .A0(n1542), .A1(n888), .B0(n1395), .B1(n890), .C0(n1101), 
        .Y(n1092) );
  OA22X1 U2364 ( .A0(n1432), .A1(n893), .B0(n1579), .B1(n895), .Y(n1101) );
  OAI221X1 U2365 ( .A0(n1543), .A1(n888), .B0(n1396), .B1(n890), .C0(n1051), 
        .Y(n1042) );
  OA22X1 U2366 ( .A0(n1433), .A1(n893), .B0(n1580), .B1(n895), .Y(n1051) );
  OAI221X1 U2367 ( .A0(n1544), .A1(n888), .B0(n1397), .B1(n890), .C0(n951), 
        .Y(n942) );
  OA22X1 U2368 ( .A0(n1434), .A1(n893), .B0(n1581), .B1(n895), .Y(n951) );
  OAI221X1 U2369 ( .A0(n1545), .A1(n888), .B0(n1398), .B1(n890), .C0(n925), 
        .Y(n916) );
  OA22X1 U2370 ( .A0(n1435), .A1(n893), .B0(n1582), .B1(n895), .Y(n925) );
  OAI221X1 U2371 ( .A0(n1546), .A1(n888), .B0(n1399), .B1(n890), .C0(n891), 
        .Y(n876) );
  OA22X1 U2372 ( .A0(n1436), .A1(n893), .B0(n1583), .B1(n895), .Y(n891) );
  OAI221X1 U2373 ( .A0(n1547), .A1(n906), .B0(n1400), .B1(n908), .C0(n1298), 
        .Y(n1264) );
  OA22X1 U2374 ( .A0(n1437), .A1(n911), .B0(n1584), .B1(n913), .Y(n1298) );
  OAI221X1 U2375 ( .A0(n1548), .A1(n906), .B0(n1401), .B1(n908), .C0(n1111), 
        .Y(n1090) );
  OA22X1 U2376 ( .A0(n1438), .A1(n911), .B0(n1585), .B1(n913), .Y(n1111) );
  OAI221X1 U2377 ( .A0(n1549), .A1(n906), .B0(n1402), .B1(n908), .C0(n1061), 
        .Y(n1040) );
  OA22X1 U2378 ( .A0(n1439), .A1(n911), .B0(n1586), .B1(n913), .Y(n1061) );
  OAI221X1 U2379 ( .A0(n1550), .A1(n906), .B0(n1403), .B1(n908), .C0(n961), 
        .Y(n940) );
  OA22X1 U2380 ( .A0(n1440), .A1(n911), .B0(n1587), .B1(n913), .Y(n961) );
  OAI221X1 U2381 ( .A0(n1551), .A1(n906), .B0(n1404), .B1(n908), .C0(n935), 
        .Y(n914) );
  OA22X1 U2382 ( .A0(n1441), .A1(n911), .B0(n1588), .B1(n913), .Y(n935) );
  OA22X1 U2383 ( .A0(n1442), .A1(n911), .B0(n1589), .B1(n913), .Y(n1261) );
  OA22X1 U2384 ( .A0(n1443), .A1(n884), .B0(n1590), .B1(n886), .Y(n1220) );
  OA22X1 U2385 ( .A0(n1444), .A1(n893), .B0(n1591), .B1(n895), .Y(n1225) );
  OA22X1 U2386 ( .A0(n1445), .A1(n911), .B0(n1592), .B1(n913), .Y(n1235) );
  OA22X1 U2387 ( .A0(n1446), .A1(n884), .B0(n1593), .B1(n886), .Y(n1196) );
  OA22X1 U2388 ( .A0(n1447), .A1(n893), .B0(n1594), .B1(n895), .Y(n1201) );
  OA22X1 U2389 ( .A0(n1448), .A1(n911), .B0(n1595), .B1(n913), .Y(n1211) );
  OA22X1 U2390 ( .A0(n1449), .A1(n884), .B0(n1596), .B1(n886), .Y(n1170) );
  OA22X1 U2391 ( .A0(n1450), .A1(n893), .B0(n1597), .B1(n895), .Y(n1175) );
  OA22X1 U2392 ( .A0(n1451), .A1(n911), .B0(n1598), .B1(n913), .Y(n1185) );
  OA22X1 U2393 ( .A0(n1452), .A1(n884), .B0(n1599), .B1(n886), .Y(n1146) );
  OA22X1 U2394 ( .A0(n1453), .A1(n893), .B0(n1600), .B1(n895), .Y(n1151) );
  OA22X1 U2395 ( .A0(n1454), .A1(n911), .B0(n1601), .B1(n913), .Y(n1161) );
  OA22X1 U2396 ( .A0(n1455), .A1(n884), .B0(n1602), .B1(n886), .Y(n1120) );
  OA22X1 U2397 ( .A0(n1456), .A1(n893), .B0(n1603), .B1(n895), .Y(n1125) );
  OA22X1 U2398 ( .A0(n1457), .A1(n911), .B0(n1604), .B1(n913), .Y(n1135) );
  OA22X1 U2399 ( .A0(n1458), .A1(n884), .B0(n1605), .B1(n886), .Y(n1070) );
  OA22X1 U2400 ( .A0(n1459), .A1(n893), .B0(n1606), .B1(n895), .Y(n1075) );
  OA22X1 U2401 ( .A0(n1460), .A1(n911), .B0(n1607), .B1(n913), .Y(n1085) );
  OA22X1 U2402 ( .A0(n1461), .A1(n884), .B0(n1608), .B1(n886), .Y(n1020) );
  OA22X1 U2403 ( .A0(n1462), .A1(n893), .B0(n1609), .B1(n895), .Y(n1025) );
  OA22X1 U2404 ( .A0(n1463), .A1(n911), .B0(n1610), .B1(n913), .Y(n1035) );
  OA22X1 U2405 ( .A0(n1464), .A1(n884), .B0(n1611), .B1(n886), .Y(n996) );
  OA22X1 U2406 ( .A0(n1465), .A1(n893), .B0(n1612), .B1(n895), .Y(n1001) );
  OA22X1 U2407 ( .A0(n1466), .A1(n911), .B0(n1613), .B1(n913), .Y(n1011) );
  OA22X1 U2408 ( .A0(n1467), .A1(n884), .B0(n1614), .B1(n886), .Y(n970) );
  OA22X1 U2409 ( .A0(n1468), .A1(n893), .B0(n1615), .B1(n895), .Y(n975) );
  OA22X1 U2410 ( .A0(n1469), .A1(n911), .B0(n1616), .B1(n913), .Y(n985) );
  OA22X1 U2411 ( .A0(n1470), .A1(n911), .B0(n1617), .B1(n913), .Y(n909) );
  AO22X1 U2412 ( .A0(n938), .A1(n1471), .B0(n939), .B1(N74), .Y(fifodata_rx[6]) );
  OR4X1 U2413 ( .A(n940), .B(n941), .C(n942), .D(n943), .Y(n939) );
  NOR2X1 U2414 ( .A(n1472), .B(n1631), .Y(n1630) );
  AO22X1 U2415 ( .A0(n1088), .A1(n1471), .B0(n1089), .B1(N74), .Y(
        fifodata_rx[3]) );
  OR4X1 U2416 ( .A(n1090), .B(n1091), .C(n1092), .D(n1093), .Y(n1089) );
  AO22X1 U2417 ( .A0(n988), .A1(n1471), .B0(n989), .B1(N74), .Y(fifodata_rx[5]) );
  AO22X1 U2418 ( .A0(n1188), .A1(n1471), .B0(n1189), .B1(N74), .Y(
        fifodata_rx[1]) );
  AO22X1 U2419 ( .A0(n1138), .A1(n1471), .B0(n1139), .B1(N74), .Y(
        fifodata_rx[2]) );
  AO22X1 U2420 ( .A0(n1038), .A1(n1471), .B0(n1039), .B1(N74), .Y(
        fifodata_rx[4]) );
  OR4X1 U2421 ( .A(n1040), .B(n1041), .C(n1042), .D(n1043), .Y(n1039) );
  AO22X1 U2422 ( .A0(n1238), .A1(n1471), .B0(n1239), .B1(N74), .Y(
        fifodata_rx[0]) );
  OR4X1 U2423 ( .A(n1240), .B(n1241), .C(n1242), .D(n1243), .Y(n1239) );
  OR4X1 U2424 ( .A(n1264), .B(n1265), .C(n1266), .D(n1267), .Y(n1238) );
  OAI221X1 U2425 ( .A0(n1552), .A1(n906), .B0(n1405), .B1(n908), .C0(n1261), 
        .Y(n1240) );
  AO22X1 U2426 ( .A0(n872), .A1(n1471), .B0(n873), .B1(N74), .Y(fifodata_rx[7]) );
  OR4X1 U2427 ( .A(n874), .B(n875), .C(n876), .D(n877), .Y(n873) );
  OR4X1 U2428 ( .A(n914), .B(n915), .C(n916), .D(n917), .Y(n872) );
  OAI221X1 U2429 ( .A0(n1553), .A1(n906), .B0(n1406), .B1(n908), .C0(n909), 
        .Y(n874) );
  DFFRX1 fifo_rdpos_reg_0_ ( .D(n566), .CK(clk), .RN(rstb), .Q(N70), .QN(n1477) );
  DFFRX1 fifo_wrpos_reg_3_ ( .D(n574), .CK(clk), .RN(rstb), .Q(fifo_wrpos_3_), 
        .QN(n1478) );
  DFFRX1 fifo_wrpos_reg_2_ ( .D(n573), .CK(clk), .RN(rstb), .Q(fifo_wrpos_2_)
         );
  DFFRX1 fifo_wrpos_reg_4_ ( .D(n575), .CK(clk), .RN(rstb), .Q(fifo_wrpos_4_), 
        .QN(n1484) );
  DFFRX1 fifo_rdpos_reg_2_ ( .D(n568), .CK(clk), .RN(rstb), .Q(N72), .QN(n1631) );
  DFFRX1 fifo_rdpos_reg_1_ ( .D(n567), .CK(clk), .RN(rstb), .Q(N71), .QN(n1473) );
  DFFRX1 fifo_rdpos_reg_3_ ( .D(n569), .CK(clk), .RN(rstb), .Q(N73), .QN(n1472) );
  DFFSX1 rx_lpfd_reg ( .D(n302), .CK(clk), .SN(rstb), .Q(rx_lpfd), .QN(n1622)
         );
  DFFRX1 current_state_reg_1_ ( .D(N512), .CK(clk), .RN(rstb), .Q(
        current_state_1_), .QN(n1474) );
  DFFRX1 fifo_wrpos_reg_0_ ( .D(n571), .CK(clk), .RN(rstb), .Q(fifo_wrpos_0_), 
        .QN(n1332) );
  DFFRX1 fifo_wrpos_reg_1_ ( .D(n572), .CK(clk), .RN(rstb), .Q(n578), .QN(
        n1336) );
  DFFRX1 current_state_reg_17_ ( .D(N528), .CK(clk), .RN(rstb), .QN(n17) );
  DFFRX1 current_state_reg_2_ ( .D(N513), .CK(clk), .RN(rstb), .Q(
        current_state_2_) );
  DFFRX1 current_state_reg_4_ ( .D(N515), .CK(clk), .RN(rstb), .Q(
        current_state_4_) );
  DFFRX1 current_state_reg_3_ ( .D(N514), .CK(clk), .RN(rstb), .Q(
        current_state_3_) );
  DFFSX1 current_state_reg_0_ ( .D(N511), .CK(clk), .SN(rstb), .QN(n1619) );
  DFFRX1 fifo_rdpos_reg_4_ ( .D(n570), .CK(clk), .RN(rstb), .Q(N74), .QN(n1471) );
  DFFRX1 fifofull_reg ( .D(n565), .CK(clk), .RN(rstb), .Q(rxfifocnt[5]), .QN(
        n1475) );
  DFFSX1 in_dly_reg_3_ ( .D(n306), .CK(clk), .SN(rstb), .Q(in_dly[3]), .QN(
        n1342) );
  DFFSX1 in_dly_reg_4_ ( .D(n307), .CK(clk), .SN(rstb), .Q(in_dly[4]), .QN(
        n1627) );
  DFFRX1 parity_int_reg ( .D(n291), .CK(clk), .RN(rstb), .Q(parity_int), .QN(
        n1483) );
  DFFRX1 current_state_reg_5_ ( .D(N516), .CK(clk), .RN(rstb), .Q(
        current_state_5_) );
  DFFRX1 current_state_reg_6_ ( .D(N517), .CK(clk), .RN(rstb), .Q(
        current_state_6_) );
  DFFRX1 current_state_reg_8_ ( .D(N519), .CK(clk), .RN(rstb), .Q(
        current_state_8_) );
  DFFRX1 current_state_reg_11_ ( .D(N522), .CK(clk), .RN(rstb), .Q(
        current_state_11_), .QN(n1476) );
  DFFRX1 current_state_reg_13_ ( .D(N524), .CK(clk), .RN(rstb), .Q(
        current_state_13_), .QN(n1334) );
  DFFRX1 current_state_reg_16_ ( .D(N527), .CK(clk), .RN(rstb), .Q(
        current_state_16_), .QN(n1480) );
  DFFRX1 current_state_reg_15_ ( .D(N526), .CK(clk), .RN(rstb), .Q(n18), .QN(
        n1337) );
  DFFRX1 current_state_reg_14_ ( .D(N525), .CK(clk), .RN(rstb), .Q(
        current_state_14_), .QN(n1479) );
  DFFRX1 current_state_reg_12_ ( .D(N523), .CK(clk), .RN(rstb), .QN(n1330) );
  DFFRX1 current_state_reg_7_ ( .D(N518), .CK(clk), .RN(rstb), .Q(
        current_state_7_) );
  DFFRX1 current_state_reg_9_ ( .D(N520), .CK(clk), .RN(rstb), .Q(
        current_state_9_) );
  DFFRX1 current_state_reg_10_ ( .D(N521), .CK(clk), .RN(rstb), .Q(
        current_state_10_) );
  DFFSX1 fifowrb_reg ( .D(n279), .CK(clk), .SN(rstb), .Q(bytereceivedb), .QN(
        n1335) );
  DFFSX1 in_dly_reg_1_ ( .D(n304), .CK(clk), .SN(rstb), .Q(in_dly[1]), .QN(
        n1481) );
  DFFSX1 in_dly_reg_0_ ( .D(n303), .CK(clk), .SN(rstb), .Q(in_dly[0]), .QN(
        n1338) );
  DFFSX1 rxclkenb_reg ( .D(n283), .CK(clk), .SN(rstb), .Q(rxclkenb), .QN(n1333) );
  DFFRX1 rxclkcnt_reg_3_ ( .D(n290), .CK(clk), .RN(rstb), .Q(rxclkcnt[3]), 
        .QN(n1489) );
  DFFSX1 framechkb_reg ( .D(n280), .CK(clk), .SN(rstb), .Q(framechkb), .QN(
        n1485) );
  DFFSX1 in_dly_reg_2_ ( .D(n305), .CK(clk), .SN(rstb), .Q(in_dly[2]), .QN(
        n1331) );
  DFFRX1 rxclkcnt_reg_0_ ( .D(n287), .CK(clk), .RN(rstb), .Q(rxclkcnt[0]), 
        .QN(n1340) );
  DFFRX1 rxclkcnt_reg_1_ ( .D(n288), .CK(clk), .RN(rstb), .Q(rxclkcnt[1]), 
        .QN(n1482) );
  DFFSX1 dataphaseb_reg ( .D(n286), .CK(clk), .SN(rstb), .Q(dataphaseb), .QN(
        n1486) );
  DFFSX1 rxsftenb_reg ( .D(n282), .CK(clk), .SN(rstb), .Q(rxsftenb), .QN(n1487) );
  DFFSX1 paritychkb_reg ( .D(n281), .CK(clk), .SN(rstb), .Q(paritychkb), .QN(
        n1488) );
  DFFRX1 rxclkcnt_reg_2_ ( .D(n289), .CK(clk), .RN(rstb), .Q(rxclkcnt[2]), 
        .QN(n1341) );
  DFFRX1 parityerror_int_reg ( .D(n292), .CK(clk), .RN(rstb), .Q(parityerror), 
        .QN(n278) );
  DFFRX1 frameerror_int_reg ( .D(n293), .CK(clk), .RN(rstb), .Q(frameerror), 
        .QN(n276) );
  DFFRX1 rxfifo_reg ( .D(n309), .CK(clk), .RN(rstb), .Q(\rxfifo[0][0] ), .QN(
        n1430) );
  DFFRX1 rxfifo_reg0 ( .D(n310), .CK(clk), .RN(rstb), .Q(\rxfifo[0][1] ), .QN(
        n1444) );
  DFFRX1 rxfifo_reg1 ( .D(n311), .CK(clk), .RN(rstb), .Q(\rxfifo[0][2] ), .QN(
        n1450) );
  DFFRX1 rxfifo_reg2 ( .D(n312), .CK(clk), .RN(rstb), .Q(\rxfifo[0][3] ), .QN(
        n1456) );
  DFFRX1 rxfifo_reg3 ( .D(n313), .CK(clk), .RN(rstb), .Q(\rxfifo[0][4] ), .QN(
        n1459) );
  DFFRX1 rxfifo_reg4 ( .D(n314), .CK(clk), .RN(rstb), .Q(\rxfifo[0][5] ), .QN(
        n1462) );
  DFFRX1 rxfifo_reg5 ( .D(n315), .CK(clk), .RN(rstb), .Q(\rxfifo[0][6] ), .QN(
        n1468) );
  DFFRX1 rxfifo_reg6 ( .D(n316), .CK(clk), .RN(rstb), .Q(\rxfifo[0][7] ), .QN(
        n1435) );
  DFFRX1 rxfifo_reg7 ( .D(n317), .CK(clk), .RN(rstb), .Q(\rxfifo[1][0] ), .QN(
        n1577) );
  DFFRX1 rxfifo_reg8 ( .D(n318), .CK(clk), .RN(rstb), .Q(\rxfifo[1][1] ), .QN(
        n1591) );
  DFFRX1 rxfifo_reg9 ( .D(n319), .CK(clk), .RN(rstb), .Q(\rxfifo[1][2] ), .QN(
        n1597) );
  DFFRX1 rxfifo_reg10 ( .D(n320), .CK(clk), .RN(rstb), .Q(\rxfifo[1][3] ), 
        .QN(n1603) );
  DFFRX1 rxfifo_reg11 ( .D(n321), .CK(clk), .RN(rstb), .Q(\rxfifo[1][4] ), 
        .QN(n1606) );
  DFFRX1 rxfifo_reg12 ( .D(n322), .CK(clk), .RN(rstb), .Q(\rxfifo[1][5] ), 
        .QN(n1609) );
  DFFRX1 rxfifo_reg13 ( .D(n323), .CK(clk), .RN(rstb), .Q(\rxfifo[1][6] ), 
        .QN(n1615) );
  DFFRX1 rxfifo_reg14 ( .D(n324), .CK(clk), .RN(rstb), .Q(\rxfifo[1][7] ), 
        .QN(n1582) );
  DFFRX1 rxfifo_reg15 ( .D(n325), .CK(clk), .RN(rstb), .Q(\rxfifo[2][0] ), 
        .QN(n1540) );
  DFFRX1 rxfifo_reg16 ( .D(n326), .CK(clk), .RN(rstb), .Q(\rxfifo[2][1] ), 
        .QN(n1491) );
  DFFRX1 rxfifo_reg17 ( .D(n327), .CK(clk), .RN(rstb), .Q(\rxfifo[2][2] ), 
        .QN(n1494) );
  DFFRX1 rxfifo_reg18 ( .D(n328), .CK(clk), .RN(rstb), .Q(\rxfifo[2][3] ), 
        .QN(n1497) );
  DFFRX1 rxfifo_reg19 ( .D(n329), .CK(clk), .RN(rstb), .Q(\rxfifo[2][4] ), 
        .QN(n1500) );
  DFFRX1 rxfifo_reg20 ( .D(n330), .CK(clk), .RN(rstb), .Q(\rxfifo[2][5] ), 
        .QN(n1503) );
  DFFRX1 rxfifo_reg21 ( .D(n331), .CK(clk), .RN(rstb), .Q(\rxfifo[2][6] ), 
        .QN(n1506) );
  DFFRX1 rxfifo_reg22 ( .D(n332), .CK(clk), .RN(rstb), .Q(\rxfifo[2][7] ), 
        .QN(n1545) );
  DFFRX1 rxfifo_reg23 ( .D(n333), .CK(clk), .RN(rstb), .Q(\rxfifo[3][0] ), 
        .QN(n1393) );
  DFFRX1 rxfifo_reg24 ( .D(n334), .CK(clk), .RN(rstb), .Q(\rxfifo[3][1] ), 
        .QN(n1344) );
  DFFRX1 rxfifo_reg25 ( .D(n335), .CK(clk), .RN(rstb), .Q(\rxfifo[3][2] ), 
        .QN(n1347) );
  DFFRX1 rxfifo_reg26 ( .D(n336), .CK(clk), .RN(rstb), .Q(\rxfifo[3][3] ), 
        .QN(n1350) );
  DFFRX1 rxfifo_reg27 ( .D(n337), .CK(clk), .RN(rstb), .Q(\rxfifo[3][4] ), 
        .QN(n1353) );
  DFFRX1 rxfifo_reg28 ( .D(n338), .CK(clk), .RN(rstb), .Q(\rxfifo[3][5] ), 
        .QN(n1356) );
  DFFRX1 rxfifo_reg29 ( .D(n339), .CK(clk), .RN(rstb), .Q(\rxfifo[3][6] ), 
        .QN(n1359) );
  DFFRX1 rxfifo_reg30 ( .D(n340), .CK(clk), .RN(rstb), .Q(\rxfifo[3][7] ), 
        .QN(n1398) );
  DFFRX1 rxfifo_reg31 ( .D(n341), .CK(clk), .RN(rstb), .Q(\rxfifo[4][0] ), 
        .QN(n1423) );
  DFFRX1 rxfifo_reg32 ( .D(n342), .CK(clk), .RN(rstb), .Q(\rxfifo[4][1] ), 
        .QN(n1443) );
  DFFRX1 rxfifo_reg33 ( .D(n343), .CK(clk), .RN(rstb), .Q(\rxfifo[4][2] ), 
        .QN(n1449) );
  DFFRX1 rxfifo_reg34 ( .D(n344), .CK(clk), .RN(rstb), .Q(\rxfifo[4][3] ), 
        .QN(n1455) );
  DFFRX1 rxfifo_reg35 ( .D(n345), .CK(clk), .RN(rstb), .Q(\rxfifo[4][4] ), 
        .QN(n1458) );
  DFFRX1 rxfifo_reg36 ( .D(n346), .CK(clk), .RN(rstb), .Q(\rxfifo[4][5] ), 
        .QN(n1461) );
  DFFRX1 rxfifo_reg37 ( .D(n347), .CK(clk), .RN(rstb), .Q(\rxfifo[4][6] ), 
        .QN(n1467) );
  DFFRX1 rxfifo_reg38 ( .D(n348), .CK(clk), .RN(rstb), .Q(\rxfifo[4][7] ), 
        .QN(n1428) );
  DFFRX1 rxfifo_reg39 ( .D(n349), .CK(clk), .RN(rstb), .Q(\rxfifo[5][0] ), 
        .QN(n1570) );
  DFFRX1 rxfifo_reg40 ( .D(n350), .CK(clk), .RN(rstb), .Q(\rxfifo[5][1] ), 
        .QN(n1590) );
  DFFRX1 rxfifo_reg41 ( .D(n351), .CK(clk), .RN(rstb), .Q(\rxfifo[5][2] ), 
        .QN(n1596) );
  DFFRX1 rxfifo_reg42 ( .D(n352), .CK(clk), .RN(rstb), .Q(\rxfifo[5][3] ), 
        .QN(n1602) );
  DFFRX1 rxfifo_reg43 ( .D(n353), .CK(clk), .RN(rstb), .Q(\rxfifo[5][4] ), 
        .QN(n1605) );
  DFFRX1 rxfifo_reg44 ( .D(n354), .CK(clk), .RN(rstb), .Q(\rxfifo[5][5] ), 
        .QN(n1608) );
  DFFRX1 rxfifo_reg45 ( .D(n355), .CK(clk), .RN(rstb), .Q(\rxfifo[5][6] ), 
        .QN(n1614) );
  DFFRX1 rxfifo_reg46 ( .D(n356), .CK(clk), .RN(rstb), .Q(\rxfifo[5][7] ), 
        .QN(n1575) );
  DFFRX1 rxfifo_reg47 ( .D(n357), .CK(clk), .RN(rstb), .Q(\rxfifo[6][0] ), 
        .QN(n1533) );
  DFFRX1 rxfifo_reg48 ( .D(n358), .CK(clk), .RN(rstb), .Q(\rxfifo[6][1] ), 
        .QN(n1490) );
  DFFRX1 rxfifo_reg49 ( .D(n359), .CK(clk), .RN(rstb), .Q(\rxfifo[6][2] ), 
        .QN(n1493) );
  DFFRX1 rxfifo_reg50 ( .D(n360), .CK(clk), .RN(rstb), .Q(\rxfifo[6][3] ), 
        .QN(n1496) );
  DFFRX1 rxfifo_reg51 ( .D(n361), .CK(clk), .RN(rstb), .Q(\rxfifo[6][4] ), 
        .QN(n1499) );
  DFFRX1 rxfifo_reg52 ( .D(n362), .CK(clk), .RN(rstb), .Q(\rxfifo[6][5] ), 
        .QN(n1502) );
  DFFRX1 rxfifo_reg53 ( .D(n363), .CK(clk), .RN(rstb), .Q(\rxfifo[6][6] ), 
        .QN(n1505) );
  DFFRX1 rxfifo_reg54 ( .D(n364), .CK(clk), .RN(rstb), .Q(\rxfifo[6][7] ), 
        .QN(n1538) );
  DFFRX1 rxfifo_reg55 ( .D(n365), .CK(clk), .RN(rstb), .Q(\rxfifo[7][0] ), 
        .QN(n1386) );
  DFFRX1 rxfifo_reg56 ( .D(n366), .CK(clk), .RN(rstb), .Q(\rxfifo[7][1] ), 
        .QN(n1343) );
  DFFRX1 rxfifo_reg57 ( .D(n367), .CK(clk), .RN(rstb), .Q(\rxfifo[7][2] ), 
        .QN(n1346) );
  DFFRX1 rxfifo_reg58 ( .D(n368), .CK(clk), .RN(rstb), .Q(\rxfifo[7][3] ), 
        .QN(n1349) );
  DFFRX1 rxfifo_reg59 ( .D(n369), .CK(clk), .RN(rstb), .Q(\rxfifo[7][4] ), 
        .QN(n1352) );
  DFFRX1 rxfifo_reg60 ( .D(n370), .CK(clk), .RN(rstb), .Q(\rxfifo[7][5] ), 
        .QN(n1355) );
  DFFRX1 rxfifo_reg61 ( .D(n371), .CK(clk), .RN(rstb), .Q(\rxfifo[7][6] ), 
        .QN(n1358) );
  DFFRX1 rxfifo_reg62 ( .D(n372), .CK(clk), .RN(rstb), .Q(\rxfifo[7][7] ), 
        .QN(n1391) );
  DFFRX1 rxfifo_reg63 ( .D(n373), .CK(clk), .RN(rstb), .Q(\rxfifo[8][0] ), 
        .QN(n1437) );
  DFFRX1 rxfifo_reg64 ( .D(n374), .CK(clk), .RN(rstb), .Q(\rxfifo[8][1] ), 
        .QN(n1445) );
  DFFRX1 rxfifo_reg65 ( .D(n375), .CK(clk), .RN(rstb), .Q(\rxfifo[8][2] ), 
        .QN(n1451) );
  DFFRX1 rxfifo_reg66 ( .D(n376), .CK(clk), .RN(rstb), .Q(\rxfifo[8][3] ), 
        .QN(n1457) );
  DFFRX1 rxfifo_reg67 ( .D(n377), .CK(clk), .RN(rstb), .Q(\rxfifo[8][4] ), 
        .QN(n1460) );
  DFFRX1 rxfifo_reg68 ( .D(n378), .CK(clk), .RN(rstb), .Q(\rxfifo[8][5] ), 
        .QN(n1463) );
  DFFRX1 rxfifo_reg69 ( .D(n379), .CK(clk), .RN(rstb), .Q(\rxfifo[8][6] ), 
        .QN(n1469) );
  DFFRX1 rxfifo_reg70 ( .D(n380), .CK(clk), .RN(rstb), .Q(\rxfifo[8][7] ), 
        .QN(n1441) );
  DFFRX1 rxfifo_reg71 ( .D(n381), .CK(clk), .RN(rstb), .Q(\rxfifo[9][0] ), 
        .QN(n1584) );
  DFFRX1 rxfifo_reg72 ( .D(n382), .CK(clk), .RN(rstb), .Q(\rxfifo[9][1] ), 
        .QN(n1592) );
  DFFRX1 rxfifo_reg73 ( .D(n383), .CK(clk), .RN(rstb), .Q(\rxfifo[9][2] ), 
        .QN(n1598) );
  DFFRX1 rxfifo_reg74 ( .D(n384), .CK(clk), .RN(rstb), .Q(\rxfifo[9][3] ), 
        .QN(n1604) );
  DFFRX1 rxfifo_reg75 ( .D(n385), .CK(clk), .RN(rstb), .Q(\rxfifo[9][4] ), 
        .QN(n1607) );
  DFFRX1 rxfifo_reg76 ( .D(n386), .CK(clk), .RN(rstb), .Q(\rxfifo[9][5] ), 
        .QN(n1610) );
  DFFRX1 rxfifo_reg77 ( .D(n387), .CK(clk), .RN(rstb), .Q(\rxfifo[9][6] ), 
        .QN(n1616) );
  DFFRX1 rxfifo_reg78 ( .D(n388), .CK(clk), .RN(rstb), .Q(\rxfifo[9][7] ), 
        .QN(n1588) );
  DFFRX1 rxfifo_reg79 ( .D(n389), .CK(clk), .RN(rstb), .Q(\rxfifo[10][0] ), 
        .QN(n1547) );
  DFFRX1 rxfifo_reg80 ( .D(n390), .CK(clk), .RN(rstb), .Q(\rxfifo[10][1] ), 
        .QN(n1492) );
  DFFRX1 rxfifo_reg81 ( .D(n391), .CK(clk), .RN(rstb), .Q(\rxfifo[10][2] ), 
        .QN(n1495) );
  DFFRX1 rxfifo_reg82 ( .D(n392), .CK(clk), .RN(rstb), .Q(\rxfifo[10][3] ), 
        .QN(n1498) );
  DFFRX1 rxfifo_reg83 ( .D(n393), .CK(clk), .RN(rstb), .Q(\rxfifo[10][4] ), 
        .QN(n1501) );
  DFFRX1 rxfifo_reg84 ( .D(n394), .CK(clk), .RN(rstb), .Q(\rxfifo[10][5] ), 
        .QN(n1504) );
  DFFRX1 rxfifo_reg85 ( .D(n395), .CK(clk), .RN(rstb), .Q(\rxfifo[10][6] ), 
        .QN(n1507) );
  DFFRX1 rxfifo_reg86 ( .D(n396), .CK(clk), .RN(rstb), .Q(\rxfifo[10][7] ), 
        .QN(n1551) );
  DFFRX1 rxfifo_reg87 ( .D(n397), .CK(clk), .RN(rstb), .Q(\rxfifo[11][0] ), 
        .QN(n1400) );
  DFFRX1 rxfifo_reg88 ( .D(n398), .CK(clk), .RN(rstb), .Q(\rxfifo[11][1] ), 
        .QN(n1345) );
  DFFRX1 rxfifo_reg89 ( .D(n399), .CK(clk), .RN(rstb), .Q(\rxfifo[11][2] ), 
        .QN(n1348) );
  DFFRX1 rxfifo_reg90 ( .D(n400), .CK(clk), .RN(rstb), .Q(\rxfifo[11][3] ), 
        .QN(n1351) );
  DFFRX1 rxfifo_reg91 ( .D(n401), .CK(clk), .RN(rstb), .Q(\rxfifo[11][4] ), 
        .QN(n1354) );
  DFFRX1 rxfifo_reg92 ( .D(n402), .CK(clk), .RN(rstb), .Q(\rxfifo[11][5] ), 
        .QN(n1357) );
  DFFRX1 rxfifo_reg93 ( .D(n403), .CK(clk), .RN(rstb), .Q(\rxfifo[11][6] ), 
        .QN(n1360) );
  DFFRX1 rxfifo_reg94 ( .D(n404), .CK(clk), .RN(rstb), .Q(\rxfifo[11][7] ), 
        .QN(n1404) );
  DFFRX1 rxfifo_reg95 ( .D(n405), .CK(clk), .RN(rstb), .Q(\rxfifo[12][0] ), 
        .QN(n1407) );
  DFFRX1 rxfifo_reg96 ( .D(n406), .CK(clk), .RN(rstb), .Q(\rxfifo[12][1] ), 
        .QN(n1409) );
  DFFRX1 rxfifo_reg97 ( .D(n407), .CK(clk), .RN(rstb), .Q(\rxfifo[12][2] ), 
        .QN(n1411) );
  DFFRX1 rxfifo_reg98 ( .D(n408), .CK(clk), .RN(rstb), .Q(\rxfifo[12][3] ), 
        .QN(n1413) );
  DFFRX1 rxfifo_reg99 ( .D(n409), .CK(clk), .RN(rstb), .Q(\rxfifo[12][4] ), 
        .QN(n1415) );
  DFFRX1 rxfifo_reg100 ( .D(n410), .CK(clk), .RN(rstb), .Q(\rxfifo[12][5] ), 
        .QN(n1417) );
  DFFRX1 rxfifo_reg101 ( .D(n411), .CK(clk), .RN(rstb), .Q(\rxfifo[12][6] ), 
        .QN(n1419) );
  DFFRX1 rxfifo_reg102 ( .D(n412), .CK(clk), .RN(rstb), .Q(\rxfifo[12][7] ), 
        .QN(n1421) );
  DFFRX1 rxfifo_reg103 ( .D(n413), .CK(clk), .RN(rstb), .Q(\rxfifo[13][0] ), 
        .QN(n1554) );
  DFFRX1 rxfifo_reg104 ( .D(n414), .CK(clk), .RN(rstb), .Q(\rxfifo[13][1] ), 
        .QN(n1556) );
  DFFRX1 rxfifo_reg105 ( .D(n415), .CK(clk), .RN(rstb), .Q(\rxfifo[13][2] ), 
        .QN(n1558) );
  DFFRX1 rxfifo_reg106 ( .D(n416), .CK(clk), .RN(rstb), .Q(\rxfifo[13][3] ), 
        .QN(n1560) );
  DFFRX1 rxfifo_reg107 ( .D(n417), .CK(clk), .RN(rstb), .Q(\rxfifo[13][4] ), 
        .QN(n1562) );
  DFFRX1 rxfifo_reg108 ( .D(n418), .CK(clk), .RN(rstb), .Q(\rxfifo[13][5] ), 
        .QN(n1564) );
  DFFRX1 rxfifo_reg109 ( .D(n419), .CK(clk), .RN(rstb), .Q(\rxfifo[13][6] ), 
        .QN(n1566) );
  DFFRX1 rxfifo_reg110 ( .D(n420), .CK(clk), .RN(rstb), .Q(\rxfifo[13][7] ), 
        .QN(n1568) );
  DFFRX1 rxfifo_reg111 ( .D(n421), .CK(clk), .RN(rstb), .Q(\rxfifo[14][0] ), 
        .QN(n1517) );
  DFFRX1 rxfifo_reg112 ( .D(n422), .CK(clk), .RN(rstb), .Q(\rxfifo[14][1] ), 
        .QN(n1519) );
  DFFRX1 rxfifo_reg113 ( .D(n423), .CK(clk), .RN(rstb), .Q(\rxfifo[14][2] ), 
        .QN(n1521) );
  DFFRX1 rxfifo_reg114 ( .D(n424), .CK(clk), .RN(rstb), .Q(\rxfifo[14][3] ), 
        .QN(n1523) );
  DFFRX1 rxfifo_reg115 ( .D(n425), .CK(clk), .RN(rstb), .Q(\rxfifo[14][4] ), 
        .QN(n1525) );
  DFFRX1 rxfifo_reg116 ( .D(n426), .CK(clk), .RN(rstb), .Q(\rxfifo[14][5] ), 
        .QN(n1527) );
  DFFRX1 rxfifo_reg117 ( .D(n427), .CK(clk), .RN(rstb), .Q(\rxfifo[14][6] ), 
        .QN(n1529) );
  DFFRX1 rxfifo_reg118 ( .D(n428), .CK(clk), .RN(rstb), .Q(\rxfifo[14][7] ), 
        .QN(n1531) );
  DFFRX1 rxfifo_reg119 ( .D(n429), .CK(clk), .RN(rstb), .Q(\rxfifo[15][0] ), 
        .QN(n1370) );
  DFFRX1 rxfifo_reg120 ( .D(n430), .CK(clk), .RN(rstb), .Q(\rxfifo[15][1] ), 
        .QN(n1372) );
  DFFRX1 rxfifo_reg121 ( .D(n431), .CK(clk), .RN(rstb), .Q(\rxfifo[15][2] ), 
        .QN(n1374) );
  DFFRX1 rxfifo_reg122 ( .D(n432), .CK(clk), .RN(rstb), .Q(\rxfifo[15][3] ), 
        .QN(n1376) );
  DFFRX1 rxfifo_reg123 ( .D(n433), .CK(clk), .RN(rstb), .Q(\rxfifo[15][4] ), 
        .QN(n1378) );
  DFFRX1 rxfifo_reg124 ( .D(n434), .CK(clk), .RN(rstb), .Q(\rxfifo[15][5] ), 
        .QN(n1380) );
  DFFRX1 rxfifo_reg125 ( .D(n435), .CK(clk), .RN(rstb), .Q(\rxfifo[15][6] ), 
        .QN(n1382) );
  DFFRX1 rxfifo_reg126 ( .D(n436), .CK(clk), .RN(rstb), .Q(\rxfifo[15][7] ), 
        .QN(n1384) );
  DFFRX1 rxfifo_reg127 ( .D(n437), .CK(clk), .RN(rstb), .Q(\rxfifo[16][0] ), 
        .QN(n1431) );
  DFFRX1 rxfifo_reg128 ( .D(n438), .CK(clk), .RN(rstb), .Q(\rxfifo[16][1] ), 
        .QN(n1447) );
  DFFRX1 rxfifo_reg129 ( .D(n439), .CK(clk), .RN(rstb), .Q(\rxfifo[16][2] ), 
        .QN(n1453) );
  DFFRX1 rxfifo_reg130 ( .D(n440), .CK(clk), .RN(rstb), .Q(\rxfifo[16][3] ), 
        .QN(n1432) );
  DFFRX1 rxfifo_reg131 ( .D(n441), .CK(clk), .RN(rstb), .Q(\rxfifo[16][4] ), 
        .QN(n1433) );
  DFFRX1 rxfifo_reg132 ( .D(n442), .CK(clk), .RN(rstb), .Q(\rxfifo[16][5] ), 
        .QN(n1465) );
  DFFRX1 rxfifo_reg133 ( .D(n4430), .CK(clk), .RN(rstb), .Q(\rxfifo[16][6] ), 
        .QN(n1434) );
  DFFRX1 rxfifo_reg134 ( .D(n444), .CK(clk), .RN(rstb), .Q(\rxfifo[16][7] ), 
        .QN(n1436) );
  DFFRX1 rxfifo_reg135 ( .D(n445), .CK(clk), .RN(rstb), .Q(\rxfifo[17][0] ), 
        .QN(n1578) );
  DFFRX1 rxfifo_reg136 ( .D(n446), .CK(clk), .RN(rstb), .Q(\rxfifo[17][1] ), 
        .QN(n1594) );
  DFFRX1 rxfifo_reg137 ( .D(n447), .CK(clk), .RN(rstb), .Q(\rxfifo[17][2] ), 
        .QN(n1600) );
  DFFRX1 rxfifo_reg138 ( .D(n448), .CK(clk), .RN(rstb), .Q(\rxfifo[17][3] ), 
        .QN(n1579) );
  DFFRX1 rxfifo_reg139 ( .D(n449), .CK(clk), .RN(rstb), .Q(\rxfifo[17][4] ), 
        .QN(n1580) );
  DFFRX1 rxfifo_reg140 ( .D(n450), .CK(clk), .RN(rstb), .Q(\rxfifo[17][5] ), 
        .QN(n1612) );
  DFFRX1 rxfifo_reg141 ( .D(n451), .CK(clk), .RN(rstb), .Q(\rxfifo[17][6] ), 
        .QN(n1581) );
  DFFRX1 rxfifo_reg142 ( .D(n452), .CK(clk), .RN(rstb), .Q(\rxfifo[17][7] ), 
        .QN(n1583) );
  DFFRX1 rxfifo_reg143 ( .D(n453), .CK(clk), .RN(rstb), .Q(\rxfifo[18][0] ), 
        .QN(n1541) );
  DFFRX1 rxfifo_reg144 ( .D(n454), .CK(clk), .RN(rstb), .Q(\rxfifo[18][1] ), 
        .QN(n1509) );
  DFFRX1 rxfifo_reg145 ( .D(n455), .CK(clk), .RN(rstb), .Q(\rxfifo[18][2] ), 
        .QN(n1512) );
  DFFRX1 rxfifo_reg146 ( .D(n456), .CK(clk), .RN(rstb), .Q(\rxfifo[18][3] ), 
        .QN(n1542) );
  DFFRX1 rxfifo_reg147 ( .D(n457), .CK(clk), .RN(rstb), .Q(\rxfifo[18][4] ), 
        .QN(n1543) );
  DFFRX1 rxfifo_reg148 ( .D(n458), .CK(clk), .RN(rstb), .Q(\rxfifo[18][5] ), 
        .QN(n1515) );
  DFFRX1 rxfifo_reg149 ( .D(n459), .CK(clk), .RN(rstb), .Q(\rxfifo[18][6] ), 
        .QN(n1544) );
  DFFRX1 rxfifo_reg150 ( .D(n460), .CK(clk), .RN(rstb), .Q(\rxfifo[18][7] ), 
        .QN(n1546) );
  DFFRX1 rxfifo_reg151 ( .D(n461), .CK(clk), .RN(rstb), .Q(\rxfifo[19][0] ), 
        .QN(n1394) );
  DFFRX1 rxfifo_reg152 ( .D(n462), .CK(clk), .RN(rstb), .Q(\rxfifo[19][1] ), 
        .QN(n1362) );
  DFFRX1 rxfifo_reg153 ( .D(n463), .CK(clk), .RN(rstb), .Q(\rxfifo[19][2] ), 
        .QN(n1365) );
  DFFRX1 rxfifo_reg154 ( .D(n464), .CK(clk), .RN(rstb), .Q(\rxfifo[19][3] ), 
        .QN(n1395) );
  DFFRX1 rxfifo_reg155 ( .D(n465), .CK(clk), .RN(rstb), .Q(\rxfifo[19][4] ), 
        .QN(n1396) );
  DFFRX1 rxfifo_reg156 ( .D(n466), .CK(clk), .RN(rstb), .Q(\rxfifo[19][5] ), 
        .QN(n1368) );
  DFFRX1 rxfifo_reg157 ( .D(n467), .CK(clk), .RN(rstb), .Q(\rxfifo[19][6] ), 
        .QN(n1397) );
  DFFRX1 rxfifo_reg158 ( .D(n468), .CK(clk), .RN(rstb), .Q(\rxfifo[19][7] ), 
        .QN(n1399) );
  DFFRX1 rxfifo_reg159 ( .D(n469), .CK(clk), .RN(rstb), .Q(\rxfifo[20][0] ), 
        .QN(n1424) );
  DFFRX1 rxfifo_reg160 ( .D(n470), .CK(clk), .RN(rstb), .Q(\rxfifo[20][1] ), 
        .QN(n1446) );
  DFFRX1 rxfifo_reg161 ( .D(n471), .CK(clk), .RN(rstb), .Q(\rxfifo[20][2] ), 
        .QN(n1452) );
  DFFRX1 rxfifo_reg162 ( .D(n472), .CK(clk), .RN(rstb), .Q(\rxfifo[20][3] ), 
        .QN(n1425) );
  DFFRX1 rxfifo_reg163 ( .D(n473), .CK(clk), .RN(rstb), .Q(\rxfifo[20][4] ), 
        .QN(n1426) );
  DFFRX1 rxfifo_reg164 ( .D(n474), .CK(clk), .RN(rstb), .Q(\rxfifo[20][5] ), 
        .QN(n1464) );
  DFFRX1 rxfifo_reg165 ( .D(n475), .CK(clk), .RN(rstb), .Q(\rxfifo[20][6] ), 
        .QN(n1427) );
  DFFRX1 rxfifo_reg166 ( .D(n476), .CK(clk), .RN(rstb), .Q(\rxfifo[20][7] ), 
        .QN(n1429) );
  DFFRX1 rxfifo_reg167 ( .D(n477), .CK(clk), .RN(rstb), .Q(\rxfifo[21][0] ), 
        .QN(n1571) );
  DFFRX1 rxfifo_reg168 ( .D(n478), .CK(clk), .RN(rstb), .Q(\rxfifo[21][1] ), 
        .QN(n1593) );
  DFFRX1 rxfifo_reg169 ( .D(n479), .CK(clk), .RN(rstb), .Q(\rxfifo[21][2] ), 
        .QN(n1599) );
  DFFRX1 rxfifo_reg170 ( .D(n480), .CK(clk), .RN(rstb), .Q(\rxfifo[21][3] ), 
        .QN(n1572) );
  DFFRX1 rxfifo_reg171 ( .D(n481), .CK(clk), .RN(rstb), .Q(\rxfifo[21][4] ), 
        .QN(n1573) );
  DFFRX1 rxfifo_reg172 ( .D(n482), .CK(clk), .RN(rstb), .Q(\rxfifo[21][5] ), 
        .QN(n1611) );
  DFFRX1 rxfifo_reg173 ( .D(n483), .CK(clk), .RN(rstb), .Q(\rxfifo[21][6] ), 
        .QN(n1574) );
  DFFRX1 rxfifo_reg174 ( .D(n484), .CK(clk), .RN(rstb), .Q(\rxfifo[21][7] ), 
        .QN(n1576) );
  DFFRX1 rxfifo_reg175 ( .D(n485), .CK(clk), .RN(rstb), .Q(\rxfifo[22][0] ), 
        .QN(n1534) );
  DFFRX1 rxfifo_reg176 ( .D(n486), .CK(clk), .RN(rstb), .Q(\rxfifo[22][1] ), 
        .QN(n1508) );
  DFFRX1 rxfifo_reg177 ( .D(n487), .CK(clk), .RN(rstb), .Q(\rxfifo[22][2] ), 
        .QN(n1511) );
  DFFRX1 rxfifo_reg178 ( .D(n488), .CK(clk), .RN(rstb), .Q(\rxfifo[22][3] ), 
        .QN(n1535) );
  DFFRX1 rxfifo_reg179 ( .D(n489), .CK(clk), .RN(rstb), .Q(\rxfifo[22][4] ), 
        .QN(n1536) );
  DFFRX1 rxfifo_reg180 ( .D(n490), .CK(clk), .RN(rstb), .Q(\rxfifo[22][5] ), 
        .QN(n1514) );
  DFFRX1 rxfifo_reg181 ( .D(n491), .CK(clk), .RN(rstb), .Q(\rxfifo[22][6] ), 
        .QN(n1537) );
  DFFRX1 rxfifo_reg182 ( .D(n492), .CK(clk), .RN(rstb), .Q(\rxfifo[22][7] ), 
        .QN(n1539) );
  DFFRX1 rxfifo_reg183 ( .D(n493), .CK(clk), .RN(rstb), .Q(\rxfifo[23][0] ), 
        .QN(n1387) );
  DFFRX1 rxfifo_reg184 ( .D(n494), .CK(clk), .RN(rstb), .Q(\rxfifo[23][1] ), 
        .QN(n1361) );
  DFFRX1 rxfifo_reg185 ( .D(n495), .CK(clk), .RN(rstb), .Q(\rxfifo[23][2] ), 
        .QN(n1364) );
  DFFRX1 rxfifo_reg186 ( .D(n496), .CK(clk), .RN(rstb), .Q(\rxfifo[23][3] ), 
        .QN(n1388) );
  DFFRX1 rxfifo_reg187 ( .D(n497), .CK(clk), .RN(rstb), .Q(\rxfifo[23][4] ), 
        .QN(n1389) );
  DFFRX1 rxfifo_reg188 ( .D(n498), .CK(clk), .RN(rstb), .Q(\rxfifo[23][5] ), 
        .QN(n1367) );
  DFFRX1 rxfifo_reg189 ( .D(n499), .CK(clk), .RN(rstb), .Q(\rxfifo[23][6] ), 
        .QN(n1390) );
  DFFRX1 rxfifo_reg190 ( .D(n500), .CK(clk), .RN(rstb), .Q(\rxfifo[23][7] ), 
        .QN(n1392) );
  DFFRX1 rxfifo_reg191 ( .D(n501), .CK(clk), .RN(rstb), .Q(\rxfifo[24][0] ), 
        .QN(n1442) );
  DFFRX1 rxfifo_reg192 ( .D(n502), .CK(clk), .RN(rstb), .Q(\rxfifo[24][1] ), 
        .QN(n1448) );
  DFFRX1 rxfifo_reg193 ( .D(n503), .CK(clk), .RN(rstb), .Q(\rxfifo[24][2] ), 
        .QN(n1454) );
  DFFRX1 rxfifo_reg194 ( .D(n504), .CK(clk), .RN(rstb), .Q(\rxfifo[24][3] ), 
        .QN(n1438) );
  DFFRX1 rxfifo_reg195 ( .D(n505), .CK(clk), .RN(rstb), .Q(\rxfifo[24][4] ), 
        .QN(n1439) );
  DFFRX1 rxfifo_reg196 ( .D(n506), .CK(clk), .RN(rstb), .Q(\rxfifo[24][5] ), 
        .QN(n1466) );
  DFFRX1 rxfifo_reg197 ( .D(n507), .CK(clk), .RN(rstb), .Q(\rxfifo[24][6] ), 
        .QN(n1440) );
  DFFRX1 rxfifo_reg198 ( .D(n508), .CK(clk), .RN(rstb), .Q(\rxfifo[24][7] ), 
        .QN(n1470) );
  DFFRX1 rxfifo_reg199 ( .D(n509), .CK(clk), .RN(rstb), .Q(\rxfifo[25][0] ), 
        .QN(n1589) );
  DFFRX1 rxfifo_reg200 ( .D(n510), .CK(clk), .RN(rstb), .Q(\rxfifo[25][1] ), 
        .QN(n1595) );
  DFFRX1 rxfifo_reg201 ( .D(n5110), .CK(clk), .RN(rstb), .Q(\rxfifo[25][2] ), 
        .QN(n1601) );
  DFFRX1 rxfifo_reg202 ( .D(n5120), .CK(clk), .RN(rstb), .Q(\rxfifo[25][3] ), 
        .QN(n1585) );
  DFFRX1 rxfifo_reg203 ( .D(n5130), .CK(clk), .RN(rstb), .Q(\rxfifo[25][4] ), 
        .QN(n1586) );
  DFFRX1 rxfifo_reg204 ( .D(n5140), .CK(clk), .RN(rstb), .Q(\rxfifo[25][5] ), 
        .QN(n1613) );
  DFFRX1 rxfifo_reg205 ( .D(n5150), .CK(clk), .RN(rstb), .Q(\rxfifo[25][6] ), 
        .QN(n1587) );
  DFFRX1 rxfifo_reg206 ( .D(n5160), .CK(clk), .RN(rstb), .Q(\rxfifo[25][7] ), 
        .QN(n1617) );
  DFFRX1 rxfifo_reg207 ( .D(n5170), .CK(clk), .RN(rstb), .Q(\rxfifo[26][0] ), 
        .QN(n1552) );
  DFFRX1 rxfifo_reg208 ( .D(n5180), .CK(clk), .RN(rstb), .Q(\rxfifo[26][1] ), 
        .QN(n1510) );
  DFFRX1 rxfifo_reg209 ( .D(n5190), .CK(clk), .RN(rstb), .Q(\rxfifo[26][2] ), 
        .QN(n1513) );
  DFFRX1 rxfifo_reg210 ( .D(n5200), .CK(clk), .RN(rstb), .Q(\rxfifo[26][3] ), 
        .QN(n1548) );
  DFFRX1 rxfifo_reg211 ( .D(n5210), .CK(clk), .RN(rstb), .Q(\rxfifo[26][4] ), 
        .QN(n1549) );
  DFFRX1 rxfifo_reg212 ( .D(n5220), .CK(clk), .RN(rstb), .Q(\rxfifo[26][5] ), 
        .QN(n1516) );
  DFFRX1 rxfifo_reg213 ( .D(n5230), .CK(clk), .RN(rstb), .Q(\rxfifo[26][6] ), 
        .QN(n1550) );
  DFFRX1 rxfifo_reg214 ( .D(n5240), .CK(clk), .RN(rstb), .Q(\rxfifo[26][7] ), 
        .QN(n1553) );
  DFFRX1 rxfifo_reg215 ( .D(n5250), .CK(clk), .RN(rstb), .Q(\rxfifo[27][0] ), 
        .QN(n1405) );
  DFFRX1 rxfifo_reg216 ( .D(n5260), .CK(clk), .RN(rstb), .Q(\rxfifo[27][1] ), 
        .QN(n1363) );
  DFFRX1 rxfifo_reg217 ( .D(n5270), .CK(clk), .RN(rstb), .Q(\rxfifo[27][2] ), 
        .QN(n1366) );
  DFFRX1 rxfifo_reg218 ( .D(n5280), .CK(clk), .RN(rstb), .Q(\rxfifo[27][3] ), 
        .QN(n1401) );
  DFFRX1 rxfifo_reg219 ( .D(n529), .CK(clk), .RN(rstb), .Q(\rxfifo[27][4] ), 
        .QN(n1402) );
  DFFRX1 rxfifo_reg220 ( .D(n530), .CK(clk), .RN(rstb), .Q(\rxfifo[27][5] ), 
        .QN(n1369) );
  DFFRX1 rxfifo_reg221 ( .D(n531), .CK(clk), .RN(rstb), .Q(\rxfifo[27][6] ), 
        .QN(n1403) );
  DFFRX1 rxfifo_reg222 ( .D(n532), .CK(clk), .RN(rstb), .Q(\rxfifo[27][7] ), 
        .QN(n1406) );
  DFFRX1 rxfifo_reg223 ( .D(n533), .CK(clk), .RN(rstb), .Q(\rxfifo[28][0] ), 
        .QN(n1408) );
  DFFRX1 rxfifo_reg224 ( .D(n534), .CK(clk), .RN(rstb), .Q(\rxfifo[28][1] ), 
        .QN(n1410) );
  DFFRX1 rxfifo_reg225 ( .D(n535), .CK(clk), .RN(rstb), .Q(\rxfifo[28][2] ), 
        .QN(n1412) );
  DFFRX1 rxfifo_reg226 ( .D(n536), .CK(clk), .RN(rstb), .Q(\rxfifo[28][3] ), 
        .QN(n1414) );
  DFFRX1 rxfifo_reg227 ( .D(n537), .CK(clk), .RN(rstb), .Q(\rxfifo[28][4] ), 
        .QN(n1416) );
  DFFRX1 rxfifo_reg228 ( .D(n538), .CK(clk), .RN(rstb), .Q(\rxfifo[28][5] ), 
        .QN(n1418) );
  DFFRX1 rxfifo_reg229 ( .D(n539), .CK(clk), .RN(rstb), .Q(\rxfifo[28][6] ), 
        .QN(n1420) );
  DFFRX1 rxfifo_reg230 ( .D(n540), .CK(clk), .RN(rstb), .Q(\rxfifo[28][7] ), 
        .QN(n1422) );
  DFFRX1 rxfifo_reg231 ( .D(n541), .CK(clk), .RN(rstb), .Q(\rxfifo[29][0] ), 
        .QN(n1555) );
  DFFRX1 rxfifo_reg232 ( .D(n542), .CK(clk), .RN(rstb), .Q(\rxfifo[29][1] ), 
        .QN(n1557) );
  DFFRX1 rxfifo_reg233 ( .D(n543), .CK(clk), .RN(rstb), .Q(\rxfifo[29][2] ), 
        .QN(n1559) );
  DFFRX1 rxfifo_reg234 ( .D(n544), .CK(clk), .RN(rstb), .Q(\rxfifo[29][3] ), 
        .QN(n1561) );
  DFFRX1 rxfifo_reg235 ( .D(n545), .CK(clk), .RN(rstb), .Q(\rxfifo[29][4] ), 
        .QN(n1563) );
  DFFRX1 rxfifo_reg236 ( .D(n546), .CK(clk), .RN(rstb), .Q(\rxfifo[29][5] ), 
        .QN(n1565) );
  DFFRX1 rxfifo_reg237 ( .D(n547), .CK(clk), .RN(rstb), .Q(\rxfifo[29][6] ), 
        .QN(n1567) );
  DFFRX1 rxfifo_reg238 ( .D(n548), .CK(clk), .RN(rstb), .Q(\rxfifo[29][7] ), 
        .QN(n1569) );
  DFFRX1 rxfifo_reg239 ( .D(n549), .CK(clk), .RN(rstb), .Q(\rxfifo[30][0] ), 
        .QN(n1518) );
  DFFRX1 rxfifo_reg240 ( .D(n550), .CK(clk), .RN(rstb), .Q(\rxfifo[30][1] ), 
        .QN(n1520) );
  DFFRX1 rxfifo_reg241 ( .D(n551), .CK(clk), .RN(rstb), .Q(\rxfifo[30][2] ), 
        .QN(n1522) );
  DFFRX1 rxfifo_reg242 ( .D(n552), .CK(clk), .RN(rstb), .Q(\rxfifo[30][3] ), 
        .QN(n1524) );
  DFFRX1 rxfifo_reg243 ( .D(n553), .CK(clk), .RN(rstb), .Q(\rxfifo[30][4] ), 
        .QN(n1526) );
  DFFRX1 rxfifo_reg244 ( .D(n554), .CK(clk), .RN(rstb), .Q(\rxfifo[30][5] ), 
        .QN(n1528) );
  DFFRX1 rxfifo_reg245 ( .D(n555), .CK(clk), .RN(rstb), .Q(\rxfifo[30][6] ), 
        .QN(n1530) );
  DFFRX1 rxfifo_reg246 ( .D(n556), .CK(clk), .RN(rstb), .Q(\rxfifo[30][7] ), 
        .QN(n1532) );
  DFFRX1 rxfifo_reg247 ( .D(n557), .CK(clk), .RN(rstb), .Q(\rxfifo[31][0] ), 
        .QN(n1371) );
  DFFRX1 rxfifo_reg248 ( .D(n558), .CK(clk), .RN(rstb), .Q(\rxfifo[31][1] ), 
        .QN(n1373) );
  DFFRX1 rxfifo_reg249 ( .D(n559), .CK(clk), .RN(rstb), .Q(\rxfifo[31][2] ), 
        .QN(n1375) );
  DFFRX1 rxfifo_reg250 ( .D(n560), .CK(clk), .RN(rstb), .Q(\rxfifo[31][3] ), 
        .QN(n1377) );
  DFFRX1 rxfifo_reg251 ( .D(n561), .CK(clk), .RN(rstb), .Q(\rxfifo[31][4] ), 
        .QN(n1379) );
  DFFRX1 rxfifo_reg252 ( .D(n562), .CK(clk), .RN(rstb), .Q(\rxfifo[31][5] ), 
        .QN(n1381) );
  DFFRX1 rxfifo_reg253 ( .D(n563), .CK(clk), .RN(rstb), .Q(\rxfifo[31][6] ), 
        .QN(n1383) );
  DFFRX1 rxfifo_reg254 ( .D(n564), .CK(clk), .RN(rstb), .Q(\rxfifo[31][7] ), 
        .QN(n1385) );
  DFFSX1 rstparityb_reg ( .D(n285), .CK(clk), .SN(rstb), .QN(n1339) );
  DFFRX1 rxsftreg_reg_1_ ( .D(n295), .CK(clk), .RN(rstb), .Q(rxsftreg[1]) );
  DFFRX1 rxsftreg_reg_2_ ( .D(n296), .CK(clk), .RN(rstb), .Q(rxsftreg[2]) );
  DFFRX1 rxsftreg_reg_3_ ( .D(n297), .CK(clk), .RN(rstb), .Q(rxsftreg[3]) );
  DFFRX1 rxsftreg_reg_4_ ( .D(n298), .CK(clk), .RN(rstb), .Q(rxsftreg[4]) );
  DFFRX1 rxsftreg_reg_5_ ( .D(n299), .CK(clk), .RN(rstb), .Q(rxsftreg[5]) );
  DFFRX1 rxsftreg_reg_6_ ( .D(n300), .CK(clk), .RN(rstb), .Q(rxsftreg[6]) );
  DFFRX1 rxsftreg_reg_7_ ( .D(n301), .CK(clk), .RN(rstb), .Q(rxsftreg[7]), 
        .QN(n1629) );
  DFFRX1 overrunerror_int_reg ( .D(n576), .CK(clk), .RN(rstb), .Q(overrunerror), .QN(n277) );
  DFFRX1 rxsftreg_reg_0_ ( .D(n294), .CK(clk), .RN(rstb), .Q(rxsftreg[0]) );
  DFFSX1 in_dly_reg_5_ ( .D(n308), .CK(clk), .SN(rstb), .Q(in_dly[5]) );
  DFFRX1 rxbusy_int_reg ( .D(n284), .CK(clk), .RN(rstb), .Q(rxbusy) );
endmodule


module RegBlk_3_5_0 ( PADDR, PENABLE, PSEL, PWDATA, PWRITE, bytereceivedb, clk, 
        fifodata_rx, frameerror, overrunerror, parityerror, rstb, rxbusy, 
        rxfifocnt, rxfifoempty, txbusy, txfifo_emptyb, txfifo_fillb, 
        txfifo_fullb, txfifocnt, PRDATA, baudx16clk, databit, fifodata_tx, 
        fifordb, fifowrb, int, loopbacken, parity, rxdmareq, stopbit, swrst, 
        txdmareq, uarten, frameerr_clear, parityerr_clear, overrunerr_clear );
  input [4:2] PADDR;
  input [31:0] PWDATA;
  input [7:0] fifodata_rx;
  input [5:0] rxfifocnt;
  input [5:0] txfifocnt;
  output [31:0] PRDATA;
  output [7:0] fifodata_tx;
  output [1:0] parity;
  input PENABLE, PSEL, PWRITE, bytereceivedb, clk, frameerror, overrunerror,
         parityerror, rstb, rxbusy, rxfifoempty, txbusy, txfifo_emptyb,
         txfifo_fillb, txfifo_fullb;
  output baudx16clk, databit, fifordb, fifowrb, int, loopbacken, rxdmareq,
         stopbit, swrst, txdmareq, uarten, frameerr_clear, parityerr_clear,
         overrunerr_clear;
  wire   n252, n253, n254, n255, n256, n257, n258, n259, reg_0x0000_30_,
         reg_0x0000_29_, reg_0x0000_27_, reg_0x0000_15_, reg_0x0000_7_,
         reg_0x0004_22_, reg_0x0004_7_, N49, N51, N52, N60, N61, N62,
         clkdivcnt_msb_dly, N90, N91, N92, N93, N94, N95, N96, N97, N98, N99,
         N100, N101, N102, N103, N104, N108, N112, N113, N114, N115, N116,
         N117, N118, N119, N120, N121, N122, N123, N124, N125, N126, N127,
         N128, N129, n10, n134, n135, n136, n137, n138, n139, n140, n141, n142,
         n143, n144, n145, n146, n147, n148, n149, n150, n151, n152, n153,
         n154, n155, n156, n157, n158, n159, n160, n161, n162, n163, n164,
         n165, n166, n167, n168, n169, n170, n171, n172, n173, n174, n175,
         n176, n177, n178, n179, n180, n181, n182, n183, n184, n185, n186,
         n187, n188, n189, n190, n191, n192, n193, n194, n195, n196, n197,
         n198, n199, n200, n201, n202, n203, n204, n205, n206, n207, n208,
         n209, n210, n211, n212, n213, n214, n215, n216, n217, n218, n219,
         n220, n221, n222, n223, n224, n225, n226, n227, n228, n229, n230,
         n231, n490, carry, carry0, carry1, carry2, carry3, carry4, carry5,
         carry6, carry7, carry8, carry9, carry10, carry11, carry12, carry_1_,
         n1101, n234, n311, n411, n510, n610, n710, n810, n910, n1011, n1111,
         n1211, n1311, n1411, carry_18_, carry_17_, carry_16_, carry_15_,
         carry_14_, carry_13_, carry_12_, carry_11_, carry_10_, carry_9_,
         carry_8_, carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_,
         n1100, n233, n310, n410, n5, n6, n7, n8, n9, n1010, n1110, n1210,
         n1310, n1410, n1510, n1610, n1710, n1810, n261, n262, n263, n265,
         n266, n267, n268, n271, n275, n276, n277, n278, n279, n280, n282,
         n283, n285, n286, n288, n290, n292, n293, n294, n295, n296, n297,
         n298, n299, n300, n303, n304, n305, n308, n309, n312, n315, n316,
         n317, n318, n319, n320, n321, n324, n325, n326, n329, n330, n331,
         n334, n335, n336, n338, n339, n340, n341, n345, n346, n351, n352,
         n353, n354, n356, n358, n359, n361, n362, n364, n365, n367, n368,
         n370, n371, n374, n377, n379, n380, n383, n384, n387, n388, n392,
         n393, n396, n397, n398, n399, n400, n401, n402, n403, n404, n405,
         n406, n407, n408, n409, n412, n413, n414, n415, n416, n417, n418,
         n419, n420, n421, n422, n423, n426, n427, n429, n430, n431, n432,
         n433, n434, n435, n436, n437, n438, n439, n440, n441, n442, n443,
         n444, n445, n446, n447, n448, n449, n450, n451, n452, n453, n454,
         n455, n456, n457, n458, n459, n460, n461, n462, n463, n464, n465,
         n466, n467, n468, n469, n470, n471, n472, n473, n474, n475, n476,
         n477, n478, n479, n481, n482, n483, n484, n485, n486, n487, n488;
  wire   [5:0] txwaterlevel_int;
  wire   [5:0] rxwaterlevel_int;
  wire   [15:0] clkdiv;
  wire   [15:0] clkdivcnt;
  wire   [19:0] timeoutcnt;
  wire   [19:0] timeoutcnt_int;
  assign PRDATA[20] = 1'b0;
  assign PRDATA[21] = 1'b0;
  assign fifodata_tx[7] = n252;
  assign n252 = PWDATA[7];
  assign fifodata_tx[6] = n253;
  assign n253 = PWDATA[6];
  assign fifodata_tx[5] = n254;
  assign n254 = PWDATA[5];
  assign fifodata_tx[4] = n255;
  assign n255 = PWDATA[4];
  assign fifodata_tx[3] = n256;
  assign n256 = PWDATA[3];
  assign fifodata_tx[2] = n257;
  assign n257 = PWDATA[2];
  assign fifodata_tx[1] = n258;
  assign n258 = PWDATA[1];
  assign fifodata_tx[0] = n259;
  assign n259 = PWDATA[0];

  AHHCONX2 U1_1_1 ( .A(timeoutcnt_int[1]), .CI(timeoutcnt_int[0]), .S(N112), 
        .CON(n1810) );
  AHHCONX2 U1_1_2 ( .A(timeoutcnt_int[2]), .CI(carry_2_), .S(N113), .CON(n1710) );
  AHHCONX2 U1_1_3 ( .A(timeoutcnt_int[3]), .CI(carry_3_), .S(N114), .CON(n1610) );
  AHHCONX2 U1_1_4 ( .A(timeoutcnt_int[4]), .CI(carry_4_), .S(N115), .CON(n1510) );
  AHHCONX2 U1_1_5 ( .A(timeoutcnt_int[5]), .CI(carry_5_), .S(N116), .CON(n1410) );
  AHHCONX2 U1_1_6 ( .A(timeoutcnt_int[6]), .CI(carry_6_), .S(N117), .CON(n1310) );
  AHHCONX2 U1_1_7 ( .A(timeoutcnt_int[7]), .CI(carry_7_), .S(N118), .CON(n1210) );
  AHHCONX2 U1_1_8 ( .A(timeoutcnt_int[8]), .CI(carry_8_), .S(N119), .CON(n1110) );
  AHHCONX2 U1_1_9 ( .A(timeoutcnt_int[9]), .CI(carry_9_), .S(N120), .CON(n1010) );
  AHHCONX2 U1_1_10 ( .A(timeoutcnt_int[10]), .CI(carry_10_), .S(N121), .CON(n9) );
  AHHCONX2 U1_1_11 ( .A(timeoutcnt_int[11]), .CI(carry_11_), .S(N122), .CON(n8) );
  AHHCONX2 U1_1_12 ( .A(timeoutcnt_int[12]), .CI(carry_12_), .S(N123), .CON(n7) );
  AHHCONX2 U1_1_13 ( .A(timeoutcnt_int[13]), .CI(carry_13_), .S(N124), .CON(n6) );
  AHHCONX2 U1_1_14 ( .A(timeoutcnt_int[14]), .CI(carry_14_), .S(N125), .CON(n5) );
  AHHCONX2 U1_1_15 ( .A(timeoutcnt_int[15]), .CI(carry_15_), .S(N126), .CON(
        n410) );
  AHHCONX2 U1_1_16 ( .A(timeoutcnt_int[16]), .CI(carry_16_), .S(N127), .CON(
        n310) );
  AHHCONX2 U1_1_17 ( .A(timeoutcnt_int[17]), .CI(carry_17_), .S(N128), .CON(
        n233) );
  AHHCONX2 U1_1_18 ( .A(timeoutcnt_int[18]), .CI(carry_18_), .S(N129), .CON(
        n1100) );
  DFFRX1 databit_int_reg ( .D(n217), .CK(clk), .RN(rstb), .Q(databit) );
  DFFRX1 swrst_int_reg ( .D(N49), .CK(clk), .RN(rstb), .Q(swrst), .QN(n449) );
  INVX1 U618 ( .A(n275), .Y(n276) );
  INVX1 U619 ( .A(n486), .Y(n267) );
  INVX1 U620 ( .A(n286), .Y(n278) );
  INVX1 U621 ( .A(n280), .Y(n283) );
  INVX1 U622 ( .A(txfifocnt[1]), .Y(n340) );
  NAND2BX1 U623 ( .AN(n334), .B(n335), .Y(fifowrb) );
  NAND2BX1 U624 ( .AN(n483), .B(n476), .Y(n275) );
  NAND2BX1 U625 ( .AN(n483), .B(n476), .Y(n485) );
  NAND2BX1 U626 ( .AN(n483), .B(n476), .Y(n484) );
  INVX1 U627 ( .A(n262), .Y(n263) );
  BUFX2 U628 ( .A(n266), .Y(n486) );
  NAND2BX1 U629 ( .AN(n268), .B(n476), .Y(n266) );
  INVX1 U630 ( .A(n482), .Y(n265) );
  DFFRX1 baudx16clk_int_reg ( .D(n175), .CK(clk), .RN(rstb), .Q(baudx16clk), 
        .QN(n431) );
  DFFRX1 parity_int_reg_1_ ( .D(n219), .CK(clk), .RN(rstb), .Q(parity[1]) );
  NAND2BX1 U631 ( .AN(n285), .B(n431), .Y(n286) );
  NAND2BX1 U632 ( .AN(n285), .B(n286), .Y(n280) );
  INVX1 U633 ( .A(n403), .Y(n356) );
  OAI31X1 U634 ( .A0(n404), .A1(n405), .A2(n406), .B0(n407), .Y(n403) );
  INVX1 U635 ( .A(n408), .Y(n406) );
  AOI222X1 U636 ( .A0(n409), .A1(n412), .B0(rxfifocnt[3]), .B1(n454), .C0(
        rxfifocnt[2]), .C1(n438), .Y(n404) );
  INVX1 U637 ( .A(rxfifocnt[4]), .Y(n361) );
  INVX1 U638 ( .A(txfifocnt[4]), .Y(n383) );
  OA22X1 U639 ( .A0(rxfifocnt[1]), .A1(n456), .B0(rxfifocnt[2]), .B1(n438), 
        .Y(n409) );
  INVX1 U640 ( .A(txfifocnt[3]), .Y(n387) );
  AO22X1 U641 ( .A0(txfifocnt[3]), .A1(n441), .B0(txfifocnt[4]), .B1(n458), 
        .Y(n417) );
  INVX1 U642 ( .A(txfifocnt[2]), .Y(n392) );
  INVX1 U643 ( .A(rxfifocnt[3]), .Y(n364) );
  OAI211X1 U644 ( .A0(txfifocnt[1]), .A1(n440), .B0(txfifocnt[0]), .C0(n457), 
        .Y(n422) );
  INVX1 U645 ( .A(n268), .Y(n353) );
  INVX1 U646 ( .A(PRDATA[28]), .Y(n339) );
  INVX1 U647 ( .A(n261), .Y(txdmareq) );
  INVX1 U648 ( .A(n483), .Y(n352) );
  INVX1 U649 ( .A(n402), .Y(n335) );
  NAND3BX1 U650 ( .AN(PADDR[4]), .B(PADDR[2]), .C(n476), .Y(n402) );
  AND3X2 U651 ( .A(PENABLE), .B(PSEL), .C(PWRITE), .Y(n476) );
  NAND3BX1 U652 ( .AN(PADDR[4]), .B(n399), .C(PADDR[3]), .Y(n268) );
  NAND4BX1 U653 ( .AN(PWRITE), .B(PENABLE), .C(PSEL), .D(n336), .Y(fifordb) );
  NAND3BX1 U654 ( .AN(PWDATA[28]), .B(n476), .C(n265), .Y(n262) );
  NAND3BX1 U655 ( .AN(PWDATA[28]), .B(n476), .C(n265), .Y(n488) );
  NAND3BX1 U656 ( .AN(PWDATA[28]), .B(n476), .C(n265), .Y(n487) );
  INVX1 U657 ( .A(PADDR[2]), .Y(n399) );
  NAND2BX1 U658 ( .AN(PADDR[3]), .B(n335), .Y(n401) );
  INVX1 U659 ( .A(PADDR[3]), .Y(n334) );
  BUFX2 U660 ( .A(n338), .Y(n482) );
  NAND3BX1 U661 ( .AN(PADDR[4]), .B(n334), .C(n399), .Y(n338) );
  NOR3BX1 U662 ( .AN(n476), .B(n482), .C(n423), .Y(N49) );
  INVX1 U663 ( .A(PWDATA[28]), .Y(n423) );
  BUFX2 U664 ( .A(n277), .Y(n483) );
  NAND3BX1 U665 ( .AN(PADDR[3]), .B(PADDR[2]), .C(PADDR[4]), .Y(n277) );
  NOR2BX1 U666 ( .AN(PWDATA[24]), .B(n401), .Y(N60) );
  NOR2BX1 U667 ( .AN(PWDATA[25]), .B(n401), .Y(N61) );
  NOR2BX1 U668 ( .AN(PWDATA[23]), .B(n401), .Y(N62) );
  INVX1 U669 ( .A(n398), .Y(n336) );
  NAND3BX1 U670 ( .AN(PADDR[3]), .B(n399), .C(PADDR[4]), .Y(n398) );
  AO22X1 U671 ( .A0(timeoutcnt[16]), .A1(n484), .B0(PWDATA[16]), .B1(n276), 
        .Y(n171) );
  AO22X1 U672 ( .A0(timeoutcnt[17]), .A1(n484), .B0(PWDATA[17]), .B1(n276), 
        .Y(n172) );
  AO22X1 U673 ( .A0(timeoutcnt[18]), .A1(n485), .B0(PWDATA[18]), .B1(n276), 
        .Y(n173) );
  AO22X1 U674 ( .A0(timeoutcnt[19]), .A1(n484), .B0(PWDATA[19]), .B1(n276), 
        .Y(n174) );
  AO22X1 U675 ( .A0(clkdiv[6]), .A1(n486), .B0(n253), .B1(n267), .Y(n199) );
  AO22X1 U676 ( .A0(clkdiv[14]), .A1(n486), .B0(PWDATA[14]), .B1(n267), .Y(
        n207) );
  AO22X1 U677 ( .A0(txwaterlevel_int[0]), .A1(n488), .B0(PWDATA[8]), .B1(n263), 
        .Y(n209) );
  AO22X1 U678 ( .A0(txwaterlevel_int[1]), .A1(n487), .B0(PWDATA[9]), .B1(n263), 
        .Y(n210) );
  AO22X1 U679 ( .A0(txwaterlevel_int[2]), .A1(n262), .B0(PWDATA[10]), .B1(n263), .Y(n211) );
  AO22X1 U680 ( .A0(txwaterlevel_int[3]), .A1(n488), .B0(PWDATA[11]), .B1(n263), .Y(n212) );
  AO22X1 U681 ( .A0(txwaterlevel_int[4]), .A1(n487), .B0(PWDATA[12]), .B1(n263), .Y(n213) );
  AO22X1 U682 ( .A0(txwaterlevel_int[5]), .A1(n262), .B0(PWDATA[13]), .B1(n263), .Y(n214) );
  AO22X1 U683 ( .A0(loopbacken), .A1(n488), .B0(PWDATA[22]), .B1(n263), .Y(
        n215) );
  AO22X1 U684 ( .A0(stopbit), .A1(n487), .B0(PWDATA[23]), .B1(n263), .Y(n216)
         );
  AO22X1 U685 ( .A0(databit), .A1(n262), .B0(PWDATA[24]), .B1(n263), .Y(n217)
         );
  AO22X1 U686 ( .A0(parity[0]), .A1(n488), .B0(PWDATA[25]), .B1(n263), .Y(n218) );
  AO22X1 U687 ( .A0(parity[1]), .A1(n487), .B0(PWDATA[26]), .B1(n263), .Y(n219) );
  AO22X1 U688 ( .A0(reg_0x0000_27_), .A1(n488), .B0(PWDATA[27]), .B1(n263), 
        .Y(n220) );
  AO22X1 U689 ( .A0(reg_0x0000_29_), .A1(n488), .B0(PWDATA[29]), .B1(n263), 
        .Y(n221) );
  AO22X1 U690 ( .A0(reg_0x0000_30_), .A1(n487), .B0(PWDATA[30]), .B1(n263), 
        .Y(n222) );
  AO22X1 U691 ( .A0(n490), .A1(n487), .B0(PWDATA[31]), .B1(n263), .Y(n223) );
  AO22X1 U692 ( .A0(reg_0x0000_7_), .A1(n488), .B0(n252), .B1(n263), .Y(n224)
         );
  AO22X1 U693 ( .A0(reg_0x0000_15_), .A1(n487), .B0(PWDATA[15]), .B1(n263), 
        .Y(n225) );
  AO22X1 U694 ( .A0(rxwaterlevel_int[0]), .A1(n488), .B0(n259), .B1(n263), .Y(
        n226) );
  AO22X1 U695 ( .A0(rxwaterlevel_int[1]), .A1(n488), .B0(n258), .B1(n263), .Y(
        n227) );
  AO22X1 U696 ( .A0(rxwaterlevel_int[2]), .A1(n487), .B0(n257), .B1(n263), .Y(
        n228) );
  AO22X1 U697 ( .A0(rxwaterlevel_int[3]), .A1(n487), .B0(n256), .B1(n263), .Y(
        n229) );
  AO22X1 U698 ( .A0(rxwaterlevel_int[4]), .A1(n488), .B0(n255), .B1(n263), .Y(
        n230) );
  AO22X1 U699 ( .A0(rxwaterlevel_int[5]), .A1(n487), .B0(n254), .B1(n263), .Y(
        n231) );
  AO22X1 U700 ( .A0(timeoutcnt[0]), .A1(n485), .B0(n276), .B1(n259), .Y(n155)
         );
  AO22X1 U701 ( .A0(timeoutcnt[1]), .A1(n484), .B0(n276), .B1(n258), .Y(n156)
         );
  AO22X1 U702 ( .A0(timeoutcnt[2]), .A1(n275), .B0(n276), .B1(n257), .Y(n157)
         );
  AO22X1 U703 ( .A0(timeoutcnt[3]), .A1(n485), .B0(n276), .B1(n256), .Y(n158)
         );
  AO22X1 U704 ( .A0(timeoutcnt[4]), .A1(n484), .B0(n276), .B1(n255), .Y(n159)
         );
  AO22X1 U705 ( .A0(timeoutcnt[5]), .A1(n275), .B0(n276), .B1(n254), .Y(n160)
         );
  AO22X1 U706 ( .A0(timeoutcnt[6]), .A1(n485), .B0(n276), .B1(n253), .Y(n161)
         );
  AO22X1 U707 ( .A0(timeoutcnt[7]), .A1(n484), .B0(n276), .B1(n252), .Y(n162)
         );
  AO22X1 U708 ( .A0(timeoutcnt[8]), .A1(n485), .B0(n276), .B1(PWDATA[8]), .Y(
        n163) );
  AO22X1 U709 ( .A0(timeoutcnt[9]), .A1(n485), .B0(n276), .B1(PWDATA[9]), .Y(
        n164) );
  AO22X1 U710 ( .A0(timeoutcnt[10]), .A1(n484), .B0(n276), .B1(PWDATA[10]), 
        .Y(n165) );
  AO22X1 U711 ( .A0(timeoutcnt[11]), .A1(n484), .B0(n276), .B1(PWDATA[11]), 
        .Y(n166) );
  AO22X1 U712 ( .A0(timeoutcnt[12]), .A1(n485), .B0(n276), .B1(PWDATA[12]), 
        .Y(n167) );
  AO22X1 U713 ( .A0(timeoutcnt[13]), .A1(n484), .B0(n276), .B1(PWDATA[13]), 
        .Y(n168) );
  AO22X1 U714 ( .A0(timeoutcnt[14]), .A1(n485), .B0(n276), .B1(PWDATA[14]), 
        .Y(n169) );
  AO22X1 U715 ( .A0(timeoutcnt[15]), .A1(n485), .B0(n276), .B1(PWDATA[15]), 
        .Y(n170) );
  AO22X1 U716 ( .A0(clkdiv[0]), .A1(n486), .B0(n267), .B1(n259), .Y(n193) );
  AO22X1 U717 ( .A0(clkdiv[1]), .A1(n486), .B0(n267), .B1(n258), .Y(n194) );
  AO22X1 U718 ( .A0(clkdiv[2]), .A1(n486), .B0(n267), .B1(n257), .Y(n195) );
  AO22X1 U719 ( .A0(clkdiv[3]), .A1(n486), .B0(n267), .B1(n256), .Y(n196) );
  AO22X1 U720 ( .A0(clkdiv[4]), .A1(n486), .B0(n267), .B1(n255), .Y(n197) );
  AO22X1 U721 ( .A0(clkdiv[5]), .A1(n486), .B0(n267), .B1(n254), .Y(n198) );
  AO22X1 U722 ( .A0(clkdiv[7]), .A1(n486), .B0(n267), .B1(n252), .Y(n200) );
  AO22X1 U723 ( .A0(clkdiv[8]), .A1(n486), .B0(n267), .B1(PWDATA[8]), .Y(n201)
         );
  AO22X1 U724 ( .A0(clkdiv[9]), .A1(n486), .B0(n267), .B1(PWDATA[9]), .Y(n202)
         );
  AO22X1 U725 ( .A0(clkdiv[10]), .A1(n486), .B0(n267), .B1(PWDATA[10]), .Y(
        n203) );
  AO22X1 U726 ( .A0(clkdiv[11]), .A1(n486), .B0(n267), .B1(PWDATA[11]), .Y(
        n204) );
  AO22X1 U727 ( .A0(clkdiv[12]), .A1(n486), .B0(n267), .B1(PWDATA[12]), .Y(
        n205) );
  AO22X1 U728 ( .A0(clkdiv[13]), .A1(n486), .B0(n267), .B1(PWDATA[13]), .Y(
        n206) );
  AO22X1 U729 ( .A0(clkdiv[15]), .A1(n486), .B0(n267), .B1(PWDATA[15]), .Y(
        n208) );
  INVX1 U730 ( .A(n233), .Y(carry_18_) );
  INVX1 U731 ( .A(n1810), .Y(carry_2_) );
  INVX1 U732 ( .A(n1710), .Y(carry_3_) );
  INVX1 U733 ( .A(n1610), .Y(carry_4_) );
  INVX1 U734 ( .A(n1510), .Y(carry_5_) );
  INVX1 U735 ( .A(n1410), .Y(carry_6_) );
  INVX1 U736 ( .A(n1310), .Y(carry_7_) );
  INVX1 U737 ( .A(n1210), .Y(carry_8_) );
  INVX1 U738 ( .A(n1110), .Y(carry_9_) );
  INVX1 U739 ( .A(n9), .Y(carry_11_) );
  INVX1 U740 ( .A(n7), .Y(carry_13_) );
  INVX1 U741 ( .A(n5), .Y(carry_15_) );
  INVX1 U742 ( .A(n310), .Y(carry_17_) );
  INVX1 U743 ( .A(n1010), .Y(carry_10_) );
  INVX1 U744 ( .A(n8), .Y(carry_12_) );
  INVX1 U745 ( .A(n6), .Y(carry_14_) );
  INVX1 U746 ( .A(n410), .Y(carry_16_) );
  AO21X1 U747 ( .A0(n278), .A1(timeoutcnt_int[19]), .B0(n279), .Y(n154) );
  OAI33X1 U748 ( .A0(n280), .A1(n478), .A2(n282), .B0(n280), .B1(
        timeoutcnt_int[19]), .B2(n1100), .Y(n279) );
  INVX1 U749 ( .A(n1100), .Y(n282) );
  AFHCONX2 U1_1 ( .A(clkdivcnt[1]), .B(clkdiv[1]), .CI(carry_1_), .S(N90), 
        .CON(n1411) );
  NOR2BX1 U750 ( .AN(clkdivcnt[0]), .B(n448), .Y(carry_1_) );
  AFHCONX2 U1_2 ( .A(clkdivcnt[2]), .B(clkdiv[2]), .CI(carry12), .S(N91), 
        .CON(n1311) );
  INVX1 U751 ( .A(n1411), .Y(carry12) );
  AFHCONX2 U1_3 ( .A(clkdivcnt[3]), .B(clkdiv[3]), .CI(carry11), .S(N92), 
        .CON(n1211) );
  INVX1 U752 ( .A(n1311), .Y(carry11) );
  AFHCONX2 U1_4 ( .A(clkdivcnt[4]), .B(clkdiv[4]), .CI(carry10), .S(N93), 
        .CON(n1111) );
  INVX1 U753 ( .A(n1211), .Y(carry10) );
  AFHCONX2 U1_5 ( .A(clkdivcnt[5]), .B(clkdiv[5]), .CI(carry9), .S(N94), .CON(
        n1011) );
  INVX1 U754 ( .A(n1111), .Y(carry9) );
  AFHCONX2 U1_6 ( .A(clkdivcnt[6]), .B(clkdiv[6]), .CI(carry8), .S(N95), .CON(
        n910) );
  INVX1 U755 ( .A(n1011), .Y(carry8) );
  AFHCONX2 U1_7 ( .A(clkdivcnt[7]), .B(clkdiv[7]), .CI(carry7), .S(N96), .CON(
        n810) );
  INVX1 U756 ( .A(n910), .Y(carry7) );
  AFHCONX2 U1_8 ( .A(clkdivcnt[8]), .B(clkdiv[8]), .CI(carry6), .S(N97), .CON(
        n710) );
  INVX1 U757 ( .A(n810), .Y(carry6) );
  AFHCONX2 U1_9 ( .A(clkdivcnt[9]), .B(clkdiv[9]), .CI(carry5), .S(N98), .CON(
        n610) );
  INVX1 U758 ( .A(n710), .Y(carry5) );
  AFHCONX2 U1_10 ( .A(clkdivcnt[10]), .B(clkdiv[10]), .CI(carry4), .S(N99), 
        .CON(n510) );
  INVX1 U759 ( .A(n610), .Y(carry4) );
  AFHCONX2 U1_11 ( .A(clkdivcnt[11]), .B(clkdiv[11]), .CI(carry3), .S(N100), 
        .CON(n411) );
  INVX1 U760 ( .A(n510), .Y(carry3) );
  AFHCONX2 U1_12 ( .A(clkdivcnt[12]), .B(clkdiv[12]), .CI(carry2), .S(N101), 
        .CON(n311) );
  INVX1 U761 ( .A(n411), .Y(carry2) );
  AFHCONX2 U1_13 ( .A(clkdivcnt[13]), .B(clkdiv[13]), .CI(carry1), .S(N102), 
        .CON(n234) );
  INVX1 U762 ( .A(n311), .Y(carry1) );
  AFHCONX2 U1_14 ( .A(clkdivcnt[14]), .B(clkdiv[14]), .CI(carry0), .S(N103), 
        .CON(n1101) );
  INVX1 U763 ( .A(n234), .Y(carry0) );
  AO22X1 U764 ( .A0(clkdivcnt[13]), .A1(n437), .B0(N102), .B1(uarten), .Y(n189) );
  AO22X1 U765 ( .A0(clkdivcnt[14]), .A1(n437), .B0(N103), .B1(uarten), .Y(n190) );
  AO22X1 U766 ( .A0(clkdivcnt[15]), .A1(n437), .B0(N104), .B1(uarten), .Y(n191) );
  XOR3X1 U1_15 ( .A(clkdivcnt[15]), .B(clkdiv[15]), .C(carry), .Y(N104) );
  INVX1 U767 ( .A(n1101), .Y(carry) );
  AO22X1 U768 ( .A0(timeoutcnt_int[15]), .A1(n278), .B0(N126), .B1(n283), .Y(
        n150) );
  AO22X1 U769 ( .A0(timeoutcnt_int[16]), .A1(n278), .B0(N127), .B1(n283), .Y(
        n151) );
  AO22X1 U770 ( .A0(timeoutcnt_int[17]), .A1(n278), .B0(N128), .B1(n283), .Y(
        n152) );
  AO22X1 U771 ( .A0(timeoutcnt_int[18]), .A1(n278), .B0(N129), .B1(n283), .Y(
        n153) );
  BUFX2 U772 ( .A(n490), .Y(uarten) );
  INVX1 U773 ( .A(n415), .Y(n377) );
  OAI31X1 U774 ( .A0(n416), .A1(n417), .A2(n418), .B0(n419), .Y(n415) );
  INVX1 U775 ( .A(n420), .Y(n418) );
  AOI222X1 U776 ( .A0(n421), .A1(n422), .B0(txwaterlevel_int[3]), .B1(n387), 
        .C0(txwaterlevel_int[2]), .C1(n392), .Y(n416) );
  NAND4BX1 U777 ( .AN(rxfifoempty), .B(n449), .C(bytereceivedb), .D(
        reg_0x0000_29_), .Y(n285) );
  NOR2BX1 U778 ( .AN(reg_0x0000_15_), .B(n377), .Y(N51) );
  NOR2BX1 U779 ( .AN(reg_0x0000_7_), .B(n356), .Y(N52) );
  AO22X1 U780 ( .A0(clkdivcnt[8]), .A1(n437), .B0(N97), .B1(uarten), .Y(n184)
         );
  AO22X1 U781 ( .A0(clkdivcnt[9]), .A1(n437), .B0(N98), .B1(uarten), .Y(n185)
         );
  AO22X1 U782 ( .A0(clkdivcnt[10]), .A1(n437), .B0(N99), .B1(uarten), .Y(n186)
         );
  AO22X1 U783 ( .A0(clkdivcnt[11]), .A1(n437), .B0(N100), .B1(uarten), .Y(n187) );
  AO22X1 U784 ( .A0(clkdivcnt[12]), .A1(n437), .B0(N101), .B1(uarten), .Y(n188) );
  AO22X1 U785 ( .A0(timeoutcnt_int[0]), .A1(n278), .B0(n283), .B1(n477), .Y(
        n135) );
  AO22X1 U786 ( .A0(timeoutcnt_int[1]), .A1(n278), .B0(N112), .B1(n283), .Y(
        n136) );
  AO22X1 U787 ( .A0(timeoutcnt_int[2]), .A1(n278), .B0(N113), .B1(n283), .Y(
        n137) );
  AO22X1 U788 ( .A0(timeoutcnt_int[3]), .A1(n278), .B0(N114), .B1(n283), .Y(
        n138) );
  AO22X1 U789 ( .A0(timeoutcnt_int[4]), .A1(n278), .B0(N115), .B1(n283), .Y(
        n139) );
  AO22X1 U790 ( .A0(timeoutcnt_int[5]), .A1(n278), .B0(N116), .B1(n283), .Y(
        n140) );
  AO22X1 U791 ( .A0(timeoutcnt_int[6]), .A1(n278), .B0(N117), .B1(n283), .Y(
        n141) );
  AO22X1 U792 ( .A0(timeoutcnt_int[7]), .A1(n278), .B0(N118), .B1(n283), .Y(
        n142) );
  AO22X1 U793 ( .A0(timeoutcnt_int[8]), .A1(n278), .B0(N119), .B1(n283), .Y(
        n143) );
  AO22X1 U794 ( .A0(timeoutcnt_int[9]), .A1(n278), .B0(N120), .B1(n283), .Y(
        n144) );
  AO22X1 U795 ( .A0(timeoutcnt_int[10]), .A1(n278), .B0(N121), .B1(n283), .Y(
        n145) );
  AO22X1 U796 ( .A0(timeoutcnt_int[11]), .A1(n278), .B0(N122), .B1(n283), .Y(
        n146) );
  AO22X1 U797 ( .A0(timeoutcnt_int[12]), .A1(n278), .B0(N123), .B1(n283), .Y(
        n147) );
  AO22X1 U798 ( .A0(timeoutcnt_int[13]), .A1(n278), .B0(N124), .B1(n283), .Y(
        n148) );
  AO22X1 U799 ( .A0(timeoutcnt_int[14]), .A1(n278), .B0(N125), .B1(n283), .Y(
        n149) );
  AO22X1 U800 ( .A0(rxwaterlevel_int[3]), .A1(n364), .B0(rxwaterlevel_int[4]), 
        .B1(n361), .Y(n405) );
  AOI32X1 U801 ( .A0(rxfifocnt[4]), .A1(n455), .A2(n408), .B0(rxfifocnt[5]), 
        .B1(n439), .Y(n407) );
  AOI32X1 U802 ( .A0(txwaterlevel_int[4]), .A1(n383), .A2(n420), .B0(
        txwaterlevel_int[5]), .B1(n379), .Y(n419) );
  XOR2X1 U803 ( .A(timeoutcnt[0]), .B(n477), .Y(n326) );
  XOR2X1 U804 ( .A(timeoutcnt[19]), .B(n478), .Y(n305) );
  XOR2X1 U805 ( .A(timeoutcnt_int[9]), .B(timeoutcnt[9]), .Y(n295) );
  XOR2X1 U806 ( .A(timeoutcnt_int[18]), .B(timeoutcnt[18]), .Y(n316) );
  XOR2X1 U807 ( .A(n435), .B(timeoutcnt_int[10]), .Y(n325) );
  XOR2X1 U808 ( .A(timeoutcnt[1]), .B(n479), .Y(n304) );
  XOR2X1 U809 ( .A(timeoutcnt_int[17]), .B(timeoutcnt[17]), .Y(n315) );
  XOR2X1 U810 ( .A(timeoutcnt_int[11]), .B(timeoutcnt[11]), .Y(n324) );
  XOR2X1 U811 ( .A(timeoutcnt_int[2]), .B(timeoutcnt[2]), .Y(n303) );
  OAI211X1 U812 ( .A0(n292), .A1(n293), .B0(reg_0x0000_29_), .C0(n449), .Y(
        n290) );
  OR4X1 U813 ( .A(n294), .B(n295), .C(n296), .D(n297), .Y(n293) );
  OR4X1 U814 ( .A(n315), .B(n316), .C(n317), .D(n318), .Y(n292) );
  XOR2X1 U815 ( .A(timeoutcnt_int[8]), .B(timeoutcnt[8]), .Y(n294) );
  NAND3BX1 U816 ( .AN(n319), .B(n320), .C(n321), .Y(n318) );
  XOR2X1 U817 ( .A(n434), .B(timeoutcnt_int[12]), .Y(n320) );
  XOR2X1 U818 ( .A(n433), .B(timeoutcnt_int[13]), .Y(n321) );
  NAND3BX1 U819 ( .AN(n324), .B(n325), .C(n326), .Y(n319) );
  NAND3BX1 U820 ( .AN(n298), .B(n299), .C(n300), .Y(n297) );
  XOR2X1 U821 ( .A(n451), .B(timeoutcnt_int[3]), .Y(n299) );
  XOR2X1 U822 ( .A(n450), .B(timeoutcnt_int[4]), .Y(n300) );
  NAND3BX1 U823 ( .AN(n303), .B(n304), .C(n305), .Y(n298) );
  NAND3BX1 U824 ( .AN(n329), .B(n330), .C(n331), .Y(n317) );
  XOR2X1 U825 ( .A(n432), .B(timeoutcnt_int[14]), .Y(n330) );
  XOR2X1 U826 ( .A(n436), .B(timeoutcnt_int[15]), .Y(n331) );
  XOR2X1 U827 ( .A(timeoutcnt_int[16]), .B(timeoutcnt[16]), .Y(n329) );
  NAND3BX1 U828 ( .AN(n308), .B(n309), .C(n312), .Y(n296) );
  XOR2X1 U829 ( .A(n453), .B(timeoutcnt_int[5]), .Y(n309) );
  XOR2X1 U830 ( .A(n452), .B(timeoutcnt_int[6]), .Y(n312) );
  XOR2X1 U831 ( .A(timeoutcnt_int[7]), .B(timeoutcnt[7]), .Y(n308) );
  OA22X1 U832 ( .A0(rxfifocnt[1]), .A1(n413), .B0(n413), .B1(n456), .Y(n412)
         );
  INVX1 U833 ( .A(n414), .Y(n413) );
  NAND2BX1 U834 ( .AN(rxwaterlevel_int[0]), .B(rxfifocnt[0]), .Y(n414) );
  OA22X1 U835 ( .A0(txwaterlevel_int[2]), .A1(n392), .B0(txwaterlevel_int[1]), 
        .B1(n340), .Y(n421) );
  AO22X1 U836 ( .A0(clkdivcnt[3]), .A1(n437), .B0(N92), .B1(uarten), .Y(n179)
         );
  AO22X1 U837 ( .A0(clkdivcnt[4]), .A1(n437), .B0(N93), .B1(uarten), .Y(n180)
         );
  AO22X1 U838 ( .A0(clkdivcnt[5]), .A1(n437), .B0(N94), .B1(uarten), .Y(n181)
         );
  AO22X1 U839 ( .A0(clkdivcnt[6]), .A1(n437), .B0(N95), .B1(uarten), .Y(n182)
         );
  AO22X1 U840 ( .A0(clkdivcnt[7]), .A1(n437), .B0(N96), .B1(uarten), .Y(n183)
         );
  OAI32X1 U841 ( .A0(n288), .A1(swrst), .A2(n442), .B0(n290), .B1(n460), .Y(
        n134) );
  INVX1 U842 ( .A(n290), .Y(n288) );
  NAND2BX1 U843 ( .AN(txwaterlevel_int[5]), .B(txfifocnt[5]), .Y(n420) );
  NAND2BX1 U844 ( .AN(rxfifocnt[5]), .B(rxwaterlevel_int[5]), .Y(n408) );
  AO22X1 U845 ( .A0(clkdivcnt[1]), .A1(n437), .B0(N90), .B1(uarten), .Y(n177)
         );
  AO22X1 U846 ( .A0(clkdivcnt[2]), .A1(n437), .B0(N91), .B1(uarten), .Y(n178)
         );
  AO22X1 U847 ( .A0(clkdivcnt_msb_dly), .A1(n437), .B0(clkdivcnt[15]), .B1(
        uarten), .Y(n192) );
  OAI32X1 U848 ( .A0(n437), .A1(clkdivcnt_msb_dly), .A2(n459), .B0(uarten), 
        .B1(n431), .Y(n175) );
  INVX1 U849 ( .A(txfifocnt[5]), .Y(n379) );
  OAI31X1 U850 ( .A0(n437), .A1(clkdivcnt[0]), .A2(n448), .B0(n271), .Y(n176)
         );
  OA22X1 U851 ( .A0(uarten), .A1(n461), .B0(clkdiv[0]), .B1(n461), .Y(n271) );
  AOI211X1 U852 ( .A0(n426), .A1(n427), .B0(swrst), .C0(n462), .Y(N108) );
  NOR3BX1 U853 ( .AN(n430), .B(overrunerror), .C(n10), .Y(n426) );
  NOR3BX1 U854 ( .AN(n429), .B(reg_0x0004_7_), .C(reg_0x0004_22_), .Y(n427) );
  INVX1 U855 ( .A(parityerror), .Y(n429) );
  INVX1 U856 ( .A(frameerror), .Y(n430) );
  AO22X1 U857 ( .A0(PADDR[4]), .A1(PADDR[3]), .B0(PADDR[2]), .B1(n400), .Y(
        PRDATA[28]) );
  INVX1 U858 ( .A(PADDR[4]), .Y(n400) );
  NAND2BX1 U859 ( .AN(n377), .B(reg_0x0000_27_), .Y(n261) );
  NOR2BX1 U860 ( .AN(timeoutcnt[19]), .B(n483), .Y(PRDATA[19]) );
  NOR2BX1 U861 ( .AN(reg_0x0000_30_), .B(n482), .Y(PRDATA[30]) );
  NOR2BX1 U862 ( .AN(timeoutcnt[16]), .B(n483), .Y(PRDATA[16]) );
  NOR2BX1 U863 ( .AN(timeoutcnt[17]), .B(n483), .Y(PRDATA[17]) );
  NOR2BX1 U864 ( .AN(timeoutcnt[18]), .B(n483), .Y(PRDATA[18]) );
  AO22X1 U865 ( .A0(frameerror), .A1(PRDATA[28]), .B0(databit), .B1(n265), .Y(
        PRDATA[24]) );
  OAI2BB1X1 U866 ( .A0N(rxdmareq), .A1N(PRDATA[28]), .B0(n354), .Y(PRDATA[6])
         );
  AOI222X1 U867 ( .A0(timeoutcnt[6]), .A1(n352), .B0(clkdiv[6]), .B1(n353), 
        .C0(fifodata_rx[6]), .C1(n336), .Y(n354) );
  AO22X1 U868 ( .A0(rxbusy), .A1(PRDATA[28]), .B0(parity[1]), .B1(n265), .Y(
        PRDATA[26]) );
  OAI222X1 U869 ( .A0(n483), .A1(n432), .B0(n268), .B1(n463), .C0(n339), .C1(
        n261), .Y(PRDATA[14]) );
  AO22X1 U870 ( .A0(overrunerror), .A1(PRDATA[28]), .B0(stopbit), .B1(n265), 
        .Y(PRDATA[23]) );
  AO22X1 U871 ( .A0(txbusy), .A1(PRDATA[28]), .B0(n265), .B1(reg_0x0000_27_), 
        .Y(PRDATA[27]) );
  AO22X1 U872 ( .A0(reg_0x0004_22_), .A1(PRDATA[28]), .B0(loopbacken), .B1(
        n265), .Y(PRDATA[22]) );
  AO22X1 U873 ( .A0(parityerror), .A1(PRDATA[28]), .B0(parity[0]), .B1(n265), 
        .Y(PRDATA[25]) );
  AO22X1 U874 ( .A0(int), .A1(PRDATA[28]), .B0(uarten), .B1(n265), .Y(
        PRDATA[31]) );
  OAI221X1 U875 ( .A0(n440), .A1(n482), .B0(n339), .B1(n340), .C0(n341), .Y(
        PRDATA[9]) );
  OA22X1 U876 ( .A0(n268), .A1(n445), .B0(n483), .B1(n473), .Y(n341) );
  OAI221X1 U877 ( .A0(n454), .A1(n482), .B0(n339), .B1(n364), .C0(n365), .Y(
        PRDATA[3]) );
  AOI222X1 U878 ( .A0(timeoutcnt[3]), .A1(n352), .B0(clkdiv[3]), .B1(n353), 
        .C0(fifodata_rx[3]), .C1(n336), .Y(n365) );
  OAI221X1 U879 ( .A0(n441), .A1(n482), .B0(n339), .B1(n387), .C0(n388), .Y(
        PRDATA[11]) );
  OA22X1 U880 ( .A0(n268), .A1(n446), .B0(n483), .B1(n474), .Y(n388) );
  OAI221X1 U881 ( .A0(n465), .A1(n482), .B0(n339), .B1(n379), .C0(n380), .Y(
        PRDATA[13]) );
  OA22X1 U882 ( .A0(n268), .A1(n467), .B0(n483), .B1(n433), .Y(n380) );
  OAI221X1 U883 ( .A0(n482), .A1(n466), .B0(n339), .B1(n396), .C0(n397), .Y(
        PRDATA[0]) );
  AOI222X1 U884 ( .A0(timeoutcnt[0]), .A1(n352), .B0(clkdiv[0]), .B1(n353), 
        .C0(fifodata_rx[0]), .C1(n336), .Y(n397) );
  INVX1 U885 ( .A(rxfifocnt[0]), .Y(n396) );
  OAI221X1 U886 ( .A0(n439), .A1(n482), .B0(n339), .B1(n358), .C0(n359), .Y(
        PRDATA[5]) );
  INVX1 U887 ( .A(rxfifocnt[5]), .Y(n358) );
  AOI222X1 U888 ( .A0(timeoutcnt[5]), .A1(n352), .B0(clkdiv[5]), .B1(n353), 
        .C0(fifodata_rx[5]), .C1(n336), .Y(n359) );
  OAI221X1 U889 ( .A0(n482), .A1(n457), .B0(n339), .B1(n345), .C0(n346), .Y(
        PRDATA[8]) );
  INVX1 U890 ( .A(txfifocnt[0]), .Y(n345) );
  OA22X1 U891 ( .A0(n268), .A1(n447), .B0(n483), .B1(n475), .Y(n346) );
  OAI221X1 U892 ( .A0(n456), .A1(n482), .B0(n339), .B1(n370), .C0(n371), .Y(
        PRDATA[1]) );
  AOI222X1 U893 ( .A0(timeoutcnt[1]), .A1(n352), .B0(clkdiv[1]), .B1(n353), 
        .C0(fifodata_rx[1]), .C1(n336), .Y(n371) );
  INVX1 U894 ( .A(rxfifocnt[1]), .Y(n370) );
  OAI221X1 U895 ( .A0(n438), .A1(n482), .B0(n339), .B1(n367), .C0(n368), .Y(
        PRDATA[2]) );
  AOI222X1 U896 ( .A0(timeoutcnt[2]), .A1(n352), .B0(clkdiv[2]), .B1(n353), 
        .C0(fifodata_rx[2]), .C1(n336), .Y(n368) );
  INVX1 U897 ( .A(rxfifocnt[2]), .Y(n367) );
  OAI221X1 U898 ( .A0(n458), .A1(n482), .B0(n339), .B1(n383), .C0(n384), .Y(
        PRDATA[12]) );
  OA22X1 U899 ( .A0(n268), .A1(n468), .B0(n483), .B1(n434), .Y(n384) );
  OAI221X1 U900 ( .A0(n455), .A1(n482), .B0(n339), .B1(n361), .C0(n362), .Y(
        PRDATA[4]) );
  AOI222X1 U901 ( .A0(timeoutcnt[4]), .A1(n352), .B0(clkdiv[4]), .B1(n353), 
        .C0(fifodata_rx[4]), .C1(n336), .Y(n362) );
  OAI221X1 U902 ( .A0(n482), .A1(n443), .B0(n339), .B1(n470), .C0(n351), .Y(
        PRDATA[7]) );
  AOI222X1 U903 ( .A0(timeoutcnt[7]), .A1(n352), .B0(clkdiv[7]), .B1(n353), 
        .C0(fifodata_rx[7]), .C1(n336), .Y(n351) );
  OAI221X1 U904 ( .A0(n464), .A1(n482), .B0(n339), .B1(n392), .C0(n393), .Y(
        PRDATA[10]) );
  OA22X1 U905 ( .A0(n268), .A1(n469), .B0(n483), .B1(n435), .Y(n393) );
  OAI221X1 U906 ( .A0(n482), .A1(n444), .B0(n339), .B1(n471), .C0(n374), .Y(
        PRDATA[15]) );
  OA22X1 U907 ( .A0(n268), .A1(n472), .B0(n483), .B1(n436), .Y(n374) );
  AO21X1 U908 ( .A0(reg_0x0000_29_), .A1(n265), .B0(PRDATA[28]), .Y(PRDATA[29]) );
  NOR2X1 U909 ( .A(n356), .B(n481), .Y(rxdmareq) );
  DFFRX1 timeoutcnt_int_reg_0_ ( .D(n135), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[0]), .QN(n477) );
  DFFRX1 clkdiv_reg_0_ ( .D(n193), .CK(clk), .RN(rstb), .Q(clkdiv[0]), .QN(
        n448) );
  DFFRX1 clkdivcnt_reg_0_ ( .D(n176), .CK(clk), .RN(rstb), .Q(clkdivcnt[0]), 
        .QN(n461) );
  DFFRX1 timeoutcnt_int_reg_1_ ( .D(n136), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[1]), .QN(n479) );
  DFFRX1 timeoutcnt_int_reg_3_ ( .D(n138), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[3]) );
  DFFRX1 timeoutcnt_int_reg_4_ ( .D(n139), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[4]) );
  DFFRX1 timeoutcnt_int_reg_5_ ( .D(n140), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[5]) );
  DFFRX1 timeoutcnt_int_reg_2_ ( .D(n137), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[2]) );
  DFFRX1 clkdiv_reg_1_ ( .D(n194), .CK(clk), .RN(rstb), .Q(clkdiv[1]) );
  DFFRX1 clkdiv_reg_2_ ( .D(n195), .CK(clk), .RN(rstb), .Q(clkdiv[2]) );
  DFFRX1 clkdiv_reg_3_ ( .D(n196), .CK(clk), .RN(rstb), .Q(clkdiv[3]) );
  DFFRX1 clkdivcnt_reg_1_ ( .D(n177), .CK(clk), .RN(rstb), .Q(clkdivcnt[1]) );
  DFFRX1 clkdivcnt_reg_2_ ( .D(n178), .CK(clk), .RN(rstb), .Q(clkdivcnt[2]) );
  DFFRX1 clkdivcnt_reg_3_ ( .D(n179), .CK(clk), .RN(rstb), .Q(clkdivcnt[3]) );
  DFFRX1 parity_int_reg_0_ ( .D(n218), .CK(clk), .RN(rstb), .Q(parity[0]) );
  DFFRX1 clkdiv_reg_8_ ( .D(n201), .CK(clk), .RN(rstb), .Q(clkdiv[8]), .QN(
        n447) );
  DFFRX1 uarten_int_reg ( .D(n223), .CK(clk), .RN(rstb), .Q(n490), .QN(n437)
         );
  DFFRX1 timeoutcnt_int_reg_6_ ( .D(n141), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[6]) );
  DFFRX1 timeoutcnt_int_reg_10_ ( .D(n145), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[10]) );
  DFFRX1 timeoutcnt_int_reg_7_ ( .D(n142), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[7]) );
  DFFRX1 timeoutcnt_int_reg_8_ ( .D(n143), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[8]) );
  DFFRX1 timeoutcnt_int_reg_9_ ( .D(n144), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[9]) );
  DFFRX1 timeoutcnt_int_reg_11_ ( .D(n146), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[11]) );
  DFFRX1 clkdiv_reg_4_ ( .D(n197), .CK(clk), .RN(rstb), .Q(clkdiv[4]) );
  DFFRX1 clkdiv_reg_5_ ( .D(n198), .CK(clk), .RN(rstb), .Q(clkdiv[5]) );
  DFFRX1 clkdiv_reg_6_ ( .D(n199), .CK(clk), .RN(rstb), .Q(clkdiv[6]) );
  DFFRX1 clkdiv_reg_7_ ( .D(n200), .CK(clk), .RN(rstb), .Q(clkdiv[7]) );
  DFFRX1 clkdivcnt_reg_4_ ( .D(n180), .CK(clk), .RN(rstb), .Q(clkdivcnt[4]) );
  DFFRX1 clkdivcnt_reg_5_ ( .D(n181), .CK(clk), .RN(rstb), .Q(clkdivcnt[5]) );
  DFFRX1 clkdivcnt_reg_6_ ( .D(n182), .CK(clk), .RN(rstb), .Q(clkdivcnt[6]) );
  DFFRX1 clkdivcnt_reg_7_ ( .D(n183), .CK(clk), .RN(rstb), .Q(clkdivcnt[7]) );
  DFFRX1 clkdivcnt_reg_8_ ( .D(n184), .CK(clk), .RN(rstb), .Q(clkdivcnt[8]) );
  DFFRX1 stopbit_int_reg ( .D(n216), .CK(clk), .RN(rstb), .Q(stopbit) );
  DFFRX1 timeoutinten_int_reg ( .D(n221), .CK(clk), .RN(rstb), .Q(
        reg_0x0000_29_), .QN(n442) );
  DFFRX1 clkdiv_reg_9_ ( .D(n202), .CK(clk), .RN(rstb), .Q(clkdiv[9]), .QN(
        n445) );
  DFFRX1 clkdiv_reg_10_ ( .D(n203), .CK(clk), .RN(rstb), .Q(clkdiv[10]), .QN(
        n469) );
  DFFRX1 clkdiv_reg_11_ ( .D(n204), .CK(clk), .RN(rstb), .Q(clkdiv[11]), .QN(
        n446) );
  DFFRX1 clkdiv_reg_12_ ( .D(n205), .CK(clk), .RN(rstb), .Q(clkdiv[12]), .QN(
        n468) );
  DFFRX1 timeoutcnt_int_reg_19_ ( .D(n154), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[19]), .QN(n478) );
  DFFRX1 timeoutcnt_reg_8_ ( .D(n163), .CK(clk), .RN(rstb), .Q(timeoutcnt[8]), 
        .QN(n475) );
  DFFRX1 timeoutcnt_reg_9_ ( .D(n164), .CK(clk), .RN(rstb), .Q(timeoutcnt[9]), 
        .QN(n473) );
  DFFRX1 timeoutcnt_reg_11_ ( .D(n166), .CK(clk), .RN(rstb), .Q(timeoutcnt[11]), .QN(n474) );
  DFFRX1 loopbacken_int_reg ( .D(n215), .CK(clk), .RN(rstb), .Q(loopbacken) );
  DFFRX1 timeoutcnt_reg_19_ ( .D(n174), .CK(clk), .RN(rstb), .Q(timeoutcnt[19]) );
  DFFRX1 rxwaterlevel_int_reg_0_ ( .D(n226), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[0]), .QN(n466) );
  DFFRX1 timeoutcnt_reg_0_ ( .D(n155), .CK(clk), .RN(rstb), .Q(timeoutcnt[0])
         );
  DFFRX1 timeoutcnt_reg_1_ ( .D(n156), .CK(clk), .RN(rstb), .Q(timeoutcnt[1])
         );
  DFFRX1 timeoutcnt_reg_3_ ( .D(n158), .CK(clk), .RN(rstb), .Q(timeoutcnt[3]), 
        .QN(n451) );
  DFFRX1 timeoutcnt_reg_4_ ( .D(n159), .CK(clk), .RN(rstb), .Q(timeoutcnt[4]), 
        .QN(n450) );
  DFFRX1 timeoutcnt_reg_5_ ( .D(n160), .CK(clk), .RN(rstb), .Q(timeoutcnt[5]), 
        .QN(n453) );
  DFFRX1 timeoutcnt_reg_6_ ( .D(n161), .CK(clk), .RN(rstb), .Q(timeoutcnt[6]), 
        .QN(n452) );
  DFFRX1 timeoutcnt_reg_10_ ( .D(n165), .CK(clk), .RN(rstb), .Q(timeoutcnt[10]), .QN(n435) );
  DFFRX1 timeoutcnt_reg_12_ ( .D(n167), .CK(clk), .RN(rstb), .Q(timeoutcnt[12]), .QN(n434) );
  DFFRX1 timeoutcnt_reg_13_ ( .D(n168), .CK(clk), .RN(rstb), .Q(timeoutcnt[13]), .QN(n433) );
  DFFRX1 timeoutcnt_reg_14_ ( .D(n169), .CK(clk), .RN(rstb), .Q(timeoutcnt[14]), .QN(n432) );
  DFFRX1 timeoutcnt_reg_15_ ( .D(n170), .CK(clk), .RN(rstb), .Q(timeoutcnt[15]), .QN(n436) );
  DFFRX1 timeoutcnt_int_reg_12_ ( .D(n147), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[12]) );
  DFFRX1 timeoutcnt_int_reg_13_ ( .D(n148), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[13]) );
  DFFRX1 timeoutcnt_int_reg_14_ ( .D(n149), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[14]) );
  DFFRX1 timeoutcnt_int_reg_15_ ( .D(n150), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[15]) );
  DFFRX1 timeoutcnt_int_reg_16_ ( .D(n151), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[16]) );
  DFFRX1 timeoutcnt_int_reg_17_ ( .D(n152), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[17]) );
  DFFRX1 timeoutcnt_int_reg_18_ ( .D(n153), .CK(clk), .RN(rstb), .Q(
        timeoutcnt_int[18]) );
  DFFRX1 timeoutcnt_reg_16_ ( .D(n171), .CK(clk), .RN(rstb), .Q(timeoutcnt[16]) );
  DFFRX1 timeoutcnt_reg_17_ ( .D(n172), .CK(clk), .RN(rstb), .Q(timeoutcnt[17]) );
  DFFRX1 timeoutcnt_reg_18_ ( .D(n173), .CK(clk), .RN(rstb), .Q(timeoutcnt[18]) );
  DFFRX1 timeoutcnt_reg_2_ ( .D(n157), .CK(clk), .RN(rstb), .Q(timeoutcnt[2])
         );
  DFFRX1 timeoutcnt_reg_7_ ( .D(n162), .CK(clk), .RN(rstb), .Q(timeoutcnt[7])
         );
  DFFRX1 clkdivcnt_reg_9_ ( .D(n185), .CK(clk), .RN(rstb), .Q(clkdivcnt[9]) );
  DFFRX1 clkdivcnt_reg_10_ ( .D(n186), .CK(clk), .RN(rstb), .Q(clkdivcnt[10])
         );
  DFFRX1 clkdivcnt_reg_11_ ( .D(n187), .CK(clk), .RN(rstb), .Q(clkdivcnt[11])
         );
  DFFRX1 clkdivcnt_reg_12_ ( .D(n188), .CK(clk), .RN(rstb), .Q(clkdivcnt[12])
         );
  DFFRX1 clkdivcnt_reg_13_ ( .D(n189), .CK(clk), .RN(rstb), .Q(clkdivcnt[13])
         );
  DFFRX1 clkdiv_reg_13_ ( .D(n206), .CK(clk), .RN(rstb), .Q(clkdiv[13]), .QN(
        n467) );
  DFFRX1 clkdiv_reg_14_ ( .D(n207), .CK(clk), .RN(rstb), .Q(clkdiv[14]), .QN(
        n463) );
  DFFRX1 clkdiv_reg_15_ ( .D(n208), .CK(clk), .RN(rstb), .Q(clkdiv[15]), .QN(
        n472) );
  DFFRX1 receivetimeout_reg ( .D(n134), .CK(clk), .RN(rstb), .Q(reg_0x0004_22_), .QN(n460) );
  DFFRX1 rxwaterlevel_int_reg_5_ ( .D(n231), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[5]), .QN(n439) );
  DFFRX1 rxfifo_interrupt_reg ( .D(N52), .CK(clk), .RN(rstb), .Q(reg_0x0004_7_), .QN(n470) );
  DFFRX1 clkdivcnt_reg_15_ ( .D(n191), .CK(clk), .RN(rstb), .Q(clkdivcnt[15]), 
        .QN(n459) );
  DFFRX1 txfifo_interrupt_reg ( .D(N51), .CK(clk), .RN(rstb), .Q(n10), .QN(
        n471) );
  DFFRX1 txwaterlevel_int_reg_2_ ( .D(n211), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[2]), .QN(n464) );
  DFFRX1 txwaterlevel_int_reg_5_ ( .D(n214), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[5]), .QN(n465) );
  DFFRX1 rxwaterlevel_int_reg_3_ ( .D(n229), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[3]), .QN(n454) );
  DFFRX1 rxwaterlevel_int_reg_4_ ( .D(n230), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[4]), .QN(n455) );
  DFFRX1 txwaterlevel_int_reg_1_ ( .D(n210), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[1]), .QN(n440) );
  DFFRX1 intgenen_int_reg ( .D(n222), .CK(clk), .RN(rstb), .Q(reg_0x0000_30_), 
        .QN(n462) );
  DFFRX1 rxfifo_inten_reg ( .D(n224), .CK(clk), .RN(rstb), .Q(reg_0x0000_7_), 
        .QN(n443) );
  DFFRX1 txfifo_inten_reg ( .D(n225), .CK(clk), .RN(rstb), .Q(reg_0x0000_15_), 
        .QN(n444) );
  DFFRX1 txwaterlevel_int_reg_4_ ( .D(n213), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[4]), .QN(n458) );
  DFFRX1 txwaterlevel_int_reg_3_ ( .D(n212), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[3]), .QN(n441) );
  DFFRX1 txwaterlevel_int_reg_0_ ( .D(n209), .CK(clk), .RN(rstb), .Q(
        txwaterlevel_int[0]), .QN(n457) );
  DFFRX1 rxwaterlevel_int_reg_1_ ( .D(n227), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[1]), .QN(n456) );
  DFFRX1 rxwaterlevel_int_reg_2_ ( .D(n228), .CK(clk), .RN(rstb), .Q(
        rxwaterlevel_int[2]), .QN(n438) );
  DFFRX1 overrunerr_clear_reg ( .D(N62), .CK(clk), .RN(rstb), .Q(
        overrunerr_clear) );
  DFFRX1 clkdivcnt_reg_14_ ( .D(n190), .CK(clk), .RN(rstb), .Q(clkdivcnt[14])
         );
  DFFRX1 clkdivcnt_msb_dly_reg ( .D(n192), .CK(clk), .RN(rstb), .Q(
        clkdivcnt_msb_dly) );
  DFFRX1 frameerr_clear_reg ( .D(N60), .CK(clk), .RN(rstb), .Q(frameerr_clear)
         );
  DFFRX1 parityerr_clear_reg ( .D(N61), .CK(clk), .RN(rstb), .Q(
        parityerr_clear) );
  DFFRX1 dmareqen_int_reg ( .D(n220), .CK(clk), .RN(rstb), .Q(reg_0x0000_27_), 
        .QN(n481) );
  DFFRX1 interrupt_status_reg ( .D(N108), .CK(clk), .RN(rstb), .Q(int) );
endmodule

