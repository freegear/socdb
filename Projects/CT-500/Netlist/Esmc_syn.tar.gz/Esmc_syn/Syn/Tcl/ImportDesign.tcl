analyze -f verilog -lib WORK ../Rtl/AXI_ESMC_interface.v
analyze -f verilog -lib WORK ../Rtl/SMC_REG.v
analyze -f verilog -lib WORK ../Rtl/SRAM_CTRL.v
analyze -f verilog -lib WORK ../Rtl/SMC_TOP.v

elaborate $TopDesign -lib WORK
