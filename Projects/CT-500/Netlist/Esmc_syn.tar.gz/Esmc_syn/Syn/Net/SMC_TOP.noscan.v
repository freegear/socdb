
module SMC_TOP ( ACLK, ARESETn, AWID, AWADDR, AWLEN, AWSIZE, AWBURST, AWVALID, 
        AWREADY, WID, WDATA, WSTRB, WLAST, WVALID, WREADY, BID, BRESP, BVALID, 
        BREADY, ARID, ARADDR, ARLEN, ARSIZE, ARBURST, ARVALID, ARREADY, RID, 
        RDATA, RRESP, RLAST, RVALID, RREADY, PCLK, PRESETn, PADDR, PSEL, 
        PENABLE, PWRITE, PWDATA, PRDATA, EXT_ADDR, EXT_WDATA, EXT_RDATA, 
        EXT_CSb, EXT_OEb, EXT_WEb, EXT_BEb, EXT_WBEb, EXT_BIDEN );
  input [3:0] AWID;
  input [31:0] AWADDR;
  input [3:0] AWLEN;
  input [2:0] AWSIZE;
  input [1:0] AWBURST;
  input [3:0] WID;
  input [31:0] WDATA;
  input [3:0] WSTRB;
  output [3:0] BID;
  output [1:0] BRESP;
  input [3:0] ARID;
  input [31:0] ARADDR;
  input [3:0] ARLEN;
  input [2:0] ARSIZE;
  input [1:0] ARBURST;
  output [3:0] RID;
  output [31:0] RDATA;
  output [1:0] RRESP;
  input [5:2] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  output [26:0] EXT_ADDR;
  output [31:0] EXT_WDATA;
  input [31:0] EXT_RDATA;
  output [8:0] EXT_CSb;
  output [3:0] EXT_BEb;
  output [3:0] EXT_WBEb;
  input ACLK, ARESETn, AWVALID, WLAST, WVALID, BREADY, ARVALID, RREADY, PCLK,
         PRESETn, PSEL, PENABLE, PWRITE;
  output AWREADY, WREADY, BVALID, ARREADY, RLAST, RVALID, EXT_OEb, EXT_WEb,
         EXT_BIDEN;
  wire   SMC_SRAM_START, SMC_WRITE, SMC_READ, SMC_TRANS_SIZE_1_,
         SMC_TRANS_SIZE_0_, SMC_READY;
  wire   [8:0] SMC_BANK_SEL;
  wire   [2:0] ADDR_SETUP;
  wire   [2:0] ADDR_HOLD;
  wire   [2:0] CS_SETUP;
  wire   [2:0] CS_HOLD;
  wire   [3:0] ACC_CYCLE;
  wire   [1:0] BUS_WIDTH;
  wire   [1:0] ADDR_SHIFT;
  wire   [26:0] SMC_ADDR;
  wire   [31:0] SMC_WDATA;
  wire   [3:0] SMC_WBEB;
  wire   [31:0] SMC_RDATA;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1, 
        SYNOPSYS_UNCONNECTED__2, SYNOPSYS_UNCONNECTED__3, 
        SYNOPSYS_UNCONNECTED__4, SYNOPSYS_UNCONNECTED__5, 
        SYNOPSYS_UNCONNECTED__6, SYNOPSYS_UNCONNECTED__7, 
        SYNOPSYS_UNCONNECTED__8, SYNOPSYS_UNCONNECTED__9, 
        SYNOPSYS_UNCONNECTED__10, SYNOPSYS_UNCONNECTED__11, 
        SYNOPSYS_UNCONNECTED__12, SYNOPSYS_UNCONNECTED__13, 
        SYNOPSYS_UNCONNECTED__14, SYNOPSYS_UNCONNECTED__15;
  assign PRDATA[31] = 1'b0;
  assign PRDATA[30] = 1'b0;
  assign PRDATA[29] = 1'b0;
  assign PRDATA[28] = 1'b0;
  assign PRDATA[27] = 1'b0;
  assign PRDATA[26] = 1'b0;
  assign PRDATA[25] = 1'b0;
  assign PRDATA[24] = 1'b0;
  assign PRDATA[23] = 1'b0;
  assign PRDATA[22] = 1'b0;
  assign PRDATA[21] = 1'b0;
  assign PRDATA[20] = 1'b0;
  assign PRDATA[3] = 1'b0;
  assign PRDATA[2] = 1'b0;
  assign PRDATA[1] = 1'b0;
  assign PRDATA[0] = 1'b0;
  assign BRESP[1] = 1'b0;
  assign BRESP[0] = 1'b0;
  assign RRESP[1] = 1'b0;
  assign RRESP[0] = 1'b0;

  SMC_REG uSMC_REG ( .PCLK(PCLK), .PRESETn(PRESETn), .PADDR(PADDR), .PSEL(PSEL), .PENABLE(PENABLE), .PWRITE(PWRITE), .PWDATA(PWDATA), .PRDATA({
        SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1, 
        SYNOPSYS_UNCONNECTED__2, SYNOPSYS_UNCONNECTED__3, 
        SYNOPSYS_UNCONNECTED__4, SYNOPSYS_UNCONNECTED__5, 
        SYNOPSYS_UNCONNECTED__6, SYNOPSYS_UNCONNECTED__7, 
        SYNOPSYS_UNCONNECTED__8, SYNOPSYS_UNCONNECTED__9, 
        SYNOPSYS_UNCONNECTED__10, SYNOPSYS_UNCONNECTED__11, PRDATA[19:4], 
        SYNOPSYS_UNCONNECTED__12, SYNOPSYS_UNCONNECTED__13, 
        SYNOPSYS_UNCONNECTED__14, SYNOPSYS_UNCONNECTED__15}), .SRAM_START(
        SMC_SRAM_START), .BANK_SEL(SMC_BANK_SEL), .ADDR_SETUP(ADDR_SETUP), 
        .ADDR_HOLD(ADDR_HOLD), .CS_SETUP(CS_SETUP), .CS_HOLD(CS_HOLD), 
        .ACC_CYCLE(ACC_CYCLE) );
  SRAM_CTRL uSRAM_CTRL ( .CLK(ACLK), .RSTb(ARESETn), .ADDR(SMC_ADDR), .WRITE(
        SMC_WRITE), .READ(SMC_READ), .WDATA(SMC_WDATA), .WBEB(SMC_WBEB), 
        .TRANS_SIZE({1'b0, SMC_TRANS_SIZE_1_, SMC_TRANS_SIZE_0_}), .BANK_SEL(
        SMC_BANK_SEL), .SRAM_START(SMC_SRAM_START), .ADDR_SETUP(ADDR_SETUP), 
        .ADDR_HOLD(ADDR_HOLD), .CS_SETUP(CS_SETUP), .CS_HOLD(CS_HOLD), 
        .ACC_CYCLE(ACC_CYCLE), .BUS_WIDTH({1'b0, 1'b0}), .ADDR_SHIFT({1'b0, 
        1'b0}), .READY(SMC_READY), .RDATA(SMC_RDATA), .EXT_ADDR(EXT_ADDR), 
        .EXT_WDATA(EXT_WDATA), .EXT_RDATA(EXT_RDATA), .EXT_CSb(EXT_CSb), 
        .EXT_WEb(EXT_WEb), .EXT_OEb(EXT_OEb), .EXT_BEb(EXT_BEb), .EXT_WBEb(
        EXT_WBEb), .EXT_BIDEN(EXT_BIDEN) );
  AXI_ESMC_interface_WID_WIDTH4_RID_WIDTH4 uAXI_interface ( .ACLK(ACLK), 
        .ARESETn(ARESETn), .AWID(AWID), .AWADDR(AWADDR), .AWLEN(AWLEN), 
        .AWSIZE(AWSIZE), .AWBURST(AWBURST), .AWVALID(AWVALID), .AWREADY(
        AWREADY), .WID(WID), .WDATA(WDATA), .WSTRB(WSTRB), .WLAST(WLAST), 
        .WVALID(WVALID), .WREADY(WREADY), .BID(BID), .BVALID(BVALID), .BREADY(
        BREADY), .ARID(ARID), .ARADDR(ARADDR), .ARLEN(ARLEN), .ARSIZE(ARSIZE), 
        .ARBURST(ARBURST), .ARVALID(ARVALID), .ARREADY(ARREADY), .RID(RID), 
        .RDATA(RDATA), .RLAST(RLAST), .RVALID(RVALID), .RREADY(RREADY), 
        .SMC_READY(SMC_READY), .SMC_RDATA(SMC_RDATA), .SMC_ADDR(SMC_ADDR), 
        .SMC_WDATA(SMC_WDATA), .SMC_WBEB(SMC_WBEB), .SMC_WRITE(SMC_WRITE), 
        .SMC_READ(SMC_READ), .SMC_BANK_SEL(SMC_BANK_SEL), .SMC_SRAM_START(
        SMC_SRAM_START), .SMC_TRANS_SIZE({SMC_TRANS_SIZE_1_, SMC_TRANS_SIZE_0_}) );
endmodule


module AXI_ESMC_interface_WID_WIDTH4_RID_WIDTH4 ( ACLK, ARESETn, AWID, AWADDR, 
        AWLEN, AWSIZE, AWBURST, AWVALID, AWREADY, WID, WDATA, WSTRB, WLAST, 
        WVALID, WREADY, BID, BRESP, BVALID, BREADY, ARID, ARADDR, ARLEN, 
        ARSIZE, ARBURST, ARVALID, ARREADY, RID, RDATA, RRESP, RLAST, RVALID, 
        RREADY, SMC_READY, SMC_RDATA, SMC_ADDR, SMC_WDATA, SMC_WBEB, SMC_WRITE, 
        SMC_READ, SMC_BANK_SEL, SMC_SRAM_START, SMC_TRANS_SIZE );
  input [3:0] AWID;
  input [31:0] AWADDR;
  input [3:0] AWLEN;
  input [2:0] AWSIZE;
  input [1:0] AWBURST;
  input [3:0] WID;
  input [31:0] WDATA;
  input [3:0] WSTRB;
  output [3:0] BID;
  output [1:0] BRESP;
  input [3:0] ARID;
  input [31:0] ARADDR;
  input [3:0] ARLEN;
  input [2:0] ARSIZE;
  input [1:0] ARBURST;
  output [3:0] RID;
  output [31:0] RDATA;
  output [1:0] RRESP;
  input [31:0] SMC_RDATA;
  output [26:0] SMC_ADDR;
  output [31:0] SMC_WDATA;
  output [3:0] SMC_WBEB;
  output [8:0] SMC_BANK_SEL;
  output [1:0] SMC_TRANS_SIZE;
  input ACLK, ARESETn, AWVALID, WLAST, WVALID, BREADY, ARVALID, RREADY,
         SMC_READY;
  output AWREADY, WREADY, BVALID, ARREADY, RLAST, RVALID, SMC_WRITE, SMC_READ,
         SMC_SRAM_START;
  wire   State_4_, StateIsWRITE, ReadOrWrite, n_211, IncreasedAddr_2_,
         IncreasedAddr_1_, GeneratedAddr_28_, GeneratedAddr_27_,
         GeneratedAddr_1_, GeneratedAddr_0_, BurstLen_3_, BurstLen_2_,
         BurstLen_1_, WaitingRREADY, n1675, n1676, n1677, n1678,
         WDATAAvailable, Len_3_, Len_2_, Len_1_, Len_0_, LatchedRDATA_31_,
         LatchedRDATA_30_, LatchedRDATA_29_, LatchedRDATA_28_,
         LatchedRDATA_27_, LatchedRDATA_26_, LatchedRDATA_25_,
         LatchedRDATA_24_, LatchedRDATA_23_, LatchedRDATA_22_,
         LatchedRDATA_21_, LatchedRDATA_20_, LatchedRDATA_19_,
         LatchedRDATA_18_, LatchedRDATA_17_, LatchedRDATA_16_,
         LatchedRDATA_15_, LatchedRDATA_14_, LatchedRDATA_13_,
         LatchedRDATA_12_, LatchedRDATA_11_, LatchedRDATA_10_, LatchedRDATA_9_,
         LatchedRDATA_8_, LatchedRDATA_7_, LatchedRDATA_6_, LatchedRDATA_5_,
         LatchedRDATA_4_, LatchedRDATA_3_, LatchedRDATA_2_, LatchedRDATA_1_,
         LatchedRDATA_0_, n1540, n1541, n1542, n1543, n1544, n1545, n1546,
         n1547, n1548, n1549, n1550, n1551, n1552, n1553, n1554, n1555, n1556,
         n1557, n1558, n1559, n1560, n1561, n1562, n1563, n1564, n1565, n1566,
         n1567, n1568, n1569, n1570, n1571, n1572, n1573, n1574, n1575, n1576,
         n1577, n1578, n1579, n1580, n1581, n1582, n1583, n1584, n1585, n1586,
         n1587, n1588, n1589, n1590, n1591, n1592, n1593, n1594, n1595, n1596,
         n1597, n1598, n1599, n1600, n1601, n1602, n1603, n1604, n1605, n1606,
         n1607, n1608, n1609, n1610, n1611, n1612, n1613, n1614, n1615, n1616,
         n1617, n1618, n1619, n1620, n1621, n1622, n1623, n1624, n1625, n1626,
         n1627, n1628, n1629, n1630, n1631, n1632, n1633, n1634, n1635, n1636,
         n1637, n1638, n1639, n1640, n1641, n1642, n1643, n1644, n1645, n1646,
         n1647, n1648, n1649, n1650, n1651, n1652, n1653, n1654, carry_2_,
         carry_1_, n9, n10, n1681, n1683, n1684, n1685, n1686, n1687, n1688,
         n1689, n1691, n1692, n1694, n1695, n1696, n1697, n1698, n1699, n1703,
         n1704, n1705, n1706, n1707, n1709, n1710, n1711, n1712, n1714, n1715,
         n1716, n1717, n1720, n1721, n1723, n1724, n1725, n1726, n1729, n1730,
         n1731, n1733, n1735, n1736, n1737, n1738, n1739, n1740, n1742, n1743,
         n1744, n1745, n1746, n1747, n1748, n1750, n1751, n1752, n1753, n1754,
         n1756, n1757, n1759, n1760, n1761, n1762, n1763, n1765, n1766, n1768,
         n1769, n1770, n1771, n1772, n1774, n1775, n1776, n1777, n1778, n1779,
         n1780, n1781, n1782, n1783, n1784, n1785, n1786, n1787, n1791, n1793,
         n1796, n1797, n1798, n1799, n1800, n1801, n1802, n1805, n1806, n1807,
         n1808, n1809, n1811, n1812, n1813, n1814, n1815, n1816, n1817, n1818,
         n1820, n1821, n1822, n1824, n1825, n1826, n1827, n1828, n1829, n1830,
         n1831, n1832, n1833, n1835, n1837, n1841, n1842, n1844, n1845, n1846,
         n1847, n1848, n1852, n1853, n1854, n1855, n1856, n1857, n1858, n1859,
         n1860, n1861, n1862, n1863, n1864, n1865, n1866, n1867, n1868, n1869,
         n1870, n1871, n1872, n1873, n1874, n1875, n1876, n1877, n1878, n1879,
         n1880, n1881, n1882, n1883, n1884, n1885, n1886, n1887, n1888, n1889,
         n1890, n1891, n1892, n1893, n1894, n1895, n1896, n1897, n1898, n1899,
         n1900;
  wire   [4:0] NextState;
  wire   [1:0] Burst;
  assign RID[3] = n1675;
  assign BID[3] = n1675;
  assign RID[2] = n1676;
  assign BID[2] = n1676;
  assign RID[1] = n1677;
  assign BID[1] = n1677;
  assign RID[0] = n1678;
  assign BID[0] = n1678;
  assign RRESP[0] = 1'b0;
  assign RRESP[1] = 1'b0;
  assign BRESP[0] = 1'b0;
  assign BRESP[1] = 1'b0;

  NAND2BX4 U1224 ( .AN(SMC_ADDR[26]), .B(GeneratedAddr_28_), .Y(n1837) );
  NOR3X2 U1302 ( .A(n1879), .B(n1837), .C(n1862), .Y(SMC_BANK_SEL[5]) );
  NAND3BX2 U1303 ( .AN(SMC_ADDR[25]), .B(SMC_ADDR[26]), .C(GeneratedAddr_28_), 
        .Y(n1835) );
  AND3X1 U1304 ( .A(SMC_ADDR[26]), .B(GeneratedAddr_28_), .C(SMC_ADDR[25]), 
        .Y(SMC_BANK_SEL[8]) );
  DFFRX2 GeneratedAddr_reg_25_ ( .D(n1627), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[25]), .QN(n1879) );
  INVX3 U1305 ( .A(n1683), .Y(RVALID) );
  NOR3BX1 U1306 ( .AN(SMC_ADDR[25]), .B(n1837), .C(SMC_ADDR[24]), .Y(
        SMC_BANK_SEL[4]) );
  NOR2BX1 U1307 ( .AN(n1862), .B(n1835), .Y(SMC_BANK_SEL[6]) );
  INVX1 U1308 ( .A(n1689), .Y(n1684) );
  DFFRX1 GeneratedAddr_reg_24_ ( .D(n1628), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[24]), .QN(n1862) );
  DFFRX2 GeneratedAddr_reg_28_ ( .D(n1624), .CK(ACLK), .RN(ARESETn), .Q(
        GeneratedAddr_28_) );
  DFFRX1 GeneratedAddr_reg_26_ ( .D(n1626), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[26]) );
  NOR3BX1 U1309 ( .AN(SMC_ADDR[24]), .B(n1837), .C(SMC_ADDR[25]), .Y(
        SMC_BANK_SEL[3]) );
  BUFX2 U1310 ( .A(SMC_READY), .Y(n1895) );
  INVX1 U1311 ( .A(SMC_READY), .Y(n1880) );
  NAND2X1 U1312 ( .A(SMC_READ), .B(n1815), .Y(n1683) );
  INVX1 U1313 ( .A(n1895), .Y(n1774) );
  INVX1 U1314 ( .A(n1746), .Y(n1743) );
  AND2X1 U1315 ( .A(n1890), .B(n1712), .Y(n1888) );
  NOR3BX1 U1316 ( .AN(n1862), .B(n1837), .C(SMC_ADDR[25]), .Y(SMC_BANK_SEL[2])
         );
  NOR2BX1 U1317 ( .AN(GeneratedAddr_27_), .B(GeneratedAddr_28_), .Y(
        SMC_BANK_SEL[1]) );
  NAND2X1 U1318 ( .A(n1886), .B(n1743), .Y(n1689) );
  AO21X1 U1319 ( .A0(ARADDR[28]), .A1(n1888), .B0(n1881), .Y(n1624) );
  AO22X1 U1320 ( .A0(GeneratedAddr_28_), .A1(n1887), .B0(AWADDR[28]), .B1(
        n1694), .Y(n1881) );
  AO21X1 U1321 ( .A0(ARADDR[26]), .A1(n1888), .B0(n1882), .Y(n1626) );
  AO22X1 U1322 ( .A0(SMC_ADDR[26]), .A1(n1887), .B0(AWADDR[26]), .B1(n1694), 
        .Y(n1882) );
  AO21X1 U1323 ( .A0(ARADDR[25]), .A1(n1888), .B0(n1883), .Y(n1627) );
  AO22X1 U1324 ( .A0(SMC_ADDR[25]), .A1(n1887), .B0(AWADDR[25]), .B1(n1694), 
        .Y(n1883) );
  AO21X1 U1325 ( .A0(ARADDR[24]), .A1(n1888), .B0(n1884), .Y(n1628) );
  AO22X1 U1326 ( .A0(SMC_ADDR[24]), .A1(n1887), .B0(AWADDR[24]), .B1(n1694), 
        .Y(n1884) );
  AOI32X1 U1327 ( .A0(n1704), .A1(SMC_ADDR[2]), .A2(n1887), .B0(n1705), .B1(
        n1689), .Y(n1703) );
  AOI32X1 U1328 ( .A0(n1696), .A1(GeneratedAddr_1_), .A2(n1887), .B0(n1697), 
        .B1(n1689), .Y(n1695) );
  AOI32X1 U1329 ( .A0(GeneratedAddr_0_), .A1(n1686), .A2(n1887), .B0(n1688), 
        .B1(n1689), .Y(n1685) );
  OAI2BB1X1 U1330 ( .A0N(SMC_ADDR[5]), .A1N(n1684), .B0(n1885), .Y(n1647) );
  OAI21X1 U1331 ( .A0(n1729), .A1(n1730), .B0(n1689), .Y(n1885) );
  OR3X2 U1332 ( .A(n1742), .B(Burst[0]), .C(n1893), .Y(n1886) );
  INVX1 U1333 ( .A(n1712), .Y(n1887) );
  AO22X2 U1334 ( .A0(AWVALID), .A1(n_211), .B0(n_211), .B1(ARVALID), .Y(n1712)
         );
  BUFX2 U1335 ( .A(n1796), .Y(n1898) );
  BUFX2 U1336 ( .A(n1796), .Y(n1899) );
  INVX1 U1337 ( .A(n1714), .Y(n1717) );
  INVX1 U1338 ( .A(n1793), .Y(n1694) );
  NAND2BX1 U1339 ( .AN(n1890), .B(n1712), .Y(n1793) );
  AO21X1 U1340 ( .A0(n1887), .A1(n1871), .B0(n1757), .Y(n1761) );
  INVX1 U1341 ( .A(n1712), .Y(n1687) );
  NAND2BX1 U1342 ( .AN(n1900), .B(n1880), .Y(n1815) );
  AO21X1 U1343 ( .A0(n9), .A1(n1887), .B0(n1684), .Y(n1710) );
  AO21X1 U1344 ( .A0(n1687), .A1(n1772), .B0(n1743), .Y(n1757) );
  AO21X1 U1345 ( .A0(n1887), .A1(n1752), .B0(n1743), .Y(n1744) );
  INVX1 U1346 ( .A(n1824), .Y(n1816) );
  INVX1 U1347 ( .A(n1825), .Y(n1818) );
  NAND2BX1 U1348 ( .AN(n1890), .B(n1824), .Y(n1825) );
  INVX1 U1349 ( .A(n1811), .Y(n1798) );
  INVX1 U1350 ( .A(n1848), .Y(ARREADY) );
  NAND2BX1 U1351 ( .AN(n1774), .B(SMC_SRAM_START), .Y(n1742) );
  INVX1 U1352 ( .A(n1813), .Y(RLAST) );
  INVX1 U1353 ( .A(n1896), .Y(n1796) );
  NOR2BX1 U1354 ( .AN(n1681), .B(n1894), .Y(NextState[4]) );
  INVX1 U1355 ( .A(n1845), .Y(n1681) );
  DFFRX1 Size_reg_1_ ( .D(n1543), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_TRANS_SIZE[1]), .QN(n1856) );
  DFFRX1 Size_reg_0_ ( .D(n1544), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_TRANS_SIZE[0]), .QN(n1866) );
  NAND2BX1 U1356 ( .AN(n1860), .B(n1692), .Y(n1833) );
  NOR3BX1 U1357 ( .AN(n1869), .B(n1725), .C(n9), .Y(n1724) );
  INVX1 U1358 ( .A(n1752), .Y(n1748) );
  INVX1 U1359 ( .A(n1772), .Y(n1759) );
  INVX1 U1360 ( .A(n1686), .Y(n1692) );
  INVX1 U1361 ( .A(n1737), .Y(n1740) );
  INVX1 U1362 ( .A(n1733), .Y(n1731) );
  NAND4BX1 U1363 ( .AN(n1686), .B(n1858), .C(n1861), .D(n1892), .Y(n1699) );
  OAI221X1 U1364 ( .A0(n1692), .A1(n1858), .B0(n1861), .B1(n1856), .C0(n1892), 
        .Y(n1714) );
  INVX1 U1365 ( .A(n1842), .Y(AWREADY) );
  NOR2BX2 U1366 ( .AN(SMC_ADDR[24]), .B(n1835), .Y(SMC_BANK_SEL[7]) );
  NAND3BX1 U1367 ( .AN(n_211), .B(n1864), .C(n1811), .Y(n1801) );
  AO21X1 U1368 ( .A0(RREADY), .A1(n1815), .B0(n_211), .Y(n1811) );
  OAI31X1 U1369 ( .A0(n1742), .A1(Burst[1]), .A2(n1874), .B0(n1687), .Y(n1746)
         );
  OAI2BB2X1 U1370 ( .A0N(SMC_ADDR[9]), .A1N(n1757), .B0(n1743), .B1(n1756), 
        .Y(n1643) );
  AOI31X1 U1371 ( .A0(n1887), .A1(n1871), .A2(n1759), .B0(n1760), .Y(n1756) );
  AO22X1 U1372 ( .A0(AWADDR[9]), .A1(n1694), .B0(ARADDR[9]), .B1(n1888), .Y(
        n1760) );
  OAI21X1 U1373 ( .A0(n1743), .A1(n1750), .B0(n1751), .Y(n1644) );
  AOI31X1 U1374 ( .A0(SMC_ADDR[7]), .A1(n1748), .A2(n1753), .B0(n1754), .Y(
        n1750) );
  AOI32X1 U1375 ( .A0(SMC_ADDR[8]), .A1(n1867), .A2(n1887), .B0(SMC_ADDR[8]), 
        .B1(n1744), .Y(n1751) );
  NOR2BX1 U1376 ( .AN(n1875), .B(n1712), .Y(n1753) );
  AO22X1 U1377 ( .A0(AWADDR[11]), .A1(n1694), .B0(ARADDR[11]), .B1(n1888), .Y(
        n1770) );
  AO22X1 U1378 ( .A0(AWADDR[8]), .A1(n1694), .B0(ARADDR[8]), .B1(n1888), .Y(
        n1754) );
  AOI32X1 U1379 ( .A0(IncreasedAddr_2_), .A1(n1707), .A2(n1887), .B0(AWADDR[2]), .B1(n1694), .Y(n1706) );
  AOI32X1 U1380 ( .A0(IncreasedAddr_1_), .A1(n1699), .A2(n1887), .B0(AWADDR[1]), .B1(n1694), .Y(n1698) );
  OAI222X1 U1381 ( .A0(n1766), .A1(n1878), .B0(n1712), .B1(n1768), .C0(n1743), 
        .C1(n1769), .Y(n1641) );
  NAND2BX1 U1382 ( .AN(SMC_ADDR[10]), .B(SMC_ADDR[11]), .Y(n1768) );
  AOI31X1 U1383 ( .A0(SMC_ADDR[10]), .A1(n1878), .A2(n1763), .B0(n1770), .Y(
        n1769) );
  INVX1 U1384 ( .A(n1761), .Y(n1766) );
  AO22X1 U1385 ( .A0(SMC_ADDR[10]), .A1(n1761), .B0(n1762), .B1(n1746), .Y(
        n1642) );
  AO21X1 U1386 ( .A0(n1763), .A1(n1876), .B0(n1765), .Y(n1762) );
  AO22X1 U1387 ( .A0(AWADDR[10]), .A1(n1694), .B0(ARADDR[10]), .B1(n1888), .Y(
        n1765) );
  AO22X1 U1388 ( .A0(SMC_ADDR[7]), .A1(n1744), .B0(n1745), .B1(n1746), .Y(
        n1645) );
  OAI2BB1X1 U1389 ( .A0N(ARADDR[7]), .A1N(n1888), .B0(n1747), .Y(n1745) );
  AOI32X1 U1390 ( .A0(n1748), .A1(n1867), .A2(n1887), .B0(AWADDR[7]), .B1(
        n1694), .Y(n1747) );
  OAI2BB1X1 U1391 ( .A0N(SMC_ADDR[6]), .A1N(n1684), .B0(n1736), .Y(n1646) );
  AOI32X1 U1392 ( .A0(SMC_ADDR[6]), .A1(n1737), .A2(n1887), .B0(n1738), .B1(
        n1689), .Y(n1736) );
  OAI2BB1X1 U1393 ( .A0N(ARADDR[6]), .A1N(n1888), .B0(n1739), .Y(n1738) );
  AOI32X1 U1394 ( .A0(n1740), .A1(n1870), .A2(n1887), .B0(AWADDR[6]), .B1(
        n1694), .Y(n1739) );
  OAI2BB1X1 U1395 ( .A0N(n1684), .A1N(GeneratedAddr_0_), .B0(n1685), .Y(n1652)
         );
  OAI2BB1X1 U1396 ( .A0N(ARADDR[0]), .A1N(n1888), .B0(n1691), .Y(n1688) );
  AOI32X1 U1397 ( .A0(n1692), .A1(n1860), .A2(n1887), .B0(AWADDR[0]), .B1(
        n1694), .Y(n1691) );
  OAI2BB1X1 U1398 ( .A0N(SMC_ADDR[2]), .A1N(n1684), .B0(n1703), .Y(n1650) );
  INVX1 U1399 ( .A(n1707), .Y(n1704) );
  OAI2BB1X1 U1400 ( .A0N(ARADDR[2]), .A1N(n1888), .B0(n1706), .Y(n1705) );
  OAI2BB1X1 U1401 ( .A0N(GeneratedAddr_1_), .A1N(n1684), .B0(n1695), .Y(n1651)
         );
  INVX1 U1402 ( .A(n1699), .Y(n1696) );
  OAI2BB1X1 U1403 ( .A0N(ARADDR[1]), .A1N(n1888), .B0(n1698), .Y(n1697) );
  INVX1 U1404 ( .A(n1771), .Y(n1763) );
  NAND3BX1 U1405 ( .AN(n1712), .B(SMC_ADDR[9]), .C(n1759), .Y(n1771) );
  AO22X1 U1406 ( .A0(ARADDR[5]), .A1(n1888), .B0(AWADDR[5]), .B1(n1694), .Y(
        n1730) );
  OAI33X1 U1407 ( .A0(n1712), .A1(n1731), .A2(n1872), .B0(n1712), .B1(
        SMC_ADDR[5]), .B2(n1733), .Y(n1729) );
  AO21X1 U1408 ( .A0(Len_2_), .A1(n1807), .B0(n1808), .Y(n1552) );
  OAI32X1 U1409 ( .A0(n1801), .A1(Len_2_), .A2(Len_1_), .B0(n1865), .B1(n1809), 
        .Y(n1808) );
  INVX1 U1410 ( .A(ARLEN[2]), .Y(n1809) );
  AO21X1 U1411 ( .A0(SMC_ADDR[4]), .A1(n1710), .B0(n1720), .Y(n1648) );
  OAI32X1 U1412 ( .A0(n1712), .A1(n1721), .A2(n1869), .B0(n1684), .B1(n1723), 
        .Y(n1720) );
  INVX1 U1413 ( .A(n1725), .Y(n1721) );
  AOI222X1 U1414 ( .A0(n1724), .A1(n1887), .B0(ARADDR[4]), .B1(n1888), .C0(
        AWADDR[4]), .C1(n1694), .Y(n1723) );
  AO21X1 U1415 ( .A0(SMC_ADDR[3]), .A1(n1710), .B0(n1711), .Y(n1649) );
  OAI32X1 U1416 ( .A0(n1712), .A1(n1868), .A2(n1714), .B0(n1684), .B1(n1715), 
        .Y(n1711) );
  AOI222X1 U1417 ( .A0(ARADDR[3]), .A1(n1888), .B0(n1716), .B1(n1887), .C0(
        AWADDR[3]), .C1(n1694), .Y(n1715) );
  NOR3BX1 U1418 ( .AN(n1868), .B(n1717), .C(n9), .Y(n1716) );
  NOR2X1 U1419 ( .A(GeneratedAddr_27_), .B(GeneratedAddr_28_), .Y(
        SMC_BANK_SEL[0]) );
  AO22X1 U1420 ( .A0(ARREADY), .A1(ARVALID), .B0(AWREADY), .B1(AWVALID), .Y(
        n1824) );
  AO21X1 U1421 ( .A0(Len_0_), .A1(n1865), .B0(n1798), .Y(n1806) );
  BUFX2 U1422 ( .A(WaitingRREADY), .Y(n1900) );
  NOR2X1 U1423 ( .A(RREADY), .B(n1683), .Y(n1653) );
  AO21X1 U1424 ( .A0(SMC_READ), .A1(n1863), .B0(WDATAAvailable), .Y(
        SMC_SRAM_START) );
  AO22X1 U1425 ( .A0(ARREADY), .A1(ARVALID), .B0(SMC_READ), .B1(n1846), .Y(
        NextState[1]) );
  AO21X1 U1426 ( .A0(ARADDR[27]), .A1(n1888), .B0(n1791), .Y(n1625) );
  AO22X1 U1427 ( .A0(GeneratedAddr_27_), .A1(n1887), .B0(AWADDR[27]), .B1(
        n1694), .Y(n1791) );
  AO21X1 U1428 ( .A0(ARADDR[23]), .A1(n1888), .B0(n1787), .Y(n1629) );
  AO22X1 U1429 ( .A0(SMC_ADDR[23]), .A1(n1887), .B0(AWADDR[23]), .B1(n1694), 
        .Y(n1787) );
  AO21X1 U1430 ( .A0(ARADDR[22]), .A1(n1888), .B0(n1786), .Y(n1630) );
  AO22X1 U1431 ( .A0(SMC_ADDR[22]), .A1(n1887), .B0(AWADDR[22]), .B1(n1694), 
        .Y(n1786) );
  AO21X1 U1432 ( .A0(ARADDR[21]), .A1(n1888), .B0(n1785), .Y(n1631) );
  AO22X1 U1433 ( .A0(SMC_ADDR[21]), .A1(n1887), .B0(AWADDR[21]), .B1(n1694), 
        .Y(n1785) );
  AO21X1 U1434 ( .A0(ARADDR[20]), .A1(n1888), .B0(n1784), .Y(n1632) );
  AO22X1 U1435 ( .A0(SMC_ADDR[20]), .A1(n1887), .B0(AWADDR[20]), .B1(n1694), 
        .Y(n1784) );
  AO21X1 U1436 ( .A0(ARADDR[19]), .A1(n1888), .B0(n1783), .Y(n1633) );
  AO22X1 U1437 ( .A0(SMC_ADDR[19]), .A1(n1887), .B0(AWADDR[19]), .B1(n1694), 
        .Y(n1783) );
  AO21X1 U1438 ( .A0(ARADDR[18]), .A1(n1888), .B0(n1782), .Y(n1634) );
  AO22X1 U1439 ( .A0(SMC_ADDR[18]), .A1(n1887), .B0(AWADDR[18]), .B1(n1694), 
        .Y(n1782) );
  AO21X1 U1440 ( .A0(ARADDR[17]), .A1(n1888), .B0(n1781), .Y(n1635) );
  AO22X1 U1441 ( .A0(SMC_ADDR[17]), .A1(n1887), .B0(AWADDR[17]), .B1(n1694), 
        .Y(n1781) );
  AO21X1 U1442 ( .A0(ARADDR[16]), .A1(n1888), .B0(n1780), .Y(n1636) );
  AO22X1 U1443 ( .A0(SMC_ADDR[16]), .A1(n1887), .B0(AWADDR[16]), .B1(n1694), 
        .Y(n1780) );
  AO21X1 U1444 ( .A0(ARADDR[15]), .A1(n1888), .B0(n1779), .Y(n1637) );
  AO22X1 U1445 ( .A0(SMC_ADDR[15]), .A1(n1887), .B0(AWADDR[15]), .B1(n1694), 
        .Y(n1779) );
  AO21X1 U1446 ( .A0(ARADDR[14]), .A1(n1888), .B0(n1778), .Y(n1638) );
  AO22X1 U1447 ( .A0(SMC_ADDR[14]), .A1(n1887), .B0(AWADDR[14]), .B1(n1694), 
        .Y(n1778) );
  AO21X1 U1448 ( .A0(ARADDR[13]), .A1(n1888), .B0(n1777), .Y(n1639) );
  AO22X1 U1449 ( .A0(SMC_ADDR[13]), .A1(n1887), .B0(AWADDR[13]), .B1(n1694), 
        .Y(n1777) );
  AO21X1 U1450 ( .A0(ARADDR[12]), .A1(n1888), .B0(n1776), .Y(n1640) );
  AO22X1 U1451 ( .A0(SMC_ADDR[12]), .A1(n1887), .B0(AWADDR[12]), .B1(n1694), 
        .Y(n1776) );
  AO21X1 U1452 ( .A0(Len_1_), .A1(n1865), .B0(n1806), .Y(n1807) );
  OAI222X1 U1453 ( .A0(n1802), .A1(n1857), .B0(n1865), .B1(n1805), .C0(Len_1_), 
        .C1(n1801), .Y(n1553) );
  INVX1 U1454 ( .A(ARLEN[1]), .Y(n1805) );
  INVX1 U1455 ( .A(n1806), .Y(n1802) );
  AO21X1 U1456 ( .A0(SMC_TRANS_SIZE[1]), .A1(n1865), .B0(n1829), .Y(n1543) );
  AO22X1 U1457 ( .A0(ARSIZE[1]), .A1(ARREADY), .B0(AWSIZE[1]), .B1(AWREADY), 
        .Y(n1829) );
  AO21X1 U1458 ( .A0(SMC_TRANS_SIZE[0]), .A1(n1865), .B0(n1828), .Y(n1544) );
  AO22X1 U1459 ( .A0(ARSIZE[0]), .A1(ARREADY), .B0(AWSIZE[0]), .B1(AWREADY), 
        .Y(n1828) );
  AO21X1 U1460 ( .A0(ReadOrWrite), .A1(n1887), .B0(n1888), .Y(n1623) );
  AO21X1 U1461 ( .A0(Len_0_), .A1(n1798), .B0(n1799), .Y(n1554) );
  AO21X1 U1462 ( .A0(ARLEN[0]), .A1(n_211), .B0(n1800), .Y(n1799) );
  INVX1 U1463 ( .A(n1801), .Y(n1800) );
  AO21X1 U1464 ( .A0(n1675), .A1(n1816), .B0(n1822), .Y(n1547) );
  AO22X1 U1465 ( .A0(AWID[3]), .A1(n1818), .B0(ARID[3]), .B1(n1889), .Y(n1822)
         );
  AO21X1 U1466 ( .A0(n1676), .A1(n1816), .B0(n1821), .Y(n1548) );
  AO22X1 U1467 ( .A0(AWID[2]), .A1(n1818), .B0(ARID[2]), .B1(n1889), .Y(n1821)
         );
  AO21X1 U1468 ( .A0(n1677), .A1(n1816), .B0(n1820), .Y(n1549) );
  AO22X1 U1469 ( .A0(AWID[1]), .A1(n1818), .B0(ARID[1]), .B1(n1889), .Y(n1820)
         );
  AO21X1 U1470 ( .A0(n1678), .A1(n1816), .B0(n1817), .Y(n1550) );
  AO22X1 U1471 ( .A0(AWID[0]), .A1(n1818), .B0(ARID[0]), .B1(n1889), .Y(n1817)
         );
  AO21X1 U1472 ( .A0(BurstLen_3_), .A1(n1865), .B0(n1832), .Y(n1540) );
  AO22X1 U1473 ( .A0(ARREADY), .A1(ARLEN[3]), .B0(AWLEN[3]), .B1(AWREADY), .Y(
        n1832) );
  AO21X1 U1474 ( .A0(BurstLen_2_), .A1(n1865), .B0(n1831), .Y(n1541) );
  AO22X1 U1475 ( .A0(ARREADY), .A1(ARLEN[2]), .B0(AWLEN[2]), .B1(AWREADY), .Y(
        n1831) );
  AO21X1 U1476 ( .A0(BurstLen_1_), .A1(n1865), .B0(n1830), .Y(n1542) );
  AO22X1 U1477 ( .A0(ARREADY), .A1(ARLEN[1]), .B0(AWLEN[1]), .B1(AWREADY), .Y(
        n1830) );
  AO21X1 U1478 ( .A0(Burst[1]), .A1(n1865), .B0(n1827), .Y(n1545) );
  AO22X1 U1479 ( .A0(ARBURST[1]), .A1(ARREADY), .B0(AWBURST[1]), .B1(AWREADY), 
        .Y(n1827) );
  AO21X1 U1480 ( .A0(Burst[0]), .A1(n1865), .B0(n1826), .Y(n1546) );
  AO22X1 U1481 ( .A0(ARBURST[0]), .A1(ARREADY), .B0(AWBURST[0]), .B1(AWREADY), 
        .Y(n1826) );
  AO21X1 U1482 ( .A0(Len_3_), .A1(n1807), .B0(n1812), .Y(n1551) );
  OAI31X1 U1483 ( .A0(n1798), .A1(n_211), .A2(n1813), .B0(n1814), .Y(n1812) );
  AOI32X1 U1484 ( .A0(Len_3_), .A1(n1865), .A2(Len_2_), .B0(ARLEN[3]), .B1(
        n_211), .Y(n1814) );
  OAI211X1 U1485 ( .A0(n1681), .A1(n1894), .B0(n1846), .C0(n1847), .Y(
        NextState[0]) );
  OA22X1 U1486 ( .A0(AWVALID), .A1(n1842), .B0(ARVALID), .B1(n1848), .Y(n1847)
         );
  AND2X2 U1487 ( .A(n1890), .B(n1824), .Y(n1889) );
  NAND4BX1 U1488 ( .AN(Len_3_), .B(n1859), .C(n1864), .D(n1857), .Y(n1813) );
  NAND2BX1 U1489 ( .AN(ReadOrWrite), .B(n_211), .Y(n1848) );
  AO22X1 U1490 ( .A0(SMC_RDATA[0]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_0_), .Y(RDATA[0]) );
  AO22X1 U1491 ( .A0(SMC_RDATA[1]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_1_), .Y(RDATA[1]) );
  AO22X1 U1492 ( .A0(SMC_RDATA[2]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_2_), .Y(RDATA[2]) );
  AO22X1 U1493 ( .A0(SMC_RDATA[3]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_3_), .Y(RDATA[3]) );
  AO22X1 U1494 ( .A0(SMC_RDATA[4]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_4_), .Y(RDATA[4]) );
  AO22X1 U1495 ( .A0(SMC_RDATA[5]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_5_), .Y(RDATA[5]) );
  AO22X1 U1496 ( .A0(SMC_RDATA[6]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_6_), .Y(RDATA[6]) );
  AO22X1 U1497 ( .A0(SMC_RDATA[7]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_7_), .Y(RDATA[7]) );
  AO22X1 U1498 ( .A0(SMC_RDATA[8]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_8_), .Y(RDATA[8]) );
  AO22X1 U1499 ( .A0(SMC_RDATA[9]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_9_), .Y(RDATA[9]) );
  AO22X1 U1500 ( .A0(SMC_RDATA[10]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_10_), .Y(RDATA[10]) );
  AO22X1 U1501 ( .A0(SMC_RDATA[11]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_11_), .Y(RDATA[11]) );
  AO22X1 U1502 ( .A0(SMC_RDATA[12]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_12_), .Y(RDATA[12]) );
  AO22X1 U1503 ( .A0(SMC_RDATA[13]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_13_), .Y(RDATA[13]) );
  AO22X1 U1504 ( .A0(SMC_RDATA[14]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_14_), .Y(RDATA[14]) );
  AO22X1 U1505 ( .A0(SMC_RDATA[15]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_15_), .Y(RDATA[15]) );
  AO22X1 U1506 ( .A0(SMC_RDATA[16]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_16_), .Y(RDATA[16]) );
  AO22X1 U1507 ( .A0(SMC_RDATA[17]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_17_), .Y(RDATA[17]) );
  AO22X1 U1508 ( .A0(SMC_RDATA[18]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_18_), .Y(RDATA[18]) );
  AO22X1 U1509 ( .A0(SMC_RDATA[19]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_19_), .Y(RDATA[19]) );
  AO22X1 U1510 ( .A0(SMC_RDATA[20]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_20_), .Y(RDATA[20]) );
  AO22X1 U1511 ( .A0(SMC_RDATA[21]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_21_), .Y(RDATA[21]) );
  AO22X1 U1512 ( .A0(SMC_RDATA[22]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_22_), .Y(RDATA[22]) );
  AO22X1 U1513 ( .A0(SMC_RDATA[23]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_23_), .Y(RDATA[23]) );
  AO22X1 U1514 ( .A0(SMC_RDATA[24]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_24_), .Y(RDATA[24]) );
  AO22X1 U1515 ( .A0(SMC_RDATA[25]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_25_), .Y(RDATA[25]) );
  AO22X1 U1516 ( .A0(SMC_RDATA[26]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_26_), .Y(RDATA[26]) );
  AO22X1 U1517 ( .A0(SMC_RDATA[27]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_27_), .Y(RDATA[27]) );
  AO22X1 U1518 ( .A0(SMC_RDATA[28]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_28_), .Y(RDATA[28]) );
  AO22X1 U1519 ( .A0(SMC_RDATA[29]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_29_), .Y(RDATA[29]) );
  AO22X1 U1520 ( .A0(SMC_RDATA[30]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_30_), .Y(RDATA[30]) );
  AO22X1 U1521 ( .A0(SMC_RDATA[31]), .A1(n1863), .B0(n1900), .B1(
        LatchedRDATA_31_), .Y(RDATA[31]) );
  NAND3BX1 U1522 ( .AN(n1844), .B(StateIsWRITE), .C(n1845), .Y(n1896) );
  NAND3BX1 U1523 ( .AN(n1844), .B(StateIsWRITE), .C(n1845), .Y(n1897) );
  NAND3BX1 U1524 ( .AN(n1844), .B(StateIsWRITE), .C(n1845), .Y(n1797) );
  OAI22X1 U1525 ( .A0(n1898), .A1(n1852), .B0(WSTRB[3]), .B1(n1797), .Y(n1619)
         );
  OAI22X1 U1526 ( .A0(n1899), .A1(n1853), .B0(WSTRB[2]), .B1(n1897), .Y(n1620)
         );
  OAI22X1 U1527 ( .A0(n1899), .A1(n1854), .B0(WSTRB[1]), .B1(n1896), .Y(n1621)
         );
  OAI22X1 U1528 ( .A0(n1898), .A1(n1855), .B0(WSTRB[0]), .B1(n1797), .Y(n1622)
         );
  NAND2BX1 U1529 ( .AN(n1895), .B(WDATAAvailable), .Y(n1845) );
  AO22X1 U1530 ( .A0(SMC_WDATA[31]), .A1(n1897), .B0(WDATA[31]), .B1(n1898), 
        .Y(n1587) );
  AO22X1 U1531 ( .A0(SMC_WDATA[30]), .A1(n1896), .B0(WDATA[30]), .B1(n1899), 
        .Y(n1588) );
  AO22X1 U1532 ( .A0(SMC_WDATA[29]), .A1(n1797), .B0(WDATA[29]), .B1(n1898), 
        .Y(n1589) );
  AO22X1 U1533 ( .A0(SMC_WDATA[28]), .A1(n1897), .B0(WDATA[28]), .B1(n1898), 
        .Y(n1590) );
  AO22X1 U1534 ( .A0(SMC_WDATA[27]), .A1(n1896), .B0(WDATA[27]), .B1(n1899), 
        .Y(n1591) );
  AO22X1 U1535 ( .A0(SMC_WDATA[26]), .A1(n1797), .B0(WDATA[26]), .B1(n1898), 
        .Y(n1592) );
  AO22X1 U1536 ( .A0(SMC_WDATA[25]), .A1(n1897), .B0(WDATA[25]), .B1(n1899), 
        .Y(n1593) );
  AO22X1 U1537 ( .A0(SMC_WDATA[24]), .A1(n1896), .B0(WDATA[24]), .B1(n1899), 
        .Y(n1594) );
  AO22X1 U1538 ( .A0(SMC_WDATA[23]), .A1(n1797), .B0(WDATA[23]), .B1(n1899), 
        .Y(n1595) );
  AO22X1 U1539 ( .A0(SMC_WDATA[22]), .A1(n1897), .B0(WDATA[22]), .B1(n1898), 
        .Y(n1596) );
  AO22X1 U1540 ( .A0(SMC_WDATA[21]), .A1(n1896), .B0(WDATA[21]), .B1(n1899), 
        .Y(n1597) );
  AO22X1 U1541 ( .A0(SMC_WDATA[20]), .A1(n1797), .B0(WDATA[20]), .B1(n1898), 
        .Y(n1598) );
  AO22X1 U1542 ( .A0(SMC_WDATA[19]), .A1(n1897), .B0(WDATA[19]), .B1(n1899), 
        .Y(n1599) );
  AO22X1 U1543 ( .A0(SMC_WDATA[18]), .A1(n1896), .B0(WDATA[18]), .B1(n1899), 
        .Y(n1600) );
  AO22X1 U1544 ( .A0(SMC_WDATA[17]), .A1(n1797), .B0(WDATA[17]), .B1(n1898), 
        .Y(n1601) );
  AO22X1 U1545 ( .A0(SMC_WDATA[16]), .A1(n1897), .B0(WDATA[16]), .B1(n1898), 
        .Y(n1602) );
  AO22X1 U1546 ( .A0(SMC_WDATA[15]), .A1(n1896), .B0(WDATA[15]), .B1(n1899), 
        .Y(n1603) );
  AO22X1 U1547 ( .A0(SMC_WDATA[14]), .A1(n1797), .B0(WDATA[14]), .B1(n1898), 
        .Y(n1604) );
  AO22X1 U1548 ( .A0(SMC_WDATA[13]), .A1(n1897), .B0(WDATA[13]), .B1(n1899), 
        .Y(n1605) );
  AO22X1 U1549 ( .A0(SMC_WDATA[12]), .A1(n1896), .B0(WDATA[12]), .B1(n1898), 
        .Y(n1606) );
  AO22X1 U1550 ( .A0(SMC_WDATA[11]), .A1(n1797), .B0(WDATA[11]), .B1(n1899), 
        .Y(n1607) );
  AO22X1 U1551 ( .A0(SMC_WDATA[10]), .A1(n1897), .B0(WDATA[10]), .B1(n1898), 
        .Y(n1608) );
  AO22X1 U1552 ( .A0(SMC_WDATA[9]), .A1(n1897), .B0(WDATA[9]), .B1(n1899), .Y(
        n1609) );
  AO22X1 U1553 ( .A0(SMC_WDATA[8]), .A1(n1797), .B0(WDATA[8]), .B1(n1898), .Y(
        n1610) );
  AO22X1 U1554 ( .A0(SMC_WDATA[7]), .A1(n1897), .B0(WDATA[7]), .B1(n1899), .Y(
        n1611) );
  AO22X1 U1555 ( .A0(SMC_WDATA[6]), .A1(n1797), .B0(WDATA[6]), .B1(n1898), .Y(
        n1612) );
  AO22X1 U1556 ( .A0(SMC_WDATA[5]), .A1(n1797), .B0(WDATA[5]), .B1(n1899), .Y(
        n1613) );
  AO22X1 U1557 ( .A0(SMC_WDATA[4]), .A1(n1897), .B0(WDATA[4]), .B1(n1898), .Y(
        n1614) );
  AO22X1 U1558 ( .A0(SMC_WDATA[3]), .A1(n1897), .B0(WDATA[3]), .B1(n1899), .Y(
        n1615) );
  AO22X1 U1559 ( .A0(SMC_WDATA[2]), .A1(n1797), .B0(WDATA[2]), .B1(n1898), .Y(
        n1616) );
  AO22X1 U1560 ( .A0(SMC_WDATA[1]), .A1(n1897), .B0(WDATA[1]), .B1(n1899), .Y(
        n1617) );
  AO22X1 U1561 ( .A0(SMC_WDATA[0]), .A1(n1897), .B0(WDATA[0]), .B1(n1898), .Y(
        n1618) );
  OAI2BB2X1 U1562 ( .A0N(WLAST), .A1N(n1898), .B0(n1891), .B1(BREADY), .Y(
        NextState[3]) );
  AO21X1 U1563 ( .A0(WVALID), .A1(StateIsWRITE), .B0(n1681), .Y(n1654) );
  OAI222X1 U1564 ( .A0(n1841), .A1(n1842), .B0(WLAST), .B1(n1877), .C0(n1899), 
        .C1(n1877), .Y(NextState[2]) );
  INVX1 U1565 ( .A(AWVALID), .Y(n1841) );
  AO22X1 U1566 ( .A0(SMC_RDATA[31]), .A1(n1895), .B0(LatchedRDATA_31_), .B1(
        n1774), .Y(n1555) );
  AO22X1 U1567 ( .A0(SMC_RDATA[30]), .A1(n1895), .B0(LatchedRDATA_30_), .B1(
        n1774), .Y(n1556) );
  AO22X1 U1568 ( .A0(SMC_RDATA[29]), .A1(n1895), .B0(LatchedRDATA_29_), .B1(
        n1774), .Y(n1557) );
  AO22X1 U1569 ( .A0(SMC_RDATA[28]), .A1(n1895), .B0(LatchedRDATA_28_), .B1(
        n1774), .Y(n1558) );
  AO22X1 U1570 ( .A0(SMC_RDATA[27]), .A1(n1895), .B0(LatchedRDATA_27_), .B1(
        n1774), .Y(n1559) );
  AO22X1 U1571 ( .A0(SMC_RDATA[26]), .A1(n1895), .B0(LatchedRDATA_26_), .B1(
        n1774), .Y(n1560) );
  AO22X1 U1572 ( .A0(SMC_RDATA[25]), .A1(n1895), .B0(LatchedRDATA_25_), .B1(
        n1774), .Y(n1561) );
  AO22X1 U1573 ( .A0(SMC_RDATA[24]), .A1(n1895), .B0(LatchedRDATA_24_), .B1(
        n1774), .Y(n1562) );
  AO22X1 U1574 ( .A0(SMC_RDATA[23]), .A1(n1895), .B0(LatchedRDATA_23_), .B1(
        n1774), .Y(n1563) );
  AO22X1 U1575 ( .A0(SMC_RDATA[22]), .A1(n1895), .B0(LatchedRDATA_22_), .B1(
        n1774), .Y(n1564) );
  AO22X1 U1576 ( .A0(SMC_RDATA[21]), .A1(n1895), .B0(LatchedRDATA_21_), .B1(
        n1774), .Y(n1565) );
  AO22X1 U1577 ( .A0(SMC_RDATA[20]), .A1(n1895), .B0(LatchedRDATA_20_), .B1(
        n1774), .Y(n1566) );
  AO22X1 U1578 ( .A0(SMC_RDATA[19]), .A1(n1895), .B0(LatchedRDATA_19_), .B1(
        n1774), .Y(n1567) );
  AO22X1 U1579 ( .A0(SMC_RDATA[18]), .A1(n1895), .B0(LatchedRDATA_18_), .B1(
        n1774), .Y(n1568) );
  AO22X1 U1580 ( .A0(SMC_RDATA[17]), .A1(n1895), .B0(LatchedRDATA_17_), .B1(
        n1774), .Y(n1569) );
  AO22X1 U1581 ( .A0(SMC_RDATA[16]), .A1(n1895), .B0(LatchedRDATA_16_), .B1(
        n1774), .Y(n1570) );
  AO22X1 U1582 ( .A0(SMC_RDATA[15]), .A1(n1895), .B0(LatchedRDATA_15_), .B1(
        n1774), .Y(n1571) );
  AO22X1 U1583 ( .A0(SMC_RDATA[14]), .A1(n1895), .B0(LatchedRDATA_14_), .B1(
        n1774), .Y(n1572) );
  AO22X1 U1584 ( .A0(SMC_RDATA[13]), .A1(n1895), .B0(LatchedRDATA_13_), .B1(
        n1774), .Y(n1573) );
  AO22X1 U1585 ( .A0(SMC_RDATA[12]), .A1(n1895), .B0(LatchedRDATA_12_), .B1(
        n1774), .Y(n1574) );
  AO22X1 U1586 ( .A0(SMC_RDATA[11]), .A1(n1895), .B0(LatchedRDATA_11_), .B1(
        n1774), .Y(n1575) );
  AO22X1 U1587 ( .A0(SMC_RDATA[10]), .A1(n1895), .B0(LatchedRDATA_10_), .B1(
        n1774), .Y(n1576) );
  AO22X1 U1588 ( .A0(SMC_RDATA[9]), .A1(n1895), .B0(LatchedRDATA_9_), .B1(
        n1774), .Y(n1577) );
  AO22X1 U1589 ( .A0(SMC_RDATA[8]), .A1(n1895), .B0(LatchedRDATA_8_), .B1(
        n1774), .Y(n1578) );
  AO22X1 U1590 ( .A0(SMC_RDATA[7]), .A1(n1895), .B0(LatchedRDATA_7_), .B1(
        n1774), .Y(n1579) );
  AO22X1 U1591 ( .A0(SMC_RDATA[6]), .A1(n1895), .B0(LatchedRDATA_6_), .B1(
        n1774), .Y(n1580) );
  AO22X1 U1592 ( .A0(SMC_RDATA[5]), .A1(n1895), .B0(LatchedRDATA_5_), .B1(
        n1774), .Y(n1581) );
  AO22X1 U1593 ( .A0(SMC_RDATA[4]), .A1(n1895), .B0(LatchedRDATA_4_), .B1(
        n1774), .Y(n1582) );
  AO22X1 U1594 ( .A0(SMC_RDATA[3]), .A1(n1895), .B0(LatchedRDATA_3_), .B1(
        n1774), .Y(n1583) );
  AO22X1 U1595 ( .A0(SMC_RDATA[2]), .A1(n1895), .B0(LatchedRDATA_2_), .B1(
        n1774), .Y(n1584) );
  AO22X1 U1596 ( .A0(SMC_RDATA[1]), .A1(n1895), .B0(LatchedRDATA_1_), .B1(
        n1774), .Y(n1585) );
  AO22X1 U1597 ( .A0(SMC_RDATA[0]), .A1(n1895), .B0(LatchedRDATA_0_), .B1(
        n1774), .Y(n1586) );
  AFHCONX2 U1_2 ( .A(SMC_ADDR[2]), .B(SMC_TRANS_SIZE[1]), .CI(carry_2_), .S(
        IncreasedAddr_2_), .CON(n9) );
  INVX1 U1598 ( .A(n10), .Y(carry_2_) );
  AFHCONX2 U1_1 ( .A(GeneratedAddr_1_), .B(SMC_TRANS_SIZE[0]), .CI(carry_1_), 
        .S(IncreasedAddr_1_), .CON(n10) );
  INVX1 U1599 ( .A(n1833), .Y(carry_1_) );
  NAND3BX1 U1600 ( .AN(n1875), .B(SMC_ADDR[7]), .C(n1748), .Y(n1772) );
  NAND3BX1 U1601 ( .AN(n1870), .B(SMC_ADDR[5]), .C(n1735), .Y(n1752) );
  NAND3BX1 U1602 ( .AN(Burst[1]), .B(SMC_ADDR[5]), .C(n1735), .Y(n1737) );
  NAND2BX1 U1603 ( .AN(n1868), .B(n1726), .Y(n1725) );
  OAI221X1 U1604 ( .A0(n1858), .A1(n1856), .B0(n1692), .B1(n1873), .C0(
        Burst[1]), .Y(n1726) );
  NAND2BX1 U1605 ( .AN(SMC_TRANS_SIZE[0]), .B(n1856), .Y(n1686) );
  OAI221X1 U1606 ( .A0(BurstLen_3_), .A1(n1893), .B0(SMC_TRANS_SIZE[1]), .B1(
        n1893), .C0(n1735), .Y(n1733) );
  INVX1 U1607 ( .A(n1775), .Y(n1735) );
  NAND3BX1 U1608 ( .AN(n9), .B(SMC_ADDR[4]), .C(SMC_ADDR[3]), .Y(n1775) );
  AO22X1 U1609 ( .A0(GeneratedAddr_1_), .A1(n1856), .B0(SMC_TRANS_SIZE[0]), 
        .B1(GeneratedAddr_1_), .Y(SMC_ADDR[1]) );
  OAI31X1 U1610 ( .A0(n1856), .A1(n1860), .A2(n1866), .B0(n1833), .Y(
        SMC_ADDR[0]) );
  NAND2BX1 U1611 ( .AN(n1865), .B(ReadOrWrite), .Y(n1842) );
  OAI211X1 U1612 ( .A0(n1861), .A1(n1866), .B0(n1709), .C0(n1892), .Y(n1707)
         );
  NOR2BX1 U1613 ( .AN(n1858), .B(SMC_TRANS_SIZE[1]), .Y(n1709) );
  NOR2X1 U1614 ( .A(BurstLen_3_), .B(n1893), .Y(n1892) );
  INVX1 U1615 ( .A(WVALID), .Y(n1844) );
  AOI21X1 U1616 ( .A0(BVALID), .A1(BREADY), .B0(State_4_), .Y(n1894) );
  NOR2BX1 U1617 ( .AN(StateIsWRITE), .B(n1681), .Y(WREADY) );
  DFFRX1 GeneratedAddr_reg_27_ ( .D(n1625), .CK(ACLK), .RN(ARESETn), .Q(
        GeneratedAddr_27_) );
  DFFRX1 State_reg_1_ ( .D(NextState[1]), .CK(ACLK), .RN(ARESETn), .Q(SMC_READ), .QN(SMC_WRITE) );
  DFFRX1 WaitingRREADY_reg ( .D(n1653), .CK(ACLK), .RN(ARESETn), .Q(
        WaitingRREADY), .QN(n1863) );
  DFFRX1 WDATAAvailable_reg ( .D(n1654), .CK(ACLK), .RN(ARESETn), .Q(
        WDATAAvailable) );
  DFFSX1 State_reg_0_ ( .D(NextState[0]), .CK(ACLK), .SN(ARESETn), .Q(n_211), 
        .QN(n1865) );
  DFFRX1 ReadOrWrite_reg ( .D(n1623), .CK(ACLK), .RN(ARESETn), .Q(ReadOrWrite), 
        .QN(n1890) );
  DFFRX1 Len_reg_1_ ( .D(n1553), .CK(ACLK), .RN(ARESETn), .Q(Len_1_), .QN(
        n1857) );
  DFFRX1 Len_reg_0_ ( .D(n1554), .CK(ACLK), .RN(ARESETn), .Q(Len_0_), .QN(
        n1864) );
  DFFRX1 Len_reg_2_ ( .D(n1552), .CK(ACLK), .RN(ARESETn), .Q(Len_2_), .QN(
        n1859) );
  DFFRX1 Id_reg_3_ ( .D(n1547), .CK(ACLK), .RN(ARESETn), .Q(n1675) );
  DFFRX1 Id_reg_2_ ( .D(n1548), .CK(ACLK), .RN(ARESETn), .Q(n1676) );
  DFFRX1 Id_reg_1_ ( .D(n1549), .CK(ACLK), .RN(ARESETn), .Q(n1677) );
  DFFRX1 Id_reg_0_ ( .D(n1550), .CK(ACLK), .RN(ARESETn), .Q(n1678) );
  DFFRX1 Len_reg_3_ ( .D(n1551), .CK(ACLK), .RN(ARESETn), .Q(Len_3_) );
  DFFRX1 LatchedRDATA_reg_31_ ( .D(n1555), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_31_) );
  DFFRX1 LatchedRDATA_reg_30_ ( .D(n1556), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_30_) );
  DFFRX1 LatchedRDATA_reg_29_ ( .D(n1557), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_29_) );
  DFFRX1 LatchedRDATA_reg_28_ ( .D(n1558), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_28_) );
  DFFRX1 LatchedRDATA_reg_27_ ( .D(n1559), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_27_) );
  DFFRX1 LatchedRDATA_reg_26_ ( .D(n1560), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_26_) );
  DFFRX1 LatchedRDATA_reg_25_ ( .D(n1561), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_25_) );
  DFFRX1 LatchedRDATA_reg_24_ ( .D(n1562), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_24_) );
  DFFRX1 LatchedRDATA_reg_23_ ( .D(n1563), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_23_) );
  DFFRX1 LatchedRDATA_reg_22_ ( .D(n1564), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_22_) );
  DFFRX1 LatchedRDATA_reg_21_ ( .D(n1565), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_21_) );
  DFFRX1 LatchedRDATA_reg_20_ ( .D(n1566), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_20_) );
  DFFRX1 LatchedRDATA_reg_19_ ( .D(n1567), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_19_) );
  DFFRX1 LatchedRDATA_reg_18_ ( .D(n1568), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_18_) );
  DFFRX1 LatchedRDATA_reg_17_ ( .D(n1569), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_17_) );
  DFFRX1 LatchedRDATA_reg_16_ ( .D(n1570), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_16_) );
  DFFRX1 LatchedRDATA_reg_15_ ( .D(n1571), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_15_) );
  DFFRX1 LatchedRDATA_reg_14_ ( .D(n1572), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_14_) );
  DFFRX1 LatchedRDATA_reg_13_ ( .D(n1573), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_13_) );
  DFFRX1 LatchedRDATA_reg_12_ ( .D(n1574), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_12_) );
  DFFRX1 LatchedRDATA_reg_11_ ( .D(n1575), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_11_) );
  DFFRX1 LatchedRDATA_reg_10_ ( .D(n1576), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_10_) );
  DFFRX1 LatchedRDATA_reg_9_ ( .D(n1577), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_9_) );
  DFFRX1 LatchedRDATA_reg_8_ ( .D(n1578), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_8_) );
  DFFRX1 LatchedRDATA_reg_7_ ( .D(n1579), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_7_) );
  DFFRX1 LatchedRDATA_reg_6_ ( .D(n1580), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_6_) );
  DFFRX1 LatchedRDATA_reg_5_ ( .D(n1581), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_5_) );
  DFFRX1 LatchedRDATA_reg_4_ ( .D(n1582), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_4_) );
  DFFRX1 LatchedRDATA_reg_3_ ( .D(n1583), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_3_) );
  DFFRX1 LatchedRDATA_reg_2_ ( .D(n1584), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_2_) );
  DFFRX1 LatchedRDATA_reg_1_ ( .D(n1585), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_1_) );
  DFFRX1 LatchedRDATA_reg_0_ ( .D(n1586), .CK(ACLK), .RN(ARESETn), .Q(
        LatchedRDATA_0_) );
  DFFRX1 GeneratedAddr_reg_0_ ( .D(n1652), .CK(ACLK), .RN(ARESETn), .Q(
        GeneratedAddr_0_), .QN(n1860) );
  DFFRX1 GeneratedAddr_reg_1_ ( .D(n1651), .CK(ACLK), .RN(ARESETn), .Q(
        GeneratedAddr_1_) );
  DFFRX1 GeneratedAddr_reg_2_ ( .D(n1650), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[2]) );
  DFFRX1 State_reg_2_ ( .D(NextState[2]), .CK(ACLK), .RN(ARESETn), .Q(
        StateIsWRITE), .QN(n1877) );
  DFFRX1 GeneratedAddr_reg_5_ ( .D(n1647), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[5]), .QN(n1872) );
  DFFRX1 Burst_reg_1_ ( .D(n1545), .CK(ACLK), .RN(ARESETn), .Q(Burst[1]), .QN(
        n1893) );
  DFFRX1 GeneratedAddr_reg_4_ ( .D(n1648), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[4]), .QN(n1869) );
  DFFRX1 GeneratedAddr_reg_7_ ( .D(n1645), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[7]), .QN(n1867) );
  DFFRX1 GeneratedAddr_reg_3_ ( .D(n1649), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[3]), .QN(n1868) );
  DFFRX1 GeneratedAddr_reg_9_ ( .D(n1643), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[9]), .QN(n1871) );
  DFFRX1 GeneratedAddr_reg_10_ ( .D(n1642), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[10]), .QN(n1876) );
  DFFRX1 GeneratedAddr_reg_11_ ( .D(n1641), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[11]), .QN(n1878) );
  DFFRX1 BurstLen_reg_3_ ( .D(n1540), .CK(ACLK), .RN(ARESETn), .Q(BurstLen_3_), 
        .QN(n1873) );
  DFFRX1 GeneratedAddr_reg_6_ ( .D(n1646), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[6]), .QN(n1870) );
  DFFRX1 GeneratedAddr_reg_8_ ( .D(n1644), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[8]), .QN(n1875) );
  DFFRX1 Burst_reg_0_ ( .D(n1546), .CK(ACLK), .RN(ARESETn), .Q(Burst[0]), .QN(
        n1874) );
  DFFRX1 BurstLen_reg_2_ ( .D(n1541), .CK(ACLK), .RN(ARESETn), .Q(BurstLen_2_), 
        .QN(n1858) );
  DFFRX1 BurstLen_reg_1_ ( .D(n1542), .CK(ACLK), .RN(ARESETn), .Q(BurstLen_1_), 
        .QN(n1861) );
  DFFRX1 State_reg_3_ ( .D(NextState[3]), .CK(ACLK), .RN(ARESETn), .Q(BVALID), 
        .QN(n1891) );
  DFFSX1 LatchedWBEB_reg_3_ ( .D(n1619), .CK(ACLK), .SN(ARESETn), .Q(
        SMC_WBEB[3]), .QN(n1852) );
  DFFSX1 LatchedWBEB_reg_2_ ( .D(n1620), .CK(ACLK), .SN(ARESETn), .Q(
        SMC_WBEB[2]), .QN(n1853) );
  DFFSX1 LatchedWBEB_reg_1_ ( .D(n1621), .CK(ACLK), .SN(ARESETn), .Q(
        SMC_WBEB[1]), .QN(n1854) );
  DFFSX1 LatchedWBEB_reg_0_ ( .D(n1622), .CK(ACLK), .SN(ARESETn), .Q(
        SMC_WBEB[0]), .QN(n1855) );
  DFFRX1 GeneratedAddr_reg_14_ ( .D(n1638), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[14]) );
  DFFRX1 GeneratedAddr_reg_12_ ( .D(n1640), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[12]) );
  DFFRX1 LatchedWDATA_reg_31_ ( .D(n1587), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[31]) );
  DFFRX1 LatchedWDATA_reg_30_ ( .D(n1588), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[30]) );
  DFFRX1 LatchedWDATA_reg_29_ ( .D(n1589), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[29]) );
  DFFRX1 LatchedWDATA_reg_28_ ( .D(n1590), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[28]) );
  DFFRX1 LatchedWDATA_reg_27_ ( .D(n1591), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[27]) );
  DFFRX1 LatchedWDATA_reg_26_ ( .D(n1592), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[26]) );
  DFFRX1 LatchedWDATA_reg_25_ ( .D(n1593), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[25]) );
  DFFRX1 LatchedWDATA_reg_24_ ( .D(n1594), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[24]) );
  DFFRX1 LatchedWDATA_reg_23_ ( .D(n1595), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[23]) );
  DFFRX1 LatchedWDATA_reg_22_ ( .D(n1596), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[22]) );
  DFFRX1 LatchedWDATA_reg_21_ ( .D(n1597), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[21]) );
  DFFRX1 LatchedWDATA_reg_20_ ( .D(n1598), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[20]) );
  DFFRX1 LatchedWDATA_reg_19_ ( .D(n1599), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[19]) );
  DFFRX1 LatchedWDATA_reg_18_ ( .D(n1600), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[18]) );
  DFFRX1 LatchedWDATA_reg_17_ ( .D(n1601), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[17]) );
  DFFRX1 LatchedWDATA_reg_16_ ( .D(n1602), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[16]) );
  DFFRX1 LatchedWDATA_reg_15_ ( .D(n1603), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[15]) );
  DFFRX1 LatchedWDATA_reg_14_ ( .D(n1604), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[14]) );
  DFFRX1 LatchedWDATA_reg_13_ ( .D(n1605), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[13]) );
  DFFRX1 LatchedWDATA_reg_12_ ( .D(n1606), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[12]) );
  DFFRX1 LatchedWDATA_reg_11_ ( .D(n1607), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[11]) );
  DFFRX1 LatchedWDATA_reg_10_ ( .D(n1608), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[10]) );
  DFFRX1 LatchedWDATA_reg_9_ ( .D(n1609), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[9]) );
  DFFRX1 LatchedWDATA_reg_8_ ( .D(n1610), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[8]) );
  DFFRX1 LatchedWDATA_reg_7_ ( .D(n1611), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[7]) );
  DFFRX1 LatchedWDATA_reg_6_ ( .D(n1612), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[6]) );
  DFFRX1 LatchedWDATA_reg_5_ ( .D(n1613), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[5]) );
  DFFRX1 LatchedWDATA_reg_4_ ( .D(n1614), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[4]) );
  DFFRX1 LatchedWDATA_reg_3_ ( .D(n1615), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[3]) );
  DFFRX1 LatchedWDATA_reg_2_ ( .D(n1616), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[2]) );
  DFFRX1 LatchedWDATA_reg_1_ ( .D(n1617), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[1]) );
  DFFRX1 LatchedWDATA_reg_0_ ( .D(n1618), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_WDATA[0]) );
  DFFRX1 GeneratedAddr_reg_13_ ( .D(n1639), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[13]) );
  DFFRX1 GeneratedAddr_reg_23_ ( .D(n1629), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[23]) );
  DFFRX1 GeneratedAddr_reg_22_ ( .D(n1630), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[22]) );
  DFFRX1 GeneratedAddr_reg_21_ ( .D(n1631), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[21]) );
  DFFRX1 GeneratedAddr_reg_20_ ( .D(n1632), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[20]) );
  DFFRX1 GeneratedAddr_reg_19_ ( .D(n1633), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[19]) );
  DFFRX1 GeneratedAddr_reg_18_ ( .D(n1634), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[18]) );
  DFFRX1 GeneratedAddr_reg_17_ ( .D(n1635), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[17]) );
  DFFRX1 GeneratedAddr_reg_16_ ( .D(n1636), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[16]) );
  DFFRX1 GeneratedAddr_reg_15_ ( .D(n1637), .CK(ACLK), .RN(ARESETn), .Q(
        SMC_ADDR[15]) );
  DFFRX1 State_reg_4_ ( .D(NextState[4]), .CK(ACLK), .RN(ARESETn), .Q(State_4_) );
  NAND3BX1 U1618 ( .AN(n1683), .B(RLAST), .C(RREADY), .Y(n1846) );
endmodule


module SRAM_CTRL ( CLK, RSTb, ADDR, WRITE, READ, WDATA, WBEB, TRANS_SIZE, 
        BANK_SEL, SRAM_START, ADDR_SETUP, ADDR_HOLD, CS_SETUP, CS_HOLD, 
        ACC_CYCLE, BUS_WIDTH, ADDR_SHIFT, READY, RDATA, EXT_ADDR, EXT_WDATA, 
        EXT_RDATA, EXT_CSb, EXT_WEb, EXT_OEb, EXT_BEb, EXT_WBEb, EXT_BIDEN );
  input [26:0] ADDR;
  input [31:0] WDATA;
  input [3:0] WBEB;
  input [2:0] TRANS_SIZE;
  input [8:0] BANK_SEL;
  input [2:0] ADDR_SETUP;
  input [2:0] ADDR_HOLD;
  input [2:0] CS_SETUP;
  input [2:0] CS_HOLD;
  input [3:0] ACC_CYCLE;
  input [1:0] BUS_WIDTH;
  input [1:0] ADDR_SHIFT;
  output [31:0] RDATA;
  output [26:0] EXT_ADDR;
  output [31:0] EXT_WDATA;
  input [31:0] EXT_RDATA;
  output [8:0] EXT_CSb;
  output [3:0] EXT_BEb;
  output [3:0] EXT_WBEb;
  input CLK, RSTb, WRITE, READ, SRAM_START;
  output READY, EXT_WEb, EXT_OEb, EXT_BIDEN;
  wire   i_addr_26_, i_addr_25_, i_addr_24_, i_addr_23_, i_addr_22_,
         i_addr_21_, i_addr_20_, i_addr_19_, i_addr_18_, i_addr_17_,
         i_addr_16_, i_addr_15_, i_addr_14_, i_addr_13_, i_addr_12_,
         i_addr_11_, i_addr_10_, i_addr_9_, i_addr_8_, i_addr_7_, i_addr_6_,
         i_addr_5_, i_addr_4_, i_addr_3_, i_addr_2_, i_addr_1_, i_wdata_31_,
         i_wdata_30_, i_wdata_29_, i_wdata_28_, i_wdata_27_, i_wdata_26_,
         i_wdata_25_, i_wdata_24_, i_wdata_23_, i_wdata_22_, i_wdata_21_,
         i_wdata_20_, i_wdata_19_, i_wdata_18_, i_wdata_17_, i_wdata_16_,
         i_wdata_15_, i_wdata_14_, i_wdata_13_, i_wdata_12_, i_wdata_11_,
         i_wdata_10_, i_wdata_9_, i_wdata_8_, i_addr1230_25_, i_addr1230_24_,
         i_addr1230_23_, i_addr1230_22_, i_addr1230_21_, i_addr1230_20_,
         i_addr1230_19_, i_addr1230_18_, i_addr1230_17_, i_addr1230_16_,
         i_addr1230_15_, i_addr1230_14_, i_addr1230_13_, i_addr1230_12_,
         i_addr1230_11_, i_addr1230_10_, i_addr1230_9_, i_addr1230_8_,
         i_addr1230_7_, i_addr1230_6_, i_addr1230_5_, i_addr1230_4_,
         i_addr1230_3_, i_addr1230_2_, i_addr1230_1_, i_addr1234_25_,
         i_addr1234_24_, i_addr1234_23_, i_addr1234_22_, i_addr1234_21_,
         i_addr1234_20_, i_addr1234_19_, i_addr1234_18_, i_addr1234_17_,
         i_addr1234_16_, i_addr1234_0_, n2816, n2817, n2818, n2819, n2820,
         n2821, n2822, n2823, n3192, n3193, n3194, n3195, n3196, n3197, n3198,
         n3199, n3200, n3201, n3202, n3203, n3204, n3205, n3206, n3207, n3208,
         n3209, n3210, n3211, n3212, n3213, n3214, n3215, n3216, n3217, n3218,
         n3219, n3220, n3221, n3222, n3223, n3224, n3225, n3226, n3227, n3228,
         n3229, n3230, n3231, n3232, n3233, n3234, n3235, n3236, n3237, n3238,
         n3239, n3240, n3241, n3242, n3243, n3244, n3245, n3246, n3247, n3248,
         n3249, n3250, n3251, n3252, n3253, n3254, n3255, n3256, n3257, n3258,
         n3259, n3260, n3261, n3262, n3263, n3264, carry, carry0, carry1,
         carry2, carry3, carry4, carry5, carry6, carry7, carry8, carry9,
         carry10, carry11, carry12, carry13, carry14, carry15, carry16,
         carry17, carry18, carry19, carry20, carry21, carry22, n110, n210, n35,
         n41, n51, n61, n71, n81, n91, n101, n111, n121, n131, n141, n151,
         n161, n171, n181, n191, n201, n211, n221, n231, n241, n251, carry_16_,
         n1, n3294, n3297, n3298, n3299, n3300, n3301, n3302, n3303, n3304,
         n3305, n3306, n3307, n3308, n3309, n3310, n3311, n3312, n3313, n3314,
         n3315, n3316, n3317, n3318, n3319, n3320, n3321, n3322, n3323, n3324,
         n3325, n3326, n3328, n3329, n3330, n3331, n3332, n3333, n3334, n3335,
         n3336, n3337, n3338, n3339, n3340, n3341, n3342, n3343, n3344, n3345,
         n3346, n3347, n3348, n3349, n3350, n3351, n3352, n3353, n3354, n3355,
         n3356, n3357, n3358, n3359, n3360, n3361, n3362, n3363, n3364, n3365,
         n3366, n3367, n3368, n3369, n3370, n3371, n3372, n3373, n3374, n3375,
         n3376, n3377, n3378, n3379, n3380, n3381, n3383, n3384, n3385, n3386,
         n3388, n3389, n3390, n3391, n3393, n3394, n3395, n3396, n3398, n3399,
         n3400, n3402, n3403, n3404, n3405, n3406, n3408, n3409, n3410, n3412,
         n3413, n3414, n3415, n3416, n3418, n3419, n3420, n3422, n3423, n3424,
         n3425, n3426, n3428, n3429, n3430, n3432, n3433, n3434, n3435, n3436,
         n3438, n3439, n3440, n3442, n3443, n3444, n3445, n3447, n3448, n3449,
         n3450, n3451, n3453, n3454, n3455, n3456, n3457, n3458, n3459, n3460,
         n3461, n3462, n3463, n3464, n3465, n3466, n3468, n3469, n3470, n3471,
         n3472, n3473, n3474, n3475, n3476, n3478, n3479, n3480, n3481, n3482,
         n3483, n3484, n3485, n3486, n3487, n3488, n3489, n3490, n3491, n3492,
         n3493, n3494, n3495, n3496, n3497, n3498, n3499, n3500, n3501, n3502,
         n3503, n3504, n3505, n3506, n3507, n3508, n3509, n3510, n3511, n3512,
         n3513, n3514, n3515, n3516, n3517, n3518, n3519, n3520, n3521, n3522,
         n3523, n3524, n3525, n3526, n3527, n3528, n3529, n3530, n3531, n3532,
         n3533, n3534, n3535, n3536, n3537, n3538, n3539, n3540, n3541, n3542,
         n3543, n3544, n3545, n3546, n3547, n3548, n3549, n3550, n3551, n3552,
         n3553, n3554, n3555, n3556, n3557, n3558, n3560, n3561, n3562, n3563,
         n3564, n3567, n3568, n3569, n3570, n3571, n3572, n3573, n3574, n3575,
         n3576, n3579, n3580, n3584, n3585, n3586, n3587, n3588, n3589, n3590,
         n3591, n3593, n3595, n3596, n3601, n3602, n3603, n3605, n3606, n3607,
         n3609, n3612, n3616, n3620, n3624, n3628, n3632, n3635, n3637, n3640,
         n3641, n3642, n3643, n3644, n3645, n3646, n3649, n3651, n3652, n3654,
         n3655, n3656, n3659, n3660, n3661, n3662, n3663, n3664, n3665, n3666,
         n3667, n3671, n3672, n3675, n3676, n3680, n3683, n3684, n3685, n3686,
         n3687, n3700, n3701, n3702, n3703, n3704, n3705, n3706, n3707, n3708,
         n3709, n3710, n3711, n3712, n3713, n3714, n3715, n3716, n3717, n3718,
         n3719, n3720, n3721, n3722, n3723, n3724, n3725, n3726, n3727, n3728,
         n3729, n3730, n3731, n3732, n3733, n3734, n3735, n3736, n3737, n3738,
         n3739, n3740, n3741, n3742, n3743, n3744, n3745, n3746, n3747, n3748,
         n3749, n3750, n3751, n3752, n3753, n3754, n3755, n3756, n3757, n3758,
         n3759, n3760, n3761, n3762, n3763, n3764, n3765, n3766, n3767, n3768,
         n3769, n3770, n3771, n3772, n3773, n3774, n3775, n3776, n3777, n3778,
         n3779, n3780;
  wire   [1:0] repeat_cnt;
  wire   [3:0] timing_cnt;
  wire   [6:0] ns;
  wire   [6:0] cs;

  AHHCONX2 U1_1_1 ( .A(i_addr_1_), .CI(n3780), .S(i_addr1230_1_), .CON(n251)
         );
  AHHCONX2 U1_1_2 ( .A(i_addr_2_), .CI(carry22), .S(i_addr1230_2_), .CON(n241)
         );
  AHHCONX2 U1_1_3 ( .A(i_addr_3_), .CI(carry21), .S(i_addr1230_3_), .CON(n231)
         );
  AHHCONX2 U1_1_4 ( .A(i_addr_4_), .CI(carry20), .S(i_addr1230_4_), .CON(n221)
         );
  AHHCONX2 U1_1_5 ( .A(i_addr_5_), .CI(carry19), .S(i_addr1230_5_), .CON(n211)
         );
  AHHCONX2 U1_1_6 ( .A(i_addr_6_), .CI(carry18), .S(i_addr1230_6_), .CON(n201)
         );
  AHHCONX2 U1_1_7 ( .A(i_addr_7_), .CI(carry17), .S(i_addr1230_7_), .CON(n191)
         );
  AHHCONX2 U1_1_8 ( .A(i_addr_8_), .CI(carry16), .S(i_addr1230_8_), .CON(n181)
         );
  AHHCONX2 U1_1_9 ( .A(i_addr_9_), .CI(carry15), .S(i_addr1230_9_), .CON(n171)
         );
  AHHCONX2 U1_1_10 ( .A(i_addr_10_), .CI(carry14), .S(i_addr1230_10_), .CON(
        n161) );
  AHHCONX2 U1_1_11 ( .A(i_addr_11_), .CI(carry13), .S(i_addr1230_11_), .CON(
        n151) );
  AHHCONX2 U1_1_12 ( .A(i_addr_12_), .CI(carry12), .S(i_addr1230_12_), .CON(
        n141) );
  AHHCONX2 U1_1_13 ( .A(i_addr_13_), .CI(carry11), .S(i_addr1230_13_), .CON(
        n131) );
  AHHCONX2 U1_1_14 ( .A(i_addr_14_), .CI(carry10), .S(i_addr1230_14_), .CON(
        n121) );
  AHHCONX2 U1_1_15 ( .A(i_addr_15_), .CI(carry9), .S(i_addr1230_15_), .CON(
        n111) );
  AHHCONX2 U1_1_16 ( .A(i_addr_16_), .CI(carry8), .S(i_addr1230_16_), .CON(
        n101) );
  AHHCONX2 U1_1_17 ( .A(i_addr_17_), .CI(carry7), .S(i_addr1230_17_), .CON(n91) );
  AHHCONX2 U1_1_18 ( .A(i_addr_18_), .CI(carry6), .S(i_addr1230_18_), .CON(n81) );
  AHHCONX2 U1_1_19 ( .A(i_addr_19_), .CI(carry5), .S(i_addr1230_19_), .CON(n71) );
  AHHCONX2 U1_1_20 ( .A(i_addr_20_), .CI(carry4), .S(i_addr1230_20_), .CON(n61) );
  AHHCONX2 U1_1_21 ( .A(i_addr_21_), .CI(carry3), .S(i_addr1230_21_), .CON(n51) );
  AHHCONX2 U1_1_22 ( .A(i_addr_22_), .CI(carry2), .S(i_addr1230_22_), .CON(n41) );
  AHHCONX2 U1_1_23 ( .A(i_addr_23_), .CI(carry1), .S(i_addr1230_23_), .CON(n35) );
  AHHCONX2 U1_1_24 ( .A(i_addr_24_), .CI(carry0), .S(i_addr1230_24_), .CON(
        n210) );
  AHHCONX2 U1_1_25 ( .A(i_addr_25_), .CI(carry), .S(i_addr1230_25_), .CON(n110) );
  NAND2BX4 U2375 ( .AN(n3558), .B(n3383), .Y(n3551) );
  INVX1 U2619 ( .A(ns[0]), .Y(n3538) );
  INVX3 U2620 ( .A(n3596), .Y(n3512) );
  NAND2BX2 U2621 ( .AN(ADDR_SETUP[0]), .B(n3516), .Y(n3596) );
  NAND2BX1 U2622 ( .AN(n3758), .B(n3769), .Y(n3587) );
  INVX1 U2623 ( .A(n3563), .Y(n3558) );
  NAND2BX1 U2624 ( .AN(BUS_WIDTH[0]), .B(BUS_WIDTH[1]), .Y(n3298) );
  AO21X1 U2625 ( .A0(n3512), .A1(n3533), .B0(n3571), .Y(n3563) );
  OAI211X1 U2626 ( .A0(n3569), .A1(n3551), .B0(n3588), .C0(n3589), .Y(ns[0])
         );
  OAI32X1 U2627 ( .A0(n3567), .A1(n3586), .A2(n3587), .B0(n3538), .B1(n3472), 
        .Y(READY) );
  INVX1 U2628 ( .A(ADDR_SETUP[1]), .Y(n3516) );
  NAND3BX1 U2629 ( .AN(n3380), .B(n3472), .C(n3469), .Y(n3391) );
  NAND2BX1 U2630 ( .AN(ADDR_SHIFT[1]), .B(ADDR_SHIFT[0]), .Y(n3686) );
  INVX1 U2631 ( .A(n3491), .Y(n3503) );
  INVX1 U2632 ( .A(n3340), .Y(n3332) );
  NAND2BX1 U2633 ( .AN(n3297), .B(n3341), .Y(n3340) );
  NAND3BX1 U2634 ( .AN(n3549), .B(n3499), .C(n3500), .Y(n3491) );
  NAND3BX1 U2635 ( .AN(n3495), .B(n3518), .C(n3548), .Y(n3549) );
  INVX1 U2636 ( .A(n3321), .Y(n3305) );
  INVX1 U2637 ( .A(n3500), .Y(n3507) );
  INVX1 U2638 ( .A(n3520), .Y(n3495) );
  INVX1 U2639 ( .A(n3548), .Y(n3494) );
  INVX1 U2640 ( .A(n3518), .Y(n3497) );
  INVX1 U2641 ( .A(n3488), .Y(n3489) );
  INVX1 U2642 ( .A(n3571), .Y(n3569) );
  NAND2BX1 U2643 ( .AN(n3754), .B(n3560), .Y(n3543) );
  NAND2BX1 U2644 ( .AN(n3323), .B(n3300), .Y(n3321) );
  INVX1 U2645 ( .A(n3329), .Y(n3341) );
  AO22X1 U2646 ( .A0(n3539), .A1(n3540), .B0(n3541), .B1(n3542), .Y(ns[6]) );
  INVX1 U2647 ( .A(n3543), .Y(n3541) );
  NAND2BX1 U2648 ( .AN(ns[6]), .B(n3538), .Y(n3488) );
  NAND2BX1 U2649 ( .AN(n3539), .B(ns[5]), .Y(n3518) );
  NAND2BX1 U2650 ( .AN(n3557), .B(ns[1]), .Y(n3499) );
  NAND2BX1 U2651 ( .AN(n3550), .B(ns[2]), .Y(n3500) );
  NAND2BX1 U2652 ( .AN(n3560), .B(ns[3]), .Y(n3548) );
  NAND2BX1 U2653 ( .AN(n3299), .B(n3300), .Y(n3294) );
  NAND2BX1 U2654 ( .AN(n3580), .B(ns[4]), .Y(n3520) );
  AO21X1 U2655 ( .A0(n3510), .A1(n3534), .B0(n3571), .Y(n3573) );
  NAND2BX1 U2656 ( .AN(n3561), .B(n3562), .Y(ns[3]) );
  AOI32X1 U2657 ( .A0(n3552), .A1(n3474), .A2(n3563), .B0(n3550), .B1(n3540), 
        .Y(n3562) );
  OAI33X1 U2658 ( .A0(n3543), .A1(n3542), .A2(n3570), .B0(n3551), .B1(n3571), 
        .B2(n3547), .Y(n3561) );
  INVX1 U2659 ( .A(n3573), .Y(n3570) );
  INVX1 U2660 ( .A(n3347), .Y(n3348) );
  AO22X1 U2661 ( .A0(n3495), .A1(n3510), .B0(n3511), .B1(n3512), .Y(n3509) );
  INVX1 U2662 ( .A(n3499), .Y(n3511) );
  INVX1 U2663 ( .A(n3546), .Y(n3510) );
  INVX1 U2664 ( .A(n3391), .Y(n3378) );
  INVX1 U2665 ( .A(n3469), .Y(n3381) );
  INVX1 U2666 ( .A(n3471), .Y(n3380) );
  INVX1 U2667 ( .A(n3575), .Y(n3580) );
  INVX1 U2668 ( .A(n3486), .Y(n3475) );
  NAND2BX1 U2669 ( .AN(n3649), .B(BANK_SEL[6]), .Y(EXT_CSb[6]) );
  INVX1 U2670 ( .A(n3649), .Y(n3651) );
  INVX1 U2671 ( .A(n3342), .Y(n3297) );
  INVX1 U2672 ( .A(ADDR_SETUP[2]), .Y(n3533) );
  NAND2BX1 U2673 ( .AN(n3553), .B(SRAM_START), .Y(n3571) );
  INVX1 U2674 ( .A(n3593), .Y(n3568) );
  NAND2BX1 U2675 ( .AN(n3769), .B(n3595), .Y(n3593) );
  INVX3 U2676 ( .A(n3472), .Y(n3383) );
  INVX1 U2677 ( .A(n3567), .Y(n3579) );
  INVX1 U2678 ( .A(n3586), .Y(n3595) );
  INVX1 U2679 ( .A(n3659), .Y(n3584) );
  INVX1 U2680 ( .A(n3537), .Y(n3527) );
  DFFRX1 i_addr_reg_1_ ( .D(n3231), .CK(CLK), .RN(RSTb), .Q(i_addr_1_), .QN(
        n3707) );
  INVX1 U2681 ( .A(n1), .Y(n3470) );
  INVX1 U2682 ( .A(n3402), .Y(n3396) );
  INVX1 U2683 ( .A(n3432), .Y(n3426) );
  INVX1 U2684 ( .A(n3422), .Y(n3416) );
  INVX1 U2685 ( .A(n3412), .Y(n3406) );
  INVX1 U2686 ( .A(n3442), .Y(n3436) );
  INVX1 U2687 ( .A(n110), .Y(n3468) );
  NAND2BX1 U2688 ( .AN(n3299), .B(n3344), .Y(n3329) );
  NAND2BX1 U2689 ( .AN(ADDR_HOLD[0]), .B(n3519), .Y(n3522) );
  AOI2BB1X1 U2690 ( .A0N(n3522), .A1N(ADDR_HOLD[2]), .B0(n3571), .Y(n3754) );
  OAI222X1 U2691 ( .A0(n3553), .A1(n3575), .B0(n3540), .B1(n3576), .C0(n3543), 
        .C1(n3573), .Y(ns[5]) );
  AO21X1 U2692 ( .A0(n3298), .A1(n3320), .B0(n3321), .Y(n3303) );
  INVX1 U2693 ( .A(n3343), .Y(n3331) );
  NAND2BX1 U2694 ( .AN(n3298), .B(n3341), .Y(n3343) );
  INVX1 U2695 ( .A(n3324), .Y(n3300) );
  OAI31X1 U2696 ( .A0(n3325), .A1(n3326), .A2(n3707), .B0(n3328), .Y(n3324) );
  NAND2BX1 U2697 ( .AN(n3323), .B(n3344), .Y(n3347) );
  NAND2BX1 U2698 ( .AN(CS_SETUP[2]), .B(n3508), .Y(n3547) );
  INVX1 U2699 ( .A(n3574), .Y(n3542) );
  NAND3BX1 U2700 ( .AN(CS_HOLD[2]), .B(n3510), .C(n3569), .Y(n3574) );
  NAND2BX1 U2701 ( .AN(CS_HOLD[0]), .B(n3521), .Y(n3546) );
  NAND4BX1 U2702 ( .AN(ADDR_SETUP[2]), .B(n3512), .C(n3547), .D(n3569), .Y(
        n3552) );
  NAND2BX1 U2703 ( .AN(n3322), .B(n3305), .Y(n3302) );
  AO22X1 U2704 ( .A0(n3754), .A1(n3560), .B0(n3580), .B1(n3553), .Y(ns[4]) );
  AO22X1 U2705 ( .A0(n3557), .A1(n3553), .B0(n3558), .B1(n3486), .Y(ns[1]) );
  OAI221X1 U2706 ( .A0(n3551), .A1(n3552), .B0(n3553), .B1(n3554), .C0(n3555), 
        .Y(ns[2]) );
  OA22X1 U2707 ( .A0(n3473), .A1(n3552), .B0(n3540), .B1(n3556), .Y(n3555) );
  AOI21X1 U2708 ( .A0(n3297), .A1(n3298), .B0(n3294), .Y(n3755) );
  AO21X1 U2709 ( .A0(n3507), .A1(n3544), .B0(n3545), .Y(n3528) );
  INVX1 U2710 ( .A(n3547), .Y(n3544) );
  OAI33X1 U2711 ( .A0(n3520), .A1(CS_HOLD[2]), .A2(n3546), .B0(n3518), .B1(
        ADDR_HOLD[2]), .B2(n3522), .Y(n3545) );
  OAI31X1 U2712 ( .A0(n3500), .A1(n3508), .A2(n3530), .B0(n3531), .Y(n3529) );
  INVX1 U2713 ( .A(CS_SETUP[2]), .Y(n3530) );
  AOI31X1 U2714 ( .A0(ADDR_HOLD[2]), .A1(n3522), .A2(n3497), .B0(n3532), .Y(
        n3531) );
  OAI33X1 U2715 ( .A0(n3499), .A1(n3512), .A2(n3533), .B0(n3520), .B1(n3510), 
        .B2(n3534), .Y(n3532) );
  INVX1 U2716 ( .A(n3572), .Y(n3508) );
  NAND2BX1 U2717 ( .AN(CS_SETUP[0]), .B(n3523), .Y(n3572) );
  AOI211X1 U2718 ( .A0(n3513), .A1(n3507), .B0(n3514), .C0(n3515), .Y(n3505)
         );
  NOR2BX1 U2719 ( .AN(CS_SETUP[0]), .B(n3523), .Y(n3513) );
  OAI32X1 U2720 ( .A0(n3520), .A1(n3521), .A2(n3496), .B0(n3522), .B1(n3518), 
        .Y(n3514) );
  OAI33X1 U2721 ( .A0(n3499), .A1(n3516), .A2(n3517), .B0(n3518), .B1(n3519), 
        .B2(n3498), .Y(n3515) );
  INVX1 U2722 ( .A(CS_HOLD[2]), .Y(n3534) );
  NAND3BX1 U2723 ( .AN(n3713), .B(n3584), .C(n3585), .Y(n3575) );
  NAND2BX1 U2724 ( .AN(n3474), .B(n3472), .Y(n3486) );
  INVX1 U2725 ( .A(n3371), .Y(n3560) );
  INVX1 U2726 ( .A(n3473), .Y(n3474) );
  INVX1 U2727 ( .A(n3564), .Y(n3585) );
  INVX1 U2728 ( .A(ADDR_HOLD[0]), .Y(n3498) );
  INVX1 U2729 ( .A(CS_HOLD[0]), .Y(n3496) );
  NAND2BX1 U2730 ( .AN(n3322), .B(n3474), .Y(n3469) );
  AO21X1 U2731 ( .A0(n3298), .A1(n3320), .B0(n3377), .Y(n3346) );
  INVX1 U2732 ( .A(n3480), .Y(n3377) );
  NAND2BX1 U2733 ( .AN(n3373), .B(n3479), .Y(n3480) );
  OAI211X1 U2734 ( .A0(n3473), .A1(n3320), .B0(n3472), .C0(n3469), .Y(n3471)
         );
  AO21X1 U2735 ( .A0(n3378), .A1(n3442), .B0(n3380), .Y(n3434) );
  AO21X1 U2736 ( .A0(n3378), .A1(n3432), .B0(n3380), .Y(n3424) );
  AO21X1 U2737 ( .A0(n3378), .A1(n3422), .B0(n3380), .Y(n3414) );
  AO21X1 U2738 ( .A0(n3378), .A1(n3412), .B0(n3380), .Y(n3404) );
  AO21X1 U2739 ( .A0(n3378), .A1(n3402), .B0(n3380), .Y(n3394) );
  AO21X1 U2740 ( .A0(n3378), .A1(n3707), .B0(n3380), .Y(n3385) );
  AO21X1 U2741 ( .A0(n3378), .A1(n3449), .B0(n3380), .Y(n3444) );
  INVX1 U2742 ( .A(n3576), .Y(n3539) );
  INVX1 U2743 ( .A(n3556), .Y(n3550) );
  INVX1 U2744 ( .A(n3553), .Y(n3540) );
  INVX1 U2745 ( .A(n3554), .Y(n3557) );
  INVX1 U2746 ( .A(n3375), .Y(n3323) );
  NAND3BX1 U2747 ( .AN(n3780), .B(n3376), .C(n3346), .Y(n3375) );
  INVX1 U2748 ( .A(n3345), .Y(n3299) );
  NAND3BX1 U2749 ( .AN(n3326), .B(n3780), .C(n3346), .Y(n3345) );
  INVX1 U2750 ( .A(n3372), .Y(n3325) );
  NAND3BX1 U2751 ( .AN(n3373), .B(n3320), .C(n3374), .Y(n3372) );
  INVX1 U2752 ( .A(n3346), .Y(n3374) );
  NAND3BX1 U2753 ( .AN(n3579), .B(n3656), .C(n3585), .Y(n3649) );
  INVX1 U2754 ( .A(n3591), .Y(n3656) );
  AO21X1 U2755 ( .A0(n3353), .A1(n3707), .B0(n3350), .Y(n3601) );
  NAND2BX1 U2756 ( .AN(n3353), .B(n3322), .Y(n3342) );
  NAND2BX1 U2757 ( .AN(n3649), .B(BANK_SEL[4]), .Y(EXT_CSb[4]) );
  NAND3BX1 U2758 ( .AN(n3644), .B(n3350), .C(n3643), .Y(EXT_WBEb[2]) );
  NAND3BX1 U2759 ( .AN(n3642), .B(n3350), .C(n3643), .Y(EXT_WBEb[3]) );
  NAND3BX1 U2760 ( .AN(n3644), .B(n3350), .C(n3651), .Y(EXT_BEb[2]) );
  NAND3BX1 U2761 ( .AN(n3642), .B(n3350), .C(n3651), .Y(EXT_BEb[3]) );
  NAND2BX1 U2762 ( .AN(n3649), .B(BANK_SEL[3]), .Y(EXT_CSb[3]) );
  NAND2BX1 U2763 ( .AN(n3649), .B(BANK_SEL[2]), .Y(EXT_CSb[2]) );
  NAND2BX1 U2764 ( .AN(n3649), .B(BANK_SEL[1]), .Y(EXT_CSb[1]) );
  NAND2BX1 U2765 ( .AN(n3649), .B(BANK_SEL[0]), .Y(EXT_CSb[0]) );
  NAND2BX1 U2766 ( .AN(EXT_WEb), .B(n3645), .Y(EXT_WBEb[1]) );
  NAND2BX1 U2767 ( .AN(n3649), .B(n3645), .Y(EXT_BEb[1]) );
  NAND2BX1 U2768 ( .AN(n3649), .B(BANK_SEL[8]), .Y(EXT_CSb[8]) );
  NAND2BX1 U2769 ( .AN(n3646), .B(n3643), .Y(EXT_WBEb[0]) );
  NAND2BX1 U2770 ( .AN(n3646), .B(n3651), .Y(EXT_BEb[0]) );
  NAND2BX1 U2771 ( .AN(n3649), .B(BANK_SEL[7]), .Y(EXT_CSb[7]) );
  OAI222X1 U2772 ( .A0(n3715), .A1(n3778), .B0(n3734), .B1(n3685), .C0(n3707), 
        .C1(n3686), .Y(EXT_ADDR[0]) );
  OAI222X1 U2773 ( .A0(n3707), .A1(n3779), .B0(n3734), .B1(n3686), .C0(n3701), 
        .C1(n3687), .Y(EXT_ADDR[1]) );
  OAI222X1 U2774 ( .A0(n3734), .A1(n3779), .B0(n3701), .B1(n3686), .C0(n3716), 
        .C1(n3687), .Y(EXT_ADDR[2]) );
  OAI222X1 U2775 ( .A0(n3701), .A1(n3779), .B0(n3730), .B1(n3685), .C0(n3716), 
        .C1(n3686), .Y(EXT_ADDR[3]) );
  OAI222X1 U2776 ( .A0(n3716), .A1(n3684), .B0(n3730), .B1(n3686), .C0(n3708), 
        .C1(n3687), .Y(EXT_ADDR[4]) );
  OAI222X1 U2777 ( .A0(n3730), .A1(n3779), .B0(n3712), .B1(n3685), .C0(n3708), 
        .C1(n3686), .Y(EXT_ADDR[5]) );
  OAI222X1 U2778 ( .A0(n3708), .A1(n3684), .B0(n3712), .B1(n3686), .C0(n3733), 
        .C1(n3687), .Y(EXT_ADDR[6]) );
  OAI222X1 U2779 ( .A0(n3712), .A1(n3684), .B0(n3706), .B1(n3685), .C0(n3733), 
        .C1(n3686), .Y(EXT_ADDR[7]) );
  OAI222X1 U2780 ( .A0(n3733), .A1(n3779), .B0(n3706), .B1(n3686), .C0(n3717), 
        .C1(n3687), .Y(EXT_ADDR[8]) );
  OAI222X1 U2781 ( .A0(n3706), .A1(n3779), .B0(n3703), .B1(n3685), .C0(n3717), 
        .C1(n3686), .Y(EXT_ADDR[9]) );
  OAI222X1 U2782 ( .A0(n3717), .A1(n3684), .B0(n3703), .B1(n3686), .C0(n3732), 
        .C1(n3687), .Y(EXT_ADDR[10]) );
  OAI222X1 U2783 ( .A0(n3703), .A1(n3779), .B0(n3705), .B1(n3685), .C0(n3732), 
        .C1(n3686), .Y(EXT_ADDR[11]) );
  OAI222X1 U2784 ( .A0(n3732), .A1(n3684), .B0(n3705), .B1(n3686), .C0(n3714), 
        .C1(n3687), .Y(EXT_ADDR[12]) );
  OAI222X1 U2785 ( .A0(n3705), .A1(n3684), .B0(n3702), .B1(n3685), .C0(n3714), 
        .C1(n3686), .Y(EXT_ADDR[13]) );
  OAI222X1 U2786 ( .A0(n3714), .A1(n3779), .B0(n3702), .B1(n3686), .C0(n3735), 
        .C1(n3687), .Y(EXT_ADDR[14]) );
  OAI222X1 U2787 ( .A0(n3702), .A1(n3779), .B0(n3719), .B1(n3685), .C0(n3735), 
        .C1(n3686), .Y(EXT_ADDR[15]) );
  OAI222X1 U2788 ( .A0(n3735), .A1(n3684), .B0(n3719), .B1(n3686), .C0(n3704), 
        .C1(n3687), .Y(EXT_ADDR[16]) );
  OAI222X1 U2789 ( .A0(n3719), .A1(n3779), .B0(n3736), .B1(n3685), .C0(n3704), 
        .C1(n3686), .Y(EXT_ADDR[17]) );
  OAI222X1 U2790 ( .A0(n3704), .A1(n3684), .B0(n3736), .B1(n3686), .C0(n3709), 
        .C1(n3687), .Y(EXT_ADDR[18]) );
  OAI222X1 U2791 ( .A0(n3736), .A1(n3684), .B0(n3718), .B1(n3685), .C0(n3709), 
        .C1(n3686), .Y(EXT_ADDR[19]) );
  OAI222X1 U2792 ( .A0(n3709), .A1(n3779), .B0(n3737), .B1(n3685), .C0(n3718), 
        .C1(n3686), .Y(EXT_ADDR[20]) );
  OAI222X1 U2793 ( .A0(n3718), .A1(n3684), .B0(n3737), .B1(n3686), .C0(n3710), 
        .C1(n3687), .Y(EXT_ADDR[21]) );
  OAI222X1 U2794 ( .A0(n3737), .A1(n3779), .B0(n3720), .B1(n3685), .C0(n3710), 
        .C1(n3686), .Y(EXT_ADDR[22]) );
  OAI222X1 U2795 ( .A0(n3710), .A1(n3684), .B0(n3720), .B1(n3686), .C0(n3773), 
        .C1(n3687), .Y(EXT_ADDR[23]) );
  OAI222X1 U2796 ( .A0(n3720), .A1(n3684), .B0(n3772), .B1(n3685), .C0(n3773), 
        .C1(n3686), .Y(EXT_ADDR[24]) );
  INVX1 U2797 ( .A(n3298), .Y(n3350) );
  INVX1 U2798 ( .A(EXT_WEb), .Y(n3643) );
  INVX1 U2799 ( .A(n3322), .Y(n3352) );
  INVX1 U2800 ( .A(n3320), .Y(n3353) );
  INVX1 U2801 ( .A(n3635), .Y(n3602) );
  NAND2BX1 U2802 ( .AN(n3707), .B(n3353), .Y(n3635) );
  INVX1 U2803 ( .A(n3680), .Y(n3676) );
  NAND3BX1 U2804 ( .AN(n3780), .B(n3482), .C(n3487), .Y(n3680) );
  AOI21X1 U2805 ( .A0(n3482), .A1(n3707), .B0(n3675), .Y(n3756) );
  INVX1 U2806 ( .A(n3642), .Y(n3672) );
  INVX1 U2807 ( .A(n3376), .Y(n3326) );
  OA22X1 U2808 ( .A0(n3568), .A1(n3758), .B0(n3759), .B1(n3711), .Y(n3588) );
  AOI211X1 U2809 ( .A0(cs[1]), .A1(cs[0]), .B0(n3590), .C0(n3591), .Y(n3589)
         );
  XOR2X1 U2810 ( .A(n3564), .B(n3579), .Y(n3590) );
  NAND3BX1 U2811 ( .AN(cs[1]), .B(cs[0]), .C(n3757), .Y(n3472) );
  NAND2BX1 U2812 ( .AN(timing_cnt[3]), .B(n3527), .Y(n3553) );
  NAND2BX1 U2813 ( .AN(cs[6]), .B(n3595), .Y(n3564) );
  NAND2BX1 U2814 ( .AN(cs[4]), .B(n3584), .Y(n3567) );
  NAND2BX1 U2815 ( .AN(cs[5]), .B(n3759), .Y(n3586) );
  NAND2BX1 U2816 ( .AN(cs[2]), .B(n3729), .Y(n3659) );
  OR2X1 U2817 ( .A(timing_cnt[2]), .B(n3504), .Y(n3537) );
  AO22X1 U2818 ( .A0(cs[2]), .A1(cs[3]), .B0(cs[4]), .B1(n3659), .Y(n3591) );
  AND3X2 U2819 ( .A(n3758), .B(n3711), .C(n3579), .Y(n3757) );
  NOR2X1 U2820 ( .A(cs[0]), .B(cs[1]), .Y(n3759) );
  OR2X1 U2821 ( .A(timing_cnt[0]), .B(timing_cnt[1]), .Y(n3504) );
  AND2X2 U2822 ( .A(i_addr_24_), .B(n3768), .Y(n3760) );
  NAND3BX1 U2823 ( .AN(n3705), .B(i_addr_12_), .C(n3436), .Y(n3449) );
  INVX1 U2824 ( .A(n251), .Y(carry22) );
  INVX1 U2825 ( .A(n231), .Y(carry20) );
  INVX1 U2826 ( .A(n211), .Y(carry18) );
  INVX1 U2827 ( .A(n191), .Y(carry16) );
  INVX1 U2828 ( .A(n171), .Y(carry14) );
  INVX1 U2829 ( .A(n151), .Y(carry12) );
  INVX1 U2830 ( .A(n210), .Y(carry) );
  INVX1 U2831 ( .A(n131), .Y(carry10) );
  INVX1 U2832 ( .A(n241), .Y(carry21) );
  INVX1 U2833 ( .A(n101), .Y(carry7) );
  INVX1 U2834 ( .A(n91), .Y(carry6) );
  INVX1 U2835 ( .A(n81), .Y(carry5) );
  INVX1 U2836 ( .A(n71), .Y(carry4) );
  INVX1 U2837 ( .A(n181), .Y(carry15) );
  INVX1 U2838 ( .A(n61), .Y(carry3) );
  INVX1 U2839 ( .A(n51), .Y(carry2) );
  INVX1 U2840 ( .A(n161), .Y(carry13) );
  INVX1 U2841 ( .A(n41), .Y(carry1) );
  INVX1 U2842 ( .A(n35), .Y(carry0) );
  INVX1 U2843 ( .A(n141), .Y(carry11) );
  INVX1 U2844 ( .A(n121), .Y(carry9) );
  NAND3BX1 U2845 ( .AN(n3703), .B(i_addr_10_), .C(n3426), .Y(n3442) );
  NAND3BX1 U2846 ( .AN(n3706), .B(i_addr_8_), .C(n3416), .Y(n3432) );
  NAND3BX1 U2847 ( .AN(n3712), .B(i_addr_6_), .C(n3406), .Y(n3422) );
  NAND3BX1 U2848 ( .AN(n3730), .B(i_addr_4_), .C(n3396), .Y(n3412) );
  NAND3BX1 U2849 ( .AN(n3701), .B(i_addr_2_), .C(i_addr_1_), .Y(n3402) );
  NOR3BX1 U2850 ( .AN(i_addr_14_), .B(n3449), .C(n3702), .Y(carry_16_) );
  AND2X2 U2851 ( .A(i_addr_16_), .B(carry_16_), .Y(n3761) );
  AND2X2 U2852 ( .A(i_addr_17_), .B(n3761), .Y(n3762) );
  AND2X2 U2853 ( .A(i_addr_18_), .B(n3762), .Y(n3763) );
  AND2X2 U2854 ( .A(i_addr_19_), .B(n3763), .Y(n3764) );
  AND2X2 U2855 ( .A(i_addr_20_), .B(n3764), .Y(n3765) );
  AND2X2 U2856 ( .A(i_addr_21_), .B(n3765), .Y(n3766) );
  AND2X2 U2857 ( .A(i_addr_22_), .B(n3766), .Y(n3767) );
  AND2X2 U2858 ( .A(i_addr_23_), .B(n3767), .Y(n3768) );
  BUFX2 U2859 ( .A(i_addr1234_0_), .Y(n3780) );
  INVX1 U2860 ( .A(n221), .Y(carry19) );
  INVX1 U2861 ( .A(n201), .Y(carry17) );
  INVX1 U2862 ( .A(n111), .Y(carry8) );
  AO21X1 U2863 ( .A0(i_addr_26_), .A1(n3464), .B0(n3465), .Y(n3206) );
  OAI31X1 U2864 ( .A0(n3391), .A1(n1), .A2(i_addr_26_), .B0(n3466), .Y(n3465)
         );
  OAI221X1 U2865 ( .A0(n3469), .A1(n3468), .B0(n3391), .B1(n3470), .C0(n3471), 
        .Y(n3464) );
  AOI32X1 U2866 ( .A0(n3772), .A1(n3468), .A2(n3381), .B0(ADDR[26]), .B1(n3383), .Y(n3466) );
  NOR2X1 U2867 ( .A(repeat_cnt[1]), .B(repeat_cnt[0]), .Y(n3769) );
  OAI2BB1X1 U2868 ( .A0N(i_addr1234_25_), .A1N(n3378), .B0(n3463), .Y(n3207)
         );
  AOI222X1 U2869 ( .A0(i_addr_25_), .A1(n3380), .B0(i_addr1230_25_), .B1(n3381), .C0(ADDR[25]), .C1(n3383), .Y(n3463) );
  OAI2BB1X1 U2870 ( .A0N(i_addr1234_24_), .A1N(n3378), .B0(n3462), .Y(n3208)
         );
  AOI222X1 U2871 ( .A0(i_addr_24_), .A1(n3380), .B0(i_addr1230_24_), .B1(n3381), .C0(ADDR[24]), .C1(n3383), .Y(n3462) );
  OAI2BB1X1 U2872 ( .A0N(i_addr1234_23_), .A1N(n3378), .B0(n3461), .Y(n3209)
         );
  AOI222X1 U2873 ( .A0(i_addr_23_), .A1(n3380), .B0(i_addr1230_23_), .B1(n3381), .C0(ADDR[23]), .C1(n3383), .Y(n3461) );
  OAI2BB1X1 U2874 ( .A0N(i_addr1234_22_), .A1N(n3378), .B0(n3460), .Y(n3210)
         );
  AOI222X1 U2875 ( .A0(i_addr_22_), .A1(n3380), .B0(i_addr1230_22_), .B1(n3381), .C0(ADDR[22]), .C1(n3383), .Y(n3460) );
  OAI2BB1X1 U2876 ( .A0N(i_addr1234_21_), .A1N(n3378), .B0(n3459), .Y(n3211)
         );
  AOI222X1 U2877 ( .A0(i_addr_21_), .A1(n3380), .B0(i_addr1230_21_), .B1(n3381), .C0(ADDR[21]), .C1(n3383), .Y(n3459) );
  OAI222X1 U2878 ( .A0(n3318), .A1(n3302), .B0(n3303), .B1(n3319), .C0(n3305), 
        .C1(n3197), .Y(n3249) );
  INVX1 U2879 ( .A(EXT_RDATA[7]), .Y(n3318) );
  INVX1 U2880 ( .A(EXT_RDATA[15]), .Y(n3319) );
  OAI222X1 U2881 ( .A0(n3316), .A1(n3302), .B0(n3303), .B1(n3317), .C0(n3305), 
        .C1(n3196), .Y(n3250) );
  INVX1 U2882 ( .A(EXT_RDATA[6]), .Y(n3316) );
  INVX1 U2883 ( .A(EXT_RDATA[14]), .Y(n3317) );
  OAI222X1 U2884 ( .A0(n3314), .A1(n3302), .B0(n3303), .B1(n3315), .C0(n3305), 
        .C1(n3195), .Y(n3251) );
  INVX1 U2885 ( .A(EXT_RDATA[5]), .Y(n3314) );
  INVX1 U2886 ( .A(EXT_RDATA[13]), .Y(n3315) );
  OAI222X1 U2887 ( .A0(n3312), .A1(n3302), .B0(n3303), .B1(n3313), .C0(n3305), 
        .C1(n3194), .Y(n3252) );
  INVX1 U2888 ( .A(EXT_RDATA[4]), .Y(n3312) );
  INVX1 U2889 ( .A(EXT_RDATA[12]), .Y(n3313) );
  OAI222X1 U2890 ( .A0(n3310), .A1(n3302), .B0(n3303), .B1(n3311), .C0(n3305), 
        .C1(n3193), .Y(n3253) );
  INVX1 U2891 ( .A(EXT_RDATA[3]), .Y(n3310) );
  INVX1 U2892 ( .A(EXT_RDATA[11]), .Y(n3311) );
  OAI222X1 U2893 ( .A0(n3308), .A1(n3302), .B0(n3303), .B1(n3309), .C0(n3305), 
        .C1(n3192), .Y(n3254) );
  INVX1 U2894 ( .A(EXT_RDATA[2]), .Y(n3308) );
  INVX1 U2895 ( .A(EXT_RDATA[10]), .Y(n3309) );
  OAI222X1 U2896 ( .A0(n3306), .A1(n3302), .B0(n3303), .B1(n3307), .C0(n3305), 
        .C1(n3199), .Y(n3255) );
  INVX1 U2897 ( .A(EXT_RDATA[1]), .Y(n3306) );
  INVX1 U2898 ( .A(EXT_RDATA[9]), .Y(n3307) );
  OAI222X1 U2899 ( .A0(n3301), .A1(n3302), .B0(n3303), .B1(n3304), .C0(n3305), 
        .C1(n3198), .Y(n3256) );
  INVX1 U2900 ( .A(EXT_RDATA[0]), .Y(n3301) );
  INVX1 U2901 ( .A(EXT_RDATA[8]), .Y(n3304) );
  AO21X1 U2902 ( .A0(RDATA[23]), .A1(n3329), .B0(n3339), .Y(n3241) );
  AO22X1 U2903 ( .A0(EXT_RDATA[23]), .A1(n3331), .B0(n3332), .B1(EXT_RDATA[7]), 
        .Y(n3339) );
  AO21X1 U2904 ( .A0(RDATA[22]), .A1(n3329), .B0(n3338), .Y(n3242) );
  AO22X1 U2905 ( .A0(EXT_RDATA[22]), .A1(n3331), .B0(n3332), .B1(EXT_RDATA[6]), 
        .Y(n3338) );
  AO21X1 U2906 ( .A0(RDATA[21]), .A1(n3329), .B0(n3337), .Y(n3243) );
  AO22X1 U2907 ( .A0(EXT_RDATA[21]), .A1(n3331), .B0(n3332), .B1(EXT_RDATA[5]), 
        .Y(n3337) );
  AO21X1 U2908 ( .A0(RDATA[20]), .A1(n3329), .B0(n3336), .Y(n3244) );
  AO22X1 U2909 ( .A0(EXT_RDATA[20]), .A1(n3331), .B0(n3332), .B1(EXT_RDATA[4]), 
        .Y(n3336) );
  AO21X1 U2910 ( .A0(RDATA[19]), .A1(n3329), .B0(n3335), .Y(n3245) );
  AO22X1 U2911 ( .A0(EXT_RDATA[19]), .A1(n3331), .B0(n3332), .B1(EXT_RDATA[3]), 
        .Y(n3335) );
  AO21X1 U2912 ( .A0(RDATA[18]), .A1(n3329), .B0(n3334), .Y(n3246) );
  AO22X1 U2913 ( .A0(EXT_RDATA[18]), .A1(n3331), .B0(n3332), .B1(EXT_RDATA[2]), 
        .Y(n3334) );
  AO21X1 U2914 ( .A0(RDATA[17]), .A1(n3329), .B0(n3333), .Y(n3247) );
  AO22X1 U2915 ( .A0(EXT_RDATA[17]), .A1(n3331), .B0(n3332), .B1(EXT_RDATA[1]), 
        .Y(n3333) );
  AO21X1 U2916 ( .A0(RDATA[16]), .A1(n3329), .B0(n3330), .Y(n3248) );
  AO22X1 U2917 ( .A0(EXT_RDATA[16]), .A1(n3331), .B0(n3332), .B1(EXT_RDATA[0]), 
        .Y(n3330) );
  INVX1 U2918 ( .A(n3368), .Y(n3344) );
  OAI31X1 U2919 ( .A0(n3325), .A1(i_addr_1_), .A2(n3326), .B0(n3328), .Y(n3368) );
  INVX1 U2920 ( .A(n3369), .Y(n3328) );
  OAI31X1 U2921 ( .A0(ns[5]), .A1(ns[6]), .A2(ns[4]), .B0(n3370), .Y(n3369) );
  NOR2BX1 U2922 ( .AN(READ), .B(n3371), .Y(n3370) );
  INVX1 U2923 ( .A(CS_SETUP[1]), .Y(n3523) );
  OAI21X1 U2924 ( .A0(n3535), .A1(n3488), .B0(n3536), .Y(n3200) );
  AOI32X1 U2925 ( .A0(timing_cnt[3]), .A1(n3537), .A2(n3503), .B0(
        timing_cnt[3]), .B1(n3488), .Y(n3536) );
  AOI221X1 U2926 ( .A0(n3503), .A1(n3540), .B0(ACC_CYCLE[3]), .B1(n3494), .C0(
        n3528), .Y(n3535) );
  AO22X1 U2927 ( .A0(RDATA[7]), .A1(n3294), .B0(EXT_RDATA[7]), .B1(n3755), .Y(
        n3257) );
  AO22X1 U2928 ( .A0(RDATA[6]), .A1(n3294), .B0(EXT_RDATA[6]), .B1(n3755), .Y(
        n3258) );
  AO22X1 U2929 ( .A0(RDATA[5]), .A1(n3294), .B0(EXT_RDATA[5]), .B1(n3755), .Y(
        n3259) );
  AO22X1 U2930 ( .A0(RDATA[4]), .A1(n3294), .B0(EXT_RDATA[4]), .B1(n3755), .Y(
        n3260) );
  AO22X1 U2931 ( .A0(RDATA[3]), .A1(n3294), .B0(EXT_RDATA[3]), .B1(n3755), .Y(
        n3261) );
  AO22X1 U2932 ( .A0(RDATA[2]), .A1(n3294), .B0(EXT_RDATA[2]), .B1(n3755), .Y(
        n3262) );
  AO22X1 U2933 ( .A0(RDATA[1]), .A1(n3294), .B0(EXT_RDATA[1]), .B1(n3755), .Y(
        n3263) );
  AO22X1 U2934 ( .A0(RDATA[0]), .A1(n3294), .B0(EXT_RDATA[0]), .B1(n3755), .Y(
        n3264) );
  OAI2BB1X1 U2935 ( .A0N(i_addr1234_20_), .A1N(n3378), .B0(n3458), .Y(n3212)
         );
  AOI222X1 U2936 ( .A0(i_addr_20_), .A1(n3380), .B0(i_addr1230_20_), .B1(n3381), .C0(ADDR[20]), .C1(n3383), .Y(n3458) );
  OAI2BB1X1 U2937 ( .A0N(i_addr1234_19_), .A1N(n3378), .B0(n3457), .Y(n3213)
         );
  AOI222X1 U2938 ( .A0(i_addr_19_), .A1(n3380), .B0(i_addr1230_19_), .B1(n3381), .C0(ADDR[19]), .C1(n3383), .Y(n3457) );
  OAI2BB1X1 U2939 ( .A0N(i_addr1234_18_), .A1N(n3378), .B0(n3456), .Y(n3214)
         );
  AOI222X1 U2940 ( .A0(i_addr_18_), .A1(n3380), .B0(i_addr1230_18_), .B1(n3381), .C0(ADDR[18]), .C1(n3383), .Y(n3456) );
  OAI2BB1X1 U2941 ( .A0N(i_addr1234_17_), .A1N(n3378), .B0(n3455), .Y(n3215)
         );
  AOI222X1 U2942 ( .A0(i_addr_17_), .A1(n3380), .B0(i_addr1230_17_), .B1(n3381), .C0(ADDR[17]), .C1(n3383), .Y(n3455) );
  OAI2BB1X1 U2943 ( .A0N(i_addr1234_16_), .A1N(n3378), .B0(n3454), .Y(n3216)
         );
  AOI222X1 U2944 ( .A0(i_addr_16_), .A1(n3380), .B0(i_addr1230_16_), .B1(n3381), .C0(ADDR[16]), .C1(n3383), .Y(n3454) );
  OAI2BB1X1 U2945 ( .A0N(timing_cnt[2]), .A1N(n3488), .B0(n3524), .Y(n3201) );
  AO21X1 U2946 ( .A0(n3525), .A1(n3526), .B0(n3488), .Y(n3524) );
  AOI32X1 U2947 ( .A0(timing_cnt[2]), .A1(n3504), .A2(n3503), .B0(n3503), .B1(
        n3527), .Y(n3526) );
  AOI211X1 U2948 ( .A0(ACC_CYCLE[2]), .A1(n3494), .B0(n3528), .C0(n3529), .Y(
        n3525) );
  AO22X1 U2949 ( .A0(RDATA[31]), .A1(n3347), .B0(n3348), .B1(n3366), .Y(n3233)
         );
  AO21X1 U2950 ( .A0(EXT_RDATA[31]), .A1(n3350), .B0(n3367), .Y(n3366) );
  AO22X1 U2951 ( .A0(n3352), .A1(EXT_RDATA[7]), .B0(n3353), .B1(EXT_RDATA[15]), 
        .Y(n3367) );
  AO22X1 U2952 ( .A0(RDATA[30]), .A1(n3347), .B0(n3348), .B1(n3364), .Y(n3234)
         );
  AO21X1 U2953 ( .A0(EXT_RDATA[30]), .A1(n3350), .B0(n3365), .Y(n3364) );
  AO22X1 U2954 ( .A0(n3352), .A1(EXT_RDATA[6]), .B0(n3353), .B1(EXT_RDATA[14]), 
        .Y(n3365) );
  AO22X1 U2955 ( .A0(RDATA[29]), .A1(n3347), .B0(n3348), .B1(n3362), .Y(n3235)
         );
  AO21X1 U2956 ( .A0(EXT_RDATA[29]), .A1(n3350), .B0(n3363), .Y(n3362) );
  AO22X1 U2957 ( .A0(n3352), .A1(EXT_RDATA[5]), .B0(n3353), .B1(EXT_RDATA[13]), 
        .Y(n3363) );
  AO22X1 U2958 ( .A0(RDATA[28]), .A1(n3347), .B0(n3348), .B1(n3360), .Y(n3236)
         );
  AO21X1 U2959 ( .A0(EXT_RDATA[28]), .A1(n3350), .B0(n3361), .Y(n3360) );
  AO22X1 U2960 ( .A0(n3352), .A1(EXT_RDATA[4]), .B0(n3353), .B1(EXT_RDATA[12]), 
        .Y(n3361) );
  AO22X1 U2961 ( .A0(RDATA[27]), .A1(n3347), .B0(n3348), .B1(n3358), .Y(n3237)
         );
  AO21X1 U2962 ( .A0(EXT_RDATA[27]), .A1(n3350), .B0(n3359), .Y(n3358) );
  AO22X1 U2963 ( .A0(n3352), .A1(EXT_RDATA[3]), .B0(n3353), .B1(EXT_RDATA[11]), 
        .Y(n3359) );
  AO22X1 U2964 ( .A0(RDATA[26]), .A1(n3347), .B0(n3348), .B1(n3356), .Y(n3238)
         );
  AO21X1 U2965 ( .A0(EXT_RDATA[26]), .A1(n3350), .B0(n3357), .Y(n3356) );
  AO22X1 U2966 ( .A0(n3352), .A1(EXT_RDATA[2]), .B0(n3353), .B1(EXT_RDATA[10]), 
        .Y(n3357) );
  AO22X1 U2967 ( .A0(RDATA[25]), .A1(n3347), .B0(n3348), .B1(n3354), .Y(n3239)
         );
  AO21X1 U2968 ( .A0(EXT_RDATA[25]), .A1(n3350), .B0(n3355), .Y(n3354) );
  AO22X1 U2969 ( .A0(n3352), .A1(EXT_RDATA[1]), .B0(n3353), .B1(EXT_RDATA[9]), 
        .Y(n3355) );
  AO22X1 U2970 ( .A0(RDATA[24]), .A1(n3347), .B0(n3348), .B1(n3349), .Y(n3240)
         );
  AO21X1 U2971 ( .A0(EXT_RDATA[24]), .A1(n3350), .B0(n3351), .Y(n3349) );
  AO22X1 U2972 ( .A0(n3352), .A1(EXT_RDATA[0]), .B0(n3353), .B1(EXT_RDATA[8]), 
        .Y(n3351) );
  AO22X1 U2973 ( .A0(timing_cnt[0]), .A1(n3488), .B0(n3489), .B1(n3490), .Y(
        n3203) );
  OAI211X1 U2974 ( .A0(timing_cnt[0]), .A1(n3491), .B0(n3492), .C0(n3493), .Y(
        n3490) );
  AOI222X1 U2975 ( .A0(ACC_CYCLE[0]), .A1(n3494), .B0(n3495), .B1(n3496), .C0(
        n3497), .C1(n3498), .Y(n3493) );
  OAI2BB1X1 U2976 ( .A0N(n3489), .A1N(n3501), .B0(n3502), .Y(n3202) );
  AOI32X1 U2977 ( .A0(timing_cnt[0]), .A1(timing_cnt[1]), .A2(n3503), .B0(
        timing_cnt[1]), .B1(n3488), .Y(n3502) );
  OAI211X1 U2978 ( .A0(n3504), .A1(n3491), .B0(n3505), .C0(n3506), .Y(n3501)
         );
  AOI221X1 U2979 ( .A0(n3507), .A1(n3508), .B0(ACC_CYCLE[1]), .B1(n3494), .C0(
        n3509), .Y(n3506) );
  INVX1 U2980 ( .A(ADDR_HOLD[1]), .Y(n3519) );
  INVX1 U2981 ( .A(CS_HOLD[1]), .Y(n3521) );
  NAND4BX1 U2982 ( .AN(n3564), .B(n3713), .C(cs[3]), .D(n3731), .Y(n3371) );
  NAND3BX1 U2983 ( .AN(n3567), .B(cs[6]), .C(n3568), .Y(n3473) );
  OAI2BB1X1 U2984 ( .A0N(i_addr_12_), .A1N(n3434), .B0(n3435), .Y(n3220) );
  AOI31X1 U2985 ( .A0(n3436), .A1(n3732), .A2(n3378), .B0(n3438), .Y(n3435) );
  AO22X1 U2986 ( .A0(ADDR[12]), .A1(n3383), .B0(i_addr1230_12_), .B1(n3381), 
        .Y(n3438) );
  NAND2BX1 U2987 ( .AN(n3450), .B(n3451), .Y(n3217) );
  OAI33X1 U2988 ( .A0(n3391), .A1(i_addr_14_), .A2(n3702), .B0(n3453), .B1(
        n3449), .B2(n3714), .Y(n3450) );
  AOI222X1 U2989 ( .A0(i_addr_15_), .A1(n3444), .B0(i_addr1230_15_), .B1(n3381), .C0(ADDR[15]), .C1(n3383), .Y(n3451) );
  NAND2BX1 U2990 ( .AN(i_addr_15_), .B(n3378), .Y(n3453) );
  OAI2BB1X1 U2991 ( .A0N(i_addr_14_), .A1N(n3444), .B0(n3445), .Y(n3218) );
  AOI31X1 U2992 ( .A0(n3378), .A1(n3714), .A2(n3447), .B0(n3448), .Y(n3445) );
  INVX1 U2993 ( .A(n3449), .Y(n3447) );
  AO22X1 U2994 ( .A0(ADDR[14]), .A1(n3383), .B0(i_addr1230_14_), .B1(n3381), 
        .Y(n3448) );
  OAI2BB1X1 U2995 ( .A0N(i_addr_13_), .A1N(n3434), .B0(n3439), .Y(n3219) );
  AOI221X1 U2996 ( .A0(i_addr1230_13_), .A1(n3381), .B0(ADDR[13]), .B1(n3383), 
        .C0(n3440), .Y(n3439) );
  OAI33X1 U2997 ( .A0(n3391), .A1(i_addr_12_), .A2(n3705), .B0(n3391), .B1(
        n3442), .B2(n3443), .Y(n3440) );
  NAND2BX1 U2998 ( .AN(i_addr_13_), .B(i_addr_12_), .Y(n3443) );
  NAND3BX1 U2999 ( .AN(TRANS_SIZE[2]), .B(n3487), .C(TRANS_SIZE[1]), .Y(n3479)
         );
  NAND4BX1 U3000 ( .AN(n3564), .B(n3713), .C(cs[2]), .D(n3729), .Y(n3556) );
  NAND4BX1 U3001 ( .AN(cs[6]), .B(cs[5]), .C(n3759), .D(n3579), .Y(n3576) );
  NAND3BX1 U3002 ( .AN(cs[0]), .B(cs[1]), .C(n3757), .Y(n3554) );
  INVX1 U3003 ( .A(TRANS_SIZE[1]), .Y(n3482) );
  INVX1 U3004 ( .A(TRANS_SIZE[0]), .Y(n3487) );
  OAI2BB1X1 U3005 ( .A0N(i_addr_3_), .A1N(n3385), .B0(n3389), .Y(n3229) );
  AOI221X1 U3006 ( .A0(i_addr1230_3_), .A1(n3381), .B0(ADDR[3]), .B1(n3383), 
        .C0(n3390), .Y(n3389) );
  OAI33X1 U3007 ( .A0(n3391), .A1(i_addr_2_), .A2(n3701), .B0(n3391), .B1(
        n3393), .B2(n3707), .Y(n3390) );
  NAND2BX1 U3008 ( .AN(i_addr_3_), .B(i_addr_2_), .Y(n3393) );
  OAI2BB1X1 U3009 ( .A0N(i_addr_6_), .A1N(n3404), .B0(n3405), .Y(n3226) );
  AOI31X1 U3010 ( .A0(n3406), .A1(n3708), .A2(n3378), .B0(n3408), .Y(n3405) );
  AO22X1 U3011 ( .A0(ADDR[6]), .A1(n3383), .B0(i_addr1230_6_), .B1(n3381), .Y(
        n3408) );
  OAI2BB1X1 U3012 ( .A0N(i_addr_4_), .A1N(n3394), .B0(n3395), .Y(n3228) );
  AOI31X1 U3013 ( .A0(n3396), .A1(n3716), .A2(n3378), .B0(n3398), .Y(n3395) );
  AO22X1 U3014 ( .A0(ADDR[4]), .A1(n3383), .B0(i_addr1230_4_), .B1(n3381), .Y(
        n3398) );
  OAI2BB1X1 U3015 ( .A0N(i_addr_10_), .A1N(n3424), .B0(n3425), .Y(n3222) );
  AOI31X1 U3016 ( .A0(n3426), .A1(n3717), .A2(n3378), .B0(n3428), .Y(n3425) );
  AO22X1 U3017 ( .A0(ADDR[10]), .A1(n3383), .B0(i_addr1230_10_), .B1(n3381), 
        .Y(n3428) );
  OAI2BB1X1 U3018 ( .A0N(i_addr_8_), .A1N(n3414), .B0(n3415), .Y(n3224) );
  AOI31X1 U3019 ( .A0(n3416), .A1(n3733), .A2(n3378), .B0(n3418), .Y(n3415) );
  AO22X1 U3020 ( .A0(ADDR[8]), .A1(n3383), .B0(i_addr1230_8_), .B1(n3381), .Y(
        n3418) );
  OAI2BB1X1 U3021 ( .A0N(i_addr_2_), .A1N(n3385), .B0(n3386), .Y(n3230) );
  AOI31X1 U3022 ( .A0(i_addr_1_), .A1(n3734), .A2(n3378), .B0(n3388), .Y(n3386) );
  AO22X1 U3023 ( .A0(ADDR[2]), .A1(n3383), .B0(i_addr1230_2_), .B1(n3381), .Y(
        n3388) );
  OAI2BB1X1 U3024 ( .A0N(i_addr_11_), .A1N(n3424), .B0(n3429), .Y(n3221) );
  AOI221X1 U3025 ( .A0(i_addr1230_11_), .A1(n3381), .B0(ADDR[11]), .B1(n3383), 
        .C0(n3430), .Y(n3429) );
  OAI33X1 U3026 ( .A0(n3391), .A1(i_addr_10_), .A2(n3703), .B0(n3391), .B1(
        n3432), .B2(n3433), .Y(n3430) );
  NAND2BX1 U3027 ( .AN(i_addr_11_), .B(i_addr_10_), .Y(n3433) );
  OAI2BB1X1 U3028 ( .A0N(i_addr_9_), .A1N(n3414), .B0(n3419), .Y(n3223) );
  AOI221X1 U3029 ( .A0(i_addr1230_9_), .A1(n3381), .B0(ADDR[9]), .B1(n3383), 
        .C0(n3420), .Y(n3419) );
  OAI33X1 U3030 ( .A0(n3391), .A1(i_addr_8_), .A2(n3706), .B0(n3391), .B1(
        n3422), .B2(n3423), .Y(n3420) );
  NAND2BX1 U3031 ( .AN(i_addr_9_), .B(i_addr_8_), .Y(n3423) );
  OAI2BB1X1 U3032 ( .A0N(i_addr_7_), .A1N(n3404), .B0(n3409), .Y(n3225) );
  AOI221X1 U3033 ( .A0(i_addr1230_7_), .A1(n3381), .B0(ADDR[7]), .B1(n3383), 
        .C0(n3410), .Y(n3409) );
  OAI33X1 U3034 ( .A0(n3391), .A1(i_addr_6_), .A2(n3712), .B0(n3391), .B1(
        n3412), .B2(n3413), .Y(n3410) );
  NAND2BX1 U3035 ( .AN(i_addr_7_), .B(i_addr_6_), .Y(n3413) );
  OAI2BB1X1 U3036 ( .A0N(i_addr_5_), .A1N(n3394), .B0(n3399), .Y(n3227) );
  AOI221X1 U3037 ( .A0(i_addr1230_5_), .A1(n3381), .B0(ADDR[5]), .B1(n3383), 
        .C0(n3400), .Y(n3399) );
  OAI33X1 U3038 ( .A0(n3391), .A1(i_addr_4_), .A2(n3730), .B0(n3391), .B1(
        n3402), .B2(n3403), .Y(n3400) );
  NAND2BX1 U3039 ( .AN(i_addr_5_), .B(i_addr_4_), .Y(n3403) );
  OAI2BB1X1 U3040 ( .A0N(n3378), .A1N(n3707), .B0(n3384), .Y(n3231) );
  AOI222X1 U3041 ( .A0(n3380), .A1(i_addr_1_), .B0(i_addr1230_1_), .B1(n3381), 
        .C0(ADDR[1]), .C1(n3383), .Y(n3384) );
  OAI2BB1X1 U3042 ( .A0N(n3378), .A1N(n3780), .B0(n3379), .Y(n3232) );
  AOI222X1 U3043 ( .A0(n3380), .A1(n3780), .B0(n3381), .B1(n3715), .C0(ADDR[0]), .C1(n3383), .Y(n3379) );
  INVX1 U3044 ( .A(n3481), .Y(n3373) );
  NAND3BX1 U3045 ( .AN(TRANS_SIZE[2]), .B(n3482), .C(TRANS_SIZE[0]), .Y(n3481)
         );
  AO21X1 U3046 ( .A0(repeat_cnt[0]), .A1(n3475), .B0(n3476), .Y(n3205) );
  OAI33X1 U3047 ( .A0(n3475), .A1(repeat_cnt[0]), .A2(n3758), .B0(n3475), .B1(
        cs[6]), .B2(n3478), .Y(n3476) );
  OA22X1 U3048 ( .A0(n3320), .A1(n3479), .B0(n3377), .B1(n3322), .Y(n3478) );
  OAI2BB1X1 U3049 ( .A0N(repeat_cnt[1]), .A1N(n3475), .B0(n3483), .Y(n3204) );
  AOI33X1 U3050 ( .A0(n3484), .A1(n3485), .A2(n3486), .B0(repeat_cnt[0]), .B1(
        repeat_cnt[1]), .B2(cs[6]), .Y(n3483) );
  NOR2BX1 U3051 ( .AN(n3758), .B(n3322), .Y(n3484) );
  INVX1 U3052 ( .A(n3479), .Y(n3485) );
  NAND2X1 U3053 ( .A(WRITE), .B(n3560), .Y(EXT_WEb) );
  NAND3BX1 U3054 ( .AN(i_addr_1_), .B(n3780), .C(n3352), .Y(n3607) );
  NAND3BX1 U3055 ( .AN(n3715), .B(i_addr_1_), .C(n3352), .Y(n3609) );
  NAND2X1 U3056 ( .A(n3770), .B(n3756), .Y(n3642) );
  AOI21X1 U3057 ( .A0(WBEB[3]), .A1(WRITE), .B0(n3676), .Y(n3770) );
  NAND2X1 U3058 ( .A(n3771), .B(n3775), .Y(n3667) );
  AOI21X1 U3059 ( .A0(WBEB[0]), .A1(WRITE), .B0(n3671), .Y(n3771) );
  NOR2BX1 U3060 ( .AN(WRITE), .B(n3383), .Y(EXT_BIDEN) );
  NOR2BX1 U3061 ( .AN(i_addr_26_), .B(n3684), .Y(EXT_ADDR[26]) );
  NOR2BX1 U3062 ( .AN(i_wdata_24_), .B(n3298), .Y(EXT_WDATA[24]) );
  NOR2BX1 U3063 ( .AN(i_wdata_25_), .B(n3298), .Y(EXT_WDATA[25]) );
  NOR2BX1 U3064 ( .AN(i_wdata_26_), .B(n3298), .Y(EXT_WDATA[26]) );
  NOR2BX1 U3065 ( .AN(i_wdata_27_), .B(n3298), .Y(EXT_WDATA[27]) );
  NOR2BX1 U3066 ( .AN(i_wdata_28_), .B(n3298), .Y(EXT_WDATA[28]) );
  NOR2BX1 U3067 ( .AN(i_wdata_29_), .B(n3298), .Y(EXT_WDATA[29]) );
  NOR2BX1 U3068 ( .AN(i_wdata_30_), .B(n3298), .Y(EXT_WDATA[30]) );
  NOR2BX1 U3069 ( .AN(i_wdata_31_), .B(n3298), .Y(EXT_WDATA[31]) );
  NOR2BX1 U3070 ( .AN(i_wdata_16_), .B(n3298), .Y(EXT_WDATA[16]) );
  NOR2BX1 U3071 ( .AN(i_wdata_17_), .B(n3298), .Y(EXT_WDATA[17]) );
  NOR2BX1 U3072 ( .AN(i_wdata_18_), .B(n3298), .Y(EXT_WDATA[18]) );
  NOR2BX1 U3073 ( .AN(i_wdata_19_), .B(n3298), .Y(EXT_WDATA[19]) );
  NOR2BX1 U3074 ( .AN(i_wdata_20_), .B(n3298), .Y(EXT_WDATA[20]) );
  NOR2BX1 U3075 ( .AN(i_wdata_21_), .B(n3298), .Y(EXT_WDATA[21]) );
  NOR2BX1 U3076 ( .AN(i_wdata_22_), .B(n3298), .Y(EXT_WDATA[22]) );
  NOR2BX1 U3077 ( .AN(i_wdata_23_), .B(n3298), .Y(EXT_WDATA[23]) );
  NAND2BX1 U3078 ( .AN(ADDR_SHIFT[0]), .B(n3779), .Y(n3687) );
  NAND2BX1 U3079 ( .AN(WRITE), .B(n3560), .Y(EXT_OEb) );
  AO22X1 U3080 ( .A0(i_wdata_8_), .A1(n3601), .B0(i_wdata_24_), .B1(n3602), 
        .Y(EXT_WDATA[8]) );
  AO22X1 U3081 ( .A0(i_wdata_9_), .A1(n3601), .B0(i_wdata_25_), .B1(n3602), 
        .Y(EXT_WDATA[9]) );
  AO22X1 U3082 ( .A0(i_wdata_10_), .A1(n3601), .B0(i_wdata_26_), .B1(n3602), 
        .Y(EXT_WDATA[10]) );
  AO22X1 U3083 ( .A0(i_wdata_11_), .A1(n3601), .B0(i_wdata_27_), .B1(n3602), 
        .Y(EXT_WDATA[11]) );
  AO22X1 U3084 ( .A0(i_wdata_12_), .A1(n3601), .B0(i_wdata_28_), .B1(n3602), 
        .Y(EXT_WDATA[12]) );
  AO22X1 U3085 ( .A0(i_wdata_13_), .A1(n3601), .B0(i_wdata_29_), .B1(n3602), 
        .Y(EXT_WDATA[13]) );
  AO22X1 U3086 ( .A0(i_wdata_14_), .A1(n3601), .B0(i_wdata_30_), .B1(n3602), 
        .Y(EXT_WDATA[14]) );
  AO22X1 U3087 ( .A0(i_wdata_15_), .A1(n3601), .B0(i_wdata_31_), .B1(n3602), 
        .Y(EXT_WDATA[15]) );
  OAI22X1 U3088 ( .A0(n3686), .A1(n3772), .B0(n3778), .B1(n3773), .Y(
        EXT_ADDR[25]) );
  OAI221X1 U3089 ( .A0(n3603), .A1(n3738), .B0(n3605), .B1(n2816), .C0(n3637), 
        .Y(EXT_WDATA[0]) );
  OA22X1 U3090 ( .A0(n3746), .A1(n3607), .B0(n3721), .B1(n3609), .Y(n3637) );
  OAI221X1 U3091 ( .A0(n3603), .A1(n3739), .B0(n3605), .B1(n2817), .C0(n3632), 
        .Y(EXT_WDATA[1]) );
  OA22X1 U3092 ( .A0(n3747), .A1(n3607), .B0(n3722), .B1(n3609), .Y(n3632) );
  OAI221X1 U3093 ( .A0(n3603), .A1(n3740), .B0(n3605), .B1(n2818), .C0(n3628), 
        .Y(EXT_WDATA[2]) );
  OA22X1 U3094 ( .A0(n3607), .A1(n3748), .B0(n3609), .B1(n3723), .Y(n3628) );
  OAI221X1 U3095 ( .A0(n3603), .A1(n3741), .B0(n3605), .B1(n2819), .C0(n3624), 
        .Y(EXT_WDATA[3]) );
  OA22X1 U3096 ( .A0(n3607), .A1(n3749), .B0(n3609), .B1(n3724), .Y(n3624) );
  OAI221X1 U3097 ( .A0(n3603), .A1(n3742), .B0(n3605), .B1(n2820), .C0(n3620), 
        .Y(EXT_WDATA[4]) );
  OA22X1 U3098 ( .A0(n3607), .A1(n3750), .B0(n3609), .B1(n3725), .Y(n3620) );
  OAI221X1 U3099 ( .A0(n3603), .A1(n3743), .B0(n3605), .B1(n2821), .C0(n3616), 
        .Y(EXT_WDATA[5]) );
  OA22X1 U3100 ( .A0(n3607), .A1(n3751), .B0(n3609), .B1(n3726), .Y(n3616) );
  OAI221X1 U3101 ( .A0(n3603), .A1(n3744), .B0(n3605), .B1(n2822), .C0(n3612), 
        .Y(EXT_WDATA[6]) );
  OA22X1 U3102 ( .A0(n3607), .A1(n3752), .B0(n3609), .B1(n3727), .Y(n3612) );
  OAI221X1 U3103 ( .A0(n3603), .A1(n3745), .B0(n3605), .B1(n2823), .C0(n3606), 
        .Y(EXT_WDATA[7]) );
  OA22X1 U3104 ( .A0(n3607), .A1(n3753), .B0(n3609), .B1(n3728), .Y(n3606) );
  OAI211X1 U3105 ( .A0(n3353), .A1(n3715), .B0(i_addr_1_), .C0(n3342), .Y(
        n3603) );
  NAND2X1 U3106 ( .A(n3774), .B(n3756), .Y(n3644) );
  AOI21X1 U3107 ( .A0(WBEB[2]), .A1(WRITE), .B0(n3671), .Y(n3774) );
  AO21X1 U3108 ( .A0(TRANS_SIZE[1]), .A1(TRANS_SIZE[0]), .B0(TRANS_SIZE[2]), 
        .Y(n3675) );
  OAI211X1 U3109 ( .A0(n3660), .A1(n3661), .B0(n3662), .C0(n3663), .Y(n3646)
         );
  INVX1 U3110 ( .A(n3667), .Y(n3660) );
  AOI31X1 U3111 ( .A0(n3664), .A1(i_addr_1_), .A2(n3644), .B0(n3665), .Y(n3663) );
  OA22X1 U3112 ( .A0(n3776), .A1(n3607), .B0(n3672), .B1(n3609), .Y(n3662) );
  INVX1 U3113 ( .A(n3683), .Y(n3671) );
  NAND3BX1 U3114 ( .AN(TRANS_SIZE[1]), .B(n3487), .C(n3780), .Y(n3683) );
  AO21X1 U3115 ( .A0(n3661), .A1(n3715), .B0(BUS_WIDTH[0]), .Y(n3664) );
  AOI21X1 U3116 ( .A0(i_addr_1_), .A1(n3482), .B0(n3675), .Y(n3775) );
  AO21X1 U3117 ( .A0(n3666), .A1(n3667), .B0(n3326), .Y(n3665) );
  OA21X2 U3118 ( .A0(BUS_WIDTH[0]), .A1(n3715), .B0(n3707), .Y(n3666) );
  INVX1 U3119 ( .A(n3652), .Y(n3645) );
  OAI221X1 U3120 ( .A0(BUS_WIDTH[0]), .A1(n3776), .B0(i_addr_1_), .B1(n3776), 
        .C0(n3654), .Y(n3652) );
  AOI211X1 U3121 ( .A0(n3655), .A1(n3642), .B0(n3326), .C0(n3352), .Y(n3654)
         );
  NOR2BX1 U3122 ( .AN(BUS_WIDTH[0]), .B(n3707), .Y(n3655) );
  AND2X2 U3123 ( .A(n3777), .B(n3775), .Y(n3776) );
  AOI21X1 U3124 ( .A0(WBEB[1]), .A1(WRITE), .B0(n3676), .Y(n3777) );
  INVX1 U3125 ( .A(n3640), .Y(n3605) );
  OAI31X1 U3126 ( .A0(n3322), .A1(i_addr_1_), .A2(n3780), .B0(n3641), .Y(n3640) );
  INVX1 U3127 ( .A(n3601), .Y(n3641) );
  NAND2BX1 U3128 ( .AN(BUS_WIDTH[0]), .B(n3661), .Y(n3322) );
  NAND2BX1 U3129 ( .AN(BUS_WIDTH[1]), .B(BUS_WIDTH[0]), .Y(n3320) );
  NAND2X1 U3130 ( .A(BUS_WIDTH[0]), .B(BUS_WIDTH[1]), .Y(n3376) );
  NAND2BX1 U3131 ( .AN(ADDR_SHIFT[0]), .B(n3700), .Y(n3778) );
  NAND2BX1 U3132 ( .AN(ADDR_SHIFT[0]), .B(n3700), .Y(n3684) );
  NAND2BX1 U3133 ( .AN(ADDR_SHIFT[0]), .B(n3700), .Y(n3779) );
  INVX1 U3134 ( .A(ADDR_SHIFT[1]), .Y(n3700) );
  NAND2BX1 U3135 ( .AN(ADDR_SHIFT[0]), .B(ADDR_SHIFT[1]), .Y(n3685) );
  INVX1 U3136 ( .A(BUS_WIDTH[1]), .Y(n3661) );
  DFFRX1 cs_reg_6_ ( .D(ns[6]), .CK(CLK), .RN(RSTb), .Q(cs[6]), .QN(n3758) );
  DFFRX1 cs_reg_2_ ( .D(ns[2]), .CK(CLK), .RN(RSTb), .Q(cs[2]), .QN(n3731) );
  DFFRX1 cs_reg_3_ ( .D(ns[3]), .CK(CLK), .RN(RSTb), .Q(cs[3]), .QN(n3729) );
  DFFRX1 cs_reg_1_ ( .D(ns[1]), .CK(CLK), .RN(RSTb), .Q(cs[1]) );
  DFFRX1 cs_reg_5_ ( .D(ns[5]), .CK(CLK), .RN(RSTb), .Q(cs[5]), .QN(n3711) );
  DFFRX1 cs_reg_4_ ( .D(ns[4]), .CK(CLK), .RN(RSTb), .Q(cs[4]), .QN(n3713) );
  DFFRX1 timing_cnt_reg_1_ ( .D(n3202), .CK(CLK), .RN(RSTb), .Q(timing_cnt[1])
         );
  DFFRX1 timing_cnt_reg_0_ ( .D(n3203), .CK(CLK), .RN(RSTb), .Q(timing_cnt[0])
         );
  DFFRX1 timing_cnt_reg_2_ ( .D(n3201), .CK(CLK), .RN(RSTb), .Q(timing_cnt[2])
         );
  DFFRX1 i_addr_reg_2_ ( .D(n3230), .CK(CLK), .RN(RSTb), .Q(i_addr_2_), .QN(
        n3734) );
  DFFRX1 i_addr_reg_3_ ( .D(n3229), .CK(CLK), .RN(RSTb), .Q(i_addr_3_), .QN(
        n3701) );
  DFFRX1 repeat_cnt_reg_0_ ( .D(n3205), .CK(CLK), .RN(RSTb), .Q(repeat_cnt[0])
         );
  DFFRX1 i_addr_reg_0_ ( .D(n3232), .CK(CLK), .RN(RSTb), .Q(i_addr1234_0_), 
        .QN(n3715) );
  DFFRX1 repeat_cnt_reg_1_ ( .D(n3204), .CK(CLK), .RN(RSTb), .Q(repeat_cnt[1])
         );
  DFFRX1 timing_cnt_reg_3_ ( .D(n3200), .CK(CLK), .RN(RSTb), .Q(timing_cnt[3])
         );
  DFFRX1 i_addr_reg_12_ ( .D(n3220), .CK(CLK), .RN(RSTb), .Q(i_addr_12_), .QN(
        n3732) );
  DFFRX1 i_addr_reg_10_ ( .D(n3222), .CK(CLK), .RN(RSTb), .Q(i_addr_10_), .QN(
        n3717) );
  DFFRX1 i_addr_reg_8_ ( .D(n3224), .CK(CLK), .RN(RSTb), .Q(i_addr_8_), .QN(
        n3733) );
  DFFRX1 i_addr_reg_6_ ( .D(n3226), .CK(CLK), .RN(RSTb), .Q(i_addr_6_), .QN(
        n3708) );
  DFFRX1 i_addr_reg_4_ ( .D(n3228), .CK(CLK), .RN(RSTb), .Q(i_addr_4_), .QN(
        n3716) );
  DFFRX1 i_addr_reg_13_ ( .D(n3219), .CK(CLK), .RN(RSTb), .Q(i_addr_13_), .QN(
        n3705) );
  DFFRX1 i_addr_reg_11_ ( .D(n3221), .CK(CLK), .RN(RSTb), .Q(i_addr_11_), .QN(
        n3703) );
  DFFRX1 i_addr_reg_9_ ( .D(n3223), .CK(CLK), .RN(RSTb), .Q(i_addr_9_), .QN(
        n3706) );
  DFFRX1 i_addr_reg_7_ ( .D(n3225), .CK(CLK), .RN(RSTb), .Q(i_addr_7_), .QN(
        n3712) );
  DFFRX1 i_addr_reg_5_ ( .D(n3227), .CK(CLK), .RN(RSTb), .Q(i_addr_5_), .QN(
        n3730) );
  DFFRX1 RDATA_reg_31_ ( .D(n3233), .CK(CLK), .RN(RSTb), .Q(RDATA[31]) );
  DFFRX1 RDATA_reg_30_ ( .D(n3234), .CK(CLK), .RN(RSTb), .Q(RDATA[30]) );
  DFFRX1 RDATA_reg_29_ ( .D(n3235), .CK(CLK), .RN(RSTb), .Q(RDATA[29]) );
  DFFRX1 RDATA_reg_28_ ( .D(n3236), .CK(CLK), .RN(RSTb), .Q(RDATA[28]) );
  DFFRX1 RDATA_reg_27_ ( .D(n3237), .CK(CLK), .RN(RSTb), .Q(RDATA[27]) );
  DFFRX1 RDATA_reg_26_ ( .D(n3238), .CK(CLK), .RN(RSTb), .Q(RDATA[26]) );
  DFFRX1 RDATA_reg_25_ ( .D(n3239), .CK(CLK), .RN(RSTb), .Q(RDATA[25]) );
  DFFRX1 RDATA_reg_24_ ( .D(n3240), .CK(CLK), .RN(RSTb), .Q(RDATA[24]) );
  DFFRX1 RDATA_reg_7_ ( .D(n3257), .CK(CLK), .RN(RSTb), .Q(RDATA[7]) );
  DFFRX1 RDATA_reg_6_ ( .D(n3258), .CK(CLK), .RN(RSTb), .Q(RDATA[6]) );
  DFFRX1 RDATA_reg_5_ ( .D(n3259), .CK(CLK), .RN(RSTb), .Q(RDATA[5]) );
  DFFRX1 RDATA_reg_4_ ( .D(n3260), .CK(CLK), .RN(RSTb), .Q(RDATA[4]) );
  DFFRX1 RDATA_reg_3_ ( .D(n3261), .CK(CLK), .RN(RSTb), .Q(RDATA[3]) );
  DFFRX1 RDATA_reg_2_ ( .D(n3262), .CK(CLK), .RN(RSTb), .Q(RDATA[2]) );
  DFFRX1 RDATA_reg_1_ ( .D(n3263), .CK(CLK), .RN(RSTb), .Q(RDATA[1]) );
  DFFRX1 RDATA_reg_0_ ( .D(n3264), .CK(CLK), .RN(RSTb), .Q(RDATA[0]) );
  DFFRX1 RDATA_reg_23_ ( .D(n3241), .CK(CLK), .RN(RSTb), .Q(RDATA[23]) );
  DFFRX1 RDATA_reg_22_ ( .D(n3242), .CK(CLK), .RN(RSTb), .Q(RDATA[22]) );
  DFFRX1 RDATA_reg_21_ ( .D(n3243), .CK(CLK), .RN(RSTb), .Q(RDATA[21]) );
  DFFRX1 RDATA_reg_20_ ( .D(n3244), .CK(CLK), .RN(RSTb), .Q(RDATA[20]) );
  DFFRX1 RDATA_reg_19_ ( .D(n3245), .CK(CLK), .RN(RSTb), .Q(RDATA[19]) );
  DFFRX1 RDATA_reg_18_ ( .D(n3246), .CK(CLK), .RN(RSTb), .Q(RDATA[18]) );
  DFFRX1 RDATA_reg_17_ ( .D(n3247), .CK(CLK), .RN(RSTb), .Q(RDATA[17]) );
  DFFRX1 RDATA_reg_16_ ( .D(n3248), .CK(CLK), .RN(RSTb), .Q(RDATA[16]) );
  DFFRX1 RDATA_reg_15_ ( .D(n3249), .CK(CLK), .RN(RSTb), .Q(RDATA[15]), .QN(
        n3197) );
  DFFRX1 RDATA_reg_14_ ( .D(n3250), .CK(CLK), .RN(RSTb), .Q(RDATA[14]), .QN(
        n3196) );
  DFFRX1 RDATA_reg_13_ ( .D(n3251), .CK(CLK), .RN(RSTb), .Q(RDATA[13]), .QN(
        n3195) );
  DFFRX1 RDATA_reg_12_ ( .D(n3252), .CK(CLK), .RN(RSTb), .Q(RDATA[12]), .QN(
        n3194) );
  DFFRX1 RDATA_reg_11_ ( .D(n3253), .CK(CLK), .RN(RSTb), .Q(RDATA[11]), .QN(
        n3193) );
  DFFRX1 RDATA_reg_10_ ( .D(n3254), .CK(CLK), .RN(RSTb), .Q(RDATA[10]), .QN(
        n3192) );
  DFFRX1 RDATA_reg_9_ ( .D(n3255), .CK(CLK), .RN(RSTb), .Q(RDATA[9]), .QN(
        n3199) );
  DFFRX1 RDATA_reg_8_ ( .D(n3256), .CK(CLK), .RN(RSTb), .Q(RDATA[8]), .QN(
        n3198) );
  DFFRX1 i_addr_reg_14_ ( .D(n3218), .CK(CLK), .RN(RSTb), .Q(i_addr_14_), .QN(
        n3714) );
  DFFRX1 i_addr_reg_18_ ( .D(n3214), .CK(CLK), .RN(RSTb), .Q(i_addr_18_), .QN(
        n3704) );
  DFFRX1 i_addr_reg_17_ ( .D(n3215), .CK(CLK), .RN(RSTb), .Q(i_addr_17_), .QN(
        n3719) );
  DFFRX1 i_addr_reg_16_ ( .D(n3216), .CK(CLK), .RN(RSTb), .Q(i_addr_16_), .QN(
        n3735) );
  DFFRX1 i_addr_reg_15_ ( .D(n3217), .CK(CLK), .RN(RSTb), .Q(i_addr_15_), .QN(
        n3702) );
  DFFRX1 i_addr_reg_20_ ( .D(n3212), .CK(CLK), .RN(RSTb), .Q(i_addr_20_), .QN(
        n3709) );
  DFFRX1 i_addr_reg_19_ ( .D(n3213), .CK(CLK), .RN(RSTb), .Q(i_addr_19_), .QN(
        n3736) );
  DFFRX1 i_addr_reg_23_ ( .D(n3209), .CK(CLK), .RN(RSTb), .Q(i_addr_23_), .QN(
        n3710) );
  DFFRX1 i_addr_reg_22_ ( .D(n3210), .CK(CLK), .RN(RSTb), .Q(i_addr_22_), .QN(
        n3737) );
  DFFRX1 i_addr_reg_21_ ( .D(n3211), .CK(CLK), .RN(RSTb), .Q(i_addr_21_), .QN(
        n3718) );
  DFFRX1 i_addr_reg_25_ ( .D(n3207), .CK(CLK), .RN(RSTb), .Q(i_addr_25_), .QN(
        n3773) );
  DFFRX1 i_addr_reg_24_ ( .D(n3208), .CK(CLK), .RN(RSTb), .Q(i_addr_24_), .QN(
        n3720) );
  DFFRX1 i_addr_reg_26_ ( .D(n3206), .CK(CLK), .RN(RSTb), .Q(i_addr_26_), .QN(
        n3772) );
  DFFRX1 i_wdata_reg_24_ ( .D(WDATA[24]), .CK(CLK), .RN(RSTb), .Q(i_wdata_24_), 
        .QN(n3721) );
  DFFRX1 i_wdata_reg_25_ ( .D(WDATA[25]), .CK(CLK), .RN(RSTb), .Q(i_wdata_25_), 
        .QN(n3722) );
  DFFRX1 i_wdata_reg_26_ ( .D(WDATA[26]), .CK(CLK), .RN(RSTb), .Q(i_wdata_26_), 
        .QN(n3723) );
  DFFRX1 i_wdata_reg_27_ ( .D(WDATA[27]), .CK(CLK), .RN(RSTb), .Q(i_wdata_27_), 
        .QN(n3724) );
  DFFRX1 i_wdata_reg_28_ ( .D(WDATA[28]), .CK(CLK), .RN(RSTb), .Q(i_wdata_28_), 
        .QN(n3725) );
  DFFRX1 i_wdata_reg_29_ ( .D(WDATA[29]), .CK(CLK), .RN(RSTb), .Q(i_wdata_29_), 
        .QN(n3726) );
  DFFRX1 i_wdata_reg_30_ ( .D(WDATA[30]), .CK(CLK), .RN(RSTb), .Q(i_wdata_30_), 
        .QN(n3727) );
  DFFRX1 i_wdata_reg_31_ ( .D(WDATA[31]), .CK(CLK), .RN(RSTb), .Q(i_wdata_31_), 
        .QN(n3728) );
  DFFRX1 i_wdata_reg_8_ ( .D(WDATA[8]), .CK(CLK), .RN(RSTb), .Q(i_wdata_8_), 
        .QN(n3746) );
  DFFRX1 i_wdata_reg_9_ ( .D(WDATA[9]), .CK(CLK), .RN(RSTb), .Q(i_wdata_9_), 
        .QN(n3747) );
  DFFRX1 i_wdata_reg_10_ ( .D(WDATA[10]), .CK(CLK), .RN(RSTb), .Q(i_wdata_10_), 
        .QN(n3748) );
  DFFRX1 i_wdata_reg_11_ ( .D(WDATA[11]), .CK(CLK), .RN(RSTb), .Q(i_wdata_11_), 
        .QN(n3749) );
  DFFRX1 i_wdata_reg_12_ ( .D(WDATA[12]), .CK(CLK), .RN(RSTb), .Q(i_wdata_12_), 
        .QN(n3750) );
  DFFRX1 i_wdata_reg_13_ ( .D(WDATA[13]), .CK(CLK), .RN(RSTb), .Q(i_wdata_13_), 
        .QN(n3751) );
  DFFRX1 i_wdata_reg_14_ ( .D(WDATA[14]), .CK(CLK), .RN(RSTb), .Q(i_wdata_14_), 
        .QN(n3752) );
  DFFRX1 i_wdata_reg_15_ ( .D(WDATA[15]), .CK(CLK), .RN(RSTb), .Q(i_wdata_15_), 
        .QN(n3753) );
  DFFRX1 i_wdata_reg_16_ ( .D(WDATA[16]), .CK(CLK), .RN(RSTb), .Q(i_wdata_16_), 
        .QN(n3738) );
  DFFRX1 i_wdata_reg_17_ ( .D(WDATA[17]), .CK(CLK), .RN(RSTb), .Q(i_wdata_17_), 
        .QN(n3739) );
  DFFRX1 i_wdata_reg_18_ ( .D(WDATA[18]), .CK(CLK), .RN(RSTb), .Q(i_wdata_18_), 
        .QN(n3740) );
  DFFRX1 i_wdata_reg_19_ ( .D(WDATA[19]), .CK(CLK), .RN(RSTb), .Q(i_wdata_19_), 
        .QN(n3741) );
  DFFRX1 i_wdata_reg_20_ ( .D(WDATA[20]), .CK(CLK), .RN(RSTb), .Q(i_wdata_20_), 
        .QN(n3742) );
  DFFRX1 i_wdata_reg_21_ ( .D(WDATA[21]), .CK(CLK), .RN(RSTb), .Q(i_wdata_21_), 
        .QN(n3743) );
  DFFRX1 i_wdata_reg_22_ ( .D(WDATA[22]), .CK(CLK), .RN(RSTb), .Q(i_wdata_22_), 
        .QN(n3744) );
  DFFRX1 i_wdata_reg_23_ ( .D(WDATA[23]), .CK(CLK), .RN(RSTb), .Q(i_wdata_23_), 
        .QN(n3745) );
  DFFRX1 i_wdata_reg_0_ ( .D(WDATA[0]), .CK(CLK), .RN(RSTb), .QN(n2816) );
  DFFRX1 i_wdata_reg_1_ ( .D(WDATA[1]), .CK(CLK), .RN(RSTb), .QN(n2817) );
  DFFRX1 i_wdata_reg_2_ ( .D(WDATA[2]), .CK(CLK), .RN(RSTb), .QN(n2818) );
  DFFRX1 i_wdata_reg_3_ ( .D(WDATA[3]), .CK(CLK), .RN(RSTb), .QN(n2819) );
  DFFRX1 i_wdata_reg_4_ ( .D(WDATA[4]), .CK(CLK), .RN(RSTb), .QN(n2820) );
  DFFRX1 i_wdata_reg_5_ ( .D(WDATA[5]), .CK(CLK), .RN(RSTb), .QN(n2821) );
  DFFRX1 i_wdata_reg_6_ ( .D(WDATA[6]), .CK(CLK), .RN(RSTb), .QN(n2822) );
  DFFRX1 i_wdata_reg_7_ ( .D(WDATA[7]), .CK(CLK), .RN(RSTb), .QN(n2823) );
  NAND2X1 U3137 ( .A(i_addr_25_), .B(n3760), .Y(n1) );
  XOR2X1 U3138 ( .A(i_addr_25_), .B(n3760), .Y(i_addr1234_25_) );
  XOR2X1 U3139 ( .A(i_addr_24_), .B(n3768), .Y(i_addr1234_24_) );
  XOR2X1 U3140 ( .A(i_addr_23_), .B(n3767), .Y(i_addr1234_23_) );
  XOR2X1 U3141 ( .A(i_addr_22_), .B(n3766), .Y(i_addr1234_22_) );
  XOR2X1 U3142 ( .A(i_addr_21_), .B(n3765), .Y(i_addr1234_21_) );
  XOR2X1 U3143 ( .A(i_addr_20_), .B(n3764), .Y(i_addr1234_20_) );
  XOR2X1 U3144 ( .A(i_addr_19_), .B(n3763), .Y(i_addr1234_19_) );
  XOR2X1 U3145 ( .A(i_addr_18_), .B(n3762), .Y(i_addr1234_18_) );
  XOR2X1 U3146 ( .A(i_addr_17_), .B(n3761), .Y(i_addr1234_17_) );
  XOR2X1 U3147 ( .A(i_addr_16_), .B(carry_16_), .Y(i_addr1234_16_) );
  INVX1 U3148 ( .A(ADDR_SETUP[0]), .Y(n3517) );
  DFFSX1 cs_reg_0_ ( .D(ns[0]), .CK(CLK), .SN(RSTb), .Q(cs[0]) );
  NAND2BX1 U3149 ( .AN(n3649), .B(BANK_SEL[5]), .Y(EXT_CSb[5]) );
  OA22X1 U3150 ( .A0(ADDR_SETUP[0]), .A1(n3499), .B0(CS_SETUP[0]), .B1(n3500), 
        .Y(n3492) );
endmodule


module SMC_REG ( PCLK, PRESETn, PADDR, PSEL, PENABLE, PWRITE, PWDATA, PRDATA, 
        SRAM_START, BANK_SEL, ADDR_SETUP, ADDR_HOLD, CS_SETUP, CS_HOLD, 
        ACC_CYCLE, BUS_WIDTH, ADDR_SHIFT );
  input [5:2] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  input [8:0] BANK_SEL;
  output [2:0] ADDR_SETUP;
  output [2:0] ADDR_HOLD;
  output [2:0] CS_SETUP;
  output [2:0] CS_HOLD;
  output [3:0] ACC_CYCLE;
  output [1:0] BUS_WIDTH;
  output [1:0] ADDR_SHIFT;
  input PCLK, PRESETn, PSEL, PENABLE, PWRITE, SRAM_START;
  wire   \bank_reg[8][15] , \bank_reg[8][14] , \bank_reg[8][13] ,
         \bank_reg[8][12] , \bank_reg[8][11] , \bank_reg[8][10] ,
         \bank_reg[8][9] , \bank_reg[8][8] , \bank_reg[8][7] ,
         \bank_reg[8][6] , \bank_reg[8][5] , \bank_reg[8][4] ,
         \bank_reg[8][3] , \bank_reg[8][2] , \bank_reg[8][1] ,
         \bank_reg[8][0] , \bank_reg[7][15] , \bank_reg[7][14] ,
         \bank_reg[7][13] , \bank_reg[7][12] , \bank_reg[7][11] ,
         \bank_reg[7][10] , \bank_reg[7][9] , \bank_reg[7][8] ,
         \bank_reg[7][7] , \bank_reg[7][6] , \bank_reg[7][5] ,
         \bank_reg[7][4] , \bank_reg[7][3] , \bank_reg[7][2] ,
         \bank_reg[7][1] , \bank_reg[7][0] , \bank_reg[6][15] ,
         \bank_reg[6][14] , \bank_reg[6][13] , \bank_reg[6][12] ,
         \bank_reg[6][11] , \bank_reg[6][10] , \bank_reg[6][9] ,
         \bank_reg[6][8] , \bank_reg[6][7] , \bank_reg[6][6] ,
         \bank_reg[6][5] , \bank_reg[6][4] , \bank_reg[6][3] ,
         \bank_reg[6][2] , \bank_reg[6][1] , \bank_reg[6][0] ,
         \bank_reg[5][15] , \bank_reg[5][14] , \bank_reg[5][13] ,
         \bank_reg[5][12] , \bank_reg[5][11] , \bank_reg[5][10] ,
         \bank_reg[5][9] , \bank_reg[5][8] , \bank_reg[5][7] ,
         \bank_reg[5][6] , \bank_reg[5][5] , \bank_reg[5][4] ,
         \bank_reg[5][3] , \bank_reg[5][2] , \bank_reg[5][1] ,
         \bank_reg[5][0] , \bank_reg[4][15] , \bank_reg[4][14] ,
         \bank_reg[4][13] , \bank_reg[4][12] , \bank_reg[4][11] ,
         \bank_reg[4][10] , \bank_reg[4][9] , \bank_reg[4][8] ,
         \bank_reg[4][7] , \bank_reg[4][6] , \bank_reg[4][5] ,
         \bank_reg[4][4] , \bank_reg[4][3] , \bank_reg[4][2] ,
         \bank_reg[4][1] , \bank_reg[4][0] , \bank_reg[3][15] ,
         \bank_reg[3][14] , \bank_reg[3][13] , \bank_reg[3][12] ,
         \bank_reg[3][11] , \bank_reg[3][10] , \bank_reg[3][9] ,
         \bank_reg[3][8] , \bank_reg[3][7] , \bank_reg[3][6] ,
         \bank_reg[3][5] , \bank_reg[3][4] , \bank_reg[3][3] ,
         \bank_reg[3][2] , \bank_reg[3][1] , \bank_reg[3][0] ,
         \bank_reg[2][15] , \bank_reg[2][14] , \bank_reg[2][13] ,
         \bank_reg[2][12] , \bank_reg[2][11] , \bank_reg[2][10] ,
         \bank_reg[2][9] , \bank_reg[2][8] , \bank_reg[2][7] ,
         \bank_reg[2][6] , \bank_reg[2][5] , \bank_reg[2][4] ,
         \bank_reg[2][3] , \bank_reg[2][2] , \bank_reg[2][1] ,
         \bank_reg[2][0] , \bank_reg[1][15] , \bank_reg[1][14] ,
         \bank_reg[1][13] , \bank_reg[1][12] , \bank_reg[1][11] ,
         \bank_reg[1][10] , \bank_reg[1][9] , \bank_reg[1][8] ,
         \bank_reg[1][7] , \bank_reg[1][6] , \bank_reg[1][5] ,
         \bank_reg[1][4] , \bank_reg[1][3] , \bank_reg[1][2] ,
         \bank_reg[1][1] , \bank_reg[1][0] , \bank_reg[0][15] ,
         \bank_reg[0][14] , \bank_reg[0][13] , \bank_reg[0][12] ,
         \bank_reg[0][11] , \bank_reg[0][10] , \bank_reg[0][9] ,
         \bank_reg[0][8] , \bank_reg[0][7] , \bank_reg[0][6] ,
         \bank_reg[0][5] , \bank_reg[0][4] , \bank_reg[0][3] ,
         \bank_reg[0][2] , \bank_reg[0][1] , \bank_reg[0][0] , n1194, n1195,
         n1196, n1197, n1198, n1199, n1200, n1201, n1202, n1203, n1204, n1205,
         n1206, n1207, n1208, n1209, n1210, n1211, n1212, n1213, n1214, n1215,
         n1216, n1217, n1218, n1219, n1220, n1221, n1222, n1223, n1224, n1225,
         n1226, n1227, n1228, n1229, n1230, n1231, n1232, n1233, n1234, n1235,
         n1236, n1237, n1238, n1239, n1240, n1241, n1242, n1243, n1244, n1245,
         n1246, n1247, n1248, n1249, n1250, n1251, n1252, n1253, n1254, n1255,
         n1256, n1257, n1258, n1259, n1260, n1261, n1262, n1263, n1264, n1265,
         n1266, n1267, n1268, n1269, n1270, n1271, n1272, n1273, n1274, n1275,
         n1276, n1277, n1278, n1279, n1280, n1281, n1282, n1283, n1284, n1285,
         n1286, n1287, n1288, n1289, n1290, n1291, n1292, n1293, n1294, n1295,
         n1296, n1297, n1298, n1299, n1300, n1301, n1302, n1303, n1304, n1305,
         n1306, n1307, n1308, n1309, n1310, n1311, n1312, n1313, n1314, n1315,
         n1316, n1317, n1318, n1319, n1320, n1321, n1322, n1323, n1324, n1325,
         n1326, n1327, n1328, n1329, n1330, n1331, n1332, n1333, n1334, n1335,
         n1336, n1337, n1367, n1368, n1369, n1370, n1371, n1372, n1373, n1374,
         n1375, n1376, n1377, n1378, n1379, n1380, n1381, n1382, n1383, n1384,
         n1385, n1386, n1387, n1388, n1389, n1390, n1391, n1392, n1393, n1394,
         n1395, n1396, n1397, n1398, n1399, n1400, n1402, n1404, n1405, n1406,
         n1407, n1409, n1411, n1412, n1414, n1416, n1417, n1418, n1419, n1424,
         n1427, n1428, n1429, n1434, n1437, n1438, n1439, n1444, n1447, n1448,
         n1449, n1454, n1457, n1458, n1459, n1464, n1467, n1468, n1469, n1474,
         n1477, n1478, n1479, n1484, n1487, n1488, n1489, n1494, n1497, n1498,
         n1499, n1504, n1507, n1508, n1509, n1514, n1517, n1518, n1519, n1524,
         n1527, n1528, n1529, n1534, n1537, n1538, n1539, n1544, n1547, n1548,
         n1549, n1554, n1557, n1558, n1559, n1562, n1563, n1564, n1566, n1567,
         n1570, n1573, n1574, n1575, n1577, n1578, n1579, n1580, n1581, n1583,
         n1584, n1586, n1587, n1588, n1590, n1591, n1592, n1593, n1594, n1596,
         n1597, n1598, n1600, n1601, n1602, n1604, n1605, n1606, n1608, n1609,
         n1610, n1612, n1613, n1614, n1616, n1617, n1618, n1620, n1621, n1622,
         n1624, n1625, n1626, n1628, n1629, n1630, n1632, n1633, n1634, n1636,
         n1637, n1638, n1640, n1641, n1642, n1644, n1645, n1646, n1648, n1649,
         n1650, n1652, n1653, n1654, n1655, n1657, n1658, n1659, n1660, n1661,
         n1663, n1664, n1665, n1666, n1667, n1668, n1669, n1670, n1671, n1674,
         n1675, n1676, n1677, n1678, n1679, n1680, n1681, n1682, n1683, n1684,
         n1685, n1686, n1687, n1689, n1690, n1691, n1692, n1693, n1694, n1695,
         n1696, n1697, n1698, n1699, n1700, n1701, n1702, n1703, n1704, n1705,
         n1706, n1707, n1708, n1709, n1710, n1711, n1712, n1713, n1714, n1715,
         n1716, n1717, n1718, n1719, n1720, n1721, n1722, n1723, n1724, n1725,
         n1726, n1727, n1728, n1729, n1730, n1731, n1732, n1733, n1734, n1735,
         n1736, n1737, n1738, n1739, n1740, n1741, n1742, n1743, n1744, n1745,
         n1746, n1747, n1748, n1749, n1750, n1751, n1752, n1753, n1754, n1755,
         n1756, n1757, n1758, n1759, n1760, n1761, n1762, n1763, n1764, n1765,
         n1766, n1767, n1768, n1769, n1770, n1771, n1772, n1773, n1774, n1775,
         n1776, n1777, n1778, n1779, n1780, n1781, n1782, n1783, n1784, n1785,
         n1786, n1787, n1788, n1789, n1790, n1791, n1792, n1793, n1794, n1795,
         n1796, n1797, n1798, n1799, n1800, n1801, n1802, n1803, n1804, n1805,
         n1806, n1807, n1808, n1809, n1810, n1811, n1812, n1813;
  assign BUS_WIDTH[1] = 1'b0;
  assign BUS_WIDTH[0] = 1'b0;
  assign ADDR_SHIFT[1] = 1'b0;
  assign ADDR_SHIFT[0] = 1'b0;
  assign PRDATA[0] = 1'b0;
  assign PRDATA[1] = 1'b0;
  assign PRDATA[2] = 1'b0;
  assign PRDATA[3] = 1'b0;
  assign PRDATA[20] = 1'b0;
  assign PRDATA[21] = 1'b0;
  assign PRDATA[22] = 1'b0;
  assign PRDATA[23] = 1'b0;
  assign PRDATA[24] = 1'b0;
  assign PRDATA[25] = 1'b0;
  assign PRDATA[26] = 1'b0;
  assign PRDATA[27] = 1'b0;
  assign PRDATA[28] = 1'b0;
  assign PRDATA[29] = 1'b0;
  assign PRDATA[30] = 1'b0;
  assign PRDATA[31] = 1'b0;

  INVX2 U1823 ( .A(n1669), .Y(n1653) );
  AOI221X4 U1824 ( .A0(n1803), .A1(\bank_reg[7][9] ), .B0(n1583), .B1(
        \bank_reg[1][9] ), .C0(n1638), .Y(n1637) );
  AOI221X4 U1825 ( .A0(n1803), .A1(\bank_reg[7][8] ), .B0(n1583), .B1(
        \bank_reg[1][8] ), .C0(n1642), .Y(n1641) );
  AOI221X4 U1826 ( .A0(n1803), .A1(\bank_reg[7][7] ), .B0(n1583), .B1(
        \bank_reg[1][7] ), .C0(n1646), .Y(n1645) );
  AOI221X4 U1827 ( .A0(n1803), .A1(\bank_reg[7][6] ), .B0(n1583), .B1(
        \bank_reg[1][6] ), .C0(n1650), .Y(n1649) );
  AOI221X4 U1828 ( .A0(n1803), .A1(\bank_reg[7][12] ), .B0(n1583), .B1(
        \bank_reg[1][12] ), .C0(n1584), .Y(n1581) );
  AOI221X4 U1829 ( .A0(n1803), .A1(\bank_reg[7][11] ), .B0(n1583), .B1(
        \bank_reg[1][11] ), .C0(n1594), .Y(n1593) );
  AOI221X4 U1830 ( .A0(n1803), .A1(\bank_reg[7][5] ), .B0(n1583), .B1(
        \bank_reg[1][5] ), .C0(n1602), .Y(n1601) );
  AOI221X4 U1831 ( .A0(n1803), .A1(\bank_reg[7][10] ), .B0(n1583), .B1(
        \bank_reg[1][10] ), .C0(n1598), .Y(n1597) );
  AOI221X4 U1832 ( .A0(n1803), .A1(\bank_reg[7][4] ), .B0(n1583), .B1(
        \bank_reg[1][4] ), .C0(n1606), .Y(n1605) );
  AOI221X4 U1833 ( .A0(n1803), .A1(\bank_reg[7][3] ), .B0(n1583), .B1(
        \bank_reg[1][3] ), .C0(n1610), .Y(n1609) );
  AOI221X4 U1834 ( .A0(n1803), .A1(\bank_reg[7][2] ), .B0(n1583), .B1(
        \bank_reg[1][2] ), .C0(n1626), .Y(n1625) );
  AOI221X4 U1835 ( .A0(n1803), .A1(\bank_reg[7][1] ), .B0(n1583), .B1(
        \bank_reg[1][1] ), .C0(n1630), .Y(n1629) );
  AOI221X4 U1836 ( .A0(n1803), .A1(\bank_reg[7][0] ), .B0(n1583), .B1(
        \bank_reg[1][0] ), .C0(n1634), .Y(n1633) );
  INVX3 U1837 ( .A(n1677), .Y(n1579) );
  NAND2BX1 U1838 ( .AN(BANK_SEL[2]), .B(n1674), .Y(n1659) );
  NAND2BX1 U1839 ( .AN(BANK_SEL[0]), .B(n1666), .Y(n1681) );
  NAND2BX2 U1840 ( .AN(BANK_SEL[4]), .B(n1801), .Y(n1682) );
  NAND2BX1 U1841 ( .AN(BANK_SEL[5]), .B(n1686), .Y(n1668) );
  NAND3BX1 U1842 ( .AN(BANK_SEL[4]), .B(n1657), .C(n1655), .Y(n1669) );
  AOI221X1 U1843 ( .A0(BANK_SEL[2]), .A1(n1681), .B0(BANK_SEL[0]), .B1(n1682), 
        .C0(n1683), .Y(n1679) );
  INVX1 U1844 ( .A(n1681), .Y(n1674) );
  INVX1 U1845 ( .A(n1682), .Y(n1666) );
  INVX1 U1846 ( .A(n1668), .Y(n1685) );
  INVX1 U1847 ( .A(BANK_SEL[6]), .Y(n1686) );
  INVX1 U1848 ( .A(n1658), .Y(n1583) );
  INVX1 U1849 ( .A(n1670), .Y(n1655) );
  INVX1 U1850 ( .A(BANK_SEL[7]), .Y(n1661) );
  OAI211X1 U1851 ( .A0(n1579), .A1(n1740), .B0(n1620), .C0(n1621), .Y(
        ADDR_SETUP[0]) );
  INVX1 U1852 ( .A(n1659), .Y(n1678) );
  NAND4BX1 U1853 ( .AN(BANK_SEL[6]), .B(n1652), .C(BANK_SEL[5]), .D(n1653), 
        .Y(n1588) );
  NAND4BX1 U1854 ( .AN(BANK_SEL[5]), .B(n1652), .C(BANK_SEL[6]), .D(n1653), 
        .Y(n1586) );
  OAI211X1 U1855 ( .A0(n1678), .A1(n1676), .B0(n1679), .C0(n1680), .Y(n1677)
         );
  INVX1 U1856 ( .A(BANK_SEL[3]), .Y(n1652) );
  AND2X2 U1857 ( .A(n1652), .B(n1685), .Y(n1801) );
  INVX1 U1858 ( .A(n1675), .Y(n1671) );
  NAND3BX1 U1859 ( .AN(BANK_SEL[8]), .B(n1661), .C(n1676), .Y(n1675) );
  NAND2BX1 U1860 ( .AN(BANK_SEL[2]), .B(n1671), .Y(n1670) );
  OAI211X1 U1861 ( .A0(n1579), .A1(n1741), .B0(n1616), .C0(n1617), .Y(
        ADDR_SETUP[1]) );
  NAND4BX1 U1862 ( .AN(n1659), .B(n1660), .C(BANK_SEL[1]), .D(n1661), .Y(n1658) );
  AND3X1 U1863 ( .A(BANK_SEL[2]), .B(n1671), .C(n1674), .Y(n1802) );
  AND3X2 U1864 ( .A(n1660), .B(BANK_SEL[7]), .C(n1663), .Y(n1803) );
  NAND4BX1 U1865 ( .AN(n1654), .B(n1655), .C(n1801), .D(n1657), .Y(n1587) );
  INVX1 U1866 ( .A(n1665), .Y(n1591) );
  NAND3BX1 U1867 ( .AN(n1657), .B(n1655), .C(n1666), .Y(n1665) );
  INVX1 U1868 ( .A(n1806), .Y(n1390) );
  INVX1 U1869 ( .A(n1807), .Y(n1385) );
  INVX1 U1870 ( .A(n1808), .Y(n1383) );
  INVX1 U1871 ( .A(n1809), .Y(n1380) );
  INVX1 U1872 ( .A(n1810), .Y(n1378) );
  INVX1 U1873 ( .A(n1811), .Y(n1375) );
  INVX1 U1874 ( .A(n1812), .Y(n1372) );
  INVX1 U1875 ( .A(n1813), .Y(n1368) );
  NAND2BX1 U1876 ( .AN(BANK_SEL[1]), .B(n1678), .Y(n1664) );
  INVX1 U1877 ( .A(BANK_SEL[4]), .Y(n1654) );
  INVX1 U1878 ( .A(n1667), .Y(n1590) );
  NAND3BX1 U1879 ( .AN(n1668), .B(BANK_SEL[3]), .C(n1653), .Y(n1667) );
  INVX1 U1880 ( .A(BANK_SEL[0]), .Y(n1657) );
  INVX1 U1881 ( .A(BANK_SEL[1]), .Y(n1676) );
  XOR2X1 U1882 ( .A(n1664), .B(BANK_SEL[7]), .Y(n1680) );
  INVX1 U1883 ( .A(n1664), .Y(n1663) );
  INVX1 U1884 ( .A(BANK_SEL[8]), .Y(n1660) );
  OAI211X1 U1885 ( .A0(n1801), .A1(n1654), .B0(n1660), .C0(n1684), .Y(n1683)
         );
  OA22X1 U1886 ( .A0(n1685), .A1(n1652), .B0(n1686), .B1(n1687), .Y(n1684) );
  BUFX2 U1887 ( .A(n1389), .Y(n1806) );
  NAND2BX1 U1888 ( .AN(n1386), .B(n1373), .Y(n1389) );
  BUFX2 U1889 ( .A(n1384), .Y(n1807) );
  NAND2BX1 U1890 ( .AN(n1386), .B(n1370), .Y(n1384) );
  BUFX2 U1891 ( .A(n1382), .Y(n1808) );
  NAND2BX1 U1892 ( .AN(n1381), .B(n1373), .Y(n1382) );
  BUFX2 U1893 ( .A(n1379), .Y(n1809) );
  NAND2BX1 U1894 ( .AN(n1381), .B(n1370), .Y(n1379) );
  BUFX2 U1895 ( .A(n1377), .Y(n1810) );
  NAND2BX1 U1896 ( .AN(n1376), .B(n1373), .Y(n1377) );
  BUFX2 U1897 ( .A(n1374), .Y(n1811) );
  NAND2BX1 U1898 ( .AN(n1376), .B(n1370), .Y(n1374) );
  BUFX2 U1899 ( .A(n1371), .Y(n1812) );
  NAND2BX1 U1900 ( .AN(n1369), .B(n1373), .Y(n1371) );
  BUFX2 U1901 ( .A(n1367), .Y(n1813) );
  NAND2BX1 U1902 ( .AN(n1369), .B(n1370), .Y(n1367) );
  INVX1 U1903 ( .A(n1805), .Y(n1397) );
  INVX1 U1904 ( .A(n1391), .Y(n1373) );
  NAND2BX1 U1905 ( .AN(n1392), .B(n1388), .Y(n1391) );
  NAND2BX1 U1906 ( .AN(n1381), .B(n1564), .Y(n1416) );
  NAND2BX1 U1907 ( .AN(n1369), .B(n1562), .Y(n1404) );
  NAND2BX1 U1908 ( .AN(n1376), .B(n1562), .Y(n1402) );
  NAND2BX1 U1909 ( .AN(n1381), .B(n1562), .Y(n1409) );
  NAND2BX1 U1910 ( .AN(n1386), .B(n1564), .Y(n1411) );
  OA22X1 U1911 ( .A0(n1749), .A1(n1804), .B0(n1708), .B1(n1416), .Y(n1464) );
  OA22X1 U1912 ( .A0(n1756), .A1(n1804), .B0(n1711), .B1(n1416), .Y(n1454) );
  OA22X1 U1913 ( .A0(n1751), .A1(n1804), .B0(n1709), .B1(n1416), .Y(n1444) );
  OA22X1 U1914 ( .A0(n1752), .A1(n1804), .B0(n1710), .B1(n1416), .Y(n1434) );
  OA22X1 U1915 ( .A0(n1757), .A1(n1804), .B0(n1712), .B1(n1416), .Y(n1424) );
  OA22X1 U1916 ( .A0(n1750), .A1(n1804), .B0(n1713), .B1(n1416), .Y(n1412) );
  OA22X1 U1917 ( .A0(n1762), .A1(n1804), .B0(n1718), .B1(n1416), .Y(n1570) );
  OA22X1 U1918 ( .A0(n1763), .A1(n1804), .B0(n1719), .B1(n1416), .Y(n1554) );
  OA22X1 U1919 ( .A0(n1764), .A1(n1804), .B0(n1720), .B1(n1416), .Y(n1544) );
  OA22X1 U1920 ( .A0(n1761), .A1(n1804), .B0(n1717), .B1(n1416), .Y(n1534) );
  OA22X1 U1921 ( .A0(n1755), .A1(n1804), .B0(n1715), .B1(n1416), .Y(n1524) );
  OA22X1 U1922 ( .A0(n1754), .A1(n1804), .B0(n1716), .B1(n1416), .Y(n1514) );
  OA22X1 U1923 ( .A0(n1753), .A1(n1804), .B0(n1714), .B1(n1416), .Y(n1504) );
  OA22X1 U1924 ( .A0(n1740), .A1(n1804), .B0(n1705), .B1(n1416), .Y(n1494) );
  OA22X1 U1925 ( .A0(n1741), .A1(n1804), .B0(n1707), .B1(n1416), .Y(n1484) );
  OA22X1 U1926 ( .A0(n1742), .A1(n1804), .B0(n1706), .B1(n1416), .Y(n1474) );
  INVX1 U1927 ( .A(n1574), .Y(n1564) );
  NAND2BX1 U1928 ( .AN(n1392), .B(n1575), .Y(n1574) );
  INVX1 U1929 ( .A(n1567), .Y(n1405) );
  NAND2BX1 U1930 ( .AN(n1376), .B(n1564), .Y(n1567) );
  INVX1 U1931 ( .A(n1578), .Y(n1575) );
  NAND3BX1 U1932 ( .AN(n1394), .B(n1573), .C(n1395), .Y(n1578) );
  INVX1 U1933 ( .A(n1566), .Y(n1406) );
  NAND2BX1 U1934 ( .AN(n1386), .B(n1562), .Y(n1566) );
  INVX1 U1935 ( .A(n1563), .Y(n1407) );
  NAND2BX1 U1936 ( .AN(n1369), .B(n1564), .Y(n1563) );
  OAI211X1 U1937 ( .A0(n1579), .A1(n1742), .B0(n1612), .C0(n1613), .Y(
        ADDR_SETUP[2]) );
  AOI222X1 U1938 ( .A0(n1802), .A1(\bank_reg[2][15] ), .B0(n1590), .B1(
        \bank_reg[3][15] ), .C0(n1591), .C1(\bank_reg[0][15] ), .Y(n1612) );
  AOI222X1 U1939 ( .A0(n1802), .A1(\bank_reg[2][13] ), .B0(n1590), .B1(
        \bank_reg[3][13] ), .C0(n1591), .C1(\bank_reg[0][13] ), .Y(n1620) );
  AOI222X1 U1940 ( .A0(n1802), .A1(\bank_reg[2][14] ), .B0(n1590), .B1(
        \bank_reg[3][14] ), .C0(n1591), .C1(\bank_reg[0][14] ), .Y(n1616) );
  OAI211X1 U1941 ( .A0(n1579), .A1(n1749), .B0(n1632), .C0(n1633), .Y(
        ADDR_HOLD[0]) );
  AOI222X1 U1942 ( .A0(n1802), .A1(\bank_reg[2][0] ), .B0(n1590), .B1(
        \bank_reg[3][0] ), .C0(n1591), .C1(\bank_reg[0][0] ), .Y(n1632) );
  OAI222X1 U1943 ( .A0(n1743), .A1(n1586), .B0(n1692), .B1(n1587), .C0(n1708), 
        .C1(n1588), .Y(n1634) );
  OAI211X1 U1944 ( .A0(n1579), .A1(n1750), .B0(n1600), .C0(n1601), .Y(
        CS_HOLD[2]) );
  AOI222X1 U1945 ( .A0(n1802), .A1(\bank_reg[2][5] ), .B0(n1590), .B1(
        \bank_reg[3][5] ), .C0(n1591), .C1(\bank_reg[0][5] ), .Y(n1600) );
  OAI222X1 U1946 ( .A0(n1758), .A1(n1586), .B0(n1698), .B1(n1587), .C0(n1713), 
        .C1(n1588), .Y(n1602) );
  OAI211X1 U1947 ( .A0(n1579), .A1(n1751), .B0(n1624), .C0(n1625), .Y(
        ADDR_HOLD[2]) );
  AOI222X1 U1948 ( .A0(n1802), .A1(\bank_reg[2][2] ), .B0(n1590), .B1(
        \bank_reg[3][2] ), .C0(n1591), .C1(\bank_reg[0][2] ), .Y(n1624) );
  OAI222X1 U1949 ( .A0(n1744), .A1(n1586), .B0(n1694), .B1(n1587), .C0(n1709), 
        .C1(n1588), .Y(n1626) );
  OAI211X1 U1950 ( .A0(n1579), .A1(n1752), .B0(n1608), .C0(n1609), .Y(
        CS_HOLD[0]) );
  AOI222X1 U1951 ( .A0(n1802), .A1(\bank_reg[2][3] ), .B0(n1590), .B1(
        \bank_reg[3][3] ), .C0(n1591), .C1(\bank_reg[0][3] ), .Y(n1608) );
  OAI222X1 U1952 ( .A0(n1745), .A1(n1586), .B0(n1695), .B1(n1587), .C0(n1710), 
        .C1(n1588), .Y(n1610) );
  OAI211X1 U1953 ( .A0(n1579), .A1(n1753), .B0(n1580), .C0(n1581), .Y(
        CS_SETUP[2]) );
  AOI222X1 U1954 ( .A0(n1802), .A1(\bank_reg[2][12] ), .B0(n1590), .B1(
        \bank_reg[3][12] ), .C0(n1591), .C1(\bank_reg[0][12] ), .Y(n1580) );
  OAI222X1 U1955 ( .A0(n1759), .A1(n1586), .B0(n1700), .B1(n1587), .C0(n1714), 
        .C1(n1588), .Y(n1584) );
  OAI211X1 U1956 ( .A0(n1579), .A1(n1754), .B0(n1592), .C0(n1593), .Y(
        CS_SETUP[1]) );
  AOI222X1 U1957 ( .A0(n1802), .A1(\bank_reg[2][11] ), .B0(n1590), .B1(
        \bank_reg[3][11] ), .C0(n1591), .C1(\bank_reg[0][11] ), .Y(n1592) );
  OAI211X1 U1958 ( .A0(n1579), .A1(n1761), .B0(n1636), .C0(n1637), .Y(
        ACC_CYCLE[3]) );
  OAI211X1 U1959 ( .A0(n1579), .A1(n1755), .B0(n1596), .C0(n1597), .Y(
        CS_SETUP[0]) );
  AOI222X1 U1960 ( .A0(n1802), .A1(\bank_reg[2][10] ), .B0(n1590), .B1(
        \bank_reg[3][10] ), .C0(n1591), .C1(\bank_reg[0][10] ), .Y(n1596) );
  OAI222X1 U1961 ( .A0(n1746), .A1(n1586), .B0(n1697), .B1(n1587), .C0(n1715), 
        .C1(n1588), .Y(n1598) );
  OAI222X1 U1962 ( .A0(n1747), .A1(n1586), .B0(n1693), .B1(n1587), .C0(n1711), 
        .C1(n1588), .Y(n1630) );
  OAI222X1 U1963 ( .A0(n1748), .A1(n1586), .B0(n1696), .B1(n1587), .C0(n1712), 
        .C1(n1588), .Y(n1606) );
  OAI222X1 U1964 ( .A0(n1760), .A1(n1586), .B0(n1699), .B1(n1587), .C0(n1716), 
        .C1(n1588), .Y(n1594) );
  OAI211X1 U1965 ( .A0(n1579), .A1(n1756), .B0(n1628), .C0(n1629), .Y(
        ADDR_HOLD[1]) );
  AOI222X1 U1966 ( .A0(n1802), .A1(\bank_reg[2][1] ), .B0(n1590), .B1(
        \bank_reg[3][1] ), .C0(n1591), .C1(\bank_reg[0][1] ), .Y(n1628) );
  OAI211X1 U1967 ( .A0(n1579), .A1(n1757), .B0(n1604), .C0(n1605), .Y(
        CS_HOLD[1]) );
  AOI222X1 U1968 ( .A0(n1802), .A1(\bank_reg[2][4] ), .B0(n1590), .B1(
        \bank_reg[3][4] ), .C0(n1591), .C1(\bank_reg[0][4] ), .Y(n1604) );
  OAI222X1 U1969 ( .A0(n1765), .A1(n1586), .B0(n1704), .B1(n1587), .C0(n1717), 
        .C1(n1588), .Y(n1638) );
  OAI211X1 U1970 ( .A0(n1579), .A1(n1762), .B0(n1648), .C0(n1649), .Y(
        ACC_CYCLE[0]) );
  AOI222X1 U1971 ( .A0(n1802), .A1(\bank_reg[2][6] ), .B0(n1590), .B1(
        \bank_reg[3][6] ), .C0(n1591), .C1(\bank_reg[0][6] ), .Y(n1648) );
  OAI222X1 U1972 ( .A0(n1766), .A1(n1586), .B0(n1701), .B1(n1587), .C0(n1718), 
        .C1(n1588), .Y(n1650) );
  OAI211X1 U1973 ( .A0(n1579), .A1(n1763), .B0(n1644), .C0(n1645), .Y(
        ACC_CYCLE[1]) );
  AOI222X1 U1974 ( .A0(n1802), .A1(\bank_reg[2][7] ), .B0(n1590), .B1(
        \bank_reg[3][7] ), .C0(n1591), .C1(\bank_reg[0][7] ), .Y(n1644) );
  OAI222X1 U1975 ( .A0(n1767), .A1(n1586), .B0(n1702), .B1(n1587), .C0(n1719), 
        .C1(n1588), .Y(n1646) );
  OAI211X1 U1976 ( .A0(n1579), .A1(n1764), .B0(n1640), .C0(n1641), .Y(
        ACC_CYCLE[2]) );
  AOI222X1 U1977 ( .A0(n1802), .A1(\bank_reg[2][8] ), .B0(n1590), .B1(
        \bank_reg[3][8] ), .C0(n1591), .C1(\bank_reg[0][8] ), .Y(n1640) );
  OAI222X1 U1978 ( .A0(n1768), .A1(n1586), .B0(n1703), .B1(n1587), .C0(n1720), 
        .C1(n1588), .Y(n1642) );
  AOI222X1 U1979 ( .A0(n1802), .A1(\bank_reg[2][9] ), .B0(n1590), .B1(
        \bank_reg[3][9] ), .C0(n1591), .C1(\bank_reg[0][9] ), .Y(n1636) );
  NAND2BX1 U1980 ( .AN(PADDR[4]), .B(PADDR[3]), .Y(n1376) );
  NAND2BX1 U1981 ( .AN(PADDR[3]), .B(PADDR[4]), .Y(n1381) );
  NAND2X1 U1982 ( .A(PADDR[3]), .B(PADDR[4]), .Y(n1386) );
  NAND2X1 U1983 ( .A(PSEL), .B(PENABLE), .Y(n1394) );
  INVX1 U1984 ( .A(PADDR[5]), .Y(n1395) );
  INVX1 U1985 ( .A(PADDR[2]), .Y(n1392) );
  OR2X1 U1986 ( .A(PADDR[3]), .B(PADDR[4]), .Y(n1369) );
  BUFX2 U1987 ( .A(n1396), .Y(n1805) );
  NAND3BX1 U1988 ( .AN(n1394), .B(PADDR[5]), .C(PWRITE), .Y(n1396) );
  AO22X1 U1989 ( .A0(\bank_reg[0][15] ), .A1(n1813), .B0(PWDATA[19]), .B1(
        n1368), .Y(n1322) );
  AO22X1 U1990 ( .A0(\bank_reg[0][14] ), .A1(n1813), .B0(PWDATA[18]), .B1(
        n1368), .Y(n1323) );
  AO22X1 U1991 ( .A0(\bank_reg[0][13] ), .A1(n1813), .B0(PWDATA[17]), .B1(
        n1368), .Y(n1324) );
  AO22X1 U1992 ( .A0(\bank_reg[0][12] ), .A1(n1813), .B0(PWDATA[16]), .B1(
        n1368), .Y(n1325) );
  AO22X1 U1993 ( .A0(\bank_reg[0][11] ), .A1(n1813), .B0(PWDATA[15]), .B1(
        n1368), .Y(n1326) );
  AO22X1 U1994 ( .A0(\bank_reg[0][10] ), .A1(n1813), .B0(PWDATA[14]), .B1(
        n1368), .Y(n1327) );
  AO22X1 U1995 ( .A0(\bank_reg[0][9] ), .A1(n1813), .B0(PWDATA[13]), .B1(n1368), .Y(n1328) );
  AO22X1 U1996 ( .A0(\bank_reg[0][8] ), .A1(n1813), .B0(PWDATA[12]), .B1(n1368), .Y(n1329) );
  AO22X1 U1997 ( .A0(\bank_reg[0][7] ), .A1(n1813), .B0(PWDATA[11]), .B1(n1368), .Y(n1330) );
  AO22X1 U1998 ( .A0(\bank_reg[0][6] ), .A1(n1813), .B0(PWDATA[10]), .B1(n1368), .Y(n1331) );
  AO22X1 U1999 ( .A0(\bank_reg[0][5] ), .A1(n1813), .B0(PWDATA[9]), .B1(n1368), 
        .Y(n1332) );
  AO22X1 U2000 ( .A0(\bank_reg[0][4] ), .A1(n1813), .B0(PWDATA[8]), .B1(n1368), 
        .Y(n1333) );
  AO22X1 U2001 ( .A0(\bank_reg[0][3] ), .A1(n1813), .B0(PWDATA[7]), .B1(n1368), 
        .Y(n1334) );
  AO22X1 U2002 ( .A0(\bank_reg[0][2] ), .A1(n1813), .B0(PWDATA[6]), .B1(n1368), 
        .Y(n1335) );
  AO22X1 U2003 ( .A0(\bank_reg[0][1] ), .A1(n1813), .B0(PWDATA[5]), .B1(n1368), 
        .Y(n1336) );
  AO22X1 U2004 ( .A0(\bank_reg[0][0] ), .A1(n1813), .B0(PWDATA[4]), .B1(n1368), 
        .Y(n1337) );
  INVX1 U2005 ( .A(n1393), .Y(n1388) );
  NAND3BX1 U2006 ( .AN(n1394), .B(n1395), .C(PWRITE), .Y(n1393) );
  AO22X1 U2007 ( .A0(\bank_reg[8][15] ), .A1(n1805), .B0(n1397), .B1(
        PWDATA[19]), .Y(n1194) );
  AO22X1 U2008 ( .A0(\bank_reg[8][14] ), .A1(n1805), .B0(n1397), .B1(
        PWDATA[18]), .Y(n1195) );
  AO22X1 U2009 ( .A0(\bank_reg[8][13] ), .A1(n1805), .B0(n1397), .B1(
        PWDATA[17]), .Y(n1196) );
  AO22X1 U2010 ( .A0(\bank_reg[8][12] ), .A1(n1805), .B0(n1397), .B1(
        PWDATA[16]), .Y(n1197) );
  AO22X1 U2011 ( .A0(\bank_reg[8][11] ), .A1(n1805), .B0(n1397), .B1(
        PWDATA[15]), .Y(n1198) );
  AO22X1 U2012 ( .A0(\bank_reg[8][10] ), .A1(n1805), .B0(n1397), .B1(
        PWDATA[14]), .Y(n1199) );
  AO22X1 U2013 ( .A0(\bank_reg[8][9] ), .A1(n1805), .B0(n1397), .B1(PWDATA[13]), .Y(n1200) );
  AO22X1 U2014 ( .A0(\bank_reg[8][8] ), .A1(n1805), .B0(n1397), .B1(PWDATA[12]), .Y(n1201) );
  AO22X1 U2015 ( .A0(\bank_reg[8][7] ), .A1(n1805), .B0(n1397), .B1(PWDATA[11]), .Y(n1202) );
  AO22X1 U2016 ( .A0(\bank_reg[8][6] ), .A1(n1805), .B0(n1397), .B1(PWDATA[10]), .Y(n1203) );
  AO22X1 U2017 ( .A0(\bank_reg[8][5] ), .A1(n1805), .B0(n1397), .B1(PWDATA[9]), 
        .Y(n1204) );
  AO22X1 U2018 ( .A0(\bank_reg[8][4] ), .A1(n1805), .B0(n1397), .B1(PWDATA[8]), 
        .Y(n1205) );
  AO22X1 U2019 ( .A0(\bank_reg[8][3] ), .A1(n1805), .B0(n1397), .B1(PWDATA[7]), 
        .Y(n1206) );
  AO22X1 U2020 ( .A0(\bank_reg[8][2] ), .A1(n1805), .B0(n1397), .B1(PWDATA[6]), 
        .Y(n1207) );
  AO22X1 U2021 ( .A0(\bank_reg[8][1] ), .A1(n1805), .B0(n1397), .B1(PWDATA[5]), 
        .Y(n1208) );
  AO22X1 U2022 ( .A0(\bank_reg[8][0] ), .A1(n1805), .B0(n1397), .B1(PWDATA[4]), 
        .Y(n1209) );
  AO22X1 U2023 ( .A0(\bank_reg[7][15] ), .A1(n1806), .B0(n1390), .B1(
        PWDATA[19]), .Y(n1210) );
  AO22X1 U2024 ( .A0(\bank_reg[7][14] ), .A1(n1806), .B0(n1390), .B1(
        PWDATA[18]), .Y(n1211) );
  AO22X1 U2025 ( .A0(\bank_reg[7][13] ), .A1(n1806), .B0(n1390), .B1(
        PWDATA[17]), .Y(n1212) );
  AO22X1 U2026 ( .A0(\bank_reg[7][12] ), .A1(n1806), .B0(n1390), .B1(
        PWDATA[16]), .Y(n1213) );
  AO22X1 U2027 ( .A0(\bank_reg[7][11] ), .A1(n1806), .B0(n1390), .B1(
        PWDATA[15]), .Y(n1214) );
  AO22X1 U2028 ( .A0(\bank_reg[7][10] ), .A1(n1806), .B0(n1390), .B1(
        PWDATA[14]), .Y(n1215) );
  AO22X1 U2029 ( .A0(\bank_reg[7][9] ), .A1(n1806), .B0(n1390), .B1(PWDATA[13]), .Y(n1216) );
  AO22X1 U2030 ( .A0(\bank_reg[7][8] ), .A1(n1806), .B0(n1390), .B1(PWDATA[12]), .Y(n1217) );
  AO22X1 U2031 ( .A0(\bank_reg[7][7] ), .A1(n1806), .B0(n1390), .B1(PWDATA[11]), .Y(n1218) );
  AO22X1 U2032 ( .A0(\bank_reg[7][6] ), .A1(n1806), .B0(n1390), .B1(PWDATA[10]), .Y(n1219) );
  AO22X1 U2033 ( .A0(\bank_reg[7][5] ), .A1(n1806), .B0(n1390), .B1(PWDATA[9]), 
        .Y(n1220) );
  AO22X1 U2034 ( .A0(\bank_reg[7][4] ), .A1(n1806), .B0(n1390), .B1(PWDATA[8]), 
        .Y(n1221) );
  AO22X1 U2035 ( .A0(\bank_reg[7][3] ), .A1(n1806), .B0(n1390), .B1(PWDATA[7]), 
        .Y(n1222) );
  AO22X1 U2036 ( .A0(\bank_reg[7][2] ), .A1(n1806), .B0(n1390), .B1(PWDATA[6]), 
        .Y(n1223) );
  AO22X1 U2037 ( .A0(\bank_reg[7][1] ), .A1(n1806), .B0(n1390), .B1(PWDATA[5]), 
        .Y(n1224) );
  AO22X1 U2038 ( .A0(\bank_reg[7][0] ), .A1(n1806), .B0(n1390), .B1(PWDATA[4]), 
        .Y(n1225) );
  AO22X1 U2039 ( .A0(\bank_reg[6][15] ), .A1(n1807), .B0(n1385), .B1(
        PWDATA[19]), .Y(n1226) );
  AO22X1 U2040 ( .A0(\bank_reg[6][14] ), .A1(n1807), .B0(n1385), .B1(
        PWDATA[18]), .Y(n1227) );
  AO22X1 U2041 ( .A0(\bank_reg[6][13] ), .A1(n1807), .B0(n1385), .B1(
        PWDATA[17]), .Y(n1228) );
  AO22X1 U2042 ( .A0(\bank_reg[6][12] ), .A1(n1807), .B0(n1385), .B1(
        PWDATA[16]), .Y(n1229) );
  AO22X1 U2043 ( .A0(\bank_reg[6][11] ), .A1(n1807), .B0(n1385), .B1(
        PWDATA[15]), .Y(n1230) );
  AO22X1 U2044 ( .A0(\bank_reg[6][10] ), .A1(n1807), .B0(n1385), .B1(
        PWDATA[14]), .Y(n1231) );
  AO22X1 U2045 ( .A0(\bank_reg[6][9] ), .A1(n1807), .B0(n1385), .B1(PWDATA[13]), .Y(n1232) );
  AO22X1 U2046 ( .A0(\bank_reg[6][8] ), .A1(n1807), .B0(n1385), .B1(PWDATA[12]), .Y(n1233) );
  AO22X1 U2047 ( .A0(\bank_reg[6][7] ), .A1(n1807), .B0(n1385), .B1(PWDATA[11]), .Y(n1234) );
  AO22X1 U2048 ( .A0(\bank_reg[6][6] ), .A1(n1807), .B0(n1385), .B1(PWDATA[10]), .Y(n1235) );
  AO22X1 U2049 ( .A0(\bank_reg[6][5] ), .A1(n1807), .B0(n1385), .B1(PWDATA[9]), 
        .Y(n1236) );
  AO22X1 U2050 ( .A0(\bank_reg[6][4] ), .A1(n1807), .B0(n1385), .B1(PWDATA[8]), 
        .Y(n1237) );
  AO22X1 U2051 ( .A0(\bank_reg[6][3] ), .A1(n1807), .B0(n1385), .B1(PWDATA[7]), 
        .Y(n1238) );
  AO22X1 U2052 ( .A0(\bank_reg[6][2] ), .A1(n1807), .B0(n1385), .B1(PWDATA[6]), 
        .Y(n1239) );
  AO22X1 U2053 ( .A0(\bank_reg[6][1] ), .A1(n1807), .B0(n1385), .B1(PWDATA[5]), 
        .Y(n1240) );
  AO22X1 U2054 ( .A0(\bank_reg[6][0] ), .A1(n1807), .B0(n1385), .B1(PWDATA[4]), 
        .Y(n1241) );
  AO22X1 U2055 ( .A0(\bank_reg[5][15] ), .A1(n1808), .B0(n1383), .B1(
        PWDATA[19]), .Y(n1242) );
  AO22X1 U2056 ( .A0(\bank_reg[5][14] ), .A1(n1808), .B0(n1383), .B1(
        PWDATA[18]), .Y(n1243) );
  AO22X1 U2057 ( .A0(\bank_reg[5][13] ), .A1(n1808), .B0(n1383), .B1(
        PWDATA[17]), .Y(n1244) );
  AO22X1 U2058 ( .A0(\bank_reg[5][12] ), .A1(n1808), .B0(n1383), .B1(
        PWDATA[16]), .Y(n1245) );
  AO22X1 U2059 ( .A0(\bank_reg[5][11] ), .A1(n1808), .B0(n1383), .B1(
        PWDATA[15]), .Y(n1246) );
  AO22X1 U2060 ( .A0(\bank_reg[5][10] ), .A1(n1808), .B0(n1383), .B1(
        PWDATA[14]), .Y(n1247) );
  AO22X1 U2061 ( .A0(\bank_reg[5][9] ), .A1(n1808), .B0(n1383), .B1(PWDATA[13]), .Y(n1248) );
  AO22X1 U2062 ( .A0(\bank_reg[5][8] ), .A1(n1808), .B0(n1383), .B1(PWDATA[12]), .Y(n1249) );
  AO22X1 U2063 ( .A0(\bank_reg[5][7] ), .A1(n1808), .B0(n1383), .B1(PWDATA[11]), .Y(n1250) );
  AO22X1 U2064 ( .A0(\bank_reg[5][6] ), .A1(n1808), .B0(n1383), .B1(PWDATA[10]), .Y(n1251) );
  AO22X1 U2065 ( .A0(\bank_reg[5][5] ), .A1(n1808), .B0(n1383), .B1(PWDATA[9]), 
        .Y(n1252) );
  AO22X1 U2066 ( .A0(\bank_reg[5][4] ), .A1(n1808), .B0(n1383), .B1(PWDATA[8]), 
        .Y(n1253) );
  AO22X1 U2067 ( .A0(\bank_reg[5][3] ), .A1(n1808), .B0(n1383), .B1(PWDATA[7]), 
        .Y(n1254) );
  AO22X1 U2068 ( .A0(\bank_reg[5][2] ), .A1(n1808), .B0(n1383), .B1(PWDATA[6]), 
        .Y(n1255) );
  AO22X1 U2069 ( .A0(\bank_reg[5][1] ), .A1(n1808), .B0(n1383), .B1(PWDATA[5]), 
        .Y(n1256) );
  AO22X1 U2070 ( .A0(\bank_reg[5][0] ), .A1(n1808), .B0(n1383), .B1(PWDATA[4]), 
        .Y(n1257) );
  AO22X1 U2071 ( .A0(\bank_reg[4][15] ), .A1(n1809), .B0(n1380), .B1(
        PWDATA[19]), .Y(n1258) );
  AO22X1 U2072 ( .A0(\bank_reg[4][14] ), .A1(n1809), .B0(n1380), .B1(
        PWDATA[18]), .Y(n1259) );
  AO22X1 U2073 ( .A0(\bank_reg[4][13] ), .A1(n1809), .B0(n1380), .B1(
        PWDATA[17]), .Y(n1260) );
  AO22X1 U2074 ( .A0(\bank_reg[4][12] ), .A1(n1809), .B0(n1380), .B1(
        PWDATA[16]), .Y(n1261) );
  AO22X1 U2075 ( .A0(\bank_reg[4][11] ), .A1(n1809), .B0(n1380), .B1(
        PWDATA[15]), .Y(n1262) );
  AO22X1 U2076 ( .A0(\bank_reg[4][10] ), .A1(n1809), .B0(n1380), .B1(
        PWDATA[14]), .Y(n1263) );
  AO22X1 U2077 ( .A0(\bank_reg[4][9] ), .A1(n1809), .B0(n1380), .B1(PWDATA[13]), .Y(n1264) );
  AO22X1 U2078 ( .A0(\bank_reg[4][8] ), .A1(n1809), .B0(n1380), .B1(PWDATA[12]), .Y(n1265) );
  AO22X1 U2079 ( .A0(\bank_reg[4][7] ), .A1(n1809), .B0(n1380), .B1(PWDATA[11]), .Y(n1266) );
  AO22X1 U2080 ( .A0(\bank_reg[4][6] ), .A1(n1809), .B0(n1380), .B1(PWDATA[10]), .Y(n1267) );
  AO22X1 U2081 ( .A0(\bank_reg[4][5] ), .A1(n1809), .B0(n1380), .B1(PWDATA[9]), 
        .Y(n1268) );
  AO22X1 U2082 ( .A0(\bank_reg[4][4] ), .A1(n1809), .B0(n1380), .B1(PWDATA[8]), 
        .Y(n1269) );
  AO22X1 U2083 ( .A0(\bank_reg[4][3] ), .A1(n1809), .B0(n1380), .B1(PWDATA[7]), 
        .Y(n1270) );
  AO22X1 U2084 ( .A0(\bank_reg[4][2] ), .A1(n1809), .B0(n1380), .B1(PWDATA[6]), 
        .Y(n1271) );
  AO22X1 U2085 ( .A0(\bank_reg[4][1] ), .A1(n1809), .B0(n1380), .B1(PWDATA[5]), 
        .Y(n1272) );
  AO22X1 U2086 ( .A0(\bank_reg[4][0] ), .A1(n1809), .B0(n1380), .B1(PWDATA[4]), 
        .Y(n1273) );
  AO22X1 U2087 ( .A0(\bank_reg[3][15] ), .A1(n1810), .B0(n1378), .B1(
        PWDATA[19]), .Y(n1274) );
  AO22X1 U2088 ( .A0(\bank_reg[3][14] ), .A1(n1810), .B0(n1378), .B1(
        PWDATA[18]), .Y(n1275) );
  AO22X1 U2089 ( .A0(\bank_reg[3][13] ), .A1(n1810), .B0(n1378), .B1(
        PWDATA[17]), .Y(n1276) );
  AO22X1 U2090 ( .A0(\bank_reg[3][12] ), .A1(n1810), .B0(n1378), .B1(
        PWDATA[16]), .Y(n1277) );
  AO22X1 U2091 ( .A0(\bank_reg[3][11] ), .A1(n1810), .B0(n1378), .B1(
        PWDATA[15]), .Y(n1278) );
  AO22X1 U2092 ( .A0(\bank_reg[3][10] ), .A1(n1810), .B0(n1378), .B1(
        PWDATA[14]), .Y(n1279) );
  AO22X1 U2093 ( .A0(\bank_reg[3][9] ), .A1(n1810), .B0(n1378), .B1(PWDATA[13]), .Y(n1280) );
  AO22X1 U2094 ( .A0(\bank_reg[3][8] ), .A1(n1810), .B0(n1378), .B1(PWDATA[12]), .Y(n1281) );
  AO22X1 U2095 ( .A0(\bank_reg[3][7] ), .A1(n1810), .B0(n1378), .B1(PWDATA[11]), .Y(n1282) );
  AO22X1 U2096 ( .A0(\bank_reg[3][6] ), .A1(n1810), .B0(n1378), .B1(PWDATA[10]), .Y(n1283) );
  AO22X1 U2097 ( .A0(\bank_reg[3][5] ), .A1(n1810), .B0(n1378), .B1(PWDATA[9]), 
        .Y(n1284) );
  AO22X1 U2098 ( .A0(\bank_reg[3][4] ), .A1(n1810), .B0(n1378), .B1(PWDATA[8]), 
        .Y(n1285) );
  AO22X1 U2099 ( .A0(\bank_reg[3][3] ), .A1(n1810), .B0(n1378), .B1(PWDATA[7]), 
        .Y(n1286) );
  AO22X1 U2100 ( .A0(\bank_reg[3][2] ), .A1(n1810), .B0(n1378), .B1(PWDATA[6]), 
        .Y(n1287) );
  AO22X1 U2101 ( .A0(\bank_reg[3][1] ), .A1(n1810), .B0(n1378), .B1(PWDATA[5]), 
        .Y(n1288) );
  AO22X1 U2102 ( .A0(\bank_reg[3][0] ), .A1(n1810), .B0(n1378), .B1(PWDATA[4]), 
        .Y(n1289) );
  AO22X1 U2103 ( .A0(\bank_reg[2][15] ), .A1(n1811), .B0(n1375), .B1(
        PWDATA[19]), .Y(n1290) );
  AO22X1 U2104 ( .A0(\bank_reg[2][14] ), .A1(n1811), .B0(n1375), .B1(
        PWDATA[18]), .Y(n1291) );
  AO22X1 U2105 ( .A0(\bank_reg[2][13] ), .A1(n1811), .B0(n1375), .B1(
        PWDATA[17]), .Y(n1292) );
  AO22X1 U2106 ( .A0(\bank_reg[2][12] ), .A1(n1811), .B0(n1375), .B1(
        PWDATA[16]), .Y(n1293) );
  AO22X1 U2107 ( .A0(\bank_reg[2][11] ), .A1(n1811), .B0(n1375), .B1(
        PWDATA[15]), .Y(n1294) );
  AO22X1 U2108 ( .A0(\bank_reg[2][10] ), .A1(n1811), .B0(n1375), .B1(
        PWDATA[14]), .Y(n1295) );
  AO22X1 U2109 ( .A0(\bank_reg[2][9] ), .A1(n1811), .B0(n1375), .B1(PWDATA[13]), .Y(n1296) );
  AO22X1 U2110 ( .A0(\bank_reg[2][8] ), .A1(n1811), .B0(n1375), .B1(PWDATA[12]), .Y(n1297) );
  AO22X1 U2111 ( .A0(\bank_reg[2][7] ), .A1(n1811), .B0(n1375), .B1(PWDATA[11]), .Y(n1298) );
  AO22X1 U2112 ( .A0(\bank_reg[2][6] ), .A1(n1811), .B0(n1375), .B1(PWDATA[10]), .Y(n1299) );
  AO22X1 U2113 ( .A0(\bank_reg[2][5] ), .A1(n1811), .B0(n1375), .B1(PWDATA[9]), 
        .Y(n1300) );
  AO22X1 U2114 ( .A0(\bank_reg[2][4] ), .A1(n1811), .B0(n1375), .B1(PWDATA[8]), 
        .Y(n1301) );
  AO22X1 U2115 ( .A0(\bank_reg[2][3] ), .A1(n1811), .B0(n1375), .B1(PWDATA[7]), 
        .Y(n1302) );
  AO22X1 U2116 ( .A0(\bank_reg[2][2] ), .A1(n1811), .B0(n1375), .B1(PWDATA[6]), 
        .Y(n1303) );
  AO22X1 U2117 ( .A0(\bank_reg[2][1] ), .A1(n1811), .B0(n1375), .B1(PWDATA[5]), 
        .Y(n1304) );
  AO22X1 U2118 ( .A0(\bank_reg[2][0] ), .A1(n1811), .B0(n1375), .B1(PWDATA[4]), 
        .Y(n1305) );
  AO22X1 U2119 ( .A0(\bank_reg[1][15] ), .A1(n1812), .B0(n1372), .B1(
        PWDATA[19]), .Y(n1306) );
  AO22X1 U2120 ( .A0(\bank_reg[1][14] ), .A1(n1812), .B0(n1372), .B1(
        PWDATA[18]), .Y(n1307) );
  AO22X1 U2121 ( .A0(\bank_reg[1][13] ), .A1(n1812), .B0(n1372), .B1(
        PWDATA[17]), .Y(n1308) );
  AO22X1 U2122 ( .A0(\bank_reg[1][12] ), .A1(n1812), .B0(n1372), .B1(
        PWDATA[16]), .Y(n1309) );
  AO22X1 U2123 ( .A0(\bank_reg[1][11] ), .A1(n1812), .B0(n1372), .B1(
        PWDATA[15]), .Y(n1310) );
  AO22X1 U2124 ( .A0(\bank_reg[1][10] ), .A1(n1812), .B0(n1372), .B1(
        PWDATA[14]), .Y(n1311) );
  AO22X1 U2125 ( .A0(\bank_reg[1][9] ), .A1(n1812), .B0(n1372), .B1(PWDATA[13]), .Y(n1312) );
  AO22X1 U2126 ( .A0(\bank_reg[1][8] ), .A1(n1812), .B0(n1372), .B1(PWDATA[12]), .Y(n1313) );
  AO22X1 U2127 ( .A0(\bank_reg[1][7] ), .A1(n1812), .B0(n1372), .B1(PWDATA[11]), .Y(n1314) );
  AO22X1 U2128 ( .A0(\bank_reg[1][6] ), .A1(n1812), .B0(n1372), .B1(PWDATA[10]), .Y(n1315) );
  AO22X1 U2129 ( .A0(\bank_reg[1][5] ), .A1(n1812), .B0(n1372), .B1(PWDATA[9]), 
        .Y(n1316) );
  AO22X1 U2130 ( .A0(\bank_reg[1][4] ), .A1(n1812), .B0(n1372), .B1(PWDATA[8]), 
        .Y(n1317) );
  AO22X1 U2131 ( .A0(\bank_reg[1][3] ), .A1(n1812), .B0(n1372), .B1(PWDATA[7]), 
        .Y(n1318) );
  AO22X1 U2132 ( .A0(\bank_reg[1][2] ), .A1(n1812), .B0(n1372), .B1(PWDATA[6]), 
        .Y(n1319) );
  AO22X1 U2133 ( .A0(\bank_reg[1][1] ), .A1(n1812), .B0(n1372), .B1(PWDATA[5]), 
        .Y(n1320) );
  AO22X1 U2134 ( .A0(\bank_reg[1][0] ), .A1(n1812), .B0(n1372), .B1(PWDATA[4]), 
        .Y(n1321) );
  INVX1 U2135 ( .A(n1387), .Y(n1370) );
  NAND2BX1 U2136 ( .AN(PADDR[2]), .B(n1388), .Y(n1387) );
  INVX1 U2137 ( .A(PWRITE), .Y(n1573) );
  NAND3BX1 U2138 ( .AN(n1457), .B(n1458), .C(n1459), .Y(PRDATA[4]) );
  OAI221X1 U2139 ( .A0(n1692), .A1(n1409), .B0(n1769), .B1(n1411), .C0(n1464), 
        .Y(n1457) );
  AOI222X1 U2140 ( .A0(n1405), .A1(\bank_reg[3][0] ), .B0(n1406), .B1(
        \bank_reg[6][0] ), .C0(n1407), .C1(\bank_reg[1][0] ), .Y(n1458) );
  OA22X1 U2141 ( .A0(n1721), .A1(n1402), .B0(n1785), .B1(n1404), .Y(n1459) );
  NAND3BX1 U2142 ( .AN(n1447), .B(n1448), .C(n1449), .Y(PRDATA[5]) );
  OAI221X1 U2143 ( .A0(n1693), .A1(n1409), .B0(n1770), .B1(n1411), .C0(n1454), 
        .Y(n1447) );
  AOI222X1 U2144 ( .A0(n1405), .A1(\bank_reg[3][1] ), .B0(n1406), .B1(
        \bank_reg[6][1] ), .C0(n1407), .C1(\bank_reg[1][1] ), .Y(n1448) );
  OA22X1 U2145 ( .A0(n1722), .A1(n1402), .B0(n1786), .B1(n1404), .Y(n1449) );
  NAND3BX1 U2146 ( .AN(n1437), .B(n1438), .C(n1439), .Y(PRDATA[6]) );
  OAI221X1 U2147 ( .A0(n1694), .A1(n1409), .B0(n1771), .B1(n1411), .C0(n1444), 
        .Y(n1437) );
  AOI222X1 U2148 ( .A0(n1405), .A1(\bank_reg[3][2] ), .B0(n1406), .B1(
        \bank_reg[6][2] ), .C0(n1407), .C1(\bank_reg[1][2] ), .Y(n1438) );
  OA22X1 U2149 ( .A0(n1723), .A1(n1402), .B0(n1787), .B1(n1404), .Y(n1439) );
  NAND3BX1 U2150 ( .AN(n1427), .B(n1428), .C(n1429), .Y(PRDATA[7]) );
  OAI221X1 U2151 ( .A0(n1695), .A1(n1409), .B0(n1772), .B1(n1411), .C0(n1434), 
        .Y(n1427) );
  AOI222X1 U2152 ( .A0(n1405), .A1(\bank_reg[3][3] ), .B0(n1406), .B1(
        \bank_reg[6][3] ), .C0(n1407), .C1(\bank_reg[1][3] ), .Y(n1428) );
  OA22X1 U2153 ( .A0(n1724), .A1(n1402), .B0(n1788), .B1(n1404), .Y(n1429) );
  NAND3BX1 U2154 ( .AN(n1417), .B(n1418), .C(n1419), .Y(PRDATA[8]) );
  OAI221X1 U2155 ( .A0(n1696), .A1(n1409), .B0(n1773), .B1(n1411), .C0(n1424), 
        .Y(n1417) );
  AOI222X1 U2156 ( .A0(n1405), .A1(\bank_reg[3][4] ), .B0(n1406), .B1(
        \bank_reg[6][4] ), .C0(n1407), .C1(\bank_reg[1][4] ), .Y(n1418) );
  OA22X1 U2157 ( .A0(n1725), .A1(n1402), .B0(n1789), .B1(n1404), .Y(n1419) );
  NAND3BX1 U2158 ( .AN(n1398), .B(n1399), .C(n1400), .Y(PRDATA[9]) );
  OAI221X1 U2159 ( .A0(n1698), .A1(n1409), .B0(n1774), .B1(n1411), .C0(n1412), 
        .Y(n1398) );
  AOI222X1 U2160 ( .A0(n1405), .A1(\bank_reg[3][5] ), .B0(n1406), .B1(
        \bank_reg[6][5] ), .C0(n1407), .C1(\bank_reg[1][5] ), .Y(n1399) );
  OA22X1 U2161 ( .A0(n1726), .A1(n1402), .B0(n1790), .B1(n1404), .Y(n1400) );
  NAND3BX1 U2162 ( .AN(n1557), .B(n1558), .C(n1559), .Y(PRDATA[10]) );
  OAI221X1 U2163 ( .A0(n1701), .A1(n1409), .B0(n1775), .B1(n1411), .C0(n1570), 
        .Y(n1557) );
  AOI222X1 U2164 ( .A0(n1405), .A1(\bank_reg[3][6] ), .B0(n1406), .B1(
        \bank_reg[6][6] ), .C0(n1407), .C1(\bank_reg[1][6] ), .Y(n1558) );
  OA22X1 U2165 ( .A0(n1727), .A1(n1402), .B0(n1791), .B1(n1404), .Y(n1559) );
  NAND3BX1 U2166 ( .AN(n1547), .B(n1548), .C(n1549), .Y(PRDATA[11]) );
  OAI221X1 U2167 ( .A0(n1702), .A1(n1409), .B0(n1776), .B1(n1411), .C0(n1554), 
        .Y(n1547) );
  AOI222X1 U2168 ( .A0(n1405), .A1(\bank_reg[3][7] ), .B0(n1406), .B1(
        \bank_reg[6][7] ), .C0(n1407), .C1(\bank_reg[1][7] ), .Y(n1548) );
  OA22X1 U2169 ( .A0(n1728), .A1(n1402), .B0(n1792), .B1(n1404), .Y(n1549) );
  NAND3BX1 U2170 ( .AN(n1537), .B(n1538), .C(n1539), .Y(PRDATA[12]) );
  OAI221X1 U2171 ( .A0(n1703), .A1(n1409), .B0(n1777), .B1(n1411), .C0(n1544), 
        .Y(n1537) );
  AOI222X1 U2172 ( .A0(n1405), .A1(\bank_reg[3][8] ), .B0(n1406), .B1(
        \bank_reg[6][8] ), .C0(n1407), .C1(\bank_reg[1][8] ), .Y(n1538) );
  OA22X1 U2173 ( .A0(n1729), .A1(n1402), .B0(n1793), .B1(n1404), .Y(n1539) );
  NAND3BX1 U2174 ( .AN(n1527), .B(n1528), .C(n1529), .Y(PRDATA[13]) );
  OAI221X1 U2175 ( .A0(n1704), .A1(n1409), .B0(n1778), .B1(n1411), .C0(n1534), 
        .Y(n1527) );
  AOI222X1 U2176 ( .A0(n1405), .A1(\bank_reg[3][9] ), .B0(n1406), .B1(
        \bank_reg[6][9] ), .C0(n1407), .C1(\bank_reg[1][9] ), .Y(n1528) );
  OA22X1 U2177 ( .A0(n1730), .A1(n1402), .B0(n1794), .B1(n1404), .Y(n1529) );
  NAND3BX1 U2178 ( .AN(n1517), .B(n1518), .C(n1519), .Y(PRDATA[14]) );
  OAI221X1 U2179 ( .A0(n1697), .A1(n1409), .B0(n1779), .B1(n1411), .C0(n1524), 
        .Y(n1517) );
  AOI222X1 U2180 ( .A0(n1405), .A1(\bank_reg[3][10] ), .B0(n1406), .B1(
        \bank_reg[6][10] ), .C0(n1407), .C1(\bank_reg[1][10] ), .Y(n1518) );
  OA22X1 U2181 ( .A0(n1731), .A1(n1402), .B0(n1795), .B1(n1404), .Y(n1519) );
  NAND3BX1 U2182 ( .AN(n1507), .B(n1508), .C(n1509), .Y(PRDATA[15]) );
  OAI221X1 U2183 ( .A0(n1699), .A1(n1409), .B0(n1780), .B1(n1411), .C0(n1514), 
        .Y(n1507) );
  AOI222X1 U2184 ( .A0(n1405), .A1(\bank_reg[3][11] ), .B0(n1406), .B1(
        \bank_reg[6][11] ), .C0(n1407), .C1(\bank_reg[1][11] ), .Y(n1508) );
  OA22X1 U2185 ( .A0(n1732), .A1(n1402), .B0(n1796), .B1(n1404), .Y(n1509) );
  NAND3BX1 U2186 ( .AN(n1497), .B(n1498), .C(n1499), .Y(PRDATA[16]) );
  OAI221X1 U2187 ( .A0(n1700), .A1(n1409), .B0(n1781), .B1(n1411), .C0(n1504), 
        .Y(n1497) );
  AOI222X1 U2188 ( .A0(n1405), .A1(\bank_reg[3][12] ), .B0(n1406), .B1(
        \bank_reg[6][12] ), .C0(n1407), .C1(\bank_reg[1][12] ), .Y(n1498) );
  OA22X1 U2189 ( .A0(n1733), .A1(n1402), .B0(n1797), .B1(n1404), .Y(n1499) );
  NAND3BX1 U2190 ( .AN(n1487), .B(n1488), .C(n1489), .Y(PRDATA[17]) );
  OAI221X1 U2191 ( .A0(n1689), .A1(n1409), .B0(n1782), .B1(n1411), .C0(n1494), 
        .Y(n1487) );
  AOI222X1 U2192 ( .A0(n1405), .A1(\bank_reg[3][13] ), .B0(n1406), .B1(
        \bank_reg[6][13] ), .C0(n1407), .C1(\bank_reg[1][13] ), .Y(n1488) );
  OA22X1 U2193 ( .A0(n1734), .A1(n1402), .B0(n1798), .B1(n1404), .Y(n1489) );
  NAND3BX1 U2194 ( .AN(n1477), .B(n1478), .C(n1479), .Y(PRDATA[18]) );
  OAI221X1 U2195 ( .A0(n1691), .A1(n1409), .B0(n1783), .B1(n1411), .C0(n1484), 
        .Y(n1477) );
  AOI222X1 U2196 ( .A0(n1405), .A1(\bank_reg[3][14] ), .B0(n1406), .B1(
        \bank_reg[6][14] ), .C0(n1407), .C1(\bank_reg[1][14] ), .Y(n1478) );
  OA22X1 U2197 ( .A0(n1735), .A1(n1402), .B0(n1799), .B1(n1404), .Y(n1479) );
  NAND3BX1 U2198 ( .AN(n1467), .B(n1468), .C(n1469), .Y(PRDATA[19]) );
  OAI221X1 U2199 ( .A0(n1690), .A1(n1409), .B0(n1784), .B1(n1411), .C0(n1474), 
        .Y(n1467) );
  AOI222X1 U2200 ( .A0(n1405), .A1(\bank_reg[3][15] ), .B0(n1406), .B1(
        \bank_reg[6][15] ), .C0(n1407), .C1(\bank_reg[1][15] ), .Y(n1468) );
  OA22X1 U2201 ( .A0(n1736), .A1(n1402), .B0(n1800), .B1(n1404), .Y(n1469) );
  BUFX2 U2202 ( .A(n1414), .Y(n1804) );
  NAND3BX1 U2203 ( .AN(n1394), .B(n1573), .C(PADDR[5]), .Y(n1414) );
  INVX1 U2204 ( .A(n1577), .Y(n1562) );
  NAND2BX1 U2205 ( .AN(PADDR[2]), .B(n1575), .Y(n1577) );
  DFFSX1 bank_reg_reg ( .D(n1210), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][15] ), .QN(n1784) );
  DFFSX1 bank_reg_reg0 ( .D(n1211), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][14] ), .QN(n1783) );
  DFFSX1 bank_reg_reg1 ( .D(n1212), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][13] ), .QN(n1782) );
  DFFSX1 bank_reg_reg2 ( .D(n1290), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][15] ), .QN(n1736) );
  DFFSX1 bank_reg_reg3 ( .D(n1291), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][14] ), .QN(n1735) );
  DFFSX1 bank_reg_reg4 ( .D(n1292), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][13] ), .QN(n1734) );
  DFFSX1 bank_reg_reg5 ( .D(n1226), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][15] ), .QN(n1738) );
  DFFSX1 bank_reg_reg6 ( .D(n1227), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][14] ), .QN(n1739) );
  DFFSX1 bank_reg_reg7 ( .D(n1228), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][13] ), .QN(n1737) );
  DFFSX1 bank_reg_reg8 ( .D(n1322), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][15] ), .QN(n1800) );
  DFFSX1 bank_reg_reg9 ( .D(n1323), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][14] ), .QN(n1799) );
  DFFSX1 bank_reg_reg10 ( .D(n1324), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][13] ), .QN(n1798) );
  DFFSX1 bank_reg_reg11 ( .D(n1194), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][15] ), .QN(n1742) );
  DFFSX1 bank_reg_reg12 ( .D(n1195), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][14] ), .QN(n1741) );
  DFFSX1 bank_reg_reg13 ( .D(n1196), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][13] ), .QN(n1740) );
  DFFSX1 bank_reg_reg14 ( .D(n1242), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][15] ), .QN(n1706) );
  DFFSX1 bank_reg_reg15 ( .D(n1243), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][14] ), .QN(n1707) );
  DFFSX1 bank_reg_reg16 ( .D(n1244), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][13] ), .QN(n1705) );
  DFFSX1 bank_reg_reg17 ( .D(n1258), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][15] ), .QN(n1690) );
  DFFSX1 bank_reg_reg18 ( .D(n1259), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][14] ), .QN(n1691) );
  DFFSX1 bank_reg_reg19 ( .D(n1260), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][13] ), .QN(n1689) );
  DFFSX1 bank_reg_reg20 ( .D(n1306), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][15] ) );
  DFFSX1 bank_reg_reg21 ( .D(n1307), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][14] ) );
  DFFSX1 bank_reg_reg22 ( .D(n1308), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][13] ) );
  DFFSX1 bank_reg_reg23 ( .D(n1274), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][15] ) );
  DFFSX1 bank_reg_reg24 ( .D(n1275), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][14] ) );
  DFFSX1 bank_reg_reg25 ( .D(n1276), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][13] ) );
  DFFSX1 bank_reg_reg26 ( .D(n1300), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][5] ), .QN(n1726) );
  DFFSX1 bank_reg_reg27 ( .D(n1301), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][4] ), .QN(n1725) );
  DFFSX1 bank_reg_reg28 ( .D(n1302), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][3] ), .QN(n1724) );
  DFFSX1 bank_reg_reg29 ( .D(n1303), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][2] ), .QN(n1723) );
  DFFSX1 bank_reg_reg30 ( .D(n1304), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][1] ), .QN(n1722) );
  DFFSX1 bank_reg_reg31 ( .D(n1305), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][0] ), .QN(n1721) );
  DFFSX1 bank_reg_reg32 ( .D(n1220), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][5] ), .QN(n1774) );
  DFFSX1 bank_reg_reg33 ( .D(n1221), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][4] ), .QN(n1773) );
  DFFSX1 bank_reg_reg34 ( .D(n1222), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][3] ), .QN(n1772) );
  DFFSX1 bank_reg_reg35 ( .D(n1223), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][2] ), .QN(n1771) );
  DFFSX1 bank_reg_reg36 ( .D(n1224), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][1] ), .QN(n1770) );
  DFFSX1 bank_reg_reg37 ( .D(n1225), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][0] ), .QN(n1769) );
  DFFSX1 bank_reg_reg38 ( .D(n1229), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][12] ), .QN(n1759) );
  DFFSX1 bank_reg_reg39 ( .D(n1230), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][11] ), .QN(n1760) );
  DFFSX1 bank_reg_reg40 ( .D(n1231), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][10] ), .QN(n1746) );
  DFFSX1 bank_reg_reg41 ( .D(n1236), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][5] ), .QN(n1758) );
  DFFSX1 bank_reg_reg42 ( .D(n1237), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][4] ), .QN(n1748) );
  DFFSX1 bank_reg_reg43 ( .D(n1238), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][3] ), .QN(n1745) );
  DFFSX1 bank_reg_reg44 ( .D(n1239), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][2] ), .QN(n1744) );
  DFFSX1 bank_reg_reg45 ( .D(n1240), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][1] ), .QN(n1747) );
  DFFSX1 bank_reg_reg46 ( .D(n1241), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][0] ), .QN(n1743) );
  DFFSX1 bank_reg_reg47 ( .D(n1326), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][11] ), .QN(n1796) );
  DFFSX1 bank_reg_reg48 ( .D(n1327), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][10] ), .QN(n1795) );
  DFFSX1 bank_reg_reg49 ( .D(n1332), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][5] ), .QN(n1790) );
  DFFSX1 bank_reg_reg50 ( .D(n1333), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][4] ), .QN(n1789) );
  DFFSX1 bank_reg_reg51 ( .D(n1334), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][3] ), .QN(n1788) );
  DFFSX1 bank_reg_reg52 ( .D(n1335), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][2] ), .QN(n1787) );
  DFFSX1 bank_reg_reg53 ( .D(n1336), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][1] ), .QN(n1786) );
  DFFSX1 bank_reg_reg54 ( .D(n1337), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][0] ), .QN(n1785) );
  DFFSX1 bank_reg_reg55 ( .D(n1208), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][1] ), .QN(n1756) );
  DFFSX1 bank_reg_reg56 ( .D(n1209), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][0] ), .QN(n1749) );
  DFFSX1 bank_reg_reg57 ( .D(n1245), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][12] ), .QN(n1714) );
  DFFSX1 bank_reg_reg58 ( .D(n1246), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][11] ), .QN(n1716) );
  DFFSX1 bank_reg_reg59 ( .D(n1247), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][10] ), .QN(n1715) );
  DFFSX1 bank_reg_reg60 ( .D(n1252), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][5] ), .QN(n1713) );
  DFFSX1 bank_reg_reg61 ( .D(n1253), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][4] ), .QN(n1712) );
  DFFSX1 bank_reg_reg62 ( .D(n1254), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][3] ), .QN(n1710) );
  DFFSX1 bank_reg_reg63 ( .D(n1255), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][2] ), .QN(n1709) );
  DFFSX1 bank_reg_reg64 ( .D(n1256), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][1] ), .QN(n1711) );
  DFFSX1 bank_reg_reg65 ( .D(n1257), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][0] ), .QN(n1708) );
  DFFSX1 bank_reg_reg66 ( .D(n1261), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][12] ), .QN(n1700) );
  DFFSX1 bank_reg_reg67 ( .D(n1262), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][11] ), .QN(n1699) );
  DFFSX1 bank_reg_reg68 ( .D(n1263), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][10] ), .QN(n1697) );
  DFFSX1 bank_reg_reg69 ( .D(n1268), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][5] ), .QN(n1698) );
  DFFSX1 bank_reg_reg70 ( .D(n1269), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][4] ), .QN(n1696) );
  DFFSX1 bank_reg_reg71 ( .D(n1270), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][3] ), .QN(n1695) );
  DFFSX1 bank_reg_reg72 ( .D(n1271), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][2] ), .QN(n1694) );
  DFFSX1 bank_reg_reg73 ( .D(n1272), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][1] ), .QN(n1693) );
  DFFSX1 bank_reg_reg74 ( .D(n1273), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][0] ), .QN(n1692) );
  DFFSX1 bank_reg_reg75 ( .D(n1284), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][5] ) );
  DFFSX1 bank_reg_reg76 ( .D(n1285), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][4] ) );
  DFFSX1 bank_reg_reg77 ( .D(n1286), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][3] ) );
  DFFSX1 bank_reg_reg78 ( .D(n1287), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][2] ) );
  DFFSX1 bank_reg_reg79 ( .D(n1288), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][1] ) );
  DFFSX1 bank_reg_reg80 ( .D(n1289), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][0] ) );
  DFFSX1 bank_reg_reg81 ( .D(n1317), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][4] ) );
  DFFSX1 bank_reg_reg82 ( .D(n1318), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][3] ) );
  DFFSX1 bank_reg_reg83 ( .D(n1319), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][2] ) );
  DFFSX1 bank_reg_reg84 ( .D(n1320), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][1] ) );
  DFFSX1 bank_reg_reg85 ( .D(n1321), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][0] ) );
  DFFSX1 bank_reg_reg86 ( .D(n1293), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][12] ), .QN(n1733) );
  DFFSX1 bank_reg_reg87 ( .D(n1294), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][11] ), .QN(n1732) );
  DFFSX1 bank_reg_reg88 ( .D(n1295), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][10] ), .QN(n1731) );
  DFFSX1 bank_reg_reg89 ( .D(n1213), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][12] ), .QN(n1781) );
  DFFSX1 bank_reg_reg90 ( .D(n1214), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][11] ), .QN(n1780) );
  DFFSX1 bank_reg_reg91 ( .D(n1215), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][10] ), .QN(n1779) );
  DFFSX1 bank_reg_reg92 ( .D(n1325), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][12] ), .QN(n1797) );
  DFFSX1 bank_reg_reg93 ( .D(n1197), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][12] ), .QN(n1753) );
  DFFSX1 bank_reg_reg94 ( .D(n1198), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][11] ), .QN(n1754) );
  DFFSX1 bank_reg_reg95 ( .D(n1199), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][10] ), .QN(n1755) );
  DFFSX1 bank_reg_reg96 ( .D(n1204), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][5] ), .QN(n1750) );
  DFFSX1 bank_reg_reg97 ( .D(n1205), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][4] ), .QN(n1757) );
  DFFSX1 bank_reg_reg98 ( .D(n1206), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][3] ), .QN(n1752) );
  DFFSX1 bank_reg_reg99 ( .D(n1207), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][2] ), .QN(n1751) );
  DFFSX1 bank_reg_reg100 ( .D(n1267), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][6] ), .QN(n1701) );
  DFFSX1 bank_reg_reg101 ( .D(n1277), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][12] ) );
  DFFSX1 bank_reg_reg102 ( .D(n1278), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][11] ) );
  DFFSX1 bank_reg_reg103 ( .D(n1279), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][10] ) );
  DFFSX1 bank_reg_reg104 ( .D(n1309), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][12] ) );
  DFFSX1 bank_reg_reg105 ( .D(n1310), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][11] ) );
  DFFSX1 bank_reg_reg106 ( .D(n1311), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][10] ) );
  DFFSX1 bank_reg_reg107 ( .D(n1316), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][5] ) );
  DFFSX1 bank_reg_reg108 ( .D(n1296), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][9] ), .QN(n1730) );
  DFFSX1 bank_reg_reg109 ( .D(n1297), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][8] ), .QN(n1729) );
  DFFSX1 bank_reg_reg110 ( .D(n1298), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][7] ), .QN(n1728) );
  DFFSX1 bank_reg_reg111 ( .D(n1299), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[2][6] ), .QN(n1727) );
  DFFSX1 bank_reg_reg112 ( .D(n1216), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][9] ), .QN(n1778) );
  DFFSX1 bank_reg_reg113 ( .D(n1217), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][8] ), .QN(n1777) );
  DFFSX1 bank_reg_reg114 ( .D(n1218), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][7] ), .QN(n1776) );
  DFFSX1 bank_reg_reg115 ( .D(n1219), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[7][6] ), .QN(n1775) );
  DFFSX1 bank_reg_reg116 ( .D(n1232), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][9] ), .QN(n1765) );
  DFFSX1 bank_reg_reg117 ( .D(n1233), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][8] ), .QN(n1768) );
  DFFSX1 bank_reg_reg118 ( .D(n1234), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][7] ), .QN(n1767) );
  DFFSX1 bank_reg_reg119 ( .D(n1235), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[6][6] ), .QN(n1766) );
  DFFSX1 bank_reg_reg120 ( .D(n1328), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][9] ), .QN(n1794) );
  DFFSX1 bank_reg_reg121 ( .D(n1329), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][8] ), .QN(n1793) );
  DFFSX1 bank_reg_reg122 ( .D(n1330), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][7] ), .QN(n1792) );
  DFFSX1 bank_reg_reg123 ( .D(n1331), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[0][6] ), .QN(n1791) );
  DFFSX1 bank_reg_reg124 ( .D(n1200), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][9] ), .QN(n1761) );
  DFFSX1 bank_reg_reg125 ( .D(n1201), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][8] ), .QN(n1764) );
  DFFSX1 bank_reg_reg126 ( .D(n1202), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][7] ), .QN(n1763) );
  DFFSX1 bank_reg_reg127 ( .D(n1203), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[8][6] ), .QN(n1762) );
  DFFSX1 bank_reg_reg128 ( .D(n1248), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][9] ), .QN(n1717) );
  DFFSX1 bank_reg_reg129 ( .D(n1249), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][8] ), .QN(n1720) );
  DFFSX1 bank_reg_reg130 ( .D(n1250), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][7] ), .QN(n1719) );
  DFFSX1 bank_reg_reg131 ( .D(n1251), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[5][6] ), .QN(n1718) );
  DFFSX1 bank_reg_reg132 ( .D(n1264), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][9] ), .QN(n1704) );
  DFFSX1 bank_reg_reg133 ( .D(n1265), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][8] ), .QN(n1703) );
  DFFSX1 bank_reg_reg134 ( .D(n1266), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[4][7] ), .QN(n1702) );
  DFFSX1 bank_reg_reg135 ( .D(n1280), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][9] ) );
  DFFSX1 bank_reg_reg136 ( .D(n1281), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][8] ) );
  DFFSX1 bank_reg_reg137 ( .D(n1282), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][7] ) );
  DFFSX1 bank_reg_reg138 ( .D(n1283), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[3][6] ) );
  DFFSX1 bank_reg_reg139 ( .D(n1312), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][9] ) );
  DFFSX1 bank_reg_reg140 ( .D(n1313), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][8] ) );
  DFFSX1 bank_reg_reg141 ( .D(n1314), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][7] ) );
  DFFSX1 bank_reg_reg142 ( .D(n1315), .CK(PCLK), .SN(PRESETn), .Q(
        \bank_reg[1][6] ) );
  OAI222X1 U2206 ( .A0(n1737), .A1(n1586), .B0(n1689), .B1(n1587), .C0(n1705), 
        .C1(n1588), .Y(n1622) );
  AOI221X1 U2207 ( .A0(n1803), .A1(\bank_reg[7][13] ), .B0(n1583), .B1(
        \bank_reg[1][13] ), .C0(n1622), .Y(n1621) );
  INVX1 U2208 ( .A(BANK_SEL[5]), .Y(n1687) );
  AOI221X1 U2209 ( .A0(n1803), .A1(\bank_reg[7][14] ), .B0(n1583), .B1(
        \bank_reg[1][14] ), .C0(n1618), .Y(n1617) );
  AOI221X1 U2210 ( .A0(n1803), .A1(\bank_reg[7][15] ), .B0(n1583), .B1(
        \bank_reg[1][15] ), .C0(n1614), .Y(n1613) );
  OAI222X1 U2211 ( .A0(n1738), .A1(n1586), .B0(n1690), .B1(n1587), .C0(n1706), 
        .C1(n1588), .Y(n1614) );
  OAI222X1 U2212 ( .A0(n1739), .A1(n1586), .B0(n1691), .B1(n1587), .C0(n1707), 
        .C1(n1588), .Y(n1618) );
endmodule

