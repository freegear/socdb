
module vic_slave_arbiter ( FIXED_MODE, INTPEND, ISPR_OUT, INTERRUPT_OUT, PSLV, 
        CSLV, NEXTCSLV );
  input [7:0] INTPEND;
  output [7:0] ISPR_OUT;
  input [23:0] PSLV;
  input [23:0] CSLV;
  output [23:0] NEXTCSLV;
  input FIXED_MODE;
  output INTERRUPT_OUT;
  wire   reordered_int_0_, highest_priority_int_1_, highest_priority_int_2_,
         highest_priority_int_3_, highest_priority_int_4_,
         highest_priority_int_5_, highest_priority_int_6_,
         highest_priority_int_7_, n360, n361, n362, n363, n364, n365, n366,
         n367, n368, n369, n370, n371, n372, n373, n374, n375, n376, n377,
         n378, n379, n380, n381, n382, n383, n384, n385, n386, n387, n388,
         n389, n390, n391, n392, n393, n394, n395, n396, n397, n398, n399,
         n400, n401, n402, n403, n404, n405, n406, n407, n408, n409, n410,
         n411, n412, n413, n414, n415, n416, n417, n418, n419, n420, n421,
         n422, n423, n424, n425, n426, n427, n428, n429, n430, n431, n432,
         n433, n434, n435, n436, n437, n438, n439, n440, n441, n442, n443,
         n444, n445, n446, n447, n448, n449, n450, n451, n452, n453, n454,
         n455, n456, n457, n458, n459, n460, n461, n462, n463, n464, n465,
         n466, n467, n468, n469, n470;
  wire   [2:0] priority0;
  wire   [2:0] priority1;
  wire   [2:0] priority2;
  wire   [2:0] priority3;
  wire   [2:0] priority4;
  wire   [2:0] priority5;
  wire   [2:0] priority6;
  wire   [2:0] priority7;
  wire   [7:0] int0;
  wire   [7:0] int1;
  wire   [7:0] int2;
  wire   [7:0] int3;
  wire   [7:0] int4;
  wire   [7:0] int5;
  wire   [7:0] int6;
  wire   [7:0] int7;

  vic_slave_arbiter_priority_decode_7 int0_decode ( .PRI(priority0), .INT(
        INTPEND[0]), .INT_OUT(int0) );
  vic_slave_arbiter_priority_decode_6 int1_decode ( .PRI(priority1), .INT(
        INTPEND[1]), .INT_OUT(int1) );
  vic_slave_arbiter_priority_decode_5 int2_decode ( .PRI(priority2), .INT(
        INTPEND[2]), .INT_OUT(int2) );
  vic_slave_arbiter_priority_decode_4 int3_decode ( .PRI(priority3), .INT(
        INTPEND[3]), .INT_OUT(int3) );
  vic_slave_arbiter_priority_decode_3 int4_decode ( .PRI(priority4), .INT(
        INTPEND[4]), .INT_OUT(int4) );
  vic_slave_arbiter_priority_decode_2 int5_decode ( .PRI(priority5), .INT(
        INTPEND[5]), .INT_OUT(int5) );
  vic_slave_arbiter_priority_decode_1 int6_decode ( .PRI(priority6), .INT(
        INTPEND[6]), .INT_OUT(int6) );
  vic_slave_arbiter_priority_decode_0 int7_decode ( .PRI(priority7), .INT(
        INTPEND[7]), .INT_OUT(int7) );
  vic_slave_arbiter_8to1_mux_7 reorder_bit0 ( .SEL(priority0), .INPUT0({
        highest_priority_int_7_, highest_priority_int_6_, 
        highest_priority_int_5_, highest_priority_int_4_, 
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[0]) );
  vic_slave_arbiter_8to1_mux_6 reorder_bit1 ( .SEL(priority1), .INPUT0({
        highest_priority_int_7_, highest_priority_int_6_, 
        highest_priority_int_5_, highest_priority_int_4_, 
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[1]) );
  vic_slave_arbiter_8to1_mux_5 reorder_bit2 ( .SEL(priority2), .INPUT0({
        highest_priority_int_7_, highest_priority_int_6_, 
        highest_priority_int_5_, highest_priority_int_4_, 
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[2]) );
  vic_slave_arbiter_8to1_mux_4 reorder_bit3 ( .SEL(priority3), .INPUT0({
        highest_priority_int_7_, highest_priority_int_6_, 
        highest_priority_int_5_, highest_priority_int_4_, 
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[3]) );
  vic_slave_arbiter_8to1_mux_3 reorder_bit4 ( .SEL(priority4), .INPUT0({
        highest_priority_int_7_, highest_priority_int_6_, 
        highest_priority_int_5_, highest_priority_int_4_, 
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[4]) );
  vic_slave_arbiter_8to1_mux_2 reorder_bit5 ( .SEL(priority5), .INPUT0({
        highest_priority_int_7_, highest_priority_int_6_, 
        highest_priority_int_5_, highest_priority_int_4_, 
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[5]) );
  vic_slave_arbiter_8to1_mux_1 reorder_bit6 ( .SEL(priority6), .INPUT0({
        highest_priority_int_7_, highest_priority_int_6_, 
        highest_priority_int_5_, highest_priority_int_4_, 
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[6]) );
  vic_slave_arbiter_8to1_mux_0 reorder_bit7 ( .SEL(priority7), .INPUT0({
        highest_priority_int_7_, highest_priority_int_6_, 
        highest_priority_int_5_, highest_priority_int_4_, 
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[7]) );
  OA22X1 U543 ( .A0(CSLV[23]), .A1(FIXED_MODE), .B0(PSLV[23]), .B1(n360), .Y(
        priority7[2]) );
  OAI22XL U544 ( .A0(n361), .A1(n360), .B0(n362), .B1(FIXED_MODE), .Y(
        priority7[1]) );
  OA22X1 U545 ( .A0(CSLV[21]), .A1(FIXED_MODE), .B0(PSLV[21]), .B1(n360), .Y(
        priority7[0]) );
  OA22X1 U546 ( .A0(CSLV[20]), .A1(FIXED_MODE), .B0(PSLV[20]), .B1(n360), .Y(
        priority6[2]) );
  OAI22XL U547 ( .A0(n363), .A1(n360), .B0(n364), .B1(FIXED_MODE), .Y(
        priority6[1]) );
  OA22X1 U548 ( .A0(CSLV[18]), .A1(FIXED_MODE), .B0(PSLV[18]), .B1(n360), .Y(
        priority6[0]) );
  OA22X1 U549 ( .A0(CSLV[17]), .A1(FIXED_MODE), .B0(PSLV[17]), .B1(n360), .Y(
        priority5[2]) );
  OAI22XL U550 ( .A0(n365), .A1(n360), .B0(n366), .B1(FIXED_MODE), .Y(
        priority5[1]) );
  OA22X1 U551 ( .A0(CSLV[15]), .A1(FIXED_MODE), .B0(PSLV[15]), .B1(n360), .Y(
        priority5[0]) );
  OA22X1 U552 ( .A0(CSLV[14]), .A1(FIXED_MODE), .B0(PSLV[14]), .B1(n360), .Y(
        priority4[2]) );
  OAI22XL U553 ( .A0(n367), .A1(n360), .B0(n368), .B1(FIXED_MODE), .Y(
        priority4[1]) );
  OA22X1 U554 ( .A0(CSLV[12]), .A1(FIXED_MODE), .B0(PSLV[12]), .B1(n360), .Y(
        priority4[0]) );
  OA22X1 U555 ( .A0(CSLV[11]), .A1(FIXED_MODE), .B0(PSLV[11]), .B1(n360), .Y(
        priority3[2]) );
  OAI22XL U556 ( .A0(n369), .A1(n360), .B0(n370), .B1(FIXED_MODE), .Y(
        priority3[1]) );
  OA22X1 U557 ( .A0(CSLV[9]), .A1(FIXED_MODE), .B0(PSLV[9]), .B1(n360), .Y(
        priority3[0]) );
  OA22X1 U558 ( .A0(CSLV[8]), .A1(FIXED_MODE), .B0(PSLV[8]), .B1(n360), .Y(
        priority2[2]) );
  OAI22XL U559 ( .A0(n371), .A1(n360), .B0(n372), .B1(FIXED_MODE), .Y(
        priority2[1]) );
  OA22X1 U560 ( .A0(CSLV[6]), .A1(FIXED_MODE), .B0(PSLV[6]), .B1(n360), .Y(
        priority2[0]) );
  OA22X1 U561 ( .A0(CSLV[5]), .A1(FIXED_MODE), .B0(PSLV[5]), .B1(n360), .Y(
        priority1[2]) );
  OAI22XL U562 ( .A0(n373), .A1(n360), .B0(n374), .B1(FIXED_MODE), .Y(
        priority1[1]) );
  OA22X1 U563 ( .A0(CSLV[3]), .A1(FIXED_MODE), .B0(PSLV[3]), .B1(n360), .Y(
        priority1[0]) );
  OA22X1 U564 ( .A0(CSLV[2]), .A1(FIXED_MODE), .B0(PSLV[2]), .B1(n360), .Y(
        priority0[2]) );
  OAI22XL U565 ( .A0(n375), .A1(n360), .B0(n376), .B1(FIXED_MODE), .Y(
        priority0[1]) );
  OA22X1 U566 ( .A0(CSLV[0]), .A1(FIXED_MODE), .B0(PSLV[0]), .B1(n360), .Y(
        priority0[0]) );
  OAI21XL U567 ( .A0(n377), .A1(n378), .B0(n379), .Y(NEXTCSLV[9]) );
  OAI22XL U568 ( .A0(PSLV[9]), .A1(n360), .B0(n380), .B1(FIXED_MODE), .Y(n379)
         );
  CLKINVX1 U569 ( .A(CSLV[9]), .Y(n377) );
  OAI2BB1X1 U570 ( .A0N(FIXED_MODE), .A1N(PSLV[8]), .B0(n381), .Y(NEXTCSLV[8])
         );
  MXI4X1 U571 ( .S1(n384), .S0(CSLV[8]), .D(n382), .C(n383), .B(n383), .A(n382), .Y(n381) );
  AOI22X1 U572 ( .A0(n385), .A1(n372), .B0(n386), .B1(n387), .Y(n384) );
  CLKINVX1 U573 ( .A(CSLV[7]), .Y(n372) );
  OR2X1 U574 ( .A(n386), .B(n387), .Y(n385) );
  OAI21XL U575 ( .A0(n360), .A1(n371), .B0(n388), .Y(NEXTCSLV[7]) );
  MXI4X1 U576 ( .S1(n386), .S0(CSLV[7]), .D(n389), .C(n390), .B(n390), .A(n389), .Y(n388) );
  CLKINVX1 U577 ( .A(PSLV[7]), .Y(n371) );
  OAI21XL U578 ( .A0(n391), .A1(n378), .B0(n392), .Y(NEXTCSLV[6]) );
  OAI22XL U579 ( .A0(PSLV[6]), .A1(n360), .B0(n386), .B1(FIXED_MODE), .Y(n392)
         );
  NOR2X1 U580 ( .A(n393), .B(CSLV[6]), .Y(n386) );
  CLKINVX1 U581 ( .A(CSLV[6]), .Y(n391) );
  OAI2BB1X1 U582 ( .A0N(FIXED_MODE), .A1N(PSLV[5]), .B0(n394), .Y(NEXTCSLV[5])
         );
  MXI4X1 U583 ( .S1(n395), .S0(CSLV[5]), .D(n382), .C(n383), .B(n383), .A(n382), .Y(n394) );
  AOI22X1 U584 ( .A0(n396), .A1(n374), .B0(n397), .B1(n387), .Y(n395) );
  CLKINVX1 U585 ( .A(CSLV[4]), .Y(n374) );
  OR2X1 U586 ( .A(n397), .B(n387), .Y(n396) );
  OAI21XL U587 ( .A0(n360), .A1(n373), .B0(n398), .Y(NEXTCSLV[4]) );
  MXI4X1 U588 ( .S1(n397), .S0(CSLV[4]), .D(n389), .C(n390), .B(n390), .A(n389), .Y(n398) );
  CLKINVX1 U589 ( .A(PSLV[4]), .Y(n373) );
  OAI21XL U590 ( .A0(n399), .A1(n378), .B0(n400), .Y(NEXTCSLV[3]) );
  OAI22XL U591 ( .A0(PSLV[3]), .A1(n360), .B0(n397), .B1(FIXED_MODE), .Y(n400)
         );
  NOR2X1 U592 ( .A(n393), .B(CSLV[3]), .Y(n397) );
  CLKINVX1 U593 ( .A(CSLV[3]), .Y(n399) );
  OAI2BB1X1 U594 ( .A0N(FIXED_MODE), .A1N(PSLV[2]), .B0(n401), .Y(NEXTCSLV[2])
         );
  MXI4X1 U595 ( .S1(n402), .S0(CSLV[2]), .D(n382), .C(n383), .B(n383), .A(n382), .Y(n401) );
  AOI22X1 U596 ( .A0(n403), .A1(n376), .B0(n404), .B1(n387), .Y(n402) );
  CLKINVX1 U597 ( .A(CSLV[1]), .Y(n376) );
  OR2X1 U598 ( .A(n404), .B(n387), .Y(n403) );
  OAI2BB1X1 U599 ( .A0N(FIXED_MODE), .A1N(PSLV[23]), .B0(n405), .Y(
        NEXTCSLV[23]) );
  MXI4X1 U600 ( .S1(n406), .S0(CSLV[23]), .D(n382), .C(n383), .B(n383), .A(
        n382), .Y(n405) );
  AOI22X1 U601 ( .A0(n407), .A1(n362), .B0(n408), .B1(n387), .Y(n406) );
  CLKINVX1 U602 ( .A(CSLV[22]), .Y(n362) );
  OR2X1 U603 ( .A(n408), .B(n387), .Y(n407) );
  OAI21XL U604 ( .A0(n360), .A1(n361), .B0(n409), .Y(NEXTCSLV[22]) );
  MXI4X1 U605 ( .S1(n408), .S0(CSLV[22]), .D(n389), .C(n390), .B(n390), .A(
        n389), .Y(n409) );
  CLKINVX1 U606 ( .A(PSLV[22]), .Y(n361) );
  OAI21XL U607 ( .A0(n410), .A1(n378), .B0(n411), .Y(NEXTCSLV[21]) );
  OAI22XL U608 ( .A0(PSLV[21]), .A1(n360), .B0(n408), .B1(FIXED_MODE), .Y(n411) );
  NOR2X1 U609 ( .A(n393), .B(CSLV[21]), .Y(n408) );
  CLKINVX1 U610 ( .A(CSLV[21]), .Y(n410) );
  OAI2BB1X1 U611 ( .A0N(FIXED_MODE), .A1N(PSLV[20]), .B0(n412), .Y(
        NEXTCSLV[20]) );
  MXI4X1 U612 ( .S1(n413), .S0(CSLV[20]), .D(n382), .C(n383), .B(n383), .A(
        n382), .Y(n412) );
  AOI22X1 U613 ( .A0(n414), .A1(n364), .B0(n415), .B1(n387), .Y(n413) );
  CLKINVX1 U614 ( .A(CSLV[19]), .Y(n364) );
  OR2X1 U615 ( .A(n415), .B(n387), .Y(n414) );
  OAI21XL U616 ( .A0(n360), .A1(n375), .B0(n416), .Y(NEXTCSLV[1]) );
  MXI4X1 U617 ( .S1(n404), .S0(CSLV[1]), .D(n389), .C(n390), .B(n390), .A(n389), .Y(n416) );
  CLKINVX1 U618 ( .A(PSLV[1]), .Y(n375) );
  OAI21XL U619 ( .A0(n360), .A1(n363), .B0(n417), .Y(NEXTCSLV[19]) );
  MXI4X1 U620 ( .S1(n415), .S0(CSLV[19]), .D(n389), .C(n390), .B(n390), .A(
        n389), .Y(n417) );
  CLKINVX1 U621 ( .A(PSLV[19]), .Y(n363) );
  OAI21XL U622 ( .A0(n418), .A1(n378), .B0(n419), .Y(NEXTCSLV[18]) );
  OAI22XL U623 ( .A0(PSLV[18]), .A1(n360), .B0(n415), .B1(FIXED_MODE), .Y(n419) );
  NOR2X1 U624 ( .A(n393), .B(CSLV[18]), .Y(n415) );
  CLKINVX1 U625 ( .A(CSLV[18]), .Y(n418) );
  OAI2BB1X1 U626 ( .A0N(FIXED_MODE), .A1N(PSLV[17]), .B0(n420), .Y(
        NEXTCSLV[17]) );
  MXI4X1 U627 ( .S1(n421), .S0(CSLV[17]), .D(n382), .C(n383), .B(n383), .A(
        n382), .Y(n420) );
  AOI22X1 U628 ( .A0(n422), .A1(n366), .B0(n423), .B1(n387), .Y(n421) );
  CLKINVX1 U629 ( .A(CSLV[16]), .Y(n366) );
  OR2X1 U630 ( .A(n423), .B(n387), .Y(n422) );
  OAI21XL U631 ( .A0(n360), .A1(n365), .B0(n424), .Y(NEXTCSLV[16]) );
  MXI4X1 U632 ( .S1(n423), .S0(CSLV[16]), .D(n389), .C(n390), .B(n390), .A(
        n389), .Y(n424) );
  CLKINVX1 U633 ( .A(PSLV[16]), .Y(n365) );
  OAI21XL U634 ( .A0(n425), .A1(n378), .B0(n426), .Y(NEXTCSLV[15]) );
  OAI22XL U635 ( .A0(PSLV[15]), .A1(n360), .B0(n423), .B1(FIXED_MODE), .Y(n426) );
  NOR2X1 U636 ( .A(n393), .B(CSLV[15]), .Y(n423) );
  CLKINVX1 U637 ( .A(CSLV[15]), .Y(n425) );
  OAI2BB1X1 U638 ( .A0N(FIXED_MODE), .A1N(PSLV[14]), .B0(n427), .Y(
        NEXTCSLV[14]) );
  MXI4X1 U639 ( .S1(n428), .S0(CSLV[14]), .D(n382), .C(n383), .B(n383), .A(
        n382), .Y(n427) );
  AOI22X1 U640 ( .A0(n429), .A1(n368), .B0(n430), .B1(n387), .Y(n428) );
  CLKINVX1 U641 ( .A(CSLV[13]), .Y(n368) );
  OR2X1 U642 ( .A(n430), .B(n387), .Y(n429) );
  OAI21XL U643 ( .A0(n360), .A1(n367), .B0(n431), .Y(NEXTCSLV[13]) );
  MXI4X1 U644 ( .S1(n430), .S0(CSLV[13]), .D(n389), .C(n390), .B(n390), .A(
        n389), .Y(n431) );
  CLKINVX1 U645 ( .A(PSLV[13]), .Y(n367) );
  OAI21XL U646 ( .A0(n432), .A1(n378), .B0(n433), .Y(NEXTCSLV[12]) );
  OAI22XL U647 ( .A0(PSLV[12]), .A1(n360), .B0(n430), .B1(FIXED_MODE), .Y(n433) );
  NOR2X1 U648 ( .A(n393), .B(CSLV[12]), .Y(n430) );
  CLKINVX1 U649 ( .A(CSLV[12]), .Y(n432) );
  OAI2BB1X1 U650 ( .A0N(FIXED_MODE), .A1N(PSLV[11]), .B0(n434), .Y(
        NEXTCSLV[11]) );
  MXI4X1 U651 ( .S1(n435), .S0(CSLV[11]), .D(n382), .C(n383), .B(n383), .A(
        n382), .Y(n434) );
  AOI22X1 U652 ( .A0(n436), .A1(n370), .B0(n380), .B1(n387), .Y(n435) );
  CLKINVX1 U653 ( .A(CSLV[10]), .Y(n370) );
  OR2X1 U654 ( .A(n380), .B(n387), .Y(n436) );
  NOR2X1 U655 ( .A(FIXED_MODE), .B(n437), .Y(n383) );
  NOR2X1 U656 ( .A(n438), .B(FIXED_MODE), .Y(n382) );
  OAI21XL U657 ( .A0(n360), .A1(n369), .B0(n439), .Y(NEXTCSLV[10]) );
  MXI4X1 U658 ( .S1(n380), .S0(CSLV[10]), .D(n389), .C(n390), .B(n390), .A(
        n389), .Y(n439) );
  NOR2X1 U659 ( .A(n393), .B(CSLV[9]), .Y(n380) );
  NOR2X1 U660 ( .A(n387), .B(FIXED_MODE), .Y(n390) );
  CLKINVX1 U661 ( .A(n440), .Y(n387) );
  NOR2X1 U662 ( .A(FIXED_MODE), .B(n440), .Y(n389) );
  NOR4X1 U663 ( .A(highest_priority_int_7_), .B(highest_priority_int_2_), .C(
        highest_priority_int_3_), .D(highest_priority_int_6_), .Y(n440) );
  NOR3X1 U664 ( .A(n441), .B(n442), .C(n443), .Y(highest_priority_int_6_) );
  NOR3BXL U665 ( .AN(n444), .B(reordered_int_0_), .C(n445), .Y(
        highest_priority_int_2_) );
  CLKINVX1 U666 ( .A(PSLV[10]), .Y(n369) );
  OAI21XL U667 ( .A0(n446), .A1(n378), .B0(n447), .Y(NEXTCSLV[0]) );
  OAI22XL U668 ( .A0(PSLV[0]), .A1(n360), .B0(n404), .B1(FIXED_MODE), .Y(n447)
         );
  NOR2X1 U669 ( .A(n393), .B(CSLV[0]), .Y(n404) );
  NAND2X1 U670 ( .A(n393), .B(n360), .Y(n378) );
  CLKINVX1 U671 ( .A(FIXED_MODE), .Y(n360) );
  NOR4X1 U672 ( .A(highest_priority_int_7_), .B(highest_priority_int_1_), .C(
        highest_priority_int_3_), .D(highest_priority_int_5_), .Y(n393) );
  NOR2BX1 U673 ( .AN(n448), .B(n449), .Y(highest_priority_int_3_) );
  NOR2BX1 U674 ( .AN(n445), .B(reordered_int_0_), .Y(highest_priority_int_1_)
         );
  CLKINVX1 U675 ( .A(n450), .Y(highest_priority_int_7_) );
  CLKINVX1 U676 ( .A(CSLV[0]), .Y(n446) );
  NAND3X1 U677 ( .A(n449), .B(n448), .C(n437), .Y(INTERRUPT_OUT) );
  CLKINVX1 U678 ( .A(n438), .Y(n437) );
  OAI211X1 U679 ( .A0(n442), .A1(n443), .B0(n450), .C0(n451), .Y(n438) );
  NOR2X1 U680 ( .A(highest_priority_int_5_), .B(highest_priority_int_4_), .Y(
        n451) );
  AND3X1 U681 ( .A(n448), .B(n452), .C(n449), .Y(highest_priority_int_4_) );
  NOR2X1 U682 ( .A(n443), .B(n453), .Y(highest_priority_int_5_) );
  NAND4BX1 U683 ( .AN(n443), .B(n442), .C(n453), .D(n454), .Y(n450) );
  NAND2X1 U684 ( .A(n455), .B(n456), .Y(n454) );
  NOR4X1 U685 ( .A(int7[7]), .B(int6[7]), .C(int5[7]), .D(int4[7]), .Y(n456)
         );
  NOR4X1 U686 ( .A(int3[7]), .B(int2[7]), .C(int1[7]), .D(int0[7]), .Y(n455)
         );
  CLKINVX1 U687 ( .A(n441), .Y(n453) );
  NAND2X1 U688 ( .A(n457), .B(n458), .Y(n441) );
  NOR4X1 U689 ( .A(int7[5]), .B(int6[5]), .C(int5[5]), .D(int4[5]), .Y(n458)
         );
  NOR4X1 U690 ( .A(int3[5]), .B(int2[5]), .C(int1[5]), .D(int0[5]), .Y(n457)
         );
  NAND3BX1 U691 ( .AN(n452), .B(n448), .C(n449), .Y(n443) );
  NAND2X1 U692 ( .A(n459), .B(n460), .Y(n452) );
  NOR4X1 U693 ( .A(int7[4]), .B(int6[4]), .C(int5[4]), .D(int4[4]), .Y(n460)
         );
  NOR4X1 U694 ( .A(int3[4]), .B(int2[4]), .C(int1[4]), .D(int0[4]), .Y(n459)
         );
  AND2X1 U695 ( .A(n461), .B(n462), .Y(n442) );
  NOR4X1 U696 ( .A(int7[6]), .B(int6[6]), .C(int5[6]), .D(int4[6]), .Y(n462)
         );
  NOR4X1 U697 ( .A(int3[6]), .B(int2[6]), .C(int1[6]), .D(int0[6]), .Y(n461)
         );
  NOR3X1 U698 ( .A(n445), .B(reordered_int_0_), .C(n444), .Y(n448) );
  NAND2X1 U699 ( .A(n463), .B(n464), .Y(n444) );
  NOR4X1 U700 ( .A(int7[2]), .B(int6[2]), .C(int5[2]), .D(int4[2]), .Y(n464)
         );
  NOR4X1 U701 ( .A(int3[2]), .B(int2[2]), .C(int1[2]), .D(int0[2]), .Y(n463)
         );
  NAND2X1 U702 ( .A(n465), .B(n466), .Y(reordered_int_0_) );
  NOR4X1 U703 ( .A(int7[0]), .B(int6[0]), .C(int5[0]), .D(int4[0]), .Y(n466)
         );
  NOR4X1 U704 ( .A(int3[0]), .B(int2[0]), .C(int1[0]), .D(int0[0]), .Y(n465)
         );
  NAND2X1 U705 ( .A(n467), .B(n468), .Y(n445) );
  NOR4X1 U706 ( .A(int7[1]), .B(int6[1]), .C(int5[1]), .D(int4[1]), .Y(n468)
         );
  NOR4X1 U707 ( .A(int3[1]), .B(int2[1]), .C(int1[1]), .D(int0[1]), .Y(n467)
         );
  AND2X1 U708 ( .A(n469), .B(n470), .Y(n449) );
  NOR4X1 U709 ( .A(int7[3]), .B(int6[3]), .C(int5[3]), .D(int4[3]), .Y(n470)
         );
  NOR4X1 U710 ( .A(int3[3]), .B(int2[3]), .C(int1[3]), .D(int0[3]), .Y(n469)
         );
endmodule


module vic_slave_arbiter_8to1_mux_7 ( SEL, INPUT0, OUTPUT0 );
  input [2:0] SEL;
  input [7:0] INPUT0;
  output OUTPUT0;
  wire   n26, n27;

  MXI2X1 U31 ( .S0(SEL[2]), .B(n27), .A(n26), .Y(OUTPUT0) );
  MXI4X1 U32 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[7]), .C(INPUT0[5]), .B(
        INPUT0[6]), .A(INPUT0[4]), .Y(n27) );
  MXI4X1 U33 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(n26) );
endmodule


module vic_slave_arbiter_8to1_mux_6 ( SEL, INPUT0, OUTPUT0 );
  input [2:0] SEL;
  input [7:0] INPUT0;
  output OUTPUT0;
  wire   n26, n27;

  MXI2X1 U31 ( .S0(SEL[2]), .B(n27), .A(n26), .Y(OUTPUT0) );
  MXI4X1 U32 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[7]), .C(INPUT0[5]), .B(
        INPUT0[6]), .A(INPUT0[4]), .Y(n27) );
  MXI4X1 U33 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(n26) );
endmodule


module vic_slave_arbiter_8to1_mux_5 ( SEL, INPUT0, OUTPUT0 );
  input [2:0] SEL;
  input [7:0] INPUT0;
  output OUTPUT0;
  wire   n26, n27;

  MXI2X1 U31 ( .S0(SEL[2]), .B(n27), .A(n26), .Y(OUTPUT0) );
  MXI4X1 U32 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[7]), .C(INPUT0[5]), .B(
        INPUT0[6]), .A(INPUT0[4]), .Y(n27) );
  MXI4X1 U33 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(n26) );
endmodule


module vic_slave_arbiter_8to1_mux_4 ( SEL, INPUT0, OUTPUT0 );
  input [2:0] SEL;
  input [7:0] INPUT0;
  output OUTPUT0;
  wire   n26, n27;

  MXI2X1 U31 ( .S0(SEL[2]), .B(n27), .A(n26), .Y(OUTPUT0) );
  MXI4X1 U32 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[7]), .C(INPUT0[5]), .B(
        INPUT0[6]), .A(INPUT0[4]), .Y(n27) );
  MXI4X1 U33 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(n26) );
endmodule


module vic_slave_arbiter_8to1_mux_3 ( SEL, INPUT0, OUTPUT0 );
  input [2:0] SEL;
  input [7:0] INPUT0;
  output OUTPUT0;
  wire   n26, n27;

  MXI2X1 U31 ( .S0(SEL[2]), .B(n27), .A(n26), .Y(OUTPUT0) );
  MXI4X1 U32 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[7]), .C(INPUT0[5]), .B(
        INPUT0[6]), .A(INPUT0[4]), .Y(n27) );
  MXI4X1 U33 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(n26) );
endmodule


module vic_slave_arbiter_8to1_mux_2 ( SEL, INPUT0, OUTPUT0 );
  input [2:0] SEL;
  input [7:0] INPUT0;
  output OUTPUT0;
  wire   n26, n27;

  MXI2X1 U31 ( .S0(SEL[2]), .B(n27), .A(n26), .Y(OUTPUT0) );
  MXI4X1 U32 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[7]), .C(INPUT0[5]), .B(
        INPUT0[6]), .A(INPUT0[4]), .Y(n27) );
  MXI4X1 U33 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(n26) );
endmodule


module vic_slave_arbiter_8to1_mux_1 ( SEL, INPUT0, OUTPUT0 );
  input [2:0] SEL;
  input [7:0] INPUT0;
  output OUTPUT0;
  wire   n26, n27;

  MXI2X1 U31 ( .S0(SEL[2]), .B(n27), .A(n26), .Y(OUTPUT0) );
  MXI4X1 U32 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[7]), .C(INPUT0[5]), .B(
        INPUT0[6]), .A(INPUT0[4]), .Y(n27) );
  MXI4X1 U33 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(n26) );
endmodule


module vic_slave_arbiter_8to1_mux_0 ( SEL, INPUT0, OUTPUT0 );
  input [2:0] SEL;
  input [7:0] INPUT0;
  output OUTPUT0;
  wire   n26, n27;

  MXI2X1 U31 ( .S0(SEL[2]), .B(n27), .A(n26), .Y(OUTPUT0) );
  MXI4X1 U32 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[7]), .C(INPUT0[5]), .B(
        INPUT0[6]), .A(INPUT0[4]), .Y(n27) );
  MXI4X1 U33 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(n26) );
endmodule


module vic_slave_arbiter_priority_decode_7 ( PRI, INT, INT_OUT );
  input [2:0] PRI;
  output [7:0] INT_OUT;
  input INT;
  wire   n16, n17, n18, n19;

  NOR3X1 U40 ( .A(n16), .B(n17), .C(n18), .Y(INT_OUT[7]) );
  NOR3X1 U41 ( .A(n16), .B(PRI[0]), .C(n17), .Y(INT_OUT[6]) );
  NOR3X1 U42 ( .A(n18), .B(PRI[1]), .C(n17), .Y(INT_OUT[5]) );
  NOR3X1 U43 ( .A(n17), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[4]) );
  NAND2X1 U44 ( .A(PRI[2]), .B(INT), .Y(n17) );
  NOR3X1 U45 ( .A(n19), .B(n18), .C(n16), .Y(INT_OUT[3]) );
  NOR3X1 U46 ( .A(n19), .B(PRI[0]), .C(n16), .Y(INT_OUT[2]) );
  CLKINVX1 U47 ( .A(PRI[1]), .Y(n16) );
  NOR3X1 U48 ( .A(n19), .B(PRI[1]), .C(n18), .Y(INT_OUT[1]) );
  CLKINVX1 U49 ( .A(PRI[0]), .Y(n18) );
  NOR3X1 U50 ( .A(n19), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  NAND2BX1 U51 ( .AN(PRI[2]), .B(INT), .Y(n19) );
endmodule


module vic_slave_arbiter_priority_decode_6 ( PRI, INT, INT_OUT );
  input [2:0] PRI;
  output [7:0] INT_OUT;
  input INT;
  wire   n16, n17, n18, n19;

  NOR3X1 U40 ( .A(n16), .B(n17), .C(n18), .Y(INT_OUT[7]) );
  NOR3X1 U41 ( .A(n16), .B(PRI[0]), .C(n17), .Y(INT_OUT[6]) );
  NOR3X1 U42 ( .A(n18), .B(PRI[1]), .C(n17), .Y(INT_OUT[5]) );
  NOR3X1 U43 ( .A(n17), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[4]) );
  NAND2X1 U44 ( .A(PRI[2]), .B(INT), .Y(n17) );
  NOR3X1 U45 ( .A(n19), .B(n18), .C(n16), .Y(INT_OUT[3]) );
  NOR3X1 U46 ( .A(n19), .B(PRI[0]), .C(n16), .Y(INT_OUT[2]) );
  CLKINVX1 U47 ( .A(PRI[1]), .Y(n16) );
  NOR3X1 U48 ( .A(n19), .B(PRI[1]), .C(n18), .Y(INT_OUT[1]) );
  CLKINVX1 U49 ( .A(PRI[0]), .Y(n18) );
  NOR3X1 U50 ( .A(n19), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  NAND2BX1 U51 ( .AN(PRI[2]), .B(INT), .Y(n19) );
endmodule


module vic_slave_arbiter_priority_decode_5 ( PRI, INT, INT_OUT );
  input [2:0] PRI;
  output [7:0] INT_OUT;
  input INT;
  wire   n16, n17, n18, n19;

  NOR3X1 U40 ( .A(n16), .B(n17), .C(n18), .Y(INT_OUT[7]) );
  NOR3X1 U41 ( .A(n16), .B(PRI[0]), .C(n17), .Y(INT_OUT[6]) );
  NOR3X1 U42 ( .A(n18), .B(PRI[1]), .C(n17), .Y(INT_OUT[5]) );
  NOR3X1 U43 ( .A(n17), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[4]) );
  NAND2X1 U44 ( .A(PRI[2]), .B(INT), .Y(n17) );
  NOR3X1 U45 ( .A(n19), .B(n18), .C(n16), .Y(INT_OUT[3]) );
  NOR3X1 U46 ( .A(n19), .B(PRI[0]), .C(n16), .Y(INT_OUT[2]) );
  CLKINVX1 U47 ( .A(PRI[1]), .Y(n16) );
  NOR3X1 U48 ( .A(n19), .B(PRI[1]), .C(n18), .Y(INT_OUT[1]) );
  CLKINVX1 U49 ( .A(PRI[0]), .Y(n18) );
  NOR3X1 U50 ( .A(n19), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  NAND2BX1 U51 ( .AN(PRI[2]), .B(INT), .Y(n19) );
endmodule


module vic_slave_arbiter_priority_decode_4 ( PRI, INT, INT_OUT );
  input [2:0] PRI;
  output [7:0] INT_OUT;
  input INT;
  wire   n16, n17, n18, n19;

  NOR3X1 U40 ( .A(n16), .B(n17), .C(n18), .Y(INT_OUT[7]) );
  NOR3X1 U41 ( .A(n16), .B(PRI[0]), .C(n17), .Y(INT_OUT[6]) );
  NOR3X1 U42 ( .A(n18), .B(PRI[1]), .C(n17), .Y(INT_OUT[5]) );
  NOR3X1 U43 ( .A(n17), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[4]) );
  NAND2X1 U44 ( .A(PRI[2]), .B(INT), .Y(n17) );
  NOR3X1 U45 ( .A(n19), .B(n18), .C(n16), .Y(INT_OUT[3]) );
  NOR3X1 U46 ( .A(n19), .B(PRI[0]), .C(n16), .Y(INT_OUT[2]) );
  CLKINVX1 U47 ( .A(PRI[1]), .Y(n16) );
  NOR3X1 U48 ( .A(n19), .B(PRI[1]), .C(n18), .Y(INT_OUT[1]) );
  CLKINVX1 U49 ( .A(PRI[0]), .Y(n18) );
  NOR3X1 U50 ( .A(n19), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  NAND2BX1 U51 ( .AN(PRI[2]), .B(INT), .Y(n19) );
endmodule


module vic_slave_arbiter_priority_decode_3 ( PRI, INT, INT_OUT );
  input [2:0] PRI;
  output [7:0] INT_OUT;
  input INT;
  wire   n16, n17, n18, n19;

  NOR3X1 U40 ( .A(n16), .B(n17), .C(n18), .Y(INT_OUT[7]) );
  NOR3X1 U41 ( .A(n16), .B(PRI[0]), .C(n17), .Y(INT_OUT[6]) );
  NOR3X1 U42 ( .A(n18), .B(PRI[1]), .C(n17), .Y(INT_OUT[5]) );
  NOR3X1 U43 ( .A(n17), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[4]) );
  NAND2X1 U44 ( .A(PRI[2]), .B(INT), .Y(n17) );
  NOR3X1 U45 ( .A(n19), .B(n18), .C(n16), .Y(INT_OUT[3]) );
  NOR3X1 U46 ( .A(n19), .B(PRI[0]), .C(n16), .Y(INT_OUT[2]) );
  CLKINVX1 U47 ( .A(PRI[1]), .Y(n16) );
  NOR3X1 U48 ( .A(n19), .B(PRI[1]), .C(n18), .Y(INT_OUT[1]) );
  CLKINVX1 U49 ( .A(PRI[0]), .Y(n18) );
  NOR3X1 U50 ( .A(n19), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  NAND2BX1 U51 ( .AN(PRI[2]), .B(INT), .Y(n19) );
endmodule


module vic_slave_arbiter_priority_decode_2 ( PRI, INT, INT_OUT );
  input [2:0] PRI;
  output [7:0] INT_OUT;
  input INT;
  wire   n16, n17, n18, n19;

  NOR3X1 U40 ( .A(n16), .B(n17), .C(n18), .Y(INT_OUT[7]) );
  NOR3X1 U41 ( .A(n16), .B(PRI[0]), .C(n17), .Y(INT_OUT[6]) );
  NOR3X1 U42 ( .A(n18), .B(PRI[1]), .C(n17), .Y(INT_OUT[5]) );
  NOR3X1 U43 ( .A(n17), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[4]) );
  NAND2X1 U44 ( .A(PRI[2]), .B(INT), .Y(n17) );
  NOR3X1 U45 ( .A(n19), .B(n18), .C(n16), .Y(INT_OUT[3]) );
  NOR3X1 U46 ( .A(n19), .B(PRI[0]), .C(n16), .Y(INT_OUT[2]) );
  CLKINVX1 U47 ( .A(PRI[1]), .Y(n16) );
  NOR3X1 U48 ( .A(n19), .B(PRI[1]), .C(n18), .Y(INT_OUT[1]) );
  CLKINVX1 U49 ( .A(PRI[0]), .Y(n18) );
  NOR3X1 U50 ( .A(n19), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  NAND2BX1 U51 ( .AN(PRI[2]), .B(INT), .Y(n19) );
endmodule


module vic_slave_arbiter_priority_decode_1 ( PRI, INT, INT_OUT );
  input [2:0] PRI;
  output [7:0] INT_OUT;
  input INT;
  wire   n16, n17, n18, n19;

  NOR3X1 U40 ( .A(n16), .B(n17), .C(n18), .Y(INT_OUT[7]) );
  NOR3X1 U41 ( .A(n16), .B(PRI[0]), .C(n17), .Y(INT_OUT[6]) );
  NOR3X1 U42 ( .A(n18), .B(PRI[1]), .C(n17), .Y(INT_OUT[5]) );
  NOR3X1 U43 ( .A(n17), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[4]) );
  NAND2X1 U44 ( .A(PRI[2]), .B(INT), .Y(n17) );
  NOR3X1 U45 ( .A(n19), .B(n18), .C(n16), .Y(INT_OUT[3]) );
  NOR3X1 U46 ( .A(n19), .B(PRI[0]), .C(n16), .Y(INT_OUT[2]) );
  CLKINVX1 U47 ( .A(PRI[1]), .Y(n16) );
  NOR3X1 U48 ( .A(n19), .B(PRI[1]), .C(n18), .Y(INT_OUT[1]) );
  CLKINVX1 U49 ( .A(PRI[0]), .Y(n18) );
  NOR3X1 U50 ( .A(n19), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  NAND2BX1 U51 ( .AN(PRI[2]), .B(INT), .Y(n19) );
endmodule


module vic_slave_arbiter_priority_decode_0 ( PRI, INT, INT_OUT );
  input [2:0] PRI;
  output [7:0] INT_OUT;
  input INT;
  wire   n16, n17, n18, n19;

  NOR3X1 U40 ( .A(n16), .B(n17), .C(n18), .Y(INT_OUT[7]) );
  NOR3X1 U41 ( .A(n16), .B(PRI[0]), .C(n17), .Y(INT_OUT[6]) );
  NOR3X1 U42 ( .A(n18), .B(PRI[1]), .C(n17), .Y(INT_OUT[5]) );
  NOR3X1 U43 ( .A(n17), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[4]) );
  NAND2X1 U44 ( .A(PRI[2]), .B(INT), .Y(n17) );
  NOR3X1 U45 ( .A(n19), .B(n18), .C(n16), .Y(INT_OUT[3]) );
  NOR3X1 U46 ( .A(n19), .B(PRI[0]), .C(n16), .Y(INT_OUT[2]) );
  CLKINVX1 U47 ( .A(PRI[1]), .Y(n16) );
  NOR3X1 U48 ( .A(n19), .B(PRI[1]), .C(n18), .Y(INT_OUT[1]) );
  CLKINVX1 U49 ( .A(PRI[0]), .Y(n18) );
  NOR3X1 U50 ( .A(n19), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  NAND2BX1 U51 ( .AN(PRI[2]), .B(INT), .Y(n19) );
endmodule

