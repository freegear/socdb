
module vic_master_arbiter ( FIXED_MODE, INTPEND, ISPR_OUT, INTERRUPT_OUT, PMST, 
        CMST, NEXTCMST );
  input [3:0] INTPEND;
  output [3:0] ISPR_OUT;
  input [7:0] PMST;
  input [7:0] CMST;
  output [7:0] NEXTCMST;
  input FIXED_MODE;
  output INTERRUPT_OUT;
  wire   reordered_int_0_, highest_priority_int_1_, highest_priority_int_2_,
         highest_priority_int_3_, n95, n96, n97, n98, n99, n100, n101, n102,
         n103, n104, n105, n106, n107, n108, n109, n110, n111, n112, n113,
         n114, n115, n116, n117, n118, n119, n120, n121, n122, n123, n124,
         n125, n126, n127, n128, n129, n130, n131, n132, n133, n134;
  wire   [1:0] priority0;
  wire   [1:0] priority1;
  wire   [1:0] priority2;
  wire   [1:0] priority3;
  wire   [3:0] int0;
  wire   [3:0] int1;
  wire   [3:0] int2;
  wire   [3:0] int3;

  vic_master_arbiter_priority_decode_3 int0_decode ( .PRI(priority0), .INT(
        INTPEND[0]), .INT_OUT(int0) );
  vic_master_arbiter_priority_decode_2 int1_decode ( .PRI(priority1), .INT(
        INTPEND[1]), .INT_OUT(int1) );
  vic_master_arbiter_priority_decode_1 int2_decode ( .PRI(priority2), .INT(
        INTPEND[2]), .INT_OUT(int2) );
  vic_master_arbiter_priority_decode_0 int3_decode ( .PRI(priority3), .INT(
        INTPEND[3]), .INT_OUT(int3) );
  vic_master_arbiter_4to1_mux_3 reorder_bit0 ( .SEL(priority0), .INPUT0({
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[0]) );
  vic_master_arbiter_4to1_mux_2 reorder_bit1 ( .SEL(priority1), .INPUT0({
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[1]) );
  vic_master_arbiter_4to1_mux_1 reorder_bit2 ( .SEL(priority2), .INPUT0({
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[2]) );
  vic_master_arbiter_4to1_mux_0 reorder_bit3 ( .SEL(priority3), .INPUT0({
        highest_priority_int_3_, highest_priority_int_2_, 
        highest_priority_int_1_, reordered_int_0_}), .OUTPUT0(ISPR_OUT[3]) );
  OA22X1 U165 ( .A0(PMST[7]), .A1(n95), .B0(CMST[7]), .B1(FIXED_MODE), .Y(
        priority3[1]) );
  OAI22XL U166 ( .A0(n96), .A1(FIXED_MODE), .B0(n97), .B1(n95), .Y(
        priority3[0]) );
  OA22X1 U167 ( .A0(PMST[5]), .A1(n95), .B0(CMST[5]), .B1(FIXED_MODE), .Y(
        priority2[1]) );
  OAI22XL U168 ( .A0(n98), .A1(FIXED_MODE), .B0(n99), .B1(n95), .Y(
        priority2[0]) );
  OA22X1 U169 ( .A0(PMST[3]), .A1(n95), .B0(CMST[3]), .B1(FIXED_MODE), .Y(
        priority1[1]) );
  OAI22XL U170 ( .A0(n100), .A1(FIXED_MODE), .B0(n101), .B1(n95), .Y(
        priority1[0]) );
  OA22X1 U171 ( .A0(PMST[1]), .A1(n95), .B0(CMST[1]), .B1(FIXED_MODE), .Y(
        priority0[1]) );
  OAI22XL U172 ( .A0(n102), .A1(FIXED_MODE), .B0(n103), .B1(n95), .Y(
        priority0[0]) );
  OAI2BB1X1 U173 ( .A0N(FIXED_MODE), .A1N(PMST[7]), .B0(n104), .Y(NEXTCMST[7])
         );
  MXI2X1 U174 ( .S0(n107), .B(n106), .A(n105), .Y(n104) );
  XOR2X1 U175 ( .A(CMST[7]), .B(n108), .Y(n107) );
  NOR2X1 U176 ( .A(CMST[6]), .B(n109), .Y(n106) );
  OAI21XL U177 ( .A0(FIXED_MODE), .A1(n96), .B0(n110), .Y(n105) );
  OAI21XL U178 ( .A0(n95), .A1(n97), .B0(n111), .Y(NEXTCMST[6]) );
  OAI22XL U179 ( .A0(n112), .A1(CMST[6]), .B0(n113), .B1(n96), .Y(n111) );
  CLKINVX1 U180 ( .A(CMST[6]), .Y(n96) );
  CLKINVX1 U181 ( .A(PMST[6]), .Y(n97) );
  OAI2BB1X1 U182 ( .A0N(FIXED_MODE), .A1N(PMST[5]), .B0(n114), .Y(NEXTCMST[5])
         );
  MXI2X1 U183 ( .S0(n117), .B(n116), .A(n115), .Y(n114) );
  XOR2X1 U184 ( .A(CMST[5]), .B(n108), .Y(n117) );
  NOR2X1 U185 ( .A(CMST[4]), .B(n109), .Y(n116) );
  OAI21XL U186 ( .A0(FIXED_MODE), .A1(n98), .B0(n110), .Y(n115) );
  OAI21XL U187 ( .A0(n95), .A1(n99), .B0(n118), .Y(NEXTCMST[4]) );
  OAI22XL U188 ( .A0(n112), .A1(CMST[4]), .B0(n113), .B1(n98), .Y(n118) );
  CLKINVX1 U189 ( .A(CMST[4]), .Y(n98) );
  CLKINVX1 U190 ( .A(PMST[4]), .Y(n99) );
  OAI2BB1X1 U191 ( .A0N(FIXED_MODE), .A1N(PMST[3]), .B0(n119), .Y(NEXTCMST[3])
         );
  MXI2X1 U192 ( .S0(n122), .B(n121), .A(n120), .Y(n119) );
  XOR2X1 U193 ( .A(CMST[3]), .B(n108), .Y(n122) );
  NOR2X1 U194 ( .A(CMST[2]), .B(n109), .Y(n121) );
  OAI21XL U195 ( .A0(FIXED_MODE), .A1(n100), .B0(n110), .Y(n120) );
  OAI21XL U196 ( .A0(n95), .A1(n101), .B0(n123), .Y(NEXTCMST[2]) );
  OAI22XL U197 ( .A0(n112), .A1(CMST[2]), .B0(n113), .B1(n100), .Y(n123) );
  CLKINVX1 U198 ( .A(CMST[2]), .Y(n100) );
  CLKINVX1 U199 ( .A(PMST[2]), .Y(n101) );
  OAI2BB1X1 U200 ( .A0N(FIXED_MODE), .A1N(PMST[1]), .B0(n124), .Y(NEXTCMST[1])
         );
  MXI2X1 U201 ( .S0(n127), .B(n126), .A(n125), .Y(n124) );
  XOR2X1 U202 ( .A(CMST[1]), .B(n108), .Y(n127) );
  NOR2X1 U203 ( .A(highest_priority_int_2_), .B(highest_priority_int_3_), .Y(
        n108) );
  NOR3X1 U204 ( .A(n128), .B(reordered_int_0_), .C(n129), .Y(
        highest_priority_int_2_) );
  NOR2X1 U205 ( .A(CMST[0]), .B(n109), .Y(n126) );
  CLKINVX1 U206 ( .A(n112), .Y(n109) );
  OAI21XL U207 ( .A0(FIXED_MODE), .A1(n102), .B0(n110), .Y(n125) );
  OAI21XL U208 ( .A0(n95), .A1(n103), .B0(n130), .Y(NEXTCMST[0]) );
  OAI22XL U209 ( .A0(n112), .A1(CMST[0]), .B0(n113), .B1(n102), .Y(n130) );
  CLKINVX1 U210 ( .A(CMST[0]), .Y(n102) );
  CLKINVX1 U211 ( .A(n110), .Y(n113) );
  NAND2X1 U212 ( .A(n131), .B(n95), .Y(n110) );
  NOR2X1 U213 ( .A(n131), .B(FIXED_MODE), .Y(n112) );
  NOR2X1 U214 ( .A(highest_priority_int_1_), .B(highest_priority_int_3_), .Y(
        n131) );
  NOR2X1 U215 ( .A(n132), .B(reordered_int_0_), .Y(highest_priority_int_1_) );
  CLKINVX1 U216 ( .A(PMST[0]), .Y(n103) );
  CLKINVX1 U217 ( .A(FIXED_MODE), .Y(n95) );
  NAND2BX1 U218 ( .AN(highest_priority_int_3_), .B(n133), .Y(INTERRUPT_OUT) );
  NOR2BX1 U219 ( .AN(n133), .B(n134), .Y(highest_priority_int_3_) );
  NOR4X1 U220 ( .A(int3[3]), .B(int2[3]), .C(int1[3]), .D(int0[3]), .Y(n134)
         );
  NOR3BXL U221 ( .AN(n128), .B(reordered_int_0_), .C(n129), .Y(n133) );
  CLKINVX1 U222 ( .A(n132), .Y(n129) );
  NOR4X1 U223 ( .A(int1[1]), .B(int0[1]), .C(int3[1]), .D(int2[1]), .Y(n132)
         );
  OR4X1 U224 ( .A(int1[0]), .B(int0[0]), .C(int3[0]), .D(int2[0]), .Y(
        reordered_int_0_) );
  NOR4X1 U225 ( .A(int1[2]), .B(int0[2]), .C(int3[2]), .D(int2[2]), .Y(n128)
         );
endmodule


module vic_master_arbiter_4to1_mux_3 ( SEL, INPUT0, OUTPUT0 );
  input [1:0] SEL;
  input [3:0] INPUT0;
  output OUTPUT0;


  MX4X1 U15 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(OUTPUT0) );
endmodule


module vic_master_arbiter_4to1_mux_2 ( SEL, INPUT0, OUTPUT0 );
  input [1:0] SEL;
  input [3:0] INPUT0;
  output OUTPUT0;


  MX4X1 U15 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(OUTPUT0) );
endmodule


module vic_master_arbiter_4to1_mux_1 ( SEL, INPUT0, OUTPUT0 );
  input [1:0] SEL;
  input [3:0] INPUT0;
  output OUTPUT0;


  MX4X1 U15 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(OUTPUT0) );
endmodule


module vic_master_arbiter_4to1_mux_0 ( SEL, INPUT0, OUTPUT0 );
  input [1:0] SEL;
  input [3:0] INPUT0;
  output OUTPUT0;


  MX4X1 U15 ( .S1(SEL[0]), .S0(SEL[1]), .D(INPUT0[3]), .C(INPUT0[1]), .B(
        INPUT0[2]), .A(INPUT0[0]), .Y(OUTPUT0) );
endmodule


module vic_master_arbiter_priority_decode_3 ( PRI, INT, INT_OUT );
  input [1:0] PRI;
  output [3:0] INT_OUT;
  input INT;
  wire   n9, n10, n11;

  NOR3X1 U21 ( .A(n9), .B(n10), .C(n11), .Y(INT_OUT[3]) );
  NOR3X1 U22 ( .A(n9), .B(PRI[0]), .C(n10), .Y(INT_OUT[2]) );
  CLKINVX1 U23 ( .A(PRI[1]), .Y(n9) );
  NOR3X1 U24 ( .A(n11), .B(PRI[1]), .C(n10), .Y(INT_OUT[1]) );
  CLKINVX1 U25 ( .A(PRI[0]), .Y(n11) );
  NOR3X1 U26 ( .A(n10), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  CLKINVX1 U27 ( .A(INT), .Y(n10) );
endmodule


module vic_master_arbiter_priority_decode_2 ( PRI, INT, INT_OUT );
  input [1:0] PRI;
  output [3:0] INT_OUT;
  input INT;
  wire   n9, n10, n11;

  NOR3X1 U21 ( .A(n9), .B(n10), .C(n11), .Y(INT_OUT[3]) );
  NOR3X1 U22 ( .A(n9), .B(PRI[0]), .C(n10), .Y(INT_OUT[2]) );
  CLKINVX1 U23 ( .A(PRI[1]), .Y(n9) );
  NOR3X1 U24 ( .A(n11), .B(PRI[1]), .C(n10), .Y(INT_OUT[1]) );
  CLKINVX1 U25 ( .A(PRI[0]), .Y(n11) );
  NOR3X1 U26 ( .A(n10), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  CLKINVX1 U27 ( .A(INT), .Y(n10) );
endmodule


module vic_master_arbiter_priority_decode_1 ( PRI, INT, INT_OUT );
  input [1:0] PRI;
  output [3:0] INT_OUT;
  input INT;
  wire   n9, n10, n11;

  NOR3X1 U21 ( .A(n9), .B(n10), .C(n11), .Y(INT_OUT[3]) );
  NOR3X1 U22 ( .A(n9), .B(PRI[0]), .C(n10), .Y(INT_OUT[2]) );
  CLKINVX1 U23 ( .A(PRI[1]), .Y(n9) );
  NOR3X1 U24 ( .A(n11), .B(PRI[1]), .C(n10), .Y(INT_OUT[1]) );
  CLKINVX1 U25 ( .A(PRI[0]), .Y(n11) );
  NOR3X1 U26 ( .A(n10), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  CLKINVX1 U27 ( .A(INT), .Y(n10) );
endmodule


module vic_master_arbiter_priority_decode_0 ( PRI, INT, INT_OUT );
  input [1:0] PRI;
  output [3:0] INT_OUT;
  input INT;
  wire   n9, n10, n11;

  NOR3X1 U21 ( .A(n9), .B(n10), .C(n11), .Y(INT_OUT[3]) );
  NOR3X1 U22 ( .A(n9), .B(PRI[0]), .C(n10), .Y(INT_OUT[2]) );
  CLKINVX1 U23 ( .A(PRI[1]), .Y(n9) );
  NOR3X1 U24 ( .A(n11), .B(PRI[1]), .C(n10), .Y(INT_OUT[1]) );
  CLKINVX1 U25 ( .A(PRI[0]), .Y(n11) );
  NOR3X1 U26 ( .A(n10), .B(PRI[1]), .C(PRI[0]), .Y(INT_OUT[0]) );
  CLKINVX1 U27 ( .A(INT), .Y(n10) );
endmodule

