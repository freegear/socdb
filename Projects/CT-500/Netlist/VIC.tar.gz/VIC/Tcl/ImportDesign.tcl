#read_verilog ./Net/vic_slave_arbiter.v
#read_verilog ./Net/vic_master_arbiter.v
read_verilog vic_slave_arbiter.v
read_verilog vic_master_arbiter.v
read_verilog VIC.v

set TopDesign VIC
