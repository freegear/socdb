analyze -f verilog -lib WORK ../../rtl/DMA2D/Dma2DCtrl.v
analyze -f verilog -lib WORK ../../rtl/DMA2D/Dma2DFifo.v
analyze -f verilog -lib WORK ../../rtl/DMA2D/Dma2DReg.v
analyze -f verilog -lib WORK ../../rtl/DMA2D/Dma2D.v

elaborate $TopDesign -lib WORK
