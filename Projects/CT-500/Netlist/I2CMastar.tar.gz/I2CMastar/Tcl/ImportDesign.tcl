analyze -f verilog -lib WORK ../Rtl/I2CClkCtrl.v
analyze -f verilog -lib WORK ../Rtl/I2CDetect.v
analyze -f verilog -lib WORK ../Rtl/I2CLoClk.v
analyze -f verilog -lib WORK ../Rtl/I2CRegIF.v
analyze -f verilog -lib WORK ../Rtl/I2CShift.v
analyze -f verilog -lib WORK ../Rtl/I2CTop.v

elaborate $TopDesign -lib WORK
