
module I2CTop ( PCLK, PRESETn, PENABLE, PSEL, PWRITE, PADDR, PWDATA, PRDATA, 
        int, SCL_i, SCL_o, nSCL_En, SDA_i, SDA_o, nSDA_En );
  input [1:0] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  input PCLK, PRESETn, PENABLE, PSEL, PWRITE, SCL_i, SDA_i;
  output int, SCL_o, nSCL_En, SDA_o, nSDA_En;
  wire   BusyDet, StopDet, ArbitLostDet, AckValue, TxCompInt, AckEn,
         IntPendFlag, IntPendClr, OpMode, Start, Stop, StartDet, SW_RST,
         WaitCnt, CntRst, SCLWait, CntIsZero, RepeatStart, SendStop,
         ArbitCheck, DSCL_in, DDSCL_in, DSCL_o, ReadUpd, WriteUpd, ClkEn, n_2;
  wire   [11:0] TxClkVal;
  wire   [7:0] IDSRo;
  wire   [7:0] ReadData;
  assign SDA_o = 1'b0;
  assign SCL_o = 1'b0;

  I2CRegIF I2CReg ( .PCLK(PCLK), .PRESETn(PRESETn), .PENABLE(PENABLE), .PSEL(
        PSEL), .PWRITE(PWRITE), .PADDR(PADDR), .PWDATA(PWDATA), .PRDATA(PRDATA), .BusyDet(BusyDet), .StopDet(StopDet), .ArbitLostDet(ArbitLostDet), 
        .TxCompInt(TxCompInt), .AckValue(AckValue), .AckEn(AckEn), 
        .IntPendFlag(IntPendFlag), .IntPendClr(IntPendClr), .TxClkVal(TxClkVal), .OpMode(OpMode), .Start(Start), .Stop(Stop), .StartClr(StartDet), .StopClr(
        StopDet), .IDSRo(IDSRo), .ReadData(ReadData), .SW_RST(SW_RST), .int(
        int) );
  I2CLoClk FsModeClock ( .PCLK(PCLK), .PRESETn(PRESETn), .SW_RST(SW_RST), 
        .Start(Start), .IntPendFlag(IntPendFlag), .StopDet(StopDet), 
        .BusErrorDet(1'b0), .ArbitLostDet(ArbitLostDet), .TxPre(TxClkVal), 
        .WaitCnt(WaitCnt), .CntRst(CntRst), .SCLWait(SCLWait), .CntIsZero(
        CntIsZero), .RepeatStart(RepeatStart), .SendStop(SendStop), .out_clk(
        nSCL_En) );
  I2CDetect I2CDetect ( .PCLK(PCLK), .PRESETn(PRESETn), .SW_RST(SW_RST), 
        .ArbitCheck(ArbitCheck), .SCL_i(SCL_i), .SDA_i(SDA_i), .SCL_o(nSCL_En), 
        .SDA_o(nSDA_En), .DSCL(DSCL_in), .DDSCL(DDSCL_in), .DSCL_o(DSCL_o), 
        .BusyDet(BusyDet), .StartDet(StartDet), .StopDet(StopDet), 
        .ArbitLostDet(ArbitLostDet) );
  I2CClkCtrl I2CClkCtrl ( .PCLK(PCLK), .PRESETn(PRESETn), .SW_RST(SW_RST), 
        .StartDet(StartDet), .StopDet(StopDet), .ArbitLostDet(ArbitLostDet), 
        .DSCL_in(DSCL_in), .DDSCL_in(DDSCL_in), .DSCL_o(DSCL_o), .ReadUpd(
        ReadUpd), .WriteUpd(WriteUpd), .WaitCnt(WaitCnt), .CntRst(CntRst), 
        .ClkEn(ClkEn) );
  I2CShift I2CShift ( .PCLK(PCLK), .PRESETn(PRESETn), .SW_RST(SW_RST), .AckEn(
        AckEn), .OpMode(OpMode), .Start(Start), .Stop(Stop), .IntPendFlag(
        IntPendFlag), .DataTrans(n_2), .StartDet(StartDet), .ArbitLostDet(
        ArbitLostDet), .ClkEn(ClkEn), .IDSRo(IDSRo), .ReadData(ReadData), 
        .AckValue(AckValue), .ReadUpd(ReadUpd), .WriteUpd(WriteUpd), .SCLWait(
        SCLWait), .CntIsZero(CntIsZero), .TxCompInt(TxCompInt), .RepeatStart(
        RepeatStart), .SendStop(SendStop), .ArbitCheck(ArbitCheck), .SDA_IN(
        SDA_i), .nSDA_En(nSDA_En) );
  AND2X2 U8 ( .A(IntPendFlag), .B(IntPendClr), .Y(n_2) );
endmodule


module I2CShift ( PCLK, PRESETn, SW_RST, AckEn, OpMode, Start, Stop, 
        IntPendFlag, DataTrans, StartDet, ArbitLostDet, ClkEn, IDSRo, ReadData, 
        AckValue, ReadUpd, WriteUpd, SCLWait, CntIsZero, TxCompInt, 
        RepeatStart, SendStop, ArbitCheck, SDA_IN, nSDA_En );
  input [7:0] IDSRo;
  output [7:0] ReadData;
  input PCLK, PRESETn, SW_RST, AckEn, OpMode, Start, Stop, IntPendFlag,
         DataTrans, StartDet, ArbitLostDet, ClkEn, ReadUpd, WriteUpd,
         CntIsZero, SDA_IN;
  output AckValue, SCLWait, TxCompInt, RepeatStart, SendStop, ArbitCheck,
         nSDA_En;
  wire   C_state_9_, C_state_8_, C_state_6_, C_state_5_, C_state_4_,
         C_state_3_, C_state_2_, C_state_1_, C_state_0_, C_state181_9_,
         C_state181_8_, C_state181_7_, C_state181_6_, C_state181_5_,
         C_state181_4_, C_state181_3_, C_state181_1_, C_state181_0_,
         nSDA_En355, n728, n729, n730, n731, n732, n733, n734, n735, n736,
         n737, n738, n739, n740, n741, n742, n743, n744, n745, n746, n747,
         n748, n749, n755, n756, n757, n758, n759, n760, n761, n762, n763,
         n764, n765, n767, n769, n770, n771, n772, n773, n774, n775, n776,
         n777, n779, n780, n781, n782, n783, n784, n785, n786, n787, n788,
         n789, n790, n791, n792, n793, n794, n795, n797, n798, n800, n801,
         n802, n804, n805, n807, n808, n810, n811, n812, n813, n814, n815,
         n816, n817, n818, n820, n821, n822, n824, n825, n826, n827, n828,
         n829, n830, n831, n832, n833, n834, n835, n836, n837, n838, n839,
         n840, n841, n844, n845, n846, n847, n848, n849, n850, n851, n852,
         n853, n854, n855, n859, n860, n861, n864, n865, n866, n867, n868,
         n869, n870, n872, n873, n875, n877, n878, n879, n880, n881, n882,
         n883, n884, n885, n886, n887, n888, n889, n890, n892, n893;
  wire   [3:0] ByteCnt;
  wire   [8:0] DataShiftReg;

  INVX1 U560 ( .A(n772), .Y(n773) );
  INVX1 U561 ( .A(n777), .Y(n783) );
  INVX1 U562 ( .A(n779), .Y(n780) );
  INVX1 U563 ( .A(n775), .Y(n782) );
  INVX1 U564 ( .A(n797), .Y(n795) );
  INVX1 U565 ( .A(n807), .Y(n794) );
  INVX1 U566 ( .A(n854), .Y(n859) );
  INVX1 U567 ( .A(n824), .Y(TxCompInt) );
  NAND2BX1 U568 ( .AN(n825), .B(n774), .Y(n824) );
  INVX1 U569 ( .A(WriteUpd), .Y(n825) );
  INVX1 U570 ( .A(CntIsZero), .Y(n847) );
  NAND2BX1 U571 ( .AN(n774), .B(C_state181_5_), .Y(n772) );
  NAND3BX1 U572 ( .AN(n780), .B(n791), .C(n792), .Y(n777) );
  OR2X1 U573 ( .A(ReadUpd), .B(n808), .Y(n807) );
  NAND2BX1 U574 ( .AN(n808), .B(n807), .Y(n797) );
  AO21X1 U575 ( .A0(n795), .A1(n885), .B0(n794), .Y(n800) );
  AO21X1 U576 ( .A0(n792), .A1(n791), .B0(n780), .Y(n775) );
  OAI221X1 U577 ( .A0(n793), .A1(n764), .B0(n793), .B1(n792), .C0(n791), .Y(
        n779) );
  AO21X1 U578 ( .A0(n795), .A1(n882), .B0(n800), .Y(n801) );
  INVX1 U579 ( .A(DataTrans), .Y(n791) );
  INVX1 U580 ( .A(n813), .Y(n818) );
  NAND4BX1 U581 ( .AN(n760), .B(n878), .C(n865), .D(n881), .Y(n875) );
  NAND4BX1 U582 ( .AN(n873), .B(n878), .C(n884), .D(n893), .Y(n854) );
  INVX1 U583 ( .A(n840), .Y(SCLWait) );
  INVX1 U584 ( .A(n848), .Y(RepeatStart) );
  INVX1 U585 ( .A(n866), .Y(n835) );
  INVX1 U586 ( .A(n756), .Y(n865) );
  INVX1 U587 ( .A(n771), .Y(n774) );
  INVX1 U588 ( .A(n821), .Y(n872) );
  OAI221X1 U589 ( .A0(n886), .A1(n892), .B0(n765), .B1(n893), .C0(n878), .Y(
        n762) );
  INVX1 U590 ( .A(n760), .Y(n834) );
  INVX1 U591 ( .A(n873), .Y(n765) );
  OAI211X1 U592 ( .A0(n880), .A1(n887), .B0(n852), .C0(n853), .Y(n851) );
  OA22X1 U593 ( .A0(n765), .A1(n884), .B0(n834), .B1(n859), .Y(n852) );
  INVX1 U594 ( .A(n759), .Y(n853) );
  INVX1 U595 ( .A(n837), .Y(n793) );
  INVX1 U596 ( .A(n828), .Y(n832) );
  NAND3BX1 U597 ( .AN(n810), .B(n811), .C(ClkEn), .Y(n808) );
  NAND3BX1 U598 ( .AN(StartDet), .B(n791), .C(n812), .Y(n810) );
  NAND3BX1 U599 ( .AN(n882), .B(ByteCnt[0]), .C(n795), .Y(n804) );
  OAI32X1 U600 ( .A0(n826), .A1(n827), .A2(n828), .B0(n818), .B1(n893), .Y(
        C_state181_5_) );
  NAND2BX1 U601 ( .AN(SW_RST), .B(WriteUpd), .Y(n827) );
  AO21X1 U602 ( .A0(n780), .A1(DataShiftReg[8]), .B0(n790), .Y(n732) );
  AO22X1 U603 ( .A0(IDSRo[7]), .A1(n782), .B0(n783), .B1(DataShiftReg[7]), .Y(
        n790) );
  AO21X1 U604 ( .A0(n780), .A1(DataShiftReg[7]), .B0(n789), .Y(n733) );
  AO22X1 U605 ( .A0(IDSRo[6]), .A1(n782), .B0(n783), .B1(DataShiftReg[6]), .Y(
        n789) );
  AO21X1 U606 ( .A0(n780), .A1(DataShiftReg[6]), .B0(n788), .Y(n734) );
  AO22X1 U607 ( .A0(IDSRo[5]), .A1(n782), .B0(n783), .B1(DataShiftReg[5]), .Y(
        n788) );
  AO21X1 U608 ( .A0(n780), .A1(DataShiftReg[5]), .B0(n787), .Y(n735) );
  AO22X1 U609 ( .A0(IDSRo[4]), .A1(n782), .B0(n783), .B1(DataShiftReg[4]), .Y(
        n787) );
  AO21X1 U610 ( .A0(n780), .A1(DataShiftReg[4]), .B0(n786), .Y(n736) );
  AO22X1 U611 ( .A0(IDSRo[3]), .A1(n782), .B0(n783), .B1(DataShiftReg[3]), .Y(
        n786) );
  AO21X1 U612 ( .A0(n780), .A1(DataShiftReg[3]), .B0(n785), .Y(n737) );
  AO22X1 U613 ( .A0(IDSRo[2]), .A1(n782), .B0(n783), .B1(DataShiftReg[2]), .Y(
        n785) );
  AO21X1 U614 ( .A0(n780), .A1(DataShiftReg[2]), .B0(n784), .Y(n738) );
  AO22X1 U615 ( .A0(IDSRo[1]), .A1(n782), .B0(n783), .B1(DataShiftReg[1]), .Y(
        n784) );
  AO21X1 U616 ( .A0(n780), .A1(DataShiftReg[1]), .B0(n781), .Y(n739) );
  AO22X1 U617 ( .A0(IDSRo[0]), .A1(n782), .B0(n783), .B1(DataShiftReg[0]), .Y(
        n781) );
  OAI222X1 U618 ( .A0(AckEn), .A1(n775), .B0(n776), .B1(n777), .C0(n890), .C1(
        n779), .Y(n740) );
  INVX1 U619 ( .A(SDA_IN), .Y(n776) );
  AO22X1 U620 ( .A0(C_state_9_), .A1(n813), .B0(n814), .B1(SendStop), .Y(
        C_state181_9_) );
  INVX1 U621 ( .A(n815), .Y(n814) );
  AO22X1 U622 ( .A0(ByteCnt[2]), .A1(n801), .B0(n802), .B1(n883), .Y(n729) );
  INVX1 U623 ( .A(n804), .Y(n802) );
  AO22X1 U624 ( .A0(ByteCnt[0]), .A1(n794), .B0(n795), .B1(n885), .Y(n731) );
  AO22X1 U625 ( .A0(ReadData[7]), .A1(n772), .B0(DataShiftReg[7]), .B1(n773), 
        .Y(n741) );
  AO22X1 U626 ( .A0(ReadData[6]), .A1(n772), .B0(DataShiftReg[6]), .B1(n773), 
        .Y(n742) );
  AO22X1 U627 ( .A0(ReadData[5]), .A1(n772), .B0(DataShiftReg[5]), .B1(n773), 
        .Y(n743) );
  AO22X1 U628 ( .A0(ReadData[4]), .A1(n772), .B0(DataShiftReg[4]), .B1(n773), 
        .Y(n744) );
  AO22X1 U629 ( .A0(ReadData[3]), .A1(n772), .B0(DataShiftReg[3]), .B1(n773), 
        .Y(n745) );
  AO22X1 U630 ( .A0(ReadData[2]), .A1(n772), .B0(DataShiftReg[2]), .B1(n773), 
        .Y(n746) );
  AO22X1 U631 ( .A0(ReadData[1]), .A1(n772), .B0(DataShiftReg[1]), .B1(n773), 
        .Y(n747) );
  AO22X1 U632 ( .A0(ReadData[0]), .A1(n772), .B0(DataShiftReg[0]), .B1(n773), 
        .Y(n748) );
  AO22X1 U633 ( .A0(TxCompInt), .A1(n812), .B0(C_state_6_), .B1(n813), .Y(
        C_state181_6_) );
  OAI32X1 U634 ( .A0(n797), .A1(ByteCnt[1]), .A2(n885), .B0(n798), .B1(n882), 
        .Y(n730) );
  INVX1 U635 ( .A(n800), .Y(n798) );
  OAI32X1 U636 ( .A0(n840), .A1(n791), .A2(n841), .B0(n818), .B1(n880), .Y(
        C_state181_1_) );
  NAND2BX1 U637 ( .AN(SW_RST), .B(Start), .Y(n841) );
  OAI32X1 U638 ( .A0(n816), .A1(SW_RST), .A2(n817), .B0(n818), .B1(n886), .Y(
        C_state181_8_) );
  AO21X1 U639 ( .A0(ByteCnt[3]), .A1(n801), .B0(n805), .Y(n728) );
  OAI33X1 U640 ( .A0(n797), .A1(ByteCnt[2]), .A2(n888), .B0(n804), .B1(
        ByteCnt[3]), .B2(n883), .Y(n805) );
  OAI211X1 U641 ( .A0(n818), .A1(n887), .B0(n844), .C0(n845), .Y(C_state181_0_) );
  AOI222X1 U642 ( .A0(n846), .A1(n847), .B0(n756), .B1(n760), .C0(RepeatStart), 
        .C1(CntIsZero), .Y(n845) );
  AOI211X1 U643 ( .A0(ArbitLostDet), .A1(n849), .B0(n850), .C0(n851), .Y(n844)
         );
  INVX1 U644 ( .A(n820), .Y(n846) );
  OAI32X1 U645 ( .A0(n866), .A1(C_state_1_), .A2(n867), .B0(SW_RST), .B1(n868), 
        .Y(n813) );
  INVX1 U646 ( .A(IntPendFlag), .Y(n867) );
  AOI221X1 U647 ( .A0(n774), .A1(n825), .B0(SCLWait), .B1(n791), .C0(n869), 
        .Y(n868) );
  OA21X2 U648 ( .A0(SendStop), .A1(n870), .B0(n847), .Y(n869) );
  NAND3BX1 U649 ( .AN(Start), .B(DataTrans), .C(SCLWait), .Y(n816) );
  OA21X2 U650 ( .A0(n829), .A1(n830), .B0(n812), .Y(C_state181_4_) );
  OAI31X1 U651 ( .A0(n792), .A1(ArbitLostDet), .A2(n793), .B0(n831), .Y(n829)
         );
  NOR2BX1 U652 ( .AN(n817), .B(n816), .Y(n830) );
  OA22X1 U653 ( .A0(n832), .A1(n826), .B0(WriteUpd), .B1(n826), .Y(n831) );
  NAND4BX1 U654 ( .AN(n875), .B(n884), .C(n765), .D(C_state_5_), .Y(n771) );
  NAND4BX1 U655 ( .AN(C_state_0_), .B(C_state_1_), .C(n865), .D(n835), .Y(n848) );
  NAND3BX1 U656 ( .AN(n873), .B(C_state_6_), .C(n872), .Y(n840) );
  NAND2BX1 U657 ( .AN(C_state_0_), .B(n880), .Y(n760) );
  NAND2BX1 U658 ( .AN(C_state_3_), .B(n879), .Y(n756) );
  NAND2BX1 U659 ( .AN(C_state_8_), .B(n892), .Y(n873) );
  NAND4BX1 U660 ( .AN(C_state_4_), .B(C_state_3_), .C(n834), .D(n835), .Y(n792) );
  NAND2BX1 U661 ( .AN(C_state_2_), .B(n859), .Y(n866) );
  OAI31X1 U662 ( .A0(n866), .A1(n760), .A2(n877), .B0(n792), .Y(n849) );
  NAND2BX1 U663 ( .AN(C_state_3_), .B(C_state_4_), .Y(n877) );
  AND4X1 U664 ( .A(n892), .B(n884), .C(C_state_8_), .D(n872), .Y(SendStop) );
  OR2X1 U665 ( .A(C_state_5_), .B(n875), .Y(n821) );
  OAI31X1 U666 ( .A0(n821), .A1(C_state_8_), .A2(C_state_6_), .B0(n848), .Y(
        n870) );
  AND2X2 U667 ( .A(OpMode), .B(n849), .Y(ArbitCheck) );
  NAND3BX1 U668 ( .AN(n864), .B(n865), .C(n835), .Y(n820) );
  NAND3BX1 U669 ( .AN(IntPendFlag), .B(n880), .C(C_state_0_), .Y(n864) );
  NAND3BX1 U670 ( .AN(n836), .B(ClkEn), .C(ByteCnt[3]), .Y(n828) );
  NAND3BX1 U671 ( .AN(ByteCnt[2]), .B(n882), .C(n885), .Y(n836) );
  NAND2BX1 U672 ( .AN(SW_RST), .B(CntIsZero), .Y(n815) );
  AO22X1 U673 ( .A0(WriteUpd), .A1(OpMode), .B0(ReadUpd), .B1(n763), .Y(n837)
         );
  AO21X1 U674 ( .A0(n854), .A1(n756), .B0(n855), .Y(n759) );
  OAI211X1 U675 ( .A0(n889), .A1(n879), .B0(n881), .C0(n812), .Y(n855) );
  NAND3BX1 U676 ( .AN(n833), .B(n834), .C(n835), .Y(n826) );
  NAND3BX1 U677 ( .AN(C_state_3_), .B(n811), .C(C_state_4_), .Y(n833) );
  INVX1 U678 ( .A(SW_RST), .Y(n812) );
  INVX1 U679 ( .A(ArbitLostDet), .Y(n811) );
  AO22X1 U680 ( .A0(AckValue), .A1(n769), .B0(SDA_IN), .B1(n770), .Y(n749) );
  INVX1 U681 ( .A(n769), .Y(n770) );
  NAND3BX1 U682 ( .AN(n771), .B(OpMode), .C(ReadUpd), .Y(n769) );
  INVX1 U683 ( .A(OpMode), .Y(n763) );
  OAI33X1 U684 ( .A0(n792), .A1(n838), .A2(n837), .B0(n820), .B1(n839), .B2(
        n815), .Y(C_state181_3_) );
  NAND2BX1 U685 ( .AN(Stop), .B(Start), .Y(n839) );
  NAND2BX1 U686 ( .AN(SW_RST), .B(n811), .Y(n838) );
  OAI33X1 U687 ( .A0(n820), .A1(n815), .A2(n817), .B0(n821), .B1(n822), .B2(
        n815), .Y(C_state181_7_) );
  NAND3BX1 U688 ( .AN(C_state_8_), .B(n884), .C(C_state_9_), .Y(n822) );
  OAI33X1 U689 ( .A0(n820), .A1(Stop), .A2(Start), .B0(n860), .B1(n760), .B2(
        n756), .Y(n850) );
  NOR2BX1 U690 ( .AN(n861), .B(n762), .Y(n860) );
  AOI32X1 U691 ( .A0(n893), .A1(n884), .A2(n765), .B0(C_state_6_), .B1(
        C_state_5_), .Y(n861) );
  OAI211X1 U692 ( .A0(n755), .A1(n756), .B0(n757), .C0(n758), .Y(nSDA_En355)
         );
  AOI211X1 U693 ( .A0(n765), .A1(n893), .B0(n767), .C0(C_state_6_), .Y(n755)
         );
  NOR2BX1 U694 ( .AN(n761), .B(n762), .Y(n757) );
  AOI211X1 U695 ( .A0(DataShiftReg[8]), .A1(C_state_5_), .B0(n759), .C0(n760), 
        .Y(n758) );
  INVX1 U696 ( .A(ClkEn), .Y(n764) );
  OAI2BB2X1 U697 ( .A0N(C_state_5_), .A1N(OpMode), .B0(n893), .B1(AckEn), .Y(
        n767) );
  OAI31X1 U698 ( .A0(n763), .A1(DataShiftReg[8]), .A2(n764), .B0(C_state_4_), 
        .Y(n761) );
  INVX1 U699 ( .A(Stop), .Y(n817) );
  DFFRX1 C_state_reg_5_ ( .D(C_state181_5_), .CK(PCLK), .RN(PRESETn), .Q(
        C_state_5_), .QN(n893) );
  DFFRX1 C_state_reg_4_ ( .D(C_state181_4_), .CK(PCLK), .RN(PRESETn), .Q(
        C_state_4_), .QN(n879) );
  DFFSX1 C_state_reg_0_ ( .D(C_state181_0_), .CK(PCLK), .SN(PRESETn), .Q(
        C_state_0_), .QN(n887) );
  DFFRX1 C_state_reg_3_ ( .D(C_state181_3_), .CK(PCLK), .RN(PRESETn), .Q(
        C_state_3_), .QN(n889) );
  DFFRX1 C_state_reg_8_ ( .D(C_state181_8_), .CK(PCLK), .RN(PRESETn), .Q(
        C_state_8_), .QN(n886) );
  DFFRX1 C_state_reg_6_ ( .D(C_state181_6_), .CK(PCLK), .RN(PRESETn), .Q(
        C_state_6_), .QN(n884) );
  DFFRX1 C_state_reg_9_ ( .D(C_state181_9_), .CK(PCLK), .RN(PRESETn), .Q(
        C_state_9_), .QN(n892) );
  DFFRX1 C_state_reg_1_ ( .D(C_state181_1_), .CK(PCLK), .RN(PRESETn), .Q(
        C_state_1_), .QN(n880) );
  DFFRX1 C_state_reg_2_ ( .D(1'b0), .CK(PCLK), .RN(PRESETn), .Q(C_state_2_), 
        .QN(n881) );
  DFFRX1 C_state_reg_7_ ( .D(C_state181_7_), .CK(PCLK), .RN(PRESETn), .QN(n878) );
  DFFRX1 ByteCnt_reg_0_ ( .D(n731), .CK(PCLK), .RN(PRESETn), .Q(ByteCnt[0]), 
        .QN(n885) );
  DFFRX1 ByteCnt_reg_2_ ( .D(n729), .CK(PCLK), .RN(PRESETn), .Q(ByteCnt[2]), 
        .QN(n883) );
  DFFRX1 ByteCnt_reg_1_ ( .D(n730), .CK(PCLK), .RN(PRESETn), .Q(ByteCnt[1]), 
        .QN(n882) );
  DFFRX1 ByteCnt_reg_3_ ( .D(n728), .CK(PCLK), .RN(PRESETn), .Q(ByteCnt[3]), 
        .QN(n888) );
  DFFRX1 DataShiftReg_reg_0_ ( .D(n740), .CK(PCLK), .RN(PRESETn), .Q(
        DataShiftReg[0]), .QN(n890) );
  DFFRX1 AckValue_reg ( .D(n749), .CK(PCLK), .RN(PRESETn), .Q(AckValue) );
  DFFRX1 DataShiftReg_reg_7_ ( .D(n733), .CK(PCLK), .RN(PRESETn), .Q(
        DataShiftReg[7]) );
  DFFRX1 DataShiftReg_reg_6_ ( .D(n734), .CK(PCLK), .RN(PRESETn), .Q(
        DataShiftReg[6]) );
  DFFRX1 DataShiftReg_reg_5_ ( .D(n735), .CK(PCLK), .RN(PRESETn), .Q(
        DataShiftReg[5]) );
  DFFRX1 DataShiftReg_reg_4_ ( .D(n736), .CK(PCLK), .RN(PRESETn), .Q(
        DataShiftReg[4]) );
  DFFRX1 DataShiftReg_reg_3_ ( .D(n737), .CK(PCLK), .RN(PRESETn), .Q(
        DataShiftReg[3]) );
  DFFRX1 DataShiftReg_reg_2_ ( .D(n738), .CK(PCLK), .RN(PRESETn), .Q(
        DataShiftReg[2]) );
  DFFRX1 DataShiftReg_reg_1_ ( .D(n739), .CK(PCLK), .RN(PRESETn), .Q(
        DataShiftReg[1]) );
  DFFRX1 ReadData_reg_7_ ( .D(n741), .CK(PCLK), .RN(PRESETn), .Q(ReadData[7])
         );
  DFFRX1 ReadData_reg_6_ ( .D(n742), .CK(PCLK), .RN(PRESETn), .Q(ReadData[6])
         );
  DFFRX1 ReadData_reg_5_ ( .D(n743), .CK(PCLK), .RN(PRESETn), .Q(ReadData[5])
         );
  DFFRX1 ReadData_reg_4_ ( .D(n744), .CK(PCLK), .RN(PRESETn), .Q(ReadData[4])
         );
  DFFRX1 DataShiftReg_reg_8_ ( .D(n732), .CK(PCLK), .RN(PRESETn), .Q(
        DataShiftReg[8]) );
  DFFRX1 ReadData_reg_3_ ( .D(n745), .CK(PCLK), .RN(PRESETn), .Q(ReadData[3])
         );
  DFFRX1 ReadData_reg_2_ ( .D(n746), .CK(PCLK), .RN(PRESETn), .Q(ReadData[2])
         );
  DFFRX1 ReadData_reg_1_ ( .D(n747), .CK(PCLK), .RN(PRESETn), .Q(ReadData[1])
         );
  DFFRX1 ReadData_reg_0_ ( .D(n748), .CK(PCLK), .RN(PRESETn), .Q(ReadData[0])
         );
  DFFSX1 nSDA_En_reg ( .D(nSDA_En355), .CK(PCLK), .SN(PRESETn), .Q(nSDA_En) );
endmodule


module I2CClkCtrl ( PCLK, PRESETn, SW_RST, StartDet, StopDet, ArbitLostDet, 
        DSCL_in, DDSCL_in, DSCL_o, ReadUpd, WriteUpd, WaitCnt, CntRst, ClkEn
 );
  input PCLK, PRESETn, SW_RST, StartDet, StopDet, ArbitLostDet, DSCL_in,
         DDSCL_in, DSCL_o;
  output ReadUpd, WriteUpd, WaitCnt, CntRst, ClkEn;
  wire   n121, n122, n123, n124, n125;

  INVX1 U44 ( .A(n125), .Y(WriteUpd) );
  NAND2BX1 U45 ( .AN(DSCL_in), .B(DDSCL_in), .Y(n125) );
  NOR3BX1 U46 ( .AN(DSCL_o), .B(DSCL_in), .C(DDSCL_in), .Y(WaitCnt) );
  NOR2BX1 U47 ( .AN(DSCL_in), .B(DDSCL_in), .Y(ReadUpd) );
  NOR2BX1 U48 ( .AN(DSCL_o), .B(n125), .Y(CntRst) );
  AO22X1 U49 ( .A0(StartDet), .A1(n122), .B0(n123), .B1(n124), .Y(n121) );
  NOR2BX1 U50 ( .AN(ClkEn), .B(ArbitLostDet), .Y(n123) );
  NOR2BX1 U51 ( .AN(n122), .B(StopDet), .Y(n124) );
  INVX1 U52 ( .A(SW_RST), .Y(n122) );
  DFFRX1 ClkEn_reg ( .D(n121), .CK(PCLK), .RN(PRESETn), .Q(ClkEn) );
endmodule


module I2CDetect ( PCLK, PRESETn, SW_RST, ArbitCheck, SCL_i, SDA_i, SCL_o, 
        SDA_o, DSCL, DDSCL, DSCL_o, BusyDet, StartDet, StopDet, ArbitLostDet
 );
  input PCLK, PRESETn, SW_RST, ArbitCheck, SCL_i, SDA_i, SCL_o, SDA_o;
  output DSCL, DDSCL, DSCL_o, BusyDet, StartDet, StopDet, ArbitLostDet;
  wire   IntSDA, DIntSDA, DSDA_o, SCL_iSync106, SDA_iSync112, IntSCL118,
         IntSDA124, DIntSCL130, DIntSDA136, SCL_oSync219, SDA_oSync225,
         DSCL_o231, DSDA_o237, StartDet300, StopDet306, n430, n431, n432, n433,
         n446, n447, n448, n449, n450, n451, n454, n455, n457, n458, n459,
         n461, n463, n464, n465, n466, n467;

  DFFRX1 StopDet_reg ( .D(StopDet306), .CK(PCLK), .RN(PRESETn), .Q(StopDet), 
        .QN(n466) );
  DFFRX1 ArbitLostDet_reg ( .D(n448), .CK(PCLK), .RN(PRESETn), .Q(ArbitLostDet) );
  INVX1 U182 ( .A(DIntSDA136), .Y(n459) );
  AOI31X1 U183 ( .A0(DSDA_o), .A1(n465), .A2(DSCL), .B0(n457), .Y(n455) );
  INVX1 U184 ( .A(ArbitCheck), .Y(n457) );
  AO22X1 U185 ( .A0(ArbitLostDet), .A1(n449), .B0(n450), .B1(n451), .Y(n448)
         );
  AND4X1 U186 ( .A(n463), .B(n466), .C(ArbitCheck), .D(n454), .Y(n450) );
  INVX1 U187 ( .A(n451), .Y(n449) );
  NAND4BX1 U188 ( .AN(StopDet), .B(n463), .C(n454), .D(n455), .Y(n451) );
  NAND2BX1 U189 ( .AN(IntSDA), .B(n454), .Y(DIntSDA136) );
  INVX1 U190 ( .A(SW_RST), .Y(n454) );
  NAND2BX1 U191 ( .AN(DSCL), .B(n454), .Y(DIntSCL130) );
  NAND2BX1 U192 ( .AN(SDA_i), .B(n454), .Y(SDA_iSync112) );
  NAND2BX1 U193 ( .AN(SCL_i), .B(n454), .Y(SCL_iSync106) );
  NAND2BX1 U194 ( .AN(SDA_o), .B(n454), .Y(SDA_oSync225) );
  NAND2BX1 U195 ( .AN(SCL_o), .B(n454), .Y(SCL_oSync219) );
  NAND2BX1 U196 ( .AN(SW_RST), .B(n430), .Y(DSDA_o237) );
  NAND2BX1 U197 ( .AN(SW_RST), .B(n431), .Y(DSCL_o231) );
  NAND2BX1 U198 ( .AN(SW_RST), .B(n432), .Y(IntSDA124) );
  NAND2BX1 U199 ( .AN(SW_RST), .B(n433), .Y(IntSCL118) );
  AND4X1 U200 ( .A(DIntSDA), .B(DDSCL), .C(DSCL), .D(n459), .Y(StartDet300) );
  AND4X1 U201 ( .A(n467), .B(n454), .C(n461), .D(DSCL), .Y(StopDet306) );
  NOR2BX1 U202 ( .AN(IntSDA), .B(n464), .Y(n461) );
  OAI31X1 U203 ( .A0(SW_RST), .A1(StopDet), .A2(n446), .B0(n458), .Y(n447) );
  NOR2BX1 U204 ( .AN(DIntSCL130), .B(n459), .Y(n458) );
  DFFSX1 DIntSCL_reg ( .D(DIntSCL130), .CK(PCLK), .SN(PRESETn), .Q(DDSCL), 
        .QN(n464) );
  DFFSX1 IntSCL_reg ( .D(IntSCL118), .CK(PCLK), .SN(PRESETn), .Q(DSCL) );
  DFFRX1 StartDet_reg ( .D(StartDet300), .CK(PCLK), .RN(PRESETn), .Q(StartDet), 
        .QN(n463) );
  DFFSX1 DIntSDA_reg ( .D(DIntSDA136), .CK(PCLK), .SN(PRESETn), .Q(DIntSDA), 
        .QN(n467) );
  DFFSX1 IntSDA_reg ( .D(IntSDA124), .CK(PCLK), .SN(PRESETn), .Q(IntSDA), .QN(
        n465) );
  DFFSX1 DSCL_o_reg ( .D(DSCL_o231), .CK(PCLK), .SN(PRESETn), .Q(DSCL_o) );
  DFFRX1 BusyDet_reg ( .D(n447), .CK(PCLK), .RN(PRESETn), .Q(BusyDet), .QN(
        n446) );
  DFFSX1 DSDA_o_reg ( .D(DSDA_o237), .CK(PCLK), .SN(PRESETn), .Q(DSDA_o) );
  DFFSX1 SDA_oSync_reg ( .D(SDA_oSync225), .CK(PCLK), .SN(PRESETn), .QN(n430)
         );
  DFFSX1 SCL_oSync_reg ( .D(SCL_oSync219), .CK(PCLK), .SN(PRESETn), .QN(n431)
         );
  DFFSX1 SDA_iSync_reg ( .D(SDA_iSync112), .CK(PCLK), .SN(PRESETn), .QN(n432)
         );
  DFFSX1 SCL_iSync_reg ( .D(SCL_iSync106), .CK(PCLK), .SN(PRESETn), .QN(n433)
         );
endmodule


module I2CLoClk ( PCLK, PRESETn, SW_RST, Start, IntPendFlag, StopDet, 
        BusErrorDet, ArbitLostDet, TxPre, WaitCnt, CntRst, SCLWait, CntIsZero, 
        RepeatStart, SendStop, out_clk );
  input [11:0] TxPre;
  input PCLK, PRESETn, SW_RST, Start, IntPendFlag, StopDet, BusErrorDet,
         ArbitLostDet, WaitCnt, CntRst, SCLWait, RepeatStart, SendStop;
  output CntIsZero, out_clk;
  wire   CntVal182_11_, CntVal182_10_, CntVal182_9_, CntVal182_8_,
         CntVal182_7_, CntVal182_6_, CntVal182_5_, CntVal182_4_, CntVal182_3_,
         CntVal182_2_, CntVal182_1_, n468, n469, n470, n471, n472, n473, n474,
         n475, n476, n477, n478, n479, n480, carry_11_, carry_10_, carry_9_,
         carry_8_, carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_,
         n482, n483, n484, n485, n486, n487, n488, n489, n490, n491, n492,
         n494, n495, n496, n497, n498, n499, n500, n501, n502, n503, n504,
         n505, n506, n507, n508, n509, n510, n511, n512, n513, n514, n515,
         n516, n517, n518, n519, n520, n521, n523, n524, n526, n528, n529,
         n530, n531, n533, n534, n535, n536, n537, n539, n540, n541, n542,
         n543, n546, n547, n548, n549, n557, n558, n559, n560, n561, n562,
         n563, n564, n565, n566, n567, n568;
  wire   [11:0] CntVal;
  wire   [3:0] State;
  wire   [3:0] NextState;

  INVX1 U313 ( .A(n483), .Y(n487) );
  NAND2BX1 U314 ( .AN(NextState[3]), .B(n490), .Y(n485) );
  OAI31X1 U315 ( .A0(n488), .A1(NextState[3]), .A2(NextState[2]), .B0(n489), 
        .Y(n483) );
  AOI33X1 U316 ( .A0(n488), .A1(NextState[3]), .A2(n490), .B0(n488), .B1(
        NextState[2]), .B2(n491), .Y(n489) );
  INVX1 U317 ( .A(NextState[0]), .Y(n488) );
  INVX1 U318 ( .A(NextState[3]), .Y(n491) );
  INVX1 U319 ( .A(NextState[2]), .Y(n490) );
  INVX1 U320 ( .A(RepeatStart), .Y(n529) );
  INVX1 U321 ( .A(n508), .Y(n495) );
  NAND3BX1 U322 ( .AN(n535), .B(n536), .C(CntIsZero), .Y(n523) );
  OAI222X1 U323 ( .A0(n537), .A1(n567), .B0(n536), .B1(n535), .C0(n521), .C1(
        n557), .Y(NextState[0]) );
  AO21X1 U324 ( .A0(SCLWait), .A1(n516), .B0(n530), .Y(NextState[1]) );
  OAI32X1 U325 ( .A0(n514), .A1(n519), .A2(n531), .B0(n521), .B1(n562), .Y(
        n530) );
  OAI221X1 U326 ( .A0(n523), .A1(n524), .B0(n521), .B1(n561), .C0(n526), .Y(
        NextState[2]) );
  INVX1 U327 ( .A(SendStop), .Y(n524) );
  OA22X1 U328 ( .A0(n557), .A1(n528), .B0(n523), .B1(n529), .Y(n526) );
  INVX1 U329 ( .A(n514), .Y(CntIsZero) );
  AO21X1 U330 ( .A0(n516), .A1(n517), .B0(n518), .Y(NextState[3]) );
  INVX1 U331 ( .A(SCLWait), .Y(n517) );
  OAI32X1 U332 ( .A0(n514), .A1(n519), .A2(n520), .B0(n521), .B1(n563), .Y(
        n518) );
  INVX1 U333 ( .A(n511), .Y(n542) );
  INVX1 U334 ( .A(n533), .Y(n516) );
  NAND3BX1 U335 ( .AN(SendStop), .B(n529), .C(n534), .Y(n533) );
  INVX1 U336 ( .A(n523), .Y(n534) );
  INVX1 U337 ( .A(n519), .Y(n537) );
  AND2X2 U338 ( .A(n520), .B(n531), .Y(n567) );
  NAND3BX1 U339 ( .AN(CntRst), .B(SCLWait), .C(n510), .Y(n508) );
  INVX1 U340 ( .A(n509), .Y(n492) );
  NAND3BX1 U341 ( .AN(CntRst), .B(n510), .C(n508), .Y(n509) );
  INVX1 U342 ( .A(n568), .Y(n510) );
  NAND4BX1 U343 ( .AN(State[3]), .B(n562), .C(State[2]), .D(n557), .Y(n520) );
  NAND2BX1 U344 ( .AN(SW_RST), .B(n515), .Y(n519) );
  NAND2BX1 U345 ( .AN(State[1]), .B(n561), .Y(n511) );
  INVX1 U346 ( .A(n543), .Y(n536) );
  NAND2BX1 U347 ( .AN(BusErrorDet), .B(n537), .Y(n543) );
  AO22X1 U348 ( .A0(n482), .A1(n483), .B0(out_clk), .B1(n484), .Y(n480) );
  INVX1 U349 ( .A(n482), .Y(n484) );
  OAI32X1 U350 ( .A0(n485), .A1(NextState[0]), .A2(n486), .B0(NextState[1]), 
        .B1(n487), .Y(n482) );
  INVX1 U351 ( .A(NextState[1]), .Y(n486) );
  NAND4BX1 U352 ( .AN(State[3]), .B(n561), .C(State[1]), .D(n557), .Y(n535) );
  NAND4BX1 U353 ( .AN(IntPendFlag), .B(Start), .C(n563), .D(n542), .Y(n528) );
  NAND3BX1 U354 ( .AN(State[0]), .B(State[3]), .C(n542), .Y(n531) );
  OR3X2 U355 ( .A(CntVal[6]), .B(CntVal[5]), .C(CntVal[4]), .Y(n549) );
  OR4X1 U356 ( .A(n546), .B(n547), .C(n548), .D(n549), .Y(n514) );
  NAND3BX1 U357 ( .AN(CntVal[3]), .B(n560), .C(n566), .Y(n546) );
  NAND3BX1 U358 ( .AN(CntVal[11]), .B(n564), .C(n558), .Y(n547) );
  NAND3BX1 U359 ( .AN(CntVal[9]), .B(n559), .C(n565), .Y(n548) );
  INVX1 U360 ( .A(StopDet), .Y(n515) );
  INVX1 U361 ( .A(n539), .Y(n521) );
  OAI31X1 U362 ( .A0(n540), .A1(CntIsZero), .A2(n519), .B0(n541), .Y(n539) );
  AOI222X1 U363 ( .A0(State[0]), .A1(n528), .B0(State[3]), .B1(n511), .C0(
        State[1]), .C1(State[2]), .Y(n541) );
  OA21X2 U364 ( .A0(BusErrorDet), .A1(n535), .B0(n567), .Y(n540) );
  BUFX2 U365 ( .A(n496), .Y(n568) );
  OAI211X1 U366 ( .A0(n511), .A1(n512), .B0(n513), .C0(n514), .Y(n496) );
  NOR3BX1 U367 ( .AN(n515), .B(WaitCnt), .C(ArbitLostDet), .Y(n513) );
  NAND2BX1 U368 ( .AN(State[3]), .B(State[0]), .Y(n512) );
  OR2X1 U1_B_1 ( .A(CntVal[1]), .B(CntVal[0]), .Y(carry_2_) );
  OR2X1 U1_B_2 ( .A(CntVal[2]), .B(carry_2_), .Y(carry_3_) );
  OR2X1 U1_B_4 ( .A(CntVal[4]), .B(carry_4_), .Y(carry_5_) );
  OR2X1 U1_B_5 ( .A(CntVal[5]), .B(carry_5_), .Y(carry_6_) );
  OR2X1 U1_B_7 ( .A(CntVal[7]), .B(carry_7_), .Y(carry_8_) );
  OR2X1 U1_B_8 ( .A(CntVal[8]), .B(carry_8_), .Y(carry_9_) );
  OR2X1 U1_B_3 ( .A(CntVal[3]), .B(carry_3_), .Y(carry_4_) );
  OR2X1 U1_B_6 ( .A(CntVal[6]), .B(carry_6_), .Y(carry_7_) );
  OR2X1 U1_B_9 ( .A(CntVal[9]), .B(carry_9_), .Y(carry_10_) );
  AO21X1 U369 ( .A0(n492), .A1(n558), .B0(n494), .Y(n479) );
  AO22X1 U370 ( .A0(CntVal[0]), .A1(n495), .B0(TxPre[0]), .B1(n568), .Y(n494)
         );
  AO21X1 U371 ( .A0(CntVal182_11_), .A1(n492), .B0(n507), .Y(n468) );
  AO22X1 U372 ( .A0(CntVal[11]), .A1(n495), .B0(TxPre[11]), .B1(n568), .Y(n507) );
  XNOR2X1 U1_A_11 ( .A(CntVal[11]), .B(carry_11_), .Y(CntVal182_11_) );
  OR2X1 U1_B_10 ( .A(CntVal[10]), .B(carry_10_), .Y(carry_11_) );
  AO21X1 U373 ( .A0(CntVal182_10_), .A1(n492), .B0(n506), .Y(n469) );
  AO22X1 U374 ( .A0(CntVal[10]), .A1(n495), .B0(TxPre[10]), .B1(n568), .Y(n506) );
  XNOR2X1 U1_A_10 ( .A(CntVal[10]), .B(carry_10_), .Y(CntVal182_10_) );
  AO21X1 U375 ( .A0(CntVal182_9_), .A1(n492), .B0(n505), .Y(n470) );
  AO22X1 U376 ( .A0(CntVal[9]), .A1(n495), .B0(TxPre[9]), .B1(n568), .Y(n505)
         );
  XNOR2X1 U1_A_9 ( .A(CntVal[9]), .B(carry_9_), .Y(CntVal182_9_) );
  AO21X1 U377 ( .A0(CntVal182_8_), .A1(n492), .B0(n504), .Y(n471) );
  AO22X1 U378 ( .A0(CntVal[8]), .A1(n495), .B0(TxPre[8]), .B1(n568), .Y(n504)
         );
  XNOR2X1 U1_A_8 ( .A(CntVal[8]), .B(carry_8_), .Y(CntVal182_8_) );
  AO21X1 U379 ( .A0(CntVal182_7_), .A1(n492), .B0(n503), .Y(n472) );
  XNOR2X1 U1_A_7 ( .A(CntVal[7]), .B(carry_7_), .Y(CntVal182_7_) );
  AO22X1 U380 ( .A0(CntVal[7]), .A1(n495), .B0(TxPre[7]), .B1(n568), .Y(n503)
         );
  AO21X1 U381 ( .A0(CntVal182_6_), .A1(n492), .B0(n502), .Y(n473) );
  XNOR2X1 U1_A_6 ( .A(CntVal[6]), .B(carry_6_), .Y(CntVal182_6_) );
  AO22X1 U382 ( .A0(CntVal[6]), .A1(n495), .B0(TxPre[6]), .B1(n568), .Y(n502)
         );
  AO21X1 U383 ( .A0(CntVal182_5_), .A1(n492), .B0(n501), .Y(n474) );
  XNOR2X1 U1_A_5 ( .A(CntVal[5]), .B(carry_5_), .Y(CntVal182_5_) );
  AO22X1 U384 ( .A0(CntVal[5]), .A1(n495), .B0(TxPre[5]), .B1(n568), .Y(n501)
         );
  AO21X1 U385 ( .A0(CntVal182_4_), .A1(n492), .B0(n500), .Y(n475) );
  XNOR2X1 U1_A_4 ( .A(CntVal[4]), .B(carry_4_), .Y(CntVal182_4_) );
  AO22X1 U386 ( .A0(CntVal[4]), .A1(n495), .B0(TxPre[4]), .B1(n568), .Y(n500)
         );
  AO21X1 U387 ( .A0(CntVal182_3_), .A1(n492), .B0(n499), .Y(n476) );
  XNOR2X1 U1_A_3 ( .A(CntVal[3]), .B(carry_3_), .Y(CntVal182_3_) );
  AO22X1 U388 ( .A0(CntVal[3]), .A1(n495), .B0(TxPre[3]), .B1(n568), .Y(n499)
         );
  AO21X1 U389 ( .A0(CntVal182_2_), .A1(n492), .B0(n498), .Y(n477) );
  XNOR2X1 U1_A_2 ( .A(CntVal[2]), .B(carry_2_), .Y(CntVal182_2_) );
  AO22X1 U390 ( .A0(CntVal[2]), .A1(n495), .B0(TxPre[2]), .B1(n568), .Y(n498)
         );
  AO21X1 U391 ( .A0(CntVal182_1_), .A1(n492), .B0(n497), .Y(n478) );
  XNOR2X1 U1_A_1 ( .A(CntVal[1]), .B(CntVal[0]), .Y(CntVal182_1_) );
  AO22X1 U392 ( .A0(CntVal[1]), .A1(n495), .B0(TxPre[1]), .B1(n568), .Y(n497)
         );
  DFFRX1 State_reg_3_ ( .D(NextState[3]), .CK(PCLK), .RN(PRESETn), .Q(State[3]), .QN(n563) );
  DFFSX1 State_reg_0_ ( .D(NextState[0]), .CK(PCLK), .SN(PRESETn), .Q(State[0]), .QN(n557) );
  DFFRX1 CntVal_reg_0_ ( .D(n479), .CK(PCLK), .RN(PRESETn), .Q(CntVal[0]), 
        .QN(n558) );
  DFFRX1 CntVal_reg_10_ ( .D(n469), .CK(PCLK), .RN(PRESETn), .Q(CntVal[10]), 
        .QN(n564) );
  DFFRX1 CntVal_reg_8_ ( .D(n471), .CK(PCLK), .RN(PRESETn), .Q(CntVal[8]), 
        .QN(n559) );
  DFFRX1 CntVal_reg_7_ ( .D(n472), .CK(PCLK), .RN(PRESETn), .Q(CntVal[7]), 
        .QN(n565) );
  DFFRX1 CntVal_reg_5_ ( .D(n474), .CK(PCLK), .RN(PRESETn), .Q(CntVal[5]) );
  DFFRX1 CntVal_reg_4_ ( .D(n475), .CK(PCLK), .RN(PRESETn), .Q(CntVal[4]) );
  DFFRX1 CntVal_reg_2_ ( .D(n477), .CK(PCLK), .RN(PRESETn), .Q(CntVal[2]), 
        .QN(n560) );
  DFFRX1 CntVal_reg_1_ ( .D(n478), .CK(PCLK), .RN(PRESETn), .Q(CntVal[1]), 
        .QN(n566) );
  DFFRX1 State_reg_1_ ( .D(NextState[1]), .CK(PCLK), .RN(PRESETn), .Q(State[1]), .QN(n562) );
  DFFRX1 State_reg_2_ ( .D(NextState[2]), .CK(PCLK), .RN(PRESETn), .Q(State[2]), .QN(n561) );
  DFFRX1 CntVal_reg_9_ ( .D(n470), .CK(PCLK), .RN(PRESETn), .Q(CntVal[9]) );
  DFFRX1 CntVal_reg_6_ ( .D(n473), .CK(PCLK), .RN(PRESETn), .Q(CntVal[6]) );
  DFFRX1 CntVal_reg_3_ ( .D(n476), .CK(PCLK), .RN(PRESETn), .Q(CntVal[3]) );
  DFFRX1 CntVal_reg_11_ ( .D(n468), .CK(PCLK), .RN(PRESETn), .Q(CntVal[11]) );
  DFFSX1 out_clk_reg ( .D(n480), .CK(PCLK), .SN(PRESETn), .Q(out_clk) );
endmodule


module I2CRegIF ( PCLK, PRESETn, PENABLE, PSEL, PWRITE, PADDR, PWDATA, PRDATA, 
        BusyDet, StopDet, ArbitLostDet, TxCompInt, AckValue, AckEn, 
        IntPendFlag, IntPendClr, TxClkVal, OpMode, Start, Stop, StartClr, 
        StopClr, IDSRo, ReadData, SW_RST, int );
  input [1:0] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  output [11:0] TxClkVal;
  output [7:0] IDSRo;
  input [7:0] ReadData;
  input PCLK, PRESETn, PENABLE, PSEL, PWRITE, BusyDet, StopDet, ArbitLostDet,
         TxCompInt, AckValue, StartClr, StopClr;
  output AckEn, IntPendFlag, IntPendClr, OpMode, Start, Stop, SW_RST, int;
  wire   TxRxIntEn, ArbSta, BusError, SW_RST245, n769, n770, n771, n772, n773,
         n774, n775, n776, n777, n778, n779, n780, n781, n782, n783, n784,
         n785, n786, n787, n788, n789, n790, n791, n792, n793, n794, n795,
         n796, n797, n798, n799, n800, n801, n802, n803, n804, n805, n806,
         n807, n808, n809, n810, n811, n812, n813, n814, n815, n816, n817,
         n818, n819, n820, n821, n822, n823, n824, n825, n826, n827, n828,
         n829, n830, n834, n835, n836, n838, n839, n840, n841, n842, n843,
         n844, n845, n846, n847, n848, n849, n850, n852, n853, n854, n855,
         n856, n857, n858, n859, n860, n861, n862, n863, n864, n865, n866,
         n867, n868, n869, n870, n871, n872, n873, n874, n875, n876, n877,
         n880, n881, n882, n883, n884;

  INVX1 U509 ( .A(TxCompInt), .Y(n839) );
  INVX1 U510 ( .A(n875), .Y(n876) );
  INVX1 U511 ( .A(n884), .Y(n856) );
  INVX1 U512 ( .A(n883), .Y(n855) );
  NAND2BX1 U513 ( .AN(n845), .B(n877), .Y(n875) );
  BUFX2 U514 ( .A(n870), .Y(n884) );
  NAND3BX1 U515 ( .AN(n860), .B(n864), .C(n869), .Y(n870) );
  INVX1 U516 ( .A(n869), .Y(n858) );
  INVX1 U517 ( .A(n864), .Y(n859) );
  INVX1 U518 ( .A(n849), .Y(n834) );
  DFFRX1 SW_RST_reg ( .D(SW_RST245), .CK(PCLK), .RN(PRESETn), .Q(SW_RST) );
  DFFRX1 IntPendFlag_reg ( .D(n826), .CK(PCLK), .RN(PRESETn), .Q(IntPendFlag), 
        .QN(n882) );
  DFFSX1 OpMode_reg ( .D(n823), .CK(PCLK), .SN(PRESETn), .Q(OpMode), .QN(n881)
         );
  NAND2X1 U519 ( .A(PWDATA[3]), .B(n855), .Y(n853) );
  BUFX2 U520 ( .A(n854), .Y(n883) );
  NAND2BX1 U521 ( .AN(PADDR[1]), .B(n877), .Y(n854) );
  INVX1 U522 ( .A(n853), .Y(IntPendClr) );
  INVX1 U523 ( .A(n880), .Y(n877) );
  NAND4BX1 U524 ( .AN(PADDR[0]), .B(PENABLE), .C(PWRITE), .D(PSEL), .Y(n880)
         );
  NAND3BX1 U525 ( .AN(PADDR[0]), .B(PADDR[1]), .C(n871), .Y(n869) );
  NAND3BX1 U526 ( .AN(PADDR[1]), .B(PADDR[0]), .C(n871), .Y(n864) );
  OAI33X1 U527 ( .A0(SW_RST), .A1(StartClr), .A2(n769), .B0(n846), .B1(n841), 
        .B2(n847), .Y(n828) );
  NAND2BX1 U528 ( .AN(n848), .B(PWDATA[4]), .Y(n847) );
  NAND4BX1 U529 ( .AN(SW_RST), .B(n845), .C(PSEL), .D(PENABLE), .Y(n846) );
  INVX1 U530 ( .A(PWRITE), .Y(n848) );
  OAI33X1 U531 ( .A0(SW_RST), .A1(StopClr), .A2(n770), .B0(n840), .B1(n841), 
        .B2(n842), .Y(n829) );
  NAND2BX1 U532 ( .AN(n843), .B(PWRITE), .Y(n842) );
  NAND4BX1 U533 ( .AN(SW_RST), .B(n844), .C(PENABLE), .D(n845), .Y(n840) );
  INVX1 U534 ( .A(PSEL), .Y(n843) );
  NAND2BX1 U535 ( .AN(SW_RST), .B(n853), .Y(n849) );
  INVX1 U536 ( .A(PADDR[1]), .Y(n845) );
  AO22X1 U537 ( .A0(n834), .A1(n835), .B0(BusError), .B1(n836), .Y(n830) );
  INVX1 U538 ( .A(n835), .Y(n836) );
  OAI31X1 U539 ( .A0(n881), .A1(n838), .A2(n839), .B0(n834), .Y(n835) );
  INVX1 U540 ( .A(AckValue), .Y(n838) );
  INVX1 U541 ( .A(PADDR[0]), .Y(n841) );
  INVX1 U542 ( .A(PWDATA[4]), .Y(n844) );
  INVX1 U543 ( .A(n872), .Y(n860) );
  NAND3BX1 U544 ( .AN(PADDR[1]), .B(n841), .C(n871), .Y(n872) );
  NOR2BX1 U545 ( .AN(PWDATA[16]), .B(n883), .Y(SW_RST245) );
  INVX1 U546 ( .A(n873), .Y(n871) );
  NAND3BX1 U547 ( .AN(PWRITE), .B(n874), .C(PSEL), .Y(n873) );
  INVX1 U548 ( .A(PENABLE), .Y(n874) );
  AO22X1 U549 ( .A0(OpMode), .A1(n883), .B0(PWDATA[2]), .B1(n855), .Y(n823) );
  AO22X1 U550 ( .A0(TxClkVal[11]), .A1(n883), .B0(PWDATA[15]), .B1(n855), .Y(
        n771) );
  AO22X1 U551 ( .A0(TxClkVal[10]), .A1(n883), .B0(PWDATA[14]), .B1(n855), .Y(
        n772) );
  AO22X1 U552 ( .A0(TxClkVal[9]), .A1(n883), .B0(PWDATA[13]), .B1(n855), .Y(
        n773) );
  AO22X1 U553 ( .A0(TxClkVal[8]), .A1(n883), .B0(PWDATA[12]), .B1(n855), .Y(
        n774) );
  AO22X1 U554 ( .A0(TxClkVal[7]), .A1(n883), .B0(PWDATA[11]), .B1(n855), .Y(
        n775) );
  AO22X1 U555 ( .A0(TxClkVal[6]), .A1(n883), .B0(PWDATA[10]), .B1(n855), .Y(
        n776) );
  AO22X1 U556 ( .A0(TxClkVal[5]), .A1(n883), .B0(PWDATA[9]), .B1(n855), .Y(
        n777) );
  AO22X1 U557 ( .A0(TxClkVal[4]), .A1(n883), .B0(PWDATA[8]), .B1(n855), .Y(
        n778) );
  AO22X1 U558 ( .A0(TxClkVal[3]), .A1(n883), .B0(PWDATA[7]), .B1(n855), .Y(
        n779) );
  AO22X1 U559 ( .A0(TxClkVal[2]), .A1(n883), .B0(PWDATA[6]), .B1(n855), .Y(
        n780) );
  AO22X1 U560 ( .A0(TxClkVal[1]), .A1(n883), .B0(PWDATA[5]), .B1(n855), .Y(
        n781) );
  AO22X1 U561 ( .A0(TxClkVal[0]), .A1(n883), .B0(PWDATA[4]), .B1(n855), .Y(
        n782) );
  AO22X1 U562 ( .A0(IDSRo[7]), .A1(n875), .B0(PWDATA[7]), .B1(n876), .Y(n783)
         );
  AO22X1 U563 ( .A0(IDSRo[6]), .A1(n875), .B0(PWDATA[6]), .B1(n876), .Y(n784)
         );
  AO22X1 U564 ( .A0(IDSRo[5]), .A1(n875), .B0(PWDATA[5]), .B1(n876), .Y(n785)
         );
  AO22X1 U565 ( .A0(AckEn), .A1(n883), .B0(PWDATA[1]), .B1(n855), .Y(n824) );
  AO22X1 U566 ( .A0(TxRxIntEn), .A1(n883), .B0(PWDATA[0]), .B1(n855), .Y(n825)
         );
  AO22X1 U567 ( .A0(IDSRo[4]), .A1(n875), .B0(n876), .B1(PWDATA[4]), .Y(n786)
         );
  AO22X1 U568 ( .A0(IDSRo[3]), .A1(n875), .B0(n876), .B1(PWDATA[3]), .Y(n787)
         );
  AO22X1 U569 ( .A0(IDSRo[2]), .A1(n875), .B0(n876), .B1(PWDATA[2]), .Y(n788)
         );
  AO22X1 U570 ( .A0(IDSRo[1]), .A1(n875), .B0(n876), .B1(PWDATA[1]), .Y(n789)
         );
  AO22X1 U571 ( .A0(IDSRo[0]), .A1(n875), .B0(n876), .B1(PWDATA[0]), .Y(n790)
         );
  NOR2BX1 U572 ( .AN(PRDATA[31]), .B(n884), .Y(n791) );
  NOR2BX1 U573 ( .AN(PRDATA[30]), .B(n884), .Y(n792) );
  NOR2BX1 U574 ( .AN(PRDATA[29]), .B(n884), .Y(n793) );
  NOR2BX1 U575 ( .AN(PRDATA[28]), .B(n884), .Y(n794) );
  NOR2BX1 U576 ( .AN(PRDATA[27]), .B(n884), .Y(n795) );
  NOR2BX1 U577 ( .AN(PRDATA[26]), .B(n884), .Y(n796) );
  NOR2BX1 U578 ( .AN(PRDATA[25]), .B(n884), .Y(n797) );
  NOR2BX1 U579 ( .AN(PRDATA[24]), .B(n884), .Y(n798) );
  NOR2BX1 U580 ( .AN(PRDATA[23]), .B(n884), .Y(n799) );
  NOR2BX1 U581 ( .AN(PRDATA[22]), .B(n884), .Y(n800) );
  NOR2BX1 U582 ( .AN(PRDATA[21]), .B(n884), .Y(n801) );
  NOR2BX1 U583 ( .AN(PRDATA[20]), .B(n884), .Y(n802) );
  NOR2BX1 U584 ( .AN(PRDATA[19]), .B(n884), .Y(n803) );
  NOR2BX1 U585 ( .AN(PRDATA[18]), .B(n884), .Y(n804) );
  NOR2BX1 U586 ( .AN(PRDATA[17]), .B(n884), .Y(n805) );
  NOR2BX1 U587 ( .AN(PRDATA[16]), .B(n884), .Y(n806) );
  AO22X1 U588 ( .A0(ArbitLostDet), .A1(n834), .B0(ArbSta), .B1(n834), .Y(n827)
         );
  AO22X1 U589 ( .A0(TxClkVal[11]), .A1(n860), .B0(PRDATA[15]), .B1(n856), .Y(
        n807) );
  AO22X1 U590 ( .A0(TxClkVal[10]), .A1(n860), .B0(PRDATA[14]), .B1(n856), .Y(
        n808) );
  AO22X1 U591 ( .A0(TxClkVal[9]), .A1(n860), .B0(PRDATA[13]), .B1(n856), .Y(
        n809) );
  AO22X1 U592 ( .A0(TxClkVal[8]), .A1(n860), .B0(PRDATA[12]), .B1(n856), .Y(
        n810) );
  AO22X1 U593 ( .A0(TxClkVal[7]), .A1(n860), .B0(PRDATA[11]), .B1(n856), .Y(
        n811) );
  AO22X1 U594 ( .A0(TxClkVal[6]), .A1(n860), .B0(PRDATA[10]), .B1(n856), .Y(
        n812) );
  AO22X1 U595 ( .A0(TxClkVal[5]), .A1(n860), .B0(PRDATA[9]), .B1(n856), .Y(
        n813) );
  AO22X1 U596 ( .A0(TxClkVal[4]), .A1(n860), .B0(PRDATA[8]), .B1(n856), .Y(
        n814) );
  OAI2BB1X1 U597 ( .A0N(PRDATA[3]), .A1N(n856), .B0(n863), .Y(n819) );
  AOI222X1 U598 ( .A0(ReadData[3]), .A1(n858), .B0(BusyDet), .B1(n859), .C0(
        IntPendFlag), .C1(n860), .Y(n863) );
  OAI2BB1X1 U599 ( .A0N(PRDATA[2]), .A1N(n856), .B0(n862), .Y(n820) );
  AOI222X1 U600 ( .A0(ReadData[2]), .A1(n858), .B0(n859), .B1(ArbSta), .C0(
        n860), .C1(OpMode), .Y(n862) );
  OAI2BB1X1 U601 ( .A0N(PRDATA[1]), .A1N(n856), .B0(n861), .Y(n821) );
  AOI222X1 U602 ( .A0(ReadData[1]), .A1(n858), .B0(n859), .B1(AckValue), .C0(
        n860), .C1(AckEn), .Y(n861) );
  OAI2BB1X1 U603 ( .A0N(PRDATA[0]), .A1N(n856), .B0(n857), .Y(n822) );
  AOI222X1 U604 ( .A0(ReadData[0]), .A1(n858), .B0(n859), .B1(BusError), .C0(
        n860), .C1(TxRxIntEn), .Y(n857) );
  AO21X1 U605 ( .A0(PRDATA[7]), .A1(n856), .B0(n868), .Y(n815) );
  AO22X1 U606 ( .A0(ReadData[7]), .A1(n858), .B0(TxClkVal[3]), .B1(n860), .Y(
        n868) );
  AO21X1 U607 ( .A0(PRDATA[6]), .A1(n856), .B0(n867), .Y(n816) );
  AO22X1 U608 ( .A0(ReadData[6]), .A1(n858), .B0(TxClkVal[2]), .B1(n860), .Y(
        n867) );
  AO21X1 U609 ( .A0(PRDATA[5]), .A1(n856), .B0(n866), .Y(n817) );
  AO22X1 U610 ( .A0(ReadData[5]), .A1(n858), .B0(TxClkVal[1]), .B1(n860), .Y(
        n866) );
  AO21X1 U611 ( .A0(PRDATA[4]), .A1(n856), .B0(n865), .Y(n818) );
  AO22X1 U612 ( .A0(ReadData[4]), .A1(n858), .B0(TxClkVal[0]), .B1(n860), .Y(
        n865) );
  AOI31X1 U613 ( .A0(n850), .A1(n882), .A2(n852), .B0(n849), .Y(n826) );
  INVX1 U614 ( .A(ArbitLostDet), .Y(n850) );
  NOR2BX1 U615 ( .AN(n839), .B(StopDet), .Y(n852) );
  AND2X2 U616 ( .A(IntPendFlag), .B(TxRxIntEn), .Y(int) );
  DFFRX1 PRDATA_reg_15_ ( .D(n807), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[15]) );
  DFFRX1 PRDATA_reg_14_ ( .D(n808), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[14]) );
  DFFRX1 PRDATA_reg_13_ ( .D(n809), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[13]) );
  DFFRX1 PRDATA_reg_12_ ( .D(n810), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[12]) );
  DFFRX1 PRDATA_reg_11_ ( .D(n811), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[11]) );
  DFFRX1 PRDATA_reg_10_ ( .D(n812), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[10]) );
  DFFRX1 PRDATA_reg_9_ ( .D(n813), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[9]) );
  DFFRX1 PRDATA_reg_8_ ( .D(n814), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[8]) );
  DFFRX1 PRDATA_reg_7_ ( .D(n815), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[7]) );
  DFFRX1 PRDATA_reg_6_ ( .D(n816), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[6]) );
  DFFRX1 PRDATA_reg_5_ ( .D(n817), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[5]) );
  DFFRX1 PRDATA_reg_4_ ( .D(n818), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[4]) );
  DFFRX1 PRDATA_reg_31_ ( .D(n791), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[31]) );
  DFFRX1 PRDATA_reg_30_ ( .D(n792), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[30]) );
  DFFRX1 PRDATA_reg_29_ ( .D(n793), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[29]) );
  DFFRX1 PRDATA_reg_28_ ( .D(n794), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[28]) );
  DFFRX1 PRDATA_reg_27_ ( .D(n795), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[27]) );
  DFFRX1 PRDATA_reg_26_ ( .D(n796), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[26]) );
  DFFRX1 PRDATA_reg_25_ ( .D(n797), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[25]) );
  DFFRX1 PRDATA_reg_24_ ( .D(n798), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[24]) );
  DFFRX1 PRDATA_reg_23_ ( .D(n799), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[23]) );
  DFFRX1 PRDATA_reg_22_ ( .D(n800), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[22]) );
  DFFRX1 PRDATA_reg_21_ ( .D(n801), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[21]) );
  DFFRX1 PRDATA_reg_20_ ( .D(n802), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[20]) );
  DFFRX1 PRDATA_reg_19_ ( .D(n803), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[19]) );
  DFFRX1 PRDATA_reg_18_ ( .D(n804), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[18]) );
  DFFRX1 PRDATA_reg_17_ ( .D(n805), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[17]) );
  DFFRX1 PRDATA_reg_16_ ( .D(n806), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[16]) );
  DFFRX1 PRDATA_reg_3_ ( .D(n819), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[3]) );
  DFFRX1 PRDATA_reg_2_ ( .D(n820), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[2]) );
  DFFRX1 PRDATA_reg_1_ ( .D(n821), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[1]) );
  DFFRX1 PRDATA_reg_0_ ( .D(n822), .CK(PCLK), .RN(PRESETn), .Q(PRDATA[0]) );
  DFFRX1 Start_reg ( .D(n828), .CK(PCLK), .RN(PRESETn), .Q(Start), .QN(n769)
         );
  DFFRX1 AckEn_reg ( .D(n824), .CK(PCLK), .RN(PRESETn), .Q(AckEn) );
  DFFRX1 TxRxIntEn_reg ( .D(n825), .CK(PCLK), .RN(PRESETn), .Q(TxRxIntEn) );
  DFFRX1 Stop_reg ( .D(n829), .CK(PCLK), .RN(PRESETn), .Q(Stop), .QN(n770) );
  DFFRX1 TxClkVal_reg_11_ ( .D(n771), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[11]) );
  DFFRX1 TxClkVal_reg_10_ ( .D(n772), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[10]) );
  DFFRX1 TxClkVal_reg_9_ ( .D(n773), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[9])
         );
  DFFRX1 TxClkVal_reg_8_ ( .D(n774), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[8])
         );
  DFFRX1 TxClkVal_reg_7_ ( .D(n775), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[7])
         );
  DFFRX1 TxClkVal_reg_6_ ( .D(n776), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[6])
         );
  DFFRX1 TxClkVal_reg_5_ ( .D(n777), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[5])
         );
  DFFRX1 TxClkVal_reg_4_ ( .D(n778), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[4])
         );
  DFFRX1 TxClkVal_reg_3_ ( .D(n779), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[3])
         );
  DFFRX1 TxClkVal_reg_2_ ( .D(n780), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[2])
         );
  DFFRX1 TxClkVal_reg_1_ ( .D(n781), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[1])
         );
  DFFRX1 TxClkVal_reg_0_ ( .D(n782), .CK(PCLK), .RN(PRESETn), .Q(TxClkVal[0])
         );
  DFFRX1 IDSRo_reg_7_ ( .D(n783), .CK(PCLK), .RN(PRESETn), .Q(IDSRo[7]) );
  DFFRX1 IDSRo_reg_6_ ( .D(n784), .CK(PCLK), .RN(PRESETn), .Q(IDSRo[6]) );
  DFFRX1 IDSRo_reg_5_ ( .D(n785), .CK(PCLK), .RN(PRESETn), .Q(IDSRo[5]) );
  DFFRX1 IDSRo_reg_4_ ( .D(n786), .CK(PCLK), .RN(PRESETn), .Q(IDSRo[4]) );
  DFFRX1 IDSRo_reg_3_ ( .D(n787), .CK(PCLK), .RN(PRESETn), .Q(IDSRo[3]) );
  DFFRX1 IDSRo_reg_2_ ( .D(n788), .CK(PCLK), .RN(PRESETn), .Q(IDSRo[2]) );
  DFFRX1 IDSRo_reg_1_ ( .D(n789), .CK(PCLK), .RN(PRESETn), .Q(IDSRo[1]) );
  DFFRX1 IDSRo_reg_0_ ( .D(n790), .CK(PCLK), .RN(PRESETn), .Q(IDSRo[0]) );
  DFFRX1 ArbSta_reg ( .D(n827), .CK(PCLK), .RN(PRESETn), .Q(ArbSta) );
  DFFRX1 BusError_reg ( .D(n830), .CK(PCLK), .RN(PRESETn), .Q(BusError) );
endmodule

