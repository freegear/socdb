analyze -f verilog -lib WORK ./Net/DmacControl.v
analyze -f verilog -lib WORK ./Net/DmacFifo.v
analyze -f verilog -lib WORK DmacEngine.v
analyze -f verilog -lib WORK DmacChReg.v
analyze -f verilog -lib WORK DmacChRegPOR.v
analyze -f verilog -lib WORK DmacRegFile4Ch.v
analyze -f verilog -lib WORK DmacRegFile4ChPOR.v
analyze -f verilog -lib WORK DmacReqAck4Ch.v
analyze -f verilog -lib WORK Dmac4Ch.v
analyze -f verilog -lib WORK Dmac4ChPOR.v
analyze -f verilog -lib WORK DmacAPBMux.v
analyze -f verilog -lib WORK DmacAXIArbiter.v
analyze -f verilog -lib WORK Dmac2x4Ch.v

elaborate $TopDesign -lib WORK
