The CCS project "cfft_bfp.pjt" shows how to use the Block FLoating Point CFFT.
It compares the SNRs of the BFP CFFT, the 16-bit SCALED CFFT and the 32-bit CFFT.

The BFP CFFT supports N = 16,32,64,128,256,512,1024. 
It is possible to support larger sizes by using the twid2048.asm or 
the twid4096.asm instead of the twiddle.asm file.


The following files are provided in the cfft_bfp folder:

Assembly files:

	- twiddle.asm		twiddle table for 16-bit CFFT, size up to 1024 points
	- twid2048.asm		twiddle table for 16-bit CFFT, size up to 2048 points
	- twid4098.asm		twiddle table for 16-bit CFFT, size up to 4098 points
	- twiddle32.asm         twiddle table for 16-bit CIFFT

	- cbrev.asm:		16-bit bit-reverse
	- cbrev32.asm		32-bit bit-reverse
	
	- cfft_bfp.asm		16-bit CFFT, Block Floating Point version
	- cfft_scale.asm	16-bit CFFT, Scaled version
	- cfft32_scale.asm	32-bit CFFT, Scaled version
	- cifft_bfp.asm		16-bit CIFFT, Block Floating Point version
	- cifft_scale.asm	16-bit CIFFT, Scaled version
	- cifft32_scale.asm	32-bit CIFFT, Scaled version

C files:

	- CFFT.c		application file calls the CFFT routines

Header files:

	- dsplib.h
	- misc.h
	- math.h
	- TMS320.h
	- stdio.h

	- n256randscaleX.h	data with max dynamic range: log2(X) (#bits)
	- n256scaleX.h

X = 2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768.
	