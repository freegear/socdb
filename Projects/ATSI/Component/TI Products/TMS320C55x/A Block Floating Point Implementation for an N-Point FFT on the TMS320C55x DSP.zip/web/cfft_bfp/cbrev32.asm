; THIS PROGRAM IS PROVIDED "AS IS". TI MAKES NO WARRANTIES OR
; REPRESENTATIONS, EITHER EXPRESS, IMPLIED OR STATUTORY, 
; INCLUDING ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS 
; FOR A PARTICULAR PURPOSE, LACK OF VIRUSES, ACCURACY OR 
; COMPLETENESS OF RESPONSES, RESULTS AND LACK OF NEGLIGENCE. 
; TI DISCLAIMS ANY WARRANTY OF TITLE, QUIET ENJOYMENT, QUIET 
; POSSESSION, AND NON-INFRINGEMENT OF ANY THIRD PARTY 
; INTELLECTUAL PROPERTY RIGHTS WITH REGARD TO THE PROGRAM OR 
; YOUR USE OF THE PROGRAM.
;
; IN NO EVENT SHALL TI BE LIABLE FOR ANY SPECIAL, INCIDENTAL, 
; CONSEQUENTIAL OR INDIRECT DAMAGES, HOWEVER CAUSED, ON ANY 
; THEORY OF LIABILITY AND WHETHER OR NOT TI HAS BEEN ADVISED 
; OF THE POSSIBILITY OF SUCH DAMAGES, ARISING IN ANY WAY OUT 
; OF THIS AGREEMENT, THE PROGRAM, OR YOUR USE OF THE PROGRAM. 
; EXCLUDED DAMAGES INCLUDE, BUT ARE NOT LIMITED TO, COST OF 
; REMOVAL OR REINSTALLATION, COMPUTER TIME, LABOR COSTS, LOSS 
; OF GOODWILL, LOSS OF PROFITS, LOSS OF SAVINGS, OR LOSS OF 
; USE OR INTERRUPTION OF BUSINESS. IN NO EVENT WILL TI'S 
; AGGREGATE LIABILITY UNDER THIS AGREEMENT OR ARISING OUT OF 
; YOUR USE OF THE PROGRAM EXCEED FIVE HUNDRED DOLLARS 
; (U.S.$500).
;
; Unless otherwise stated, the Program written and copyrighted 
; by Texas Instruments is distributed as "freeware".  You may, 
; only under TI's copyright in the Program, use and modify the 
; Program without any charge or restriction.  You may 
; distribute to third parties, provided that you transfer a 
; copy of this license to the third party and the third party 
; agrees to these terms by its first use of the Program. You 
; must reproduce the copyright notice and any other legend of 
; ownership on each copy or partial copy, of the Program.
;
; You acknowledge and agree that the Program contains 
; copyrighted material, trade secrets and other TI proprietary 
; information and is protected by copyright laws, 
; international copyright treaties, and trade secret laws, as 
; well as other intellectual property laws.  To protect TI's 
; rights in the Program, you agree not to decompile, reverse 
; engineer, disassemble or otherwise translate any object code 
; versions of the Program to a human-readable form.  You agree 
; that in no event will you alter, remove or destroy any 
; copyright notice included in the Program.  TI reserves all 
; rights not specifically granted under this license. Except 
; as specifically provided herein, nothing in this agreement 
; shall be construed as conferring by implication, estoppel, 
; or otherwise, upon you, any license or other right under any 
; TI patents, copyrights or trade secrets.
;
; You may not use the Program in non-TI devices.

;***********************************************************
; Version 2.00.00                                           
;***********************************************************
; Note: a symbol "SI_BUGS" is used to make a work around for silicon
; 5510 version1.0. If you are going to use the code on 5510 version1.0
; silicon, you have to put switch -d"SI_BUGS" when you compile the code.
;*********************************************************************
; Function:    cbrev32
; Processor:   C55xx
; Description: This function performs 32-bit bit-reversal of complex 
;			   data array x.
;              If x==y, in-place bit reversal is performed.
; Usage:    void cbrev32 (DATA *x, DATA *y, ushort n)
; Copyright Texas instruments Inc, 2002
;****************************************************************

		.mmregs  
		.cpl_on   

        .global _cbrev32   

_cbrev32:

;//-----------------------------------------------------------------------------
;// Context Save
;//-----------------------------------------------------------------------------

	PSH	mmap(ST2_55)		; preserve ST2 register  

;//-----------------------------------------------------------------------------
;// Initialize
;//-----------------------------------------------------------------------------

	BSET	AR1LC			; circular addressing for AR1
	.arms_off
	BCLR	ARMS			; reset ARMS bit

	MOV	T0, T1				; n in DR1
	SFTL T1, #1				; 2*n
	SFTL T1, #1				; 4*n
	MOV	mmap(T1), BK03		; circular buffer size is 4*n 
	MOV	mmap(AR1), BSA01	; circular buffer offset      
 
 	MOV	T0, T1				; n in DR1
	SUB	#1, T1
	MOV	mmap(T1), BRC0		; BRC0 = n - 1

	MOV	XAR1, AC0

	MOV	XAR0, AC1			; 
	MOV	#0, AR1				; output pointer (circular)
	SFTL T0,#1

	SUB	AC1, AC0		; compare input and output pointers 
	BCC	off_place, AC0 != #0	; if x<>y, do off-place bit reversal

;//-----------------------------------------------------------------------------
;// In-place bit reversal
;//-----------------------------------------------------------------------------
in_place: 

	BSET	AR0LC			; circular addressing for AR0
	MOV	#0, AR0

	RPTBLOCAL	loop1-1 
	MOV	dbl(*AR0+), AC0
	MOV dbl(*AR0-), AC3      
	AMOV	AR1, T1			; should be in parallel but CCS1.00b crashes
	MOV	dbl(*AR1+), AC1
	MOV dbl(*AR1-), AC2
	ASUB	AR0, T1			; should be in parallel but CCS1.00b crashes
 	XCCPART	check1, T1>=#0	; swap only if AR3 < AR2 
	||MOV	AC1, dbl(*AR0+)	; otherwise they are swapped already
check1:	
	XCCPART check2, T1>=#0
	||MOV AC2,dbl(*AR0+)
check2:
	XCCPART	check3, T1>=#0
	||MOV	AC0, dbl(*AR1+)
check3:
	XCCPART check4, T1>=#0
	|| MOV AC3, dbl(*(AR1+T0B))
check4:
	MAR *+AR1(-2)
loop1:

	B	end  
	
;//-----------------------------------------------------------------------------
;// Off-place bit reversal
;//-----------------------------------------------------------------------------
off_place:  						
 
	RPTBLOCAL	loop2-1            
	MOV	dbl(*AR0+), AC0
	MOV dbl(*AR0+), AC1
	MOV AC0, dbl(*AR1+)
	MOV	AC1, dbl(*(AR1+T0B))  
	MAR *+AR1(-2)
loop2:

;//-----------------------------------------------------------------------------
;// Context Restore
;//-----------------------------------------------------------------------------
end:
    BSET	ARMS			; restore C environment
	POP	mmap(ST2_55)		; restore ST2 register

	RET				; return   

	.end     


