/* ***********************************************************
* THIS PROGRAM IS PROVIDED "AS IS". TI MAKES NO WARRANTIES OR
* REPRESENTATIONS, EITHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS 
* FOR A PARTICULAR PURPOSE, LACK OF VIRUSES, ACCURACY OR 
* COMPLETENESS OF RESPONSES, RESULTS AND LACK OF NEGLIGENCE. 
* TI DISCLAIMS ANY WARRANTY OF TITLE, QUIET ENJOYMENT, QUIET 
* POSSESSION, AND NON-INFRINGEMENT OF ANY THIRD PARTY 
* INTELLECTUAL PROPERTY RIGHTS WITH REGARD TO THE PROGRAM OR 
* YOUR USE OF THE PROGRAM.
*
* IN NO EVENT SHALL TI BE LIABLE FOR ANY SPECIAL, INCIDENTAL, 
* CONSEQUENTIAL OR INDIRECT DAMAGES, HOWEVER CAUSED, ON ANY 
* THEORY OF LIABILITY AND WHETHER OR NOT TI HAS BEEN ADVISED 
* OF THE POSSIBILITY OF SUCH DAMAGES, ARISING IN ANY WAY OUT 
* OF THIS AGREEMENT, THE PROGRAM, OR YOUR USE OF THE PROGRAM. 
* EXCLUDED DAMAGES INCLUDE, BUT ARE NOT LIMITED TO, COST OF 
* REMOVAL OR REINSTALLATION, COMPUTER TIME, LABOR COSTS, LOSS 
* OF GOODWILL, LOSS OF PROFITS, LOSS OF SAVINGS, OR LOSS OF 
* USE OR INTERRUPTION OF BUSINESS. IN NO EVENT WILL TI'S 
* AGGREGATE LIABILITY UNDER THIS AGREEMENT OR ARISING OUT OF 
* YOUR USE OF THE PROGRAM EXCEED FIVE HUNDRED DOLLARS 
* (U.S.$500).
*
* Unless otherwise stated, the Program written and copyrighted 
* by Texas Instruments is distributed as "freeware".  You may, 
* only under TI's copyright in the Program, use and modify the 
* Program without any charge or restriction.  You may 
* distribute to third parties, provided that you transfer a 
* copy of this license to the third party and the third party 
* agrees to these terms by its first use of the Program. You 
* must reproduce the copyright notice and any other legend of 
* ownership on each copy or partial copy, of the Program.
*
* You acknowledge and agree that the Program contains 
* copyrighted material, trade secrets and other TI proprietary 
* information and is protected by copyright laws, 
* international copyright treaties, and trade secret laws, as 
* well as other intellectual property laws.  To protect TI's 
* rights in the Program, you agree not to decompile, reverse 
* engineer, disassemble or otherwise translate any object code 
* versions of the Program to a human-readable form.  You agree 
* that in no event will you alter, remove or destroy any 
* copyright notice included in the Program.  TI reserves all 
* rights not specifically granted under this license. Except 
* as specifically provided herein, nothing in this agreement 
* shall be construed as conferring by implication, estoppel, 
* or otherwise, upon you, any license or other right under any 
* TI patents, copyrights or trade secrets.
*
* You may not use the Program in non-TI devices.
* ********************************************************* */
//*****************************************************************************
//  Filename:	 cfft_t6.c
//  Version:	 0.01
//  Description: test for cfft routine
//*****************************************************************************

#include <math.h>
#include <tms320.h>
#include <dsplib.h>
#include <stdio.h>
#include <stdlib.h>


#define NX 256
#define PI 3.141592653589793

#include "n256randscale32768.h"

DATA x1[2*NX];
#pragma DATA_SECTION (x1,".input")
DATA x2[2*NX];
#pragma DATA_SECTION (x2,".input")
LDATA x3[2*NX];
#pragma DATA_SECTION (x3,".input")


float x1_float[2*NX];
float x2_float[2*NX];
float x3_float[2*NX];

float x_float[2*NX];

int rand(void);

void main()
{
	int i;
	short scale_exp1, scale_exp2, scale_exp3;
	float noise_power_x1 = 0;
	float noise_power_x2 = 0;
	float noise_power_x3 = 0;
	float signal_power_x = 0;
	float SNR_x1 = 0;
	float SNR_x2 = 0;
	float SNR_x3 = 0;
	
//============================================================================/
//	transfer input data (created with Matlab) to arrays:
//	x1 - binary scaling 16-bit FFT
//	x2 - block floating-point 16-bit FFT
//	x3 - binary scaling 32-bit FFT	
//============================================================================/


for(i=0; i<NX; i++)
	{
		x1[2*i] = x[2*i];
		x1[2*i+1] = x[2*i+1];
		
	
		x2[2*i] = x[2*i];
		x2[2*i+1] = x[2*i+1];
		
		x3[2*i] = ((long) x[2*i])<<16;
		x3[2*i+1] = ((long) x[2*i+1]<<16);
	}
	

/*
//============================================================================/
//	Verify functionality:
//  create Q.15 sine wave for fft's. x1 is input to the fixed-point fft 
//	and x2 is the input to the block floating-point fft
//============================================================================/

for(i=0; i<NX; i++)
	{	
      	x2[2*i] = (int) ((200*sin(2*PI*i/8.0)));
      	x2[2*i+1] = x2[2*i];
      	
      	x1[2*i] = (int) (200*((float)rand()/RAND_MAX));
		x1[2*i+1] = x1[2*i];
		
	}
*/
	
//============================================================================/
//	call fixed-point fft and block floating-point fft
//============================================================================/
	cfft(x1,NX, SCALE);
	cbrev(x1,x1,NX);

	scale_exp2 = cfft_bfp(x2, NX);
    cbrev(x2,x2,NX);

	cfft32_SCALE(x3,NX);
	cbrev32(x3, x3, NX);

//============================================================================/
//	scale block floating-point output and convert both to floating point 
//  format for comparison with Matlab output	
//============================================================================/
	scale_exp1 = log(NX)/log(2);
	scale_exp3 = log(NX)/log(2)-16;
	for(i=0; i<2*NX; i++)
	{
		x1_float[i] = (float) (x1[i]);
		x1_float[i] = x1_float[i]*pow(2, scale_exp1);
		
		x2_float[i] = (float) (x2[i]);
		x2_float[i] = x2_float[i]*pow(2, -scale_exp2);

		x3_float[i] = (float) ((x3[i]));
		x3_float[i] = x3_float[i]*pow(2, scale_exp3);
	}

//============================================================================/
//	calculate SNR(i) using Matlab reference	
//============================================================================/
	for(i=0; i<2*NX; i++)
	{
		noise_power_x1 = pow((x_float[i] - x1_float[i]),2);
		noise_power_x2 = pow((x_float[i] - x2_float[i]),2);
		noise_power_x3 = pow((x_float[i] - x3_float[i]),2);
		signal_power_x = pow(x_float[i],2);
		SNR_x1 += 10*log(signal_power_x/noise_power_x1);
		SNR_x2 += 10*log(signal_power_x/noise_power_x2);
		SNR_x3 += 10*log(signal_power_x/noise_power_x3);
	}
	
	SNR_x1 /= (2*NX);
	SNR_x2 /= (2*NX);
	SNR_x3 /= (2*NX);
	
	
	printf("%f\n", SNR_x1);
	printf("%f\n", SNR_x2);
	printf("%f\n", SNR_x3);
			    	    	    
    return;
}
