/*********************************************************
 
         LINKER command file for LEAD3 memory map.
 
**********************************************************/

 
MEMORY
{
    PAGE 0:

        MMR     : origin = 0000000h, length = 00000c0h 
        SPRAM   : origin = 00000c0h, length = 0000040
        DARAM0  : origin = 0000100h, length = 0003F00h
        DARAM1  : origin = 0004000h, length = 0004000h
        DARAM2  : origin = 0008000h, length = 0004000h
        DARAM3  : origin = 000c000h, length = 0004000h 

        SARAM0  : origin = 0010000h, length = 0004000h
        SARAM1  : origin = 0014000h, length = 0004000h
        SARAM2  : origin = 0018000h, length = 0004000h
        SARAM3  : origin = 001c000h, length = 0004000h
        SARAM4  : origin = 0020000h, length = 0004000h
        SARAM5  : origin = 0024000h, length = 0004000h
        SARAM6  : origin = 0028000h, length = 0010000h
        SARAM11 : origin = 003c000h, length = 0010000h
       

        CE0     : origin = 0050000h, length = 03b0000h 
        CE1     : origin = 0400000h, length = 0400000h
        CE2     : origin = 0800000h, length = 0400000h
        CE3     : origin = 0c00000h, length = 03f8000h

        PDROM   : origin = 0ff8000h, length = 07f00h
        VECS    : origin = 0ffff00h, length = 00100h  /* reset vector */
}	

 
SECTIONS
{
        vectors  : {} > VECS   PAGE 0         /* interrupt vector table */
        .cinit   : {} > SARAM0 PAGE 0
        .text    : {} > SARAM11 PAGE 0

        .stack   : {} > DARAM0 PAGE 0
        .sysstack: {} > DARAM0 PAGE 0
        .sysmem  : {} > DARAM1 PAGE 0
        .data    : {} > DARAM1 PAGE 0
        .bss     : {} > SARAM1 PAGE 0
        .const   : {} > DARAM1 PAGE 0
        .cio     : {} > DARAM1 PAGE 0 		  /* added for debug */	

        files    : {} > DARAM2 PAGE 0         /* User-defined sections */
        statvar  : {} > DARAM2 PAGE 0
        statarry : {} > DARAM2 PAGE 0
        tempvar  : {} > DARAM2 PAGE 0
        temparry : {} > DARAM2 PAGE 0 


        .fftcode : {} > SARAM0 PAGE 0		  /*FFT-specific sections  */
        .test    : {} > DARAM2 PAGE 0
        .twiddle : {} > SARAM3 PAGE 0 
        .input   : {} > DARAM3 PAGE 0  /* memory alignment: (n+1) LSBs should be 0, while n=log2(nx) */
}