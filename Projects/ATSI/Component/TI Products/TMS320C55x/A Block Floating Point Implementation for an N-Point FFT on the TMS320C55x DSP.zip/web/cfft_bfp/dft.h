
void dft(int n, float x[], float y[])                               
       {                                                                   
          int k,i;                                                 
          const float pi = 3.141592653589793238462643;                                                                                          
          float arg, fy_0, fy_1;                   
                                                                           
          for(k = 0; k<n; k++)                                             
          {                                                                                                                      
            fy_0 = 0;                                                      
            fy_1 = 0;                                                      
            for(i=0; i<n; i++)                                             
            {                                                                                                                                                                                                
              arg = 2*pi*i*k/n;                                                                                       
              fy_0 += ((x[2*i] * cos(arg)) - (x[2*i+1] * -sin(arg)));                         
              fy_1 += ((x[2*i+1] * cos(arg)) + (x[2*i] * -sin(arg)));                         
            }                                                              
            y[2*k] = 2*fy_0/sqrt(n);                                
            y[2*k+1] = 2*fy_1/sqrt(n);                              
          }                                                               
       }           