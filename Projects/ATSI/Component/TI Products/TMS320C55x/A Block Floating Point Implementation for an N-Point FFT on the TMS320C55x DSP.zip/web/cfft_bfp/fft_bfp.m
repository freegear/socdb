n = 256;
pi = 3.141592653589793;

for l=2:15
scale = (2^l)/2;

for k=1:n
   x(k) = (scale*sin(2*pi*k/6) + scale*sin(2*pi*k/24));
   y(k) = i*(scale*sin(2*pi*k/6) + scale*sin(2*pi*k/24));
end

x = round(x);
x = double(x);
y = round(y);
y = double(y); 

if (scale)==2 fid = fopen('c:\ti\n256scale2.txt', 'w'); end   
if (scale)==4 fid = fopen('c:\ti\n256scale4.txt', 'w'); end   
if (scale)==8 fid = fopen('c:\ti\n256scale8.txt', 'w'); end 
if (scale)==16 fid = fopen('c:\ti\n256scale16.txt', 'w'); end 
if (scale)==32 fid = fopen('c:\ti\n256scale32.txt', 'w'); end 
if (scale)==64 fid = fopen('c:\ti\n256scale64.txt', 'w'); end 
if (scale)==128 fid = fopen('c:\ti\n256scale128.txt', 'w'); end 
if (scale)==256 fid = fopen('c:\ti\n256scale256.txt', 'w'); end 
if (scale)==512 fid = fopen('c:\ti\n256scale512.txt', 'w'); end 
if (scale)==1024 fid = fopen('c:\ti\n256scale1024.txt', 'w'); end 
if (scale)==2048 fid = fopen('c:\ti\n256scale2048.txt', 'w'); end 
if (scale)==4096 fid = fopen('c:\ti\n256scale4096.txt', 'w'); end 
if (scale)==8192 fid = fopen('c:\ti\n256scale8192.txt', 'w'); end 
if (scale)==16384 fid = fopen('c:\ti\n256scale16384.txt', 'w'); end 

fprintf(fid, '//fft input \n');
fprintf(fid, 'DATA x[2*NX] = \n{');

for k=1:n-1
fprintf(fid, '%i, ', real(x(k)));
fprintf(fid, '%i, \n', imag(y(k)));
end

fprintf(fid, '%i, ', real(x(n)));
fprintf(fid, '%i', imag(y(n)));
fprintf(fid, '}; \n\n');

q = x+y;
q = fft(q, n);

f = 1000*(1:n)/n;
plot(f, real(q), f, imag(q))
fprintf(fid, '//matlab fft output \n');
fprintf(fid, 'float x_float[2*NX] = \n{');

for k=1:n-1
fprintf(fid, '%f, ', real(q(k)));
fprintf(fid, '%f,\n', imag(q(k)));
end

fprintf(fid, '%f, ', real(q(n)));
fprintf(fid, '%f', imag(q(n)));
fprintf(fid, '}; \n\n');

fclose(fid);
end