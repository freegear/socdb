************************************************************************
**  File Name:	C5402Vec.asm
**  Part Number:  CODEC-EVM-SW-AIC12-0010
************************************************************************
**  Copyright (c) Texas Instruments, Inc. 2001, 2002
************************************************************************
**
**	Release History:
**	Version	 Date		Engr		Description
**	1.00	12-19-2001	Wendy X Fang	Original Release
**
************************************************************************
**
**  Function:
**	This routine initializes the 54xx DSK PLUS vector table.
**	(Note that each vector must occupates four(4)16-bit space.)
**
************************************************************************
**  References:
**  (1) TMS320C54x DSP, CPU and Peripheral (SPRU131)
**  (2) TMS320C54x DSP, Enhanced Peripheral (SPRU302)
************************************************************************

************************************************************************
** Include Statements
************************************************************************
	.global	_c_int00
	.global	_McBSP1RXISR, _McBSP1TXISR

	.sect	".vectors"
************************************************************************
**  Unmaskable Interrupts
************************************************************************
RESET:	BD	_c_int00	  ; HW/SW RESET vector
		NOP
		NOP
NMI:	RETE			; ~NMI, Non-Maskable interrupt
		NOP						
		NOP
		NOP

************************************************************************
**  S/W Interrupts
************************************************************************
SINT17:	RETE
		NOP
		NOP
		NOP
SINT18:	RETE
		NOP
		NOP
		NOP
SINT19:	RETE
		NOP
		NOP
		NOP
SINT20:	RETE
		NOP
		NOP
		NOP
SINT21:	RETE
		NOP 
		NOP
		NOP
SINT22:	RETE
		NOP
		NOP
		NOP
SINT23:	RETE
		NOP
		NOP
		NOP
SINT24:	RETE
		NOP
		NOP
		NOP
SINT25:	RETE
		NOP
		NOP
		NOP
SINT26:	RETE
		NOP
		NOP
		NOP
SINT27:	RETE
		NOP
		NOP
		NOP
SINT28:	RETE
		NOP
		NOP
		NOP
SINT29:	RETE
		NOP
		NOP
		NOP
SINT30:	RETE
		NOP
		NOP
		NOP

************************************************************************
**	Rest of the Interrupts
************************************************************************
INT0:	RETE			; external user interrupt #0
		NOP		
		NOP		
		NOP
INT1:	RETE			; external user interrupt #1
		NOP		
		NOP
		NOP
INT2:	RETE			; external user interrupt #2
		NOP		
		NOP
		NOP
TINT0:	RETE			; Timer0 interrupt
		NOP		
		NOP
		NOP					
BRINT0:	RETE			; McBSP#0 receive interrupt
		NOP
		NOP
		NOP
BXINT0:	RETE			; McBSP#0 transmit interrupt
		NOP
		NOP
		NOP
DMAC0:	RETE			; DMA channel0 interrupt
		NOP		
		NOP
		NOP
TINT1:	RETE			; Timer1 interrupt
		NOP		
		NOP
		NOP
INT3:	RETE			; external user interrupt #3
		NOP		
		NOP
		NOP
HPINT:	RETE			; HPI interrupt
		NOP		
		NOP
		NOP
BRINT1:	BD	_McBSP1RXISR	; McBSP#1 receive interrupt
		NOP
		NOP
BXINT1:	BD	_McBSP1TXISR	; McBSP#1 transmit interrupt
		NOP			 
		NOP
DMAC4:	RETE			; DMA channel4 interrupt
		NOP
		NOP
		NOP
DMAC5:	RETE			; DMA channel5 interrupt
		NOP		
		NOP
		NOP

	  .end 

************************************************************************
**  End of File -- C5402Vec.asm
************************************************************************
