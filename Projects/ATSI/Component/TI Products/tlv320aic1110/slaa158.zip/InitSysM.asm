************************************************************************
**  File Name:	InitSysM.asm
**  Part Number:  CODEC-EVM-SW-AIC12-0014.1
************************************************************************
**  Copyright (c) Texas Instruments, Inc. 2001, 2002
************************************************************************
**
**  Release History:
**	Version	 Date		Engr		Description
**	1.00	12-19-2001	Wendy X Fang	Original Release
**
************************************************************************
**
**  Function:
**	This routine initializes the variables and parameters of
**	the system, enable interrupts, and start main loop.
** 
************************************************************************
**  References:
************************************************************************

	.global	_InitSys
	.ref	  LoopCount	 ; main loop counter

************************************************************************
** Include Statements
************************************************************************
	.include  MMRegs.h

************************************************************************
**  Function Code
************************************************************************
	.text
 
_InitSys:
	NOP	

************************************************************************
**  Initialize Variable and Parameters
************************************************************************		
	LD	#LoopCount, DP	  ; set DP to the page having LoopCount
	NOP
	NOP
	ST	#0, LoopCount		; reset LoopCount
	NOP	 
	 
************************************************************************
**  Set McBSP1 to Continous Data RX/TX Mode
************************************************************************
******* Set Interrupt(s)
	STM	#0x0800, IMR		; enable BXINT1 interrupts
	STM	#0x3FFF, IFR		; reset all interrupt flags
	RSBX	INTM			; enable system interrupts

******* Enable McBSP1 for AIC Data RX/TX
	STM	SPCR1, McBSP1_SPSA	; ena McBSP1 RX for ADC data in
	LDM	McBSP1_SPSD,A
	OR	#0x0001, A
	STLM	A, McBSP1_SPSD
	STM	SPCR2, McBSP1_SPSA	; enable McBSP1 TX for DTMF out
	LDM	McBSP1_SPSD,A
	OR	#0x0001, A
	STLM	A, McBSP1_SPSD
	NOP
	RPT	#512			; waiting for 2 CLKG
	NOP 

************************************************************************
**  Start Main Loop
************************************************************************
	NOP
	LDM	TCR, A			; start timer0 for main loop
	AND	#0xFFEF, A		;	(by clear bit4 of TCR)
	STLM	A, TCR
			
************************************************************************
** Return to Main Routine
************************************************************************
	NOP
	RETD				; return to main
	NOP
	NOP

	.end

************************************************************************
**  End of File -- InitSysM.asm
************************************************************************
