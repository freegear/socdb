/***********************************************************************
**  File Name:	IntrSrvcS.c
**  Part Number:  CODEC-EVM-SW-AIC1110-0001.2
************************************************************************
**  Copyright (c) Texas Instruments, Inc. 2001, 2002
************************************************************************
**
**  Release History:
**	Version	 Date		Engr			Description
**	1.00	02-26-2002	Bolanle Onodipe	Original Release
**
************************************************************************
**
**  Function:
**	This file includes all interrupt service routines (ISR) for
**	T5402 DSP that communicates to a stand-along slave AIC12 CODECs.
**
************************************************************************
**  References:
**	(1) TMS320C54x DSP, CPU and Peripheral (SPRU131)
**	(2) TMS320C54x DSP, Enhanced Peripheral (SPRU302)
**	(3) Data Manual: TLV320AIC12, Very Low Power, Low Voltage CMOS, 
**	  16-bit, 26-KSPS CODEC
***********************************************************************/

/***********************************************************************
** Include Statements
***********************************************************************/
#include	"IntrSrvc.h" 

/***********************************************************************
**  Interrupt Serivece Routines
***********************************************************************/
/******** This ISR responds to McBSP1 receive ready (RRDY)
		flags to load ADC data from McBSP RX register
		and send DAC date to AIC12 for output
		This interrupt occures at FSR frequency!  *******/
interrupt void McBSP1RXISR()
{  
	IFR	|= 0x0400;		  /* reset BRINT1 interrupt flag */  
}

/******** This ISR responds to McBSP1 transmit frame sync (FSX)
		to reset  McBSP1 Frame Counter Load/Send Data  *********/
interrupt void McBSP1TXISR()
{ 
	SL_ADC = McBSP1_DRR1;	/* load slave AIC ADC result	*/
	McBSP1_DXR1 = SL_ADC;
	IFR |= 0x0800;		  /* reset BXINT1 interrupt flag	*/  
}

/***********************************************************************
**  End of File -- IntrSrvcS.c
***********************************************************************/
