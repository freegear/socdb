/***********************************************************************
**  File Name:    IntrSrvc.h
**  Part Number:  CODEC-EVM-SW-AIC12-0101
************************************************************************
**  Copyright (c) Texas Instruments, Inc. 2001
************************************************************************
**
**  Release History:
**     Version       Date           Engr          Description
**      1.00      11-05-2001      Wendy X Fang   Original Release
**
************************************************************************
**
**  Function:
**    This is the head file of the ISR file -- IntrSrvc.c, which defines
**    or refers to all variables and parameters the ISR file uses.
**
***********************************************************************/

/***********************************************************************
**  Define Statements for MMRs
***********************************************************************/
#define IMR          (*(volatile unsigned int *)0x0000)
#define IFR          (*(volatile unsigned int *)0x0001)

#define McBSP0_DRR2  (*(volatile unsigned int *)0x0020)
#define McBSP0_DRR1  (*(volatile unsigned int *)0x0021)
#define McBSP0_DXR2  (*(volatile unsigned int *)0x0022)
#define McBSP0_DXR1  (*(volatile unsigned int *)0x0023)

#define McBSP1_DRR2  (*(volatile unsigned int *)0x0040)
#define McBSP1_DRR1  (*(volatile unsigned int *)0x0041)
#define McBSP1_DXR2  (*(volatile unsigned int *)0x0042)
#define McBSP1_DXR1  (*(volatile unsigned int *)0x0043)

/***********************************************************************
**  Global Varaibles Used for TX from McBSP0 to AIC10s
***********************************************************************/
extern   int  ToneWave;           /* DTMF tone wave form */
extern   int  SOut;               /* security voice or farend output */
extern   int  MicPhIn;            /* microphone input */

/***********************************************************************
**  Global Varaibles Used for Loading AIC10s' ADC Data
***********************************************************************/
int           MS_ADC    = 0;      /* master AIC ADC data storage */
int           SL_ADC    = 0;      /* slave1 AIC ADC data storage */

/***********************************************************************
**  Local Variables
***********************************************************************/
unsigned int  McBSP1Frame = 0;    /* McBSP1 comm to AIC EVM frame */
           
/***********************************************************************
**  End of File -- IntrSrvc.h
***********************************************************************/
