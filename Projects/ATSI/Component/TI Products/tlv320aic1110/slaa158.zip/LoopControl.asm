************************************************************************
**	File Name:	LoopControl.asm
**	Part Number:	CODEC-EVM-SW-AIC12-0015
************************************************************************
**	Copyright (c) Texas Instruments, Inc. 2001, 2002
************************************************************************
**
**	Release History:
**	Version	Date		Engr		Description
**	1.00	12-18-2001	Wendy X Fang	Original Release
**
************************************************************************
**
**	Function: 
**	This program has the following two functions:
**	(1) control main loop repeat rate, here is equals to 10KHz
**		(using time0 to control and where
**			=CPUCLKFreq/(TDDR+1)/(PRD+1)=50M/3125=16KHz)
**	(2) flash XF pin at 1hz rate to indicate the main loop is running
**		(which can also be called DSP safety checking and indicating).
**
************************************************************************
**	References:
**		(1) TMS320C54x DSP, CPU and Peripheral (SPRU131)
************************************************************************

	.global	_LoopControl

************************************************************************
** Include Statements
************************************************************************
	.include		MMRegs.h

************************************************************************
**	Varaible & Initialization
************************************************************************
	.global	InitVari, LoopCount
	 
InitVari	.usect ".variable", 1	; initial point of data 
Spares	 	.usect ".variable", 5	; spare space
LoopCount	.usect ".variable", 1	; main loop counter (system var)	
		
************************************************************************
**	Function Routine
************************************************************************
_LoopControl:
	NOP

******* Wait for Starting Next Loop *******
LoopWait:				 ; wait for timer0 return to zero
	NOP
	LDM	IFR, A			; load interupt flag
	AND	#0x0008, A		; mask out timer0 intr flag
	BC LoopWait, AEQ		; check if tim0 intr occured
	NOP				 ; no:	waiting
	OR #0x0008, A		; yes: clear timer0 interrupt flag
	STLM A, IFR
	LD	#LoopCount, DP		; set DP to the page having LoopCount
	NOP
	NOP

****** Toggle/Flash XF at Frequency 1Hz *******
	ADDM #1, LoopCount		; increase LoopCounter by 1
	LD	LoopCount, A
	SUB	#8000, A			; t=8000*2*(3125/50M)=1sec
	BC	LoopEnd, ALT		; if not 1/2t, wait for mext loop 
	NOP				 ; else: toggle XF
	NOP

	ST	#0, LoopCount		; reset LoopCount
	LDM	ST1, A			; check XF status: load ST1
	AND	#0x2000, A		;	& mask out XF
	BC	SetXF, AEQ		; if XF=0, to set XF=1
	NOP
	NOP
	RSBX XF				; else (XF=1), to set XF=0
	B LoopEnd
	NOP
SetXF:
	NOP
	SSBX XF
	NOP
LoopEnd:
	NOP
	RETD				; return
	NOP
	NOP
	
	.end

************************************************************************
**	End of File -- LoopControl.asm
************************************************************************
 