************************************************************************
**  File Name:	MMRegs.h
**  Part Number:  CODEC-EVM-SW-AIC12-0100
************************************************************************
**  Copyright (c) Texas Instruments, Inc. 2001, 2002
************************************************************************
**
**  Release History:
**	Version	Date		Engr		Description
**	1.00	05-22-2002	Bolanle Onodipe	Original Release
**
************************************************************************
**
**  Function:
**	1. Memory-Maped Registers (MMR) are mapped to data-page memory
**	(page1 & Address: 0x0000 to 0x005F). Note that the assembly
**	tool ".mmregs" can NOT be used in C5402 directly 
**	2. Sub-bank addresses for McBSP and DMA are defined, and
**	3. Addresses for C5402 DSK on-board IO ports are defined.
**
************************************************************************
**  References:
**	(1) TMS320VC5402 Fixed-Point Digital Signal Processor (SPRS079D)
**	(2) TMS320C54x DSP, CPU and Peripheral (SPRU131)
**	(3) TMS320C54x DSP, Enhanced Peripheral (SPRU302)
************************************************************************

************************************************************************
** C5402 Memory Mapped Register Definations (On Data-Page or Page1) 
************************************************************************
******** Map Interrupt Registers to Data Page Addresses
IMR	.set	0x0000	; interrupt mask reg
IFR	.set	0x0001	; interrupt mask reg

******** Map CPU Registers to Data Page Addresses
ST0	.set	0x0006	; CPU status reg0
ST1	.set	0x0007	; CPU status reg1
A	 .set	0x0008	; CPU accumulator A
AL	.set	0x0008	; CPU accumulator A low word
AH	.set	0x0009	; CPU accumulator A high word
AG	.set	0x000A	; CPU accumulator A guard word
B	 .set	0x000B	; CPU accumulator B
BL	.set	0x000B	; CPU accumulator B low word
BH	.set	0x000C	; CPU accumulator B high word
BG	.set	0x000D	; CPU accumulator B guard word
TREG	.set	0x000E	; CPU temporary reg
TRN	.set	0x000F	; CPU transition reg
* AR0	.set	0x0010	; CPU auxiliary reg0
* AR1	.set	0x0011	; CPU auxiliary reg1
* AR2	.set	0x0012	; CPU auxiliary reg2
* AR3	.set	0x0013	; CPU auxiliary reg3
* AR4	.set	0x0014	; CPU auxiliary reg4
* AR5	.set	0x0015	; CPU auxiliary reg5
* AR6	.set	0x0016	; CPU auxiliary reg6
* AR7	.set	0x0017	; CPU auxiliary reg7
* SP	.set	0x0018	; CPU stack pointer reg
BK	.set	0x0019	; CPU circular buffer size reg
BRC	.set	0x001A	; CPU block repeat counter
RSA	.set	0x001B	; CPU block repeat start address
REA	.set	0x001C	; CPU block repeat end address

******* Map System Registers to Data Page Addresses 
PMST	.set	0x001D	; processor mode status reg
XPC	.set	0x001E	; extended program page reg
SWWSR	.set	0x0028	; software wait-state reg
BSCR	.set	0x0029	; bank-switching control reg
SWCR	.set	0x002B	; software wait-state control reg
HPIC	.set	0x002C	; HPI control register
CLKMD	.set	0x0058	; clock mode reg

******** Map McBSP0 Registers to Data Page Addresses
McBSP0_DRR2	.set	0x0020	; McBSP0 data Rx reg2
McBSP0_DRR1	.set	0x0021	; McBSP0 data Rx reg1
McBSP0_DXR2	.set	0x0022	; McBSP0 data Tx reg2
McBSP0_DXR1	.set	0x0023	; McBSP0 data Tx reg1

McBSP0_SPSA .set	0x0038	; McBSP0 sub bank addr reg
McBSP0_SPSD .set	0x0039	; McBSP0 sub bank data reg

******** Map McBSP1 Registers to Data Page Addresses
McBSP1_DRR2	.set	0x0040	; McBSP1 data Rx reg2
McBSP1_DRR1	.set	0x0041	; McBSP1 data Rx reg1
McBSP1_DXR2	.set	0x0042	; McBSP1 data Tx reg2
McBSP1_DXR1	.set	0x0043	; McBSP1 data Tx reg1

McBSP1_SPSA .set	0x0048	; McBSP1 sub bank addr reg
McBSP1_SPSD .set	0x0049	; McBSP1 sub bank data reg

******** Map Timer0 Registers to Data Page Addresses
TIM	.set	0x0024	; timer0 reg
PRD	.set	0x0025	; timer0 period reg
TCR	.set	0x0026	; timer0 control reg

******** Map Timer1 Registers to Data Page Addresses
TIM1	.set	0x0030	; timer1 reg
PRD1	.set	0x0031	; timer1 period reg
TCR1	.set	0x0032	; timer1 control reg

******** Map General IO Port (Pins) Registers to Data Page Addresses
GPIOCR	.set	0x003C	;GP I/O Pins Control Reg
GPIOSR	.set	0x003D	;GP I/O Pins Status Reg

******* Map DMA Registers to Data Page Addresses
DMPREC	.set	0x0054	; DMA channel priority and ebanle control
DMSA	.set	0x0055	; DMA subbank address reg
DMSDI	.set	0x0056	; DMA subbank data reg w/autoincrement
DMSDN	.set	0x0057	; DMA subbank data reg

************************************************************************
** Sub-Bank Address Definations
** (C5402 is a cost efficient DSP and McBSP and DMA control MMRs are put
**	 into sub-address for keeping MMR block small and compact).
************************************************************************

******** McBSP Sub-Bank Register Addresses 
SPCR1	.set	0x0000	; McBSP Ser Port Ctrl Reg1
SPCR2	.set	0x0001	; McBSP Ser Port Ctrl Reg2
RCR1	.set	0x0002	; McBSP Rx Ctrl Reg1
RCR2	.set	0x0003	; McBSP Rx Ctrl Reg2
XCR1	.set	0x0004	; McBSP Tx Ctrl Reg1
XCR2	.set	0x0005	; McBSP Tx Ctrl Reg2
SRGR1	.set	0x0006	; McBSP Sample Rate Gen Reg1
SRGR2	.set	0x0007	; McBSP Sample Rate Gen Reg2
MCR1	.set	0x0008	; McBSP Multichan Reg1
MCR2	.set	0x0009	; McBSP Multichan Reg2
RCERA	.set	0x000A	; McBSP Rx Chan Enable Reg PartA
RCERB	.set	0x000B	; McBSP Rx Chan Enable Reg PartB
XCERA	.set	0x000C	; McBSP Tx Chan Enable Reg PartA
XCERB	.set	0x000D	; McBSP Tx Chan Enable Reg PartB
PCR	.set	0x000E	; McBSP Pin Ctrl Reg

******* (6 Channels) DMA Sub-Bank Register Addresses 
DMARC0	.set	0x0000	; DMA channel0 source address reg
DMDST0	.set	0x0001	; DMA channel0 destination address reg
DMCTR0	.set	0x0002	; DMA channel0 element count reg
DMDFC0	.set	0x0003	; DMA channel0 sync sel & frame count reg
DMMCR0	.set	0x0004	; DMA channel0 transfer mode cntrl reg

DMARC1	.set	0x0005	; DMA channel1 source address reg
DMDST1	.set	0x0006	; DMA channel1 destination address reg
DMCTR1	.set	0x0007	; DMA channel1 element count reg
DMDFC1	.set	0x0008	; DMA channel1 sync sel & frame count reg
DMMCR1	.set	0x0009	; DMA channel1 transfer mode cntrl reg

DMARC2	.set	0x000A	; DMA channel2 source address reg
DMDST2	.set	0x000B	; DMA channel2 destination address reg
DMCTR2	.set	0x000C	; DMA channel2 element count reg
DMDFC2	.set	0x000D	; DMA channel2 sync sel & frame count reg
DMMCR2	.set	0x000E	; DMA channel2 transfer mode cntrl reg

DMARC3	.set	0x000F	; DMA channel3 source address reg
DMDST3	.set	0x0010	; DMA channel3 destination address reg
DMCTR3	.set	0x0011	; DMA channel3 element count reg
DMDFC3	.set	0x0012	; DMA channel3 sync sel & frame count reg
DMMCR3	.set	0x0013	; DMA channel3 transfer mode cntrl reg

DMARC4	.set	0x0014	; DMA channel4 source address reg
DMDST4	.set	0x0015	; DMA channel4 destination address reg
DMCTR4	.set	0x0016	; DMA channel4 element count reg
DMDFC4	.set	0x0017	; DMA channel4 sync sel & frame count reg
DMMCR4	.set	0x0018	; DMA channel4 transfer mode cntrl reg

DMARC5	.set	0x0019	; DMA channel5 source address reg
DMDST5	.set	0x001A	; DMA channel5 destination address reg
DMCTR5	.set	0x001B	; DMA channel5 element count reg
DMDFC5	.set	0x001C	; DMA channel5 sync sel & frame count reg
DMMCR5	.set	0x001D	; DMA channel5 transfer mode cntrl reg

DMSRCP	.set	0x001E	; DMA source prog page address
DMDSTP	.set	0x001F	; DMA destination prog page address
DMIDX0	.set	0x0020	; DMA element index address reg0
DMIDX1	.set	0x0021	; DMA element index address reg1
DMFRI0	.set	0x0022	; DMA frame index reg0
DMFRI1	.set	0x0023	; DMA frame index reg1
DMGSA	.set	0x0024	; DMA global source address reload reg
DMGDA	.set	0x0025	; DMA global destination address reload reg
DMGCA	.set	0x0026	; DMA global counter reload reg
DMGFA	.set	0x0027	; DMA global frame count reload reg

************************************************************************
** C5402 DSK On-Board I/O Memory Mapped Registers
************************************************************************
DSP_CPLD_CNTL1	.set	0000h	;Control Reg1
DSP_CPLD_STAT	.set	0001h	;Status Reg
DSP_CPLD_DMCNTL	.set	0002h	;Data Memory Control Reg
DSP_CPLD_DBIO	.set	0003h	;Daughter Brd / GPIO Reg
DSP_CPLD_CNTL2	.set	0004h	;Control Reg2
DSP_CPLD_SEM0	.set	0005h	;Semaphore 0
DSP_CPLD_SEM1	.set	0006h	;Semaphore 1

************************************************************************
** End of File -- MMRegs.h
************************************************************************
