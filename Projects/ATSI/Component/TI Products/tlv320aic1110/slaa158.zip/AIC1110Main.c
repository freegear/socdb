/***********************************************************************
**  File Name:	AIC12Main.c
**  Part Number:  CODEC-EVM-SW-AIC12-0000
************************************************************************
**  Copyright (c) Texas Instruments, Inc. 2001, 2002
************************************************************************
**
**  Release History:
**	Version	 Date		Engr		Description
**	1.00	05-22-2002	Bolanle Onodipe	Original Release
**
************************************************************************
**
**  Function:
**	This C code is written for using the TI's C54 Code Composer
**	Studio platform. It serves as the main program for C54xx DSP 
**	interfacing with the AIC1110 CODEC(s). It communicates with, and 
**	controls the AIC1110 CODEC(s) on the daughter EVM.
**
************************************************************************
**  References:
**	(1) TMS320C54x DSP, CPU and Peripheral (SPRU131)
***********************************************************************/

/***********************************************************************
** External Functions Called by Main()
***********************************************************************/

/******* DSP & AIC1110 System Routines *******/
extern void InitC5402(void);
extern void InitSys(void);
extern void LoopControl(void);


/***********************************************************************
** Main Function Program
***********************************************************************/
void  main(void)
{
	InitC5402();			/* initialize C5402 DSP	  */
	InitSys();			/* initialize variables/paras  */
	while (1)
	{
		LoopControl();		/* control main-loop rate	*/ 
	} 
}

/***********************************************************************
**  End of File -- AIC12Main.c
***********************************************************************/
