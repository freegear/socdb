/***********************************************************************
**  File Name:    IntrSrvcM.c
**  Part Number:  CODEC-EVM-SW-00001.1
************************************************************************
**  Copyright (c) Texas Instruments, Inc. 2001, 2002
************************************************************************
**
**  Release History:
**     Version       Date           Engr          Description
**      1.00      12-18-2001      Wendy X Fang   Original Release
**
************************************************************************
**
**  Function:
**    This file includes all interrupt service routines (ISR) for
**    T5402 DSP that communicates to a Stand-Along Master
**    AIC12 CODEC.
**
************************************************************************
**  References:
**    (1) TMS320C54x DSP, CPU and Peripheral (SPRU131)
**    (2) TMS320C54x DSP, Enhanced Peripheral (SPRU302)
**    (3) Data Manual: TLV320AIC12, Very Low Power, Low Voltage CMOS, 
**        16-bit, 26-KSPS CODEC
***********************************************************************/

/***********************************************************************
** Include Statements
***********************************************************************/
#include   "IntrSrvc.h" 

/***********************************************************************
**  Interrupt Serivece Routines
***********************************************************************/
/******** This ISR responds to McBSP1 transmit frame sync (FSX)
          to reset  McBSP1 Frame Counter Load/Send Data *********/
interrupt void McBSP1TXISR()
{ 
    MS_ADC      = McBSP1_DRR1;    /* load master AIC ADC result    */
    McBSP1_DXR1 = ToneWave&0xFFFE;/* DTMF tone to slave AIC DAC     */
/*    McBSP1_DXR1 = SOut&0xFFFE;     securied voice to mstr AIC DAC  */
/*    McBSP1_DXR1 = MicPhIn&0xFFFE;  microphone inp to mstr AIC DAC  */
    IFR        |= 0x0800;          /* reset BXINT1 interrupt flag    */
}
 
/***********************************************************************
**  End of File -- IntrSrvcM.c
***********************************************************************/
