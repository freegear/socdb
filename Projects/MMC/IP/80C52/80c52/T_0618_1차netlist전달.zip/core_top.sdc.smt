#####################################################

#  Created by Design Compiler write_sdc on Mon Jun 18 20:21:07 2007

#####################################################
set sdc_version 1.4

create_clock -period 8.4 -waveform {0 4.2} [get_ports {clk_cpu}]
create_clock -period 8.4 -waveform {0 4.2} [get_ports {clk_peri}]
create_clock -period 8.4 -waveform {0 4.2} [get_ports {clk_wdt}]
set_max_fanout 30 [current_design]
set_max_transition 0.3 [current_design]
set_max_area 0
set_operating_conditions "slow" -library "slow"
set_wire_load_mode "enclosed" 
