/*********************************************************************
*
*   This confidential and proprietary software may be used only as
*   authorised by a licensing agreement from CORERIVER Semiconductor
*   Co., Ltd.
*
*   (c) Copyright 2006 CORERIVER Semiconductor Co., Ltd.
*     All Rights Reserved
*
*   The entire notice above must be reproduced on all authorised
*   copies and copies may only be made to the extent permitted
*   by a licensing agreement from CORERIVER Semiconductor Co., Ltd.
*
* -------------------------------------------------------------------
*
*   FILE          : ext_sfr_test.v
*   AUTHOR        : CORERIVER
*   DESCRIPTION   : 
*   VERSION       : $Revision:$ ($Date:$)
*   COMMENT       :
* 
*********************************************************************/
module  ext_sfr_test( 
CLK, 
RESET, 
EXT_SFR_DIN, 
EXT_SFR_DOUT, 
EXT_SFR_ADDR, 
EXT_SFR_WR 
);

input		CLK;
input		RESET;
output	[7:0]	EXT_SFR_DIN;
input 	[7:0]	EXT_SFR_DOUT;
input 	[8:0]	EXT_SFR_ADDR;
input		EXT_SFR_WR;

`define	EXT_SFR_REGF_SEL 	9'h1FF
`define	EXT_SFR_REGE_SEL 	9'h1FE
`define	EXT_SFR_REGD_SEL 	9'h1FD
`define	EXT_SFR_REGC_SEL 	9'h1FC
`define	EXT_SFR_REGB_SEL 	9'h1FB
`define	EXT_SFR_REGA_SEL 	9'h1FA

reg		[7:0]	EXT_SFR_DIN;
reg		[7:0]	EXT_SFR_REGF;
reg		[7:0]	EXT_SFR_REGE;
reg		[7:0]	EXT_SFR_REGD;
reg		[7:0]	EXT_SFR_REGC;
reg		[7:0]	EXT_SFR_REGB;
reg		[7:0]	EXT_SFR_REGA;

always 	@(EXT_SFR_ADDR or EXT_SFR_REGF or EXT_SFR_REGE or EXT_SFR_REGD or
					EXT_SFR_REGC or EXT_SFR_REGB or EXT_SFR_REGA)
begin
	case(EXT_SFR_ADDR)	//synopsys parallel_case
		`EXT_SFR_REGF_SEL	:	EXT_SFR_DIN	= EXT_SFR_REGF;
		`EXT_SFR_REGE_SEL	:	EXT_SFR_DIN	= EXT_SFR_REGE;
		`EXT_SFR_REGD_SEL	:	EXT_SFR_DIN	= EXT_SFR_REGD;
		`EXT_SFR_REGC_SEL	:	EXT_SFR_DIN	= EXT_SFR_REGC;
		`EXT_SFR_REGB_SEL	:	EXT_SFR_DIN	= EXT_SFR_REGB;
		`EXT_SFR_REGA_SEL	:	EXT_SFR_DIN	= EXT_SFR_REGA;
		default						: EXT_SFR_DIN	= 8'h00;
	endcase
end

		
always @(posedge CLK or posedge RESET)
	if(RESET)
		EXT_SFR_REGF	<= 8'h00;
	else
		if(EXT_SFR_ADDR == 9'h1FF) 	EXT_SFR_REGF	<= EXT_SFR_DOUT;

always @(posedge CLK or posedge RESET)
	if(RESET)
		EXT_SFR_REGE	<= 8'h00;
	else
		if(EXT_SFR_ADDR == 9'h1FE) 	EXT_SFR_REGE	<= EXT_SFR_DOUT;

always @(posedge CLK or posedge RESET)
	if(RESET)
		EXT_SFR_REGD	<= 8'h00;
	else
		if(EXT_SFR_ADDR == 9'h1FD) 	EXT_SFR_REGD	<= EXT_SFR_DOUT;

always @(posedge CLK or posedge RESET)
	if(RESET)
		EXT_SFR_REGC	<= 8'h00;
	else
		if(EXT_SFR_ADDR == 9'h1FC) 	EXT_SFR_REGC	<= EXT_SFR_DOUT;

always @(posedge CLK or posedge RESET)
	if(RESET)
		EXT_SFR_REGB	<= 8'h00;
	else
		if(EXT_SFR_ADDR == 9'h1FB) 	EXT_SFR_REGB	<= EXT_SFR_DOUT;

always @(posedge CLK or posedge RESET)
	if(RESET)
		EXT_SFR_REGA	<= 8'h00;
	else
		if(EXT_SFR_ADDR == 9'h1FA) 	EXT_SFR_REGA	<= EXT_SFR_DOUT;

endmodule
