
module core_top ( user_init_pc, user_init_pc_en, RESET_pin, final_all_reset, 
        final_POR_ext_reset, wdt_reset, xrom_addr, xrom_ce_b, xrom_oe_b, 
        xrom_dout, xram_addr, xram_din, xram_ce_b, xram_oe_b, xram_we_b, 
        xram_dout, iram_addr, iram_din, iram_ce_b, iram_oe_b, iram_we_b, 
        iram_dout, clk_cpu, clk_peri, clk_wdt, WDT_RUN, pdwn, idle, EA, ALE, 
        PSEN, P0_DIN, P0_DOUT, P1_DIN, P1_DOUT, P2_DIN, P2_DOUT, P3_DIN, 
        P3_DOUT, INT0_B, INT1_B, INT2, INT3_B, INT4, INT5_B, T0_PIN, T1_PIN, 
        T2_PIN, T2EX_PIN, T2_OUT, RX_PIN, TX_PIN, PWM1_OUT, PWM2_OUT, 
        EXT_SFR_DIN, EXT_SFR_DOUT, EXT_SFR_ADDR, EXT_SFR_WR );
  input [15:0] user_init_pc;
  output [15:0] xrom_addr;
  input [7:0] xrom_dout;
  output [15:0] xram_addr;
  output [7:0] xram_din;
  input [7:0] xram_dout;
  output [7:0] iram_addr;
  output [7:0] iram_din;
  input [7:0] iram_dout;
  input [7:0] P0_DIN;
  output [7:0] P0_DOUT;
  input [7:0] P1_DIN;
  output [7:0] P1_DOUT;
  input [7:0] P2_DIN;
  output [7:0] P2_DOUT;
  input [7:0] P3_DIN;
  output [7:0] P3_DOUT;
  input [7:0] EXT_SFR_DIN;
  output [7:0] EXT_SFR_DOUT;
  output [8:0] EXT_SFR_ADDR;
  input user_init_pc_en, RESET_pin, final_all_reset, final_POR_ext_reset,
         clk_cpu, clk_peri, clk_wdt, EA, INT0_B, INT1_B, INT2, INT3_B, INT4,
         INT5_B, T0_PIN, T1_PIN, T2_PIN, T2EX_PIN, RX_PIN;
  output wdt_reset, xrom_ce_b, xrom_oe_b, xram_ce_b, xram_oe_b, xram_we_b,
         iram_ce_b, iram_oe_b, iram_we_b, WDT_RUN, pdwn, idle, ALE, PSEN,
         T2_OUT, TX_PIN, PWM1_OUT, PWM2_OUT, EXT_SFR_WR;
  wire   n22, n23, n24, n25, n26, n27, n28, n29, n30, PCON_7_, PCON_6_,
         PCON_5_, PCON_4_, PCON_3_, PCON_2_, ALE_B_I, PSEN_B, ALE_B, EWT, EWDI,
         IR_EN, pre_idle, pre_pdwn_idle, DIR_WR, RETI_end, RETI_NFC, ALEOFF,
         PERI_SFR_sel, read_modify, inter_LCALL, P0_sel, P1_sel, P2_sel,
         P3_sel, interrupt_ack, STOPwake_INT0, STOPwake_INT1, STOPwake_WDT,
         TF0, TF1, t2_intr, ua_intr, wdt_intr, TCON_sel, EXIF_sel, IE_sel,
         IP_sel, EIE_sel, EIP_sel, IPH_sel, clear_TF0, clear_TF1, sample_INT0,
         sample_INT1, pre_pdwn, Z_update, T0M, T0M_S1, T0M_S2, T0M_S5, T0M_S6,
         T1M, T1M_S1, T1M_S2, T1M_S4, T1M_S5, T1M_S6, T2M, T2M_S1, T2M_S2,
         TH0_sel, TL0_sel, TH1_sel, TL1_sel, TMOD_sel, T1_overflow, T2CON_sel,
         T2MOD_sel, TH2_sel, TL2_sel, RCAP2L_sel, RCAP2H_sel, T2_uart_clk,
         RCLK, TCLK, SCON_sel, SBUF_sel, SADDR_sel, SADEN_sel, SMOD1_update,
         SMOD1, SMOD0, PCON_sel, PWM1CON_sel, PWM2CON_sel, PWM1D_sel,
         PWM2D_sel, CKCON_sel, WDCON_sel, PMR_sel, n4, n5, n7, n8, n9, n10,
         n11, n12, n20;
  wire   [7:0] P2_SFR;
  wire   [7:0] SFR_DATA;
  wire   [7:0] IDATA;
  wire   [7:0] inter_vector;
  wire   [7:0] P0_OUT;
  wire   [7:0] P1_OUT;
  wire   [7:0] P2_OUT;
  wire   [7:0] P3_OUT;
  wire   [2:0] peri_state;
  wire   [3:0] TCON30;
  wire   [7:0] INT_SFR_OUT;
  wire   [7:0] T01_SFR_OUT;
  wire   [7:0] T2_SFR_OUT;
  wire   [7:0] UART_SFR_OUT;
  wire   [7:0] PWM_SFR_OUT;
  wire   [7:0] WDT_SFR_OUT;
  wire   [7:0] PMR_OUT;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1;

  cpu cpu ( .IR_EN(IR_EN), .ACC(xram_din), .user_init_pc(user_init_pc), 
        .user_init_pc_en(user_init_pc_en), .xram_dout(xram_dout), .pre_idle(
        pre_idle), .pre_pdwn_idle(pre_pdwn_idle), .DIR_WR(DIR_WR), .PDWN(pdwn), 
        .IDLE(idle), .POR(final_POR_ext_reset), .IRAM_DIN(iram_din), 
        .RETI_NFC(RETI_NFC), .INT_EN_1_EN(RETI_end), .EA(EA), .RESET(n9), 
        .CLK(clk_cpu), .RAM_CS_B(iram_ce_b), .RAM_WE_B(iram_we_b), .RAMADDR(
        iram_addr), .RAMOUT(iram_dout), .ALEOFF(ALEOFF), .P2_SFR(P2_SFR), 
        .XMEM_L(xrom_addr[7:0]), .XMEM_H(xrom_addr[15:8]), .XA(xram_addr), 
        .P0_IN(xrom_dout), .ALE_B_I(ALE_B_I), .ALE_B_X(ALE_B), .PSEN_B_X(
        PSEN_B), .PERI_SFR_DATA(SFR_DATA), .PERI_SFR_sel(PERI_SFR_sel), 
        .IDATA(IDATA), .MAR(EXT_SFR_ADDR), .SFR_wr(n30), .XRAM_CE_B(xram_ce_b), 
        .XRAM_WR_B(xram_we_b), .XRAM_RD_B(xram_oe_b), .read_modify(read_modify), .inter_LCALL(inter_LCALL), .inter_vector({1'b0, inter_vector[6:3], 1'b0, 
        inter_vector[1:0]}) );
  port0 port0 ( .sw_rst(final_all_reset), .clk(clk_peri), .P0_DOUT(P0_DOUT), 
        .SFR_bus({EXT_SFR_DOUT[7:1], n4}), .P0_sel(P0_sel), .SFR_wr(EXT_SFR_WR), .pin_P0(P0_DIN), .read_modify(n7), .P0_OUT(P0_OUT) );
  port1 port1 ( .sw_rst(final_all_reset), .clk(clk_peri), .P1_DOUT(P1_DOUT), 
        .SFR_bus({EXT_SFR_DOUT[7:1], n4}), .P1_sel(P1_sel), .SFR_wr(EXT_SFR_WR), .read_modify(read_modify), .P1_OUT(P1_OUT), .pin_P1(P1_DIN) );
  port2 port2 ( .sw_rst(final_all_reset), .clk(clk_peri), .P2_DOUT(P2_DOUT), 
        .SFR_bus({EXT_SFR_DOUT[7:1], n4}), .SFR_wr(EXT_SFR_WR), .P2_sel(P2_sel), .pin_P2(P2_DIN), .read_modify(n7), .P2_OUT(P2_OUT), .P2_SFR(P2_SFR) );
  port3 port3 ( .sw_rst(final_all_reset), .clk(clk_peri), .P3_DOUT(P3_DOUT), 
        .SFR_bus({EXT_SFR_DOUT[7:1], n4}), .P3_sel(P3_sel), .SFR_wr(EXT_SFR_WR), .pin_P3(P3_DIN), .read_modify(n7), .P3_OUT(P3_OUT) );
  interrupt interrupt ( .EWDI(EWDI), .STOPwake_WDT(STOPwake_WDT), .DIR_WR(
        DIR_WR), .LVD_intr(1'b0), .POR(final_POR_ext_reset), .sw_rst(n10), 
        .clk(clk_peri), .pin_INT0(INT0_B), .pin_INT1(INT1_B), .pin_INT2(INT2), 
        .pin_INT3(INT3_B), .pin_INT4(INT4), .pin_INT5(INT5_B), .TF0(TF0), 
        .TF1(TF1), .adc_intr(1'b0), .t2_intr(t2_intr), .ua_intr(ua_intr), 
        .wdt_intr(wdt_intr), .pwm1_intr(1'b0), .pwm2_intr(1'b0), .pr_st(
        peri_state), .RETI_end(RETI_end), .RETI_NFC(RETI_NFC), .SFR_wr(
        EXT_SFR_WR), .SFR_bus(EXT_SFR_DOUT), .TCON_sel(TCON_sel), .EXIF_sel(
        EXIF_sel), .IE_sel(IE_sel), .IP_sel(IP_sel), .EIE_sel(EIE_sel), 
        .EIP_sel(EIP_sel), .IPH_sel(IPH_sel), .clear_TF0(clear_TF0), 
        .clear_TF1(clear_TF1), .TCON30(TCON30), .inter_vector({
        SYNOPSYS_UNCONNECTED__0, inter_vector[6:3], SYNOPSYS_UNCONNECTED__1, 
        inter_vector[1:0]}), .inter_LCALL(inter_LCALL), .sample_INT0(
        sample_INT0), .sample_INT1(sample_INT1), .interrupt_ack(interrupt_ack), 
        .STOPwake_INT0(STOPwake_INT0), .STOPwake_INT1(STOPwake_INT1), 
        .INT_SFR_OUT(INT_SFR_OUT) );
  peri_cycle peri_cycle ( .end_of_inst(IR_EN), .pcon_idle(idle), .pre_pdwn(
        pre_pdwn), .POR(final_POR_ext_reset), .reset(final_all_reset), .clk(
        clk_peri), .Z_update(Z_update), .peri_state(peri_state) );
  t0_cycle t0_cycle ( .reset(final_all_reset), .clk(clk_peri), .T0M(T0M), 
        .T0M_S1(T0M_S1), .T0M_S2(T0M_S2), .T0M_S5(T0M_S5), .T0M_S6(T0M_S6) );
  t1_cycle t1_cycle ( .reset(n10), .clk(clk_peri), .T1M(T1M), .T1M_S1(T1M_S1), 
        .T1M_S2(T1M_S2), .T1M_S4(T1M_S4), .T1M_S5(T1M_S5), .T1M_S6(T1M_S6) );
  t2_cycle t2_cycle ( .reset(n10), .clk(clk_peri), .T2M(T2M), .T2M_S1(T2M_S1), 
        .T2M_S2(T2M_S2) );
  timer01 timer01 ( .Z_update(Z_update), .Z0_S1(T0M_S1), .Z0_S2(T0M_S2), 
        .Z0_S5(T0M_S5), .Z0_S6(T0M_S6), .Z1_S1(T1M_S1), .Z1_S2(T1M_S2), 
        .Z1_S4(T1M_S4), .Z1_S5(T1M_S5), .Z1_S6(T1M_S6), .sw_rst(n10), .clk_b(
        clk_peri), .SFR_wr(n20), .SFR_bus(EXT_SFR_DOUT), .TH0_sel(TH0_sel), 
        .TL0_sel(TL0_sel), .TH1_sel(TH1_sel), .TL1_sel(TL1_sel), .TCON_sel(
        TCON_sel), .TMOD_sel(TMOD_sel), .clear_TF0(clear_TF0), .clear_TF1(
        clear_TF1), .pin_T0(T0_PIN), .pin_T1(T1_PIN), .sample_INT0(sample_INT0), .sample_INT1(sample_INT1), .TCON30(TCON30), .TF0(TF0), .TF1(TF1), 
        .T1_overflow(T1_overflow), .T01_SFR_OUT(T01_SFR_OUT) );
  timer2 timer2 ( .POR(final_POR_ext_reset), .Z_update(Z_update), .pr_st_0(
        peri_state[0]), .Z2_S1(T2M_S1), .Z2_S2(T2M_S2), .sw_rst(n10), .clk_b(
        clk_peri), .SFR_wr(EXT_SFR_WR), .SFR_bus({EXT_SFR_DOUT[7:1], n4}), 
        .T2CON_sel(T2CON_sel), .T2MOD_sel(T2MOD_sel), .TH2_sel(TH2_sel), 
        .TL2_sel(TL2_sel), .RCAP2L_sel(RCAP2L_sel), .RCAP2H_sel(RCAP2H_sel), 
        .pin_T2(T2_PIN), .pin_T2EX(T2EX_PIN), .T2_CLKOUT(T2_OUT), .t2_intr(
        t2_intr), .T2_uart_clk(T2_uart_clk), .RCLK(RCLK), .TCLK(TCLK), 
        .T2_SFR_OUT(T2_SFR_OUT) );
  uart uart ( .POR(final_POR_ext_reset), .Z_update(Z_update), .sw_rst(n9), 
        .clk_b(clk_peri), .pr_st(peri_state), .SFR_wr(EXT_SFR_WR), .SFR_bus({
        EXT_SFR_DOUT[7:1], n4}), .SCON_sel(SCON_sel), .SBUF_sel(SBUF_sel), 
        .SADDR_sel(SADDR_sel), .SADEN_sel(SADEN_sel), .pin_RXD(RX_PIN), 
        .SMOD1_update(SMOD1_update), .SMOD1(SMOD1), .SMOD0(SMOD0), 
        .T1_overflow(T1_overflow), .T2_uart_clk(T2_uart_clk), .TCLK(TCLK), 
        .RCLK(RCLK), .ua_intr(ua_intr), .Uart_TXD(TX_PIN), .UART_SFR_OUT(
        UART_SFR_OUT) );
  power_control power_control ( .STOPwake_WDT(STOPwake_WDT), .POR(
        final_POR_ext_reset), .sw_rst(n10), .clk(clk_peri), .RST_pin(RESET_pin), .interrupt_ack(interrupt_ack), .STOPwake_INT0(STOPwake_INT0), 
        .STOPwake_INT1(STOPwake_INT1), .SFR_wr(EXT_SFR_WR), .SFR_bus({
        EXT_SFR_DOUT[7:1], n12}), .PCON_sel(PCON_sel), .SMOD1_update(
        SMOD1_update), .SMOD1(SMOD1), .SMOD0(SMOD0), .PCON({PCON_7_, PCON_6_, 
        PCON_5_, PCON_4_, PCON_3_, PCON_2_, pdwn, idle}), .pre_idle(pre_idle), 
        .pre_pdwn(pre_pdwn), .pre_pdwn_idle(pre_pdwn_idle) );
  pwm_top pwm_top ( .sw_rst(final_all_reset), .clk_b(clk_peri), .SFR_wr(
        EXT_SFR_WR), .PWM1CON_sel(PWM1CON_sel), .PWM2CON_sel(PWM2CON_sel), 
        .PWM1D_sel(PWM1D_sel), .PWM2D_sel(PWM2D_sel), .SFR_bus({
        EXT_SFR_DOUT[7:1], n4}), .PWM_SFR_OUT(PWM_SFR_OUT), .pwm1_out(PWM1_OUT), .pwm2_out(PWM2_OUT) );
  wdt wdt ( .EWT(EWT), .CKCON_sel(CKCON_sel), .T2M(T2M), .T1M(T1M), .T0M(T0M), 
        .clk_b(clk_wdt), .reset(n10), .POR(final_POR_ext_reset), .WDCON_sel(
        WDCON_sel), .SFR_wr(EXT_SFR_WR), .SFR_bus(EXT_SFR_DOUT), .wdt_intr(
        wdt_intr), .WDT_reset(wdt_reset), .WDT_SFR_OUT(WDT_SFR_OUT) );
  etc_sfr etc_sfr ( .clk_b(clk_peri), .reset(n10), .SFR_wr(EXT_SFR_WR), 
        .SFR_bus({EXT_SFR_DOUT[7:1], n4}), .PMR_sel(PMR_sel), .ALEOFF(ALEOFF), 
        .PMR_OUT(PMR_OUT) );
  sfr_inf sfr_inf ( .SFR_DATA(SFR_DATA), .SFR_wr(n20), .SFR_addr(EXT_SFR_ADDR), 
        .IDATA(IDATA), .PCON({PCON_7_, PCON_6_, PCON_5_, PCON_4_, PCON_3_, 
        PCON_2_, pdwn, idle}), .P0_OUT(P0_OUT), .P1_OUT(P1_OUT), .P2_OUT(
        P2_OUT), .P3_OUT(P3_OUT), .INT_SFR_OUT(INT_SFR_OUT), .T01_SFR_OUT(
        T01_SFR_OUT), .T2_SFR_OUT(T2_SFR_OUT), .UART_SFR_OUT(UART_SFR_OUT), 
        .WDT_SFR_OUT(WDT_SFR_OUT), .PWM_SFR_OUT(PWM_SFR_OUT), .PMR_OUT(PMR_OUT), .SFR_bus({n22, n23, n24, n25, n26, n27, n28, n29}), .PERI_SFR_sel(
        PERI_SFR_sel), .WDCON_sel(WDCON_sel), .PCON_sel(PCON_sel), .SCON_sel(
        SCON_sel), .SBUF_sel(SBUF_sel), .SADDR_sel(SADDR_sel), .SADEN_sel(
        SADEN_sel), .T2CON_sel(T2CON_sel), .T2MOD_sel(T2MOD_sel), .TH2_sel(
        TH2_sel), .TL2_sel(TL2_sel), .RCAP2L_sel(RCAP2L_sel), .RCAP2H_sel(
        RCAP2H_sel), .TH0_sel(TH0_sel), .TL0_sel(TL0_sel), .TH1_sel(TH1_sel), 
        .TL1_sel(TL1_sel), .TMOD_sel(TMOD_sel), .TCON_sel(TCON_sel), 
        .EXIF_sel(EXIF_sel), .IE_sel(IE_sel), .IP_sel(IP_sel), .EIE_sel(
        EIE_sel), .EIP_sel(EIP_sel), .IPH_sel(IPH_sel), .P0_sel(P0_sel), 
        .P1_sel(P1_sel), .P2_sel(P2_sel), .P3_sel(P3_sel), .PMR_sel(PMR_sel), 
        .PWM1CON_sel(PWM1CON_sel), .PWM2CON_sel(PWM2CON_sel), .PWM1D_sel(
        PWM1D_sel), .PWM2D_sel(PWM2D_sel), .CKCON_sel(CKCON_sel), 
        .EXT_SFR_DIN(EXT_SFR_DIN) );
  INVX1 I6 ( .A(1'b1), .Y(iram_oe_b) );
  INVX20 I8 ( .A(n11), .Y(n9) );
  BUFX4 I9 ( .A(n30), .Y(n20) );
  INVX8 I10 ( .A(n11), .Y(n10) );
  BUFX4 I11 ( .A(n30), .Y(EXT_SFR_WR) );
  BUFX8 I12 ( .A(n28), .Y(EXT_SFR_DOUT[1]) );
  INVX2 I13 ( .A(read_modify), .Y(n8) );
  BUFX2 I14 ( .A(n29), .Y(n4) );
  BUFX2 I15 ( .A(n29), .Y(EXT_SFR_DOUT[0]) );
  BUFX3 I16 ( .A(n29), .Y(n12) );
  INVX8 I17 ( .A(n8), .Y(n7) );
  BUFX4 I18 ( .A(n22), .Y(EXT_SFR_DOUT[7]) );
  BUFX4 I19 ( .A(n24), .Y(EXT_SFR_DOUT[5]) );
  BUFX4 I20 ( .A(n26), .Y(EXT_SFR_DOUT[3]) );
  BUFX4 I21 ( .A(n27), .Y(EXT_SFR_DOUT[2]) );
  BUFX4 I22 ( .A(n25), .Y(EXT_SFR_DOUT[4]) );
  BUFX4 I23 ( .A(n23), .Y(EXT_SFR_DOUT[6]) );
  INVX1 I24 ( .A(ALE_B_I), .Y(xrom_ce_b) );
  INVX2 I25 ( .A(final_all_reset), .Y(n11) );
  OR2X2 I26 ( .A(EWDI), .B(EWT), .Y(WDT_RUN) );
  INVX1 I27 ( .A(ALE_B), .Y(ALE) );
  INVX1 I28 ( .A(n5), .Y(PSEN) );
  INVX1 I29 ( .A(xrom_oe_b), .Y(n5) );
  INVX1 I30 ( .A(PSEN_B), .Y(xrom_oe_b) );
endmodule


module sfr_inf ( SFR_DATA, SFR_wr, SFR_addr, IDATA, PCON, P0_OUT, P1_OUT, 
        P2_OUT, P3_OUT, INT_SFR_OUT, T01_SFR_OUT, T2_SFR_OUT, UART_SFR_OUT, 
        WDT_SFR_OUT, PWM_SFR_OUT, PMR_OUT, SFR_bus, PERI_SFR_sel, WDCON_sel, 
        PCON_sel, SCON_sel, SBUF_sel, SADDR_sel, SADEN_sel, T2CON_sel, 
        T2MOD_sel, TH2_sel, TL2_sel, RCAP2L_sel, RCAP2H_sel, TH0_sel, TL0_sel, 
        TH1_sel, TL1_sel, TMOD_sel, TCON_sel, EXIF_sel, IE_sel, IP_sel, 
        EIE_sel, EIP_sel, IPH_sel, P0_sel, P1_sel, P2_sel, P3_sel, PMR_sel, 
        PWM1CON_sel, PWM2CON_sel, PWM1D_sel, PWM2D_sel, CKCON_sel, EXT_SFR_DIN
 );
  output [7:0] SFR_DATA;
  input [8:0] SFR_addr;
  input [7:0] IDATA;
  input [7:0] PCON;
  input [7:0] P0_OUT;
  input [7:0] P1_OUT;
  input [7:0] P2_OUT;
  input [7:0] P3_OUT;
  input [7:0] INT_SFR_OUT;
  input [7:0] T01_SFR_OUT;
  input [7:0] T2_SFR_OUT;
  input [7:0] UART_SFR_OUT;
  input [7:0] WDT_SFR_OUT;
  input [7:0] PWM_SFR_OUT;
  input [7:0] PMR_OUT;
  output [7:0] SFR_bus;
  input [7:0] EXT_SFR_DIN;
  input SFR_wr;
  output PERI_SFR_sel, WDCON_sel, PCON_sel, SCON_sel, SBUF_sel, SADDR_sel,
         SADEN_sel, T2CON_sel, T2MOD_sel, TH2_sel, TL2_sel, RCAP2L_sel,
         RCAP2H_sel, TH0_sel, TL0_sel, TH1_sel, TL1_sel, TMOD_sel, TCON_sel,
         EXIF_sel, IE_sel, IP_sel, EIE_sel, EIP_sel, IPH_sel, P0_sel, P1_sel,
         P2_sel, P3_sel, PMR_sel, PWM1CON_sel, PWM2CON_sel, PWM1D_sel,
         PWM2D_sel, CKCON_sel;
  wire   n12, n13, n14, n15, n16, n17, n28, n39, n46, n53, n60, n67, n161,
         n162, n163, n164, n165, n166, n168, n169, n171, n172, n173, n175,
         n176, n177, n179, n180, n181, n182, n183, n184, n185, n186, n187,
         n188, n189, n190, n191, n192, n193, n194, n195, n196, n197, n198,
         n199, n200, n201, n202, n203, n204, n205, n206, n207, n208, n209,
         n211, n212, n213, n214, n215, n216, n217, n218, n219, n220, n221,
         n222, n223, n224, n225, n226, n227, n228, n229, n230, n231, n232,
         n233, n234, n235, n236, n237, n238, n239, n240, n241, n242, n243,
         n244, n245, n246, n247, n248, n249, n250, n251, n252, n253, n254,
         n255, n256, n257, n258, n259, n260, n261, n262, n263, n264, n265,
         n266, n267, n268, n269, n270, n271, n272, n273, n274, n275, n276,
         n277, n278, n279, n280, n281, n282, n283, n284, n285, n286, n287,
         n288, n289, n290, n291, n292, n293, n294, n295, n296, n297, n298,
         n299, n300, n301, n302, n303, n304, n305, n306, n307, n308, n309,
         n310, n311, n312, n313, n314, n315, n316, n317, n318, n319, n320,
         n321, n322, n323, n324, n325, n326, n327, n328, n329, n330, n331,
         n332, n333, n334, n335, n336, n337, n338, n339, n340, n341, n342,
         n343, n344, n345, n346, n347, n348, n349, n350, n351, n352, n353,
         n354, n355, n356, n357, n358, n359, n360, n361, n362, n363, n364,
         n365, n366, n367, n368, n369, n370, n371, n372, n373, n374, n375,
         n376, n377, n378, n379, n380, n381, n382, n383, n384, n385, n386,
         n387, n388, n389, n390, n391, n392, n393, n394, n395, n396, n397,
         n398, n399;

  NAND2BX1 I215 ( .AN(n214), .B(n208), .Y(n218) );
  AND2X2 I216 ( .A(n163), .B(PWM_SFR_OUT[6]), .Y(n251) );
  OAI31X1 I217 ( .A0(n347), .A1(n353), .A2(n398), .B0(SFR_addr[8]), .Y(n161)
         );
  INVX1 I218 ( .A(n161), .Y(PERI_SFR_sel) );
  AND2X2 I219 ( .A(n212), .B(n357), .Y(n208) );
  AND2X2 I220 ( .A(n162), .B(PWM_SFR_OUT[5]), .Y(n264) );
  AND2X2 I221 ( .A(n163), .B(PWM_SFR_OUT[3]), .Y(n291) );
  AND2X2 I222 ( .A(n162), .B(PWM_SFR_OUT[2]), .Y(n305) );
  NAND3BX2 I223 ( .AN(n397), .B(n399), .C(n211), .Y(n315) );
  AND4X2 I224 ( .A(n363), .B(n396), .C(n212), .D(n399), .Y(n162) );
  INVX2 I225 ( .A(n162), .Y(n394) );
  INVX1 I226 ( .A(n359), .Y(n363) );
  AND4X2 I227 ( .A(n363), .B(n396), .C(n212), .D(n399), .Y(n163) );
  INVX2 I228 ( .A(n163), .Y(n237) );
  NAND3BX1 I229 ( .AN(n359), .B(n164), .C(n399), .Y(n387) );
  INVX1 I230 ( .A(n212), .Y(n164) );
  NAND3BX1 I231 ( .AN(n377), .B(n165), .C(n212), .Y(n365) );
  INVX1 I232 ( .A(n397), .Y(n165) );
  AOI2BB1X1 I233 ( .A0N(n346), .A1N(n347), .B0(n377), .Y(n166) );
  INVX2 I234 ( .A(n166), .Y(n398) );
  NAND2X1 I235 ( .A(n344), .B(n376), .Y(n374) );
  INVX1 I236 ( .A(n399), .Y(n344) );
  OR3X2 I237 ( .A(n396), .B(n214), .C(n387), .Y(n343) );
  OAI2BB1X1 I238 ( .A0N(n175), .A1N(T01_SFR_OUT[0]), .B0(n339), .Y(n338) );
  NAND2X1 I239 ( .A(n211), .B(n397), .Y(n372) );
  OR2X4 I240 ( .A(SFR_addr[1]), .B(SFR_addr[0]), .Y(n180) );
  AND3X2 I241 ( .A(n399), .B(n373), .C(SFR_addr[5]), .Y(IPH_sel) );
  NAND4X1 I242 ( .A(n177), .B(n176), .C(n354), .D(n355), .Y(n347) );
  AND3X4 I243 ( .A(n399), .B(n211), .C(n397), .Y(IP_sel) );
  OR4X2 I244 ( .A(n180), .B(n374), .C(n365), .D(n351), .Y(n323) );
  NAND2BX2 I245 ( .AN(n377), .B(n386), .Y(n359) );
  NOR2BX1 I246 ( .AN(n397), .B(SFR_addr[5]), .Y(n386) );
  AND2X2 I247 ( .A(n382), .B(n348), .Y(n169) );
  NOR3X1 I248 ( .A(n212), .B(n396), .C(SFR_addr[1]), .Y(n382) );
  BUFX3 I249 ( .A(SFR_addr[3]), .Y(n397) );
  BUFX4 I250 ( .A(SFR_addr[6]), .Y(n396) );
  NAND2X2 I251 ( .A(SFR_addr[1]), .B(SFR_addr[0]), .Y(n216) );
  AND2X2 I252 ( .A(SFR_addr[5]), .B(n209), .Y(n211) );
  BUFX4 I253 ( .A(SFR_addr[2]), .Y(n212) );
  NAND2X2 I254 ( .A(SFR_addr[1]), .B(n378), .Y(n217) );
  INVX1 I255 ( .A(n370), .Y(EXIF_sel) );
  NAND2X1 I256 ( .A(SFR_addr[8]), .B(SFR_addr[7]), .Y(n377) );
  MX2X2 I257 ( .S0(SFR_wr), .B(IDATA[1]), .A(SFR_DATA[1]), .Y(SFR_bus[1]) );
  NOR2X1 I258 ( .A(n399), .B(n372), .Y(IE_sel) );
  NOR2X1 I259 ( .A(n384), .B(n385), .Y(n383) );
  NAND2X1 I260 ( .A(n179), .B(n209), .Y(n312) );
  NAND2X2 I261 ( .A(n375), .B(n211), .Y(n228) );
  OAI21X1 I262 ( .A0(n320), .A1(n321), .B0(n322), .Y(n319) );
  NAND4X2 I263 ( .A(n396), .B(n212), .C(n399), .D(n363), .Y(n395) );
  NAND4X1 I264 ( .A(SFR_addr[5]), .B(SFR_addr[0]), .C(n397), .D(n169), .Y(n345) );
  NOR3X2 I265 ( .A(n365), .B(n396), .C(n216), .Y(n373) );
  NOR2X2 I266 ( .A(n216), .B(n215), .Y(TL1_sel) );
  NOR2X1 I267 ( .A(n344), .B(n345), .Y(SADEN_sel) );
  NOR2X2 I268 ( .A(n180), .B(n220), .Y(T2CON_sel) );
  NOR2X1 I269 ( .A(n217), .B(n395), .Y(PWM1D_sel) );
  NOR2X2 I270 ( .A(n399), .B(n397), .Y(n375) );
  NOR3X2 I271 ( .A(n359), .B(n396), .C(n399), .Y(n357) );
  INVX4 I272 ( .A(n212), .Y(n358) );
  INVX1 I273 ( .A(n374), .Y(n352) );
  NAND2X2 I274 ( .A(SFR_addr[0]), .B(n368), .Y(n214) );
  NAND2X2 I275 ( .A(n375), .B(n211), .Y(n390) );
  NAND2X2 I276 ( .A(n357), .B(n358), .Y(n215) );
  NOR2X2 I277 ( .A(n214), .B(n394), .Y(PWM2CON_sel) );
  NOR2X1 I278 ( .A(n214), .B(n215), .Y(TMOD_sel) );
  NAND3X1 I279 ( .A(n306), .B(n307), .C(n308), .Y(SFR_DATA[1]) );
  NOR2X1 I280 ( .A(n309), .B(n310), .Y(n308) );
  NOR3X1 I281 ( .A(n183), .B(n318), .C(n319), .Y(n307) );
  OR3X2 I282 ( .A(n387), .B(n396), .C(n180), .Y(n168) );
  OR2X2 I283 ( .A(n399), .B(n345), .Y(n171) );
  OR2X2 I284 ( .A(n180), .B(n351), .Y(n172) );
  INVX2 I285 ( .A(SFR_addr[1]), .Y(n368) );
  OAI221X4 I286 ( .A0(n228), .A1(n311), .B0(n312), .B1(n313), .C0(n314), .Y(
        n310) );
  NOR2X1 I287 ( .A(n387), .B(n172), .Y(WDCON_sel) );
  NAND2BX1 I288 ( .AN(WDCON_sel), .B(n356), .Y(n297) );
  NOR3BX2 I289 ( .AN(n367), .B(n180), .C(n358), .Y(TL2_sel) );
  NAND3X2 I290 ( .A(n215), .B(n219), .C(n218), .Y(n175) );
  NAND2X2 I291 ( .A(n208), .B(n350), .Y(n219) );
  OAI221X4 I292 ( .A0(n390), .A1(n332), .B0(n312), .B1(n333), .C0(n334), .Y(
        n331) );
  INVX2 I293 ( .A(n312), .Y(P0_sel) );
  NOR3BX2 I294 ( .AN(n367), .B(n214), .C(n358), .Y(TH2_sel) );
  NOR2X4 I295 ( .A(n180), .B(n237), .Y(PWM1CON_sel) );
  OR2X1 I296 ( .A(n180), .B(n215), .Y(n173) );
  INVX4 I297 ( .A(n173), .Y(TCON_sel) );
  MX2X1 I298 ( .S0(SFR_wr), .B(IDATA[0]), .A(SFR_DATA[0]), .Y(SFR_bus[0]) );
  INVX2 I299 ( .A(SFR_addr[0]), .Y(n378) );
  AND2X2 I300 ( .A(INT_SFR_OUT[1]), .B(n388), .Y(n183) );
  BUFX3 I301 ( .A(n213), .Y(TH1_sel) );
  AND2X2 I302 ( .A(n366), .B(n220), .Y(n176) );
  INVX2 I303 ( .A(n297), .Y(n224) );
  INVX3 I304 ( .A(n356), .Y(CKCON_sel) );
  INVX2 I305 ( .A(n343), .Y(SBUF_sel) );
  NAND2X1 I306 ( .A(n373), .B(n352), .Y(n362) );
  AND4X1 I307 ( .A(n369), .B(n370), .C(n371), .D(n372), .Y(n177) );
  INVX1 I308 ( .A(n369), .Y(EIE_sel) );
  NOR2X1 I309 ( .A(n397), .B(n374), .Y(n179) );
  NAND2X1 I310 ( .A(n169), .B(n379), .Y(n370) );
  OAI2BB2X1 I311 ( .A0N(SFR_wr), .A1N(IDATA[7]), .B0(SFR_wr), .B1(n12), .Y(
        SFR_bus[7]) );
  NAND2X1 I312 ( .A(n383), .B(n344), .Y(n369) );
  INVX2 I313 ( .A(n171), .Y(SADDR_sel) );
  INVX2 I314 ( .A(n168), .Y(SCON_sel) );
  INVX1 I315 ( .A(n396), .Y(n351) );
  INVX2 I316 ( .A(n364), .Y(P1_sel) );
  OAI2BB2X1 I317 ( .A0N(IDATA[5]), .A1N(SFR_wr), .B0(SFR_wr), .B1(n14), .Y(
        SFR_bus[5]) );
  OAI2BB2X1 I318 ( .A0N(IDATA[3]), .A1N(SFR_wr), .B0(SFR_wr), .B1(n16), .Y(
        SFR_bus[3]) );
  OAI2BB2X1 I319 ( .A0N(IDATA[2]), .A1N(SFR_wr), .B0(SFR_wr), .B1(n17), .Y(
        SFR_bus[2]) );
  OAI2BB2X1 I320 ( .A0N(IDATA[4]), .A1N(SFR_wr), .B0(SFR_wr), .B1(n15), .Y(
        SFR_bus[4]) );
  OAI2BB2X1 I321 ( .A0N(IDATA[6]), .A1N(SFR_wr), .B0(SFR_wr), .B1(n13), .Y(
        SFR_bus[6]) );
  NAND2X1 I322 ( .A(n181), .B(n209), .Y(n364) );
  NOR3X1 I323 ( .A(n344), .B(SFR_addr[5]), .C(n397), .Y(n181) );
  OAI21X1 I324 ( .A0(n315), .A1(n316), .B0(n317), .Y(n309) );
  OAI21X1 I325 ( .A0(n315), .A1(n335), .B0(n336), .Y(n330) );
  BUFX8 I326 ( .A(SFR_addr[4]), .Y(n399) );
  NAND3X1 I327 ( .A(n327), .B(n328), .C(n329), .Y(SFR_DATA[0]) );
  INVX1 I328 ( .A(SFR_addr[5]), .Y(n376) );
  AND2X2 I329 ( .A(INT_SFR_OUT[0]), .B(n389), .Y(n182) );
  NOR2X1 I330 ( .A(n228), .B(n229), .Y(n222) );
  NAND3X1 I331 ( .A(n184), .B(n185), .C(n186), .Y(SFR_DATA[7]) );
  NAND2X1 I332 ( .A(EXT_SFR_DIN[7]), .B(n398), .Y(n184) );
  NOR2X1 I333 ( .A(n232), .B(n197), .Y(n185) );
  NOR3X1 I334 ( .A(n221), .B(n222), .C(n223), .Y(n186) );
  NAND3X1 I335 ( .A(n187), .B(n188), .C(n189), .Y(SFR_DATA[6]) );
  NAND2X1 I336 ( .A(EXT_SFR_DIN[6]), .B(n398), .Y(n187) );
  NOR2X1 I337 ( .A(n247), .B(n198), .Y(n188) );
  NOR3X1 I338 ( .A(n239), .B(n240), .C(n241), .Y(n189) );
  NAND3X1 I339 ( .A(n190), .B(n191), .C(n192), .Y(SFR_DATA[5]) );
  NAND2X1 I340 ( .A(EXT_SFR_DIN[5]), .B(n398), .Y(n190) );
  NOR2X1 I341 ( .A(n260), .B(n196), .Y(n191) );
  NOR3X1 I342 ( .A(n252), .B(n253), .C(n254), .Y(n192) );
  NAND3X1 I343 ( .A(n193), .B(n194), .C(n195), .Y(SFR_DATA[3]) );
  NAND2X1 I344 ( .A(EXT_SFR_DIN[3]), .B(n398), .Y(n193) );
  NOR2X1 I345 ( .A(n287), .B(n199), .Y(n194) );
  NOR3X1 I346 ( .A(n279), .B(n280), .C(n281), .Y(n195) );
  NOR2X1 I347 ( .A(n395), .B(n238), .Y(n236) );
  AND2X1 I348 ( .A(INT_SFR_OUT[5]), .B(n389), .Y(n196) );
  AND2X2 I349 ( .A(INT_SFR_OUT[7]), .B(n388), .Y(n197) );
  AND2X2 I350 ( .A(INT_SFR_OUT[6]), .B(n388), .Y(n198) );
  AND2X2 I351 ( .A(INT_SFR_OUT[3]), .B(n388), .Y(n199) );
  OAI21X1 I352 ( .A0(n224), .A1(n225), .B0(n226), .Y(n223) );
  NOR2X1 I353 ( .A(n228), .B(n257), .Y(n253) );
  NOR2X1 I354 ( .A(n228), .B(n284), .Y(n280) );
  NOR2X1 I355 ( .A(n390), .B(n244), .Y(n240) );
  NOR2X1 I356 ( .A(n390), .B(n298), .Y(n293) );
  NOR2X1 I357 ( .A(n390), .B(n270), .Y(n266) );
  NAND3X1 I358 ( .A(n200), .B(n201), .C(n202), .Y(SFR_DATA[2]) );
  NAND2X1 I359 ( .A(EXT_SFR_DIN[2]), .B(n398), .Y(n200) );
  NOR2X1 I360 ( .A(n301), .B(n206), .Y(n201) );
  NOR3X1 I361 ( .A(n292), .B(n293), .C(n294), .Y(n202) );
  NAND3X1 I362 ( .A(n203), .B(n204), .C(n205), .Y(SFR_DATA[4]) );
  NAND2X1 I363 ( .A(EXT_SFR_DIN[4]), .B(n398), .Y(n203) );
  NOR2X1 I364 ( .A(n273), .B(n207), .Y(n204) );
  NOR3X1 I365 ( .A(n265), .B(n266), .C(n267), .Y(n205) );
  AND2X2 I366 ( .A(INT_SFR_OUT[2]), .B(n388), .Y(n206) );
  AND2X2 I367 ( .A(INT_SFR_OUT[4]), .B(n388), .Y(n207) );
  OAI21X1 I368 ( .A0(n224), .A1(n242), .B0(n243), .Y(n241) );
  OAI21X1 I369 ( .A0(n224), .A1(n255), .B0(n256), .Y(n254) );
  OAI21X1 I370 ( .A0(n224), .A1(n268), .B0(n269), .Y(n267) );
  INVX1 I371 ( .A(n176), .Y(n391) );
  INVX1 I372 ( .A(n175), .Y(n320) );
  INVX1 I373 ( .A(n176), .Y(n392) );
  INVX4 I374 ( .A(n219), .Y(TH0_sel) );
  INVX1 I375 ( .A(n218), .Y(n213) );
  INVX2 I376 ( .A(n323), .Y(PMR_sel) );
  INVX1 I377 ( .A(n177), .Y(n389) );
  INVX1 I378 ( .A(n177), .Y(n388) );
  NOR2X1 I379 ( .A(TL2_sel), .B(TH2_sel), .Y(n366) );
  INVX4 I380 ( .A(n362), .Y(PCON_sel) );
  INVX1 I381 ( .A(n377), .Y(n348) );
  NOR2X1 I382 ( .A(n360), .B(n361), .Y(n354) );
  NOR3X1 I383 ( .A(n393), .B(n175), .C(n297), .Y(n355) );
  NAND2X1 I384 ( .A(n315), .B(n228), .Y(n353) );
  NAND2X1 I385 ( .A(n395), .B(n362), .Y(n361) );
  NOR2X1 I386 ( .A(EIP_sel), .B(IPH_sel), .Y(n371) );
  INVX1 I387 ( .A(n180), .Y(n350) );
  NOR2X1 I388 ( .A(n214), .B(n220), .Y(T2MOD_sel) );
  INVX2 I389 ( .A(n315), .Y(P3_sel) );
  INVX1 I390 ( .A(n390), .Y(P2_sel) );
  NAND2X1 I391 ( .A(P1_OUT[1]), .B(P1_sel), .Y(n314) );
  INVX1 I392 ( .A(P2_OUT[1]), .Y(n311) );
  INVX1 I393 ( .A(P0_OUT[1]), .Y(n313) );
  NAND2X1 I394 ( .A(P1_OUT[0]), .B(P1_sel), .Y(n334) );
  INVX1 I395 ( .A(P2_OUT[0]), .Y(n332) );
  INVX1 I396 ( .A(P0_OUT[0]), .Y(n333) );
  NAND2X1 I397 ( .A(WDT_SFR_OUT[0]), .B(n297), .Y(n339) );
  NAND2X1 I398 ( .A(WDT_SFR_OUT[1]), .B(n297), .Y(n322) );
  INVX1 I399 ( .A(T01_SFR_OUT[1]), .Y(n321) );
  NOR2X2 I400 ( .A(n217), .B(n215), .Y(TL0_sel) );
  INVX1 I401 ( .A(SFR_DATA[7]), .Y(n12) );
  AND2X2 I402 ( .A(n169), .B(n378), .Y(n209) );
  OAI221X4 I403 ( .A0(n323), .A1(n340), .B0(n394), .B1(n341), .C0(n342), .Y(
        n337) );
  INVX1 I404 ( .A(PMR_OUT[0]), .Y(n340) );
  NAND2X1 I405 ( .A(T2_SFR_OUT[0]), .B(n391), .Y(n342) );
  INVX1 I406 ( .A(PWM_SFR_OUT[0]), .Y(n341) );
  OAI221X4 I407 ( .A0(n323), .A1(n324), .B0(n394), .B1(n325), .C0(n326), .Y(
        n318) );
  INVX1 I408 ( .A(PMR_OUT[1]), .Y(n324) );
  INVX1 I409 ( .A(PWM_SFR_OUT[1]), .Y(n325) );
  NAND2X1 I410 ( .A(T2_SFR_OUT[1]), .B(n391), .Y(n326) );
  AND2X2 I411 ( .A(n383), .B(n399), .Y(EIP_sel) );
  INVX1 I412 ( .A(SFR_DATA[3]), .Y(n16) );
  NAND2BX1 I413 ( .AN(n217), .B(n208), .Y(n356) );
  NAND3X1 I414 ( .A(n364), .B(n312), .C(n323), .Y(n360) );
  NOR2X1 I415 ( .A(n380), .B(n344), .Y(n379) );
  NAND3X1 I416 ( .A(n381), .B(n376), .C(SFR_addr[0]), .Y(n380) );
  INVX1 I417 ( .A(n397), .Y(n381) );
  NOR2X1 I418 ( .A(n212), .B(n349), .Y(n346) );
  MXI2X1 I419 ( .S0(n352), .B(n351), .A(n350), .Y(n349) );
  BUFX3 I420 ( .A(n227), .Y(n393) );
  NAND3X1 I421 ( .A(n345), .B(n168), .C(n343), .Y(n227) );
  NOR2X1 I422 ( .A(n216), .B(n237), .Y(PWM2D_sel) );
  NAND3X1 I423 ( .A(n233), .B(n234), .C(n235), .Y(n232) );
  NAND2X1 I424 ( .A(PMR_OUT[7]), .B(PMR_sel), .Y(n234) );
  AOI21X1 I425 ( .A0(T2_SFR_OUT[7]), .A1(n392), .B0(n236), .Y(n235) );
  NAND2X1 I426 ( .A(T01_SFR_OUT[7]), .B(n175), .Y(n233) );
  NAND3X1 I427 ( .A(n248), .B(n249), .C(n250), .Y(n247) );
  NAND2X1 I428 ( .A(PMR_OUT[6]), .B(PMR_sel), .Y(n249) );
  AOI21X1 I429 ( .A0(T2_SFR_OUT[6]), .A1(n392), .B0(n251), .Y(n250) );
  NAND2X1 I430 ( .A(T01_SFR_OUT[6]), .B(n175), .Y(n248) );
  NAND3X1 I431 ( .A(n261), .B(n262), .C(n263), .Y(n260) );
  NAND2X1 I432 ( .A(PMR_OUT[5]), .B(PMR_sel), .Y(n262) );
  AOI21X1 I433 ( .A0(T2_SFR_OUT[5]), .A1(n391), .B0(n264), .Y(n263) );
  NAND2X1 I434 ( .A(T01_SFR_OUT[5]), .B(n175), .Y(n261) );
  NAND3X1 I435 ( .A(n288), .B(n289), .C(n290), .Y(n287) );
  NAND2X1 I436 ( .A(PMR_OUT[3]), .B(PMR_sel), .Y(n289) );
  AOI21X1 I437 ( .A0(T2_SFR_OUT[3]), .A1(n392), .B0(n291), .Y(n290) );
  NAND2X1 I438 ( .A(T01_SFR_OUT[3]), .B(n175), .Y(n288) );
  NAND3X1 I439 ( .A(n302), .B(n303), .C(n304), .Y(n301) );
  NAND2X1 I440 ( .A(PMR_OUT[2]), .B(PMR_sel), .Y(n303) );
  AOI21X1 I441 ( .A0(T2_SFR_OUT[2]), .A1(n391), .B0(n305), .Y(n304) );
  NAND2X1 I442 ( .A(T01_SFR_OUT[2]), .B(n175), .Y(n302) );
  INVX1 I443 ( .A(SFR_DATA[2]), .Y(n17) );
  INVX1 I444 ( .A(SFR_DATA[4]), .Y(n15) );
  INVX1 I445 ( .A(SFR_DATA[5]), .Y(n14) );
  INVX1 I446 ( .A(SFR_DATA[6]), .Y(n13) );
  NAND3X1 I447 ( .A(n274), .B(n275), .C(n276), .Y(n273) );
  NAND2X1 I448 ( .A(PMR_OUT[4]), .B(PMR_sel), .Y(n275) );
  AOI21X1 I449 ( .A0(T2_SFR_OUT[4]), .A1(n392), .B0(n277), .Y(n276) );
  NAND2X1 I450 ( .A(T01_SFR_OUT[4]), .B(n175), .Y(n274) );
  OAI21X1 I451 ( .A0(n224), .A1(n282), .B0(n283), .Y(n281) );
  INVX1 I452 ( .A(WDT_SFR_OUT[3]), .Y(n282) );
  NAND2X1 I453 ( .A(UART_SFR_OUT[3]), .B(n393), .Y(n283) );
  OAI21X1 I454 ( .A0(n224), .A1(n295), .B0(n296), .Y(n294) );
  INVX1 I455 ( .A(WDT_SFR_OUT[2]), .Y(n295) );
  NAND2X1 I456 ( .A(UART_SFR_OUT[2]), .B(n393), .Y(n296) );
  NAND2X1 I457 ( .A(EXT_SFR_DIN[1]), .B(n398), .Y(n306) );
  NAND2X1 I458 ( .A(EXT_SFR_DIN[0]), .B(n398), .Y(n327) );
  NOR3X1 I459 ( .A(n182), .B(n337), .C(n338), .Y(n328) );
  NOR2X1 I460 ( .A(n330), .B(n331), .Y(n329) );
  NAND3X1 I461 ( .A(n397), .B(n358), .C(n348), .Y(n384) );
  NAND3X1 I462 ( .A(SFR_addr[5]), .B(n396), .C(n350), .Y(n385) );
  AOI22X1 I463 ( .A0(UART_SFR_OUT[1]), .A1(n393), .B0(PCON[1]), .B1(PCON_sel), 
        .Y(n317) );
  INVX1 I464 ( .A(P3_OUT[1]), .Y(n316) );
  AOI22X1 I465 ( .A0(UART_SFR_OUT[0]), .A1(n393), .B0(PCON[0]), .B1(PCON_sel), 
        .Y(n336) );
  INVX1 I466 ( .A(P3_OUT[0]), .Y(n335) );
  NAND3X1 I467 ( .A(n230), .B(n231), .C(n28), .Y(n221) );
  NAND2X1 I468 ( .A(P0_OUT[7]), .B(P0_sel), .Y(n230) );
  NAND2X1 I469 ( .A(P1_OUT[7]), .B(P1_sel), .Y(n231) );
  AOI22X1 I470 ( .A0(PCON[7]), .A1(PCON_sel), .B0(P3_OUT[7]), .B1(P3_sel), .Y(
        n28) );
  INVX1 I471 ( .A(P2_OUT[7]), .Y(n229) );
  INVX1 I472 ( .A(WDT_SFR_OUT[7]), .Y(n225) );
  NAND2X1 I473 ( .A(UART_SFR_OUT[7]), .B(n393), .Y(n226) );
  NAND3X1 I474 ( .A(n245), .B(n246), .C(n39), .Y(n239) );
  NAND2X1 I475 ( .A(P0_OUT[6]), .B(P0_sel), .Y(n245) );
  NAND2X1 I476 ( .A(P1_OUT[6]), .B(P1_sel), .Y(n246) );
  AOI22X1 I477 ( .A0(PCON[6]), .A1(PCON_sel), .B0(P3_OUT[6]), .B1(P3_sel), .Y(
        n39) );
  NAND3X1 I478 ( .A(n258), .B(n259), .C(n46), .Y(n252) );
  NAND2X1 I479 ( .A(P0_OUT[5]), .B(P0_sel), .Y(n258) );
  NAND2X1 I480 ( .A(P1_OUT[5]), .B(P1_sel), .Y(n259) );
  AOI22X1 I481 ( .A0(PCON[5]), .A1(PCON_sel), .B0(P3_OUT[5]), .B1(P3_sel), .Y(
        n46) );
  NAND3X1 I482 ( .A(n285), .B(n286), .C(n60), .Y(n279) );
  NAND2X1 I483 ( .A(P0_OUT[3]), .B(P0_sel), .Y(n285) );
  NAND2X1 I484 ( .A(P1_OUT[3]), .B(P1_sel), .Y(n286) );
  AOI22X1 I485 ( .A0(PCON[3]), .A1(PCON_sel), .B0(P3_OUT[3]), .B1(P3_sel), .Y(
        n60) );
  NAND3X1 I486 ( .A(n299), .B(n300), .C(n67), .Y(n292) );
  NAND2X1 I487 ( .A(P0_OUT[2]), .B(P0_sel), .Y(n299) );
  NAND2X1 I488 ( .A(P1_OUT[2]), .B(P1_sel), .Y(n300) );
  AOI22X1 I489 ( .A0(PCON[2]), .A1(PCON_sel), .B0(P3_OUT[2]), .B1(P3_sel), .Y(
        n67) );
  NAND3X1 I490 ( .A(n271), .B(n272), .C(n53), .Y(n265) );
  NAND2X1 I491 ( .A(P0_OUT[4]), .B(P0_sel), .Y(n271) );
  NAND2X1 I492 ( .A(P1_OUT[4]), .B(P1_sel), .Y(n272) );
  AOI22X1 I493 ( .A0(PCON[4]), .A1(PCON_sel), .B0(P3_OUT[4]), .B1(P3_sel), .Y(
        n53) );
  INVX1 I494 ( .A(PWM_SFR_OUT[7]), .Y(n238) );
  INVX1 I495 ( .A(P2_OUT[4]), .Y(n270) );
  INVX1 I496 ( .A(P2_OUT[6]), .Y(n244) );
  INVX1 I497 ( .A(P2_OUT[5]), .Y(n257) );
  INVX1 I498 ( .A(P2_OUT[3]), .Y(n284) );
  INVX1 I499 ( .A(P2_OUT[2]), .Y(n298) );
  INVX1 I500 ( .A(WDT_SFR_OUT[6]), .Y(n242) );
  NAND2X1 I501 ( .A(UART_SFR_OUT[6]), .B(n393), .Y(n243) );
  INVX1 I502 ( .A(WDT_SFR_OUT[5]), .Y(n255) );
  NAND2X1 I503 ( .A(UART_SFR_OUT[5]), .B(n393), .Y(n256) );
  INVX1 I504 ( .A(WDT_SFR_OUT[4]), .Y(n268) );
  NAND2X1 I505 ( .A(UART_SFR_OUT[4]), .B(n393), .Y(n269) );
  NOR2X1 I506 ( .A(n395), .B(n278), .Y(n277) );
  INVX1 I507 ( .A(PWM_SFR_OUT[4]), .Y(n278) );
  NOR2X4 I508 ( .A(n217), .B(n220), .Y(RCAP2L_sel) );
  NOR2X4 I509 ( .A(n216), .B(n220), .Y(RCAP2H_sel) );
  NAND2X4 I510 ( .A(n367), .B(n358), .Y(n220) );
  NOR3BX4 I511 ( .AN(n396), .B(n359), .C(n399), .Y(n367) );
endmodule


module etc_sfr ( clk_b, reset, SFR_wr, SFR_bus, PMR_sel, ALEOFF, PMR_OUT );
  input [7:0] SFR_bus;
  output [7:0] PMR_OUT;
  input clk_b, reset, SFR_wr, PMR_sel;
  output ALEOFF;
  wire   PMR_7_, PMR_6_, PMR_5_, PMR_4_, PMR_3_, PMR_1_, PMR_0_, N4, N5, N6,
         N7, N11, N12, N13, N14, N18, n50, n60;

  AND2X1 I22 ( .A(PMR_0_), .B(PMR_sel), .Y(PMR_OUT[0]) );
  AND2X1 I23 ( .A(PMR_1_), .B(PMR_sel), .Y(PMR_OUT[1]) );
  AND2X1 I24 ( .A(PMR_sel), .B(PMR_7_), .Y(PMR_OUT[7]) );
  AND2X1 I25 ( .A(ALEOFF), .B(PMR_sel), .Y(PMR_OUT[2]) );
  AND2X1 I26 ( .A(PMR_6_), .B(PMR_sel), .Y(PMR_OUT[6]) );
  AND2X1 I27 ( .A(PMR_3_), .B(PMR_sel), .Y(PMR_OUT[3]) );
  AND2X1 I28 ( .A(PMR_5_), .B(PMR_sel), .Y(PMR_OUT[5]) );
  AND2X1 I29 ( .A(PMR_4_), .B(PMR_sel), .Y(PMR_OUT[4]) );
  AND3X2 I30 ( .A(SFR_wr), .B(n60), .C(PMR_sel), .Y(n50) );
  AND2X2 I31 ( .A(SFR_bus[3]), .B(n50), .Y(N14) );
  AND2X2 I32 ( .A(SFR_bus[7]), .B(n50), .Y(N7) );
  AND2X2 I33 ( .A(SFR_bus[6]), .B(n50), .Y(N6) );
  AND2X2 I34 ( .A(SFR_bus[5]), .B(n50), .Y(N5) );
  AND2X2 I35 ( .A(SFR_bus[4]), .B(n50), .Y(N4) );
  AND2X2 I36 ( .A(SFR_bus[2]), .B(n50), .Y(N13) );
  INVX1 I37 ( .A(reset), .Y(n60) );
  OR2X2 I38 ( .A(n50), .B(reset), .Y(N18) );
  EDFFX1 PMR_reg_1_ ( .D(N12), .CK(clk_b), .E(N18), .Q(PMR_1_) );
  EDFFX1 PMR_reg_0_ ( .D(N11), .CK(clk_b), .E(N18), .Q(PMR_0_) );
  EDFFX1 PMR_reg_7_ ( .D(N7), .CK(clk_b), .E(N18), .Q(PMR_7_) );
  EDFFX1 PMR_reg_2_ ( .D(N13), .CK(clk_b), .E(N18), .Q(ALEOFF) );
  EDFFX1 PMR_reg_6_ ( .D(N6), .CK(clk_b), .E(N18), .Q(PMR_6_) );
  EDFFX1 PMR_reg_5_ ( .D(N5), .CK(clk_b), .E(N18), .Q(PMR_5_) );
  EDFFX1 PMR_reg_4_ ( .D(N4), .CK(clk_b), .E(N18), .Q(PMR_4_) );
  EDFFX1 PMR_reg_3_ ( .D(N14), .CK(clk_b), .E(N18), .Q(PMR_3_) );
  AND2X1 I39 ( .A(SFR_bus[1]), .B(n50), .Y(N12) );
  AND2X1 I40 ( .A(SFR_bus[0]), .B(n50), .Y(N11) );
endmodule


module wdt ( EWT, CKCON_sel, T2M, T1M, T0M, LVD_intr, clk_b, reset, POR, 
        WDCON_sel, SFR_wr, SFR_bus, wdt_intr, WDT_reset, WDT_SFR_OUT );
  input [7:0] SFR_bus;
  output [7:0] WDT_SFR_OUT;
  input CKCON_sel, clk_b, reset, POR, WDCON_sel, SFR_wr;
  output EWT, T2M, T1M, T0M, LVD_intr, wdt_intr, WDT_reset;
  wire   CKCON_7_, CKCON_6_, RWT, RWT_D, N88, N89, N90, N91, N92, N101, N102,
         N103, N104, N105, N106, N107, N108, N109, N110, N111, N112, N113,
         N114, N115, N116, N117, N118, N119, N120, N121, N122, N123, N124,
         N125, N126, N127, N128, N129, N130, N131, N132, N133, N134, N135,
         N136, N137, n2, n3, n6, n15, n21, n23, n24, n26, n28, n34, n35, n36,
         n37, n40, n41, n42, n43, n46, n47, n48, n50, n51, n52, n53, n54, n55,
         n56, n57, n58, n59, n60, n61, n62, n63, n64, n65, n66, n67, n68, n69,
         n70, n71, n72, n73, n74, n75, n76, n77, n78, n79, n80, n81, n82, n83,
         n84, n85, n86, n87, n880, n890, n900, n910, n920, n93, n94, n95, n96,
         n97, n98, n99, n100, n1010, n1020, n1030, n1040, n1050, n1060, n1070,
         n1080, n1090, n1100, n1110, n1120, n1130, n1140, n1150, n1160, n1170,
         n1180, n1190, n1200, n1210, n1220, n1230, n1240, n1250, n1260, n1270,
         n1280, n1290, n1300, n1310, n1320, n1330, n1340, n1350, n1360, n1370,
         n138, n139, n140, n141, n142, n143, n144, n145, n146, n147, n148,
         n149, n150, n151, n152, n153, n154, n155, n156, n157, n158, n159,
         n160, n161, n162, n163, n164, n165, n166, n167, n168, n169, n170,
         n171, n172, n173, n174, n175, n176, n177, n178, n179, n180, n181,
         n182, n183, n184, n185, n187, n189, n191, n193, n197, n198, n199,
         n200, n201, n202, n203, n204, n205, n206, n207, n208, n209, n210,
         n211, n212, n213, n214, n215, n216, n217, n218, n219, n220, n221,
         n222, n223, n224, n225, n226, n227, n228, n229, n230, n231, n232,
         n233, n234, n235;
  wire   [26:0] wdt_count;
  wire   [9:0] count_512;
  wire   [4:0] wdt_rst_cnt;

  OAI33X4 U75 ( .A0(n202), .A1(n201), .A2(n206), .B0(n206), .B1(CKCON_7_), 
        .B2(n213), .Y(n37) );
  OAI33X4 U78 ( .A0(n201), .A1(CKCON_6_), .A2(n214), .B0(n207), .B1(CKCON_7_), 
        .B2(CKCON_6_), .Y(n36) );
  OAI31X4 U82 ( .A0(n34), .A1(RWT), .A2(n40), .B0(n41), .Y(n1120) );
  INVX1 I168 ( .A(1'b1), .Y(LVD_intr) );
  NOR2BX1 I170 ( .AN(n1040), .B(n227), .Y(n51) );
  AOI21X1 I171 ( .A0(n21), .A1(n215), .B0(RWT), .Y(n197) );
  INVX3 I172 ( .A(n197), .Y(n232) );
  AND2X1 I173 ( .A(n1050), .B(n231), .Y(n52) );
  NAND3X1 I174 ( .A(wdt_rst_cnt[0]), .B(n198), .C(n2), .Y(n3) );
  INVX1 I175 ( .A(n6), .Y(n198) );
  AND2X2 I176 ( .A(n1120), .B(n231), .Y(n63) );
  NOR2X1 I177 ( .A(n15), .B(RWT), .Y(n224) );
  OR2X2 I178 ( .A(n15), .B(RWT), .Y(n199) );
  OR2X2 I179 ( .A(n15), .B(RWT), .Y(n200) );
  INVX1 I180 ( .A(n21), .Y(n15) );
  OR2X2 I181 ( .A(n47), .B(n28), .Y(n46) );
  DFFRX1 wdt_count_reg_16_ ( .D(n920), .CK(clk_b), .RN(n48), .Q(wdt_count[16]), 
        .QN(n149) );
  DFFRX1 wdt_count_reg_19_ ( .D(n95), .CK(clk_b), .RN(n48), .Q(wdt_count[19]), 
        .QN(n154) );
  DFFRX1 wdt_count_reg_22_ ( .D(n98), .CK(clk_b), .RN(n48), .Q(wdt_count[22]), 
        .QN(n161) );
  DFFRX1 wdt_count_reg_0_ ( .D(n76), .CK(clk_b), .RN(n48), .Q(wdt_count[0]), 
        .QN(n1350) );
  DFFRX1 CKCON_reg_3_ ( .D(n53), .CK(clk_b), .RN(n48), .Q(T0M), .QN(n205) );
  DFFRX1 wdt_count_reg_17_ ( .D(n93), .CK(clk_b), .RN(n48), .Q(wdt_count[17]), 
        .QN(n207) );
  DFFRX1 wdt_rst_cnt_reg_0_ ( .D(n58), .CK(clk_b), .RN(n48), .Q(wdt_rst_cnt[0]), .QN(n208) );
  DFFRX1 wdt_count_reg_20_ ( .D(n96), .CK(clk_b), .RN(n48), .Q(wdt_count[20]), 
        .QN(n213) );
  DFFRX1 wdt_count_reg_23_ ( .D(n99), .CK(clk_b), .RN(n48), .Q(wdt_count[23]), 
        .QN(n214) );
  DFFRX1 CKCON_reg_4_ ( .D(n54), .CK(clk_b), .RN(n48), .Q(T1M), .QN(n217) );
  DFFRX1 CKCON_reg_5_ ( .D(n55), .CK(clk_b), .RN(n48), .Q(T2M), .QN(n218) );
  INVX4 I182 ( .A(RWT), .Y(n219) );
  NAND2X1 I183 ( .A(WDCON_sel), .B(SFR_wr), .Y(n34) );
  INVX4 I184 ( .A(POR), .Y(n220) );
  INVX4 I185 ( .A(POR), .Y(n48) );
  AND2X4 I186 ( .A(n223), .B(n200), .Y(n221) );
  INVX1 I187 ( .A(reset), .Y(n230) );
  INVX1 I188 ( .A(reset), .Y(n231) );
  INVX2 I189 ( .A(n228), .Y(n226) );
  INVX2 I190 ( .A(n229), .Y(n225) );
  INVX2 I191 ( .A(CKCON_sel), .Y(n28) );
  INVX4 I192 ( .A(n46), .Y(n43) );
  INVX1 I193 ( .A(n34), .Y(n24) );
  INVX1 I194 ( .A(n231), .Y(n229) );
  INVX1 I195 ( .A(n231), .Y(n228) );
  INVX1 I196 ( .A(SFR_bus[3]), .Y(n35) );
  INVX1 I197 ( .A(SFR_bus[2]), .Y(n23) );
  INVX1 I198 ( .A(SFR_bus[1]), .Y(n42) );
  INVX1 I199 ( .A(SFR_wr), .Y(n47) );
  INVX1 I200 ( .A(n231), .Y(n227) );
  OAI22X2 I201 ( .A0(CKCON_sel), .A1(n223), .B0(n28), .B1(n210), .Y(
        WDT_SFR_OUT[0]) );
  OAI22X2 I202 ( .A0(CKCON_sel), .A1(n203), .B0(n28), .B1(n209), .Y(
        WDT_SFR_OUT[1]) );
  OAI221X4 I203 ( .A0(n204), .A1(n23), .B0(n24), .B1(n204), .C0(n2), .Y(n1150)
         );
  OAI22X1 I204 ( .A0(n43), .A1(n209), .B0(n42), .B1(n46), .Y(n1040) );
  NOR2BX1 U121 ( .AN(n1090), .B(n229), .Y(n56) );
  OAI2BB2X1 I205 ( .A0N(SFR_bus[6]), .A1N(n43), .B0(n43), .B1(n206), .Y(n1090)
         );
  DFFRX1 wdt_count_reg_1_ ( .D(n77), .CK(clk_b), .RN(n48), .Q(wdt_count[1]), 
        .QN(n156) );
  DFFRX1 EWT_reg ( .D(n64), .CK(clk_b), .RN(n220), .Q(EWT), .QN(n203) );
  NOR2BX1 U130 ( .AN(n1130), .B(n227), .Y(n65) );
  OAI221X4 I206 ( .A0(n34), .A1(n35), .B0(n24), .B1(n212), .C0(n15), .Y(n1130)
         );
  NOR2BX1 U115 ( .AN(n1030), .B(n228), .Y(n50) );
  OAI22X1 I207 ( .A0(n43), .A1(n210), .B0(n40), .B1(n46), .Y(n1030) );
  OAI22X1 I208 ( .A0(n43), .A1(n211), .B0(n23), .B1(n46), .Y(n1050) );
  NOR2BX1 U118 ( .AN(n1060), .B(n227), .Y(n53) );
  OAI22X1 I209 ( .A0(n43), .A1(n205), .B0(n35), .B1(n46), .Y(n1060) );
  NOR2BX1 U129 ( .AN(n1110), .B(n227), .Y(n64) );
  OAI22X1 I210 ( .A0(n24), .A1(n203), .B0(n34), .B1(n42), .Y(n1110) );
  NOR2BX1 U122 ( .AN(n1100), .B(n228), .Y(n57) );
  OAI2BB2X1 I211 ( .A0N(SFR_bus[7]), .A1N(n43), .B0(n43), .B1(n201), .Y(n1100)
         );
  OAI22X1 I212 ( .A0(n28), .A1(n205), .B0(CKCON_sel), .B1(n212), .Y(
        WDT_SFR_OUT[3]) );
  OAI22X1 I213 ( .A0(CKCON_sel), .A1(n204), .B0(n28), .B1(n211), .Y(
        WDT_SFR_OUT[2]) );
  DFFRX1 wdt_count_reg_2_ ( .D(n78), .CK(clk_b), .RN(n220), .Q(wdt_count[2]), 
        .QN(n169) );
  DFFRX1 wdt_count_reg_3_ ( .D(n79), .CK(clk_b), .RN(n220), .Q(wdt_count[3]), 
        .QN(n171) );
  DFFRX1 wdt_count_reg_4_ ( .D(n80), .CK(clk_b), .RN(n48), .Q(wdt_count[4]), 
        .QN(n173) );
  DFFRX1 wdt_count_reg_5_ ( .D(n81), .CK(clk_b), .RN(n48), .Q(wdt_count[5]), 
        .QN(n175) );
  DFFRX1 wdt_count_reg_6_ ( .D(n82), .CK(clk_b), .RN(n220), .Q(wdt_count[6]), 
        .QN(n177) );
  DFFRX1 wdt_count_reg_7_ ( .D(n83), .CK(clk_b), .RN(n220), .Q(wdt_count[7]), 
        .QN(n179) );
  DFFRX1 WDIF_reg ( .D(n65), .CK(clk_b), .RN(n220), .Q(wdt_intr), .QN(n212) );
  AND3X2 U161 ( .A(n158), .B(n225), .C(n219), .Y(n96) );
  OAI2BB2X1 I214 ( .A0N(N121), .A1N(n221), .B0(n213), .B1(n199), .Y(n158) );
  AND3X2 U164 ( .A(n163), .B(n230), .C(n219), .Y(n99) );
  OAI2BB2X1 I215 ( .A0N(N124), .A1N(n221), .B0(n214), .B1(n200), .Y(n163) );
  DFFRX1 wdt_count_reg_8_ ( .D(n84), .CK(clk_b), .RN(n220), .Q(wdt_count[8]), 
        .QN(n181) );
  DFFRX1 wdt_count_reg_9_ ( .D(n85), .CK(clk_b), .RN(n48), .Q(wdt_count[9]), 
        .QN(n183) );
  DFFRX1 wdt_count_reg_10_ ( .D(n86), .CK(clk_b), .RN(n220), .Q(wdt_count[10]), 
        .QN(n1370) );
  DFFRX1 wdt_count_reg_11_ ( .D(n87), .CK(clk_b), .RN(n220), .Q(wdt_count[11]), 
        .QN(n139) );
  DFFRX1 wdt_count_reg_12_ ( .D(n880), .CK(clk_b), .RN(n220), .Q(wdt_count[12]), .QN(n141) );
  DFFRX1 wdt_count_reg_13_ ( .D(n890), .CK(clk_b), .RN(n220), .Q(wdt_count[13]), .QN(n143) );
  DFFRX1 CKCON_reg_6_ ( .D(n56), .CK(clk_b), .RN(n220), .Q(CKCON_6_), .QN(n206) );
  DFFRX1 CKCON_reg_7_ ( .D(n57), .CK(clk_b), .RN(n48), .Q(CKCON_7_), .QN(n201)
         );
  AND3X2 U158 ( .A(n151), .B(n225), .C(n219), .Y(n93) );
  OAI2BB2X1 I216 ( .A0N(N118), .A1N(n221), .B0(n207), .B1(n234), .Y(n151) );
  DFFRX1 wdt_count_reg_26_ ( .D(n1020), .CK(clk_b), .RN(n48), .Q(wdt_count[26]), .QN(n202) );
  DFFRX1 count_512_reg_0_ ( .D(n66), .CK(clk_b), .RN(n48), .Q(count_512[0]), 
        .QN(n1160) );
  DFFRX1 count_512_reg_1_ ( .D(n67), .CK(clk_b), .RN(n220), .Q(count_512[1]), 
        .QN(n1180) );
  DFFRX1 count_512_reg_2_ ( .D(n68), .CK(clk_b), .RN(n220), .Q(count_512[2]), 
        .QN(n1200) );
  DFFRX1 wdt_count_reg_14_ ( .D(n900), .CK(clk_b), .RN(n220), .Q(wdt_count[14]), .QN(n145) );
  DFFRX1 wdt_count_reg_15_ ( .D(n910), .CK(clk_b), .RN(n220), .Q(wdt_count[15]), .QN(n147) );
  DFFRX1 wdt_count_reg_18_ ( .D(n94), .CK(clk_b), .RN(n48), .Q(wdt_count[18]), 
        .QN(n152) );
  OR2X2 I217 ( .A(n203), .B(n215), .Y(n2) );
  DFFRX1 count_512_reg_9_ ( .D(n75), .CK(clk_b), .RN(n48), .Q(count_512[9]), 
        .QN(n215) );
  DFFRX1 wdt_rst_cnt_reg_1_ ( .D(n59), .CK(clk_b), .RN(n48), .Q(wdt_rst_cnt[1]) );
  DFFRX1 wdt_rst_cnt_reg_2_ ( .D(n60), .CK(clk_b), .RN(n48), .Q(wdt_rst_cnt[2]) );
  DFFRX1 wdt_rst_cnt_reg_3_ ( .D(n61), .CK(clk_b), .RN(n220), .Q(
        wdt_rst_cnt[3]) );
  DFFRX1 count_512_reg_3_ ( .D(n69), .CK(clk_b), .RN(n220), .Q(count_512[3]), 
        .QN(n1220) );
  DFFRX1 count_512_reg_4_ ( .D(n70), .CK(clk_b), .RN(n220), .Q(count_512[4]), 
        .QN(n1240) );
  DFFRX1 count_512_reg_5_ ( .D(n71), .CK(clk_b), .RN(n48), .Q(count_512[5]), 
        .QN(n1260) );
  DFFRX1 count_512_reg_6_ ( .D(n72), .CK(clk_b), .RN(n220), .Q(count_512[6]), 
        .QN(n1280) );
  DFFRX1 count_512_reg_7_ ( .D(n73), .CK(clk_b), .RN(n48), .Q(count_512[7]), 
        .QN(n1300) );
  DFFRX1 count_512_reg_8_ ( .D(n74), .CK(clk_b), .RN(n220), .Q(count_512[8]), 
        .QN(n1320) );
  DFFRX1 wdt_count_reg_21_ ( .D(n97), .CK(clk_b), .RN(n220), .Q(wdt_count[21]), 
        .QN(n159) );
  DFFRX1 wdt_count_reg_24_ ( .D(n100), .CK(clk_b), .RN(n220), .Q(wdt_count[24]), .QN(n164) );
  DFFRX1 wdt_count_reg_25_ ( .D(n1010), .CK(clk_b), .RN(n220), .Q(
        wdt_count[25]), .QN(n166) );
  INVX1 I218 ( .A(n224), .Y(n233) );
  INVX1 I219 ( .A(n224), .Y(n235) );
  INVX1 I220 ( .A(n224), .Y(n234) );
  AND2X2 U124 ( .A(n219), .B(n187), .Y(n59) );
  OAI2BB1X1 I221 ( .A0N(N89), .A1N(n2), .B0(n3), .Y(n187) );
  AND2X2 U125 ( .A(n219), .B(n189), .Y(n60) );
  OAI2BB1X1 I222 ( .A0N(N90), .A1N(n2), .B0(n3), .Y(n189) );
  AND2X2 U126 ( .A(n219), .B(n191), .Y(n61) );
  OAI2BB1X1 I223 ( .A0N(N91), .A1N(n2), .B0(n3), .Y(n191) );
  AND2X2 I224 ( .A(CKCON_sel), .B(CKCON_7_), .Y(WDT_SFR_OUT[7]) );
  NOR2BX1 U119 ( .AN(n1070), .B(n227), .Y(n54) );
  OAI2BB2X1 I225 ( .A0N(SFR_bus[4]), .A1N(n43), .B0(n43), .B1(n217), .Y(n1070)
         );
  NOR2BX1 U120 ( .AN(n1080), .B(n229), .Y(n55) );
  OAI2BB2X1 I226 ( .A0N(SFR_bus[5]), .A1N(n43), .B0(n43), .B1(n218), .Y(n1080)
         );
  AND3X2 U167 ( .A(n168), .B(n230), .C(n219), .Y(n1020) );
  OAI2BB2X1 I227 ( .A0N(N127), .A1N(n221), .B0(n202), .B1(n234), .Y(n168) );
  AND2X2 I228 ( .A(CKCON_sel), .B(CKCON_6_), .Y(WDT_SFR_OUT[6]) );
  AND2X2 I229 ( .A(T2M), .B(CKCON_sel), .Y(WDT_SFR_OUT[5]) );
  AND2X2 I230 ( .A(T1M), .B(CKCON_sel), .Y(WDT_SFR_OUT[4]) );
  AND3X2 U162 ( .A(n160), .B(n231), .C(n219), .Y(n97) );
  OAI2BB2X1 I231 ( .A0N(N122), .A1N(n221), .B0(n235), .B1(n159), .Y(n160) );
  AND3X2 U163 ( .A(n162), .B(n225), .C(n223), .Y(n98) );
  OAI2BB2X1 I232 ( .A0N(N123), .A1N(n221), .B0(n235), .B1(n161), .Y(n162) );
  AND3X2 U165 ( .A(n165), .B(n225), .C(n219), .Y(n100) );
  OAI2BB2X1 I233 ( .A0N(N125), .A1N(n221), .B0(n234), .B1(n164), .Y(n165) );
  AND3X2 U166 ( .A(n167), .B(n230), .C(n219), .Y(n1010) );
  OAI2BB2X1 I234 ( .A0N(N126), .A1N(n221), .B0(n233), .B1(n166), .Y(n167) );
  AND3X2 U155 ( .A(n146), .B(n225), .C(n219), .Y(n900) );
  OAI2BB2X1 I235 ( .A0N(N115), .A1N(n221), .B0(n235), .B1(n145), .Y(n146) );
  AND3X2 U156 ( .A(n148), .B(n226), .C(n219), .Y(n910) );
  OAI2BB2X1 I236 ( .A0N(N116), .A1N(n221), .B0(n234), .B1(n147), .Y(n148) );
  AND3X2 U157 ( .A(n150), .B(n225), .C(n223), .Y(n920) );
  OAI2BB2X1 I237 ( .A0N(N117), .A1N(n221), .B0(n233), .B1(n149), .Y(n150) );
  AND3X2 U159 ( .A(n153), .B(n225), .C(n219), .Y(n94) );
  OAI2BB2X1 I238 ( .A0N(N119), .A1N(n221), .B0(n233), .B1(n152), .Y(n153) );
  AND3X1 U160 ( .A(n155), .B(n226), .C(n223), .Y(n95) );
  OAI2BB2X1 I239 ( .A0N(N120), .A1N(n221), .B0(n200), .B1(n154), .Y(n155) );
  AND3X1 U131 ( .A(n1170), .B(n226), .C(n219), .Y(n66) );
  OAI2BB2X1 I240 ( .A0N(N128), .A1N(n222), .B0(n232), .B1(n1160), .Y(n1170) );
  AND3X1 U132 ( .A(n1190), .B(n231), .C(n219), .Y(n67) );
  OAI2BB2X1 I241 ( .A0N(N129), .A1N(n222), .B0(n232), .B1(n1180), .Y(n1190) );
  AND3X1 U133 ( .A(n1210), .B(n226), .C(n219), .Y(n68) );
  OAI2BB2X1 I242 ( .A0N(N130), .A1N(n222), .B0(n232), .B1(n1200), .Y(n1210) );
  AND3X1 U134 ( .A(n1230), .B(n226), .C(n219), .Y(n69) );
  OAI2BB2X1 I243 ( .A0N(N131), .A1N(n222), .B0(n232), .B1(n1220), .Y(n1230) );
  AND3X1 U135 ( .A(n1250), .B(n226), .C(n223), .Y(n70) );
  OAI2BB2X1 I244 ( .A0N(N132), .A1N(n222), .B0(n232), .B1(n1240), .Y(n1250) );
  AND3X1 U136 ( .A(n1270), .B(n226), .C(n219), .Y(n71) );
  OAI2BB2X1 I245 ( .A0N(N133), .A1N(n222), .B0(n232), .B1(n1260), .Y(n1270) );
  AND3X1 U137 ( .A(n1290), .B(n226), .C(n219), .Y(n72) );
  OAI2BB2X1 I246 ( .A0N(N134), .A1N(n222), .B0(n232), .B1(n1280), .Y(n1290) );
  AND3X1 U138 ( .A(n1310), .B(n226), .C(n223), .Y(n73) );
  OAI2BB2X1 I247 ( .A0N(N135), .A1N(n222), .B0(n232), .B1(n1300), .Y(n1310) );
  AND3X1 U139 ( .A(n1330), .B(n225), .C(n219), .Y(n74) );
  OAI2BB2X1 I248 ( .A0N(N136), .A1N(n222), .B0(n232), .B1(n1320), .Y(n1330) );
  AND2X2 I249 ( .A(n223), .B(n232), .Y(n222) );
  OR2X2 I250 ( .A(n36), .B(n37), .Y(n21) );
  AND3X1 U140 ( .A(n1340), .B(n226), .C(n223), .Y(n75) );
  OAI2BB2X1 I251 ( .A0N(N137), .A1N(n222), .B0(n215), .B1(n232), .Y(n1340) );
  AND3X1 U141 ( .A(n1360), .B(n225), .C(n223), .Y(n76) );
  OAI2BB2X1 I252 ( .A0N(N101), .A1N(n221), .B0(n199), .B1(n1350), .Y(n1360) );
  AND3X1 U142 ( .A(n157), .B(n226), .C(n219), .Y(n77) );
  OAI2BB2X1 I253 ( .A0N(N102), .A1N(n221), .B0(n235), .B1(n156), .Y(n157) );
  AND3X1 U143 ( .A(n170), .B(n225), .C(n223), .Y(n78) );
  OAI2BB2X1 I254 ( .A0N(N103), .A1N(n221), .B0(n200), .B1(n169), .Y(n170) );
  AND3X1 U144 ( .A(n172), .B(n226), .C(n219), .Y(n79) );
  OAI2BB2X1 I255 ( .A0N(N104), .A1N(n221), .B0(n233), .B1(n171), .Y(n172) );
  AND3X1 U145 ( .A(n174), .B(n225), .C(n223), .Y(n80) );
  OAI2BB2X1 I256 ( .A0N(N105), .A1N(n221), .B0(n200), .B1(n173), .Y(n174) );
  AND3X1 U146 ( .A(n176), .B(n226), .C(n219), .Y(n81) );
  OAI2BB2X1 I257 ( .A0N(N106), .A1N(n221), .B0(n200), .B1(n175), .Y(n176) );
  AND3X1 U147 ( .A(n178), .B(n225), .C(n223), .Y(n82) );
  OAI2BB2X1 I258 ( .A0N(N107), .A1N(n221), .B0(n199), .B1(n177), .Y(n178) );
  AND3X1 U148 ( .A(n180), .B(n226), .C(n223), .Y(n83) );
  OAI2BB2X1 I259 ( .A0N(N108), .A1N(n221), .B0(n200), .B1(n179), .Y(n180) );
  AND3X1 U149 ( .A(n182), .B(n225), .C(n219), .Y(n84) );
  OAI2BB2X1 I260 ( .A0N(N109), .A1N(n221), .B0(n200), .B1(n181), .Y(n182) );
  AND3X1 U150 ( .A(n184), .B(n226), .C(n219), .Y(n85) );
  OAI2BB2X1 I261 ( .A0N(N110), .A1N(n221), .B0(n199), .B1(n183), .Y(n184) );
  AND3X1 U151 ( .A(n138), .B(n225), .C(n223), .Y(n86) );
  OAI2BB2X1 I262 ( .A0N(N111), .A1N(n221), .B0(n199), .B1(n1370), .Y(n138) );
  AND3X1 U152 ( .A(n140), .B(n226), .C(n219), .Y(n87) );
  OAI2BB2X1 I263 ( .A0N(N112), .A1N(n221), .B0(n199), .B1(n139), .Y(n140) );
  AND3X1 U153 ( .A(n142), .B(n225), .C(n219), .Y(n880) );
  OAI2BB2X1 I264 ( .A0N(N113), .A1N(n221), .B0(n199), .B1(n141), .Y(n142) );
  AND3X1 U154 ( .A(n144), .B(n226), .C(n219), .Y(n890) );
  OAI2BB2X1 I265 ( .A0N(N114), .A1N(n221), .B0(n199), .B1(n143), .Y(n144) );
  NAND4X1 I266 ( .A(wdt_rst_cnt[3]), .B(wdt_rst_cnt[4]), .C(wdt_rst_cnt[1]), 
        .D(wdt_rst_cnt[2]), .Y(n6) );
  AND2X1 U127 ( .A(n219), .B(n193), .Y(n62) );
  OAI2BB1X1 I267 ( .A0N(N92), .A1N(n2), .B0(n3), .Y(n193) );
  AND2X1 U123 ( .A(n185), .B(n219), .Y(n58) );
  OAI2BB1X1 I268 ( .A0N(N88), .A1N(n2), .B0(n3), .Y(n185) );
  OAI221X4 I269 ( .A0(n208), .A1(n216), .B0(n26), .B1(n216), .C0(n2), .Y(n1140) );
  INVX1 I270 ( .A(n6), .Y(n26) );
  DFFRX1 CKCON_reg_0_ ( .D(n50), .CK(clk_b), .RN(n220), .QN(n210) );
  DFFRX1 CKCON_reg_1_ ( .D(n51), .CK(clk_b), .RN(n220), .QN(n209) );
  DFFRX1 CKCON_reg_2_ ( .D(n52), .CK(clk_b), .RN(n220), .QN(n211) );
  DFFRX1 WTRF_reg ( .D(n1150), .CK(clk_b), .RN(n220), .QN(n204) );
  DFFRX1 wdt_rst_cnt_reg_4_ ( .D(n62), .CK(clk_b), .RN(n220), .Q(
        wdt_rst_cnt[4]) );
  DFFRX1 WDT_reset_reg ( .D(n1140), .CK(clk_b), .RN(n220), .Q(WDT_reset), .QN(
        n216) );
  DFFHQX1 RWT_D_reg ( .D(RWT), .CK(clk_b), .Q(RWT_D) );
  INVX1 I271 ( .A(SFR_bus[0]), .Y(n40) );
  OAI211X4 I272 ( .A0(SFR_bus[0]), .A1(n34), .B0(RWT_D), .C0(RWT), .Y(n41) );
  wdt_DW01_inc_5_0 add_144 ( .A(wdt_rst_cnt), .SUM({N92, N91, N90, N89, N88})
         );
  wdt_DW01_inc_10_0 add_100 ( .A(count_512), .SUM({N137, N136, N135, N134, 
        N133, N132, N131, N130, N129, N128}) );
  wdt_DW01_inc_27_0 add_94 ( .A(wdt_count), .SUM({N127, N126, N125, N124, N123, 
        N122, N121, N120, N119, N118, N117, N116, N115, N114, N113, N112, N111, 
        N110, N109, N108, N107, N106, N105, N104, N103, N102, N101}) );
  DFFX4 reset_d_reg ( .D(reset), .CK(clk_b) );
  DFFRX4 RWT_reg ( .D(n63), .CK(clk_b), .RN(n48), .Q(RWT), .QN(n223) );
endmodule


module wdt_DW01_inc_27_0 ( A, SUM );
  input [26:0] A;
  output [26:0] SUM;
  wire   carry_26_, carry_25_, carry_24_, carry_23_, carry_22_, carry_21_,
         carry_20_, carry_19_, carry_18_, carry_17_, carry_16_, carry_15_,
         carry_14_, carry_13_, carry_12_, carry_11_, carry_10_, carry_9_,
         carry_8_, carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_;

  CMPR22X1 U1_1_16 ( .A(A[16]), .B(carry_16_), .S(SUM[16]), .CO(carry_17_) );
  CMPR22X1 U1_1_19 ( .A(A[19]), .B(carry_19_), .S(SUM[19]), .CO(carry_20_) );
  CMPR22X1 U1_1_22 ( .A(A[22]), .B(carry_22_), .S(SUM[22]), .CO(carry_23_) );
  XOR2X1 U5 ( .A(carry_26_), .B(A[26]), .Y(SUM[26]) );
  CMPR22X1 U1_1_17 ( .A(A[17]), .B(carry_17_), .S(SUM[17]), .CO(carry_18_) );
  CMPR22X1 U1_1_20 ( .A(A[20]), .B(carry_20_), .S(SUM[20]), .CO(carry_21_) );
  CMPR22X1 U1_1_23 ( .A(A[23]), .B(carry_23_), .S(SUM[23]), .CO(carry_24_) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(carry_5_) );
  CMPR22X1 U1_1_5 ( .A(A[5]), .B(carry_5_), .S(SUM[5]), .CO(carry_6_) );
  CMPR22X1 U1_1_6 ( .A(A[6]), .B(carry_6_), .S(SUM[6]), .CO(carry_7_) );
  CMPR22X1 U1_1_7 ( .A(A[7]), .B(carry_7_), .S(SUM[7]), .CO(carry_8_) );
  CMPR22X1 U1_1_8 ( .A(A[8]), .B(carry_8_), .S(SUM[8]), .CO(carry_9_) );
  CMPR22X1 U1_1_9 ( .A(A[9]), .B(carry_9_), .S(SUM[9]), .CO(carry_10_) );
  CMPR22X1 U1_1_10 ( .A(A[10]), .B(carry_10_), .S(SUM[10]), .CO(carry_11_) );
  CMPR22X1 U1_1_11 ( .A(A[11]), .B(carry_11_), .S(SUM[11]), .CO(carry_12_) );
  CMPR22X1 U1_1_12 ( .A(A[12]), .B(carry_12_), .S(SUM[12]), .CO(carry_13_) );
  CMPR22X1 U1_1_13 ( .A(A[13]), .B(carry_13_), .S(SUM[13]), .CO(carry_14_) );
  CMPR22X1 U1_1_14 ( .A(A[14]), .B(carry_14_), .S(SUM[14]), .CO(carry_15_) );
  CMPR22X1 U1_1_15 ( .A(A[15]), .B(carry_15_), .S(SUM[15]), .CO(carry_16_) );
  CMPR22X1 U1_1_18 ( .A(A[18]), .B(carry_18_), .S(SUM[18]), .CO(carry_19_) );
  CMPR22X1 U1_1_21 ( .A(A[21]), .B(carry_21_), .S(SUM[21]), .CO(carry_22_) );
  CMPR22X1 U1_1_24 ( .A(A[24]), .B(carry_24_), .S(SUM[24]), .CO(carry_25_) );
  CMPR22X1 U1_1_25 ( .A(A[25]), .B(carry_25_), .S(SUM[25]), .CO(carry_26_) );
  INVX1 U6 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module wdt_DW01_inc_10_0 ( A, SUM );
  input [9:0] A;
  output [9:0] SUM;
  wire   carry_9_, carry_8_, carry_7_, carry_6_, carry_5_, carry_4_, carry_3_,
         carry_2_;

  INVX1 U5 ( .A(A[0]), .Y(SUM[0]) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(carry_5_) );
  CMPR22X1 U1_1_5 ( .A(A[5]), .B(carry_5_), .S(SUM[5]), .CO(carry_6_) );
  CMPR22X1 U1_1_6 ( .A(A[6]), .B(carry_6_), .S(SUM[6]), .CO(carry_7_) );
  CMPR22X1 U1_1_7 ( .A(A[7]), .B(carry_7_), .S(SUM[7]), .CO(carry_8_) );
  CMPR22X1 U1_1_8 ( .A(A[8]), .B(carry_8_), .S(SUM[8]), .CO(carry_9_) );
  XOR2X1 U6 ( .A(carry_9_), .B(A[9]), .Y(SUM[9]) );
endmodule


module wdt_DW01_inc_5_0 ( A, SUM );
  input [4:0] A;
  output [4:0] SUM;
  wire   carry_4_, carry_3_, carry_2_;

  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  XOR2X1 U5 ( .A(carry_4_), .B(A[4]), .Y(SUM[4]) );
  INVX1 U6 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module pwm_top ( sw_rst, clk_b, SFR_wr, PWM1CON_sel, PWM2CON_sel, PWM1D_sel, 
        PWM2D_sel, SFR_bus, PWM_SFR_OUT, pwm1_out, pwm2_out, PWM1D, PWM1_SEL, 
        PWM2_SEL );
  input [7:0] SFR_bus;
  output [7:0] PWM_SFR_OUT;
  output [7:0] PWM1D;
  input sw_rst, clk_b, SFR_wr, PWM1CON_sel, PWM2CON_sel, PWM1D_sel, PWM2D_sel;
  output pwm1_out, pwm2_out, PWM1_SEL, PWM2_SEL;
  wire   pwm1_reload, pwm2_reload, pwm1_en, pwm2_en, pwm1_reset, pwm2_reset,
         n1, n2;
  wire   [7:0] PWM1CON;
  wire   [7:0] PWM2CON;
  wire   [7:0] PWM2D;
  wire   [7:0] pwm1buf;
  wire   [7:0] pwm2buf;
  wire   [7:0] pwm1_cnt;
  wire   [7:0] pwm2_cnt;

  sfr_pwm sfr_pwm ( .PWM1_SEL(PWM1_SEL), .PWM2_SEL(PWM2_SEL), .sw_rst(n1), 
        .clk_b(clk_b), .SFR_wr(SFR_wr), .PWM1CON_sel(PWM1CON_sel), 
        .PWM2CON_sel(PWM2CON_sel), .PWM1D_sel(PWM1D_sel), .PWM2D_sel(PWM2D_sel), .SFR_bus(SFR_bus), .PWM_SFR_OUT(PWM_SFR_OUT), .PWM1CON(PWM1CON), .PWM2CON(
        PWM2CON), .PWM1D(PWM1D), .PWM2D(PWM2D) );
  buf_pwm1 buf_pwm1 ( .sw_rst(n1), .clk_b(clk_b), .pwm1_clear(PWM1CON[1]), 
        .PWM1D(PWM1D), .pwm1_reload(pwm1_reload), .pwm1buf(pwm1buf) );
  buf_pwm2 buf_pwm2 ( .sw_rst(n1), .clk_b(clk_b), .pwm2_clear(PWM2CON[1]), 
        .PWM2D(PWM2D), .pwm2_reload(pwm2_reload), .pwm2buf(pwm2buf) );
  comp_pwm1 comp_pwm1 ( .sw_rst(n1), .clk_b(clk_b), .PWM1CON(PWM1CON), 
        .pwm1buf(pwm1buf), .pwm1_cnt(pwm1_cnt), .pwm1_reset(pwm1_reset), 
        .pwm1_out(pwm1_out) );
  comp_pwm2 comp_pwm2 ( .sw_rst(n1), .clk_b(clk_b), .PWM2CON(PWM2CON), 
        .pwm2buf(pwm2buf), .pwm2_cnt(pwm2_cnt), .pwm2_reset(pwm2_reset), 
        .pwm2_out(pwm2_out) );
  counter_pwm1 counter_pwm1 ( .sw_rst(n1), .clk_b(clk_b), .PWM1CON(PWM1CON), 
        .PWM1D(PWM1D), .pwm1_en(pwm1_en), .pwm1_reload(pwm1_reload), 
        .pwm1_reset(pwm1_reset), .pwm1_cnt(pwm1_cnt) );
  counter_pwm2 counter_pwm2 ( .sw_rst(n1), .clk_b(clk_b), .PWM2CON(PWM2CON), 
        .PWM2D(PWM2D), .pwm2_en(pwm2_en), .pwm2_reload(pwm2_reload), 
        .pwm2_reset(pwm2_reset), .pwm2_cnt(pwm2_cnt) );
  prescale_pwm1 prescale_pwm1 ( .sw_rst(n1), .clk_b(clk_b), .PWM1CON(PWM1CON), 
        .pwm1_en(pwm1_en) );
  prescale_pwm2 prescale_pwm2 ( .sw_rst(n1), .clk_b(clk_b), .PWM2CON(PWM2CON), 
        .pwm2_en(pwm2_en) );
  INVX2 I1 ( .A(n2), .Y(n1) );
  INVX1 I2 ( .A(sw_rst), .Y(n2) );
endmodule


module prescale_pwm2 ( sw_rst, clk_b, PWM2CON, pwm2_en );
  input [7:0] PWM2CON;
  input sw_rst, clk_b;
  output pwm2_en;
  wire   pwm2_clk_en, pwm2_en_reg, pwm2_en_del, N37, N38, N39, N40, N41, N42,
         N43, n2, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16, n17,
         n18;
  wire   [6:0] pwm2_clk_cnt;

  OAI32X4 U3 ( .A0(n2), .A1(PWM2CON[6]), .A2(PWM2CON[5]), .B0(pwm2_en_del), 
        .B1(n2), .Y(pwm2_en) );
  AOI33X4 U9 ( .A0(pwm2_clk_cnt[0]), .A1(n10), .A2(PWM2CON[4]), .B0(PWM2CON[4]), .B1(pwm2_clk_cnt[2]), .B2(PWM2CON[5]), .Y(n6) );
  AOI33X4 U15 ( .A0(pwm2_clk_cnt[4]), .A1(n10), .A2(PWM2CON[4]), .B0(
        PWM2CON[4]), .B1(pwm2_clk_cnt[6]), .B2(PWM2CON[5]), .Y(n11) );
  NOR2X1 I20 ( .A(PWM2CON[4]), .B(n17), .Y(n13) );
  AOI32X1 I21 ( .A0(pwm2_clk_cnt[1]), .A1(n8), .A2(PWM2CON[5]), .B0(n9), .B1(
        n10), .Y(n7) );
  AOI32X1 I22 ( .A0(pwm2_clk_cnt[5]), .A1(n8), .A2(PWM2CON[5]), .B0(n13), .B1(
        n10), .Y(n12) );
  AND2X2 I23 ( .A(n6), .B(n7), .Y(n5) );
  DFFHQX1 pwm2_clk_en_reg ( .D(PWM2CON[0]), .CK(clk_b), .Q(pwm2_clk_en) );
  DFFTRX1 pwm2_clk_cnt_reg_0_ ( .D(N37), .CK(clk_b), .RN(n14), .Q(
        pwm2_clk_cnt[0]) );
  DFFTRX1 pwm2_clk_cnt_reg_3_ ( .D(N40), .CK(clk_b), .RN(n14), .Q(
        pwm2_clk_cnt[3]), .QN(n17) );
  DFFTRX1 pwm2_clk_cnt_reg_1_ ( .D(N38), .CK(clk_b), .RN(n14), .Q(
        pwm2_clk_cnt[1]) );
  DFFTRX1 pwm2_clk_cnt_reg_2_ ( .D(N39), .CK(clk_b), .RN(n14), .Q(
        pwm2_clk_cnt[2]) );
  DFFTRX1 pwm2_clk_cnt_reg_4_ ( .D(N41), .CK(clk_b), .RN(n14), .Q(
        pwm2_clk_cnt[4]) );
  DFFTRX1 pwm2_clk_cnt_reg_5_ ( .D(N42), .CK(clk_b), .RN(n14), .Q(
        pwm2_clk_cnt[5]) );
  OAI2BB2X1 I24 ( .A0N(n18), .A1N(PWM2CON[6]), .B0(PWM2CON[6]), .B1(n5), .Y(
        pwm2_en_reg) );
  NAND2X1 I25 ( .A(n11), .B(n12), .Y(n18) );
  INVX1 I26 ( .A(pwm2_en_reg), .Y(n2) );
  INVX1 I27 ( .A(PWM2CON[4]), .Y(n8) );
  AND2X2 I28 ( .A(n8), .B(pwm2_clk_en), .Y(n9) );
  INVX1 I29 ( .A(PWM2CON[5]), .Y(n10) );
  INVX1 I30 ( .A(n15), .Y(n14) );
  OR3X1 I31 ( .A(sw_rst), .B(PWM2CON[1]), .C(n16), .Y(n15) );
  INVX1 I32 ( .A(pwm2_clk_en), .Y(n16) );
  DFFTRX1 pwm2_clk_cnt_reg_6_ ( .D(N43), .CK(clk_b), .RN(n14), .Q(
        pwm2_clk_cnt[6]) );
  DFFHQX1 pwm2_en_del_reg ( .D(pwm2_en_reg), .CK(clk_b), .Q(pwm2_en_del) );
  prescale_pwm2_DW01_dec_7_0 sub_125 ( .A(pwm2_clk_cnt), .SUM({N43, N42, N41, 
        N40, N39, N38, N37}) );
endmodule


module prescale_pwm2_DW01_dec_7_0 ( A, SUM );
  input [6:0] A;
  output [6:0] SUM;
  wire   carry_5_, carry_4_, carry_3_, carry_2_, n5;

  OR2X2 U1_B_1 ( .A(A[1]), .B(A[0]), .Y(carry_2_) );
  OR2X2 U1_B_2 ( .A(A[2]), .B(carry_2_), .Y(carry_3_) );
  OR2X2 U1_B_3 ( .A(A[3]), .B(carry_3_), .Y(carry_4_) );
  OR2X2 U1_B_4 ( .A(A[4]), .B(carry_4_), .Y(carry_5_) );
  XNOR2X1 U1_A_5 ( .A(A[5]), .B(carry_5_), .Y(SUM[5]) );
  XNOR2X1 U1_A_4 ( .A(A[4]), .B(carry_4_), .Y(SUM[4]) );
  XOR2X1 U6 ( .A(A[6]), .B(n5), .Y(SUM[6]) );
  NOR2X1 U7 ( .A(A[5]), .B(carry_5_), .Y(n5) );
  XNOR2X1 U1_A_1 ( .A(A[1]), .B(A[0]), .Y(SUM[1]) );
  XNOR2X1 U1_A_3 ( .A(A[3]), .B(carry_3_), .Y(SUM[3]) );
  XNOR2X1 U1_A_2 ( .A(A[2]), .B(carry_2_), .Y(SUM[2]) );
  INVX1 U8 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module prescale_pwm1 ( sw_rst, clk_b, PWM1CON, pwm1_en );
  input [7:0] PWM1CON;
  input sw_rst, clk_b;
  output pwm1_en;
  wire   pwm1_clk_en, pwm1_en_reg, pwm1_en_del, N37, N38, N39, N40, N41, N42,
         N43, n2, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16, n17,
         n18;
  wire   [6:0] pwm1_clk_cnt;

  OAI32X4 U3 ( .A0(n2), .A1(PWM1CON[6]), .A2(PWM1CON[5]), .B0(pwm1_en_del), 
        .B1(n2), .Y(pwm1_en) );
  AOI33X4 U9 ( .A0(pwm1_clk_cnt[0]), .A1(n10), .A2(PWM1CON[4]), .B0(PWM1CON[4]), .B1(pwm1_clk_cnt[2]), .B2(PWM1CON[5]), .Y(n6) );
  AOI33X4 U15 ( .A0(pwm1_clk_cnt[4]), .A1(n10), .A2(PWM1CON[4]), .B0(
        PWM1CON[4]), .B1(pwm1_clk_cnt[6]), .B2(PWM1CON[5]), .Y(n11) );
  NOR2X1 I20 ( .A(PWM1CON[4]), .B(n17), .Y(n13) );
  AOI32X1 I21 ( .A0(pwm1_clk_cnt[1]), .A1(n8), .A2(PWM1CON[5]), .B0(n9), .B1(
        n10), .Y(n7) );
  AOI32X1 I22 ( .A0(pwm1_clk_cnt[5]), .A1(n8), .A2(PWM1CON[5]), .B0(n13), .B1(
        n10), .Y(n12) );
  AND2X2 I23 ( .A(n6), .B(n7), .Y(n5) );
  DFFHQX1 pwm1_clk_en_reg ( .D(PWM1CON[0]), .CK(clk_b), .Q(pwm1_clk_en) );
  DFFTRX1 pwm1_clk_cnt_reg_0_ ( .D(N37), .CK(clk_b), .RN(n14), .Q(
        pwm1_clk_cnt[0]) );
  DFFTRX1 pwm1_clk_cnt_reg_3_ ( .D(N40), .CK(clk_b), .RN(n14), .Q(
        pwm1_clk_cnt[3]), .QN(n17) );
  DFFTRX1 pwm1_clk_cnt_reg_1_ ( .D(N38), .CK(clk_b), .RN(n14), .Q(
        pwm1_clk_cnt[1]) );
  DFFTRX1 pwm1_clk_cnt_reg_2_ ( .D(N39), .CK(clk_b), .RN(n14), .Q(
        pwm1_clk_cnt[2]) );
  DFFTRX1 pwm1_clk_cnt_reg_4_ ( .D(N41), .CK(clk_b), .RN(n14), .Q(
        pwm1_clk_cnt[4]) );
  DFFTRX1 pwm1_clk_cnt_reg_5_ ( .D(N42), .CK(clk_b), .RN(n14), .Q(
        pwm1_clk_cnt[5]) );
  OAI2BB2X1 I24 ( .A0N(n18), .A1N(PWM1CON[6]), .B0(PWM1CON[6]), .B1(n5), .Y(
        pwm1_en_reg) );
  NAND2X1 I25 ( .A(n11), .B(n12), .Y(n18) );
  INVX1 I26 ( .A(pwm1_en_reg), .Y(n2) );
  INVX1 I27 ( .A(PWM1CON[4]), .Y(n8) );
  AND2X2 I28 ( .A(n8), .B(pwm1_clk_en), .Y(n9) );
  INVX1 I29 ( .A(PWM1CON[5]), .Y(n10) );
  INVX1 I30 ( .A(n15), .Y(n14) );
  OR3X1 I31 ( .A(sw_rst), .B(PWM1CON[1]), .C(n16), .Y(n15) );
  INVX1 I32 ( .A(pwm1_clk_en), .Y(n16) );
  DFFTRX1 pwm1_clk_cnt_reg_6_ ( .D(N43), .CK(clk_b), .RN(n14), .Q(
        pwm1_clk_cnt[6]) );
  DFFHQX1 pwm1_en_del_reg ( .D(pwm1_en_reg), .CK(clk_b), .Q(pwm1_en_del) );
  prescale_pwm1_DW01_dec_7_0 sub_65 ( .A(pwm1_clk_cnt), .SUM({N43, N42, N41, 
        N40, N39, N38, N37}) );
endmodule


module prescale_pwm1_DW01_dec_7_0 ( A, SUM );
  input [6:0] A;
  output [6:0] SUM;
  wire   carry_5_, carry_4_, carry_3_, carry_2_, n5;

  OR2X2 U1_B_1 ( .A(A[1]), .B(A[0]), .Y(carry_2_) );
  OR2X2 U1_B_2 ( .A(A[2]), .B(carry_2_), .Y(carry_3_) );
  OR2X2 U1_B_3 ( .A(A[3]), .B(carry_3_), .Y(carry_4_) );
  OR2X2 U1_B_4 ( .A(A[4]), .B(carry_4_), .Y(carry_5_) );
  XNOR2X1 U1_A_5 ( .A(A[5]), .B(carry_5_), .Y(SUM[5]) );
  XNOR2X1 U1_A_4 ( .A(A[4]), .B(carry_4_), .Y(SUM[4]) );
  XOR2X1 U6 ( .A(A[6]), .B(n5), .Y(SUM[6]) );
  NOR2X1 U7 ( .A(A[5]), .B(carry_5_), .Y(n5) );
  XNOR2X1 U1_A_1 ( .A(A[1]), .B(A[0]), .Y(SUM[1]) );
  XNOR2X1 U1_A_3 ( .A(A[3]), .B(carry_3_), .Y(SUM[3]) );
  XNOR2X1 U1_A_2 ( .A(A[2]), .B(carry_2_), .Y(SUM[2]) );
  INVX1 U8 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module counter_pwm2 ( sw_rst, clk_b, PWM2CON, PWM2D, pwm2_en, pwm2_reload, 
        pwm2_reset, pwm2_cnt, pwm2_intr );
  input [7:0] PWM2CON;
  input [7:0] PWM2D;
  output [7:0] pwm2_cnt;
  input sw_rst, clk_b, pwm2_en;
  output pwm2_reload, pwm2_reset, pwm2_intr;
  wire   pwm2_reload_tmp, pwm2_reload_dly, N16, N17, N18, N19, N20, N21, N22,
         N23, N26, N27, N28, N29, N30, N31, N32, N33, N34, n3, n4, n5, n6, n7,
         n8, n9, n10, n11, n13, n14, n15, n160, n170, n180, n190;

  EDFFX4 pwm2_cnt_reg_6_ ( .D(N22), .CK(clk_b), .E(N26), .Q(pwm2_cnt[6]), .QN(
        n15) );
  AOI211X4 U4 ( .A0(PWM2CON[3]), .A1(n3), .B0(n4), .C0(n5), .Y(pwm2_reset) );
  AOI221X4 U6 ( .A0(PWM2D[6]), .A1(PWM2CON[3]), .B0(PWM2D[7]), .B1(PWM2CON[3]), 
        .C0(n7), .Y(n6) );
  OAI33X4 U14 ( .A0(n5), .A1(pwm2_cnt[7]), .A2(pwm2_cnt[6]), .B0(n5), .B1(
        PWM2CON[3]), .B2(PWM2CON[2]), .Y(pwm2_reload_tmp) );
  NAND2X1 I28 ( .A(n14), .B(n15), .Y(n3) );
  NAND3X1 I29 ( .A(n160), .B(n170), .C(n180), .Y(n13) );
  EDFFX1 pwm2_cnt_reg_5_ ( .D(N21), .CK(clk_b), .E(N26), .Q(pwm2_cnt[5]), .QN(
        n160) );
  EDFFX1 pwm2_cnt_reg_4_ ( .D(N20), .CK(clk_b), .E(N26), .Q(pwm2_cnt[4]), .QN(
        n170) );
  EDFFX1 pwm2_cnt_reg_3_ ( .D(N19), .CK(clk_b), .E(N26), .Q(pwm2_cnt[3]), .QN(
        n180) );
  NOR2X1 I30 ( .A(n190), .B(n11), .Y(pwm2_intr) );
  INVX1 I31 ( .A(n11), .Y(pwm2_reload) );
  OR2X2 I32 ( .A(pwm2_en), .B(n10), .Y(N26) );
  EDFFX2 pwm2_cnt_reg_7_ ( .D(N23), .CK(clk_b), .E(N26), .Q(pwm2_cnt[7]), .QN(
        n14) );
  EDFFX2 pwm2_cnt_reg_2_ ( .D(N18), .CK(clk_b), .E(N26), .Q(pwm2_cnt[2]) );
  EDFFX2 pwm2_cnt_reg_1_ ( .D(N17), .CK(clk_b), .E(N26), .Q(pwm2_cnt[1]) );
  EDFFX2 pwm2_cnt_reg_0_ ( .D(N16), .CK(clk_b), .E(N26), .Q(pwm2_cnt[0]) );
  NAND2BX1 I33 ( .AN(pwm2_reload_dly), .B(pwm2_reload_tmp), .Y(n11) );
  INVX2 I34 ( .A(n10), .Y(n9) );
  OAI2BB1X1 I35 ( .A0N(N33), .A1N(pwm2_en), .B0(n9), .Y(N22) );
  OAI2BB1X1 I36 ( .A0N(N32), .A1N(pwm2_en), .B0(n9), .Y(N21) );
  OAI2BB1X1 I37 ( .A0N(N31), .A1N(pwm2_en), .B0(n9), .Y(N20) );
  OAI2BB1X1 I38 ( .A0N(N30), .A1N(pwm2_en), .B0(n9), .Y(N19) );
  OAI2BB1X1 I39 ( .A0N(N29), .A1N(pwm2_en), .B0(n9), .Y(N18) );
  OAI2BB1X1 I40 ( .A0N(N28), .A1N(pwm2_en), .B0(n9), .Y(N17) );
  EDFFTRX1 pwm2_intr_rdy_reg ( .D(1'b1), .CK(clk_b), .E(pwm2_reload), .RN(n9), 
        .QN(n190) );
  OR2X2 I41 ( .A(pwm2_reload_dly), .B(n6), .Y(n4) );
  OR4X2 I42 ( .A(pwm2_cnt[2]), .B(pwm2_cnt[1]), .C(pwm2_cnt[0]), .D(n13), .Y(
        n5) );
  OR3X2 I43 ( .A(PWM2D[1]), .B(PWM2D[0]), .C(n8), .Y(n7) );
  OR4X2 I44 ( .A(PWM2D[3]), .B(PWM2D[2]), .C(PWM2D[5]), .D(PWM2D[4]), .Y(n8)
         );
  OR2X2 I45 ( .A(PWM2CON[1]), .B(sw_rst), .Y(n10) );
  OAI2BB1X1 I46 ( .A0N(N34), .A1N(pwm2_en), .B0(n9), .Y(N23) );
  OAI2BB1X1 I47 ( .A0N(N27), .A1N(pwm2_en), .B0(n9), .Y(N16) );
  DFFHQX1 pwm2_reload_dly_reg ( .D(pwm2_reload_tmp), .CK(clk_b), .Q(
        pwm2_reload_dly) );
  counter_pwm2_DW01_inc_8_0 add_156 ( .A(pwm2_cnt), .SUM({N34, N33, N32, N31, 
        N30, N29, N28, N27}) );
endmodule


module counter_pwm2_DW01_inc_8_0 ( A, SUM );
  input [7:0] A;
  output [7:0] SUM;
  wire   carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_;

  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(carry_5_) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  CMPR22X1 U1_1_5 ( .A(A[5]), .B(carry_5_), .S(SUM[5]), .CO(carry_6_) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_6 ( .A(A[6]), .B(carry_6_), .S(SUM[6]), .CO(carry_7_) );
  XOR2X1 U5 ( .A(carry_7_), .B(A[7]), .Y(SUM[7]) );
  INVX1 U6 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module counter_pwm1 ( sw_rst, clk_b, PWM1CON, PWM1D, pwm1_en, pwm1_reload, 
        pwm1_reset, pwm1_cnt, pwm1_intr );
  input [7:0] PWM1CON;
  input [7:0] PWM1D;
  output [7:0] pwm1_cnt;
  input sw_rst, clk_b, pwm1_en;
  output pwm1_reload, pwm1_reset, pwm1_intr;
  wire   pwm1_reload_tmp, pwm1_reload_dly, N16, N17, N18, N19, N20, N21, N22,
         N23, N26, N27, N28, N29, N30, N31, N32, N33, N34, n3, n4, n5, n6, n7,
         n8, n9, n10, n11, n13, n14, n15, n160, n170, n180, n190;

  EDFFX4 pwm1_cnt_reg_6_ ( .D(N22), .CK(clk_b), .E(N26), .Q(pwm1_cnt[6]), .QN(
        n15) );
  AOI211X4 U4 ( .A0(PWM1CON[3]), .A1(n3), .B0(n4), .C0(n5), .Y(pwm1_reset) );
  AOI221X4 U6 ( .A0(PWM1D[6]), .A1(PWM1CON[3]), .B0(PWM1D[7]), .B1(PWM1CON[3]), 
        .C0(n7), .Y(n6) );
  OAI33X4 U14 ( .A0(n5), .A1(pwm1_cnt[7]), .A2(pwm1_cnt[6]), .B0(n5), .B1(
        PWM1CON[3]), .B2(PWM1CON[2]), .Y(pwm1_reload_tmp) );
  NAND2X1 I28 ( .A(n14), .B(n15), .Y(n3) );
  NAND3X1 I29 ( .A(n160), .B(n170), .C(n180), .Y(n13) );
  EDFFX1 pwm1_cnt_reg_5_ ( .D(N21), .CK(clk_b), .E(N26), .Q(pwm1_cnt[5]), .QN(
        n160) );
  EDFFX1 pwm1_cnt_reg_4_ ( .D(N20), .CK(clk_b), .E(N26), .Q(pwm1_cnt[4]), .QN(
        n170) );
  EDFFX1 pwm1_cnt_reg_3_ ( .D(N19), .CK(clk_b), .E(N26), .Q(pwm1_cnt[3]), .QN(
        n180) );
  NOR2X1 I30 ( .A(n190), .B(n11), .Y(pwm1_intr) );
  INVX1 I31 ( .A(n11), .Y(pwm1_reload) );
  OR2X2 I32 ( .A(pwm1_en), .B(n10), .Y(N26) );
  EDFFX2 pwm1_cnt_reg_7_ ( .D(N23), .CK(clk_b), .E(N26), .Q(pwm1_cnt[7]), .QN(
        n14) );
  EDFFX2 pwm1_cnt_reg_2_ ( .D(N18), .CK(clk_b), .E(N26), .Q(pwm1_cnt[2]) );
  EDFFX2 pwm1_cnt_reg_1_ ( .D(N17), .CK(clk_b), .E(N26), .Q(pwm1_cnt[1]) );
  EDFFX2 pwm1_cnt_reg_0_ ( .D(N16), .CK(clk_b), .E(N26), .Q(pwm1_cnt[0]) );
  NAND2BX1 I33 ( .AN(pwm1_reload_dly), .B(pwm1_reload_tmp), .Y(n11) );
  INVX2 I34 ( .A(n10), .Y(n9) );
  OAI2BB1X1 I35 ( .A0N(N33), .A1N(pwm1_en), .B0(n9), .Y(N22) );
  OAI2BB1X1 I36 ( .A0N(N32), .A1N(pwm1_en), .B0(n9), .Y(N21) );
  OAI2BB1X1 I37 ( .A0N(N31), .A1N(pwm1_en), .B0(n9), .Y(N20) );
  OAI2BB1X1 I38 ( .A0N(N30), .A1N(pwm1_en), .B0(n9), .Y(N19) );
  OAI2BB1X1 I39 ( .A0N(N29), .A1N(pwm1_en), .B0(n9), .Y(N18) );
  OAI2BB1X1 I40 ( .A0N(N28), .A1N(pwm1_en), .B0(n9), .Y(N17) );
  EDFFTRX1 pwm1_intr_rdy_reg ( .D(1'b1), .CK(clk_b), .E(pwm1_reload), .RN(n9), 
        .QN(n190) );
  OR2X2 I41 ( .A(pwm1_reload_dly), .B(n6), .Y(n4) );
  OR4X2 I42 ( .A(pwm1_cnt[2]), .B(pwm1_cnt[1]), .C(pwm1_cnt[0]), .D(n13), .Y(
        n5) );
  OR3X2 I43 ( .A(PWM1D[1]), .B(PWM1D[0]), .C(n8), .Y(n7) );
  OR4X2 I44 ( .A(PWM1D[3]), .B(PWM1D[2]), .C(PWM1D[5]), .D(PWM1D[4]), .Y(n8)
         );
  OR2X2 I45 ( .A(PWM1CON[1]), .B(sw_rst), .Y(n10) );
  OAI2BB1X1 I46 ( .A0N(N34), .A1N(pwm1_en), .B0(n9), .Y(N23) );
  OAI2BB1X1 I47 ( .A0N(N27), .A1N(pwm1_en), .B0(n9), .Y(N16) );
  DFFHQX1 pwm1_reload_dly_reg ( .D(pwm1_reload_tmp), .CK(clk_b), .Q(
        pwm1_reload_dly) );
  counter_pwm1_DW01_inc_8_0 add_86 ( .A(pwm1_cnt), .SUM({N34, N33, N32, N31, 
        N30, N29, N28, N27}) );
endmodule


module counter_pwm1_DW01_inc_8_0 ( A, SUM );
  input [7:0] A;
  output [7:0] SUM;
  wire   carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_;

  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(carry_5_) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  CMPR22X1 U1_1_5 ( .A(A[5]), .B(carry_5_), .S(SUM[5]), .CO(carry_6_) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_6 ( .A(A[6]), .B(carry_6_), .S(SUM[6]), .CO(carry_7_) );
  XOR2X1 U5 ( .A(carry_7_), .B(A[7]), .Y(SUM[7]) );
  INVX1 U6 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module comp_pwm2 ( sw_rst, clk_b, PWM2CON, pwm2buf, pwm2_cnt, pwm2_reset, 
        pwm2_out );
  input [7:0] PWM2CON;
  input [7:0] pwm2buf;
  input [7:0] pwm2_cnt;
  input sw_rst, clk_b, pwm2_reset;
  output pwm2_out;
  wire   N40, pwm2_ext, pwm2_out_ext, N78, N79, N80, N110, N111, N113, N114,
         N115, N116, N117, N118, N119, N137, n2, n3, n4, n5, n6, n7, n8, n9,
         n10, n11, n12, n13, n15, n16, n17, n18, n19, n20, n21, n22, n23, n26,
         n27, n28, n29, n30, n31, n32, n33, n34, n38, n39, n400, n41, n42, n43,
         n44, n46, n47, n48, n49, n50, n51, n53, n54, n55, n56, n57, n58;
  wire   [6:0] pwm2_out_cnt;

  OAI33X4 U14 ( .A0(n18), .A1(PWM2CON[5]), .A2(n15), .B0(n19), .B1(PWM2CON[6]), 
        .B2(n20), .Y(n8) );
  OAI33X4 U17 ( .A0(n23), .A1(pwm2_out_cnt[2]), .A2(PWM2CON[4]), .B0(
        PWM2CON[5]), .B1(pwm2_out_cnt[2]), .B2(pwm2_out_cnt[1]), .Y(n22) );
  OAI33X4 U42 ( .A0(n46), .A1(n47), .A2(n29), .B0(n48), .B1(n42), .B2(n29), 
        .Y(N111) );
  AOI221X4 U45 ( .A0(n51), .A1(n44), .B0(n47), .B1(n49), .C0(n29), .Y(n50) );
  NOR2X1 I54 ( .A(n53), .B(n23), .Y(n21) );
  NAND2X1 I55 ( .A(n27), .B(n54), .Y(n20) );
  NAND3BX1 I56 ( .AN(n23), .B(pwm2_out_cnt[2]), .C(pwm2_out_cnt[3]), .Y(n15)
         );
  DFFTRX1 pwm2_out_cnt_reg_1_ ( .D(N114), .CK(clk_b), .RN(n56), .Q(
        pwm2_out_cnt[1]), .QN(n23) );
  NOR3BX1 I57 ( .AN(n16), .B(n28), .C(n27), .Y(n10) );
  NOR3X1 I58 ( .A(pwm2_out_cnt[5]), .B(pwm2_out_cnt[6]), .C(n55), .Y(n7) );
  DFFTRX1 pwm2_out_cnt_reg_4_ ( .D(N117), .CK(clk_b), .RN(n56), .Q(
        pwm2_out_cnt[4]), .QN(n27) );
  NOR2X1 I59 ( .A(n2), .B(n29), .Y(N80) );
  AOI32X1 I60 ( .A0(PWM2CON[6]), .A1(pwm2_out_cnt[4]), .A2(PWM2CON[4]), .B0(
        n26), .B1(n27), .Y(n18) );
  OR2X2 I61 ( .A(sw_rst), .B(PWM2CON[1]), .Y(n29) );
  DFFTRX1 pwm2_out_cnt_reg_5_ ( .D(N118), .CK(clk_b), .RN(n56), .Q(
        pwm2_out_cnt[5]), .QN(n28) );
  DFFTRX1 pwm2_out_cnt_reg_3_ ( .D(N116), .CK(clk_b), .RN(n56), .Q(
        pwm2_out_cnt[3]), .QN(n54) );
  DFFTRX2 pwm2_out_cnt_reg_2_ ( .D(N115), .CK(clk_b), .RN(n56), .Q(
        pwm2_out_cnt[2]), .QN(n53) );
  DFFTRX1 pwm2_out_cnt_reg_0_ ( .D(N113), .CK(clk_b), .RN(n56), .Q(
        pwm2_out_cnt[0]), .QN(n55) );
  NOR2X2 I62 ( .A(N78), .B(n29), .Y(n56) );
  OR3X2 I63 ( .A(pwm2_reset), .B(n29), .C(n4), .Y(N137) );
  DFFTRX1 pwm2_out_cnt_reg_6_ ( .D(N119), .CK(clk_b), .RN(n56), .Q(
        pwm2_out_cnt[6]), .QN(n17) );
  INVX1 I64 ( .A(n29), .Y(n6) );
  AND2X2 I65 ( .A(pwm2_reset), .B(n6), .Y(N40) );
  INVX1 I66 ( .A(n15), .Y(n12) );
  OAI2BB1X1 I67 ( .A0N(n7), .A1N(n8), .B0(n9), .Y(N79) );
  AOI31X1 I68 ( .A0(n10), .A1(n11), .A2(n12), .B0(n13), .Y(n9) );
  NOR3X1 I69 ( .A(n57), .B(n58), .C(pwm2_reset), .Y(n34) );
  XOR2X1 I70 ( .A(pwm2buf[1]), .B(pwm2_cnt[1]), .Y(n57) );
  XOR2X1 I71 ( .A(pwm2buf[0]), .B(pwm2_cnt[0]), .Y(n58) );
  OAI31X1 I72 ( .A0(PWM2CON[4]), .A1(PWM2CON[6]), .A2(PWM2CON[5]), .B0(n56), 
        .Y(n13) );
  INVX1 I73 ( .A(n30), .Y(n4) );
  OAI211X1 I74 ( .A0(n31), .A1(n32), .B0(n33), .C0(n34), .Y(n30) );
  AND4X2 I75 ( .A(n38), .B(n39), .C(n400), .D(n41), .Y(n33) );
  AND3X2 I76 ( .A(pwm2buf[6]), .B(pwm2_cnt[6]), .C(n44), .Y(n31) );
  XNOR2X1 I77 ( .A(pwm2_cnt[7]), .B(pwm2buf[7]), .Y(n44) );
  INVX1 I78 ( .A(pwm2_cnt[5]), .Y(n42) );
  OR3X2 I79 ( .A(pwm2_cnt[7]), .B(pwm2_cnt[6]), .C(n42), .Y(n46) );
  XNOR2X1 I80 ( .A(pwm2buf[2]), .B(pwm2_cnt[2]), .Y(n41) );
  XNOR2X1 I81 ( .A(pwm2buf[3]), .B(pwm2_cnt[3]), .Y(n400) );
  XNOR2X1 I82 ( .A(pwm2buf[4]), .B(pwm2_cnt[4]), .Y(n39) );
  OR3X2 I83 ( .A(pwm2buf[6]), .B(pwm2_cnt[6]), .C(n49), .Y(n48) );
  AOI31X1 I84 ( .A0(PWM2CON[5]), .A1(PWM2CON[4]), .A2(n21), .B0(n22), .Y(n19)
         );
  OAI211X1 I85 ( .A0(pwm2buf[6]), .A1(n42), .B0(n46), .C0(n50), .Y(N110) );
  AND2X2 I86 ( .A(pwm2_cnt[5]), .B(pwm2_cnt[6]), .Y(n51) );
  XOR2X1 I87 ( .A(n42), .B(pwm2buf[5]), .Y(n38) );
  AND3X2 I88 ( .A(pwm2_out_cnt[0]), .B(PWM2CON[6]), .C(PWM2CON[5]), .Y(n11) );
  XOR2X1 I89 ( .A(n17), .B(PWM2CON[4]), .Y(n16) );
  OAI31X1 I90 ( .A0(n43), .A1(pwm2buf[6]), .A2(pwm2_cnt[6]), .B0(PWM2CON[3]), 
        .Y(n32) );
  INVX1 I91 ( .A(n44), .Y(n43) );
  INVX1 I92 ( .A(PWM2CON[4]), .Y(n26) );
  INVX1 I93 ( .A(pwm2buf[7]), .Y(n49) );
  INVX1 I94 ( .A(pwm2buf[6]), .Y(n47) );
  NAND2X1 I95 ( .A(n2), .B(n3), .Y(pwm2_out) );
  OAI211X1 I96 ( .A0(n4), .A1(pwm2_out_ext), .B0(pwm2_ext), .C0(n5), .Y(n3) );
  INVX1 I97 ( .A(PWM2CON[3]), .Y(n5) );
  EDFFX1 pwm2_out_reg_reg ( .D(N40), .CK(clk_b), .E(N137), .Q(N78), .QN(n2) );
  EDFFX1 pwm2_ext_reg ( .D(N111), .CK(clk_b), .E(N110), .Q(pwm2_ext) );
  EDFFX1 pwm2_out_ext_reg ( .D(N80), .CK(clk_b), .E(N79), .Q(pwm2_out_ext) );
  comp_pwm2_DW01_inc_7_0 add_205 ( .A(pwm2_out_cnt), .SUM({N119, N118, N117, 
        N116, N115, N114, N113}) );
endmodule


module comp_pwm2_DW01_inc_7_0 ( A, SUM );
  input [6:0] A;
  output [6:0] SUM;
  wire   carry_6_, carry_5_, carry_4_, carry_3_, carry_2_;

  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(carry_5_) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_5 ( .A(A[5]), .B(carry_5_), .S(SUM[5]), .CO(carry_6_) );
  XOR2X1 U5 ( .A(carry_6_), .B(A[6]), .Y(SUM[6]) );
  INVX1 U6 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module comp_pwm1 ( sw_rst, clk_b, PWM1CON, pwm1buf, pwm1_cnt, pwm1_reset, 
        pwm1_out );
  input [7:0] PWM1CON;
  input [7:0] pwm1buf;
  input [7:0] pwm1_cnt;
  input sw_rst, clk_b, pwm1_reset;
  output pwm1_out;
  wire   N40, pwm1_ext, pwm1_out_ext, N78, N79, N80, N110, N111, N113, N114,
         N115, N116, N117, N118, N119, N137, n2, n3, n4, n5, n6, n7, n8, n9,
         n10, n11, n12, n13, n15, n16, n17, n18, n19, n20, n21, n22, n23, n26,
         n27, n28, n29, n30, n31, n32, n33, n34, n38, n39, n400, n41, n42, n43,
         n44, n46, n47, n48, n49, n50, n51, n53, n54, n55, n56, n57, n58;
  wire   [6:0] pwm1_out_cnt;

  OAI33X4 U14 ( .A0(n18), .A1(PWM1CON[5]), .A2(n15), .B0(n19), .B1(PWM1CON[6]), 
        .B2(n20), .Y(n8) );
  OAI33X4 U17 ( .A0(n23), .A1(pwm1_out_cnt[2]), .A2(PWM1CON[4]), .B0(
        PWM1CON[5]), .B1(pwm1_out_cnt[2]), .B2(pwm1_out_cnt[1]), .Y(n22) );
  OAI33X4 U42 ( .A0(n46), .A1(n47), .A2(n29), .B0(n48), .B1(n42), .B2(n29), 
        .Y(N111) );
  AOI221X4 U45 ( .A0(n51), .A1(n44), .B0(n47), .B1(n49), .C0(n29), .Y(n50) );
  NOR2X1 I54 ( .A(n53), .B(n23), .Y(n21) );
  NAND2X1 I55 ( .A(n27), .B(n54), .Y(n20) );
  NAND3BX1 I56 ( .AN(n23), .B(pwm1_out_cnt[2]), .C(pwm1_out_cnt[3]), .Y(n15)
         );
  DFFTRX1 pwm1_out_cnt_reg_1_ ( .D(N114), .CK(clk_b), .RN(n56), .Q(
        pwm1_out_cnt[1]), .QN(n23) );
  NOR3BX1 I57 ( .AN(n16), .B(n28), .C(n27), .Y(n10) );
  NOR3X1 I58 ( .A(pwm1_out_cnt[5]), .B(pwm1_out_cnt[6]), .C(n55), .Y(n7) );
  DFFTRX1 pwm1_out_cnt_reg_4_ ( .D(N117), .CK(clk_b), .RN(n56), .Q(
        pwm1_out_cnt[4]), .QN(n27) );
  NOR2X1 I59 ( .A(n2), .B(n29), .Y(N80) );
  AOI32X1 I60 ( .A0(PWM1CON[6]), .A1(pwm1_out_cnt[4]), .A2(PWM1CON[4]), .B0(
        n26), .B1(n27), .Y(n18) );
  OR2X2 I61 ( .A(sw_rst), .B(PWM1CON[1]), .Y(n29) );
  DFFTRX1 pwm1_out_cnt_reg_5_ ( .D(N118), .CK(clk_b), .RN(n56), .Q(
        pwm1_out_cnt[5]), .QN(n28) );
  DFFTRX1 pwm1_out_cnt_reg_3_ ( .D(N116), .CK(clk_b), .RN(n56), .Q(
        pwm1_out_cnt[3]), .QN(n54) );
  DFFTRX2 pwm1_out_cnt_reg_2_ ( .D(N115), .CK(clk_b), .RN(n56), .Q(
        pwm1_out_cnt[2]), .QN(n53) );
  DFFTRX1 pwm1_out_cnt_reg_0_ ( .D(N113), .CK(clk_b), .RN(n56), .Q(
        pwm1_out_cnt[0]), .QN(n55) );
  NOR2X2 I62 ( .A(N78), .B(n29), .Y(n56) );
  OR3X2 I63 ( .A(pwm1_reset), .B(n29), .C(n4), .Y(N137) );
  DFFTRX1 pwm1_out_cnt_reg_6_ ( .D(N119), .CK(clk_b), .RN(n56), .Q(
        pwm1_out_cnt[6]), .QN(n17) );
  INVX1 I64 ( .A(n29), .Y(n6) );
  AND2X2 I65 ( .A(pwm1_reset), .B(n6), .Y(N40) );
  INVX1 I66 ( .A(n15), .Y(n12) );
  OAI2BB1X1 I67 ( .A0N(n7), .A1N(n8), .B0(n9), .Y(N79) );
  AOI31X1 I68 ( .A0(n10), .A1(n11), .A2(n12), .B0(n13), .Y(n9) );
  NOR3X1 I69 ( .A(n57), .B(n58), .C(pwm1_reset), .Y(n34) );
  XOR2X1 I70 ( .A(pwm1buf[1]), .B(pwm1_cnt[1]), .Y(n57) );
  XOR2X1 I71 ( .A(pwm1buf[0]), .B(pwm1_cnt[0]), .Y(n58) );
  OAI31X1 I72 ( .A0(PWM1CON[4]), .A1(PWM1CON[6]), .A2(PWM1CON[5]), .B0(n56), 
        .Y(n13) );
  INVX1 I73 ( .A(n30), .Y(n4) );
  OAI211X1 I74 ( .A0(n31), .A1(n32), .B0(n33), .C0(n34), .Y(n30) );
  AND4X2 I75 ( .A(n38), .B(n39), .C(n400), .D(n41), .Y(n33) );
  AND3X2 I76 ( .A(pwm1buf[6]), .B(pwm1_cnt[6]), .C(n44), .Y(n31) );
  XNOR2X1 I77 ( .A(pwm1_cnt[7]), .B(pwm1buf[7]), .Y(n44) );
  INVX1 I78 ( .A(pwm1_cnt[5]), .Y(n42) );
  OR3X2 I79 ( .A(pwm1_cnt[7]), .B(pwm1_cnt[6]), .C(n42), .Y(n46) );
  XNOR2X1 I80 ( .A(pwm1buf[2]), .B(pwm1_cnt[2]), .Y(n41) );
  XNOR2X1 I81 ( .A(pwm1buf[3]), .B(pwm1_cnt[3]), .Y(n400) );
  XNOR2X1 I82 ( .A(pwm1buf[4]), .B(pwm1_cnt[4]), .Y(n39) );
  OR3X2 I83 ( .A(pwm1buf[6]), .B(pwm1_cnt[6]), .C(n49), .Y(n48) );
  AOI31X1 I84 ( .A0(PWM1CON[5]), .A1(PWM1CON[4]), .A2(n21), .B0(n22), .Y(n19)
         );
  OAI211X1 I85 ( .A0(pwm1buf[6]), .A1(n42), .B0(n46), .C0(n50), .Y(N110) );
  AND2X2 I86 ( .A(pwm1_cnt[5]), .B(pwm1_cnt[6]), .Y(n51) );
  XOR2X1 I87 ( .A(n42), .B(pwm1buf[5]), .Y(n38) );
  AND3X2 I88 ( .A(pwm1_out_cnt[0]), .B(PWM1CON[6]), .C(PWM1CON[5]), .Y(n11) );
  XOR2X1 I89 ( .A(n17), .B(PWM1CON[4]), .Y(n16) );
  OAI31X1 I90 ( .A0(n43), .A1(pwm1buf[6]), .A2(pwm1_cnt[6]), .B0(PWM1CON[3]), 
        .Y(n32) );
  INVX1 I91 ( .A(n44), .Y(n43) );
  INVX1 I92 ( .A(PWM1CON[4]), .Y(n26) );
  INVX1 I93 ( .A(pwm1buf[7]), .Y(n49) );
  INVX1 I94 ( .A(pwm1buf[6]), .Y(n47) );
  NAND2X1 I95 ( .A(n2), .B(n3), .Y(pwm1_out) );
  OAI211X1 I96 ( .A0(n4), .A1(pwm1_out_ext), .B0(pwm1_ext), .C0(n5), .Y(n3) );
  INVX1 I97 ( .A(PWM1CON[3]), .Y(n5) );
  EDFFX1 pwm1_out_reg_reg ( .D(N40), .CK(clk_b), .E(N137), .Q(N78), .QN(n2) );
  EDFFX1 pwm1_ext_reg ( .D(N111), .CK(clk_b), .E(N110), .Q(pwm1_ext) );
  EDFFX1 pwm1_out_ext_reg ( .D(N80), .CK(clk_b), .E(N79), .Q(pwm1_out_ext) );
  comp_pwm1_DW01_inc_7_0 add_90 ( .A(pwm1_out_cnt), .SUM({N119, N118, N117, 
        N116, N115, N114, N113}) );
endmodule


module comp_pwm1_DW01_inc_7_0 ( A, SUM );
  input [6:0] A;
  output [6:0] SUM;
  wire   carry_6_, carry_5_, carry_4_, carry_3_, carry_2_;

  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(carry_5_) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_5 ( .A(A[5]), .B(carry_5_), .S(SUM[5]), .CO(carry_6_) );
  XOR2X1 U5 ( .A(carry_6_), .B(A[6]), .Y(SUM[6]) );
  INVX1 U6 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module buf_pwm2 ( sw_rst, clk_b, pwm2_clear, PWM2D, pwm2_reload, pwm2buf );
  input [7:0] PWM2D;
  output [7:0] pwm2buf;
  input sw_rst, clk_b, pwm2_clear, pwm2_reload;
  wire   N2, N3, N4, N5, N6, N7, N8, N9, N12, n40, n60, n70;

  EDFFX1 pwm2buf_reg_7_ ( .D(N9), .CK(clk_b), .E(N12), .Q(pwm2buf[7]) );
  EDFFX2 pwm2buf_reg_6_ ( .D(N8), .CK(clk_b), .E(N12), .Q(pwm2buf[6]) );
  AND3X2 I15 ( .A(n40), .B(n70), .C(pwm2_reload), .Y(n60) );
  EDFFX1 pwm2buf_reg_5_ ( .D(N7), .CK(clk_b), .E(N12), .Q(pwm2buf[5]) );
  OR3X2 I16 ( .A(sw_rst), .B(pwm2_clear), .C(n60), .Y(N12) );
  INVX1 I17 ( .A(pwm2_clear), .Y(n40) );
  INVX1 I18 ( .A(sw_rst), .Y(n70) );
  AND2X2 I19 ( .A(PWM2D[7]), .B(n60), .Y(N9) );
  AND2X2 I20 ( .A(PWM2D[6]), .B(n60), .Y(N8) );
  AND2X2 I21 ( .A(PWM2D[5]), .B(n60), .Y(N7) );
  AND2X2 I22 ( .A(PWM2D[4]), .B(n60), .Y(N6) );
  AND2X2 I23 ( .A(PWM2D[3]), .B(n60), .Y(N5) );
  AND2X2 I24 ( .A(PWM2D[2]), .B(n60), .Y(N4) );
  AND2X2 I25 ( .A(PWM2D[1]), .B(n60), .Y(N3) );
  AND2X2 I26 ( .A(PWM2D[0]), .B(n60), .Y(N2) );
  EDFFX1 pwm2buf_reg_4_ ( .D(N6), .CK(clk_b), .E(N12), .Q(pwm2buf[4]) );
  EDFFX1 pwm2buf_reg_3_ ( .D(N5), .CK(clk_b), .E(N12), .Q(pwm2buf[3]) );
  EDFFX1 pwm2buf_reg_2_ ( .D(N4), .CK(clk_b), .E(N12), .Q(pwm2buf[2]) );
  EDFFX1 pwm2buf_reg_1_ ( .D(N3), .CK(clk_b), .E(N12), .Q(pwm2buf[1]) );
  EDFFX1 pwm2buf_reg_0_ ( .D(N2), .CK(clk_b), .E(N12), .Q(pwm2buf[0]) );
endmodule


module buf_pwm1 ( sw_rst, clk_b, pwm1_clear, PWM1D, pwm1_reload, pwm1buf );
  input [7:0] PWM1D;
  output [7:0] pwm1buf;
  input sw_rst, clk_b, pwm1_clear, pwm1_reload;
  wire   N2, N3, N4, N5, N6, N7, N8, N9, N12, n40, n60, n70;

  EDFFX1 pwm1buf_reg_7_ ( .D(N9), .CK(clk_b), .E(N12), .Q(pwm1buf[7]) );
  EDFFX2 pwm1buf_reg_6_ ( .D(N8), .CK(clk_b), .E(N12), .Q(pwm1buf[6]) );
  AND3X2 I15 ( .A(n40), .B(n70), .C(pwm1_reload), .Y(n60) );
  EDFFX1 pwm1buf_reg_5_ ( .D(N7), .CK(clk_b), .E(N12), .Q(pwm1buf[5]) );
  OR3X2 I16 ( .A(sw_rst), .B(pwm1_clear), .C(n60), .Y(N12) );
  INVX1 I17 ( .A(pwm1_clear), .Y(n40) );
  INVX1 I18 ( .A(sw_rst), .Y(n70) );
  AND2X2 I19 ( .A(PWM1D[7]), .B(n60), .Y(N9) );
  AND2X2 I20 ( .A(PWM1D[6]), .B(n60), .Y(N8) );
  AND2X2 I21 ( .A(PWM1D[5]), .B(n60), .Y(N7) );
  AND2X2 I22 ( .A(PWM1D[4]), .B(n60), .Y(N6) );
  AND2X2 I23 ( .A(PWM1D[3]), .B(n60), .Y(N5) );
  AND2X2 I24 ( .A(PWM1D[2]), .B(n60), .Y(N4) );
  AND2X2 I25 ( .A(PWM1D[1]), .B(n60), .Y(N3) );
  AND2X2 I26 ( .A(PWM1D[0]), .B(n60), .Y(N2) );
  EDFFX1 pwm1buf_reg_4_ ( .D(N6), .CK(clk_b), .E(N12), .Q(pwm1buf[4]) );
  EDFFX1 pwm1buf_reg_3_ ( .D(N5), .CK(clk_b), .E(N12), .Q(pwm1buf[3]) );
  EDFFX1 pwm1buf_reg_2_ ( .D(N4), .CK(clk_b), .E(N12), .Q(pwm1buf[2]) );
  EDFFX1 pwm1buf_reg_1_ ( .D(N3), .CK(clk_b), .E(N12), .Q(pwm1buf[1]) );
  EDFFX1 pwm1buf_reg_0_ ( .D(N2), .CK(clk_b), .E(N12), .Q(pwm1buf[0]) );
endmodule


module sfr_pwm ( PWM1_SEL, PWM2_SEL, sw_rst, clk_b, SFR_wr, PWM1CON_sel, 
        PWM2CON_sel, PWM1D_sel, PWM2D_sel, SFR_bus, PWM_SFR_OUT, PWM1CON, 
        PWM2CON, PWM1D, PWM2D );
  input [7:0] SFR_bus;
  output [7:0] PWM_SFR_OUT;
  output [7:0] PWM1CON;
  output [7:0] PWM2CON;
  output [7:0] PWM1D;
  output [7:0] PWM2D;
  input sw_rst, clk_b, SFR_wr, PWM1CON_sel, PWM2CON_sel, PWM1D_sel, PWM2D_sel;
  output PWM1_SEL, PWM2_SEL;
  wire   n78, n79, N16, N17, N18, N19, N20, N21, N22, N28, N29, N30, N31, N32,
         N33, N34, N39, N40, N41, N42, N43, N44, N45, N46, N48, N49, N50, N51,
         N52, N53, N54, N55, N57, N58, N62, N66, n2, n3, n4, n5, n8, n9, n10,
         n11, n12, n13, n14, n15, n160, n170, n180, n190, n200, n210, n220,
         n23, n24, n25, n26, n27, n280, n290, n300, n310, n320, n330, n340,
         n35, n36, n37, n390, n410, n420, n480, n530, n540, n550, n56, n570,
         n580, n59, n60, n61, n620, n63, n64, n65, n660, n67, n68, n69, n70,
         n71, n76, n77;

  EDFFX4 PWM2CON_reg_4_ ( .D(N31), .CK(clk_b), .E(N66), .Q(PWM2CON[4]) );
  EDFFX4 PWM2CON_reg_5_ ( .D(N32), .CK(clk_b), .E(N66), .Q(PWM2CON[5]), .QN(
        n550) );
  EDFFX4 PWM1CON_reg_4_ ( .D(N19), .CK(clk_b), .E(N62), .Q(PWM1CON[4]) );
  EDFFX4 PWM1CON_reg_5_ ( .D(N20), .CK(clk_b), .E(N62), .Q(PWM1CON[5]) );
  NOR2X1 I93 ( .A(n530), .B(n65), .Y(n36) );
  NOR2X1 I94 ( .A(n540), .B(n65), .Y(n190) );
  NOR2X1 I95 ( .A(n550), .B(n290), .Y(n13) );
  NOR2X1 I96 ( .A(n56), .B(n65), .Y(n4) );
  NOR2X1 I97 ( .A(n570), .B(n290), .Y(n210) );
  NOR2X1 I98 ( .A(n580), .B(n65), .Y(n11) );
  NOR2X1 I99 ( .A(n59), .B(n65), .Y(n15) );
  NOR2X1 I100 ( .A(n60), .B(n290), .Y(n25) );
  NOR2X1 I101 ( .A(n61), .B(n65), .Y(n23) );
  NOR2X1 I102 ( .A(n620), .B(n65), .Y(n27) );
  DFFTRX1 PWM2CON_reg_1_ ( .D(SFR_bus[1]), .CK(clk_b), .RN(n68), .Q(PWM2CON[1]), .QN(n300) );
  EDFFX2 PWM1CON_reg_6_ ( .D(N21), .CK(clk_b), .E(N62), .Q(PWM1CON[6]) );
  EDFFX2 PWM1CON_reg_3_ ( .D(N18), .CK(clk_b), .E(N62), .Q(PWM1CON[3]) );
  EDFFX2 PWM2CON_reg_6_ ( .D(N33), .CK(clk_b), .E(N66), .Q(PWM2CON[6]) );
  EDFFX2 PWM2CON_reg_3_ ( .D(N30), .CK(clk_b), .E(N66), .Q(PWM2CON[3]), .QN(
        n570) );
  NOR2X2 I103 ( .A(n390), .B(n480), .Y(n70) );
  INVX2 I104 ( .A(PWM1D_sel), .Y(n390) );
  NOR2X2 I105 ( .A(n420), .B(n480), .Y(n68) );
  NOR3X4 I106 ( .A(PWM2CON_sel), .B(PWM1CON_sel), .C(n390), .Y(n67) );
  NOR2X2 I107 ( .A(n410), .B(n480), .Y(n71) );
  INVX1 I108 ( .A(PWM2D_sel), .Y(n410) );
  NOR2X2 I109 ( .A(n310), .B(n480), .Y(n69) );
  NAND2X2 I110 ( .A(SFR_wr), .B(n77), .Y(n480) );
  OR4X2 I111 ( .A(PWM1CON_sel), .B(n410), .C(PWM2CON_sel), .D(PWM1D_sel), .Y(
        n65) );
  INVX1 I112 ( .A(n65), .Y(n660) );
  AND2X1 I113 ( .A(SFR_bus[6]), .B(n69), .Y(N21) );
  AND2X1 I114 ( .A(SFR_bus[5]), .B(n69), .Y(N20) );
  AND2X1 I115 ( .A(SFR_bus[4]), .B(n69), .Y(N19) );
  AND2X1 I116 ( .A(SFR_bus[3]), .B(n69), .Y(N18) );
  AND2X1 I117 ( .A(SFR_bus[6]), .B(n68), .Y(N33) );
  AND2X1 I118 ( .A(SFR_bus[5]), .B(n68), .Y(N32) );
  AND2X1 I119 ( .A(SFR_bus[4]), .B(n68), .Y(N31) );
  AND2X1 I120 ( .A(SFR_bus[3]), .B(n68), .Y(N30) );
  AND2X1 I121 ( .A(n70), .B(SFR_bus[7]), .Y(N46) );
  AND2X1 I122 ( .A(n70), .B(SFR_bus[6]), .Y(N45) );
  AND2X1 I123 ( .A(n70), .B(SFR_bus[5]), .Y(N44) );
  AND2X1 I124 ( .A(n70), .B(SFR_bus[4]), .Y(N43) );
  AND2X1 I125 ( .A(n70), .B(SFR_bus[3]), .Y(N42) );
  AND2X1 I126 ( .A(n70), .B(SFR_bus[2]), .Y(N41) );
  AND2X1 I127 ( .A(SFR_bus[7]), .B(n69), .Y(N22) );
  AND2X1 I128 ( .A(SFR_bus[2]), .B(n69), .Y(N17) );
  AND2X1 I129 ( .A(SFR_bus[7]), .B(n68), .Y(N34) );
  AND2X1 I130 ( .A(SFR_bus[2]), .B(n68), .Y(N29) );
  INVX1 I131 ( .A(n290), .Y(n8) );
  INVX1 I132 ( .A(n77), .Y(n76) );
  OR2X1 I133 ( .A(PWM1CON_sel), .B(n420), .Y(n290) );
  AND2X1 I134 ( .A(PWM1CON[0]), .B(PWM1CON_sel), .Y(n35) );
  AND2X1 I135 ( .A(n78), .B(PWM1CON_sel), .Y(n3) );
  AND2X1 I136 ( .A(PWM1D[7]), .B(n67), .Y(n5) );
  AND2X1 I137 ( .A(n79), .B(n8), .Y(n2) );
  AND2X1 I138 ( .A(PWM1CON[5]), .B(PWM1CON_sel), .Y(n14) );
  AND2X1 I139 ( .A(PWM1CON[3]), .B(PWM1CON_sel), .Y(n220) );
  AND2X1 I140 ( .A(PWM1CON[6]), .B(PWM1CON_sel), .Y(n10) );
  AND2X1 I141 ( .A(PWM1CON[2]), .B(PWM1CON_sel), .Y(n26) );
  AND2X1 I142 ( .A(PWM1CON[4]), .B(PWM1CON_sel), .Y(n180) );
  AND2X1 I143 ( .A(PWM1D[6]), .B(n67), .Y(n12) );
  AND2X1 I144 ( .A(PWM1D[5]), .B(n67), .Y(n160) );
  AND2X1 I145 ( .A(PWM1D[3]), .B(n67), .Y(n24) );
  AND2X1 I146 ( .A(PWM1D[2]), .B(n67), .Y(n280) );
  AND2X1 I147 ( .A(PWM1D[4]), .B(n67), .Y(n200) );
  AND2X1 I148 ( .A(PWM2CON[6]), .B(n8), .Y(n9) );
  AND2X1 I149 ( .A(PWM2CON[4]), .B(n8), .Y(n170) );
  OR2X2 I150 ( .A(n70), .B(n76), .Y(N57) );
  OR2X2 I151 ( .A(n69), .B(n76), .Y(N62) );
  OR2X2 I152 ( .A(n68), .B(n76), .Y(N66) );
  INVX1 I153 ( .A(PWM2CON_sel), .Y(n420) );
  INVX1 I154 ( .A(PWM1CON_sel), .Y(n310) );
  EDFFX1 PWM2D_reg_1_ ( .D(N49), .CK(clk_b), .E(N58), .Q(PWM2D[1]) );
  EDFFX1 PWM1D_reg_1_ ( .D(N40), .CK(clk_b), .E(N57), .Q(PWM1D[1]) );
  EDFFX1 PWM1D_reg_0_ ( .D(N39), .CK(clk_b), .E(N57), .Q(PWM1D[0]) );
  EDFFX1 PWM2D_reg_0_ ( .D(N48), .CK(clk_b), .E(N58), .Q(PWM2D[0]), .QN(n530)
         );
  EDFFX1 PWM1D_reg_4_ ( .D(N43), .CK(clk_b), .E(N57), .Q(PWM1D[4]) );
  EDFFX1 PWM2D_reg_4_ ( .D(N52), .CK(clk_b), .E(N58), .Q(PWM2D[4]), .QN(n540)
         );
  EDFFX1 PWM1D_reg_5_ ( .D(N44), .CK(clk_b), .E(N57), .Q(PWM1D[5]) );
  EDFFX1 PWM2D_reg_5_ ( .D(N53), .CK(clk_b), .E(N58), .Q(PWM2D[5]), .QN(n59)
         );
  EDFFX1 PWM1D_reg_2_ ( .D(N41), .CK(clk_b), .E(N57), .Q(PWM1D[2]) );
  EDFFX1 PWM2D_reg_2_ ( .D(N50), .CK(clk_b), .E(N58), .Q(PWM2D[2]), .QN(n620)
         );
  EDFFX1 PWM1D_reg_3_ ( .D(N42), .CK(clk_b), .E(N57), .Q(PWM1D[3]) );
  EDFFX1 PWM2D_reg_3_ ( .D(N51), .CK(clk_b), .E(N58), .Q(PWM2D[3]), .QN(n61)
         );
  OR2X2 I155 ( .A(n71), .B(n76), .Y(N58) );
  INVX1 I156 ( .A(sw_rst), .Y(n77) );
  AND2X1 I157 ( .A(SFR_bus[3]), .B(n71), .Y(N51) );
  AND2X1 I158 ( .A(SFR_bus[7]), .B(n71), .Y(N55) );
  AND2X1 I159 ( .A(SFR_bus[6]), .B(n71), .Y(N54) );
  AND2X1 I160 ( .A(SFR_bus[5]), .B(n71), .Y(N53) );
  AND2X1 I161 ( .A(SFR_bus[4]), .B(n71), .Y(N52) );
  AND2X1 I162 ( .A(SFR_bus[2]), .B(n71), .Y(N50) );
  INVX1 I163 ( .A(n63), .Y(PWM2_SEL) );
  INVX1 I164 ( .A(n63), .Y(PWM2CON[7]) );
  INVX1 I165 ( .A(n64), .Y(PWM1_SEL) );
  INVX1 I166 ( .A(n64), .Y(PWM1CON[7]) );
  OAI221X4 I167 ( .A0(n290), .A1(n300), .B0(n310), .B1(n320), .C0(n330), .Y(
        PWM_SFR_OUT[1]) );
  AOI22X1 I168 ( .A0(PWM2D[1]), .A1(n660), .B0(PWM1D[1]), .B1(n67), .Y(n330)
         );
  OR4X2 I169 ( .A(n340), .B(n35), .C(n36), .D(n37), .Y(PWM_SFR_OUT[0]) );
  AND2X2 I170 ( .A(PWM2CON[0]), .B(n8), .Y(n340) );
  AND2X2 I171 ( .A(PWM1D[0]), .B(n67), .Y(n37) );
  OR4X2 I172 ( .A(n2), .B(n3), .C(n4), .D(n5), .Y(PWM_SFR_OUT[7]) );
  OR4X2 I173 ( .A(n210), .B(n220), .C(n23), .D(n24), .Y(PWM_SFR_OUT[3]) );
  OR4X2 I174 ( .A(n13), .B(n14), .C(n15), .D(n160), .Y(PWM_SFR_OUT[5]) );
  OR4X2 I175 ( .A(n25), .B(n26), .C(n27), .D(n280), .Y(PWM_SFR_OUT[2]) );
  OR4X2 I176 ( .A(n170), .B(n180), .C(n190), .D(n200), .Y(PWM_SFR_OUT[4]) );
  OR4X2 I177 ( .A(n9), .B(n10), .C(n11), .D(n12), .Y(PWM_SFR_OUT[6]) );
  EDFFX1 PWM1CON_reg_0_ ( .D(N16), .CK(clk_b), .E(N62), .Q(PWM1CON[0]) );
  EDFFX1 PWM2CON_reg_0_ ( .D(N28), .CK(clk_b), .E(N66), .Q(PWM2CON[0]) );
  EDFFX1 PWM1D_reg_7_ ( .D(N46), .CK(clk_b), .E(N57), .Q(PWM1D[7]) );
  EDFFX1 PWM1CON_reg_7_ ( .D(N22), .CK(clk_b), .E(N62), .Q(n78), .QN(n64) );
  EDFFX1 PWM2CON_reg_7_ ( .D(N34), .CK(clk_b), .E(N66), .Q(n79), .QN(n63) );
  EDFFX1 PWM1D_reg_6_ ( .D(N45), .CK(clk_b), .E(N57), .Q(PWM1D[6]) );
  EDFFX1 PWM2D_reg_6_ ( .D(N54), .CK(clk_b), .E(N58), .Q(PWM2D[6]), .QN(n580)
         );
  EDFFX1 PWM2D_reg_7_ ( .D(N55), .CK(clk_b), .E(N58), .Q(PWM2D[7]), .QN(n56)
         );
  EDFFX1 PWM1CON_reg_2_ ( .D(N17), .CK(clk_b), .E(N62), .Q(PWM1CON[2]) );
  EDFFX1 PWM2CON_reg_2_ ( .D(N29), .CK(clk_b), .E(N66), .Q(PWM2CON[2]), .QN(
        n60) );
  AND2X1 I178 ( .A(n71), .B(SFR_bus[1]), .Y(N49) );
  AND2X1 I179 ( .A(n70), .B(SFR_bus[1]), .Y(N40) );
  AND2X1 I180 ( .A(SFR_bus[0]), .B(n71), .Y(N48) );
  AND2X1 I181 ( .A(n70), .B(SFR_bus[0]), .Y(N39) );
  AND2X1 I182 ( .A(SFR_bus[0]), .B(n68), .Y(N28) );
  AND2X1 I183 ( .A(SFR_bus[0]), .B(n69), .Y(N16) );
  DFFTRX1 PWM1CON_reg_1_ ( .D(n69), .CK(clk_b), .RN(SFR_bus[1]), .Q(PWM1CON[1]), .QN(n320) );
endmodule


module power_control ( STOPwake_WDT, POR, sw_rst, clk, RST_pin, interrupt_ack, 
        STOPwake_INT0, STOPwake_INT1, SFR_wr, SFR_bus, PCON_sel, SMOD1_update, 
        SMOD1, SMOD0, PCON, pre_idle, pre_pdwn, pre_pdwn_idle );
  input [7:0] SFR_bus;
  output [7:0] PCON;
  input STOPwake_WDT, POR, sw_rst, clk, RST_pin, interrupt_ack, STOPwake_INT0,
         STOPwake_INT1, SFR_wr, PCON_sel;
  output SMOD1_update, SMOD1, SMOD0, pre_idle, pre_pdwn, pre_pdwn_idle;
  wire   SFR_wr_PCON, n5, n6, n8, n9, n10, n11, n12, n13, n17, n18, n20, n21,
         n22, n23, n24, n26, n28, n29, n30, n31, n32;

  OAI32X4 U11 ( .A0(n5), .A1(STOPwake_INT0), .A2(n6), .B0(PCON[1]), .B1(n5), 
        .Y(n8) );
  AND2X2 I23 ( .A(n30), .B(PCON[0]), .Y(n22) );
  NOR2BX1 I24 ( .AN(n30), .B(n29), .Y(n20) );
  OAI211X1 I25 ( .A0(pre_pdwn), .A1(n20), .B0(n28), .C0(n11), .Y(n21) );
  INVX1 I26 ( .A(n21), .Y(n12) );
  OAI211X1 I27 ( .A0(pre_idle), .A1(n22), .B0(n28), .C0(n11), .Y(n23) );
  INVX1 I28 ( .A(n23), .Y(n13) );
  INVX2 I29 ( .A(SFR_bus[1]), .Y(n31) );
  NOR2X2 I30 ( .A(n30), .B(n31), .Y(pre_pdwn) );
  DFFRX1 PCON_reg_1_ ( .D(n12), .CK(clk), .RN(n8), .Q(PCON[1]), .QN(n29) );
  DFFRX1 PCON_reg_0_ ( .D(n13), .CK(clk), .RN(n9), .Q(PCON[0]) );
  INVX1 I31 ( .A(n24), .Y(SMOD0) );
  INVX1 I32 ( .A(n26), .Y(SMOD1) );
  INVX1 I33 ( .A(n32), .Y(pre_idle) );
  INVX1 I34 ( .A(interrupt_ack), .Y(n11) );
  INVX2 I35 ( .A(n30), .Y(SFR_wr_PCON) );
  EDFFTRX1 PCON_reg_7_ ( .D(SMOD1_update), .CK(clk), .E(SFR_wr_PCON), .RN(n28), 
        .Q(PCON[7]) );
  NAND2BX2 I36 ( .AN(n30), .B(SFR_bus[0]), .Y(n32) );
  AND2X2 I37 ( .A(SFR_bus[7]), .B(SFR_wr_PCON), .Y(SMOD1_update) );
  EDFFTRX1 PCON_reg_6_ ( .D(SFR_bus[6]), .CK(clk), .E(SFR_wr_PCON), .RN(n28), 
        .Q(PCON[6]) );
  INVX2 I38 ( .A(sw_rst), .Y(n28) );
  INVX1 I39 ( .A(n5), .Y(n9) );
  OAI2BB2X1 I40 ( .A0N(SFR_bus[4]), .A1N(SFR_wr_PCON), .B0(SFR_wr_PCON), .B1(
        n17), .Y(n18) );
  INVX1 I41 ( .A(PCON[6]), .Y(n24) );
  INVX1 I42 ( .A(PCON[7]), .Y(n26) );
  OR2X2 I43 ( .A(RST_pin), .B(POR), .Y(n5) );
  OR2X2 I44 ( .A(STOPwake_WDT), .B(STOPwake_INT1), .Y(n6) );
  INVX1 I45 ( .A(POR), .Y(n10) );
  DFFSX1 PCON_reg_4_ ( .D(n18), .CK(clk), .SN(n10), .Q(PCON[4]), .QN(n17) );
  EDFFTRX1 PCON_reg_5_ ( .D(SFR_bus[5]), .CK(clk), .E(SFR_wr_PCON), .RN(n28), 
        .Q(PCON[5]) );
  EDFFTRX1 PCON_reg_3_ ( .D(SFR_bus[3]), .CK(clk), .E(SFR_wr_PCON), .RN(n28), 
        .Q(PCON[3]) );
  EDFFTRX1 PCON_reg_2_ ( .D(SFR_bus[2]), .CK(clk), .E(SFR_wr_PCON), .RN(n28), 
        .Q(PCON[2]) );
  OAI21X4 I46 ( .A0(n30), .A1(n31), .B0(n32), .Y(pre_pdwn_idle) );
  NAND2X4 I47 ( .A(SFR_wr), .B(PCON_sel), .Y(n30) );
endmodule


module uart ( POR, Z_update, sw_rst, clk_b, pr_st, SFR_wr, SFR_bus, SCON_sel, 
        SBUF_sel, SADDR_sel, SADEN_sel, pin_RXD, SMOD1_update, SMOD1, SMOD0, 
        T1_overflow, T2_uart_clk, TCLK, RCLK, ua_intr, Mode0_data_RXD, 
        Uart_TXD, UART_SFR_OUT );
  input [2:0] pr_st;
  input [7:0] SFR_bus;
  output [7:0] UART_SFR_OUT;
  input POR, Z_update, sw_rst, clk_b, SFR_wr, SCON_sel, SBUF_sel, SADDR_sel,
         SADEN_sel, pin_RXD, SMOD1_update, SMOD1, SMOD0, T1_overflow,
         T2_uart_clk, TCLK, RCLK;
  output ua_intr, Mode0_data_RXD, Uart_TXD;
  wire   RX_clk, TX_clk, TX_shift_bit, TX_shift, RX_shift_bit, RX_shift,
         chosen_RX_bit, set_TI, set_RI, set_FE, now_TX_bit, Uart_mode0,
         Uart_mode1, Uart_mode2, Uart_mode3, SM2, REN, TB8, RI, SADDR_match,
         SFR_wr_SBUF, mode0_TX_ing, mode0_RX_ing;

  uart_sfr uart_sfr ( .POR(POR), .sw_rst(sw_rst), .clk_b(clk_b), .pr_st(pr_st), 
        .SFR_wr(SFR_wr), .SFR_bus(SFR_bus), .SCON_sel(SCON_sel), .SBUF_sel(
        SBUF_sel), .SADEN_sel(SADEN_sel), .SADDR_sel(SADDR_sel), .Uart_mode0(
        Uart_mode0), .Uart_mode1(Uart_mode1), .Uart_mode2(Uart_mode2), 
        .Uart_mode3(Uart_mode3), .SMOD1_update(SMOD1_update), .SMOD1(SMOD1), 
        .SMOD0(SMOD0), .T1_overflow(T1_overflow), .T2_uart_clk(T2_uart_clk), 
        .TCLK(TCLK), .RCLK(RCLK), .RX_clk(RX_clk), .TX_clk(TX_clk), 
        .now_TX_bit(now_TX_bit), .TX_shift_bit(TX_shift_bit), .TX_shift(
        TX_shift), .RX_shift_bit(RX_shift_bit), .chosen_RX_bit(chosen_RX_bit), 
        .RX_shift(RX_shift), .set_TI(set_TI), .set_RI(set_RI), .set_FE(set_FE), 
        .SM2(SM2), .REN(REN), .TB8(TB8), .RI(RI), .ua_intr(ua_intr), 
        .SADDR_match(SADDR_match), .SFR_wr_SBUF(SFR_wr_SBUF), .UART_SFR_OUT(
        UART_SFR_OUT) );
  RX RX ( .POR(POR), .Z_update(Z_update), .sw_rst(sw_rst), .clk_b(clk_b), 
        .pr_st(pr_st), .mode0_TX_ing(mode0_TX_ing), .now_TX_bit(now_TX_bit), 
        .SM2(SM2), .REN(REN), .RI(RI), .pin_RXD(pin_RXD), .SADDR_match(
        SADDR_match), .RX_clk(RX_clk), .Uart_mode0(Uart_mode0), .Uart_mode1(
        Uart_mode1), .Uart_mode2(Uart_mode2), .Uart_mode3(Uart_mode3), 
        .RX_shift_bit(RX_shift_bit), .chosen_RX_bit(chosen_RX_bit), 
        .mode0_RX_ing(mode0_RX_ing), .RX_shift(RX_shift), .set_RI(set_RI), 
        .set_FE(set_FE), .Mode0_data_RXD(Mode0_data_RXD) );
  TX TX ( .POR(POR), .Z_update(Z_update), .sw_rst(sw_rst), .clk_b(clk_b), 
        .pr_st(pr_st), .now_TX_bit(now_TX_bit), .mode0_RX_ing(mode0_RX_ing), 
        .TB8(TB8), .SFR_wr_SBUF(SFR_wr_SBUF), .TX_clk(TX_clk), .Uart_mode0(
        Uart_mode0), .Uart_mode1(Uart_mode1), .Uart_mode2(Uart_mode2), 
        .Uart_mode3(Uart_mode3), .mode0_TX_ing(mode0_TX_ing), .TX_shift_bit(
        TX_shift_bit), .TX_shift(TX_shift), .set_TI(set_TI), .Uart_TXD(
        Uart_TXD) );
endmodule


module TX ( POR, Z_update, sw_rst, clk_b, pr_st, now_TX_bit, mode0_RX_ing, TB8, 
        SFR_wr_SBUF, TX_clk, Uart_mode0, Uart_mode1, Uart_mode2, Uart_mode3, 
        mode0_TX_ing, TX_shift_bit, TX_shift, set_TI, Uart_TXD );
  input [2:0] pr_st;
  input POR, Z_update, sw_rst, clk_b, now_TX_bit, mode0_RX_ing, TB8,
         SFR_wr_SBUF, TX_clk, Uart_mode0, Uart_mode1, Uart_mode2, Uart_mode3;
  output mode0_TX_ing, TX_shift_bit, TX_shift, set_TI, Uart_TXD;
  wire   TX_step_one, N19, TX_start, mode123_TX_ing, mode0_shift_clk,
         TX_div16_carry, N74, N76, n8, n11, n14, n16, n17, n18, n190, n20, n22,
         n23, n24, n25, n26, n27, n28, n29, n31, n32, n34, n35, n36, n37, n38,
         n40, n41, n42, n43, n44, n45, n46, n47, n48, n49, n51, n52, n53, n54,
         n55, n56, n57, n58, n59, n60, n61, n62, n63, n64, n65, n66, n67, n68,
         n69, n70, n71, n72, n73, n740, n75, n760, n77, n78, n79, n80, n81,
         n82, n83, n84, n85, n86;
  wire   [3:0] TX_div16;
  wire   [3:0] state_TX;
  wire   [3:0] TX_div16_inc;

  OAI222X4 U9 ( .A0(n11), .A1(n760), .B0(n11), .B1(n79), .C0(n8), .C1(n14), 
        .Y(n73) );
  OAI31X4 U16 ( .A0(n20), .A1(mode0_TX_ing), .A2(TX_start), .B0(TX_step_one), 
        .Y(n190) );
  OAI211X4 U22 ( .A0(n23), .A1(n78), .B0(n24), .C0(n25), .Y(n17) );
  AOI221X4 U23 ( .A0(n26), .A1(n27), .B0(state_TX[0]), .B1(n28), .C0(
        state_TX[2]), .Y(n25) );
  OAI211X4 U29 ( .A0(Uart_mode3), .A1(Uart_mode2), .B0(state_TX[1]), .C0(n80), 
        .Y(n27) );
  OAI32X4 U30 ( .A0(n31), .A1(pr_st[2]), .A2(pr_st[0]), .B0(n32), .B1(n77), 
        .Y(n68) );
  OAI222X4 U33 ( .A0(mode0_shift_clk), .A1(n29), .B0(mode0_TX_ing), .B1(
        mode0_RX_ing), .C0(Uart_mode0), .C1(n35), .Y(Uart_TXD) );
  AOI222X4 U37 ( .A0(Uart_mode0), .A1(n41), .B0(SFR_wr_SBUF), .B1(n42), .C0(
        TX_shift_bit), .C1(n38), .Y(n40) );
  OAI33X4 U59 ( .A0(n48), .A1(sw_rst), .A2(Uart_mode0), .B0(n49), .B1(n29), 
        .B2(n34), .Y(N19) );
  NAND3X1 I71 ( .A(n81), .B(n82), .C(n78), .Y(mode123_TX_ing) );
  AND4X2 I72 ( .A(n80), .B(n78), .C(n81), .D(n82), .Y(n75) );
  INVX1 I73 ( .A(n75), .Y(mode0_TX_ing) );
  DFFRX1 state_TX_reg_0_ ( .D(n53), .CK(clk_b), .RN(n51), .Q(state_TX[0]), 
        .QN(n80) );
  OR2X2 I74 ( .A(n78), .B(n80), .Y(n85) );
  DFFRX1 state_TX_reg_1_ ( .D(n54), .CK(clk_b), .RN(n51), .Q(state_TX[1]), 
        .QN(n78) );
  OAI21X1 I75 ( .A0(SFR_wr_SBUF), .A1(n43), .B0(n40), .Y(n66) );
  INVX12 I76 ( .A(sw_rst), .Y(n84) );
  INVX1 I77 ( .A(POR), .Y(n51) );
  DFFSX1 TX_div16_reg_0_ ( .D(n59), .CK(clk_b), .SN(n84), .Q(TX_div16[0]), 
        .QN(n58) );
  DFFRHQX1 TX_step_one_reg ( .D(N19), .CK(clk_b), .RN(n51), .Q(TX_step_one) );
  XOR2X1 I78 ( .A(state_TX[2]), .B(n85), .Y(n79) );
  DFFRX1 state_TX_reg_2_ ( .D(n55), .CK(clk_b), .RN(n51), .Q(state_TX[2]), 
        .QN(n81) );
  DFFRX1 state_TX_reg_3_ ( .D(n56), .CK(clk_b), .RN(n51), .Q(state_TX[3]), 
        .QN(n82) );
  INVX1 I79 ( .A(SFR_wr_SBUF), .Y(n38) );
  OAI2BB1X1 I80 ( .A0N(Uart_mode0), .A1N(n41), .B0(n43), .Y(TX_shift) );
  OR2X2 I81 ( .A(n20), .B(n22), .Y(n11) );
  INVX1 I82 ( .A(Uart_mode0), .Y(n29) );
  INVX1 I83 ( .A(n22), .Y(n41) );
  INVX1 I84 ( .A(n190), .Y(n8) );
  INVX1 I85 ( .A(n17), .Y(n20) );
  OR4X2 I86 ( .A(Uart_mode0), .B(n44), .C(n37), .D(n36), .Y(n43) );
  INVX1 I87 ( .A(mode123_TX_ing), .Y(n44) );
  OR2X2 I88 ( .A(n37), .B(n18), .Y(n22) );
  INVX1 I89 ( .A(mode0_TX_ing), .Y(n18) );
  AND2X2 I90 ( .A(n29), .B(n80), .Y(n26) );
  INVX1 I91 ( .A(Uart_mode1), .Y(n28) );
  NOR2X1 I92 ( .A(n85), .B(n81), .Y(n86) );
  DFFRX1 TX_start_reg ( .D(n57), .CK(clk_b), .RN(n51), .Q(TX_start), .QN(n760)
         );
  DFFRX1 TX_div16_reg_1_ ( .D(n61), .CK(clk_b), .RN(n84), .Q(TX_div16[1]), 
        .QN(n60) );
  DFFRX1 TX_div16_reg_2_ ( .D(n63), .CK(clk_b), .RN(n84), .Q(TX_div16[2]), 
        .QN(n62) );
  DFFRX1 TX_div16_reg_3_ ( .D(n65), .CK(clk_b), .RN(n84), .Q(TX_div16[3]), 
        .QN(n64) );
  DFFSX1 TX_shift_bit_reg ( .D(n66), .CK(clk_b), .SN(n84), .Q(TX_shift_bit) );
  DFFRX1 mode0_shift_clk_reg ( .D(n52), .CK(clk_b), .RN(n84), .Q(
        mode0_shift_clk), .QN(n77) );
  OR3X1 I93 ( .A(sw_rst), .B(pr_st[2]), .C(n31), .Y(n49) );
  NAND2X1 I94 ( .A(TX_div16_carry), .B(TX_clk), .Y(n48) );
  OAI2BB2X1 I95 ( .A0N(TX_div16_inc[1]), .A1N(TX_clk), .B0(TX_clk), .B1(n60), 
        .Y(n61) );
  OAI2BB2X1 I96 ( .A0N(TX_div16_inc[2]), .A1N(TX_clk), .B0(TX_clk), .B1(n62), 
        .Y(n63) );
  OAI2BB2X1 I97 ( .A0N(TX_div16_inc[3]), .A1N(TX_clk), .B0(TX_clk), .B1(n64), 
        .Y(n65) );
  OAI2BB2X1 I98 ( .A0N(TX_div16_inc[0]), .A1N(TX_clk), .B0(TX_clk), .B1(n58), 
        .Y(n59) );
  AND2X2 I99 ( .A(TX_step_one), .B(state_TX[3]), .Y(n24) );
  INVX1 I100 ( .A(n27), .Y(n23) );
  NOR2BX1 U66 ( .AN(n71), .B(sw_rst), .Y(n53) );
  OAI2BB1X1 I101 ( .A0N(n80), .A1N(n83), .B0(n16), .Y(n71) );
  AOI32X1 I102 ( .A0(n17), .A1(n18), .A2(n8), .B0(state_TX[0]), .B1(n190), .Y(
        n16) );
  OAI21X1 I103 ( .A0(Z_update), .A1(n69), .B0(n17), .Y(n70) );
  NOR2BX1 U67 ( .AN(n72), .B(sw_rst), .Y(n54) );
  OAI2BB2X1 I104 ( .A0N(N74), .A1N(n83), .B0(n8), .B1(n78), .Y(n72) );
  XOR2X1 I105 ( .A(state_TX[1]), .B(state_TX[0]), .Y(N74) );
  NOR2BX1 U69 ( .AN(n740), .B(sw_rst), .Y(n56) );
  OAI2BB2X1 I106 ( .A0N(N76), .A1N(n83), .B0(n8), .B1(n82), .Y(n740) );
  XOR2X1 I107 ( .A(state_TX[3]), .B(n86), .Y(N76) );
  NOR2BX1 U68 ( .AN(n73), .B(sw_rst), .Y(n55) );
  OR3X2 I108 ( .A(Uart_mode1), .B(TB8), .C(Uart_mode0), .Y(n42) );
  NOR2X1 I109 ( .A(TX_start), .B(n11), .Y(n83) );
  INVX1 I110 ( .A(state_TX[2]), .Y(n14) );
  INVX1 I111 ( .A(n45), .Y(n36) );
  OAI211X1 I112 ( .A0(state_TX[0]), .A1(Uart_mode1), .B0(n14), .C0(n46), .Y(
        n45) );
  AND3X1 I113 ( .A(state_TX[3]), .B(state_TX[1]), .C(n47), .Y(n46) );
  OR3X2 I114 ( .A(Uart_mode3), .B(Uart_mode2), .C(n80), .Y(n47) );
  INVX1 I115 ( .A(pr_st[1]), .Y(n31) );
  INVX1 I116 ( .A(pr_st[0]), .Y(n34) );
  NOR2BX1 U70 ( .AN(n67), .B(sw_rst), .Y(n57) );
  OAI2BB1X1 I117 ( .A0N(TX_start), .A1N(n37), .B0(n38), .Y(n67) );
  AND2X2 U65 ( .A(n68), .B(Uart_mode0), .Y(n52) );
  AND3X1 I118 ( .A(n34), .B(n31), .C(pr_st[2]), .Y(n32) );
  INVX1 I119 ( .A(TX_step_one), .Y(n37) );
  AOI211X1 I120 ( .A0(now_TX_bit), .A1(mode123_TX_ing), .B0(n36), .C0(n18), 
        .Y(n35) );
  DFFRX1 set_TI_reg ( .D(n70), .CK(clk_b), .RN(n84), .Q(set_TI), .QN(n69) );
  TX_DW01_inc_5_0 add_83 ( .A({1'b0, TX_div16}), .SUM({TX_div16_carry, 
        TX_div16_inc}) );
endmodule


module TX_DW01_inc_5_0 ( A, SUM );
  input [4:0] A;
  output [4:0] SUM;
  wire   carry_3_, carry_2_;

  INVX1 U5 ( .A(A[0]), .Y(SUM[0]) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(SUM[4]) );
endmodule


module RX ( POR, Z_update, sw_rst, clk_b, pr_st, mode0_TX_ing, now_TX_bit, SM2, 
        REN, RI, pin_RXD, SADDR_match, RX_clk, Uart_mode0, Uart_mode1, 
        Uart_mode2, Uart_mode3, RX_shift_bit, chosen_RX_bit, mode0_RX_ing, 
        RX_shift, set_RI, set_FE, Mode0_data_RXD );
  input [2:0] pr_st;
  input POR, Z_update, sw_rst, clk_b, mode0_TX_ing, now_TX_bit, SM2, REN, RI,
         pin_RXD, SADDR_match, RX_clk, Uart_mode0, Uart_mode1, Uart_mode2,
         Uart_mode3;
  output RX_shift_bit, chosen_RX_bit, mode0_RX_ing, RX_shift, set_RI, set_FE,
         Mode0_data_RXD;
  wire   current_RXD, before_RXD, now_RX_ing, decision_time, RX_step_one, N34,
         N35, N61, N62, RX_div16_carry, N86, N87, N88, n14, n19, n20, n22, n23,
         n24, n25, n26, n27, n28, n29, n31, n32, n33, n340, n350, n36, n37,
         n38, n40, n41, n42, n43, n45, n46, n50, n51, n52, n55, n56, n57, n59,
         n610, n620, n65, n69, n70, n71, n72, n73, n74, n75, n77, n78, n79,
         n81, n84, n85, n870, n89, n90, n91, n92, n93, n94, n95, n96, n97, n98,
         n99, n100, n101, n102, n103, n104, n105, n106, n107, n108, n109, n110,
         n111, n112, n113, n114, n115, n116, n117, n118, n119, n120, n121,
         n122, n123, n124, n125, n126, n127, n128, n129, n130, n131, n132,
         n133, n134, n135;
  wire   [3:0] RX_div16;
  wire   [3:0] state_RX;
  wire   [3:0] RX_div16_inc;

  OAI211X4 U17 ( .A0(n25), .A1(n26), .B0(n27), .C0(n28), .Y(n19) );
  AOI33X4 U18 ( .A0(n29), .A1(n120), .A2(n127), .B0(state_RX[0]), .B1(n31), 
        .B2(n127), .Y(n28) );
  OAI211X4 U34 ( .A0(Uart_mode1), .A1(n31), .B0(n133), .C0(n120), .Y(n350) );
  OAI33X4 U45 ( .A0(n120), .A1(Uart_mode1), .A2(Uart_mode0), .B0(n51), .B1(RI), 
        .B2(n52), .Y(n45) );
  OAI222X4 U53 ( .A0(n59), .A1(n113), .B0(RX_div16[0]), .B1(n113), .C0(n610), 
        .C1(n620), .Y(n103) );
  OAI222X4 U55 ( .A0(n59), .A1(n112), .B0(n112), .B1(n118), .C0(n610), .C1(n65), .Y(n102) );
  OAI222X4 U65 ( .A0(n112), .A1(n115), .B0(n112), .B1(n113), .C0(n113), .C1(
        n115), .Y(chosen_RX_bit) );
  OAI211X4 U82 ( .A0(n77), .A1(n78), .B0(REN), .C0(n75), .Y(n37) );
  NAND4X1 I113 ( .A(n120), .B(n116), .C(n121), .D(n122), .Y(now_RX_ing) );
  NOR4BX1 I114 ( .AN(n79), .B(set_RI), .C(RI), .D(n81), .Y(n77) );
  NOR3X1 I115 ( .A(RX_div16[2]), .B(n117), .C(n131), .Y(n870) );
  AOI31X1 I116 ( .A0(n40), .A1(n41), .A2(n127), .B0(n38), .Y(n110) );
  INVX1 I117 ( .A(n110), .Y(n105) );
  NAND3BX1 I118 ( .AN(n122), .B(n121), .C(state_RX[1]), .Y(n129) );
  DFFRX1 state_RX_reg_3_ ( .D(n93), .CK(clk_b), .RN(n89), .Q(state_RX[3]), 
        .QN(n122) );
  NAND3BX1 I119 ( .AN(state_RX[2]), .B(n122), .C(n116), .Y(N61) );
  NAND2X1 I120 ( .A(RX_div16[0]), .B(current_RXD), .Y(n620) );
  NOR3X1 I121 ( .A(state_RX[1]), .B(state_RX[3]), .C(Uart_mode0), .Y(n33) );
  NAND2X1 I122 ( .A(n118), .B(current_RXD), .Y(n65) );
  OAI2BB1X1 I123 ( .A0N(n121), .A1N(n116), .B0(state_RX[3]), .Y(N62) );
  DFFRX1 state_RX_reg_2_ ( .D(n92), .CK(clk_b), .RN(n89), .Q(state_RX[2]), 
        .QN(n121) );
  MX2X1 I124 ( .S0(n55), .B(n111), .A(current_RXD), .Y(n104) );
  INVX2 I125 ( .A(n131), .Y(n130) );
  DFFRX1 RX_div16_reg_1_ ( .D(n97), .CK(clk_b), .RN(n130), .Q(RX_div16[1]), 
        .QN(n128) );
  DFFRHQX1 decision_time_reg ( .D(N34), .CK(clk_b), .RN(n89), .Q(decision_time) );
  DFFRX1 RX_div16_reg_2_ ( .D(n98), .CK(clk_b), .RN(n130), .Q(RX_div16[2]), 
        .QN(n114) );
  DFFRX1 RX_div16_reg_3_ ( .D(n99), .CK(clk_b), .RN(n130), .Q(RX_div16[3]), 
        .QN(n117) );
  DFFSX2 RX_div16_reg_0_ ( .D(n96), .CK(clk_b), .SN(n130), .Q(RX_div16[0]), 
        .QN(n118) );
  DFFRX1 set_RI_reg ( .D(n105), .CK(clk_b), .RN(n130), .Q(set_RI), .QN(n119)
         );
  DFFRX2 state_RX_reg_0_ ( .D(n90), .CK(clk_b), .RN(n89), .Q(state_RX[0]), 
        .QN(n120) );
  NOR3X2 I126 ( .A(n128), .B(n50), .C(n129), .Y(n127) );
  INVX1 I127 ( .A(sw_rst), .Y(n132) );
  INVX1 I128 ( .A(n37), .Y(n24) );
  NAND2X1 I129 ( .A(n133), .B(state_RX[0]), .Y(n134) );
  INVX1 I130 ( .A(n20), .Y(n23) );
  BUFX3 I131 ( .A(state_RX[1]), .Y(n133) );
  NAND2X1 I132 ( .A(now_RX_ing), .B(RX_step_one), .Y(n20) );
  INVX2 I133 ( .A(current_RXD), .Y(n56) );
  INVX2 I134 ( .A(POR), .Y(n89) );
  INVX1 I135 ( .A(n71), .Y(n70) );
  INVX2 I136 ( .A(n132), .Y(n131) );
  NOR2X1 I137 ( .A(Uart_mode0), .B(n57), .Y(n124) );
  OR2X2 I138 ( .A(n74), .B(n75), .Y(n71) );
  INVX1 I139 ( .A(n69), .Y(n74) );
  INVX1 I140 ( .A(Uart_mode0), .Y(n36) );
  INVX1 I141 ( .A(n31), .Y(n29) );
  INVX1 I142 ( .A(n350), .Y(n340) );
  INVX1 I143 ( .A(chosen_RX_bit), .Y(n46) );
  OAI2BB1X2 I144 ( .A0N(n124), .A1N(now_RX_ing), .B0(n37), .Y(n69) );
  INVX1 I145 ( .A(RX_clk), .Y(n57) );
  INVX1 I146 ( .A(RX_div16_inc[1]), .Y(n72) );
  NAND2X1 I147 ( .A(n125), .B(n84), .Y(N35) );
  NAND3X1 I148 ( .A(RX_div16_carry), .B(n130), .C(n124), .Y(n125) );
  INVX1 I149 ( .A(n610), .Y(n59) );
  OR3X2 I150 ( .A(n24), .B(n23), .C(n19), .Y(n14) );
  OR2X2 I151 ( .A(Uart_mode2), .B(Uart_mode3), .Y(n31) );
  DFFSX1 pin_sample7_reg ( .D(n103), .CK(clk_b), .SN(n130), .QN(n113) );
  DFFSX1 pin_sample6_reg ( .D(n102), .CK(clk_b), .SN(n130), .QN(n112) );
  DFFSX1 pin_sample8_reg ( .D(n104), .CK(clk_b), .SN(n130), .Q(n111), .QN(n115) );
  DFFRX1 state_RX_reg_1_ ( .D(n91), .CK(clk_b), .RN(n89), .Q(state_RX[1]), 
        .QN(n116) );
  OR3X2 I152 ( .A(n133), .B(n120), .C(n43), .Y(n27) );
  NOR2BX1 U109 ( .AN(n106), .B(n131), .Y(n90) );
  OAI22X1 I153 ( .A0(n120), .A1(n14), .B0(n22), .B1(n19), .Y(n106) );
  AOI21X1 I154 ( .A0(n120), .A1(n23), .B0(n24), .Y(n22) );
  NOR2BX1 U110 ( .AN(n107), .B(n131), .Y(n91) );
  OAI2BB2X1 I155 ( .A0N(N86), .A1N(n126), .B0(n116), .B1(n14), .Y(n107) );
  XOR2X1 I156 ( .A(n133), .B(state_RX[0]), .Y(N86) );
  NOR2BX1 U111 ( .AN(n108), .B(n131), .Y(n92) );
  OAI2BB2X1 I157 ( .A0N(N87), .A1N(n126), .B0(n14), .B1(n121), .Y(n108) );
  XNOR2X1 I158 ( .A(state_RX[2]), .B(n134), .Y(N87) );
  NOR2X1 I159 ( .A(n19), .B(n20), .Y(n126) );
  OR3X2 I160 ( .A(n131), .B(n79), .C(n81), .Y(n84) );
  OAI22X1 I161 ( .A0(n36), .A1(n56), .B0(Uart_mode0), .B1(n46), .Y(
        RX_shift_bit) );
  DFFSX1 before_RXD_reg ( .D(n95), .CK(clk_b), .SN(n89), .Q(before_RXD), .QN(
        n123) );
  DFFSX1 current_RXD_reg ( .D(n94), .CK(clk_b), .SN(n89), .Q(current_RXD) );
  INVX1 I162 ( .A(now_RX_ing), .Y(n75) );
  OAI221X4 I163 ( .A0(n43), .A1(n350), .B0(Z_update), .B1(n119), .C0(n27), .Y(
        n38) );
  AND3X2 I164 ( .A(n42), .B(n120), .C(n36), .Y(n40) );
  INVX1 I165 ( .A(Uart_mode1), .Y(n52) );
  DFFRHQX1 RX_step_one_reg ( .D(N35), .CK(clk_b), .RN(n89), .Q(RX_step_one) );
  NAND3BX1 I166 ( .AN(now_TX_bit), .B(mode0_TX_ing), .C(Uart_mode0), .Y(
        Mode0_data_RXD) );
  OAI211X1 I167 ( .A0(n118), .A1(n69), .B0(n37), .C0(n73), .Y(n96) );
  NAND2X1 I168 ( .A(RX_div16_inc[0]), .B(n70), .Y(n73) );
  OR4X2 I169 ( .A(n57), .B(n114), .C(RX_div16[3]), .D(n128), .Y(n610) );
  OAI2BB1X1 I170 ( .A0N(n85), .A1N(n124), .B0(n84), .Y(N34) );
  AND3X2 I171 ( .A(RX_div16_inc[1]), .B(RX_div16[0]), .C(n870), .Y(n85) );
  OR3X2 I172 ( .A(RX_div16[1]), .B(n57), .C(n50), .Y(n55) );
  OR2X2 U108 ( .A(n100), .B(n131), .Y(n95) );
  OAI22X1 I173 ( .A0(n57), .A1(n56), .B0(RX_clk), .B1(n123), .Y(n100) );
  OR2X2 U107 ( .A(n101), .B(n131), .Y(n94) );
  OAI2BB2X1 I174 ( .A0N(pin_RXD), .A1N(RX_clk), .B0(RX_clk), .B1(n56), .Y(n101) );
  AND3X1 I175 ( .A(n45), .B(n46), .C(n127), .Y(set_FE) );
  NAND3BX1 I176 ( .AN(pr_st[2]), .B(pr_st[0]), .C(Uart_mode0), .Y(n81) );
  AND3X2 I177 ( .A(before_RXD), .B(n56), .C(n36), .Y(n78) );
  OR3X2 I178 ( .A(RX_div16[2]), .B(RX_div16[0]), .C(n117), .Y(n50) );
  INVX1 I179 ( .A(pr_st[1]), .Y(n79) );
  OR2X2 I180 ( .A(state_RX[2]), .B(n32), .Y(n26) );
  AOI32X1 I181 ( .A0(state_RX[0]), .A1(n33), .A2(chosen_RX_bit), .B0(n340), 
        .B1(state_RX[3]), .Y(n25) );
  OR4X2 I182 ( .A(n32), .B(n122), .C(state_RX[2]), .D(n36), .Y(n43) );
  NOR2BX1 U112 ( .AN(n109), .B(n131), .Y(n93) );
  OAI2BB2X1 I183 ( .A0N(N88), .A1N(n126), .B0(n122), .B1(n14), .Y(n109) );
  XOR2X1 I184 ( .A(state_RX[3]), .B(n135), .Y(N88) );
  NOR2X1 I185 ( .A(n134), .B(n121), .Y(n135) );
  AND3X2 I186 ( .A(N61), .B(N62), .C(decision_time), .Y(RX_shift) );
  OAI2BB1X1 I187 ( .A0N(SADDR_match), .A1N(chosen_RX_bit), .B0(SM2), .Y(n41)
         );
  INVX1 I188 ( .A(RI), .Y(n42) );
  OR2X2 I189 ( .A(state_RX[0]), .B(SM2), .Y(n51) );
  INVX1 I190 ( .A(decision_time), .Y(n32) );
  AND2X2 I191 ( .A(N61), .B(Uart_mode0), .Y(mode0_RX_ing) );
  OAI2BB2X1 I192 ( .A0N(RX_div16_inc[2]), .A1N(n70), .B0(n114), .B1(n69), .Y(
        n98) );
  OAI2BB2X1 I193 ( .A0N(RX_div16_inc[3]), .A1N(n70), .B0(n117), .B1(n69), .Y(
        n99) );
  OAI22X1 I194 ( .A0(n128), .A1(n69), .B0(n71), .B1(n72), .Y(n97) );
  RX_DW01_inc_5_0 add_116 ( .A({1'b0, RX_div16}), .SUM({RX_div16_carry, 
        RX_div16_inc}) );
endmodule


module RX_DW01_inc_5_0 ( A, SUM );
  input [4:0] A;
  output [4:0] SUM;
  wire   carry_3_, carry_2_;

  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  INVX1 U5 ( .A(A[0]), .Y(SUM[0]) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(SUM[4]) );
endmodule


module uart_sfr ( POR, sw_rst, clk_b, pr_st, SFR_wr, SFR_bus, SCON_sel, 
        SBUF_sel, SADEN_sel, SADDR_sel, Uart_mode0, Uart_mode1, Uart_mode2, 
        Uart_mode3, SMOD1_update, SMOD1, SMOD0, T1_overflow, T2_uart_clk, TCLK, 
        RCLK, RX_clk, TX_clk, now_TX_bit, TX_shift_bit, TX_shift, RX_shift_bit, 
        chosen_RX_bit, RX_shift, set_TI, set_RI, set_FE, SM2, REN, TB8, RI, 
        ua_intr, SADDR_match, SFR_wr_SBUF, UART_SFR_OUT );
  input [2:0] pr_st;
  input [7:0] SFR_bus;
  output [7:0] UART_SFR_OUT;
  input POR, sw_rst, clk_b, SFR_wr, SCON_sel, SBUF_sel, SADEN_sel, SADDR_sel,
         SMOD1_update, SMOD1, SMOD0, T1_overflow, T2_uart_clk, TCLK, RCLK,
         TX_shift_bit, TX_shift, RX_shift_bit, chosen_RX_bit, RX_shift, set_TI,
         set_RI, set_FE;
  output Uart_mode0, Uart_mode1, Uart_mode2, Uart_mode3, RX_clk, TX_clk,
         now_TX_bit, SM2, REN, TB8, RI, ua_intr, SADDR_match, SFR_wr_SBUF;
  wire   scon_mode_1_, SADEN_7_, SADEN_5_, SADEN_4_, SADEN_3_, SADEN_0_,
         SCON_TMP_6_, SCON_TMP_2_, FE, RXBUF_wr_en, RX_shift_reg_5_,
         RX_shift_reg_4_, RX_shift_reg_3_, RX_shift_reg_0_, T2_uart_clk_delay,
         T2_uart_clk_delay0, T2_uart_clk_delay1, T2_overflow_sel,
         T2_uart_clk_delay2, even_state, N51, T1_overflow_div2, n2, n4, n7, n9,
         n10, n11, n12, n13, n16, n17, n20, n21, n24, n27, n30, n32, n35, n36,
         n37, n38, n39, n40, n41, n42, n43, n45, n46, n47, n48, n50, n52, n54,
         n56, n58, n60, n61, n63, n65, n66, n67, n68, n69, n70, n72, n73, n74,
         n75, n78, n86, n87, n88, n89, n90, n91, n92, n95, n96, n97, n98, n99,
         n102, n107, n108, n109, n110, n111, n112, n122, n123, n124, n127,
         n128, n129, n130, n131, n132, n133, n134, n135, n136, n137, n138,
         n139, n140, n141, n142, n143, n144, n145, n146, n147, n148, n149,
         n150, n151, n152, n153, n154, n155, n156, n157, n158, n159, n160,
         n161, n162, n163, n164, n165, n166, n167, n168, n169, n170, n171,
         n172, n173, n174, n175, n176, n177, n178, n179, n180, n181, n182,
         n183, n184, n185, n186, n187, n188, n189, n190, n191, n192, n193,
         n194, n195, n196, n197, n198, n199, n200, n201, n202, n203, n204,
         n205, n206, n207, n208, n209, n210, n211, n212, n213, n214, n215,
         n216, n217, n218, n219, n220, n221, n222, n223, n224, n225, n226,
         n227, n228, n229, n230, n231, n232, n233, n234, n235, n236, n237,
         n238, n239, n240, n241, n242, n243, n244, n245, n246;
  wire   [7:0] SADDR;
  wire   [7:0] RXBUF;

  AOI221X4 U9 ( .A0(SADDR_sel), .A1(SADDR[7]), .B0(SADEN_sel), .B1(SADEN_7_), 
        .C0(n11), .Y(n10) );
  OAI31X4 U27 ( .A0(n36), .A1(n37), .A2(n38), .B0(n39), .Y(TX_clk) );
  OAI222X4 U32 ( .A0(n43), .A1(n226), .B0(n45), .B1(n46), .C0(n47), .C1(n48), 
        .Y(n189) );
  OAI222X4 U34 ( .A0(n43), .A1(n211), .B0(n45), .B1(n50), .C0(n47), .C1(n226), 
        .Y(n188) );
  OAI222X4 U36 ( .A0(n43), .A1(n225), .B0(n45), .B1(n52), .C0(n47), .C1(n211), 
        .Y(n187) );
  OAI222X4 U38 ( .A0(n43), .A1(n210), .B0(n45), .B1(n54), .C0(n47), .C1(n225), 
        .Y(n186) );
  OAI222X4 U40 ( .A0(n43), .A1(n224), .B0(n45), .B1(n56), .C0(n47), .C1(n210), 
        .Y(n185) );
  OAI222X4 U42 ( .A0(n43), .A1(n209), .B0(n45), .B1(n58), .C0(n47), .C1(n224), 
        .Y(n184) );
  OAI222X4 U44 ( .A0(n43), .A1(n223), .B0(n45), .B1(n60), .C0(n47), .C1(n209), 
        .Y(n183) );
  OAI222X4 U46 ( .A0(n43), .A1(n181), .B0(n45), .B1(n61), .C0(n47), .C1(n223), 
        .Y(n182) );
  OAI32X4 U53 ( .A0(n222), .A1(T1_overflow), .A2(SMOD1), .B0(n38), .B1(n42), 
        .Y(n180) );
  OAI32X4 U59 ( .A0(n67), .A1(sw_rst), .A2(n214), .B0(n46), .B1(n68), .Y(n179)
         );
  AOI221X4 U121 ( .A0(SADEN_3_), .A1(n88), .B0(SADEN_5_), .B1(n89), .C0(n90), 
        .Y(n87) );
  AOI221X4 U129 ( .A0(SADEN_0_), .A1(n95), .B0(SADEN_4_), .B1(n96), .C0(n97), 
        .Y(n86) );
  AOI33X4 U147 ( .A0(n42), .A1(n110), .A2(n111), .B0(T2_overflow_sel), .B1(
        RCLK), .B2(SCON_TMP_6_), .Y(n109) );
  OAI32X4 U190 ( .A0(n69), .A1(n12), .A2(n46), .B0(n70), .B1(n242), .Y(n138)
         );
  OR2X4 U195 ( .A(n16), .B(n66), .Y(n69) );
  NAND2X1 I210 ( .A(n216), .B(scon_mode_1_), .Y(n40) );
  NAND2X1 I211 ( .A(set_RI), .B(n63), .Y(n73) );
  NOR2X1 I212 ( .A(n216), .B(n214), .Y(Uart_mode3) );
  NAND3BX1 I213 ( .AN(n7), .B(n63), .C(n40), .Y(n4) );
  NAND2X2 I214 ( .A(n45), .B(n43), .Y(n47) );
  MXI2X1 I215 ( .S0(n107), .B(n215), .A(n194), .Y(n139) );
  OR2X2 I216 ( .A(n13), .B(n66), .Y(n191) );
  DFFRX1 SCON_reg_6_ ( .D(n134), .CK(clk_b), .RN(n127), .Q(SCON_TMP_6_), .QN(
        n216) );
  INVX4 I217 ( .A(n63), .Y(Uart_mode0) );
  OR3X2 I218 ( .A(pr_st[2]), .B(n122), .C(n123), .Y(n107) );
  INVX2 I219 ( .A(n245), .Y(n102) );
  AND2X2 I220 ( .A(SCON_TMP_6_), .B(n214), .Y(Uart_mode1) );
  OR2X2 I221 ( .A(n65), .B(n66), .Y(n45) );
  INVX1 I222 ( .A(POR), .Y(n127) );
  AOI32X1 I223 ( .A0(n73), .A1(SCON_TMP_2_), .A2(n69), .B0(chosen_RX_bit), 
        .B1(n74), .Y(n72) );
  DFFRHQX1 RXBUF_wr_en_reg ( .D(set_RI), .CK(clk_b), .RN(n243), .Q(RXBUF_wr_en) );
  DFFRX1 SCON_reg_0_ ( .D(n129), .CK(clk_b), .RN(n243), .Q(RI), .QN(n194) );
  DFFRX1 RX_shift_reg_reg_4_ ( .D(n152), .CK(clk_b), .RN(n244), .Q(
        RX_shift_reg_4_), .QN(n198) );
  OR2X2 I224 ( .A(n21), .B(n66), .Y(n204) );
  DFFRX1 RX_shift_reg_reg_3_ ( .D(n151), .CK(clk_b), .RN(n243), .Q(
        RX_shift_reg_3_), .QN(n206) );
  DFFRX1 RX_shift_reg_reg_5_ ( .D(n153), .CK(clk_b), .RN(n243), .Q(
        RX_shift_reg_5_), .QN(n207) );
  DFFRX1 RX_shift_reg_reg_0_ ( .D(n148), .CK(clk_b), .RN(n244), .Q(
        RX_shift_reg_0_), .QN(n208) );
  DFFRX1 SCON_reg_7_ ( .D(n135), .CK(clk_b), .RN(n127), .Q(scon_mode_1_), .QN(
        n214) );
  DFFRX1 SCON_reg_5_ ( .D(n133), .CK(clk_b), .RN(n127), .Q(SM2), .QN(n219) );
  DFFRX1 SADDR_reg_1_ ( .D(n157), .CK(clk_b), .RN(n243), .Q(SADDR[1]), .QN(
        n235) );
  DFFRX1 SADDR_reg_2_ ( .D(n158), .CK(clk_b), .RN(n243), .Q(SADDR[2]), .QN(
        n236) );
  DFFRX1 SADDR_reg_6_ ( .D(n162), .CK(clk_b), .RN(n244), .Q(SADDR[6]), .QN(
        n237) );
  DFFRX1 SADDR_reg_3_ ( .D(n159), .CK(clk_b), .RN(n243), .Q(SADDR[3]), .QN(
        n238) );
  DFFRX1 SADDR_reg_5_ ( .D(n161), .CK(clk_b), .RN(n243), .Q(SADDR[5]), .QN(
        n239) );
  DFFRX1 SADDR_reg_7_ ( .D(n163), .CK(clk_b), .RN(n244), .Q(SADDR[7]), .QN(
        n240) );
  DFFRX1 SCON_reg_4_ ( .D(n132), .CK(clk_b), .RN(n127), .Q(REN), .QN(n241) );
  OR2X2 I225 ( .A(SFR_wr_SBUF), .B(TX_shift), .Y(n43) );
  INVX2 I226 ( .A(n204), .Y(n78) );
  INVX2 I227 ( .A(n191), .Y(n75) );
  AOI32X1 I228 ( .A0(SMOD0), .A1(FE), .A2(SCON_sel), .B0(SBUF_sel), .B1(
        RXBUF[7]), .Y(n9) );
  INVX1 I229 ( .A(n45), .Y(SFR_wr_SBUF) );
  INVX1 I230 ( .A(SFR_wr), .Y(n66) );
  AOI22X1 I231 ( .A0(SCON_sel), .A1(RI), .B0(RXBUF[0]), .B1(SBUF_sel), .Y(n35)
         );
  AOI22X1 I232 ( .A0(RXBUF[1]), .A1(SBUF_sel), .B0(SADDR[1]), .B1(SADDR_sel), 
        .Y(n32) );
  AND3X1 I233 ( .A(SCON_sel), .B(n12), .C(scon_mode_1_), .Y(n11) );
  BUFX3 I234 ( .A(RX_shift), .Y(n245) );
  INVX1 I235 ( .A(set_RI), .Y(n137) );
  BUFX3 I236 ( .A(RXBUF_wr_en), .Y(n246) );
  INVX2 I237 ( .A(n69), .Y(n70) );
  INVX1 I238 ( .A(SBUF_sel), .Y(n65) );
  DFFRHQX1 T2_uart_clk_delay2_reg ( .D(T2_uart_clk_delay1), .CK(clk_b), .RN(
        n244), .Q(T2_uart_clk_delay2) );
  DFFRHQX1 T2_uart_clk_delay1_reg ( .D(T2_uart_clk_delay0), .CK(clk_b), .RN(
        n244), .Q(T2_uart_clk_delay1) );
  INVX2 I239 ( .A(SADEN_sel), .Y(n13) );
  INVX2 I240 ( .A(SCON_sel), .Y(n16) );
  INVX1 I241 ( .A(SADDR_sel), .Y(n21) );
  DFFRX1 SADDR_reg_0_ ( .D(n156), .CK(clk_b), .RN(n243), .Q(SADDR[0]), .QN(
        n193) );
  DFFRX1 SADEN_reg_0_ ( .D(n164), .CK(clk_b), .RN(n243), .Q(SADEN_0_), .QN(
        n213) );
  INVX1 I242 ( .A(SFR_bus[3]), .Y(n56) );
  INVX1 I243 ( .A(SFR_bus[4]), .Y(n54) );
  INVX1 I244 ( .A(SFR_bus[5]), .Y(n52) );
  INVX1 I245 ( .A(SFR_bus[6]), .Y(n50) );
  DFFRX1 SADEN_reg_1_ ( .D(n165), .CK(clk_b), .RN(n243), .QN(n212) );
  DFFRX1 RI_delay_reg ( .D(n139), .CK(clk_b), .RN(n244), .QN(n215) );
  INVX1 I246 ( .A(SFR_bus[7]), .Y(n46) );
  INVX1 I247 ( .A(SFR_bus[0]), .Y(n61) );
  INVX1 I248 ( .A(SFR_bus[1]), .Y(n60) );
  INVX1 I249 ( .A(SFR_bus[2]), .Y(n58) );
  DFFRX1 SADEN_reg_7_ ( .D(n171), .CK(clk_b), .RN(n243), .Q(SADEN_7_), .QN(
        n221) );
  DFFRX1 SADDR_reg_4_ ( .D(n160), .CK(clk_b), .RN(n243), .Q(SADDR[4]), .QN(
        n195) );
  DFFRX1 SADEN_reg_3_ ( .D(n167), .CK(clk_b), .RN(n243), .Q(SADEN_3_), .QN(
        n202) );
  DFFRX1 SADEN_reg_4_ ( .D(n168), .CK(clk_b), .RN(n243), .Q(SADEN_4_), .QN(
        n218) );
  DFFRX1 SADEN_reg_5_ ( .D(n169), .CK(clk_b), .RN(n243), .Q(SADEN_5_), .QN(
        n203) );
  DFFRX1 SADEN_reg_2_ ( .D(n166), .CK(clk_b), .RN(n243), .QN(n200) );
  DFFRX1 SADEN_reg_6_ ( .D(n170), .CK(clk_b), .RN(n243), .QN(n201) );
  DFFRX1 RX_shift_reg_reg_1_ ( .D(n149), .CK(clk_b), .RN(n244), .QN(n192) );
  DFFRX1 RX_shift_reg_reg_2_ ( .D(n150), .CK(clk_b), .RN(n244), .QN(n196) );
  DFFRX1 RX_shift_reg_reg_6_ ( .D(n154), .CK(clk_b), .RN(n244), .QN(n197) );
  DFFRX1 RX_shift_reg_reg_7_ ( .D(n155), .CK(clk_b), .RN(n243), .QN(n205) );
  DFFRX1 TXBUF_reg_1_ ( .D(n183), .CK(clk_b), .RN(n243), .QN(n223) );
  DFFRX1 TXBUF_reg_2_ ( .D(n184), .CK(clk_b), .RN(n244), .QN(n209) );
  DFFRX1 TXBUF_reg_3_ ( .D(n185), .CK(clk_b), .RN(n244), .QN(n224) );
  DFFRX1 TXBUF_reg_4_ ( .D(n186), .CK(clk_b), .RN(n244), .QN(n210) );
  DFFRX1 TXBUF_reg_5_ ( .D(n187), .CK(clk_b), .RN(n244), .QN(n225) );
  DFFRX1 TXBUF_reg_6_ ( .D(n188), .CK(clk_b), .RN(n244), .QN(n211) );
  INVX4 I250 ( .A(sw_rst), .Y(n243) );
  INVX4 I251 ( .A(sw_rst), .Y(n244) );
  OAI22X1 I252 ( .A0(n75), .A1(n212), .B0(n60), .B1(n191), .Y(n165) );
  OAI22X1 I253 ( .A0(n75), .A1(n200), .B0(n58), .B1(n191), .Y(n166) );
  OAI22X1 I254 ( .A0(n75), .A1(n202), .B0(n56), .B1(n191), .Y(n167) );
  OAI22X1 I255 ( .A0(n75), .A1(n218), .B0(n54), .B1(n191), .Y(n168) );
  OAI22X1 I256 ( .A0(n75), .A1(n203), .B0(n52), .B1(n191), .Y(n169) );
  OAI22X1 I257 ( .A0(n75), .A1(n201), .B0(n50), .B1(n191), .Y(n170) );
  OAI22X1 I258 ( .A0(n75), .A1(n221), .B0(n46), .B1(n191), .Y(n171) );
  OAI22X1 I259 ( .A0(n78), .A1(n195), .B0(n54), .B1(n204), .Y(n160) );
  DFFRX1 RXBUF_reg_1_ ( .D(n141), .CK(clk_b), .RN(n244), .Q(RXBUF[1]), .QN(
        n227) );
  DFFRX1 RXBUF_reg_0_ ( .D(n140), .CK(clk_b), .RN(n244), .Q(RXBUF[0]), .QN(
        n233) );
  DFFRX1 SCON_reg_1_ ( .D(n130), .CK(clk_b), .RN(n243), .QN(n199) );
  INVX2 I260 ( .A(n40), .Y(Uart_mode2) );
  NAND2BX1 U202 ( .AN(n172), .B(n137), .Y(n129) );
  OAI22X1 I261 ( .A0(n70), .A1(n194), .B0(n61), .B1(n69), .Y(n172) );
  AND2X2 U209 ( .A(n243), .B(n179), .Y(n135) );
  INVX1 I262 ( .A(n68), .Y(n67) );
  OR2X2 I263 ( .A(SMOD0), .B(n69), .Y(n68) );
  AND2X2 U205 ( .A(n175), .B(n243), .Y(n131) );
  OAI22X1 I264 ( .A0(n70), .A1(n217), .B0(n56), .B1(n69), .Y(n175) );
  AND2X2 U207 ( .A(n243), .B(n177), .Y(n133) );
  OAI22X1 I265 ( .A0(n70), .A1(n219), .B0(n52), .B1(n69), .Y(n177) );
  AND2X2 U208 ( .A(n244), .B(n178), .Y(n134) );
  OAI22X1 I266 ( .A0(n70), .A1(n216), .B0(n50), .B1(n69), .Y(n178) );
  OAI22X1 I267 ( .A0(n75), .A1(n213), .B0(n61), .B1(n191), .Y(n164) );
  OAI22X1 I268 ( .A0(n78), .A1(n193), .B0(n61), .B1(n204), .Y(n156) );
  DFFRX1 RXBUF_reg_7_ ( .D(n147), .CK(clk_b), .RN(n244), .Q(RXBUF[7]), .QN(
        n232) );
  DFFRX1 FE_reg ( .D(n136), .CK(clk_b), .RN(n244), .Q(FE), .QN(n242) );
  INVX1 I269 ( .A(SMOD0), .Y(n12) );
  DFFRX1 RXBUF_reg_2_ ( .D(n142), .CK(clk_b), .RN(n244), .Q(RXBUF[2]), .QN(
        n228) );
  DFFRX1 RXBUF_reg_3_ ( .D(n143), .CK(clk_b), .RN(n244), .Q(RXBUF[3]), .QN(
        n229) );
  DFFRX1 RXBUF_reg_5_ ( .D(n145), .CK(clk_b), .RN(n244), .Q(RXBUF[5]), .QN(
        n230) );
  DFFRX1 RXBUF_reg_6_ ( .D(n146), .CK(clk_b), .RN(n244), .Q(RXBUF[6]), .QN(
        n231) );
  DFFRX1 RXBUF_reg_4_ ( .D(n144), .CK(clk_b), .RN(n244), .Q(RXBUF[4]), .QN(
        n234) );
  DFFRX1 SCON_reg_3_ ( .D(n131), .CK(clk_b), .RN(n127), .Q(TB8), .QN(n217) );
  DFFRX1 SCON_reg_2_ ( .D(n174), .CK(clk_b), .RN(n243), .Q(SCON_TMP_2_), .QN(
        n220) );
  DFFRX1 T1_overflow_div2_reg ( .D(n128), .CK(clk_b), .RN(n244), .Q(
        T1_overflow_div2), .QN(n222) );
  OAI22X1 I270 ( .A0(n196), .A1(n102), .B0(n245), .B1(n192), .Y(n149) );
  OAI22X1 I271 ( .A0(n206), .A1(n102), .B0(n245), .B1(n196), .Y(n150) );
  OAI22X1 I272 ( .A0(n198), .A1(n102), .B0(n245), .B1(n206), .Y(n151) );
  OAI22X1 I273 ( .A0(n207), .A1(n102), .B0(n245), .B1(n198), .Y(n152) );
  OAI22X1 I274 ( .A0(n197), .A1(n102), .B0(n245), .B1(n207), .Y(n153) );
  OAI22X1 I275 ( .A0(n205), .A1(n102), .B0(n245), .B1(n197), .Y(n154) );
  OAI22X1 I276 ( .A0(n192), .A1(n102), .B0(n245), .B1(n208), .Y(n148) );
  OAI2BB2X1 I277 ( .A0N(RX_shift_bit), .A1N(n245), .B0(n245), .B1(n205), .Y(
        n155) );
  INVX2 I278 ( .A(n246), .Y(n112) );
  DFFRX1 TXBUF_reg_7_ ( .D(n189), .CK(clk_b), .RN(n244), .QN(n226) );
  DFFRHQX1 T2_uart_clk_delay0_reg ( .D(T2_uart_clk_delay), .CK(clk_b), .RN(
        n244), .Q(T2_uart_clk_delay0) );
  INVX1 I279 ( .A(SMOD1), .Y(n190) );
  OAI221X4 I280 ( .A0(n13), .A1(n212), .B0(n16), .B1(n199), .C0(n32), .Y(
        UART_SFR_OUT[1]) );
  OAI221X4 I281 ( .A0(n21), .A1(n193), .B0(n13), .B1(n213), .C0(n35), .Y(
        UART_SFR_OUT[0]) );
  OR3X2 I282 ( .A(even_state), .B(SMOD1_update), .C(SMOD1), .Y(n41) );
  INVX1 I283 ( .A(n42), .Y(n37) );
  OR2X2 I284 ( .A(TCLK), .B(Uart_mode2), .Y(n36) );
  AOI32X1 I285 ( .A0(T2_overflow_sel), .A1(TCLK), .A2(n40), .B0(Uart_mode2), 
        .B1(n41), .Y(n39) );
  OAI221X4 I286 ( .A0(n107), .A1(n63), .B0(n108), .B1(n40), .C0(n109), .Y(
        RX_clk) );
  INVX1 I287 ( .A(n41), .Y(n108) );
  INVX1 I288 ( .A(RCLK), .Y(n110) );
  OAI221X4 I289 ( .A0(n2), .A1(n194), .B0(n4), .B1(n215), .C0(n199), .Y(
        ua_intr) );
  INVX1 I290 ( .A(n4), .Y(n2) );
  OAI22X1 I291 ( .A0(n78), .A1(n235), .B0(n60), .B1(n204), .Y(n157) );
  OAI22X1 I292 ( .A0(n78), .A1(n236), .B0(n58), .B1(n204), .Y(n158) );
  OAI22X1 I293 ( .A0(n78), .A1(n238), .B0(n56), .B1(n204), .Y(n159) );
  OAI22X1 I294 ( .A0(n78), .A1(n239), .B0(n52), .B1(n204), .Y(n161) );
  OAI22X1 I295 ( .A0(n78), .A1(n237), .B0(n50), .B1(n204), .Y(n162) );
  OAI22X1 I296 ( .A0(n78), .A1(n240), .B0(n46), .B1(n204), .Y(n163) );
  OR2X2 I297 ( .A(scon_mode_1_), .B(SCON_TMP_6_), .Y(n63) );
  NAND2X1 I298 ( .A(n9), .B(n10), .Y(UART_SFR_OUT[7]) );
  OR2X2 I299 ( .A(RCLK), .B(TCLK), .Y(n7) );
  OAI2BB1X1 I300 ( .A0N(n70), .A1N(SFR_bus[2]), .B0(n72), .Y(n174) );
  INVX1 I301 ( .A(n73), .Y(n74) );
  INVX1 I302 ( .A(TX_shift_bit), .Y(n48) );
  OR2X2 U203 ( .A(set_TI), .B(n173), .Y(n130) );
  OAI22X1 I303 ( .A0(n70), .A1(n199), .B0(n60), .B1(n69), .Y(n173) );
  OR2X2 U204 ( .A(set_FE), .B(n138), .Y(n136) );
  AND2X2 U206 ( .A(n243), .B(n176), .Y(n132) );
  OAI22X1 I304 ( .A0(n70), .A1(n241), .B0(n54), .B1(n69), .Y(n176) );
  OAI221X4 I305 ( .A0(n13), .A1(n201), .B0(n216), .B1(n16), .C0(n17), .Y(
        UART_SFR_OUT[6]) );
  AOI22X1 I306 ( .A0(RXBUF[6]), .A1(SBUF_sel), .B0(SADDR[6]), .B1(SADDR_sel), 
        .Y(n17) );
  OAI221X4 I307 ( .A0(n13), .A1(n203), .B0(n16), .B1(n219), .C0(n20), .Y(
        UART_SFR_OUT[5]) );
  AOI22X1 I308 ( .A0(RXBUF[5]), .A1(SBUF_sel), .B0(SADDR[5]), .B1(SADDR_sel), 
        .Y(n20) );
  OAI221X4 I309 ( .A0(n13), .A1(n202), .B0(n16), .B1(n217), .C0(n27), .Y(
        UART_SFR_OUT[3]) );
  AOI22X1 I310 ( .A0(RXBUF[3]), .A1(SBUF_sel), .B0(SADDR[3]), .B1(SADDR_sel), 
        .Y(n27) );
  OAI221X4 I311 ( .A0(n13), .A1(n200), .B0(n16), .B1(n220), .C0(n30), .Y(
        UART_SFR_OUT[2]) );
  AOI22X1 I312 ( .A0(RXBUF[2]), .A1(SBUF_sel), .B0(SADDR[2]), .B1(SADDR_sel), 
        .Y(n30) );
  OAI221X4 I313 ( .A0(n21), .A1(n195), .B0(n13), .B1(n218), .C0(n24), .Y(
        UART_SFR_OUT[4]) );
  AOI22X1 I314 ( .A0(REN), .A1(SCON_sel), .B0(RXBUF[4]), .B1(SBUF_sel), .Y(n24) );
  INVX1 I315 ( .A(pr_st[1]), .Y(n123) );
  INVX1 I316 ( .A(pr_st[0]), .Y(n122) );
  OR2X2 I317 ( .A(SMOD1), .B(T1_overflow_div2), .Y(n42) );
  AND2X2 I318 ( .A(T1_overflow), .B(SCON_TMP_6_), .Y(n111) );
  OAI22X1 I319 ( .A0(n91), .A1(n200), .B0(n92), .B1(n212), .Y(n90) );
  XOR2X1 I320 ( .A(n196), .B(SADDR[2]), .Y(n91) );
  XOR2X1 I321 ( .A(n192), .B(SADDR[1]), .Y(n92) );
  OAI22X1 I322 ( .A0(n98), .A1(n221), .B0(n99), .B1(n201), .Y(n97) );
  XOR2X1 I323 ( .A(n205), .B(SADDR[7]), .Y(n98) );
  XOR2X1 I324 ( .A(n197), .B(SADDR[6]), .Y(n99) );
  AND2X2 I325 ( .A(n86), .B(n87), .Y(SADDR_match) );
  AND2X2 U201 ( .A(n180), .B(n190), .Y(n128) );
  AND3X2 I326 ( .A(n190), .B(n122), .C(n124), .Y(N51) );
  XOR2X1 I327 ( .A(pr_st[2]), .B(pr_st[1]), .Y(n124) );
  XOR2X1 I328 ( .A(SADDR[3]), .B(RX_shift_reg_3_), .Y(n88) );
  XOR2X1 I329 ( .A(SADDR[0]), .B(RX_shift_reg_0_), .Y(n95) );
  XOR2X1 I330 ( .A(SADDR[5]), .B(RX_shift_reg_5_), .Y(n89) );
  XOR2X1 I331 ( .A(SADDR[4]), .B(RX_shift_reg_4_), .Y(n96) );
  INVX1 I332 ( .A(T1_overflow), .Y(n38) );
  OAI22X1 I333 ( .A0(n208), .A1(n112), .B0(n246), .B1(n233), .Y(n140) );
  OAI22X1 I334 ( .A0(n192), .A1(n112), .B0(n246), .B1(n227), .Y(n141) );
  OAI22X1 I335 ( .A0(n196), .A1(n112), .B0(n246), .B1(n228), .Y(n142) );
  OAI22X1 I336 ( .A0(n206), .A1(n112), .B0(n246), .B1(n229), .Y(n143) );
  OAI22X1 I337 ( .A0(n198), .A1(n112), .B0(n246), .B1(n234), .Y(n144) );
  OAI22X1 I338 ( .A0(n207), .A1(n112), .B0(n246), .B1(n230), .Y(n145) );
  OAI22X1 I339 ( .A0(n197), .A1(n112), .B0(n246), .B1(n231), .Y(n146) );
  OAI22X1 I340 ( .A0(n205), .A1(n112), .B0(n246), .B1(n232), .Y(n147) );
  AND3X2 I341 ( .A(n7), .B(T2_uart_clk), .C(n63), .Y(T2_uart_clk_delay) );
  DFFRHQX1 even_state_reg ( .D(N51), .CK(clk_b), .RN(n243), .Q(even_state) );
  DFFRHQX1 T2_overflow_sel_reg ( .D(T2_uart_clk_delay2), .CK(clk_b), .RN(n244), 
        .Q(T2_overflow_sel) );
  DFFRX1 TXBUF_reg_0_ ( .D(n182), .CK(clk_b), .RN(n243), .Q(now_TX_bit), .QN(
        n181) );
endmodule


module timer2 ( POR, Z_update, T2MOD_T2OE, pr_st_0, Z2_S1, Z2_S2, sw_rst, 
        clk_b, SFR_wr, SFR_bus, T2CON_sel, T2MOD_sel, TH2_sel, TL2_sel, 
        RCAP2L_sel, RCAP2H_sel, pin_T2, pin_T2EX, T2_CLKOUT, t2_intr, 
        T2_uart_clk, RCLK, TCLK, T2_SFR_OUT );
  input [7:0] SFR_bus;
  output [7:0] T2_SFR_OUT;
  input POR, Z_update, pr_st_0, Z2_S1, Z2_S2, sw_rst, clk_b, SFR_wr, T2CON_sel,
         T2MOD_sel, TH2_sel, TL2_sel, RCAP2L_sel, RCAP2H_sel, pin_T2, pin_T2EX;
  output T2MOD_T2OE, T2_CLKOUT, t2_intr, T2_uart_clk, RCLK, TCLK;
  wire   T2CON_7_, T2CON_6_, T2CON_3_, T2CON_2_, T2CON_1_, T2CON_0_, T2MOD_0_,
         current_T2EX, before_T2, before_T2EX, clk_2, T2_flow_flag, set_EXF2,
         N54, N118, N119, N120, N121, N122, N123, N124, N125, N126, N127, N128,
         N129, N130, N131, N132, N133, N137, N138, N139, N140, N141, N142,
         N143, N144, N145, N146, N147, N148, N149, N150, N151, N152, N153, n9,
         n10, n13, n14, n16, n17, n21, n22, n25, n27, n28, n29, n30, n31, n32,
         n33, n34, n35, n36, n37, n38, n39, n40, n41, n42, n44, n45, n46, n47,
         n48, n49, n50, n51, n53, n540, n55, n56, n57, n58, n59, n60, n61, n62,
         n63, n64, n65, n66, n67, n68, n70, n72, n74, n75, n76, n77, n78, n79,
         n80, n81, n82, n84, n85, n86, n87, n88, n89, n90, n91, n92, n93, n98,
         n99, n100, n107, n108, n109, n115, n116, n117, n1180, n1250, n1280,
         n1310, n134, n1370, n1400, n1410, n1420, n1450, n1460, n1470, n1480,
         n1490, n1500, n157, n158, n159, n160, n162, n163, n168, n169, n170,
         n171, n172, n173, n174, n176, n177, n178, n180, n183, n185, n186,
         n187, n188, n189, n190, n191, n193, n194, n197, n198, n199, n201,
         n203, n204, n205, n206, n207, n208, n209, n210, n211, n212, n213,
         n214, n215, n216, n217, n218, n219, n220, n221, n222, n223, n224,
         n225, n226, n227, n228, n229, n230, n231, n232, n233, n234, n235,
         n236, n237, n238, n239, n240, n241, n242, n243, n244, n245, n246,
         n247, n248, n249, n250, n251, n252, n253, n254, n255, n256, n257,
         n258, n260, n261, n262, n263, n264, n265, n266, n267, n268, n269,
         n270, n271, n272, n273, n274, n275, n276, n277, n278, n279, n280,
         n281, n282, n283, n284, n285, n286, n287, n288, n289, n290, n291,
         n292, n293, n294, n295, n296, n297, n298, n299, n300, n301, n302,
         n303, n304, n305, n306, n307, n308, n309, n310, n311, n312, n313,
         n314, n315, n316, n317, n318, n319, n320, n321, n322, n323, n324;
  wire   [7:0] RCAP2L;
  wire   [7:0] RCAP2H;
  wire   [7:0] TL2;
  wire   [7:0] TH2;
  wire   SYNOPSYS_UNCONNECTED__0;

  OAI32X4 U4 ( .A0(n9), .A1(n260), .A2(n10), .B0(Z_update), .B1(n257), .Y(n258) );
  AOI32X4 U9 ( .A0(Z2_S2), .A1(n299), .A2(n16), .B0(set_EXF2), .B1(n17), .Y(
        n14) );
  AOI221X4 U19 ( .A0(N125), .A1(n319), .B0(N144), .B1(n316), .C0(n25), .Y(n22)
         );
  AOI222X4 U20 ( .A0(SFR_bus[7]), .A1(n317), .B0(RCAP2L[7]), .B1(n27), .C0(n28), .C1(TL2[7]), .Y(n21) );
  AOI221X4 U22 ( .A0(N124), .A1(n319), .B0(N143), .B1(n316), .C0(n25), .Y(n30)
         );
  AOI222X4 U23 ( .A0(SFR_bus[6]), .A1(n317), .B0(RCAP2L[6]), .B1(n27), .C0(n28), .C1(TL2[6]), .Y(n29) );
  AOI221X4 U25 ( .A0(N123), .A1(n319), .B0(N142), .B1(n316), .C0(n25), .Y(n32)
         );
  AOI222X4 U26 ( .A0(SFR_bus[5]), .A1(n317), .B0(RCAP2L[5]), .B1(n27), .C0(n28), .C1(TL2[5]), .Y(n31) );
  AOI221X4 U28 ( .A0(N122), .A1(n319), .B0(N141), .B1(n316), .C0(n25), .Y(n34)
         );
  AOI222X4 U29 ( .A0(SFR_bus[4]), .A1(n317), .B0(RCAP2L[4]), .B1(n27), .C0(n28), .C1(TL2[4]), .Y(n33) );
  AOI221X4 U31 ( .A0(N121), .A1(n319), .B0(N140), .B1(n316), .C0(n25), .Y(n36)
         );
  AOI222X4 U32 ( .A0(SFR_bus[3]), .A1(n317), .B0(RCAP2L[3]), .B1(n27), .C0(n28), .C1(TL2[3]), .Y(n35) );
  AOI221X4 U34 ( .A0(N120), .A1(n319), .B0(N139), .B1(n316), .C0(n25), .Y(n38)
         );
  AOI222X4 U35 ( .A0(SFR_bus[2]), .A1(n317), .B0(RCAP2L[2]), .B1(n27), .C0(n28), .C1(TL2[2]), .Y(n37) );
  AOI221X4 U37 ( .A0(N119), .A1(n319), .B0(N138), .B1(n316), .C0(n25), .Y(n40)
         );
  AOI222X4 U38 ( .A0(SFR_bus[1]), .A1(n317), .B0(RCAP2L[1]), .B1(n27), .C0(n28), .C1(TL2[1]), .Y(n39) );
  AOI221X4 U40 ( .A0(N118), .A1(n319), .B0(N137), .B1(n316), .C0(n25), .Y(n42)
         );
  AOI222X4 U41 ( .A0(SFR_bus[0]), .A1(n317), .B0(RCAP2L[0]), .B1(n27), .C0(n28), .C1(TL2[0]), .Y(n41) );
  OAI211X4 U45 ( .A0(n46), .A1(n47), .B0(n48), .C0(n49), .Y(n45) );
  AOI221X4 U47 ( .A0(N133), .A1(n319), .B0(N152), .B1(n316), .C0(n25), .Y(n51)
         );
  AOI222X4 U48 ( .A0(n318), .A1(SFR_bus[7]), .B0(RCAP2H[7]), .B1(n27), .C0(n53), .C1(TH2[7]), .Y(n50) );
  AOI221X4 U50 ( .A0(N132), .A1(n319), .B0(N151), .B1(n316), .C0(n25), .Y(n55)
         );
  AOI222X4 U51 ( .A0(n318), .A1(SFR_bus[6]), .B0(RCAP2H[6]), .B1(n27), .C0(n53), .C1(TH2[6]), .Y(n540) );
  AOI221X4 U53 ( .A0(N131), .A1(n319), .B0(N150), .B1(n316), .C0(n25), .Y(n57)
         );
  AOI222X4 U54 ( .A0(n318), .A1(SFR_bus[5]), .B0(RCAP2H[5]), .B1(n27), .C0(n53), .C1(TH2[5]), .Y(n56) );
  AOI221X4 U56 ( .A0(N130), .A1(n319), .B0(N149), .B1(n316), .C0(n25), .Y(n59)
         );
  AOI222X4 U57 ( .A0(n318), .A1(SFR_bus[4]), .B0(RCAP2H[4]), .B1(n27), .C0(n53), .C1(TH2[4]), .Y(n58) );
  AOI221X4 U59 ( .A0(N129), .A1(n319), .B0(N148), .B1(n316), .C0(n25), .Y(n61)
         );
  AOI222X4 U60 ( .A0(n318), .A1(SFR_bus[3]), .B0(RCAP2H[3]), .B1(n27), .C0(n53), .C1(TH2[3]), .Y(n60) );
  AOI221X4 U62 ( .A0(N128), .A1(n319), .B0(N147), .B1(n316), .C0(n25), .Y(n63)
         );
  AOI222X4 U63 ( .A0(n318), .A1(SFR_bus[2]), .B0(RCAP2H[2]), .B1(n27), .C0(n53), .C1(TH2[2]), .Y(n62) );
  AOI221X4 U65 ( .A0(N127), .A1(n319), .B0(N146), .B1(n316), .C0(n25), .Y(n65)
         );
  AOI222X4 U66 ( .A0(n318), .A1(SFR_bus[1]), .B0(RCAP2H[1]), .B1(n27), .C0(n53), .C1(TH2[1]), .Y(n64) );
  AOI221X4 U68 ( .A0(N126), .A1(n319), .B0(N145), .B1(n316), .C0(n25), .Y(n67)
         );
  AOI222X4 U74 ( .A0(n318), .A1(SFR_bus[0]), .B0(RCAP2H[0]), .B1(n27), .C0(n53), .C1(TH2[0]), .Y(n66) );
  OAI211X4 U80 ( .A0(n46), .A1(n76), .B0(n48), .C0(n49), .Y(n75) );
  OAI32X4 U83 ( .A0(n9), .A1(n78), .A2(n79), .B0(n80), .B1(n81), .Y(n27) );
  AOI222X4 U113 ( .A0(T2CON_sel), .A1(T2CON_7_), .B0(RCAP2H_sel), .B1(
        RCAP2H[7]), .C0(RCAP2L_sel), .C1(RCAP2L[7]), .Y(n1250) );
  AOI222X4 U115 ( .A0(T2CON_sel), .A1(T2CON_6_), .B0(RCAP2H_sel), .B1(
        RCAP2H[6]), .C0(RCAP2L_sel), .C1(RCAP2L[6]), .Y(n1280) );
  AOI222X4 U117 ( .A0(RCLK), .A1(T2CON_sel), .B0(RCAP2H_sel), .B1(RCAP2H[5]), 
        .C0(RCAP2L_sel), .C1(RCAP2L[5]), .Y(n1310) );
  AOI222X4 U119 ( .A0(TCLK), .A1(T2CON_sel), .B0(RCAP2H_sel), .B1(RCAP2H[4]), 
        .C0(RCAP2L_sel), .C1(RCAP2L[4]), .Y(n134) );
  AOI222X4 U121 ( .A0(T2CON_sel), .A1(T2CON_3_), .B0(RCAP2H_sel), .B1(
        RCAP2H[3]), .C0(RCAP2L_sel), .C1(RCAP2L[3]), .Y(n1370) );
  AOI222X4 U123 ( .A0(T2CON_sel), .A1(T2CON_2_), .B0(RCAP2H_sel), .B1(
        RCAP2H[2]), .C0(RCAP2L_sel), .C1(RCAP2L[2]), .Y(n1400) );
  OAI222X4 U125 ( .A0(n293), .A1(n76), .B0(n279), .B1(n47), .C0(n266), .C1(
        n1450), .Y(n1420) );
  OAI222X4 U126 ( .A0(n291), .A1(n1460), .B0(n277), .B1(n1470), .C0(n265), 
        .C1(n1480), .Y(n1410) );
  OAI222X4 U128 ( .A0(n292), .A1(n76), .B0(n268), .B1(n1450), .C0(n278), .C1(
        n47), .Y(n1500) );
  OAI222X4 U131 ( .A0(n290), .A1(n1460), .B0(n276), .B1(n1470), .C0(n267), 
        .C1(n1480), .Y(n1490) );
  AOI221X4 U135 ( .A0(T2CON_1_), .A1(n266), .B0(T2_CLKOUT), .B1(T2CON_1_), 
        .C0(n158), .Y(n157) );
  OAI32X4 U152 ( .A0(n169), .A1(sw_rst), .A2(n170), .B0(n171), .B1(n266), .Y(
        n233) );
  OAI32X4 U154 ( .A0(n169), .A1(sw_rst), .A2(n172), .B0(n171), .B1(n268), .Y(
        n232) );
  OAI222X4 U161 ( .A0(n176), .A1(n288), .B0(n173), .B1(n177), .C0(n178), .C1(
        n314), .Y(n230) );
  OAI222X4 U183 ( .A0(n306), .A1(n188), .B0(n269), .B1(n189), .C0(n174), .C1(
        n190), .Y(n223) );
  OAI222X4 U186 ( .A0(n305), .A1(n188), .B0(n275), .B1(n189), .C0(n176), .C1(
        n190), .Y(n222) );
  OAI222X4 U189 ( .A0(n304), .A1(n188), .B0(n274), .B1(n189), .C0(n183), .C1(
        n190), .Y(n221) );
  OAI222X4 U192 ( .A0(n303), .A1(n188), .B0(n273), .B1(n189), .C0(n185), .C1(
        n190), .Y(n220) );
  OAI222X4 U195 ( .A0(n302), .A1(n188), .B0(n272), .B1(n189), .C0(n186), .C1(
        n190), .Y(n219) );
  OAI222X4 U198 ( .A0(n301), .A1(n188), .B0(n271), .B1(n189), .C0(n187), .C1(
        n190), .Y(n218) );
  OAI222X4 U201 ( .A0(n291), .A1(n188), .B0(n279), .B1(n189), .C0(n170), .C1(
        n190), .Y(n217) );
  OAI222X4 U204 ( .A0(n290), .A1(n188), .B0(n278), .B1(n189), .C0(n172), .C1(
        n190), .Y(n216) );
  OAI222X4 U210 ( .A0(n309), .A1(n193), .B0(n281), .B1(n189), .C0(n174), .C1(
        n194), .Y(n215) );
  OAI222X4 U214 ( .A0(n308), .A1(n193), .B0(n287), .B1(n189), .C0(n176), .C1(
        n194), .Y(n214) );
  OAI222X4 U218 ( .A0(n298), .A1(n193), .B0(n286), .B1(n189), .C0(n183), .C1(
        n194), .Y(n213) );
  OAI222X4 U222 ( .A0(n297), .A1(n193), .B0(n285), .B1(n189), .C0(n185), .C1(
        n194), .Y(n212) );
  OAI222X4 U226 ( .A0(n296), .A1(n193), .B0(n284), .B1(n189), .C0(n186), .C1(
        n194), .Y(n211) );
  OAI222X4 U230 ( .A0(n307), .A1(n193), .B0(n283), .B1(n189), .C0(n187), .C1(
        n194), .Y(n210) );
  OAI222X4 U234 ( .A0(n277), .A1(n193), .B0(n293), .B1(n189), .C0(n170), .C1(
        n194), .Y(n209) );
  OAI222X4 U238 ( .A0(n276), .A1(n193), .B0(n292), .B1(n189), .C0(n172), .C1(
        n194), .Y(n208) );
  OAI33X4 U253 ( .A0(n197), .A1(n198), .A2(n300), .B0(n199), .B1(T2CON_1_), 
        .B2(n198), .Y(N54) );
  NAND2BX1 I269 ( .AN(n162), .B(T2CON_2_), .Y(n77) );
  NAND2X1 I270 ( .A(before_T2EX), .B(T2CON_3_), .Y(n79) );
  AND3X2 I271 ( .A(n70), .B(n84), .C(n85), .Y(n261) );
  INVX1 I272 ( .A(n261), .Y(n68) );
  INVX1 I273 ( .A(n72), .Y(n70) );
  NAND3X1 I274 ( .A(N153), .B(n262), .C(n72), .Y(n81) );
  INVX1 I275 ( .A(n77), .Y(n262) );
  NAND4X1 I276 ( .A(n267), .B(T2MOD_0_), .C(n312), .D(n311), .Y(n13) );
  MX2X1 I277 ( .S0(n9), .B(clk_2), .A(Z2_S1), .Y(n159) );
  NAND2X1 I278 ( .A(n312), .B(n311), .Y(n168) );
  OAI21X1 I279 ( .A0(T2_CLKOUT), .A1(n81), .B0(n157), .Y(n234) );
  NOR2X1 I280 ( .A(n289), .B(n295), .Y(n16) );
  AND4X2 I281 ( .A(T2CON_3_), .B(Z2_S1), .C(n299), .D(before_T2EX), .Y(n315)
         );
  NOR2BX1 I282 ( .AN(n180), .B(n13), .Y(n178) );
  NAND2X1 I283 ( .A(Z2_S2), .B(T2CON_1_), .Y(n197) );
  AND2X2 I284 ( .A(n45), .B(n263), .Y(n317) );
  INVX1 I285 ( .A(n44), .Y(n263) );
  NAND2X1 I286 ( .A(SFR_wr), .B(T2MOD_sel), .Y(n169) );
  NAND2X1 I287 ( .A(T2CON_2_), .B(T2_flow_flag), .Y(n10) );
  AND2X2 I288 ( .A(n75), .B(n264), .Y(n318) );
  INVX1 I289 ( .A(n44), .Y(n264) );
  NAND2X1 I290 ( .A(N153), .B(clk_2), .Y(n199) );
  AOI32X1 I291 ( .A0(Z2_S1), .A1(before_T2), .A2(n163), .B0(n159), .B1(n265), 
        .Y(n162) );
  INVX4 I292 ( .A(sw_rst), .Y(n324) );
  INVX4 I293 ( .A(sw_rst), .Y(n323) );
  DFFRX1 T2CON_reg_1_ ( .D(n225), .CK(clk_b), .RN(n324), .Q(T2CON_1_), .QN(
        n265) );
  DFFRX1 T2MOD_reg_1_ ( .D(n205), .CK(clk_b), .RN(n201), .Q(T2MOD_T2OE), .QN(
        n266) );
  DFFRX2 TL2_reg_7_ ( .D(n251), .CK(clk_b), .RN(n324), .Q(TL2[7]), .QN(n269)
         );
  DFFRX2 TL2_reg_2_ ( .D(n246), .CK(clk_b), .RN(n324), .Q(TL2[2]), .QN(n271)
         );
  DFFRX2 TL2_reg_3_ ( .D(n247), .CK(clk_b), .RN(n324), .Q(TL2[3]), .QN(n272)
         );
  DFFRX2 TL2_reg_4_ ( .D(n248), .CK(clk_b), .RN(n324), .Q(TL2[4]), .QN(n273)
         );
  DFFRX2 TL2_reg_5_ ( .D(n249), .CK(clk_b), .RN(n323), .Q(TL2[5]), .QN(n274)
         );
  DFFRX2 TL2_reg_6_ ( .D(n250), .CK(clk_b), .RN(n324), .Q(TL2[6]), .QN(n275)
         );
  DFFRX2 TL2_reg_0_ ( .D(n244), .CK(clk_b), .RN(n324), .Q(TL2[0]), .QN(n278)
         );
  DFFRX2 TL2_reg_1_ ( .D(n245), .CK(clk_b), .RN(n323), .Q(TL2[1]), .QN(n279)
         );
  DFFRX2 TH2_reg_7_ ( .D(n243), .CK(clk_b), .RN(n324), .Q(TH2[7]), .QN(n281)
         );
  DFFRX2 TH2_reg_2_ ( .D(n238), .CK(clk_b), .RN(n324), .Q(TH2[2]), .QN(n283)
         );
  DFFRX2 TH2_reg_3_ ( .D(n239), .CK(clk_b), .RN(n324), .Q(TH2[3]), .QN(n284)
         );
  DFFRX2 TH2_reg_4_ ( .D(n240), .CK(clk_b), .RN(n324), .Q(TH2[4]), .QN(n285)
         );
  DFFRX2 TH2_reg_5_ ( .D(n241), .CK(clk_b), .RN(n324), .Q(TH2[5]), .QN(n286)
         );
  DFFRX2 TH2_reg_6_ ( .D(n242), .CK(clk_b), .RN(n324), .Q(TH2[6]), .QN(n287)
         );
  OR2X2 I294 ( .A(n46), .B(n1480), .Y(n288) );
  DFFRX2 TH2_reg_0_ ( .D(n236), .CK(clk_b), .RN(n324), .Q(TH2[0]), .QN(n292)
         );
  DFFRX2 TH2_reg_1_ ( .D(n237), .CK(clk_b), .RN(n324), .Q(TH2[1]), .QN(n293)
         );
  DFFSX1 current_T2EX_reg ( .D(n254), .CK(clk_b), .SN(n323), .Q(current_T2EX), 
        .QN(n299) );
  DFFRX1 T2_flow_flag_reg ( .D(n207), .CK(clk_b), .RN(n323), .Q(T2_flow_flag), 
        .QN(n300) );
  DFFRX1 T2CON_reg_4_ ( .D(n228), .CK(clk_b), .RN(n324), .Q(TCLK), .QN(n311)
         );
  DFFRX1 T2CON_reg_5_ ( .D(n229), .CK(clk_b), .RN(n324), .Q(RCLK), .QN(n312)
         );
  NAND2BX2 I295 ( .AN(n191), .B(n188), .Y(n190) );
  NAND2BX2 I296 ( .AN(n191), .B(n193), .Y(n194) );
  INVX2 I297 ( .A(TL2_sel), .Y(n47) );
  NOR2X4 I298 ( .A(n70), .B(n49), .Y(n316) );
  INVX2 I299 ( .A(TH2_sel), .Y(n76) );
  DFFRHQX1 clk_2_reg ( .D(pr_st_0), .CK(clk_b), .RN(n323), .Q(clk_2) );
  INVX2 I300 ( .A(n288), .Y(n173) );
  NAND2BX4 I301 ( .AN(n82), .B(n315), .Y(n189) );
  NOR2X4 I302 ( .A(n72), .B(n49), .Y(n319) );
  INVX1 I303 ( .A(n169), .Y(n171) );
  INVX1 I304 ( .A(T2CON_sel), .Y(n1480) );
  INVX1 I305 ( .A(T2MOD_sel), .Y(n1450) );
  INVX1 I306 ( .A(RCAP2L_sel), .Y(n1460) );
  INVX1 I307 ( .A(RCAP2H_sel), .Y(n1470) );
  DFFRX1 T2CON_reg_0_ ( .D(n224), .CK(clk_b), .RN(n324), .Q(T2CON_0_), .QN(
        n267) );
  DFFRX1 RCAP2H_reg_0_ ( .D(n208), .CK(clk_b), .RN(n324), .Q(RCAP2H[0]), .QN(
        n276) );
  DFFRX1 RCAP2H_reg_1_ ( .D(n209), .CK(clk_b), .RN(n323), .Q(RCAP2H[1]), .QN(
        n277) );
  DFFRX1 RCAP2L_reg_0_ ( .D(n216), .CK(clk_b), .RN(n323), .Q(RCAP2L[0]), .QN(
        n290) );
  DFFRX1 RCAP2L_reg_1_ ( .D(n217), .CK(clk_b), .RN(n324), .Q(RCAP2L[1]), .QN(
        n291) );
  INVX1 I308 ( .A(SFR_bus[1]), .Y(n170) );
  INVX2 I309 ( .A(n75), .Y(n53) );
  INVX2 I310 ( .A(n45), .Y(n28) );
  INVX1 I311 ( .A(SFR_bus[3]), .Y(n186) );
  INVX1 I312 ( .A(SFR_bus[2]), .Y(n187) );
  INVX1 I313 ( .A(SFR_bus[4]), .Y(n185) );
  INVX1 I314 ( .A(SFR_bus[5]), .Y(n183) );
  INVX1 I315 ( .A(SFR_bus[7]), .Y(n174) );
  INVX1 I316 ( .A(SFR_bus[6]), .Y(n176) );
  DFFRX1 RCAP2L_reg_7_ ( .D(n223), .CK(clk_b), .RN(n323), .Q(RCAP2L[7]), .QN(
        n306) );
  DFFRX1 RCAP2H_reg_7_ ( .D(n215), .CK(clk_b), .RN(n323), .Q(RCAP2H[7]), .QN(
        n309) );
  DFFRX1 T2CON_reg_3_ ( .D(n227), .CK(clk_b), .RN(n324), .Q(T2CON_3_), .QN(
        n295) );
  DFFRX1 T2CON_reg_2_ ( .D(n226), .CK(clk_b), .RN(n324), .Q(T2CON_2_), .QN(
        n270) );
  DFFRX1 RCAP2L_reg_2_ ( .D(n218), .CK(clk_b), .RN(n323), .Q(RCAP2L[2]), .QN(
        n301) );
  DFFRX1 RCAP2L_reg_3_ ( .D(n219), .CK(clk_b), .RN(n323), .Q(RCAP2L[3]), .QN(
        n302) );
  DFFRX1 RCAP2L_reg_4_ ( .D(n220), .CK(clk_b), .RN(n323), .Q(RCAP2L[4]), .QN(
        n303) );
  DFFRX1 RCAP2L_reg_5_ ( .D(n221), .CK(clk_b), .RN(n323), .Q(RCAP2L[5]), .QN(
        n304) );
  DFFRX1 RCAP2L_reg_6_ ( .D(n222), .CK(clk_b), .RN(n324), .Q(RCAP2L[6]), .QN(
        n305) );
  DFFRX1 RCAP2H_reg_2_ ( .D(n210), .CK(clk_b), .RN(n324), .Q(RCAP2H[2]), .QN(
        n307) );
  DFFRX1 RCAP2H_reg_3_ ( .D(n211), .CK(clk_b), .RN(n323), .Q(RCAP2H[3]), .QN(
        n296) );
  DFFRX1 RCAP2H_reg_4_ ( .D(n212), .CK(clk_b), .RN(n324), .Q(RCAP2H[4]), .QN(
        n297) );
  DFFRX1 RCAP2H_reg_5_ ( .D(n213), .CK(clk_b), .RN(n323), .Q(RCAP2H[5]), .QN(
        n298) );
  DFFRX1 RCAP2H_reg_6_ ( .D(n214), .CK(clk_b), .RN(n323), .Q(RCAP2H[6]), .QN(
        n308) );
  DFFSX1 before_T2EX_reg ( .D(n252), .CK(clk_b), .SN(n323), .Q(before_T2EX), 
        .QN(n289) );
  INVX4 I317 ( .A(n68), .Y(n25) );
  INVX1 I318 ( .A(SFR_wr), .Y(n46) );
  OR2X2 I319 ( .A(n1490), .B(n1500), .Y(T2_SFR_OUT[0]) );
  OR2X2 I320 ( .A(n1410), .B(n1420), .Y(T2_SFR_OUT[1]) );
  OAI22X1 I321 ( .A0(n173), .A1(n270), .B0(n187), .B1(n288), .Y(n226) );
  OAI22X1 I322 ( .A0(n173), .A1(n295), .B0(n186), .B1(n288), .Y(n227) );
  DFFRX1 T2MOD_reg_0_ ( .D(n204), .CK(clk_b), .RN(n201), .Q(T2MOD_0_), .QN(
        n268) );
  OR2X2 I323 ( .A(n77), .B(n27), .Y(n49) );
  DFFRX1 T2CON_reg_6_ ( .D(n230), .CK(clk_b), .RN(n324), .Q(T2CON_6_), .QN(
        n280) );
  DFFRX1 T2CON_reg_7_ ( .D(n203), .CK(clk_b), .RN(n324), .Q(T2CON_7_), .QN(
        n294) );
  OR2X2 I324 ( .A(n74), .B(n27), .Y(n44) );
  INVX1 I325 ( .A(n49), .Y(n74) );
  INVX1 I326 ( .A(n27), .Y(n48) );
  AND2X2 U266 ( .A(n232), .B(n323), .Y(n204) );
  AND2X2 U267 ( .A(n323), .B(n233), .Y(n205) );
  OAI22X1 I327 ( .A0(n173), .A1(n267), .B0(n172), .B1(n288), .Y(n224) );
  OAI22X1 I328 ( .A0(n265), .A1(n173), .B0(n170), .B1(n288), .Y(n225) );
  DFFSX1 before_T2_reg ( .D(n253), .CK(clk_b), .SN(n323), .Q(before_T2), .QN(
        n313) );
  DFFSX1 current_T2_reg ( .D(n255), .CK(clk_b), .SN(n323), .QN(n282) );
  AND2X1 U268 ( .A(n235), .B(n260), .Y(n207) );
  OAI211X1 I329 ( .A0(n84), .A1(n300), .B0(n81), .C0(n68), .Y(n235) );
  OAI2BB1X2 I330 ( .A0N(RCAP2H_sel), .A1N(SFR_wr), .B0(n189), .Y(n193) );
  OAI2BB1X2 I331 ( .A0N(RCAP2L_sel), .A1N(SFR_wr), .B0(n189), .Y(n188) );
  AND4X2 I332 ( .A(n86), .B(n87), .C(n88), .D(n89), .Y(n85) );
  AND3X2 I333 ( .A(n98), .B(n99), .C(n100), .Y(n88) );
  AND4X2 I334 ( .A(n115), .B(n116), .C(n117), .D(n1180), .Y(n86) );
  OR2X2 I335 ( .A(n168), .B(n267), .Y(n82) );
  INVX1 I336 ( .A(n77), .Y(n84) );
  INVX1 I337 ( .A(Z2_S2), .Y(n260) );
  DFFSX1 T2_CLKOUT_reg ( .D(n206), .CK(clk_b), .SN(n323), .Q(T2_CLKOUT), .QN(
        n310) );
  INVX1 I338 ( .A(n189), .Y(n191) );
  OAI22X1 I339 ( .A0(n260), .A1(n299), .B0(Z2_S2), .B1(n289), .Y(n252) );
  DFFRX1 set_EXF2_reg ( .D(n256), .CK(clk_b), .RN(n323), .Q(set_EXF2), .QN(
        n314) );
  OAI221X4 I340 ( .A0(n281), .A1(n76), .B0(n269), .B1(n47), .C0(n1250), .Y(
        T2_SFR_OUT[7]) );
  OR3X2 I341 ( .A(T2CON_0_), .B(T2MOD_0_), .C(current_T2EX), .Y(n78) );
  INVX1 I342 ( .A(n82), .Y(n80) );
  OAI22X1 I343 ( .A0(n173), .A1(n311), .B0(n185), .B1(n288), .Y(n228) );
  OAI22X1 I344 ( .A0(n173), .A1(n312), .B0(n183), .B1(n288), .Y(n229) );
  OAI221X4 I345 ( .A0(T2MOD_0_), .A1(n280), .B0(n280), .B1(n266), .C0(n294), 
        .Y(t2_intr) );
  NAND2BX1 U264 ( .AN(n231), .B(n257), .Y(n203) );
  OAI22X1 I346 ( .A0(n173), .A1(n294), .B0(n174), .B1(n288), .Y(n231) );
  NAND2X1 I347 ( .A(n66), .B(n67), .Y(n236) );
  NAND2X1 I348 ( .A(n64), .B(n65), .Y(n237) );
  NAND2X1 I349 ( .A(n62), .B(n63), .Y(n238) );
  NAND2X1 I350 ( .A(n60), .B(n61), .Y(n239) );
  NAND2X1 I351 ( .A(n58), .B(n59), .Y(n240) );
  NAND2X1 I352 ( .A(n56), .B(n57), .Y(n241) );
  NAND2X1 I353 ( .A(n540), .B(n55), .Y(n242) );
  NAND2X1 I354 ( .A(n50), .B(n51), .Y(n243) );
  NAND2X1 I355 ( .A(n39), .B(n40), .Y(n245) );
  NAND2X1 I356 ( .A(n37), .B(n38), .Y(n246) );
  NAND2X1 I357 ( .A(n35), .B(n36), .Y(n247) );
  NAND2X1 I358 ( .A(n33), .B(n34), .Y(n248) );
  NAND2X1 I359 ( .A(n31), .B(n32), .Y(n249) );
  NAND2X1 I360 ( .A(n29), .B(n30), .Y(n250) );
  NAND2X1 I361 ( .A(n21), .B(n22), .Y(n251) );
  NAND2X1 I362 ( .A(n41), .B(n42), .Y(n244) );
  OR2X2 I363 ( .A(set_EXF2), .B(n280), .Y(n177) );
  OAI221X4 I364 ( .A0(n287), .A1(n76), .B0(n275), .B1(n47), .C0(n1280), .Y(
        T2_SFR_OUT[6]) );
  OAI221X4 I365 ( .A0(n284), .A1(n76), .B0(n272), .B1(n47), .C0(n1370), .Y(
        T2_SFR_OUT[3]) );
  OAI221X4 I366 ( .A0(n283), .A1(n76), .B0(n271), .B1(n47), .C0(n1400), .Y(
        T2_SFR_OUT[2]) );
  AND2X2 I367 ( .A(T2CON_1_), .B(n282), .Y(n163) );
  OR2X2 I368 ( .A(T2MOD_T2OE), .B(n168), .Y(n9) );
  NAND3BX1 U265 ( .AN(n234), .B(T2MOD_T2OE), .C(n265), .Y(n206) );
  OAI221X4 I369 ( .A0(n286), .A1(n76), .B0(n274), .B1(n47), .C0(n1310), .Y(
        T2_SFR_OUT[5]) );
  OAI221X4 I370 ( .A0(n285), .A1(n76), .B0(n273), .B1(n47), .C0(n134), .Y(
        T2_SFR_OUT[4]) );
  AOI211X1 I371 ( .A0(n159), .A1(n160), .B0(n310), .C0(n266), .Y(n158) );
  AND3X2 I372 ( .A(N153), .B(T2CON_2_), .C(n72), .Y(n160) );
  OR2X2 I373 ( .A(current_T2EX), .B(n13), .Y(n72) );
  INVX1 I374 ( .A(n168), .Y(n198) );
  AND4X2 I375 ( .A(n90), .B(n91), .C(n92), .D(n93), .Y(n89) );
  XOR2X1 I376 ( .A(n308), .B(TH2[6]), .Y(n90) );
  XOR2X1 I377 ( .A(n298), .B(TH2[5]), .Y(n91) );
  XOR2X1 I378 ( .A(n297), .B(TH2[4]), .Y(n92) );
  NOR3X1 I379 ( .A(n320), .B(n321), .C(n322), .Y(n87) );
  XNOR2X1 I380 ( .A(n302), .B(TL2[3]), .Y(n320) );
  XNOR2X1 I381 ( .A(n301), .B(TL2[2]), .Y(n321) );
  NAND3X1 I382 ( .A(n107), .B(n108), .C(n109), .Y(n322) );
  XOR2X1 I383 ( .A(n296), .B(TH2[3]), .Y(n93) );
  XOR2X1 I384 ( .A(n290), .B(TL2[0]), .Y(n109) );
  XOR2X1 I385 ( .A(n291), .B(TL2[1]), .Y(n108) );
  XOR2X1 I386 ( .A(n309), .B(TH2[7]), .Y(n107) );
  OAI31X1 I387 ( .A0(n13), .A1(n260), .A2(n270), .B0(n14), .Y(n256) );
  INVX1 I388 ( .A(Z_update), .Y(n17) );
  XOR2X1 I389 ( .A(n303), .B(TL2[4]), .Y(n1180) );
  XOR2X1 I390 ( .A(n304), .B(TL2[5]), .Y(n117) );
  XOR2X1 I391 ( .A(n305), .B(TL2[6]), .Y(n116) );
  XOR2X1 I392 ( .A(n306), .B(TL2[7]), .Y(n115) );
  XOR2X1 I393 ( .A(n276), .B(TH2[0]), .Y(n100) );
  XOR2X1 I394 ( .A(n277), .B(TH2[1]), .Y(n99) );
  XOR2X1 I395 ( .A(n307), .B(TH2[2]), .Y(n98) );
  XOR2X1 I396 ( .A(n280), .B(T2_flow_flag), .Y(n180) );
  OAI22X1 I397 ( .A0(n260), .A1(n282), .B0(Z2_S2), .B1(n313), .Y(n253) );
  OAI2BB2X1 I398 ( .A0N(pin_T2EX), .A1N(Z2_S2), .B0(Z2_S2), .B1(n299), .Y(n254) );
  OAI2BB2X1 I399 ( .A0N(pin_T2), .A1N(Z2_S2), .B0(Z2_S2), .B1(n282), .Y(n255)
         );
  INVX1 I400 ( .A(POR), .Y(n201) );
  DFFRHQX1 T2_uart_clk_reg ( .D(N54), .CK(clk_b), .RN(n323), .Q(T2_uart_clk)
         );
  DFFRX1 set_TF2_reg ( .D(n258), .CK(clk_b), .RN(n323), .QN(n257) );
  INVX1 I401 ( .A(SFR_bus[0]), .Y(n172) );
  timer2_DW01_inc_17_0 add_332 ( .A({1'b0, TH2, TL2}), .SUM({N153, N152, N151, 
        N150, N149, N148, N147, N146, N145, N144, N143, N142, N141, N140, N139, 
        N138, N137}) );
  timer2_DW01_dec_17_0 sub_332 ( .A({1'b0, TH2, TL2}), .SUM({
        SYNOPSYS_UNCONNECTED__0, N133, N132, N131, N130, N129, N128, N127, 
        N126, N125, N124, N123, N122, N121, N120, N119, N118}) );
  DFFRX4 T2CON_CT2_d_reg ( .D(T2CON_1_), .CK(clk_b), .RN(n323) );
endmodule


module timer2_DW01_dec_17_0 ( A, SUM );
  input [16:0] A;
  output [16:0] SUM;
  wire   carry_15_, carry_14_, carry_13_, carry_12_, carry_11_, carry_10_,
         carry_9_, carry_8_, carry_7_, carry_6_, carry_5_, carry_4_, carry_3_,
         carry_2_;

  XNOR2X1 U1_A_8 ( .A(A[8]), .B(carry_8_), .Y(SUM[8]) );
  XNOR2X1 U1_A_9 ( .A(A[9]), .B(carry_9_), .Y(SUM[9]) );
  XNOR2X1 U1_A_10 ( .A(A[10]), .B(carry_10_), .Y(SUM[10]) );
  XNOR2X1 U1_A_11 ( .A(A[11]), .B(carry_11_), .Y(SUM[11]) );
  XNOR2X1 U1_A_12 ( .A(A[12]), .B(carry_12_), .Y(SUM[12]) );
  XNOR2X1 U1_A_13 ( .A(A[13]), .B(carry_13_), .Y(SUM[13]) );
  XNOR2X1 U1_A_14 ( .A(A[14]), .B(carry_14_), .Y(SUM[14]) );
  XNOR2X1 U1_A_15 ( .A(A[15]), .B(carry_15_), .Y(SUM[15]) );
  XNOR2X1 U1_A_1 ( .A(A[1]), .B(A[0]), .Y(SUM[1]) );
  XNOR2X1 U1_A_2 ( .A(A[2]), .B(carry_2_), .Y(SUM[2]) );
  XNOR2X1 U1_A_3 ( .A(A[3]), .B(carry_3_), .Y(SUM[3]) );
  XNOR2X1 U1_A_4 ( .A(A[4]), .B(carry_4_), .Y(SUM[4]) );
  XNOR2X1 U1_A_5 ( .A(A[5]), .B(carry_5_), .Y(SUM[5]) );
  XNOR2X1 U1_A_6 ( .A(A[6]), .B(carry_6_), .Y(SUM[6]) );
  XNOR2X1 U1_A_7 ( .A(A[7]), .B(carry_7_), .Y(SUM[7]) );
  OR2X2 U1_B_1 ( .A(A[1]), .B(A[0]), .Y(carry_2_) );
  OR2X2 U1_B_7 ( .A(A[7]), .B(carry_7_), .Y(carry_8_) );
  OR2X2 U1_B_8 ( .A(A[8]), .B(carry_8_), .Y(carry_9_) );
  OR2X2 U1_B_9 ( .A(A[9]), .B(carry_9_), .Y(carry_10_) );
  OR2X2 U1_B_10 ( .A(A[10]), .B(carry_10_), .Y(carry_11_) );
  OR2X2 U1_B_11 ( .A(A[11]), .B(carry_11_), .Y(carry_12_) );
  OR2X2 U1_B_12 ( .A(A[12]), .B(carry_12_), .Y(carry_13_) );
  OR2X2 U1_B_13 ( .A(A[13]), .B(carry_13_), .Y(carry_14_) );
  OR2X2 U1_B_2 ( .A(A[2]), .B(carry_2_), .Y(carry_3_) );
  OR2X2 U1_B_3 ( .A(A[3]), .B(carry_3_), .Y(carry_4_) );
  OR2X2 U1_B_4 ( .A(A[4]), .B(carry_4_), .Y(carry_5_) );
  OR2X2 U1_B_5 ( .A(A[5]), .B(carry_5_), .Y(carry_6_) );
  OR2X2 U1_B_6 ( .A(A[6]), .B(carry_6_), .Y(carry_7_) );
  OR2X2 U1_B_14 ( .A(A[14]), .B(carry_14_), .Y(carry_15_) );
  INVX1 U6 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module timer2_DW01_inc_17_0 ( A, SUM );
  input [16:0] A;
  output [16:0] SUM;
  wire   carry_15_, carry_14_, carry_13_, carry_12_, carry_11_, carry_10_,
         carry_9_, carry_8_, carry_7_, carry_6_, carry_5_, carry_4_, carry_3_,
         carry_2_;

  CMPR22X1 U1_1_14 ( .A(A[14]), .B(carry_14_), .S(SUM[14]), .CO(carry_15_) );
  CMPR22X1 U1_1_15 ( .A(A[15]), .B(carry_15_), .S(SUM[15]), .CO(SUM[16]) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(carry_5_) );
  CMPR22X1 U1_1_5 ( .A(A[5]), .B(carry_5_), .S(SUM[5]), .CO(carry_6_) );
  CMPR22X1 U1_1_6 ( .A(A[6]), .B(carry_6_), .S(SUM[6]), .CO(carry_7_) );
  CMPR22X1 U1_1_7 ( .A(A[7]), .B(carry_7_), .S(SUM[7]), .CO(carry_8_) );
  CMPR22X1 U1_1_8 ( .A(A[8]), .B(carry_8_), .S(SUM[8]), .CO(carry_9_) );
  CMPR22X1 U1_1_9 ( .A(A[9]), .B(carry_9_), .S(SUM[9]), .CO(carry_10_) );
  CMPR22X1 U1_1_10 ( .A(A[10]), .B(carry_10_), .S(SUM[10]), .CO(carry_11_) );
  CMPR22X1 U1_1_11 ( .A(A[11]), .B(carry_11_), .S(SUM[11]), .CO(carry_12_) );
  CMPR22X1 U1_1_12 ( .A(A[12]), .B(carry_12_), .S(SUM[12]), .CO(carry_13_) );
  CMPR22X1 U1_1_13 ( .A(A[13]), .B(carry_13_), .S(SUM[13]), .CO(carry_14_) );
  INVX1 U5 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module timer01 ( Z_update, Z0_S1, Z0_S2, Z0_S5, Z0_S6, Z1_S1, Z1_S2, Z1_S4, 
        Z1_S5, Z1_S6, sw_rst, clk_b, SFR_wr, SFR_bus, TH0_sel, TL0_sel, 
        TH1_sel, TL1_sel, TCON_sel, TMOD_sel, clear_TF0, clear_TF1, pin_T0, 
        pin_T1, sample_INT0, sample_INT1, TCON30, TF0, TF1, T1_overflow, 
        T01_SFR_OUT );
  input [7:0] SFR_bus;
  input [3:0] TCON30;
  output [7:0] T01_SFR_OUT;
  input Z_update, Z0_S1, Z0_S2, Z0_S5, Z0_S6, Z1_S1, Z1_S2, Z1_S4, Z1_S5,
         Z1_S6, sw_rst, clk_b, SFR_wr, TH0_sel, TL0_sel, TH1_sel, TL1_sel,
         TCON_sel, TMOD_sel, clear_TF0, clear_TF1, pin_T0, pin_T1, sample_INT0,
         sample_INT1;
  output TF0, TF1, T1_overflow;
  wire   set_TF0, set_TF1, TR0, TR1, TH0_carry, T0_mode3, n2, n3, n5, n6, n7,
         n8, n9, n10, n11, n12, n16, n17;
  wire   [7:0] TH0_TL0_OUT;
  wire   [7:0] TH1_TL1_OUT;
  wire   [7:0] TCON_TMOD_OUT;
  wire   [7:0] TMOD;

  t01_control t01_control ( .sw_rst(sw_rst), .clk_b(clk_b), .TCON_sel(TCON_sel), .TMOD_sel(TMOD_sel), .SFR_wr(SFR_wr), .SFR_bus(SFR_bus), .clear_TF0(
        clear_TF0), .clear_TF1(clear_TF1), .set_TF0(set_TF0), .set_TF1(set_TF1), .TCON30(TCON30), .TF0(TF0), .TF1(TF1), .TR0(TR0), .TR1(TR1), .TCON_TMOD_OUT(
        TCON_TMOD_OUT), .TMOD(TMOD) );
  timer0 timer0 ( .Z_update(Z_update), .Z_S1(Z0_S1), .Z_S2(Z0_S2), .Z_S5(Z0_S5), .Z_S6(Z0_S6), .sw_rst(sw_rst), .clk_b(clk_b), .SFR_bus(SFR_bus), .TH0_sel(
        TH0_sel), .TL0_sel(TL0_sel), .SFR_wr(SFR_wr), .pin_T0(pin_T0), 
        .sample_INT0(sample_INT0), .TMOD30(TMOD[3:0]), .TR0(TR0), .TR1(TR1), 
        .TH0_carry(TH0_carry), .T0_mode3(T0_mode3), .set_TF0(set_TF0), 
        .TH0_TL0_OUT(TH0_TL0_OUT) );
  timer1 timer1 ( .Z_update(Z_update), .Z_S1(Z1_S1), .Z_S2(Z1_S2), .Z_S4(Z1_S4), .Z_S5(Z1_S5), .Z_S6(Z1_S6), .sw_rst(sw_rst), .clk_b(clk_b), .SFR_bus(SFR_bus), .SFR_wr(SFR_wr), .TH1_sel(TH1_sel), .TL1_sel(TL1_sel), .pin_T1(pin_T1), 
        .sample_INT1(sample_INT1), .TH0_carry(TH0_carry), .T0_mode3(T0_mode3), 
        .TMOD74(TMOD[7:4]), .TR1(TR1), .T1_overflow(T1_overflow), .set_TF1(
        set_TF1), .TH1_TL1_OUT(TH1_TL1_OUT) );
  AOI222X4 U5 ( .A0(TH1_TL1_OUT[7]), .A1(n16), .B0(TCON_TMOD_OUT[7]), .B1(n17), 
        .C0(TH0_TL0_OUT[7]), .C1(n5), .Y(n2) );
  AOI222X4 U7 ( .A0(TH1_TL1_OUT[6]), .A1(n16), .B0(TCON_TMOD_OUT[6]), .B1(n17), 
        .C0(TH0_TL0_OUT[6]), .C1(n5), .Y(n6) );
  AOI222X4 U9 ( .A0(TH1_TL1_OUT[5]), .A1(n16), .B0(TCON_TMOD_OUT[5]), .B1(n17), 
        .C0(TH0_TL0_OUT[5]), .C1(n5), .Y(n7) );
  AOI222X4 U11 ( .A0(TH1_TL1_OUT[4]), .A1(n16), .B0(TCON_TMOD_OUT[4]), .B1(n17), .C0(TH0_TL0_OUT[4]), .C1(n5), .Y(n8) );
  AOI222X4 U13 ( .A0(TH1_TL1_OUT[3]), .A1(n16), .B0(TCON_TMOD_OUT[3]), .B1(n17), .C0(TH0_TL0_OUT[3]), .C1(n5), .Y(n9) );
  AOI222X4 U15 ( .A0(TH1_TL1_OUT[2]), .A1(n16), .B0(TCON_TMOD_OUT[2]), .B1(n17), .C0(TH0_TL0_OUT[2]), .C1(n5), .Y(n10) );
  AOI222X4 U17 ( .A0(TH1_TL1_OUT[1]), .A1(n16), .B0(TCON_TMOD_OUT[1]), .B1(n17), .C0(TH0_TL0_OUT[1]), .C1(n5), .Y(n11) );
  AOI222X4 U19 ( .A0(TH1_TL1_OUT[0]), .A1(n16), .B0(TCON_TMOD_OUT[0]), .B1(n17), .C0(TH0_TL0_OUT[0]), .C1(n5), .Y(n12) );
  OR2X4 U25 ( .A(TH0_sel), .B(TL0_sel), .Y(n5) );
  AOI2BB1X1 I26 ( .A0N(TL1_sel), .A1N(TH1_sel), .B0(n5), .Y(n3) );
  BUFX3 I27 ( .A(n3), .Y(n16) );
  INVX1 I28 ( .A(n12), .Y(T01_SFR_OUT[0]) );
  INVX1 I29 ( .A(n11), .Y(T01_SFR_OUT[1]) );
  NOR3X4 I30 ( .A(TL1_sel), .B(TH1_sel), .C(n5), .Y(n17) );
  INVX1 I31 ( .A(n2), .Y(T01_SFR_OUT[7]) );
  INVX1 I32 ( .A(n6), .Y(T01_SFR_OUT[6]) );
  INVX1 I33 ( .A(n7), .Y(T01_SFR_OUT[5]) );
  INVX1 I34 ( .A(n9), .Y(T01_SFR_OUT[3]) );
  INVX1 I35 ( .A(n8), .Y(T01_SFR_OUT[4]) );
  INVX1 I36 ( .A(n10), .Y(T01_SFR_OUT[2]) );
endmodule


module timer1 ( Z_update, Z_S1, Z_S2, Z_S4, Z_S5, Z_S6, sw_rst, clk_b, SFR_bus, 
        SFR_wr, TH1_sel, TL1_sel, pin_T1, sample_INT1, TH0_carry, T0_mode3, 
        TMOD74, TR1, T1_overflow, set_TF1, TH1_TL1_OUT );
  input [7:0] SFR_bus;
  input [3:0] TMOD74;
  output [7:0] TH1_TL1_OUT;
  input Z_update, Z_S1, Z_S2, Z_S4, Z_S5, Z_S6, sw_rst, clk_b, SFR_wr, TH1_sel,
         TL1_sel, pin_T1, sample_INT1, TH0_carry, T0_mode3, TR1;
  output T1_overflow, set_TF1;
  wire   TL1_7_, TL1_5_, TL1_4_, TL1_3_, TL1_2_, TL1_1_, TL1_0_, before_T1,
         early_t1_overflow_S4, N61, TL1_carry_4, TH1_carry_7, TL1_carry_7, n8,
         n9, n10, n11, n13, n17, n21, n23, n25, n26, n27, n30, n33, n36, n39,
         n42, n45, n48, n49, n50, n51, n53, n54, n55, n56, n57, n58, n59, n60,
         n610, n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74,
         n75, n76, n77, n78, n79, n80, n83, n84, n85, n86, n87, n88, n89, n90,
         n92, n93, n94, n95, n96, n97, n98, n99, n100, n101, n102, n103, n104,
         n105, n106, n107, n108, n109, n110, n111, n112, n113, n114, n115,
         n116, n117, n118, n119, n120, n121, n122, n123, n124, n125, n126,
         n127, n128, n129, n130, n131, n132, n133, n134, n135, n136, n137,
         n138, n139, n140, n141;
  wire   [7:0] TH1;
  wire   [7:0] TL1_inc;
  wire   [7:0] TH1_inc;

  AOI31X4 U4 ( .A0(T0_mode3), .A1(TH0_carry), .A2(Z_S5), .B0(n11), .Y(n10) );
  OAI211X4 U37 ( .A0(n17), .A1(n50), .B0(n51), .C0(n23), .Y(n49) );
  AOI222X4 U45 ( .A0(n56), .A1(n57), .B0(TL1_carry_7), .B1(TMOD74[1]), .C0(
        TL1_carry_7), .C1(TMOD74[0]), .Y(n54) );
  OAI222X4 U49 ( .A0(n130), .A1(n610), .B0(n62), .B1(n63), .C0(n64), .C1(n65), 
        .Y(n102) );
  OAI222X4 U52 ( .A0(n131), .A1(n610), .B0(n66), .B1(n63), .C0(n64), .C1(n67), 
        .Y(n101) );
  OAI222X4 U55 ( .A0(n124), .A1(n610), .B0(n68), .B1(n63), .C0(n64), .C1(n69), 
        .Y(n100) );
  OAI222X4 U58 ( .A0(n123), .A1(n610), .B0(n70), .B1(n63), .C0(n64), .C1(n71), 
        .Y(n99) );
  OAI222X4 U61 ( .A0(n122), .A1(n610), .B0(n72), .B1(n63), .C0(n64), .C1(n73), 
        .Y(n98) );
  OAI222X4 U64 ( .A0(n121), .A1(n610), .B0(n74), .B1(n63), .C0(n64), .C1(n75), 
        .Y(n97) );
  OAI222X4 U67 ( .A0(n120), .A1(n610), .B0(n76), .B1(n63), .C0(n64), .C1(n77), 
        .Y(n96) );
  OAI222X4 U70 ( .A0(n119), .A1(n610), .B0(n78), .B1(n63), .C0(n64), .C1(n79), 
        .Y(n95) );
  OAI222X4 U80 ( .A0(n86), .A1(n137), .B0(n60), .B1(n137), .C0(n85), .C1(n87), 
        .Y(n94) );
  OAI211X4 U85 ( .A0(n58), .A1(n57), .B0(n90), .C0(TR1), .Y(n88) );
  NAND2X2 I123 ( .A(n85), .B(n63), .Y(n610) );
  OR4X2 I124 ( .A(n17), .B(n27), .C(n50), .D(n55), .Y(n21) );
  OR2X2 I125 ( .A(n80), .B(n85), .Y(n64) );
  MX2X1 I126 ( .S0(n17), .B(n137), .A(n127), .Y(n8) );
  DFFRX1 TL1_reg_4_ ( .D(n108), .CK(clk_b), .RN(n139), .Q(TL1_4_), .QN(n132)
         );
  DFFRX1 TL1_reg_3_ ( .D(n107), .CK(clk_b), .RN(n139), .Q(TL1_3_), .QN(n134)
         );
  BUFX1 I127 ( .A(Z_S6), .Y(n118) );
  OR2X2 I128 ( .A(TMOD74[0]), .B(n58), .Y(n17) );
  INVX2 I129 ( .A(n51), .Y(n27) );
  INVX2 I130 ( .A(n49), .Y(n26) );
  OAI2BB1X1 I131 ( .A0N(before_T1), .A1N(n125), .B0(TMOD74[2]), .Y(n59) );
  OR2X2 I132 ( .A(n83), .B(n84), .Y(n63) );
  NAND3X1 I133 ( .A(n117), .B(TL1_5_), .C(TL1_carry_4), .Y(n141) );
  NOR2X1 I134 ( .A(n141), .B(n126), .Y(TL1_carry_7) );
  AOI22X1 I135 ( .A0(TL1_inc[0]), .A1(n26), .B0(SFR_bus[0]), .B1(n27), .Y(n48)
         );
  INVX4 I136 ( .A(sw_rst), .Y(n139) );
  DFFRHQX1 T1_overflow_reg ( .D(N61), .CK(clk_b), .RN(n139), .Q(T1_overflow)
         );
  DFFRX1 TH1_reg_0_ ( .D(n95), .CK(clk_b), .RN(n139), .Q(TH1[0]), .QN(n119) );
  DFFRX1 TH1_reg_1_ ( .D(n96), .CK(clk_b), .RN(n139), .Q(TH1[1]), .QN(n120) );
  DFFRX1 TH1_reg_2_ ( .D(n97), .CK(clk_b), .RN(n139), .Q(TH1[2]), .QN(n121) );
  DFFRX1 TH1_reg_3_ ( .D(n98), .CK(clk_b), .RN(n139), .Q(TH1[3]), .QN(n122) );
  DFFRX1 TH1_reg_4_ ( .D(n99), .CK(clk_b), .RN(n139), .Q(TH1[4]), .QN(n123) );
  DFFRX1 TH1_reg_5_ ( .D(n100), .CK(clk_b), .RN(n139), .Q(TH1[5]), .QN(n124)
         );
  DFFRX1 TL1_reg_0_ ( .D(n104), .CK(clk_b), .RN(n139), .Q(TL1_0_), .QN(n128)
         );
  DFFRX1 TL1_reg_1_ ( .D(n105), .CK(clk_b), .RN(n139), .Q(TL1_1_), .QN(n129)
         );
  DFFRX1 TH1_reg_7_ ( .D(n102), .CK(clk_b), .RN(n139), .Q(TH1[7]), .QN(n130)
         );
  DFFRX1 TH1_reg_6_ ( .D(n101), .CK(clk_b), .RN(n139), .Q(TH1[6]), .QN(n131)
         );
  DFFRX1 TL1_reg_2_ ( .D(n106), .CK(clk_b), .RN(n139), .Q(TL1_2_), .QN(n135)
         );
  DFFRX1 TL1_reg_7_ ( .D(n111), .CK(clk_b), .RN(n139), .Q(TL1_7_), .QN(n126)
         );
  OAI221X4 I137 ( .A0(n21), .A1(n130), .B0(n23), .B1(n126), .C0(n25), .Y(n111)
         );
  DFFRX1 TL1_reg_6_ ( .D(n110), .CK(clk_b), .RN(n139), .Q(n117), .QN(n136) );
  OAI221X4 I138 ( .A0(n21), .A1(n131), .B0(n23), .B1(n136), .C0(n30), .Y(n110)
         );
  OAI221X4 I139 ( .A0(n21), .A1(n119), .B0(n23), .B1(n128), .C0(n48), .Y(n104)
         );
  NAND3X1 I140 ( .A(Z_S2), .B(n17), .C(n59), .Y(n89) );
  NAND2X1 I141 ( .A(TL1_sel), .B(SFR_wr), .Y(n51) );
  NAND3X1 I142 ( .A(Z_S1), .B(n59), .C(n60), .Y(n55) );
  INVX2 I143 ( .A(TH1_sel), .Y(n84) );
  INVX1 I144 ( .A(n63), .Y(n80) );
  DFFRX1 TL1_reg_5_ ( .D(n109), .CK(clk_b), .RN(n139), .Q(TL1_5_), .QN(n133)
         );
  OR2X2 I145 ( .A(n53), .B(n27), .Y(n23) );
  INVX1 I146 ( .A(SFR_wr), .Y(n83) );
  INVX1 I147 ( .A(TL1_carry_7), .Y(n50) );
  DFFRX1 TH1_carry_reg ( .D(n92), .CK(clk_b), .RN(n139), .QN(n137) );
  OAI221X4 I148 ( .A0(n21), .A1(n120), .B0(n23), .B1(n129), .C0(n45), .Y(n105)
         );
  OAI221X4 I149 ( .A0(n21), .A1(n121), .B0(n23), .B1(n135), .C0(n42), .Y(n106)
         );
  AOI22X1 I150 ( .A0(TL1_inc[2]), .A1(n26), .B0(SFR_bus[2]), .B1(n27), .Y(n42)
         );
  OAI221X4 I151 ( .A0(n21), .A1(n122), .B0(n23), .B1(n134), .C0(n39), .Y(n107)
         );
  AOI22X1 I152 ( .A0(TL1_inc[3]), .A1(n26), .B0(SFR_bus[3]), .B1(n27), .Y(n39)
         );
  OAI221X4 I153 ( .A0(n21), .A1(n123), .B0(n23), .B1(n132), .C0(n36), .Y(n108)
         );
  AOI22X1 I154 ( .A0(TL1_inc[4]), .A1(n26), .B0(SFR_bus[4]), .B1(n27), .Y(n36)
         );
  OAI221X4 I155 ( .A0(n21), .A1(n124), .B0(n23), .B1(n133), .C0(n33), .Y(n109)
         );
  AOI22X1 I156 ( .A0(TL1_inc[5]), .A1(n26), .B0(SFR_bus[5]), .B1(n27), .Y(n33)
         );
  XOR2X1 I157 ( .A(TL1_carry_4), .B(TL1_5_), .Y(TL1_inc[5]) );
  AOI22X1 I158 ( .A0(TL1_inc[6]), .A1(n26), .B0(SFR_bus[6]), .B1(n27), .Y(n30)
         );
  XNOR2X1 I159 ( .A(n117), .B(n140), .Y(TL1_inc[6]) );
  NAND2X1 I160 ( .A(TL1_carry_4), .B(TL1_5_), .Y(n140) );
  AOI22X1 I161 ( .A0(TL1_inc[7]), .A1(n26), .B0(SFR_bus[7]), .B1(n27), .Y(n25)
         );
  XNOR2X1 I162 ( .A(TL1_7_), .B(n141), .Y(TL1_inc[7]) );
  INVX1 I163 ( .A(TH1_inc[1]), .Y(n77) );
  INVX1 I164 ( .A(SFR_bus[1]), .Y(n76) );
  INVX1 I165 ( .A(TH1_inc[2]), .Y(n75) );
  INVX1 I166 ( .A(SFR_bus[2]), .Y(n74) );
  INVX1 I167 ( .A(TH1_inc[3]), .Y(n73) );
  INVX1 I168 ( .A(SFR_bus[3]), .Y(n72) );
  INVX1 I169 ( .A(TH1_inc[4]), .Y(n71) );
  INVX1 I170 ( .A(SFR_bus[4]), .Y(n70) );
  INVX1 I171 ( .A(TH1_inc[5]), .Y(n69) );
  INVX1 I172 ( .A(SFR_bus[5]), .Y(n68) );
  INVX1 I173 ( .A(TH1_inc[6]), .Y(n67) );
  INVX1 I174 ( .A(SFR_bus[6]), .Y(n66) );
  INVX1 I175 ( .A(TH1_inc[7]), .Y(n65) );
  INVX1 I176 ( .A(SFR_bus[7]), .Y(n62) );
  OAI22X1 I177 ( .A0(TH1_sel), .A1(n126), .B0(n130), .B1(n84), .Y(
        TH1_TL1_OUT[7]) );
  OAI22X1 I178 ( .A0(TH1_sel), .A1(n136), .B0(n131), .B1(n84), .Y(
        TH1_TL1_OUT[6]) );
  OAI22X1 I179 ( .A0(TH1_sel), .A1(n133), .B0(n124), .B1(n84), .Y(
        TH1_TL1_OUT[5]) );
  OAI22X1 I180 ( .A0(TH1_sel), .A1(n134), .B0(n122), .B1(n84), .Y(
        TH1_TL1_OUT[3]) );
  OAI22X1 I181 ( .A0(TH1_sel), .A1(n132), .B0(n123), .B1(n84), .Y(
        TH1_TL1_OUT[4]) );
  OR3X2 I182 ( .A(n127), .B(n88), .C(n89), .Y(n85) );
  DFFSX1 current_T1_reg ( .D(n113), .CK(clk_b), .SN(n139), .QN(n125) );
  INVX1 I183 ( .A(n55), .Y(n53) );
  NOR2BX1 U121 ( .AN(n94), .B(n118), .Y(n92) );
  INVX1 I184 ( .A(n89), .Y(n86) );
  INVX1 I185 ( .A(TH1_carry_7), .Y(n87) );
  INVX1 I186 ( .A(n88), .Y(n60) );
  DFFSX1 before_T1_reg ( .D(n112), .CK(clk_b), .SN(n139), .Q(before_T1), .QN(
        n138) );
  DFFRX1 TL1_carry_reg ( .D(n93), .CK(clk_b), .RN(n139), .QN(n127) );
  INVX1 I187 ( .A(Z_S5), .Y(n9) );
  DFFRX1 early_t1_overflow_S4_reg ( .D(n114), .CK(clk_b), .RN(n139), .Q(
        early_t1_overflow_S4) );
  OAI22X1 I188 ( .A0(TH1_sel), .A1(n128), .B0(n119), .B1(n84), .Y(
        TH1_TL1_OUT[0]) );
  OAI22X1 I189 ( .A0(TH1_sel), .A1(n129), .B0(n120), .B1(n84), .Y(
        TH1_TL1_OUT[1]) );
  INVX1 I190 ( .A(TH1_inc[0]), .Y(n79) );
  OAI22X1 I191 ( .A0(TH1_sel), .A1(n135), .B0(n121), .B1(n84), .Y(
        TH1_TL1_OUT[2]) );
  NAND2BX1 I192 ( .AN(sample_INT1), .B(TMOD74[3]), .Y(n90) );
  NOR2BX1 U122 ( .AN(n103), .B(n118), .Y(n93) );
  OAI22X1 I193 ( .A0(n53), .A1(n127), .B0(n54), .B1(n55), .Y(n103) );
  AND2X2 I194 ( .A(TL1_carry_4), .B(n58), .Y(n56) );
  INVX1 I195 ( .A(TMOD74[1]), .Y(n58) );
  OAI31X1 I196 ( .A0(n8), .A1(T0_mode3), .A2(n9), .B0(n10), .Y(n116) );
  NOR2X1 I197 ( .A(Z_update), .B(n115), .Y(n11) );
  INVX1 I198 ( .A(TMOD74[0]), .Y(n57) );
  OAI2BB2X1 I199 ( .A0N(n13), .A1N(early_t1_overflow_S4), .B0(n8), .B1(n13), 
        .Y(n114) );
  INVX1 I200 ( .A(Z_S4), .Y(n13) );
  OAI22X1 I201 ( .A0(n9), .A1(n125), .B0(Z_S5), .B1(n138), .Y(n112) );
  OAI2BB2X1 I202 ( .A0N(pin_T1), .A1N(Z_S5), .B0(Z_S5), .B1(n125), .Y(n113) );
  AND2X1 I203 ( .A(early_t1_overflow_S4), .B(Z_S4), .Y(N61) );
  DFFRX1 set_TF1_reg ( .D(n116), .CK(clk_b), .RN(n139), .Q(set_TF1), .QN(n115)
         );
  INVX1 I204 ( .A(SFR_bus[0]), .Y(n78) );
  AOI22X1 I205 ( .A0(TL1_inc[1]), .A1(n26), .B0(SFR_bus[1]), .B1(n27), .Y(n45)
         );
  timer1_DW01_inc_9_0 add_139 ( .A({1'b0, TH1}), .SUM({TH1_carry_7, TH1_inc})
         );
  timer1_DW01_inc_6_0 add_115 ( .A({1'b0, TL1_4_, TL1_3_, TL1_2_, TL1_1_, 
        TL1_0_}), .SUM({TL1_carry_4, TL1_inc[4:0]}) );
endmodule


module timer1_DW01_inc_6_0 ( A, SUM );
  input [5:0] A;
  output [5:0] SUM;
  wire   carry_4_, carry_3_, carry_2_;

  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(SUM[5]) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  INVX1 U5 ( .A(A[0]), .Y(SUM[0]) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
endmodule


module timer1_DW01_inc_9_0 ( A, SUM );
  input [8:0] A;
  output [8:0] SUM;
  wire   carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_;

  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(carry_5_) );
  CMPR22X1 U1_1_5 ( .A(A[5]), .B(carry_5_), .S(SUM[5]), .CO(carry_6_) );
  CMPR22X1 U1_1_6 ( .A(A[6]), .B(carry_6_), .S(SUM[6]), .CO(carry_7_) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  CMPR22X1 U1_1_7 ( .A(A[7]), .B(carry_7_), .S(SUM[7]), .CO(SUM[8]) );
  INVX1 U5 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module timer0 ( Z_update, Z_S1, Z_S2, Z_S5, Z_S6, sw_rst, clk_b, SFR_bus, 
        TH0_sel, TL0_sel, SFR_wr, pin_T0, sample_INT0, TMOD30, TR0, TR1, 
        TH0_carry, T0_mode3, set_TF0, TH0_TL0_OUT );
  input [7:0] SFR_bus;
  input [3:0] TMOD30;
  output [7:0] TH0_TL0_OUT;
  input Z_update, Z_S1, Z_S2, Z_S5, Z_S6, sw_rst, clk_b, TH0_sel, TL0_sel,
         SFR_wr, pin_T0, sample_INT0, TR0, TR1;
  output TH0_carry, T0_mode3, set_TF0;
  wire   TL0_carry, before_T0, TL0_carry_4, TH0_carry_7, TL0_carry_7, n8, n9,
         n10, n11, n12, n13, n16, n17, n18, n20, n23, n25, n26, n28, n29, n31,
         n32, n34, n35, n37, n38, n40, n41, n43, n46, n47, n52, n53, n55, n56,
         n57, n58, n59, n60, n61, n62, n63, n64, n65, n66, n67, n68, n69, n70,
         n73, n74, n75, n76, n78, n79, n80, n81, n82, n92, n93, n94, n95, n96,
         n97, n98, n99, n100, n101, n102, n103, n104, n105, n106, n107, n108,
         n109, n110, n111, n112, n113, n114, n115, n116, n117, n118, n119,
         n120, n121, n122, n123, n124, n125, n126, n127, n128, n129, n130,
         n131, n132, n133, n134, n135, n136, n137, n138, n139, n140, n141;
  wire   [7:0] TH0;
  wire   [7:0] TL0;
  wire   [7:0] TL0_inc;
  wire   [7:0] TH0_inc;

  AOI222X4 U4 ( .A0(n10), .A1(n11), .B0(T0_mode3), .B1(TL0_carry), .C0(
        TL0_carry), .C1(n12), .Y(n8) );
  AOI222X4 U44 ( .A0(n57), .A1(n58), .B0(TL0_carry_7), .B1(TMOD30[1]), .C0(
        TL0_carry_7), .C1(TMOD30[0]), .Y(n52) );
  OAI222X4 U46 ( .A0(n127), .A1(n60), .B0(n17), .B1(n61), .C0(n62), .C1(n63), 
        .Y(n102) );
  OAI222X4 U49 ( .A0(n123), .A1(n60), .B0(n23), .B1(n61), .C0(n62), .C1(n64), 
        .Y(n101) );
  OAI222X4 U52 ( .A0(n130), .A1(n60), .B0(n26), .B1(n61), .C0(n62), .C1(n65), 
        .Y(n100) );
  OAI222X4 U55 ( .A0(n122), .A1(n60), .B0(n29), .B1(n61), .C0(n62), .C1(n66), 
        .Y(n99) );
  OAI222X4 U58 ( .A0(n120), .A1(n60), .B0(n32), .B1(n61), .C0(n62), .C1(n67), 
        .Y(n98) );
  OAI222X4 U61 ( .A0(n129), .A1(n60), .B0(n35), .B1(n61), .C0(n62), .C1(n68), 
        .Y(n97) );
  OAI222X4 U64 ( .A0(n119), .A1(n60), .B0(n38), .B1(n61), .C0(n62), .C1(n69), 
        .Y(n96) );
  OAI222X4 U67 ( .A0(n118), .A1(n60), .B0(n41), .B1(n61), .C0(n62), .C1(n70), 
        .Y(n95) );
  OAI211X4 U81 ( .A0(TR1), .A1(n11), .B0(Z_S2), .C0(n79), .Y(n78) );
  NAND2BX1 I122 ( .AN(n137), .B(n16), .Y(n46) );
  AND2X2 I123 ( .A(n47), .B(n116), .Y(n138) );
  INVX1 I124 ( .A(n46), .Y(n116) );
  AOI21X1 I125 ( .A0(n117), .A1(n11), .B0(n78), .Y(n73) );
  NAND2BX2 I126 ( .AN(n73), .B(n61), .Y(n60) );
  MXI2X1 I127 ( .S0(n53), .B(n117), .A(n52), .Y(n103) );
  NAND2X2 I128 ( .A(n61), .B(n60), .Y(n62) );
  AND2X2 I129 ( .A(n53), .B(n16), .Y(n137) );
  NOR2X1 I130 ( .A(n12), .B(n135), .Y(n10) );
  DFFRX1 TL0_reg_3_ ( .D(n107), .CK(clk_b), .RN(n139), .Q(TL0[3]), .QN(n128)
         );
  DFFRX1 TL0_reg_4_ ( .D(n108), .CK(clk_b), .RN(n139), .Q(TL0[4]), .QN(n132)
         );
  INVX1 I131 ( .A(SFR_bus[1]), .Y(n38) );
  OR2X2 I132 ( .A(n74), .B(n75), .Y(n61) );
  OR2X2 I133 ( .A(n58), .B(n59), .Y(n11) );
  NAND2X2 I134 ( .A(TL0_sel), .B(SFR_wr), .Y(n16) );
  INVX4 I135 ( .A(sw_rst), .Y(n139) );
  DFFRX1 TH0_reg_0_ ( .D(n95), .CK(clk_b), .RN(n139), .Q(TH0[0]), .QN(n118) );
  DFFRX1 TH0_reg_1_ ( .D(n96), .CK(clk_b), .RN(n139), .Q(TH0[1]), .QN(n119) );
  DFFRX1 TH0_reg_3_ ( .D(n98), .CK(clk_b), .RN(n139), .Q(TH0[3]), .QN(n120) );
  DFFRX1 TH0_reg_4_ ( .D(n99), .CK(clk_b), .RN(n139), .Q(TH0[4]), .QN(n122) );
  DFFRX1 TH0_reg_6_ ( .D(n101), .CK(clk_b), .RN(n139), .Q(TH0[6]), .QN(n123)
         );
  DFFRX1 TL0_reg_1_ ( .D(n105), .CK(clk_b), .RN(n139), .Q(TL0[1]), .QN(n126)
         );
  DFFRX1 TH0_reg_7_ ( .D(n102), .CK(clk_b), .RN(n139), .Q(TH0[7]), .QN(n127)
         );
  DFFRX1 TH0_reg_2_ ( .D(n97), .CK(clk_b), .RN(n139), .Q(TH0[2]), .QN(n129) );
  DFFRX1 TH0_reg_5_ ( .D(n100), .CK(clk_b), .RN(n139), .Q(TH0[5]), .QN(n130)
         );
  DFFRX1 TL0_reg_7_ ( .D(n111), .CK(clk_b), .RN(n139), .Q(TL0[7]), .QN(n134)
         );
  OAI221X4 I136 ( .A0(n16), .A1(n17), .B0(n18), .B1(n127), .C0(n20), .Y(n111)
         );
  DFFRX1 TL0_reg_6_ ( .D(n110), .CK(clk_b), .RN(n139), .Q(TL0[6]), .QN(n131)
         );
  OAI221X4 I137 ( .A0(n16), .A1(n23), .B0(n18), .B1(n123), .C0(n25), .Y(n110)
         );
  DFFRX1 TL0_reg_5_ ( .D(n109), .CK(clk_b), .RN(n139), .Q(TL0[5]), .QN(n133)
         );
  OAI221X4 I138 ( .A0(n16), .A1(n26), .B0(n18), .B1(n130), .C0(n28), .Y(n109)
         );
  OAI221X4 I139 ( .A0(n16), .A1(n29), .B0(n18), .B1(n122), .C0(n31), .Y(n108)
         );
  OAI221X4 I140 ( .A0(n16), .A1(n32), .B0(n18), .B1(n120), .C0(n34), .Y(n107)
         );
  DFFRX1 TL0_reg_2_ ( .D(n106), .CK(clk_b), .RN(n139), .Q(TL0[2]), .QN(n121)
         );
  OAI221X4 I141 ( .A0(n16), .A1(n35), .B0(n18), .B1(n129), .C0(n37), .Y(n106)
         );
  OAI221X4 I142 ( .A0(n16), .A1(n38), .B0(n18), .B1(n119), .C0(n40), .Y(n105)
         );
  DFFRX1 TL0_reg_0_ ( .D(n104), .CK(clk_b), .RN(n139), .Q(TL0[0]), .QN(n125)
         );
  OAI221X4 I143 ( .A0(n16), .A1(n41), .B0(n18), .B1(n118), .C0(n43), .Y(n104)
         );
  NAND2X1 I144 ( .A(Z_S1), .B(n55), .Y(n53) );
  INVX2 I145 ( .A(TH0_sel), .Y(n75) );
  INVX1 I146 ( .A(SFR_bus[3]), .Y(n32) );
  INVX1 I147 ( .A(SFR_bus[2]), .Y(n35) );
  INVX1 I148 ( .A(SFR_bus[4]), .Y(n29) );
  INVX1 I149 ( .A(SFR_bus[5]), .Y(n26) );
  INVX1 I150 ( .A(SFR_bus[6]), .Y(n23) );
  INVX1 I151 ( .A(SFR_bus[7]), .Y(n17) );
  OR2X2 I152 ( .A(n47), .B(n46), .Y(n18) );
  INVX1 I153 ( .A(SFR_wr), .Y(n74) );
  INVX1 I154 ( .A(n11), .Y(T0_mode3) );
  INVX1 I155 ( .A(TH0_inc[1]), .Y(n69) );
  INVX1 I156 ( .A(TH0_inc[2]), .Y(n68) );
  INVX1 I157 ( .A(TH0_inc[3]), .Y(n67) );
  INVX1 I158 ( .A(TH0_inc[4]), .Y(n66) );
  INVX1 I159 ( .A(TH0_inc[5]), .Y(n65) );
  INVX1 I160 ( .A(TH0_inc[6]), .Y(n64) );
  INVX1 I161 ( .A(TH0_inc[7]), .Y(n63) );
  NAND3X1 I162 ( .A(TL0[6]), .B(TL0[5]), .C(TL0_carry_4), .Y(n141) );
  NOR2X1 I163 ( .A(n141), .B(n134), .Y(TL0_carry_7) );
  DFFSX1 before_T0_reg ( .D(n112), .CK(clk_b), .SN(n139), .Q(before_T0), .QN(
        n136) );
  NAND2BX1 I164 ( .AN(n13), .B(TL0_carry_7), .Y(n47) );
  DFFSX1 current_T0_reg ( .D(n113), .CK(clk_b), .SN(n139), .QN(n124) );
  INVX1 I165 ( .A(n13), .Y(n12) );
  DFFRX1 TH0_carry_reg ( .D(n92), .CK(clk_b), .RN(n139), .Q(TH0_carry), .QN(
        n135) );
  DFFRX1 TL0_carry_reg ( .D(n93), .CK(clk_b), .RN(n139), .Q(TL0_carry), .QN(
        n117) );
  INVX1 I166 ( .A(Z_S5), .Y(n9) );
  OAI22X1 I167 ( .A0(TH0_sel), .A1(n125), .B0(n118), .B1(n75), .Y(
        TH0_TL0_OUT[0]) );
  OAI22X1 I168 ( .A0(TH0_sel), .A1(n126), .B0(n119), .B1(n75), .Y(
        TH0_TL0_OUT[1]) );
  AOI22X1 I169 ( .A0(TL0_inc[1]), .A1(n138), .B0(TL0[1]), .B1(n137), .Y(n40)
         );
  AOI22X1 I170 ( .A0(TL0_inc[2]), .A1(n138), .B0(TL0[2]), .B1(n137), .Y(n37)
         );
  AOI22X1 I171 ( .A0(TL0_inc[3]), .A1(n138), .B0(TL0[3]), .B1(n137), .Y(n34)
         );
  AOI22X1 I172 ( .A0(TL0_inc[4]), .A1(n138), .B0(TL0[4]), .B1(n137), .Y(n31)
         );
  AOI22X1 I173 ( .A0(TL0_inc[5]), .A1(n138), .B0(TL0[5]), .B1(n137), .Y(n28)
         );
  XOR2X1 I174 ( .A(TL0_carry_4), .B(TL0[5]), .Y(TL0_inc[5]) );
  AOI22X1 I175 ( .A0(TL0_inc[6]), .A1(n138), .B0(TL0[6]), .B1(n137), .Y(n25)
         );
  XNOR2X1 I176 ( .A(TL0[6]), .B(n140), .Y(TL0_inc[6]) );
  NAND2X1 I177 ( .A(TL0_carry_4), .B(TL0[5]), .Y(n140) );
  AOI22X1 I178 ( .A0(TL0_inc[7]), .A1(n138), .B0(TL0[7]), .B1(n137), .Y(n20)
         );
  XNOR2X1 I179 ( .A(TL0[7]), .B(n141), .Y(TL0_inc[7]) );
  OAI22X1 I180 ( .A0(TH0_sel), .A1(n134), .B0(n127), .B1(n75), .Y(
        TH0_TL0_OUT[7]) );
  INVX1 I181 ( .A(TH0_inc[0]), .Y(n70) );
  AOI22X1 I182 ( .A0(TL0_inc[0]), .A1(n138), .B0(TL0[0]), .B1(n137), .Y(n43)
         );
  OAI22X1 I183 ( .A0(TH0_sel), .A1(n131), .B0(n123), .B1(n75), .Y(
        TH0_TL0_OUT[6]) );
  OAI22X1 I184 ( .A0(TH0_sel), .A1(n133), .B0(n130), .B1(n75), .Y(
        TH0_TL0_OUT[5]) );
  OAI22X1 I185 ( .A0(TH0_sel), .A1(n128), .B0(n120), .B1(n75), .Y(
        TH0_TL0_OUT[3]) );
  OAI22X1 I186 ( .A0(TH0_sel), .A1(n121), .B0(n129), .B1(n75), .Y(
        TH0_TL0_OUT[2]) );
  OAI22X1 I187 ( .A0(TH0_sel), .A1(n132), .B0(n122), .B1(n75), .Y(
        TH0_TL0_OUT[4]) );
  AOI21X1 I188 ( .A0(n56), .A1(n11), .B0(n12), .Y(n79) );
  OR2X2 I189 ( .A(TMOD30[0]), .B(n59), .Y(n13) );
  INVX1 I190 ( .A(n56), .Y(n55) );
  NOR2BX1 U121 ( .AN(n103), .B(Z_S6), .Y(n93) );
  AND2X2 I191 ( .A(TL0_carry_4), .B(n59), .Y(n57) );
  OAI221X4 I192 ( .A0(before_T0), .A1(n80), .B0(n124), .B1(n80), .C0(n81), .Y(
        n56) );
  AND2X2 I193 ( .A(TR0), .B(n82), .Y(n81) );
  INVX1 I194 ( .A(TMOD30[2]), .Y(n80) );
  NAND2BX1 I195 ( .AN(sample_INT0), .B(TMOD30[3]), .Y(n82) );
  INVX1 I196 ( .A(TMOD30[1]), .Y(n59) );
  INVX1 I197 ( .A(TMOD30[0]), .Y(n58) );
  OAI22X1 I198 ( .A0(Z_update), .A1(n114), .B0(n8), .B1(n9), .Y(n115) );
  NOR2BX1 U120 ( .AN(n94), .B(Z_S6), .Y(n92) );
  OAI2BB2X1 I199 ( .A0N(TH0_carry_7), .A1N(n73), .B0(n76), .B1(n135), .Y(n94)
         );
  INVX1 I200 ( .A(n78), .Y(n76) );
  OAI22X1 I201 ( .A0(n9), .A1(n124), .B0(Z_S5), .B1(n136), .Y(n112) );
  OAI2BB2X1 I202 ( .A0N(pin_T0), .A1N(Z_S5), .B0(Z_S5), .B1(n124), .Y(n113) );
  DFFRX1 set_TF0_reg ( .D(n115), .CK(clk_b), .RN(n139), .Q(set_TF0), .QN(n114)
         );
  INVX1 I203 ( .A(SFR_bus[0]), .Y(n41) );
  timer0_DW01_inc_9_0 add_135 ( .A({1'b0, TH0}), .SUM({TH0_carry_7, TH0_inc})
         );
  timer0_DW01_inc_6_0 add_104 ( .A({1'b0, TL0[4:0]}), .SUM({TL0_carry_4, 
        TL0_inc[4:0]}) );
endmodule


module timer0_DW01_inc_6_0 ( A, SUM );
  input [5:0] A;
  output [5:0] SUM;
  wire   carry_4_, carry_3_, carry_2_;

  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(SUM[5]) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  INVX1 U5 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module timer0_DW01_inc_9_0 ( A, SUM );
  input [8:0] A;
  output [8:0] SUM;
  wire   carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_;

  CMPR22X1 U1_1_7 ( .A(A[7]), .B(carry_7_), .S(SUM[7]), .CO(SUM[8]) );
  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(carry_5_) );
  CMPR22X1 U1_1_5 ( .A(A[5]), .B(carry_5_), .S(SUM[5]), .CO(carry_6_) );
  CMPR22X1 U1_1_6 ( .A(A[6]), .B(carry_6_), .S(SUM[6]), .CO(carry_7_) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  INVX1 U5 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module t01_control ( sw_rst, clk_b, TCON_sel, TMOD_sel, SFR_wr, SFR_bus, 
        clear_TF0, clear_TF1, set_TF0, set_TF1, TCON30, TF0, TF1, TR0, TR1, 
        TCON_TMOD_OUT, TMOD );
  input [7:0] SFR_bus;
  input [3:0] TCON30;
  output [7:0] TCON_TMOD_OUT;
  output [7:0] TMOD;
  input sw_rst, clk_b, TCON_sel, TMOD_sel, SFR_wr, clear_TF0, clear_TF1,
         set_TF0, set_TF1;
  output TF0, TF1, TR0, TR1;
  wire   n2, n4, n5, n7, n9, n11, n16, n21, n22, n23, n24, n27, n28, n29, n31,
         n32, n33, n34, n35, n36, n37, n38, n39, n40, n41, n42, n43, n44, n45,
         n46, n47, n48, n49, n50, n51, n52, n53;

  AOI221X4 U33 ( .A0(n22), .A1(SFR_bus[7]), .B0(TF1), .B1(n23), .C0(set_TF1), 
        .Y(n21) );
  NAND2X1 I49 ( .A(SFR_wr), .B(TCON_sel), .Y(n23) );
  INVX2 I50 ( .A(TCON_sel), .Y(n16) );
  INVX1 I51 ( .A(n23), .Y(n22) );
  NAND2X2 I52 ( .A(TMOD_sel), .B(SFR_wr), .Y(n4) );
  INVX2 I53 ( .A(sw_rst), .Y(n53) );
  DFFRX1 TMOD_reg_5_ ( .D(n38), .CK(clk_b), .RN(n53), .Q(TMOD[5]), .QN(n44) );
  DFFRX1 TMOD_reg_0_ ( .D(n33), .CK(clk_b), .RN(n53), .Q(TMOD[0]), .QN(n45) );
  DFFRX1 TMOD_reg_1_ ( .D(n34), .CK(clk_b), .RN(n53), .Q(TMOD[1]), .QN(n46) );
  DFFRX1 TCON74_reg_3_ ( .D(n28), .CK(clk_b), .RN(n53), .Q(TF1), .QN(n48) );
  DFFRX1 TMOD_reg_2_ ( .D(n35), .CK(clk_b), .RN(n53), .Q(TMOD[2]), .QN(n50) );
  DFFRX1 TMOD_reg_4_ ( .D(n37), .CK(clk_b), .RN(n53), .Q(TMOD[4]), .QN(n51) );
  DFFRX1 TCON74_reg_1_ ( .D(n27), .CK(clk_b), .RN(n53), .Q(TF0), .QN(n52) );
  AOI221X4 I54 ( .A0(n22), .A1(SFR_bus[5]), .B0(TF0), .B1(n23), .C0(set_TF0), 
        .Y(n24) );
  INVX4 I55 ( .A(n4), .Y(n2) );
  INVX1 I56 ( .A(SFR_bus[4]), .Y(n11) );
  INVX1 I57 ( .A(SFR_bus[6]), .Y(n7) );
  DFFRX1 TMOD_reg_7_ ( .D(n40), .CK(clk_b), .RN(n53), .Q(TMOD[7]), .QN(n41) );
  DFFRX1 TMOD_reg_3_ ( .D(n36), .CK(clk_b), .RN(n53), .Q(TMOD[3]), .QN(n47) );
  DFFRX1 TMOD_reg_6_ ( .D(n39), .CK(clk_b), .RN(n53), .Q(TMOD[6]), .QN(n49) );
  DFFRX1 TCON74_reg_2_ ( .D(n31), .CK(clk_b), .RN(n53), .Q(TR1), .QN(n42) );
  DFFRX1 TCON74_reg_0_ ( .D(n29), .CK(clk_b), .RN(n53), .Q(TR0), .QN(n43) );
  OAI22X1 I58 ( .A0(n2), .A1(n51), .B0(n4), .B1(n11), .Y(n37) );
  OAI22X1 I59 ( .A0(n2), .A1(n44), .B0(n4), .B1(n9), .Y(n38) );
  INVX1 I60 ( .A(SFR_bus[5]), .Y(n9) );
  OAI22X1 I61 ( .A0(n2), .A1(n49), .B0(n4), .B1(n7), .Y(n39) );
  OAI22X1 I62 ( .A0(n2), .A1(n41), .B0(n4), .B1(n5), .Y(n40) );
  INVX1 I63 ( .A(SFR_bus[7]), .Y(n5) );
  OAI22X1 I64 ( .A0(n22), .A1(n43), .B0(n11), .B1(n23), .Y(n29) );
  OAI22X1 I65 ( .A0(n22), .A1(n42), .B0(n7), .B1(n23), .Y(n31) );
  OAI2BB2X1 I66 ( .A0N(SFR_bus[2]), .A1N(n2), .B0(n2), .B1(n50), .Y(n35) );
  OAI2BB2X1 I67 ( .A0N(SFR_bus[3]), .A1N(n2), .B0(n2), .B1(n47), .Y(n36) );
  OAI22X1 I68 ( .A0(n16), .A1(n48), .B0(TCON_sel), .B1(n41), .Y(
        TCON_TMOD_OUT[7]) );
  OAI22X1 I69 ( .A0(n16), .A1(n42), .B0(TCON_sel), .B1(n49), .Y(
        TCON_TMOD_OUT[6]) );
  OAI22X1 I70 ( .A0(n16), .A1(n52), .B0(TCON_sel), .B1(n44), .Y(
        TCON_TMOD_OUT[5]) );
  OAI2BB2X1 I71 ( .A0N(TCON30[3]), .A1N(TCON_sel), .B0(TCON_sel), .B1(n47), 
        .Y(TCON_TMOD_OUT[3]) );
  OAI22X1 I72 ( .A0(n16), .A1(n43), .B0(TCON_sel), .B1(n51), .Y(
        TCON_TMOD_OUT[4]) );
  OAI2BB2X1 I73 ( .A0N(TCON30[0]), .A1N(TCON_sel), .B0(TCON_sel), .B1(n45), 
        .Y(TCON_TMOD_OUT[0]) );
  OAI2BB2X1 I74 ( .A0N(TCON30[1]), .A1N(TCON_sel), .B0(TCON_sel), .B1(n46), 
        .Y(TCON_TMOD_OUT[1]) );
  NOR2BX1 U48 ( .AN(n32), .B(clear_TF1), .Y(n28) );
  INVX1 I75 ( .A(n21), .Y(n32) );
  OAI2BB2X1 I76 ( .A0N(TCON30[2]), .A1N(TCON_sel), .B0(TCON_sel), .B1(n50), 
        .Y(TCON_TMOD_OUT[2]) );
  NOR2X1 I77 ( .A(n24), .B(clear_TF0), .Y(n27) );
  OAI2BB2X1 I78 ( .A0N(SFR_bus[0]), .A1N(n2), .B0(n2), .B1(n45), .Y(n33) );
  OAI2BB2X1 I79 ( .A0N(SFR_bus[1]), .A1N(n2), .B0(n2), .B1(n46), .Y(n34) );
endmodule


module t2_cycle ( reset, clk, T2M, T2M_S1, T2M_S2 );
  input reset, clk, T2M;
  output T2M_S1, T2M_S2;
  wire   T2M_d, N68, N70, N71, N72, N86, N87, N93, n2, n3, n4, n5, n6, n10,
         n12, n17, n21, n22, n26, n27, n28, n29, n30, n31, n32, n33, n34, n35,
         n37, n38, n39, n41, n44, n45, n46, n47, n48, n49, n50, n51, n52, n53,
         n54, n55, n57, n58, n59, n60, n61, n62, n63, n64;
  wire   [3:0] T2_six_state;
  wire   [1:0] T2_four_state;

  OAI32X4 U3 ( .A0(n6), .A1(n62), .A2(n51), .B0(N93), .B1(n38), .Y(n39) );
  OAI32X4 U5 ( .A0(n6), .A1(T2_six_state[3]), .A2(n51), .B0(N93), .B1(n34), 
        .Y(n35) );
  OAI32X4 U6 ( .A0(n6), .A1(T2_six_state[3]), .A2(T2_six_state[1]), .B0(N93), 
        .B1(n32), .Y(n33) );
  OAI32X4 U20 ( .A0(n54), .A1(reset), .A2(n55), .B0(reset), .B1(
        T2_six_state[0]), .Y(n17) );
  DFFHQX4 T2M_d_reg ( .D(T2M), .CK(clk), .Q(T2M_d) );
  MX2X1 I43 ( .S0(T2M_d), .B(n5), .A(n3), .Y(n46) );
  INVX2 I44 ( .A(n46), .Y(T2M_S2) );
  MXI2X2 I45 ( .S0(T2M_d), .B(n4), .A(n2), .Y(T2M_S1) );
  NAND2X1 I46 ( .A(T2_four_state[0]), .B(T2_four_state[1]), .Y(n12) );
  AOI32X1 I47 ( .A0(n47), .A1(n55), .A2(n51), .B0(n48), .B1(n49), .Y(n50) );
  INVX1 I48 ( .A(n6), .Y(n47) );
  INVX1 I49 ( .A(N93), .Y(n48) );
  INVX1 I50 ( .A(n50), .Y(n37) );
  DFFTRX1 T2_six_state_reg_1_ ( .D(N70), .CK(clk), .RN(n44), .Q(
        T2_six_state[1]), .QN(n51) );
  EDFFX1 T2_six_S2_reg ( .D(N87), .CK(clk), .E(N93), .QN(n3) );
  DFFTRX1 T2_four_state_reg_1_ ( .D(N68), .CK(clk), .RN(n45), .Q(
        T2_four_state[1]), .QN(n41) );
  DFFTRX2 T2_six_state_reg_3_ ( .D(N72), .CK(clk), .RN(n44), .Q(
        T2_six_state[3]), .QN(n54) );
  DFFTRX1 T2_six_state_reg_0_ ( .D(n52), .CK(clk), .RN(n44), .Q(
        T2_six_state[0]), .QN(n52) );
  DFFTRX1 T2_four_state_reg_0_ ( .D(n53), .CK(clk), .RN(n45), .Q(
        T2_four_state[0]), .QN(n53) );
  BUFX3 I51 ( .A(T2_six_state[2]), .Y(n62) );
  NAND2X1 I52 ( .A(T2_six_state[1]), .B(T2_six_state[0]), .Y(n63) );
  INVX2 I53 ( .A(reset), .Y(n61) );
  OR3X2 I54 ( .A(n54), .B(n55), .C(n10), .Y(N93) );
  DFFTRX1 T2_six_state_reg_2_ ( .D(N71), .CK(clk), .RN(n44), .Q(
        T2_six_state[2]), .QN(n55) );
  OR3X2 I55 ( .A(n59), .B(n58), .C(n10), .Y(n6) );
  INVX1 I56 ( .A(n17), .Y(n10) );
  AND2X1 I57 ( .A(n59), .B(n17), .Y(N86) );
  AND2X1 I58 ( .A(n58), .B(n17), .Y(N87) );
  NOR2X1 I59 ( .A(reset), .B(n60), .Y(n57) );
  XNOR2X1 I60 ( .A(n62), .B(n63), .Y(N71) );
  AND2X2 I61 ( .A(n57), .B(n53), .Y(n30) );
  NOR2BX1 I62 ( .AN(n57), .B(n12), .Y(n31) );
  NOR3X1 I63 ( .A(T2_six_state[3]), .B(n62), .C(n51), .Y(n58) );
  AND3X2 U39 ( .A(n35), .B(n62), .C(n61), .Y(n26) );
  AND3X2 U41 ( .A(T2_six_state[3]), .B(n61), .C(n39), .Y(n28) );
  AND3X2 U42 ( .A(T2_six_state[3]), .B(n61), .C(n37), .Y(n29) );
  AND3X2 U40 ( .A(n61), .B(n62), .C(n33), .Y(n27) );
  NOR3X1 I64 ( .A(T2_six_state[3]), .B(T2_six_state[1]), .C(n62), .Y(n59) );
  AND3X2 I65 ( .A(n21), .B(n61), .C(n22), .Y(n44) );
  INVX1 I66 ( .A(T2M), .Y(n21) );
  OR4X2 I67 ( .A(n51), .B(n52), .C(n62), .D(n54), .Y(n22) );
  AND3X2 I68 ( .A(T2M), .B(n61), .C(n12), .Y(n45) );
  XOR2X1 I69 ( .A(T2_six_state[1]), .B(T2_six_state[0]), .Y(N70) );
  XOR2X1 I70 ( .A(T2_four_state[1]), .B(T2_four_state[0]), .Y(N68) );
  XOR2X1 I71 ( .A(T2_six_state[3]), .B(n64), .Y(N72) );
  NOR2X1 I72 ( .A(n63), .B(n55), .Y(n64) );
  NOR2X1 I73 ( .A(T2_four_state[0]), .B(T2_four_state[1]), .Y(n60) );
  DFFTRX1 T2_four_S1_reg ( .D(n60), .CK(clk), .RN(n61), .QN(n4) );
  EDFFX1 T2_six_S1_reg ( .D(N86), .CK(clk), .E(N93), .QN(n2) );
  DFFTRX1 T2_four_S2_reg ( .D(n57), .CK(clk), .RN(n41), .QN(n5) );
  DFFX1 T2_six_S4_reg ( .D(n26), .CK(clk), .QN(n34) );
  DFFX1 T2_six_S3_reg ( .D(n27), .CK(clk), .QN(n32) );
  DFFX1 T2_six_S6_reg ( .D(n28), .CK(clk), .QN(n38) );
  DFFX1 T2_six_S5_reg ( .D(n29), .CK(clk), .Q(n49) );
  DFFX4 T2_four_S3_reg ( .D(n30), .CK(clk) );
  DFFX4 T2_four_S4_reg ( .D(n31), .CK(clk) );
endmodule


module t1_cycle ( reset, clk, T1M, T1M_S1, T1M_S2, T1M_S4, T1M_S5, T1M_S6 );
  input reset, clk, T1M;
  output T1M_S1, T1M_S2, T1M_S4, T1M_S5, T1M_S6;
  wire   T1M_d, N68, N70, N71, N72, N86, N87, N90, N91, N93, n2, n3, n4, n5,
         n7, n8, n10, n11, n14, n15, n16, n17, n20, n21, n24, n25, n28, n29,
         n30, n34, n35, n36, n37, n39, n41, n42, n43, n44, n46, n47, n48, n49,
         n50, n51, n52, n53, n54, n55, n56, n57, n58, n59;
  wire   [3:0] T1_six_state;
  wire   [1:0] T1_four_state;

  OAI32X4 U27 ( .A0(n55), .A1(reset), .A2(n51), .B0(reset), .B1(
        T1_six_state[0]), .Y(n25) );
  DFFHQX4 T1M_d_reg ( .D(T1M), .CK(clk), .Q(T1M_d) );
  MXI2X1 I48 ( .S0(T1M_d), .B(n53), .A(n4), .Y(T1M_S2) );
  MXI2X1 I49 ( .S0(T1M_d), .B(n8), .A(n3), .Y(T1M_S1) );
  NAND2X1 I50 ( .A(n51), .B(T1_six_state[1]), .Y(n16) );
  MX2X1 I51 ( .S0(T1M_d), .B(n49), .A(n5), .Y(T1M_S4) );
  NAND2X1 I52 ( .A(n54), .B(n55), .Y(n14) );
  MX2X1 I53 ( .S0(T1M_d), .B(n50), .A(n5), .Y(T1M_S5) );
  AND4X2 I54 ( .A(n15), .B(T1_six_state[2]), .C(n57), .D(n10), .Y(n35) );
  NAND2X1 I55 ( .A(n43), .B(n42), .Y(n34) );
  AND4X2 I56 ( .A(T1_six_state[3]), .B(n57), .C(n11), .D(n10), .Y(n36) );
  OAI22X1 I57 ( .A0(n17), .A1(n7), .B0(T1M_d), .B1(n2), .Y(T1M_S6) );
  DFFTRX1 T1_four_state_reg_1_ ( .D(N68), .CK(clk), .RN(n48), .Q(
        T1_four_state[1]), .QN(n43) );
  DFFTRX1 T1_six_state_reg_3_ ( .D(N72), .CK(clk), .RN(n47), .Q(
        T1_six_state[3]), .QN(n51) );
  DFFTRX1 T1_six_state_reg_1_ ( .D(N70), .CK(clk), .RN(n47), .Q(
        T1_six_state[1]), .QN(n54) );
  DFFTRX2 T1_six_state_reg_2_ ( .D(N71), .CK(clk), .RN(n47), .Q(
        T1_six_state[2]), .QN(n55) );
  DFFTRX1 T1_six_state_reg_0_ ( .D(n52), .CK(clk), .RN(n47), .Q(
        T1_six_state[0]), .QN(n52) );
  DFFTRX1 T1_four_state_reg_0_ ( .D(n42), .CK(clk), .RN(n48), .Q(
        T1_four_state[0]), .QN(n42) );
  INVX4 I58 ( .A(T1M_d), .Y(n17) );
  DFFTRX1 T1_four_S2_reg ( .D(n41), .CK(clk), .RN(n43), .Q(n49), .QN(n53) );
  EDFFX1 T1_six_S3_reg ( .D(N91), .CK(clk), .E(N93), .Q(n5) );
  INVX1 I59 ( .A(n21), .Y(n10) );
  DFFTRX1 T1_four_S4_reg ( .D(n46), .CK(clk), .RN(n41), .QN(n7) );
  INVX1 I60 ( .A(reset), .Y(n57) );
  OAI2BB1X1 I61 ( .A0N(n55), .A1N(n51), .B0(n25), .Y(n24) );
  OR2X2 I62 ( .A(n56), .B(n24), .Y(n21) );
  OR3X2 I63 ( .A(n20), .B(n55), .C(n21), .Y(N93) );
  AND3X1 I64 ( .A(n56), .B(n55), .C(n25), .Y(N86) );
  AND3X2 I65 ( .A(n20), .B(n55), .C(n25), .Y(N87) );
  AND3X2 I66 ( .A(n14), .B(n55), .C(n10), .Y(N90) );
  INVX1 I67 ( .A(n16), .Y(n20) );
  NOR2BX1 I68 ( .AN(n56), .B(n24), .Y(N91) );
  AND2X2 I69 ( .A(n34), .B(n57), .Y(n41) );
  INVX1 I70 ( .A(n28), .Y(n46) );
  INVX1 I71 ( .A(n34), .Y(n44) );
  NOR2X1 I72 ( .A(T1_six_state[1]), .B(T1_six_state[3]), .Y(n56) );
  OAI31X1 I73 ( .A0(n55), .A1(n39), .A2(n51), .B0(n14), .Y(n11) );
  OAI2BB1X1 I74 ( .A0N(n37), .A1N(T1_six_state[2]), .B0(n16), .Y(n15) );
  NAND2X1 I75 ( .A(T1_six_state[1]), .B(T1_six_state[0]), .Y(n58) );
  NAND2X1 I76 ( .A(T1_four_state[0]), .B(T1_four_state[1]), .Y(n28) );
  AND3X2 I77 ( .A(n29), .B(n57), .C(n30), .Y(n47) );
  INVX1 I78 ( .A(T1M), .Y(n29) );
  OR4X2 I79 ( .A(n54), .B(n52), .C(T1_six_state[2]), .D(n51), .Y(n30) );
  AND3X2 I80 ( .A(T1M), .B(n57), .C(n28), .Y(n48) );
  XNOR2X1 I81 ( .A(T1_six_state[2]), .B(n58), .Y(N71) );
  XOR2X1 I82 ( .A(T1_six_state[1]), .B(T1_six_state[0]), .Y(N70) );
  XOR2X1 I83 ( .A(T1_four_state[1]), .B(T1_four_state[0]), .Y(N68) );
  XOR2X1 I84 ( .A(T1_six_state[3]), .B(n59), .Y(N72) );
  NOR2X1 I85 ( .A(n58), .B(n55), .Y(n59) );
  DFFTRX1 T1_four_S3_reg ( .D(n41), .CK(clk), .RN(n42), .Q(n50) );
  DFFTRX1 T1_four_S1_reg ( .D(n44), .CK(clk), .RN(n57), .QN(n8) );
  EDFFX1 T1_six_S1_reg ( .D(N86), .CK(clk), .E(N93), .QN(n3) );
  EDFFX1 T1_six_S2_reg ( .D(N87), .CK(clk), .E(N93), .QN(n4) );
  EDFFX1 T1_six_S6_reg ( .D(N90), .CK(clk), .E(N93), .QN(n2) );
  DFFX1 T1_six_S4_reg ( .D(n35), .CK(clk), .Q(n37) );
  DFFX1 T1_six_S5_reg ( .D(n36), .CK(clk), .QN(n39) );
endmodule


module t0_cycle ( reset, clk, T0M, T0M_S1, T0M_S2, T0M_S5, T0M_S6 );
  input reset, clk, T0M;
  output T0M_S1, T0M_S2, T0M_S5, T0M_S6;
  wire   T0M_d, N68, N70, N71, N72, N86, N87, N90, N91, N93, n2, n3, n4, n5,
         n6, n7, n8, n9, n10, n11, n14, n15, n16, n17, n18, n19, n22, n23, n26,
         n27, n28, n32, n33, n34, n35, n37, n39, n40, n41, n42, n44, n45, n46,
         n47, n48, n49, n50, n51, n52, n53, n54, n55;
  wire   [3:0] six_state;
  wire   [1:0] four_state;

  OAI32X4 U24 ( .A0(n51), .A1(reset), .A2(n48), .B0(six_state[0]), .B1(reset), 
        .Y(n23) );
  DFFHQX4 T0M_d_reg ( .D(T0M), .CK(clk), .Q(T0M_d) );
  MX2X1 I45 ( .S0(T0M_d), .B(n6), .A(n5), .Y(n47) );
  INVX1 I46 ( .A(n47), .Y(T0M_S5) );
  MXI2X2 I47 ( .S0(T0M_d), .B(n7), .A(n2), .Y(T0M_S6) );
  NAND2X1 I48 ( .A(n48), .B(six_state[1]), .Y(n16) );
  MXI2X1 I49 ( .S0(T0M_d), .B(n8), .A(n3), .Y(T0M_S1) );
  NAND2X1 I50 ( .A(n50), .B(n51), .Y(n14) );
  AND4X2 I51 ( .A(n15), .B(six_state[2]), .C(n53), .D(n10), .Y(n33) );
  NAND2X1 I52 ( .A(n41), .B(n40), .Y(n32) );
  AND4X2 I53 ( .A(six_state[3]), .B(n53), .C(n11), .D(n10), .Y(n34) );
  DFFTRX1 four_state_reg_1_ ( .D(N68), .CK(clk), .RN(n46), .Q(four_state[1]), 
        .QN(n41) );
  DFFTRX1 six_state_reg_3_ ( .D(N72), .CK(clk), .RN(n45), .Q(six_state[3]), 
        .QN(n48) );
  DFFTRX1 six_state_reg_1_ ( .D(N70), .CK(clk), .RN(n45), .Q(six_state[1]), 
        .QN(n50) );
  DFFTRX2 six_state_reg_2_ ( .D(N71), .CK(clk), .RN(n45), .Q(six_state[2]), 
        .QN(n51) );
  DFFTRX1 six_state_reg_0_ ( .D(n49), .CK(clk), .RN(n45), .Q(six_state[0]), 
        .QN(n49) );
  DFFTRX1 four_state_reg_0_ ( .D(n40), .CK(clk), .RN(n46), .Q(four_state[0]), 
        .QN(n40) );
  INVX1 I54 ( .A(n19), .Y(n10) );
  DFFTRX1 four_S4_reg ( .D(n44), .CK(clk), .RN(n39), .QN(n7) );
  INVX1 I55 ( .A(reset), .Y(n53) );
  OAI2BB1X1 I56 ( .A0N(n51), .A1N(n48), .B0(n23), .Y(n22) );
  OR2X2 I57 ( .A(n52), .B(n22), .Y(n19) );
  OR3X2 I58 ( .A(n18), .B(n51), .C(n19), .Y(N93) );
  AND3X1 I59 ( .A(n52), .B(n51), .C(n23), .Y(N86) );
  AND3X2 I60 ( .A(n18), .B(n51), .C(n23), .Y(N87) );
  AND3X2 I61 ( .A(n14), .B(n51), .C(n10), .Y(N90) );
  INVX1 I62 ( .A(n16), .Y(n18) );
  NOR2BX1 I63 ( .AN(n52), .B(n22), .Y(N91) );
  AND2X2 I64 ( .A(n32), .B(n53), .Y(n39) );
  INVX1 I65 ( .A(n26), .Y(n44) );
  INVX1 I66 ( .A(n32), .Y(n42) );
  OAI22X1 I67 ( .A0(n17), .A1(n9), .B0(T0M_d), .B1(n4), .Y(T0M_S2) );
  INVX4 I68 ( .A(T0M_d), .Y(n17) );
  NOR2X1 I69 ( .A(six_state[1]), .B(six_state[3]), .Y(n52) );
  OAI31X1 I70 ( .A0(n51), .A1(n37), .A2(n48), .B0(n14), .Y(n11) );
  OAI2BB1X1 I71 ( .A0N(n35), .A1N(six_state[2]), .B0(n16), .Y(n15) );
  NAND2X1 I72 ( .A(six_state[1]), .B(six_state[0]), .Y(n54) );
  NAND2X1 I73 ( .A(four_state[0]), .B(four_state[1]), .Y(n26) );
  AND3X2 I74 ( .A(n27), .B(n53), .C(n28), .Y(n45) );
  INVX1 I75 ( .A(T0M), .Y(n27) );
  OR4X2 I76 ( .A(n50), .B(n49), .C(six_state[2]), .D(n48), .Y(n28) );
  AND3X2 I77 ( .A(T0M), .B(n53), .C(n26), .Y(n46) );
  XNOR2X1 I78 ( .A(six_state[2]), .B(n54), .Y(N71) );
  XOR2X1 I79 ( .A(six_state[1]), .B(six_state[0]), .Y(N70) );
  XOR2X1 I80 ( .A(four_state[1]), .B(four_state[0]), .Y(N68) );
  XOR2X1 I81 ( .A(six_state[3]), .B(n55), .Y(N72) );
  NOR2X1 I82 ( .A(n54), .B(n51), .Y(n55) );
  DFFTRX1 four_S1_reg ( .D(n42), .CK(clk), .RN(n53), .QN(n8) );
  DFFTRX1 four_S2_reg ( .D(n39), .CK(clk), .RN(n41), .QN(n9) );
  EDFFX1 six_S1_reg ( .D(N86), .CK(clk), .E(N93), .QN(n3) );
  EDFFX1 six_S2_reg ( .D(N87), .CK(clk), .E(N93), .QN(n4) );
  DFFTRX1 four_S3_reg ( .D(n39), .CK(clk), .RN(n40), .QN(n6) );
  EDFFX1 six_S6_reg ( .D(N90), .CK(clk), .E(N93), .QN(n2) );
  EDFFX1 six_S3_reg ( .D(N91), .CK(clk), .E(N93), .QN(n5) );
  DFFX1 six_S4_reg ( .D(n33), .CK(clk), .Q(n35) );
  DFFX1 six_S5_reg ( .D(n34), .CK(clk), .QN(n37) );
endmodule


module peri_cycle ( end_of_inst, pcon_idle, pre_pdwn, POR, reset, clk, 
        Z_update, peri_state );
  output [2:0] peri_state;
  input end_of_inst, pcon_idle, pre_pdwn, POR, reset, clk;
  output Z_update;
  wire   n30, n32, N13, N35, N36, N37, N39, N41, N42, n2, n3, n4, n5, n8, n9,
         n10, n11, n12, n14, n15, n16, n17, n19, n20, n21, n22, n23, n24, n27,
         n28, n29;
  wire   [1:0] mach_cycle;

  OAI32X4 U3 ( .A0(n2), .A1(n3), .A2(n4), .B0(n5), .B1(n27), .Y(n23) );
  DFFRHQX4 peri_state_reg_2_ ( .D(N42), .CK(clk), .RN(n19), .Q(peri_state[2])
         );
  NOR2X1 I29 ( .A(n27), .B(mach_cycle[0]), .Y(n4) );
  NOR2X1 I30 ( .A(mach_cycle[1]), .B(n2), .Y(n10) );
  INVX2 I31 ( .A(n14), .Y(peri_state[1]) );
  INVX2 I32 ( .A(N35), .Y(peri_state[0]) );
  OAI31X1 I33 ( .A0(n17), .A1(n30), .A2(n32), .B0(n28), .Y(n16) );
  DFFRX1 mach_cycle_reg_1_ ( .D(n21), .CK(clk), .RN(n19), .Q(mach_cycle[1]), 
        .QN(n27) );
  DFFRX1 mach_cycle_reg_0_ ( .D(n20), .CK(clk), .RN(n19), .Q(mach_cycle[0]), 
        .QN(n24) );
  DFFRHQX1 peri_state_reg_1_ ( .D(N41), .CK(clk), .RN(n19), .Q(n30) );
  DFFRHQX1 peri_state_reg_0_ ( .D(N13), .CK(clk), .RN(n19), .Q(n32) );
  OR4X1 I34 ( .A(peri_state[0]), .B(n17), .C(reset), .D(peri_state[1]), .Y(n2)
         );
  INVX1 I35 ( .A(pre_pdwn), .Y(n8) );
  INVX1 I36 ( .A(reset), .Y(n28) );
  INVX1 I37 ( .A(n2), .Y(n5) );
  OAI2BB2X1 I38 ( .A0N(N35), .A1N(n15), .B0(pre_pdwn), .B1(n2), .Y(N13) );
  INVX1 I39 ( .A(n32), .Y(N35) );
  NOR2BX1 U27 ( .AN(n22), .B(reset), .Y(n20) );
  OAI2BB1X1 I40 ( .A0N(mach_cycle[0]), .A1N(n2), .B0(n9), .Y(n22) );
  OAI211X1 I41 ( .A0(n10), .A1(mach_cycle[0]), .B0(n24), .C0(n8), .Y(n9) );
  NOR2BX1 U28 ( .AN(n23), .B(reset), .Y(n21) );
  NAND2X1 I42 ( .A(N39), .B(n8), .Y(n3) );
  OAI2BB1X2 I43 ( .A0N(end_of_inst), .A1N(n11), .B0(n12), .Y(Z_update) );
  OR4X1 I44 ( .A(N35), .B(n14), .C(peri_state[2]), .D(n11), .Y(n12) );
  INVX1 I45 ( .A(pcon_idle), .Y(n11) );
  INVX1 I46 ( .A(n30), .Y(n14) );
  INVX1 I47 ( .A(peri_state[2]), .Y(n17) );
  XNOR2X1 I48 ( .A(n27), .B(mach_cycle[0]), .Y(N39) );
  INVX1 I49 ( .A(n16), .Y(n15) );
  AND2X2 I50 ( .A(N37), .B(n15), .Y(N42) );
  XNOR2X1 I51 ( .A(peri_state[2]), .B(n29), .Y(N37) );
  NAND2X1 I52 ( .A(peri_state[1]), .B(peri_state[0]), .Y(n29) );
  AND2X2 I53 ( .A(N36), .B(n15), .Y(N41) );
  XOR2X1 I54 ( .A(peri_state[1]), .B(peri_state[0]), .Y(N36) );
  INVX2 I55 ( .A(POR), .Y(n19) );
endmodule


module interrupt ( EWDI, STOPwake_WDT, DIR_WR, LVD_intr, POR, sw_rst, clk, 
        pin_INT0, pin_INT1, pin_INT2, pin_INT3, pin_INT4, pin_INT5, TF0, TF1, 
        adc_intr, t2_intr, ua_intr, wdt_intr, pwm1_intr, pwm2_intr, pr_st, 
        RETI_end, RETI_NFC, SFR_wr, SFR_bus, TCON_sel, EXIF_sel, IE_sel, 
        IP_sel, EIE_sel, EIP_sel, IPH_sel, clear_TF0, clear_TF1, TCON30, 
        inter_vector, inter_LCALL, sample_INT0, sample_INT1, interrupt_ack, 
        STOPwake_INT0, STOPwake_INT1, INT_SFR_OUT );
  input [2:0] pr_st;
  input [7:0] SFR_bus;
  output [3:0] TCON30;
  output [7:0] inter_vector;
  output [7:0] INT_SFR_OUT;
  input DIR_WR, LVD_intr, POR, sw_rst, clk, pin_INT0, pin_INT1, pin_INT2,
         pin_INT3, pin_INT4, pin_INT5, TF0, TF1, adc_intr, t2_intr, ua_intr,
         wdt_intr, pwm1_intr, pwm2_intr, RETI_end, RETI_NFC, SFR_wr, TCON_sel,
         EXIF_sel, IE_sel, IP_sel, EIE_sel, EIP_sel, IPH_sel;
  output EWDI, STOPwake_WDT, clear_TF0, clear_TF1, inter_LCALL, sample_INT0,
         sample_INT1, interrupt_ack, STOPwake_INT0, STOPwake_INT1;
  wire   ir_EX1, ir_EX0, ir_clr_IE0, ir_clr_IE1, tcon_IE0, tcon_IE1,
         INT_SFR_sel;
  wire   [7:0] IE;
  wire   [7:0] IPH;
  wire   [7:0] IP;
  wire   [4:0] new_src;
  wire   [2:0] new_pri;
  wire   [7:0] EIE;
  wire   [7:0] EIP;
  wire   [7:0] EXIF;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1;

  ir_ext ir_ext ( .SFR_bus(SFR_bus), .EXIF(EXIF), .pin_INT2(pin_INT2), 
        .pin_INT3(pin_INT3), .pin_INT4(pin_INT4), .pin_INT5(pin_INT5), 
        .EXIF_sel(EXIF_sel), .TCON_sel(TCON_sel), .SFR_wr(SFR_wr), .sw_rst(
        sw_rst), .clk(clk), .pr_st(pr_st), .pin_INT0(pin_INT0), .pin_INT1(
        pin_INT1), .ir_EX1(ir_EX1), .ir_EX0(ir_EX0), .tcon_IE0(tcon_IE0), 
        .tcon_IE1(tcon_IE1), .STOPwake_INT0(STOPwake_INT0), .STOPwake_INT1(
        STOPwake_INT1), .ir_clr_IE0(ir_clr_IE0), .ir_clr_IE1(ir_clr_IE1), 
        .TCON30(TCON30), .sample_INT0(sample_INT0), .sample_INT1(sample_INT1), 
        .POR(POR) );
  ir_ctrl ir_ctrl ( .POR(POR), .DIR_WR(DIR_WR), .pr_st(pr_st), .RETI_end(
        RETI_end), .RETI_NFC(RETI_NFC), .INT_SFR_sel(INT_SFR_sel), .new_src(
        new_src), .new_pri(new_pri), .sw_rst(sw_rst), .clk(clk), 
        .inter_vector({SYNOPSYS_UNCONNECTED__0, inter_vector[6:3], 
        SYNOPSYS_UNCONNECTED__1, inter_vector[1:0]}), .inter_LCALL(inter_LCALL), .interrupt_ack(interrupt_ack), .clear_TF1(clear_TF1), .ir_clr_IE1(ir_clr_IE1), .clear_TF0(clear_TF0), .ir_clr_IE0(ir_clr_IE0) );
  ir_poll ir_poll ( .STOPwake_WDT(STOPwake_WDT), .LVD_intr(LVD_intr), .EIE(EIE), .EIP(EIP), .exif_IE2(EXIF[4]), .exif_IE3(EXIF[5]), .exif_IE4(EXIF[6]), 
        .exif_IE5(EXIF[7]), .wdt_intr(wdt_intr), .pwm1_intr(pwm1_intr), 
        .pwm2_intr(pwm2_intr), .IE(IE), .IPH(IPH), .IP(IP), .adc_intr(adc_intr), .t2_intr(t2_intr), .ua_intr(ua_intr), .TF1(TF1), .tcon_IE1(tcon_IE1), .TF0(
        TF0), .tcon_IE0(tcon_IE0), .new_src(new_src), .new_pri(new_pri), 
        .ir_EX1(ir_EX1), .ir_EX0(ir_EX0) );
  ip_dp ip_dp ( .EWDI(EWDI), .sw_rst(sw_rst), .clk(clk), .SFR_wr(SFR_wr), 
        .SFR_bus(SFR_bus), .IE_sel(IE_sel), .IP_sel(IP_sel), .IPH_sel(IPH_sel), 
        .EIE_sel(EIE_sel), .EIP_sel(EIP_sel), .EXIF_sel(EXIF_sel), .EXIF(EXIF), 
        .EIE(EIE), .EIP(EIP), .IE(IE), .IPH(IPH), .IP(IP), .INT_SFR_sel(
        INT_SFR_sel), .INT_SFR_OUT(INT_SFR_OUT) );
  INVX1 I1 ( .A(1'b1), .Y(inter_vector[2]) );
  INVX1 I3 ( .A(1'b1), .Y(inter_vector[7]) );
endmodule


module ip_dp ( EWDI, sw_rst, clk, SFR_wr, SFR_bus, IE_sel, IP_sel, IPH_sel, 
        EIE_sel, EIP_sel, EXIF_sel, EXIF, EIE, EIP, IE, IPH, IP, INT_SFR_sel, 
        INT_SFR_OUT );
  input [7:0] SFR_bus;
  input [7:0] EXIF;
  output [7:0] EIE;
  output [7:0] EIP;
  output [7:0] IE;
  output [7:0] IPH;
  output [7:0] IP;
  output [7:0] INT_SFR_OUT;
  input sw_rst, clk, SFR_wr, IE_sel, IP_sel, IPH_sel, EIE_sel, EIP_sel,
         EXIF_sel;
  output EWDI, INT_SFR_sel;
  wire   N19, N20, N21, N22, N23, N24, N25, N26, N30, N31, N32, N33, N34, N35,
         N36, N37, N40, N41, N42, N43, N44, N45, N46, N47, N50, N51, N52, N53,
         N54, N55, N56, N59, N60, N61, N62, N63, N64, N65, N67, N68, N69, N70,
         N71, n4, n6, n9, n10, n13, n14, n17, n190, n210, n220, n250, n260,
         n27, n300, n310, n320, n330, n340, n350, n360, n370, n38, n39, n400,
         n410, n420, n430, n440, n450, n460, n470, n48, n49, n500, n530, n550,
         n57, n58, n590, n600, n610, n620, n630, n640, n650, n670, n680;

  AOI221X4 U64 ( .A0(EIP[7]), .A1(n600), .B0(EXIF[7]), .B1(n650), .C0(n250), 
        .Y(n220) );
  AOI222X4 U66 ( .A0(EIE[7]), .A1(n590), .B0(IP[7]), .B1(IP_sel), .C0(IPH[7]), 
        .C1(n610), .Y(n27) );
  AOI221X4 U68 ( .A0(EIP[6]), .A1(n600), .B0(EXIF[6]), .B1(n650), .C0(n310), 
        .Y(n300) );
  AOI222X4 U70 ( .A0(EIE[6]), .A1(n590), .B0(IP[6]), .B1(IP_sel), .C0(IPH[6]), 
        .C1(n610), .Y(n320) );
  AOI221X4 U72 ( .A0(EIP[5]), .A1(n600), .B0(EXIF[5]), .B1(n650), .C0(n340), 
        .Y(n330) );
  AOI222X4 U74 ( .A0(EIE[5]), .A1(n590), .B0(IP[5]), .B1(IP_sel), .C0(IPH[5]), 
        .C1(n610), .Y(n350) );
  AOI221X4 U76 ( .A0(EIP[4]), .A1(n600), .B0(EXIF[4]), .B1(n650), .C0(n370), 
        .Y(n360) );
  AOI222X4 U78 ( .A0(EWDI), .A1(n590), .B0(IP[4]), .B1(IP_sel), .C0(IPH[4]), 
        .C1(n610), .Y(n38) );
  AOI221X4 U80 ( .A0(EIP[3]), .A1(n600), .B0(EXIF[3]), .B1(n650), .C0(n400), 
        .Y(n39) );
  AOI222X4 U82 ( .A0(EIE[3]), .A1(n590), .B0(IP[3]), .B1(IP_sel), .C0(IPH[3]), 
        .C1(n610), .Y(n410) );
  AOI221X4 U84 ( .A0(EIP[2]), .A1(n600), .B0(EXIF[2]), .B1(n650), .C0(n430), 
        .Y(n420) );
  AOI222X4 U86 ( .A0(EIE[2]), .A1(n590), .B0(IP[2]), .B1(IP_sel), .C0(IPH[2]), 
        .C1(n610), .Y(n440) );
  AOI221X4 U88 ( .A0(EIP[1]), .A1(n600), .B0(EXIF[1]), .B1(n650), .C0(n460), 
        .Y(n450) );
  AOI222X4 U90 ( .A0(EIE[1]), .A1(n590), .B0(IP[1]), .B1(IP_sel), .C0(IPH[1]), 
        .C1(n610), .Y(n470) );
  AOI221X4 U92 ( .A0(EIP[0]), .A1(n600), .B0(EXIF[0]), .B1(n650), .C0(n49), 
        .Y(n48) );
  INVX1 I110 ( .A(IPH_sel), .Y(n13) );
  NOR2X2 I111 ( .A(IP_sel), .B(n13), .Y(n610) );
  INVX1 I112 ( .A(EXIF_sel), .Y(n550) );
  INVX2 I113 ( .A(n14), .Y(n6) );
  EDFFX2 IPH_reg_6_ ( .D(N56), .CK(clk), .E(N70), .Q(IPH[6]) );
  EDFFX1 IPH_reg_5_ ( .D(N55), .CK(clk), .E(N70), .Q(IPH[5]) );
  NOR2X2 I114 ( .A(n10), .B(n13), .Y(n640) );
  NOR2X2 I115 ( .A(n10), .B(n190), .Y(n620) );
  NOR2X2 I116 ( .A(n17), .B(n530), .Y(n600) );
  OR3X2 I117 ( .A(EIE_sel), .B(IPH_sel), .C(IP_sel), .Y(n530) );
  NOR2X2 I118 ( .A(n10), .B(n17), .Y(n630) );
  NOR3X4 I119 ( .A(EIP_sel), .B(n550), .C(n530), .Y(n650) );
  OR3X2 I120 ( .A(IP_sel), .B(IPH_sel), .C(n190), .Y(n58) );
  INVX2 I121 ( .A(n58), .Y(n590) );
  AOI222X4 I122 ( .A0(EIE[0]), .A1(n590), .B0(IP[0]), .B1(IP_sel), .C0(IPH[0]), 
        .C1(n610), .Y(n500) );
  INVX1 I123 ( .A(n450), .Y(INT_SFR_OUT[1]) );
  INVX1 I124 ( .A(n48), .Y(INT_SFR_OUT[0]) );
  AND2X1 I125 ( .A(n640), .B(SFR_bus[6]), .Y(N56) );
  AND2X1 I126 ( .A(n640), .B(SFR_bus[5]), .Y(N55) );
  AND2X1 I127 ( .A(n620), .B(SFR_bus[7]), .Y(N26) );
  AND2X1 I128 ( .A(n620), .B(SFR_bus[6]), .Y(N25) );
  AND2X1 I129 ( .A(n620), .B(SFR_bus[5]), .Y(N24) );
  AND2X1 I130 ( .A(n620), .B(SFR_bus[4]), .Y(N23) );
  AND2X1 I131 ( .A(n620), .B(SFR_bus[3]), .Y(N22) );
  AND2X1 I132 ( .A(n620), .B(SFR_bus[2]), .Y(N21) );
  AND2X1 I133 ( .A(n630), .B(SFR_bus[7]), .Y(N37) );
  AND2X1 I134 ( .A(n630), .B(SFR_bus[6]), .Y(N36) );
  AND2X1 I135 ( .A(n630), .B(SFR_bus[5]), .Y(N35) );
  AND2X1 I136 ( .A(n630), .B(SFR_bus[4]), .Y(N34) );
  AND2X1 I137 ( .A(n630), .B(SFR_bus[3]), .Y(N33) );
  AND2X1 I138 ( .A(n630), .B(SFR_bus[2]), .Y(N32) );
  AND2X1 I139 ( .A(n640), .B(SFR_bus[4]), .Y(N54) );
  AND2X1 I140 ( .A(n640), .B(SFR_bus[3]), .Y(N53) );
  AND2X1 I141 ( .A(n640), .B(SFR_bus[2]), .Y(N52) );
  NAND2BX1 I142 ( .AN(n10), .B(IP_sel), .Y(n9) );
  INVX1 I143 ( .A(n680), .Y(n670) );
  OR2X1 I144 ( .A(IE_sel), .B(n210), .Y(INT_SFR_sel) );
  NAND2BX1 I145 ( .AN(n10), .B(IE_sel), .Y(n14) );
  INVX1 I146 ( .A(sw_rst), .Y(n680) );
  OR2X2 I147 ( .A(n4), .B(n670), .Y(N71) );
  OR2X2 I148 ( .A(n620), .B(n670), .Y(N67) );
  OR2X2 I149 ( .A(n630), .B(n670), .Y(N68) );
  OR2X2 I150 ( .A(n640), .B(n670), .Y(N70) );
  INVX1 I151 ( .A(n210), .Y(n260) );
  INVX1 I152 ( .A(EIE_sel), .Y(n190) );
  EDFFX1 EIP_reg_1_ ( .D(N31), .CK(clk), .E(N68), .Q(EIP[1]) );
  EDFFX1 EIP_reg_0_ ( .D(N30), .CK(clk), .E(N68), .Q(EIP[0]) );
  EDFFX1 IE_reg_7_ ( .D(N47), .CK(clk), .E(N69), .Q(IE[7]) );
  EDFFX1 IP_reg_1_ ( .D(N60), .CK(clk), .E(N71), .Q(IP[1]) );
  EDFFX1 IP_reg_0_ ( .D(N59), .CK(clk), .E(N71), .Q(IP[0]) );
  EDFFX1 IPH_reg_1_ ( .D(N51), .CK(clk), .E(N70), .Q(IPH[1]) );
  EDFFX1 IPH_reg_0_ ( .D(N50), .CK(clk), .E(N70), .Q(IPH[0]) );
  EDFFX1 IE_reg_2_ ( .D(N42), .CK(clk), .E(N69), .Q(IE[2]) );
  EDFFX1 IE_reg_0_ ( .D(N40), .CK(clk), .E(N69), .Q(IE[0]) );
  EDFFX1 IE_reg_1_ ( .D(N41), .CK(clk), .E(N69), .Q(IE[1]) );
  EDFFX1 EIE_reg_1_ ( .D(N20), .CK(clk), .E(N67), .Q(EIE[1]) );
  EDFFX1 EIE_reg_0_ ( .D(N19), .CK(clk), .E(N67), .Q(EIE[0]) );
  EDFFX1 IP_reg_6_ ( .D(N65), .CK(clk), .E(N71), .Q(IP[6]) );
  EDFFX1 IP_reg_5_ ( .D(N64), .CK(clk), .E(N71), .Q(IP[5]) );
  EDFFX1 EIP_reg_3_ ( .D(N33), .CK(clk), .E(N68), .Q(EIP[3]) );
  EDFFX1 EIP_reg_2_ ( .D(N32), .CK(clk), .E(N68), .Q(EIP[2]) );
  EDFFX1 IP_reg_4_ ( .D(N63), .CK(clk), .E(N71), .Q(IP[4]) );
  EDFFX1 IP_reg_3_ ( .D(N62), .CK(clk), .E(N71), .Q(IP[3]) );
  EDFFX1 IP_reg_2_ ( .D(N61), .CK(clk), .E(N71), .Q(IP[2]) );
  EDFFX1 EIE_reg_4_ ( .D(N23), .CK(clk), .E(N67), .Q(EIE[4]), .QN(n57) );
  EDFFX1 IE_reg_6_ ( .D(N46), .CK(clk), .E(N69), .Q(IE[6]) );
  EDFFX1 IE_reg_5_ ( .D(N45), .CK(clk), .E(N69), .Q(IE[5]) );
  EDFFX1 IE_reg_4_ ( .D(N44), .CK(clk), .E(N69), .Q(IE[4]) );
  EDFFX1 IE_reg_3_ ( .D(N43), .CK(clk), .E(N69), .Q(IE[3]) );
  EDFFX1 EIE_reg_3_ ( .D(N22), .CK(clk), .E(N67), .Q(EIE[3]) );
  EDFFX1 EIE_reg_2_ ( .D(N21), .CK(clk), .E(N67), .Q(EIE[2]) );
  EDFFX1 EIP_reg_5_ ( .D(N35), .CK(clk), .E(N68), .Q(EIP[5]) );
  EDFFX1 EIP_reg_4_ ( .D(N34), .CK(clk), .E(N68), .Q(EIP[4]) );
  EDFFX1 IPH_reg_4_ ( .D(N54), .CK(clk), .E(N70), .Q(IPH[4]) );
  EDFFX1 IPH_reg_3_ ( .D(N53), .CK(clk), .E(N70), .Q(IPH[3]) );
  EDFFX1 IPH_reg_2_ ( .D(N52), .CK(clk), .E(N70), .Q(IPH[2]) );
  EDFFX1 EIE_reg_6_ ( .D(N25), .CK(clk), .E(N67), .Q(EIE[6]) );
  EDFFX1 EIE_reg_5_ ( .D(N24), .CK(clk), .E(N67), .Q(EIE[5]) );
  OR2X2 I153 ( .A(n6), .B(n670), .Y(N69) );
  INVX2 I154 ( .A(n9), .Y(n4) );
  OR3X2 I155 ( .A(EXIF_sel), .B(EIP_sel), .C(n530), .Y(n210) );
  INVX1 I156 ( .A(EIP_sel), .Y(n17) );
  AND2X2 I157 ( .A(n6), .B(SFR_bus[3]), .Y(N43) );
  AND2X2 I158 ( .A(n6), .B(SFR_bus[2]), .Y(N42) );
  AND2X2 I159 ( .A(n6), .B(SFR_bus[5]), .Y(N45) );
  AND2X2 I160 ( .A(n6), .B(SFR_bus[4]), .Y(N44) );
  AND2X2 I161 ( .A(n6), .B(SFR_bus[6]), .Y(N46) );
  AND2X2 I162 ( .A(SFR_bus[3]), .B(n4), .Y(N62) );
  AND2X2 I163 ( .A(SFR_bus[7]), .B(n6), .Y(N47) );
  AND2X2 I164 ( .A(SFR_bus[6]), .B(n4), .Y(N65) );
  AND2X2 I165 ( .A(SFR_bus[5]), .B(n4), .Y(N64) );
  AND2X2 I166 ( .A(SFR_bus[4]), .B(n4), .Y(N63) );
  AND2X2 I167 ( .A(SFR_bus[2]), .B(n4), .Y(N61) );
  NAND2X2 I168 ( .A(SFR_wr), .B(n680), .Y(n10) );
  OAI2BB1X1 I169 ( .A0N(IE[0]), .A1N(n260), .B0(n500), .Y(n49) );
  OAI2BB1X1 I170 ( .A0N(IE[1]), .A1N(n260), .B0(n470), .Y(n460) );
  INVX1 I171 ( .A(n220), .Y(INT_SFR_OUT[7]) );
  OAI2BB1X1 I172 ( .A0N(IE[7]), .A1N(n260), .B0(n27), .Y(n250) );
  INVX1 I173 ( .A(n300), .Y(INT_SFR_OUT[6]) );
  INVX1 I174 ( .A(n39), .Y(INT_SFR_OUT[3]) );
  INVX1 I175 ( .A(n420), .Y(INT_SFR_OUT[2]) );
  INVX1 I176 ( .A(n360), .Y(INT_SFR_OUT[4]) );
  OAI2BB1X1 I177 ( .A0N(IE[6]), .A1N(n260), .B0(n320), .Y(n310) );
  OAI2BB1X1 I178 ( .A0N(IE[5]), .A1N(n260), .B0(n350), .Y(n340) );
  OAI2BB1X1 I179 ( .A0N(IE[3]), .A1N(n260), .B0(n410), .Y(n400) );
  OAI2BB1X1 I180 ( .A0N(IE[2]), .A1N(n260), .B0(n440), .Y(n430) );
  OAI2BB1X1 I181 ( .A0N(IE[4]), .A1N(n260), .B0(n38), .Y(n370) );
  INVX1 I182 ( .A(n57), .Y(EWDI) );
  INVX1 I183 ( .A(n330), .Y(INT_SFR_OUT[5]) );
  EDFFX1 EIE_reg_7_ ( .D(N26), .CK(clk), .E(N67), .Q(EIE[7]) );
  EDFFX1 IP_reg_7_ ( .D(1'b1), .CK(clk), .E(N71), .Q(IP[7]) );
  EDFFX1 IPH_reg_7_ ( .D(1'b1), .CK(clk), .E(N70), .Q(IPH[7]) );
  EDFFX1 EIP_reg_6_ ( .D(N36), .CK(clk), .E(N68), .Q(EIP[6]) );
  EDFFX1 EIP_reg_7_ ( .D(N37), .CK(clk), .E(N68), .Q(EIP[7]) );
  AND2X1 I184 ( .A(n6), .B(SFR_bus[1]), .Y(N41) );
  AND2X1 I185 ( .A(n630), .B(SFR_bus[1]), .Y(N31) );
  AND2X1 I186 ( .A(n620), .B(SFR_bus[1]), .Y(N20) );
  AND2X1 I187 ( .A(n630), .B(SFR_bus[0]), .Y(N30) );
  AND2X1 I188 ( .A(n620), .B(SFR_bus[0]), .Y(N19) );
  AND2X1 I189 ( .A(n640), .B(SFR_bus[0]), .Y(N50) );
  AND2X1 I190 ( .A(SFR_bus[0]), .B(n4), .Y(N59) );
  AND2X1 I191 ( .A(n6), .B(SFR_bus[0]), .Y(N40) );
  AND2X1 I192 ( .A(SFR_bus[1]), .B(n4), .Y(N60) );
  AND2X1 I193 ( .A(n640), .B(SFR_bus[1]), .Y(N51) );
endmodule


module ir_poll ( STOPwake_WDT, LVD_intr, EIE, EIP, exif_IE2, exif_IE3, 
        exif_IE4, exif_IE5, wdt_intr, pwm1_intr, pwm2_intr, IE, IPH, IP, 
        adc_intr, t2_intr, ua_intr, TF1, tcon_IE1, TF0, tcon_IE0, new_src, 
        new_pri, ir_EX1, ir_EX0 );
  input [7:0] EIE;
  input [7:0] EIP;
  input [7:0] IE;
  input [7:0] IPH;
  input [7:0] IP;
  output [4:0] new_src;
  output [2:0] new_pri;
  input LVD_intr, exif_IE2, exif_IE3, exif_IE4, exif_IE5, wdt_intr, pwm1_intr,
         pwm2_intr, adc_intr, t2_intr, ua_intr, TF1, tcon_IE1, TF0, tcon_IE0;
  output STOPwake_WDT, ir_EX1, ir_EX0;
  wire   n2, n4, n5, n6, n7, n8, n9, n10, n12, n13, n15, n16, n17, n18, n20,
         n21, n22, n23, n24, n25, n26, n27, n28, n29, n30, n31, n32, n33, n34,
         n35, n36, n37, n38, n39, n40, n41, n42, n43, n44, n45, n46, n48, n49,
         n50, n51, n52, n53, n54, n55, n57, n58, n62, n63, n64, n65, n66, n67,
         n68, n69, n70, n71, n72, n73, n74, n75, n76, n77, n78, n79, n80, n81,
         n82, n85, n86, n87, n88, n89, n90, n91, n95, n96, n97, n100, n102,
         n104, n105, n106, n107, n108, n109, n110, n111, n112, n113, n114,
         n119, n120, n121, n122, n123, n124, n129, n130, n131, n133, n134,
         n136, n137, n138, n139, n141, n143, n144, n145, n146, n147, n149,
         n150, n151, n153, n154, n155, n156, n157, n158, n159, n160, n164,
         n165, n166, n167, n168, n169, n170, n171, n181, n182, n183, n184,
         n185, n189, n191, n192, n193, n194, n195, n196, n197, n198, n201,
         n202, n203, n206, n207, n208, n210, n213, n214, n215, n216, n219,
         n220, n221, n222, n226, n227, n231, n235, n238, n239, n240, n241,
         n242, n243, n244, n245, n246, n247, n248, n249, n250, n251, n252,
         n253, n254, n256, n258, n259, n261;

  OAI211X4 U10 ( .A0(n16), .A1(n17), .B0(n18), .C0(n252), .Y(n15) );
  OAI33X4 U16 ( .A0(n35), .A1(n36), .A2(n37), .B0(n38), .B1(n39), .B2(n40), 
        .Y(n24) );
  OAI211X4 U24 ( .A0(n53), .A1(n13), .B0(n54), .C0(n55), .Y(n26) );
  AOI222X4 U33 ( .A0(n73), .A1(n74), .B0(n75), .B1(n76), .C0(n37), .C1(n42), 
        .Y(n51) );
  OAI32X4 U97 ( .A0(n38), .A1(n253), .A2(n141), .B0(n249), .B1(n143), .Y(n88)
         );
  OAI31X4 U123 ( .A0(n154), .A1(n167), .A2(n168), .B0(n169), .Y(n139) );
  OAI211X4 U193 ( .A0(n10), .A1(n215), .B0(n41), .C0(n216), .Y(n203) );
  NAND2X1 I249 ( .A(n133), .B(n114), .Y(n81) );
  NAND2X1 I250 ( .A(n130), .B(n71), .Y(n108) );
  NAND3BX1 I251 ( .AN(n157), .B(n158), .C(n171), .Y(n160) );
  NAND4BX1 I252 ( .AN(n131), .B(IPH[6]), .C(n207), .D(n208), .Y(n210) );
  NAND3BX1 I253 ( .AN(n79), .B(n80), .C(n106), .Y(n49) );
  NAND4BX1 I254 ( .AN(n203), .B(n210), .C(n144), .D(n54), .Y(n95) );
  NAND3BX1 I255 ( .AN(n82), .B(n31), .C(n194), .Y(n183) );
  NAND4X1 I256 ( .A(n5), .B(n6), .C(n2), .D(n4), .Y(new_src[4]) );
  NAND3BX1 I257 ( .AN(n131), .B(n226), .C(n235), .Y(n247) );
  NAND3BX1 I258 ( .AN(n81), .B(n46), .C(n10), .Y(n72) );
  NAND2BX1 I259 ( .AN(n49), .B(n48), .Y(n66) );
  NAND4X1 I260 ( .A(n241), .B(n227), .C(n226), .D(n247), .Y(n149) );
  NAND2BX1 I261 ( .AN(n248), .B(n136), .Y(n82) );
  NAND2X1 I262 ( .A(n193), .B(n191), .Y(n182) );
  AND3X2 I263 ( .A(n46), .B(n43), .C(n65), .Y(n8) );
  NAND2BX1 I264 ( .AN(n249), .B(n143), .Y(n37) );
  NAND2BX1 I265 ( .AN(n160), .B(n159), .Y(n166) );
  NAND3BX1 I266 ( .AN(n250), .B(n31), .C(n28), .Y(n185) );
  NAND2BX1 I267 ( .AN(n253), .B(n141), .Y(n40) );
  OAI211X1 I268 ( .A0(n238), .A1(n239), .B0(n86), .C0(n85), .Y(n240) );
  INVX1 I269 ( .A(n82), .Y(n238) );
  INVX1 I270 ( .A(n31), .Y(n239) );
  INVX1 I271 ( .A(n240), .Y(n50) );
  NAND2BX1 I272 ( .AN(n256), .B(n17), .Y(n79) );
  NAND3BX1 I273 ( .AN(n226), .B(n241), .C(n227), .Y(n57) );
  INVX1 I274 ( .A(n222), .Y(n241) );
  NAND2X1 I275 ( .A(n155), .B(n168), .Y(n157) );
  AOI31X1 I276 ( .A0(n64), .A1(n63), .A2(n242), .B0(n2), .Y(n243) );
  INVX1 I277 ( .A(n250), .Y(n242) );
  INVX1 I278 ( .A(n243), .Y(n58) );
  BUFX4 I279 ( .A(IE[7]), .Y(n261) );
  NAND2X1 I280 ( .A(tcon_IE1), .B(ir_EX1), .Y(n133) );
  OR2X2 I281 ( .A(n37), .B(n231), .Y(n222) );
  OAI31X1 I282 ( .A0(n10), .A1(n198), .A2(n215), .B0(n42), .Y(n231) );
  NAND3X2 I283 ( .A(IE[1]), .B(TF0), .C(n261), .Y(n114) );
  OR2X2 I284 ( .A(n62), .B(n146), .Y(new_pri[0]) );
  NAND3X1 I285 ( .A(IE[6]), .B(adc_intr), .C(n261), .Y(n131) );
  NAND3X2 I286 ( .A(TF1), .B(IE[3]), .C(n261), .Y(n10) );
  NAND3X2 I287 ( .A(IE[4]), .B(ua_intr), .C(n261), .Y(n130) );
  NAND2X2 I288 ( .A(tcon_IE0), .B(ir_EX0), .Y(n46) );
  OR2X2 I289 ( .A(n46), .B(n221), .Y(n41) );
  AND3X2 I290 ( .A(n256), .B(n17), .C(n104), .Y(n100) );
  OAI211X1 I291 ( .A0(n248), .A1(n136), .B0(n137), .C0(n138), .Y(n134) );
  OR2X2 I292 ( .A(n5), .B(n147), .Y(n38) );
  NOR2X1 I293 ( .A(n139), .B(n153), .Y(n244) );
  NOR2X1 I294 ( .A(n203), .B(n210), .Y(n245) );
  OAI221X4 I295 ( .A0(n38), .A1(n41), .B0(n91), .B1(n13), .C0(n258), .Y(n90)
         );
  OR2X2 I296 ( .A(n95), .B(n96), .Y(n13) );
  OR3X2 I297 ( .A(n147), .B(n95), .C(n150), .Y(n2) );
  NOR3X2 I298 ( .A(n69), .B(n66), .C(n16), .Y(n251) );
  OR3X2 I299 ( .A(n107), .B(n108), .C(n72), .Y(n16) );
  NAND3X1 I300 ( .A(IE[5]), .B(t2_intr), .C(n261), .Y(n129) );
  NAND3X1 I301 ( .A(EIE[6]), .B(pwm2_intr), .C(n261), .Y(n124) );
  INVX1 I302 ( .A(n259), .Y(new_pri[2]) );
  INVX1 I303 ( .A(n13), .Y(n73) );
  INVX1 I304 ( .A(n82), .Y(n32) );
  NAND3X1 I305 ( .A(n151), .B(n137), .C(n244), .Y(n96) );
  AND3X2 I306 ( .A(n32), .B(n194), .C(n63), .Y(n151) );
  OR2X2 I307 ( .A(n76), .B(n146), .Y(new_pri[1]) );
  AND3X2 I308 ( .A(n7), .B(n8), .C(n9), .Y(n4) );
  INVX1 I309 ( .A(n2), .Y(n62) );
  OAI211X1 I310 ( .A0(n50), .A1(n2), .B0(n51), .C0(n52), .Y(new_src[1]) );
  INVX1 I311 ( .A(n26), .Y(n52) );
  INVX1 I312 ( .A(n193), .Y(n189) );
  INVX1 I313 ( .A(n38), .Y(n76) );
  OR3X2 I314 ( .A(n206), .B(n207), .C(n203), .Y(n54) );
  OR2X2 I315 ( .A(n222), .B(n227), .Y(n145) );
  INVX1 I316 ( .A(n185), .Y(n137) );
  OR2X2 I317 ( .A(n203), .B(n208), .Y(n144) );
  OR2X2 I318 ( .A(n183), .B(n193), .Y(n28) );
  OR4X1 I319 ( .A(n87), .B(n88), .C(n89), .D(n90), .Y(new_src[0]) );
  OAI211X1 I320 ( .A0(n38), .A1(n144), .B0(n145), .C0(n42), .Y(n87) );
  AND2X2 I321 ( .A(n62), .B(n134), .Y(n89) );
  INVX1 I322 ( .A(n139), .Y(n138) );
  INVX1 I323 ( .A(n95), .Y(n5) );
  INVX1 I324 ( .A(n208), .Y(n206) );
  INVX1 I325 ( .A(n16), .Y(n104) );
  INVX1 I326 ( .A(n194), .Y(n30) );
  OAI211X1 I327 ( .A0(n77), .A1(n7), .B0(n78), .C0(n21), .Y(n74) );
  AOI31X1 I328 ( .A0(n30), .A1(n31), .A2(n32), .B0(n33), .Y(n29) );
  INVX1 I329 ( .A(n34), .Y(n33) );
  INVX1 I330 ( .A(n108), .Y(n111) );
  INVX1 I331 ( .A(n81), .Y(n7) );
  AND2X2 I332 ( .A(n40), .B(n41), .Y(n75) );
  INVX1 I333 ( .A(n66), .Y(n112) );
  INVX1 I334 ( .A(n42), .Y(n36) );
  INVX1 I335 ( .A(n41), .Y(n39) );
  OR3X2 I336 ( .A(n181), .B(n182), .C(n183), .Y(n154) );
  INVX1 I337 ( .A(n184), .Y(n181) );
  INVX1 I338 ( .A(n96), .Y(n150) );
  OR3X2 I339 ( .A(n197), .B(n213), .C(n130), .Y(n227) );
  OR4X2 I340 ( .A(n170), .B(n171), .C(n157), .D(n154), .Y(n85) );
  AND3X2 I341 ( .A(n65), .B(n12), .C(n22), .Y(n53) );
  AND3X1 I342 ( .A(n258), .B(n57), .C(n58), .Y(n55) );
  OR3X2 I343 ( .A(n157), .B(n158), .C(n154), .Y(n86) );
  OR3X2 I344 ( .A(n165), .B(n166), .C(n154), .Y(n34) );
  AND2X2 I345 ( .A(n34), .B(n85), .Y(n169) );
  OR2X2 I346 ( .A(n130), .B(n197), .Y(n193) );
  OR2X2 I347 ( .A(n133), .B(n202), .Y(n136) );
  OR4X2 I348 ( .A(n23), .B(n24), .C(n25), .D(n26), .Y(new_src[2]) );
  AOI31X1 I349 ( .A0(n27), .A1(n28), .A2(n29), .B0(n2), .Y(n25) );
  AOI31X1 I350 ( .A0(n20), .A1(n43), .A2(n44), .B0(n13), .Y(n23) );
  OR3X2 I351 ( .A(n159), .B(n160), .C(n154), .Y(n27) );
  OAI211X1 I352 ( .A0(n154), .A1(n155), .B0(n64), .C0(n156), .Y(n153) );
  AND2X2 I353 ( .A(n27), .B(n86), .Y(n156) );
  NOR2X1 I354 ( .A(n247), .B(n222), .Y(n246) );
  NOR2X1 I355 ( .A(n114), .B(n201), .Y(n248) );
  AND3X1 I356 ( .A(n8), .B(n97), .C(n252), .Y(n91) );
  AOI32X1 I357 ( .A0(n110), .A1(n111), .A2(n112), .B0(n113), .B1(n114), .Y(n97) );
  AND3X2 I358 ( .A(n10), .B(n114), .C(n67), .Y(n110) );
  OAI221X4 I359 ( .A0(n6), .A1(n13), .B0(n244), .B1(n2), .C0(n259), .Y(
        new_src[3]) );
  INVX1 I360 ( .A(n109), .Y(n107) );
  OR3X2 I361 ( .A(n195), .B(n221), .C(n46), .Y(n42) );
  OR3X2 I362 ( .A(n189), .B(n191), .C(n183), .Y(n63) );
  OR3X2 I363 ( .A(n109), .B(n108), .C(n72), .Y(n65) );
  OR4X2 I364 ( .A(n105), .B(n106), .C(n79), .D(n16), .Y(n78) );
  OR2X2 I365 ( .A(n129), .B(n214), .Y(n207) );
  OR3X2 I366 ( .A(n202), .B(n220), .C(n133), .Y(n143) );
  OR2X2 I367 ( .A(n130), .B(n213), .Y(n208) );
  OR2X2 I368 ( .A(n10), .B(n198), .Y(n194) );
  OR2X2 I369 ( .A(n46), .B(n195), .Y(n31) );
  INVX1 I370 ( .A(n40), .Y(n216) );
  NOR3X1 I371 ( .A(n201), .B(n219), .C(n114), .Y(n249) );
  NOR3X1 I372 ( .A(n184), .B(n182), .C(n183), .Y(n250) );
  OR2X2 I373 ( .A(n133), .B(n220), .Y(n141) );
  OR4X2 I374 ( .A(n66), .B(n67), .C(n68), .D(n16), .Y(n22) );
  INVX1 I375 ( .A(n69), .Y(n68) );
  OR3X2 I376 ( .A(n196), .B(n214), .C(n129), .Y(n226) );
  OR3X2 I377 ( .A(n48), .B(n49), .C(n16), .Y(n20) );
  OR3X2 I378 ( .A(n79), .B(n80), .C(n16), .Y(n21) );
  INVX1 I379 ( .A(n130), .Y(n70) );
  INVX1 I380 ( .A(n46), .Y(n77) );
  INVX1 I381 ( .A(n10), .Y(n45) );
  INVX1 I382 ( .A(n158), .Y(n170) );
  INVX1 I383 ( .A(n15), .Y(n6) );
  AND3X2 I384 ( .A(n20), .B(n21), .C(n22), .Y(n18) );
  INVX1 I385 ( .A(n133), .Y(n113) );
  INVX1 I386 ( .A(n35), .Y(n146) );
  NOR3BX1 I387 ( .AN(n78), .B(n100), .C(n251), .Y(n252) );
  INVX1 I388 ( .A(n155), .Y(n167) );
  NOR2X1 I389 ( .A(n114), .B(n219), .Y(n253) );
  OR2X2 I390 ( .A(n130), .B(n72), .Y(n43) );
  OR3X2 I391 ( .A(n70), .B(n71), .C(n72), .Y(n12) );
  AND3X2 I392 ( .A(n10), .B(n259), .C(n12), .Y(n9) );
  INVX1 I393 ( .A(n80), .Y(n105) );
  AOI31X1 I394 ( .A0(n45), .A1(n46), .A2(n7), .B0(n251), .Y(n44) );
  INVX1 I395 ( .A(n124), .Y(n164) );
  OR3X2 I396 ( .A(n166), .B(n254), .C(n154), .Y(n64) );
  NAND3X1 I397 ( .A(n164), .B(EIP[6]), .C(n165), .Y(n254) );
  OR3X2 I398 ( .A(IPH[5]), .B(n196), .C(n129), .Y(n191) );
  AND2X2 I399 ( .A(IE[2]), .B(n261), .Y(ir_EX1) );
  OR2X2 I400 ( .A(LVD_intr), .B(n149), .Y(n147) );
  AND3X2 I401 ( .A(IP[6]), .B(IPH[6]), .C(n227), .Y(n235) );
  NAND3X1 I402 ( .A(EIE[4]), .B(wdt_intr), .C(n261), .Y(n123) );
  NAND3X1 I403 ( .A(EIE[3]), .B(exif_IE5), .C(n261), .Y(n121) );
  NAND3X1 I404 ( .A(EIE[2]), .B(exif_IE4), .C(n261), .Y(n122) );
  NAND3X1 I405 ( .A(EIE[1]), .B(exif_IE3), .C(n261), .Y(n119) );
  NAND3X1 I406 ( .A(EIE[0]), .B(exif_IE2), .C(n261), .Y(n120) );
  OR3X2 I407 ( .A(IPH[6]), .B(n192), .C(n131), .Y(n184) );
  INVX1 I408 ( .A(IP[6]), .Y(n192) );
  OR3X2 I409 ( .A(IP[5]), .B(IPH[5]), .C(n129), .Y(n71) );
  NAND2BX1 I410 ( .AN(n121), .B(EIP[3]), .Y(n171) );
  NAND2BX1 I411 ( .AN(n123), .B(EIP[4]), .Y(n159) );
  NAND2BX1 I412 ( .AN(n122), .B(EIP[2]), .Y(n158) );
  NAND2BX1 I413 ( .AN(LVD_intr), .B(n149), .Y(n35) );
  NAND2BX1 I414 ( .AN(n119), .B(EIP[1]), .Y(n168) );
  NAND2BX1 I415 ( .AN(n120), .B(EIP[0]), .Y(n155) );
  NOR2X1 I416 ( .A(EIP[1]), .B(n119), .Y(n256) );
  AND2X2 I417 ( .A(IE[0]), .B(n261), .Y(ir_EX0) );
  NOR3X1 I418 ( .A(LVD_intr), .B(n245), .C(n246), .Y(n258) );
  INVX1 I419 ( .A(IP[5]), .Y(n196) );
  INVX1 I420 ( .A(IPH[0]), .Y(n221) );
  INVX1 I421 ( .A(IP[4]), .Y(n197) );
  INVX1 I422 ( .A(IP[2]), .Y(n202) );
  INVX1 I423 ( .A(IP[1]), .Y(n201) );
  INVX1 I424 ( .A(IP[0]), .Y(n195) );
  INVX1 I425 ( .A(IP[3]), .Y(n198) );
  NAND3X1 I426 ( .A(EIE[5]), .B(pwm1_intr), .C(n261), .Y(n102) );
  OR3X2 I427 ( .A(IP[6]), .B(IPH[6]), .C(n131), .Y(n109) );
  OR2X2 I428 ( .A(EIP[0]), .B(n120), .Y(n17) );
  OR2X2 I429 ( .A(EIP[3]), .B(n121), .Y(n106) );
  OR2X2 I430 ( .A(EIP[4]), .B(n123), .Y(n48) );
  OR2X2 I431 ( .A(EIP[2]), .B(n122), .Y(n80) );
  OR2X2 I432 ( .A(EIP[5]), .B(n102), .Y(n69) );
  OR2X2 I433 ( .A(EIP[6]), .B(n124), .Y(n67) );
  NAND2BX1 I434 ( .AN(n102), .B(EIP[5]), .Y(n165) );
  INVX1 I435 ( .A(IPH[5]), .Y(n214) );
  INVX1 I436 ( .A(IPH[4]), .Y(n213) );
  INVX1 I437 ( .A(IPH[1]), .Y(n219) );
  INVX1 I438 ( .A(IPH[2]), .Y(n220) );
  INVX1 I439 ( .A(IPH[3]), .Y(n215) );
  INVX1 I440 ( .A(n123), .Y(STOPwake_WDT) );
  INVX1 I441 ( .A(LVD_intr), .Y(n259) );
endmodule


module ir_ctrl ( POR, DIR_WR, pr_st, RETI_end, RETI_NFC, INT_SFR_sel, new_src, 
        new_pri, sw_rst, clk, inter_vector, inter_LCALL, interrupt_ack, 
        clear_TF1, ir_clr_IE1, clear_TF0, ir_clr_IE0 );
  input [2:0] pr_st;
  input [4:0] new_src;
  input [2:0] new_pri;
  output [7:0] inter_vector;
  input POR, DIR_WR, RETI_end, RETI_NFC, INT_SFR_sel, sw_rst, clk;
  output inter_LCALL, interrupt_ack, clear_TF1, ir_clr_IE1, clear_TF0,
         ir_clr_IE0;
  wire   update_pri_4_, update_pri_2_, N60, N61, N62, N63, N64, N65, N66, N67,
         N68, N69, lock_valid, pri_low, current_pri_0_, current_pri_1_, n9,
         n13, n14, n15, n17, n18, n19, n20, n22, n24, n25, n26, n27, n28, n29,
         n30, n31, n34, n36, n37, n39, n40, n43, n44, n45, n46, n47, n48, n49,
         n50, n52, n54, n56, n57, n58, n59, n610, n620, n630, n640, n650, n660,
         n72, n73, n74, n75, n76, n77, n78, n79, n80, n81, n82, n83, n84, n85,
         n86, n87, n88, n89, n90, n91, n92, n93, n94, n95, n96;
  wire   [3:0] ir_src;
  wire   [1:0] ir_st;

  OAI222X4 U7 ( .A0(ir_st[0]), .A1(n75), .B0(n13), .B1(n14), .C0(n75), .C1(n15), .Y(n660) );
  AOI221X4 U20 ( .A0(n29), .A1(ir_src[2]), .B0(ir_src[3]), .B1(ir_src[1]), 
        .C0(n22), .Y(n27) );
  OAI33X4 U23 ( .A0(n30), .A1(ir_src[3]), .A2(n28), .B0(n31), .B1(n82), .B2(
        n28), .Y(inter_vector[3]) );
  OAI32X4 U73 ( .A0(update_pri_4_), .A1(n77), .A2(update_pri_2_), .B0(
        update_pri_4_), .B1(n74), .Y(current_pri_0_) );
  OR2X4 U87 ( .A(ir_st[0]), .B(ir_st[1]), .Y(inter_LCALL) );
  INVX1 I91 ( .A(1'b1), .Y(inter_vector[2]) );
  INVX1 I93 ( .A(1'b1), .Y(inter_vector[7]) );
  NAND2X1 I95 ( .A(ir_src[0]), .B(ir_src[1]), .Y(n34) );
  NAND3X1 I96 ( .A(n82), .B(n76), .C(n79), .Y(n26) );
  OAI2BB2X1 I97 ( .A0N(lock_valid), .A1N(n94), .B0(n96), .B1(n95), .Y(pri_low)
         );
  NAND2X1 I98 ( .A(n78), .B(inter_LCALL), .Y(inter_vector[1]) );
  NOR3X1 I99 ( .A(n72), .B(n73), .C(update_pri_4_), .Y(n9) );
  AOI21X1 I100 ( .A0(n54), .A1(new_pri[1]), .B0(n87), .Y(n93) );
  NOR2X1 I101 ( .A(n81), .B(ir_src[0]), .Y(n37) );
  NOR2X1 I102 ( .A(n44), .B(n18), .Y(N69) );
  AND2X1 I103 ( .A(n85), .B(RETI_end), .Y(n84) );
  NAND2X1 I104 ( .A(n75), .B(ir_st[0]), .Y(n14) );
  NOR3X1 I105 ( .A(new_pri[0]), .B(n57), .C(n18), .Y(N61) );
  EDFFTRX1 ir_src_reg_0_ ( .D(new_src[0]), .CK(clk), .E(interrupt_ack), .RN(
        n86), .Q(ir_src[0]), .QN(n79) );
  OR4X2 I106 ( .A(pri_low), .B(RETI_NFC), .C(inter_LCALL), .D(n610), .Y(n24)
         );
  AND3X2 I107 ( .A(ir_src[1]), .B(n79), .C(n83), .Y(clear_TF0) );
  INVX1 I108 ( .A(sw_rst), .Y(n86) );
  OAI31X1 I109 ( .A0(n24), .A1(new_pri[0]), .A2(n49), .B0(n52), .Y(N64) );
  OAI31X1 I110 ( .A0(n24), .A1(n48), .A2(n49), .B0(n50), .Y(N66) );
  OAI31X1 I111 ( .A0(n24), .A1(n57), .A2(n48), .B0(n58), .Y(N62) );
  EDFFX1 update_pri_reg_4_ ( .D(N69), .CK(clk), .E(N68), .Q(update_pri_4_), 
        .QN(n85) );
  DFFRX1 ir_st_reg_1_ ( .D(n640), .CK(clk), .RN(n620), .Q(ir_st[1]), .QN(n75)
         );
  EDFFTRX1 ir_src_reg_1_ ( .D(new_src[1]), .CK(clk), .E(interrupt_ack), .RN(
        n86), .Q(ir_src[1]), .QN(n76) );
  DFFRX1 ir_st_reg_0_ ( .D(n630), .CK(clk), .RN(n620), .Q(ir_st[0]), .QN(n78)
         );
  EDFFTRX1 ir_src_reg_2_ ( .D(new_src[2]), .CK(clk), .E(interrupt_ack), .RN(
        n86), .Q(ir_src[2]), .QN(n81) );
  EDFFTRX1 ir_src_reg_3_ ( .D(new_src[3]), .CK(clk), .E(interrupt_ack), .RN(
        n86), .Q(ir_src[3]), .QN(n82) );
  AOI31X1 I112 ( .A0(current_pri_1_), .A1(n84), .A2(current_pri_0_), .B0(
        sw_rst), .Y(n50) );
  AOI31X1 I113 ( .A0(current_pri_1_), .A1(n84), .A2(n89), .B0(sw_rst), .Y(n52)
         );
  AOI31X1 I114 ( .A0(n84), .A1(n54), .A2(current_pri_0_), .B0(sw_rst), .Y(n58)
         );
  AOI31X1 I115 ( .A0(n54), .A1(n84), .A2(n89), .B0(sw_rst), .Y(n59) );
  AND3X1 I116 ( .A(ir_src[0]), .B(n76), .C(n83), .Y(ir_clr_IE0) );
  INVX1 I117 ( .A(new_pri[1]), .Y(n88) );
  INVX2 I118 ( .A(n24), .Y(interrupt_ack) );
  INVX1 I119 ( .A(n54), .Y(current_pri_1_) );
  AOI21X1 I120 ( .A0(n93), .A1(n92), .B0(n91), .Y(n95) );
  NOR2X1 I121 ( .A(lock_valid), .B(n94), .Y(n96) );
  OAI2BB1X1 I122 ( .A0N(n80), .A1N(n74), .B0(n85), .Y(n54) );
  NAND3X1 I123 ( .A(n74), .B(n80), .C(n9), .Y(lock_valid) );
  NAND2X1 I124 ( .A(current_pri_1_), .B(n88), .Y(n90) );
  INVX1 I125 ( .A(n18), .Y(n43) );
  INVX1 I126 ( .A(new_pri[0]), .Y(n48) );
  AND3X2 I127 ( .A(n47), .B(new_pri[0]), .C(n43), .Y(N67) );
  AND3X2 I128 ( .A(new_pri[0]), .B(n56), .C(n43), .Y(N63) );
  AND3X2 I129 ( .A(n47), .B(n48), .C(n43), .Y(N65) );
  OR2X2 I130 ( .A(sw_rst), .B(n24), .Y(n18) );
  INVX1 I131 ( .A(new_src[4]), .Y(n94) );
  INVX1 I132 ( .A(n57), .Y(n56) );
  INVX1 I133 ( .A(n49), .Y(n47) );
  EDFFX1 update_pri_reg_2_ ( .D(N65), .CK(clk), .E(N64), .Q(update_pri_2_), 
        .QN(n80) );
  EDFFX1 update_pri_reg_3_ ( .D(N67), .CK(clk), .E(N66), .QN(n74) );
  EDFFX1 update_pri_reg_1_ ( .D(N63), .CK(clk), .E(N62), .Q(n73), .QN(n77) );
  OR2X2 I134 ( .A(n20), .B(sw_rst), .Y(n15) );
  INVX1 I135 ( .A(n34), .Y(n22) );
  INVX1 I136 ( .A(n28), .Y(inter_vector[0]) );
  OAI221X4 I137 ( .A0(n45), .A1(n85), .B0(n24), .B1(n44), .C0(n86), .Y(N68) );
  OAI2BB1X1 I138 ( .A0N(INT_SFR_sel), .A1N(DIR_WR), .B0(n20), .Y(n610) );
  NOR2X1 I139 ( .A(new_pri[2]), .B(n85), .Y(n91) );
  NAND3X1 I140 ( .A(n90), .B(n89), .C(new_pri[0]), .Y(n92) );
  OAI31X1 I141 ( .A0(n24), .A1(new_pri[0]), .A2(n57), .B0(n59), .Y(N60) );
  OR3X2 I142 ( .A(new_pri[1]), .B(new_pri[0]), .C(n46), .Y(n44) );
  INVX1 I143 ( .A(new_pri[2]), .Y(n46) );
  OR2X2 I144 ( .A(new_pri[2]), .B(new_pri[1]), .Y(n57) );
  NAND2BX1 I145 ( .AN(new_pri[2]), .B(new_pri[1]), .Y(n49) );
  INVX1 I146 ( .A(RETI_end), .Y(n45) );
  OR2X2 I147 ( .A(n75), .B(n78), .Y(n28) );
  OR2X2 I148 ( .A(n34), .B(n81), .Y(n25) );
  AND2X1 I149 ( .A(n83), .B(n22), .Y(ir_clr_IE1) );
  INVX1 I150 ( .A(n19), .Y(n20) );
  INVX1 I151 ( .A(current_pri_0_), .Y(n89) );
  INVX1 I152 ( .A(n26), .Y(n29) );
  AND4X2 I153 ( .A(n79), .B(n76), .C(ir_src[2]), .D(n39), .Y(clear_TF1) );
  INVX1 I154 ( .A(n40), .Y(n39) );
  AND2X2 U89 ( .A(n650), .B(n86), .Y(n630) );
  OAI211X1 I155 ( .A0(n78), .A1(n15), .B0(n17), .C0(n18), .Y(n650) );
  OR4X1 I156 ( .A(sw_rst), .B(ir_st[0]), .C(n75), .D(n19), .Y(n17) );
  AND3X2 I157 ( .A(inter_vector[0]), .B(ir_src[3]), .C(n25), .Y(
        inter_vector[6]) );
  AND3X2 I158 ( .A(ir_src[2]), .B(n26), .C(inter_vector[0]), .Y(
        inter_vector[5]) );
  OAI21X1 I159 ( .A0(n27), .A1(n28), .B0(ir_st[1]), .Y(inter_vector[4]) );
  NAND3BX1 I160 ( .AN(pr_st[2]), .B(pr_st[0]), .C(pr_st[1]), .Y(n19) );
  OR3X2 I161 ( .A(ir_src[3]), .B(n19), .C(n28), .Y(n40) );
  NOR2X1 I162 ( .A(ir_src[2]), .B(n40), .Y(n83) );
  AOI211X1 I163 ( .A0(ir_src[1]), .A1(n79), .B0(n36), .C0(n37), .Y(n30) );
  INVX1 I164 ( .A(n25), .Y(n36) );
  AOI22X1 I165 ( .A0(n22), .A1(n81), .B0(ir_src[0]), .B1(n76), .Y(n31) );
  AND2X2 I166 ( .A(n85), .B(new_pri[2]), .Y(n87) );
  AND2X2 U90 ( .A(n86), .B(n660), .Y(n640) );
  INVX1 I167 ( .A(n15), .Y(n13) );
  INVX1 I168 ( .A(POR), .Y(n620) );
  EDFFX1 update_pri_reg_0_ ( .D(N61), .CK(clk), .E(N60), .Q(n72) );
endmodule


module ir_ext ( SFR_bus, EXIF, pin_INT2, pin_INT3, pin_INT4, pin_INT5, 
        EXIF_sel, TCON_sel, SFR_wr, sw_rst, clk, pr_st, pin_INT0, pin_INT1, 
        ir_EX1, ir_EX0, tcon_IE0, tcon_IE1, STOPwake_INT0, STOPwake_INT1, 
        ir_clr_IE0, ir_clr_IE1, TCON30, sample_INT0, sample_INT1, POR );
  input [7:0] SFR_bus;
  output [7:0] EXIF;
  input [2:0] pr_st;
  output [3:0] TCON30;
  input pin_INT2, pin_INT3, pin_INT4, pin_INT5, EXIF_sel, TCON_sel, SFR_wr,
         sw_rst, clk, pin_INT0, pin_INT1, ir_EX1, ir_EX0, ir_clr_IE0,
         ir_clr_IE1, POR;
  output tcon_IE0, tcon_IE1, STOPwake_INT0, STOPwake_INT1, sample_INT0,
         sample_INT1;
  wire   sample2_INT0, sample2_INT1, sample2_INT2, sample_INT2, sample2_INT3,
         sample_INT3, sample2_INT4, sample_INT4, sample2_INT5, sample_INT5,
         N12, N13, N14, N15, N16, N17, N18, N47, N52, N57, N62, N68, N69, N70,
         N71, N72, N73, N74, N75, N76, N77, N78, N80, N81, N83, n2, n4, n6, n7,
         n8, n9, n10, n11, n120, n130, n140, n150, n160, n170, n180, n19, n20,
         n21, n22, n23, n24, n32, n35, n37, n39, n42, n44, n45, n46, n49, n50,
         n51, n53, n54, n55, n56, n570, n58, n59, n60, n61, n64, n65, n66, n67,
         n680, n690, n700, n710, n720, n730, n740, n750, n760, n770, n780, n79,
         n800, n810, n84, n85, n86, n87;

  OAI32X4 U7 ( .A0(n6), .A1(TCON30[2]), .A2(n7), .B0(n86), .B1(n8), .Y(N83) );
  AOI222X4 U8 ( .A0(n9), .A1(n10), .B0(n11), .B1(n120), .C0(n11), .C1(n690), 
        .Y(n8) );
  AOI221X4 U14 ( .A0(n150), .A1(n690), .B0(ir_clr_IE1), .B1(TCON30[2]), .C0(n7), .Y(n140) );
  OAI32X4 U18 ( .A0(n170), .A1(TCON30[0]), .A2(n7), .B0(n86), .B1(n180), .Y(
        N80) );
  AOI222X4 U19 ( .A0(n19), .A1(n20), .B0(n21), .B1(n22), .C0(n21), .C1(n680), 
        .Y(n180) );
  AOI221X4 U25 ( .A0(n150), .A1(n680), .B0(ir_clr_IE0), .B1(TCON30[0]), .C0(n7), .Y(n24) );
  OR2X4 U65 ( .A(n45), .B(n85), .Y(N18) );
  NAND2BX1 I88 ( .AN(n800), .B(n87), .Y(n7) );
  NOR2X2 I89 ( .A(n85), .B(n42), .Y(n79) );
  AND2X2 I90 ( .A(n87), .B(n42), .Y(n780) );
  NOR3X1 I91 ( .A(n64), .B(ir_clr_IE0), .C(n680), .Y(n20) );
  NOR3X1 I92 ( .A(n65), .B(ir_clr_IE1), .C(n690), .Y(n10) );
  EDFFX1 TCON30_reg_3_ ( .D(N83), .CK(clk), .E(N81), .Q(tcon_IE1), .QN(n66) );
  OAI211X1 I93 ( .A0(ir_EX0), .A1(TCON30[0]), .B0(SFR_bus[1]), .C0(n800), .Y(
        n23) );
  OR3X2 I94 ( .A(pr_st[1]), .B(pr_st[0]), .C(n44), .Y(n160) );
  NAND2X2 I95 ( .A(EXIF_sel), .B(SFR_wr), .Y(n42) );
  EDFFTRX1 TCON30_reg_2_ ( .D(SFR_bus[2]), .CK(clk), .E(n800), .RN(n84), .Q(
        TCON30[2]), .QN(n690) );
  AOI32X1 I96 ( .A0(sample2_INT5), .A1(n710), .A2(n810), .B0(SFR_bus[7]), .B1(
        n79), .Y(n39) );
  AOI32X1 I97 ( .A0(sample_INT4), .A1(n750), .A2(n810), .B0(SFR_bus[6]), .B1(
        n79), .Y(n37) );
  AOI32X1 I98 ( .A0(sample2_INT3), .A1(n700), .A2(n810), .B0(SFR_bus[5]), .B1(
        n79), .Y(n35) );
  AOI32X1 I99 ( .A0(sample_INT2), .A1(n740), .A2(n810), .B0(SFR_bus[4]), .B1(
        n79), .Y(n32) );
  NOR2X2 I100 ( .A(n85), .B(n160), .Y(n810) );
  INVX1 I101 ( .A(n46), .Y(n45) );
  AND2X1 I102 ( .A(TCON_sel), .B(SFR_wr), .Y(n800) );
  INVX1 I103 ( .A(sw_rst), .Y(n87) );
  INVX2 I104 ( .A(n85), .Y(n84) );
  INVX2 I105 ( .A(n42), .Y(n49) );
  INVX2 I106 ( .A(n87), .Y(n86) );
  INVX2 I107 ( .A(n87), .Y(n85) );
  EDFFX1 TCON30_reg_1_ ( .D(N80), .CK(clk), .E(N78), .Q(TCON30[1]), .QN(n67)
         );
  INVX1 I108 ( .A(ir_clr_IE0), .Y(n22) );
  EDFFX1 sample_INT0_reg ( .D(N68), .CK(clk), .E(N18), .Q(sample_INT0) );
  INVX1 I109 ( .A(n6), .Y(n9) );
  INVX1 I110 ( .A(n170), .Y(n19) );
  EDFFX1 sample_INT2_reg ( .D(N70), .CK(clk), .E(N18), .Q(sample_INT2), .QN(
        n730) );
  EDFFX1 sample_INT4_reg ( .D(N72), .CK(clk), .E(N18), .Q(sample_INT4), .QN(
        n720) );
  EDFFX1 sample2_INT5_reg ( .D(N17), .CK(clk), .E(N18), .Q(sample2_INT5), .QN(
        n760) );
  EDFFX1 sample2_INT3_reg ( .D(N15), .CK(clk), .E(N18), .Q(sample2_INT3), .QN(
        n770) );
  EDFFX1 sample_INT1_reg ( .D(N69), .CK(clk), .E(N18), .Q(sample_INT1) );
  INVX1 I111 ( .A(n160), .Y(n150) );
  EDFFX1 sample_INT3_reg ( .D(N71), .CK(clk), .E(N18), .Q(sample_INT3), .QN(
        n700) );
  EDFFX1 sample_INT5_reg ( .D(N73), .CK(clk), .E(N18), .Q(sample_INT5), .QN(
        n710) );
  EDFFX1 sample2_INT2_reg ( .D(N14), .CK(clk), .E(N18), .Q(sample2_INT2), .QN(
        n740) );
  EDFFX1 sample2_INT4_reg ( .D(N16), .CK(clk), .E(N18), .Q(sample2_INT4), .QN(
        n750) );
  INVX1 I112 ( .A(n130), .Y(n11) );
  OAI211X1 I113 ( .A0(ir_EX1), .A1(TCON30[2]), .B0(SFR_bus[3]), .C0(n800), .Y(
        n130) );
  INVX1 I114 ( .A(ir_clr_IE1), .Y(n120) );
  INVX1 I115 ( .A(n23), .Y(n21) );
  OAI22X1 I116 ( .A0(n49), .A1(n60), .B0(n50), .B1(n42), .Y(n61) );
  INVX1 I117 ( .A(SFR_bus[3]), .Y(n50) );
  OAI2BB2X1 I118 ( .A0N(SFR_bus[2]), .A1N(n49), .B0(n49), .B1(n58), .Y(n59) );
  INVX1 I119 ( .A(n39), .Y(N47) );
  INVX1 I120 ( .A(n37), .Y(N52) );
  INVX1 I121 ( .A(n35), .Y(N57) );
  INVX1 I122 ( .A(n32), .Y(N62) );
  INVX1 I123 ( .A(n67), .Y(tcon_IE0) );
  OAI22X1 I124 ( .A0(n49), .A1(n56), .B0(n51), .B1(n42), .Y(n570) );
  INVX1 I125 ( .A(SFR_bus[1]), .Y(n51) );
  INVX1 I126 ( .A(n66), .Y(TCON30[3]) );
  INVX1 I127 ( .A(pr_st[2]), .Y(n44) );
  OR2X2 I128 ( .A(sample_INT1), .B(n160), .Y(n6) );
  OR2X2 I129 ( .A(sample_INT0), .B(n160), .Y(n170) );
  OAI2BB1X1 I130 ( .A0N(sample2_INT1), .A1N(n9), .B0(n140), .Y(N81) );
  OAI2BB1X1 I131 ( .A0N(sample2_INT0), .A1N(n19), .B0(n24), .Y(N78) );
  OAI31X1 I132 ( .A0(n160), .A1(sample_INT5), .A2(n760), .B0(n780), .Y(N77) );
  OAI31X1 I133 ( .A0(n160), .A1(sample_INT3), .A2(n770), .B0(n780), .Y(N75) );
  OAI31X1 I134 ( .A0(n160), .A1(sample2_INT4), .A2(n720), .B0(n780), .Y(N76)
         );
  OAI31X1 I135 ( .A0(n160), .A1(sample2_INT2), .A2(n730), .B0(n780), .Y(N74)
         );
  NAND3BX1 I136 ( .AN(pr_st[2]), .B(pr_st[0]), .C(pr_st[1]), .Y(n46) );
  OAI2BB1X1 I137 ( .A0N(sample_INT5), .A1N(n45), .B0(n84), .Y(N17) );
  OAI2BB1X1 I138 ( .A0N(sample_INT0), .A1N(n45), .B0(n84), .Y(N12) );
  OAI2BB1X1 I139 ( .A0N(sample_INT1), .A1N(n45), .B0(n84), .Y(N13) );
  OAI2BB1X1 I140 ( .A0N(n45), .A1N(sample_INT2), .B0(n84), .Y(N14) );
  OAI2BB1X1 I141 ( .A0N(sample_INT3), .A1N(n45), .B0(n84), .Y(N15) );
  OAI2BB1X1 I142 ( .A0N(n45), .A1N(sample_INT4), .B0(n84), .Y(N16) );
  OR2X2 I143 ( .A(pin_INT0), .B(n86), .Y(N68) );
  OR2X2 I144 ( .A(pin_INT1), .B(n86), .Y(N69) );
  OR2X2 I145 ( .A(pin_INT2), .B(n86), .Y(N70) );
  OR2X2 I146 ( .A(pin_INT3), .B(n86), .Y(N71) );
  OR2X2 I147 ( .A(pin_INT4), .B(n86), .Y(N72) );
  OR2X2 I148 ( .A(pin_INT5), .B(n86), .Y(N73) );
  AND3X2 I149 ( .A(ir_EX0), .B(n4), .C(n680), .Y(STOPwake_INT0) );
  AND3X2 I150 ( .A(ir_EX1), .B(n2), .C(n690), .Y(STOPwake_INT1) );
  INVX1 I151 ( .A(pin_INT1), .Y(n2) );
  INVX1 I152 ( .A(POR), .Y(n53) );
  INVX1 I153 ( .A(pin_INT0), .Y(n4) );
  DFFRX1 EXIF_reg_0_ ( .D(n55), .CK(clk), .RN(n53), .Q(EXIF[0]), .QN(n54) );
  DFFRX1 EXIF_reg_1_ ( .D(n570), .CK(clk), .RN(n53), .Q(EXIF[1]), .QN(n56) );
  EDFFX1 EXIF_reg_7_ ( .D(N47), .CK(clk), .E(N77), .Q(EXIF[7]) );
  EDFFX1 EXIF_reg_6_ ( .D(N52), .CK(clk), .E(N76), .Q(EXIF[6]) );
  EDFFX1 EXIF_reg_5_ ( .D(N57), .CK(clk), .E(N75), .Q(EXIF[5]) );
  EDFFX1 EXIF_reg_4_ ( .D(N62), .CK(clk), .E(N74), .Q(EXIF[4]) );
  DFFRX1 EXIF_reg_2_ ( .D(n59), .CK(clk), .RN(n53), .Q(EXIF[2]), .QN(n58) );
  DFFRX1 EXIF_reg_3_ ( .D(n61), .CK(clk), .RN(n53), .Q(EXIF[3]), .QN(n60) );
  EDFFX1 sample2_INT0_reg ( .D(N12), .CK(clk), .E(N18), .Q(sample2_INT0), .QN(
        n64) );
  EDFFX1 sample2_INT1_reg ( .D(N13), .CK(clk), .E(N18), .Q(sample2_INT1), .QN(
        n65) );
  OAI2BB2X1 I154 ( .A0N(SFR_bus[0]), .A1N(n49), .B0(n49), .B1(n54), .Y(n55) );
  EDFFTRX1 TCON30_reg_0_ ( .D(SFR_bus[0]), .CK(clk), .E(n800), .RN(n84), .Q(
        TCON30[0]), .QN(n680) );
endmodule


module port3 ( sw_rst, clk, P3_DOUT, SFR_bus, P3_sel, SFR_wr, pin_P3, 
        read_modify, P3_OUT );
  output [7:0] P3_DOUT;
  input [7:0] SFR_bus;
  input [7:0] pin_P3;
  output [7:0] P3_OUT;
  input sw_rst, clk, P3_sel, SFR_wr, read_modify;
  wire   N4, N5, N6, N7, N8, N9, N10, N11, N15, n22, n23, n24, n25, n26, n27,
         n28, n29, n30, n31, n32, n33, n34, n35, n36, n37, n38, n39, n40;

  INVX2 I40 ( .A(read_modify), .Y(n39) );
  INVX2 I41 ( .A(sw_rst), .Y(n40) );
  OAI2BB1X1 I42 ( .A0N(SFR_bus[7]), .A1N(n22), .B0(n40), .Y(N11) );
  OAI2BB1X1 I43 ( .A0N(SFR_bus[6]), .A1N(n22), .B0(n40), .Y(N10) );
  OAI2BB1X1 I44 ( .A0N(SFR_bus[5]), .A1N(n22), .B0(n40), .Y(N9) );
  OAI2BB1X1 I45 ( .A0N(SFR_bus[4]), .A1N(n22), .B0(n40), .Y(N8) );
  OAI2BB1X1 I46 ( .A0N(SFR_bus[3]), .A1N(n22), .B0(n40), .Y(N7) );
  OAI2BB1X1 I47 ( .A0N(SFR_bus[2]), .A1N(n22), .B0(n40), .Y(N6) );
  OR2X2 I48 ( .A(n22), .B(sw_rst), .Y(N15) );
  AND2X2 I49 ( .A(SFR_wr), .B(P3_sel), .Y(n22) );
  NAND2X1 I50 ( .A(n23), .B(n24), .Y(P3_OUT[1]) );
  NAND2X1 I51 ( .A(P3_DOUT[1]), .B(read_modify), .Y(n23) );
  NAND2X1 I52 ( .A(pin_P3[1]), .B(n39), .Y(n24) );
  NAND2X1 I53 ( .A(n25), .B(n26), .Y(P3_OUT[0]) );
  NAND2X1 I54 ( .A(P3_DOUT[0]), .B(read_modify), .Y(n25) );
  NAND2X1 I55 ( .A(pin_P3[0]), .B(n39), .Y(n26) );
  NAND2X1 I56 ( .A(n27), .B(n28), .Y(P3_OUT[7]) );
  NAND2X1 I57 ( .A(read_modify), .B(P3_DOUT[7]), .Y(n27) );
  NAND2X1 I58 ( .A(pin_P3[7]), .B(n39), .Y(n28) );
  NAND2X1 I59 ( .A(n29), .B(n30), .Y(P3_OUT[6]) );
  NAND2X1 I60 ( .A(P3_DOUT[6]), .B(read_modify), .Y(n29) );
  NAND2X1 I61 ( .A(pin_P3[6]), .B(n39), .Y(n30) );
  NAND2X1 I62 ( .A(n31), .B(n32), .Y(P3_OUT[5]) );
  NAND2X1 I63 ( .A(P3_DOUT[5]), .B(read_modify), .Y(n31) );
  NAND2X1 I64 ( .A(pin_P3[5]), .B(n39), .Y(n32) );
  NAND2X1 I65 ( .A(n33), .B(n34), .Y(P3_OUT[3]) );
  NAND2X1 I66 ( .A(P3_DOUT[3]), .B(read_modify), .Y(n33) );
  NAND2X1 I67 ( .A(pin_P3[3]), .B(n39), .Y(n34) );
  NAND2X1 I68 ( .A(n35), .B(n36), .Y(P3_OUT[2]) );
  NAND2X1 I69 ( .A(P3_DOUT[2]), .B(read_modify), .Y(n35) );
  NAND2X1 I70 ( .A(pin_P3[2]), .B(n39), .Y(n36) );
  NAND2X1 I71 ( .A(n37), .B(n38), .Y(P3_OUT[4]) );
  NAND2X1 I72 ( .A(P3_DOUT[4]), .B(read_modify), .Y(n37) );
  NAND2X1 I73 ( .A(pin_P3[4]), .B(n39), .Y(n38) );
  EDFFX1 P3_SFR_reg_1_ ( .D(N5), .CK(clk), .E(N15), .Q(P3_DOUT[1]) );
  EDFFX1 P3_SFR_reg_0_ ( .D(N4), .CK(clk), .E(N15), .Q(P3_DOUT[0]) );
  EDFFX1 P3_SFR_reg_7_ ( .D(N11), .CK(clk), .E(N15), .Q(P3_DOUT[7]) );
  EDFFX1 P3_SFR_reg_6_ ( .D(N10), .CK(clk), .E(N15), .Q(P3_DOUT[6]) );
  EDFFX1 P3_SFR_reg_5_ ( .D(N9), .CK(clk), .E(N15), .Q(P3_DOUT[5]) );
  EDFFX1 P3_SFR_reg_3_ ( .D(N7), .CK(clk), .E(N15), .Q(P3_DOUT[3]) );
  EDFFX1 P3_SFR_reg_2_ ( .D(N6), .CK(clk), .E(N15), .Q(P3_DOUT[2]) );
  EDFFX1 P3_SFR_reg_4_ ( .D(N8), .CK(clk), .E(N15), .Q(P3_DOUT[4]) );
  OAI2BB1X1 I74 ( .A0N(SFR_bus[1]), .A1N(n22), .B0(n40), .Y(N5) );
  OAI2BB1X1 I75 ( .A0N(SFR_bus[0]), .A1N(n22), .B0(n40), .Y(N4) );
endmodule


module port2 ( sw_rst, clk, P2_DOUT, SFR_bus, SFR_wr, P2_sel, pin_P2, 
        read_modify, P2_OUT, P2_SFR );
  output [7:0] P2_DOUT;
  input [7:0] SFR_bus;
  input [7:0] pin_P2;
  output [7:0] P2_OUT;
  output [7:0] P2_SFR;
  input sw_rst, clk, SFR_wr, P2_sel, read_modify;
  wire   n61, n63, n65, n67, n69, n71, n73, n75, N4, N5, N6, N7, N8, N9, N10,
         N11, N15, n2, n3, n50, n60, n70, n80, n90, n100, n110, n12, n13, n14,
         n22, n23, n24, n25, n26, n27, n28, n29, n30, n31, n32, n33, n34, n51,
         n52;

  INVX1 I40 ( .A(read_modify), .Y(n51) );
  AND2X2 I41 ( .A(SFR_wr), .B(P2_sel), .Y(n30) );
  INVX2 I42 ( .A(sw_rst), .Y(n52) );
  AND2X1 I43 ( .A(read_modify), .B(n61), .Y(n2) );
  AND2X1 I44 ( .A(pin_P2[7]), .B(n51), .Y(n3) );
  AND2X1 I45 ( .A(pin_P2[5]), .B(n51), .Y(n80) );
  AND2X1 I46 ( .A(pin_P2[3]), .B(n51), .Y(n12) );
  AND2X1 I47 ( .A(pin_P2[6]), .B(n51), .Y(n60) );
  AND2X1 I48 ( .A(pin_P2[2]), .B(n51), .Y(n14) );
  AND2X1 I49 ( .A(n67), .B(read_modify), .Y(n90) );
  AND2X1 I50 ( .A(pin_P2[4]), .B(n51), .Y(n100) );
  AND2X1 I51 ( .A(n63), .B(read_modify), .Y(n50) );
  AND2X1 I52 ( .A(n65), .B(read_modify), .Y(n70) );
  AND2X1 I53 ( .A(n69), .B(read_modify), .Y(n110) );
  AND2X1 I54 ( .A(n71), .B(read_modify), .Y(n13) );
  OAI2BB1X1 I55 ( .A0N(SFR_bus[7]), .A1N(n30), .B0(n52), .Y(N11) );
  OAI2BB1X1 I56 ( .A0N(SFR_bus[6]), .A1N(n30), .B0(n52), .Y(N10) );
  OAI2BB1X1 I57 ( .A0N(SFR_bus[5]), .A1N(n30), .B0(n52), .Y(N9) );
  OAI2BB1X1 I58 ( .A0N(SFR_bus[4]), .A1N(n30), .B0(n52), .Y(N8) );
  OAI2BB1X1 I59 ( .A0N(SFR_bus[3]), .A1N(n30), .B0(n52), .Y(N7) );
  OAI2BB1X1 I60 ( .A0N(SFR_bus[2]), .A1N(n30), .B0(n52), .Y(N6) );
  OR2X2 I61 ( .A(n30), .B(sw_rst), .Y(N15) );
  INVX1 I62 ( .A(n24), .Y(P2_SFR[7]) );
  INVX1 I63 ( .A(n29), .Y(P2_SFR[6]) );
  INVX1 I64 ( .A(n28), .Y(P2_SFR[5]) );
  INVX1 I65 ( .A(n27), .Y(P2_SFR[4]) );
  INVX1 I66 ( .A(n26), .Y(P2_SFR[3]) );
  INVX1 I67 ( .A(n25), .Y(P2_SFR[2]) );
  INVX1 I68 ( .A(n23), .Y(P2_SFR[1]) );
  INVX1 I69 ( .A(n22), .Y(P2_SFR[0]) );
  INVX1 I70 ( .A(n22), .Y(P2_DOUT[0]) );
  INVX1 I71 ( .A(n23), .Y(P2_DOUT[1]) );
  INVX1 I72 ( .A(n25), .Y(P2_DOUT[2]) );
  INVX1 I73 ( .A(n26), .Y(P2_DOUT[3]) );
  INVX1 I74 ( .A(n27), .Y(P2_DOUT[4]) );
  INVX1 I75 ( .A(n28), .Y(P2_DOUT[5]) );
  INVX1 I76 ( .A(n29), .Y(P2_DOUT[6]) );
  INVX1 I77 ( .A(n24), .Y(P2_DOUT[7]) );
  NAND2X1 I78 ( .A(n31), .B(n32), .Y(P2_OUT[1]) );
  NAND2X1 I79 ( .A(n73), .B(read_modify), .Y(n31) );
  NAND2X1 I80 ( .A(pin_P2[1]), .B(n51), .Y(n32) );
  NAND2X1 I81 ( .A(n33), .B(n34), .Y(P2_OUT[0]) );
  NAND2X1 I82 ( .A(n75), .B(read_modify), .Y(n33) );
  NAND2X1 I83 ( .A(pin_P2[0]), .B(n51), .Y(n34) );
  OR2X2 I84 ( .A(n2), .B(n3), .Y(P2_OUT[7]) );
  OR2X2 I85 ( .A(n90), .B(n100), .Y(P2_OUT[4]) );
  OR2X2 I86 ( .A(n50), .B(n60), .Y(P2_OUT[6]) );
  OR2X2 I87 ( .A(n70), .B(n80), .Y(P2_OUT[5]) );
  OR2X2 I88 ( .A(n110), .B(n12), .Y(P2_OUT[3]) );
  OR2X2 I89 ( .A(n13), .B(n14), .Y(P2_OUT[2]) );
  EDFFX1 P2_SFR_reg_1_ ( .D(N5), .CK(clk), .E(N15), .Q(n73), .QN(n23) );
  EDFFX1 P2_SFR_reg_0_ ( .D(N4), .CK(clk), .E(N15), .Q(n75), .QN(n22) );
  EDFFX1 P2_SFR_reg_7_ ( .D(N11), .CK(clk), .E(N15), .Q(n61), .QN(n24) );
  EDFFX1 P2_SFR_reg_6_ ( .D(N10), .CK(clk), .E(N15), .Q(n63), .QN(n29) );
  EDFFX1 P2_SFR_reg_3_ ( .D(N7), .CK(clk), .E(N15), .Q(n69), .QN(n26) );
  EDFFX1 P2_SFR_reg_2_ ( .D(N6), .CK(clk), .E(N15), .Q(n71), .QN(n25) );
  EDFFX1 P2_SFR_reg_5_ ( .D(N9), .CK(clk), .E(N15), .Q(n65), .QN(n28) );
  EDFFX1 P2_SFR_reg_4_ ( .D(N8), .CK(clk), .E(N15), .Q(n67), .QN(n27) );
  OAI2BB1X1 I90 ( .A0N(SFR_bus[1]), .A1N(n30), .B0(n52), .Y(N5) );
  OAI2BB1X1 I91 ( .A0N(SFR_bus[0]), .A1N(n30), .B0(n52), .Y(N4) );
endmodule


module port1 ( sw_rst, clk, P1_DOUT, SFR_bus, P1_sel, SFR_wr, read_modify, 
        P1_OUT, pin_P1 );
  output [7:0] P1_DOUT;
  input [7:0] SFR_bus;
  output [7:0] P1_OUT;
  input [7:0] pin_P1;
  input sw_rst, clk, P1_sel, SFR_wr, read_modify;
  wire   N4, N5, N6, N7, N8, N9, N10, N11, N15, n22, n23, n24, n25, n26, n27,
         n28, n29, n30, n31, n32, n33, n34, n35, n36, n37, n38, n39, n40;

  INVX2 I40 ( .A(sw_rst), .Y(n40) );
  INVX2 I41 ( .A(read_modify), .Y(n39) );
  OAI2BB1X1 I42 ( .A0N(SFR_bus[7]), .A1N(n22), .B0(n40), .Y(N11) );
  OAI2BB1X1 I43 ( .A0N(SFR_bus[6]), .A1N(n22), .B0(n40), .Y(N10) );
  OAI2BB1X1 I44 ( .A0N(SFR_bus[5]), .A1N(n22), .B0(n40), .Y(N9) );
  OAI2BB1X1 I45 ( .A0N(SFR_bus[4]), .A1N(n22), .B0(n40), .Y(N8) );
  OAI2BB1X1 I46 ( .A0N(SFR_bus[3]), .A1N(n22), .B0(n40), .Y(N7) );
  OAI2BB1X1 I47 ( .A0N(SFR_bus[2]), .A1N(n22), .B0(n40), .Y(N6) );
  OR2X2 I48 ( .A(n22), .B(sw_rst), .Y(N15) );
  AND2X2 I49 ( .A(SFR_wr), .B(P1_sel), .Y(n22) );
  NAND2X1 I50 ( .A(n23), .B(n24), .Y(P1_OUT[1]) );
  NAND2X1 I51 ( .A(P1_DOUT[1]), .B(read_modify), .Y(n23) );
  NAND2X1 I52 ( .A(pin_P1[1]), .B(n39), .Y(n24) );
  NAND2X1 I53 ( .A(n25), .B(n26), .Y(P1_OUT[0]) );
  NAND2X1 I54 ( .A(P1_DOUT[0]), .B(read_modify), .Y(n25) );
  NAND2X1 I55 ( .A(pin_P1[0]), .B(n39), .Y(n26) );
  NAND2X1 I56 ( .A(n27), .B(n28), .Y(P1_OUT[7]) );
  NAND2X1 I57 ( .A(read_modify), .B(P1_DOUT[7]), .Y(n27) );
  NAND2X1 I58 ( .A(pin_P1[7]), .B(n39), .Y(n28) );
  NAND2X1 I59 ( .A(n29), .B(n30), .Y(P1_OUT[6]) );
  NAND2X1 I60 ( .A(P1_DOUT[6]), .B(read_modify), .Y(n29) );
  NAND2X1 I61 ( .A(pin_P1[6]), .B(n39), .Y(n30) );
  NAND2X1 I62 ( .A(n31), .B(n32), .Y(P1_OUT[5]) );
  NAND2X1 I63 ( .A(P1_DOUT[5]), .B(read_modify), .Y(n31) );
  NAND2X1 I64 ( .A(pin_P1[5]), .B(n39), .Y(n32) );
  NAND2X1 I65 ( .A(n33), .B(n34), .Y(P1_OUT[3]) );
  NAND2X1 I66 ( .A(P1_DOUT[3]), .B(read_modify), .Y(n33) );
  NAND2X1 I67 ( .A(pin_P1[3]), .B(n39), .Y(n34) );
  NAND2X1 I68 ( .A(n35), .B(n36), .Y(P1_OUT[2]) );
  NAND2X1 I69 ( .A(P1_DOUT[2]), .B(read_modify), .Y(n35) );
  NAND2X1 I70 ( .A(pin_P1[2]), .B(n39), .Y(n36) );
  NAND2X1 I71 ( .A(n37), .B(n38), .Y(P1_OUT[4]) );
  NAND2X1 I72 ( .A(P1_DOUT[4]), .B(read_modify), .Y(n37) );
  NAND2X1 I73 ( .A(pin_P1[4]), .B(n39), .Y(n38) );
  EDFFX1 P1_SFR_reg_1_ ( .D(N5), .CK(clk), .E(N15), .Q(P1_DOUT[1]) );
  EDFFX1 P1_SFR_reg_0_ ( .D(N4), .CK(clk), .E(N15), .Q(P1_DOUT[0]) );
  EDFFX1 P1_SFR_reg_7_ ( .D(N11), .CK(clk), .E(N15), .Q(P1_DOUT[7]) );
  EDFFX1 P1_SFR_reg_6_ ( .D(N10), .CK(clk), .E(N15), .Q(P1_DOUT[6]) );
  EDFFX1 P1_SFR_reg_3_ ( .D(N7), .CK(clk), .E(N15), .Q(P1_DOUT[3]) );
  EDFFX1 P1_SFR_reg_5_ ( .D(N9), .CK(clk), .E(N15), .Q(P1_DOUT[5]) );
  EDFFX1 P1_SFR_reg_4_ ( .D(N8), .CK(clk), .E(N15), .Q(P1_DOUT[4]) );
  EDFFX1 P1_SFR_reg_2_ ( .D(N6), .CK(clk), .E(N15), .Q(P1_DOUT[2]) );
  OAI2BB1X1 I74 ( .A0N(SFR_bus[1]), .A1N(n22), .B0(n40), .Y(N5) );
  OAI2BB1X1 I75 ( .A0N(SFR_bus[0]), .A1N(n22), .B0(n40), .Y(N4) );
endmodule


module port0 ( sw_rst, clk, P0_DOUT, SFR_bus, P0_sel, SFR_wr, pin_P0, 
        read_modify, P0_OUT );
  output [7:0] P0_DOUT;
  input [7:0] SFR_bus;
  input [7:0] pin_P0;
  output [7:0] P0_OUT;
  input sw_rst, clk, P0_sel, SFR_wr, read_modify;
  wire   N4, N5, N6, N7, N8, N9, N10, N11, N15, n22, n23, n24, n25, n26, n27,
         n28, n29, n30, n31, n32, n33, n34, n35, n36, n37, n38, n39, n40;

  INVX2 I40 ( .A(read_modify), .Y(n39) );
  AND2X1 I41 ( .A(SFR_wr), .B(P0_sel), .Y(n22) );
  INVX2 I42 ( .A(sw_rst), .Y(n40) );
  OAI2BB1X1 I43 ( .A0N(SFR_bus[7]), .A1N(n22), .B0(n40), .Y(N11) );
  OAI2BB1X1 I44 ( .A0N(SFR_bus[6]), .A1N(n22), .B0(n40), .Y(N10) );
  OAI2BB1X1 I45 ( .A0N(SFR_bus[5]), .A1N(n22), .B0(n40), .Y(N9) );
  OAI2BB1X1 I46 ( .A0N(SFR_bus[4]), .A1N(n22), .B0(n40), .Y(N8) );
  OAI2BB1X1 I47 ( .A0N(SFR_bus[3]), .A1N(n22), .B0(n40), .Y(N7) );
  OAI2BB1X1 I48 ( .A0N(SFR_bus[2]), .A1N(n22), .B0(n40), .Y(N6) );
  OR2X2 I49 ( .A(n22), .B(sw_rst), .Y(N15) );
  NAND2X1 I50 ( .A(n23), .B(n24), .Y(P0_OUT[1]) );
  NAND2X1 I51 ( .A(P0_DOUT[1]), .B(read_modify), .Y(n23) );
  NAND2X1 I52 ( .A(pin_P0[1]), .B(n39), .Y(n24) );
  NAND2X1 I53 ( .A(n25), .B(n26), .Y(P0_OUT[0]) );
  NAND2X1 I54 ( .A(P0_DOUT[0]), .B(read_modify), .Y(n25) );
  NAND2X1 I55 ( .A(pin_P0[0]), .B(n39), .Y(n26) );
  NAND2X1 I56 ( .A(n27), .B(n28), .Y(P0_OUT[7]) );
  NAND2X1 I57 ( .A(read_modify), .B(P0_DOUT[7]), .Y(n27) );
  NAND2X1 I58 ( .A(pin_P0[7]), .B(n39), .Y(n28) );
  NAND2X1 I59 ( .A(n29), .B(n30), .Y(P0_OUT[6]) );
  NAND2X1 I60 ( .A(P0_DOUT[6]), .B(read_modify), .Y(n29) );
  NAND2X1 I61 ( .A(pin_P0[6]), .B(n39), .Y(n30) );
  NAND2X1 I62 ( .A(n31), .B(n32), .Y(P0_OUT[5]) );
  NAND2X1 I63 ( .A(P0_DOUT[5]), .B(read_modify), .Y(n31) );
  NAND2X1 I64 ( .A(pin_P0[5]), .B(n39), .Y(n32) );
  NAND2X1 I65 ( .A(n33), .B(n34), .Y(P0_OUT[3]) );
  NAND2X1 I66 ( .A(P0_DOUT[3]), .B(read_modify), .Y(n33) );
  NAND2X1 I67 ( .A(pin_P0[3]), .B(n39), .Y(n34) );
  NAND2X1 I68 ( .A(n35), .B(n36), .Y(P0_OUT[2]) );
  NAND2X1 I69 ( .A(P0_DOUT[2]), .B(read_modify), .Y(n35) );
  NAND2X1 I70 ( .A(pin_P0[2]), .B(n39), .Y(n36) );
  NAND2X1 I71 ( .A(n37), .B(n38), .Y(P0_OUT[4]) );
  NAND2X1 I72 ( .A(P0_DOUT[4]), .B(read_modify), .Y(n37) );
  NAND2X1 I73 ( .A(pin_P0[4]), .B(n39), .Y(n38) );
  EDFFX1 P0_SFR_reg_1_ ( .D(N5), .CK(clk), .E(N15), .Q(P0_DOUT[1]) );
  EDFFX1 P0_SFR_reg_0_ ( .D(N4), .CK(clk), .E(N15), .Q(P0_DOUT[0]) );
  EDFFX1 P0_SFR_reg_7_ ( .D(N11), .CK(clk), .E(N15), .Q(P0_DOUT[7]) );
  EDFFX1 P0_SFR_reg_6_ ( .D(N10), .CK(clk), .E(N15), .Q(P0_DOUT[6]) );
  EDFFX1 P0_SFR_reg_3_ ( .D(N7), .CK(clk), .E(N15), .Q(P0_DOUT[3]) );
  EDFFX1 P0_SFR_reg_5_ ( .D(N9), .CK(clk), .E(N15), .Q(P0_DOUT[5]) );
  EDFFX1 P0_SFR_reg_4_ ( .D(N8), .CK(clk), .E(N15), .Q(P0_DOUT[4]) );
  EDFFX1 P0_SFR_reg_2_ ( .D(N6), .CK(clk), .E(N15), .Q(P0_DOUT[2]) );
  OAI2BB1X1 I74 ( .A0N(SFR_bus[0]), .A1N(n22), .B0(n40), .Y(N4) );
  OAI2BB1X1 I75 ( .A0N(SFR_bus[1]), .A1N(n22), .B0(n40), .Y(N5) );
endmodule


module cpu ( IR_EN, ACC, user_init_pc, user_init_pc_en, xram_dout, pre_idle, 
        pre_pdwn_idle, DIR_WR, PDWN, IDLE, POR, IRAM_DIN, RETI_NFC, 
        INT_EN_1_EN, EA, RESET, CLK, RAM_CS_B, RAM_WE_B, RAM_OE_B, RAMADDR, 
        RAMOUT, ALEOFF, P2_SFR, XMEM_L, XMEM_H, XA, P0_IN, ALE_B_I, ALE_B_X, 
        PSEN_B_X, PERI_SFR_DATA, PERI_SFR_sel, IDATA, MAR, SFR_wr, XRAM_CE_B, 
        XRAM_WR_B, XRAM_RD_B, ACC_RD_XRAM, read_modify, inter_LCALL, 
        inter_vector, xrom_code_en );
  output [7:0] ACC;
  input [15:0] user_init_pc;
  input [7:0] xram_dout;
  output [7:0] IRAM_DIN;
  output [7:0] RAMADDR;
  input [7:0] RAMOUT;
  input [7:0] P2_SFR;
  output [7:0] XMEM_L;
  output [7:0] XMEM_H;
  output [15:0] XA;
  input [7:0] P0_IN;
  input [7:0] PERI_SFR_DATA;
  output [7:0] IDATA;
  output [8:0] MAR;
  input [7:0] inter_vector;
  input user_init_pc_en, pre_idle, pre_pdwn_idle, PDWN, IDLE, POR, EA, RESET,
         CLK, ALEOFF, PERI_SFR_sel, inter_LCALL;
  output IR_EN, DIR_WR, RETI_NFC, INT_EN_1_EN, RAM_CS_B, RAM_WE_B, RAM_OE_B,
         ALE_B_I, ALE_B_X, PSEN_B_X, SFR_wr, XRAM_CE_B, XRAM_WR_B, XRAM_RD_B,
         ACC_RD_XRAM, read_modify, xrom_code_en;
  wire   RETI, LAST_CYCLE, MAR_RI_EN, RAM_RD_EN, ID_PCH_EN, ID_PCL_EN,
         ID_T2_EN, WM_EN, ID_WR_EN, CYCLE2, CYCLE3, CYCLE4, BYTE2, BYTE3,
         PC_HOLD, MOVX_RI, MOVX_DPI, MOVX_RI_A, MOVX_DPI_A, MOVX_INS, MOVC_INS,
         T2_XCHD_A_EN, T1_XCHD_MDR_EN, A_IDATA_EN, CY_AC_OV_UP,
         CY_AC_OV_SUB_UP, CY0_MUL_OV_UP, CY0_DIV_OV_UP, CY_UP, CY_DA_UP,
         CY_CJNE_EN, ALU_SUBBC_EN, JBC_BIT_EN, JBC_BIT_ADDR_EN, CS1, CS2, CS3,
         CS4, LS1, LS2, LS3, LS4, ALLZ_B_PC_RES_EN, ALLZ_PC_RES_EN, ALU_ADC_EN,
         ALU_ADD_EN, ALU_ANL_EN, ALU_BITC_EN, ALU_CPL_EN, ALU_ORL_EN,
         ALU_RLC_EN, ALU_RL_EN, ALU_RRC_EN, ALU_RR_EN, ALU_SUB_EN, ALU_SWAP_EN,
         ALU_XRL_EN, A_MRR_EN, A_T1_EN, B_T1_EN, B_T2RES_EN, CAR_OUT_EN,
         CAR_PC_RES_EN, C_0_EN, C_1_EN, C_ALLZ_AND_EN, C_ALLZ_B_AND_EN,
         C_ALLZ_B_EN, C_ALLZ_B_OR_EN, C_ALLZ_OR_EN, C_B_PC_RES_EN, C_CB_EN,
         C_PC_RES_EN, DIV_OP_EN, DPTR_INC_EN, DPTR_DEC_EN, DP_T2T1_EN,
         F5_ALLZ_EN, F5_B_PC_RES_EN, F5_PC_RES_EN, MAR_BAR_EN, MAR_MDR_EN,
         MAR_P0R_EN, MAR_RES_EN, MAR_RN_EN, MAR_SP_EN, MAR_T1_EN, MUL_OP_EN,
         OV_T1Z_EN, P0R_MDR_EN, P0R_P0_EN, PC1_A_EN, PC1_DP_EN, PC1_P0R_EN,
         PC1_PCCALL_EN, PC2_DP_EN, PC2_PC_EN, PC_AD11_EN, PC_PC1_EN,
         SJMP_PC_RES_EN, JMP_PC_RES_EN, PC_RET_EN, PC_T2T1_EN, SP_RES_EN,
         SP_T1_EN, T1_0_EN, T1_1_EN, T1_BITCP_EN, T1_B_EN, T1_CBP_EN,
         T1_DAD_EN, T1_MDR_EN, T1_P0R_EN, T1_RES_EN, T1_SBP_EN, T2_0_EN,
         T2_1_EN, T2_A_EN, T2_MDR_EN, T2_P0R_EN, T2_REM2_EN, T2_RES_EN,
         T2_SP_EN, WA_EN, XAH_P2R_EN, XAL_MDR_EN, XA_DP_EN, XA_OUT_EN,
         TRANS_EN, MOVC_XROM, ACC_WR_XRAM, PC_INC_EN, PSEN_B_I, ALLZ, CY, F5,
         P0R_PRE_IR, n3, n4, n5, n6, n7, n8;
  wire   [8:0] MAR_IN;
  wire   [7:0] IR;
  wire   [2:0] BIT_REG;
  wire   [15:0] DPTR;
  wire   [7:0] P0R;
  wire   [7:0] TMP1;
  wire   [7:0] TMP2;
  wire   [7:0] rom_code;
  wire   [15:0] PC;

  iram_intf iram_intf ( .IDATA({IDATA[7:1], n7}), .MAR_RI_EN(MAR_RI_EN), 
        .RAM_RD_EN(RAM_RD_EN), .ID_PCH_EN(ID_PCH_EN), .ID_PCL_EN(ID_PCL_EN), 
        .ID_T2_EN(ID_T2_EN), .WM_EN(WM_EN), .SFR_wr(SFR_wr), .MAR(MAR_IN), 
        .RAMADDR(RAMADDR), .IRAM_DIN(IRAM_DIN), .RAM_CS_B(RAM_CS_B), 
        .RAM_OE_B(RAM_OE_B), .RAM_WE_B(RAM_WE_B), .ID_WR_EN(ID_WR_EN) );
  IR_DECODER1 ir_decoder1_0 ( .DIR_WR(DIR_WR), .RETI(RETI), .IR({IR[7:6], n6, 
        IR[4:0]}), .CYCLE2(CYCLE2), .CYCLE3(CYCLE3), .CYCLE4(CYCLE4), .BYTE2(
        BYTE2), .BYTE3(BYTE3) );
  IR_DECODER2 ir_decoder2_0 ( .POR(POR), .CLK(CLK), .PC_HOLD(PC_HOLD), 
        .read_modify(read_modify), .RAM_RD_EN(RAM_RD_EN), .MOVX_RI(MOVX_RI), 
        .MOVX_DPI(MOVX_DPI), .MOVX_RI_A(MOVX_RI_A), .MOVX_DPI_A(MOVX_DPI_A), 
        .MOVX_INS(MOVX_INS), .MOVC_INS(MOVC_INS), .T2_XCHD_A_EN(T2_XCHD_A_EN), 
        .T1_XCHD_MDR_EN(T1_XCHD_MDR_EN), .A_IDATA_EN(A_IDATA_EN), 
        .CY_AC_OV_UP(CY_AC_OV_UP), .CY_AC_OV_SUB_UP(CY_AC_OV_SUB_UP), 
        .CY0_MUL_OV_UP(CY0_MUL_OV_UP), .CY0_DIV_OV_UP(CY0_DIV_OV_UP), .CY_UP(
        CY_UP), .CY_DA_UP(CY_DA_UP), .CY_CJNE_EN(CY_CJNE_EN), .ALU_SUBBC_EN(
        ALU_SUBBC_EN), .JBC_BIT_EN(JBC_BIT_EN), .JBC_BIT_ADDR_EN(
        JBC_BIT_ADDR_EN), .IR({IR[7], n5, n6, IR[4:0]}), .CS1(CS1), .CS2(CS2), 
        .CS3(CS3), .CS4(CS4), .LS1(LS1), .LS2(LS2), .LS3(LS3), .LS4(LS4), 
        .ALLZ_B_PC_RES_EN(ALLZ_B_PC_RES_EN), .ALLZ_PC_RES_EN(ALLZ_PC_RES_EN), 
        .ALU_ADC_EN(ALU_ADC_EN), .ALU_ADD_EN(ALU_ADD_EN), .ALU_ANL_EN(
        ALU_ANL_EN), .ALU_BITC_EN(ALU_BITC_EN), .ALU_CPL_EN(ALU_CPL_EN), 
        .ALU_ORL_EN(ALU_ORL_EN), .ALU_RLC_EN(ALU_RLC_EN), .ALU_RL_EN(ALU_RL_EN), .ALU_RRC_EN(ALU_RRC_EN), .ALU_RR_EN(ALU_RR_EN), .ALU_SUB_EN(ALU_SUB_EN), 
        .ALU_SWAP_EN(ALU_SWAP_EN), .ALU_XRL_EN(ALU_XRL_EN), .A_MRR_EN(A_MRR_EN), .A_T1_EN(A_T1_EN), .B_T1_EN(B_T1_EN), .B_T2RES_EN(B_T2RES_EN), .CAR_OUT_EN(
        CAR_OUT_EN), .CAR_PC_RES_EN(CAR_PC_RES_EN), .C_0_EN(C_0_EN), .C_1_EN(
        C_1_EN), .C_ALLZ_AND_EN(C_ALLZ_AND_EN), .C_ALLZ_B_AND_EN(
        C_ALLZ_B_AND_EN), .C_ALLZ_B_EN(C_ALLZ_B_EN), .C_ALLZ_B_OR_EN(
        C_ALLZ_B_OR_EN), .C_ALLZ_OR_EN(C_ALLZ_OR_EN), .C_B_PC_RES_EN(
        C_B_PC_RES_EN), .C_CB_EN(C_CB_EN), .C_PC_RES_EN(C_PC_RES_EN), 
        .DIV_OP_EN(DIV_OP_EN), .DPTR_INC_EN(DPTR_INC_EN), .DPTR_DEC_EN(
        DPTR_DEC_EN), .DP_T2T1_EN(DP_T2T1_EN), .F5_ALLZ_EN(F5_ALLZ_EN), 
        .F5_B_PC_RES_EN(F5_B_PC_RES_EN), .F5_PC_RES_EN(F5_PC_RES_EN), 
        .ID_PCH_EN_g(ID_PCH_EN), .ID_PCL_EN_g(ID_PCL_EN), .ID_T2_EN_g(ID_T2_EN), .WM_EN_g(WM_EN), .INT_EN_1_EN(INT_EN_1_EN), .MAR_BAR_EN(MAR_BAR_EN), 
        .MAR_MDR_EN(MAR_MDR_EN), .MAR_P0R_EN(MAR_P0R_EN), .MAR_RES_EN(
        MAR_RES_EN), .MAR_RI_EN(MAR_RI_EN), .MAR_RN_EN(MAR_RN_EN), .MAR_SP_EN(
        MAR_SP_EN), .MAR_T1_EN(MAR_T1_EN), .MUL_OP_EN(MUL_OP_EN), .OV_T1Z_EN(
        OV_T1Z_EN), .P0R_MDR_EN(P0R_MDR_EN), .P0R_P0_EN(P0R_P0_EN), .PC1_A_EN(
        PC1_A_EN), .PC1_DP_EN(PC1_DP_EN), .PC1_P0R_EN(PC1_P0R_EN), 
        .PC1_PCCALL_EN(PC1_PCCALL_EN), .PC2_DP_EN(PC2_DP_EN), .PC2_PC_EN(
        PC2_PC_EN), .PC_AD11_EN(PC_AD11_EN), .PC_PC1_EN(PC_PC1_EN), 
        .SJMP_PC_RES_EN(SJMP_PC_RES_EN), .JMP_PC_RES_EN(JMP_PC_RES_EN), 
        .PC_RET_EN(PC_RET_EN), .PC_T2T1_EN(PC_T2T1_EN), .SP_RES_EN(SP_RES_EN), 
        .SP_T1_EN(SP_T1_EN), .T1_0_EN(T1_0_EN), .T1_1_EN(T1_1_EN), 
        .T1_BITCP_EN(T1_BITCP_EN), .T1_B_EN(T1_B_EN), .T1_CBP_EN(T1_CBP_EN), 
        .T1_DAD_EN(T1_DAD_EN), .T1_MDR_EN(T1_MDR_EN), .T1_P0R_EN(T1_P0R_EN), 
        .T1_RES_EN(T1_RES_EN), .T1_SBP_EN(T1_SBP_EN), .T2_0_EN(T2_0_EN), 
        .T2_1_EN(T2_1_EN), .T2_A_EN(T2_A_EN), .T2_MDR_EN(T2_MDR_EN), 
        .T2_P0R_EN(T2_P0R_EN), .T2_REM2_EN(T2_REM2_EN), .T2_RES_EN(T2_RES_EN), 
        .T2_SP_EN(T2_SP_EN), .WA_EN(WA_EN), .XAH_P2R_EN(XAH_P2R_EN), 
        .XAL_MDR_EN(XAL_MDR_EN), .XA_DP_EN(XA_DP_EN), .XA_OUT_EN(XA_OUT_EN) );
  FETCH_FSM fetch_fsm_0 ( .TRANS_EN(TRANS_EN), .PDWN(PDWN), .IDLE(IDLE), .POR(
        POR), .LAST_CYCLE(LAST_CYCLE), .MOVC_XROM(MOVC_XROM), .xrom_code_en(
        1'b1), .ALEOFF(ALEOFF), .inter_LCALL(inter_LCALL), .pre_idle(pre_idle), 
        .pre_pdwn_idle(pre_pdwn_idle), .MOVX_RI(MOVX_RI), .MOVX_DPI(MOVX_DPI), 
        .MOVX_RI_A(MOVX_RI_A), .MOVX_DPI_A(MOVX_DPI_A), .ACC_WR_XRAM(
        ACC_WR_XRAM), .ACC_RD_XRAM(ACC_RD_XRAM), .CLK(CLK), .RESET(RESET), 
        .CS1(CS1), .CS2(CS2), .CS3(CS3), .CS4(CS4), .LS1(LS1), .LS2(LS2), 
        .LS3(LS3), .LS4(LS4), .CYCLE2(CYCLE2), .CYCLE3(CYCLE3), .CYCLE4(CYCLE4), .BYTE2(BYTE2), .BYTE3(BYTE3), .PC_INC_EN(PC_INC_EN), .IR_EN(IR_EN), 
        .PSEN_B_X(PSEN_B_X), .PSEN_B_I(PSEN_B_I), .ALE_B_X(ALE_B_X), .ALE_B_I(
        ALE_B_I), .XRAM_CE_B(XRAM_CE_B), .XRAM_WR_B(XRAM_WR_B), .XRAM_RD_B(
        XRAM_RD_B) );
  MEM_INTF mem_intf_0 ( .user_init_pc(user_init_pc), .user_init_pc_en(
        user_init_pc_en), .TRANS_EN(TRANS_EN), .PC_HOLD(PC_HOLD), 
        .inter_LCALL(inter_LCALL), .inter_vector(inter_vector), .JBC_BIT_EN(
        JBC_BIT_EN), .BIT_REG(BIT_REG), .P2_SFR(P2_SFR), .DPTR(DPTR), .ALLZ(
        ALLZ), .ALLZ_B_PC_RES_EN(ALLZ_B_PC_RES_EN), .ALLZ_PC_RES_EN(
        ALLZ_PC_RES_EN), .CLK(CLK), .RESET(RESET), .XA(XA), .IDATA({IDATA[7:1], 
        n7}), .ID_WR_EN(ID_WR_EN), .MAR(MAR), .P0R(P0R), .CY(CY), .F5(F5), 
        .C_B_PC_RES_EN(C_B_PC_RES_EN), .C_PC_RES_EN(C_PC_RES_EN), 
        .F5_B_PC_RES_EN(F5_B_PC_RES_EN), .F5_PC_RES_EN(F5_PC_RES_EN), .IR({n3, 
        n8, n6, IR[4:0]}), .MDR(RAMOUT), .TMP1(TMP1), .TMP2(TMP2), .ACC(ACC), 
        .PC_AD11_EN(PC_AD11_EN), .PC_PC1_EN(PC_PC1_EN), .SJMP_PC_RES_EN(
        SJMP_PC_RES_EN), .JMP_PC_RES_EN(JMP_PC_RES_EN), .PC_RET_EN(PC_RET_EN), 
        .PC_T2T1_EN(PC_T2T1_EN), .PC1_A_EN(PC1_A_EN), .PC1_DP_EN(PC1_DP_EN), 
        .PC1_P0R_EN(PC1_P0R_EN), .PC2_DP_EN(PC2_DP_EN), .PC2_PC_EN(PC2_PC_EN), 
        .PC1_PCCALL_EN(PC1_PCCALL_EN), .DPTR_INC_EN(DPTR_INC_EN), 
        .DPTR_DEC_EN(DPTR_DEC_EN), .DP_T2T1_EN(DP_T2T1_EN), .XAH_P2R_EN(
        XAH_P2R_EN), .XA_DP_EN(XA_DP_EN), .XAL_MDR_EN(XAL_MDR_EN), 
        .P0R_MDR_EN(P0R_MDR_EN), .P0R_P0_EN(P0R_P0_EN), .P0R_PRE_IR(P0R_PRE_IR), .P0_IN(rom_code), .CAR_PC_RES_EN(CAR_PC_RES_EN), .PC_INC_EN(PC_INC_EN), 
        .PC_ADD(1'b0), .PC(PC) );
  IR_REG ir_reg_0 ( .pre_pdwn_idle(pre_pdwn_idle), .inter_LCALL(inter_LCALL), 
        .POR(POR), .CLK(CLK), .RESET(RESET), .IR_EN(IR_EN), .MOVX_INS(MOVX_INS), .MOVC_INS(MOVC_INS), .LS4(LS4), .CS3(CS3), .CS2(CS2), .ID(rom_code), .P0R(
        P0R), .P0R_PRE_IR(P0R_PRE_IR), .IR(IR) );
  EX_UNIT ex_unit_0 ( .MAR_IN(MAR_IN), .CLK(CLK), .WM_EN(WM_EN), .DPTR(DPTR), 
        .PERI_SFR_DATA(PERI_SFR_DATA), .PERI_SFR_sel(PERI_SFR_sel), .ALLZ(ALLZ), .A_IDATA_EN(A_IDATA_EN), .ALU_SUBBC_EN(ALU_SUBBC_EN), .T2_XCHD_A_EN(
        T2_XCHD_A_EN), .T1_XCHD_MDR_EN(T1_XCHD_MDR_EN), .BIT_REG(BIT_REG), 
        .JBC_BIT_ADDR_EN(JBC_BIT_ADDR_EN), .CY_AC_OV_UP(CY_AC_OV_UP), 
        .CY_AC_OV_SUB_UP(CY_AC_OV_SUB_UP), .CY0_MUL_OV_UP(CY0_MUL_OV_UP), 
        .CY0_DIV_OV_UP(CY0_DIV_OV_UP), .CY_UP(CY_UP), .CY_DA_UP(CY_DA_UP), 
        .CY_CJNE_EN(CY_CJNE_EN), .RESET(RESET), .ACC(ACC), .TMP1(TMP1), .TMP2(
        TMP2), .P0_IN(rom_code), .IDATA(IDATA), .ID_WR_EN(ID_WR_EN), .MAR(MAR), 
        .IR({n3, n8, n6, IR[4:0]}), .PC(PC), .CY(CY), .F5(F5), .MUL_OP_EN(
        MUL_OP_EN), .B_T1_EN(B_T1_EN), .OV_T1Z_EN(OV_T1Z_EN), .T1_B_EN(T1_B_EN), .T2_0_EN(T2_0_EN), .T2_REM2_EN(T2_REM2_EN), .DIV_OP_EN(DIV_OP_EN), 
        .B_T2RES_EN(B_T2RES_EN), .C_0_EN(C_0_EN), .C_1_EN(C_1_EN), 
        .C_ALLZ_AND_EN(C_ALLZ_AND_EN), .C_ALLZ_B_AND_EN(C_ALLZ_B_AND_EN), 
        .C_ALLZ_B_EN(C_ALLZ_B_EN), .C_ALLZ_B_OR_EN(C_ALLZ_B_OR_EN), 
        .C_ALLZ_OR_EN(C_ALLZ_OR_EN), .C_CB_EN(C_CB_EN), .F5_ALLZ_EN(F5_ALLZ_EN), .ID_PCH_EN(ID_PCH_EN), .ID_PCL_EN(ID_PCL_EN), .ID_T2_EN(ID_T2_EN), 
        .MAR_BAR_EN(MAR_BAR_EN), .MAR_MDR_EN(MAR_MDR_EN), .MAR_P0R_EN(
        MAR_P0R_EN), .MAR_RES_EN(MAR_RES_EN), .MAR_RI_EN(MAR_RI_EN), 
        .MAR_RN_EN(MAR_RN_EN), .MAR_SP_EN(MAR_SP_EN), .MAR_T1_EN(MAR_T1_EN), 
        .A_MRR_EN(A_MRR_EN), .A_T1_EN(A_T1_EN), .WA_EN(WA_EN), .T1_0_EN(
        T1_0_EN), .T1_1_EN(T1_1_EN), .T1_BITCP_EN(T1_BITCP_EN), .T1_CBP_EN(
        T1_CBP_EN), .T1_DAD_EN(T1_DAD_EN), .T1_MDR_EN(T1_MDR_EN), .T1_P0R_EN(
        T1_P0R_EN), .T1_RES_EN(T1_RES_EN), .T1_SBP_EN(T1_SBP_EN), .MDR(RAMOUT), 
        .P0R(P0R), .T2_1_EN(T2_1_EN), .T2_A_EN(T2_A_EN), .T2_MDR_EN(T2_MDR_EN), 
        .T2_P0R_EN(T2_P0R_EN), .T2_RES_EN(T2_RES_EN), .T2_SP_EN(T2_SP_EN), 
        .SP_RES_EN(SP_RES_EN), .SP_T1_EN(SP_T1_EN), .ALU_ADC_EN(ALU_ADC_EN), 
        .ALU_ADD_EN(ALU_ADD_EN), .ALU_ANL_EN(ALU_ANL_EN), .ALU_BITC_EN(
        ALU_BITC_EN), .ALU_CPL_EN(ALU_CPL_EN), .ALU_ORL_EN(ALU_ORL_EN), 
        .ALU_RLC_EN(ALU_RLC_EN), .ALU_RL_EN(ALU_RL_EN), .ALU_RRC_EN(ALU_RRC_EN), .ALU_RR_EN(ALU_RR_EN), .ALU_SUB_EN(ALU_SUB_EN), .ALU_SWAP_EN(ALU_SWAP_EN), 
        .ALU_XRL_EN(ALU_XRL_EN) );
  ETC_UNIT etc_unit_0 ( .xram_dout(xram_dout), .CLK(CLK), .RESET(RESET), .EA(
        EA), .ALE_B(ALE_B_I), .PSEN_B_I(PSEN_B_I), .PSEN_B_X(PSEN_B_X), 
        .xrom_code(P0_IN), .CAR_OUT_EN(CAR_OUT_EN), .XA_OUT_EN(XA_OUT_EN), 
        .XA(XA), .PC(PC), .ACC_WR_XRAM(ACC_WR_XRAM), .ACC_RD_XRAM(ACC_RD_XRAM), 
        .ACC(ACC), .P2_OUT(XMEM_H), .P0_OUT(XMEM_L), .rom_code(rom_code), 
        .MOVC_XROM(MOVC_XROM) );
  INVX1 I3 ( .A(1'b0), .Y(xrom_code_en) );
  INVX2 I5 ( .A(n4), .Y(n5) );
  BUFX1 I6 ( .A(IDATA[0]), .Y(n7) );
  BUFX1 I7 ( .A(n5), .Y(n8) );
  BUFX1 I8 ( .A(IR[7]), .Y(n3) );
  INVX1 I9 ( .A(IR[6]), .Y(n4) );
  BUFX12 I10 ( .A(IR[5]), .Y(n6) );
  NAND2BX1 I11 ( .AN(RETI), .B(LAST_CYCLE), .Y(RETI_NFC) );
endmodule


module ETC_UNIT ( xram_dout, CLK, RESET, EA, ALE_B, PSEN_B_I, PSEN_B_X, 
        xrom_code, CAR_OUT_EN, XA_OUT_EN, XA, PC, ACC_WR_XRAM, ACC_RD_XRAM, 
        ACC, P2_OUT, P0_OUT, rom_code, xrom_code_en, MOVC_XROM );
  input [7:0] xram_dout;
  input [7:0] xrom_code;
  input [15:0] XA;
  input [15:0] PC;
  input [7:0] ACC;
  output [7:0] P2_OUT;
  output [7:0] P0_OUT;
  output [7:0] rom_code;
  input CLK, RESET, EA, ALE_B, PSEN_B_I, PSEN_B_X, CAR_OUT_EN, XA_OUT_EN,
         ACC_WR_XRAM, ACC_RD_XRAM;
  output xrom_code_en, MOVC_XROM;
  wire   n4, n21, n22, n55, n56, n57, n58, n59, n60, n61, n62, n63, n64, n65,
         n66, n67, n68, n69, n70, n71, n72, n73, n74, n75, n76, n77, n78, n79,
         n80, n81, n82, n83, n84, n85, n86, n87, n88, n89, n90, n91, n92, n93,
         n94, n95, n96, n97, n98, n99, n100, n101, n102, n103;

  INVX1 I78 ( .A(1'b0), .Y(xrom_code_en) );
  INVX4 I80 ( .A(n103), .Y(n22) );
  DFFHQX1 MOVC_XROM_reg ( .D(CAR_OUT_EN), .CK(CLK), .Q(MOVC_XROM) );
  BUFX4 I81 ( .A(n21), .Y(n103) );
  OR2X2 I82 ( .A(CAR_OUT_EN), .B(XA_OUT_EN), .Y(n21) );
  NAND2X1 I83 ( .A(n55), .B(n56), .Y(rom_code[1]) );
  NAND2X1 I84 ( .A(xrom_code[1]), .B(n4), .Y(n55) );
  NAND2X1 I85 ( .A(xram_dout[1]), .B(ACC_RD_XRAM), .Y(n56) );
  NAND2X1 I86 ( .A(n57), .B(n58), .Y(rom_code[2]) );
  NAND2X1 I87 ( .A(xrom_code[2]), .B(n4), .Y(n57) );
  NAND2X1 I88 ( .A(xram_dout[2]), .B(ACC_RD_XRAM), .Y(n58) );
  INVX2 I89 ( .A(ACC_RD_XRAM), .Y(n4) );
  NAND2X1 I90 ( .A(n59), .B(n60), .Y(rom_code[4]) );
  NAND2X1 I91 ( .A(xrom_code[4]), .B(n4), .Y(n59) );
  NAND2X1 I92 ( .A(xram_dout[4]), .B(ACC_RD_XRAM), .Y(n60) );
  NAND2X1 I93 ( .A(n61), .B(n62), .Y(rom_code[0]) );
  NAND2X1 I94 ( .A(xrom_code[0]), .B(n4), .Y(n61) );
  NAND2X1 I95 ( .A(xram_dout[0]), .B(ACC_RD_XRAM), .Y(n62) );
  NAND2X1 I96 ( .A(n63), .B(n64), .Y(rom_code[6]) );
  NAND2X1 I97 ( .A(xrom_code[6]), .B(n4), .Y(n63) );
  NAND2X1 I98 ( .A(xram_dout[6]), .B(ACC_RD_XRAM), .Y(n64) );
  NAND2X1 I99 ( .A(n65), .B(n66), .Y(rom_code[5]) );
  NAND2X1 I100 ( .A(xrom_code[5]), .B(n4), .Y(n65) );
  NAND2X1 I101 ( .A(xram_dout[5]), .B(ACC_RD_XRAM), .Y(n66) );
  NAND2X1 I102 ( .A(n67), .B(n68), .Y(rom_code[3]) );
  NAND2X1 I103 ( .A(xrom_code[3]), .B(n4), .Y(n67) );
  NAND2X1 I104 ( .A(xram_dout[3]), .B(ACC_RD_XRAM), .Y(n68) );
  NAND2X1 I105 ( .A(n69), .B(n70), .Y(rom_code[7]) );
  NAND2X1 I106 ( .A(xrom_code[7]), .B(n4), .Y(n69) );
  NAND2X1 I107 ( .A(xram_dout[7]), .B(ACC_RD_XRAM), .Y(n70) );
  NAND2X1 I108 ( .A(n71), .B(n72), .Y(P0_OUT[0]) );
  NAND2X1 I109 ( .A(PC[0]), .B(n22), .Y(n71) );
  NAND2X1 I110 ( .A(XA[0]), .B(n103), .Y(n72) );
  NAND2X1 I111 ( .A(n73), .B(n74), .Y(P0_OUT[1]) );
  NAND2X1 I112 ( .A(PC[1]), .B(n22), .Y(n73) );
  NAND2X1 I113 ( .A(XA[1]), .B(n103), .Y(n74) );
  NAND2X1 I114 ( .A(n75), .B(n76), .Y(P0_OUT[2]) );
  NAND2X1 I115 ( .A(PC[2]), .B(n22), .Y(n75) );
  NAND2X1 I116 ( .A(XA[2]), .B(n103), .Y(n76) );
  NAND2X1 I117 ( .A(n77), .B(n78), .Y(P0_OUT[3]) );
  NAND2X1 I118 ( .A(PC[3]), .B(n22), .Y(n77) );
  NAND2X1 I119 ( .A(XA[3]), .B(n103), .Y(n78) );
  NAND2X1 I120 ( .A(n79), .B(n80), .Y(P0_OUT[4]) );
  NAND2X1 I121 ( .A(PC[4]), .B(n22), .Y(n79) );
  NAND2X1 I122 ( .A(XA[4]), .B(n103), .Y(n80) );
  NAND2X1 I123 ( .A(n81), .B(n82), .Y(P0_OUT[5]) );
  NAND2X1 I124 ( .A(PC[5]), .B(n22), .Y(n81) );
  NAND2X1 I125 ( .A(XA[5]), .B(n103), .Y(n82) );
  NAND2X1 I126 ( .A(n83), .B(n84), .Y(P0_OUT[6]) );
  NAND2X1 I127 ( .A(PC[6]), .B(n22), .Y(n83) );
  NAND2X1 I128 ( .A(XA[6]), .B(n103), .Y(n84) );
  NAND2X1 I129 ( .A(n85), .B(n86), .Y(P0_OUT[7]) );
  NAND2X1 I130 ( .A(PC[7]), .B(n22), .Y(n85) );
  NAND2X1 I131 ( .A(XA[7]), .B(n103), .Y(n86) );
  NAND2X1 I132 ( .A(n87), .B(n88), .Y(P2_OUT[0]) );
  NAND2X1 I133 ( .A(PC[8]), .B(n22), .Y(n87) );
  NAND2X1 I134 ( .A(XA[8]), .B(n103), .Y(n88) );
  NAND2X1 I135 ( .A(n89), .B(n90), .Y(P2_OUT[1]) );
  NAND2X1 I136 ( .A(PC[9]), .B(n22), .Y(n89) );
  NAND2X1 I137 ( .A(XA[9]), .B(n103), .Y(n90) );
  NAND2X1 I138 ( .A(n91), .B(n92), .Y(P2_OUT[2]) );
  NAND2X1 I139 ( .A(PC[10]), .B(n22), .Y(n91) );
  NAND2X1 I140 ( .A(XA[10]), .B(n103), .Y(n92) );
  NAND2X1 I141 ( .A(n93), .B(n94), .Y(P2_OUT[3]) );
  NAND2X1 I142 ( .A(PC[11]), .B(n22), .Y(n93) );
  NAND2X1 I143 ( .A(XA[11]), .B(n103), .Y(n94) );
  NAND2X1 I144 ( .A(n95), .B(n96), .Y(P2_OUT[4]) );
  NAND2X1 I145 ( .A(PC[12]), .B(n22), .Y(n95) );
  NAND2X1 I146 ( .A(XA[12]), .B(n103), .Y(n96) );
  NAND2X1 I147 ( .A(n97), .B(n98), .Y(P2_OUT[5]) );
  NAND2X1 I148 ( .A(PC[13]), .B(n22), .Y(n97) );
  NAND2X1 I149 ( .A(XA[13]), .B(n103), .Y(n98) );
  NAND2X1 I150 ( .A(n99), .B(n100), .Y(P2_OUT[6]) );
  NAND2X1 I151 ( .A(PC[14]), .B(n22), .Y(n99) );
  NAND2X1 I152 ( .A(XA[14]), .B(n103), .Y(n100) );
  NAND2X1 I153 ( .A(n101), .B(n102), .Y(P2_OUT[7]) );
  NAND2X1 I154 ( .A(PC[15]), .B(n22), .Y(n101) );
  NAND2X1 I155 ( .A(XA[15]), .B(n103), .Y(n102) );
endmodule


module EX_UNIT ( MAR_IN, CLK, WM_EN, DPTR, PERI_SFR_DATA, PERI_SFR_sel, ALLZ, 
        A_IDATA_EN, ALU_SUBBC_EN, T2_XCHD_A_EN, T1_XCHD_MDR_EN, BIT_REG, 
        JBC_BIT_ADDR_EN, CY_AC_OV_UP, CY_AC_OV_SUB_UP, CY0_MUL_OV_UP, 
        CY0_DIV_OV_UP, CY_UP, CY_DA_UP, CY_CJNE_EN, RESET, ACC, TMP1, TMP2, 
        P0_IN, IDATA, ID_WR_EN, MAR, IR, PC, CY, F5, MUL_OP_EN, B_T1_EN, 
        OV_T1Z_EN, T1_B_EN, T2_0_EN, T2_REM2_EN, DIV_OP_EN, B_T2RES_EN, C_0_EN, 
        C_1_EN, C_ALLZ_AND_EN, C_ALLZ_B_AND_EN, C_ALLZ_B_EN, C_ALLZ_B_OR_EN, 
        C_ALLZ_OR_EN, C_CB_EN, F5_ALLZ_EN, ID_PCH_EN, ID_PCL_EN, ID_T2_EN, 
        MAR_BAR_EN, MAR_MDR_EN, MAR_P0R_EN, MAR_RES_EN, MAR_RI_EN, MAR_RN_EN, 
        MAR_SP_EN, MAR_T1_EN, A_MRR_EN, A_T1_EN, WA_EN, T1_0_EN, T1_1_EN, 
        T1_BITCP_EN, T1_CBP_EN, T1_DAD_EN, T1_MDR_EN, T1_P0R_EN, T1_RES_EN, 
        T1_SBP_EN, MDR, P0R, T2_1_EN, T2_A_EN, T2_MDR_EN, T2_P0R_EN, T2_RES_EN, 
        T2_SP_EN, SP_RES_EN, SP_T1_EN, ALU_ADC_EN, ALU_ADD_EN, ALU_ANL_EN, 
        ALU_BITC_EN, ALU_CPL_EN, ALU_ORL_EN, ALU_RLC_EN, ALU_RL_EN, ALU_RRC_EN, 
        ALU_RR_EN, ALU_SUB_EN, ALU_SWAP_EN, ALU_XRL_EN );
  output [8:0] MAR_IN;
  input [15:0] DPTR;
  input [7:0] PERI_SFR_DATA;
  input [2:0] BIT_REG;
  output [7:0] ACC;
  output [7:0] TMP1;
  output [7:0] TMP2;
  input [7:0] P0_IN;
  output [7:0] IDATA;
  output [8:0] MAR;
  input [7:0] IR;
  input [15:0] PC;
  input [7:0] MDR;
  input [7:0] P0R;
  input CLK, WM_EN, PERI_SFR_sel, A_IDATA_EN, ALU_SUBBC_EN, T2_XCHD_A_EN,
         T1_XCHD_MDR_EN, JBC_BIT_ADDR_EN, CY_AC_OV_UP, CY_AC_OV_SUB_UP,
         CY0_MUL_OV_UP, CY0_DIV_OV_UP, CY_UP, CY_DA_UP, CY_CJNE_EN, RESET,
         ID_WR_EN, MUL_OP_EN, B_T1_EN, OV_T1Z_EN, T1_B_EN, T2_0_EN, T2_REM2_EN,
         DIV_OP_EN, B_T2RES_EN, C_0_EN, C_1_EN, C_ALLZ_AND_EN, C_ALLZ_B_AND_EN,
         C_ALLZ_B_EN, C_ALLZ_B_OR_EN, C_ALLZ_OR_EN, C_CB_EN, F5_ALLZ_EN,
         ID_PCH_EN, ID_PCL_EN, ID_T2_EN, MAR_BAR_EN, MAR_MDR_EN, MAR_P0R_EN,
         MAR_RES_EN, MAR_RI_EN, MAR_RN_EN, MAR_SP_EN, MAR_T1_EN, A_MRR_EN,
         A_T1_EN, WA_EN, T1_0_EN, T1_1_EN, T1_BITCP_EN, T1_CBP_EN, T1_DAD_EN,
         T1_MDR_EN, T1_P0R_EN, T1_RES_EN, T1_SBP_EN, T2_1_EN, T2_A_EN,
         T2_MDR_EN, T2_P0R_EN, T2_RES_EN, T2_SP_EN, SP_RES_EN, SP_T1_EN,
         ALU_ADC_EN, ALU_ADD_EN, ALU_ANL_EN, ALU_BITC_EN, ALU_CPL_EN,
         ALU_ORL_EN, ALU_RLC_EN, ALU_RL_EN, ALU_RRC_EN, ALU_RR_EN, ALU_SUB_EN,
         ALU_SWAP_EN, ALU_XRL_EN;
  output ALLZ, CY, F5;
  wire   n1568, n1569, n1570, n1571, n1572, n1573, n1574, ACC_IN_2_, ACC_IN_1_,
         n1567, n1575, n1576, n1577, n1578, n1579, n1580, n1581, n1582,
         T1_GT_T2, PSW_IN_5_, PSW_IN_4_, PSW_IN_3_, PSW_IN_1_, PSW_IN_0_,
         PSW_6_, PSW_5_, PSW_4_, PSW_3_, PSW_1_, SP_IN_2_, SP_IN_1_, SP_IN_0_,
         N195, TMP1_IN_7_, TMP1_IN_0_, N218, N220, N221, TMP_CY_7_, N235, N236,
         N237, N238, N239, N240, N241, N242, N243, N253, N254, N255, N256,
         N257, N258, N259, N260, N261, N262, N263, N264, N265, N266, N267,
         N268, N269, N270, N273, N274, N278, N293, N294, N295, N296, N297,
         N298, N299, N300, N301, N302, N315, N316, N317, N318, N319, N320,
         N321, N322, N323, N330, n83, n91, n97, n99, n101, n109, n110, n117,
         n118, n119, n125, n128, n129, n142, n150, n158, n160, n164, n165,
         n166, n167, n169, n170, n178, n179, n181, n182, n183, n184, n185,
         n189, n191, n192, n194, n197, n198, n199, n200, n201, n208, n211,
         n212, n213, n214, n217, n2180, n2200, n2210, n223, n224, n225, n228,
         n229, n230, n231, n232, n233, n2360, n2370, n2380, n2390, n2400,
         n2420, n245, n246, n247, n248, n2570, n2580, n2590, n2600, n2610,
         n2620, n2630, n2670, n2690, n2700, n271, n272, n276, n2780, n280,
         n282, n292, n2930, n2940, n3020, n303, n305, n306, n307, n309, n310,
         n311, n312, n313, n314, n3150, n3160, n3170, n3180, n3200, n3210,
         n327, n329, n331, n332, n334, n335, n344, n345, n347, n348, n349,
         n354, n361, n365, n368, n369, n393, n394, n395, n396, n397, n398,
         n399, n400, n401, n402, n404, n410, n411, n412, n418, n420, n421,
         n422, n424, n425, n429, n430, n431, n432, n436, n437, n438, n439,
         n444, n446, n450, n451, n452, n453, n457, n459, n460, n462, n463,
         n482, n483, n488, n489, n490, n524, n525, n544, n545, n562, n563,
         n578, n579, n595, n596, n611, n629, n632, n670, n671, n675, n676,
         n677, n678, n679, n680, n681, n682, n683, n684, n685, n686, n687,
         n688, n689, n690, n691, n692, n693, n694, n695, n696, n697, n698,
         n699, n700, n701, n702, n703, n704, n705, n706, n707, n708, n709,
         n710, n711, n712, n713, n714, n715, n716, n717, n718, n719, n720,
         n721, n722, n723, n724, n725, n726, n727, n728, n729, n730, n731,
         n732, n733, n734, n735, n736, n737, n738, n739, n740, n741, n742,
         n743, n744, n745, n746, n747, n748, n749, n750, n751, n752, n753,
         n754, n755, n756, n757, n758, n759, n760, n761, n762, n763, n764,
         n765, n766, n767, n768, n769, n770, n771, n772, n773, n774, n775,
         n776, n777, n778, n779, n780, n781, n782, n783, n784, n785, n786,
         n787, n788, n789, n790, n791, n792, n793, n794, n795, n796, n797,
         n798, n799, n800, n801, n802, n803, n804, n805, n806, n807, n808,
         n809, n810, n811, n812, n813, n814, n815, n816, n817, n819, n820,
         n821, n822, n823, n824, n825, n826, n827, n828, n829, n830, n831,
         n832, n833, n834, n835, n836, n837, n838, n839, n840, n841, n842,
         n843, n844, n845, n846, n847, n848, n849, n850, n851, n852, n853,
         n854, n855, n856, n857, n858, n859, n860, n861, n862, n863, n864,
         n865, n866, n867, n868, n869, n870, n871, n872, n873, n874, n875,
         n876, n877, n878, n879, n880, n881, n882, n883, n884, n885, n886,
         n887, n888, n889, n890, n891, n892, n893, n894, n895, n896, n897,
         n898, n899, n900, n901, n902, n903, n904, n905, n906, n907, n908,
         n909, n910, n911, n912, n913, n914, n915, n916, n917, n918, n919,
         n920, n921, n922, n923, n924, n925, n926, n927, n928, n929, n930,
         n931, n932, n933, n934, n935, n936, n937, n938, n939, n940, n941,
         n942, n943, n944, n945, n946, n947, n948, n949, n950, n951, n952,
         n953, n954, n955, n956, n957, n958, n959, n960, n961, n962, n963,
         n964, n965, n966, n967, n968, n969, n970, n971, n972, n973, n974,
         n975, n976, n977, n978, n979, n980, n981, n982, n983, n984, n985,
         n986, n987, n988, n989, n990, n991, n992, n993, n994, n995, n996,
         n997, n998, n999, n1000, n1001, n1002, n1003, n1004, n1005, n1006,
         n1007, n1008, n1009, n1010, n1011, n1012, n1013, n1014, n1015, n1016,
         n1017, n1018, n1019, n1020, n1021, n1022, n1023, n1024, n1025, n1026,
         n1027, n1028, n1029, n1030, n1031, n1032, n1033, n1034, n1035, n1036,
         n1037, n1038, n1039, n1040, n1041, n1042, n1043, n1044, n1045, n1046,
         n1047, n1048, n1049, n1050, n1051, n1052, n1053, n1054, n1055, n1056,
         n1057, n1058, n1059, n1060, n1061, n1062, n1063, n1064, n1065, n1066,
         n1067, n1068, n1069, n1070, n1071, n1072, n1073, n1074, n1075, n1076,
         n1077, n1078, n1079, n1080, n1081, n1082, n1083, n1084, n1085, n1086,
         n1087, n1088, n1089, n1090, n1091, n1092, n1093, n1094, n1095, n1096,
         n1097, n1098, n1099, n1100, n1101, n1102, n1103, n1104, n1105, n1106,
         n1107, n1108, n1109, n1110, n1111, n1112, n1113, n1114, n1115, n1116,
         n1117, n1118, n1119, n1120, n1121, n1122, n1123, n1124, n1125, n1126,
         n1127, n1128, n1129, n1130, n1131, n1132, n1133, n1134, n1135, n1136,
         n1137, n1138, n1139, n1140, n1141, n1142, n1143, n1144, n1145, n1146,
         n1147, n1148, n1149, n1150, n1151, n1152, n1153, n1154, n1155, n1156,
         n1157, n1158, n1159, n1160, n1161, n1162, n1163, n1164, n1165, n1166,
         n1167, n1168, n1169, n1170, n1171, n1172, n1173, n1174, n1175, n1176,
         n1177, n1178, n1179, n1180, n1181, n1182, n1183, n1184, n1185, n1186,
         n1187, n1188, n1189, n1190, n1191, n1192, n1193, n1194, n1195, n1196,
         n1197, n1198, n1199, n1200, n1201, n1202, n1203, n1204, n1205, n1206,
         n1207, n1208, n1209, n1210, n1211, n1212, n1213, n1214, n1215, n1216,
         n1217, n1218, n1219, n1220, n1221, n1222, n1223, n1224, n1225, n1226,
         n1227, n1228, n1229, n1230, n1231, n1232, n1233, n1234, n1235, n1236,
         n1237, n1238, n1239, n1240, n1241, n1242, n1243, n1244, n1245, n1246,
         n1247, n1248, n1249, n1250, n1251, n1252, n1253, n1254, n1255, n1256,
         n1257, n1258, n1259, n1260, n1261, n1262, n1263, n1264, n1265, n1266,
         n1267, n1268, n1269, n1270, n1271, n1272, n1273, n1274, n1275, n1276,
         n1277, n1278, n1279, n1280, n1281, n1282, n1283, n1284, n1285, n1286,
         n1287, n1288, n1289, n1290, n1291, n1292, n1293, n1294, n1295, n1296,
         n1297, n1298, n1299, n1300, n1301, n1302, n1303, n1304, n1305, n1306,
         n1307, n1308, n1309, n1310, n1311, n1312, n1313, n1314, n1315, n1316,
         n1317, n1318, n1319, n1320, n1321, n1322, n1323, n1324, n1325, n1326,
         n1327, n1328, n1329, n1330, n1331, n1332, n1333, n1334, n1335, n1336,
         n1337, n1338, n1339, n1340, n1341, n1342, n1343, n1344, n1345, n1346,
         n1347, n1348, n1349, n1350, n1351, n1352, n1353, n1354, n1355, n1356,
         n1357, n1358, n1359, n1360, n1361, n1362, n1363, n1364, n1365, n1366,
         n1367, n1368, n1369, n1370, n1371, n1372, n1373, n1374, n1375, n1376,
         n1377, n1378, n1379, n1380, n1381, n1382, n1383, n1384, n1385, n1386,
         n1387, n1388, n1389, n1390, n1391, n1392, n1393, n1394, n1395, n1396,
         n1397, n1398, n1399, n1400, n1401, n1402, n1403, n1404, n1405, n1406,
         n1407, n1408, n1409, n1410, n1411, n1412, n1413, n1414, n1415, n1416,
         n1417, n1418, n1419, n1420, n1421, n1422, n1423, n1424, n1425, n1426,
         n1427, n1428, n1429, n1430, n1431, n1432, n1433, n1434, n1435, n1436,
         n1437, n1438, n1439, n1440, n1441, n1442, n1443, n1444, n1445, n1446,
         n1447, n1448, n1449, n1450, n1451, n1452, n1453, n1454, n1455, n1456,
         n1457, n1458, n1459, n1460, n1461, n1462, n1463, n1464, n1465, n1466,
         n1467, n1468, n1469, n1470, n1471, n1472, n1473, n1474, n1475, n1476,
         n1477, n1478, n1479, n1480, n1481, n1482, n1483, n1484, n1485, n1486,
         n1487, n1488, n1489, n1490, n1491, n1492, n1493, n1494, n1495, n1496,
         n1497, n1498, n1499, n1500, n1501, n1502, n1503, n1504, n1505, n1506,
         n1507, n1508, n1509, n1510, n1511, n1512, n1513, n1514, n1515, n1516,
         n1517, n1518, n1519, n1520, n1521, n1522, n1523, n1524, n1525, n1526,
         n1528, n1529, n1530, n1531, n1532, n1533, n1534, n1535, n1540, n1543,
         n1544, add_1_root_add_626_4_carry_3_, n1553, n1554, n1555, n1556,
         n1557, n1558, n1559, n1560, n1561, n1562, n1563, n1564, n1565, n1566;
  wire   [7:0] B_REG;
  wire   [7:0] B2_REG;
  wire   [7:0] B_REG_IN;
  wire   [7:0] SP;
  wire   [7:0] TMP1_SUB;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1, 
        SYNOPSYS_UNCONNECTED__2, SYNOPSYS_UNCONNECTED__3;

  DFFTRX4 TMP1_reg_1_ ( .D(n2420), .CK(CLK), .RN(n815), .Q(n1574), .QN(n246)
         );
  DFFHQX4 MAR_reg_0_ ( .D(MAR_IN[0]), .CK(CLK), .Q(MAR[0]) );
  DFFX4 MAR_reg_1_ ( .D(MAR_IN[1]), .CK(CLK), .Q(MAR[1]), .QN(n750) );
  DFFHQX4 MAR_reg_5_ ( .D(MAR_IN[5]), .CK(CLK), .Q(MAR[5]) );
  AOI221X4 U63 ( .A0(P0R[0]), .A1(T2_P0R_EN), .B0(SP[0]), .B1(T2_SP_EN), .C0(
        n166), .Y(n165) );
  AOI222X4 U114 ( .A0(n713), .A1(TMP1[3]), .B0(T1_B_EN), .B1(B_REG[3]), .C0(
        n675), .C1(P0R[3]), .Y(n232) );
  AOI221X4 U120 ( .A0(T1_B_EN), .A1(B_REG[2]), .B0(n675), .B1(P0R[2]), .C0(
        n2390), .Y(n2380) );
  AOI221X4 U128 ( .A0(T1_B_EN), .A1(B_REG[1]), .B0(n675), .B1(P0R[1]), .C0(
        n248), .Y(n247) );
  OAI31X4 U195 ( .A0(n309), .A1(n310), .A2(n311), .B0(n312), .Y(n307) );
  AOI32X4 U198 ( .A0(n3150), .A1(n3160), .A2(n3170), .B0(CY_DA_UP), .B1(n314), 
        .Y(n309) );
  OAI32X4 U277 ( .A0(n393), .A1(n811), .A2(n394), .B0(n395), .B1(n396), .Y(
        PSW_IN_0_) );
  OAI211X4 U297 ( .A0(n788), .A1(n117), .B0(n421), .C0(n422), .Y(n420) );
  AOI222X4 U298 ( .A0(MAR_T1_EN), .A1(TMP1[5]), .B0(MAR_MDR_EN), .B1(MDR[5]), 
        .C0(MAR_SP_EN), .C1(SP[5]), .Y(n422) );
  OAI222X4 U305 ( .A0(n125), .A1(n411), .B0(n431), .B1(n410), .C0(n2180), .C1(
        n412), .Y(n430) );
  AOI222X4 U311 ( .A0(MAR_T1_EN), .A1(TMP1[3]), .B0(MAR_SP_EN), .B1(SP[3]), 
        .C0(MAR_MDR_EN), .C1(MDR[3]), .Y(n438) );
  AOI221X4 U411 ( .A0(n489), .A1(IDATA[6]), .B0(n490), .B1(ACC[6]), .C0(n525), 
        .Y(n524) );
  AOI221X4 U433 ( .A0(n489), .A1(IDATA[5]), .B0(n490), .B1(ACC[5]), .C0(n545), 
        .Y(n544) );
  AOI221X4 U456 ( .A0(n489), .A1(IDATA[4]), .B0(n490), .B1(ACC[4]), .C0(n563), 
        .Y(n562) );
  AOI221X4 U478 ( .A0(n489), .A1(IDATA[3]), .B0(n490), .B1(ACC[3]), .C0(n579), 
        .Y(n578) );
  AOI221X4 U500 ( .A0(n489), .A1(IDATA[2]), .B0(n490), .B1(ACC[2]), .C0(n596), 
        .Y(n595) );
  BUFX3 I630 ( .A(T1_P0R_EN), .Y(n675) );
  NAND3BX1 I631 ( .AN(n800), .B(n1519), .C(n1517), .Y(n1317) );
  AOI2BB2X1 I632 ( .A0N(n990), .A1N(n2580), .B0(n989), .B1(B_REG[0]), .Y(n1098) );
  AND3X2 I633 ( .A(n1424), .B(n1425), .C(n1426), .Y(n681) );
  NOR2BX1 I634 ( .AN(MAR[7]), .B(n711), .Y(n1130) );
  AND4X2 I635 ( .A(n1411), .B(n1413), .C(n1414), .D(n676), .Y(n1410) );
  INVX1 I636 ( .A(n1412), .Y(n676) );
  NOR3X2 I637 ( .A(n677), .B(n1508), .C(n1327), .Y(n1160) );
  NAND3BX1 I638 ( .AN(n208), .B(n992), .C(n993), .Y(n985) );
  AOI22X1 I639 ( .A0(T2_P0R_EN), .A1(P0R[1]), .B0(n91), .B1(n1582), .Y(n678)
         );
  INVX1 I640 ( .A(n678), .Y(n1011) );
  NOR3X1 I641 ( .A(n1420), .B(n1421), .C(n1422), .Y(n682) );
  OR2X2 I642 ( .A(n1330), .B(MAR[0]), .Y(n1296) );
  OAI2BB2X1 I643 ( .A0N(n736), .A1N(ALU_CPL_EN), .B0(n1423), .B1(n365), .Y(
        n1444) );
  INVX1 I644 ( .A(n1509), .Y(n1423) );
  AOI211X1 I645 ( .A0(n679), .A1(PERI_SFR_DATA[1]), .B0(n1321), .C0(n1322), 
        .Y(n680) );
  INVX1 I646 ( .A(n772), .Y(n679) );
  INVX1 I647 ( .A(n680), .Y(n1155) );
  AND4X2 I648 ( .A(n681), .B(n682), .C(n685), .D(n763), .Y(n683) );
  INVX2 I649 ( .A(n683), .Y(n857) );
  OR2X2 I650 ( .A(ALU_RL_EN), .B(ALU_RLC_EN), .Y(n1448) );
  OAI2BB1X1 I651 ( .A0N(n738), .A1N(B_REG[7]), .B0(n1169), .Y(n1168) );
  OAI2BB1X1 I652 ( .A0N(n684), .A1N(PERI_SFR_DATA[2]), .B0(n1298), .Y(n1279)
         );
  INVX1 I653 ( .A(n772), .Y(n684) );
  AND4X2 I654 ( .A(n1101), .B(n1102), .C(n2590), .D(n969), .Y(n713) );
  OAI2BB2X1 I655 ( .A0N(ACC[1]), .A1N(n716), .B0(n790), .B1(n836), .Y(n1013)
         );
  NAND2X1 I656 ( .A(MAR_RES_EN), .B(n866), .Y(n896) );
  NAND2X1 I657 ( .A(N266), .B(n762), .Y(n769) );
  AND2X2 I658 ( .A(n2370), .B(n746), .Y(n923) );
  AOI21X1 I659 ( .A0(n1515), .A1(n1576), .B0(n1202), .Y(n1201) );
  OR3X2 I660 ( .A(n715), .B(n429), .C(n462), .Y(n711) );
  NOR2BX1 I661 ( .AN(n1164), .B(n1162), .Y(n1149) );
  NOR2X1 I662 ( .A(n966), .B(n967), .Y(n964) );
  INVX1 I663 ( .A(n1531), .Y(n967) );
  AOI2BB2X1 I664 ( .A0N(n463), .A1N(n736), .B0(n1512), .B1(n795), .Y(n1167) );
  NAND2BX1 I665 ( .AN(n1082), .B(N239), .Y(n770) );
  AOI22X1 I666 ( .A0(n762), .A1(N264), .B0(n1448), .B1(n1581), .Y(n685) );
  OR2X2 I667 ( .A(n1153), .B(n1163), .Y(n1151) );
  AOI2BB2X1 I668 ( .A0N(n463), .A1N(n728), .B0(n838), .B1(n795), .Y(n1195) );
  AOI211X1 I669 ( .A0(n1574), .A1(n748), .B0(n1513), .C0(n749), .Y(n686) );
  INVX1 I670 ( .A(n686), .Y(n1562) );
  AND4X2 I671 ( .A(n1465), .B(n1466), .C(n769), .D(n770), .Y(n771) );
  OAI2BB1X1 I672 ( .A0N(n738), .A1N(B_REG[6]), .B0(n1197), .Y(n1196) );
  NAND2X1 I673 ( .A(n871), .B(n1531), .Y(n981) );
  NAND2X1 I674 ( .A(n1576), .B(n91), .Y(n833) );
  OAI222X4 I675 ( .A0(n695), .A1(n687), .B0(n966), .B1(n836), .C0(n790), .C1(
        n837), .Y(n1016) );
  INVX1 I676 ( .A(n716), .Y(n687) );
  DFFX1 ACC_reg_2_ ( .D(ACC_IN_2_), .CK(CLK), .Q(ACC[2]), .QN(n695) );
  NOR3BX1 I677 ( .AN(n1156), .B(n1160), .C(n1161), .Y(n690) );
  OAI2BB1X1 I678 ( .A0N(n118), .A1N(n109), .B0(ACC[7]), .Y(n808) );
  NOR3X1 I679 ( .A(T1_CBP_EN), .B(T1_DAD_EN), .C(T1_B_EN), .Y(n2620) );
  OAI211X1 I680 ( .A0(n348), .A1(n1427), .B0(n1429), .C0(n1428), .Y(n688) );
  INVX1 I681 ( .A(n688), .Y(n1426) );
  AOI21X1 I682 ( .A0(n1578), .A1(n1515), .B0(n1243), .Y(n1242) );
  NAND3BX1 I683 ( .AN(n1512), .B(n1575), .C(n314), .Y(n734) );
  NAND2X1 I684 ( .A(n866), .B(n968), .Y(n980) );
  INVX2 I685 ( .A(n771), .Y(n866) );
  AOI2BB2X1 I686 ( .A0N(n463), .A1N(n689), .B0(n871), .B1(n795), .Y(n1214) );
  OAI2BB1X1 I687 ( .A0N(IDATA[3]), .A1N(T2_MDR_EN), .B0(n1022), .Y(n129) );
  NOR2BX1 I688 ( .AN(B_REG[0]), .B(n482), .Y(n1367) );
  OAI22X1 I689 ( .A0(n787), .A1(n728), .B0(n1383), .B1(n703), .Y(n1487) );
  OAI2BB2X1 I690 ( .A0N(n178), .A1N(n212), .B0(n807), .B1(n197), .Y(n208) );
  AND2X2 I691 ( .A(n771), .B(n768), .Y(n1431) );
  AOI2BB1X1 I692 ( .A0N(n1082), .A1N(n1083), .B0(n801), .Y(n1081) );
  AOI21X1 I693 ( .A0(n1515), .A1(n1579), .B0(n1264), .Y(n1263) );
  OAI2BB1X1 I694 ( .A0N(n738), .A1N(B_REG[5]), .B0(n1216), .Y(n1215) );
  NAND2X1 I695 ( .A(n1571), .B(n713), .Y(n794) );
  AOI31X1 I696 ( .A0(n1157), .A1(n1159), .A2(n690), .B0(n760), .Y(n691) );
  INVX1 I697 ( .A(n691), .Y(n1310) );
  AOI2BB1X1 I698 ( .A0N(n711), .A1N(n1137), .B0(n1133), .Y(n1132) );
  OAI2BB1X1 I699 ( .A0N(n819), .A1N(T2_MDR_EN), .B0(n1015), .Y(n142) );
  AND2X2 I700 ( .A(MAR[0]), .B(n750), .Y(n751) );
  AND2X2 I701 ( .A(n762), .B(N265), .Y(n1452) );
  NAND3BX1 I702 ( .AN(n311), .B(n305), .C(n3200), .Y(n3020) );
  NOR2X1 I703 ( .A(n771), .B(n1496), .Y(n1241) );
  AOI21X1 I704 ( .A0(n1515), .A1(n1580), .B0(n1285), .Y(n1284) );
  AOI222X4 I705 ( .A0(ACC[4]), .A1(T1_XCHD_MDR_EN), .B0(P0R[4]), .B1(n675), 
        .C0(B_REG[4]), .C1(T1_B_EN), .Y(n692) );
  INVX1 I706 ( .A(n692), .Y(n2210) );
  AOI22X1 I707 ( .A0(n1531), .A1(n1512), .B0(n838), .B1(n968), .Y(n693) );
  INVX1 I708 ( .A(n693), .Y(n997) );
  NAND2X1 I709 ( .A(n1577), .B(n91), .Y(n1057) );
  OAI2BB2X1 I710 ( .A0N(n1500), .A1N(n795), .B0(n463), .B1(n749), .Y(n1334) );
  NAND4BX1 I711 ( .AN(n437), .B(n893), .C(n894), .D(n895), .Y(n432) );
  NAND2X1 I712 ( .A(T2_MDR_EN), .B(n847), .Y(n1008) );
  AOI21X1 I713 ( .A0(n694), .A1(n695), .B0(n741), .Y(N195) );
  OAI2BB1X1 I714 ( .A0N(n1509), .A1N(n1514), .B0(n1391), .Y(n1415) );
  OAI22X1 I715 ( .A0(n394), .A1(n1508), .B0(n1374), .B1(n292), .Y(n1364) );
  AND2X2 I716 ( .A(n762), .B(N267), .Y(n1480) );
  NOR3X1 I717 ( .A(T1_RES_EN), .B(T1_SBP_EN), .C(n675), .Y(n2630) );
  NAND3BX1 I718 ( .AN(n314), .B(n1512), .C(n736), .Y(n369) );
  OAI2BB1X1 I719 ( .A0N(n738), .A1N(B_REG[2]), .B0(n1278), .Y(n1277) );
  OAI211X4 I720 ( .A0(n772), .A1(n1205), .B0(n1206), .C0(n1198), .Y(n821) );
  NAND2X1 I721 ( .A(n1578), .B(n91), .Y(n1047) );
  OAI2BB1X1 I722 ( .A0N(IDATA[4]), .A1N(n1534), .B0(n978), .Y(n214) );
  AOI31X1 I723 ( .A0(n889), .A1(n890), .A2(n891), .B0(RESET), .Y(MAR_IN[2]) );
  AOI211X1 I724 ( .A0(n1581), .A1(n756), .B0(n1011), .C0(n1012), .Y(n1010) );
  AND2X1 I725 ( .A(n1512), .B(WM_EN), .Y(n1173) );
  AOI21X1 I726 ( .A0(n246), .A1(n748), .B0(n749), .Y(n926) );
  NOR2X1 I727 ( .A(N278), .B(n1498), .Y(n1075) );
  INVX1 I728 ( .A(n713), .Y(n1498) );
  AOI21X1 I729 ( .A0(n696), .A1(N241), .B0(n1396), .Y(n1395) );
  INVX1 I730 ( .A(n1082), .Y(n696) );
  OAI22X1 I731 ( .A0(n697), .A1(n191), .B0(n189), .B1(n117), .Y(n988) );
  AOI21X1 I732 ( .A0(n892), .A1(MAR[2]), .B0(n444), .Y(n891) );
  OAI2BB1X1 I733 ( .A0N(n738), .A1N(B_REG[3]), .B0(n1258), .Y(n1257) );
  NAND2X1 I734 ( .A(T2_RES_EN), .B(n871), .Y(n1048) );
  NAND2X1 I735 ( .A(n1579), .B(n91), .Y(n1037) );
  MX2X1 I736 ( .S0(n314), .B(n912), .A(n365), .Y(n911) );
  NAND2X1 I737 ( .A(n974), .B(IDATA[3]), .Y(n976) );
  AOI2BB2X1 I738 ( .A0N(n463), .A1N(n746), .B0(n857), .B1(n795), .Y(n1276) );
  AOI21X1 I739 ( .A0(n1515), .A1(n1575), .B0(n1177), .Y(n1176) );
  AOI22X1 I740 ( .A0(PSW_4_), .A1(n429), .B0(n418), .B1(P0R[4]), .Y(n698) );
  INVX1 I741 ( .A(n698), .Y(n899) );
  NAND2X1 I742 ( .A(n1128), .B(n1569), .Y(n1135) );
  NOR2X1 I743 ( .A(ALU_ADC_EN), .B(ALU_SUBBC_EN), .Y(n347) );
  AOI21X1 I744 ( .A0(n1357), .A1(n1356), .B0(n1355), .Y(n699) );
  INVX1 I745 ( .A(n699), .Y(n1341) );
  AOI211X1 I746 ( .A0(TMP1[5]), .A1(n713), .B0(n987), .C0(n988), .Y(n700) );
  INVX1 I747 ( .A(n700), .Y(n986) );
  MXI2X1 I748 ( .S0(n913), .B(n931), .A(n822), .Y(n930) );
  OAI2BB1X1 I749 ( .A0N(SP[4]), .A1N(n739), .B0(n949), .Y(n948) );
  OAI21X1 I750 ( .A0(n229), .A1(n2360), .B0(n2380), .Y(n701) );
  INVX1 I751 ( .A(n701), .Y(n970) );
  AOI2BB2X1 I752 ( .A0N(n463), .A1N(n748), .B0(n1504), .B1(n795), .Y(n1307) );
  AOI211X1 I753 ( .A0(n128), .A1(n821), .B0(n1051), .C0(n1052), .Y(n702) );
  INVX1 I754 ( .A(n702), .Y(n101) );
  AND2X2 I755 ( .A(ALU_ADC_EN), .B(N253), .Y(n1416) );
  NAND4X1 I756 ( .A(n823), .B(n1193), .C(n1295), .D(n1296), .Y(n1319) );
  AOI21X1 I757 ( .A0(n1515), .A1(n1577), .B0(n1223), .Y(n1222) );
  OAI2BB2X1 I758 ( .A0N(n178), .A1N(n245), .B0(n806), .B1(n197), .Y(n248) );
  OAI2BB1X1 I759 ( .A0N(IDATA[7]), .A1N(n128), .B0(n825), .Y(n83) );
  OAI2BB1X1 I760 ( .A0N(n797), .A1N(PSW_3_), .B0(n1118), .Y(PSW_IN_3_) );
  AOI22X1 I761 ( .A0(n1505), .A1(n1531), .B0(n713), .B1(n1573), .Y(n972) );
  AOI2BB2X1 I762 ( .A0N(n463), .A1N(n703), .B0(n866), .B1(n795), .Y(n1235) );
  OAI2BB1X1 I763 ( .A0N(ALU_SUBBC_EN), .A1N(N315), .B0(n1418), .Y(n1417) );
  AOI211X1 I764 ( .A0(n1362), .A1(n704), .B0(n1355), .C0(n459), .Y(n705) );
  INVX1 I765 ( .A(n1361), .Y(n704) );
  INVX1 I766 ( .A(n705), .Y(n1360) );
  NAND2X1 I767 ( .A(n1531), .B(n314), .Y(n1072) );
  OAI222X4 I768 ( .A0(n198), .A1(n194), .B0(n1498), .B1(n729), .C0(n807), .C1(
        n197), .Y(n998) );
  INVX1 I769 ( .A(n178), .Y(n198) );
  AND2X2 I770 ( .A(SP[1]), .B(T2_SP_EN), .Y(n1012) );
  OAI2BB1X1 I771 ( .A0N(n738), .A1N(B_REG[1]), .B0(n1309), .Y(n1308) );
  NAND2X1 I772 ( .A(MAR_RES_EN), .B(n1500), .Y(n881) );
  NOR2X1 I773 ( .A(n744), .B(n463), .Y(n1256) );
  OAI2BB1X1 I774 ( .A0N(n128), .A1N(n820), .B0(n1040), .Y(n110) );
  AOI22X1 I775 ( .A0(n909), .A1(n908), .B0(n368), .B1(n910), .Y(n900) );
  AND2X1 I776 ( .A(n762), .B(N268), .Y(n1396) );
  NAND2X1 I777 ( .A(n2370), .B(n1580), .Y(n1063) );
  OAI22X1 I778 ( .A0(n3020), .A1(n939), .B0(n940), .B1(n2600), .Y(n938) );
  AND4X2 I779 ( .A(n1357), .B(n1356), .C(n706), .D(n707), .Y(n791) );
  INVX1 I780 ( .A(n1358), .Y(n706) );
  INVX1 I781 ( .A(n1407), .Y(n707) );
  OAI2BB1X1 I782 ( .A0N(n738), .A1N(B_REG[4]), .B0(n1237), .Y(n1236) );
  OAI211X4 I783 ( .A0(n772), .A1(n1267), .B0(n1268), .C0(n1259), .Y(IDATA[3])
         );
  OAI2BB1X1 I784 ( .A0N(n739), .A1N(SP[7]), .B0(n960), .Y(n959) );
  OAI2BB1X1 I785 ( .A0N(IDATA[4]), .A1N(n128), .B0(n1030), .Y(n119) );
  OAI2BB1X1 I786 ( .A0N(n797), .A1N(PSW_5_), .B0(n1116), .Y(PSW_IN_5_) );
  NAND2X1 I787 ( .A(n892), .B(MAR[5]), .Y(n1141) );
  NAND2X1 I788 ( .A(n974), .B(n847), .Y(n961) );
  INVX2 I789 ( .A(n768), .Y(n1505) );
  DFFHQX1 MAR_reg_6_ ( .D(MAR_IN[6]), .CK(CLK), .Q(MAR[6]) );
  AND3X2 I790 ( .A(n1165), .B(n1153), .C(n712), .Y(n790) );
  NAND3BX4 I791 ( .AN(n1432), .B(n1433), .C(n1434), .Y(n1512) );
  NAND4BX2 I792 ( .AN(n1148), .B(n1149), .C(n1150), .D(n1151), .Y(IDATA[1]) );
  INVX1 I793 ( .A(n1330), .Y(n1354) );
  AND2X2 I794 ( .A(n1377), .B(n776), .Y(n731) );
  DFFHQX2 PSW_7_D_reg ( .D(CY), .CK(CLK), .Q(TMP_CY_7_) );
  NAND4X1 I795 ( .A(n823), .B(n1507), .C(n1296), .D(n1295), .Y(n1352) );
  NAND2BX1 I796 ( .AN(n1495), .B(N269), .Y(n799) );
  NAND3X1 I797 ( .A(n192), .B(n1014), .C(n1530), .Y(n723) );
  INVX1 I798 ( .A(n482), .Y(n671) );
  MXI2X1 I799 ( .S0(n1523), .B(n1430), .A(ALU_CPL_EN), .Y(n1424) );
  NAND2X1 I800 ( .A(n1390), .B(n1511), .Y(n1389) );
  MXI2X1 I801 ( .S0(n1574), .B(n1392), .A(n1509), .Y(n1390) );
  NAND3X1 I802 ( .A(n1439), .B(n1440), .C(n1441), .Y(n1435) );
  INVX2 I803 ( .A(n760), .Y(n761) );
  INVX1 I804 ( .A(n723), .Y(n760) );
  BUFX3 I805 ( .A(n1581), .Y(TMP2[1]) );
  DFFHQX1 SP_reg_1_ ( .D(SP_IN_1_), .CK(CLK), .Q(SP[1]) );
  DFFX1 MAR_reg_8_ ( .D(MAR_IN[8]), .CK(CLK), .Q(MAR[8]), .QN(n404) );
  DFFHQX2 MAR_reg_7_ ( .D(MAR_IN[7]), .CK(CLK), .Q(MAR[7]) );
  DFFHQX2 MAR_reg_4_ ( .D(MAR_IN[4]), .CK(CLK), .Q(MAR[4]) );
  INVX1 I806 ( .A(T1_XCHD_MDR_EN), .Y(n192) );
  INVX2 I807 ( .A(N322), .Y(n1437) );
  NAND2BX2 I808 ( .AN(n1288), .B(n1289), .Y(n1174) );
  OAI21X1 I809 ( .A0(n1290), .A1(n1291), .B0(n761), .Y(n1289) );
  NAND2X2 I810 ( .A(MAR[0]), .B(n1354), .Y(n1295) );
  NAND2X1 I811 ( .A(MAR[4]), .B(n671), .Y(n1293) );
  NAND2X2 I812 ( .A(ALU_ADD_EN), .B(n967), .Y(n1082) );
  NAND2X1 I813 ( .A(n1183), .B(DPTR[1]), .Y(n1332) );
  NAND3X1 I814 ( .A(SP[1]), .B(n1183), .C(n1326), .Y(n1159) );
  NAND2BX1 I815 ( .AN(n811), .B(WM_EN), .Y(n1163) );
  BUFX3 I816 ( .A(n1573), .Y(n1540) );
  NAND2BX1 I817 ( .AN(n811), .B(WM_EN), .Y(n1355) );
  NAND2BX2 I818 ( .AN(ALU_ORL_EN), .B(n1489), .Y(n1361) );
  MX2X1 I819 ( .S0(n1531), .B(N263), .A(N236), .Y(n1388) );
  OAI2BB2X2 I820 ( .A0N(BIT_REG[0]), .A1N(JBC_BIT_ADDR_EN), .B0(
        JBC_BIT_ADDR_EN), .B1(n271), .Y(n200) );
  OAI2BB2X2 I821 ( .A0N(JBC_BIT_ADDR_EN), .A1N(BIT_REG[2]), .B0(
        JBC_BIT_ADDR_EN), .B1(n2690), .Y(n224) );
  INVX1 I822 ( .A(P0R[2]), .Y(n2690) );
  INVX1 I823 ( .A(TMP2[0]), .Y(n927) );
  INVX1 I824 ( .A(P0R[1]), .Y(n2700) );
  NAND3X1 I825 ( .A(n1408), .B(n1409), .C(n1410), .Y(n1358) );
  MXI2X1 I826 ( .S0(n1582), .B(n1415), .A(ALU_CPL_EN), .Y(n1409) );
  AOI21X1 I827 ( .A0(n1343), .A1(n1344), .B0(n1345), .Y(n1342) );
  OAI21X1 I828 ( .A0(n1352), .A1(n1353), .B0(n723), .Y(n1343) );
  NAND4X1 I829 ( .A(n1346), .B(n1347), .C(n1348), .D(n1349), .Y(n1345) );
  NAND2X1 I830 ( .A(n1152), .B(n1358), .Y(n1340) );
  OAI21X1 I831 ( .A0(n431), .A1(n1174), .B0(n1242), .Y(n1240) );
  NAND2X2 I832 ( .A(TMP2[7]), .B(n1528), .Y(n912) );
  NAND4X1 I833 ( .A(n1156), .B(n1157), .C(n1158), .D(n1159), .Y(n1154) );
  BUFX8 I834 ( .A(MUL_OP_EN), .Y(n1531) );
  NAND4X1 I835 ( .A(n1053), .B(n1054), .C(n1055), .D(n1056), .Y(n1052) );
  NAND4X1 I836 ( .A(n1043), .B(n1044), .C(n1045), .D(n1046), .Y(n1042) );
  INVX1 I837 ( .A(ID_PCH_EN), .Y(n1517) );
  INVX1 I838 ( .A(ID_PCL_EN), .Y(n1519) );
  NOR2BX2 I839 ( .AN(MAR[4]), .B(MAR[5]), .Y(n1375) );
  AND2X2 I840 ( .A(n1376), .B(n776), .Y(n730) );
  NAND2X2 I841 ( .A(MAR[1]), .B(n731), .Y(n1330) );
  NAND2X2 I842 ( .A(n1375), .B(n730), .Y(n1193) );
  MXI2X2 I843 ( .S0(n1526), .B(n1392), .A(n1509), .Y(n1362) );
  NAND2X2 I844 ( .A(n1375), .B(n730), .Y(n1508) );
  NAND2X2 I845 ( .A(MAR[5]), .B(n730), .Y(n482) );
  NAND2X2 I846 ( .A(n1447), .B(n1510), .Y(n1392) );
  AOI2BB2X1 I847 ( .A0N(n1383), .A1N(n927), .B0(n1361), .B1(TMP1[1]), .Y(n1381) );
  AOI2BB2X1 I848 ( .A0N(n782), .A1N(n1384), .B0(N316), .B1(n1093), .Y(n1380)
         );
  OAI2BB2X2 I849 ( .A0N(BIT_REG[1]), .A1N(JBC_BIT_ADDR_EN), .B0(
        JBC_BIT_ADDR_EN), .B1(n2700), .Y(n213) );
  MXI2X2 I850 ( .S0(n1535), .B(N218), .A(T1_GT_T2), .Y(n939) );
  INVX1 I851 ( .A(n332), .Y(n329) );
  AOI22X1 I852 ( .A0(n1525), .A1(TMP1[3]), .B0(n1523), .B1(n1540), .Y(n925) );
  BUFX8 I853 ( .A(TMP_CY_7_), .Y(n1535) );
  NAND4X1 I854 ( .A(n1445), .B(n1446), .C(n722), .D(n799), .Y(n1432) );
  AOI2BB1X2 I855 ( .A0N(n1082), .A1N(n1443), .B0(n1444), .Y(n1433) );
  NAND2X1 I856 ( .A(n1315), .B(n1316), .Y(n1164) );
  NOR3BX1 I857 ( .AN(n1297), .B(n1317), .C(n1318), .Y(n1316) );
  OAI21X1 I858 ( .A0(n1319), .A1(n1320), .B0(n723), .Y(n1315) );
  NAND3X2 I859 ( .A(n789), .B(n1378), .C(n1379), .Y(n934) );
  NOR2X1 I860 ( .A(n857), .B(n1501), .Y(n1378) );
  NOR2X1 I861 ( .A(n1506), .B(n1504), .Y(n1379) );
  NAND3X2 I862 ( .A(n724), .B(n798), .C(n1341), .Y(IDATA[0]) );
  AND2X2 I863 ( .A(n1359), .B(n1360), .Y(n798) );
  NAND2BX2 I864 ( .AN(n1238), .B(n1239), .Y(IDATA[4]) );
  OAI21X1 I865 ( .A0(n1240), .A1(n1241), .B0(n812), .Y(n1239) );
  NOR2X1 I866 ( .A(TMP1[5]), .B(TMP1[4]), .Y(n902) );
  INVX2 I867 ( .A(n1512), .Y(n909) );
  NAND2X2 I868 ( .A(n1120), .B(ID_WR_EN), .Y(n913) );
  OR2X2 I869 ( .A(n811), .B(n595), .Y(n401) );
  NAND4X1 I870 ( .A(n1025), .B(n1026), .C(n1027), .D(n1028), .Y(n1024) );
  NAND4X1 I871 ( .A(n1018), .B(n1019), .C(n1020), .D(n1021), .Y(n1017) );
  INVX4 I872 ( .A(n934), .Y(ALLZ) );
  DFFHQX1 TMP1_reg_7_ ( .D(TMP1_IN_7_), .CK(CLK), .Q(n1568) );
  DFFX2 ACC_reg_6_ ( .D(n778), .CK(CLK), .Q(ACC[6]), .QN(n109) );
  DFFX1 ACC_reg_1_ ( .D(ACC_IN_1_), .CK(CLK), .Q(ACC[1]), .QN(n694) );
  DFFHQX1 B_REG_reg_7_ ( .D(B_REG_IN[7]), .CK(CLK), .Q(B_REG[7]) );
  DFFX1 B_REG_reg_6_ ( .D(B_REG_IN[6]), .CK(CLK), .Q(B_REG[6]) );
  DFFX1 B_REG_reg_5_ ( .D(B_REG_IN[5]), .CK(CLK), .Q(B_REG[5]), .QN(n697) );
  DFFHQX1 B_REG_reg_0_ ( .D(B_REG_IN[0]), .CK(CLK), .Q(B_REG[0]) );
  DFFTRX1 SP_reg_7_ ( .D(n272), .CK(CLK), .RN(n813), .Q(SP[7]), .QN(n710) );
  DFFTRX1 SP_reg_5_ ( .D(n2780), .CK(CLK), .RN(n813), .Q(SP[5]), .QN(n709) );
  DFFTRX1 SP_reg_3_ ( .D(n282), .CK(CLK), .RN(n814), .Q(SP[3]), .QN(n708) );
  DFFX1 MAR_reg_3_ ( .D(MAR_IN[3]), .CK(CLK), .Q(MAR[3]), .QN(n805) );
  OAI21X2 I873 ( .A0(n349), .A1(n1437), .B0(n1438), .Y(n1436) );
  AND4X2 I874 ( .A(n766), .B(n1380), .C(n1381), .D(n1382), .Y(n712) );
  DFFHQX2 TMP1_reg_0_ ( .D(TMP1_IN_0_), .CK(CLK), .Q(TMP1[0]) );
  INVX2 I875 ( .A(n767), .Y(n871) );
  AND3X2 I876 ( .A(n1477), .B(n1478), .C(n1479), .Y(n767) );
  OR2X2 I877 ( .A(n1127), .B(MAR_MDR_EN), .Y(n715) );
  OR2X2 I878 ( .A(T2_A_EN), .B(T2_XCHD_A_EN), .Y(n716) );
  AND2X2 I879 ( .A(n946), .B(n1503), .Y(n717) );
  AND2X2 I880 ( .A(n757), .B(n752), .Y(n718) );
  INVX2 I881 ( .A(n1514), .Y(n1513) );
  DFFTRX1 SP_reg_6_ ( .D(n276), .CK(CLK), .RN(n814), .Q(SP[6]), .QN(n719) );
  DFFX1 PSW_reg_4_ ( .D(PSW_IN_4_), .CK(CLK), .Q(PSW_4_), .QN(n720) );
  BUFX3 I882 ( .A(n1579), .Y(TMP2[3]) );
  AND4X2 I883 ( .A(n774), .B(n775), .C(n902), .D(n903), .Y(n721) );
  INVX1 I884 ( .A(ALU_SUB_EN), .Y(n1533) );
  INVX1 I885 ( .A(ALU_ADC_EN), .Y(n348) );
  AND2X2 I886 ( .A(n1531), .B(ALU_ADD_EN), .Y(n762) );
  INVX2 I887 ( .A(n762), .Y(n1495) );
  OR2X2 I888 ( .A(n783), .B(n912), .Y(n722) );
  INVX1 I889 ( .A(ALU_ANL_EN), .Y(n1510) );
  AND2X2 I890 ( .A(n1340), .B(n1342), .Y(n724) );
  DFFTRX1 TMP1_reg_5_ ( .D(n201), .CK(CLK), .RN(n812), .Q(n1570), .QN(n725) );
  BUFX4 I891 ( .A(n1571), .Y(TMP1[4]) );
  DFFTRX1 TMP1_reg_4_ ( .D(n214), .CK(CLK), .RN(n814), .Q(n1571), .QN(n2180)
         );
  NOR2X1 I892 ( .A(n811), .B(n544), .Y(n726) );
  NOR2X1 I893 ( .A(n811), .B(n488), .Y(n727) );
  DFFTRX1 TMP1_reg_6_ ( .D(n185), .CK(CLK), .RN(n812), .Q(n1569), .QN(n729) );
  NAND2X2 I894 ( .A(n1351), .B(n816), .Y(n1327) );
  MX2X1 I895 ( .S0(n334), .B(IDATA[2]), .A(n904), .Y(n732) );
  MX2X1 I896 ( .S0(n334), .B(IDATA[6]), .A(n915), .Y(n733) );
  DFFX1 MAR_reg_2_ ( .D(MAR_IN[2]), .CK(CLK), .Q(MAR[2]), .QN(n735) );
  DFFTRX1 TMP2_reg_7_ ( .D(n83), .CK(CLK), .RN(n812), .Q(n1575), .QN(n736) );
  AND3X2 I897 ( .A(n1449), .B(n1450), .C(n1451), .Y(n768) );
  OR2X2 I898 ( .A(n246), .B(n1498), .Y(n737) );
  INVX1 I899 ( .A(n791), .Y(n1501) );
  DFFTRX2 PSW_reg_7_ ( .D(n2940), .CK(CLK), .RN(n814), .Q(CY), .QN(n2600) );
  INVX1 I900 ( .A(T1_MDR_EN), .Y(n1530) );
  AND2X2 I901 ( .A(n753), .B(n718), .Y(n738) );
  AND2X2 I902 ( .A(n754), .B(n717), .Y(n739) );
  DFFX1 ACC_reg_7_ ( .D(n727), .CK(CLK), .Q(ACC[7]), .QN(n99) );
  INVX1 I903 ( .A(n675), .Y(n189) );
  NAND3X1 I904 ( .A(n913), .B(n914), .C(CY_AC_OV_UP), .Y(n361) );
  DFFTRX1 PSW_reg_6_ ( .D(n733), .CK(CLK), .RN(n813), .Q(PSW_6_), .QN(n740) );
  DFFTRX1 SP_reg_4_ ( .D(n280), .CK(CLK), .RN(n813), .Q(SP[4]), .QN(n125) );
  INVX2 I905 ( .A(n1513), .Y(n459) );
  DFFX1 ACC_reg_3_ ( .D(n777), .CK(CLK), .Q(ACC[3]), .QN(n741) );
  DFFX1 PSW_reg_3_ ( .D(PSW_IN_3_), .CK(CLK), .Q(PSW_3_), .QN(n743) );
  DFFX2 ACC_reg_5_ ( .D(n726), .CK(CLK), .Q(ACC[5]), .QN(n118) );
  DFFTRX1 TMP2_reg_3_ ( .D(n129), .CK(CLK), .RN(n815), .Q(n1579), .QN(n744) );
  DFFTRX1 TMP1_reg_3_ ( .D(n225), .CK(CLK), .RN(n812), .Q(n1572), .QN(n745) );
  BUFX3 I906 ( .A(n1580), .Y(TMP2[2]) );
  DFFTRX1 TMP2_reg_2_ ( .D(n142), .CK(CLK), .RN(n817), .Q(n1580), .QN(n746) );
  AND2X2 I907 ( .A(n1529), .B(n1574), .Y(n747) );
  DFFTRX1 TMP1_reg_2_ ( .D(n233), .CK(CLK), .RN(n814), .Q(n1573), .QN(n2370)
         );
  DFFTRX1 TMP2_reg_1_ ( .D(n150), .CK(CLK), .RN(n812), .Q(n1581), .QN(n748) );
  DFFTRX1 TMP2_reg_0_ ( .D(n160), .CK(CLK), .RN(n817), .Q(n1582), .QN(n749) );
  DFFHQX1 SP_reg_2_ ( .D(SP_IN_2_), .CK(CLK), .Q(SP[2]) );
  DFFHQX1 SP_reg_0_ ( .D(SP_IN_0_), .CK(CLK), .Q(SP[0]) );
  NAND2BX2 I908 ( .AN(n811), .B(B_T2RES_EN), .Y(n483) );
  NAND2X2 I909 ( .A(N237), .B(n1419), .Y(n763) );
  NAND2X4 I910 ( .A(n751), .B(n731), .Y(n292) );
  MXI2X1 I911 ( .S0(n3160), .B(n714), .A(n721), .Y(n907) );
  NOR2X2 I912 ( .A(n811), .B(n629), .Y(n764) );
  INVX1 I913 ( .A(B_T1_EN), .Y(n752) );
  INVX1 I914 ( .A(B_T2RES_EN), .Y(n753) );
  INVX2 I915 ( .A(n757), .Y(n758) );
  NOR2X4 I916 ( .A(T1_GT_T2), .B(n483), .Y(n795) );
  NAND4X1 I917 ( .A(n850), .B(n851), .C(n852), .D(n853), .Y(n849) );
  NAND3X2 I918 ( .A(n765), .B(n1080), .C(n1081), .Y(n314) );
  MXI2X2 I919 ( .S0(n1529), .B(n1389), .A(ALU_CPL_EN), .Y(n1165) );
  DFFHQX2 ACC_reg_4_ ( .D(n779), .CK(CLK), .Q(ACC[4]) );
  NOR2X2 I920 ( .A(n811), .B(n562), .Y(n779) );
  AOI21X1 I921 ( .A0(n1154), .A1(n761), .B0(n1155), .Y(n1150) );
  INVX1 I922 ( .A(SP_T1_EN), .Y(n754) );
  NOR2X2 I923 ( .A(n292), .B(n2930), .Y(n796) );
  OR4X2 I924 ( .A(T2_P0R_EN), .B(T2_A_EN), .C(n169), .D(n170), .Y(n755) );
  INVX2 I925 ( .A(n755), .Y(n756) );
  OR3X2 I926 ( .A(n2930), .B(n425), .C(n482), .Y(n757) );
  BUFX2 I927 ( .A(n1495), .Y(n759) );
  BUFX3 I928 ( .A(n1574), .Y(TMP1[1]) );
  NAND2X1 I929 ( .A(n1388), .B(ALU_ADD_EN), .Y(n1153) );
  BUFX3 I930 ( .A(n1582), .Y(TMP2[0]) );
  AND2X1 I931 ( .A(n974), .B(IDATA[0]), .Y(n793) );
  INVX1 I932 ( .A(TMP1[0]), .Y(n1514) );
  NOR3BX4 I933 ( .AN(n1442), .B(n1435), .C(n1436), .Y(n1434) );
  AND2X1 I934 ( .A(n1447), .B(n1510), .Y(n783) );
  NOR2X1 I935 ( .A(n712), .B(n1163), .Y(n1162) );
  BUFX3 I936 ( .A(n838), .Y(n1506) );
  NOR2X1 I937 ( .A(ALU_RR_EN), .B(ALU_RRC_EN), .Y(n787) );
  BUFX3 I938 ( .A(n787), .Y(n782) );
  INVX1 I939 ( .A(T1_GT_T2), .Y(n303) );
  NAND2X2 I940 ( .A(PERI_SFR_sel), .B(n1183), .Y(n772) );
  INVX1 I941 ( .A(n1523), .Y(n1384) );
  BUFX4 I942 ( .A(n1578), .Y(TMP2[4]) );
  BUFX4 I943 ( .A(n1576), .Y(TMP2[6]) );
  BUFX4 I944 ( .A(n1577), .Y(TMP2[5]) );
  AND4X1 I945 ( .A(n805), .B(n735), .C(MAR[8]), .D(MAR[7]), .Y(n776) );
  OR2X1 I946 ( .A(n805), .B(n711), .Y(n894) );
  INVX1 I947 ( .A(n191), .Y(n989) );
  INVX1 I948 ( .A(T1_B_EN), .Y(n191) );
  BUFX3 I949 ( .A(DIV_OP_EN), .Y(n1524) );
  INVX1 I950 ( .A(T1_RES_EN), .Y(n2670) );
  INVX1 I951 ( .A(ALU_BITC_EN), .Y(n1447) );
  INVX1 I952 ( .A(A_MRR_EN), .Y(n1522) );
  INVX1 I953 ( .A(MAR_SP_EN), .Y(n411) );
  NAND2X1 I954 ( .A(n1530), .B(n192), .Y(n974) );
  INVX1 I955 ( .A(SP_RES_EN), .Y(n1503) );
  BUFX2 I956 ( .A(n1391), .Y(n1511) );
  INVX2 I957 ( .A(ALU_SUBBC_EN), .Y(n349) );
  INVX1 I958 ( .A(ALU_RL_EN), .Y(n1087) );
  BUFX1 I959 ( .A(T1_MDR_EN), .Y(n1534) );
  BUFX3 I960 ( .A(WA_EN), .Y(n1497) );
  INVX1 I961 ( .A(MAR_MDR_EN), .Y(n410) );
  INVX1 I962 ( .A(MAR_T1_EN), .Y(n412) );
  OR2X1 I963 ( .A(C_ALLZ_B_OR_EN), .B(n331), .Y(n3210) );
  NAND2BX1 I964 ( .AN(n331), .B(C_ALLZ_B_OR_EN), .Y(n332) );
  OR2X1 I965 ( .A(ALU_ADD_EN), .B(n1532), .Y(n921) );
  INVX1 I966 ( .A(T2_RES_EN), .Y(n836) );
  NOR2X1 I967 ( .A(n782), .B(n922), .Y(n1422) );
  AOI21X1 I968 ( .A0(n1069), .A1(n1063), .B0(n1423), .Y(n1421) );
  BUFX3 I969 ( .A(ALU_XRL_EN), .Y(n1509) );
  NOR2X1 I970 ( .A(n1511), .B(n923), .Y(n1420) );
  INVX1 I971 ( .A(n1361), .Y(n1391) );
  AND4X2 I972 ( .A(n1089), .B(n1090), .C(n1091), .D(n1092), .Y(n765) );
  INVX1 I973 ( .A(n1163), .Y(n1152) );
  NAND4X1 I974 ( .A(n766), .B(n1380), .C(n1381), .D(n1382), .Y(n1313) );
  AND3X2 I975 ( .A(n1385), .B(n1386), .C(n1387), .Y(n766) );
  NAND3X1 I976 ( .A(N235), .B(n967), .C(ALU_ADD_EN), .Y(n1357) );
  NAND3X1 I977 ( .A(n1531), .B(N262), .C(ALU_ADD_EN), .Y(n1356) );
  INVX1 I978 ( .A(n1514), .Y(n1544) );
  BUFX3 I979 ( .A(n819), .Y(IDATA[2]) );
  INVX1 I980 ( .A(n1540), .Y(N273) );
  BUFX3 I981 ( .A(n822), .Y(IDATA[7]) );
  INVX1 I982 ( .A(TMP1[3]), .Y(N274) );
  NOR2X1 I983 ( .A(n1333), .B(n482), .Y(n1161) );
  BUFX3 I984 ( .A(n820), .Y(IDATA[5]) );
  BUFX3 I985 ( .A(n821), .Y(IDATA[6]) );
  INVX1 I986 ( .A(n1517), .Y(n1516) );
  INVX1 I987 ( .A(n1519), .Y(n1518) );
  INVX1 I988 ( .A(TMP1[7]), .Y(N278) );
  AOI21X1 I989 ( .A0(n307), .A1(n773), .B0(n938), .Y(n937) );
  AND2X2 I990 ( .A(n305), .B(n306), .Y(n773) );
  INVX1 I991 ( .A(MAR[0]), .Y(n888) );
  NAND2X1 I992 ( .A(n1540), .B(n1384), .Y(n1069) );
  INVX2 I993 ( .A(n1529), .Y(n1325) );
  NAND2X1 I994 ( .A(TMP1[1]), .B(n1325), .Y(n1064) );
  INVX2 I995 ( .A(n1525), .Y(n922) );
  INVX2 I996 ( .A(TMP2[5]), .Y(n1060) );
  INVX2 I997 ( .A(TMP2[4]), .Y(n1050) );
  NAND2X1 I998 ( .A(n1494), .B(n1531), .Y(n845) );
  INVX1 I999 ( .A(ACC[0]), .Y(n842) );
  INVX1 I1000 ( .A(n181), .Y(n990) );
  AOI21X1 I1001 ( .A0(n1086), .A1(n1087), .B0(n1088), .Y(n1084) );
  AND2X1 I1002 ( .A(ALU_RLC_EN), .B(TMP2[7]), .Y(n801) );
  NOR2X1 I1003 ( .A(n410), .B(n1139), .Y(n1138) );
  INVX1 I1004 ( .A(n99), .Y(n832) );
  INVX1 I1005 ( .A(n741), .Y(n858) );
  NOR2X1 I1006 ( .A(n1574), .B(n1513), .Y(n774) );
  NOR2X1 I1007 ( .A(TMP1[3]), .B(n1540), .Y(n775) );
  AOI21X1 I1008 ( .A0(n1563), .A1(n1562), .B0(n1561), .Y(n1565) );
  AOI21X1 I1009 ( .A0(n926), .A1(n1544), .B0(n747), .Y(n924) );
  NOR2X1 I1010 ( .A(n1554), .B(n1553), .Y(n1557) );
  NOR2X1 I1011 ( .A(TMP1[7]), .B(n1569), .Y(n903) );
  NOR2X1 I1012 ( .A(TMP1[3]), .B(n744), .Y(n1566) );
  NOR2BX1 I1013 ( .AN(n1529), .B(TMP1[1]), .Y(n1068) );
  NOR2X1 I1014 ( .A(n1574), .B(n748), .Y(n1062) );
  OAI21X1 I1015 ( .A0(n1174), .A1(n1175), .B0(n1176), .Y(n1172) );
  BUFX8 I1016 ( .A(n1572), .Y(TMP1[3]) );
  BUFX3 I1017 ( .A(n1573), .Y(TMP1[2]) );
  BUFX4 I1018 ( .A(n1570), .Y(TMP1[5]) );
  BUFX3 I1019 ( .A(n1567), .Y(ACC[0]) );
  BUFX3 I1020 ( .A(n1569), .Y(TMP1[6]) );
  OAI21X1 I1021 ( .A0(n1174), .A1(n1221), .B0(n1222), .Y(n1219) );
  OAI21X1 I1022 ( .A0(n1174), .A1(n1262), .B0(n1263), .Y(n1260) );
  OAI21X1 I1023 ( .A0(n1174), .A1(n1283), .B0(n1284), .Y(n1281) );
  NAND2X1 I1024 ( .A(n671), .B(n1328), .Y(n1157) );
  BUFX3 I1025 ( .A(n1568), .Y(TMP1[7]) );
  BUFX8 I1026 ( .A(n1575), .Y(TMP2[7]) );
  INVX1 I1027 ( .A(MAR[6]), .Y(n1137) );
  BUFX3 I1028 ( .A(ID_T2_EN), .Y(n1515) );
  NOR2X1 I1029 ( .A(n811), .B(n578), .Y(n777) );
  NOR2X1 I1030 ( .A(n811), .B(n524), .Y(n778) );
  AOI22X1 I1031 ( .A0(ACC[6]), .A1(n1524), .B0(P0_IN[7]), .B1(n1520), .Y(n877)
         );
  OAI21X1 I1032 ( .A0(n1330), .A1(n1373), .B0(n888), .Y(n1370) );
  BUFX3 I1033 ( .A(n1568), .Y(n1528) );
  INVX1 I1034 ( .A(MAR[4]), .Y(n425) );
  NAND4X1 I1035 ( .A(n1097), .B(n1098), .C(n1099), .D(n1100), .Y(n1096) );
  NAND3X1 I1036 ( .A(n813), .B(PC[0]), .C(n1518), .Y(n1347) );
  BUFX3 I1037 ( .A(n1580), .Y(n1523) );
  NAND3X1 I1038 ( .A(n814), .B(PC[8]), .C(ID_PCH_EN), .Y(n1346) );
  BUFX2 I1039 ( .A(n1582), .Y(n1526) );
  BUFX3 I1040 ( .A(n1581), .Y(n1529) );
  MXI2X1 I1041 ( .S0(C_ALLZ_AND_EN), .B(n781), .A(n780), .Y(n932) );
  NOR2X1 I1042 ( .A(ALLZ), .B(n935), .Y(n780) );
  NOR2X1 I1043 ( .A(n2600), .B(n934), .Y(n781) );
  BUFX3 I1044 ( .A(ACC[1]), .Y(n1494) );
  BUFX3 I1045 ( .A(n1579), .Y(n1525) );
  NAND2X1 I1046 ( .A(ACC[4]), .B(n1524), .Y(n867) );
  NAND2X1 I1047 ( .A(ACC[2]), .B(n1524), .Y(n859) );
  NAND2X1 I1048 ( .A(n1531), .B(ACC[6]), .Y(n869) );
  NAND2X1 I1049 ( .A(ACC[4]), .B(n1531), .Y(n861) );
  AOI32X1 I1050 ( .A0(n311), .A1(n313), .A2(n314), .B0(C_CB_EN), .B1(n2600), 
        .Y(n312) );
  OAI22X1 I1051 ( .A0(n1508), .A1(n2600), .B0(n292), .B1(n710), .Y(n1192) );
  AOI22X1 I1052 ( .A0(B_REG[7]), .A1(n989), .B0(P0R[7]), .B1(n675), .Y(n1079)
         );
  OAI21X1 I1053 ( .A0(n990), .A1(n199), .B0(n1003), .Y(n999) );
  OAI21X1 I1054 ( .A0(n189), .A1(n1001), .B0(n1002), .Y(n1000) );
  OAI2BB1X1 I1055 ( .A0N(T1_BITCP_EN), .A1N(n2600), .B0(n2610), .Y(n178) );
  OAI2BB1X1 I1056 ( .A0N(MAR_BAR_EN), .A1N(P0R[7]), .B0(n439), .Y(n418) );
  OAI22X1 I1057 ( .A0(n1507), .A1(n742), .B0(n292), .B1(n709), .Y(n1233) );
  OAI22X1 I1058 ( .A0(n1193), .A1(n743), .B0(n292), .B1(n708), .Y(n1274) );
  INVX1 I1059 ( .A(MDR[6]), .Y(n1139) );
  INVX1 I1060 ( .A(P0R[0]), .Y(n271) );
  INVX1 I1061 ( .A(MDR[4]), .Y(n431) );
  INVX1 I1062 ( .A(P0R[5]), .Y(n117) );
  INVX1 I1063 ( .A(n1524), .Y(n167) );
  INVX2 I1064 ( .A(n2670), .Y(n968) );
  INVX4 I1065 ( .A(n1448), .Y(n1383) );
  INVX1 I1066 ( .A(T2_MDR_EN), .Y(n1014) );
  INVX4 I1067 ( .A(n816), .Y(n810) );
  INVX4 I1068 ( .A(n816), .Y(n811) );
  INVX1 I1069 ( .A(n1522), .Y(n1521) );
  INVX1 I1070 ( .A(n1522), .Y(n1520) );
  NAND2X1 I1071 ( .A(n1499), .B(n1513), .Y(n844) );
  INVX1 I1072 ( .A(n974), .Y(n969) );
  INVX1 I1073 ( .A(n1503), .Y(n1502) );
  INVX1 I1074 ( .A(n411), .Y(n1129) );
  INVX2 I1075 ( .A(n349), .Y(n1093) );
  INVX1 I1076 ( .A(n1082), .Y(n1419) );
  INVX1 I1077 ( .A(n632), .Y(n490) );
  MXI2X1 I1078 ( .S0(ALLZ), .B(n786), .A(n329), .Y(n936) );
  INVX4 I1079 ( .A(n1327), .Y(n1183) );
  NAND2X1 I1080 ( .A(n1531), .B(n1501), .Y(n879) );
  AND2X2 I1081 ( .A(n1497), .B(n1500), .Y(n784) );
  INVX1 I1082 ( .A(RESET), .Y(n813) );
  INVX1 I1083 ( .A(n810), .Y(n814) );
  INVX1 I1084 ( .A(RESET), .Y(n815) );
  INVX2 I1085 ( .A(RESET), .Y(n816) );
  INVX1 I1086 ( .A(n711), .Y(n892) );
  NOR2X1 I1087 ( .A(n786), .B(n329), .Y(n940) );
  NAND2X1 I1088 ( .A(n1500), .B(n968), .Y(n1100) );
  NOR3X1 I1089 ( .A(n1531), .B(T1_BITCP_EN), .C(T1_0_EN), .Y(n1101) );
  BUFX3 I1090 ( .A(A_T1_EN), .Y(n1499) );
  OR2X2 I1091 ( .A(T2_REM2_EN), .B(n785), .Y(n91) );
  AND2X2 I1092 ( .A(n1524), .B(T1_GT_T2), .Y(n785) );
  AND2X2 I1093 ( .A(n2630), .B(n2620), .Y(n1102) );
  INVX1 I1094 ( .A(CY_AC_OV_SUB_UP), .Y(n344) );
  INVX1 I1095 ( .A(n3210), .Y(n305) );
  NOR2X1 I1096 ( .A(n3210), .B(n306), .Y(n786) );
  INVX1 I1097 ( .A(n788), .Y(n1127) );
  EDFFTRX1 F5_reg ( .D(ALLZ), .CK(CLK), .E(F5_ALLZ_EN), .RN(n813), .Q(F5) );
  INVX1 I1098 ( .A(n412), .Y(n1128) );
  INVX1 I1099 ( .A(T2_REM2_EN), .Y(n158) );
  INVX1 I1100 ( .A(CY0_DIV_OV_UP), .Y(n3150) );
  INVX1 I1101 ( .A(n810), .Y(n812) );
  INVX1 I1102 ( .A(n1533), .Y(n1532) );
  INVX2 I1103 ( .A(n790), .Y(n1504) );
  INVX1 I1104 ( .A(n857), .Y(n966) );
  NAND2X1 I1105 ( .A(n1497), .B(n857), .Y(n856) );
  NAND2X1 I1106 ( .A(n1497), .B(n1505), .Y(n862) );
  DFFHQX1 ACC_reg_0_ ( .D(n764), .CK(CLK), .Q(n1567) );
  INVX1 I1107 ( .A(n459), .Y(n1543) );
  OR3X1 I1108 ( .A(T2_SP_EN), .B(T2_RES_EN), .C(T2_REM2_EN), .Y(n169) );
  INVX1 I1109 ( .A(n791), .Y(n1500) );
  NAND2X1 I1110 ( .A(n1497), .B(n1512), .Y(n878) );
  OR3X2 I1111 ( .A(MAR_T1_EN), .B(MAR_SP_EN), .C(MAR_RES_EN), .Y(n462) );
  NAND2X2 I1112 ( .A(n303), .B(n1524), .Y(n837) );
  INVX1 I1113 ( .A(T1_CBP_EN), .Y(n2610) );
  OR2X2 I1114 ( .A(MAR_RI_EN), .B(MAR_RN_EN), .Y(n429) );
  INVX2 I1115 ( .A(n1296), .Y(n1191) );
  AND3X2 I1116 ( .A(n306), .B(n313), .C(CY_AC_OV_SUB_UP), .Y(n3200) );
  NAND2X1 I1117 ( .A(MAR_RES_EN), .B(n857), .Y(n890) );
  INVX2 I1118 ( .A(T1_DAD_EN), .Y(n197) );
  NAND2X1 I1119 ( .A(MAR_RES_EN), .B(n1505), .Y(n895) );
  OR2X2 I1120 ( .A(CY_AC_OV_UP), .B(CY_UP), .Y(n311) );
  NOR2X1 I1121 ( .A(MAR_BAR_EN), .B(MAR_P0R_EN), .Y(n788) );
  NAND2X1 I1122 ( .A(n1512), .B(n968), .Y(n1073) );
  NAND2BX1 I1123 ( .AN(n837), .B(n1505), .Y(n1039) );
  INVX1 I1124 ( .A(n369), .Y(n368) );
  INVX1 I1125 ( .A(T1_1_EN), .Y(n2590) );
  OR2X2 I1126 ( .A(n303), .B(n483), .Y(n463) );
  INVX1 I1127 ( .A(C_ALLZ_OR_EN), .Y(n306) );
  INVX1 I1128 ( .A(CY0_MUL_OV_UP), .Y(n3160) );
  INVX1 I1129 ( .A(C_ALLZ_B_AND_EN), .Y(n327) );
  INVX1 I1130 ( .A(n796), .Y(n946) );
  OAI22X2 I1131 ( .A0(n782), .A1(n1050), .B0(n1383), .B1(n1384), .Y(n1459) );
  OAI22X2 I1132 ( .A0(n782), .A1(n736), .B0(n1383), .B1(n1060), .Y(n1401) );
  OAI22X2 I1133 ( .A0(n782), .A1(n1060), .B0(n1383), .B1(n922), .Y(n1471) );
  AND3X4 I1134 ( .A(n767), .B(n1431), .C(n909), .Y(n789) );
  NAND2BX1 I1135 ( .AN(n728), .B(n1448), .Y(n1445) );
  OAI2BB1X1 I1136 ( .A0N(n736), .A1N(N278), .B0(n1361), .Y(n1446) );
  AOI21X1 I1137 ( .A0(n1362), .A1(n1511), .B0(n459), .Y(n1407) );
  AOI21X1 I1138 ( .A0(n1511), .A1(n1460), .B0(N274), .Y(n1458) );
  NAND2X1 I1139 ( .A(n1509), .B(n922), .Y(n1460) );
  AOI21X1 I1140 ( .A0(n1511), .A1(n1402), .B0(n729), .Y(n1400) );
  NAND2X1 I1141 ( .A(n1509), .B(n728), .Y(n1402) );
  AOI21X1 I1142 ( .A0(n1511), .A1(n1488), .B0(n725), .Y(n1486) );
  NAND2X1 I1143 ( .A(n1509), .B(n1060), .Y(n1488) );
  AOI21X1 I1144 ( .A0(n1511), .A1(n1472), .B0(n2180), .Y(n1470) );
  NAND2X1 I1145 ( .A(n1509), .B(n1050), .Y(n1472) );
  NOR2X1 I1146 ( .A(n782), .B(n1325), .Y(n1412) );
  NAND2X1 I1147 ( .A(N295), .B(n1532), .Y(n1382) );
  NAND2X1 I1148 ( .A(N260), .B(ALU_ADC_EN), .Y(n1441) );
  NAND2X1 I1149 ( .A(N296), .B(n1532), .Y(n1429) );
  NAND2X1 I1150 ( .A(N301), .B(ALU_SUB_EN), .Y(n1442) );
  NAND2X1 I1151 ( .A(N297), .B(n1532), .Y(n1464) );
  NAND2X1 I1152 ( .A(N300), .B(ALU_SUB_EN), .Y(n1406) );
  NAND2X1 I1153 ( .A(N299), .B(ALU_SUB_EN), .Y(n1493) );
  NAND2X1 I1154 ( .A(N298), .B(ALU_SUB_EN), .Y(n1476) );
  NAND2X1 I1155 ( .A(N254), .B(ALU_ADC_EN), .Y(n1387) );
  NAND2X1 I1156 ( .A(N317), .B(n1093), .Y(n1425) );
  NAND2BX1 I1157 ( .AN(n1064), .B(n1509), .Y(n1385) );
  INVX1 I1158 ( .A(N255), .Y(n1427) );
  NAND2X1 I1159 ( .A(n1351), .B(n1297), .Y(n1288) );
  NAND3BX1 I1160 ( .AN(n1294), .B(n1295), .C(n1296), .Y(n1290) );
  DFFHQX1 B_REG_reg_2_ ( .D(B_REG_IN[2]), .CK(CLK), .Q(B_REG[2]) );
  DFFHQX1 B_REG_reg_1_ ( .D(B_REG_IN[1]), .CK(CLK), .Q(B_REG[1]) );
  NOR2X1 I1161 ( .A(n966), .B(n1496), .Y(n1282) );
  NOR2BX1 I1162 ( .AN(n1506), .B(n1496), .Y(n1200) );
  NOR2X1 I1163 ( .A(n767), .B(n1496), .Y(n1220) );
  NOR2X1 I1164 ( .A(n768), .B(n1496), .Y(n1261) );
  NAND2X1 I1165 ( .A(n1497), .B(n871), .Y(n870) );
  NAND2X1 I1166 ( .A(n1497), .B(n1506), .Y(n874) );
  OR4X1 I1167 ( .A(WA_EN), .B(A_T1_EN), .C(A_MRR_EN), .D(n489), .Y(n402) );
  AND2X2 I1168 ( .A(n489), .B(IDATA[7]), .Y(n792) );
  INVX1 I1169 ( .A(N240), .Y(n1482) );
  NOR2X1 I1170 ( .A(n1084), .B(n1085), .Y(n1080) );
  NOR2X1 I1171 ( .A(CY_AC_OV_UP), .B(n905), .Y(n904) );
  MXI2X1 I1172 ( .S0(n344), .B(n907), .A(n906), .Y(n905) );
  INVX1 I1173 ( .A(IDATA[4]), .Y(n945) );
  NOR2X1 I1174 ( .A(n842), .B(n632), .Y(n841) );
  NOR2X1 I1175 ( .A(n810), .B(n1070), .Y(TMP1_IN_7_) );
  AOI21X1 I1176 ( .A0(IDATA[7]), .A1(n1534), .B0(n1071), .Y(n1070) );
  NAND3X1 I1177 ( .A(n1072), .B(n1073), .C(n1074), .Y(n1071) );
  INVX1 I1178 ( .A(N243), .Y(n1083) );
  DFFHQX1 B_REG_reg_3_ ( .D(B_REG_IN[3]), .CK(CLK), .Q(B_REG[3]) );
  DFFX1 B_REG_reg_4_ ( .D(B_REG_IN[4]), .CK(CLK), .Q(B_REG[4]) );
  INVX1 I1179 ( .A(IDATA[7]), .Y(n824) );
  INVX1 I1180 ( .A(n1508), .Y(n1120) );
  NAND2X1 I1181 ( .A(n796), .B(IDATA[5]), .Y(n953) );
  NAND2X1 I1182 ( .A(n796), .B(IDATA[3]), .Y(n944) );
  NAND2X1 I1183 ( .A(n796), .B(IDATA[6]), .Y(n957) );
  NAND2X1 I1184 ( .A(n796), .B(IDATA[2]), .Y(n1106) );
  NAND2X1 I1185 ( .A(n974), .B(IDATA[2]), .Y(n973) );
  NAND2X1 I1186 ( .A(n489), .B(IDATA[0]), .Y(n839) );
  DFFTRX1 TMP2_reg_6_ ( .D(n101), .CK(CLK), .RN(n815), .Q(n1576), .QN(n728) );
  DFFTRX1 TMP2_reg_5_ ( .D(n110), .CK(CLK), .RN(n814), .Q(n1577), .QN(n689) );
  DFFTRX1 TMP2_reg_4_ ( .D(n119), .CK(CLK), .RN(n814), .Q(n1578), .QN(n703) );
  NOR4BX2 I1187 ( .AN(n839), .B(n840), .C(n784), .D(n841), .Y(n629) );
  NAND4X1 I1188 ( .A(n843), .B(n844), .C(n845), .D(n837), .Y(n840) );
  NAND2X1 I1189 ( .A(n1497), .B(n866), .Y(n865) );
  NAND2X1 I1190 ( .A(N302), .B(ALU_SUB_EN), .Y(n1092) );
  INVX1 I1191 ( .A(N238), .Y(n1454) );
  INVX1 I1192 ( .A(RESET), .Y(n817) );
  NAND4X1 I1193 ( .A(n919), .B(n920), .C(n347), .D(n921), .Y(n918) );
  NAND2X1 I1194 ( .A(N274), .B(n922), .Y(n920) );
  OAI21X1 I1195 ( .A0(n923), .A1(n924), .B0(n925), .Y(n919) );
  NAND2X1 I1196 ( .A(n871), .B(n968), .Y(n993) );
  NAND2BX1 I1197 ( .AN(n967), .B(n1506), .Y(n992) );
  INVX2 I1198 ( .A(n1295), .Y(n1188) );
  INVX2 I1199 ( .A(n1292), .Y(n1189) );
  NOR2X1 I1200 ( .A(n361), .B(n911), .Y(n908) );
  NAND2BX1 I1201 ( .AN(n837), .B(n871), .Y(n1059) );
  NAND2BX1 I1202 ( .AN(n837), .B(n866), .Y(n1049) );
  NAND2BX1 I1203 ( .AN(n836), .B(n866), .Y(n1038) );
  NAND2BX1 I1204 ( .AN(n837), .B(n1506), .Y(n834) );
  NAND2BX1 I1205 ( .AN(n836), .B(n1506), .Y(n1058) );
  NAND2X1 I1206 ( .A(N323), .B(n1093), .Y(n1091) );
  NAND2X1 I1207 ( .A(n823), .B(n1193), .Y(n1294) );
  NAND2X1 I1208 ( .A(N261), .B(ALU_ADC_EN), .Y(n1090) );
  NAND2X1 I1209 ( .A(n1189), .B(n832), .Y(n1186) );
  NAND2X1 I1210 ( .A(n1189), .B(n858), .Y(n1272) );
  OR2X2 I1211 ( .A(n334), .B(n335), .Y(n331) );
  INVX1 I1212 ( .A(n1317), .Y(n1351) );
  INVX1 I1213 ( .A(OV_T1Z_EN), .Y(n914) );
  NAND2X1 I1214 ( .A(SP_T1_EN), .B(n1544), .Y(n1114) );
  NAND2X1 I1215 ( .A(P0R[4]), .B(T2_P0R_EN), .Y(n1033) );
  NAND2X1 I1216 ( .A(n832), .B(T2_A_EN), .Y(n828) );
  INVX1 I1217 ( .A(C_CB_EN), .Y(n313) );
  INVX2 I1218 ( .A(n913), .Y(n334) );
  DFFTRX1 PSW_reg_2_ ( .D(n354), .CK(CLK), .RN(n815), .QN(n714) );
  NAND2X1 I1219 ( .A(n927), .B(n1513), .Y(n1067) );
  INVX1 I1220 ( .A(n1069), .Y(n1555) );
  NAND2X1 I1221 ( .A(n1064), .B(n1065), .Y(n1556) );
  NAND2X1 I1222 ( .A(n749), .B(n1513), .Y(n1065) );
  AND2X2 I1223 ( .A(n913), .B(n812), .Y(n797) );
  INVX1 I1224 ( .A(n1063), .Y(n1061) );
  NOR3BX1 I1225 ( .AN(n1515), .B(n1325), .C(n810), .Y(n1321) );
  NAND2X1 I1226 ( .A(n1535), .B(ALU_BITC_EN), .Y(n1489) );
  NAND4X1 I1227 ( .A(n1403), .B(n1404), .C(n1405), .D(n1406), .Y(n1399) );
  NAND2X1 I1228 ( .A(n1523), .B(ALU_SWAP_EN), .Y(n1403) );
  NAND2X1 I1229 ( .A(N259), .B(ALU_ADC_EN), .Y(n1405) );
  NAND2X1 I1230 ( .A(N321), .B(n1093), .Y(n1404) );
  NAND4X1 I1231 ( .A(n1490), .B(n1491), .C(n1492), .D(n1493), .Y(n1485) );
  NAND2X1 I1232 ( .A(n1529), .B(ALU_SWAP_EN), .Y(n1490) );
  NAND2X1 I1233 ( .A(N258), .B(ALU_ADC_EN), .Y(n1492) );
  NAND2X1 I1234 ( .A(N320), .B(n1093), .Y(n1491) );
  NAND4X1 I1235 ( .A(n1473), .B(n1474), .C(n1475), .D(n1476), .Y(n1469) );
  NAND2X1 I1236 ( .A(n1526), .B(ALU_SWAP_EN), .Y(n1473) );
  NAND2X1 I1237 ( .A(N257), .B(ALU_ADC_EN), .Y(n1475) );
  NAND2X1 I1238 ( .A(N319), .B(n1093), .Y(n1474) );
  NAND4X1 I1239 ( .A(n1461), .B(n1462), .C(n1463), .D(n1464), .Y(n1457) );
  NAND2X1 I1240 ( .A(ALU_SWAP_EN), .B(TMP2[7]), .Y(n1461) );
  NAND2X1 I1241 ( .A(N256), .B(ALU_ADC_EN), .Y(n1463) );
  NAND2X1 I1242 ( .A(N318), .B(n1093), .Y(n1462) );
  NOR2X1 I1243 ( .A(n1416), .B(n1417), .Y(n1408) );
  INVX1 I1244 ( .A(N242), .Y(n1443) );
  NAND2X1 I1245 ( .A(TMP2[4]), .B(ALU_SWAP_EN), .Y(n1418) );
  MXI2X1 I1246 ( .S0(TMP2[5]), .B(n1483), .A(ALU_CPL_EN), .Y(n1478) );
  NOR3X1 I1247 ( .A(n1485), .B(n1486), .C(n1487), .Y(n1477) );
  NAND3X1 I1248 ( .A(n1363), .B(n1183), .C(n723), .Y(n1359) );
  NAND3BX1 I1249 ( .AN(n1364), .B(n1365), .C(n1366), .Y(n1363) );
  NAND2X1 I1250 ( .A(n1370), .B(n1371), .Y(n1365) );
  OAI21X1 I1251 ( .A0(n1367), .A1(n1368), .B0(n1369), .Y(n1366) );
  MXI2X1 I1252 ( .S0(TMP2[4]), .B(n1467), .A(ALU_CPL_EN), .Y(n1466) );
  NOR3X1 I1253 ( .A(n1469), .B(n1470), .C(n1471), .Y(n1465) );
  NAND3X1 I1254 ( .A(n1393), .B(n1394), .C(n1395), .Y(n838) );
  MXI2X1 I1255 ( .S0(TMP2[6]), .B(n1397), .A(ALU_CPL_EN), .Y(n1394) );
  NOR3X1 I1256 ( .A(n1399), .B(n1400), .C(n1401), .Y(n1393) );
  NOR2X1 I1257 ( .A(n1160), .B(n1161), .Y(n1158) );
  NOR2X1 I1258 ( .A(n1452), .B(n1453), .Y(n1451) );
  NOR2X1 I1259 ( .A(n1082), .B(n1454), .Y(n1453) );
  NAND2X1 I1260 ( .A(PERI_SFR_DATA[0]), .B(n1350), .Y(n1349) );
  INVX1 I1261 ( .A(n772), .Y(n1350) );
  NOR2X1 I1262 ( .A(n783), .B(N273), .Y(n1430) );
  NAND2X1 I1263 ( .A(TMP2[6]), .B(ALU_SWAP_EN), .Y(n1428) );
  NAND2BX1 I1264 ( .AN(n1170), .B(n1171), .Y(n822) );
  OAI21X1 I1265 ( .A0(n772), .A1(n1180), .B0(n1181), .Y(n1170) );
  OAI21X1 I1266 ( .A0(n1172), .A1(n1173), .B0(n817), .Y(n1171) );
  NAND2X1 I1267 ( .A(ALU_RLC_EN), .B(n1535), .Y(n1413) );
  NAND2X1 I1268 ( .A(ALU_RL_EN), .B(TMP2[7]), .Y(n1414) );
  NAND2X1 I1269 ( .A(n1526), .B(ALU_RR_EN), .Y(n1439) );
  NOR2X1 I1270 ( .A(n1480), .B(n1481), .Y(n1479) );
  NOR2X1 I1271 ( .A(n1082), .B(n1482), .Y(n1481) );
  NAND2X1 I1272 ( .A(ALU_RRC_EN), .B(n1535), .Y(n1440) );
  NAND2X1 I1273 ( .A(n1456), .B(n1391), .Y(n1455) );
  MXI2X1 I1274 ( .S0(TMP1[3]), .B(n1392), .A(n1509), .Y(n1456) );
  NAND2X1 I1275 ( .A(n1398), .B(n1391), .Y(n1397) );
  MXI2X1 I1276 ( .S0(TMP1[6]), .B(n1392), .A(n1509), .Y(n1398) );
  NAND2X1 I1277 ( .A(n1484), .B(n1511), .Y(n1483) );
  MXI2X1 I1278 ( .S0(TMP1[5]), .B(n1392), .A(n1509), .Y(n1484) );
  NAND2X1 I1279 ( .A(n1468), .B(n1391), .Y(n1467) );
  MXI2X1 I1280 ( .S0(TMP1[4]), .B(n1392), .A(n1509), .Y(n1468) );
  MXI2X1 I1281 ( .S0(n1525), .B(n1455), .A(ALU_CPL_EN), .Y(n1450) );
  NOR3X1 I1282 ( .A(n1457), .B(n1458), .C(n1459), .Y(n1449) );
  NAND2X1 I1283 ( .A(ALU_SWAP_EN), .B(TMP2[5]), .Y(n1386) );
  NAND2X1 I1284 ( .A(N294), .B(n1532), .Y(n1411) );
  OAI21X1 I1285 ( .A0(n772), .A1(n1246), .B0(n1247), .Y(n1238) );
  INVX1 I1286 ( .A(PERI_SFR_DATA[4]), .Y(n1246) );
  OAI21X1 I1287 ( .A0(n1174), .A1(n1139), .B0(n1201), .Y(n1199) );
  NAND2X1 I1288 ( .A(n1203), .B(n1204), .Y(n1202) );
  NAND2X1 I1289 ( .A(n1244), .B(n1245), .Y(n1243) );
  AOI21X1 I1290 ( .A0(n1499), .A1(TMP1[7]), .B0(n880), .Y(n876) );
  NOR2X1 I1291 ( .A(n99), .B(n632), .Y(n880) );
  XOR3X2 I1292 ( .A(n726), .B(n779), .C(n399), .Y(n398) );
  XOR2X1 I1293 ( .A(n727), .B(n778), .Y(n399) );
  XOR3X2 I1294 ( .A(ACC_IN_1_), .B(n764), .C(n400), .Y(n397) );
  XOR2X1 I1295 ( .A(n401), .B(n777), .Y(n400) );
  NAND2BX1 I1296 ( .AN(n1217), .B(n1218), .Y(n820) );
  OAI21X1 I1297 ( .A0(n772), .A1(n1226), .B0(n1227), .Y(n1217) );
  OAI21X1 I1298 ( .A0(n1219), .A1(n1220), .B0(n815), .Y(n1218) );
  OAI21X1 I1299 ( .A0(n1260), .A1(n1261), .B0(n813), .Y(n1259) );
  OAI21X1 I1300 ( .A0(n1199), .A1(n1200), .B0(n815), .Y(n1198) );
  NAND2BX1 I1301 ( .AN(n1279), .B(n1280), .Y(n819) );
  OAI21X1 I1302 ( .A0(n1281), .A1(n1282), .B0(n816), .Y(n1280) );
  NAND2X1 I1303 ( .A(n1525), .B(ALU_SWAP_EN), .Y(n1438) );
  NAND2X1 I1304 ( .A(n1494), .B(n490), .Y(n853) );
  INVX1 I1305 ( .A(PERI_SFR_sel), .Y(n1297) );
  INVX1 I1306 ( .A(PERI_SFR_DATA[7]), .Y(n1180) );
  NOR2X1 I1307 ( .A(n875), .B(n792), .Y(n488) );
  NAND4X1 I1308 ( .A(n876), .B(n877), .C(n878), .D(n879), .Y(n875) );
  INVX1 I1309 ( .A(n611), .Y(ACC_IN_1_) );
  NAND2BX1 I1310 ( .AN(n811), .B(n846), .Y(n611) );
  OAI2BB1X1 I1311 ( .A0N(n489), .A1N(n847), .B0(n848), .Y(n846) );
  AOI21X1 I1312 ( .A0(n1497), .A1(n1504), .B0(n849), .Y(n848) );
  NAND4X2 I1313 ( .A(n1310), .B(n1311), .C(n1164), .D(n1312), .Y(n847) );
  INVX1 I1314 ( .A(n1155), .Y(n1311) );
  OAI21X2 I1315 ( .A0(n1313), .A1(n1314), .B0(n1152), .Y(n1312) );
  NAND2X2 I1316 ( .A(n671), .B(n425), .Y(n1292) );
  MXI2X1 I1317 ( .S0(n1528), .B(n369), .A(n734), .Y(n906) );
  NAND3X1 I1318 ( .A(n1494), .B(n425), .C(n1183), .Y(n1333) );
  OR2X2 I1319 ( .A(n670), .B(A_IDATA_EN), .Y(n489) );
  AND3X2 I1320 ( .A(ID_WR_EN), .B(n425), .C(n671), .Y(n670) );
  NAND2X2 I1321 ( .A(n1375), .B(n730), .Y(n1507) );
  OR2X2 I1322 ( .A(WM_EN), .B(n1515), .Y(n800) );
  AOI22X1 I1323 ( .A0(P0_IN[4]), .A1(n1521), .B0(ACC[5]), .B1(n1531), .Y(n863)
         );
  AOI22X1 I1324 ( .A0(P0_IN[6]), .A1(n1521), .B0(ACC[5]), .B1(n1524), .Y(n872)
         );
  AOI22X1 I1325 ( .A0(n1499), .A1(n1540), .B0(n1531), .B1(n858), .Y(n855) );
  AOI22X1 I1326 ( .A0(n1499), .A1(TMP1[6]), .B0(n1531), .B1(n832), .Y(n873) );
  AOI22X1 I1327 ( .A0(n1499), .A1(TMP1[4]), .B0(n1524), .B1(n858), .Y(n864) );
  OAI21X1 I1328 ( .A0(n482), .A1(n842), .B0(n1368), .Y(n1369) );
  NAND3X1 I1329 ( .A(n1515), .B(n815), .C(TMP2[0]), .Y(n1348) );
  NAND4X1 I1330 ( .A(n970), .B(n971), .C(n972), .D(n973), .Y(n233) );
  NAND2X1 I1331 ( .A(n857), .B(n968), .Y(n971) );
  NOR2BX1 I1332 ( .AN(N270), .B(n759), .Y(n1085) );
  NAND2X1 I1333 ( .A(n1292), .B(n1293), .Y(n1320) );
  NAND2X1 I1334 ( .A(n1292), .B(n1293), .Y(n1353) );
  OAI21X1 I1335 ( .A0(n810), .A1(n1194), .B0(n1195), .Y(B_REG_IN[6]) );
  AOI21X1 I1336 ( .A0(n758), .A1(IDATA[6]), .B0(n1196), .Y(n1194) );
  OAI21X1 I1337 ( .A0(n810), .A1(n1213), .B0(n1214), .Y(B_REG_IN[5]) );
  AOI21X1 I1338 ( .A0(n758), .A1(IDATA[5]), .B0(n1215), .Y(n1213) );
  OAI21X1 I1339 ( .A0(n824), .A1(n946), .B0(n958), .Y(n272) );
  AOI21X1 I1340 ( .A0(n1502), .A1(n1512), .B0(n959), .Y(n958) );
  NAND2X1 I1341 ( .A(SP_T1_EN), .B(n1528), .Y(n960) );
  OAI21X1 I1342 ( .A0(n945), .A1(n946), .B0(n947), .Y(n280) );
  AOI21X1 I1343 ( .A0(SP_RES_EN), .A1(n866), .B0(n948), .Y(n947) );
  NAND2X1 I1344 ( .A(SP_T1_EN), .B(TMP1[4]), .Y(n949) );
  NOR2X1 I1345 ( .A(n826), .B(n827), .Y(n825) );
  NAND3X1 I1346 ( .A(n833), .B(n834), .C(n835), .Y(n826) );
  NAND4X1 I1347 ( .A(n828), .B(n829), .C(n830), .D(n831), .Y(n827) );
  NOR2X1 I1348 ( .A(n1031), .B(n1032), .Y(n1030) );
  NAND3X1 I1349 ( .A(n1037), .B(n1038), .C(n1039), .Y(n1031) );
  NAND4X1 I1350 ( .A(n1033), .B(n1034), .C(n1035), .D(n1036), .Y(n1032) );
  OAI21X1 I1351 ( .A0(n810), .A1(n1166), .B0(n1167), .Y(B_REG_IN[7]) );
  AOI21X1 I1352 ( .A0(n758), .A1(IDATA[7]), .B0(n1168), .Y(n1166) );
  OAI21X1 I1353 ( .A0(n810), .A1(n1254), .B0(n1255), .Y(B_REG_IN[3]) );
  AOI21X1 I1354 ( .A0(n1505), .A1(n795), .B0(n1256), .Y(n1255) );
  AOI21X1 I1355 ( .A0(n758), .A1(IDATA[3]), .B0(n1257), .Y(n1254) );
  OAI21X1 I1356 ( .A0(n810), .A1(n1275), .B0(n1276), .Y(B_REG_IN[2]) );
  AOI21X1 I1357 ( .A0(n758), .A1(IDATA[2]), .B0(n1277), .Y(n1275) );
  NAND3X1 I1358 ( .A(n1008), .B(n1009), .C(n1010), .Y(n150) );
  AOI2BB1X1 I1359 ( .A0N(n791), .A1N(n837), .B0(n1013), .Y(n1009) );
  NAND2X1 I1360 ( .A(n756), .B(TMP2[7]), .Y(n831) );
  NAND2X1 I1361 ( .A(TMP2[4]), .B(n756), .Y(n1036) );
  NAND2X1 I1362 ( .A(n756), .B(TMP2[5]), .Y(n1046) );
  NAND2X1 I1363 ( .A(n756), .B(TMP2[6]), .Y(n1056) );
  NAND2X1 I1364 ( .A(n756), .B(n1525), .Y(n1028) );
  NAND2X1 I1365 ( .A(n756), .B(n1523), .Y(n1021) );
  NAND2BX1 I1366 ( .AN(n929), .B(n930), .Y(n2940) );
  NAND2X1 I1367 ( .A(n936), .B(n937), .Y(n929) );
  AOI21X1 I1368 ( .A0(n932), .A1(n933), .B0(C_0_EN), .Y(n931) );
  NAND2X1 I1369 ( .A(n900), .B(n901), .Y(n354) );
  MXI2X1 I1370 ( .S0(OV_T1Z_EN), .B(n721), .A(n732), .Y(n901) );
  NOR2X1 I1371 ( .A(n1528), .B(n361), .Y(n910) );
  NOR2X1 I1372 ( .A(n1023), .B(n1024), .Y(n1022) );
  OAI221X4 I1373 ( .A0(n768), .A1(n836), .B0(n966), .B1(n837), .C0(n1029), .Y(
        n1023) );
  NOR2X1 I1374 ( .A(n1016), .B(n1017), .Y(n1015) );
  NAND3X1 I1375 ( .A(n1057), .B(n1058), .C(n1059), .Y(n1051) );
  NOR2X1 I1376 ( .A(n1041), .B(n1042), .Y(n1040) );
  NAND3X1 I1377 ( .A(n1047), .B(n1048), .C(n1049), .Y(n1041) );
  INVX1 I1378 ( .A(PERI_SFR_DATA[6]), .Y(n1205) );
  INVX1 I1379 ( .A(PERI_SFR_DATA[5]), .Y(n1226) );
  INVX1 I1380 ( .A(PERI_SFR_DATA[3]), .Y(n1267) );
  INVX1 I1381 ( .A(n401), .Y(ACC_IN_2_) );
  INVX1 I1382 ( .A(n199), .Y(n194) );
  AOI22X1 I1383 ( .A0(P0_IN[3]), .A1(n1521), .B0(n1499), .B1(TMP1[3]), .Y(n860) );
  AOI22X1 I1384 ( .A0(P0_IN[5]), .A1(n1521), .B0(n1499), .B1(TMP1[5]), .Y(n868) );
  INVX1 I1385 ( .A(n1535), .Y(n1088) );
  NOR2X1 I1386 ( .A(ALU_SWAP_EN), .B(ALU_RR_EN), .Y(n1086) );
  INVX2 I1387 ( .A(n1293), .Y(n1190) );
  OR3X2 I1388 ( .A(n182), .B(n200), .C(n213), .Y(n223) );
  OR3X2 I1389 ( .A(n184), .B(n213), .C(n224), .Y(n245) );
  OR3X2 I1390 ( .A(n182), .B(n184), .C(n213), .Y(n212) );
  OR3X2 I1391 ( .A(n182), .B(n183), .C(n200), .Y(n199) );
  OR3X2 I1392 ( .A(n183), .B(n200), .C(n224), .Y(n2360) );
  NAND4X1 I1393 ( .A(n961), .B(n962), .C(n737), .D(n963), .Y(n2420) );
  NAND2X1 I1394 ( .A(n1504), .B(n968), .Y(n962) );
  NAND2X1 I1395 ( .A(n1292), .B(n1293), .Y(n1291) );
  AOI21X1 I1396 ( .A0(n1131), .A1(n1132), .B0(n811), .Y(MAR_IN[6]) );
  AOI21X1 I1397 ( .A0(MAR_RES_EN), .A1(n1506), .B0(n1138), .Y(n1131) );
  NAND3X1 I1398 ( .A(n1134), .B(n1135), .C(n1136), .Y(n1133) );
  OAI21X1 I1399 ( .A0(n810), .A1(n1234), .B0(n1235), .Y(B_REG_IN[4]) );
  AOI21X1 I1400 ( .A0(n758), .A1(IDATA[4]), .B0(n1236), .Y(n1234) );
  OAI21X1 I1401 ( .A0(n810), .A1(n1306), .B0(n1307), .Y(B_REG_IN[1]) );
  AOI21X1 I1402 ( .A0(n758), .A1(n847), .B0(n1308), .Y(n1306) );
  OAI21X1 I1403 ( .A0(n1111), .A1(n946), .B0(n1112), .Y(SP_IN_0_) );
  INVX1 I1404 ( .A(IDATA[0]), .Y(n1111) );
  AOI21X1 I1405 ( .A0(n1502), .A1(n1501), .B0(n1113), .Y(n1112) );
  NAND3BX1 I1406 ( .AN(n811), .B(n1114), .C(n1115), .Y(n1113) );
  AND2X2 I1407 ( .A(n918), .B(n345), .Y(n917) );
  AOI32X1 I1408 ( .A0(N330), .A1(n348), .A2(ALU_SUBBC_EN), .B0(N293), .B1(
        ALU_ADC_EN), .Y(n345) );
  NAND2X1 I1409 ( .A(P0_IN[0]), .B(n1520), .Y(n843) );
  NAND3X1 I1410 ( .A(n975), .B(n976), .C(n977), .Y(n225) );
  AOI22X1 I1411 ( .A0(n1531), .A1(n866), .B0(n1505), .B1(n968), .Y(n975) );
  INVX1 I1412 ( .A(n228), .Y(n977) );
  NAND3X1 I1413 ( .A(n994), .B(n995), .C(n996), .Y(n185) );
  NOR2X1 I1414 ( .A(n999), .B(n1000), .Y(n995) );
  NOR2X1 I1415 ( .A(n997), .B(n998), .Y(n996) );
  NAND2X1 I1416 ( .A(IDATA[6]), .B(n1534), .Y(n994) );
  NAND3X1 I1417 ( .A(n1004), .B(n1005), .C(n1006), .Y(n160) );
  NAND2X1 I1418 ( .A(T2_MDR_EN), .B(IDATA[0]), .Y(n1004) );
  AOI22X1 I1419 ( .A0(ACC[0]), .A1(n716), .B0(T2_RES_EN), .B1(n1500), .Y(n1006) );
  AOI21X1 I1420 ( .A0(n756), .A1(n1526), .B0(n1007), .Y(n1005) );
  AOI21X1 I1421 ( .A0(n1094), .A1(n1095), .B0(n810), .Y(TMP1_IN_0_) );
  AOI21X1 I1422 ( .A0(n713), .A1(n1513), .B0(n2570), .Y(n1094) );
  NOR2X1 I1423 ( .A(n1096), .B(n793), .Y(n1095) );
  OAI2BB1X1 I1424 ( .A0N(n178), .A1N(n2580), .B0(n2590), .Y(n2570) );
  NOR2X1 I1425 ( .A(n1075), .B(n1076), .Y(n1074) );
  NAND3X1 I1426 ( .A(n1077), .B(n1078), .C(n1079), .Y(n1076) );
  NAND2X1 I1427 ( .A(n832), .B(T1_XCHD_MDR_EN), .Y(n1078) );
  OR3X1 I1428 ( .A(n200), .B(n213), .C(n224), .Y(n2580) );
  DFFX1 PSW_reg_1_ ( .D(PSW_IN_1_), .CK(CLK), .Q(PSW_1_), .QN(n677) );
  NAND2X1 I1429 ( .A(n1526), .B(ALU_RRC_EN), .Y(n1089) );
  INVX1 I1430 ( .A(n200), .Y(n184) );
  INVX1 I1431 ( .A(n213), .Y(n183) );
  INVX1 I1432 ( .A(n224), .Y(n182) );
  NAND2BX1 I1433 ( .AN(n1334), .B(n1335), .Y(B_REG_IN[0]) );
  NAND2X1 I1434 ( .A(n1336), .B(n814), .Y(n1335) );
  OAI2BB1X1 I1435 ( .A0N(n796), .A1N(n847), .B0(n1107), .Y(SP_IN_1_) );
  AOI21X1 I1436 ( .A0(SP_RES_EN), .A1(n1504), .B0(n1108), .Y(n1107) );
  NAND3BX1 I1437 ( .AN(n811), .B(n1109), .C(n1110), .Y(n1108) );
  NAND2X1 I1438 ( .A(SP_T1_EN), .B(TMP1[1]), .Y(n1109) );
  AND4X2 I1439 ( .A(n979), .B(n980), .C(n981), .D(n794), .Y(n978) );
  AOI21X1 I1440 ( .A0(n178), .A1(n223), .B0(n982), .Y(n979) );
  NAND2X1 I1441 ( .A(n983), .B(n984), .Y(n201) );
  NOR2X1 I1442 ( .A(n985), .B(n986), .Y(n984) );
  NAND2X1 I1443 ( .A(IDATA[5]), .B(n1534), .Y(n983) );
  MXI2X1 I1444 ( .S0(n179), .B(n178), .A(n181), .Y(n1077) );
  OR3X2 I1445 ( .A(n182), .B(n183), .C(n184), .Y(n179) );
  AND2X2 I1446 ( .A(n424), .B(n812), .Y(MAR_IN[4]) );
  NAND3X1 I1447 ( .A(n896), .B(n897), .C(n898), .Y(n424) );
  INVX1 I1448 ( .A(n430), .Y(n897) );
  AND2X2 I1449 ( .A(n453), .B(n813), .Y(MAR_IN[0]) );
  NAND3X1 I1450 ( .A(n881), .B(n882), .C(n883), .Y(n453) );
  INVX1 I1451 ( .A(n457), .Y(n882) );
  NAND2X1 I1452 ( .A(ACC[5]), .B(T1_XCHD_MDR_EN), .Y(n991) );
  INVX1 I1453 ( .A(n421), .Y(n436) );
  INVX1 I1454 ( .A(n181), .Y(n229) );
  NAND2X1 I1455 ( .A(ACC[5]), .B(n1189), .Y(n1231) );
  INVX1 I1456 ( .A(C_1_EN), .Y(n933) );
  DFFX1 PSW_reg_5_ ( .D(PSW_IN_5_), .CK(CLK), .Q(PSW_5_), .QN(n742) );
  ADDFX2 I1457 ( .A(TMP2[3]), .B(n745), .CI(add_1_root_add_626_4_carry_3_), 
        .CO(N330) );
  OAI21X1 I1458 ( .A0(n1555), .A1(n1066), .B0(n1063), .Y(
        add_1_root_add_626_4_carry_3_) );
  AOI21X1 I1459 ( .A0(n1067), .A1(n1064), .B0(n1068), .Y(n1066) );
  OAI21X1 I1460 ( .A0(n1560), .A1(n1559), .B0(n1558), .Y(N221) );
  NAND2X1 I1461 ( .A(TMP1[3]), .B(n744), .Y(n1558) );
  NOR2X1 I1462 ( .A(TMP1[3]), .B(n744), .Y(n1560) );
  AOI21X1 I1463 ( .A0(n1557), .A1(n1556), .B0(n1555), .Y(n1559) );
  MX2X1 I1464 ( .S0(n1535), .B(N220), .A(N221), .Y(n928) );
  OAI21X1 I1465 ( .A0(n1566), .A1(n1565), .B0(n1564), .Y(N220) );
  NOR2X1 I1466 ( .A(TMP2[2]), .B(n2370), .Y(n1561) );
  NOR2X1 I1467 ( .A(n1061), .B(n1062), .Y(n1563) );
  NOR2X1 I1468 ( .A(TMP1[2]), .B(n746), .Y(n1554) );
  NOR2X1 I1469 ( .A(TMP1[1]), .B(n748), .Y(n1553) );
  NAND2X1 I1470 ( .A(TMP1[3]), .B(n744), .Y(n1564) );
  INVX1 I1471 ( .A(ID_WR_EN), .Y(n2930) );
  AND4X2 I1472 ( .A(n817), .B(MDR[0]), .C(n1351), .D(n1297), .Y(n1344) );
  NAND2BX1 I1473 ( .AN(n811), .B(MDR[1]), .Y(n1318) );
  NAND2X1 I1474 ( .A(n1499), .B(TMP1[1]), .Y(n852) );
  AOI22X1 I1475 ( .A0(ACC[0]), .A1(n1524), .B0(P0_IN[1]), .B1(n1520), .Y(n851)
         );
  NAND2X1 I1476 ( .A(ACC[2]), .B(n1531), .Y(n850) );
  INVX1 I1477 ( .A(MDR[7]), .Y(n1175) );
  INVX1 I1478 ( .A(MDR[5]), .Y(n1221) );
  INVX1 I1479 ( .A(MDR[3]), .Y(n1262) );
  INVX1 I1480 ( .A(MDR[2]), .Y(n1283) );
  NAND3X1 I1481 ( .A(n1182), .B(n1183), .C(n761), .Y(n1181) );
  NAND4X1 I1482 ( .A(n1184), .B(n1185), .C(n1186), .D(n1187), .Y(n1182) );
  NAND2X1 I1483 ( .A(DPTR[15]), .B(n1188), .Y(n1187) );
  AOI21X1 I1484 ( .A0(DPTR[7]), .A1(n1191), .B0(n1192), .Y(n1184) );
  NAND3X1 I1485 ( .A(n854), .B(n855), .C(n856), .Y(n596) );
  AOI22X1 I1486 ( .A0(P0_IN[2]), .A1(n1520), .B0(n1494), .B1(n1524), .Y(n854)
         );
  AND2X2 I1487 ( .A(ACC[0]), .B(B_REG[7]), .Y(B2_REG[7]) );
  AND2X2 I1488 ( .A(ACC[0]), .B(B_REG[1]), .Y(B2_REG[1]) );
  AND2X2 I1489 ( .A(ACC[0]), .B(B_REG[2]), .Y(B2_REG[2]) );
  AND2X2 I1490 ( .A(ACC[0]), .B(B_REG[3]), .Y(B2_REG[3]) );
  AND2X2 I1491 ( .A(ACC[0]), .B(B_REG[6]), .Y(B2_REG[6]) );
  AND2X2 I1492 ( .A(ACC[0]), .B(B_REG[5]), .Y(B2_REG[5]) );
  AND2X2 I1493 ( .A(ACC[0]), .B(B_REG[4]), .Y(B2_REG[4]) );
  NAND3X1 I1494 ( .A(n863), .B(n864), .C(n865), .Y(n563) );
  NAND3X1 I1495 ( .A(n872), .B(n873), .C(n874), .Y(n525) );
  NAND4X1 I1496 ( .A(n859), .B(n860), .C(n861), .D(n862), .Y(n579) );
  AND2X2 I1497 ( .A(B_REG[0]), .B(ACC[0]), .Y(B2_REG[0]) );
  INVX1 I1498 ( .A(n393), .Y(n395) );
  OR3X2 I1499 ( .A(B_T2RES_EN), .B(B_T1_EN), .C(n402), .Y(n393) );
  XOR2X1 I1500 ( .A(n397), .B(n398), .Y(n396) );
  NAND4X1 I1501 ( .A(n867), .B(n868), .C(n869), .D(n870), .Y(n545) );
  MX2X1 I1502 ( .S0(MAR[0]), .B(n803), .A(n802), .Y(n1156) );
  OR2X2 I1503 ( .A(n1330), .B(n1332), .Y(n802) );
  OR2X2 I1504 ( .A(n1330), .B(n1331), .Y(n803) );
  INVX1 I1505 ( .A(n292), .Y(n1326) );
  NAND2X1 I1506 ( .A(ACC[6]), .B(T2_A_EN), .Y(n1054) );
  NAND2X1 I1507 ( .A(P0R[6]), .B(T2_P0R_EN), .Y(n1053) );
  NAND2X1 I1508 ( .A(SP[6]), .B(T2_SP_EN), .Y(n1055) );
  NAND2X1 I1509 ( .A(ACC[5]), .B(T2_A_EN), .Y(n1044) );
  NAND2X1 I1510 ( .A(P0R[5]), .B(T2_P0R_EN), .Y(n1043) );
  NAND2X1 I1511 ( .A(SP[5]), .B(T2_SP_EN), .Y(n1045) );
  NAND2X1 I1512 ( .A(SP[3]), .B(T2_SP_EN), .Y(n1027) );
  NAND2X1 I1513 ( .A(n1523), .B(n91), .Y(n1025) );
  NAND2X1 I1514 ( .A(n716), .B(n858), .Y(n1026) );
  NAND2X1 I1515 ( .A(P0R[2]), .B(T2_P0R_EN), .Y(n1019) );
  NAND2X1 I1516 ( .A(SP[2]), .B(T2_SP_EN), .Y(n1020) );
  NAND2X1 I1517 ( .A(n1529), .B(n91), .Y(n1018) );
  NOR3X1 I1518 ( .A(n1137), .B(MAR[1]), .C(MAR[0]), .Y(n1376) );
  INVX1 I1519 ( .A(DPTR[0]), .Y(n1373) );
  OAI21X1 I1520 ( .A0(n1330), .A1(n1372), .B0(MAR[0]), .Y(n1371) );
  INVX1 I1521 ( .A(DPTR[8]), .Y(n1372) );
  NAND3X1 I1522 ( .A(n1207), .B(n1183), .C(n761), .Y(n1206) );
  NAND4X1 I1523 ( .A(n1208), .B(n1209), .C(n1210), .D(n1211), .Y(n1207) );
  NAND2X1 I1524 ( .A(DPTR[14]), .B(n1188), .Y(n1211) );
  AOI21X1 I1525 ( .A0(DPTR[6]), .A1(n1191), .B0(n1212), .Y(n1208) );
  NAND3X1 I1526 ( .A(n1228), .B(n1183), .C(n761), .Y(n1227) );
  NAND4X1 I1527 ( .A(n1229), .B(n1230), .C(n1231), .D(n1232), .Y(n1228) );
  NAND2X1 I1528 ( .A(DPTR[13]), .B(n1188), .Y(n1232) );
  AOI21X1 I1529 ( .A0(DPTR[5]), .A1(n1191), .B0(n1233), .Y(n1229) );
  NAND3X1 I1530 ( .A(n1269), .B(n1183), .C(n761), .Y(n1268) );
  NAND4X1 I1531 ( .A(n1270), .B(n1271), .C(n1272), .D(n1273), .Y(n1269) );
  NAND2X1 I1532 ( .A(DPTR[11]), .B(n1188), .Y(n1273) );
  AOI21X1 I1533 ( .A0(DPTR[3]), .A1(n1191), .B0(n1274), .Y(n1270) );
  NAND3X1 I1534 ( .A(n1299), .B(n1183), .C(n761), .Y(n1298) );
  NAND4X1 I1535 ( .A(n1300), .B(n1301), .C(n1302), .D(n1303), .Y(n1299) );
  NAND2X1 I1536 ( .A(DPTR[10]), .B(n1188), .Y(n1303) );
  AOI21X1 I1537 ( .A0(DPTR[2]), .A1(n1191), .B0(n1304), .Y(n1300) );
  NAND3X1 I1538 ( .A(n1248), .B(n1183), .C(n761), .Y(n1247) );
  NAND4X1 I1539 ( .A(n1249), .B(n1250), .C(n1251), .D(n1252), .Y(n1248) );
  NAND2X1 I1540 ( .A(DPTR[12]), .B(n1188), .Y(n1252) );
  AOI21X1 I1541 ( .A0(DPTR[4]), .A1(n1191), .B0(n1253), .Y(n1249) );
  NOR2X1 I1542 ( .A(n1329), .B(n1327), .Y(n1328) );
  NAND2X1 I1543 ( .A(B_REG[1]), .B(MAR[4]), .Y(n1329) );
  NOR3X1 I1544 ( .A(MAR[4]), .B(MAR[6]), .C(MAR[5]), .Y(n1377) );
  INVX1 I1545 ( .A(SP[0]), .Y(n1374) );
  NAND4X1 I1546 ( .A(n954), .B(n955), .C(n956), .D(n957), .Y(n276) );
  NAND2X1 I1547 ( .A(SP_T1_EN), .B(n1569), .Y(n954) );
  NAND2X1 I1548 ( .A(n739), .B(SP[6]), .Y(n955) );
  NAND2X1 I1549 ( .A(n1502), .B(n1506), .Y(n956) );
  NAND4X1 I1550 ( .A(n950), .B(n951), .C(n952), .D(n953), .Y(n2780) );
  NAND2X1 I1551 ( .A(SP_T1_EN), .B(n1570), .Y(n950) );
  NAND2X1 I1552 ( .A(SP[5]), .B(n739), .Y(n951) );
  NAND2X1 I1553 ( .A(n1502), .B(n871), .Y(n952) );
  NAND4X1 I1554 ( .A(n941), .B(n942), .C(n943), .D(n944), .Y(n282) );
  NAND2X1 I1555 ( .A(SP_T1_EN), .B(TMP1[3]), .Y(n941) );
  NAND2X1 I1556 ( .A(n739), .B(SP[3]), .Y(n942) );
  NAND2X1 I1557 ( .A(n1502), .B(n1505), .Y(n943) );
  NAND4X1 I1558 ( .A(n1103), .B(n1104), .C(n1105), .D(n1106), .Y(SP_IN_2_) );
  AOI21X1 I1559 ( .A0(SP_T1_EN), .A1(n1540), .B0(n810), .Y(n1104) );
  NAND2X1 I1560 ( .A(n739), .B(SP[2]), .Y(n1103) );
  NAND2X1 I1561 ( .A(SP_RES_EN), .B(n857), .Y(n1105) );
  OR2X2 I1562 ( .A(C_CB_EN), .B(CY_AC_OV_SUB_UP), .Y(n310) );
  NAND2X1 I1563 ( .A(n1323), .B(n1324), .Y(n1322) );
  NAND3BX1 I1564 ( .AN(n811), .B(PC[1]), .C(ID_PCL_EN), .Y(n1323) );
  NAND3BX1 I1565 ( .AN(n811), .B(PC[9]), .C(ID_PCH_EN), .Y(n1324) );
  NAND2X1 I1566 ( .A(n1183), .B(DPTR[9]), .Y(n1331) );
  INVX2 I1567 ( .A(WM_EN), .Y(n1496) );
  MXI2X1 I1568 ( .S0(CY_AC_OV_UP), .B(n917), .A(n916), .Y(n915) );
  MXI2X1 I1569 ( .S0(n344), .B(PSW_6_), .A(n928), .Y(n916) );
  OAI221X4 I1570 ( .A0(n1374), .A1(n411), .B0(n459), .B1(n412), .C0(n460), .Y(
        n457) );
  AOI22X1 I1571 ( .A0(MAR_MDR_EN), .A1(MDR[0]), .B0(MAR_P0R_EN), .B1(P0R[0]), 
        .Y(n460) );
  OAI221X4 I1572 ( .A0(n229), .A1(n230), .B0(n198), .B1(n231), .C0(n232), .Y(
        n228) );
  INVX1 I1573 ( .A(n230), .Y(n231) );
  OR3X1 I1574 ( .A(n183), .B(n184), .C(n224), .Y(n230) );
  OAI221X4 I1575 ( .A0(n788), .A1(n97), .B0(n404), .B1(n711), .C0(n817), .Y(
        MAR_IN[8]) );
  INVX1 I1576 ( .A(P0R[7]), .Y(n97) );
  OR2X2 I1577 ( .A(T1_SBP_EN), .B(n804), .Y(n181) );
  AND2X2 I1578 ( .A(T1_BITCP_EN), .B(CY), .Y(n804) );
  INVX1 I1579 ( .A(n2200), .Y(n982) );
  AOI21X1 I1580 ( .A0(n217), .A1(n181), .B0(n2210), .Y(n2200) );
  INVX1 I1581 ( .A(n223), .Y(n217) );
  OAI22X1 I1582 ( .A0(n198), .A1(n2400), .B0(n806), .B1(n197), .Y(n2390) );
  INVX1 I1583 ( .A(n2360), .Y(n2400) );
  OAI22X1 I1584 ( .A0(n303), .A1(n3180), .B0(CY_CJNE_EN), .B1(n2600), .Y(n3170) );
  INVX1 I1585 ( .A(CY_CJNE_EN), .Y(n3180) );
  OAI221X4 I1586 ( .A0(n1305), .A1(n411), .B0(n2370), .B1(n412), .C0(n446), 
        .Y(n444) );
  AOI22X1 I1587 ( .A0(MAR_MDR_EN), .A1(MDR[2]), .B0(MAR_P0R_EN), .B1(P0R[2]), 
        .Y(n446) );
  AOI22X1 I1588 ( .A0(MAR_MDR_EN), .A1(MDR[1]), .B0(MAR_P0R_EN), .B1(P0R[1]), 
        .Y(n452) );
  NAND2X1 I1589 ( .A(n675), .B(P0R[0]), .Y(n1097) );
  NAND2X1 I1590 ( .A(n1531), .B(n1504), .Y(n1099) );
  NAND2X1 I1591 ( .A(ACC[6]), .B(T1_XCHD_MDR_EN), .Y(n1003) );
  NOR2X1 I1592 ( .A(n711), .B(n750), .Y(n1144) );
  NAND3X1 I1593 ( .A(n1337), .B(n1338), .C(n1339), .Y(n1336) );
  NAND2X1 I1594 ( .A(B_T1_EN), .B(n1544), .Y(n1338) );
  NAND2X1 I1595 ( .A(n738), .B(B_REG[0]), .Y(n1337) );
  NAND2X1 I1596 ( .A(n758), .B(IDATA[0]), .Y(n1339) );
  AOI21X1 I1597 ( .A0(n892), .A1(MAR[4]), .B0(n899), .Y(n898) );
  INVX1 I1598 ( .A(MAR_P0R_EN), .Y(n439) );
  OAI2BB1X1 I1599 ( .A0N(P0R[3]), .A1N(n418), .B0(n438), .Y(n437) );
  AOI21X1 I1600 ( .A0(n1121), .A1(n1122), .B0(n810), .Y(MAR_IN[7]) );
  AOI21X1 I1601 ( .A0(MDR[7]), .A1(MAR_MDR_EN), .B0(n1130), .Y(n1121) );
  OAI21X1 I1602 ( .A0(n990), .A1(n212), .B0(n991), .Y(n987) );
  OAI21X1 I1603 ( .A0(n945), .A1(n913), .B0(n1117), .Y(PSW_IN_4_) );
  NAND2X1 I1604 ( .A(n797), .B(PSW_4_), .Y(n1117) );
  AOI21X1 I1605 ( .A0(n1142), .A1(n1143), .B0(n811), .Y(MAR_IN[1]) );
  AOI21X1 I1606 ( .A0(MAR_RES_EN), .A1(n1504), .B0(n450), .Y(n1142) );
  NOR2X1 I1607 ( .A(n1144), .B(n1145), .Y(n1143) );
  OAI221X4 I1608 ( .A0(n451), .A1(n411), .B0(n246), .B1(n412), .C0(n452), .Y(
        n450) );
  AOI21X1 I1609 ( .A0(n1140), .A1(n1141), .B0(n810), .Y(MAR_IN[5]) );
  AOI21X1 I1610 ( .A0(MAR_RES_EN), .A1(n871), .B0(n420), .Y(n1140) );
  NAND3X1 I1611 ( .A(n1124), .B(n1125), .C(n1126), .Y(n1123) );
  NAND2X1 I1612 ( .A(SP[7]), .B(n1129), .Y(n1124) );
  NAND2X1 I1613 ( .A(TMP1[7]), .B(n1128), .Y(n1125) );
  NAND2X1 I1614 ( .A(P0R[7]), .B(n1127), .Y(n1126) );
  NAND2X1 I1615 ( .A(P0R[6]), .B(n418), .Y(n1136) );
  NOR2X1 I1616 ( .A(n884), .B(n885), .Y(n883) );
  NAND2X1 I1617 ( .A(n886), .B(n887), .Y(n885) );
  NOR2X1 I1618 ( .A(n711), .B(n888), .Y(n884) );
  NAND2X1 I1619 ( .A(n436), .B(P0R[3]), .Y(n886) );
  NAND2X1 I1620 ( .A(n164), .B(n165), .Y(n1007) );
  INVX1 I1621 ( .A(T2_1_EN), .Y(n164) );
  OAI22X1 I1622 ( .A0(n99), .A1(n158), .B0(n167), .B1(n109), .Y(n166) );
  INVX1 I1623 ( .A(MAR[4]), .Y(n1368) );
  NAND2X1 I1624 ( .A(B_REG[7]), .B(n1190), .Y(n1185) );
  NAND2X1 I1625 ( .A(B_REG[3]), .B(n1190), .Y(n1271) );
  NOR2X1 I1626 ( .A(n964), .B(n965), .Y(n963) );
  OAI21X1 I1627 ( .A0(n229), .A1(n245), .B0(n247), .Y(n965) );
  OAI2BB1X1 I1628 ( .A0N(n334), .A1N(n847), .B0(n1119), .Y(PSW_IN_1_) );
  NAND2X1 I1629 ( .A(n797), .B(PSW_1_), .Y(n1119) );
  NAND2BX1 I1630 ( .AN(n913), .B(IDATA[5]), .Y(n1116) );
  NAND2BX1 I1631 ( .AN(n913), .B(IDATA[3]), .Y(n1118) );
  AND2X2 I1632 ( .A(n432), .B(n816), .Y(MAR_IN[3]) );
  AOI22X1 I1633 ( .A0(P0R[6]), .A1(n436), .B0(PSW_3_), .B1(n429), .Y(n893) );
  OAI22X2 I1634 ( .A0(n1193), .A1(n740), .B0(n823), .B1(n719), .Y(n1212) );
  OAI22X2 I1635 ( .A0(n1507), .A1(n714), .B0(n823), .B1(n1305), .Y(n1304) );
  INVX1 I1636 ( .A(SP[2]), .Y(n1305) );
  OAI22X2 I1637 ( .A0(n1508), .A1(n720), .B0(n823), .B1(n125), .Y(n1253) );
  NAND2X1 I1638 ( .A(n429), .B(IR[0]), .Y(n887) );
  NAND2BX1 I1639 ( .AN(P0R[7]), .B(MAR_BAR_EN), .Y(n421) );
  NAND2X1 I1640 ( .A(B_T1_EN), .B(TMP1[7]), .Y(n1169) );
  NAND2X1 I1641 ( .A(n1146), .B(n1147), .Y(n1145) );
  NAND2X1 I1642 ( .A(IR[1]), .B(MAR_RN_EN), .Y(n1147) );
  NAND2X1 I1643 ( .A(n436), .B(P0R[4]), .Y(n1146) );
  NAND2X1 I1644 ( .A(n739), .B(SP[0]), .Y(n1115) );
  NAND2X1 I1645 ( .A(B_T1_EN), .B(TMP1[4]), .Y(n1237) );
  NAND2X1 I1646 ( .A(n1178), .B(n1179), .Y(n1177) );
  NAND2X1 I1647 ( .A(PC[15]), .B(n1516), .Y(n1178) );
  NAND2X1 I1648 ( .A(PC[7]), .B(n1518), .Y(n1179) );
  NAND2X1 I1649 ( .A(n739), .B(SP[1]), .Y(n1110) );
  NAND2X1 I1650 ( .A(B_T1_EN), .B(TMP1[3]), .Y(n1258) );
  NAND2X1 I1651 ( .A(B_T1_EN), .B(n1540), .Y(n1278) );
  NAND2X1 I1652 ( .A(B_T1_EN), .B(n1569), .Y(n1197) );
  NAND2X1 I1653 ( .A(B_T1_EN), .B(TMP1[1]), .Y(n1309) );
  NAND2X1 I1654 ( .A(B_T1_EN), .B(n1570), .Y(n1216) );
  INVX1 I1655 ( .A(P0R[6]), .Y(n1001) );
  NAND2X1 I1656 ( .A(B_REG[6]), .B(n989), .Y(n1002) );
  NAND2X1 I1657 ( .A(n1189), .B(ACC[4]), .Y(n1251) );
  NAND2X1 I1658 ( .A(SP[6]), .B(n1129), .Y(n1134) );
  NAND2X1 I1659 ( .A(P0R[7]), .B(T2_P0R_EN), .Y(n829) );
  NAND2X1 I1660 ( .A(ACC[6]), .B(n1189), .Y(n1210) );
  NAND2X1 I1661 ( .A(ACC[2]), .B(n1189), .Y(n1302) );
  NAND2X1 I1662 ( .A(B_REG[6]), .B(n1190), .Y(n1209) );
  NAND2X1 I1663 ( .A(B_REG[5]), .B(n1190), .Y(n1230) );
  NAND2X1 I1664 ( .A(B_REG[2]), .B(n1190), .Y(n1301) );
  NAND2X1 I1665 ( .A(B_REG[4]), .B(n1190), .Y(n1250) );
  NAND2X1 I1666 ( .A(ACC[4]), .B(T2_A_EN), .Y(n1034) );
  NAND2X1 I1667 ( .A(SP[7]), .B(T2_SP_EN), .Y(n830) );
  NAND2X1 I1668 ( .A(SP[4]), .B(T2_SP_EN), .Y(n1035) );
  NAND2X1 I1669 ( .A(P0R[3]), .B(T2_P0R_EN), .Y(n1029) );
  NAND2X1 I1670 ( .A(n1224), .B(n1225), .Y(n1223) );
  NAND2X1 I1671 ( .A(PC[13]), .B(ID_PCH_EN), .Y(n1224) );
  NAND2X1 I1672 ( .A(PC[5]), .B(ID_PCL_EN), .Y(n1225) );
  NAND2X1 I1673 ( .A(n1286), .B(n1287), .Y(n1285) );
  NAND2X1 I1674 ( .A(PC[10]), .B(ID_PCH_EN), .Y(n1286) );
  NAND2X1 I1675 ( .A(PC[2]), .B(ID_PCL_EN), .Y(n1287) );
  NAND2X1 I1676 ( .A(n1265), .B(n1266), .Y(n1264) );
  NAND2X1 I1677 ( .A(PC[11]), .B(n1516), .Y(n1265) );
  NAND2X1 I1678 ( .A(PC[3]), .B(n1518), .Y(n1266) );
  NAND2X1 I1679 ( .A(PC[12]), .B(n1516), .Y(n1244) );
  NAND2X1 I1680 ( .A(PC[14]), .B(n1516), .Y(n1203) );
  NAND2X1 I1681 ( .A(PC[4]), .B(ID_PCL_EN), .Y(n1245) );
  NAND2X1 I1682 ( .A(PC[6]), .B(n1518), .Y(n1204) );
  NOR2X1 I1683 ( .A(N195), .B(PSW_6_), .Y(n806) );
  AND3X2 I1684 ( .A(n808), .B(n2600), .C(n809), .Y(n807) );
  NAND3X1 I1685 ( .A(N195), .B(ACC[4]), .C(n211), .Y(n809) );
  AND3X2 I1686 ( .A(n118), .B(n109), .C(ACC[7]), .Y(n211) );
  INVX1 I1687 ( .A(SP[1]), .Y(n451) );
  DFFX1 PSW_reg_0_ ( .D(PSW_IN_0_), .CK(CLK), .QN(n394) );
  AOI22X1 I1688 ( .A0(MAR_RN_EN), .A1(IR[2]), .B0(n436), .B1(P0R[5]), .Y(n889)
         );
  MXI2X1 I1689 ( .S0(n327), .B(C_ALLZ_B_EN), .A(CY), .Y(n935) );
  OR4X1 I1690 ( .A(C_ALLZ_AND_EN), .B(C_0_EN), .C(C_ALLZ_B_EN), .D(
        C_ALLZ_B_AND_EN), .Y(n335) );
  NAND2X1 I1691 ( .A(n1165), .B(n1153), .Y(n1314) );
  NOR2X1 I1692 ( .A(n1165), .B(n1163), .Y(n1148) );
  AOI21X1 I1693 ( .A0(MAR_RES_EN), .A1(n1512), .B0(n1123), .Y(n1122) );
  NAND2BX1 I1694 ( .AN(n836), .B(n1512), .Y(n835) );
  NAND2X4 I1695 ( .A(n751), .B(n731), .Y(n823) );
  OAI21X4 I1696 ( .A0(TMP2[7]), .A1(n1528), .B0(n912), .Y(n365) );
  OR2X1 I1697 ( .A(T2_MDR_EN), .B(T2_XCHD_A_EN), .Y(n128) );
  OR4X1 I1698 ( .A(T2_1_EN), .B(T2_0_EN), .C(DIV_OP_EN), .D(n128), .Y(n170) );
  OR3X1 I1699 ( .A(MUL_OP_EN), .B(DIV_OP_EN), .C(n402), .Y(n632) );
  EX_UNIT_DW01_add_5_0 add_1_root_add_626_2 ( .A({1'b0, TMP2[3:0]}), .B({1'b0, 
        TMP1[3:2], n1574, TMP1[0]}), .CI(CY), .SUM({N293, 
        SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1, 
        SYNOPSYS_UNCONNECTED__2, SYNOPSYS_UNCONNECTED__3}) );
  EX_UNIT_DW01_cmp2_8_1 lte_614 ( .A(TMP2), .B({n1568, TMP1[6:1], n1513}), 
        .LEQ(1'b1), .TC(1'b0), .LT_LE(N218) );
  EX_UNIT_DW01_cmp2_8_0 r207 ( .A(TMP2), .B({n1528, TMP1[6:3], n1540, n1574, 
        n1513}), .LEQ(1'b0), .TC(1'b0), .LT_LE(T1_GT_T2) );
  EX_UNIT_DW01_add_9_4 add_636_7 ( .A({1'b0, TMP2}), .B({1'b0, n1528, 
        TMP1[6:3], n1540, n1574, n1543}), .CI(1'b0), .SUM({N243, N242, N241, 
        N240, N239, N238, N237, N236, N235}) );
  EX_UNIT_DW01_add_9_3 add_636_6 ( .A({1'b0, B2_REG}), .B({1'b0, n1528, 
        TMP1[6:3], n1540, n1574, n1544}), .CI(1'b0), .SUM({N270, N269, N268, 
        N267, N266, N265, N264, N263, N262}) );
  EX_UNIT_DW01_add_9_2 add_636_5 ( .A({1'b0, TMP2}), .B({1'b0, TMP1_SUB}), 
        .CI(1'b0), .SUM({N323, N322, N321, N320, N319, N318, N317, N316, N315}) );
  EX_UNIT_DW01_sub_8_1 sub_1_root_add_634_2 ( .A({n1535, n1535, n1535, n1535, 
        n1535, n1535, n1535, n1535}), .B({TMP1[7:4], n1572, n1540, n1574, 
        TMP1[0]}), .CI(1'b0), .DIFF(TMP1_SUB) );
  EX_UNIT_DW01_add_9_1 add_1_root_add_636_4 ( .A({1'b0, TMP2}), .B({1'b0, N278, 
        n729, n725, n2180, N274, N273, n246, n459}), .CI(1'b1), .SUM({N302, 
        N301, N300, N299, N298, N297, N296, N295, N294}) );
  EX_UNIT_DW01_add_9_0 add_1_root_add_636_2 ( .A({1'b0, TMP2}), .B({1'b0, 
        n1568, TMP1[6:2], n1574, n1543}), .CI(n1535), .SUM({N261, N260, N259, 
        N258, N257, N256, N255, N254, N253}) );
endmodule


module EX_UNIT_DW01_add_9_0 ( A, B, CI, SUM, CO );
  input [8:0] A;
  input [8:0] B;
  output [8:0] SUM;
  input CI;
  output CO;
  wire   carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_, carry_1_;

  CMPR32X1 U1_2 ( .A(A[2]), .B(B[2]), .C(carry_2_), .S(SUM[2]), .CO(carry_3_)
         );
  CMPR32X1 U1_4 ( .A(A[4]), .B(B[4]), .C(carry_4_), .S(SUM[4]), .CO(carry_5_)
         );
  ADDFHX1 U1_5 ( .A(A[5]), .B(B[5]), .CI(carry_5_), .S(SUM[5]), .CO(carry_6_)
         );
  CMPR32X1 U1_0 ( .A(A[0]), .B(B[0]), .C(CI), .S(SUM[0]), .CO(carry_1_) );
  CMPR32X1 U1_1 ( .A(A[1]), .B(B[1]), .C(carry_1_), .S(SUM[1]), .CO(carry_2_)
         );
  CMPR32X1 U1_6 ( .A(A[6]), .B(B[6]), .C(carry_6_), .S(SUM[6]), .CO(carry_7_)
         );
  CMPR32X1 U1_7 ( .A(A[7]), .B(B[7]), .C(carry_7_), .S(SUM[7]), .CO(SUM[8]) );
  ADDFX2 U1_3 ( .A(A[3]), .B(B[3]), .CI(carry_3_), .S(SUM[3]), .CO(carry_4_)
         );
endmodule


module EX_UNIT_DW01_add_9_1 ( A, B, CI, SUM, CO );
  input [8:0] A;
  input [8:0] B;
  output [8:0] SUM;
  input CI;
  output CO;
  wire   carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_, carry_1_;

  ADDFX2 U1_1 ( .A(A[1]), .B(B[1]), .CI(carry_1_), .S(SUM[1]), .CO(carry_2_)
         );
  CMPR32X1 U1_3 ( .A(A[3]), .B(B[3]), .C(carry_3_), .S(SUM[3]), .CO(carry_4_)
         );
  CMPR32X1 U1_4 ( .A(A[4]), .B(B[4]), .C(carry_4_), .S(SUM[4]), .CO(carry_5_)
         );
  CMPR32X1 U1_5 ( .A(A[5]), .B(B[5]), .C(carry_5_), .S(SUM[5]), .CO(carry_6_)
         );
  CMPR32X1 U1_7 ( .A(A[7]), .B(B[7]), .C(carry_7_), .S(SUM[7]), .CO(SUM[8]) );
  ADDFX2 U1_2 ( .A(A[2]), .B(B[2]), .CI(carry_2_), .S(SUM[2]), .CO(carry_3_)
         );
  ADDFX2 U1_6 ( .A(A[6]), .B(B[6]), .CI(carry_6_), .S(SUM[6]), .CO(carry_7_)
         );
  OR2X1 U4 ( .A(B[0]), .B(A[0]), .Y(carry_1_) );
  XNOR2X1 U5 ( .A(A[0]), .B(B[0]), .Y(SUM[0]) );
endmodule


module EX_UNIT_DW01_sub_8_1 ( A, B, CI, DIFF, CO );
  input [7:0] A;
  input [7:0] B;
  output [7:0] DIFF;
  input CI;
  output CO;
  wire   carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_, carry_1_,
         B_not_6_, B_not_5_, B_not_4_, B_not_3_, B_not_2_, B_not_1_, B_not_0_;

  CMPR32X1 U2_5 ( .A(A[5]), .B(B_not_5_), .C(carry_5_), .S(DIFF[5]), .CO(
        carry_6_) );
  CMPR32X1 U2_4 ( .A(A[4]), .B(B_not_4_), .C(carry_4_), .S(DIFF[4]), .CO(
        carry_5_) );
  CMPR32X1 U2_2 ( .A(A[2]), .B(B_not_2_), .C(carry_2_), .S(DIFF[2]), .CO(
        carry_3_) );
  CMPR32X1 U2_3 ( .A(A[3]), .B(B_not_3_), .C(carry_3_), .S(DIFF[3]), .CO(
        carry_4_) );
  XNOR3X2 U6 ( .A(A[7]), .B(B[7]), .C(carry_7_), .Y(DIFF[7]) );
  CMPR32X1 U2_1 ( .A(A[1]), .B(B_not_1_), .C(carry_1_), .S(DIFF[1]), .CO(
        carry_2_) );
  INVX1 U7 ( .A(B[0]), .Y(B_not_0_) );
  INVX1 U8 ( .A(B[1]), .Y(B_not_1_) );
  INVX1 U9 ( .A(B[2]), .Y(B_not_2_) );
  ADDFX2 U2_6 ( .A(A[6]), .B(B_not_6_), .CI(carry_6_), .S(DIFF[6]), .CO(
        carry_7_) );
  INVX1 U10 ( .A(B[6]), .Y(B_not_6_) );
  INVX1 U11 ( .A(B[3]), .Y(B_not_3_) );
  INVX1 U12 ( .A(B[4]), .Y(B_not_4_) );
  INVX1 U13 ( .A(B[5]), .Y(B_not_5_) );
  OR2X1 U14 ( .A(B_not_0_), .B(A[0]), .Y(carry_1_) );
  XNOR2X1 U15 ( .A(A[0]), .B(B_not_0_), .Y(DIFF[0]) );
endmodule


module EX_UNIT_DW01_add_9_2 ( A, B, CI, SUM, CO );
  input [8:0] A;
  input [8:0] B;
  output [8:0] SUM;
  input CI;
  output CO;
  wire   carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_, carry_1_;

  CMPR32X1 U1_6 ( .A(A[6]), .B(B[6]), .C(carry_6_), .S(SUM[6]), .CO(carry_7_)
         );
  ADDFX2 U1_4 ( .A(A[4]), .B(B[4]), .CI(carry_4_), .S(SUM[4]), .CO(carry_5_)
         );
  CMPR32X1 U1_3 ( .A(A[3]), .B(B[3]), .C(carry_3_), .S(SUM[3]), .CO(carry_4_)
         );
  CMPR32X1 U1_5 ( .A(A[5]), .B(B[5]), .C(carry_5_), .S(SUM[5]), .CO(carry_6_)
         );
  CMPR32X1 U1_1 ( .A(A[1]), .B(B[1]), .C(carry_1_), .S(SUM[1]), .CO(carry_2_)
         );
  ADDFX2 U1_7 ( .A(A[7]), .B(B[7]), .CI(carry_7_), .S(SUM[7]), .CO(SUM[8]) );
  ADDFX2 U1_2 ( .A(A[2]), .B(B[2]), .CI(carry_2_), .S(SUM[2]), .CO(carry_3_)
         );
  AND2X1 U4 ( .A(A[0]), .B(B[0]), .Y(carry_1_) );
  XOR2X1 U5 ( .A(B[0]), .B(A[0]), .Y(SUM[0]) );
endmodule


module EX_UNIT_DW01_add_9_3 ( A, B, CI, SUM, CO );
  input [8:0] A;
  input [8:0] B;
  output [8:0] SUM;
  input CI;
  output CO;
  wire   carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_, carry_1_;

  ADDFX2 U1_7 ( .A(A[7]), .B(B[7]), .CI(carry_7_), .S(SUM[7]), .CO(SUM[8]) );
  ADDFX2 U1_1 ( .A(A[1]), .B(B[1]), .CI(carry_1_), .S(SUM[1]), .CO(carry_2_)
         );
  ADDFX2 U1_2 ( .A(A[2]), .B(B[2]), .CI(carry_2_), .S(SUM[2]), .CO(carry_3_)
         );
  ADDFX2 U1_3 ( .A(A[3]), .B(B[3]), .CI(carry_3_), .S(SUM[3]), .CO(carry_4_)
         );
  ADDFX2 U1_6 ( .A(A[6]), .B(B[6]), .CI(carry_6_), .S(SUM[6]), .CO(carry_7_)
         );
  ADDFX2 U1_5 ( .A(A[5]), .B(B[5]), .CI(carry_5_), .S(SUM[5]), .CO(carry_6_)
         );
  ADDFX2 U1_4 ( .A(A[4]), .B(B[4]), .CI(carry_4_), .S(SUM[4]), .CO(carry_5_)
         );
  AND2X1 U4 ( .A(A[0]), .B(B[0]), .Y(carry_1_) );
  XOR2X1 U5 ( .A(B[0]), .B(A[0]), .Y(SUM[0]) );
endmodule


module EX_UNIT_DW01_add_9_4 ( A, B, CI, SUM, CO );
  input [8:0] A;
  input [8:0] B;
  output [8:0] SUM;
  input CI;
  output CO;
  wire   carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_, carry_1_;

  ADDFX2 U1_1 ( .A(A[1]), .B(B[1]), .CI(carry_1_), .S(SUM[1]), .CO(carry_2_)
         );
  ADDFX2 U1_7 ( .A(A[7]), .B(B[7]), .CI(carry_7_), .S(SUM[7]), .CO(SUM[8]) );
  ADDFX2 U1_3 ( .A(A[3]), .B(B[3]), .CI(carry_3_), .S(SUM[3]), .CO(carry_4_)
         );
  ADDFX2 U1_4 ( .A(A[4]), .B(B[4]), .CI(carry_4_), .S(SUM[4]), .CO(carry_5_)
         );
  ADDFX2 U1_5 ( .A(A[5]), .B(B[5]), .CI(carry_5_), .S(SUM[5]), .CO(carry_6_)
         );
  ADDFX2 U1_6 ( .A(A[6]), .B(B[6]), .CI(carry_6_), .S(SUM[6]), .CO(carry_7_)
         );
  ADDFX2 U1_2 ( .A(A[2]), .B(B[2]), .CI(carry_2_), .S(SUM[2]), .CO(carry_3_)
         );
  AND2X1 U4 ( .A(A[0]), .B(B[0]), .Y(carry_1_) );
  XOR2X1 U5 ( .A(B[0]), .B(A[0]), .Y(SUM[0]) );
endmodule


module EX_UNIT_DW01_cmp2_8_0 ( A, B, LEQ, TC, LT_LE, GE_GT );
  input [7:0] A;
  input [7:0] B;
  input LEQ, TC;
  output LT_LE, GE_GT;
  wire   n15, n16, n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28,
         n29, n30, n31, n32, n33, n34, n35, n36, n37, n38, n39, n40, n41, n42,
         n43, n44, n45, n46, n47;

  AOI21X1 U6 ( .A0(n32), .A1(n33), .B0(n34), .Y(n23) );
  OAI21X1 U7 ( .A0(A[1]), .A1(n38), .B0(n39), .Y(n33) );
  OAI21X1 U8 ( .A0(n23), .A1(n24), .B0(n25), .Y(n20) );
  NOR2X1 U9 ( .A(n26), .B(n27), .Y(n25) );
  OAI21X1 U10 ( .A0(A[3]), .A1(n35), .B0(n36), .Y(n34) );
  NOR2X1 U11 ( .A(n44), .B(n45), .Y(n19) );
  NOR2X1 U12 ( .A(n41), .B(n42), .Y(n32) );
  NOR2X1 U13 ( .A(A[5]), .B(n28), .Y(n27) );
  NOR2X1 U14 ( .A(A[6]), .B(n22), .Y(n21) );
  NOR2X1 U15 ( .A(A[4]), .B(n29), .Y(n26) );
  INVX1 U16 ( .A(A[7]), .Y(n18) );
  INVX1 U17 ( .A(B[4]), .Y(n29) );
  INVX1 U18 ( .A(A[2]), .Y(n37) );
  NAND2X1 U19 ( .A(B[7]), .B(n18), .Y(n17) );
  NOR2X2 U20 ( .A(B[7]), .B(n18), .Y(n15) );
  AOI21X2 U21 ( .A0(n19), .A1(n20), .B0(n21), .Y(n16) );
  NAND2X1 U22 ( .A(B[2]), .B(n37), .Y(n36) );
  INVX1 U23 ( .A(B[3]), .Y(n35) );
  NOR2X1 U24 ( .A(B[2]), .B(n37), .Y(n41) );
  NOR2X1 U25 ( .A(B[1]), .B(n43), .Y(n42) );
  INVX1 U26 ( .A(A[1]), .Y(n43) );
  NOR2X1 U27 ( .A(B[6]), .B(n47), .Y(n44) );
  NOR2X1 U28 ( .A(B[5]), .B(n46), .Y(n45) );
  INVX1 U29 ( .A(A[6]), .Y(n47) );
  INVX1 U30 ( .A(B[5]), .Y(n28) );
  INVX1 U31 ( .A(B[6]), .Y(n22) );
  NAND2X1 U32 ( .A(A[4]), .B(n29), .Y(n31) );
  INVX1 U33 ( .A(B[1]), .Y(n38) );
  NAND2X1 U34 ( .A(B[0]), .B(n40), .Y(n39) );
  INVX1 U35 ( .A(A[0]), .Y(n40) );
  INVX1 U36 ( .A(A[3]), .Y(n30) );
  INVX1 U37 ( .A(A[5]), .Y(n46) );
  OAI21X4 U38 ( .A0(n15), .A1(n16), .B0(n17), .Y(LT_LE) );
  OAI21X4 U39 ( .A0(B[3]), .A1(n30), .B0(n31), .Y(n24) );
endmodule


module EX_UNIT_DW01_cmp2_8_1 ( A, B, LEQ, TC, LT_LE, GE_GT );
  input [7:0] A;
  input [7:0] B;
  input LEQ, TC;
  output LT_LE, GE_GT;
  wire   n15, n16, n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28,
         n29, n30, n31, n32, n33, n34, n35, n36, n37, n38, n39, n40, n41, n42,
         n43, n44, n45;

  AOI21X1 U6 ( .A0(n24), .A1(n25), .B0(n26), .Y(n19) );
  NOR2X1 U7 ( .A(n39), .B(n40), .Y(n30) );
  OAI21X1 U8 ( .A0(n30), .A1(n31), .B0(n32), .Y(n25) );
  NOR2X1 U9 ( .A(n33), .B(n34), .Y(n32) );
  OAI21X1 U10 ( .A0(A[7]), .A1(n15), .B0(n16), .Y(LT_LE) );
  OAI21X1 U11 ( .A0(A[5]), .A1(n27), .B0(n28), .Y(n26) );
  NOR2X1 U12 ( .A(n43), .B(n44), .Y(n24) );
  NOR2X1 U13 ( .A(A[3]), .B(n35), .Y(n34) );
  NOR2X1 U14 ( .A(A[1]), .B(n42), .Y(n39) );
  NOR2X1 U15 ( .A(A[2]), .B(n36), .Y(n33) );
  INVX1 U16 ( .A(B[7]), .Y(n15) );
  INVX1 U17 ( .A(B[6]), .Y(n21) );
  INVX1 U18 ( .A(B[2]), .Y(n36) );
  INVX1 U19 ( .A(A[4]), .Y(n29) );
  OAI22X2 U20 ( .A0(n19), .A1(n20), .B0(A[6]), .B1(n21), .Y(n17) );
  OAI21X2 U21 ( .A0(B[5]), .A1(n22), .B0(n23), .Y(n20) );
  NAND2X1 U22 ( .A(A[6]), .B(n21), .Y(n23) );
  NAND2X1 U23 ( .A(n17), .B(n18), .Y(n16) );
  NAND2X1 U24 ( .A(A[7]), .B(n15), .Y(n18) );
  INVX1 U25 ( .A(B[5]), .Y(n27) );
  NAND2X1 U26 ( .A(B[4]), .B(n29), .Y(n28) );
  NOR2X1 U27 ( .A(B[4]), .B(n29), .Y(n43) );
  NOR2X1 U28 ( .A(B[3]), .B(n45), .Y(n44) );
  INVX1 U29 ( .A(A[3]), .Y(n45) );
  INVX1 U30 ( .A(B[1]), .Y(n42) );
  INVX1 U31 ( .A(B[3]), .Y(n35) );
  NAND2X1 U32 ( .A(A[0]), .B(n41), .Y(n40) );
  INVX1 U33 ( .A(B[0]), .Y(n41) );
  NAND2X1 U34 ( .A(A[2]), .B(n36), .Y(n38) );
  INVX1 U35 ( .A(A[5]), .Y(n22) );
  INVX1 U36 ( .A(A[1]), .Y(n37) );
  OAI21X4 U37 ( .A0(B[1]), .A1(n37), .B0(n38), .Y(n31) );
endmodule


module EX_UNIT_DW01_add_5_0 ( A, B, CI, SUM, CO );
  input [4:0] A;
  input [4:0] B;
  output [4:0] SUM;
  input CI;
  output CO;
  wire   carry_3_, carry_2_, carry_1_;

  ADDFX2 U1_3 ( .A(A[3]), .B(B[3]), .CI(carry_3_), .CO(SUM[4]) );
  ADDFX2 U1_2 ( .A(A[2]), .B(B[2]), .CI(carry_2_), .CO(carry_3_) );
  ADDFX2 U1_1 ( .A(A[1]), .B(B[1]), .CI(carry_1_), .CO(carry_2_) );
  ADDFX2 U1_0 ( .A(A[0]), .B(B[0]), .CI(CI), .CO(carry_1_) );
endmodule


module IR_REG ( pre_pdwn_idle, inter_LCALL, POR, CLK, RESET, IR_EN, MOVX_INS, 
        MOVC_INS, LS4, CS3, CS2, ID, P0R, P0R_PRE_IR, IR );
  input [7:0] ID;
  input [7:0] P0R;
  output [7:0] IR;
  input pre_pdwn_idle, inter_LCALL, POR, CLK, RESET, IR_EN, MOVX_INS, MOVC_INS,
         LS4, CS3, CS2;
  output P0R_PRE_IR;
  wire   n52, n53, n54, n2, n3, n7, n8, n9, n10, n11, n12, n13, n16, n17, n21,
         n23, n24, n25, n26, n27, n28, n29, n30, n31, n33, n36, n38, n40, n41,
         n42, n43, n45, n47, n49, n50, n51;

  AOI33X4 U4 ( .A0(LS4), .A1(CS2), .A2(MOVC_INS), .B0(CS3), .B1(LS4), .B2(
        MOVX_INS), .Y(n2) );
  AOI222X4 U6 ( .A0(ID[7]), .A1(n49), .B0(IR[7]), .B1(n50), .C0(P0R[7]), .C1(
        n40), .Y(n3) );
  AOI222X4 U8 ( .A0(ID[6]), .A1(n49), .B0(IR[6]), .B1(n50), .C0(P0R[6]), .C1(
        n40), .Y(n7) );
  AOI222X4 U10 ( .A0(ID[5]), .A1(n49), .B0(IR[5]), .B1(n50), .C0(P0R[5]), .C1(
        n40), .Y(n8) );
  AOI221X4 U12 ( .A0(P0R[4]), .A1(n40), .B0(IR[4]), .B1(n50), .C0(inter_LCALL), 
        .Y(n9) );
  AOI222X4 U14 ( .A0(ID[3]), .A1(n49), .B0(n52), .B1(n50), .C0(P0R[3]), .C1(
        n40), .Y(n10) );
  AOI222X4 U16 ( .A0(ID[2]), .A1(n49), .B0(n53), .B1(n50), .C0(P0R[2]), .C1(
        n40), .Y(n11) );
  AOI221X4 U18 ( .A0(P0R[1]), .A1(n40), .B0(IR[1]), .B1(n50), .C0(inter_LCALL), 
        .Y(n12) );
  AOI222X4 U20 ( .A0(ID[0]), .A1(n49), .B0(n54), .B1(n50), .C0(P0R[0]), .C1(
        n40), .Y(n13) );
  NOR3BX1 I42 ( .AN(n51), .B(inter_LCALL), .C(n11), .Y(n25) );
  NOR3BX1 I43 ( .AN(n51), .B(inter_LCALL), .C(n10), .Y(n26) );
  NOR3BX1 I44 ( .AN(n51), .B(inter_LCALL), .C(n13), .Y(n23) );
  AND3X2 I45 ( .A(n42), .B(n17), .C(n41), .Y(n40) );
  NOR3BX1 I46 ( .AN(n51), .B(inter_LCALL), .C(n8), .Y(n28) );
  NOR3BX1 I47 ( .AN(n51), .B(inter_LCALL), .C(n3), .Y(n30) );
  INVX4 I48 ( .A(n47), .Y(IR[0]) );
  INVX1 I49 ( .A(RESET), .Y(n51) );
  DFFRX2 IR_reg_2_ ( .D(n25), .CK(CLK), .RN(n21), .Q(n53), .QN(n45) );
  DFFRX2 IR_reg_3_ ( .D(n26), .CK(CLK), .RN(n21), .Q(n52), .QN(n43) );
  DFFRX2 IR_reg_0_ ( .D(n23), .CK(CLK), .RN(n21), .Q(n54), .QN(n47) );
  NOR2BX2 I50 ( .AN(n16), .B(inter_LCALL), .Y(n50) );
  NAND2X2 I51 ( .A(IR_EN), .B(n31), .Y(n16) );
  NOR3X4 I52 ( .A(pre_pdwn_idle), .B(n17), .C(n16), .Y(n49) );
  INVX1 I53 ( .A(n16), .Y(n41) );
  INVX1 I54 ( .A(pre_pdwn_idle), .Y(n42) );
  INVX4 I55 ( .A(n43), .Y(IR[3]) );
  INVX8 I56 ( .A(n45), .Y(IR[2]) );
  OR2X2 I57 ( .A(MOVC_INS), .B(MOVX_INS), .Y(n17) );
  INVX1 I58 ( .A(n2), .Y(P0R_PRE_IR) );
  INVX2 I59 ( .A(inter_LCALL), .Y(n31) );
  OAI2BB1X1 I60 ( .A0N(ID[4]), .A1N(n49), .B0(n9), .Y(n36) );
  AND3X2 U40 ( .A(n38), .B(n51), .C(n31), .Y(n29) );
  INVX1 I61 ( .A(n7), .Y(n38) );
  NOR2BX1 U35 ( .AN(n33), .B(RESET), .Y(n24) );
  OAI2BB1X1 I62 ( .A0N(ID[1]), .A1N(n49), .B0(n12), .Y(n33) );
  INVX2 I63 ( .A(POR), .Y(n21) );
  NOR2BX1 U38 ( .AN(n36), .B(RESET), .Y(n27) );
  DFFRX4 IR_reg_7_ ( .D(n30), .CK(CLK), .RN(n21), .Q(IR[7]) );
  DFFRX4 IR_reg_6_ ( .D(n29), .CK(CLK), .RN(n21), .Q(IR[6]) );
  DFFRX4 IR_reg_5_ ( .D(n28), .CK(CLK), .RN(n21), .Q(IR[5]) );
  DFFRX4 IR_reg_4_ ( .D(n27), .CK(CLK), .RN(n21), .Q(IR[4]) );
  DFFRX4 IR_reg_1_ ( .D(n24), .CK(CLK), .RN(n21), .Q(IR[1]) );
endmodule


module MEM_INTF ( user_init_pc, user_init_pc_en, TRANS_EN, PC_HOLD, 
        inter_LCALL, inter_vector, JBC_BIT_EN, BIT_REG, P2_SFR, DPTR, ALLZ, 
        ALLZ_B_PC_RES_EN, ALLZ_PC_RES_EN, CLK, RESET, XA, IDATA, ID_WR_EN, MAR, 
        P0R, CY, F5, C_B_PC_RES_EN, C_PC_RES_EN, F5_B_PC_RES_EN, F5_PC_RES_EN, 
        IR, MDR, TMP1, TMP2, ACC, PC_AD11_EN, PC_PC1_EN, SJMP_PC_RES_EN, 
        JMP_PC_RES_EN, PC_RET_EN, PC_T2T1_EN, PC1_A_EN, PC1_DP_EN, PC1_P0R_EN, 
        PC2_DP_EN, PC2_PC_EN, PC1_PCCALL_EN, DPTR_INC_EN, DPTR_DEC_EN, 
        DP_T2T1_EN, XAH_P2R_EN, XA_DP_EN, XAL_MDR_EN, P0R_MDR_EN, P0R_P0_EN, 
        P0R_PRE_IR, P0_IN, CAR_PC_RES_EN, PC_INC_EN, PC_ADD, PC );
  input [15:0] user_init_pc;
  input [7:0] inter_vector;
  output [2:0] BIT_REG;
  input [7:0] P2_SFR;
  output [15:0] DPTR;
  output [15:0] XA;
  input [7:0] IDATA;
  input [8:0] MAR;
  output [7:0] P0R;
  input [7:0] IR;
  input [7:0] MDR;
  input [7:0] TMP1;
  input [7:0] TMP2;
  input [7:0] ACC;
  input [7:0] P0_IN;
  output [15:0] PC;
  input user_init_pc_en, TRANS_EN, PC_HOLD, inter_LCALL, JBC_BIT_EN, ALLZ,
         ALLZ_B_PC_RES_EN, ALLZ_PC_RES_EN, CLK, RESET, ID_WR_EN, CY, F5,
         C_B_PC_RES_EN, C_PC_RES_EN, F5_B_PC_RES_EN, F5_PC_RES_EN, PC_AD11_EN,
         PC_PC1_EN, SJMP_PC_RES_EN, JMP_PC_RES_EN, PC_RET_EN, PC_T2T1_EN,
         PC1_A_EN, PC1_DP_EN, PC1_P0R_EN, PC2_DP_EN, PC2_PC_EN, PC1_PCCALL_EN,
         DPTR_INC_EN, DPTR_DEC_EN, DP_T2T1_EN, XAH_P2R_EN, XA_DP_EN,
         XAL_MDR_EN, P0R_MDR_EN, P0R_P0_EN, P0R_PRE_IR, CAR_PC_RES_EN,
         PC_INC_EN, PC_ADD;
  wire   N34, N35, N36, N37, N38, N39, N40, N41, N45, N58, PC2_5_, N80, N81,
         N82, N83, N84, N85, N86, N87, N88, N89, N90, N91, N92, N93, N94, N95,
         PC2_NEW_15_, PC2_NEW_14_, PC2_NEW_13_, PC2_NEW_12_, PC2_NEW_11_,
         PC2_NEW_10_, PC2_NEW_9_, PC2_NEW_7_, PC2_NEW_6_, PC2_NEW_5_,
         PC2_NEW_4_, PC2_NEW_3_, PC2_NEW_2_, PC2_NEW_1_, N111, N122, N131,
         N141, N151, N183, N216, N217, N218, N219, N220, N221, N222, N223,
         N224, N225, N229, N230, N231, N232, N233, N234, N235, N236, N237,
         N238, N239, N240, N241, N242, N243, N244, N245, N246, N247, N248,
         N249, N250, N251, N252, N253, N254, N255, N256, N257, N258, N259,
         N260, n7, n11, n12, n16, n20, n21, n22, n24, n25, n27, n30, n31, n33,
         n3400, n3600, n3900, n42, n4500, n48, n51, n54, n59, n60, n68, n70,
         n71, n72, n73, n74, n75, n76, n77, n78, n79, n800, n810, n820, n830,
         n840, n850, n106, n107, n108, n109, n110, n1110, n114, n115, n116,
         n117, n118, n119, n120, n121, n1220, n123, n124, n125, n126, n127,
         n128, n129, n130, n1310, n132, n133, n135, n136, n138, n139, n1410,
         n142, n145, n147, n148, n149, n150, n1510, n152, n153, n154, n155,
         n156, n158, n160, n164, n189, n2470, n2490, n2510, n2520, n2570,
         n2580, n2590, n262, n263, n264, n327, n328, n329, n330, n331, n332,
         n333, n334, n335, n336, n337, n338, n339, n3401, n341, n342, n343,
         n344, n345, n346, n347, n348, n349, n350, n351, n352, n353, n354,
         n355, n356, n357, n358, n359, n3601, n361, n362, n363, n364, n365,
         n366, n367, n368, n369, n370, n371, n372, n373, n374, n375, n376,
         n377, n378, n379, n380, n381, n382, n383, n384, n385, n386, n387,
         n388, n389, n3901, n391, n392, n393, n394, n395, n396, n397, n398,
         n399, n400, n401, n402, n403, n404, n405, n406, n407, n408, n409,
         n410, n411, n412, n413, n414, n415, n416, n417, n418, n419, n420,
         n421, n422, n423, n424, n425, n426, n427, n428, n429, n430, n431,
         n432, n433, n434, n435, n436, n437, n438, n439, n440, n441, n442,
         n443, n444, n445, n446, n447, n448, n449, n4501, n451, n452, n453,
         n454, n455, n456, n457, n458, n459, n460, n461, n462, n463, n464,
         n465, n466, n467, n468, n469, n470, n471, n472, n473, n474, n475,
         n476, n477, n478, n479, n480, n481, n482, n483, n484, n485, n486,
         n487, n488, n489, n490, n491, n492, n493, n494, n495, n496, n497,
         n498, n499, n500, n501, n502, n503, n504, n505, n506, n507, n508,
         n509, n510, n511, n512, n513, n514, n515, n516, n517, n518, n519,
         n520, n521, n522, n523, n524, n525, n526, n527, n528, n529, n530,
         n531, n532, n533, n534, n535, n536, n537, n538, n539, n540, n541,
         n542, n543, n544, n545, n546, n547, n548, n549, n550, n551, n552,
         n553, n554, n555, n556, n557, n558, n559, n560, n561, n562, n563,
         n564, n565, n566, n567, n568, n569, n570, n571, n572, n573, n574,
         n575, n576, n577, n578, n579, n580, n581, n582, n583, n584, n585,
         n586, n587, n588, n589, n590, n591, n592, n593, n594, n595, n596,
         n597, n598, n599, n600, n601, n602, n603, n604, n605, n606, n607,
         n608, n609, n610, n611, n612, n613, n614, n615, n616, n617, n618,
         n619, n620, n621, n622, n623, n624, n625, n626, n627, n628, n629,
         n630, n631, n632, n633, n634, n635, n636, n637, n638, n639, n640,
         n641, n642, n643, n644, n645;
  wire   [15:0] PC1_NEW;
  wire   [15:0] PC2_IN;
  wire   [7:0] P0R_IN;
  wire   [15:0] PC1_IN;
  wire   [15:0] DPTR_IN;
  wire   [15:0] XA_IN;

  AOI222X4 U139 ( .A0(MDR[7]), .A1(n383), .B0(P0_IN[7]), .B1(n147), .C0(
        inter_vector[7]), .C1(n148), .Y(n145) );
  AOI222X4 U141 ( .A0(MDR[6]), .A1(n383), .B0(P0_IN[6]), .B1(n147), .C0(
        inter_vector[6]), .C1(n148), .Y(n149) );
  AOI222X4 U143 ( .A0(MDR[5]), .A1(n383), .B0(P0_IN[5]), .B1(n147), .C0(
        inter_vector[5]), .C1(n148), .Y(n150) );
  AOI222X4 U145 ( .A0(MDR[4]), .A1(n383), .B0(P0_IN[4]), .B1(n147), .C0(
        inter_vector[4]), .C1(n148), .Y(n1510) );
  AOI222X4 U147 ( .A0(MDR[3]), .A1(n383), .B0(P0_IN[3]), .B1(n147), .C0(
        inter_vector[3]), .C1(n148), .Y(n152) );
  AOI222X4 U149 ( .A0(MDR[2]), .A1(n383), .B0(P0_IN[2]), .B1(n147), .C0(
        inter_vector[2]), .C1(n148), .Y(n153) );
  AOI222X4 U151 ( .A0(MDR[1]), .A1(n383), .B0(P0_IN[1]), .B1(n147), .C0(
        inter_vector[1]), .C1(n148), .Y(n154) );
  AOI222X4 U153 ( .A0(MDR[0]), .A1(n383), .B0(P0_IN[0]), .B1(n147), .C0(
        inter_vector[0]), .C1(n148), .Y(n155) );
  OR2X4 U238 ( .A(PC2_PC_EN), .B(n354), .Y(N58) );
  OR2X4 U240 ( .A(PC1_PCCALL_EN), .B(n133), .Y(N45) );
  OAI32X4 U246 ( .A0(n2510), .A1(PC_AD11_EN), .A2(n2520), .B0(n189), .B1(n2520), .Y(N183) );
  MX2X1 I408 ( .S0(n380), .B(n76), .A(n3601), .Y(n327) );
  INVX1 I409 ( .A(n327), .Y(PC1_NEW[3]) );
  AOI21X1 I410 ( .A0(n328), .A1(user_init_pc[10]), .B0(n494), .Y(n493) );
  INVX1 I411 ( .A(n368), .Y(n328) );
  AOI2BB2X1 I412 ( .A0N(n604), .A1N(n3900), .B0(P2_SFR[7]), .B1(n379), .Y(n433) );
  AOI2BB2X1 I413 ( .A0N(n606), .A1N(n16), .B0(n329), .B1(MAR[7]), .Y(n408) );
  INVX1 I414 ( .A(n353), .Y(n329) );
  AOI2BB2X1 I415 ( .A0N(n470), .A1N(N35), .B0(n619), .B1(n634), .Y(n476) );
  NAND2BX1 I416 ( .AN(n442), .B(n402), .Y(n441) );
  NAND2BX1 I417 ( .AN(n416), .B(n411), .Y(n415) );
  OAI21X1 I418 ( .A0(n470), .A1(N36), .B0(n482), .Y(n330) );
  INVX1 I419 ( .A(n330), .Y(n481) );
  NAND2X1 I420 ( .A(n393), .B(n612), .Y(n2490) );
  AOI2BB2X1 I421 ( .A0N(n604), .A1N(n4500), .B0(P2_SFR[5]), .B1(n379), .Y(n440) );
  AOI2BB2X1 I422 ( .A0N(n22), .A1N(n353), .B0(n607), .B1(DPTR[6]), .Y(n414) );
  OAI2BB1X1 I423 ( .A0N(n372), .A1N(n331), .B0(n458), .Y(PC2_NEW_1_) );
  OAI222X4 I424 ( .A0(n332), .A1(n620), .B0(n468), .B1(n492), .C0(n470), .C1(
        N38), .Y(n491) );
  NAND2BX1 I425 ( .AN(n445), .B(n402), .Y(n444) );
  AOI2BB2X1 I426 ( .A0N(n604), .A1N(n48), .B0(P2_SFR[4]), .B1(n379), .Y(n443)
         );
  NAND2BX1 I427 ( .AN(n419), .B(n411), .Y(n418) );
  NAND2X1 I428 ( .A(n603), .B(n463), .Y(n462) );
  BUFX4 I429 ( .A(n458), .Y(n603) );
  MX2X1 I430 ( .S0(n380), .B(n840), .A(n357), .Y(n333) );
  INVX1 I431 ( .A(n333), .Y(PC1_NEW[10]) );
  NAND2BX1 I432 ( .AN(n448), .B(n402), .Y(n447) );
  AOI2BB2X1 I433 ( .A0N(n25), .A1N(n353), .B0(n607), .B1(DPTR[5]), .Y(n417) );
  AOI21X1 I434 ( .A0(n334), .A1(n372), .B0(n611), .Y(n336) );
  OR3X2 I435 ( .A(n619), .B(PC_RET_EN), .C(PC_T2T1_EN), .Y(n471) );
  INVX1 I436 ( .A(n620), .Y(n619) );
  OR2X2 I437 ( .A(n139), .B(n1410), .Y(n335) );
  INVX2 I438 ( .A(n335), .Y(n382) );
  OAI22X1 I439 ( .A0(n106), .A1(n7), .B0(n107), .B1(n108), .Y(PC1_IN[9]) );
  AOI2BB2X1 I440 ( .A0N(n604), .A1N(n51), .B0(P2_SFR[3]), .B1(n379), .Y(n446)
         );
  INVX1 I441 ( .A(n336), .Y(PC2_NEW_15_) );
  AOI21X1 I442 ( .A0(n337), .A1(user_init_pc[9]), .B0(n499), .Y(n498) );
  INVX1 I443 ( .A(n368), .Y(n337) );
  NAND2BX1 I444 ( .AN(n453), .B(n402), .Y(n4501) );
  NAND2BX1 I445 ( .AN(n422), .B(n411), .Y(n421) );
  OAI2BB1X1 I446 ( .A0N(n372), .A1N(n338), .B0(n458), .Y(n349) );
  OAI222X4 I447 ( .A0(n339), .A1(n620), .B0(n468), .B1(n469), .C0(n470), .C1(
        N34), .Y(n467) );
  AOI2BB2X1 I448 ( .A0N(n604), .A1N(n54), .B0(P2_SFR[2]), .B1(n379), .Y(n449)
         );
  AOI2BB2X1 I449 ( .A0N(n608), .A1N(n353), .B0(n607), .B1(DPTR[4]), .Y(n420)
         );
  OAI2BB1X1 I450 ( .A0N(n372), .A1N(n3401), .B0(n458), .Y(PC2_NEW_6_) );
  OR2X2 I451 ( .A(n403), .B(n11), .Y(n401) );
  AOI2BB1X1 I452 ( .A0N(PC2_5_), .A1N(n611), .B0(n459), .Y(PC2_NEW_5_) );
  MX2X1 I453 ( .S0(n380), .B(n850), .A(n367), .Y(n341) );
  INVX2 I454 ( .A(n341), .Y(PC1_NEW[0]) );
  OAI222X4 I455 ( .A0(n342), .A1(n620), .B0(n468), .B1(n487), .C0(n470), .C1(
        N37), .Y(n486) );
  AOI22X1 I456 ( .A0(P2_SFR[1]), .A1(n379), .B0(n605), .B1(DPTR[9]), .Y(n400)
         );
  AOI211X1 I457 ( .A0(n423), .A1(n411), .B0(n425), .C0(n426), .Y(n343) );
  INVX1 I458 ( .A(n343), .Y(XA_IN[3]) );
  AOI2BB2X1 I459 ( .A0N(n366), .A1N(n610), .B0(P0R[1]), .B1(n377), .Y(n501) );
  OR2X2 I460 ( .A(n407), .B(n11), .Y(n406) );
  OAI21X1 I461 ( .A0(n428), .A1(n20), .B0(n427), .Y(XA_IN[2]) );
  OAI2BB1X1 I462 ( .A0N(n344), .A1N(user_init_pc[14]), .B0(n472), .Y(N94) );
  INVX1 I463 ( .A(n368), .Y(n344) );
  AOI22X1 I464 ( .A0(P2_SFR[0]), .A1(n379), .B0(n605), .B1(DPTR[8]), .Y(n405)
         );
  INVX1 I465 ( .A(n20), .Y(n411) );
  NOR2X1 I466 ( .A(n395), .B(n471), .Y(n2510) );
  OAI222X4 I467 ( .A0(n353), .A1(n432), .B0(n606), .B1(n3600), .C0(n431), .C1(
        n20), .Y(XA_IN[1]) );
  NAND2BX1 I468 ( .AN(n439), .B(n402), .Y(n438) );
  OAI21X1 I469 ( .A0(n457), .A1(n345), .B0(n603), .Y(PC2_NEW_3_) );
  AOI2BB2X1 I470 ( .A0N(n357), .A1N(n609), .B0(P0R[2]), .B1(n377), .Y(n496) );
  OAI2BB1X1 I471 ( .A0N(n346), .A1N(user_init_pc[13]), .B0(n477), .Y(N93) );
  INVX1 I472 ( .A(n368), .Y(n346) );
  OAI222X4 I473 ( .A0(n60), .A1(n353), .B0(n606), .B1(n59), .C0(n456), .C1(n20), .Y(XA_IN[0]) );
  AOI22X1 I474 ( .A0(P2_SFR[6]), .A1(n379), .B0(n605), .B1(DPTR[14]), .Y(n437)
         );
  MXI2X1 I475 ( .S0(n623), .B(n75), .A(n361), .Y(n348) );
  OAI21X1 I476 ( .A0(n457), .A1(n641), .B0(n603), .Y(n347) );
  OAI21X1 I477 ( .A0(n457), .A1(n638), .B0(n603), .Y(n350) );
  MXI2X2 I478 ( .S0(n622), .B(n70), .A(n366), .Y(PC1_NEW[9]) );
  MX2X1 I479 ( .S0(n622), .B(PC[11]), .A(n630), .Y(PC1_NEW[11]) );
  MXI2X2 I480 ( .S0(n623), .B(n74), .A(n362), .Y(PC1_NEW[5]) );
  BUFX3 I481 ( .A(PC_AD11_EN), .Y(n621) );
  EDFFX2 P0R_reg_2_ ( .D(P0R_IN[2]), .CK(CLK), .E(N151), .Q(P0R[2]), .QN(N39)
         );
  OAI21X1 I482 ( .A0(n457), .A1(n637), .B0(n603), .Y(n351) );
  MXI2X1 I483 ( .S0(ALLZ), .B(ALLZ_PC_RES_EN), .A(ALLZ_B_PC_RES_EN), .Y(n601)
         );
  INVX1 I484 ( .A(n598), .Y(n558) );
  BUFX4 I485 ( .A(n558), .Y(n617) );
  INVX1 I486 ( .A(PC_RET_EN), .Y(n553) );
  BUFX4 I487 ( .A(n558), .Y(n618) );
  MXI2X1 I488 ( .S0(n623), .B(n75), .A(n361), .Y(PC1_NEW[4]) );
  NOR2X2 I489 ( .A(n621), .B(n613), .Y(n554) );
  NOR2X2 I490 ( .A(n3901), .B(DP_T2T1_EN), .Y(n595) );
  MXI2X2 I491 ( .S0(n617), .B(N243), .A(N259), .Y(n439) );
  MXI2X2 I492 ( .S0(n617), .B(N242), .A(N258), .Y(n442) );
  MXI2X2 I493 ( .S0(n617), .B(N241), .A(N257), .Y(n445) );
  MXI2X2 I494 ( .S0(n617), .B(N240), .A(N256), .Y(n448) );
  MXI2X2 I495 ( .S0(n617), .B(N238), .A(N254), .Y(n403) );
  MXI2X2 I496 ( .S0(n617), .B(N239), .A(N255), .Y(n453) );
  MXI2X2 I497 ( .S0(n617), .B(N229), .A(N245), .Y(n456) );
  MXI2X2 I498 ( .S0(n618), .B(N236), .A(N252), .Y(n412) );
  NAND3X2 I499 ( .A(n620), .B(n553), .C(PC_T2T1_EN), .Y(n468) );
  MXI2X2 I500 ( .S0(n618), .B(N235), .A(N251), .Y(n416) );
  MXI2X2 I501 ( .S0(n618), .B(N234), .A(N250), .Y(n419) );
  MXI2X2 I502 ( .S0(n618), .B(N233), .A(N249), .Y(n422) );
  MXI2X2 I503 ( .S0(n618), .B(N232), .A(N248), .Y(n424) );
  NAND2BX2 I504 ( .AN(n133), .B(PC1_PCCALL_EN), .Y(n107) );
  MXI2X2 I505 ( .S0(n618), .B(N230), .A(N246), .Y(n431) );
  MXI2X2 I506 ( .S0(n618), .B(N237), .A(N253), .Y(n407) );
  AND3X2 I507 ( .A(n25), .B(n22), .C(n608), .Y(n263) );
  AND3X2 I508 ( .A(n25), .B(n22), .C(n608), .Y(n2580) );
  OR3X2 I509 ( .A(P0R_PRE_IR), .B(P0R_P0_EN), .C(n158), .Y(N151) );
  EDFFX1 PC_reg_1_ ( .D(N81), .CK(CLK), .E(N216), .Q(PC[1]), .QN(n78) );
  EDFFX1 DPTR_reg_15_ ( .D(DPTR_IN[15]), .CK(CLK), .E(N122), .Q(DPTR[15]), 
        .QN(n3900) );
  EDFFX1 DPTR_reg_8_ ( .D(DPTR_IN[8]), .CK(CLK), .E(N122), .Q(DPTR[8]), .QN(
        n12) );
  EDFFX2 P0R_reg_1_ ( .D(P0R_IN[1]), .CK(CLK), .E(N151), .Q(P0R[1]), .QN(N40)
         );
  EDFFX2 P0R_reg_0_ ( .D(P0R_IN[0]), .CK(CLK), .E(N151), .Q(P0R[0]), .QN(N41)
         );
  OAI21X1 I510 ( .A0(n457), .A1(n640), .B0(n603), .Y(n352) );
  NAND2X2 I511 ( .A(XAL_MDR_EN), .B(n391), .Y(n353) );
  EDFFX2 P0R_reg_5_ ( .D(P0R_IN[5]), .CK(CLK), .E(N151), .Q(P0R[5]), .QN(N36)
         );
  EDFFX2 P0R_reg_4_ ( .D(P0R_IN[4]), .CK(CLK), .E(N151), .Q(P0R[4]), .QN(N37)
         );
  INVX1 I512 ( .A(n463), .Y(n399) );
  NAND4BBX1 I513 ( .AN(n384), .BN(n385), .C(n600), .D(n601), .Y(n463) );
  INVX2 I514 ( .A(PC_PC1_EN), .Y(n620) );
  OR2X4 I515 ( .A(n3901), .B(PC2_DP_EN), .Y(n354) );
  NAND2X4 I516 ( .A(n597), .B(n392), .Y(n355) );
  OR2X2 I517 ( .A(inter_LCALL), .B(n160), .Y(n356) );
  NAND2X4 I518 ( .A(user_init_pc_en), .B(n3901), .Y(n368) );
  EDFFX2 P0R_reg_7_ ( .D(P0R_IN[7]), .CK(CLK), .E(N151), .Q(P0R[7]), .QN(N34)
         );
  EDFFX2 P0R_reg_6_ ( .D(P0R_IN[6]), .CK(CLK), .E(N151), .Q(P0R[6]), .QN(N35)
         );
  EDFFX2 P0R_reg_3_ ( .D(P0R_IN[3]), .CK(CLK), .E(N151), .Q(P0R[3]), .QN(N38)
         );
  NAND2BX2 I519 ( .AN(DPTR_INC_EN), .B(n603), .Y(n597) );
  INVX12 I520 ( .A(n2470), .Y(N216) );
  MXI2X2 I521 ( .S0(n618), .B(N231), .A(N247), .Y(n428) );
  INVX2 I522 ( .A(n621), .Y(n550) );
  INVX2 I523 ( .A(n262), .Y(n2570) );
  NAND2X2 I524 ( .A(n595), .B(n596), .Y(n262) );
  NOR2X4 I525 ( .A(n138), .B(n139), .Y(n381) );
  NOR2X4 I526 ( .A(n3901), .B(n356), .Y(n383) );
  INVX1 I527 ( .A(P0R_MDR_EN), .Y(n160) );
  INVX12 I528 ( .A(n393), .Y(n3901) );
  AND2X4 I529 ( .A(n551), .B(n550), .Y(n377) );
  INVX1 I530 ( .A(n470), .Y(n551) );
  OAI21X4 I531 ( .A0(n388), .A1(n389), .B0(n2570), .Y(N111) );
  INVX12 I532 ( .A(n378), .Y(n106) );
  NOR2X1 I533 ( .A(SJMP_PC_RES_EN), .B(JMP_PC_RES_EN), .Y(n600) );
  INVX2 I534 ( .A(n368), .Y(n510) );
  OR3X2 I535 ( .A(PC1_A_EN), .B(PC1_DP_EN), .C(n3901), .Y(n139) );
  EDFFX1 DPTR_reg_9_ ( .D(DPTR_IN[9]), .CK(CLK), .E(N122), .Q(DPTR[9]), .QN(n7) );
  EDFFX1 DPTR_reg_10_ ( .D(DPTR_IN[10]), .CK(CLK), .E(N122), .Q(DPTR[10]), 
        .QN(n54) );
  EDFFX1 DPTR_reg_11_ ( .D(DPTR_IN[11]), .CK(CLK), .E(N122), .Q(DPTR[11]), 
        .QN(n51) );
  EDFFX1 DPTR_reg_12_ ( .D(DPTR_IN[12]), .CK(CLK), .E(N122), .Q(DPTR[12]), 
        .QN(n48) );
  EDFFX1 DPTR_reg_13_ ( .D(DPTR_IN[13]), .CK(CLK), .E(N122), .Q(DPTR[13]), 
        .QN(n4500) );
  EDFFX1 DPTR_reg_14_ ( .D(DPTR_IN[14]), .CK(CLK), .E(N122), .Q(DPTR[14]), 
        .QN(n42) );
  OAI21X4 I536 ( .A0(n386), .A1(n387), .B0(n2570), .Y(N122) );
  AND2X2 I537 ( .A(n552), .B(n550), .Y(n369) );
  AOI22X1 I538 ( .A0(n369), .A1(TMP1[1]), .B0(P0R[1]), .B1(n621), .Y(n542) );
  AOI22X1 I539 ( .A0(n369), .A1(TMP1[4]), .B0(n621), .B1(P0R[4]), .Y(n527) );
  AOI22X1 I540 ( .A0(n369), .A1(TMP1[6]), .B0(n621), .B1(P0R[6]), .Y(n517) );
  AOI22X1 I541 ( .A0(n369), .A1(TMP1[3]), .B0(n621), .B1(P0R[3]), .Y(n532) );
  AOI22X1 I542 ( .A0(n376), .A1(TMP1[7]), .B0(n621), .B1(P0R[7]), .Y(n512) );
  AOI22X1 I543 ( .A0(n376), .A1(TMP1[5]), .B0(n621), .B1(P0R[5]), .Y(n522) );
  AOI22X1 I544 ( .A0(n376), .A1(TMP1[2]), .B0(n621), .B1(P0R[2]), .Y(n537) );
  AOI22X1 I545 ( .A0(TMP2[2]), .A1(n369), .B0(n621), .B1(IR[7]), .Y(n495) );
  AOI22X1 I546 ( .A0(TMP2[1]), .A1(n369), .B0(IR[6]), .B1(n621), .Y(n500) );
  INVX1 I547 ( .A(n468), .Y(n552) );
  INVX1 I548 ( .A(n435), .Y(n370) );
  MXI2X2 I549 ( .S0(n617), .B(N244), .A(N260), .Y(n436) );
  OAI21X1 I550 ( .A0(n457), .A1(n636), .B0(n603), .Y(PC2_NEW_10_) );
  AND2X4 I551 ( .A(n460), .B(n461), .Y(n372) );
  EDFFX1 PC_reg_8_ ( .D(N88), .CK(CLK), .E(N216), .Q(PC[8]), .QN(n71) );
  BUFX2 I552 ( .A(n373), .Y(n371) );
  BUFX8 I553 ( .A(n380), .Y(n622) );
  EDFFX1 PC_reg_11_ ( .D(N91), .CK(CLK), .E(N183), .Q(PC[11]), .QN(n830) );
  NAND2X1 I554 ( .A(PC_INC_EN), .B(n399), .Y(n461) );
  OAI21X2 I555 ( .A0(n457), .A1(n639), .B0(n603), .Y(PC2_NEW_7_) );
  BUFX20 I556 ( .A(n380), .Y(n623) );
  INVX2 I557 ( .A(n605), .Y(n604) );
  INVX2 I558 ( .A(n607), .Y(n606) );
  NAND2BX1 I559 ( .AN(n3901), .B(PC1_A_EN), .Y(n142) );
  NAND2X1 I560 ( .A(n451), .B(n452), .Y(n11) );
  NAND2X1 I561 ( .A(n454), .B(n455), .Y(n20) );
  INVX1 I562 ( .A(n629), .Y(n627) );
  INVX8 I563 ( .A(n372), .Y(n457) );
  NAND2BX1 I564 ( .AN(n3901), .B(PC2_DP_EN), .Y(n68) );
  INVX1 I565 ( .A(RESET), .Y(n393) );
  INVX1 I566 ( .A(RESET), .Y(n391) );
  AOI22X1 I567 ( .A0(TMP2[0]), .A1(n376), .B0(IR[5]), .B1(n621), .Y(n506) );
  NAND2BX1 I568 ( .AN(n3901), .B(inter_LCALL), .Y(n156) );
  OAI21X1 I569 ( .A0(n457), .A1(n635), .B0(n603), .Y(PC2_NEW_11_) );
  NAND2BX1 I570 ( .AN(n457), .B(n374), .Y(n373) );
  OAI21X1 I571 ( .A0(n457), .A1(n641), .B0(n603), .Y(PC2_NEW_4_) );
  OAI21X1 I572 ( .A0(n457), .A1(n637), .B0(n603), .Y(PC2_NEW_9_) );
  OAI21X1 I573 ( .A0(n457), .A1(n640), .B0(n603), .Y(PC2_NEW_2_) );
  OAI21X1 I574 ( .A0(n457), .A1(n642), .B0(n603), .Y(PC2_NEW_12_) );
  OAI21X1 I575 ( .A0(n457), .A1(n643), .B0(n603), .Y(PC2_NEW_13_) );
  OAI21X1 I576 ( .A0(n457), .A1(n644), .B0(n603), .Y(PC2_NEW_14_) );
  OR2X1 I577 ( .A(n375), .B(JMP_PC_RES_EN), .Y(n599) );
  AOI22X1 I578 ( .A0(n376), .A1(TMP1[0]), .B0(P0R[0]), .B1(n621), .Y(n547) );
  AOI21X1 I579 ( .A0(P0R[0]), .A1(n377), .B0(n508), .Y(n507) );
  NOR2X1 I580 ( .A(n606), .B(n30), .Y(n426) );
  NOR2X1 I581 ( .A(n606), .B(n33), .Y(n430) );
  INVX1 I582 ( .A(MAR[6]), .Y(n22) );
  INVX1 I583 ( .A(MAR[2]), .Y(n3400) );
  INVX1 I584 ( .A(MAR[3]), .Y(n31) );
  INVX1 I585 ( .A(MAR[0]), .Y(n60) );
  AND3X1 I586 ( .A(MAR[8]), .B(ID_WR_EN), .C(MAR[0]), .Y(n2590) );
  NAND2X2 I587 ( .A(PC_RET_EN), .B(n620), .Y(n470) );
  INVX1 I588 ( .A(n471), .Y(n164) );
  INVX1 I589 ( .A(XAL_MDR_EN), .Y(n455) );
  NAND2X2 I590 ( .A(n595), .B(n596), .Y(n394) );
  NAND2X2 I591 ( .A(n595), .B(n596), .Y(n616) );
  NAND2X1 I592 ( .A(n554), .B(n164), .Y(n396) );
  NAND2X1 I593 ( .A(n619), .B(n550), .Y(n609) );
  NAND2X1 I594 ( .A(n619), .B(n550), .Y(n610) );
  NAND2X1 I595 ( .A(PC_PC1_EN), .B(n550), .Y(n497) );
  OR2X2 I596 ( .A(CAR_PC_RES_EN), .B(n20), .Y(N141) );
  AND2X2 I597 ( .A(n552), .B(n550), .Y(n376) );
  INVX1 I598 ( .A(n627), .Y(n625) );
  INVX1 I599 ( .A(n627), .Y(n626) );
  INVX1 I600 ( .A(n627), .Y(n628) );
  NAND2X1 I601 ( .A(n554), .B(n164), .Y(n614) );
  NAND2X1 I602 ( .A(n554), .B(n164), .Y(n615) );
  INVX2 I603 ( .A(n11), .Y(n402) );
  OR2X2 I604 ( .A(CAR_PC_RES_EN), .B(n11), .Y(N131) );
  INVX1 I605 ( .A(XAH_P2R_EN), .Y(n452) );
  INVX2 I606 ( .A(n612), .Y(n189) );
  NOR2X1 I607 ( .A(n436), .B(n471), .Y(n466) );
  NOR2X1 I608 ( .A(n439), .B(n471), .Y(n473) );
  NOR2X1 I609 ( .A(n442), .B(n471), .Y(n478) );
  NOR2X1 I610 ( .A(n445), .B(n471), .Y(n485) );
  NOR2X1 I611 ( .A(n448), .B(n471), .Y(n490) );
  INVX1 I612 ( .A(n436), .Y(n435) );
  INVX1 I613 ( .A(n412), .Y(n410) );
  INVX1 I614 ( .A(n424), .Y(n423) );
  INVX1 I615 ( .A(n611), .Y(n458) );
  INVX1 I616 ( .A(IDATA[0]), .Y(n602) );
  INVX1 I617 ( .A(n413), .Y(n607) );
  NAND3BX1 I618 ( .AN(n3901), .B(XA_DP_EN), .C(n455), .Y(n413) );
  INVX2 I619 ( .A(n142), .Y(n114) );
  INVX2 I620 ( .A(n597), .Y(n596) );
  NOR2X1 I621 ( .A(XA_DP_EN), .B(n3901), .Y(n454) );
  NOR3BX1 I622 ( .AN(DP_T2T1_EN), .B(n597), .C(n3901), .Y(n629) );
  NOR3BX1 I623 ( .AN(PC1_DP_EN), .B(PC1_A_EN), .C(n3901), .Y(n378) );
  OR3X1 I624 ( .A(PC1_DP_EN), .B(PC1_A_EN), .C(N217), .Y(n133) );
  OR2X2 I625 ( .A(PC1_P0R_EN), .B(n3901), .Y(N217) );
  INVX1 I626 ( .A(IDATA[1]), .Y(n557) );
  NAND2X1 I627 ( .A(TRANS_EN), .B(n391), .Y(n613) );
  INVX1 I628 ( .A(n404), .Y(n605) );
  NAND3BX1 I629 ( .AN(n3901), .B(XA_DP_EN), .C(n452), .Y(n404) );
  NOR2X1 I630 ( .A(XA_DP_EN), .B(n3901), .Y(n451) );
  AND2X2 I631 ( .A(XAH_P2R_EN), .B(n392), .Y(n379) );
  AND2X4 I632 ( .A(PC_INC_EN), .B(n399), .Y(n380) );
  OAI21X1 I633 ( .A0(n456), .A1(n355), .B0(n593), .Y(DPTR_IN[0]) );
  AOI21X1 I634 ( .A0(n628), .A1(TMP1[0]), .B0(n594), .Y(n593) );
  NOR2X1 I635 ( .A(n616), .B(n602), .Y(n594) );
  BUFX3 I636 ( .A(DPTR_DEC_EN), .Y(n611) );
  INVX1 I637 ( .A(IDATA[4]), .Y(n572) );
  INVX1 I638 ( .A(IDATA[5]), .Y(n569) );
  INVX1 I639 ( .A(IDATA[3]), .Y(n575) );
  INVX1 I640 ( .A(IDATA[6]), .Y(n566) );
  INVX1 I641 ( .A(IDATA[2]), .Y(n578) );
  INVX1 I642 ( .A(IDATA[7]), .Y(n563) );
  EDFFX1 PC_reg_9_ ( .D(N89), .CK(CLK), .E(N216), .Q(PC[9]), .QN(n70) );
  INVX2 I643 ( .A(n158), .Y(n147) );
  BUFX4 I644 ( .A(n68), .Y(n645) );
  EDFFX1 PC_reg_10_ ( .D(N90), .CK(CLK), .E(N216), .Q(PC[10]), .QN(n840) );
  INVX1 I645 ( .A(RESET), .Y(n392) );
  OAI21X2 I646 ( .A0(DPTR_INC_EN), .A1(n611), .B0(n462), .Y(n460) );
  AOI21X1 I647 ( .A0(n625), .A1(TMP2[7]), .B0(n582), .Y(n581) );
  NOR2X1 I648 ( .A(n616), .B(n563), .Y(n582) );
  OAI21X1 I649 ( .A0(n453), .A1(n614), .B0(n493), .Y(N90) );
  AOI21X1 I650 ( .A0(n495), .A1(n496), .B0(n397), .Y(n494) );
  OAI21X1 I651 ( .A0(n403), .A1(n615), .B0(n498), .Y(N89) );
  AOI21X1 I652 ( .A0(n500), .A1(n501), .B0(n612), .Y(n499) );
  OAI21X1 I653 ( .A0(n407), .A1(n396), .B0(n502), .Y(N88) );
  NOR2X1 I654 ( .A(n503), .B(n504), .Y(n502) );
  NOR2X1 I655 ( .A(n368), .B(n505), .Y(n504) );
  AOI21X1 I656 ( .A0(n506), .A1(n507), .B0(n397), .Y(n503) );
  OAI21X1 I657 ( .A0(n453), .A1(n355), .B0(n591), .Y(DPTR_IN[10]) );
  AOI21X1 I658 ( .A0(n628), .A1(TMP2[2]), .B0(n592), .Y(n591) );
  NOR2X1 I659 ( .A(n394), .B(n578), .Y(n592) );
  OAI21X1 I660 ( .A0(n403), .A1(n355), .B0(n555), .Y(DPTR_IN[9]) );
  AOI21X1 I661 ( .A0(n625), .A1(TMP2[1]), .B0(n556), .Y(n555) );
  NOR2X1 I662 ( .A(n616), .B(n557), .Y(n556) );
  OAI21X1 I663 ( .A0(n407), .A1(n355), .B0(n559), .Y(DPTR_IN[8]) );
  AOI21X1 I664 ( .A0(n626), .A1(TMP2[0]), .B0(n560), .Y(n559) );
  NOR2X1 I665 ( .A(n394), .B(n602), .Y(n560) );
  OAI21X1 I666 ( .A0(n412), .A1(n355), .B0(n561), .Y(DPTR_IN[7]) );
  AOI21X1 I667 ( .A0(n628), .A1(TMP1[7]), .B0(n562), .Y(n561) );
  NOR2X1 I668 ( .A(n262), .B(n563), .Y(n562) );
  OAI21X1 I669 ( .A0(n416), .A1(n355), .B0(n564), .Y(DPTR_IN[6]) );
  AOI21X1 I670 ( .A0(n626), .A1(TMP1[6]), .B0(n565), .Y(n564) );
  NOR2X1 I671 ( .A(n616), .B(n566), .Y(n565) );
  OAI21X1 I672 ( .A0(n419), .A1(n355), .B0(n567), .Y(DPTR_IN[5]) );
  AOI21X1 I673 ( .A0(n628), .A1(TMP1[5]), .B0(n568), .Y(n567) );
  NOR2X1 I674 ( .A(n394), .B(n569), .Y(n568) );
  OAI21X1 I675 ( .A0(n422), .A1(n355), .B0(n570), .Y(DPTR_IN[4]) );
  AOI21X1 I676 ( .A0(n624), .A1(TMP1[4]), .B0(n571), .Y(n570) );
  INVX1 I677 ( .A(n627), .Y(n624) );
  NOR2X1 I678 ( .A(n262), .B(n572), .Y(n571) );
  OAI21X1 I679 ( .A0(n424), .A1(n355), .B0(n573), .Y(DPTR_IN[3]) );
  AOI21X1 I680 ( .A0(n624), .A1(TMP1[3]), .B0(n574), .Y(n573) );
  NOR2X1 I681 ( .A(n616), .B(n575), .Y(n574) );
  OAI21X1 I682 ( .A0(n428), .A1(n355), .B0(n576), .Y(DPTR_IN[2]) );
  AOI21X1 I683 ( .A0(n624), .A1(TMP1[2]), .B0(n577), .Y(n576) );
  NOR2X1 I684 ( .A(n394), .B(n578), .Y(n577) );
  OAI21X1 I685 ( .A0(n431), .A1(n355), .B0(n579), .Y(DPTR_IN[1]) );
  AOI21X1 I686 ( .A0(n626), .A1(TMP1[1]), .B0(n580), .Y(n579) );
  NOR2X1 I687 ( .A(n262), .B(n557), .Y(n580) );
  OAI21X1 I688 ( .A0(n439), .A1(n355), .B0(n583), .Y(DPTR_IN[14]) );
  AOI21X1 I689 ( .A0(n624), .A1(TMP2[6]), .B0(n584), .Y(n583) );
  NOR2X1 I690 ( .A(n394), .B(n566), .Y(n584) );
  OAI21X1 I691 ( .A0(n442), .A1(n355), .B0(n585), .Y(DPTR_IN[13]) );
  AOI21X1 I692 ( .A0(n625), .A1(TMP2[5]), .B0(n586), .Y(n585) );
  NOR2X1 I693 ( .A(n262), .B(n569), .Y(n586) );
  OAI21X1 I694 ( .A0(n445), .A1(n355), .B0(n587), .Y(DPTR_IN[12]) );
  AOI21X1 I695 ( .A0(n626), .A1(TMP2[4]), .B0(n588), .Y(n587) );
  NOR2X1 I696 ( .A(n616), .B(n572), .Y(n588) );
  OAI21X1 I697 ( .A0(n448), .A1(n355), .B0(n589), .Y(DPTR_IN[11]) );
  AOI21X1 I698 ( .A0(n625), .A1(TMP2[3]), .B0(n590), .Y(n589) );
  NOR2X1 I699 ( .A(n394), .B(n575), .Y(n590) );
  NAND2X1 I700 ( .A(n408), .B(n409), .Y(XA_IN[7]) );
  NAND2X1 I701 ( .A(n410), .B(n411), .Y(n409) );
  NAND2X1 I702 ( .A(n414), .B(n415), .Y(XA_IN[6]) );
  NAND2X1 I703 ( .A(n417), .B(n418), .Y(XA_IN[5]) );
  NAND2X1 I704 ( .A(n420), .B(n421), .Y(XA_IN[4]) );
  NOR2X1 I705 ( .A(n31), .B(n353), .Y(n425) );
  NOR2X1 I706 ( .A(n429), .B(n430), .Y(n427) );
  NOR2X1 I707 ( .A(n3400), .B(n353), .Y(n429) );
  NAND2X1 I708 ( .A(n449), .B(n4501), .Y(XA_IN[10]) );
  NAND2X1 I709 ( .A(n433), .B(n434), .Y(XA_IN[15]) );
  NAND2X1 I710 ( .A(n435), .B(n402), .Y(n434) );
  NAND2X1 I711 ( .A(n446), .B(n447), .Y(XA_IN[11]) );
  NAND2X1 I712 ( .A(n437), .B(n438), .Y(XA_IN[14]) );
  NAND2X1 I713 ( .A(n440), .B(n441), .Y(XA_IN[13]) );
  NAND2X1 I714 ( .A(n443), .B(n444), .Y(XA_IN[12]) );
  NAND2X1 I715 ( .A(n400), .B(n401), .Y(XA_IN[9]) );
  NAND2X1 I716 ( .A(n405), .B(n406), .Y(XA_IN[8]) );
  INVX1 I717 ( .A(n2490), .Y(n2520) );
  OAI21X1 I718 ( .A0(n396), .A1(n395), .B0(n2490), .Y(n2470) );
  OR3X2 I719 ( .A(inter_LCALL), .B(P0R_MDR_EN), .C(n3901), .Y(n158) );
  NOR2X1 I720 ( .A(n363), .B(n610), .Y(n519) );
  NOR2X1 I721 ( .A(n3601), .B(n610), .Y(n534) );
  NOR2X1 I722 ( .A(n367), .B(n610), .Y(n549) );
  NOR2X1 I723 ( .A(n364), .B(n609), .Y(n514) );
  NOR2X1 I724 ( .A(n361), .B(n609), .Y(n529) );
  NOR2X1 I725 ( .A(n358), .B(n609), .Y(n544) );
  NOR2X1 I726 ( .A(n362), .B(n497), .Y(n524) );
  NOR2X1 I727 ( .A(n359), .B(n497), .Y(n539) );
  EDFFX1 DPTR_reg_0_ ( .D(DPTR_IN[0]), .CK(CLK), .E(N111), .Q(DPTR[0]), .QN(
        n59) );
  EDFFX1 PC_reg_0_ ( .D(N80), .CK(CLK), .E(N216), .Q(PC[0]), .QN(n850) );
  EDFFX1 DPTR_reg_1_ ( .D(DPTR_IN[1]), .CK(CLK), .E(N111), .Q(DPTR[1]), .QN(
        n3600) );
  INVX1 I728 ( .A(n1410), .Y(n138) );
  EDFFX1 PC_reg_15_ ( .D(N95), .CK(CLK), .E(N183), .Q(PC[15]), .QN(n79) );
  EDFFX1 PC_reg_7_ ( .D(N87), .CK(CLK), .E(N216), .Q(PC[7]), .QN(n72) );
  EDFFX1 DPTR_reg_7_ ( .D(DPTR_IN[7]), .CK(CLK), .E(N111), .Q(DPTR[7]), .QN(
        n16) );
  EDFFX1 PC1_reg_13_ ( .D(PC1_IN[13]), .CK(CLK), .E(N45), .Q(n632) );
  EDFFX1 PC1_reg_12_ ( .D(PC1_IN[12]), .CK(CLK), .E(N45), .Q(n631), .QN(n342)
         );
  EDFFX1 PC1_reg_11_ ( .D(PC1_IN[11]), .CK(CLK), .E(N45), .Q(n630), .QN(n332)
         );
  EDFFX1 PC_reg_12_ ( .D(N92), .CK(CLK), .E(N183), .Q(PC[12]), .QN(n820) );
  EDFFX1 PC_reg_6_ ( .D(N86), .CK(CLK), .E(N216), .Q(PC[6]), .QN(n73) );
  EDFFX1 PC_reg_5_ ( .D(N85), .CK(CLK), .E(N216), .Q(PC[5]), .QN(n74) );
  EDFFX1 PC_reg_4_ ( .D(N84), .CK(CLK), .E(N216), .Q(PC[4]), .QN(n75) );
  EDFFX1 PC_reg_2_ ( .D(N82), .CK(CLK), .E(N216), .Q(PC[2]), .QN(n77) );
  EDFFX1 PC1_reg_10_ ( .D(PC1_IN[10]), .CK(CLK), .E(N45), .QN(n357) );
  EDFFX1 PC1_reg_9_ ( .D(PC1_IN[9]), .CK(CLK), .E(N45), .QN(n366) );
  EDFFX1 PC1_reg_8_ ( .D(PC1_IN[8]), .CK(CLK), .E(N45), .QN(n365) );
  EDFFX1 PC1_reg_7_ ( .D(PC1_IN[7]), .CK(CLK), .E(N45), .QN(n364) );
  EDFFX1 PC1_reg_6_ ( .D(PC1_IN[6]), .CK(CLK), .E(N45), .QN(n363) );
  EDFFX1 PC1_reg_5_ ( .D(PC1_IN[5]), .CK(CLK), .E(N45), .QN(n362) );
  EDFFX1 PC1_reg_4_ ( .D(PC1_IN[4]), .CK(CLK), .E(N45), .QN(n361) );
  EDFFX1 PC1_reg_3_ ( .D(PC1_IN[3]), .CK(CLK), .E(N45), .QN(n3601) );
  EDFFX1 PC1_reg_2_ ( .D(PC1_IN[2]), .CK(CLK), .E(N45), .QN(n359) );
  EDFFX1 PC1_reg_1_ ( .D(PC1_IN[1]), .CK(CLK), .E(N45), .QN(n358) );
  EDFFX1 PC_reg_14_ ( .D(N94), .CK(CLK), .E(N183), .Q(PC[14]), .QN(n800) );
  EDFFX1 PC_reg_13_ ( .D(N93), .CK(CLK), .E(N183), .Q(PC[13]), .QN(n810) );
  EDFFX1 PC_reg_3_ ( .D(N83), .CK(CLK), .E(N216), .Q(PC[3]), .QN(n76) );
  EDFFX1 DPTR_reg_6_ ( .D(DPTR_IN[6]), .CK(CLK), .E(N111), .Q(DPTR[6]), .QN(
        n21) );
  EDFFX1 DPTR_reg_5_ ( .D(DPTR_IN[5]), .CK(CLK), .E(N111), .Q(DPTR[5]), .QN(
        n24) );
  EDFFX1 DPTR_reg_4_ ( .D(DPTR_IN[4]), .CK(CLK), .E(N111), .Q(DPTR[4]), .QN(
        n27) );
  EDFFX1 DPTR_reg_3_ ( .D(DPTR_IN[3]), .CK(CLK), .E(N111), .Q(DPTR[3]), .QN(
        n30) );
  EDFFX1 DPTR_reg_2_ ( .D(DPTR_IN[2]), .CK(CLK), .E(N111), .Q(DPTR[2]), .QN(
        n33) );
  EDFFX1 PC1_reg_15_ ( .D(PC1_IN[15]), .CK(CLK), .E(N45), .Q(n633), .QN(n339)
         );
  EDFFX1 PC1_reg_14_ ( .D(PC1_IN[14]), .CK(CLK), .E(N45), .Q(n634) );
  INVX2 I729 ( .A(n156), .Y(n148) );
  INVX1 I730 ( .A(TMP2[7]), .Y(n469) );
  INVX1 I731 ( .A(TMP2[5]), .Y(n480) );
  INVX1 I732 ( .A(TMP2[6]), .Y(n475) );
  INVX1 I733 ( .A(TMP2[3]), .Y(n492) );
  INVX1 I734 ( .A(TMP2[4]), .Y(n487) );
  MX2X1 I735 ( .S0(n622), .B(PC[13]), .A(n632), .Y(PC1_NEW[13]) );
  MX2X1 I736 ( .S0(F5), .B(F5_PC_RES_EN), .A(F5_B_PC_RES_EN), .Y(n384) );
  MX2X1 I737 ( .S0(CY), .B(C_PC_RES_EN), .A(C_B_PC_RES_EN), .Y(n385) );
  MX2X1 I738 ( .S0(n622), .B(PC[12]), .A(n631), .Y(PC1_NEW[12]) );
  MX2X1 I739 ( .S0(n622), .B(PC[14]), .A(n634), .Y(PC1_NEW[14]) );
  INVX1 I740 ( .A(user_init_pc[15]), .Y(n464) );
  OAI21X1 I741 ( .A0(n466), .A1(n467), .B0(n189), .Y(n465) );
  OAI21X1 I742 ( .A0(n412), .A1(n614), .B0(n509), .Y(N87) );
  AOI21X1 I743 ( .A0(user_init_pc[7]), .A1(n510), .B0(n511), .Y(n509) );
  AOI21X1 I744 ( .A0(n512), .A1(n513), .B0(n612), .Y(n511) );
  AOI21X1 I745 ( .A0(MDR[7]), .A1(n377), .B0(n514), .Y(n513) );
  OAI21X1 I746 ( .A0(n416), .A1(n615), .B0(n515), .Y(N86) );
  AOI21X1 I747 ( .A0(user_init_pc[6]), .A1(n510), .B0(n516), .Y(n515) );
  AOI21X1 I748 ( .A0(n517), .A1(n518), .B0(n397), .Y(n516) );
  AOI21X1 I749 ( .A0(MDR[6]), .A1(n377), .B0(n519), .Y(n518) );
  OAI21X1 I750 ( .A0(n419), .A1(n396), .B0(n520), .Y(N85) );
  AOI21X1 I751 ( .A0(user_init_pc[5]), .A1(n510), .B0(n521), .Y(n520) );
  AOI21X1 I752 ( .A0(n522), .A1(n523), .B0(n612), .Y(n521) );
  AOI21X1 I753 ( .A0(MDR[5]), .A1(n377), .B0(n524), .Y(n523) );
  OAI21X1 I754 ( .A0(n422), .A1(n614), .B0(n525), .Y(N84) );
  AOI21X1 I755 ( .A0(user_init_pc[4]), .A1(n510), .B0(n526), .Y(n525) );
  AOI21X1 I756 ( .A0(n527), .A1(n528), .B0(n397), .Y(n526) );
  AOI21X1 I757 ( .A0(MDR[4]), .A1(n377), .B0(n529), .Y(n528) );
  OAI21X1 I758 ( .A0(n424), .A1(n615), .B0(n530), .Y(N83) );
  AOI21X1 I759 ( .A0(user_init_pc[3]), .A1(n510), .B0(n531), .Y(n530) );
  AOI21X1 I760 ( .A0(n532), .A1(n533), .B0(n612), .Y(n531) );
  AOI21X1 I761 ( .A0(MDR[3]), .A1(n377), .B0(n534), .Y(n533) );
  OAI21X1 I762 ( .A0(n428), .A1(n396), .B0(n535), .Y(N82) );
  AOI21X1 I763 ( .A0(user_init_pc[2]), .A1(n510), .B0(n536), .Y(n535) );
  AOI21X1 I764 ( .A0(n537), .A1(n538), .B0(n397), .Y(n536) );
  AOI21X1 I765 ( .A0(MDR[2]), .A1(n377), .B0(n539), .Y(n538) );
  OAI21X1 I766 ( .A0(n431), .A1(n614), .B0(n540), .Y(N81) );
  AOI21X1 I767 ( .A0(user_init_pc[1]), .A1(n510), .B0(n541), .Y(n540) );
  AOI21X1 I768 ( .A0(n542), .A1(n543), .B0(n612), .Y(n541) );
  AOI21X1 I769 ( .A0(MDR[1]), .A1(n377), .B0(n544), .Y(n543) );
  AOI21X1 I770 ( .A0(n460), .A1(n461), .B0(n611), .Y(n459) );
  OAI21X1 I771 ( .A0(n473), .A1(n474), .B0(n189), .Y(n472) );
  OAI21X1 I772 ( .A0(n468), .A1(n475), .B0(n476), .Y(n474) );
  OAI21X1 I773 ( .A0(n478), .A1(n479), .B0(n189), .Y(n477) );
  OAI21X1 I774 ( .A0(n468), .A1(n480), .B0(n481), .Y(n479) );
  OAI21X1 I775 ( .A0(n368), .A1(n483), .B0(n484), .Y(N92) );
  INVX1 I776 ( .A(user_init_pc[12]), .Y(n483) );
  OAI21X1 I777 ( .A0(n485), .A1(n486), .B0(n189), .Y(n484) );
  OAI21X1 I778 ( .A0(n368), .A1(n488), .B0(n489), .Y(N91) );
  INVX1 I779 ( .A(user_init_pc[11]), .Y(n488) );
  OAI21X1 I780 ( .A0(n490), .A1(n491), .B0(n189), .Y(n489) );
  NOR2X1 I781 ( .A(PC_INC_EN), .B(PC_ADD), .Y(n398) );
  MX2X1 I782 ( .S0(n622), .B(PC[15]), .A(n633), .Y(PC1_NEW[15]) );
  OAI21X1 I783 ( .A0(n456), .A1(n615), .B0(n545), .Y(N80) );
  AOI21X1 I784 ( .A0(user_init_pc[0]), .A1(n510), .B0(n546), .Y(n545) );
  AOI21X1 I785 ( .A0(n547), .A1(n548), .B0(n397), .Y(n546) );
  AOI21X1 I786 ( .A0(MDR[0]), .A1(n377), .B0(n549), .Y(n548) );
  OAI22X1 I787 ( .A0(n3900), .A1(n106), .B0(n107), .B1(n127), .Y(PC1_IN[15])
         );
  INVX1 I788 ( .A(TMP1[7]), .Y(n127) );
  OAI22X1 I789 ( .A0(n42), .A1(n106), .B0(n107), .B1(n128), .Y(PC1_IN[14]) );
  INVX1 I790 ( .A(TMP1[6]), .Y(n128) );
  OAI22X1 I791 ( .A0(n4500), .A1(n106), .B0(n107), .B1(n129), .Y(PC1_IN[13])
         );
  INVX1 I792 ( .A(TMP1[5]), .Y(n129) );
  OAI22X1 I793 ( .A0(n48), .A1(n106), .B0(n107), .B1(n130), .Y(PC1_IN[12]) );
  INVX1 I794 ( .A(TMP1[4]), .Y(n130) );
  OAI22X1 I795 ( .A0(n51), .A1(n106), .B0(n107), .B1(n1310), .Y(PC1_IN[11]) );
  INVX1 I796 ( .A(TMP1[3]), .Y(n1310) );
  OAI22X1 I797 ( .A0(n54), .A1(n106), .B0(n107), .B1(n132), .Y(PC1_IN[10]) );
  INVX1 I798 ( .A(TMP1[2]), .Y(n132) );
  INVX1 I799 ( .A(TMP1[1]), .Y(n108) );
  OAI22X1 I800 ( .A0(n12), .A1(n106), .B0(n107), .B1(n109), .Y(PC1_IN[8]) );
  INVX1 I801 ( .A(TMP1[0]), .Y(n109) );
  OAI22X1 I802 ( .A0(n3900), .A1(n645), .B0(n354), .B1(n79), .Y(PC2_IN[15]) );
  OAI22X1 I803 ( .A0(n42), .A1(n645), .B0(n354), .B1(n800), .Y(PC2_IN[14]) );
  OAI22X1 I804 ( .A0(n4500), .A1(n645), .B0(n354), .B1(n810), .Y(PC2_IN[13])
         );
  OAI22X1 I805 ( .A0(n48), .A1(n645), .B0(n354), .B1(n820), .Y(PC2_IN[12]) );
  OAI22X1 I806 ( .A0(n51), .A1(n645), .B0(n354), .B1(n830), .Y(PC2_IN[11]) );
  OAI22X1 I807 ( .A0(n54), .A1(n645), .B0(n354), .B1(n840), .Y(PC2_IN[10]) );
  OAI22X1 I808 ( .A0(n7), .A1(n645), .B0(n354), .B1(n70), .Y(PC2_IN[9]) );
  OAI22X1 I809 ( .A0(n12), .A1(n645), .B0(n354), .B1(n71), .Y(PC2_IN[8]) );
  OAI22X1 I810 ( .A0(n16), .A1(n645), .B0(n354), .B1(n72), .Y(PC2_IN[7]) );
  OAI22X1 I811 ( .A0(n21), .A1(n645), .B0(n354), .B1(n73), .Y(PC2_IN[6]) );
  OAI22X1 I812 ( .A0(n24), .A1(n645), .B0(n354), .B1(n74), .Y(PC2_IN[5]) );
  OAI22X1 I813 ( .A0(n27), .A1(n645), .B0(n354), .B1(n75), .Y(PC2_IN[4]) );
  OAI22X1 I814 ( .A0(n30), .A1(n645), .B0(n354), .B1(n76), .Y(PC2_IN[3]) );
  OAI22X1 I815 ( .A0(n33), .A1(n645), .B0(n354), .B1(n77), .Y(PC2_IN[2]) );
  OAI22X1 I816 ( .A0(n3600), .A1(n645), .B0(n354), .B1(n78), .Y(PC2_IN[1]) );
  OAI22X1 I817 ( .A0(n59), .A1(n645), .B0(n354), .B1(n850), .Y(PC2_IN[0]) );
  NAND3X1 I818 ( .A(MAR[1]), .B(MAR[7]), .C(n2590), .Y(n386) );
  NAND3X1 I819 ( .A(n3400), .B(n31), .C(n2580), .Y(n387) );
  NAND3X1 I820 ( .A(MAR[7]), .B(n60), .C(n264), .Y(n388) );
  NAND3X1 I821 ( .A(n3400), .B(n31), .C(n263), .Y(n389) );
  NOR2X1 I822 ( .A(n365), .B(n497), .Y(n508) );
  NAND2X1 I823 ( .A(PC_PC1_EN), .B(n632), .Y(n482) );
  NAND2X1 I824 ( .A(P0R[7]), .B(PC1_P0R_EN), .Y(n1410) );
  OAI211X1 I825 ( .A0(n16), .A1(n106), .B0(n110), .C0(n1110), .Y(PC1_IN[7]) );
  NAND2X1 I826 ( .A(ACC[7]), .B(n114), .Y(n110) );
  AOI22X1 I827 ( .A0(N225), .A1(n382), .B0(n381), .B1(P0R[7]), .Y(n1110) );
  OAI211X1 I828 ( .A0(n21), .A1(n106), .B0(n115), .C0(n116), .Y(PC1_IN[6]) );
  NAND2X1 I829 ( .A(ACC[6]), .B(n114), .Y(n115) );
  AOI22X1 I830 ( .A0(N224), .A1(n382), .B0(n381), .B1(P0R[6]), .Y(n116) );
  OAI211X1 I831 ( .A0(n24), .A1(n106), .B0(n117), .C0(n118), .Y(PC1_IN[5]) );
  NAND2X1 I832 ( .A(ACC[5]), .B(n114), .Y(n117) );
  AOI22X1 I833 ( .A0(N223), .A1(n382), .B0(n381), .B1(P0R[5]), .Y(n118) );
  OAI211X1 I834 ( .A0(n27), .A1(n106), .B0(n119), .C0(n120), .Y(PC1_IN[4]) );
  NAND2X1 I835 ( .A(ACC[4]), .B(n114), .Y(n119) );
  AOI22X1 I836 ( .A0(N222), .A1(n382), .B0(n381), .B1(P0R[4]), .Y(n120) );
  OAI211X1 I837 ( .A0(n30), .A1(n106), .B0(n121), .C0(n1220), .Y(PC1_IN[3]) );
  NAND2X1 I838 ( .A(ACC[3]), .B(n114), .Y(n121) );
  AOI22X1 I839 ( .A0(N221), .A1(n382), .B0(n381), .B1(P0R[3]), .Y(n1220) );
  OAI211X1 I840 ( .A0(n33), .A1(n106), .B0(n123), .C0(n124), .Y(PC1_IN[2]) );
  NAND2X1 I841 ( .A(ACC[2]), .B(n114), .Y(n123) );
  AOI22X1 I842 ( .A0(N220), .A1(n382), .B0(n381), .B1(P0R[2]), .Y(n124) );
  OAI211X1 I843 ( .A0(n3600), .A1(n106), .B0(n125), .C0(n126), .Y(PC1_IN[1])
         );
  NAND2X1 I844 ( .A(ACC[1]), .B(n114), .Y(n125) );
  AOI22X1 I845 ( .A0(N219), .A1(n382), .B0(n381), .B1(P0R[1]), .Y(n126) );
  OAI211X1 I846 ( .A0(n59), .A1(n106), .B0(n135), .C0(n136), .Y(PC1_IN[0]) );
  NAND2X1 I847 ( .A(ACC[0]), .B(n114), .Y(n135) );
  AOI22X1 I848 ( .A0(N218), .A1(n382), .B0(n381), .B1(P0R[0]), .Y(n136) );
  INVX1 I849 ( .A(n145), .Y(P0R_IN[7]) );
  INVX1 I850 ( .A(n149), .Y(P0R_IN[6]) );
  INVX1 I851 ( .A(n150), .Y(P0R_IN[5]) );
  INVX1 I852 ( .A(n1510), .Y(P0R_IN[4]) );
  INVX1 I853 ( .A(n152), .Y(P0R_IN[3]) );
  INVX1 I854 ( .A(n153), .Y(P0R_IN[2]) );
  INVX1 I855 ( .A(n154), .Y(P0R_IN[1]) );
  INVX1 I856 ( .A(n155), .Y(P0R_IN[0]) );
  INVX1 I857 ( .A(MAR[5]), .Y(n25) );
  AND3X1 I858 ( .A(MAR[8]), .B(ID_WR_EN), .C(MAR[1]), .Y(n264) );
  INVX1 I859 ( .A(MAR[4]), .Y(n608) );
  INVX1 I860 ( .A(MAR[1]), .Y(n432) );
  INVX1 I861 ( .A(user_init_pc[8]), .Y(n505) );
  EDFFX1 PC2_reg_13_ ( .D(PC2_IN[13]), .CK(CLK), .E(N58), .QN(n643) );
  EDFFX1 PC2_reg_12_ ( .D(PC2_IN[12]), .CK(CLK), .E(N58), .QN(n642) );
  EDFFX1 PC2_reg_11_ ( .D(PC2_IN[11]), .CK(CLK), .E(N58), .QN(n635) );
  EDFFX1 PC2_reg_10_ ( .D(PC2_IN[10]), .CK(CLK), .E(N58), .QN(n636) );
  EDFFX1 PC2_reg_9_ ( .D(PC2_IN[9]), .CK(CLK), .E(N58), .QN(n637) );
  EDFFX1 PC2_reg_8_ ( .D(PC2_IN[8]), .CK(CLK), .E(N58), .Q(n338), .QN(n638) );
  EDFFX1 PC2_reg_7_ ( .D(PC2_IN[7]), .CK(CLK), .E(N58), .QN(n639) );
  EDFFX1 PC2_reg_6_ ( .D(PC2_IN[6]), .CK(CLK), .E(N58), .Q(n3401) );
  EDFFX1 PC2_reg_4_ ( .D(PC2_IN[4]), .CK(CLK), .E(N58), .QN(n641) );
  EDFFX1 PC2_reg_2_ ( .D(PC2_IN[2]), .CK(CLK), .E(N58), .QN(n640) );
  EDFFX1 PC2_reg_1_ ( .D(PC2_IN[1]), .CK(CLK), .E(N58), .Q(n331) );
  EDFFX1 PC2_reg_5_ ( .D(PC2_IN[5]), .CK(CLK), .E(N58), .Q(PC2_5_) );
  EDFFX1 PC2_reg_3_ ( .D(PC2_IN[3]), .CK(CLK), .E(N58), .QN(n345) );
  EDFFX1 PC2_reg_0_ ( .D(PC2_IN[0]), .CK(CLK), .E(N58), .QN(n374) );
  EDFFX1 PC2_reg_15_ ( .D(PC2_IN[15]), .CK(CLK), .E(N58), .Q(n334) );
  EDFFX1 PC2_reg_14_ ( .D(PC2_IN[14]), .CK(CLK), .E(N58), .QN(n644) );
  EDFFTRX1 rel_minus_reg ( .D(n138), .CK(CLK), .E(PC1_P0R_EN), .RN(n392), .QN(
        n375) );
  EDFFX1 BIT_REG_reg_1_ ( .D(P0_IN[1]), .CK(CLK), .E(JBC_BIT_EN), .Q(
        BIT_REG[1]) );
  EDFFX1 BIT_REG_reg_0_ ( .D(P0_IN[0]), .CK(CLK), .E(JBC_BIT_EN), .Q(
        BIT_REG[0]) );
  EDFFX1 BIT_REG_reg_2_ ( .D(P0_IN[2]), .CK(CLK), .E(JBC_BIT_EN), .Q(
        BIT_REG[2]) );
  EDFFX1 XA_reg_15_ ( .D(XA_IN[15]), .CK(CLK), .E(N131), .Q(XA[15]) );
  EDFFX1 XA_reg_13_ ( .D(XA_IN[13]), .CK(CLK), .E(N131), .Q(XA[13]) );
  EDFFX1 XA_reg_12_ ( .D(XA_IN[12]), .CK(CLK), .E(N131), .Q(XA[12]) );
  EDFFX1 XA_reg_11_ ( .D(XA_IN[11]), .CK(CLK), .E(N131), .Q(XA[11]) );
  EDFFX1 XA_reg_10_ ( .D(XA_IN[10]), .CK(CLK), .E(N131), .Q(XA[10]) );
  EDFFX1 XA_reg_9_ ( .D(XA_IN[9]), .CK(CLK), .E(N131), .Q(XA[9]) );
  EDFFX1 XA_reg_8_ ( .D(XA_IN[8]), .CK(CLK), .E(N131), .Q(XA[8]) );
  EDFFX1 XA_reg_7_ ( .D(XA_IN[7]), .CK(CLK), .E(N141), .Q(XA[7]) );
  EDFFX1 XA_reg_6_ ( .D(XA_IN[6]), .CK(CLK), .E(N141), .Q(XA[6]) );
  EDFFX1 XA_reg_5_ ( .D(XA_IN[5]), .CK(CLK), .E(N141), .Q(XA[5]) );
  EDFFX1 XA_reg_4_ ( .D(XA_IN[4]), .CK(CLK), .E(N141), .Q(XA[4]) );
  EDFFX1 XA_reg_3_ ( .D(XA_IN[3]), .CK(CLK), .E(N141), .Q(XA[3]) );
  EDFFX1 XA_reg_2_ ( .D(XA_IN[2]), .CK(CLK), .E(N141), .Q(XA[2]) );
  EDFFX1 XA_reg_1_ ( .D(XA_IN[1]), .CK(CLK), .E(N141), .Q(XA[1]) );
  EDFFX1 XA_reg_0_ ( .D(XA_IN[0]), .CK(CLK), .E(N141), .Q(XA[0]) );
  EDFFX1 XA_reg_14_ ( .D(XA_IN[14]), .CK(CLK), .E(N131), .Q(XA[14]) );
  OAI21X1 I862 ( .A0(n370), .A1(n355), .B0(n581), .Y(DPTR_IN[15]) );
  OAI21X1 I863 ( .A0(n368), .A1(n464), .B0(n465), .Y(N95) );
  NAND2BX1 I864 ( .AN(n599), .B(n463), .Y(n598) );
  NAND2X1 I865 ( .A(n398), .B(n399), .Y(n395) );
  MXI2X4 I866 ( .S0(n623), .B(n71), .A(n365), .Y(PC1_NEW[8]) );
  MXI2X4 I867 ( .S0(n623), .B(n72), .A(n364), .Y(PC1_NEW[7]) );
  MXI2X4 I868 ( .S0(n623), .B(n73), .A(n363), .Y(PC1_NEW[6]) );
  MXI2X4 I869 ( .S0(n623), .B(n77), .A(n359), .Y(PC1_NEW[2]) );
  MXI2X4 I870 ( .S0(n623), .B(n78), .A(n358), .Y(PC1_NEW[1]) );
  NAND2X2 I871 ( .A(TRANS_EN), .B(n391), .Y(n397) );
  NAND2X2 I872 ( .A(TRANS_EN), .B(n393), .Y(n612) );
  MEM_INTF_DW01_add_16_1 add_291 ( .A({PC2_NEW_15_, PC2_NEW_14_, PC2_NEW_13_, 
        PC2_NEW_12_, PC2_NEW_11_, PC2_NEW_10_, PC2_NEW_9_, n350, PC2_NEW_7_, 
        PC2_NEW_6_, PC2_NEW_5_, PC2_NEW_4_, PC2_NEW_3_, PC2_NEW_2_, PC2_NEW_1_, 
        n371}), .B(PC1_NEW), .CI(1'b0), .SUM({N260, N259, N258, N257, N256, 
        N255, N254, N253, N252, N251, N250, N249, N248, N247, N246, N245}) );
  MEM_INTF_DW01_sub_16_1 sub_291 ( .A({PC2_NEW_15_, PC2_NEW_14_, PC2_NEW_13_, 
        PC2_NEW_12_, PC2_NEW_11_, PC2_NEW_10_, n351, n349, PC2_NEW_7_, 
        PC2_NEW_6_, PC2_NEW_5_, n347, PC2_NEW_3_, n352, PC2_NEW_1_, n373}), 
        .B({PC1_NEW[15:5], n348, PC1_NEW[3:0]}), .CI(1'b0), .DIFF({N244, N243, 
        N242, N241, N240, N239, N238, N237, N236, N235, N234, N233, N232, N231, 
        N230, N229}) );
  EDFFX1 PC1_reg_0_ ( .D(PC1_IN[0]), .CK(CLK), .E(N45), .QN(n367) );
  MEM_INTF_DW01_inc_8_0 add_245 ( .A({N34, N35, N36, N37, N38, N39, N40, N41}), 
        .SUM({N225, N224, N223, N222, N221, N220, N219, N218}) );
endmodule


module MEM_INTF_DW01_inc_8_0 ( A, SUM );
  input [7:0] A;
  output [7:0] SUM;
  wire   carry_7_, carry_6_, carry_5_, carry_4_, carry_3_, carry_2_;

  CMPR22X1 U1_1_2 ( .A(A[2]), .B(carry_2_), .S(SUM[2]), .CO(carry_3_) );
  CMPR22X1 U1_1_3 ( .A(A[3]), .B(carry_3_), .S(SUM[3]), .CO(carry_4_) );
  CMPR22X1 U1_1_4 ( .A(A[4]), .B(carry_4_), .S(SUM[4]), .CO(carry_5_) );
  CMPR22X1 U1_1_5 ( .A(A[5]), .B(carry_5_), .S(SUM[5]), .CO(carry_6_) );
  CMPR22X1 U1_1_1 ( .A(A[1]), .B(A[0]), .S(SUM[1]), .CO(carry_2_) );
  CMPR22X1 U1_1_6 ( .A(A[6]), .B(carry_6_), .S(SUM[6]), .CO(carry_7_) );
  XOR2X1 U5 ( .A(carry_7_), .B(A[7]), .Y(SUM[7]) );
  INVX1 U6 ( .A(A[0]), .Y(SUM[0]) );
endmodule


module MEM_INTF_DW01_sub_16_1 ( A, B, CI, DIFF, CO );
  input [15:0] A;
  input [15:0] B;
  output [15:0] DIFF;
  input CI;
  output CO;
  wire   n50, n51, n52, n53, n54, n55, n56, n57, n58, n59, n60, n61, n62, n63,
         n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75, n76, n77,
         n78, n79, n80, n81, n82, n83, n84, n85, n86, n87, n88, n89, n90, n91,
         n92, n93, n94, n95, n96, n97, n98, n99, n100, n101, n102, n103, n104,
         n105, n106, n107, n108, n109, n110, n111, n112, n113, n114, n115,
         n116, n117, n118, n119, n120, n121, n122, n123, n124, n125, n126,
         n127, n128, n129, n130, n131, n132, n133, n134, n135, n136, n137,
         n138, n139, n140, n141, n142, n143, n144, n145, n146, n147, n148,
         n149, n150, n151, n152, n153, n154, n155, n156, n157, n158, n159,
         n160, n161, n162, n163, n164, n165, n166, n167, n168, n169, n170,
         n171, n172, n173, n174, n175, n176, n177, n178, n179, n180, n181,
         n182, n183, n184, n185, n186, n187, n188, n189, n190, n191, n192,
         n193, n194, n195, n196, n197, n198, n199, n200, n201, n202, n203,
         n204, n205, n206, n207, n208, n209, n210, n211, n212, n213;

  XNOR2X1 U4 ( .A(n145), .B(n146), .Y(DIFF[12]) );
  OR2X1 U5 ( .A(n186), .B(B[5]), .Y(n88) );
  XNOR2X1 U6 ( .A(n140), .B(n141), .Y(DIFF[13]) );
  AOI31X2 U7 ( .A0(n101), .A1(n50), .A2(n158), .B0(n159), .Y(n157) );
  INVX1 U8 ( .A(n161), .Y(n50) );
  AND2X2 U9 ( .A(n75), .B(n77), .Y(n82) );
  NOR2BX2 U10 ( .AN(n203), .B(n212), .Y(n162) );
  OAI21X1 U11 ( .A0(n62), .A1(n63), .B0(n64), .Y(DIFF[9]) );
  NAND2X1 U12 ( .A(n116), .B(n117), .Y(n109) );
  AND2X2 U13 ( .A(n149), .B(n152), .Y(n154) );
  OR2X2 U14 ( .A(n189), .B(B[13]), .Y(n138) );
  AOI31X1 U15 ( .A0(n109), .A1(n107), .A2(n108), .B0(n101), .Y(n51) );
  INVX1 U16 ( .A(n51), .Y(n105) );
  OAI2BB1X1 U17 ( .A0N(n76), .A1N(n77), .B0(n75), .Y(n74) );
  OAI2BB1X1 U18 ( .A0N(n153), .A1N(n52), .B0(n133), .Y(n134) );
  INVX1 U19 ( .A(n132), .Y(n52) );
  NOR2X1 U20 ( .A(n99), .B(n57), .Y(n106) );
  OAI21X1 U21 ( .A0(n147), .A1(n60), .B0(n148), .Y(n142) );
  OAI2BB1X1 U22 ( .A0N(n92), .A1N(n176), .B0(n175), .Y(n170) );
  AND2X2 U23 ( .A(n167), .B(n72), .Y(n70) );
  OAI2BB1X1 U24 ( .A0N(n204), .A1N(n190), .B0(n130), .Y(n135) );
  AOI22X1 U25 ( .A0(n129), .A1(n130), .B0(n190), .B1(n204), .Y(n127) );
  OR2X2 U26 ( .A(n203), .B(B[4]), .Y(n114) );
  NAND2X1 U27 ( .A(n180), .B(n101), .Y(n87) );
  OAI2BB1X1 U28 ( .A0N(n153), .A1N(n53), .B0(n137), .Y(n140) );
  INVX1 U29 ( .A(n139), .Y(n53) );
  XNOR2X1 U30 ( .A(n126), .B(n123), .Y(DIFF[1]) );
  OR2X2 U31 ( .A(n195), .B(B[12]), .Y(n143) );
  OR2X2 U32 ( .A(n139), .B(n61), .Y(n132) );
  OAI2BB1X1 U33 ( .A0N(n149), .A1N(n153), .B0(n152), .Y(n150) );
  OAI211X4 U34 ( .A0(n66), .A1(n67), .B0(n72), .C0(n68), .Y(n62) );
  NAND2X1 U35 ( .A(n76), .B(n84), .Y(n81) );
  XNOR2X1 U36 ( .A(n109), .B(n115), .Y(DIFF[3]) );
  OAI2BB1X1 U37 ( .A0N(n153), .A1N(n54), .B0(n142), .Y(n145) );
  INVX1 U38 ( .A(n144), .Y(n54) );
  OAI21X1 U39 ( .A0(n89), .A1(n97), .B0(n98), .Y(n80) );
  NAND4BX1 U40 ( .AN(n59), .B(n178), .C(n170), .D(n171), .Y(n155) );
  AND2X2 U41 ( .A(n79), .B(n76), .Y(n95) );
  INVX1 U42 ( .A(n202), .Y(n94) );
  INVX1 U43 ( .A(n208), .Y(n207) );
  INVX1 U44 ( .A(n57), .Y(n180) );
  NAND3X2 U45 ( .A(n108), .B(n180), .C(n174), .Y(n89) );
  NAND2X1 U46 ( .A(B[8]), .B(n173), .Y(n167) );
  INVX1 U47 ( .A(A[8]), .Y(n173) );
  NOR2BX1 U48 ( .AN(B[9]), .B(n200), .Y(n59) );
  OAI2BB1X1 U49 ( .A0N(n138), .A1N(n137), .B0(n179), .Y(n133) );
  INVX1 U50 ( .A(n167), .Y(n71) );
  NAND2X1 U51 ( .A(n196), .B(n206), .Y(n152) );
  AOI21X1 U52 ( .A0(n207), .A1(n94), .B0(n104), .Y(n102) );
  OAI2BB1X1 U53 ( .A0N(n202), .A1N(n208), .B0(n103), .Y(n91) );
  INVX1 U54 ( .A(n212), .Y(n211) );
  INVX1 U55 ( .A(n193), .Y(n192) );
  NAND2X1 U56 ( .A(n134), .B(n135), .Y(n136) );
  NAND2X1 U57 ( .A(B[11]), .B(n199), .Y(n148) );
  INVX1 U58 ( .A(n152), .Y(n147) );
  INVX1 U59 ( .A(n75), .Y(n83) );
  INVX1 U60 ( .A(A[7]), .Y(n184) );
  NAND2X2 U61 ( .A(B[2]), .B(n187), .Y(n55) );
  INVX1 U62 ( .A(B[7]), .Y(n210) );
  NAND2X1 U63 ( .A(n149), .B(n148), .Y(n144) );
  NAND2X1 U64 ( .A(n211), .B(n203), .Y(n174) );
  INVX1 U65 ( .A(n58), .Y(n181) );
  NOR2BX1 U66 ( .AN(B[12]), .B(n194), .Y(n58) );
  NAND2X2 U67 ( .A(n192), .B(n205), .Y(n113) );
  NAND2X1 U68 ( .A(n207), .B(n94), .Y(n124) );
  NAND2X1 U69 ( .A(B[7]), .B(n184), .Y(n75) );
  NAND2X1 U70 ( .A(B[6]), .B(n96), .Y(n79) );
  NAND2X1 U71 ( .A(n181), .B(n143), .Y(n146) );
  NOR2X1 U72 ( .A(n163), .B(n164), .Y(n156) );
  NOR2X1 U73 ( .A(n99), .B(n100), .Y(n98) );
  OAI21X2 U74 ( .A0(n102), .A1(n91), .B0(n55), .Y(n97) );
  NOR2BX1 U75 ( .AN(B[5]), .B(n185), .Y(n57) );
  AOI21X1 U76 ( .A0(n119), .A1(n55), .B0(n120), .Y(n116) );
  INVX1 U77 ( .A(n201), .Y(n200) );
  INVX1 U78 ( .A(B[4]), .Y(n212) );
  NAND2X1 U79 ( .A(B[3]), .B(n193), .Y(n108) );
  NAND2BX1 U80 ( .AN(n144), .B(n181), .Y(n139) );
  NAND2X1 U81 ( .A(n165), .B(n166), .Y(n68) );
  NOR2X1 U82 ( .A(n83), .B(n71), .Y(n165) );
  INVX1 U83 ( .A(n125), .Y(n119) );
  NAND2X1 U84 ( .A(n179), .B(n138), .Y(n141) );
  AOI21X1 U85 ( .A0(n123), .A1(n124), .B0(n119), .Y(n122) );
  OAI21X1 U86 ( .A0(B[0]), .A1(n177), .B0(n123), .Y(DIFF[0]) );
  INVX1 U87 ( .A(B[1]), .Y(n208) );
  INVX1 U88 ( .A(B[10]), .Y(n206) );
  INVX1 U89 ( .A(B[3]), .Y(n205) );
  INVX1 U90 ( .A(B[6]), .Y(n213) );
  INVX1 U91 ( .A(B[2]), .Y(n209) );
  AND2X2 U92 ( .A(n92), .B(n93), .Y(n56) );
  NAND2X1 U93 ( .A(A[2]), .B(n209), .Y(n103) );
  INVX1 U94 ( .A(n59), .Y(n183) );
  NAND3X2 U95 ( .A(n155), .B(n156), .C(n157), .Y(n153) );
  INVX1 U96 ( .A(n197), .Y(n196) );
  NAND3X2 U97 ( .A(n172), .B(n167), .C(n78), .Y(n67) );
  OAI21X2 U98 ( .A0(n134), .A1(n135), .B0(n136), .Y(DIFF[14]) );
  INVX1 U99 ( .A(n61), .Y(n179) );
  NAND2X2 U100 ( .A(B[0]), .B(n177), .Y(n123) );
  NAND2X1 U101 ( .A(B[0]), .B(n177), .Y(n92) );
  INVX1 U102 ( .A(A[6]), .Y(n96) );
  INVX1 U103 ( .A(n186), .Y(n185) );
  INVX4 U104 ( .A(n153), .Y(n131) );
  XOR2X1 U105 ( .A(n150), .B(n151), .Y(DIFF[11]) );
  NOR2X1 U106 ( .A(n67), .B(n160), .Y(n159) );
  INVX1 U107 ( .A(n88), .Y(n99) );
  INVX1 U108 ( .A(n80), .Y(n66) );
  NOR2X1 U109 ( .A(n89), .B(n67), .Y(n171) );
  BUFX1 U110 ( .A(n108), .Y(n182) );
  OAI21X1 U111 ( .A0(n56), .A1(n91), .B0(n55), .Y(n90) );
  NAND2X1 U112 ( .A(B[7]), .B(n184), .Y(n78) );
  NAND2X1 U113 ( .A(B[10]), .B(n197), .Y(n149) );
  NAND2X1 U114 ( .A(B[14]), .B(n191), .Y(n130) );
  NAND2X1 U115 ( .A(A[8]), .B(n168), .Y(n72) );
  NAND2X1 U116 ( .A(A[7]), .B(n210), .Y(n77) );
  NAND2X1 U117 ( .A(n202), .B(n208), .Y(n125) );
  NAND2X1 U118 ( .A(A[6]), .B(n213), .Y(n76) );
  NAND2X1 U119 ( .A(n200), .B(n169), .Y(n65) );
  NAND2X1 U120 ( .A(n211), .B(n203), .Y(n107) );
  INVX1 U121 ( .A(n199), .Y(n198) );
  XOR2X1 U122 ( .A(B[15]), .B(A[15]), .Y(n128) );
  INVX1 U123 ( .A(n195), .Y(n194) );
  INVX1 U124 ( .A(n189), .Y(n188) );
  INVX1 U125 ( .A(n191), .Y(n190) );
  INVX1 U126 ( .A(n87), .Y(n100) );
  OAI2BB1X1 U127 ( .A0N(n143), .A1N(n142), .B0(n181), .Y(n137) );
  AOI21X1 U128 ( .A0(n109), .A1(n182), .B0(n112), .Y(n111) );
  INVX1 U129 ( .A(n113), .Y(n112) );
  OAI21X1 U130 ( .A0(n66), .A1(n73), .B0(n74), .Y(n69) );
  NAND2X1 U131 ( .A(n78), .B(n79), .Y(n73) );
  NOR2BX1 U132 ( .AN(n148), .B(n60), .Y(n151) );
  OAI21X1 U133 ( .A0(n131), .A1(n132), .B0(n133), .Y(n129) );
  NAND2X1 U134 ( .A(n124), .B(n125), .Y(n126) );
  NAND2X1 U135 ( .A(n182), .B(n113), .Y(n115) );
  NAND2X1 U136 ( .A(n65), .B(n183), .Y(n63) );
  NAND2X1 U137 ( .A(n99), .B(n183), .Y(n160) );
  NAND2X1 U138 ( .A(n183), .B(n180), .Y(n161) );
  AOI21X1 U139 ( .A0(n72), .A1(n68), .B0(n59), .Y(n164) );
  NAND2X1 U140 ( .A(n55), .B(n103), .Y(n121) );
  OAI21X1 U141 ( .A0(n85), .A1(n86), .B0(n79), .Y(n84) );
  NAND2X1 U142 ( .A(n87), .B(n88), .Y(n86) );
  NOR2X1 U143 ( .A(n89), .B(n90), .Y(n85) );
  NAND2X1 U144 ( .A(n107), .B(n114), .Y(n110) );
  INVX1 U145 ( .A(n67), .Y(n158) );
  INVX1 U146 ( .A(n65), .Y(n163) );
  NAND2X1 U147 ( .A(n62), .B(n63), .Y(n64) );
  XOR2X1 U148 ( .A(n69), .B(n70), .Y(DIFF[8]) );
  XOR2X1 U149 ( .A(n81), .B(n82), .Y(DIFF[7]) );
  XOR2X1 U150 ( .A(n80), .B(n95), .Y(DIFF[6]) );
  XOR2X1 U151 ( .A(n105), .B(n106), .Y(DIFF[5]) );
  XOR2X1 U152 ( .A(n110), .B(n111), .Y(DIFF[4]) );
  XOR2X1 U153 ( .A(n121), .B(n122), .Y(DIFF[2]) );
  NAND2X1 U154 ( .A(B[6]), .B(n96), .Y(n172) );
  XOR2X1 U155 ( .A(n127), .B(n128), .Y(DIFF[15]) );
  NAND3X1 U156 ( .A(n92), .B(n55), .C(n118), .Y(n117) );
  INVX1 U157 ( .A(n103), .Y(n120) );
  INVX1 U158 ( .A(B[9]), .Y(n169) );
  NAND2X1 U159 ( .A(n207), .B(n94), .Y(n93) );
  OAI2BB1X1 U160 ( .A0N(A[6]), .A1N(n213), .B0(n77), .Y(n166) );
  INVX1 U161 ( .A(B[8]), .Y(n168) );
  NOR2BX2 U162 ( .AN(n198), .B(B[11]), .Y(n60) );
  NAND2X1 U163 ( .A(n207), .B(n94), .Y(n118) );
  AOI21X1 U164 ( .A0(n202), .A1(n208), .B0(n120), .Y(n175) );
  NAND2X1 U165 ( .A(n207), .B(n94), .Y(n176) );
  NAND2X1 U166 ( .A(B[2]), .B(n187), .Y(n178) );
  INVX1 U167 ( .A(n92), .Y(n104) );
  INVX1 U168 ( .A(A[4]), .Y(n203) );
  NOR2BX1 U169 ( .AN(B[13]), .B(n188), .Y(n61) );
  INVX1 U170 ( .A(B[14]), .Y(n204) );
  INVX1 U171 ( .A(A[9]), .Y(n201) );
  INVX1 U172 ( .A(A[10]), .Y(n197) );
  INVX1 U173 ( .A(A[11]), .Y(n199) );
  INVX1 U174 ( .A(A[12]), .Y(n195) );
  INVX1 U175 ( .A(A[13]), .Y(n189) );
  INVX1 U176 ( .A(A[14]), .Y(n191) );
  INVX1 U177 ( .A(A[2]), .Y(n187) );
  INVX1 U178 ( .A(A[5]), .Y(n186) );
  BUFX3 U179 ( .A(A[1]), .Y(n202) );
  INVX1 U180 ( .A(A[3]), .Y(n193) );
  INVX1 U181 ( .A(A[0]), .Y(n177) );
  XOR2X1 U182 ( .A(n153), .B(n154), .Y(DIFF[10]) );
  OAI21X4 U183 ( .A0(n162), .A1(n113), .B0(n114), .Y(n101) );
endmodule


module MEM_INTF_DW01_add_16_1 ( A, B, CI, SUM, CO );
  input [15:0] A;
  input [15:0] B;
  output [15:0] SUM;
  input CI;
  output CO;
  wire   n49, n50, n51, n52, n53, n54, n55, n56, n57, n58, n59, n60, n61, n62,
         n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75, n76,
         n77, n78, n79, n80, n81, n82, n83, n84, n85, n86, n87, n88, n89, n90,
         n91, n92, n93, n94, n95, n96, n97, n98, n99, n100, n101, n102, n103,
         n104, n105, n106, n107, n108, n109, n110, n111, n112, n113, n114,
         n115, n116, n117, n118, n119, n120, n121, n122, n123, n124, n125,
         n126, n127, n128, n129, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n144, n145, n146, n147,
         n148, n149, n150, n151, n152, n153, n154, n155, n156, n157, n158,
         n159, n160, n161, n162, n163, n164, n165, n166, n167, n168, n169,
         n170, n171, n172, n173, n174, n175, n176, n177, n178, n179, n180,
         n181, n182, n183, n184, n185, n186, n187, n188, n189, n190, n191,
         n192, n193, n194, n195, n196, n197, n198, n199, n200, n201, n202,
         n203, n204, n205, n206, n207, n208, n209, n210, n211, n212, n213,
         n214, n215, n216, n217, n218, n219, n220;

  NAND3X1 U5 ( .A(n67), .B(n99), .C(n68), .Y(n49) );
  XNOR2X1 U6 ( .A(n153), .B(n154), .Y(SUM[13]) );
  AND3X2 U7 ( .A(n110), .B(n49), .C(n50), .Y(n104) );
  INVX1 U8 ( .A(n111), .Y(n50) );
  XNOR2X1 U9 ( .A(n160), .B(n161), .Y(SUM[12]) );
  AND2X2 U10 ( .A(n94), .B(n93), .Y(n105) );
  XNOR2X1 U11 ( .A(n166), .B(n167), .Y(SUM[11]) );
  AOI2BB1X1 U12 ( .A0N(n183), .A1N(n184), .B0(n182), .Y(n180) );
  XNOR2X1 U13 ( .A(n103), .B(n85), .Y(SUM[6]) );
  AOI21X1 U14 ( .A0(n155), .A1(n156), .B0(n157), .Y(n149) );
  OAI2BB1X1 U15 ( .A0N(n210), .A1N(n186), .B0(n185), .Y(n75) );
  NAND3BX1 U16 ( .AN(n94), .B(n175), .C(n177), .Y(n174) );
  XNOR2X1 U17 ( .A(n51), .B(n113), .Y(SUM[5]) );
  AOI22X1 U18 ( .A0(n116), .A1(n57), .B0(n109), .B1(n107), .Y(n51) );
  OAI21X1 U19 ( .A0(n146), .A1(n55), .B0(n147), .Y(n144) );
  XNOR2X1 U20 ( .A(n80), .B(n81), .Y(SUM[8]) );
  NOR2BX1 U21 ( .AN(n151), .B(n152), .Y(n137) );
  NAND3X1 U22 ( .A(n218), .B(n220), .C(n124), .Y(n123) );
  XNOR2X1 U23 ( .A(n144), .B(n145), .Y(SUM[14]) );
  OR2X2 U24 ( .A(n133), .B(n58), .Y(n56) );
  OAI2BB1X1 U25 ( .A0N(n115), .A1N(n116), .B0(n120), .Y(n117) );
  OAI2BB1X1 U26 ( .A0N(n139), .A1N(n52), .B0(n149), .Y(n153) );
  INVX1 U27 ( .A(n152), .Y(n52) );
  NAND3BX1 U28 ( .AN(n65), .B(n54), .C(n82), .Y(n80) );
  AND2X2 U29 ( .A(n169), .B(n165), .Y(n170) );
  XNOR2X1 U30 ( .A(n117), .B(n118), .Y(SUM[4]) );
  NAND2X1 U31 ( .A(n100), .B(n219), .Y(n126) );
  AND2X1 U32 ( .A(n54), .B(n84), .Y(n87) );
  NAND4BX1 U33 ( .AN(n171), .B(n172), .C(n173), .D(n174), .Y(n53) );
  OAI21X1 U34 ( .A0(n148), .A1(n149), .B0(n150), .Y(n140) );
  NAND2X1 U35 ( .A(B[13]), .B(n202), .Y(n150) );
  NOR2X1 U36 ( .A(n187), .B(n188), .Y(n185) );
  INVX1 U37 ( .A(n177), .Y(n72) );
  NOR3BX1 U38 ( .AN(n107), .B(n114), .C(n72), .Y(n176) );
  OR2X2 U39 ( .A(n208), .B(n206), .Y(n107) );
  NAND2X1 U40 ( .A(n168), .B(n169), .Y(n167) );
  NAND4BX2 U41 ( .AN(n171), .B(n172), .C(n173), .D(n174), .Y(n139) );
  NAND3X1 U42 ( .A(n176), .B(n109), .C(n175), .Y(n173) );
  NAND2X1 U43 ( .A(n178), .B(n179), .Y(n172) );
  NAND2X1 U44 ( .A(n165), .B(n164), .Y(n159) );
  INVX2 U45 ( .A(n139), .Y(n146) );
  OR2X2 U46 ( .A(B[11]), .B(n204), .Y(n164) );
  NAND2X1 U47 ( .A(B[12]), .B(n200), .Y(n158) );
  INVX1 U48 ( .A(n216), .Y(n215) );
  INVX1 U49 ( .A(n140), .Y(n147) );
  NAND2X1 U50 ( .A(n138), .B(n142), .Y(n145) );
  OAI21X2 U51 ( .A0(n146), .A1(n159), .B0(n162), .Y(n160) );
  INVX1 U52 ( .A(n62), .Y(n162) );
  NAND2X1 U53 ( .A(n158), .B(n156), .Y(n161) );
  NAND2X1 U54 ( .A(n164), .B(n163), .Y(n166) );
  NAND3BX1 U55 ( .AN(n101), .B(n122), .C(n123), .Y(n116) );
  BUFX3 U56 ( .A(A[1]), .Y(n220) );
  OR2X2 U57 ( .A(B[9]), .B(A[9]), .Y(n177) );
  INVX1 U58 ( .A(n212), .Y(n211) );
  INVX1 U59 ( .A(n214), .Y(n213) );
  BUFX3 U60 ( .A(A[6]), .Y(n217) );
  NAND2BX1 U61 ( .AN(n159), .B(n156), .Y(n152) );
  INVX1 U62 ( .A(n75), .Y(n175) );
  OR2X2 U63 ( .A(B[3]), .B(n215), .Y(n115) );
  NAND2X1 U64 ( .A(B[2]), .B(A[2]), .Y(n110) );
  NAND2X1 U65 ( .A(n150), .B(n151), .Y(n154) );
  NOR2X1 U66 ( .A(n69), .B(n194), .Y(SUM[0]) );
  OAI21X1 U67 ( .A0(n220), .A1(n218), .B0(n131), .Y(n132) );
  INVX1 U68 ( .A(n85), .Y(n74) );
  NAND2X1 U69 ( .A(B[7]), .B(n213), .Y(n54) );
  AND2X2 U70 ( .A(n196), .B(A[0]), .Y(n69) );
  NAND2X1 U71 ( .A(n133), .B(n58), .Y(n134) );
  NAND2X1 U72 ( .A(n56), .B(n134), .Y(SUM[15]) );
  AND2X2 U73 ( .A(n135), .B(n136), .Y(n58) );
  NAND2BX1 U74 ( .AN(n152), .B(n151), .Y(n55) );
  INVX1 U75 ( .A(n207), .Y(n206) );
  INVX1 U76 ( .A(n84), .Y(n88) );
  AND2X1 U77 ( .A(n211), .B(B[10]), .Y(n64) );
  AND2X1 U78 ( .A(n115), .B(n107), .Y(n57) );
  AND2X1 U79 ( .A(n112), .B(n199), .Y(n63) );
  NAND2X1 U80 ( .A(n119), .B(n120), .Y(n109) );
  NAND2X1 U81 ( .A(n83), .B(n89), .Y(n103) );
  NAND2X1 U82 ( .A(n112), .B(n199), .Y(n124) );
  INVX1 U83 ( .A(n110), .Y(n101) );
  NAND2X1 U84 ( .A(B[5]), .B(A[5]), .Y(n94) );
  OR2X1 U85 ( .A(B[6]), .B(n217), .Y(n83) );
  NOR2X1 U86 ( .A(n217), .B(B[6]), .Y(n188) );
  NAND2X1 U87 ( .A(B[3]), .B(n215), .Y(n120) );
  NAND2X1 U88 ( .A(B[8]), .B(A[8]), .Y(n79) );
  NAND2X1 U89 ( .A(B[6]), .B(n217), .Y(n89) );
  NAND2X1 U90 ( .A(n208), .B(n206), .Y(n119) );
  NAND2X1 U91 ( .A(B[14]), .B(n197), .Y(n142) );
  NAND2X1 U92 ( .A(B[11]), .B(n204), .Y(n163) );
  NAND2X1 U93 ( .A(B[10]), .B(n211), .Y(n169) );
  INVX2 U94 ( .A(n220), .Y(n100) );
  INVX1 U95 ( .A(n219), .Y(n218) );
  NOR2X1 U96 ( .A(n191), .B(n192), .Y(n189) );
  AND2X1 U97 ( .A(n66), .B(n84), .Y(n65) );
  AND2X1 U98 ( .A(n217), .B(B[6]), .Y(n66) );
  NAND2X1 U99 ( .A(B[9]), .B(A[9]), .Y(n73) );
  INVX1 U100 ( .A(B[2]), .Y(n112) );
  XOR2X1 U101 ( .A(B[3]), .B(n215), .Y(n121) );
  INVX1 U102 ( .A(A[8]), .Y(n186) );
  OAI21X1 U103 ( .A0(n59), .A1(n60), .B0(n131), .Y(n129) );
  NOR2X1 U104 ( .A(n220), .B(n218), .Y(n59) );
  NAND2X1 U105 ( .A(A[0]), .B(n196), .Y(n60) );
  INVX1 U106 ( .A(B[1]), .Y(n219) );
  INVX1 U107 ( .A(n201), .Y(n200) );
  AND2X1 U108 ( .A(n196), .B(A[0]), .Y(n67) );
  OR2X1 U109 ( .A(n220), .B(B[1]), .Y(n68) );
  NAND3X1 U110 ( .A(n61), .B(n98), .C(n99), .Y(n96) );
  AND2X1 U111 ( .A(n196), .B(A[0]), .Y(n61) );
  INVX1 U112 ( .A(n209), .Y(n208) );
  INVX1 U113 ( .A(n205), .Y(n204) );
  INVX1 U114 ( .A(n203), .Y(n202) );
  INVX1 U115 ( .A(n198), .Y(n197) );
  OAI2BB1X1 U116 ( .A0N(n164), .A1N(n64), .B0(n163), .Y(n62) );
  OAI21X1 U117 ( .A0(n189), .A1(n190), .B0(n73), .Y(n171) );
  INVX1 U118 ( .A(n151), .Y(n148) );
  NAND3X2 U119 ( .A(n115), .B(n108), .C(n107), .Y(n97) );
  INVX1 U120 ( .A(n158), .Y(n157) );
  NAND3X1 U121 ( .A(n107), .B(n108), .C(n109), .Y(n93) );
  NAND2X1 U122 ( .A(n210), .B(n186), .Y(n78) );
  OAI21X1 U123 ( .A0(n74), .A1(n75), .B0(n76), .Y(n70) );
  OAI21X1 U124 ( .A0(n65), .A1(n77), .B0(n78), .Y(n76) );
  NAND2X1 U125 ( .A(n79), .B(n54), .Y(n77) );
  NOR2BX1 U126 ( .AN(n73), .B(n72), .Y(n71) );
  NAND2X1 U127 ( .A(n119), .B(n107), .Y(n118) );
  NAND2X1 U128 ( .A(n124), .B(n110), .Y(n128) );
  NAND3X1 U129 ( .A(n83), .B(n84), .C(n85), .Y(n82) );
  NAND2X1 U130 ( .A(n79), .B(n78), .Y(n81) );
  NAND2X1 U131 ( .A(n139), .B(n165), .Y(n168) );
  NAND2X1 U132 ( .A(n112), .B(n199), .Y(n99) );
  NOR2X1 U133 ( .A(n101), .B(n102), .Y(n95) );
  NOR3BX1 U134 ( .AN(n218), .B(n63), .C(n100), .Y(n102) );
  INVX1 U135 ( .A(n94), .Y(n106) );
  INVX1 U136 ( .A(n108), .Y(n114) );
  NOR2X1 U137 ( .A(n180), .B(n181), .Y(n179) );
  NOR2X1 U138 ( .A(n97), .B(n75), .Y(n178) );
  OAI2BB1X1 U139 ( .A0N(n112), .A1N(n199), .B0(n177), .Y(n181) );
  NAND2X1 U140 ( .A(n177), .B(n78), .Y(n190) );
  INVX1 U141 ( .A(n142), .Y(n141) );
  AOI21X1 U142 ( .A0(n140), .A1(n138), .B0(n141), .Y(n135) );
  NAND3X1 U143 ( .A(n137), .B(n138), .C(n53), .Y(n136) );
  XOR2X1 U144 ( .A(n139), .B(n170), .Y(SUM[10]) );
  XNOR2X1 U145 ( .A(n69), .B(n132), .Y(SUM[1]) );
  XOR2X1 U146 ( .A(n70), .B(n71), .Y(SUM[9]) );
  XOR2X1 U147 ( .A(n116), .B(n121), .Y(SUM[3]) );
  XOR2X1 U148 ( .A(n86), .B(n87), .Y(SUM[7]) );
  NOR2X1 U149 ( .A(n106), .B(n114), .Y(n113) );
  OAI21X1 U150 ( .A0(n128), .A1(n129), .B0(n130), .Y(SUM[2]) );
  NAND2X1 U151 ( .A(n128), .B(n129), .Y(n130) );
  NAND3BX1 U152 ( .AN(n125), .B(n126), .C(n127), .Y(n122) );
  NAND2X1 U153 ( .A(n112), .B(n199), .Y(n127) );
  OR2X2 U154 ( .A(B[12]), .B(n200), .Y(n156) );
  OR2X2 U155 ( .A(B[14]), .B(n197), .Y(n138) );
  NOR2X1 U156 ( .A(n213), .B(B[7]), .Y(n187) );
  OAI2BB1X1 U157 ( .A0N(n164), .A1N(n64), .B0(n163), .Y(n155) );
  OR2X2 U158 ( .A(B[10]), .B(n211), .Y(n165) );
  OR2X2 U159 ( .A(B[13]), .B(n202), .Y(n151) );
  OR2X2 U160 ( .A(B[7]), .B(n213), .Y(n84) );
  OR2X2 U161 ( .A(B[5]), .B(A[5]), .Y(n108) );
  NAND2X1 U162 ( .A(n79), .B(n54), .Y(n192) );
  NOR2X1 U163 ( .A(n88), .B(n193), .Y(n191) );
  NAND2X1 U164 ( .A(n217), .B(B[6]), .Y(n193) );
  OAI2BB1X1 U165 ( .A0N(n218), .A1N(n220), .B0(n110), .Y(n182) );
  NOR2X1 U166 ( .A(n220), .B(B[1]), .Y(n183) );
  NAND2X1 U167 ( .A(B[1]), .B(n220), .Y(n131) );
  NAND2X1 U168 ( .A(n89), .B(n90), .Y(n86) );
  OAI21X1 U169 ( .A0(n91), .A1(n92), .B0(n83), .Y(n90) );
  NAND2X1 U170 ( .A(n93), .B(n94), .Y(n92) );
  AOI21X1 U171 ( .A0(n95), .A1(n96), .B0(n97), .Y(n91) );
  OAI2BB1X1 U172 ( .A0N(n195), .A1N(B[15]), .B0(n143), .Y(n133) );
  OR2X2 U173 ( .A(n195), .B(B[15]), .Y(n143) );
  INVX1 U174 ( .A(A[3]), .Y(n216) );
  INVX1 U175 ( .A(A[10]), .Y(n212) );
  NAND2X1 U176 ( .A(n219), .B(n100), .Y(n98) );
  INVX1 U177 ( .A(B[4]), .Y(n209) );
  INVX1 U178 ( .A(B[8]), .Y(n210) );
  INVX1 U179 ( .A(A[4]), .Y(n207) );
  INVX1 U180 ( .A(A[11]), .Y(n205) );
  INVX1 U181 ( .A(A[12]), .Y(n201) );
  INVX1 U182 ( .A(A[13]), .Y(n203) );
  INVX1 U183 ( .A(A[14]), .Y(n198) );
  INVX1 U184 ( .A(A[2]), .Y(n199) );
  INVX1 U185 ( .A(A[7]), .Y(n214) );
  BUFX3 U186 ( .A(B[0]), .Y(n196) );
  NAND2X1 U187 ( .A(A[0]), .B(n196), .Y(n184) );
  NAND2X1 U188 ( .A(n196), .B(A[0]), .Y(n125) );
  NOR2X1 U189 ( .A(A[0]), .B(n196), .Y(n194) );
  INVX1 U190 ( .A(A[15]), .Y(n195) );
  OAI21X4 U191 ( .A0(n104), .A1(n97), .B0(n105), .Y(n85) );
  NOR3BX4 U192 ( .AN(B[1]), .B(n63), .C(n100), .Y(n111) );
endmodule


module FETCH_FSM ( TRANS_EN, PDWN, IDLE, POR, LAST_CYCLE, MOVC_XROM, 
        xrom_code_en, ALEOFF, inter_LCALL, pre_idle, pre_pdwn_idle, MOVX_RI, 
        MOVX_DPI, MOVX_RI_A, MOVX_DPI_A, ACC_WR_XRAM, ACC_RD_XRAM, CLK, RESET, 
        CS1, CS2, CS3, CS4, LS1, LS2, LS3, LS4, CYCLE2, CYCLE3, CYCLE4, BYTE2, 
        BYTE3, PC_INC_EN, IR_EN, PSEN_B_X, PSEN_B_I, ALE_B_X, ALE_B_I, 
        XRAM_CE_B, XRAM_WR_B, XRAM_RD_B );
  input PDWN, IDLE, POR, MOVC_XROM, xrom_code_en, ALEOFF, inter_LCALL,
         pre_idle, pre_pdwn_idle, MOVX_RI, MOVX_DPI, MOVX_RI_A, MOVX_DPI_A,
         CLK, RESET, CYCLE2, CYCLE3, CYCLE4, BYTE2, BYTE3;
  output TRANS_EN, LAST_CYCLE, ACC_WR_XRAM, ACC_RD_XRAM, CS1, CS2, CS3, CS4,
         LS1, LS2, LS3, LS4, PC_INC_EN, IR_EN, PSEN_B_X, PSEN_B_I, ALE_B_X,
         ALE_B_I, XRAM_CE_B, XRAM_WR_B, XRAM_RD_B;
  wire   N25, BCR_1_, PSEN_B_next, PSEN_TMP, RST_d0, ALE_tmp1, ALE_new, CS2_d1,
         CS2_d3, CS2_d2, N114, N116, N118, N126, N127, n2, n3, n4, n5, n6, n7,
         n9, n10, n12, n16, n21, n31, n32, n33, n34, n35, n36, n38, n43, n44,
         n45, n48, n60, n62, n63, n64, n65, n66, n67, n68, n70, n73, n74, n75,
         n76, n77, n78, n79, n80, n81, n82, n83, n84, n85, n86, n87, n88, n89,
         n91, n92, n93, n94, n95, n96, n97, n98, n99, n100, n101, n102, n103,
         n104, n105, n106, n107, n108, n109, n110, n111, n112, n113, n1140,
         n115, n1160, n117, n1180, n119, n120, n121, n122, n123, n124, n125,
         n1260, n1270, n128, n129, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139;
  wire   [1:0] BS;
  wire   [2:0] LSR;
  wire   [2:0] MCR;
  wire   [2:0] LS_next;

  AOI221X4 U4 ( .A0(LS4), .A1(n6), .B0(PSEN_TMP), .B1(n7), .C0(RESET), .Y(n5)
         );
  OAI32X4 U33 ( .A0(n32), .A1(pre_pdwn_idle), .A2(RESET), .B0(RESET), .B1(n33), 
        .Y(LS_next[2]) );
  NAND3X1 I104 ( .A(n135), .B(n1180), .C(LSR[2]), .Y(n31) );
  AOI2BB1X1 I105 ( .A0N(n139), .A1N(n120), .B0(BS[1]), .Y(n76) );
  INVX1 I106 ( .A(n76), .Y(n1160) );
  NAND2X1 I107 ( .A(MCR[0]), .B(n130), .Y(n93) );
  NAND2X1 I108 ( .A(n128), .B(n129), .Y(n139) );
  OAI21X1 I109 ( .A0(n112), .A1(n94), .B0(n77), .Y(n85) );
  NAND3BX1 I110 ( .AN(LS4), .B(n32), .C(n48), .Y(n21) );
  NAND2X1 I111 ( .A(MCR[2]), .B(n130), .Y(n128) );
  NAND3BX1 I112 ( .AN(n119), .B(n137), .C(n101), .Y(n110) );
  XNOR2X1 I113 ( .A(n98), .B(n119), .Y(n97) );
  AOI211X1 I114 ( .A0(LSR[1]), .A1(LSR[2]), .B0(n34), .C0(LSR[0]), .Y(
        LS_next[0]) );
  AOI21X1 I115 ( .A0(n31), .A1(n7), .B0(n110), .Y(n109) );
  NAND3BX2 I116 ( .AN(LSR[2]), .B(n135), .C(LSR[1]), .Y(n7) );
  OAI211X1 I117 ( .A0(n78), .A1(n80), .B0(n91), .C0(n105), .Y(n62) );
  INVX1 I118 ( .A(n84), .Y(n78) );
  NOR2X1 I119 ( .A(xrom_code_en), .B(MOVC_XROM), .Y(n9) );
  OAI211X1 I120 ( .A0(n79), .A1(n81), .B0(n91), .C0(n96), .Y(n64) );
  INVX1 I121 ( .A(n84), .Y(n79) );
  AOI21X1 I122 ( .A0(n35), .A1(n7), .B0(n34), .Y(LS_next[1]) );
  NOR2X1 I123 ( .A(xrom_code_en), .B(PSEN_TMP), .Y(PSEN_B_I) );
  NAND2X2 I124 ( .A(n82), .B(n133), .Y(n94) );
  INVX1 I125 ( .A(CYCLE4), .Y(n133) );
  OAI2BB1X1 I126 ( .A0N(n94), .A1N(n93), .B0(n132), .Y(n101) );
  INVX2 I127 ( .A(n35), .Y(LS1) );
  AOI21X1 I128 ( .A0(n93), .A1(n94), .B0(n85), .Y(CS1) );
  INVX2 I129 ( .A(n7), .Y(LS2) );
  NOR2BX2 I130 ( .AN(n101), .B(n86), .Y(CS2) );
  INVX2 I131 ( .A(MCR[1]), .Y(n113) );
  NOR2X1 I132 ( .A(n99), .B(n137), .Y(CS4) );
  NAND2X2 I133 ( .A(n137), .B(n99), .Y(n86) );
  NAND3X1 I134 ( .A(MCR[2]), .B(n113), .C(MCR[0]), .Y(n130) );
  NOR2X1 I135 ( .A(CYCLE2), .B(CYCLE3), .Y(n112) );
  AOI21X1 I136 ( .A0(n48), .A1(n110), .B0(n122), .Y(n121) );
  INVX2 I137 ( .A(n119), .Y(n99) );
  BUFX3 I138 ( .A(n120), .Y(n137) );
  NOR2X1 I139 ( .A(CYCLE2), .B(CYCLE3), .Y(n131) );
  INVX2 I140 ( .A(POR), .Y(n60) );
  DFFRHQX2 LSR_reg_2_ ( .D(LS_next[2]), .CK(CLK), .RN(n60), .Q(LSR[2]) );
  DFFTRX2 ACC_RD_XRAM_reg ( .D(n73), .CK(CLK), .RN(n74), .Q(ACC_RD_XRAM) );
  OR3X1 I141 ( .A(pre_pdwn_idle), .B(pre_idle), .C(RESET), .Y(n34) );
  DFFSX1 MCR_reg_0_ ( .D(n62), .CK(CLK), .SN(n60), .Q(MCR[0]), .QN(n80) );
  DFFRHQX1 LSR_reg_0_ ( .D(LS_next[0]), .CK(CLK), .RN(n60), .Q(LSR[0]) );
  DFFRHQX2 LSR_reg_1_ ( .D(LS_next[1]), .CK(CLK), .RN(n60), .Q(LSR[1]) );
  INVX1 I142 ( .A(LSR[1]), .Y(n1180) );
  AND3X2 I143 ( .A(n80), .B(n113), .C(n81), .Y(n82) );
  DFFRX1 BCR_reg_1_ ( .D(n66), .CK(CLK), .RN(n60), .Q(BCR_1_), .QN(n83) );
  AND2X2 I144 ( .A(n89), .B(n136), .Y(n84) );
  INVX4 I145 ( .A(n32), .Y(LS3) );
  DFFRHQX2 IR_EN_reg ( .D(N25), .CK(CLK), .RN(n60), .Q(IR_EN) );
  OAI21X1 I146 ( .A0(n87), .A1(n125), .B0(n111), .Y(n95) );
  AND2X2 I147 ( .A(n1140), .B(n115), .Y(n87) );
  NOR2X2 I148 ( .A(IR_EN), .B(n106), .Y(n38) );
  DFFHQX1 CS2_d2_reg ( .D(CS2_d1), .CK(CLK), .Q(CS2_d2) );
  INVX1 I149 ( .A(CYCLE3), .Y(n1260) );
  NAND2X1 I150 ( .A(n128), .B(n129), .Y(n119) );
  NAND3X1 I151 ( .A(n80), .B(n113), .C(CYCLE4), .Y(n129) );
  INVX1 I152 ( .A(n89), .Y(TRANS_EN) );
  INVX1 I153 ( .A(n137), .Y(n100) );
  INVX1 I154 ( .A(LS4), .Y(n89) );
  NAND2X1 I155 ( .A(n83), .B(n134), .Y(BS[1]) );
  OAI2BB1X1 I156 ( .A0N(CS2_d3), .A1N(n45), .B0(ALE_new), .Y(ALE_B_I) );
  INVX1 I157 ( .A(pre_pdwn_idle), .Y(n6) );
  INVX1 I158 ( .A(n45), .Y(n3) );
  DFFHQX1 XRAM_WR_B_reg ( .D(N114), .CK(CLK), .Q(XRAM_WR_B) );
  DFFHQX1 XRAM_RD_B_reg ( .D(N116), .CK(CLK), .Q(XRAM_RD_B) );
  NAND2X1 I159 ( .A(n110), .B(n95), .Y(n107) );
  NAND2X1 I160 ( .A(n121), .B(n75), .Y(N114) );
  NAND2X1 I161 ( .A(n121), .B(n74), .Y(N116) );
  INVX1 I162 ( .A(n95), .Y(LAST_CYCLE) );
  NOR2X1 I163 ( .A(n87), .B(n125), .Y(n104) );
  OR2X2 I164 ( .A(n75), .B(n74), .Y(n45) );
  NAND2X1 I165 ( .A(n100), .B(n101), .Y(n98) );
  DFFHQX1 XRAM_CE_B_reg ( .D(N118), .CK(CLK), .Q(XRAM_CE_B) );
  DFFTRX1 ACC_WR_XRAM_reg ( .D(n73), .CK(CLK), .RN(n75), .Q(ACC_WR_XRAM) );
  NAND3X1 I166 ( .A(n93), .B(n1260), .C(CYCLE2), .Y(n132) );
  INVX1 I167 ( .A(n106), .Y(PC_INC_EN) );
  NAND2X1 I168 ( .A(CYCLE2), .B(n1260), .Y(n115) );
  NOR2X2 I169 ( .A(n123), .B(n124), .Y(CS3) );
  OAI21X1 I170 ( .A0(n125), .A1(n115), .B0(n99), .Y(n124) );
  NAND2X2 I171 ( .A(n137), .B(n1270), .Y(n123) );
  INVX1 I172 ( .A(n93), .Y(n125) );
  NAND2X1 I173 ( .A(n94), .B(n93), .Y(n1270) );
  INVX1 I174 ( .A(n85), .Y(n111) );
  INVX1 I175 ( .A(n48), .Y(n138) );
  OAI2BB1X1 I176 ( .A0N(LS3), .A1N(n107), .B0(n108), .Y(n73) );
  NOR2X1 I177 ( .A(n109), .B(n138), .Y(n108) );
  INVX1 I178 ( .A(n94), .Y(n1140) );
  NAND2X1 I179 ( .A(n91), .B(n21), .Y(n122) );
  OR3X2 I180 ( .A(RESET), .B(n3), .C(n16), .Y(N118) );
  INVX1 I181 ( .A(n73), .Y(n16) );
  NOR3X1 I182 ( .A(n137), .B(n139), .C(n32), .Y(N25) );
  OR2X2 I183 ( .A(MOVX_DPI_A), .B(MOVX_RI_A), .Y(n75) );
  OR2X2 I184 ( .A(MOVX_DPI), .B(MOVX_RI), .Y(n74) );
  AND2X2 I185 ( .A(LS4), .B(n136), .Y(n88) );
  INVX2 I186 ( .A(RESET), .Y(n91) );
  NAND3BX2 I187 ( .AN(pre_pdwn_idle), .B(n1160), .C(n117), .Y(n106) );
  NOR2X1 I188 ( .A(inter_LCALL), .B(n31), .Y(n117) );
  OAI21X1 I189 ( .A0(n131), .A1(n94), .B0(n113), .Y(n120) );
  DFFSX1 MCR_reg_2_ ( .D(n64), .CK(CLK), .SN(n60), .Q(MCR[2]), .QN(n81) );
  DFFRX1 MCR_reg_1_ ( .D(n63), .CK(CLK), .RN(n60), .Q(MCR[1]), .QN(n77) );
  INVX2 I190 ( .A(n31), .Y(LS4) );
  INVX1 I191 ( .A(pre_idle), .Y(n33) );
  AND3X2 U102 ( .A(n67), .B(n136), .C(n91), .Y(n65) );
  OAI2BB2X1 I192 ( .A0N(N126), .A1N(n38), .B0(n38), .B1(n92), .Y(n67) );
  INVX1 I193 ( .A(BS[0]), .Y(N126) );
  AND3X2 U103 ( .A(n68), .B(n136), .C(n91), .Y(n66) );
  OAI2BB2X1 I194 ( .A0N(N127), .A1N(n38), .B0(n38), .B1(n83), .Y(n68) );
  XNOR2X1 I195 ( .A(BS[1]), .B(BS[0]), .Y(N127) );
  DFFRX1 BCR_reg_0_ ( .D(n65), .CK(CLK), .RN(n60), .QN(n92) );
  NAND2X1 I196 ( .A(n88), .B(n101), .Y(n105) );
  NAND2X1 I197 ( .A(n97), .B(n88), .Y(n96) );
  DFFHQX1 PSEN_TMP_reg ( .D(PSEN_B_next), .CK(CLK), .Q(PSEN_TMP) );
  OR3X2 I198 ( .A(LSR[2]), .B(LSR[1]), .C(n135), .Y(n35) );
  OR3X2 I199 ( .A(LSR[2]), .B(n1180), .C(n135), .Y(n32) );
  INVX1 I200 ( .A(LSR[0]), .Y(n135) );
  OAI31X1 I201 ( .A0(n2), .A1(n3), .A2(n4), .B0(n5), .Y(PSEN_B_next) );
  INVX1 I202 ( .A(n107), .Y(n2) );
  OAI21X1 I203 ( .A0(BYTE2), .A1(BYTE3), .B0(n92), .Y(n134) );
  OAI221X4 I204 ( .A0(BYTE2), .A1(BCR_1_), .B0(BCR_1_), .B1(n36), .C0(n92), 
        .Y(BS[0]) );
  INVX1 I205 ( .A(BYTE3), .Y(n36) );
  AND3X2 U101 ( .A(n70), .B(n136), .C(n91), .Y(n63) );
  OAI2BB1X1 I206 ( .A0N(MCR[1]), .A1N(n84), .B0(n102), .Y(n70) );
  NAND2X1 I207 ( .A(n103), .B(n88), .Y(n102) );
  XNOR2X1 I208 ( .A(n100), .B(n104), .Y(n103) );
  INVX1 I209 ( .A(IR_EN), .Y(n136) );
  OR2X2 I210 ( .A(LS4), .B(RST_d0), .Y(ALE_tmp1) );
  INVX1 I211 ( .A(PSEN_TMP), .Y(n4) );
  OAI31X1 I212 ( .A0(n9), .A1(PSEN_TMP), .A2(IDLE), .B0(n10), .Y(PSEN_B_X) );
  INVX1 I213 ( .A(PDWN), .Y(n10) );
  INVX1 I214 ( .A(MOVC_XROM), .Y(n12) );
  AND2X2 I215 ( .A(n43), .B(ALE_B_I), .Y(ALE_B_X) );
  AOI31X1 I216 ( .A0(ALEOFF), .A1(n12), .A2(n3), .B0(n44), .Y(n43) );
  OR2X2 I217 ( .A(PDWN), .B(IDLE), .Y(n44) );
  DFFHQX1 RST_d0_reg ( .D(RESET), .CK(CLK), .Q(RST_d0) );
  DFFHQX1 ALE_new_reg ( .D(ALE_tmp1), .CK(CLK), .Q(ALE_new) );
  DFFHQX1 CS2_d3_reg ( .D(CS2_d2), .CK(CLK), .Q(CS2_d3) );
  DFFHQX1 CS2_d1_reg ( .D(CS2), .CK(CLK), .Q(CS2_d1) );
  OAI2BB1X1 I218 ( .A0N(n7), .A1N(n35), .B0(LAST_CYCLE), .Y(n48) );
  DFFX4 RST_d1_reg ( .D(RST_d0), .CK(CLK) );
endmodule


module IR_DECODER2 ( POR, CLK, PC_HOLD, read_modify, RAM_RD_EN, MOVX_RI, 
        MOVX_DPI, MOVX_RI_A, MOVX_DPI_A, MOVX_INS, MOVC_INS, T2_XCHD_A_EN, 
        T1_XCHD_MDR_EN, A_IDATA_EN, CY_AC_OV_UP, CY_AC_OV_SUB_UP, 
        CY0_MUL_OV_UP, CY0_DIV_OV_UP, CY_UP, CY_DA_UP, CY_CJNE_EN, 
        ALU_SUBBC_EN, JBC_BIT_EN, JBC_BIT_ADDR_EN, IR, CS1, CS2, CS3, CS4, LS1, 
        LS2, LS3, LS4, ALLZ_B_PC_RES_EN, ALLZ_PC_RES_EN, ALU_ADC_EN, 
        ALU_ADD_EN, ALU_ANL_EN, ALU_BITC_EN, ALU_CPL_EN, ALU_ORL_EN, 
        ALU_RLC_EN, ALU_RL_EN, ALU_RRC_EN, ALU_RR_EN, ALU_SUB_EN, ALU_SWAP_EN, 
        ALU_XRL_EN, A_MRR_EN, A_T1_EN, B_T1_EN, B_T2RES_EN, CAR_OUT_EN, 
        CAR_PC_RES_EN, C_0_EN, C_1_EN, C_ALLZ_AND_EN, C_ALLZ_B_AND_EN, 
        C_ALLZ_B_EN, C_ALLZ_B_OR_EN, C_ALLZ_OR_EN, C_B_PC_RES_EN, C_CB_EN, 
        C_PC_RES_EN, DIV_OP_EN, DPTR_INC_EN, DPTR_DEC_EN, DP_T2T1_EN, 
        F5_ALLZ_EN, F5_B_PC_RES_EN, F5_PC_RES_EN, ID_PCH_EN_g, ID_PCL_EN_g, 
        ID_T2_EN_g, WM_EN_g, INT_EN_1_EN, MAR_BAR_EN, MAR_MDR_EN, MAR_P0R_EN, 
        MAR_RES_EN, MAR_RI_EN, MAR_RN_EN, MAR_SP_EN, MAR_T1_EN, MUL_OP_EN, 
        OV_T1Z_EN, P0R_MDR_EN, P0R_P0_EN, PC1_A_EN, PC1_DP_EN, PC1_P0R_EN, 
        PC1_PCCALL_EN, PC2_DP_EN, PC2_PC_EN, PC_AD11_EN, PC_PC1_EN, 
        SJMP_PC_RES_EN, JMP_PC_RES_EN, PC_RET_EN, PC_T2T1_EN, SP_RES_EN, 
        SP_T1_EN, T1_0_EN, T1_1_EN, T1_BITCP_EN, T1_B_EN, T1_CBP_EN, T1_DAD_EN, 
        T1_MDR_EN, T1_P0R_EN, T1_RES_EN, T1_SBP_EN, T2_0_EN, T2_1_EN, T2_A_EN, 
        T2_MDR_EN, T2_P0R_EN, T2_REM2_EN, T2_RES_EN, T2_SP_EN, WA_EN, 
        XAH_P2R_EN, XAL_MDR_EN, XA_DP_EN, XA_OUT_EN );
  input [7:0] IR;
  input POR, CLK, CS1, CS2, CS3, CS4, LS1, LS2, LS3, LS4;
  output PC_HOLD, read_modify, RAM_RD_EN, MOVX_RI, MOVX_DPI, MOVX_RI_A,
         MOVX_DPI_A, MOVX_INS, MOVC_INS, T2_XCHD_A_EN, T1_XCHD_MDR_EN,
         A_IDATA_EN, CY_AC_OV_UP, CY_AC_OV_SUB_UP, CY0_MUL_OV_UP,
         CY0_DIV_OV_UP, CY_UP, CY_DA_UP, CY_CJNE_EN, ALU_SUBBC_EN, JBC_BIT_EN,
         JBC_BIT_ADDR_EN, ALLZ_B_PC_RES_EN, ALLZ_PC_RES_EN, ALU_ADC_EN,
         ALU_ADD_EN, ALU_ANL_EN, ALU_BITC_EN, ALU_CPL_EN, ALU_ORL_EN,
         ALU_RLC_EN, ALU_RL_EN, ALU_RRC_EN, ALU_RR_EN, ALU_SUB_EN, ALU_SWAP_EN,
         ALU_XRL_EN, A_MRR_EN, A_T1_EN, B_T1_EN, B_T2RES_EN, CAR_OUT_EN,
         CAR_PC_RES_EN, C_0_EN, C_1_EN, C_ALLZ_AND_EN, C_ALLZ_B_AND_EN,
         C_ALLZ_B_EN, C_ALLZ_B_OR_EN, C_ALLZ_OR_EN, C_B_PC_RES_EN, C_CB_EN,
         C_PC_RES_EN, DIV_OP_EN, DPTR_INC_EN, DPTR_DEC_EN, DP_T2T1_EN,
         F5_ALLZ_EN, F5_B_PC_RES_EN, F5_PC_RES_EN, ID_PCH_EN_g, ID_PCL_EN_g,
         ID_T2_EN_g, WM_EN_g, INT_EN_1_EN, MAR_BAR_EN, MAR_MDR_EN, MAR_P0R_EN,
         MAR_RES_EN, MAR_RI_EN, MAR_RN_EN, MAR_SP_EN, MAR_T1_EN, MUL_OP_EN,
         OV_T1Z_EN, P0R_MDR_EN, P0R_P0_EN, PC1_A_EN, PC1_DP_EN, PC1_P0R_EN,
         PC1_PCCALL_EN, PC2_DP_EN, PC2_PC_EN, PC_AD11_EN, PC_PC1_EN,
         SJMP_PC_RES_EN, JMP_PC_RES_EN, PC_RET_EN, PC_T2T1_EN, SP_RES_EN,
         SP_T1_EN, T1_0_EN, T1_1_EN, T1_BITCP_EN, T1_B_EN, T1_CBP_EN,
         T1_DAD_EN, T1_MDR_EN, T1_P0R_EN, T1_RES_EN, T1_SBP_EN, T2_0_EN,
         T2_1_EN, T2_A_EN, T2_MDR_EN, T2_P0R_EN, T2_REM2_EN, T2_RES_EN,
         T2_SP_EN, WA_EN, XAH_P2R_EN, XAL_MDR_EN, XA_DP_EN, XA_OUT_EN;
  wire   ID_PCH_EN, ID_T2_EN, WM_EN, n1, n13, n14, n15, n96, n98, n109, n112,
         n165, n215, n216, n222, n235, n237, n244, n271, n381, n421, n443,
         n495, n496, n497, n498, n499, n500, n501, n502, n503, n504, n505,
         n506, n508, n509, n510, n512, n513, n514, n515, n518, n521, n522,
         n523, n524, n526, n527, n528, n529, n530, n531, n533, n534, n535,
         n536, n537, n538, n539, n540, n541, n542, n545, n547, n549, n555,
         n557, n558, n559, n561, n562, n563, n564, n565, n566, n567, n568,
         n569, n570, n571, n572, n573, n574, n575, n578, n580, n585, n586,
         n587, n588, n589, n590, n591, n592, n593, n594, n595, n596, n597,
         n598, n599, n600, n601, n602, n603, n604, n605, n606, n607, n608,
         n609, n610, n611, n612, n613, n614, n615, n616, n617, n618, n619,
         n620, n621, n622, n623, n624, n625, n626, n627, n628, n629, n630,
         n631, n632, n633, n634, n635, n636, n637, n638, n639, n640, n641,
         n642, n643, n644, n645, n646, n647, n648, n649, n650, n651, n652,
         n653, n654, n655, n656, n657, n658, n659, n660, n661, n662, n663,
         n664, n665, n666, n667, n668, n669, n670, n671, n672, n673, n674,
         n675, n676, n677, n678, n679, n680, n681, n682, n683, n684, n685,
         n686, n687, n688, n689, n690, n691, n692, n693, n694, n695, n696,
         n697, n698, n699, n700, n701, n702, n703, n704, n705, n706, n707,
         n708, n709, n710, n711, n712, n713, n714, n715, n716, n717, n718,
         n719, n720, n721, n722, n723, n724, n725, n726, n727, n728, n729,
         n730, n731, n732, n733, n734, n735, n736, n737, n738, n739, n740,
         n741, n742, n743, n744, n745, n746, n747, n748, n749, n750, n751,
         n752, n753, n754, n755, n756, n757, n758, n759, n760, n761, n762,
         n763, n764, n765, n766, n767, n768, n769, n770, n771, n772, n773,
         n774, n775, n776, n777, n778, n779, n780, n781, n782, n783, n784,
         n785, n786, n787, n788, n789, n790, n791, n792, n793, n794, n795,
         n796, n797, n798, n799, n800, n801, n802, n803, n804, n805, n806,
         n807, n808, n809, n810, n811, n812, n813, n814, n815, n816, n817,
         n818, n819, n820, n821, n822, n823, n824, n825, n826, n827, n828,
         n829, n830, n831, n832, n833, n834, n835, n836, n837, n838, n839,
         n840, n841, n842, n843, n844, n845, n846, n847, n848, n849, n850,
         n851, n852, n853, n854, n855, n856, n857, n858, n859, n860, n861,
         n862, n863, n864, n865, n866, n867, n868, n869, n870, n871, n872,
         n873, n874, n875, n876, n877, n878, n879, n880, n881, n882, n883,
         n884, n885, n886, n887, n888, n889, n890, n891, n892, n893, n894,
         n895, n896, n897, n898, n899, n900, n901, n902, n903, n904, n905,
         n906, n907, n908, n909, n910, n911, n912, n913, n914, n915, n916,
         n917, n918, n919, n920, n921, n922, n923, n924, n925, n926, n927,
         n928, n929, n930, n931, n932, n933, n934, n935, n936, n937, n938,
         n939, n940, n941, n942, n943, n944, n945, n946, n947, n948, n949,
         n950, n951, n952, n953, n954, n955, n956, n957, n958;

  NAND4X1 I605 ( .A(n529), .B(n530), .C(n698), .D(n699), .Y(T1_P0R_EN) );
  NOR3BX1 I606 ( .AN(n514), .B(n526), .C(n793), .Y(DPTR_DEC_EN) );
  AND3X2 I607 ( .A(n942), .B(n920), .C(n495), .Y(n533) );
  INVX1 I608 ( .A(n919), .Y(n495) );
  NAND2X1 I609 ( .A(n739), .B(n595), .Y(n652) );
  INVX2 I610 ( .A(n940), .Y(n739) );
  NAND4X1 I611 ( .A(n711), .B(n854), .C(n623), .D(n765), .Y(n763) );
  OAI2BB1X1 I612 ( .A0N(n630), .A1N(n685), .B0(n595), .Y(n684) );
  NAND2X1 I613 ( .A(n957), .B(n835), .Y(n831) );
  NAND2X1 I614 ( .A(n956), .B(n13), .Y(n883) );
  NAND4X1 I615 ( .A(n916), .B(n828), .C(n947), .D(n807), .Y(n866) );
  OR2X1 I616 ( .A(n940), .B(n848), .Y(n703) );
  AOI2BB1X2 I617 ( .A0N(n715), .A1N(n853), .B0(n526), .Y(MAR_T1_EN) );
  AOI2BB1X1 I618 ( .A0N(n663), .A1N(n748), .B0(n818), .Y(n817) );
  OAI2BB1X1 I619 ( .A0N(n570), .A1N(n595), .B0(n643), .Y(n642) );
  NAND2X1 I620 ( .A(n869), .B(n572), .Y(n858) );
  AND3X2 I621 ( .A(n949), .B(n557), .C(n956), .Y(n496) );
  NAND4BBX1 I622 ( .AN(n235), .BN(n237), .C(n597), .D(n593), .Y(n98) );
  NOR3X1 I623 ( .A(CY_AC_OV_UP), .B(ALU_SWAP_EN), .C(ALU_RR_EN), .Y(n635) );
  AND2X2 I624 ( .A(n222), .B(n443), .Y(n545) );
  AOI211X1 I625 ( .A0(n672), .A1(n622), .B0(n496), .C0(n547), .Y(n659) );
  AOI2BB1X1 I626 ( .A0N(n664), .A1N(n665), .B0(n663), .Y(n662) );
  OAI2BB1X1 I627 ( .A0N(n775), .A1N(n112), .B0(n776), .Y(PC2_DP_EN) );
  NAND4BX1 I628 ( .AN(PC_HOLD), .B(n778), .C(n779), .D(n780), .Y(P0R_P0_EN) );
  OAI211X1 I629 ( .A0(n841), .A1(n947), .B0(n767), .C0(n836), .Y(n835) );
  OAI2BB1X2 I630 ( .A0N(n538), .A1N(n527), .B0(n592), .Y(n669) );
  OAI221X4 I631 ( .A0(n567), .A1(n526), .B0(n165), .B1(n747), .C0(n804), .Y(
        MAR_RN_EN) );
  AND2X2 I632 ( .A(n739), .B(n574), .Y(n930) );
  NOR3X1 I633 ( .A(n944), .B(n777), .C(n685), .Y(JMP_PC_RES_EN) );
  AND2X2 I634 ( .A(n649), .B(n644), .Y(n691) );
  AOI221X4 I635 ( .A0(n713), .A1(n820), .B0(n497), .B1(n956), .C0(n518), .Y(
        n751) );
  INVX1 I636 ( .A(n627), .Y(n497) );
  OAI2BB1X1 I637 ( .A0N(n514), .A1N(n498), .B0(n765), .Y(n715) );
  INVX1 I638 ( .A(n825), .Y(n498) );
  AND2X2 I639 ( .A(n604), .B(n605), .Y(T1_B_EN) );
  AOI21X1 I640 ( .A0(n574), .A1(n596), .B0(n541), .Y(n885) );
  AOI2BB1X1 I641 ( .A0N(n599), .A1N(n653), .B0(n762), .Y(n760) );
  OAI2BB1X1 I642 ( .A0N(n868), .A1N(n946), .B0(n861), .Y(n856) );
  NOR2X1 I643 ( .A(n515), .B(n916), .Y(n911) );
  INVX2 I644 ( .A(n514), .Y(n515) );
  NAND4BX1 I645 ( .AN(n574), .B(n598), .C(n953), .D(n829), .Y(n931) );
  NAND2BX2 I646 ( .AN(PC2_DP_EN), .B(n772), .Y(PC1_A_EN) );
  OAI2BB1X1 I647 ( .A0N(n760), .A1N(n569), .B0(n759), .Y(n758) );
  OR4X2 I648 ( .A(n541), .B(n686), .C(n650), .D(n631), .Y(n873) );
  NAND2X1 I649 ( .A(n610), .B(n611), .Y(n609) );
  INVX2 I650 ( .A(n956), .Y(n610) );
  AOI2BB1X1 I651 ( .A0N(n679), .A1N(n951), .B0(n670), .Y(n796) );
  OR3X1 I652 ( .A(n508), .B(n630), .C(n858), .Y(n499) );
  INVX1 I653 ( .A(n499), .Y(C_0_EN) );
  OAI2BB1X1 I654 ( .A0N(n812), .A1N(n940), .B0(n574), .Y(n625) );
  AND4X2 I655 ( .A(n591), .B(n592), .C(n589), .D(n590), .Y(n586) );
  NOR2X1 I656 ( .A(n713), .B(n595), .Y(n679) );
  AND4X1 I657 ( .A(n514), .B(n869), .C(n958), .D(n622), .Y(DPTR_INC_EN) );
  NOR2X1 I658 ( .A(n830), .B(n750), .Y(n547) );
  AOI31X1 I659 ( .A0(n500), .A1(n854), .A2(n244), .B0(n508), .Y(A_T1_EN) );
  INVX1 I660 ( .A(n766), .Y(n500) );
  NAND4X1 I661 ( .A(n222), .B(n602), .C(n601), .D(n603), .Y(n216) );
  NAND4X1 I662 ( .A(n673), .B(n748), .C(n568), .D(n567), .Y(n855) );
  AND4X1 I663 ( .A(n949), .B(n957), .C(n501), .D(n628), .Y(C_ALLZ_B_AND_EN) );
  INVX1 I664 ( .A(n761), .Y(n501) );
  AND3X2 I665 ( .A(n920), .B(n502), .C(n923), .Y(n538) );
  INVX1 I666 ( .A(n919), .Y(n502) );
  OAI2BB1X1 I667 ( .A0N(n754), .A1N(n755), .B0(n694), .Y(n753) );
  AOI2BB1X2 I668 ( .A0N(n865), .A1N(n503), .B0(n508), .Y(CY_AC_OV_UP) );
  INVX1 I669 ( .A(n864), .Y(n503) );
  NAND3BX1 I670 ( .AN(n855), .B(n856), .C(n651), .Y(n851) );
  OAI2BB2X1 I671 ( .A0N(n504), .A1N(CS3), .B0(n610), .B1(n761), .Y(n820) );
  INVX1 I672 ( .A(n950), .Y(n504) );
  AOI2BB1X1 I673 ( .A0N(n950), .A1N(n807), .B0(n561), .Y(n165) );
  OR2X2 I674 ( .A(n848), .B(n812), .Y(n606) );
  NOR3X1 I675 ( .A(n937), .B(n508), .C(n858), .Y(C_1_EN) );
  OAI2BB1X1 I676 ( .A0N(n521), .A1N(n505), .B0(n112), .Y(n771) );
  INVX1 I677 ( .A(n669), .Y(n505) );
  NAND2X1 I678 ( .A(n794), .B(n830), .Y(n852) );
  NOR2BX1 I679 ( .AN(n796), .B(n619), .Y(n887) );
  NAND4BX1 I680 ( .AN(n571), .B(n810), .C(n643), .D(n645), .Y(n769) );
  NOR2X1 I681 ( .A(n673), .B(n750), .Y(n744) );
  OAI2BB1X1 I682 ( .A0N(n946), .A1N(n793), .B0(n739), .Y(n830) );
  NAND3X1 I683 ( .A(n937), .B(n630), .C(n599), .Y(n629) );
  AND3X4 I684 ( .A(n949), .B(CS4), .C(n506), .Y(JBC_BIT_EN) );
  INVX1 I685 ( .A(n592), .Y(n506) );
  INVX1 I686 ( .A(n932), .Y(n934) );
  NAND3X1 I687 ( .A(IR[0]), .B(n942), .C(n934), .Y(n793) );
  INVX1 I688 ( .A(n943), .Y(n917) );
  NAND2X1 I689 ( .A(n686), .B(n632), .Y(n627) );
  NAND3X2 I690 ( .A(n917), .B(n918), .C(IR[6]), .Y(n630) );
  INVX2 I691 ( .A(n937), .Y(n693) );
  INVX1 I692 ( .A(n942), .Y(n923) );
  INVX2 I693 ( .A(IR[6]), .Y(n922) );
  INVX1 I694 ( .A(IR[5]), .Y(n918) );
  NAND3X1 I695 ( .A(n942), .B(n907), .C(n934), .Y(n916) );
  NAND2X1 I696 ( .A(IR[3]), .B(n942), .Y(n807) );
  INVX2 I697 ( .A(n630), .Y(n861) );
  INVX2 I698 ( .A(n718), .Y(JBC_BIT_ADDR_EN) );
  INVX1 I699 ( .A(n807), .Y(n808) );
  NAND2BX1 I700 ( .AN(n573), .B(n572), .Y(n845) );
  INVX2 I701 ( .A(n793), .Y(n713) );
  NAND2X1 I702 ( .A(n958), .B(IR[2]), .Y(n946) );
  NAND3X1 I703 ( .A(IR[1]), .B(n923), .C(n924), .Y(n848) );
  INVX2 I704 ( .A(n570), .Y(n941) );
  INVX2 I705 ( .A(n508), .Y(n734) );
  INVX1 I706 ( .A(n845), .Y(n628) );
  INVX2 I707 ( .A(n534), .Y(n937) );
  NAND3X2 I708 ( .A(n630), .B(n937), .C(n941), .Y(n632) );
  INVX2 I709 ( .A(n848), .Y(n631) );
  BUFX3 I710 ( .A(n761), .Y(n940) );
  NAND2X1 I711 ( .A(n627), .B(n794), .Y(n786) );
  NAND2X2 I712 ( .A(n538), .B(n596), .Y(n592) );
  AND2X2 I713 ( .A(n911), .B(n912), .Y(MUL_OP_EN) );
  NAND2X1 I714 ( .A(n628), .B(n596), .Y(n589) );
  NAND2X4 I715 ( .A(n957), .B(n949), .Y(n508) );
  NAND4X2 I716 ( .A(n513), .B(n509), .C(n910), .D(n909), .Y(ALU_ADD_EN) );
  NOR2X1 I717 ( .A(CY_DA_UP), .B(ID_PCH_EN), .Y(n910) );
  BUFX8 I718 ( .A(CS2), .Y(n956) );
  NAND2X2 I719 ( .A(n631), .B(n527), .Y(n756) );
  NAND2X2 I720 ( .A(n956), .B(LS1), .Y(n612) );
  NOR2X1 I721 ( .A(n713), .B(n808), .Y(n868) );
  NOR2X1 I722 ( .A(n837), .B(n838), .Y(n767) );
  NAND2X1 I723 ( .A(n570), .B(n574), .Y(n643) );
  OAI21X1 I724 ( .A0(n868), .A1(n941), .B0(n856), .Y(n766) );
  BUFX3 I725 ( .A(IR[4]), .Y(n943) );
  NAND2X2 I726 ( .A(n949), .B(n956), .Y(n944) );
  INVX1 I727 ( .A(n843), .Y(n695) );
  NAND2X1 I728 ( .A(n541), .B(n632), .Y(n590) );
  NAND2X2 I729 ( .A(n957), .B(LS1), .Y(n655) );
  NAND2X2 I730 ( .A(n723), .B(n724), .Y(T2_SP_EN) );
  AOI21X1 I731 ( .A0(n668), .A1(n939), .B0(n726), .Y(n723) );
  AND2X2 I732 ( .A(n875), .B(n948), .Y(ALU_CPL_EN) );
  NOR2X1 I733 ( .A(n786), .B(n787), .Y(n654) );
  BUFX3 I734 ( .A(n585), .Y(read_modify) );
  NAND2X1 I735 ( .A(n952), .B(n861), .Y(n648) );
  NAND2X1 I736 ( .A(n952), .B(n693), .Y(n647) );
  NAND3X2 I737 ( .A(n943), .B(n922), .C(IR[5]), .Y(n950) );
  NAND2X1 I738 ( .A(n650), .B(n596), .Y(n644) );
  INVX2 I739 ( .A(n916), .Y(n595) );
  NAND3BX2 I740 ( .AN(IR[5]), .B(n943), .C(n922), .Y(n812) );
  NAND2X1 I741 ( .A(n940), .B(n812), .Y(n687) );
  NAND2X1 I742 ( .A(n861), .B(n628), .Y(n717) );
  INVX2 I743 ( .A(n747), .Y(n605) );
  NAND4X1 I744 ( .A(n537), .B(n767), .C(n768), .D(n590), .Y(n688) );
  NAND2X2 I745 ( .A(LS1), .B(n954), .Y(n747) );
  INVX1 I746 ( .A(n655), .Y(n690) );
  NOR2BX1 I747 ( .AN(IR[0]), .B(IR[2]), .Y(n869) );
  NAND3X2 I748 ( .A(IR[5]), .B(n943), .C(IR[6]), .Y(n685) );
  NOR2X2 I749 ( .A(n703), .B(n944), .Y(PC_T2T1_EN) );
  NAND3X1 I750 ( .A(n943), .B(n922), .C(IR[5]), .Y(n599) );
  INVX1 I751 ( .A(n858), .Y(n774) );
  INVX4 I752 ( .A(n812), .Y(n596) );
  INVX1 I753 ( .A(n612), .Y(n112) );
  NAND2X1 I754 ( .A(n774), .B(n687), .Y(n803) );
  INVX1 I755 ( .A(n944), .Y(n781) );
  NAND3X1 I756 ( .A(n589), .B(n717), .C(n695), .Y(n665) );
  INVX1 I757 ( .A(n799), .Y(P0R_MDR_EN) );
  NOR2X1 I758 ( .A(C_ALLZ_B_OR_EN), .B(C_ALLZ_B_EN), .Y(n908) );
  NAND3X1 I759 ( .A(n686), .B(n596), .C(n734), .Y(n862) );
  NAND2X1 I760 ( .A(n889), .B(n686), .Y(n863) );
  INVX2 I761 ( .A(IR[0]), .Y(n907) );
  NOR2X1 I762 ( .A(n589), .B(n508), .Y(ALU_BITC_EN) );
  NOR2X1 I763 ( .A(n937), .B(n845), .Y(n896) );
  NAND3X1 I764 ( .A(n907), .B(n923), .C(n934), .Y(n598) );
  NAND3X1 I765 ( .A(n913), .B(n663), .C(n914), .Y(n912) );
  NAND2X1 I766 ( .A(n732), .B(n510), .Y(n915) );
  INVX2 I767 ( .A(CS3), .Y(n955) );
  NAND2X1 I768 ( .A(LS2), .B(n954), .Y(n653) );
  OAI21X1 I769 ( .A0(n695), .A1(n526), .B0(n696), .Y(T1_SBP_EN) );
  AND3X2 I770 ( .A(n917), .B(n922), .C(IR[5]), .Y(n514) );
  NAND2X1 I771 ( .A(n604), .B(n882), .Y(n860) );
  NAND3BX1 I772 ( .AN(n571), .B(n647), .C(n648), .Y(n640) );
  NAND3X1 I773 ( .A(n644), .B(n645), .C(n646), .Y(n641) );
  NOR2X1 I774 ( .A(n510), .B(n606), .Y(n700) );
  NOR2X1 I775 ( .A(n508), .B(n656), .Y(DP_T2T1_EN) );
  INVX1 I776 ( .A(IR[3]), .Y(n925) );
  INVX1 I777 ( .A(IR[1]), .Y(n920) );
  NAND3X2 I778 ( .A(n943), .B(n922), .C(IR[5]), .Y(n951) );
  NOR2X1 I779 ( .A(n823), .B(n381), .Y(n749) );
  OAI21X1 I780 ( .A0(n515), .A1(n946), .B0(n626), .Y(n823) );
  NAND2BX1 I781 ( .AN(n807), .B(n948), .Y(n271) );
  NAND2X1 I782 ( .A(n952), .B(n948), .Y(n765) );
  NAND2X2 I783 ( .A(n957), .B(LS2), .Y(n663) );
  INVX1 I784 ( .A(n663), .Y(n728) );
  NAND2X2 I785 ( .A(LS3), .B(n954), .Y(n732) );
  INVX1 I786 ( .A(n639), .Y(ALU_SUBBC_EN) );
  NAND3X1 I787 ( .A(LS2), .B(n881), .C(n956), .Y(n799) );
  INVX1 I788 ( .A(n732), .Y(n697) );
  NAND3X2 I789 ( .A(n674), .B(n675), .C(n676), .Y(T2_A_EN) );
  OAI21X1 I790 ( .A0(n688), .A1(n689), .B0(n690), .Y(n674) );
  NAND2X1 I791 ( .A(n949), .B(n956), .Y(n945) );
  NAND2X1 I792 ( .A(n693), .B(n713), .Y(n591) );
  NAND2X1 I793 ( .A(n728), .B(n604), .Y(n859) );
  NOR2X1 I794 ( .A(n663), .B(n773), .Y(PC1_DP_EN) );
  OAI21X1 I795 ( .A0(n774), .A1(n713), .B0(n514), .Y(n773) );
  NAND2X1 I796 ( .A(n815), .B(n728), .Y(n694) );
  NAND4X1 I797 ( .A(IR[0]), .B(n920), .C(n801), .D(n925), .Y(n770) );
  INVX2 I798 ( .A(IR[2]), .Y(n801) );
  BUFX4 I799 ( .A(CS1), .Y(n957) );
  OAI2BB1X1 I800 ( .A0N(n605), .A1N(n669), .B0(n842), .Y(MAR_BAR_EN) );
  OAI2BB1X1 I801 ( .A0N(n697), .A1N(n939), .B0(n799), .Y(T2_RES_EN) );
  NOR2X1 I802 ( .A(n770), .B(n945), .Y(PC_AD11_EN) );
  NAND2X1 I803 ( .A(n952), .B(n739), .Y(n624) );
  OAI2BB1X2 I804 ( .A0N(LS2), .A1N(n813), .B0(n694), .Y(MAR_MDR_EN) );
  OR2X2 I805 ( .A(T2_RES_EN), .B(ID_PCH_EN), .Y(MAR_RES_EN) );
  INVX1 I806 ( .A(POR), .Y(n1) );
  DFFRHQX1 ID_T2_EN_g_reg ( .D(ID_T2_EN), .CK(CLK), .RN(n1), .Q(ID_T2_EN_g) );
  OR2X2 I807 ( .A(n727), .B(n738), .Y(n509) );
  NAND2X4 I808 ( .A(n949), .B(n954), .Y(n510) );
  INVX2 I809 ( .A(n526), .Y(n622) );
  INVX1 I810 ( .A(n840), .Y(n953) );
  INVX2 I811 ( .A(n953), .Y(n952) );
  NAND2X1 I812 ( .A(n952), .B(n596), .Y(n623) );
  OR2X2 I813 ( .A(n786), .B(n792), .Y(n512) );
  NAND2X1 I814 ( .A(n911), .B(n912), .Y(n513) );
  NAND3X2 I815 ( .A(n920), .B(n925), .C(IR[2]), .Y(n932) );
  NAND4X1 I816 ( .A(n821), .B(n537), .C(n749), .D(n822), .Y(n783) );
  INVX1 I817 ( .A(n946), .Y(n759) );
  INVX1 I818 ( .A(n859), .Y(B_T2RES_EN) );
  NAND3X1 I819 ( .A(n596), .B(n866), .C(n734), .Y(n639) );
  AOI21X2 I820 ( .A0(n613), .A1(n614), .B0(n510), .Y(XA_DP_EN) );
  OAI221X4 I821 ( .A0(n816), .A1(n655), .B0(n612), .B1(n794), .C0(n817), .Y(
        MAR_P0R_EN) );
  INVX12 I822 ( .A(n777), .Y(n686) );
  NAND2X2 I823 ( .A(LS2), .B(n956), .Y(n531) );
  NOR2X1 I824 ( .A(n549), .B(n526), .Y(n702) );
  NOR4BX2 I825 ( .AN(n562), .B(n640), .C(n641), .D(n642), .Y(n638) );
  NOR2X2 I826 ( .A(n652), .B(n653), .Y(T2_REM2_EN) );
  NOR2X1 I827 ( .A(n849), .B(n858), .Y(C_CB_EN) );
  OAI21X1 I828 ( .A0(n929), .A1(n515), .B0(n597), .Y(n865) );
  AND2X1 I829 ( .A(n906), .B(n942), .Y(n572) );
  INVX2 I830 ( .A(n557), .Y(n673) );
  NOR3X2 I831 ( .A(n700), .B(n701), .C(n702), .Y(n699) );
  NOR3BX2 I832 ( .AN(n271), .B(n564), .C(n563), .Y(n568) );
  OAI21X2 I833 ( .A0(n825), .A1(n951), .B0(n594), .Y(n670) );
  NAND2X2 I834 ( .A(n958), .B(IR[2]), .Y(n825) );
  OAI22X2 I835 ( .A0(n508), .A1(n803), .B0(n421), .B1(n526), .Y(A_MRR_EN) );
  NAND2X4 I836 ( .A(LS3), .B(n957), .Y(n526) );
  NAND2X2 I837 ( .A(n533), .B(n861), .Y(n727) );
  AND2X2 I838 ( .A(n734), .B(n735), .Y(SP_T1_EN) );
  NAND2X1 I839 ( .A(n541), .B(n687), .Y(n626) );
  NOR2X4 I840 ( .A(n932), .B(n542), .Y(n541) );
  INVX4 I841 ( .A(n955), .Y(n954) );
  NAND2X1 I842 ( .A(LS3), .B(n956), .Y(n750) );
  NAND2X2 I843 ( .A(n951), .B(n515), .Y(n527) );
  INVX2 I844 ( .A(n864), .Y(ALU_ADC_EN) );
  AND2X1 I845 ( .A(n533), .B(n693), .Y(n557) );
  OR2X1 I846 ( .A(n940), .B(n531), .Y(n569) );
  AND3X1 I847 ( .A(n943), .B(n918), .C(IR[6]), .Y(n534) );
  INVX1 I848 ( .A(n651), .Y(T1_XCHD_MDR_EN) );
  INVX1 I849 ( .A(n652), .Y(n604) );
  NAND2X1 I850 ( .A(n859), .B(n860), .Y(DIV_OP_EN) );
  AND2X1 I851 ( .A(n781), .B(n735), .Y(T1_RES_EN) );
  INVX1 I852 ( .A(n736), .Y(PC_RET_EN) );
  INVX1 I853 ( .A(n575), .Y(XAL_MDR_EN) );
  NAND2BX1 I854 ( .AN(n561), .B(n591), .Y(n619) );
  NAND2X1 I855 ( .A(n949), .B(n956), .Y(n738) );
  NAND2X1 I856 ( .A(n880), .B(n956), .Y(n736) );
  NAND3X1 I857 ( .A(n949), .B(n669), .C(n954), .Y(n782) );
  NOR2X1 I858 ( .A(n900), .B(n901), .Y(n899) );
  NOR3BX1 I859 ( .AN(n956), .B(n592), .C(n797), .Y(n901) );
  NAND2X1 I860 ( .A(n739), .B(n650), .Y(n649) );
  NOR2X1 I861 ( .A(C_ALLZ_B_AND_EN), .B(C_ALLZ_AND_EN), .Y(n898) );
  INVX2 I862 ( .A(n949), .Y(n797) );
  INVX1 I863 ( .A(n854), .Y(n764) );
  INVX1 I864 ( .A(n863), .Y(ALU_RLC_EN) );
  INVX1 I865 ( .A(n531), .Y(n729) );
  OAI21X1 I866 ( .A0(n545), .A1(n732), .B0(n733), .Y(T1_0_EN) );
  NAND2X1 I867 ( .A(n736), .B(n737), .Y(SP_RES_EN) );
  INVX1 I868 ( .A(n14), .Y(n421) );
  NOR2X1 I869 ( .A(n955), .B(n591), .Y(n518) );
  INVX1 I870 ( .A(n639), .Y(CY_AC_OV_SUB_UP) );
  NOR2X1 I871 ( .A(n565), .B(n510), .Y(XAH_P2R_EN) );
  NAND4BBX1 I872 ( .AN(n785), .BN(n665), .C(n654), .D(n549), .Y(n784) );
  NOR2X1 I873 ( .A(n738), .B(n803), .Y(CAR_PC_RES_EN) );
  INVX1 I874 ( .A(n703), .Y(n658) );
  NOR2X1 I875 ( .A(n215), .B(n216), .Y(n521) );
  NOR3BX1 I876 ( .AN(n957), .B(n515), .C(n797), .Y(n888) );
  NAND2BX1 I877 ( .AN(n522), .B(n957), .Y(n849) );
  OR2X2 I878 ( .A(n950), .B(n797), .Y(n522) );
  NAND4X1 I879 ( .A(n523), .B(n524), .C(n626), .D(n627), .Y(n588) );
  NAND2X1 I880 ( .A(n631), .B(n632), .Y(n523) );
  NAND2X1 I881 ( .A(n628), .B(n629), .Y(n524) );
  INVX1 I882 ( .A(n950), .Y(n704) );
  NAND4X1 I883 ( .A(n748), .B(n727), .C(n625), .D(n749), .Y(n664) );
  OAI21X1 I884 ( .A0(n666), .A1(n955), .B0(n667), .Y(n661) );
  OAI21X1 I885 ( .A0(n670), .A1(n619), .B0(LS3), .Y(n666) );
  BUFX2 I886 ( .A(n572), .Y(n958) );
  NAND2X1 I887 ( .A(n704), .B(n808), .Y(n594) );
  AND3X1 I888 ( .A(n538), .B(n857), .C(n781), .Y(F5_B_PC_RES_EN) );
  NAND2X1 I889 ( .A(n739), .B(n808), .Y(n748) );
  NAND2X1 I890 ( .A(n952), .B(n570), .Y(n646) );
  AOI21X1 I891 ( .A0(n693), .A1(n873), .B0(n571), .Y(n902) );
  BUFX4 I892 ( .A(LS4), .Y(n949) );
  INVX2 I893 ( .A(n598), .Y(n650) );
  AND2X1 I894 ( .A(n938), .B(n686), .Y(ALU_RL_EN) );
  NAND2X1 I895 ( .A(n620), .B(n939), .Y(n737) );
  AND4X1 I896 ( .A(n949), .B(n631), .C(n948), .D(n957), .Y(C_ALLZ_B_OR_EN) );
  NAND2X1 I897 ( .A(n759), .B(n693), .Y(n854) );
  BUFX3 I898 ( .A(n788), .Y(n948) );
  AOI21X1 I899 ( .A0(n870), .A1(n871), .B0(n508), .Y(ALU_XRL_EN) );
  INVX1 I900 ( .A(n830), .Y(n671) );
  AND3X1 I901 ( .A(n704), .B(n538), .C(n781), .Y(F5_PC_RES_EN) );
  NAND4BX1 I902 ( .AN(n633), .B(n528), .C(n634), .D(n635), .Y(WA_EN) );
  AND2X1 I903 ( .A(n636), .B(n637), .Y(n528) );
  NAND2X1 I904 ( .A(n605), .B(n670), .Y(n529) );
  NAND3X1 I905 ( .A(n595), .B(n704), .C(n697), .Y(n530) );
  NAND3X1 I906 ( .A(n774), .B(n739), .C(n729), .Y(n772) );
  NAND2X1 I907 ( .A(n729), .B(n939), .Y(n720) );
  NOR2X1 I908 ( .A(n515), .B(n867), .Y(CY0_MUL_OV_UP) );
  NOR3BX1 I909 ( .AN(n590), .B(n564), .C(n671), .Y(n821) );
  NAND3X1 I910 ( .A(n682), .B(n683), .C(n684), .Y(n680) );
  NOR2X1 I911 ( .A(n679), .B(n950), .Y(n677) );
  INVX1 I912 ( .A(n856), .Y(n681) );
  BUFX3 I913 ( .A(n725), .Y(n939) );
  AOI21X1 I914 ( .A0(n535), .A1(n536), .B0(n508), .Y(n892) );
  NOR2X1 I915 ( .A(n895), .B(n896), .Y(n535) );
  NAND2X1 I916 ( .A(n861), .B(n873), .Y(n536) );
  AND4X2 I917 ( .A(n826), .B(n827), .C(n828), .D(n829), .Y(n537) );
  NAND2X1 I918 ( .A(n861), .B(n574), .Y(n645) );
  INVX1 I919 ( .A(n824), .Y(n381) );
  NOR2X1 I920 ( .A(n926), .B(n508), .Y(n921) );
  NOR3BX1 I921 ( .AN(n927), .B(n928), .C(n865), .Y(n926) );
  AND3X2 I922 ( .A(n703), .B(n770), .C(n521), .Y(n539) );
  NOR2X1 I923 ( .A(n941), .B(n802), .Y(MOVX_RI) );
  NOR3X1 I924 ( .A(n764), .B(n563), .C(n672), .Y(n836) );
  OAI21X1 I925 ( .A0(n793), .A1(n940), .B0(n656), .Y(n792) );
  NAND2X1 I926 ( .A(n948), .B(n541), .Y(n794) );
  NAND2X1 I927 ( .A(n540), .B(n906), .Y(n777) );
  NOR3X1 I928 ( .A(n907), .B(n942), .C(IR[2]), .Y(n540) );
  NAND2X1 I929 ( .A(IR[0]), .B(n923), .Y(n542) );
  BUFX3 I930 ( .A(IR[7]), .Y(n942) );
  INVX1 I931 ( .A(n651), .Y(T2_XCHD_A_EN) );
  INVX1 I932 ( .A(n616), .Y(T1_BITCP_EN) );
  INVX1 I933 ( .A(n694), .Y(T2_1_EN) );
  INVX1 I934 ( .A(n545), .Y(n678) );
  INVX1 I935 ( .A(n894), .Y(ALLZ_PC_RES_EN) );
  NOR2X1 I936 ( .A(n936), .B(n944), .Y(ALLZ_B_PC_RES_EN) );
  INVX1 I937 ( .A(n215), .Y(n936) );
  INVX1 I938 ( .A(n867), .Y(n875) );
  NAND2X1 I939 ( .A(n764), .B(n622), .Y(n651) );
  INVX1 I940 ( .A(n636), .Y(CY_DA_UP) );
  INVX1 I941 ( .A(n957), .Y(n611) );
  NAND3BX2 I942 ( .AN(n897), .B(n898), .C(n899), .Y(ALU_ANL_EN) );
  INVX1 I943 ( .A(CY_UP), .Y(n637) );
  NAND2X1 I944 ( .A(n887), .B(n443), .Y(n215) );
  NAND2X1 I945 ( .A(n618), .B(n729), .Y(n718) );
  INVX1 I946 ( .A(n771), .Y(PC1_P0R_EN) );
  NAND2BX1 I947 ( .AN(n589), .B(n622), .Y(n616) );
  NAND2X1 I948 ( .A(n658), .B(n112), .Y(n698) );
  INVX1 I949 ( .A(XAH_P2R_EN), .Y(n575) );
  AND2X2 I950 ( .A(n604), .B(n605), .Y(T2_0_EN) );
  INVX1 I951 ( .A(n510), .Y(n791) );
  INVX1 I952 ( .A(n782), .Y(F5_ALLZ_EN) );
  INVX1 I953 ( .A(n578), .Y(OV_T1Z_EN) );
  INVX1 I954 ( .A(T2_REM2_EN), .Y(n578) );
  NOR2X1 I955 ( .A(n652), .B(n508), .Y(CY0_DIV_OV_UP) );
  AND2X2 I956 ( .A(n875), .B(n861), .Y(ALU_SWAP_EN) );
  NAND3X1 I957 ( .A(n949), .B(n595), .C(n957), .Y(n867) );
  INVX1 I958 ( .A(n862), .Y(ALU_RRC_EN) );
  NOR2X1 I959 ( .A(n756), .B(n797), .Y(n880) );
  INVX1 I960 ( .A(n750), .Y(n620) );
  NAND2X1 I961 ( .A(n875), .B(n693), .Y(n636) );
  NAND2X1 I962 ( .A(n935), .B(n956), .Y(n894) );
  NOR2X1 I963 ( .A(n222), .B(n797), .Y(n935) );
  NAND4X1 I964 ( .A(n883), .B(n655), .C(n732), .D(n510), .Y(n882) );
  NAND2X1 I965 ( .A(n659), .B(n660), .Y(T2_MDR_EN) );
  NOR2X1 I966 ( .A(n661), .B(n662), .Y(n660) );
  AOI21X1 I967 ( .A0(n902), .A1(n903), .B0(n508), .Y(n900) );
  NOR2X1 I968 ( .A(n904), .B(n905), .Y(n903) );
  INVX1 I969 ( .A(n653), .Y(n668) );
  NAND3BX1 I970 ( .AN(C_ALLZ_OR_EN), .B(n782), .C(n908), .Y(n897) );
  INVX1 I971 ( .A(n849), .Y(n889) );
  INVX1 I972 ( .A(n766), .Y(n711) );
  NAND2X1 I973 ( .A(n711), .B(n624), .Y(n709) );
  NAND2X1 I974 ( .A(n443), .B(n894), .Y(n893) );
  NOR2X1 I975 ( .A(n690), .B(n915), .Y(n914) );
  NOR2BX1 I976 ( .AN(n859), .B(n879), .Y(n878) );
  NAND2X1 I977 ( .A(n799), .B(n736), .Y(n879) );
  INVX1 I978 ( .A(n737), .Y(ID_PCH_EN) );
  INVX1 I979 ( .A(n588), .Y(n587) );
  NAND2X1 I980 ( .A(n586), .B(n587), .Y(n585) );
  NAND2X1 I981 ( .A(n514), .B(n650), .Y(n597) );
  NAND2X1 I982 ( .A(n862), .B(n863), .Y(CY_UP) );
  NAND2X1 I983 ( .A(n887), .B(n673), .Y(n886) );
  INVX1 I984 ( .A(n717), .Y(n904) );
  INVX1 I985 ( .A(n647), .Y(n905) );
  INVX1 I986 ( .A(n623), .Y(n672) );
  INVX1 I987 ( .A(n627), .Y(n714) );
  NOR2X1 I988 ( .A(n945), .B(n603), .Y(SJMP_PC_RES_EN) );
  NOR2X1 I989 ( .A(n944), .B(n602), .Y(C_PC_RES_EN) );
  NOR2X1 I990 ( .A(n945), .B(n601), .Y(C_B_PC_RES_EN) );
  OAI221X4 I991 ( .A0(n654), .A1(n655), .B0(n612), .B1(n656), .C0(n657), .Y(
        T2_P0R_EN) );
  NAND2X1 I992 ( .A(n658), .B(n605), .Y(n657) );
  NAND2X1 I993 ( .A(n771), .B(n772), .Y(PC2_PC_EN) );
  OAI21X2 I994 ( .A0(n677), .A1(n678), .B0(n605), .Y(n676) );
  OAI21X2 I995 ( .A0(n680), .A1(n681), .B0(n622), .Y(n675) );
  OAI21X1 I996 ( .A0(n526), .A1(n717), .B0(n718), .Y(T1_CBP_EN) );
  NAND2X1 I997 ( .A(n690), .B(n665), .Y(n842) );
  NAND2X1 I998 ( .A(n948), .B(n650), .Y(n244) );
  NAND3X1 I999 ( .A(n595), .B(n514), .C(n605), .Y(n733) );
  NAND2X1 I1000 ( .A(n650), .B(n632), .Y(n593) );
  NOR2X1 I1001 ( .A(n655), .B(n656), .Y(n701) );
  NOR2X1 I1002 ( .A(n526), .B(n716), .Y(T1_DAD_EN) );
  NAND2X1 I1003 ( .A(n595), .B(n693), .Y(n716) );
  NOR2X2 I1004 ( .A(n738), .B(n606), .Y(PC_PC1_EN) );
  NOR2BX1 I1005 ( .AN(n244), .B(n98), .Y(n549) );
  NAND4X1 I1006 ( .A(n719), .B(n720), .C(n721), .D(n722), .Y(T1_1_EN) );
  AOI22X1 I1007 ( .A0(n672), .A1(n728), .B0(n697), .B1(n619), .Y(n721) );
  OAI21X1 I1008 ( .A0(n730), .A1(n731), .B0(n622), .Y(n719) );
  INVX1 I1009 ( .A(n614), .Y(MOVX_DPI) );
  INVX1 I1010 ( .A(T2_SP_EN), .Y(n722) );
  AND2X2 I1011 ( .A(n595), .B(n596), .Y(n237) );
  NAND4X1 I1012 ( .A(n691), .B(n692), .C(n568), .D(n96), .Y(n689) );
  NAND2X1 I1013 ( .A(n595), .B(n693), .Y(n692) );
  INVX1 I1014 ( .A(n98), .Y(n96) );
  NAND2X1 I1015 ( .A(n727), .B(n673), .Y(n735) );
  OAI21X1 I1016 ( .A0(n783), .A1(n784), .B0(n781), .Y(n779) );
  NAND2BX1 I1017 ( .AN(n789), .B(n656), .Y(n785) );
  INVX1 I1018 ( .A(n592), .Y(n618) );
  AND2X2 I1019 ( .A(n109), .B(n112), .Y(PC1_PCCALL_EN) );
  INVX1 I1020 ( .A(n606), .Y(n109) );
  NAND3X1 I1021 ( .A(n615), .B(n616), .C(n617), .Y(WM_EN) );
  OAI21X1 I1022 ( .A0(n618), .A1(n619), .B0(n620), .Y(n617) );
  OAI21X1 I1023 ( .A0(n588), .A1(n621), .B0(n622), .Y(n615) );
  NAND3X1 I1024 ( .A(n623), .B(n624), .C(n625), .Y(n621) );
  INVX1 I1025 ( .A(n748), .Y(n789) );
  INVX2 I1026 ( .A(n580), .Y(B_T1_EN) );
  INVX1 I1027 ( .A(CY0_MUL_OV_UP), .Y(n580) );
  NOR2X1 I1028 ( .A(T1_RES_EN), .B(n566), .Y(n780) );
  INVX1 I1029 ( .A(n803), .Y(MOVC_INS) );
  INVX1 I1030 ( .A(n613), .Y(MOVX_DPI_A) );
  OR2X2 I1031 ( .A(n15), .B(n14), .Y(MOVX_INS) );
  INVX1 I1032 ( .A(n565), .Y(n834) );
  NOR2X1 I1033 ( .A(n798), .B(n669), .Y(n795) );
  NAND3X1 I1034 ( .A(n606), .B(n703), .C(n591), .Y(n798) );
  INVX1 I1035 ( .A(n624), .Y(n815) );
  NAND2X1 I1036 ( .A(n625), .B(n644), .Y(n731) );
  NOR3X1 I1037 ( .A(n743), .B(n744), .C(n745), .Y(n742) );
  NOR2X1 I1038 ( .A(n751), .B(n752), .Y(n743) );
  OAI22X1 I1039 ( .A0(n746), .A1(n655), .B0(n165), .B1(n747), .Y(n745) );
  NAND3X1 I1040 ( .A(n13), .B(n14), .C(n609), .Y(n608) );
  NOR2X1 I1041 ( .A(n756), .B(n610), .Y(n754) );
  OAI2BB1X1 I1042 ( .A0N(n607), .A1N(n15), .B0(n608), .Y(XA_OUT_EN) );
  NAND2X1 I1043 ( .A(n531), .B(n612), .Y(n607) );
  INVX1 I1044 ( .A(n664), .Y(n746) );
  NOR2X2 I1045 ( .A(n921), .B(n555), .Y(n909) );
  INVX1 I1046 ( .A(n769), .Y(n768) );
  INVX1 I1047 ( .A(n756), .Y(n881) );
  NAND4X1 I1048 ( .A(n712), .B(LS3), .C(n713), .D(n954), .Y(n707) );
  INVX1 I1049 ( .A(n599), .Y(n712) );
  NAND3BX1 I1050 ( .AN(n797), .B(n886), .C(n956), .Y(n876) );
  NAND3X1 I1051 ( .A(n596), .B(n884), .C(n734), .Y(n877) );
  NAND2BX1 I1052 ( .AN(n610), .B(n13), .Y(n913) );
  NAND2X1 I1053 ( .A(n596), .B(n713), .Y(n828) );
  NAND2X1 I1054 ( .A(n668), .B(n669), .Y(n667) );
  NOR2BX1 I1055 ( .AN(n646), .B(n872), .Y(n871) );
  AOI21X1 I1056 ( .A0(n570), .A1(n873), .B0(n874), .Y(n870) );
  AND2X2 I1057 ( .A(n889), .B(n533), .Y(C_ALLZ_AND_EN) );
  NAND4X1 I1058 ( .A(n705), .B(n706), .C(n707), .D(n708), .Y(T1_MDR_EN) );
  OAI21X1 I1059 ( .A0(n688), .A1(n709), .B0(n710), .Y(n708) );
  NAND3X1 I1060 ( .A(n715), .B(LS2), .C(n956), .Y(n705) );
  NAND3X1 I1061 ( .A(LS3), .B(n714), .C(n956), .Y(n706) );
  AND3X2 I1062 ( .A(n739), .B(n686), .C(n734), .Y(ALU_RR_EN) );
  NOR2BX1 I1063 ( .AN(LS3), .B(n611), .Y(n710) );
  AND2X2 I1064 ( .A(n938), .B(n533), .Y(C_ALLZ_OR_EN) );
  NOR2X1 I1065 ( .A(n781), .B(n892), .Y(n891) );
  BUFX3 I1066 ( .A(n888), .Y(n938) );
  AND2X2 I1067 ( .A(n697), .B(n939), .Y(n555) );
  AND2X2 I1068 ( .A(n938), .B(n628), .Y(C_ALLZ_B_EN) );
  NOR2X1 I1069 ( .A(ALU_RL_EN), .B(ALU_CPL_EN), .Y(n634) );
  OAI21X1 I1070 ( .A0(n638), .A1(n508), .B0(n639), .Y(n633) );
  NAND2X1 I1071 ( .A(n570), .B(n538), .Y(n222) );
  OR2X2 I1072 ( .A(n558), .B(n559), .Y(n13) );
  OR2X2 I1073 ( .A(LS2), .B(LS1), .Y(n558) );
  OR2X2 I1074 ( .A(n949), .B(LS3), .Y(n559) );
  NAND2X1 I1075 ( .A(n948), .B(n538), .Y(n443) );
  INVX1 I1076 ( .A(n685), .Y(n788) );
  NAND2X1 I1077 ( .A(n645), .B(n648), .Y(n895) );
  NAND2X1 I1078 ( .A(n940), .B(n937), .Y(n847) );
  INVX1 I1079 ( .A(n643), .Y(n872) );
  NAND2X1 I1080 ( .A(n592), .B(n515), .Y(n857) );
  AND2X2 I1081 ( .A(n808), .B(n693), .Y(n561) );
  AND3X2 I1082 ( .A(n649), .B(n593), .C(n590), .Y(n562) );
  INVX1 I1083 ( .A(MAR_SP_EN), .Y(n724) );
  NOR2X1 I1084 ( .A(n531), .B(n727), .Y(n726) );
  NAND2X1 I1085 ( .A(n697), .B(n669), .Y(n696) );
  OAI21X1 I1086 ( .A0(n769), .A1(n805), .B0(n690), .Y(n804) );
  INVX1 I1087 ( .A(n727), .Y(n853) );
  NAND2X1 I1088 ( .A(n533), .B(n570), .Y(n614) );
  NAND2X1 I1089 ( .A(n538), .B(n693), .Y(n601) );
  NAND2X1 I1090 ( .A(n739), .B(n533), .Y(n603) );
  NAND2X1 I1091 ( .A(n861), .B(n538), .Y(n602) );
  NOR2X1 I1092 ( .A(n783), .B(n735), .Y(n816) );
  NOR2X1 I1093 ( .A(n598), .B(n599), .Y(n235) );
  NAND3X1 I1094 ( .A(n831), .B(n832), .C(n833), .Y(n813) );
  NAND2X1 I1095 ( .A(CS3), .B(n834), .Y(n832) );
  NAND2X1 I1096 ( .A(n759), .B(n820), .Y(n833) );
  OR2X2 I1097 ( .A(MOVX_DPI), .B(MOVX_RI), .Y(n14) );
  NOR2X1 I1098 ( .A(n751), .B(n819), .Y(n818) );
  INVX1 I1099 ( .A(LS1), .Y(n819) );
  OAI2BB1X1 I1100 ( .A0N(LS1), .A1N(n813), .B0(n814), .Y(MAR_RI_EN) );
  AOI22X1 I1101 ( .A0(n112), .A1(n715), .B0(n815), .B1(n690), .Y(n814) );
  NAND2X1 I1102 ( .A(n713), .B(n809), .Y(n822) );
  NAND2X2 I1103 ( .A(n533), .B(n596), .Y(n656) );
  NAND2X1 I1104 ( .A(n941), .B(n630), .Y(n809) );
  AOI22X1 I1105 ( .A0(n790), .A1(CS4), .B0(n791), .B1(n512), .Y(n778) );
  AOI21X1 I1106 ( .A0(n795), .A1(n796), .B0(n797), .Y(n790) );
  NAND3X1 I1107 ( .A(n806), .B(n271), .C(n625), .Y(n805) );
  AOI21X1 I1108 ( .A0(n808), .A1(n809), .B0(n789), .Y(n806) );
  NAND2X1 I1109 ( .A(n533), .B(n948), .Y(n613) );
  NAND2X1 I1110 ( .A(n649), .B(n626), .Y(n730) );
  NAND2X1 I1111 ( .A(n686), .B(n527), .Y(n683) );
  NAND2X1 I1112 ( .A(n686), .B(n687), .Y(n682) );
  AND2X2 I1113 ( .A(n759), .B(n948), .Y(n563) );
  AND2X2 I1114 ( .A(n948), .B(n713), .Y(n564) );
  NOR2X1 I1115 ( .A(MOVX_RI_A), .B(MOVX_RI), .Y(n565) );
  NOR2X1 I1116 ( .A(n850), .B(n526), .Y(ID_T2_EN) );
  NOR3X1 I1117 ( .A(n851), .B(MAR_T1_EN), .C(n852), .Y(n850) );
  AND2X2 I1118 ( .A(n791), .B(n939), .Y(n566) );
  NOR2BX1 I1119 ( .AN(n600), .B(n381), .Y(n567) );
  OR2X2 I1120 ( .A(MOVX_DPI_A), .B(MOVX_RI_A), .Y(n15) );
  NAND2X1 I1121 ( .A(n765), .B(n600), .Y(n787) );
  OAI21X1 I1122 ( .A0(n757), .A1(n663), .B0(n758), .Y(n740) );
  NOR2X1 I1123 ( .A(n688), .B(n763), .Y(n757) );
  NOR2X1 I1124 ( .A(n941), .B(n526), .Y(n762) );
  NOR2X1 I1125 ( .A(MAR_BAR_EN), .B(n753), .Y(n741) );
  NAND2BX1 I1126 ( .AN(LS3), .B(n612), .Y(n755) );
  INVX1 I1127 ( .A(LS2), .Y(n752) );
  NAND3BX1 I1128 ( .AN(n740), .B(n741), .C(n742), .Y(RAM_RD_EN) );
  NOR2X1 I1129 ( .A(n890), .B(n891), .Y(ALU_ORL_EN) );
  NOR2X1 I1130 ( .A(n892), .B(n893), .Y(n890) );
  AOI21X1 I1131 ( .A0(n574), .A1(n527), .B0(n811), .Y(n810) );
  NAND3X1 I1132 ( .A(n648), .B(n647), .C(n646), .Y(n837) );
  OAI21X1 I1133 ( .A0(n812), .A1(n947), .B0(n839), .Y(n838) );
  NAND2X1 I1134 ( .A(n952), .B(n527), .Y(n839) );
  AND3X2 I1135 ( .A(IR[5]), .B(n917), .C(IR[6]), .Y(n570) );
  NAND3X1 I1136 ( .A(n704), .B(n931), .C(n734), .Y(n864) );
  NOR2X1 I1137 ( .A(n812), .B(n807), .Y(n811) );
  NAND2X1 I1138 ( .A(n739), .B(n541), .Y(n927) );
  NAND3BX1 I1139 ( .AN(n930), .B(n624), .C(n649), .Y(n928) );
  AND2X2 I1140 ( .A(n574), .B(n693), .Y(n571) );
  INVX1 I1141 ( .A(n933), .Y(n906) );
  NAND3BX1 I1142 ( .AN(n943), .B(n918), .C(n922), .Y(n761) );
  NAND2X1 I1143 ( .A(n514), .B(n541), .Y(n826) );
  NAND2X1 I1144 ( .A(n631), .B(n632), .Y(n827) );
  NOR3X1 I1145 ( .A(n541), .B(n952), .C(n574), .Y(n929) );
  NAND2X1 I1146 ( .A(n704), .B(n541), .Y(n829) );
  OAI21X1 I1147 ( .A0(n844), .A1(n845), .B0(n846), .Y(n843) );
  NOR2X1 I1148 ( .A(n527), .B(n847), .Y(n844) );
  AOI22X1 I1149 ( .A0(n948), .A1(n631), .B0(n533), .B1(n527), .Y(n846) );
  NAND3X1 I1150 ( .A(n644), .B(n623), .C(n885), .Y(n884) );
  NOR2X1 I1151 ( .A(n845), .B(n951), .Y(n874) );
  OAI21X1 I1152 ( .A0(n917), .A1(n770), .B0(n606), .Y(n725) );
  NAND2BX1 I1153 ( .AN(n807), .B(n514), .Y(n824) );
  NOR3BX1 I1154 ( .AN(n734), .B(n825), .C(n941), .Y(A_IDATA_EN) );
  NOR2X1 I1155 ( .A(n777), .B(n685), .Y(n775) );
  NAND3X1 I1156 ( .A(n774), .B(n596), .C(n729), .Y(n776) );
  NAND2X1 I1157 ( .A(n958), .B(n801), .Y(n802) );
  NOR2X2 I1158 ( .A(n685), .B(n800), .Y(MOVX_RI_A) );
  NAND2X1 I1159 ( .A(n958), .B(n801), .Y(n800) );
  INVX1 I1160 ( .A(n809), .Y(n841) );
  OAI21X1 I1161 ( .A0(n539), .A1(n510), .B0(n782), .Y(PC_HOLD) );
  NOR2X1 I1162 ( .A(n848), .B(n849), .Y(INT_EN_1_EN) );
  NAND2X1 I1163 ( .A(n574), .B(n948), .Y(n600) );
  INVX1 I1164 ( .A(n919), .Y(n924) );
  OR2X2 I1165 ( .A(IR[2]), .B(IR[0]), .Y(n573) );
  NAND2X1 I1166 ( .A(IR[1]), .B(n925), .Y(n933) );
  NOR3BX1 I1167 ( .AN(IR[2]), .B(n933), .C(n942), .Y(n840) );
  AND2X2 I1168 ( .A(IR[3]), .B(n923), .Y(n574) );
  NOR2X1 I1169 ( .A(n796), .B(n508), .Y(CY_CJNE_EN) );
  DFFRHQX2 ID_PCH_EN_g_reg ( .D(ID_PCH_EN), .CK(CLK), .RN(n1), .Q(ID_PCH_EN_g)
         );
  DFFRHQX2 ID_PCL_EN_g_reg ( .D(n566), .CK(CLK), .RN(n1), .Q(ID_PCL_EN_g) );
  DFFRHQX2 WM_EN_g_reg ( .D(WM_EN), .CK(CLK), .RN(n1), .Q(WM_EN_g) );
  NAND2X1 I1170 ( .A(n958), .B(IR[2]), .Y(n947) );
  OAI22X4 I1171 ( .A0(n673), .A1(n531), .B0(n612), .B1(n756), .Y(MAR_SP_EN) );
  NAND4X2 I1172 ( .A(n876), .B(n877), .C(n860), .D(n878), .Y(ALU_SUB_EN) );
  NAND3BX4 I1173 ( .AN(IR[3]), .B(n907), .C(n801), .Y(n919) );
  AND3X1 I1174 ( .A(CS1), .B(n13), .C(MOVC_INS), .Y(CAR_OUT_EN) );
endmodule


module IR_DECODER1 ( DIR_WR, RETI, IR, CYCLE2, CYCLE3, CYCLE4, BYTE2, BYTE3 );
  input [7:0] IR;
  output DIR_WR, RETI, CYCLE2, CYCLE3, CYCLE4, BYTE2, BYTE3;
  wire   n99, n100, n101, n102, n103, n104, n105, n106, n107, n108, n109, n110,
         n111, n112, n113, n114, n115, n116, n117, n118, n119, n120, n121,
         n122, n123, n124, n125, n126, n127, n128, n129, n130, n131, n132,
         n133, n134, n135, n136, n137, n138, n139, n140, n141, n142, n143,
         n144, n145, n146, n147, n148, n149, n150, n151, n152, n153, n154,
         n155, n156, n157, n158, n159, n160, n161, n162, n163, n164, n165,
         n166, n167, n168, n169, n170, n171, n172, n173, n174, n175, n176,
         n177, n178, n179, n180, n181, n182, n183, n184, n185, n186, n187,
         n188, n189, n190, n191, n192, n193, n194, n195, n196, n197, n198,
         n199, n200, n201, n202, n203, n204, n205, n206, n207, n208, n209,
         n210, n211, n212, n213, n214, n215, n216, n217, n218, n219, n220,
         n221;

  OAI2BB1X1 I106 ( .A0N(n200), .A1N(n153), .B0(n209), .Y(n214) );
  AOI211X1 I107 ( .A0(n193), .A1(n194), .B0(n106), .C0(n120), .Y(n99) );
  INVX1 I108 ( .A(n99), .Y(n171) );
  NAND2X1 I109 ( .A(IR[7]), .B(n158), .Y(n168) );
  OR4X2 I110 ( .A(n153), .B(n188), .C(n114), .D(n187), .Y(n118) );
  NAND3X1 I111 ( .A(n153), .B(n157), .C(n158), .Y(n204) );
  AND4X2 I112 ( .A(n172), .B(n169), .C(n170), .D(n171), .Y(n148) );
  NAND2BX1 I113 ( .AN(n200), .B(n201), .Y(n105) );
  OR3X2 I114 ( .A(n183), .B(n106), .C(n120), .Y(n122) );
  OAI21X1 I115 ( .A0(n125), .A1(n126), .B0(n127), .Y(n143) );
  AOI21X1 I116 ( .A0(n100), .A1(n165), .B0(n161), .Y(n160) );
  INVX1 I117 ( .A(n162), .Y(n100) );
  OAI2BB1X1 I118 ( .A0N(n121), .A1N(n135), .B0(n103), .Y(n134) );
  AND3X2 I119 ( .A(n168), .B(n167), .C(n127), .Y(n159) );
  AND3X1 I120 ( .A(n103), .B(n121), .C(n127), .Y(n119) );
  AOI2BB2X1 I121 ( .A0N(n133), .A1N(n134), .B0(n132), .B1(n131), .Y(n130) );
  NOR2X1 I122 ( .A(n112), .B(n158), .Y(n113) );
  INVX1 I123 ( .A(IR[7]), .Y(n221) );
  NAND2X1 I124 ( .A(n167), .B(n221), .Y(n139) );
  OAI21X1 I125 ( .A0(n109), .A1(n110), .B0(n135), .Y(n172) );
  NAND4BX2 I126 ( .AN(IR[3]), .B(n206), .C(IR[2]), .D(IR[0]), .Y(n120) );
  NAND4BX1 I127 ( .AN(n147), .B(n142), .C(n143), .D(n118), .Y(CYCLE3) );
  OAI21X1 I128 ( .A0(n113), .A1(n144), .B0(n145), .Y(n142) );
  INVX2 I129 ( .A(n120), .Y(n127) );
  NAND4X2 I130 ( .A(IR[1]), .B(n166), .C(n145), .D(n220), .Y(n101) );
  NAND4BX2 I131 ( .AN(IR[6]), .B(n121), .C(IR[7]), .D(IR[4]), .Y(n158) );
  NAND3BX1 I132 ( .AN(n156), .B(n157), .C(n158), .Y(n151) );
  OAI21X1 I133 ( .A0(n101), .A1(n153), .B0(n154), .Y(n152) );
  INVX2 I134 ( .A(IR[1]), .Y(n206) );
  INVX2 I135 ( .A(IR[0]), .Y(n166) );
  INVX2 I136 ( .A(IR[6]), .Y(n167) );
  NAND2X1 I137 ( .A(n102), .B(n130), .Y(CYCLE4) );
  NOR2X1 I138 ( .A(n159), .B(n160), .Y(n149) );
  INVX3 I139 ( .A(IR[3]), .Y(n220) );
  INVX2 I140 ( .A(IR[2]), .Y(n145) );
  INVX1 I141 ( .A(IR[4]), .Y(n135) );
  NAND2X1 I142 ( .A(IR[7]), .B(n167), .Y(n181) );
  NAND2X1 I143 ( .A(IR[0]), .B(IR[1]), .Y(n188) );
  AOI21X2 I144 ( .A0(n132), .A1(n151), .B0(n152), .Y(n150) );
  NAND4X1 I145 ( .A(IR[7]), .B(n135), .C(n121), .D(n167), .Y(n200) );
  NAND4X1 I146 ( .A(IR[2]), .B(n166), .C(n206), .D(n220), .Y(n179) );
  NAND2X1 I147 ( .A(IR[2]), .B(IR[1]), .Y(n180) );
  NAND2X1 I148 ( .A(n199), .B(n138), .Y(n170) );
  NOR2X1 I149 ( .A(n210), .B(n211), .Y(n110) );
  INVX1 I150 ( .A(n101), .Y(n138) );
  NAND4BX1 I151 ( .AN(IR[7]), .B(IR[5]), .C(IR[6]), .D(IR[4]), .Y(n178) );
  NAND4X1 I152 ( .A(n179), .B(n180), .C(n120), .D(n220), .Y(n141) );
  NOR2X1 I153 ( .A(n181), .B(n182), .Y(n140) );
  INVX1 I154 ( .A(n179), .Y(n132) );
  INVX4 I155 ( .A(IR[5]), .Y(n121) );
  AND3X2 I156 ( .A(n122), .B(n129), .C(n128), .Y(n102) );
  OAI21X1 I157 ( .A0(n184), .A1(IR[4]), .B0(n185), .Y(n123) );
  NAND2X2 I158 ( .A(IR[7]), .B(IR[6]), .Y(n106) );
  NAND4BX2 I159 ( .AN(n107), .B(n148), .C(n149), .D(n150), .Y(CYCLE2) );
  NAND2X2 I160 ( .A(IR[6]), .B(n221), .Y(n153) );
  OR2X2 I161 ( .A(n139), .B(n121), .Y(n157) );
  INVX1 I162 ( .A(n139), .Y(n103) );
  AND2X2 I163 ( .A(n123), .B(n122), .Y(n176) );
  OR2X2 I164 ( .A(IR[1]), .B(IR[0]), .Y(n115) );
  NAND2X1 I165 ( .A(IR[4]), .B(n121), .Y(n183) );
  INVX1 I166 ( .A(n178), .Y(n125) );
  NOR2X1 I167 ( .A(IR[4]), .B(n136), .Y(n131) );
  NAND2X1 I168 ( .A(n121), .B(n135), .Y(n193) );
  AND4X1 I169 ( .A(n105), .B(n191), .C(n192), .D(n171), .Y(n104) );
  OAI21X1 I170 ( .A0(n114), .A1(n153), .B0(n196), .Y(n195) );
  AND2X1 I171 ( .A(n170), .B(n169), .Y(n191) );
  NAND2X1 I172 ( .A(n173), .B(n174), .Y(n107) );
  NOR2X1 I173 ( .A(n106), .B(n146), .Y(n144) );
  OAI2BB1X1 I174 ( .A0N(n220), .A1N(n180), .B0(n205), .Y(n173) );
  AND2X1 I175 ( .A(IR[4]), .B(IR[5]), .Y(n114) );
  NAND3X1 I176 ( .A(n108), .B(n117), .C(n104), .Y(DIR_WR) );
  AND3X1 I177 ( .A(n122), .B(n123), .C(n124), .Y(n108) );
  NAND2X1 I178 ( .A(n213), .B(n214), .Y(n147) );
  NOR2X1 I179 ( .A(n101), .B(n136), .Y(n109) );
  NAND2BX1 I180 ( .AN(n115), .B(n215), .Y(n112) );
  NAND2BX1 I181 ( .AN(n115), .B(n215), .Y(n111) );
  INVX1 I182 ( .A(n200), .Y(n126) );
  NAND2X1 I183 ( .A(n140), .B(n141), .Y(n128) );
  NAND2X1 I184 ( .A(n137), .B(n138), .Y(n129) );
  OAI21X1 I185 ( .A0(n207), .A1(n208), .B0(n209), .Y(n174) );
  NOR2X1 I186 ( .A(n121), .B(n181), .Y(n208) );
  NOR2X1 I187 ( .A(n106), .B(n193), .Y(n207) );
  NAND2X1 I188 ( .A(IR[7]), .B(n167), .Y(n136) );
  INVX1 I189 ( .A(n153), .Y(n156) );
  NOR2X1 I190 ( .A(n106), .B(n183), .Y(n217) );
  NAND2X1 I191 ( .A(n195), .B(n138), .Y(n192) );
  AOI21X1 I192 ( .A0(n140), .A1(n141), .B0(n113), .Y(n177) );
  NAND3X1 I193 ( .A(IR[7]), .B(n167), .C(IR[4]), .Y(n196) );
  OAI2BB1X1 I194 ( .A0N(n132), .A1N(n204), .B0(n173), .Y(n203) );
  NAND2X1 I195 ( .A(n103), .B(n121), .Y(n186) );
  OAI21X1 I196 ( .A0(n125), .A1(n126), .B0(n127), .Y(n124) );
  NAND2X1 I197 ( .A(IR[4]), .B(IR[5]), .Y(n194) );
  MXI2X1 I198 ( .S0(IR[6]), .B(n164), .A(n163), .Y(n162) );
  NAND3X1 I199 ( .A(IR[4]), .B(n221), .C(IR[5]), .Y(n164) );
  NAND3X1 I200 ( .A(n220), .B(n121), .C(IR[7]), .Y(n163) );
  NAND2X1 I201 ( .A(IR[4]), .B(IR[5]), .Y(n182) );
  NAND2X1 I202 ( .A(n155), .B(n127), .Y(n154) );
  NOR2X1 I203 ( .A(IR[5]), .B(n153), .Y(n155) );
  NAND4X1 I204 ( .A(n166), .B(n167), .C(n220), .D(IR[5]), .Y(n165) );
  NAND3X1 I205 ( .A(n206), .B(n220), .C(IR[0]), .Y(n210) );
  NAND2BX1 I206 ( .AN(n112), .B(n198), .Y(n169) );
  NOR2X1 I207 ( .A(n106), .B(n183), .Y(n198) );
  NOR2X1 I208 ( .A(IR[5]), .B(n139), .Y(n137) );
  OAI21X1 I209 ( .A0(IR[4]), .A1(n136), .B0(n178), .Y(n205) );
  NOR2X1 I210 ( .A(IR[5]), .B(n106), .Y(n199) );
  INVX1 I211 ( .A(n111), .Y(n209) );
  NAND2X1 I212 ( .A(IR[5]), .B(n220), .Y(n146) );
  NAND2X1 I213 ( .A(n145), .B(n220), .Y(n187) );
  NAND3X1 I214 ( .A(n189), .B(n190), .C(n104), .Y(BYTE2) );
  NOR2X1 I215 ( .A(n212), .B(n147), .Y(n189) );
  NOR2X1 I216 ( .A(n202), .B(n203), .Y(n190) );
  OAI21X1 I217 ( .A0(n178), .A1(n101), .B0(n218), .Y(n212) );
  NAND4BX1 I218 ( .AN(n175), .B(n176), .C(n177), .D(n143), .Y(BYTE3) );
  OAI21X1 I219 ( .A0(n101), .A1(n186), .B0(n118), .Y(n175) );
  NOR2X1 I220 ( .A(n111), .B(n139), .Y(n185) );
  INVX1 I221 ( .A(n157), .Y(n184) );
  NAND2X1 I222 ( .A(IR[4]), .B(IR[5]), .Y(n197) );
  NAND2X1 I223 ( .A(n172), .B(n174), .Y(n202) );
  NAND2X1 I224 ( .A(n219), .B(n168), .Y(n218) );
  AOI2BB1X1 I225 ( .A0N(n197), .A1N(n167), .B0(n120), .Y(n219) );
  NAND2BX1 I226 ( .AN(IR[3]), .B(n180), .Y(n201) );
  NOR2BX1 I227 ( .AN(n118), .B(n119), .Y(n117) );
  NOR2X1 I228 ( .A(n101), .B(n116), .Y(RETI) );
  NAND3X1 I229 ( .A(IR[4]), .B(n103), .C(IR[5]), .Y(n116) );
  NAND2BX1 I230 ( .AN(n115), .B(n215), .Y(n133) );
  MXI2X1 I231 ( .S0(IR[3]), .B(n217), .A(n216), .Y(n213) );
  NAND2X1 I232 ( .A(IR[1]), .B(n145), .Y(n161) );
  NOR3X1 I233 ( .A(n166), .B(IR[2]), .C(IR[1]), .Y(n216) );
  NAND2X1 I234 ( .A(IR[6]), .B(IR[2]), .Y(n211) );
  NOR2X1 I235 ( .A(IR[3]), .B(IR[2]), .Y(n215) );
endmodule


module iram_intf ( IDATA, MAR_RI_EN, RAM_RD_EN, ID_PCH_EN, ID_PCL_EN, ID_T2_EN, 
        WM_EN, SFR_wr, MAR, RAMADDR, IRAM_DIN, RAM_CS_B, RAM_OE_B, RAM_WE_B, 
        ID_WR_EN );
  input [7:0] IDATA;
  input [8:0] MAR;
  output [7:0] RAMADDR;
  output [7:0] IRAM_DIN;
  input MAR_RI_EN, RAM_RD_EN, ID_PCH_EN, ID_PCL_EN, ID_T2_EN, WM_EN;
  output SFR_wr, RAM_CS_B, RAM_OE_B, RAM_WE_B, ID_WR_EN;
  wire   n1, n4, n6, n8, n10, n12, n14, n16, n18, n20, n22, n24, n26, n28, n30,
         n32, n34;

  OR2X2 I8 ( .A(ID_T2_EN), .B(WM_EN), .Y(SFR_wr) );
  OR3X2 I9 ( .A(ID_PCL_EN), .B(ID_PCH_EN), .C(SFR_wr), .Y(ID_WR_EN) );
  NOR2X1 I10 ( .A(RAM_RD_EN), .B(MAR_RI_EN), .Y(RAM_OE_B) );
  INVX1 I11 ( .A(n4), .Y(IRAM_DIN[0]) );
  INVX1 I12 ( .A(IDATA[0]), .Y(n4) );
  INVX1 I13 ( .A(n6), .Y(IRAM_DIN[1]) );
  INVX1 I14 ( .A(IDATA[1]), .Y(n6) );
  AND2X2 I15 ( .A(RAM_OE_B), .B(RAM_WE_B), .Y(RAM_CS_B) );
  OR2X2 I16 ( .A(n1), .B(MAR[8]), .Y(RAM_WE_B) );
  INVX1 I17 ( .A(ID_WR_EN), .Y(n1) );
  INVX1 I18 ( .A(n34), .Y(RAMADDR[7]) );
  INVX1 I19 ( .A(MAR[7]), .Y(n34) );
  INVX1 I20 ( .A(n32), .Y(RAMADDR[6]) );
  INVX1 I21 ( .A(MAR[6]), .Y(n32) );
  INVX1 I22 ( .A(n30), .Y(RAMADDR[5]) );
  INVX1 I23 ( .A(MAR[5]), .Y(n30) );
  INVX1 I24 ( .A(n28), .Y(RAMADDR[4]) );
  INVX1 I25 ( .A(MAR[4]), .Y(n28) );
  INVX1 I26 ( .A(n26), .Y(RAMADDR[3]) );
  INVX1 I27 ( .A(MAR[3]), .Y(n26) );
  INVX1 I28 ( .A(n24), .Y(RAMADDR[2]) );
  INVX1 I29 ( .A(MAR[2]), .Y(n24) );
  INVX1 I30 ( .A(n22), .Y(RAMADDR[1]) );
  INVX1 I31 ( .A(MAR[1]), .Y(n22) );
  INVX1 I32 ( .A(n20), .Y(RAMADDR[0]) );
  INVX1 I33 ( .A(MAR[0]), .Y(n20) );
  INVX1 I34 ( .A(n18), .Y(IRAM_DIN[7]) );
  INVX1 I35 ( .A(IDATA[7]), .Y(n18) );
  INVX1 I36 ( .A(n16), .Y(IRAM_DIN[6]) );
  INVX1 I37 ( .A(IDATA[6]), .Y(n16) );
  INVX1 I38 ( .A(n14), .Y(IRAM_DIN[5]) );
  INVX1 I39 ( .A(IDATA[5]), .Y(n14) );
  INVX1 I40 ( .A(n12), .Y(IRAM_DIN[4]) );
  INVX1 I41 ( .A(IDATA[4]), .Y(n12) );
  INVX1 I42 ( .A(n10), .Y(IRAM_DIN[3]) );
  INVX1 I43 ( .A(IDATA[3]), .Y(n10) );
  INVX1 I44 ( .A(n8), .Y(IRAM_DIN[2]) );
  INVX1 I45 ( .A(IDATA[2]), .Y(n8) );
endmodule

