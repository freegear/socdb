README.txt                    : This file
IP_basic_spec.pdf             : IP basic specification.
IP8052_edif.zip               : IP8052 EDIF files for Xilinx FPGA
coregen.zip                   : Memory model for Xilinx FPGA test.
core_top.zip                  : Module top description and basic reset, clk block
