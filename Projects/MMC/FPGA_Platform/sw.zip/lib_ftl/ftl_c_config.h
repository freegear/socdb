#ifndef _FTL_C_CONFIG_H_
#define	_FTL_C_CONFIG_H_


/****************************************************************************
 *
 *            Copyright (c) 2005-2006 by HCC Embedded
 *
 * This software is copyrighted by and is the sole property of
 * HCC.  All rights, title, ownership, or other interests
 * in the software remain the property of HCC.  This
 * software may only be used in accordance with the corresponding
 * license agreement.  Any unauthorized use, duplication, transmission,
 * distribution, or disclosure of this software is expressly forbidden.
 *
 * This Copyright notice may not be removed or modified without prior
 * written consent of HCC.
 *
 * HCC reserves the right to modify this software without notice.
 *
 * HCC Embedded
 * Budapest 1132
 * Victor Hugo Utca 11-15
 * Hungary
 *
 * Tel:  +36 (1) 450 1302
 * Fax:  +36 (1) 450 1303
 * http: www.hcc-embedded.com
 * email: info@hcc-embedded.com
 *
 ***************************************************************************/
 /*----------------------------------------------------------
	 Developed by S/W Team, SHMT.Co
	 Copyright @ 2006 SHMT. Co
	 All Rights Reserved.
----------------------------------------------------------*/
/*
/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// 
*/
/*
/////////////////////////////////////////////////////////
        TYPE DEFINITION
///////////////////////////////////////////////////////// 
*/
/*
/////////////////////////////////////////////////////////
        GLOBAL VARIABLE  
///////////////////////////////////////////////////////// 
*/
/*
/////////////////////////////////////////////////////////
        FUNCTIONS 
///////////////////////////////////////////////////////// 
*/

#define	USE_ONLY512

/*
/////////////////////////////////////////////////////////
		MACRO DEFINITION
/////////////////////////////////////////////////////////
*/
// Signal version of 1.30 
#define FTL_VERSION 130										
#ifdef WIN32
// MAX block available
#define MAX_BLOCK_AVAILABLE				(16384)				
// Page per block
#define MAX_PAGE_PER_BLOCK_AVAILABLE	(64)				
// Free block available
#define MAX_FREE_BLOCK_AVAILABLE		(40)			
// Log block available
#define MAX_LOG_BLOCK_AVAILABLE			(2)					
// Number of different map from 1-16 
#define	FTL_MAPBLOCK_NUM				(4)
// number of shadow map block per different maps 		
#define	FTL_MAPBLOCK_DEPTH				(3)	
#else
// MAX block available
#define MAX_BLOCK_AVAILABLE				(200)				
// Page per block
#define MAX_PAGE_PER_BLOCK_AVAILABLE	(2)				
// Free block available
#define MAX_FREE_BLOCK_AVAILABLE		(40)	
// Log block available
#define MAX_LOG_BLOCK_AVAILABLE			(1)					
// Number of different map from 1-16 
#define	FTL_MAPBLOCK_NUM				(2)
// number of shadow map block per different maps 			
#define	FTL_MAPBLOCK_DEPTH				(1)			
#endif


// number of cacheable fragments optimum is 4 <depending on RAM>, minimum is 1
#define MAX_CACHEFRAG					(1)			


#define	MAX_FRAG_BLOCK_AVAILABLE		(2)

//-----------------------------------------------------------
// make Size define
//-----------------------------------------------------------
#ifdef USE_ONLY512
#define MAX_DATA_SIZE   				(512)
#else
#define MAX_DATA_SIZE   				(2048)
#endif
#define MAX_SPARE_SIZE  				(sizeof(ST_SPARE))
#define MAX_PAGE_SIZE	 				(MAX_DATA_SIZE + MAX_SPARE_SIZE)
#endif
//-----------------------------------------------------------
// make Fragment size
//-----------------------------------------------------------
#define MAX_FRAGSIZE 					((gDevInfo.pageSize/2)/sizeof (smtBlkAddr))
#if defined(USE_ONLY512)
	#define MAX_FRAGNUM_AVAILABLE 												\
		(MAX_BLOCK_AVAILABLE / ((MAX_DATA_SIZE/2)/sizeof (smtBlkAddr)) )
#else
#if defined(USE_ONLY2048)
	#define MAX_FRAGNUM_AVAILABLE  												\
		(MAX_BLOCK_AVAILABLE / ((MAX_DATA_SIZE/2)/sizeof (smtBlkAddr)) )
#else
	#define MAX_FRAGNUM_AVAILABLE  												\
		(MAX_BLOCK_AVAILABLE / (512/2/sizeof (smtBlkAddr)))
#endif
#endif	//_FTL_C_CONFIG_H_