/****************************************************************************
 *
 *            Copyright (c) 2005-2006 by HCC Embedded
 *
 * This software is copyrighted by and is the sole property of
 * HCC.  All rights, title, ownership, or other interests
 * in the software remain the property of HCC.  This
 * software may only be used in accordance with the corresponding
 * license agreement.  Any unauthorized use, duplication, transmission,
 * distribution, or disclosure of this software is expressly forbidden.
 *
 * This Copyright notice may not be removed or modified without prior
 * written consent of HCC.
 *
 * HCC reserves the right to modify this software without notice.
 *
 * HCC Embedded
 * Budapest 1132
 * Victor Hugo Utca 11-15
 * Hungary
 *
 * Tel:  +36 (1) 450 1302
 * Fax:  +36 (1) 450 1303
 * http: www.hcc-embedded.com
 * email: info@hcc-embedded.com
 *
 ***************************************************************************/
 /*----------------------------------------------------------
	 Developed by S/W Team, SHMT.Co
	 Copyright @ 2006 SHMT. Co
	 All Rights Reserved.
----------------------------------------------------------*/
/*
/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// 
*/
#include <stdio.h>
#include <string.h>
#include "ftl_o_gabarge.h"
#include "ftl_o_rw.h"
/*
/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// 
*/
/*
/////////////////////////////////////////////////////////
        GLOBAL VARIABLE
///////////////////////////////////////////////////////// 
*/
/*
/////////////////////////////////////////////////////////
        STATIC VARIABLE
///////////////////////////////////////////////////////// 
*/
/*
/////////////////////////////////////////////////////////
        FUNCTIONS 
///////////////////////////////////////////////////////// 
*/
/*----------------------------------------------------------
	Function name	:	FTL_Format
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
smtBoolean 
FTL_Format(
void
)
{
	smtBoolean ret;

	ret = FTL_O_LowInit(); 
	if(ret == SMT_FALSE) {
		printf("FTL_LowInit fail!!!\n");
		return SMT_FALSE;
	}

	ret = FTL_O_Format();
	if(ret == SMT_FALSE) {
		printf("FTL_O_Format fail!!!\n");
		return SMT_FALSE;
	}

	return SMT_TRUE;
}

/*----------------------------------------------------------
	Function name	:	FTL_Init
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
smtBoolean 
FTL_Init(
void
)
{
	
	smtBoolean ret;

	ret = FTL_O_LowInit();
	if(ret == SMT_FALSE) {
		printf("FTL_O_LowInit fail!!!\n");
		return SMT_FALSE;
	}

	ret = FTL_O_Init();
	if(ret == SMT_FALSE){
		printf("FTL_O_Init fail!!!\n");
		return SMT_FALSE;
	}

	ret = FTL_O_BuildCache();
	if(ret == SMT_FALSE){
		printf("FTL_O_BuildCache fail!!!\n");
		return SMT_FALSE;
	}

	return SMT_TRUE;
}
/*----------------------------------------------------------
	Function name	:	FTL_Deinit
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
smtBoolean
FTL_Deinit(
void
)
{
	return SMT_TRUE;
}

/*----------------------------------------------------------
	Function name	:	FTL_Write
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
smtBoolean
FTL_Write(
smtUint32	sector, // sector address
smtUint32	num,	// number of sector
smtUint32	buffer	// source buffer
)
{

	smtUint32 sectorCount;
	int	ret;

	ret = FTL_O_Open(sector, num, ML_WRITE);
	if(ret == SMT_FALSE) {
		printf("FTL_Write::FTL_O_Open fail!!!\n");
		return SMT_FALSE;
	}

	for(sectorCount = 0; sectorCount < num; sectorCount++)
	{
retry:
		ret = FTL_O_Write((smtUint8*)buffer + (512*sectorCount));
		if(ret == 2) 
		{
			FTL_O_GCollect();
			goto retry;
		}

		if(ret == 1) {
			printf("FTL_Write::FTL_O_Write fail!!!\n");
			return SMT_FALSE;
		}
	}
	
	ret = FTL_O_Close();
	if(ret == SMT_FALSE){
		printf("FTL_Write::FTL_O_Close fail!!!\n");
		return SMT_FALSE;
	}

	return SMT_TRUE;
}
/*----------------------------------------------------------
	Function name	:	FTL_Read
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
smtBoolean
FTL_Read(
smtUint32	sector,	// sector address
smtUint32	num,	// number of sector
smtUint32	buffer	// target buffer
)
{
	smtUint32	sectorCount;
	smtBoolean	ret;

	ret = FTL_O_Open(sector, num, ML_READ);
	if(ret == SMT_FALSE) {
		printf("FTL_Read::FTL_O_Open fail!!!\n");
		return SMT_FALSE;
	}

	for(sectorCount = 0; sectorCount < num; sectorCount++)
	{
		ret = FTL_O_Read((smtUint8*)(buffer + (512*sectorCount)));
		if(ret) {
			printf("FTL_Read::FTL_O_Read fail!!!\n");
			return SMT_FALSE;
		}
	}

	ret = FTL_O_Close();
	if(ret == SMT_FALSE) {
		printf("FTL_Read::FTL_O_Close fail!!!\n");
		return SMT_FALSE;
	}
	
	return SMT_TRUE;
}
/*----------------------------------------------------------
	Function name	:	FTL_GetMaxSectors
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
smtUint32 
FTL_GetMaxSectors(
void
)
{
	return FTL_O_GetMaxSector();
}