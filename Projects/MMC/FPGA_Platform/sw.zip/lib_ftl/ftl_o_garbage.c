/****************************************************************************
 *
 *            Copyright (c) 2005-2006 by HCC Embedded
 *
 * This software is copyrighted by and is the sole property of
 * HCC.  All rights, title, ownership, or other interests
 * in the software remain the property of HCC.  This
 * software may only be used in accordance with the corresponding
 * license agreement.  Any unauthorized use, duplication, transmission,
 * distribution, or disclosure of this software is expressly forbidden.
 *
 * This Copyright notice may not be removed or modified without prior
 * written consent of HCC.
 *
 * HCC reserves the right to modify this software without notice.
 *
 * HCC Embedded
 * Budapest 1132
 * Victor Hugo Utca 11-15
 * Hungary
 *
 * Tel:  +36 (1) 450 1302
 * Fax:  +36 (1) 450 1303
 * http: www.hcc-embedded.com
 * email: info@hcc-embedded.com
 *
 ***************************************************************************/
 /*----------------------------------------------------------
	 Developed by S/W Team, SHMT.Co
	 Copyright @ 2006 SHMT. Co
	 All Rights Reserved.
----------------------------------------------------------*/
/*
/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// 
*/
#include <string.h>
#include "../lib_nand/ftl_l_layer.h"
#include "ftl_t_define.h"
#include "ftl_o_rw.h"
#include "ftl_w_wear.h"
#include "ftl_c_core.h"


/*
/////////////////////////////////////////////////////////
        GLOBAL VARIABLE DECLARE
///////////////////////////////////////////////////////// 
*/

/*
/////////////////////////////////////////////////////////
        FUNCTIONS 
///////////////////////////////////////////////////////// 
*/
/*----------------------------------------------------------
	Function name	: ml_dostatic
	Prototype		: 
	Return			: none
	Argument		: 
	Comments		: does static wear leveling, its read logical
					  block, updates static wear info, and if static
					  request is comming, then copy the block
-----------------------------------------------------------*/
static 
void 
ml_dostatic(
void
)
{
	smtUint32 		wear;
	smtBlkAddr 		pba;
	smtBlkAddr 		static_lba;

	//-------------------------------------------------------
	// Get next static LBA
	//-------------------------------------------------------
	static_lba	= FTL_W_GetStaticLBA();
	for (;;)
	{
		static_lba++;
		if (static_lba >= gDevInfo.dataBlks) 
		{
			static_lba = 0;
		}

		pba = FTL_C_GetPhy(static_lba);
		if (pba != BLK_NA) 
		{
			break;
		}

		static_lba = 0;
		pba = FTL_C_GetPhy(static_lba);
		if (pba != BLK_NA) 
		{
			break;
		}
	}
	FTL_W_SetStaticLBA(static_lba);


	//-------------------------------------------------------
	// Copy block ?? 
	//-------------------------------------------------------
	if(!FTL_L_Read(
		pba,
		0,
		ml_buffer)	// 
	)
	{ // get original 
		
	 	wear = GET_SPARE_AREA(ml_buffer)->wear;
		if (wear<WEAR_NA) 
		{
			FTL_W_UpdateSInfo(static_lba,wear);
		}
		else 
		{
			FTL_W_UpdateSInfo(static_lba,0);
		}
	}
	else 
	{
		FTL_W_UpdateSInfo(static_lba,0);
	}

	if(FTL_W_ChkStatic())
	{
		smtPageAddr 		po;
		smtBlkAddr 		d_pba,lba;
		smtBlkAddr 		s_pba;
		smtUint8  	index = gl_wear_allocstruct.free_index;

		if(index == INDEX_NA) 
		{
			return;
		}
		//d_pba = gl_freetable[index];
		d_pba = gFlush.freeBlks[index];

		if(FTL_L_Erase(d_pba) ==  FTL_L_ERROR)
		{
			// signal it and set as BAD 
			gFlush.freeBlks[index] |= FT_BAD;
			return;
		}

		lba		= gl_wear_allocstruct.static_lba;
		s_pba	= FTL_C_GetPhy(lba);
		if (s_pba == BLK_NA) 
		{
			// nothing to do 
			return; 
		}

		for (po = 0; po < gDevInfo.pagePerBlks; po++)
		{
			int ret=FTL_L_Read(s_pba,po,ml_buffer);
			if (!po)
			{
				ST_SPARE *sptr			= GET_SPARE_AREA(ml_buffer);
				sptr->wear				= gl_wear_allocstruct.free_wear;
				sptr->u.map.block_type	= BLK_TYPE_DAT;
			}
			else if (ret) 
			{
				continue;
			}

			if (FTL_L_Write(
				d_pba,
				po,
				ml_buffer
				) == FTL_L_ERROR) 
			{
				// we can stop static swap 
				return; 
			}
		}

		FTL_C_SetPhy(lba,d_pba);
		FTL_W_UpdateSInfo(lba,gl_wear_allocstruct.free_wear);

		gFlush.freeBlks[index] = s_pba;
		FTL_W_UpdateDInfo(index,gl_wear_allocstruct.static_wear);

		FTL_C_SaveMap();
	}
}
/*----------------------------------------------------------
	Function name	: FTL_O_GCollect
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: does log block and logical block merge
-----------------------------------------------------------*/
smtBoolean	 		// 0/other, success/any error
FTL_O_GCollect(
void
) 
{
	smtUint32 	wear=WEAR_NA;
	smtUint8 	po,lpo,index;
	smtBlkAddr 		pba;
	smtBlkAddr 		orig_pba;
	ST_LOG 		*log;
	
	smtBlkAddr		trgLBA;
	smtBlkAddr		trgPBA;
	smtUint32		trgWear;
	smtUint8		freeIdx;

	log = gLogCache.curLog;

	ml_dostatic();

	gfSaveMapNeed 	= SMT_TRUE;

	orig_pba 		= FTL_C_GetPhy(log->lba);
	SMT_ASSERT(orig_pba != BLK_NA);
	
	if ((log->lastppo == gDevInfo.pagePerBlks)	
      && log->switchable)
	{ //  check if switchable 

		// put log block to original
		trgLBA		= log->lba;
		trgPBA 		= log->pba;
		trgWear		= log->wear;
		freeIdx		= log->index;

		FTL_C_SetPhy(trgLBA, trgPBA);		
		FTL_W_UpdateSInfo(trgLBA, trgWear);

		// Read original block's wear
		if (!FTL_L_Read(orig_pba, 0, ml_buffer))
		{
		 	wear = GET_SPARE_AREA(ml_buffer)->wear;
		}
		
		if(wear == WEAR_NA) 
		{
			wear = 0;
		}
		
		// Release log 
		gFlush.freeBlks[freeIdx] = orig_pba;
		FTL_W_UpdateDInfo(freeIdx, wear);

		log->lba = BLK_NA;
		gLogCache.lockedCnt--;
		
		// Alloc new log
		FTL_C_AllocLog(log, gOpInfo.LBA);

		return SMT_TRUE;
	}
	
	
	
again:
	index	= FTL_C_AllocBlk();
	SMT_ASSERT(index != INDEX_NA);
	
	pba			= gFlush.freeBlks[index];

	//-------------------------------------------------------
	// Get log cache data to orignal block
	//-------------------------------------------------------
	for (po = 0; po < gDevInfo.pagePerBlks; po++)
	{
		lpo = log->ppo[po];
		if(lpo == INDEX_NA)
		{
			FTL_L_Read(orig_pba, po, ml_buffer);
		}
		else
		{
			FTL_L_Read(log->pba,lpo,ml_buffer);	
		}
		

		if (po == 0)
		{
			ST_SPARE *sptr			= GET_SPARE_AREA(ml_buffer);
			sptr->wear				= gl_wear_allocstruct.free_wear;
			sptr->u.map.block_type	= BLK_TYPE_DAT;
		}

		if (FTL_L_Write(pba, po, ml_buffer) == FTL_L_ERROR) 
		{
			goto again;
		}
	}


	// Wear update
	if (!FTL_L_Read(orig_pba, 0 ,ml_buffer))
	{
		wear = GET_SPARE_AREA(ml_buffer)->wear;
		if(wear == WEAR_NA) wear = 0;
	}
	else
	{
		wear = 0;
	}
	
	// Update orignal block 
	gFlush.freeBlks[index] = orig_pba;
	FTL_W_UpdateDInfo(index, wear);

	// Update static
	FTL_C_SetPhy(log->lba, pba);		
	FTL_W_UpdateSInfo(log->lba, gl_wear_allocstruct.free_wear);
	
	// Release current log
	log->lba		= BLK_NA;
	gLogCache.lockedCnt--;	
	gFlush.freeBlks[log->index] &= ~FT_LOG;
	FTL_W_UpdateDInfo(log->index, WEAR_NA);
	
	// Alloc new log
	FTL_C_AllocLog(log, gOpInfo.LBA);

	return SMT_TRUE;
}
