/****************************************************************************
 *
 *            Copyright (c) 2005-2006 by HCC Embedded
 *
 * This software is copyrighted by and is the sole property of
 * HCC.  All rights, title, ownership, or other interests
 * in the software remain the property of HCC.  This
 * software may only be used in accordance with the corresponding
 * license agreement.  Any unauthorized use, duplication, transmission,
 * distribution, or disclosure of this software is expressly forbidden.
 *
 * This Copyright notice may not be removed or modified without prior
 * written consent of HCC.
 *
 * HCC reserves the right to modify this software without notice.
 *
 * HCC Embedded
 * Budapest 1132
 * Victor Hugo Utca 11-15
 * Hungary
 *
 * Tel:  +36 (1) 450 1302
 * Fax:  +36 (1) 450 1303
 * http: www.hcc-embedded.com
 * email: info@hcc-embedded.com
 *
 ***************************************************************************/
 /*----------------------------------------------------------
	 Developed by S/W Team, SHMT.Co
	 Copyright @ 2006 SHMT. Co
	 All Rights Reserved.
----------------------------------------------------------*/
/*
/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// 
*/
#include <string.h>
#include "../lib_nand/ftl_l_layer.h"
#include "ftl_t_define.h"
#include "ftl_o_rw.h"
#include "ftl_w_wear.h"
#include "ftl_c_core.h"
/*
/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// 
*/
/*
/////////////////////////////////////////////////////////
        GLOBAL VARIABLE
///////////////////////////////////////////////////////// 
*/
// NAND device information
FTL_DEV_INFO	gDevInfo;	
// FTL operation information
FTL_OP_INFO		gOpInfo;	
// FTL cache buffer
smtUint8 		ml_basebuff[(MAX_DATA_SIZE/2)+MAX_SPARE_SIZE+(MAX_DATA_SIZE/2)*MAX_CACHEFRAG];
// FTL temporal buffer
smtUint8 		ml_buffer[MAX_PAGE_SIZE]; 
// FTL map directory
ST_MAPDIR 		ml_mapdir[MAX_FRAGNUM_AVAILABLE];
// FTL etc
smtBoolean 		gfSaveMapNeed;
// FTL Cache
ST_FRAG 		gFragCache;
ST_LOG_CACHE	gLogCache;
ST_FLUSH_DATA	gFlush;
ST_MAP_BLOCKS	gMapBlocks;

WEAR_ALLOCSTRUCT gl_wear_allocstruct; 

/*
/////////////////////////////////////////////////////////
        STATIC VARIABLE
///////////////////////////////////////////////////////// 
*/
/*
/////////////////////////////////////////////////////////
        FUNCTIONS 
///////////////////////////////////////////////////////// 
*/

