/****************************************************************************
 *
 *            Copyright (c) 2005-2006 by HCC Embedded
 *
 * This software is copyrighted by and is the sole property of
 * HCC.  All rights, title, ownership, or other interests
 * in the software remain the property of HCC.  This
 * software may only be used in accordance with the corresponding
 * license agreement.  Any unauthorized use, duplication, transmission,
 * distribution, or disclosure of this software is expressly forbidden.
 *
 * This Copyright notice may not be removed or modified without prior
 * written consent of HCC.
 *
 * HCC reserves the right to modify this software without notice.
 *
 * HCC Embedded
 * Budapest 1132
 * Victor Hugo Utca 11-15
 * Hungary
 *
 * Tel:  +36 (1) 450 1302
 * Fax:  +36 (1) 450 1303
 * http: www.hcc-embedded.com
 * email: info@hcc-embedded.com
 *
 ***************************************************************************/
 /*----------------------------------------------------------
	 Developed by S/W Team, SHMT.Co
	 Copyright @ 2006 SHMT. Co
	 All Rights Reserved.
----------------------------------------------------------*/
/*
/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// 
*/
#include <string.h>
#include "../lib_nand/ftl_l_layer.h"
#include "ftl_t_define.h"
#include "ftl_o_rw.h"
#include "ftl_w_wear.h"
#include "ftl_c_core.h"
/*
/////////////////////////////////////////////////////////
        DEFINITION
///////////////////////////////////////////////////////// 
*/
/*
/////////////////////////////////////////////////////////
        GLOBAL VARIABLE
///////////////////////////////////////////////////////// 
*/
/*
/////////////////////////////////////////////////////////
        STATIC VARIABLE
///////////////////////////////////////////////////////// 
*/
/*
/////////////////////////////////////////////////////////
        FUNCTIONS 
///////////////////////////////////////////////////////// 
*/
/*----------------------------------------------------------
	Function name	: FTL_O_GetMaxSector
	Prototype		: 
	Return			: none
	Argument		: 
	Comments		: retreives the maximum number of sectors 
					  can be used in the system
-----------------------------------------------------------*/
smtUint32 
FTL_O_GetMaxSector(
void
) 
{
	return gDevInfo.dataBlks*gDevInfo.pagePerBlks;
}
/*----------------------------------------------------------
	Function name	: FTL_O_Open
	Prototype		: 
	Return			: none
	Argument		: 
	Comments		: Opening the chanel for read or write 
					  from a specified sector
-----------------------------------------------------------*/
smtBoolean 			// SMT_TRUE/SMT_FALSE, ok/fail
FTL_O_Open(
smtUint32	sector, // start of sector for read or write
smtUint32	secnum, // number of sector will be read or written
smtUint8	mode	// ML_READ open for read, ML_WRITE open for write
)
{

	gOpInfo.state	= ML_CLOSE;
    gOpInfo.secCnt	= secnum;
	gOpInfo.LBA		= (smtBlkAddr)(sector/gDevInfo.pagePerBlks);
	gOpInfo.LPO		= (smtPageAddr)(sector%gDevInfo.pagePerBlks);
	
	SMT_ASSERT(gOpInfo.LBA < gDevInfo.dataBlks);
	SMT_ASSERT(gOpInfo.LPO < gDevInfo.pagePerBlks);

	if (mode == ML_READ) 
	{
		gOpInfo.state = ML_PENDING_READ;
	}
	else if (mode == ML_WRITE) 
	{
		gOpInfo.state = ML_PENDING_WRITE;
	}
	else 
	{
		return SMT_FALSE;
	}

	return SMT_TRUE;
}
/*----------------------------------------------------------
	Function name	: FTL_O_Write
	Prototype		: 
	Return			: none
	Argument		: 
	Comments		: Writing sector data
-----------------------------------------------------------*/
smtUint8 			// 0/other, success/any error
FTL_O_Write(
smtUint8	*datap	// data pointer for an array which length is sector size
) 
{
	
	ST_SPARE *sptr;

	if ((gOpInfo.state == ML_PENDING_WRITE)
	 || (gOpInfo.LPO >= gDevInfo.pagePerBlks))
	{
		
		
		if (gOpInfo.LPO >= gDevInfo.pagePerBlks)
		{
			gOpInfo.LBA++;
			gOpInfo.LPO = 0;
			SMT_ASSERT(gOpInfo.LBA < gDevInfo.dataBlks);
			
		}
		
		if(!FTL_C_FindLog(gOpInfo.LBA))
		{
			SMT_ASSERT(gLogCache.lockedCnt <= gLogCache.num);
			
			if(FTL_C_FindLog(BLK_NA))
			{				
				FTL_C_AllocLog(gLogCache.curLog, gOpInfo.LBA);
			}
			else
			{
				gLogCache.curLog 
					= &gLogCache.logs[gLogCache.nextIdx++];
				if(gLogCache.nextIdx >= gLogCache.num)
				{
					gLogCache.nextIdx = 0;
				}		
			
				// do merge						
				return 2;
			}
		}
		
		
		gOpInfo.state = ML_WRITE;
	}


	if(gOpInfo.state == ML_WRITE)
	{
		// do merge
		if(gLogCache.curLog->lastppo >= gDevInfo.pagePerBlks)
		{
			return 2;
		}

		if (!gOpInfo.secCnt--)
		{
			gOpInfo.state = ML_ABORT;
			return 1;
		}

		// data write per page size
		memcpy (ml_buffer,datap,(smtInt32)gDevInfo.pageSize);
		sptr = GET_SPARE_AREA(ml_buffer);
		
		if(!gLogCache.curLog->lastppo)
		{
			sptr->wear				= gLogCache.curLog->wear;
			sptr->u.map.block_type	= BLK_TYPE_DAT;
		}
		sptr->u.log.lba	= gOpInfo.LBA;
		sptr->u.log.lpo	= gOpInfo.LPO;
		
		
		FTL_L_Write(
			gLogCache.curLog->pba,
			gLogCache.curLog->lastppo,
			ml_buffer
		);
		

		// log cache update
		if(gOpInfo.LPO != gLogCache.curLog->lastppo)
		{
			gLogCache.curLog->switchable = 0;
		}
		gLogCache.curLog->ppo[gOpInfo.LPO++]
			= gLogCache.curLog->lastppo++;

		// save map
		if (gfSaveMapNeed)
		{
			if (FTL_C_SaveMap()) 
			{
				return 1;
			}
		}

		return 0;
	}

	return 1;
}
/*----------------------------------------------------------
	Function name	: FTL_O_Read
	Prototype		: 
	Return			: none
	Argument		: 
	Comments		: Read sector data
-----------------------------------------------------------*/
smtUint8 		// 0/other success/any error
FTL_O_Read(
smtUint8 *datap	// where to read a given sector
)
{
	smtBlkAddr		ba;
	smtPageAddr 		po;
	smtInt32	ret;
	
	// Check block boundary
	if ((gOpInfo.state == ML_PENDING_READ)
	 || (gOpInfo.LPO   >= gDevInfo.pagePerBlks))
	{
		
		if(gOpInfo.LPO   >= gDevInfo.pagePerBlks)
		{
			gOpInfo.LBA++;
			gOpInfo.LPO = 0;
			SMT_ASSERT(gOpInfo.LBA < gDevInfo.dataBlks);
		}
		
		gOpInfo.PBA = FTL_C_GetPhy(gOpInfo.LBA);
		SMT_ASSERT(gOpInfo.PBA != BLK_NA);

		FTL_C_FindLog(gOpInfo.LBA);
		gOpInfo.state = ML_READ;
	}

	// Read operation
	if (gOpInfo.state == ML_READ)
	{
		
		// Check seccou
		if(!gOpInfo.secCnt--)
		{
			gOpInfo.state = ML_ABORT;
			return 1;
		}
		
		// Check log cache pointer		
		ba = gOpInfo.PBA;
		po = gOpInfo.LPO;
		
		if(gLogCache.curLog)
		{
			if(gLogCache.curLog->ppo[gOpInfo.LPO] != INDEX_NA)
			{
				ba = gLogCache.curLog->pba;
				po = gLogCache.curLog->ppo[gOpInfo.LPO];
			}
		}

		// Read operation
		ret = FTL_L_Read(ba, po, ml_buffer);

		memcpy(
			datap,
			ml_buffer,
			(smtInt32)gDevInfo.pageSize
		);

		gOpInfo.LPO++;

		if (ret == FTL_L_OK) 
		{
			return 0;
		}
		else if (ret == FTL_L_ERASED) 
		{
			// erased 
			return 0; 
		}

		return 1;
	}

	return 1;
}
/*----------------------------------------------------------
	Function name	: FTL_O_Close
	Prototype		: 
	Return			: none
	Argument		: 
	Comments		: Closing sector reading or writing
-----------------------------------------------------------*/
smtUint8 		// 0/other, success/any error
FTL_O_Close(
void
) 
{
	t_bit ret = 0;

	if (gOpInfo.state == ML_INIT) 
	{
		return SMT_FALSE;
	}

	if (gOpInfo.secCnt) 
	{
		return SMT_FALSE;
	}
	
	if (gOpInfo.state == ML_ABORT) 
	{
		return SMT_FALSE;
	}

	gOpInfo.state = ML_CLOSE;
	return SMT_TRUE;
}
