/*----------------------------------------------------------
	 MMC controller SOC
	 Developed by S/W Team, SHMT.Co
	 Copyright @ 2007 SHMT. Co
	 All Rights Reserved.
----------------------------------------------------------*/
/*----------------------------------------------------------
	File Name	: main.c 
	Description	: Application Entry Point File
	Created by	: SHMT SOC Team
-----------------------------------------------------------*/

/*
/////////////////////////////////////////////////////////
	INCLUDE
///////////////////////////////////////////////////////// 
*/
#pragma LARGE

#include <intrins.h>

#include "sysinc.h"
#include "lib.h"
#include "sdmmc.h"

#include "ftl.h"
#include "nand.h"


/*
/////////////////////////////////////////////////////////
	DEFINITION
///////////////////////////////////////////////////////// 
*/
typedef void (*dLoaderFTLFunc)(void);

typedef struct
{
	dLoaderFTLFunc ftlFunc;
} pDLoaderFunc;


/* When you wanna test a peri-module, define the following */


/*
/////////////////////////////////////////////////////////
	FUNCTION DECLARATION
///////////////////////////////////////////////////////// 
*/


/*
/////////////////////////////////////////////////////////
	VARIABLE DECLARATION
///////////////////////////////////////////////////////// 
*/

/*
/////////////////////////////////////////////////////////
	FUNCTION
///////////////////////////////////////////////////////// 
*/
/*------------------------------------------------------------------------------
    Function name	: main
    Return			: int
    Argument		: 
    Comments		:
    	main function
------------------------------------------------------------------------------*/
#define MMCRAMCTRLREG	(*(volatile smtUint8 *)(0x84))
#define NANDRAM0CTRLREG	(*(volatile smtUint8 *)(0x85))
#define NANDRAM1CTRLREG	(*(volatile smtUint8 *)(0x86))

#define EXTRAM0BASE		(*(volatile smtUint16 *)(0x8000)) // 2k boundary	 
#define EXTRAM1BASE		(*(volatile smtUint16 *)(0x8800))
#define EXTRAM2BASE		(*(volatile smtUint16 *)(0x9000))
#define EXTRAM3BASE		(*(volatile smtUint16 *)(0x9800))
#define MMCRAM0BASE		(*(volatile smtUint16 *)(0xA000))
#define	MMCRAM1BASE		(*(volatile smtUint16 *)(0xA800))

//#define SMT_WRITE(addr, data)   (addr = ((smtUint8) (data)));
#define SMT_READ(addr)          (addr)
int Mem_Test(void);
int main(void);
int main(void)
{
    ADCSEL = 0x7;

//	pDLoaderFunc dLFTLFunc;
	Mem_Test();

#if 0
	smt2UartInit();

	//ADCSEL = 0x7;

	// Initialize
	smtExtIntInitial();
	smtTimer0Initial();

	dLFTLFunc.ftlFunc = 0x2000; //ftl;

	while(1)
	{
		sdmmcCmdParser();
		dynamicLoader();
	}

	//printf("Hello World!");
#endif
	return 0;
}

int Mem_Test(void)
{
	smtUint8 dat;

    smtUint16 i;
    
    xddata smtUint8 test[10];

    volatile smtUint8 * MMC0TestRegion= (volatile smtUint16 *)(MMCRAM0BASE);
    volatile smtUint8 * MMC1TestRegion= (volatile smtUint16 *)(MMCRAM0BASE);
    volatile smtUint8 * EXTRAM0TestRegion= (volatile smtUint16 *)(EXTRAM0BASE);
    volatile smtUint8 * EXTRAM1TestRegion= (volatile smtUint16 *)(EXTRAM1BASE);
    volatile smtUint8 * EXTRAM2TestRegion= (volatile smtUint16 *)(EXTRAM2BASE);
    volatile smtUint8 * EXTRAM3TestRegion= (volatile smtUint16 *)(EXTRAM3BASE);

    
   	SMT_WRITE(MMCRAMCTRLREG,0x01); // MMC0 RAM Select
	dat = SMT_READ(MMCRAMCTRLREG);// Register Read
//	if (data  != )
//		goto  error;

    

	// MMC RAM 0  CPU Read Write Test
	for (i=0; i<2048 ; i++)
		MMC0TestRegion[i] = i;
	for (i=0; i<2048 ; i++)
		{
			dat= MMC0TestRegion[i];
			if (dat != i)
				goto error;
		}
	
	// MMC RAM1 CPU Read Write Test
	for (i=0; i<2048 ; i++)
		MMC0TestRegion[i] = i;
	for (i=0; i<2048 ; i++)
		{
			dat = MMC0TestRegion[i];
			if (dat != i)
				goto error;
		}

	// EXT RAM0 CPU Read Write Test
	for (i=0; i<2048 ; i++)
		EXTRAM0TestRegion[i] = i;
	for (i=0; i<2048 ; i++)
		{
			dat = EXTRAM0TestRegion[i];
			if (dat != i)
				goto error;
		}

	// EXT RAM1 CPU Read Write Test
	for (i=0; i<2048 ; i++)
		EXTRAM1TestRegion[i] = i;
	for (i=0; i<2048 ; i++)
		{
			dat = EXTRAM1TestRegion[i];
			if (dat != i)
				goto error;
		}

	// EXT RAM2 CPU Read Write Test
	for (i=0; i<2048 ; i++)
		EXTRAM2TestRegion[i] = i;
	for (i=0; i<2048 ; i++)
		{
			dat = EXTRAM2TestRegion[i];
			if (dat != i)
				goto error;
		}

	// EXT RAM3 CPU Read Write Test
	for (i=0; i<2048 ; i++)
		EXTRAM3TestRegion[i] = i;
	for (i=0; i<2048 ; i++)
		{
			dat = EXTRAM3TestRegion[i];
			if (dat != i)
				goto error;
		}
	return 0;
 
error:
//DPRINTF("Error : Read 0x%04x when 0x%04x expected\n", dat , data_expected);
return 1;

}



