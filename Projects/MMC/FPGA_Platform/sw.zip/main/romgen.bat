mtirgen.exe -8 ./project/mmcSOC.BIN ./program.rom
