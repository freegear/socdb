/*----------------------------------------------------------
	 MMC controller SOC
	 Developed by S/W Team, SHMT.Co
	 Copyright @ 2007 SHMT. Co
	 All Rights Reserved.
----------------------------------------------------------*/
/*----------------------------------------------------------
	File Name	: main.c 
	Description	: Application Entry Point File
	Created by	: SHMT SOC Team
-----------------------------------------------------------*/

/*
/////////////////////////////////////////////////////////
	INCLUDE
///////////////////////////////////////////////////////// 
*/
#pragma LARGE

#include <intrins.h>

#include "sysinc.h"
#include "lib.h"
#include "sdmmc.h"

#include "ftl.h"
#include "nand.h"


/*
/////////////////////////////////////////////////////////
	DEFINITION
///////////////////////////////////////////////////////// 
*/
typedef void (*dLoaderFTLFunc)(void);

typedef struct
{
	dLoaderFTLFunc ftlFunc;
} pDLoaderFunc;


/* When you wanna test a peri-module, define the following */


/*
/////////////////////////////////////////////////////////
	FUNCTION DECLARATION
///////////////////////////////////////////////////////// 
*/


/*
/////////////////////////////////////////////////////////
	VARIABLE DECLARATION
///////////////////////////////////////////////////////// 
*/

/*
/////////////////////////////////////////////////////////
	FUNCTION
///////////////////////////////////////////////////////// 
*/
/*------------------------------------------------------------------------------
    Function name	: main
    Return			: int
    Argument		: 
    Comments		:
    	main function
------------------------------------------------------------------------------*/

#define MMCRAMCTRLREG	(*(volatile smtUint8 *)(0x84))
#define NANDRAM0CTRLREG	(*(volatile smtUint8 *)(0x85))
#define NANDRAM1CTRLREG	(*(volatile smtUint8 *)(0x86))

#define EXTRAM0BASE		(*(volatile smtUint16 *)(0x8000)) // 2k boundary	 
#define EXTRAM1BASE		(*(volatile smtUint16 *)(0x8800))
#define EXTRAM2BASE		(*(volatile smtUint16 *)(0x9000))
#define EXTRAM3BASE		(*(volatile smtUint16 *)(0x9800))
#define MMCRAM0BASE		(*(volatile smtUint16 *)(0xA000))
#define	MMCRAM1BASE		(*(volatile smtUint16 *)(0xA800))

#define SMT_WRITE(addr, data)   (addr = ((smtUint8) (data)));
#define SMT_READ(addr)          (addr)
int main(void)
{
	volatile smtUint8 * MMC0TestRegion= (volatile smtUint8 *)(MMCRAM0BASE);
    volatile smtUint8 * MMC11estRegion= (volatile smtUint8 *)(MMCRAM0BASE);
    volatile smtUint8 * EXTRAM0TestRegion= (volatile smtUint8 *)(EXTRAM0BASE);
    volatile smtUint8 * EXTRAM1TestRegion= (volatile smtUint8 *)(EXTRAM1BASE);
    volatile smtUint8 * EXTRAM2TestRegion= (volatile smtUint8 *)(EXTRAM2BASE);
    volatile smtUint8 * EXTRAM3TestRegion= (volatile smtUint8 *)(EXTRAM3BASE);
    volatile smtUint8 * EXTRAM4TestRegion= (volatile smtUint8 *)(EXTRAM4BASE);
//	pDLoaderFunc dLFTLFunc;
	smtUint8 data;

    int i;
    

												
	SMT_WRITE(MMCRAMCTRLREG,0x01); // MMC0 RAM Select
	data = SMT_READ(MMMCRAMCLRLREG);// Register Read
	if (data  != )
		goto  error;

    

//	smt2UartInit();

	// Initialize
//	smtExtIntInitial();
//	smtTimer0Initial();

	

//	dLFTLFunc.ftlFunc = 0x2000; //ftl;
/*
	while(1)
	{
		sdmmcCmdParser();
		dynamicLoader();
	}

*/	//printf("Hello World!");
error:
	DPRINTF("Error : Read 0x%04x when 0x%04x expected\n", data , data_expected);
	return 0;
}
