/*----------------------------------------------------------
	 MMC controller SOC
	 Developed by S/W Team, SHMT.Co
	 Copyright @ 2007 SHMT. Co
	 All Rights Reserved.
-----------------------------------------------------------*/
/*----------------------------------------------------------
	File Name	: nand.c 
	Description	: nand file
	Created by	: SHMT SOC Team
-----------------------------------------------------------*/

/*
/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// 
*/
//#include "global.h"
#include "nand_pre_drv.h"



/*
/////////////////////////////////////////////////////////
        DEFINITIOIN
/////////////////////////////////////////////////////////
*/



/*
/////////////////////////////////////////////////////////
	VARIABLE DECLARATION
///////////////////////////////////////////////////////// 
*/


/*
/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////// 
*/
/*----------------------------------------------------------
	NAND controller interface
	
	#operation config /command/address
		- smtNANDSetOPT0
		- smtNANDSetOPT1
		- smtNANDSetOPT2
		- smtNANDSetData
		- smtNANDGetData
		
	# config
		- smtNANDGetCfg/smtNANDSetCfg

	# control
		- smtNANDGetControl/smtNANDSetControl
		
	# status
		- smtNANDGetStatus/smtNANDSetStatus
		
-----------------------------------------------------------*/
/*----------------------------------------------------------
	Function name	: smtNANDSetOPT0
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDSetOPT0(NandOpt0 *popt0)
{
	smtUint32 regData;
	regData = 
		 ((popt0->chipSel			& 0x1) 		<< 31)
		|((popt0->option			& 0x3)		<< 29)
		|((popt0->dataSize			& 0xFFF)	<< 17)
		|((popt0->opMode			& 0x7) 		<< 14)
		|((popt0->TransSize			& 0x3) 		<< 12)
		|((popt0->cmdAddrTransByte	& 0xF) 		<< 8)
		|((popt0->cmdAddrFlag		& 0xFF) 	<< 0);
	
	SMT_WRITE(NFOPER3, ((regData >> (3*8)) & 0xFF));
	SMT_WRITE(NFOPER2, ((regData >> (2*8)) & 0xFF));
	SMT_WRITE(NFOPER1, ((regData >> (1*8)) & 0xFF));
	SMT_WRITE(NFOPER0, ((regData >> (0*8)) & 0xFF));

}
/*----------------------------------------------------------
	Function name	: smtNANDSetOPT1
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDSetOPT1(NandOpt1 *popt1)
{
	SMT_WRITE(NFOPER3, (popt1->CMDADDR[3] & 0xFF));
	SMT_WRITE(NFOPER2, (popt1->CMDADDR[2] & 0xFF));
	SMT_WRITE(NFOPER1, (popt1->CMDADDR[1] & 0xFF));
	SMT_WRITE(NFOPER0, (popt1->CMDADDR[0] & 0xFF));
}

/*----------------------------------------------------------
	Function name	: smtNANDSetOPT2
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDSetOPT2(NandOpt2 *popt2)
{
	SMT_WRITE(NFOPER3, (popt2->CMDADDR[3] & 0xFF));
	SMT_WRITE(NFOPER2, (popt2->CMDADDR[2] & 0xFF));
	SMT_WRITE(NFOPER1, (popt2->CMDADDR[1] & 0xFF));
	SMT_WRITE(NFOPER0, (popt2->CMDADDR[0] & 0xFF));
}
/*----------------------------------------------------------
	Function name	: smtNANDSetData
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDSetData(smtUint32 *pData)
{
	SMT_WRITE(NFDATA, ((*pData >> (3*8)) & 0xFF));
	SMT_WRITE(NFDATA, ((*pData >> (2*8)) & 0xFF));
	SMT_WRITE(NFDATA, ((*pData >> (1*8)) & 0xFF));
	SMT_WRITE(NFDATA, ((*pData >> (0*8)) & 0xFF));
}
/*----------------------------------------------------------
	Function name	: smtNANDGetData
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDGetData(smtUint32 *pData)
{
	*pData = 0;
	*pData |= (SMT_READ(NFDATA) & 0xFF) << (3*8);
	*pData |= (SMT_READ(NFDATA) & 0xFF) << (2*8);
	*pData |= (SMT_READ(NFDATA) & 0xFF) << (1*8);
	*pData |= (SMT_READ(NFDATA) & 0xFF) << (0*8);
}
/*----------------------------------------------------------
	Function name	: smtNANDGetCfg
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDGetCfg(NandCfg *pconfig)
{
	smtUint32 reg = 0;
	reg |= (SMT_READ(NFCONF2) & 0xFF) << (2*8);
	reg |= (SMT_READ(NFCONF1) & 0xFF) << (1*8);
	reg |= (SMT_READ(NFCONF0) & 0xFF) << (0*8);
		
	pconfig->nandBootEn	= ((reg	>> 18) & 0x1);
	pconfig->IOWidth	= ((reg >> 17) & 0x1);
	pconfig->NandWidth	= ((reg >> 16) & 0x1);
	pconfig->bootCfg	= ((reg	>> 14) & 0x3);
	pconfig->OutDtmn	= ((reg >> 13) & 0x1);
	pconfig->TADLTWB	= ((reg >> 9 ) & 0xF);
	pconfig->TCALS		= ((reg	>> 6 ) & 0x7);
	pconfig->TRWLP		= ((reg >> 3 ) & 0x7);
	pconfig->TRWHP		= ((reg >> 0 ) & 0x7);
	
}
/*----------------------------------------------------------
	Function name	: smtNANDSetCfg
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDSetCfg(NandCfg *pconfig)
{
	smtUint32 reg;
	
	reg =  
		(((pconfig->nandBootEn	& 0x1) << 18)
		|((pconfig->IOWidth		& 0x1) << 17)
		|((pconfig->NandWidth	& 0x1) << 16)
		|((pconfig->bootCfg		& 0x1) << 14)
		|((pconfig->OutDtmn		& 0x0) << 13)
		|((pconfig->TADLTWB		& 0xF) << 9)
		|((pconfig->TCALS		& 0x7) << 6)
		|((pconfig->TRWLP		& 0x7) << 3)
		|((pconfig->TRWHP		& 0x7) << 0));
	
	SMT_WRITE(NFCONF2, ((reg >> (2*8)) & 0xFF));
	SMT_WRITE(NFCONF1, ((reg >> (1*8)) & 0xFF));
	SMT_WRITE(NFCONF0, ((reg >> (0*8)) & 0xFF));
}


/*----------------------------------------------------------
	Function name	: smtNANDGetControl
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDGetControl(NandCtrl *pcontrol)
{
	smtUint32 reg = 0;

	reg |= (SMT_READ(NFCTRL1) & 0xFF) << (1*8);
	reg |= (SMT_READ(NFCTRL0) & 0xFF) << (0*8);
	
	pcontrol->NFCtrlRst		= ((reg	>> 13) & 0x1);
	pcontrol->FIFOLevel		= ((reg >> 10) & 0x7);
	pcontrol->Ecc512byteEn	= ((reg >> 8 ) & 0x1);
	pcontrol->autoEccWr		= ((reg	>> 7 ) & 0x1);//shkim-20070613 : remove???
	pcontrol->DMAEn			= ((reg >> 6 ) & 0x1);
	pcontrol->wrEndIntEn	= ((reg >> 5 ) & 0x1);	
	pcontrol->rdEndIntEn	= ((reg	>> 4 ) & 0x1);
	//pcontrol->eccErrIntEn	= ((reg >> 3 ) & 0x1); don't use
	pcontrol->FIFOIntEn		= ((reg >> 2 ) & 0x1);	
	//pcontrol->RnBintEn1		= ((reg >> 1 ) & 0x1);	reserve
	pcontrol->RnBintEn0		= ((reg >> 0 ) & 0x1);	
}
/*----------------------------------------------------------
	Function name	: smtNANDSetControl
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDSetControl(NandCtrl *pcontrol)
{
	
	smtUint32 reg;
	
	reg = (
		 ((pcontrol->NFCtrlRst    	& 0x1)<<13)									
		|((pcontrol->FIFOLevel		& 0x7)<<10)									
		|((pcontrol->Ecc512byteEn 	& 0x1)<< 8)									
		|((pcontrol->autoEccWr		& 0x1)<< 7)									
		|((pcontrol->DMAEn		  	& 0x1)<< 6)									
		|((pcontrol->wrEndIntEn		& 0x1)<< 5)									
		|((pcontrol->rdEndIntEn	  	& 0x1)<< 4)									
		|((pcontrol->FIFOIntEn	  	& 0x1)<< 2)									
		|((pcontrol->RnBintEn0	  	& 0x1)<< 0));
		
	SMT_WRITE(NFCTRL1 , ((reg >> (1*8)) & 0xFF));
	SMT_WRITE(NFCTRL0 , ((reg >> (0*8)) & 0xFF));
}
/*----------------------------------------------------------
	Function name	: smtNANDGetStatus
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDGetStatus(NandStat *pstatus)
{
	smtUint32 reg =	0;
	reg |= (SMT_READ(NFSTAT3) & 0xFF) << 3*8;	
	reg |= (SMT_READ(NFSTAT2) & 0xFF) << 2*8;	
	reg |= (SMT_READ(NFSTAT1) & 0xFF) << 1*8;	
	reg |= (SMT_READ(NFSTAT0) & 0xFF) << 0*8;	
														
														
	pstatus->NFCtrlBusy		= ((reg >> 25) & 0x1);		
	pstatus->NFStatValid	= ((reg >> 24) & 0x1); 		
	pstatus->NFStatus		= ((reg >> 8 ) & 0xFFFF);	
	pstatus->wrEnd			= ((reg >> 7 ) & 0x1);
	pstatus->rdEnd			= ((reg >> 6 ) & 0x1);
	pstatus->wrFIFOReady	= ((reg >> 5 ) & 0x1);
	pstatus->rdFIFOReady	= ((reg >> 4 ) & 0x1);
	pstatus->RnBDetect0		= ((reg >> 2 ) & 0x1);
	pstatus->RnBSTAT0		= ((reg >> 0 ) & 0x1);
}
/*----------------------------------------------------------
	Function name	: smtNANDSetStatus
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDSetStatus(NandStat *pstatus)
{
	smtUint32 reg;
	
	reg = (
		 ((pstatus->NFCtrlBusy		& 0x1)  	<< 25)
		|((pstatus->NFStatValid		& 0x1)		<< 24)
		|((pstatus->NFStatus		& 0xFFFF) 	<< 8)
		|((pstatus->wrEnd			& 0x1)  	<< 7) 
		|((pstatus->rdEnd			& 0x1)		<< 6)
		|((pstatus->wrFIFOReady		& 0x1)  	<< 5) 
		|((pstatus->rdFIFOReady		& 0x1)		<< 4)
		|((pstatus->RnBDetect0		& 0x1)		<< 2)
		|((pstatus->RnBSTAT0		& 0x1)		<< 0));

	SMT_WRITE(NFSTAT3, ((reg >> (3*8)) & 0xFF));
	SMT_WRITE(NFSTAT2, ((reg >> (2*8)) & 0xFF));
	SMT_WRITE(NFSTAT1, ((reg >> (1*8)) & 0xFF));
	SMT_WRITE(NFSTAT0, ((reg >> (0*8)) & 0xFF));
			
}
/*----------------------------------------------------------
	Function name	: smtNANDGetFIFOStatus
	Prototype		: 
	Return			: 
	Argument		: 
	Comments		: 
-----------------------------------------------------------*/
void smtNANDGetFIFOStatus(NandFifoStat *pfifoStatus)
{
	
	smtUint32 reg =	0;
	reg |= (SMT_READ(NFFIFOSTAT1) & 0xFF) << (1*8);
	reg |= (SMT_READ(NFFIFOSTAT0) & 0xFF) << (0*8);
	
	pfifoStatus->QLevel			= ((reg >> 8) & 0xF);
	pfifoStatus->DFIFOLevel1	= ((reg >> 4) & 0xF);
	pfifoStatus->DFIFOLevel0	= ((reg >> 0) & 0xF);
}
