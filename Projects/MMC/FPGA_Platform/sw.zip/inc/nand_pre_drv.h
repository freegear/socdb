/*----------------------------------------------------------
	 SkyWalker for Navigation
	 Developed by S/W Team, SHMT.Co
	 Copyright @ 2006 SHMT. Co
	 All Rights Reserved.
----------------------------------------------------------*/
/*----------------------------------------------------------
	File name		: nand_pre_drv.h
	Description		: nand pre driver header file
	Created by		: SHMT SOC Team
-----------------------------------------------------------*/
#ifndef __NAND_PRE_DRV_H__
#define __NAND_PRE_DRV_H__

/*
/////////////////////////////////////////////////////////
        INCLUDE
///////////////////////////////////////////////////////// 
*/

#include "commonmacro.h"
#include "sysinc.h"

/*
/////////////////////////////////////////////////////////
        TYPEDEF
///////////////////////////////////////////////////////// 
*/
/*----------------------------------------------------------
	NAND controller structure
	
		NandOpt0
		NandOpt1
		NandOpt2
		NAND_DAT	
		NandCfg
		NandCtrl
		NAND_STA
		NandEcc
		NandEccStat
	
-----------------------------------------------------------*/

typedef struct 
{
	smtBoolean	chipSel;	
	smtUint8	option;
	smtUint16	dataSize;
	smtUint8	opMode;
	smtUint8	TransSize;
	smtUint8	cmdAddrTransByte;
	smtUint8	cmdAddrFlag;
}	NandOpt0;

typedef struct 
{
	smtUint8	CMDADDR[4];
}	NandOpt1;

typedef struct 
{

	smtUint8	CMDADDR[4];
}	NandOpt2;


typedef struct 
{
	smtBoolean	nandBootEn;	
	smtBoolean	IOWidth;
	smtBoolean	NandWidth;
	smtUint8	bootCfg;
	smtBoolean	OutDtmn;
	smtUint8	TADLTWB;
	smtUint8	TCALS;
	smtUint8	TRWLP;
	smtUint8	TRWHP;
	
}	NandCfg;

typedef struct 
{
	smtBoolean	NFCtrlRst;	
	smtUint8	FIFOLevel;
	smtBoolean	Ecc512byteEn;
	smtBoolean	autoEccWr;
	smtBoolean	DMAEn;
	smtBoolean	wrEndIntEn;
	smtBoolean	rdEndIntEn;
	smtBoolean	eccErrIntEn;
	smtBoolean	FIFOIntEn;
	smtBoolean	RnBintEn1;
	smtBoolean	RnBintEn0;
	
}	NandCtrl;

typedef struct 
{
//	smtBoolean	eccErr;	
//	smtUint8	NFQueLevel;
	smtBoolean	NFCtrlBusy;
	smtBoolean	NFIDValid;
	smtBoolean	NFStatValid;
	smtUint16	NFStatus;			// change from 8bits to 16bits
	smtBoolean	wrEnd;
	smtBoolean	rdEnd;
	smtBoolean	wrFIFOReady;
	smtBoolean	rdFIFOReady;
//	smtBoolean 	RnBDetect1;
	smtBoolean 	RnBDetect0;
//	smtBoolean	RnBSTAT1;
	smtBoolean	RnBSTAT0;
	
}	NandStat;

typedef struct 
{
	smtUint8	DFIFOLevel1;
	smtUint8	DFIFOLevel0;
	smtUint8	QLevel;
	
}	NandFifoStat;

/*
/////////////////////////////////////////////////////////
        FUNCTION
///////////////////////////////////////////////////////////
*/

#endif //__NAND_PRE_DRV_H__


