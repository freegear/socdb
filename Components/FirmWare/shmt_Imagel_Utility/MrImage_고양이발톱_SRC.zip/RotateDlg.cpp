/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "resource.h"
#include "RotateDlg.h"

namespace MrImage
{

// CRotateDlg dialog

IMPLEMENT_DYNAMIC(CRotateDlg, CDialog)
CRotateDlg::CRotateDlg(CWnd* pParent /*=NULL*/)
: CDialog(CRotateDlg::IDD, pParent)
,m_Angle(0.0)
{
}

CRotateDlg::~CRotateDlg()
{
}

void CRotateDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_ANGLE, m_Angle);
}

BOOL CRotateDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWinApp * pApp = AfxGetApp();
	CString strAngle = pApp->GetProfileString(_T("Rotate"), _T("Angle"), _T("0.0"));
	m_Angle = (float)atof(strAngle);
	VERIFY(UpdateData(FALSE));

	return TRUE;  // return TRUE unless you set the focus to a control
}

void CRotateDlg::OnOK()
{
	CDialog::OnOK();

	CWinApp * pApp = AfxGetApp();
	CString strAngle;
	strAngle.Format(_T("%f"), m_Angle);
	VERIFY(pApp->WriteProfileString(_T("Rotate"), _T("Angle"), strAngle));
}

BEGIN_MESSAGE_MAP(CRotateDlg, CDialog)
END_MESSAGE_MAP()


// CRotateDlg message handlers
}//end namespace