/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#pragma once

namespace MrImage
{

class COptionsDlg : public CDialog
{
	DECLARE_DYNAMIC(COptionsDlg)

public:
	explicit COptionsDlg(CWnd* pParent = NULL);
	virtual ~COptionsDlg();

	enum { IDD = IDD_OPTIONS };

	virtual BOOL OnInitDialog();

	UINT GetColorWidthHeight()const { return m_unColorSize; }
	void SetColorWidthHeight(UINT unLength){ m_unColorSize = unLength; }

	BOOL IsRememberColorTabEnabled()const { return m_bRememberColorTab; }
	void EnableRememberColorTab(BOOL bEnable){ m_bRememberColorTab = bEnable; }

	BOOL IsRememberApplyToSelectionEnabled()const { return m_bRememberApplyToSelection; }
	void EnableRememberApplyToSelection(BOOL bEnable){ m_bRememberApplyToSelection = bEnable; 	}

	BOOL IsApplyToSelectionEnabled()const { return m_bApplyToSelection; }
	void EnableApplyToSelection(BOOL bEnable){ m_bApplyToSelection = bEnable; }

	BOOL IsUndoRedoEnabled()const { return m_bEnableUndoRedo; }
	void EnableUndoRedo(BOOL bEnable){ m_bEnableUndoRedo = bEnable; }

	UINT GetMaxUndoItems()const { return m_unMaxUndoItems; }
	void SetMaxUndoItems(UINT unMax){ m_unMaxUndoItems = unMax; }

	UINT GetLastColorTab()const { return m_unLastColorTab; }
	void SetLastColorTab(UINT unTab){ m_unLastColorTab = unTab; }

	BOOL IsRememberWindowStateEnabled()const { return m_bRememberWindowState; }
	void EnableRememberWindowState(BOOL bEnable){ m_bRememberWindowState = bEnable; }

	BOOL IsRememberToolbarStateEnabled()const { return m_bRememberToolbarState; }
	void EnableRememberToolbarState(BOOL bEnable){ m_bRememberToolbarState = bEnable; }

	BOOL IsRememberFontFormatSettingsEnabled()const { return m_bRememberFontFormatSettings; }
	void EnableRememberFontFormatSettings(BOOL bEnable){ m_bRememberFontFormatSettings = bEnable; }

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual void OnOK();

	DECLARE_MESSAGE_MAP()

private:
	
	UINT m_unColorSize;
	BOOL m_bRememberColorTab;
	BOOL m_bRememberApplyToSelection;
	BOOL m_bRememberWindowState;
	BOOL m_bEnableUndoRedo;
	UINT m_unMaxUndoItems;
	UINT m_unLastColorTab;
	BOOL m_bRememberToolbarState;
	BOOL m_bApplyToSelection;
	BOOL m_bSaveSettings;
	BOOL m_bRememberFontFormatSettings;
};


}//end namespace
