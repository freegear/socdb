/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/
#pragma once

#include "resource.h"

namespace MrImage
{

class CFontFormatBar : public CToolBar
{
	DECLARE_DYNAMIC(CFontFormatBar)

public:
	CFontFormatBar();
	virtual ~CFontFormatBar();

	CString GetSelectedFontName()const;
	BOOL SetSelectedFontName(LPCTSTR szFontName);

	int GetSelectedFontPointSize()const;
	BOOL SetSelectedFontPointSize(int size);

	BOOL IsBoldEnabled()const { return GetToolBarCtrl().IsButtonChecked(ID_BOLD); }
	BOOL IsItalicsEnabled()const { return GetToolBarCtrl().IsButtonChecked(ID_ITALICS); }
	BOOL IsUnderlineEnabled()const { return GetToolBarCtrl().IsButtonChecked(ID_UNDERLINE); }

	void EnableBold(BOOL bEnable){ GetToolBarCtrl().CheckButton(ID_BOLD, bEnable); }
	void EnableItalics(BOOL bEnable){ GetToolBarCtrl().CheckButton(ID_ITALICS, bEnable); }
	void EnableUnderline(BOOL bEnable){ GetToolBarCtrl().CheckButton(ID_UNDERLINE, bEnable); }

protected:
	DECLARE_MESSAGE_MAP()

	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSelectFontName();
	afx_msg void OnSelectFontSize();
	
private:
	static int CALLBACK EnumFontFamProc(ENUMLOGFONT *lpelf, NEWTEXTMETRIC *lpntm, int nFontType, LPARAM lParam);
	static int CALLBACK EnumFontSizesProc(ENUMLOGFONTEX  *lpelfe,	TEXTMETRIC *lpntme, int FontType, LPARAM lParam);

	CComboBox m_cboFontName;
	CComboBox m_cboFontSize;
};
																		   
}//end namespace
