/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "MainFrm.h"
#include "resource.h"
#include "MrImageView.h"
#include "MrImageDoc.h"
#include "OptionsDlg.h"
#include "WindowsDlg.h"
#include "BinToHex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace MrImage
{

const UINT DROPPERSELECTEDCOLOR_MSGID = CMrImageView::GetDropperSelectedColorMsgID();
const UINT CURSORPOSITION_MSGID = CMrImageView::GetCursorPositionMsgID();

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_UPDATE_COMMAND_UI((AFX_IDW_TOOLBAR + 50), OnUpdateControlBarMenu)
	ON_COMMAND_EX((AFX_IDW_TOOLBAR + 50), OnBarCheck)
	ON_UPDATE_COMMAND_UI((AFX_IDW_TOOLBAR + 51), OnUpdateControlBarMenu)
	ON_COMMAND_EX((AFX_IDW_TOOLBAR + 51), OnBarCheck)
	ON_UPDATE_COMMAND_UI((AFX_IDW_TOOLBAR + 52), OnUpdateControlBarMenu)
	ON_COMMAND_EX((AFX_IDW_TOOLBAR + 52), OnBarCheck)
	ON_UPDATE_COMMAND_UI((AFX_IDW_TOOLBAR + 53), OnUpdateControlBarMenu)
	ON_COMMAND_EX((AFX_IDW_TOOLBAR + 53), OnBarCheck)
	ON_UPDATE_COMMAND_UI((AFX_IDW_TOOLBAR + 54), OnUpdateControlBarMenu)
	ON_COMMAND_EX((AFX_IDW_TOOLBAR + 54), OnBarCheck)
	ON_REGISTERED_MESSAGE(DROPPERSELECTEDCOLOR_MSGID, OnDropperSelectedColor)
	ON_REGISTERED_MESSAGE(CURSORPOSITION_MSGID, OnCursorPositionChanged)
	ON_COMMAND(ID_EDIT_PASTEASNEWIMAGE, OnEditPasteAsNewImage)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTEASNEWIMAGE, OnUpdateEditPasteAsNewImage)
	ON_COMMAND(ID_EDIT_OPTIONS, OnEditOptions)
	ON_COMMAND(ID_FILE_OPENBINTOHEX, OnOpenBinToHex)
	ON_WM_DROPFILES()
	ON_COMMAND(ID_WINDOW_WINDOWS, OnWindows)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CURSOR,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

//---------------------------------------------------------------
CMainFrame::CMainFrame()
:m_wndStatusBar()
,m_wndToolBar()
,m_wndStdDrawToolBar()
,m_wndTransformFilterToolBar()
,m_wndNudgeSelectionToolBar()
,m_wndColorPickerBar()
,m_wndFontFormatBar()
{
}

//---------------------------------------------------------------
CMainFrame::~CMainFrame()
{
}

//---------------------------------------------------------------
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	DWORD dwStyle = WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC;

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, dwStyle) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	CString strTitle;
	VERIFY(strTitle.LoadString(IDS_MAIN_TOOLBAR_TITLE));
	m_wndToolBar.SetWindowText(strTitle);

	if (!m_wndStdDrawToolBar.CreateEx(this, TBSTYLE_FLAT, dwStyle, CRect(0,0,0,0), AFX_IDW_TOOLBAR + 50) ||
		!m_wndStdDrawToolBar.LoadToolBar(IDR_STD_DRAWTOOLS))
	{
		TRACE0("Failed to create draw tools toolbar\n");
		return -1;      // fail to create
	}
	
	VERIFY(strTitle.LoadString(IDS_DRAWTOOLS_TOOLBAR_TITLE));
	m_wndStdDrawToolBar.SetWindowText(strTitle);

	//Add drop-down arrow capability to the toolbar
	DWORD dwExStyle = TBSTYLE_EX_DRAWDDARROWS;
	m_wndStdDrawToolBar.GetToolBarCtrl().SendMessage(TB_SETEXTENDEDSTYLE, 0, (LPARAM)dwExStyle);

	//Add drop-down arrow to "Brush Tool" button
	DWORD dwBtnStyle = m_wndStdDrawToolBar.GetButtonStyle(m_wndStdDrawToolBar.CommandToIndex(ID_BUTTON_BRUSH_TOOL));
	dwBtnStyle |= TBSTYLE_DROPDOWN;
	m_wndStdDrawToolBar.SetButtonStyle(m_wndStdDrawToolBar.CommandToIndex(ID_BUTTON_BRUSH_TOOL), dwBtnStyle);

	if (!m_wndTransformFilterToolBar.CreateEx(this, TBSTYLE_FLAT, dwStyle, CRect(0,0,0,0), AFX_IDW_TOOLBAR + 51) ||
		!m_wndTransformFilterToolBar.LoadToolBar(IDR_TRANSFORMFILTER_TOOLBAR))
	{
		TRACE0("Failed to create transform/filter toolbar\n");
		return -1;      // fail to create
	}

	VERIFY(strTitle.LoadString(IDS_TRANSFORMFILTER_TOOLBAR_TITLE));
	m_wndTransformFilterToolBar.SetWindowText(strTitle);

	VERIFY(strTitle.LoadString(IDS_COLORPICKERBAR_TITLE));
	if (!m_wndColorPickerBar.Create(strTitle, this, AFX_IDW_TOOLBAR + 52, dwStyle))
	{
		TRACE0("Failed to create color palette\n");
		return -1;
	}
	m_wndColorPickerBar.SetWindowText(strTitle);

	if (!m_wndFontFormatBar.CreateEx(this, TBSTYLE_FLAT, dwStyle, CRect(0,0,0,0), AFX_IDW_TOOLBAR + 53))
	{
		TRACE0("Failed to create font format bar\n");
		return -1;      // fail to create
	}

	VERIFY(strTitle.LoadString(IDS_FONTFORMATBAR_TITLE));
	m_wndFontFormatBar.SetWindowText(strTitle);

	if (!m_wndNudgeSelectionToolBar.CreateEx(this, TBSTYLE_FLAT, dwStyle, CRect(0,0,0,0), AFX_IDW_TOOLBAR + 54) ||
		!m_wndNudgeSelectionToolBar.LoadToolBar(IDR_NUDGE_TOOLBAR))
	{
		TRACE0("Failed to create nudge toolbar\n");
		return -1;      // fail to create
	}

	VERIFY(strTitle.LoadString(IDS_NUDGE_TOOLBAR_TITLE));
	m_wndNudgeSelectionToolBar.SetWindowText(strTitle);

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;
	}

	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndStdDrawToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndTransformFilterToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndColorPickerBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndFontFormatBar.EnableDocking(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM);
	m_wndNudgeSelectionToolBar.EnableDocking(CBRS_ALIGN_ANY);

	EnableDocking(CBRS_ALIGN_ANY);

	DockControlBar(&m_wndToolBar);
	DockControlBar(&m_wndStdDrawToolBar);
	DockControlBar(&m_wndTransformFilterToolBar);
	DockControlBar(&m_wndColorPickerBar, AFX_IDW_DOCKBAR_BOTTOM);
	DockControlBar(&m_wndFontFormatBar);
	DockControlBar(&m_wndNudgeSelectionToolBar);

	CWinApp * pApp = AfxGetApp();
	ASSERT(pApp);

	COptionsDlg options;
	if (options.IsRememberWindowStateEnabled())
	{
		//restore the window state
		WINDOWPLACEMENT wp;
		memset(&wp, 0, sizeof(wp));
		wp.length = sizeof (WINDOWPLACEMENT);
		if (GetWindowPlacement(&wp))
		{
			CString strSection(_T("WindowState"));
			wp.flags = pApp->GetProfileInt (strSection, _T("flags"), -1);
			wp.showCmd = pApp->GetProfileInt (strSection, _T("showCmd"), -1);
			wp.rcNormalPosition.left = pApp->GetProfileInt (strSection, _T("left"), -1);
			wp.rcNormalPosition.top = pApp->GetProfileInt (strSection, _T("top"), -1);
			wp.rcNormalPosition.right = pApp->GetProfileInt (strSection, _T("right"), -1);
			wp.rcNormalPosition.bottom = pApp->GetProfileInt (strSection, _T("bottom"), -1);
			if (-1 != wp.flags && -1 != wp.showCmd && (CRect(-1,-1,-1,-1) != wp.rcNormalPosition))
			{
				int screenleft = ::GetSystemMetrics (SM_CXSCREEN) - ::GetSystemMetrics (SM_CXICON);
				int screentop = ::GetSystemMetrics (SM_CYSCREEN) - ::GetSystemMetrics (SM_CYICON);
				wp.rcNormalPosition.left = min (wp.rcNormalPosition.left, screenleft);
				wp.rcNormalPosition.top =  min (wp.rcNormalPosition.top, screentop);
				VERIFY(SetWindowPlacement (&wp));
			}
		}
	}

	if (options.IsRememberToolbarStateEnabled())
	{
		CString sProfile(_T("BarState"));
		if (VerifyBarState(sProfile))
		{
			CSizingControlBar::GlobalLoadState(this, sProfile);
			LoadBarState(sProfile);
		}
	}

	if (options.IsRememberFontFormatSettingsEnabled())
	{
		//restore state to the FontFormat bar
		CString strSection(_T("FontFormatState"));
		CString strSelectedFont = pApp->GetProfileString (strSection, _T("SelectedFontName"));
		if (!strSelectedFont.IsEmpty())
		{
			VERIFY(m_wndFontFormatBar.SetSelectedFontName(strSelectedFont));
		}
		int nFontSize = pApp->GetProfileInt(strSection, _T("SelectedFontSize"), -1);
		if (nFontSize > -1)
		{
			VERIFY(m_wndFontFormatBar.SetSelectedFontPointSize(nFontSize));
		}
		m_wndFontFormatBar.EnableBold(pApp->GetProfileInt(strSection, _T("Bold"), 0));
		m_wndFontFormatBar.EnableItalics(pApp->GetProfileInt(strSection, _T("Italics"), 0));
		m_wndFontFormatBar.EnableUnderline(pApp->GetProfileInt(strSection, _T("Underline"), 0));
	}

	//turn on drag'n drop
	DragAcceptFiles();

	return 0;
}

//---------------------------------------------------------------
// This function is Copyright (c) 2000, Cristi Posea.
// See www.datamekanix.com for more control bars tips&tricks.
BOOL CMainFrame::VerifyBarState(LPCTSTR lpszProfileName)
{
	CDockState state;
	state.LoadState(lpszProfileName);

	for (int i = 0; i < state.m_arrBarInfo.GetSize(); i++)
	{
		CControlBarInfo* pInfo = (CControlBarInfo*)state.m_arrBarInfo[i];
		ASSERT(pInfo != NULL);
		int nDockedCount = (int)pInfo->m_arrBarID.GetSize();
		if (nDockedCount > 0)
		{
			// dockbar
			for (int j = 0; j < nDockedCount; j++)
			{
				UINT nID = (UINT) pInfo->m_arrBarID[j];
				if (nID == 0) continue; // row separator
				if (nID > 0xFFFF)
					nID &= 0xFFFF; // placeholder - get the ID
				if (GetControlBar(nID) == NULL)
					return FALSE;
			}
		}

		if (!pInfo->m_bFloating) // floating dockbars can be created later
			if (GetControlBar(pInfo->m_nBarID) == NULL)
				return FALSE; // invalid bar ID
	}

	return TRUE;
}

//---------------------------------------------------------------
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	return TRUE;
}

#ifdef _DEBUG
//---------------------------------------------------------------
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

//---------------------------------------------------------------
void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

//---------------------------------------------------------------
void CMainFrame::OnClose() 
{
	CWinApp * pApp = AfxGetApp();
	ASSERT(pApp);

	//save the window state
	WINDOWPLACEMENT wp;
	memset(&wp, 0, sizeof(wp));
	wp.length = sizeof (WINDOWPLACEMENT);
	if (GetWindowPlacement (&wp))
	{
		CString strSection(_T("WindowState"));
		VERIFY(pApp->WriteProfileInt (strSection, _T("flags"), wp.flags));
		VERIFY(pApp->WriteProfileInt (strSection, _T("showCmd"), wp.showCmd));
		VERIFY(pApp->WriteProfileInt (strSection, _T("left"), wp.rcNormalPosition.left));
		VERIFY(pApp->WriteProfileInt (strSection, _T("top"), wp.rcNormalPosition.top));
		VERIFY(pApp->WriteProfileInt (strSection, _T("right"), wp.rcNormalPosition.right));
		VERIFY(pApp->WriteProfileInt (strSection, _T("bottom"), wp.rcNormalPosition.bottom));
	}

	CString sProfile = _T("BarState");
	CSizingControlBar::GlobalSaveState(this, sProfile);
	SaveBarState(sProfile);
	
	CString strSection(_T("FontFormatState"));
	VERIFY(pApp->WriteProfileString (strSection, _T("SelectedFontName"), m_wndFontFormatBar.GetSelectedFontName()));
	VERIFY(pApp->WriteProfileInt(strSection, _T("SelectedFontSize"), m_wndFontFormatBar.GetSelectedFontPointSize()));
	VERIFY(pApp->WriteProfileInt(strSection, _T("Bold"), m_wndFontFormatBar.IsBoldEnabled()));
	VERIFY(pApp->WriteProfileInt(strSection, _T("Italics"), m_wndFontFormatBar.IsItalicsEnabled()));
	VERIFY(pApp->WriteProfileInt(strSection, _T("Underline"), m_wndFontFormatBar.IsUnderlineEnabled()));

	CMDIFrameWnd::OnClose();
}

//---------------------------------------------------------------
LRESULT CMainFrame::OnDropperSelectedColor(WPARAM wMouseBtn, LPARAM lColor)
{
	COLORREF selected = (COLORREF)lColor;

	if (0 == wMouseBtn)
	{
		m_wndColorPickerBar.SetForegroundColor(selected);
	}
	else if (1 == wMouseBtn)
	{
		m_wndColorPickerBar.SetBackgroundColor(selected);
	}

	return 0L;
}

//---------------------------------------------------------------
LRESULT CMainFrame::OnCursorPositionChanged(WPARAM wUnused, LPARAM lCursorPos)
{
	CPoint ptCursorPos(LOWORD(lCursorPos), HIWORD(lCursorPos));

	CString strPos;
	strPos.Format(_T("%d,%d"), ptCursorPos.x, ptCursorPos.y);

	const int index = m_wndStatusBar.CommandToIndex(ID_INDICATOR_CURSOR);

	CDC * pDC = m_wndStatusBar.GetDC();
	if (pDC)
	{
		CFont * pFont = m_wndStatusBar.GetFont();
		CFont * pOldFont = pDC->SelectObject(pFont);
		CSize size = pDC->GetTextExtent(strPos);
		pDC->LPtoDP(&size); 
		pDC->SelectObject(pOldFont);
		m_wndStatusBar.ReleaseDC(pDC);
		pDC = NULL;

		UINT id = 0;
		UINT style = 0;
		int width = 0;
		m_wndStatusBar.GetPaneInfo(index, id, style, width);
		m_wndStatusBar.SetPaneInfo(index, id, style, size.cx);
	}

	m_wndStatusBar.SetPaneText(index, strPos);

	return 0L;
}

//---------------------------------------------------------------
void CMainFrame::OnEditPasteAsNewImage()
{
	VERIFY(CMrImageDoc::PasteAsNewImage());
}

//---------------------------------------------------------------
void CMainFrame::OnUpdateEditPasteAsNewImage(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(CMrImageDoc::CanPaste());
}


//---------------------------------------------------------------
void CMainFrame::OnEditOptions()
{
	COptionsDlg options(this);
	if (IDOK == options.DoModal())
	{
		//update the color picker
		UINT unColorWidthHeight = options.GetColorWidthHeight();
		m_wndColorPickerBar.SetColorSize(CSize(unColorWidthHeight, unColorWidthHeight));

		BOOL bUndoRedoEnabled = options.IsUndoRedoEnabled();
		UINT unMaxUndoItems = options.GetMaxUndoItems();

		//Update open docs with the undo/redo settings
		CWinApp * pApp = AfxGetApp();
		POSITION posDoc = NULL;
		CDocument * pDoc = NULL;
		POSITION pos = pApp->m_pDocManager->GetFirstDocTemplatePosition();
		CDocTemplate * pDocTemplate = NULL;
		while (pos)
		{
			pDocTemplate = pApp->m_pDocManager->GetNextDocTemplate(pos);
			
			if (pDocTemplate)
			{
				posDoc = pDocTemplate->GetFirstDocPosition();

				while (posDoc)
				{
					pDoc = pDocTemplate->GetNextDoc(posDoc);

					if (pDoc)
					{
						if (pDoc->IsKindOf(RUNTIME_CLASS(CMrImageDoc)))
						{
							CMrImageDoc * pImageDoc = (CMrImageDoc*)pDoc;
							if (pImageDoc)
							{
								pImageDoc->EnableUndoRedo(bUndoRedoEnabled);
								pImageDoc->SetMaxUndoItems(unMaxUndoItems);
							}
						}
					}
				}//end while
			}
		}//end while
	}
}

//---------------------------------------------------------------
void CMainFrame::OnDropFiles( HDROP hdrop)
{
	TCHAR szNextFile [MAX_PATH];

	// Get the # of files being dropped.
	const UINT uNumFiles = DragQueryFile ( hdrop, -1, NULL, 0 );

	for ( UINT i = 0; i < uNumFiles; ++i )
	{
		memset(szNextFile, 0, sizeof(szNextFile));

		// Get the next filename from the HDROP info.
		if ( DragQueryFile ( hdrop, i, szNextFile, MAX_PATH ) > 0 )
		{
			// Do whatever you want with the filename in szNextFile.
			AfxGetApp()->OpenDocumentFile(szNextFile);
		}
	}

	// Free up memory.
	DragFinish ( hdrop );
}

//---------------------------------------------------------------
void CMainFrame::OnWindows()
{
	CWindowsDlg dlg(this);
	dlg.DoModal();
}


//---------------------------------------------------------------
void CMainFrame::OnOpenBinToHex()
{
	CBinToHex dlg;
	dlg.DoModal();
}


//---------------------------------------------------------------
//---------------------------------------------------------------

}//end namespace



