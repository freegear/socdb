/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "resource.h"
#include "ResizeDlg.h"

namespace MrImage
{

IMPLEMENT_DYNAMIC(CResizeDlg, CDialog)
CResizeDlg::CResizeDlg(CWnd* pParent /*=NULL*/)
: CDialog(CResizeDlg::IDD, pParent)
,m_sizeOriginal(0,0)
,m_bSizeSmaller(TRUE)
,m_nHoriz(0)
,m_nVert(0)
,m_wndSpinHorz()
,m_wndSpinVert()
,m_bActual(TRUE)
{
}

CResizeDlg::~CResizeDlg()
{
}

void CResizeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Text(pDX,IDC_EDIT_HORIZ, m_nHoriz);
	DDX_Text(pDX,IDC_EDIT_VERT, m_nVert);
	DDX_Control(pDX, IDC_SPIN_HORIZ, m_wndSpinHorz);
	DDX_Control(pDX, IDC_SPIN_VERT, m_wndSpinVert);
}


BEGIN_MESSAGE_MAP(CResizeDlg, CDialog)
	ON_BN_CLICKED(IDC_RADIO_PERCENTAGE, OnBnClickedRadioPercentage)
	ON_BN_CLICKED(IDC_RADIO_ACTUAL, OnBnClickedRadioActual)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_EN_KILLFOCUS(IDC_EDIT_HORIZ, OnHorzChange)
	ON_EN_KILLFOCUS(IDC_EDIT_VERT, OnVertChange)
END_MESSAGE_MAP()

BOOL CResizeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	CString strOrigSize;
	m_sizeOriginal = CSize(m_nHoriz, m_nVert);
	strOrigSize.Format(IDS_ORIGINALSIZE, m_nHoriz, m_nVert);
	SetDlgItemText(IDC_STATIC_ORIGSIZE,strOrigSize);
	((CButton*)GetDlgItem(IDC_RADIO_ACTUAL))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_RADIO_PERCENTAGE))->SetCheck(0);
	int nMinX = 0;
	int nMinY = 0;
	if (!m_bSizeSmaller)
	{
		nMinX = m_sizeOriginal.cx;
		nMinY = m_sizeOriginal.cy;
	}
	m_wndSpinVert.SetRange32(nMinY, 65535);
	m_wndSpinHorz.SetRange32(nMinX, 65535);
	return TRUE;  // return TRUE unless you set the focus to a control
}

void CResizeDlg::OnHorzChange()
{
	UpdateData(TRUE);

	if (!m_bSizeSmaller)
	{
		if (m_bActual)
		{
			if (m_nHoriz < m_sizeOriginal.cx)
			{
				m_nHoriz = m_sizeOriginal.cx;
			}
		}
		else
		{
			if (m_nHoriz < 100)
			{
				m_nHoriz = 100;
			}
		}
	}

	UpdateData(FALSE);
}

void CResizeDlg::OnVertChange()
{
	UpdateData(TRUE);

	if (!m_bSizeSmaller)
	{
		if (m_bActual)
		{
			if (m_nVert < m_sizeOriginal.cy)
			{
				m_nVert = m_sizeOriginal.cy;
			}
		}
		else
		{
			if (m_nVert < 100)
			{
				m_nVert = 100;
			}
		}
	}

	UpdateData(FALSE);
}

void CResizeDlg::CalcPercentage()
{
	if (0 != m_sizeOriginal.cx)
	{
		m_nHoriz = (int)((double)m_nHoriz / (double)m_sizeOriginal.cx) * 100;
	}

	if (0 != m_sizeOriginal.cy)
	{
		m_nVert = (int)((double)m_nVert / (double)m_sizeOriginal.cy) * 100;
	}

	if (!m_bSizeSmaller)
	{
		if (m_nHoriz < 100)
		{
			m_nHoriz = 100;
		}

		if (m_nVert < 100)
		{
			m_nVert = 100;
		}

		m_wndSpinVert.SetRange32(100, 500);
		m_wndSpinHorz.SetRange32(100, 500);
	}
}

void CResizeDlg::CalcActual()
{
	m_nHoriz = (int)(m_sizeOriginal.cx * (m_nHoriz * .01));
	m_nVert = (int)(m_sizeOriginal.cy * (m_nVert * .01));
	
	if (!m_bSizeSmaller)
	{
		if (m_nHoriz < m_sizeOriginal.cx)
		{
			m_nHoriz = m_sizeOriginal.cx;
		}

		if (m_nVert < m_sizeOriginal.cy)
		{
			m_nVert = m_sizeOriginal.cy;
		}

		m_wndSpinVert.SetRange32(m_sizeOriginal.cx, 65535);
		m_wndSpinHorz.SetRange32(m_sizeOriginal.cy, 65535);
	}
}

// CResizeDlg message handlers
void CResizeDlg::OnBnClickedRadioPercentage()
{
	if (m_bActual)
	{
		if (UpdateData())
		{
			m_bActual = FALSE;

			CalcPercentage();

			m_wndSpinHorz.SetPos(m_nHoriz);
			m_wndSpinVert.SetPos(m_nVert);

			VERIFY(UpdateData(FALSE));
		}
	}
}

void CResizeDlg::OnBnClickedRadioActual()
{
	if (!m_bActual)
	{
		if (UpdateData())
		{
			m_bActual = TRUE;

			CalcActual();

			m_wndSpinHorz.SetPos(m_nHoriz);
			m_wndSpinVert.SetPos(m_nVert);

			VERIFY(UpdateData(FALSE));
		}
	}
}

void CResizeDlg::OnOK()
{
	if (UpdateData())
	{
		if (!m_bActual)
		{
			CalcActual();

			VERIFY(UpdateData(FALSE));
		}
	}
	CDialog::OnOK();
}

}//end namespace
