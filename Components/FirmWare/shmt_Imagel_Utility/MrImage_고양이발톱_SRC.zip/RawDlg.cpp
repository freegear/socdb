// RawDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "MrImage.h"
#include "RawDlg.h"
#include ".\rawdlg.h"



// CRawDlg dialog

IMPLEMENT_DYNAMIC(CRawDlg, CDialog)
CRawDlg::CRawDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRawDlg::IDD, pParent)
{
	m_widthValue = 0;
	m_widthValue = 0;

}

CRawDlg::~CRawDlg()
{
}

void CRawDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_COMBO_PACKED, m_comBoPacked);
	DDX_Control(pDX, IDC_COMBO_SAMPLE_FORMAT, m_comBoSampleFormat);
	DDX_Control(pDX, IDC_COMBO_INTERLACED, m_comBoInterlaced);

	DDX_Control(pDX, IDC_RADIO_RGB565, m_vRGB565);
	DDX_Control(pDX, IDC_RADIO_RGB_666, m_vRGB666);
	DDX_Control(pDX, IDC_RADIO_RGB888, m_vRGB888);
	DDX_Control(pDX, IDC_RADIO_YUV, m_vYUV);
	DDX_Text(pDX, IDC_EDIT_MASK_R, m_Rmask);
	DDX_Text(pDX, IDC_EDIT_MASK_G, m_Gmask);
	DDX_Text(pDX, IDC_EDIT_MASK_B, m_Bmask);
	DDX_Text(pDX, IDC_EDIT_WIDTH, m_width);
	DDX_Text(pDX, IDC_EDIT_HEIGHT, m_height);
}
BEGIN_MESSAGE_MAP(CRawDlg, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_BN_CLICKED(IDC_RADIO_RGB_666, OnBnClickedRadioRgb666)
	ON_BN_CLICKED(IDC_RADIO_RGB888, OnBnClickedRadioRgb888)
	ON_BN_CLICKED(IDC_RADIO_RGB565, OnBnClickedRadioRgb565)
	ON_BN_CLICKED(IDC_RADIO_YUV, OnBnClickedRadioYUV)
END_MESSAGE_MAP()


BOOL CRawDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here

	if(m_dlgStart==DLG_OPEN_YUV)
	{
		m_vYUV.SetCheck(1);
		m_vRGB565.EnableWindow(0);
		m_vRGB666.EnableWindow(0);
		m_vRGB888.EnableWindow(0);
		
		GetDlgItem(IDC_EDIT_MASK_R)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MASK_G)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MASK_B)->EnableWindow(0);

		m_width.Format("%d", m_widthValue);
		m_height.Format("%d", m_heightValue);

		m_comBoPacked.SetCurSel(0);
		m_comBoSampleFormat.SetCurSel(1);
		m_comBoInterlaced.SetCurSel(0);

		m_comBoPacked.EnableWindow(0);
		m_comBoSampleFormat.EnableWindow(0);
		m_comBoInterlaced.EnableWindow(0);

	}
	else if(m_dlgStart==DLG_OPEN_RGB)
	{
		m_vRGB565.SetCheck(1);
		m_vYUV.EnableWindow(0);
		m_vRGB666.EnableWindow(0);

		m_Rmask.Format("0x1F");
		m_Gmask.Format("0x3F");
		m_Bmask.Format("0x1F");
		
		m_width.Format("%d", m_widthValue);
		m_height.Format("%d", m_heightValue);

		m_comBoPacked.EnableWindow(0);
		m_comBoSampleFormat.EnableWindow(0);
		m_comBoInterlaced.EnableWindow(0);
	}
	else if(m_dlgStart==DLG_SAVE_YUV)
	{
		m_vYUV.SetCheck(1);
		m_vRGB565.EnableWindow(0);
		m_vRGB666.EnableWindow(0);
		m_vRGB888.EnableWindow(0);
		
		GetDlgItem(IDC_EDIT_MASK_R)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MASK_G)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MASK_B)->EnableWindow(0);

		m_width.Format("%d", m_widthValue);
		m_height.Format("%d", m_heightValue);

		m_comBoPacked.SetCurSel(0);
		m_comBoSampleFormat.SetCurSel(1);
		m_comBoInterlaced.SetCurSel(0);

		m_comBoPacked.EnableWindow(1);
		m_comBoSampleFormat.EnableWindow(1);
		m_comBoInterlaced.EnableWindow(1);	
	}
	else if(m_dlgStart==DLG_SAVE_RGB)
	{
		m_vRGB565.SetCheck(1);
		m_vRGB666.EnableWindow(0);
		m_vYUV.EnableWindow(0);

		m_Rmask.Format("0x1F");
		m_Gmask.Format("0x3F");
		m_Bmask.Format("0x1F");

		m_width.Format("%d", m_widthValue);
		m_height.Format("%d", m_heightValue);

		m_comBoPacked.EnableWindow(0);
		m_comBoSampleFormat.EnableWindow(0);
		m_comBoInterlaced.EnableWindow(0);		
	}
	
	UpdateData(FALSE); 

	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

/*

void main( void ) 
{
    char *string = "0xFF";
    char *stop;
    int radix;
    long value;

    radix = 16; // ����
    
    value = strtol( string, &stop, radix );

    printf( "%d ���� ���ڰ� ��ȯ�Ǿ����ϴ�. \n", stop - string );
    printf( "16���� %s�� ���ڷ� ��ȯ�ϸ� %ld�Դϴ�. \n", string, value );
} 

*/
void CRawDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	char *string;
    char *stop;
    int radix;

	UpdateData(TRUE);

	if (m_vRGB565.GetCheck())		m_method = 16;
	else if (m_vRGB666.GetCheck())	m_method = 18;
	else if (m_vRGB888.GetCheck())	m_method = 24;
	else m_method = 0;

	string = (LPSTR)(LPCSTR)m_Rmask;
	radix = 16;
	m_RmaskValue = strtol( string, &stop, radix );

	string = (LPSTR)(LPCTSTR)m_Gmask;
	radix = 16;
	m_GmaskValue = strtol( string, &stop, radix );

	string = (LPSTR)(LPCTSTR)m_Bmask;
	radix = 16;
	m_BmaskValue = strtol( string, &stop, radix );

	string = (LPSTR)(LPCTSTR)m_width;
	radix = 10;
	m_widthValue = strtol( string, &stop, radix );

	string = (LPSTR)(LPCTSTR)m_height;
	radix = 10;
	m_heightValue = strtol( string, &stop, radix );

	m_packed		= m_comBoPacked.GetCurSel();
	m_sampleFormat	= m_comBoSampleFormat.GetCurSel();
	m_interlaced	= m_comBoInterlaced.GetCurSel();

	OnOK();
}


void CRawDlg::OnBnClickedRadioRgb666()
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_EDIT_MASK_R)->EnableWindow(0);
	GetDlgItem(IDC_EDIT_MASK_G)->EnableWindow(0);
	GetDlgItem(IDC_EDIT_MASK_B)->EnableWindow(0);

	GetDlgItem(IDC_COMBO_INTERLACED)->EnableWindow(0);
	GetDlgItem(IDC_COMBO_SAMPLE_FORMAT)->EnableWindow(0);
	m_comBoPacked.EnableWindow(0);

}

void CRawDlg::OnBnClickedRadioRgb888()
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_EDIT_MASK_R)->EnableWindow(0);
	GetDlgItem(IDC_EDIT_MASK_G)->EnableWindow(0);
	GetDlgItem(IDC_EDIT_MASK_B)->EnableWindow(0);

	GetDlgItem(IDC_COMBO_PACKED)->EnableWindow(0);
	GetDlgItem(IDC_COMBO_INTERLACED)->EnableWindow(0);
	GetDlgItem(IDC_COMBO_SAMPLE_FORMAT)->EnableWindow(0);
}

void CRawDlg::OnBnClickedRadioRgb565()
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_EDIT_MASK_R)->EnableWindow(1);
	GetDlgItem(IDC_EDIT_MASK_G)->EnableWindow(1);
	GetDlgItem(IDC_EDIT_MASK_B)->EnableWindow(1);

	GetDlgItem(IDC_COMBO_PACKED)->EnableWindow(0);
	GetDlgItem(IDC_COMBO_INTERLACED)->EnableWindow(0);
	GetDlgItem(IDC_COMBO_SAMPLE_FORMAT)->EnableWindow(0);
}


void CRawDlg::OnBnClickedRadioYUV()
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_EDIT_MASK_R)->EnableWindow(0);
	GetDlgItem(IDC_EDIT_MASK_G)->EnableWindow(0);
	GetDlgItem(IDC_EDIT_MASK_B)->EnableWindow(0);

	GetDlgItem(IDC_COMBO_PACKED)->EnableWindow(1);
	GetDlgItem(IDC_COMBO_INTERLACED)->EnableWindow(1);
	GetDlgItem(IDC_COMBO_SAMPLE_FORMAT)->EnableWindow(1);
}
