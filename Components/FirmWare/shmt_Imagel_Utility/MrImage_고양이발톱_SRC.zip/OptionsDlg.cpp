/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

// OptionsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "OptionsDlg.h"

namespace MrImage
{

static const int DEFAULT_CELL_SIZE = 8;
static const int SMALLEST_CELL_SIZE = 4;
static const int LARGEST_CELL_SIZE = 52;
static const int MAX_UNDO_ITEMS = 512;
static const int MIN_UNDO_ITEMS = 1;
static LPCTSTR SECTION_COLORPICKER = _T("ColorPicker");
static LPCTSTR SECTION_IMAGEVIEW = _T("ImageView");
static LPCTSTR SECTION_WINDOWSTATE = _T("WindowState");

IMPLEMENT_DYNAMIC(COptionsDlg, CDialog)
COptionsDlg::COptionsDlg(CWnd* pParent /*=NULL*/)
:CDialog(COptionsDlg::IDD, pParent)
,m_unColorSize(DEFAULT_CELL_SIZE)
,m_bRememberColorTab(TRUE)
,m_bRememberApplyToSelection(TRUE)
,m_bRememberWindowState(TRUE)
,m_bEnableUndoRedo(TRUE)
,m_unMaxUndoItems(MAX_UNDO_ITEMS)
,m_unLastColorTab(0)
,m_bRememberToolbarState(TRUE)
,m_bApplyToSelection(TRUE)
,m_bSaveSettings(TRUE)
,m_bRememberFontFormatSettings(TRUE)
{
	CWinApp * pApp = AfxGetApp();
	if (pApp)
	{
		m_unColorSize = pApp->GetProfileInt(SECTION_COLORPICKER, _T("Color Size"), m_unColorSize);
		m_bRememberColorTab = pApp->GetProfileInt(SECTION_COLORPICKER, _T("Remember Tab"), m_bRememberColorTab);
		m_unLastColorTab = pApp->GetProfileInt(SECTION_COLORPICKER, _T("LastTab"), m_unLastColorTab);

		m_bRememberApplyToSelection = pApp->GetProfileInt(SECTION_IMAGEVIEW, _T("Remember Apply To Selection"), m_bRememberApplyToSelection);
		m_bEnableUndoRedo = pApp->GetProfileInt(SECTION_IMAGEVIEW, _T("EnableUndoRedo"), m_bEnableUndoRedo);
		m_unMaxUndoItems = pApp->GetProfileInt(SECTION_IMAGEVIEW, _T("GetMaxUndoItems"), m_unMaxUndoItems);

		m_bRememberWindowState = pApp->GetProfileInt(SECTION_WINDOWSTATE, _T("Remember Window SizePos"), m_bRememberWindowState);
		m_bRememberToolbarState = pApp->GetProfileInt(SECTION_WINDOWSTATE, _T("Remember Toolbar SizePos"), m_bRememberToolbarState);
		m_bApplyToSelection = pApp->GetProfileInt(SECTION_IMAGEVIEW, _T("ApplyToSelection"), m_bApplyToSelection);
		m_bRememberFontFormatSettings = pApp->GetProfileInt(SECTION_IMAGEVIEW, _T("Remember FontFormat Settings"), m_bRememberFontFormatSettings);
	}
}

COptionsDlg::~COptionsDlg()
{
	if (m_bSaveSettings)
	{
		CWinApp * pApp = AfxGetApp();
		if (pApp)
		{
			pApp->WriteProfileInt(SECTION_COLORPICKER, _T("Color Size"), m_unColorSize);
			pApp->WriteProfileInt(SECTION_COLORPICKER, _T("Remember Tab"), m_bRememberColorTab);
			pApp->WriteProfileInt(SECTION_COLORPICKER, _T("LastTab"), m_unLastColorTab);
			pApp->WriteProfileInt(SECTION_IMAGEVIEW, _T("Remember Apply To Selection"), m_bRememberApplyToSelection);
			pApp->WriteProfileInt(SECTION_IMAGEVIEW, _T("EnableUndoRedo"), m_bEnableUndoRedo);
			pApp->WriteProfileInt(SECTION_IMAGEVIEW, _T("GetMaxUndoItems"), m_unMaxUndoItems);

			pApp->WriteProfileInt(SECTION_WINDOWSTATE, _T("Remember Window SizePos"), m_bRememberWindowState);
			pApp->WriteProfileInt(SECTION_WINDOWSTATE, _T("Remember Toolbar SizePos"), m_bRememberToolbarState);
			pApp->WriteProfileInt(SECTION_IMAGEVIEW, _T("ApplyToSelection"), m_bApplyToSelection);
			pApp->WriteProfileInt(SECTION_IMAGEVIEW, _T("Remember FontFormat Settings"), m_bRememberFontFormatSettings);
		}
	}
}

void COptionsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_EDIT_COLOR_SIZE, m_unColorSize);
	DDV_MinMaxInt(pDX, m_unColorSize, SMALLEST_CELL_SIZE, LARGEST_CELL_SIZE);
	DDX_Check(pDX, IDC_CHECK_REMEMBER_COLOR_TAB, m_bRememberColorTab);
	DDX_Check(pDX, IDC_CHECK_REMEMBER_APPLY_TO_SELECTION, m_bRememberApplyToSelection);
	DDX_Check(pDX, IDC_CHECK_REMEMBER_WINDOW_SIZEPOS, m_bRememberWindowState);
	DDX_Check(pDX, IDC_CHECK_ENABLE_UNDO_REDO, m_bEnableUndoRedo);
	DDX_Text(pDX, IDC_EDIT_MAX_UNDO_ITEMS, m_unMaxUndoItems);
	DDV_MinMaxInt(pDX, m_unMaxUndoItems, MIN_UNDO_ITEMS, MAX_UNDO_ITEMS);
	DDX_Check(pDX, IDC_CHECK_REMEMBER_TOOLBAR_SIZEPOS, m_bRememberToolbarState);
	DDX_Check(pDX, IDC_CHECK_REMEMBER_FONTFORMAT_SETTINGS, m_bRememberFontFormatSettings);
}

BEGIN_MESSAGE_MAP(COptionsDlg, CDialog)
END_MESSAGE_MAP()

BOOL COptionsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	//since the dialog was invoked
	//do not save settings unless user hits IDOK
	m_bSaveSettings = FALSE;

	return TRUE;
}

void COptionsDlg::OnOK()
{
	CDialog::OnOK();
	m_bSaveSettings = TRUE;
}

}//end namespace