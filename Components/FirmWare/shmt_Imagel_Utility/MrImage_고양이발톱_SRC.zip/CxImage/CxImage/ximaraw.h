#pragma once

#include "ximabmp.h"

#define YUV_PACKED 0
#define YUV_PLANAR 1

#define YUV_420 0
#define YUV_422 1
#define YUV_444 2

#define YUV_INTERLACED  0
#define YUV_PROGRESSIVE 1


typedef struct {
	unsigned char r,g,b,a;
} BITMAP4;

typedef struct tagVOIDARGU
{
	char    *arg0;
	char    *arg1;
	int     arg2;
	int     arg3;
	int     arg4;
	int     arg5;
	int     arg6;
	int     arg7;
	int     arg8;
	int     arg9;
} VOIDARGU;

class CxImageRAW : public CxImageBMP
{
public:
	CxImageRAW(void);
	CxImageRAW(char *dummy);	
	~CxImageRAW(void); 
	bool DecodeRaw(CxFile * hFile, void *str);	
	bool EncodeRaw(CxFile * hFile);
	bool EncodeRaw(CxFile * hFile, void *dummy);

	bool DecodeYUV(CxFile * hFile, void *str);
	BITMAP4 YUV422_to_Bitmap(int y,int u,int v);
	void YUV422_Convert(unsigned char *yuv,BITMAP4 *rgb1,BITMAP4 *rgb2);
	bool EncodeYUV422_Packed(CxFile * hFile, void *dummy);
	bool EncodeYUV422_planar(CxFile * hFile, void *dummy);
	bool EncodeYUV422(CxFile * hFile, void *dummy);


};
