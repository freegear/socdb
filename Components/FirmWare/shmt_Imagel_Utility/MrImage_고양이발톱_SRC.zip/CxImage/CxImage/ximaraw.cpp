

#include "ximaraw.h"

#if CXIMAGE_SUPPORT_RAW

#include "ximaiter.h"


CxImageRAW::CxImageRAW(void)
{	
}

CxImageRAW::CxImageRAW(char *dummy)
{
}

CxImageRAW::~CxImageRAW(void)
{
}

/**********
argument.arg2 = dlg.m_heightValue;
argument.arg3 = dlg.m_widthValue;

argument.arg4 = dlg.m_packed;
argument.arg5 = dlg.m_sampleFormat;
argument.arg6 = dlg.m_interlaced;

#define YUV_PACKED 0
#define YUV_PLANAR 1

#define YUV_420 0
#define YUV_422 1
#define YUV_444 2

#define YUV_INTERLACED  0
#define YUV_PROGRESSIVE 1

**********/

bool CxImageRAW::EncodeYUV422(CxFile * hFile, void *dummy)
{
	VOIDARGU *argument = (VOIDARGU *)dummy;

	if(argument->arg6 == YUV_INTERLACED)
	{
		if(argument->arg4 == YUV_PACKED)
		{
			return EncodeYUV422_Packed(hFile, dummy);
		}
		else if(argument->arg4 == YUV_PLANAR)
		{
			return EncodeYUV422_planar(hFile, dummy);
		}
	}
	else if(argument->arg6 == YUV_PROGRESSIVE)
	{
		strcpy(info.szLastError, "Save This FORMAT not supported");
		return false;
	
	}

	return false;
}

/*
bool CxImage::Save(const TCHAR * filename, DWORD imagetype, void *dummy)
argument.arg0 = filename;

BOOL CMrImageDoc::OnSaveDocument(LPCTSTR lpszPathName)
argument.arg2 = dlg.m_heightValue;
argument.arg3 = dlg.m_widthValue;
*/
bool CxImageRAW::EncodeYUV422_Packed(CxFile * hFile, void *dummy)
{
	VOIDARGU *argument = (VOIDARGU *)dummy;
	unsigned char *p_pDib  = (unsigned char *)pDib;
	p_pDib += 40;

    int R1, G1, B1;
    int R2, G2, B2;
    int Y1, Cb1, Cr1;
    int Y2, Cb2, Cr2; 
    
    int wi, hi;
    
    unsigned char yuv[4];

	int width  = argument->arg2;
	int height = argument->arg3;
	    	    
    for(hi = 0; hi<height; hi++) {
        for(wi = 0; wi < width; wi++) {

			R1 = *p_pDib++;
			G1 = *p_pDib++;
			B1 = *p_pDib++;
			wi++;
            
            Y1  = (int)(0.2989 * R1 + 0.5866 * G1 + 0.1145 * B1);
            Cb1 = (int)((B1 - Y1) / (2. - 2. * 0.1145));
            Cr1 = (int)((R1 - Y1) / (2. - 2. * 0.2989));

			R2 = *p_pDib++;
			G2 = *p_pDib++;
			B2 = *p_pDib++;

            Y2  = (int)(0.2989 * R2 + 0.5866 * G2 + 0.1145 * B2);
            Cb2 = (int)((B2 - Y2) / (2. - 2. * 0.1145));
            Cr2 = (int)((R2 - Y2) / (2. - 2. * 0.2989));
		      
		      
            yuv[2] = (unsigned char)((unsigned char) (128 + (Cb1 + Cb2) / 2) * 224./255.+ 16);
            yuv[1] = (unsigned char)(Y1);//(unsigned char) Y1 * 219./255/ + 16;                    
            yuv[0] = (unsigned char)((unsigned char) (128 + (Cr1 + Cr2) / 2) * 224./255.+ 16);
            yuv[3] = (unsigned char)(Y2);//(unsigned char) Y2 * 219./255/ + 16;                    
										
			hFile->Write(yuv, 4, 1);
        }
    }

	return true;
}


bool CxImageRAW::EncodeYUV422_planar(CxFile * hFile, void *dummy)
{
	VOIDARGU *argument = (VOIDARGU *)dummy;
	unsigned char *p_pDib;
	
    int R1, G1, B1;
    int R2, G2, B2;
    int Y1, Cb1, Cr1;
    int Y2, Cb2, Cr2; 

    int wi, hi;
    unsigned char yuv[4];

	int width  = argument->arg2;
	int height = argument->arg3;
  	   
	// write y                  
	p_pDib  = (unsigned char *)pDib; p_pDib += 40;
	for(hi = 0; hi < height; hi++)  {   	
		for(wi = 0; wi < width; wi++) 	{
			
			R1 = *p_pDib++;
			G1 = *p_pDib++;
			B1 = *p_pDib++;
					
			Y1 		= (int)(0.2989 * R1 + 0.5866 * G1 + 0.1145 * B1); 		
			yuv[0] 	= Y1; 

			hFile->Write(&yuv[0], sizeof(char), 1);	  		
		}
	}                                 

	// write u
	p_pDib  = (unsigned char *)pDib; p_pDib += 40;
	for(hi = 0; hi < height; hi+=2)  {
		for(wi = 0; wi < width; wi++) {
							
			R1 = *p_pDib++;
			G1 = *p_pDib++;
			B1 = *p_pDib++;
			
			wi++; p_pDib += 3;

			R2 = *p_pDib++;
			G2 = *p_pDib++;
			B2 = *p_pDib++;

			Y1 = (int)(0.2989 * R1 + 0.5866 * G1 + 0.1145 * B1);    
			Y2 = (int)(0.2989 * R2 + 0.5866 * G2 + 0.1145 * B2);  

            Cr1 = (int)((R1 - Y1) / (2. - 2. * 0.2989));
            Cr2 = (int)((R2 - Y2) / (2. - 2. * 0.2989));
            
            Cr1 = (int)((unsigned char) (128 + (Cr1 + Cr2) / 2) * 224./255.+ 16);
            yuv[0] = (unsigned char)Cr1;
	  		hFile->Write(&yuv[0], sizeof(char), 1);	  		
		}                               
	}       		             
	                             
	// write v
	p_pDib  = (unsigned char *)pDib; p_pDib += 40;
	for(hi = 0; hi < height; hi+=2)  {
		for(wi = 0; wi < width; wi++) 	{				
					
			R1 = *p_pDib++;
			G1 = *p_pDib++;
			B1 = *p_pDib++;
			
			wi++; p_pDib += 3;

			R2 = *p_pDib++;
			G2 = *p_pDib++;
			B2 = *p_pDib++;
			                                            
			Y1 = (int)(0.2989 * R1 + 0.5866 * G1 + 0.1145 * B1);    
			Y2 = (int)(0.2989 * R2 + 0.5866 * G2 + 0.1145 * B2);  
			
			
			Cb1 = (int)((B1 - Y1) / (2. - 2. * 0.1145));      
			Cb2 = (int)((B2 - Y2) / (2. - 2. * 0.1145));      				
			
			Cb1 = (int)((unsigned char) (128 + (Cb1 + Cb2) / 2) * 224./255.+ 16);
            
			yuv[0] = (unsigned char)Cb1;
	  		hFile->Write(&yuv[0], sizeof(char), 1);
		}                               
	}

	return true;
}    



/*
argument.arg2 = dlg.m_method;
argument.arg3 = dlg.m_heightValue;
argument.arg4 = dlg.m_widthValue;
argument.arg5 = dlg.m_RmaskValue;
argument.arg6 = dlg.m_GmaskValue;
argument.arg7 = dlg.m_BmaskValue;
*/
bool CxImageRAW::EncodeRaw(CxFile * hFile, void *dummy)
{
	VOIDARGU *argument = (VOIDARGU *)dummy;

	unsigned char *p_pDib  = (unsigned char *)pDib;
	int wSize;


	int i, bpp;
	unsigned char buf[2];
	unsigned short raw;

		
	wSize = GetSize();
	bpp = argument->arg2;

	p_pDib += 40;
	wSize -=  40;

	if(bpp ==16)  // 565
	{
		for(i=0;i<wSize;i += 3, p_pDib += 3)
		{
			#define RGB565(r,g,b) ((((b)>>3)<<11)|(((g)>>2)<<5)|((r)>>3))


			raw = RGB565(p_pDib[0], p_pDib[1], p_pDib[2]);

			buf[0] = raw & 0xFF;
			buf[1] = raw >> 8;

			hFile->Write(buf, 2, 1);
		}
	}
	else //RGB888
	{
		hFile->Write(p_pDib,wSize,1);
	}

	return true;
}

/*

CMrImageDoc::OnOpenDocument()

argument.arg2 = dlg.m_heightValue;
argument.arg3 = dlg.m_widthValue;
argument.arg4 = dlg.m_sampleFormat;
argument.arg5 = dlg.m_packed;
argument.arg6 = dlg.m_interlaced;
argument.arg7 = filesize

*/
bool CxImageRAW::DecodeYUV(CxFile * hFile, void *str)
{
	FILE* rgbFile;
	int length;
	VOIDARGU *argument = (VOIDARGU *)str;

	TCHAR * filename = (TCHAR *)argument->arg0;
	length = strlen(filename);

	filename[length-3] = 's';
	filename[length-2] = 'm';
	filename[length-1] = 't';

	#ifdef WIN32
			if ((rgbFile=_tfopen(filename,_T("wb")))==NULL)  return false;	// For UNICODE support
	#else
			if ((rgbFile=fopen(filename,"wb"))==NULL)  return false;
	#endif
	
	/**********************************************/
	/*                                            */
	/**********************************************/
	int count;
	unsigned char rgb1[4], rgb2[4]; 
	unsigned char yuv[4];
	int wi, hi, filelen;
	
    memset(rgb1, 0, 4);
    memset(rgb2, 0, 4);

	hi = argument->arg2;
	wi = argument->arg3;
	filelen = argument->arg7;

	for(count=0;count<filelen;count += 4)
	{
		hFile->Read(yuv, 4, 1);
		YUV422_Convert(yuv,(BITMAP4 *)rgb1,(BITMAP4 *)rgb2);
		fwrite(rgb1, 3, 1, rgbFile);
		fwrite(rgb2, 3, 1, rgbFile);
	}

	count = filelen%4;
	if(count!=0)
	{
		memset(yuv, 0, 4);
		hFile->Read(yuv, count, 1);
		YUV422_Convert(yuv,(BITMAP4 *)rgb1,(BITMAP4 *)rgb2);
		fwrite(rgb1, 3, 1, rgbFile);
		fwrite(rgb2, 3, 1, rgbFile);	
	}

	fclose(rgbFile);

	return true;
}


/*
argument.arg2 = dlg.m_method;
argument.arg3 = dlg.m_heightValue;
argument.arg4 = dlg.m_widthValue;
argument.arg5 = dlg.m_RmaskValue;
argument.arg6 = dlg.m_GmaskValue;
argument.arg7 = dlg.m_BmaskValue;
*/

bool CxImageRAW::DecodeRaw(CxFile * hFile, void *str)
{
	if (hFile == NULL) return false;

	BITMAPFILEHEADER   bf;
	DWORD off = hFile->Tell(); //<CSC>

  try {
    //if (hFile->Read(&bf,min(14,sizeof(bf)),1)==0) throw "Not a BMP";
	  hFile->Read(&bf,min(14,sizeof(bf)),1);
    if (bf.bfType != BFT_BITMAP) { //do we have a RC HEADER?
        bf.bfOffBits = 0L;
        hFile->Seek(off,SEEK_SET);
    }
	
	VOIDARGU *argument = (VOIDARGU *)str;
	BITMAPINFOHEADER bmpHeader;
	DWORD RGBmask[3] = {0,0,0};
	
	memset(&bmpHeader, 0, sizeof(bmpHeader));

	bmpHeader.biBitCount = argument->arg2;
	bmpHeader.biHeight = argument->arg3;
	bmpHeader.biWidth = argument->arg4;

	RGBmask[0] = argument->arg5;
	RGBmask[1] = argument->arg6;
	RGBmask[2] = argument->arg7;

	DWORD dwCompression= bmpHeader.biCompression;
	DWORD dwBitCount=bmpHeader.biBitCount; //preserve for BI_BITFIELDS compression <Thomas Ernst>
	bool bIsOldBmp = bmpHeader.biSize == sizeof(BITMAPCOREHEADER);

	bool bTopDownDib = bmpHeader.biHeight<0; //<Flanders> check if it's a top-down bitmap
	if (bTopDownDib) bmpHeader.biHeight=-bmpHeader.biHeight;

	if (info.nEscape == -1) {
		// Return output dimensions only
		head.biWidth = bmpHeader.biWidth;
		head.biHeight = bmpHeader.biHeight;
		throw "output dimensions returned";
	}

	if (!Create(bmpHeader.biWidth,bmpHeader.biHeight,bmpHeader.biBitCount,CXIMAGE_FORMAT_BMP))
		throw "Can't allocate memory";

	head.biXPelsPerMeter = bmpHeader.biXPelsPerMeter;
	head.biYPelsPerMeter = bmpHeader.biYPelsPerMeter;
	info.xDPI = (long) floor(bmpHeader.biXPelsPerMeter * 254.0 / 10000.0 + 0.5);
	info.yDPI = (long) floor(bmpHeader.biYPelsPerMeter * 254.0 / 10000.0 + 0.5);

	if (info.nEscape) throw "Cancelled"; // <vho> - cancel decoding

    RGBQUAD *pRgb = GetPalette();
    if (pRgb){
        if (bIsOldBmp){
             // convert a old color table (3 byte entries) to a new
             // color table (4 byte entries)
            hFile->Read((void*)pRgb,DibNumColors(&bmpHeader) * sizeof(RGBTRIPLE),1);
            for (int i=DibNumColors(&head)-1; i>=0; i--){
                pRgb[i].rgbRed      = ((RGBTRIPLE *)pRgb)[i].rgbtRed;
                pRgb[i].rgbBlue     = ((RGBTRIPLE *)pRgb)[i].rgbtBlue;
                pRgb[i].rgbGreen    = ((RGBTRIPLE *)pRgb)[i].rgbtGreen;
                pRgb[i].rgbReserved = (unsigned char)0;
            }
        } else {
            hFile->Read((void*)pRgb,DibNumColors(&bmpHeader) * sizeof(RGBQUAD),1);
			//force rgbReserved=0, to avoid problems with some WinXp bitmaps
			for (unsigned int i=0; i<head.biClrUsed; i++) pRgb[i].rgbReserved=0;
        }
    }


	if (info.nEscape) throw "Cancelled"; // <vho> - cancel decoding

	switch (dwBitCount) {
		case 32 :
			if (bf.bfOffBits != 0L) hFile->Seek(off + bf.bfOffBits,SEEK_SET);
			if (dwCompression == BI_BITFIELDS || dwCompression == BI_RGB){
				long imagesize=4*head.biHeight*head.biWidth;
				unsigned char* buff32=(unsigned char *)malloc(imagesize);
				if (buff32){
					hFile->Read(buff32, imagesize,1); // read in the pixels
					Bitfield2RGB(buff32,0,0,0,32);
					free(buff32);
				} else throw "can't allocate memory";
			} else throw "unknown compression";
			break;
		case 24 :
			if (bf.bfOffBits != 0L) hFile->Seek(off + bf.bfOffBits,SEEK_SET);
			if (dwCompression == BI_RGB){
				hFile->Read(info.pImage, head.biSizeImage,1); // read in the pixels
			} else throw "unknown compression";
			break;
		case 16 :
		{
			DWORD bfmask[3];
			if (dwCompression == BI_BITFIELDS)
			{
				hFile->Read(bfmask, 12, 1);
			} else {
//				bfmask[0]=0xF800; bfmask[1]=0x7E0; bfmask[2]=0x1F; //RGB565
				// bhlee
				bfmask[0]=RGBmask[0]<<11; 
				bfmask[1]=RGBmask[1]<<5;
				bfmask[2]=RGBmask[2]<<0;
			}
			// bf.bfOffBits required after the bitfield mask <Cui Ying Jie>
			if (bf.bfOffBits != 0L) hFile->Seek(off + bf.bfOffBits,SEEK_SET);
			// read in the pixels
			hFile->Read(info.pImage, head.biHeight*((head.biWidth+1)/2)*4,1);
			// transform into RGB
			Bitfield2RGB(info.pImage,(WORD)bfmask[0],(WORD)bfmask[1],(WORD)bfmask[2],16);
			break;
		}
		case 8 :
		case 4 :
		case 1 :
		if (bf.bfOffBits != 0L) hFile->Seek(off + bf.bfOffBits,SEEK_SET);
		switch (dwCompression) {
			case BI_RGB :
				hFile->Read(info.pImage, head.biSizeImage,1); // read in the pixels
				break;
			case BI_RLE4 :
			{
				unsigned char status_byte = 0;
				unsigned char second_byte = 0;
				int scanline = 0;
				int bits = 0;
				BOOL low_nibble = FALSE;
				CImageIterator iter(this);

				for (BOOL bContinue = TRUE; bContinue;) {
					hFile->Read(&status_byte, sizeof(unsigned char), 1);
					switch (status_byte) {
						case RLE_COMMAND :
							hFile->Read(&status_byte, sizeof(unsigned char), 1);
							switch (status_byte) {
								case RLE_ENDOFLINE :
									bits = 0;
									scanline++;
									low_nibble = FALSE;
									break;
								case RLE_ENDOFBITMAP :
									bContinue=FALSE;
									break;
								case RLE_DELTA :
								{
									// read the delta values
									unsigned char delta_x;
									unsigned char delta_y;
									hFile->Read(&delta_x, sizeof(unsigned char), 1);
									hFile->Read(&delta_y, sizeof(unsigned char), 1);
									// apply them
									bits       += delta_x / 2;
									scanline   += delta_y;
									break;
								}
								default :
									hFile->Read(&second_byte, sizeof(unsigned char), 1);
									unsigned char *sline = iter.GetRow(scanline);
									for (int i = 0; i < status_byte; i++) {
										if (low_nibble) {
											if ((DWORD)(sline+bits) < (DWORD)(info.pImage+head.biSizeImage)){
												*(sline + bits) |=  (second_byte & 0x0F);
											}
											if (i != status_byte - 1)
												hFile->Read(&second_byte, sizeof(unsigned char), 1);
											bits++;
										} else {
											if ((DWORD)(sline+bits) < (DWORD)(info.pImage+head.biSizeImage)){
												*(sline + bits) = (unsigned char)(second_byte & 0xF0);
											}
										}
										low_nibble = !low_nibble;
									}
									if ((((status_byte+1) >> 1) & 1 )== 1)
										hFile->Read(&second_byte, sizeof(unsigned char), 1);												
									break;
							};
							break;
						default :
						{
							unsigned char *sline = iter.GetRow(scanline);
							hFile->Read(&second_byte, sizeof(unsigned char), 1);
							for (unsigned i = 0; i < status_byte; i++) {
								if (low_nibble) {
									if ((DWORD)(sline+bits) < (DWORD)(info.pImage+head.biSizeImage)){
										*(sline + bits) |= (second_byte & 0x0F);
									}
									bits++;
								} else {
									if ((DWORD)(sline+bits) < (DWORD)(info.pImage+head.biSizeImage)){
										*(sline + bits) = (unsigned char)(second_byte & 0xF0);
									}
								}				
								low_nibble = !low_nibble;
							}
						}
						break;
					};
				}
				break;
			}
			case BI_RLE8 :
			{
				unsigned char status_byte = 0;
				unsigned char second_byte = 0;
				int scanline = 0;
				int bits = 0;
				CImageIterator iter(this);

				for (BOOL bContinue = TRUE; bContinue; ) {
					hFile->Read(&status_byte, sizeof(unsigned char), 1);
					switch (status_byte) {
						case RLE_COMMAND :
							hFile->Read(&status_byte, sizeof(unsigned char), 1);
							switch (status_byte) {
								case RLE_ENDOFLINE :
									bits = 0;
									scanline++;
									break;
								case RLE_ENDOFBITMAP :
									bContinue=FALSE;
									break;
								case RLE_DELTA :
								{
									// read the delta values
									unsigned char delta_x;
									unsigned char delta_y;
									hFile->Read(&delta_x, sizeof(unsigned char), 1);
									hFile->Read(&delta_y, sizeof(unsigned char), 1);
									// apply them
									bits     += delta_x;
									scanline += delta_y;
									break;
								}
								default :
									hFile->Read((void *)(iter.GetRow(scanline) + bits), sizeof(unsigned char) * status_byte, 1);
									// align run length to even number of bytes 
									if ((status_byte & 1) == 1)
										hFile->Read(&second_byte, sizeof(unsigned char), 1);												
									bits += status_byte;													
									break;								
							};
							break;
						default :
							unsigned char *sline = iter.GetRow(scanline);
							hFile->Read(&second_byte, sizeof(unsigned char), 1);
							for (unsigned i = 0; i < status_byte; i++) {
								if ((DWORD)bits<info.dwEffWidth){
									*(sline + bits) = second_byte;
									bits++;					
								} else {
									bContinue = FALSE;
									break;
								}
							}
							break;
					};
				}
				break;
			}
			default :								
				throw "compression type not supported";
		}
	}

  } catch (char *message) {
	strncpy(info.szLastError,message,255);
	if (info.nEscape==-1) return true;
	return false;
  }
    return true;
}


void CxImageRAW::YUV422_Convert(unsigned char *yuv,BITMAP4 *rgb1,BITMAP4 *rgb2)
{
   int y1,y2,u,v;

   // Extract yuv components
   u  = yuv[0];
   y1 = yuv[1];
   v  = yuv[2];
   y2 = yuv[3];

   // yuv to rgb
   *rgb1 = YUV422_to_Bitmap(y1,u,v);
   *rgb2 = YUV422_to_Bitmap(y2,u,v);
}



BITMAP4 CxImageRAW::YUV422_to_Bitmap(int y,int u,int v)

{
   int r,g,b;
   BITMAP4 bm = {0,0,0,0};
   
   // u and v are +-0.5
   u -= 128;
   v -= 128;

   // Conversion
   r = (int)(y + 1.370705 * v);
   g = (int)(y - 0.698001 * v - 0.337633 * u);
   b = (int)(y + 1.732446 * u);

   // Clamp to 0..1
   if (r < 0) r = 0;
   if (g < 0) g = 0;
   if (b < 0) b = 0;
   if (r > 255) r = 255;
   if (g > 255) g = 255;
   if (b > 255) b = 255;

   bm.r = b;
   bm.g = g;
   bm.b = r;
   bm.a = 0;

   return(bm);
}


#endif //CXIMAGE_SUPPORT_RAW










