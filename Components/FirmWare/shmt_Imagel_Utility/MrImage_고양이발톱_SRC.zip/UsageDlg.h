#pragma once


// CUsageDlg dialog

class CUsageDlg : public CDialog
{
	DECLARE_DYNAMIC(CUsageDlg)

public:
	CUsageDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CUsageDlg();

// Dialog Data
	enum { IDD = IDD_DIALOG_USAGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};
