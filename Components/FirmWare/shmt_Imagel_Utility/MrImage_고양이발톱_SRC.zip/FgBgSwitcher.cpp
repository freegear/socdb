/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "FgBgSwitcher.h"
#include "resource.h"

namespace MrImage
{
//---------------------------------------------------------------
IMPLEMENT_DYNAMIC(CFgBgSwitcher, CWnd)


//---------------------------------------------------------------
CFgBgSwitcher::CFgBgSwitcher()
:m_foreColor(RGB(0,0,0))
,m_backColor(RGB(255,255,255))
,m_rcSwap(0,0,0,0)
,m_bVerticalDisplay(TRUE)
{
}

//---------------------------------------------------------------
CFgBgSwitcher::~CFgBgSwitcher()
{
}

//---------------------------------------------------------------
BEGIN_MESSAGE_MAP(CFgBgSwitcher, CWnd)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
END_MESSAGE_MAP()

//---------------------------------------------------------------
int CFgBgSwitcher::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	return 0;
}

//---------------------------------------------------------------
void CFgBgSwitcher::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	CRect rcClient;
	GetClientRect(rcClient);

	//paint the background
	CBrush brBack(GetSysColor(COLOR_BTNFACE));
	dc.FillRect(rcClient, &brBack);
	
	//this is the rectangle that contains both the 
	//foreground and background color well
	CRect rcFgBg;

	if (m_bVerticalDisplay)
	{
		rcFgBg = CRect(CPoint(0,0), CSize(rcClient.Width(),rcClient.Width()));
	}
	else
	{
		rcFgBg = CRect(CPoint(0,0), CSize(rcClient.Height(),rcClient.Height()));
		
		//leave room for swap button
		rcFgBg.bottom -= 20;
	}

	CPoint ptFgBgCenter = rcFgBg.CenterPoint();

	const int offset = 4;

	//Draw the background rectangle
	CRect rcBg(rcFgBg);
	rcBg.left = ptFgBgCenter.x;
	rcBg.top = ptFgBgCenter.y;
	rcBg.OffsetRect(-offset, -offset);
	dc.Rectangle(rcBg);
	dc.FillRect(&rcBg, &CBrush(m_backColor));
	dc.DrawEdge(rcBg, EDGE_SUNKEN, BF_RECT);
	
	//Draw the foreground rectangle
	CRect rcFg(rcFgBg);
	rcFg.right = ptFgBgCenter.x;
	rcFg.bottom = ptFgBgCenter.y;
	rcFg.OffsetRect(offset, offset);
	dc.Rectangle(rcFg);
	dc.FillRect(&rcFg, &CBrush(m_foreColor));
	dc.DrawEdge(rcFg, EDGE_SUNKEN, BF_RECT);
	
	//Draw the swap button
	m_rcSwap.left = rcFg.left;
	m_rcSwap.top = rcBg.bottom + offset;
	m_rcSwap.right = rcBg.right;
	m_rcSwap.left += offset;
	m_rcSwap.right -= offset;
	CString str;
	VERIFY(str.LoadString(IDS_SWAP));
	CFont fnt;
	fnt.CreateStockObject(DEFAULT_GUI_FONT);
	CFont * pOldFont = dc.SelectObject(&fnt);
	CSize sz = dc.GetTextExtent(str);
	m_rcSwap.bottom = m_rcSwap.top + sz.cy + offset;
	int prevMode = dc.SetBkMode(TRANSPARENT);
	dc.DrawText(str, &m_rcSwap,DT_END_ELLIPSIS | DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	dc.FrameRect(&m_rcSwap, &CBrush(GetSysColor(COLOR_3DDKSHADOW)));

	//Draw the color information
	CRect rcColorInfo(m_rcSwap);

	str.Format(IDS_COLORPROP_FORMAT,GetRValue(m_foreColor), GetGValue(m_foreColor), GetBValue(m_foreColor));

	UINT uFlags = DT_END_ELLIPSIS;

	if (m_bVerticalDisplay)
	{
		rcColorInfo.top += m_rcSwap.Height() + 8;
		rcColorInfo.bottom = rcClient.bottom;
		uFlags |= DT_LEFT;
	}
	else
	{
		rcColorInfo = rcClient;
		rcColorInfo.left = rcBg.right + (2 * offset);
		str = _T("\r") + str;
	}

	dc.DrawText(str, &rcColorInfo, uFlags);
	dc.SetBkMode(prevMode);
	dc.SelectObject(pOldFont);

	// Draw raised window edge
	GetClientRect(rcClient);
	dc.DrawEdge(rcClient, EDGE_SUNKEN, BF_RECT);

}

//---------------------------------------------------------------
void CFgBgSwitcher::OnLButtonDown(UINT nFlags, CPoint point)
{
	if (m_rcSwap.PtInRect(point))
	{
		Swap();
	}
	CWnd::OnLButtonDown(nFlags, point);
}

//---------------------------------------------------------------
void CFgBgSwitcher::OnRButtonDown(UINT nFlags, CPoint point)
{
	CWnd::OnRButtonDown(nFlags, point);
}

//---------------------------------------------------------------
void CFgBgSwitcher::Swap()
{
	COLORREF temp = m_foreColor;
	m_foreColor = m_backColor;
	m_backColor = temp;
	Invalidate(); 
	CWnd * pOwner = GetOwner();
	if (pOwner)
	{
		VERIFY(pOwner->PostMessage (CFgBgSwitcher::GetSwapMsgID()));
	}
}

//---------------------------------------------------------------
UINT CFgBgSwitcher::GetSwapMsgID()
{
	return RegisterWindowMessage(_T("FGBGSWITCHER_SWAP_MSGID"));
}

//---------------------------------------------------------------
//---------------------------------------------------------------

}//end namespace