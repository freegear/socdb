/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/
#ifndef FGBGSWITCHER_H
#define FGBGSWITCHER_H
#pragma once

namespace MrImage
{
class CFgBgSwitcher 
: public CWnd
{
	DECLARE_DYNAMIC(CFgBgSwitcher)

public:
	CFgBgSwitcher();
	virtual ~CFgBgSwitcher();

	COLORREF GetForegroundColor()const { return m_foreColor; }
	COLORREF GetBackgroundColor()const { return m_backColor; }
	void SetForegroundColor(const COLORREF & color){ m_foreColor = color; Invalidate(); }
	void SetBackgroundColor(const COLORREF & color){ m_backColor = color; Invalidate(); }
	void Swap();
	void DisplayVertically(BOOL bEnabled){ m_bVerticalDisplay = bEnabled; Invalidate(); }
	BOOL IsDisplayedVertically()const { return m_bVerticalDisplay;	}

	//This retrieves the id of the registered window message
	//for when the user swaps the foreground/background color.
	//Parent/Owner should handle this message with an ON_REGISTERED_MESSAGE message map entry.
	//When handling the message:
	//The WPARAM should be ignored.
	//The LPARAM should be ignored.
	static UINT GetSwapMsgID();

protected:
	DECLARE_MESSAGE_MAP()

	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);

private:
	COLORREF m_foreColor;
	COLORREF m_backColor;
	CRect m_rcSwap;
	BOOL m_bVerticalDisplay;
};

}//end namespace

#endif FGBGSWITCHER_H