/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#ifndef WINDOWSDLG_H
#define WINDOWSDLG_H

#pragma once

namespace MrImage
{

class CWindowsDlg
: public CDialog
{
public:

	explicit CWindowsDlg(CWnd* pParent = NULL);
	virtual BOOL OnInitDialog();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);

	afx_msg void OnBtnActivateWindow();
	afx_msg void OnBtnSave();
	afx_msg void OnBtnCloseWindows();
	afx_msg void OnSelChangeListWindows();

private:
	enum { IDD = IDD_WINDOWSDLG };
	CListBox m_lstWindows;

	DECLARE_MESSAGE_MAP()
};

}//end namespace

#endif WINDOWSDLG_H
