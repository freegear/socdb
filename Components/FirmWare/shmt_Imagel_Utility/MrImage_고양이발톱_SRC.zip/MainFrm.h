/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "ColorPickerBar.h"
#include "FontFormatBar.h"

#pragma once

namespace MrImage
{

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();
	virtual ~CMainFrame();

	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CString GetSelectedFontName()const { return m_wndFontFormatBar.GetSelectedFontName(); }
	int GetSelectedFontPointSize()const { return m_wndFontFormatBar.GetSelectedFontPointSize(); }
	BOOL IsSelectedFontBold()const { return m_wndFontFormatBar.IsBoldEnabled(); }
	BOOL IsSelectedFontItalicized()const { return m_wndFontFormatBar.IsItalicsEnabled(); }
	BOOL IsSelectedFontUnderlined()const { return m_wndFontFormatBar.IsUnderlineEnabled(); }

	COLORREF GetForegroundColor()const { return m_wndColorPickerBar.GetForegroundColor(); }
	COLORREF GetBackgroundColor()const { return m_wndColorPickerBar.GetBackgroundColor(); }

protected: 
	CStatusBar  m_wndStatusBar;
	CToolBar m_wndToolBar;
	CToolBar m_wndStdDrawToolBar;
	CToolBar m_wndTransformFilterToolBar;
	CToolBar m_wndNudgeSelectionToolBar;

	CColorPickerBar	m_wndColorPickerBar;
	CFontFormatBar m_wndFontFormatBar;

protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg LRESULT OnDropperSelectedColor(WPARAM wMouseBtn, LPARAM lColor);
	afx_msg LRESULT OnCursorPositionChanged(WPARAM wUnused, LPARAM lCursorPos);
	afx_msg void OnEditPasteAsNewImage();
	afx_msg void OnUpdateEditPasteAsNewImage(CCmdUI *pCmdUI);
	afx_msg void OnEditOptions();
	afx_msg void OnDropFiles( HDROP );
	afx_msg void OnWindows();
	afx_msg void OnOpenBinToHex();

	BOOL VerifyBarState(LPCTSTR lpszProfileName);

	DECLARE_MESSAGE_MAP()
};

}//end namespace
