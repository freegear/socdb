/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "ColorPicker.h"
#include "MrImageDoc.h"
#include "resource.h"
#include "OptionsDlg.h"

namespace MrImage
{

const int DEFAULT_CELL_WIDTH = 8;
const int DEFAULT_CELL_HEIGHT = 8;
const int BORDER_OFFSET = 8;
const int NUMBER_CUSTOM_COLORS = 16;
//---------------------------------------------------------------

IMPLEMENT_DYNAMIC(CColorPicker, CWnd)


//---------------------------------------------------------------
CColorPicker::CColorPicker()
:m_colors()
,m_colorType(COMMON_COLORS)
,m_ptSelected(-1, -1)
,m_colorSelected(RGB(0,0,0))
,m_pActiveImage(NULL)
,m_unTimerID(0)
,m_CellSize(DEFAULT_CELL_WIDTH, DEFAULT_CELL_HEIGHT)
,m_customcolors(NUMBER_CUSTOM_COLORS,RGB(255,255,255))
{
	m_colors.reserve(32000);
	COptionsDlg options;
	UINT unWidthHeight = options.GetColorWidthHeight();
	m_CellSize = CSize(unWidthHeight,unWidthHeight);
}

//---------------------------------------------------------------
CColorPicker::~CColorPicker()
{
}

//---------------------------------------------------------------
BEGIN_MESSAGE_MAP(CColorPicker, CWnd)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_TIMER()
	ON_WM_DESTROY()
END_MESSAGE_MAP()

//---------------------------------------------------------------
CMrImageDoc * GetActiveImage()
{
	CMDIFrameWnd * pFrame = (CMDIFrameWnd*)AfxGetMainWnd();
	if (pFrame)
	{
		CMDIChildWnd *pChild = pFrame->MDIGetActive();
		if (pChild)
		{
			CDocument * pDoc = pChild->GetActiveDocument();
			if (pDoc && pDoc->IsKindOf(RUNTIME_CLASS(CMrImageDoc)))
			{
				return (CMrImageDoc*)pDoc;
			}
		}
	}
	return NULL;
}

//---------------------------------------------------------------
void CColorPicker::LoadColors()
{
	m_colors.clear();
	m_ptSelected = CPoint(-1, -1);

	switch(m_colorType)
	{
		case COMMON_COLORS:
		{
			m_colors.push_back(RGB(255,255,255));
			m_colors.push_back(RGB(224, 224, 224));
			m_colors.push_back(RGB(192, 192, 192));
			m_colors.push_back(RGB(128, 128, 128));
			m_colors.push_back(RGB(64,64,64));
			m_colors.push_back(RGB(0, 0, 0));
			m_colors.push_back(RGB(255,192,192));
			m_colors.push_back(RGB(255, 128, 128));
			m_colors.push_back(RGB(255, 0, 0));
			m_colors.push_back(RGB(192, 0, 0));
			m_colors.push_back(RGB(128,0, 0));
			m_colors.push_back(RGB(64, 0, 0));
			m_colors.push_back(RGB(255,224, 192));
			m_colors.push_back(RGB(255, 224, 128));
			m_colors.push_back(RGB(255, 192, 0));
			m_colors.push_back(RGB(255, 128, 0));
			m_colors.push_back(RGB(128, 64, 0));
			m_colors.push_back(RGB(128, 64, 64));
			m_colors.push_back(RGB(255,255, 192));
			m_colors.push_back(RGB(255, 255, 128));
			m_colors.push_back(RGB(255, 255, 0));
			m_colors.push_back(RGB(192, 192, 0));
			m_colors.push_back(RGB(128,128, 0));
			m_colors.push_back(RGB(64, 64, 0));
			m_colors.push_back(RGB(192,255, 192));
			m_colors.push_back(RGB(128, 255, 128));
			m_colors.push_back(RGB(0, 255, 0));
			m_colors.push_back(RGB(0, 192, 0));
			m_colors.push_back(RGB(0, 128, 0));
			m_colors.push_back(RGB(0, 64, 0));
			m_colors.push_back(RGB(192,255,255));
			m_colors.push_back(RGB(128, 255, 255));
			m_colors.push_back(RGB(0, 255, 255));
			m_colors.push_back(RGB(0, 192, 192));
			m_colors.push_back(RGB(0,128,128));
			m_colors.push_back(RGB(0, 64, 64));
			m_colors.push_back(RGB(192,192,255));
			m_colors.push_back(RGB(128, 128, 255));
			m_colors.push_back(RGB(0, 0, 255));
			m_colors.push_back(RGB(0, 0, 192));
			m_colors.push_back(RGB(0,0,128));
			m_colors.push_back(RGB(0, 0, 64));
			m_colors.push_back(RGB(255,192,255));
			m_colors.push_back(RGB(255, 128, 255));
			m_colors.push_back(RGB(255, 0, 255));
			m_colors.push_back(RGB(192, 0, 192));
			m_colors.push_back(RGB(128,0,128));
			m_colors.push_back(RGB(64, 0, 64));
			TRACE(_T("%d common colors\n"), m_colors.size());
		}
		break;
		case SYSTEM_COLORS:
		{
			COLORREF clr = GetSysColor(COLOR_SCROLLBAR);
			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_BACKGROUND);
			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_ACTIVECAPTION);
			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_INACTIVECAPTION);
			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_MENU);              
			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_WINDOW);
			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_WINDOWFRAME);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_MENUTEXT);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_WINDOWTEXT);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_CAPTIONTEXT);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_ACTIVEBORDER);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_INACTIVEBORDER);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_APPWORKSPACE);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_HIGHLIGHT);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_HIGHLIGHTTEXT);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_BTNFACE);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_BTNSHADOW);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_GRAYTEXT);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_BTNTEXT);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_INACTIVECAPTIONTEXT);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_BTNHIGHLIGHT);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_3DDKSHADOW);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_3DLIGHT);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_INFOTEXT);
			m_colors.push_back(clr);
			
			clr = GetSysColor(COLOR_INFOBK);
			m_colors.push_back(clr);
			
//			clr = GetSysColor(COLOR_HOTLIGHT);
//			m_colors.push_back(clr);

//			clr = GetSysColor(COLOR_GRADIENTACTIVECAPTION);
//			m_colors.push_back(clr);

//			clr = GetSysColor(COLOR_GRADIENTINACTIVECAPTION);
//			m_colors.push_back(clr);

//			clr = GetSysColor(COLOR_MENUHILIGHT);
//			m_colors.push_back(clr);

//			clr = GetSysColor(COLOR_MENUBAR);
//			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_DESKTOP);
			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_3DFACE);
			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_3DSHADOW);
			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_3DHIGHLIGHT);
			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_3DHILIGHT);
			m_colors.push_back(clr);

			clr = GetSysColor(COLOR_BTNHILIGHT);
			m_colors.push_back(clr);

			TRACE(_T("%d system colors\n"), m_colors.size());
		}
		break;
		case WEB_COLORS:
			m_colors.push_back(RGB(0,0,0));
			m_colors.push_back(RGB(105, 105, 105));
			m_colors.push_back(RGB(200, 200, 200));
			m_colors.push_back(RGB(169, 169, 169));
			m_colors.push_back(RGB(192, 192, 192));
			m_colors.push_back(RGB(211, 211, 211));
			m_colors.push_back(RGB(220, 220, 220));
			m_colors.push_back(RGB(245, 245, 245));
			m_colors.push_back(RGB(255, 255, 255));
			m_colors.push_back(RGB(188, 143, 143));
			m_colors.push_back(RGB(205, 92, 92));
			m_colors.push_back(RGB(165, 42, 42));
			m_colors.push_back(RGB(178, 34, 34));
			m_colors.push_back(RGB(240, 128, 128));
			m_colors.push_back(RGB(128, 0, 0));
			m_colors.push_back(RGB(139, 0, 0));
			m_colors.push_back(RGB(255, 0, 0));
			m_colors.push_back(RGB(255, 250, 250));
			m_colors.push_back(RGB(255, 228, 225));
			m_colors.push_back(RGB(250, 128, 114));
			m_colors.push_back(RGB(255, 99, 71));
			m_colors.push_back(RGB(233, 150, 122));
			m_colors.push_back(RGB(255, 127, 80));
			m_colors.push_back(RGB(255, 69, 0));
			m_colors.push_back(RGB(255, 160, 122));
			m_colors.push_back(RGB(160, 82, 45));
			m_colors.push_back(RGB(255, 245, 238));
			m_colors.push_back(RGB(210,105,30));
			m_colors.push_back(RGB(139,69,19));
			m_colors.push_back(RGB(244,164,96));
			m_colors.push_back(RGB(255,218,185));
			m_colors.push_back(RGB(205,133,63));
			m_colors.push_back(RGB(250,240,230));
			m_colors.push_back(RGB(255,228,196));
			m_colors.push_back(RGB(255,140,0));
			m_colors.push_back(RGB(222,184,135));
			m_colors.push_back(RGB(210,180,140));
			m_colors.push_back(RGB(250,235,215));
			m_colors.push_back(RGB(255,222,173));
			m_colors.push_back(RGB(255,235,205));
			m_colors.push_back(RGB(255,239,213));
			m_colors.push_back(RGB(255,228,181));
			m_colors.push_back(RGB(255,165,0));
			m_colors.push_back(RGB(245,222,179));
			m_colors.push_back(RGB(253,245,230));
			m_colors.push_back(RGB(255,250,240));
			m_colors.push_back(RGB(184,134,11));
			m_colors.push_back(RGB(218,165,32));
			m_colors.push_back(RGB(255,248,220));
			m_colors.push_back(RGB(255,215,0));
			m_colors.push_back(RGB(240,230,140));
			m_colors.push_back(RGB(255,250,205));
			m_colors.push_back(RGB(238,232,170));
			m_colors.push_back(RGB(189,183,107));
			m_colors.push_back(RGB(245,245,220));
			m_colors.push_back(RGB(250,250,210));
			m_colors.push_back(RGB(128,128,0));
			m_colors.push_back(RGB(255,255,0));
			m_colors.push_back(RGB(255,255,224));
			m_colors.push_back(RGB(255,255,240));
			m_colors.push_back(RGB(107,142,35));
			m_colors.push_back(RGB(154,205,50));
			m_colors.push_back(RGB(85,107,47));
			m_colors.push_back(RGB(173,255,47));
			m_colors.push_back(RGB(127,255,0));
			m_colors.push_back(RGB(124,252,0));
			m_colors.push_back(RGB(143,188,143));
			m_colors.push_back(RGB(34,139,34));
			m_colors.push_back(RGB(50,205,50));
			m_colors.push_back(RGB(144,238,144));
			m_colors.push_back(RGB(152,251,152));
			m_colors.push_back(RGB(0,100,0));
			m_colors.push_back(RGB(0,128,0));
			m_colors.push_back(RGB(0,255,0));
			m_colors.push_back(RGB(240,255,240));
			m_colors.push_back(RGB(46,139,87));
			m_colors.push_back(RGB(60,179,113));
			m_colors.push_back(RGB(0,255,127));
			m_colors.push_back(RGB(245,255,250));
			m_colors.push_back(RGB(0,250,154));
			m_colors.push_back(RGB(102,205,170));
			m_colors.push_back(RGB(127,255,212));
			m_colors.push_back(RGB(64,224,208));
			m_colors.push_back(RGB(32,178,170));
			m_colors.push_back(RGB(72,209,204));
			m_colors.push_back(RGB(47,79,79));
			m_colors.push_back(RGB(175,238,238));
			m_colors.push_back(RGB(0,128,128));
			m_colors.push_back(RGB(0,139,139));
			m_colors.push_back(RGB(0,255,255));
			m_colors.push_back(RGB(0,255,255));
			m_colors.push_back(RGB(224,255,255));
			m_colors.push_back(RGB(240,255,255));
			m_colors.push_back(RGB(0,206,209));
			m_colors.push_back(RGB(95,158,160));
			m_colors.push_back(RGB(176,224,230));
			m_colors.push_back(RGB(173,216,230));
			m_colors.push_back(RGB(0,191,255));
			m_colors.push_back(RGB(135,206,235));
			m_colors.push_back(RGB(135,206,250));
			m_colors.push_back(RGB(70,130,180));
			m_colors.push_back(RGB(240,248,255));
			m_colors.push_back(RGB(30,144,255));
			m_colors.push_back(RGB(112,128,144));
			m_colors.push_back(RGB(119,136,153));
			m_colors.push_back(RGB(176,196,222));
			m_colors.push_back(RGB(100,149,237));
			m_colors.push_back(RGB(65,105,225));
			m_colors.push_back(RGB(25,25,112));
			m_colors.push_back(RGB(230,230,250));
			m_colors.push_back(RGB(0,0,128));
			m_colors.push_back(RGB(0,0,139));
			m_colors.push_back(RGB(0,0,205));
			m_colors.push_back(RGB(0,0,255));
			m_colors.push_back(RGB(248,248,255));
			m_colors.push_back(RGB(106,90,205));
			m_colors.push_back(RGB(72,61,139));
			m_colors.push_back(RGB(0,0,205));
			m_colors.push_back(RGB(123,104,238));
			m_colors.push_back(RGB(147,112,219));
			m_colors.push_back(RGB(138,43,226));
			m_colors.push_back(RGB(75,0,130));
			m_colors.push_back(RGB(153,50,204));
			m_colors.push_back(RGB(148,0,211));
			m_colors.push_back(RGB(186,85,211));
			m_colors.push_back(RGB(216,191,216));
			m_colors.push_back(RGB(221,160,221));
			m_colors.push_back(RGB(238,130,238));
			m_colors.push_back(RGB(128,0,128));
			m_colors.push_back(RGB(139,0,139));
			m_colors.push_back(RGB(255,0,255));
			m_colors.push_back(RGB(255,0,255));
			m_colors.push_back(RGB(218,112,214));
			m_colors.push_back(RGB(199,21,133));
			m_colors.push_back(RGB(255,20,147));
			m_colors.push_back(RGB(255,105,180));
			m_colors.push_back(RGB(255,240,245));
			m_colors.push_back(RGB(218,112,214));
			m_colors.push_back(RGB(220,20,60));
			m_colors.push_back(RGB(255,192,203));
			m_colors.push_back(RGB(255,182,193));
			TRACE(_T("%d web colors\n"), m_colors.size());
		break;

		case IMAGE_COLORS:
		{
			if (0 == m_unTimerID)
			{
				m_unTimerID = (UINT)SetTimer(42, 1000, NULL);
			}

			//load the colors within the active image into m_colors
			m_pActiveImage = GetActiveImage();
			if (m_pActiveImage)
			{
				VERIFY(m_pActiveImage->GetQuantizedPalette(m_colors));
			}
		}
		break;

		default:
			;//unknown
	}//end switch

	//now add-in the custom colors
	for (int i = 0; i < NUMBER_CUSTOM_COLORS; ++i)
	{
		m_colors.push_back(m_customcolors[i]);
	}

	Invalidate();
}

//---------------------------------------------------------------
int CColorPicker::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	LoadColors();

	return 0;
}

//---------------------------------------------------------------
void CColorPicker::OnDestroy()
{
	if (m_unTimerID)
	{
		VERIFY(KillTimer(m_unTimerID));
		m_unTimerID = 0;
	}
	CWnd::OnDestroy();
}

//---------------------------------------------------------------
CSize CColorPicker::CalcCellMax(const CRect & rcClient)
{
	CSize m;
	m.cx = rcClient.Width();
	m.cx -= (m.cx % m_CellSize.cx);
	m.cx -= BORDER_OFFSET;

	m.cy = rcClient.Height();
	m.cy -= (m.cy % m_CellSize.cy);
	m.cy -= BORDER_OFFSET;

	return m;
}

//---------------------------------------------------------------
void CColorPicker::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	CRect rcClient;
	GetClientRect(rcClient);

	CBrush brBack(GetSysColor(COLOR_BTNFACE));
	dc.FillRect(rcClient, &brBack);

	//calculate how many cells we can fit in client area
	CSize max_cell;
	max_cell = CalcCellMax(rcClient);

	//draw vertical lines
	for (int x = BORDER_OFFSET; x <= max_cell.cx; x += m_CellSize.cx)
	{
		dc.MoveTo(x, BORDER_OFFSET);
		dc.LineTo(x, max_cell.cy);
	}

	//draw horizontal lines
	for (int y = BORDER_OFFSET; y <= max_cell.cy; y += m_CellSize.cy)
	{
		dc.MoveTo(BORDER_OFFSET,y);
		dc.LineTo(max_cell.cx, y);
	}

	CRect rcFill;
	std::vector<COLORREF>::iterator it = m_colors.begin();
	std::vector<COLORREF>::iterator end = m_colors.end();

	for (y = BORDER_OFFSET; y < max_cell.cy && it != end; y+= m_CellSize.cy)
	{
		for ( x = BORDER_OFFSET; x < max_cell.cx && it != end; x += m_CellSize.cx)
		{
			rcFill.left = x;
			rcFill.top = y;
			rcFill.right = rcFill.left + m_CellSize.cx;
			rcFill.bottom = rcFill.top + m_CellSize.cy;
			rcFill.DeflateRect(1,1,0,0);

			dc.FillRect(rcFill, &CBrush(*it));

			if (rcFill.PtInRect(m_ptSelected))
			{
				dc.DrawFocusRect(&rcFill);
				m_colorSelected = *it;
			}

			++it;
		}//end for
	}//end for

	// Draw raised window edge
	dc.DrawEdge(rcClient, EDGE_SUNKEN, BF_RECT);
}

//---------------------------------------------------------------
void CColorPicker::SetColorType(COLOR_TYPE type)
{
	if (type != m_colorType)
	{
		m_colorType = type;
		LoadColors();
		Invalidate();
	}
}

//---------------------------------------------------------------
void CColorPicker::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	//allow the user to specify a custom color

	CColorDialog dlg(m_colorSelected,CC_FULLOPEN,this);

	COLORREF* pCustomColors = dlg.GetSavedCustomColors();
	if (pCustomColors)
	{
		//initialize w/ previous custom colors
		for (int i = 0; i < NUMBER_CUSTOM_COLORS; i++)
		{
			pCustomColors[i] = m_customcolors[i];
		}
	}

	if (IDOK == dlg.DoModal())
	{
		//load the newly defined custom colors
		pCustomColors = dlg.GetSavedCustomColors();
		if (pCustomColors)
		{
			m_customcolors.clear();

			COLORREF color;

			for (int i = 0; i < NUMBER_CUSTOM_COLORS; i++)
			{
				color = pCustomColors[i];

				m_customcolors.push_back(color);

				TRACE("RGB value of the selected color - red = %u, green = %u, blue = %u\n",GetRValue(color), GetGValue(color), GetBValue(color));
			}

			LoadColors();
		}
	}
}

//---------------------------------------------------------------
void CColorPicker::OnLButtonDown(UINT nFlags, CPoint point)
{
	m_ptSelected = point;

	//we call OnPaint here so that it will
	//set the selected color
	OnPaint();
	
	CWnd * pOwner = GetOwner();
	if (pOwner)
	{
		VERIFY(pOwner->PostMessage (CColorPicker::GetSelectionChangeMsgID(), (WPARAM)0,(LPARAM)0));
	}

	Invalidate();

	CWnd::OnLButtonDown(nFlags, point);
}

//---------------------------------------------------------------
void CColorPicker::OnRButtonDown(UINT nFlags, CPoint point)
{
	m_ptSelected = point;

	//we call OnPaint here so that it will
	//set the selected color
	OnPaint();

	CWnd * pOwner = GetOwner();
	if (pOwner)
	{
		VERIFY(pOwner->PostMessage (CColorPicker::GetSelectionChangeMsgID(), (WPARAM)0,(LPARAM)1));
	}

	Invalidate();

	CWnd::OnRButtonDown(nFlags, point);
}

//---------------------------------------------------------------
UINT CColorPicker::GetSelectionChangeMsgID()
{
	return RegisterWindowMessage(_T("COLORPICKER_SELECTIONCHANGED_MSGID"));
}

//---------------------------------------------------------------
void CColorPicker::OnTimer(UINT nIDEvent)
{
	if (m_unTimerID == nIDEvent)
	{
		if (IMAGE_COLORS == m_colorType)
		{
			CMrImageDoc * pActive = GetActiveImage();
			if (pActive)
			{
				if (m_pActiveImage != pActive)
				{
					LoadColors();
				}
			}
		}
		else
		{
			VERIFY(KillTimer(m_unTimerID));
			m_unTimerID = 0;
		}
	}

	CWnd::OnTimer(nIDEvent);
}

//---------------------------------------------------------------
void CColorPicker::SetColorSize(const CSize & size)
{ 
	const int CELL_SIZE_DELTA = 4;
	const int SMALLEST_CELL_SIZE = 4;
	const int LARGEST_CELL_SIZE = 52;

	m_CellSize.cx = max(SMALLEST_CELL_SIZE, size.cx);
	m_CellSize.cy = max(SMALLEST_CELL_SIZE, size.cy);
	m_CellSize.cx = min(LARGEST_CELL_SIZE, size.cx);
	m_CellSize.cy = min(LARGEST_CELL_SIZE, size.cy);

	Invalidate();
}

//---------------------------------------------------------------
}//end namespace

