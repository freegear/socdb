/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#pragma once

namespace MrImage
{

class CSkewDlg : public CDialog
{
	DECLARE_DYNAMIC(CSkewDlg)
public:
	explicit CSkewDlg(CWnd* pParent = NULL);
	virtual ~CSkewDlg();

	enum { IDD = IDD_SKEW };

	void SetImageSize(const CSize & size){ m_size = size; }

	CPoint GetPivot()const { return CPoint(m_pivotx, m_pivoty); }
	float GetHorizSkew()const;
	float GetVertSkew()const;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

private:
	long	m_pivotx;
	long	m_pivoty;
	float	m_skewx;
	float	m_skewy;
	CSize   m_size;
};

}//end namespace