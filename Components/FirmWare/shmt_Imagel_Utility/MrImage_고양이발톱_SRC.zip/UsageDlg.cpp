// UsageDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MrImage.h"
#include "resource.h"
#include "UsageDlg.h"
#include ".\usagedlg.h"


// CUsageDlg dialog

IMPLEMENT_DYNAMIC(CUsageDlg, CDialog)
CUsageDlg::CUsageDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUsageDlg::IDD, pParent)
{
}

CUsageDlg::~CUsageDlg()
{
}

void CUsageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CUsageDlg, CDialog)
END_MESSAGE_MAP()


// CUsageDlg message handlers

BOOL CUsageDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	CString strLicense;

	//Get the current app directory
	CString strAppDir;
	TCHAR szModFileName[MAX_PATH];
	ZeroMemory(szModFileName, sizeof(szModFileName));
	DWORD dwLen = ::GetModuleFileName(NULL,szModFileName, sizeof(szModFileName));
	if (dwLen > 0)
	{
		TCHAR drive[_MAX_DRIVE];
		memset(drive,0,sizeof(drive));
		TCHAR dir[_MAX_PATH];
		memset(dir,0,sizeof(dir));
		_tsplitpath(szModFileName, drive, dir, NULL, NULL);
		strAppDir = drive;
		strAppDir += dir;

#ifdef _DEBUG
		strAppDir.MakeLower();
		(void)strAppDir.Replace (_T("debug\\"), _T(""));
#endif
	}
	
	strAppDir += _T("usage.txt");

	CStdioFile f;
	if (f.Open(strAppDir, CFile::typeText | CFile::modeRead))
	{
		CString strLine;
		while(f.ReadString(strLine))
		{
			strLicense += strLine;
			strLicense += _T("\r\n");
		}
	}


	GetDlgItem(IDC_EDIT_USAGE)->SetWindowText(strLicense);

	return TRUE;  // return TRUE unless you set the focus to a control
}
