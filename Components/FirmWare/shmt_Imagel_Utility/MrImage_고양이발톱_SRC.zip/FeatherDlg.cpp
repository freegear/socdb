/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "resource.h"
#include "FeatherDlg.h"

namespace MrImage
{

IMPLEMENT_DYNAMIC(CFeatherDlg, CDialog)
CFeatherDlg::CFeatherDlg(CWnd* pParent /*=NULL*/)
: CDialog(CFeatherDlg::IDD, pParent)
,m_unWidth(0)
{
}

CFeatherDlg::~CFeatherDlg()
{
}

void CFeatherDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_WIDTH, m_unWidth);
}

BOOL CFeatherDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	CWinApp * pApp = AfxGetApp();
	m_unWidth = pApp->GetProfileInt(_T("Feather"), _T("Width"), 8);
	VERIFY(UpdateData(FALSE));

	return TRUE;  // return TRUE unless you set the focus to a control
}

void CFeatherDlg::OnOK()
{
	CDialog::OnOK();

	CWinApp * pApp = AfxGetApp();
	VERIFY(pApp->WriteProfileInt(_T("Feather"), _T("Width"), m_unWidth));
}


BEGIN_MESSAGE_MAP(CFeatherDlg, CDialog)
END_MESSAGE_MAP()


}//end namespace