/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "resource.h"
#include "aboutdlg.h"

#pragma comment( lib, "version" )

namespace MrImage
{

CAboutDlg::CAboutDlg() 
: CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_HYPERLINK, m_hyperlink);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CString strLicense;

	//Get the current app directory
	CString strAppDir;
	TCHAR szModFileName[MAX_PATH];
	ZeroMemory(szModFileName, sizeof(szModFileName));
	DWORD dwLen = ::GetModuleFileName(NULL,szModFileName, sizeof(szModFileName));
	if (dwLen > 0)
	{
		TCHAR drive[_MAX_DRIVE];
		memset(drive,0,sizeof(drive));
		TCHAR dir[_MAX_PATH];
		memset(dir,0,sizeof(dir));
		_tsplitpath(szModFileName, drive, dir, NULL, NULL);
		strAppDir = drive;
		strAppDir += dir;

#ifdef _DEBUG
		strAppDir.MakeLower();
		(void)strAppDir.Replace (_T("debug\\"), _T(""));
#endif
	}
	
	strAppDir += _T("license.txt");

	CStdioFile f;
	if (f.Open(strAppDir, CFile::typeText | CFile::modeRead))
	{
		CString strLine;
		while(f.ReadString(strLine))
		{
			strLicense += strLine;
			strLicense += _T("\r\n");
		}
	}

	if (strLicense.IsEmpty())
	{
		VERIFY(strLicense.LoadString(IDS_MISSING_LICENSE));
	}

	GetDlgItem(IDC_EDIT_LICENSE)->SetWindowText(strLicense);

	CString strVersion;
	GetAppVersion(strVersion);
	GetDlgItem(IDC_STATIC_VERSION)->SetWindowText(strVersion);

	return TRUE;  // return TRUE unless you set the focus to a control
}

void CAboutDlg::GetAppVersion(CString & strVersion)
{
	TCHAR szModuleFileName[MAX_PATH]; 
	memset(szModuleFileName, 0, sizeof(szModuleFileName));

	DWORD ret = ::GetModuleFileName (NULL, szModuleFileName, MAX_PATH);
	if (ret > 0)
	{
		DWORD dwHandle = 0;
		DWORD dwVerInfoSize = ::GetFileVersionInfoSize (szModuleFileName, &dwHandle);
		if (dwVerInfoSize > 0)
		{
			HGLOBAL hVerInfo = ::GlobalAlloc (GMEM_MOVEABLE,dwVerInfoSize);
			if (hVerInfo)
			{
				LPVOID pVerInfo = ::GlobalLock(hVerInfo);

				if (::GetFileVersionInfo (szModuleFileName, dwHandle, dwVerInfoSize, pVerInfo))
				{
					VS_FIXEDFILEINFO* pFFI = 0;
					UINT uLen = 0;
					(void)::VerQueryValue (pVerInfo, _T("\\"), (void **)&pFFI, &uLen);
					if (uLen > 0)
					{
						WORD wMajorMajorVersion = (WORD)(pFFI->dwProductVersionMS >> 16);
						WORD wMajorMinorVersion = (WORD)(pFFI->dwProductVersionMS);
						WORD wMinorMajorVersion = (WORD)(pFFI->dwProductVersionLS >> 16);
						WORD wMinorMinorVersion = (WORD)(pFFI->dwProductVersionLS);

						strVersion.Format (_T("Version: %d.%d.%d.%d"), wMajorMajorVersion, wMajorMinorVersion, wMinorMajorVersion, wMinorMinorVersion);
					}
				}
				::GlobalUnlock(hVerInfo);
				::GlobalFree(hVerInfo);
			}     
		}
	}
}

}//end namespace