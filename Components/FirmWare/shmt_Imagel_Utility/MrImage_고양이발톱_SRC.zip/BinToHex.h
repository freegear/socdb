#pragma once


// CBinToHex dialog

class CBinToHex : public CDialog
{
	DECLARE_DYNAMIC(CBinToHex)

public:
	CBinToHex(CWnd* pParent = NULL);   // standard constructor
	virtual ~CBinToHex();

// Dialog Data
	enum { IDD = IDD_DIALOG_BINTOHEX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CButton m_vChar;
	CButton m_vShort;
	CButton m_vInt;

	CButton m_vCheck;
	int m_vSwap;

	CStatic m_inFileName;
	CStatic m_outFileName;

	CString m_SrcPathName;
	CString m_DstPathName;
	
	CString m_SrcFileName;
	CString m_DstFileName;

	CString m_PathName;

	void convertTypeShort(void);
	void convertTypeInt(void);
	void convertTypeChar(void);

public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonInputfile();
	afx_msg void OnBnClickedButtonConvert();
};
