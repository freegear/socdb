#pragma once

#define YUV_PACKED 0
#define YUV_PLANAR 1

#define YUV_420 0
#define YUV_422 1
#define YUV_444 2

#define YUV_INTERLACED  0
#define YUV_PROGRESSIVE 1


#define DLG_OPEN_YUV	0
#define DLG_OPEN_RGB	1
#define DLG_SAVE_YUV	2
#define DLG_SAVE_RGB	3

// CRawDlg dialog

class CRawDlg : public CDialog
{
	DECLARE_DYNAMIC(CRawDlg)

public:
	CRawDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CRawDlg();

// Dialog Data
	enum { IDD = IDD_RAWDIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CComboBox	m_comBoPacked;
	CComboBox	m_comBoSampleFormat;
	CComboBox	m_comBoInterlaced;

	CButton m_vRGB565;
	CButton m_vRGB666;
	CButton m_vRGB888;
	CButton m_vYUV;

	CString m_Rmask;
	CString m_Gmask;
	CString m_Bmask;
	DWORD m_RmaskValue;
	DWORD m_GmaskValue;
	DWORD m_BmaskValue;
	
	CString m_width;
	CString m_height;
	DWORD m_widthValue;
	DWORD m_heightValue;

	int m_method;
	int m_sampleFormat, m_packed, m_interlaced;

	int m_dlgStart;


	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedRadioRgb666();
	afx_msg void OnBnClickedRadioRgb888();
	afx_msg void OnBnClickedRadioRgb565();
	afx_msg void OnBnClickedRadioYUV();
};
