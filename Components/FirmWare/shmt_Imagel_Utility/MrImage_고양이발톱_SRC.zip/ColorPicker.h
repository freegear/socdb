/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/
#pragma once

#include <vector>

namespace MrImage
{
class CMrImageDoc;

class CColorPicker 
: public CWnd
{
	DECLARE_DYNAMIC(CColorPicker)

public:
	CColorPicker();
	virtual ~CColorPicker();

	typedef enum
	{ COMMON_COLORS = 0,
	  SYSTEM_COLORS,
	  WEB_COLORS,
	  IMAGE_COLORS,
	  MAX_COLORS = 32
	}COLOR_TYPE;

	void SetColorType(COLOR_TYPE type);

	//This retrieves the id of the registered window message
	//for when the user selects a color.
	//Parent/Owner should handle this message with an ON_REGISTERED_MESSAGE message map entry.
	//When handling the message:
	//The WPARAM should be ignored.
	//The LPARAM indicates the mouse button used to select (0 == left button, 1 == right button).
	static UINT GetSelectionChangeMsgID();

	COLORREF GetSelectedColor()const{ return m_colorSelected; }

	//set the size of the displayed colors
	CSize GetColorSize()const { return m_CellSize; }
	void SetColorSize(const CSize & size);

protected:
	DECLARE_MESSAGE_MAP()

	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk( UINT, CPoint );
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);

	void LoadColors();
	CSize CalcCellMax(const CRect & rcClient);

private:
	std::vector<COLORREF> m_colors;
	COLOR_TYPE m_colorType;
	CPoint m_ptSelected;
	COLORREF m_colorSelected;
	CMrImageDoc * m_pActiveImage;
	UINT m_unTimerID;
	CSize m_CellSize;
	std::vector<COLORREF> m_customcolors;
};

}//end namespace
