/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "resource.h"
#include "MrImage.h"
#include "MainFrm.h"
#include "ChildFrm.h"
#include "MrImageDoc.h"
#include "MrImageView.h"
#include "AboutDlg.h"
#include "UsageDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace MrImage
{

BEGIN_MESSAGE_MAP(CMrImageApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)

	ON_COMMAND(ID_BUTTON_HEX, OnButtonHexOpen)
	ON_COMMAND(ID_BUTTON_EXPLORER, OnButtonExplorerOpen)
	ON_COMMAND(ID_BUTTON_CALC, OnCalcOpen)
	ON_COMMAND(ID_BUTTON_YUV, OnYuvOpen)
	ON_COMMAND(ID_BUTTON_PICKER, OnPickerOpen)
	ON_COMMAND(ID_BUTTON_CAPTURE, OnCaptureOpen)
	ON_COMMAND(ID_BUTTON_MSPAINT, OnMsPaintOpen)

END_MESSAGE_MAP()

// CMrImageApp construction

CMrImageApp::CMrImageApp()
{
}


// The one and only CMrImageApp object
CMrImageApp theApp;

BOOL CMrImageApp::InitInstance()
{
	// InitCommonControls() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	InitCommonControls();

	CWinApp::InitInstance();

	// Initialize OLE libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}
	AfxEnableControlContainer();
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	SetRegistryKey(_T("MrImage"));

	LoadStdProfileSettings(8);  // Load standard INI file options (including MRU)
	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views
	CMultiDocTemplate* pDocTemplate;

	pDocTemplate = new CMultiDocTemplate(IDR_ALL_IMAGES,
		RUNTIME_CLASS(CMrImageDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CMrImageView));

	if (!pDocTemplate)
		return FALSE;

	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame || !pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;
	// call DragAcceptFiles only if there's a suffix
	//  In an MDI app, this should occur immediately after setting m_pMainWnd
	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// disable automatically FileNew at startup
	if (CCommandLineInfo::FileNew == cmdInfo.m_nShellCommand)
	{
		cmdInfo.m_nShellCommand = CCommandLineInfo::FileNothing;
	}

	// Dispatch commands specified on the command line.  Will return FALSE if
	// app was launched with /RegServer, /Register, /Unregserver or /Unregister.
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
	// The main window has been initialized, so show and update it
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();
	return TRUE;
}

// App command to run the dialog
void CMrImageApp::OnAppAbout()
{
	CUsageDlg usageDlg;
	usageDlg.DoModal();

	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

void CMrImageApp::OnButtonHexOpen()
{
	DWORD bufferlen = 256;
	char path[256];
	CString fullPath;

	GetCurrentDirectory(bufferlen,(LPSTR)path); 
	fullPath.Format("%s\\%s", path, "\\utility\\HexTool.exe");

	ShellExecute(NULL,(LPCSTR)"open", (LPCSTR)fullPath, NULL, NULL, SW_SHOW);
}

void CMrImageApp::OnCaptureOpen()
{
	DWORD bufferlen = 256;
	char path[256];
	CString fullPath;

	GetCurrentDirectory(bufferlen,(LPSTR)path); 
	fullPath.Format("%s\\%s", path, "\\utility\\opencapture.exe");

	ShellExecute(NULL,(LPCSTR)"open", (LPCSTR)fullPath, NULL, NULL, SW_SHOW);
}

void CMrImageApp::OnPickerOpen()
{
	DWORD bufferlen = 256;
	char path[256];
	CString fullPath;

	GetCurrentDirectory(bufferlen,(LPSTR)path); 
	fullPath.Format("%s\\%s", path, "\\utility\\ColorPix.exe");

	ShellExecute(NULL,(LPCSTR)"open", (LPCSTR)fullPath, NULL, NULL, SW_SHOW);
}

void CMrImageApp::OnYuvOpen()
{
	DWORD bufferlen = 256;
	char path[256];
	CString fullPath;

	GetCurrentDirectory(bufferlen,(LPSTR)path); 
	fullPath.Format("%s\\%s", path, "\\utility\\Elecard.exe");

	ShellExecute(NULL,(LPCSTR)"open", (LPCSTR)fullPath, NULL, NULL, SW_SHOW);
}

void CMrImageApp::OnButtonExplorerOpen()
{
	ShellExecute(NULL,(LPCSTR)"open", (LPCSTR)"explorer.exe", NULL, NULL, SW_SHOW);
}
void CMrImageApp::OnCalcOpen()
{
	ShellExecute(NULL,(LPCSTR)"open", (LPCSTR)"calc.exe", NULL, NULL, SW_SHOW);
}

void CMrImageApp::OnMsPaintOpen()
{
	ShellExecute(NULL,(LPCSTR)"open", (LPCSTR)"mspaint.exe", NULL, NULL, SW_SHOW);
}


void CMrImageApp::OnFileOpen()
{
	CString strFilter;

	CString str;

	VERIFY(str.LoadString(IDS_YUV_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_YUV_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_RAW_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_RAW_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_BITMAP_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_BITMAP_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_JPEG_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_JPEG_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_GIF_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_GIF_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_PNG_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_PNG_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_ICO_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_ICO_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_TIFF_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_TIFF_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_TGA_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_TGA_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_PCX_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_PCX_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_WBMP_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_WBMP_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_WMF_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_WMF_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_JPEG2000_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_JPEG2000_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_RAS_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_RAS_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_PNM_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_PNM_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");

	VERIFY(str.LoadString(IDS_ALLIMAGE_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_ALLIMAGE_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");

	VERIFY(str.LoadString(IDS_ALLFILES_FILTER));
	strFilter += str;
	strFilter += _T("|");
	VERIFY(str.LoadString(IDS_ALLFILES_EXTENSIONS));
	strFilter += str;
	strFilter += _T("|");

	//no more so append final pipe
	strFilter += _T("|");

	CFileDialog fd(TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, strFilter, m_pMainWnd);

	//restore the last selection filter
	fd.m_ofn.nFilterIndex = AfxGetApp()->GetProfileInt(_T("FileOpen"), _T("LastFilter"), 0);

	//allow multiple selection
	fd.m_ofn.Flags |= OFN_ALLOWMULTISELECT;
	
	if (IDOK == fd.DoModal())
	{
		//save off the selected filter
		VERIFY(AfxGetApp()->WriteProfileInt(_T("FileOpen"), _T("LastFilter"), fd.m_ofn.nFilterIndex));

		//open each selected file
		POSITION pos = fd.GetStartPosition();
		while (pos)
		{
			(void)OpenDocumentFile(fd.GetNextPathName(pos));
		}
	}
}

}//end namespace
