/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "resource.h"
#include "WindowsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace MrImage
{

//-----------------------------------------------------------------------
CWindowsDlg::CWindowsDlg(CWnd* pParent /*=NULL*/)
: CDialog(CWindowsDlg::IDD, pParent)
,m_lstWindows()
{
}

//-----------------------------------------------------------------------
void CWindowsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWindowsDlg)
	DDX_Control(pDX, IDC_LIST_WINDOWS, m_lstWindows);
	//}}AFX_DATA_MAP
}

//-----------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CWindowsDlg, CDialog)
	//{{AFX_MSG_MAP(CWindowsDlg)
	ON_BN_CLICKED(ID_BTN_ACTIVATE, OnBtnActivateWindow)
	ON_BN_CLICKED(ID_BTN_SAVE, OnBtnSave)
	ON_BN_CLICKED(ID_BTN_CLOSEWINDOWS, OnBtnCloseWindows)
	ON_LBN_SELCHANGE(IDC_LIST_WINDOWS, OnSelChangeListWindows)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//-----------------------------------------------------------------------
BOOL CWindowsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CWinApp * pApp = AfxGetApp();
	POSITION posDoc = NULL;
	POSITION posView = NULL;
	CDocument * pDoc = NULL;
	CView * pView = NULL;
	CDocTemplate * pDocTemplate = NULL;
	CString strTitle;
	int nIndex = -1;

	CSize sz;
	int dx = 0;
	TEXTMETRIC tm;
	CDC* pDC = m_lstWindows.GetDC();
	CFont * pFont = m_lstWindows.GetFont();
	CFont* pOldFont = pDC->SelectObject(pFont);
	
	// Get the text metrics for avg char width
	pDC->GetTextMetrics(&tm); 

	POSITION pos = pApp->m_pDocManager->GetFirstDocTemplatePosition();

	while (pos)
	{
		pDocTemplate = pApp->m_pDocManager->GetNextDocTemplate(pos);

		if (pDocTemplate)
		{
			posDoc = pDocTemplate->GetFirstDocPosition();

			while (posDoc)
			{
				pDoc = pDocTemplate->GetNextDoc(posDoc);

				if (pDoc)
				{
					posView = pDoc->GetFirstViewPosition();
					
					while (posView)
					{
						pView = pDoc->GetNextView(posView);

						if (pView)
						{
							CFrameWnd * pFrame = pView->GetParentFrame();
							if (pFrame)
							{
								strTitle.Empty();
								pFrame->GetWindowText(strTitle);
								if (!strTitle.IsEmpty())
								{
									nIndex = m_lstWindows.AddString(strTitle);
									if (LB_ERR != nIndex)
									{
										m_lstWindows.SetItemData(nIndex, (DWORD)pFrame->GetSafeHwnd());

										//calculate the horizontal extent
										sz = pDC->GetTextExtent(strTitle);

										sz.cx += tm.tmAveCharWidth;

										dx = max(sz.cx, dx);
									}
								}
							}
						}

					}//end while
				}
			}//end while
		}
	}//end while

	pDC->SelectObject(pOldFont);
	m_lstWindows.ReleaseDC(pDC);

	m_lstWindows.SetHorizontalExtent(dx);

	OnSelChangeListWindows();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//-----------------------------------------------------------------------
void CWindowsDlg::OnBtnActivateWindow() 
{
	int arrSelected[256];
	int nSelected = m_lstWindows.GetSelItems(256, arrSelected);
	if (LB_ERR != nSelected && nSelected > 0)
	{
		//you can only activate one window
		//so we only process the first selected item

		HWND hWnd = (HWND)m_lstWindows.GetItemData(arrSelected[0]);
		CWnd * pChild = CWnd::FromHandle(hWnd);
		if (pChild)
		{
			CMDIFrameWnd * pMainFrame = (CMDIFrameWnd*)AfxGetMainWnd();
			pMainFrame->MDIActivate(pChild);
			
			//now close this dialog
			SendMessage(WM_CLOSE);
		}
	}
}

//-----------------------------------------------------------------------
void CWindowsDlg::OnBtnSave() 
{
	int arrSelected[256];
	int nSelected = m_lstWindows.GetSelItems(256, arrSelected);
	if (LB_ERR != nSelected && nSelected > 0)
	{
		HWND hWnd = NULL;
		CWnd * pChild = NULL;
		CMDIFrameWnd * pMainFrame = (CMDIFrameWnd*)AfxGetMainWnd();

		for (int i = 0; i < nSelected; ++i)
		{
			hWnd = (HWND)m_lstWindows.GetItemData(arrSelected[i]);
			pChild = CWnd::FromHandle(hWnd);
			if (pChild)
			{
				pMainFrame->MDIActivate(pChild);
				pMainFrame->SendMessage(WM_COMMAND, MAKEWPARAM(ID_FILE_SAVE, 0L), NULL);
			}
		}
		//now close this dialog
		SendMessage(WM_CLOSE);
	}
}

//-----------------------------------------------------------------------
void CWindowsDlg::OnBtnCloseWindows() 
{
	int arrSelected[256];
	int nSelected = m_lstWindows.GetSelItems(256, arrSelected);
	if (LB_ERR != nSelected && nSelected > 0)
	{
		HWND hWnd = NULL;
		CWnd * pChild = NULL;
		CMDIFrameWnd * pMainFrame = (CMDIFrameWnd*)AfxGetMainWnd();

		for (int i = nSelected - 1; i > -1; --i)
		{
			hWnd = (HWND)m_lstWindows.GetItemData(arrSelected[i]);
			pChild = CWnd::FromHandle(hWnd);
			if (pChild)
			{
				pMainFrame->MDIActivate(pChild);
				pMainFrame->SendMessage(WM_COMMAND, MAKEWPARAM(ID_FILE_CLOSE, 0L), NULL);
			}
			m_lstWindows.DeleteString(arrSelected[i]);
		}
	}
}

//-----------------------------------------------------------------------
void CWindowsDlg::OnSelChangeListWindows() 
{
	BOOL bEnable = FALSE;
	BOOL bMulti = FALSE;
	int nSelected = m_lstWindows.GetSelCount();
	if (nSelected > 0)
	{
		bEnable = TRUE;

		if (nSelected > 1)
		{
			bMulti = TRUE;
		}
	}

	GetDlgItem(ID_BTN_SAVE)->EnableWindow(bEnable);
	GetDlgItem(ID_BTN_CLOSEWINDOWS)->EnableWindow(bEnable);
	GetDlgItem(ID_BTN_ACTIVATE)->EnableWindow(bEnable && !bMulti);
}

//-----------------------------------------------------------------------
//-----------------------------------------------------------------------

}//end namespace