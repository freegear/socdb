/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/
#pragma once

#include <memory>

namespace MrImage
{
class CMrImageDoc;
class CTextEditCtrl;

class CMrImageView 
: public CScrollView
{
protected: // create from serialization only
	CMrImageView();
	DECLARE_DYNCREATE(CMrImageView)

public:
	virtual ~CMrImageView();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CMrImageDoc* GetDocument() const;

	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();

	//This retrieves the id of the registered window message
	//for when the user selects a color with the dropper tool.
	//Main Window (AfxGetMainWnd()) should handle this message
	//with an ON_REGISTERED_MESSAGE message map entry.
	//When handling the message:
	//The WPARAM indicates the mouse button used to select (0 == left button, 1 == right button).
	//The LPARAM is the colorref
	static UINT GetDropperSelectedColorMsgID();

	//This retrieves the id of the registered window message
	//for when the user moves the cursor within the view.
	static UINT GetCursorPositionMsgID();

	BOOL HasSelection()const;
	void MergeSelection();
	void ClearSelection();

	//this is used by the document during "Paste As New Image"
	SELKEY GetSelectionKey()const { return m_hSelectionKey; }

protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
	virtual void OnSizeToFit();

	typedef enum
	{
		NO_MOUSE_BTN_DOWN = 0,
		LEFT_MOUSE_BTN_DOWN,
		RIGHT_MOUSE_BTN_DOWN
	}MOUSE_BTN_DOWN;

	virtual void OnToolBegin(const CPoint & position, MOUSE_BTN_DOWN mouse);
	virtual void OnToolMove(const CPoint & position, MOUSE_BTN_DOWN mouse);
	virtual void OnToolEnd(const CPoint & position, MOUSE_BTN_DOWN mouse);
	virtual void OnToolCancel();

	BOOL IsSplit(void)const;
	BOOL IsLeftMouseButtonDown()const{ return (GetAsyncKeyState((m_bMouseBtnSwapped ? VK_RBUTTON : VK_LBUTTON)) < 0);	}
	BOOL IsRightMouseButtonDown()const{ return (GetAsyncKeyState((m_bMouseBtnSwapped ? VK_LBUTTON : VK_RBUTTON)) < 0);	}
	BOOL IsMultiSelectKeyDown()const { return (GetAsyncKeyState(VK_CONTROL) < 0);	}
	BOOL IsToolSelected()const{ return (0 != m_unSelectedTool);}
	CPoint GetMouseCursorPos()const;
	void RubberRect(CDC & dc, const CPoint & ptTopLeft, const CPoint & ptBottomRight);
	void RubberEllipse(CDC & dc, const CPoint & ptTopLeft, const CPoint & ptBottomRight);
	void RubberLine(CDC & dc, const CPoint & ptStart, const CPoint & ptEnd);
	BOOL CreateSelection(BOOL bConvertToImagePoints, int type);
	CPoint GetImagePoint(const CPoint & pt)const;
	BOOL PtInSel(const CPoint & pt)const;
	BOOL GetSelRect(CRect & rc)const;
	CFont * GetTextFont();
	BOOL GetSelectedBrushStyleMask(CBitmap & bmp);

	afx_msg void OnUpdateStdDrawTools( CCmdUI* pCmdUI );
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg LPARAM OnMouseLeave(WPARAM wp, LPARAM lp);
	afx_msg void OnSelectedStdDrawTool(UINT nID);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnEditCopy();
	afx_msg void OnUpdateEditCopy(CCmdUI *pCmdUI);
	afx_msg void OnEditCut();
	afx_msg void OnUpdateEditCut(CCmdUI *pCmdUI);
	afx_msg void OnEditPaste();
	afx_msg void OnUpdateEditPaste(CCmdUI *pCmdUI);
	afx_msg void OnCrop();
	afx_msg void OnUpdateCrop(CCmdUI *pCmdUI);
	afx_msg void OnEditSelectAll();
	afx_msg void OnUpdateEditSelectAll(CCmdUI *pCmdUI);
	afx_msg void OnEditSelectNone();
	afx_msg void OnUpdateEditSelectNone(CCmdUI *pCmdUI);
	afx_msg void OnRedEyeRemove();
	afx_msg void OnUpdateRedEyeRemove(CCmdUI *pCmdUI);
	afx_msg void OnZoomIn();
	afx_msg void OnUpdateZoomIn(CCmdUI *pCmdUI);
	afx_msg void OnZoomOut();
	afx_msg void OnUpdateZoomOut(CCmdUI *pCmdUI);
	afx_msg void OnNoZoom();
	afx_msg void OnUpdateNoZoom(CCmdUI *pCmdUI);
	afx_msg void OnApplyToSelection();
	afx_msg void OnUpdateApplyToSelection(CCmdUI *pCmdUI);
	afx_msg void OnShowSelectionBorder();
	afx_msg void OnUpdateShowSelectionBorder(CCmdUI *pCmdUI);
	afx_msg void OnFilterTransform(UINT nID);
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateEditUndo(CCmdUI *pCmdUI);
	afx_msg void OnEditRedo();
	afx_msg void OnUpdateEditRedo(CCmdUI *pCmdUI);
	afx_msg LPARAM OnTextEditComplete(WPARAM wp, LPARAM lp);
	afx_msg void OnFontNameChange();
	afx_msg void OnUpdateFontName(CCmdUI *pCmdUI);
	afx_msg void OnFontSizeChange();
	afx_msg void OnUpdateFontSize(CCmdUI *pCmdUI);
	afx_msg void OnFontBold();
	afx_msg void OnFontItalics();
	afx_msg void OnFontUnderline();
	afx_msg void OnNudge(UINT nID);
	afx_msg void OnUpdateNudge(CCmdUI * pCmdUI);
	afx_msg void OnKeyDown( UINT, UINT, UINT );
	afx_msg void OnToolbarDropDown( NMHDR * pNotifyStruct, LRESULT * result );


	DECLARE_MESSAGE_MAP()

private:
	static UINT m_unSelectedTool;
	static UINT m_unLastSelectedTool;
	static BOOL m_bApplyToSelection;
	static BOOL m_bShowSelectionBorder;
	static UINT m_unBrushStyle;

	BOOL m_bSized;
	BOOL m_bTrackingMouse;
	
	//points made while using a tool. Rectangles, ellipses, selections, etc.
	std::vector<POINT> m_pts;

	BOOL m_bMouseBtnSwapped;
	COLORREF m_foreColor;
	COLORREF m_backColor;
	MOUSE_BTN_DOWN m_eMouseBtnDown;
	BOOL m_bTrackOutside;
	UINT m_unTimerID;
	SELKEY m_hSelectionKey;
	float m_fZoomFactor;
	std::auto_ptr<CTextEditCtrl> m_ptrEdit;
	
	CFont m_TextFont;
};

#ifndef _DEBUG  // debug version located in MrImageView.cpp
inline CMrImageDoc* CMrImageView::GetDocument() const
   { return reinterpret_cast<CMrImageDoc*>(m_pDocument); }
#endif

class CSelectedColorChanged
: public CObject
{
	DECLARE_DYNAMIC(CSelectedColorChanged)

	CSelectedColorChanged();
public:
	explicit CSelectedColorChanged(const COLORREF & clr, bool isForeground = true):m_selectedColor(clr), m_bForeColor(isForeground){ }
	virtual ~CSelectedColorChanged(){}

	static LPARAM HINT_SELECTED_COLOR_CHANGED;

	COLORREF GetSelectedColor()const { return m_selectedColor; }
	bool IsForegroundColor()const{ return m_bForeColor; }

private:
	COLORREF m_selectedColor;
	bool m_bForeColor;
};

class CTextEditCtrl
: public CEdit
{
public:
	CTextEditCtrl();
	virtual ~CTextEditCtrl();

	CString GetText()const { return m_strText; }
	BOOL IsCancelled()const { return m_bCancelled; 	}

	//{{AFX_VIRTUAL(CTextEditCtrl)
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

private:	
	CString m_strText;
	BOOL m_bCancelled;
	CBrush m_Brush;
	BOOL m_bNotify;
protected:
	//{{AFX_MSG(CTextEditCtrl)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);	
	afx_msg void OnDestroy();
	afx_msg void OnUpdate();
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

class CStyleMenu
:public CMenu
{
public:
	CStyleMenu();
	virtual ~CStyleMenu();

	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	
	void SetImageList(CImageList * pil){ m_pImageList = pil; }
private:
	CImageList * m_pImageList;
};


}//end namespace