/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

// SkewDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "SkewDlg.h"


namespace MrImage
{

IMPLEMENT_DYNAMIC(CSkewDlg, CDialog)
CSkewDlg::CSkewDlg(CWnd* pParent /*=NULL*/)
: CDialog(CSkewDlg::IDD, pParent)
,m_pivotx(0)
,m_pivoty(0)
,m_skewx(0.0f)
,m_skewy(0.0f)
,m_size(0,0)
{
}

CSkewDlg::~CSkewDlg()
{
}

void CSkewDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_EDIT_PIVOTX, m_pivotx);
	DDX_Text(pDX, IDC_EDIT_PIVOTY, m_pivoty);
	DDX_Text(pDX, IDC_EDIT_HORIZ, m_skewx);
	DDX_Text(pDX, IDC_EDIT_VERT, m_skewy);
}


BEGIN_MESSAGE_MAP(CSkewDlg, CDialog)
END_MESSAGE_MAP()

float CSkewDlg::GetHorizSkew()const
{
	ASSERT(m_size.cx > 0);
	//calc horiz slope
	return (-10 * (m_skewx/m_size.cx));
}

float CSkewDlg::GetVertSkew()const
{
	ASSERT(m_size.cy > 0);
	//calc vert slope
	return (-10 * (m_skewy/m_size.cy));
}

}//end namespace