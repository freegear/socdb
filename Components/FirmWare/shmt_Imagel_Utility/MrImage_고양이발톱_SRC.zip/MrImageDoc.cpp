/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "resource.h"
#include "MrImageDoc.h"
#include "MrImageView.h"
#include "image.h"
#include <queue>
#include "Quantize.h"
#include "OptionsDlg.h"
#include ".\rawdlg.h"
#include "BinToHex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace MrImage
{

IMPLEMENT_DYNCREATE(CMrImageDoc, CDocument)

//---------------------------------------------------------------
BEGIN_MESSAGE_MAP(CMrImageDoc, CDocument)
	ON_COMMAND(ID_VIEW_IMAGEATTRIBUTES, OnViewImageAttributes)	
END_MESSAGE_MAP()

//---------------------------------------------------------------
CMrImageDoc::CMrImageDoc()
:m_pImage(NULL)
,m_Undo()
,m_Redo()
,m_nBeginUndoRefCount(0)
,m_bUndoing(FALSE)
,m_bUndoRedoEnabled(TRUE)
,m_unMaxUndoItems(512)
{
	COptionsDlg options;
	m_bUndoRedoEnabled = options.IsUndoRedoEnabled();
	m_unMaxUndoItems = options.GetMaxUndoItems();
}

//---------------------------------------------------------------
CMrImageDoc::~CMrImageDoc()
{
	ASSERT(NULL == m_pImage);
}

//---------------------------------------------------------------
COLORREF CMrImageDoc::GetPixel(int x, int y)const
{
	ASSERT(m_pImage);

	//flip the y
	y = m_pImage->GetHeight() - y - 1;

	RGBQUAD rgb = m_pImage->GetPixelColor(x, y);
	return RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue);
}

//---------------------------------------------------------------
void CMrImageDoc::SetPixel(int x, int y, const COLORREF & color)
{
	ASSERT(m_pImage);

	//if there is transparency
	//and the color being set is the transparent color
	//do nothing
	if (m_pImage->IsTransparent())
	{
		RGBQUAD rgb = m_pImage->GetTransColor();
		COLORREF trans(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
		if (trans == color)
		{
			return;
		}
	}

	//flip the y
	const int yOrig = y;
	y = m_pImage->GetHeight() - y - 1;

	BeginUndo();

	//TRACE(_T("Set pixel (%d,%d): R:%d G:%d B:%d\n"),x,y, color.GetR(), color.GetG(), color.GetB());
	m_pImage->SetPixelColor(x, y, color);

	EndUndo();
}

//---------------------------------------------------------------
void CMrImageDoc::Render(CDC * pDC)
{
	ASSERT(m_pImage);
	m_pImage->Render(pDC);
}

//---------------------------------------------------------------
CSize CMrImageDoc::GetSize()const
{
	ASSERT(m_pImage); 
	return CSize(m_pImage->GetWidth(), m_pImage->GetHeight()); 
}

//---------------------------------------------------------------
int GetImageType(LPCTSTR lpszPathName)
{
	TCHAR ext[_MAX_EXT]; 
	memset(ext, 0, sizeof(ext));

	_tsplitpath(lpszPathName, NULL, NULL, NULL, ext);

	CString strType;

	VERIFY(strType.LoadString(IDS_YUV_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_YUV;
	}

	VERIFY(strType.LoadString(IDS_RAW_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_RAW;
	}
	VERIFY(strType.LoadString(IDS_BITMAP_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_BMP;
	}

	VERIFY(strType.LoadString(IDS_JPEG_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_JPG;
	}

	VERIFY(strType.LoadString(IDS_GIF_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_GIF;
	}

	VERIFY(strType.LoadString(IDS_PNG_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_PNG;
	}

	VERIFY(strType.LoadString(IDS_ICO_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_ICO;
	}

	VERIFY(strType.LoadString(IDS_TIFF_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_TIF;
	}

	VERIFY(strType.LoadString(IDS_TGA_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_TGA;
	}

	VERIFY(strType.LoadString(IDS_PCX_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_PCX;
	}

	VERIFY(strType.LoadString(IDS_WBMP_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_WBMP;
	}

	VERIFY(strType.LoadString(IDS_WMF_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_WMF;
	}

	VERIFY(strType.LoadString(IDS_JPEG2000_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		CString test(ext);
		test.MakeLower();

		if (test == _T(".j2k") || test == _T(".jp2"))
		{
			return CXIMAGE_FORMAT_JP2;
		}

		if (test == _T(".jpc") || test == _T(".j2c"))
		{
			return CXIMAGE_FORMAT_JPC;
		}

		if (test == _T("pgx"))
		{
			return CXIMAGE_FORMAT_PGX;
		}
	}

	VERIFY(strType.LoadString(IDS_RAS_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_RAS;
	}

	VERIFY(strType.LoadString(IDS_PNM_EXTENSIONS));
	if (-1 != strType.Find(ext))
	{
		return CXIMAGE_FORMAT_PNM;
	}

	return CXIMAGE_FORMAT_UNKNOWN;
}

//-----------------------------------------------------------------------------
// Override SetModified flag to notify view when doc has changed,
// so the view can tell the frame to update the title.
//-----------------------------------------------------------------------------
void CMrImageDoc::SetModifiedFlag (BOOL bModified)
{
	CString title = GetTitle();	

	if (title.GetLength() > 0)
	{
		if (IsModified() != bModified) 
		{
			CDocument::SetModifiedFlag(bModified);

			int asterisk = title.GetLength() - 1;

			if (asterisk >= 0 && title.GetAt(asterisk) == _T('*'))
			{
				if (!bModified)
				{
					title.SetAt(asterisk,0);
				}
			}
			else if (bModified)
			{
				title += _T('*');
			}

			SetTitle(title);
		}
	}
}

//---------------------------------------------------------------
void CMrImageDoc::BeginUndo()
{
	if (m_bUndoRedoEnabled)
	{
		if (m_Undo.size() < m_unMaxUndoItems)
		{
			if (0 == m_nBeginUndoRefCount)
			{
				m_Undo.push(new Image(*m_pImage));
			}
		}
		++m_nBeginUndoRefCount;
	}
}

//---------------------------------------------------------------
void CMrImageDoc::EndUndo()
{
	if (m_bUndoRedoEnabled)
	{
		--m_nBeginUndoRefCount;
		if (0 == m_nBeginUndoRefCount)
		{
			SetModifiedFlag(TRUE);
			UpdateAllViews(NULL);
		}
	}
	else
	{
		SetModifiedFlag(TRUE);
		UpdateAllViews(NULL);
	}

}

//---------------------------------------------------------------
void CMrImageDoc::ClearUndoRedo()
{
	while(!m_Undo.empty())
	{
		delete m_Undo.top();		
		m_Undo.pop();
	}

	m_nBeginUndoRefCount = 0; 

	while(!m_Redo.empty())
	{
		delete m_Redo.top();
		m_Redo.pop();
	}
}

//---------------------------------------------------------------
void CMrImageDoc::Undo()
{
	ASSERT(CanUndo());
	if (!m_Undo.empty())
	{
		Image * pImage = m_Undo.top();
		m_Undo.pop();
		m_nBeginUndoRefCount = 0;

		while (!m_Redo.empty())
		{
			delete m_Redo.top();
			m_Redo.pop();
		}

		m_Redo.push(m_pImage);
		m_pImage = pImage;

		if (!CanUndo())
		{
			SetModifiedFlag(FALSE);
		}
		UpdateAllViews(NULL);
	}
}

//---------------------------------------------------------------
void CMrImageDoc::Redo()
{
	ASSERT(CanRedo());
	if (!m_Redo.empty())
	{
		Image * pImage = m_Redo.top();
		m_Redo.pop();
		m_nBeginUndoRefCount = 0;
		m_Undo.push(m_pImage);
		m_pImage = pImage;
		SetModifiedFlag(TRUE);
		UpdateAllViews(NULL);
	}
}

//---------------------------------------------------------------
void CMrImageDoc::DrawRectangle(const CPoint & ptStart, const CPoint & ptEnd, const COLORREF & color)
{
	BeginUndo();
	DrawLine(ptStart, CPoint(ptEnd.x, ptStart.y), color);
	DrawLine(CPoint(ptEnd.x, ptStart.y), CPoint(ptEnd.x, ptEnd.y), color);
	DrawLine(CPoint(ptStart.x, ptEnd.y), CPoint(ptEnd.x, ptEnd.y), color);
	DrawLine(CPoint(ptStart.x, ptStart.y), CPoint(ptStart.x, ptEnd.y), color);
	EndUndo();
}

//---------------------------------------------------------------
//implementation taken from Wikipedia
void CMrImageDoc::DrawLine(const CPoint & ptStart, const CPoint & ptEnd, const COLORREF & color)
{ 
	BeginUndo();

	int x0 = ptStart.x;
	int y0 = ptStart.y;
	int x1 = ptEnd.x;
	int y1 = ptEnd.y;

	int i;
	int sx, sy;  /* step positive or negative (1 or -1) */
	int dx, dy;  /* delta (difference in X and Y between points) */
	int dx2, dy2;
	int e;
	int temp;

	dx = x1 - x0;
	sx = (dx > 0) ? 1 : -1;
	if (dx < 0)
		dx = -dx;

	dy = y1 - y0;
	sy = (dy > 0) ? 1 : -1;
	if (dy < 0)
		dy = -dy;

	dx2 = dx << 1; /* dx2 = 2 * dx */
	dy2 = dy << 1; /* dy2 = 2 * dy */

	if (dy <= dx)
	{ /* steep */
		e = dy2 - dx;

		for (i = 0; i < dx; ++i)
		{
			SetPixel(x0, y0, color);

			while (e >= 0)
			{
				y0 += sy;
				e -= dx2;
			}

			x0 += sx;
			e += dy2;
		}
	} 
	else 
	{
		/* swap x0 <-> y0 */
		temp = x0;
		x0 = y0;
		y0 = temp;

		/* swap dx <-> dy */
		temp = dx;
		dx = dy;
		dy = temp;

		/* swap dx2 <-> dy2 */
		temp = dx2;
		dx2 = dy2;
		dy2 = temp;

		/* swap sx <-> sy */
		temp = sx;
		sx = sy;
		sy = temp;

		e = dy2 - dx;

		for (i = 0; i < dx; ++i)
		{
			SetPixel(y0, x0, color);

			while (e >= 0)
			{
				y0 += sy;
				e -= dx2;
			}

			x0 += sx;
			e += dy2;
		}
	}
	EndUndo();
} 

//---------------------------------------------------------------
//Called by DrawBresenhamEllipse to fill it
//---------------------------------------------------------------
void CMrImageDoc::FillEllipse(int x, int y, int YRADIUS, int MAX_WIDTH, const CPoint & ptCenter, const COLORREF & fillColor)
{
	if (y != YRADIUS)
	{
		BeginUndo();

		int xLeft = max(0, (ptCenter.x - x + 1));
		int xRight = min((MAX_WIDTH-1), (ptCenter.x + x - 1));

		for (int i = xLeft; i < xRight; ++i)
		{
			SetPixel(i, ptCenter.y + y, fillColor);
			SetPixel(i, ptCenter.y - y, fillColor);
		}

		EndUndo();
	}
}

//---------------------------------------------------------------
void CMrImageDoc::DrawEllipse(const CRect & rc, const COLORREF & color, const COLORREF * pFillColor /*=NULL*/)
{
	ASSERT(m_pImage);

	BeginUndo();

	const CPoint ptCenter = rc.CenterPoint();

	//tons of constants to calculate first
	const int XRADIUS = rc.Width()/2;
	const int YRADIUS = rc.Height()/2;
	const int YRADIUS_2X = YRADIUS * 2;
	const int XRADIUS_SQ = XRADIUS * XRADIUS; 
	const int XRADIUS_SQ_2X = 2 * XRADIUS_SQ; 
	const int XRADIUS_SQ_4X = 4 * XRADIUS_SQ; 
	const int YRADIUS_SQ = YRADIUS * YRADIUS; 
	const int YRADIUS_SQ_2X = 2 * YRADIUS_SQ;
	const int YRADIUS_SQ_4X = 4 * YRADIUS_SQ;
	const int ONE_MINUS_YRADIUS_2X = 1 - YRADIUS_2X;
	const int MAX_WIDTH = m_pImage->GetWidth();

	int x = 0;
	int y = YRADIUS;

	int d1 = (XRADIUS_SQ * ONE_MINUS_YRADIUS_2X) + YRADIUS_SQ_2X;
	int d2 = YRADIUS_SQ - XRADIUS_SQ_2X * ONE_MINUS_YRADIUS_2X;

	SetPixel(ptCenter.x - x, ptCenter.y + y, color);
	SetPixel(ptCenter.x + x, ptCenter.y + y, color);
	SetPixel(ptCenter.x - x, ptCenter.y - y, color);
	SetPixel(ptCenter.x + x, ptCenter.y - y, color);

	int x2 = 2 * x;
	int y2 = 2 * y;

	while (y > 0)
	{
		if (d1 < 0)
		{
			d1 += (YRADIUS_SQ_2X * (x2 + 3));
			d2 += (YRADIUS_SQ_4X * (x + 1));
			++x;
		}
		else if (d2 < 0)
		{
			d1 += (YRADIUS_SQ_2X * (x2 + 3) - XRADIUS_SQ_4X * (y - 1));
			d2 += (YRADIUS_SQ_4X * (x + 1) - XRADIUS_SQ_2X * (y2 - 3));
			++x;
			--y;

			if (pFillColor)
			{
				FillEllipse(x, y, YRADIUS, MAX_WIDTH, ptCenter, *pFillColor);
			}
		}
		else
		{
			d1 -= (XRADIUS_SQ_4X * (y - 1));
			d2 -= (XRADIUS_SQ_2X * (y2 - 3));
			--y;

			if (pFillColor)
			{
				FillEllipse(x, y, YRADIUS, MAX_WIDTH, ptCenter, *pFillColor);
			}
		}

		SetPixel(ptCenter.x - x, ptCenter.y + y, color);
		SetPixel(ptCenter.x + x, ptCenter.y + y, color);
		SetPixel(ptCenter.x - x, ptCenter.y - y, color);
		SetPixel(ptCenter.x + x, ptCenter.y - y, color);

		x2 = 2 * x;
		y2 = 2 * y;

	}//end while

	EndUndo();
}

//---------------------------------------------------------------
//helper to test image boundaries
inline bool InBounds(int x, int y, int width, int height)
{
	return (x >= 0 && x < width && y >= 0 && y < height);
}

//-----------------------------------------------------------------------------
// Replaces all instances of old_color with fill_color until it encounters
// a pixel that is already the fill_color or not the old_color.
// This implementation is adapted from the Wikipedia "Flood Fill Example in C".
void CMrImageDoc::FloodFill(const CPoint & ptStart, const COLORREF & new_color,  const COLORREF & old_color)
{
	if (new_color == old_color)
	{
		return;
	}

	//if there is transparency
	//and the color being set is the transparent color
	//do nothing
	if (m_pImage->IsTransparent())
	{
		RGBQUAD rgb = m_pImage->GetTransColor();
		COLORREF trans(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
		if (trans == new_color)
		{
			return;
		}
	}

	BeginUndo();

	int x = ptStart.x;
	int y = ptStart.y;

	ASSERT(m_pImage);
	const int width = m_pImage->GetWidth();
	const int height = m_pImage->GetHeight();

	CPoint pt(x,y);
	std::queue<CPoint> q;

	if (InBounds(x,y,width,height))
	{
		q.push(pt);
	}

	while(!q.empty())
	{
		pt = q.front();
		q.pop();
		x = pt.x;
		y = pt.y;

		SetPixel(x, y, new_color);

		if (InBounds(x-1, y, width, height))
		{
			if (old_color == GetPixel(x - 1, y)) 
			{
				SetPixel (x-1, y, new_color);

				pt.x = x - 1;
				pt.y = y;
				q.push(pt);
			}
		}

		if (InBounds(x, y-1, width, height))
		{
			if (old_color == GetPixel (x, y-1)) 
			{
				SetPixel (x, y-1, new_color);

				pt.x = x;
				pt.y = y - 1;
				q.push(pt);
			}
		}

		if (InBounds(x+1, y, width, height))
		{
			if (old_color == GetPixel (x+1, y))
			{
				SetPixel (x+1, y, new_color);

				pt.x = x+1;
				pt.y = y;
				q.push(pt);
			}
		}

		if (InBounds(x, y+1, width, height))
		{
			if (old_color == GetPixel (x, y+1))
			{
				SetPixel (x, y+1, new_color);

				pt.x = x;
				pt.y = y + 1;
				q.push(pt);
			}
		}
	}//end while

	EndUndo();
}

//---------------------------------------------------------------
void CMrImageDoc::FillRectangle(const CPoint & ptStart, const CPoint & ptEnd, const COLORREF & color)
{
	BeginUndo();

	BYTE r = GetRValue(color);
	BYTE g = GetGValue(color);
	BYTE b = GetBValue(color);

	CPoint pt1(ptStart);
	CPoint pt2(ptEnd);

	for (int y = ptStart.y; y < ptEnd.y; ++y)
	{
		pt1.y = y;
		pt2.y = y;
		DrawLine(pt1, pt2, color);
	}

	EndUndo();
}

//---------------------------------------------------------------
BOOL CMrImageDoc::DrawText(const CPoint & ptTopLeft, const CString & strText, const CFont & font, COLORREF clr)
{
	BOOL ret = FALSE;
	ASSERT(m_pImage);
	
	CSize extent(0,0);

	//calculate the height offset for the text
	CDC dc;
	if (dc.CreateCompatibleDC(NULL))
	{
		dc.SelectObject((CFont*)&font);
		extent = dc.GetTextExtent(strText);
	}

	LOGFONT lf;
	memset(&lf, 0, sizeof(lf));
	if (((CFont &)font).GetLogFont(&lf))
	{
		ret = TRUE;
		RGBQUAD rgb;
		rgb.rgbRed = GetRValue(clr);
		rgb.rgbGreen = GetGValue(clr);
		rgb.rgbBlue = GetBValue(clr);
		
		BeginUndo();

		m_pImage->DrawString(	NULL,
							ptTopLeft.x,
							ptTopLeft.y + extent.cy,
							strText,
							rgb,
							lf.lfFaceName,
							lf.lfHeight,
							lf.lfWeight,
							lf.lfItalic,
							lf.lfUnderline,	
							false);

		EndUndo();
	}

	return ret;
}

//---------------------------------------------------------------
//Pixels that are not white in the mask are set within
//the current image to the specified color.
void CMrImageDoc::DrawPattern(const CPoint & ptTopLeft, CBitmap & bmpMask, COLORREF color)
{
	Image pattern;
	if (pattern.CreateFromHBITMAP((HBITMAP)bmpMask.GetSafeHandle()))
	{
		RGBQUAD newColor;
		newColor.rgbRed = GetRValue(color);
		newColor.rgbGreen = GetGValue(color);
		newColor.rgbBlue = GetBValue(color);

		RGBQUAD pixelColor;
		int x = ptTopLeft.x;
		int y = m_pImage->GetHeight()- ptTopLeft.y -1;
		CSize area(pattern.GetWidth(), pattern.GetHeight());
		
		BeginUndo();
		long iy = 0;
		for (long ix = 0; ix < area.cx; ix++)
		{
			for (iy = 0; iy < area.cy; iy++)
			{
				pixelColor = pattern.GetPixelColor(ix,iy);
				if (255 != pixelColor.rgbRed || 255 != pixelColor.rgbGreen || 255 != pixelColor.rgbBlue)
				{
					m_pImage->SetPixelColor(x+ix,y+iy,newColor,false);
				}
			}
		}
		EndUndo();
	}
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Crop(SELKEY key)
{
	ASSERT(m_pImage);
	
	BOOL ret = FALSE;

	CRect rcSelection(0,0,0,0);
	if (m_pImage->GetSelectionRect(key, rcSelection))
	{
		BeginUndo();

		if (m_pImage->MergeSelection(key))
		{
			ret = m_pImage->Crop(rcSelection);
		}

		EndUndo();
	}

	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageDoc::ResizeCanvas(const CSize & sizeCanvas)
{
	ASSERT(m_pImage);

	BeginUndo();

	BOOL ret = m_pImage->ResizeCanvas(sizeCanvas);

	EndUndo();

	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageDoc::GrayScale()
{
	return DoFilterTransform(FT_GRAYSCALE);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::GrayScale(SELKEY key)
{
	return DoFilterTransform(FT_GRAYSCALE, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Blur()
{
	return DoFilterTransform(FT_BLUR);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Blur(SELKEY key)
{
	return DoFilterTransform(FT_BLUR, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Emboss()
{
	return DoFilterTransform(FT_EMBOSS);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Emboss(SELKEY key)
{
	return DoFilterTransform(FT_EMBOSS, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Soften()
{
	return DoFilterTransform(FT_SOFTEN);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Soften(SELKEY key)
{
	return DoFilterTransform(FT_SOFTEN, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Sharpen()
{
	return DoFilterTransform(FT_SHARPEN);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Sharpen(SELKEY key)
{
	return DoFilterTransform(FT_SHARPEN, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Jitter()
{
	return DoFilterTransform(FT_JITTER);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Jitter(SELKEY key)
{
	return DoFilterTransform(FT_JITTER, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Contour()
{
	return DoFilterTransform(FT_CONTOUR);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Contour(SELKEY key)
{
	return DoFilterTransform(FT_CONTOUR, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Feather(UINT width)
{
	FILTERTRANSFORM_ARGS args;
	args.size.cx = width;
	return DoFilterTransform(FT_FEATHER, NULL, &args);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Feather(SELKEY key, UINT width)
{
	FILTERTRANSFORM_ARGS args;
	args.size.cx = width;
	return DoFilterTransform(FT_FEATHER, key, &args);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Flip()
{
	return DoFilterTransform(FT_FLIP);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Flip(SELKEY key)
{
	return DoFilterTransform(FT_FLIP, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Mirror()
{
	return DoFilterTransform(FT_MIRROR);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Mirror(SELKEY key)
{
	return DoFilterTransform(FT_MIRROR, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Negative()
{
	return DoFilterTransform(FT_NEGATIVE);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Negative(SELKEY key)
{
	return DoFilterTransform(FT_NEGATIVE, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::RotateLeft()
{
	return DoFilterTransform(FT_ROTATE_LEFT);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::RotateLeft(SELKEY key)
{
	return DoFilterTransform(FT_ROTATE_LEFT, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::RotateRight()
{
	return DoFilterTransform(FT_ROTATE_RIGHT);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::RotateRight(SELKEY key)
{
	return DoFilterTransform(FT_ROTATE_RIGHT, key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Resize(const CSize & s)
{
	FILTERTRANSFORM_ARGS args;
	args.size = s;
	return DoFilterTransform(FT_RESIZE, NULL, &args);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Resize(SELKEY key, const CSize & s)
{
	FILTERTRANSFORM_ARGS args;
	args.size = s;
	return DoFilterTransform(FT_RESIZE, key, &args);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Rotate(float angle)
{
	FILTERTRANSFORM_ARGS args;
	args.angle = angle;
	return DoFilterTransform(FT_ROTATE, NULL, &args);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Rotate(SELKEY key, float angle)
{
	FILTERTRANSFORM_ARGS args;
	args.angle = angle;
	return DoFilterTransform(FT_ROTATE, key, &args);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Brightness(short brightness)
{
	if (brightness < -255 || brightness > 255)
	{
		return FALSE;
	}

	FILTERTRANSFORM_ARGS args;
	args.brightness = brightness;
	return DoFilterTransform(FT_BRIGHTNESS, NULL, &args);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Brightness(SELKEY key, short brightness)
{
	if (brightness < -255 || brightness > 255)
	{
		return FALSE;
	}

	FILTERTRANSFORM_ARGS args;
	args.brightness = brightness;
	return DoFilterTransform(FT_BRIGHTNESS, key, &args);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Contrast(signed char contrast)
{
	if (contrast < -100 || contrast > 100)
	{
		return FALSE;
	}
	
	FILTERTRANSFORM_ARGS args;
	args.contrast = contrast;
	return DoFilterTransform(FT_CONTRAST, NULL, &args);
}
	
//---------------------------------------------------------------
BOOL CMrImageDoc::Contrast(SELKEY key, signed char contrast)
{
	if (contrast < -100 || contrast > 100)
	{
		return FALSE;
	}

	FILTERTRANSFORM_ARGS args;
	args.contrast = contrast;
	return DoFilterTransform(FT_CONTRAST, key, &args);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Skew(const CPoint & ptPivot, float horz, float vert)
{
	FILTERTRANSFORM_ARGS args;
	args.skew.pivot.x = ptPivot.x;
	args.skew.pivot.y = ptPivot.y;
	args.skew.horz = horz;
	args.skew.vert = vert;
	return DoFilterTransform(FT_SKEW, NULL, &args);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Skew(SELKEY key, const CPoint & ptPivot, float horz, float vert)
{
	FILTERTRANSFORM_ARGS args;
	args.skew.pivot.x = ptPivot.x;
	args.skew.pivot.y = ptPivot.y;
	args.skew.horz = horz;
	args.skew.vert = vert;
	return DoFilterTransform(FT_SKEW, key, &args);
}

//---------------------------------------------------------------
//Creates a mask of pImage.
//
//bIsSelection - if pImage is actually a base pointer to a Selection object set this to TRUE
//				and the mask will use the selection boundary and not the image boundary
//				Areas within the selection are set to white
//				and the area outside of the selection is set to black.
//
//				if pImage is not selection set this to FALSE,
//				Areas within the image is set to white and the outside border is black.
//
//unNumGrayTransitionBands - specified a number of bands that trace the inner portion
//							of pImage. Transition bands are lighter and lighter shades
//							of gray (darkest from the outside).
//							These are useful when creating a mask that is used for feathering.
//
//bBlurMask - set to TRUE if you want the mask blurred
//
//
void CMrImageDoc::CreateMask(CxImage * pImage, CxImage & mask, UINT unNumGrayTransitionBands, BOOL bBlurMask, BOOL bIsSelection)
{
	ASSERT(pImage);

	const long width = pImage->GetWidth();
	ASSERT(width == mask.GetWidth());
	const long height = pImage->GetHeight();
	ASSERT(height == mask.GetHeight());

	long xOffset = 0;
	long yOffset = 0;
	pImage->GetOffset(&xOffset, &yOffset);
	mask.SetOffset(xOffset, yOffset);

	Selection * pSelection = NULL;
	if (bIsSelection)
	{
		pSelection = dynamic_cast<Selection*>(pImage);
		ASSERT(pSelection);
	}

	COLORREF clrMaskedOut = RGB(0,0,0);
	COLORREF clrMaskedIn = RGB(255,255,255);

	//first, mark pixels that are inside or outside the mask
	//pixels inside are set to clrMaskedIn
	//pixels outside of selection are set to clrMaskedOut
	long x = 0, yFlipped = 0;

	for (long y = 0; y < height; ++y)
	{
		yFlipped = height - y - 1;
		for (x = 0; x < width; ++x)
		{
			if (pSelection)
			{
				if (pSelection->PointInSelection(CPoint(xOffset + x, yOffset + y)))
				{
					//in
					mask.SetPixelColor(x, yFlipped, clrMaskedIn);
				}
				else
				{
					//out
					mask.SetPixelColor(x, yFlipped, clrMaskedOut);
				}
			}
			else
			{
				//in
				mask.SetPixelColor(x, yFlipped, clrMaskedIn);
			}
		}//end for
	}//end for

	//now from top to bottom (for each line), walk the pixels horizontally.
	//if we find a maskedin pixel, set it to a grey color.
	//we are attempting to ring the inner portion of the mask
	//with a number of grey bands. The greys change from dark to light with
	//each band.
	RGBQUAD clr;
	int grey = 0;
	bool in = false;
	for (long k = 0; k < (long)unNumGrayTransitionBands; ++k)
	{
		grey = MulDiv(255, k, unNumGrayTransitionBands);

		//for each line, walk horiz
		for (y = 0; y < height; ++y)
		{
			in = false;
			yFlipped = height - y - 1;

			//ensure last pixel on this line is maskedout
			mask.SetPixelColor(width - 1, yFlipped, clrMaskedOut);

			for (x = 0; x < width; ++x)
			{
				clr = mask.GetPixelColor(x, yFlipped);
				if (clrMaskedIn == RGB(clr.rgbRed, clr.rgbGreen, clr.rgbBlue))
				{
					//in
					
					if (!in)
					{
						in = true;

						//set grey pixel
						memset(&clr, grey, sizeof(clr));
						mask.SetPixelColor(x, yFlipped, clr);
					}
				}
				else
				{
					//out

					if (in)
					{
						in = false;

						if (x > 0)
						{
							//set grey pixel
							memset(&clr, grey, sizeof(clr));
							mask.SetPixelColor(x - 1, yFlipped, clr);
						}
					}	
				}
			}//end for
		}//end for

		//for each column, walk vert
		for (x = 0; x < width; ++x)
		{
			in = false;

			//ensure last pixel in this column is maskedout
			mask.SetPixelColor(x, 0, clrMaskedOut);

			for (y = 0; y < height; ++y)
			{
				yFlipped = height - y - 1;
				clr = mask.GetPixelColor(x, yFlipped);

				if (clrMaskedIn == RGB(clr.rgbRed, clr.rgbGreen, clr.rgbBlue))
				{
					//in
					if (!in)
					{
						in = true;

						//set grey pixel
						memset(&clr, grey, sizeof(clr));
						mask.SetPixelColor(x, yFlipped, clr);
					}
				}
				else
				{
					//out

					if (in)
					{
						in = false;

						if (y > 0)
						{
							//set grey pixel
							memset(&clr, grey, sizeof(clr));
							mask.SetPixelColor(x, height - (y-1) - 1, clr);
						}
					}	
				}
			}//end for
		}//end for

	}//end for

	//now blur the mask - improves mask continuity
	if (bBlurMask)
	{
		long kernel[]={1,1,1,1,1,1,1,1,1};
		(void)pImage->Filter(kernel,3,9,0);
	}
}

//---------------------------------------------------------------
BOOL CMrImageDoc::DoFilterTransform(FILTERTRANSFORM_ENUM type, SELKEY key, FILTERTRANSFORM_ARGS * pArgs)
{
	ASSERT(m_pImage);

	BeginUndo();

	BOOL ret = FALSE;

	CxImage * pImage = m_pImage;

	if (key)
	{
		pImage = (CxImage*)m_pImage->GetSelection(key);
	}

	if (NULL == pImage)
	{
		return FALSE;
	}

	switch (type)
	{
		case FT_GRAYSCALE:
			ret = pImage->GrayScale();
		break;

		case FT_FLIP:
			ret = pImage->Flip();
		break;

		case FT_MIRROR:
			ret = pImage->Mirror();
		break;

		case FT_NEGATIVE:
			ret = pImage->Negative();
		break;

		case FT_ROTATE_LEFT:
			ret = pImage->RotateLeft();
		break;

		case FT_ROTATE_RIGHT:
			ret = pImage->RotateRight();
		break;

		case FT_RESIZE:
			ASSERT(pArgs);
			ret = pImage->Resample2(pArgs->size.cx, pArgs->size.cy);
		break;

		case FT_ROTATE:
			ASSERT(pArgs);
			ret = pImage->Rotate(pArgs->angle);
		break;

		case FT_BRIGHTNESS:
			ASSERT(pArgs);
			ret = pImage->Light(pArgs->brightness, 0);
		break;

		case FT_CONTRAST:
			ASSERT(pArgs);
			ret = pImage->Light((long)0, pArgs->contrast);
		break;

		case FT_BLUR:
		{
			long kernel[]={1,1,1,1,1,1,1,1,1};
			ret = pImage->Filter(kernel,3,9,0);
		}
		break;

		case FT_EMBOSS:
		{
			long kernel[]={0,0,-1,0,0,0,1,0,0};
			ret = pImage->Filter(kernel,3,0,127);
		}
		break;
/*
		case ID_CXIMAGE_GAUSSIAN3X3:
		{
			long kernel[]={1,2,1,2,4,2,1,2,1};
			ret = pImage->Filter(kernel,3,16,0);
		}
		break;

		case ID_CXIMAGE_GAUSSIAN5X5:
		{
			long kernel[]={0,1,2,1,0,1,3,4,3,1,2,4,8,4,2,1,3,4,3,1,0,1,2,1,0};
			ret = pImage->Filter(kernel,5,52,0);
		}
		break;

		case ID_CXIMAGE_EDGE:
		{
		long kernel[]={-1,-1,-1,-1,8,-1,-1,-1,-1};
		pDoc->image->Filter(kernel,3,-1,255);
		}
		break;
*/
		case FT_SOFTEN:
		{
			long kernel[]={1,1,1,1,8,1,1,1,1};
			ret = pImage->Filter(kernel,3,16,0);
		}
		break;

		case FT_SHARPEN:
		{
			long kernel[]={-1,-1,-1,-1,15,-1,-1,-1,-1};
			ret = pImage->Filter(kernel,3,7,0);
		}
		break;

		case FT_SKEW:
		{
			ASSERT(pArgs);
			ret = pImage->Skew(pArgs->skew.horz, pArgs->skew.vert, pArgs->skew.pivot.x, pArgs->skew.pivot.y);
		}
		break;

		case FT_FEATHER:
		{
			//In desktop publishing, feathering is the process of softening
			//the edges of an image in the foreground so that it blends into
			//the background image with less contrast.

			ASSERT(pArgs);

			//create the mask image
			const long width = pImage->GetWidth();
			const long height = pImage->GetHeight();
			CxImage mask(width, height, 24);
			mask.SetGrayPalette();
			CreateMask(pImage, mask, pArgs->size.cx, FALSE, (key != NULL)); 

			int weight = 0;
			long x = 0;
			long yFlipped = 0;
			long xOffset = 0;
			long yOffset = 0;
			
			if (key)
			{
				pImage->GetOffset(&xOffset,&yOffset);
			}

			RGBQUAD rgbFore;
			RGBQUAD rgbBack;
			RGBQUAD rgbMask;
			RGBQUAD rgbFeathered;

			//now that we have a mask, we weight the 
			//foreground color, background color, and mask color
			//to come up with a new feathered color
			for(long y = 0; y < height; ++y)
			{
				yFlipped = height - y - 1;

				for (long x = 0; x < width; ++x)
				{
					rgbFore = pImage->GetPixelColor(x, yFlipped);
					rgbMask = mask.GetPixelColor(x, yFlipped);

					if (key)
					{
						//if pImage is a selection
						//the background is whatever is underneath the selection.
						//AKA - pixels within the main image
						rgbBack = m_pImage->GetPixelColor(xOffset + x, m_pImage->GetHeight() - (yOffset + y) - 1);
					}
					else
					{
						//if pImage is not a selection
						//then the background color is WHITE
						memset(&rgbBack, 255, sizeof(rgbBack));
					}

					weight = rgbMask.rgbRed;
					rgbFeathered.rgbRed = (weight * rgbFore.rgbRed + (255-weight)* rgbBack.rgbRed) / 255;

					weight = rgbMask.rgbRed;
					rgbFeathered.rgbGreen = (weight * rgbFore.rgbGreen + (255-weight)* rgbBack.rgbGreen) / 255;

					weight = rgbMask.rgbRed;
					rgbFeathered.rgbBlue = (weight * rgbFore.rgbBlue + (255-weight)* rgbBack.rgbBlue) / 255;

					pImage->SetPixelColor(x, yFlipped, rgbFeathered);
				}//end for
			}//end for

			//debug - show the mask
			//pImage->Transfer(mask);

			ret = true;
		}
		break;

		case FT_JITTER:
			ret = pImage->Jitter();
		break;

		case FT_CONTOUR:
			ret = pImage->Contour();
		break;

		default:
			;//ignore
	}//end switch

	EndUndo();

	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageDoc::GetQuantizedPalette(std::vector<COLORREF> & colors)
{
	colors.clear();
	if (m_pImage)
	{
		CQuantizer q(256,8);
		if (q.ProcessImage(m_pImage->GetDIB()))
		{
			RGBQUAD* ppal=(RGBQUAD*)malloc(256*sizeof(RGBQUAD));
			if (ppal)
			{
				q.SetColorTable(ppal);
				RGBQUAD rgb;
				UINT total = q.GetColorCount();
				for (UINT i = 0; i < total; ++i)
				{
		 			rgb = ppal[i];
					colors.push_back(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
				}
				free(ppal);
				ppal = NULL;
			}
		}
	}
	return !colors.empty();
}

//---------------------------------------------------------------
BOOL CMrImageDoc::RedEyeRemove(SELKEY key)
{
	BOOL ret = FALSE;
	ASSERT(m_pImage);

	BeginUndo();
	
	RGBQUAD color;
	int x = 0;
	int selX = 0, selY = 0;
	CPoint pt;
	CRect rcArea;

	Selection * pSel = m_pImage->GetSelection(key);
	if (pSel)
	{
		const int selHeight = pSel->GetHeight();

		//get the bounding rect for the selection
		if (pSel->GetBoundingRect(rcArea))
		{
			for(int y = rcArea.top; y < rcArea.bottom; ++y)
			{
				for(x = rcArea.left; x < rcArea.right; ++x)
				{
					pt.x = x;
					pt.y = y;

					//test to see if the point is within the selection
					if (pSel->PointInSelection(pt))
					{
						selX = x - rcArea.left;
						selY = selHeight - (y - rcArea.top) - 1;
						color = pSel->GetPixelColor(selX, selY);
						color.rgbRed = min(color.rgbGreen,color.rgbBlue);
						pSel->SetPixelColor(selX, selY, color);
					}
				}
			}

			ret = TRUE;
		}
	}

	EndUndo();

	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Cut(SELKEY key)
{
	BOOL ret = FALSE;
	BeginUndo();
	ret = Copy(key);
	if (ret)
	{
		ret = DestroySelection(key);
	}
	EndUndo();
	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Copy(SELKEY key)const
{
	ASSERT(m_pImage);

	BOOL ret = FALSE;

	Selection * pSel = m_pImage->GetSelection(key);
	if (pSel)
	{
		HANDLE hDIB = pSel->CopyToHandle();
		if (hDIB)
		{
			if (::OpenClipboard(AfxGetMainWnd()->GetSafeHwnd())) 
			{
				if(::EmptyClipboard())
				{
					if (::SetClipboardData(CF_DIB,hDIB)) 
					{
						ret = TRUE;
					}   
				}
				
				VERIFY(CloseClipboard());
			}
			hDIB = NULL;
		}
	}
	return ret;
}

//---------------------------------------------------------------
//Creates a new selection and pastes the clipboard contents into it.
BOOL CMrImageDoc::Paste(SELKEY key)
{
	BOOL ret = FALSE;
	ASSERT(m_pImage);
	ASSERT(CMrImageDoc::CanPaste());
	HANDLE hBitmap=NULL;
	if (::OpenClipboard(AfxGetMainWnd()->GetSafeHwnd()))
	{
		hBitmap = ::GetClipboardData(CF_DIB);
		if (hBitmap)
		{
			BeginUndo();

			ret = m_pImage->CreateSelectionFromHandle(key, hBitmap);
			
			EndUndo();
		}
		VERIFY(CloseClipboard());
	}
	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageDoc::PasteAsNewImage()
{
	BOOL ret = FALSE;
	ASSERT(CMrImageDoc::CanPaste());
	CString strRegFileTypeName;
	CWinApp * pApp = AfxGetApp();
	ASSERT(pApp);
	CDocTemplate * pTemplate = NULL;
	POSITION pos = pApp->GetFirstDocTemplatePosition();
	while(pos)
	{
		pTemplate = pApp->GetNextDocTemplate(pos);
		if (pTemplate)
		{
			strRegFileTypeName.Empty();
			if (pTemplate->GetDocString(strRegFileTypeName, CDocTemplate::regFileTypeName))
			{
				if (strRegFileTypeName == _T("MrImage.Document"))
				{
					CDocument * pDoc = pTemplate->OpenDocumentFile(NULL);
					if (pDoc)
					{
						if (pDoc->IsKindOf(RUNTIME_CLASS(CMrImageDoc)))
						{
							CMrImageDoc * pImgDoc = (CMrImageDoc*)pDoc;
							if (pImgDoc)
							{
								POSITION pos = pImgDoc->GetFirstViewPosition();
								CView * pView = pImgDoc->GetNextView(pos);
								if (pView)
								{
									if (pView->IsKindOf(RUNTIME_CLASS(CMrImageView)))
									{
										CMrImageView * pImgView = (CMrImageView*)pView;
										if (pImgView)
										{
											ret = pImgDoc->Paste(pImgView->GetSelectionKey());
										}
									}
								}
							}
						}
					}							
					break;
				}
			}
		}
	}
	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageDoc::CanPaste()
{
	BOOL ret = FALSE;
	ret = IsClipboardFormatAvailable(CF_DIB);
	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageDoc::PointInSelection(SELKEY key, const CPoint & pt)const
{
	ASSERT(m_pImage);
	return m_pImage->PointInSelection(key, pt);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::GetSelectionRect(SELKEY key, CRect & rc)const
{
	ASSERT(m_pImage);
	return m_pImage->GetSelectionRect(key, rc);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::HasSelection(SELKEY key)const
{
	ASSERT(m_pImage);
	const Selection * pSel = m_pImage->GetSelection(key);
	return (NULL != pSel);
}


//---------------------------------------------------------------
BOOL CMrImageDoc::MoveSelection(SELKEY key, const CPoint & ptTopLeft)
{
	ASSERT(m_pImage);
	BOOL ret = m_pImage->MoveSelection(key, ptTopLeft);
	if (ret)
	{
		SetModifiedFlag(TRUE);
		UpdateAllViews(NULL);
	}
	return ret;
}

//---------------------------------------------------------------
SELKEY CMrImageDoc::CreateSelectionKey()const
{
	ASSERT(m_pImage);
	return m_pImage->CreateSelectionKey();
}

//---------------------------------------------------------------
BOOL CMrImageDoc::CreateSelection(SELKEY key, std::vector<POINT> & arrPoints, eSelectionType type)
{
	ASSERT(m_pImage);

	BeginUndo();

	BOOL ret = m_pImage->CreateSelection(key, arrPoints, (int)type);
	if (ret)
	{
		//now remove the area that was selected from the main image
		CRect rcSel(0,0,0,0);
		if (GetSelectionRect(key, rcSel))
		{
			int x = 0;
			CPoint pt;
			for (int y = rcSel.top; y <= rcSel.bottom; ++y)
			{
				pt.y = y;
				for (x = rcSel.left; x <= rcSel.right; ++x)
				{
					pt.x = x;
					if (PointInSelection(key, pt))
					{
						SetPixel(x, y, RGB(255,255,255));
					}
				}
			}
		}
	}

	EndUndo();

	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageDoc::DestroySelection(SELKEY key)
{
	return m_pImage->DestroySelection(key);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::MergeSelection(SELKEY key)
{
	ASSERT(m_pImage);

	BeginUndo();
	BOOL ret = m_pImage->MergeSelection(key);
	EndUndo();

	return ret;
}

//---------------------------------------------------------------
CMrImageDoc::eSelectionType CMrImageDoc::GetSelectionType(SELKEY key)const
{
	eSelectionType type = SEL_RECT;
	ASSERT(m_pImage);
	const Selection * pSel = m_pImage->GetSelection(key);
	ASSERT(pSel);
	if (pSel)
	{
		type = (eSelectionType)pSel->GetSelectionType();
	}
	return type;
}

//---------------------------------------------------------------
#ifdef _DEBUG
void CMrImageDoc::AssertValid() const
{
	CDocument::AssertValid();
}

//---------------------------------------------------------------
void CMrImageDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

//---------------------------------------------------------------
BOOL CMrImageDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	ClearUndoRedo();

	BOOL bRet = FALSE;

	if (m_pImage)
	{
		m_pImage->DestroyAllSelections();
		delete m_pImage;
		m_pImage = NULL;
	}

	CRect rc(0,0,320,240);
	m_pImage = new Image(rc.Width(), rc.Height(), 32);
	if (m_pImage)
	{
		bRet = TRUE;
	}
	return bRet;
}

//---------------------------------------------------------------
BOOL CMrImageDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	BOOL ret = CDocument::OnOpenDocument(lpszPathName);
	if (ret)
	{
		char filename[256];		
		CRawDlg dlg;
		VOIDARGU argument;

		memset(filename, 0, 256);
		memcpy(filename, lpszPathName, strlen(lpszPathName));

		ClearUndoRedo();

		ret = FALSE;

		if (m_pImage)
		{
			m_pImage->DestroyAllSelections();
			delete m_pImage;
			m_pImage = NULL;
		}

		m_pImage = new Image();
		if (m_pImage)
		{
			int type = GetImageType(filename);

			if(type==CXIMAGE_FORMAT_YUV)
			{
				/*
				#define YUV_PACKED 0
				#define YUV_PLANAR 1

				#define YUV_420 0
				#define YUV_422 1
				#define YUV_444 2

				#define YUV_INTERLACED  0
				#define YUV_PROGRESSIVE 1
				*/
				
				dlg.m_dlgStart = DLG_OPEN_YUV;
				dlg.m_heightValue = 0;
				dlg.m_widthValue = 0;

				if(dlg.DoModal()==IDOK)
				{
					int length;					

					argument.arg2 = dlg.m_heightValue;
					argument.arg3 = dlg.m_widthValue;
					argument.arg4 = dlg.m_sampleFormat;
					argument.arg5 = dlg.m_packed;
					argument.arg6 = dlg.m_interlaced;
					//argument.arg7 = filesize;
					//argument.arg0 = filename;

					if( (m_pImage->GetWidth()%16)!=0 || (m_pImage->GetHeight()%16!=0))
					{
						AfxMessageBox("������ Width/Height ��� 16����� ���ڵ� ������\nreSize�޴����� ������ �ٲټ���", MB_YESNO|MB_ICONSTOP);
						return false;
					}
					// CxImageRAW::DecodeYUV()�Լ����� YUV������ .smt���Ϸ� �ٲ㼭 rgb888�� �����Ѵ�
					ret = m_pImage->Load(filename, type, &argument);


					if(ret==true)
					{
						length = strlen(filename);
						filename[length-3] = 's';
						filename[length-2] = 'm';
						filename[length-1] = 't';
						
						argument.arg7 = 0;
						argument.arg6 = 0;
						argument.arg5 = 0;
						argument.arg4 = argument.arg3;
						argument.arg3 = argument.arg2;
						argument.arg2 = 24;

						ret = m_pImage->Load(filename, CXIMAGE_FORMAT_RAW, &argument);

						DeleteFile(filename);
					}
					else
						return false;
				}
			}
			
			else if(type==CXIMAGE_FORMAT_RAW)
			{
				dlg.m_dlgStart = DLG_OPEN_RGB;

				dlg.m_widthValue  = 480;
				dlg.m_heightValue = 272;

				if(dlg.DoModal()==IDOK)
				{
					argument.arg2 = dlg.m_method;
					argument.arg3 = dlg.m_heightValue;
					argument.arg4 = dlg.m_widthValue;
					argument.arg5 = dlg.m_RmaskValue;
					argument.arg6 = dlg.m_GmaskValue;
					argument.arg7 = dlg.m_BmaskValue;

					ret = m_pImage->Load(filename, type, &argument);
				}
			}
			else
			{
				ret = m_pImage->Load(filename, type);
			}

			if (ret)
			{
				//loaded image successfully
			}
			else
			{
				m_pImage->DestroyAllSelections();
				delete m_pImage;
				m_pImage = NULL;

				CString msg;
				msg.Format(IDS_FAILEDTODECODEFILE, filename);
				AfxMessageBox(msg, MB_ICONERROR);
			}
		}
	}

	return ret;
}

//---------------------------------------------------------------
void CMrImageDoc::OnCloseDocument()
{
	ClearUndoRedo();

	if (m_pImage)
	{
		m_pImage->DestroyAllSelections();
		delete m_pImage;
		m_pImage = NULL;
	}

	CDocument::OnCloseDocument();
}

//---------------------------------------------------------------
BOOL CMrImageDoc::OnSaveDocument(LPCTSTR lpszPathName)
{
	ASSERT(m_pImage);

	//in order to save the image we have to merge all selections
	//but that means that the image loses its selections
	//so instead we create a copy of the image, merge the copy's selections,
	//and then save the copy
	Image copy(*m_pImage);

	(void)copy.MergeAllSelections();

	DWORD type = GetImageType(lpszPathName);

	VOIDARGU argument;
	
	CRawDlg dlg;

	dlg.m_widthValue  = m_pImage->GetWidth();
	dlg.m_heightValue = m_pImage->GetHeight();

	if(type==CXIMAGE_FORMAT_RAW)
	{
		dlg.m_dlgStart = DLG_SAVE_RGB;

		if(dlg.DoModal()==IDOK)
		{
			argument.arg2 = dlg.m_method;
			argument.arg3 = dlg.m_heightValue;
			argument.arg4 = dlg.m_widthValue;
			argument.arg5 = dlg.m_RmaskValue;
			argument.arg6 = dlg.m_GmaskValue;
			argument.arg7 = dlg.m_BmaskValue;
		}
		else
		{
			return FALSE;
		}

		if (copy.Save(lpszPathName, type, &argument))
		{
			SetModifiedFlag(FALSE);
		}
		else
		{
			AfxMessageBox(m_pImage->GetLastError(), MB_ICONERROR);

			//trigger a SaveAs
			AfxGetMainWnd()->PostMessage(WM_COMMAND, MAKEWPARAM(ID_FILE_SAVE_AS, 0), 0);
		}
	}
	else if(type==CXIMAGE_FORMAT_YUV)
	{	
		dlg.m_dlgStart = DLG_SAVE_YUV;
		if(dlg.DoModal()==IDOK)
		{
			argument.arg2 = dlg.m_heightValue;
			argument.arg3 = dlg.m_widthValue;
			argument.arg4 = dlg.m_packed;
			argument.arg5 = dlg.m_sampleFormat;
			argument.arg6 = dlg.m_interlaced;

		}
		else
		{
			return FALSE;
		}

		if( (m_pImage->GetWidth()%16)!=0 || (m_pImage->GetHeight()%16!=0))
		{
			AfxMessageBox("������ Width/Height ��� 16����� ���ڵ� ������", MB_YESNO|MB_ICONSTOP);
			return false;
		}

		if (copy.Save(lpszPathName, type, &argument))
		{
			SetModifiedFlag(FALSE);
		}
		else
		{
			AfxMessageBox(copy.GetLastError(), MB_ICONERROR);
			return false;

			//trigger a SaveAs
			AfxGetMainWnd()->PostMessage(WM_COMMAND, MAKEWPARAM(ID_FILE_SAVE_AS, 0), 0);
		}
	}
	else
	{
		if (copy.Save(lpszPathName, type))
		{
			SetModifiedFlag(FALSE);
		}
		else
		{
			AfxMessageBox(m_pImage->GetLastError(), MB_ICONERROR);

			//trigger a SaveAs
			AfxGetMainWnd()->PostMessage(WM_COMMAND, MAKEWPARAM(ID_FILE_SAVE_AS, 0), 0);
		}
	}
	return TRUE;
}


//---------------------------------------------------------------
void CMrImageDoc::OnViewImageAttributes()
{
	ASSERT(m_pImage);
	
	CString strAttributes;

	//get the file name
	TCHAR fname[_MAX_FNAME];
	TCHAR ext[_MAX_EXT];
	_tsplitpath(GetPathName(), NULL, NULL, fname, ext);
	
	CString temp;
	temp.Format(IDS_FILENAMEEXT, fname, ext);
	strAttributes += temp;
	strAttributes += _T("\r");

	//get the width and height
	temp.Format(IDS_WIDTHHEIGHTPIXELS, m_pImage->GetWidth(), m_pImage->GetHeight());
	strAttributes += temp;
	strAttributes += _T("\r");

	//get the bits per pixel
	temp.Format(IDS_BITSPERPIXEL, m_pImage->GetBpp());
	strAttributes += temp;
	strAttributes += _T("\r");

	DWORD dwType = m_pImage->GetType();
	switch(dwType)
	{
		case CXIMAGE_FORMAT_JPG:
		case CXIMAGE_FORMAT_TIF:
		case CXIMAGE_FORMAT_PNG:
		case CXIMAGE_FORMAT_BMP:
		{
			//get the resolution
			int xDPI = m_pImage->GetXDPI();
			int yDPI = m_pImage->GetYDPI();
			temp.Format(IDS_DPI, xDPI, yDPI);
			strAttributes += temp;
			strAttributes += _T("\r");
		}
		break;

		case CXIMAGE_FORMAT_GIF:
		case CXIMAGE_FORMAT_ICO:
		case CXIMAGE_FORMAT_TGA:
		case CXIMAGE_FORMAT_PCX:
		case CXIMAGE_FORMAT_WBMP:
		case CXIMAGE_FORMAT_WMF:
		case CXIMAGE_FORMAT_JP2:
		case CXIMAGE_FORMAT_JPC:
		case CXIMAGE_FORMAT_PGX:
		case CXIMAGE_FORMAT_RAS:
		case CXIMAGE_FORMAT_PNM:
		case CXIMAGE_FORMAT_UNKNOWN:
		default:
			;//ignore
	}//end switch

	//get the color type
	switch(m_pImage->GetColorType())
	{
		case 1:
			VERIFY(temp.LoadString(IDS_TYPE_INDEXED));
			strAttributes += temp;
			strAttributes += _T("\r");
		break;

		case 2:
			VERIFY(temp.LoadString(IDS_TYPE_RGB));
			strAttributes += temp;
			strAttributes += _T("\r");
		break;

		case 4:
			VERIFY(temp.LoadString(IDS_TYPE_RGBA));
			strAttributes += temp;
			strAttributes += _T("\r");
		break;

		default:
			;//ignore
	}//end switch
    
	AfxMessageBox(strAttributes, MB_OK | MB_ICONINFORMATION);
}

//---------------------------------------------------------------
BOOL CMrImageDoc::SetTransColorIndex(const CPoint & point)
{
	ASSERT(m_pImage);
	BOOL ret = m_pImage->IsInside(point.x, point.y);
	if (ret)
	{
		BeginUndo();
		long yflip = m_pImage->GetHeight() - point.y - 1;
		m_pImage->SetTransIndex(m_pImage->GetPixelIndex(point.x,yflip));
		m_pImage->SetTransColor(m_pImage->GetPixelColor(point.x,yflip));
		EndUndo();
	}
	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageDoc::Nudge(SELKEY key, eNudge dir)
{
	BOOL ret = FALSE;
	ASSERT(m_pImage);
	Selection * pSel = m_pImage->GetSelection(key);
	if (pSel)
	{
		ret = TRUE;
		long x = 0, y = 0;
		pSel->GetOffset(&x, &y);
		switch(dir)
		{
			case NUDGE_LEFT:
				x -= 1;
			break;
			case NUDGE_RIGHT:
				x += 1;
			break;
			case NUDGE_UP:
				y -= 1;
			break;
			case NUDGE_DOWN:
				y += 1;
			break;

			default:
				ret = FALSE;
		}//end switch
		
		if (ret)
		{
			if (m_pImage->IsInside(x,y))
			{
				BeginUndo();
				pSel->SetOffset(x,y);
				EndUndo();
			}
		}
	}
	return ret;
}

//---------------------------------------------------------------
//-----------------------------------------------------------------------------
//---------------------------------------------------------------
}//end namespace


