// Author: Keith Rule
// Email:  keithr@europa.com
// Copyright 1996-2002, Keith Rule
//
// You may freely use or modify this code provided this
// Copyright is included in all derived versions.

#ifndef MEMDC_H
#define MEMDC_H

#pragma once

namespace MrImage
{

class CMemDC : public CDC 
{
private:    
    CBitmap  m_bitmap;       // Offscreen bitmap
    CBitmap* m_oldBitmap;    // bitmap originally found in CMemDC
    CDC*     m_pDC;          // Saves CDC passed in constructor
    CRect    m_rect;         // Rectangle of drawing area.
    BOOL     m_bMemDC;       // TRUE if CDC really is a Memory DC.

	CMemDC();
public:
    
    explicit CMemDC(CDC* pDC, const CRect* pRect = NULL) 
	: CDC()
	, m_bitmap()
	, m_oldBitmap(NULL)
	, m_pDC(NULL)
	, m_rect(0,0,0,0)
	, m_bMemDC(FALSE)
    {
        ASSERT(pDC != NULL); 

        // Some initialization
        m_pDC = pDC;
        m_oldBitmap = NULL;
        m_bMemDC = !pDC->IsPrinting();

        // Get the rectangle to draw
        if (pRect == NULL)
		{
            (void)pDC->GetClipBox(&m_rect);
        }
		else
		{
            m_rect = *pRect;
        }
        
        if (m_bMemDC)
		{
            // Create a Memory DC
            VERIFY(CreateCompatibleDC(pDC));
            pDC->LPtoDP(&m_rect);

            VERIFY(m_bitmap.CreateCompatibleBitmap(pDC, m_rect.Width(), m_rect.Height()));
            m_oldBitmap = SelectObject(&m_bitmap);
            
            (void)CMemDC::SetMapMode(pDC->GetMapMode());
            pDC->DPtoLP(&m_rect);
            (void)SetWindowOrg(m_rect.left, m_rect.top);
        }
		else
		{
            // Make a copy of the relevent parts of the current DC for printing
            m_bPrinting = pDC->m_bPrinting;
            m_hDC       = pDC->m_hDC;
            m_hAttribDC = pDC->m_hAttribDC;
        }

        // Fill background 
        FillSolidRect(m_rect, pDC->GetBkColor());
    }
    
    virtual ~CMemDC()    
    {       
		try
		{
			if (m_bMemDC) 
			{
				//MP - fix for better quality when image is zoomed out
				m_pDC->SetStretchBltMode(COLORONCOLOR);

				// Copy the offscreen bitmap onto the screen.
				VERIFY(m_pDC->BitBlt(m_rect.left, m_rect.top, m_rect.Width(), m_rect.Height(),
					this, m_rect.left, m_rect.top, SRCCOPY));            
            
				//Swap back the original bitmap.
				(void)SelectObject(m_oldBitmap);        
			}
			else 
			{
				// All we need to do is replace the DC with an illegal value,
				// this keeps us from accidently deleting the handles associated with
				// the CDC that was passed to the constructor.            
				m_hDC = m_hAttribDC = NULL;
			} 
			
			m_oldBitmap = NULL;
			m_pDC = NULL;
		}
		catch(...)
		{
		}
    }
    
    // Allow usage as a pointer    
    CMemDC* operator->(){ return this; }    

    // Allow usage as a pointer    
    operator CMemDC*(){ return this; }
};

}//end namespace

#endif MEMDC_H