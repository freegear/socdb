/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/
#pragma once

#include "ColorPicker.h"
#include "FgBgSwitcher.h"

namespace MrImage
{

class CColorPickerBar : public CSizingControlBarG
{
	DECLARE_DYNAMIC(CColorPickerBar)

public:
	CColorPickerBar();
	virtual ~CColorPickerBar();

	void SetForegroundColor(const COLORREF & color){ m_FgBgSwitcher.SetForegroundColor(color); }
	COLORREF GetForegroundColor()const { return m_FgBgSwitcher.GetForegroundColor(); }
	void SetBackgroundColor(const COLORREF & color){ m_FgBgSwitcher.SetBackgroundColor(color); }
	COLORREF GetBackgroundColor()const { return m_FgBgSwitcher.GetBackgroundColor(); }
	void SetColorSize(const CSize & size){ m_Picker.SetColorSize(size); }

protected:
	DECLARE_MESSAGE_MAP()

	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSelchangeTab(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg LRESULT OnColorPickerSelectionChange (WPARAM wUnused, LPARAM lMouseBtnClicked);
	afx_msg LRESULT OnFgBgSwitcherColorSwap (WPARAM, LPARAM);

	void NotifySelectionChange(COLORREF color, bool isForeground);

private:
	CColorPicker m_Picker;
	CTabCtrl m_Tab;
	CFgBgSwitcher m_FgBgSwitcher;
};
																		   
}//end namespace
