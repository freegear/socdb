/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#pragma once
#include "CxImage/CxImage/ximage.h"
#include <map>
#include <vector>

namespace MrImage
{

class Selection
:public CxImage
{
private:
	Selection();
public:
	Selection(const Selection & rhs);
	explicit Selection(const CxImage & rhs);
	virtual ~Selection();
	Selection & operator=(const Selection & rhs);
	void Render(CDC * pDC);
	
	//type: 0 = rect, 1 = ellipse, 2 = polygon
	BOOL Create(std::vector<POINT> & pts, int type);
	BOOL GetBoundingRect(CRect & rc)const;
	BOOL PointInSelection(const CPoint & pt)const;

	int GetSelectionType()const { return m_type; }
private:
	HRGN m_hRgn;
	const CxImage * m_pParent;
	int m_type;
};

class Image 
:public CxImage
{
public:
	Image();
	Image(const Image & rhs);
	Image(DWORD dwWidth, DWORD dwHeight, DWORD wBpp, DWORD imagetype = 0);
	virtual ~Image(void);

	void Render(CDC * pDC);

	SELKEY CreateSelectionKey()const;
	BOOL CreateSelection(SELKEY key, std::vector<POINT> & arrPoints, int type);
	BOOL CreateSelectionFromHandle(SELKEY key, HANDLE hBitmap);
	BOOL DestroySelection(SELKEY key);
	void DestroyAllSelections();
	Selection * GetSelection(SELKEY key);
	const Selection * GetSelection(SELKEY key)const;
	BOOL PointInSelection(SELKEY key, const CPoint & pt)const;
	BOOL GetSelectionRect(SELKEY key, CRect & rc)const;
	BOOL MoveSelection(SELKEY key, const CPoint & ptTopLeft);
	BOOL MergeSelection(SELKEY key);
	BOOL MergeAllSelections();
	BOOL ResizeCanvas(const CSize & sizeCanvas);
private:

	//last selection key returned
	mutable SELKEY m_lastSelectionKey;

	typedef std::map<SELKEY, Selection*> SELMAP;
	typedef SELMAP::iterator SELMAP_ITER;
	typedef SELMAP::const_iterator SELMAP_CITER;
	SELMAP m_mapSelections;
};

}//end namespace