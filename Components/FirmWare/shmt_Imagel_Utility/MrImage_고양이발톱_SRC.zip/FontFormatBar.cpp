/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "FontFormatBar.h"
#include "resource.h"
namespace MrImage
{

const int DROPDOWNHEIGHT = 200;

IMPLEMENT_DYNAMIC(CFontFormatBar, CToolBar)

//---------------------------------------------------------------
CFontFormatBar::CFontFormatBar()
:m_cboFontName()
,m_cboFontSize()
{
}

//---------------------------------------------------------------
CFontFormatBar::~CFontFormatBar()
{
}


//---------------------------------------------------------------
BEGIN_MESSAGE_MAP(CFontFormatBar, CToolBar)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_CBN_SELENDOK(ID_FONTNAME, OnSelectFontName)
	ON_CBN_SELENDOK(ID_FONTSIZE, OnSelectFontSize)
END_MESSAGE_MAP()

//---------------------------------------------------------------
int CFontFormatBar::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CToolBar::OnCreate(lpCreateStruct) == -1)
		return -1;

	// Load the toolbar
	if( !LoadToolBar( IDR_FONTFORMAT_TOOLBAR ) )
		return -1;

	//determine width of font name combo
	CClientDC dc(this);

	HGDIOBJ hFont = GetStockObject( DEFAULT_GUI_FONT );
	CFont font;
	font.Attach( hFont );
	dc.SelectObject( font );

	//longest font name is 32 chars wide
	//but use 16 since it seems to be the right width for the toolbar
	CString str(_T("WWWWWWWWWWWWWWWW"));
	CSize sizeFontName = dc.GetTextExtent(str);
	//add in dropdown button width
	sizeFontName.cx += GetSystemMetrics(SM_CXVSCROLL);

	//setup fontname toolbar item
	CRect rect; 
	GetItemRect( CommandToIndex(ID_FONTNAME), &rect );
	rect.right = rect.left + sizeFontName.cx;
	rect.bottom = rect.top + sizeFontName.cy + DROPDOWNHEIGHT;

	SetButtonInfo( CommandToIndex(ID_FONTNAME), ID_FONTNAME, TBBS_SEPARATOR, rect.Width() );

	// Create the Font Name combo
	if (!m_cboFontName.Create(WS_CHILD | WS_VISIBLE | CBS_HASSTRINGS | WS_VSCROLL | CBS_DROPDOWNLIST | CBS_SORT, rect, this, ID_FONTNAME))
	{
		TRACE(_T("Failed to create the font name combo!\n"));
		return -1;
	}

	m_cboFontName.EnableWindow(FALSE);

	//determine width of font size combo 

	//longest font size is 2 digits wide 
	//but we'll use a bit more for good measure
	str = _T("XXXX");
	CSize sizeFontSize = dc.GetTextExtent(str);
	//add in dropdown button width
	sizeFontSize.cx += GetSystemMetrics(SM_CXVSCROLL);

	//setup fontsize toolbar item
	GetItemRect( CommandToIndex(ID_FONTSIZE), &rect );
	rect.right = rect.left + sizeFontSize.cx;
	rect.bottom = rect.top + sizeFontSize.cy + DROPDOWNHEIGHT;

	SetButtonInfo( CommandToIndex(ID_FONTSIZE), ID_FONTSIZE, TBBS_SEPARATOR, rect.Width() );

	// Create the Font Size combo
	if (!m_cboFontSize.Create(WS_CHILD | WS_VISIBLE | CBS_HASSTRINGS | WS_VSCROLL | CBS_DROPDOWNLIST | CBS_SORT, rect, this, ID_FONTSIZE))
	{
		TRACE(_T("Failed to create the font size combo!\n"));
		return -1;
	}
	m_cboFontSize.LimitText(4);
	m_cboFontSize.EnableWindow(FALSE);

	// Fill the Font names in the Font Name combo
	::EnumFontFamilies( dc.GetSafeHdc(), NULL, (FONTENUMPROC)EnumFontFamProc, (LPARAM) this );

	//select the first font name
	m_cboFontName.SetCurSel(m_cboFontName.GetTopIndex());

	//trigger the refreshing of the font sizes
	OnSelectFontName();

	return 0;
}

//---------------------------------------------------------------
void CFontFormatBar::OnDestroy()
{
	CToolBar::OnDestroy();
}

//---------------------------------------------------------------
void CFontFormatBar::OnSelectFontName()
{
	TRACE(_T("Font Name Changed!\n"));
	
	int nCurSel = m_cboFontName.GetCurSel();
	if (nCurSel > -1)
	{
		m_cboFontSize.ResetContent();
		CString strFaceName;
		m_cboFontName.GetLBText(nCurSel, strFaceName);
		if (!strFaceName.IsEmpty())
		{
			LOGFONT lf;
			memset(&lf, 0, sizeof(lf));
			lf.lfCharSet = DEFAULT_CHARSET;
			lstrcpy(lf.lfFaceName, strFaceName);
			CClientDC dc(this);
			(void)EnumFontFamiliesEx(dc.GetSafeHdc(), &lf, (FONTENUMPROC)EnumFontSizesProc,(LPARAM)this, 0);

			//select the first one
			m_cboFontSize.SetCurSel(m_cboFontSize.GetTopIndex());
			
			//notify
			CWnd * pOwner = GetOwner();
			if (pOwner)
			{
				pOwner->SendMessage(WM_COMMAND, MAKEWPARAM(ID_FONTNAME,0), (LPARAM)NULL);
			}
		}
	}
}

//---------------------------------------------------------------
CString CFontFormatBar::GetSelectedFontName()const
{
	CString strFaceName;
	if (::IsWindow(m_cboFontName.m_hWnd))
	{
		int nCurSel = m_cboFontName.GetCurSel();
		if (nCurSel > -1)
		{
			m_cboFontName.GetLBText(nCurSel, strFaceName);
		}
	}
	return strFaceName;
}

//---------------------------------------------------------------
BOOL CFontFormatBar::SetSelectedFontName(LPCTSTR szFontName)
{
	BOOL ret = FALSE;
	if (::IsWindow(m_cboFontName.m_hWnd))
	{
		int nCurSel = m_cboFontName.FindStringExact(0, szFontName);
		if (nCurSel > -1)
		{
			m_cboFontName.SetCurSel(nCurSel);
			ret = TRUE;
		}
	}
	return ret;
}

//---------------------------------------------------------------
void CFontFormatBar::OnSelectFontSize()
{
	TRACE(_T("Font Size Changed!\n"));

	//notify
	CWnd * pOwner = GetOwner();
	if (pOwner)
	{
		pOwner->SendMessage(WM_COMMAND, MAKEWPARAM(ID_FONTSIZE,0), (LPARAM)NULL);
	}
}

//---------------------------------------------------------------
int CFontFormatBar::GetSelectedFontPointSize()const
{
	int nPointSize = -1;
	if (::IsWindow(m_cboFontSize.m_hWnd))
	{
		int nCurSel = m_cboFontSize.GetCurSel();
		if (nCurSel > -1)
		{
			nPointSize = (int)m_cboFontSize.GetItemData(nCurSel);
		}
	}
	return nPointSize;
}

//---------------------------------------------------------------
BOOL CFontFormatBar::SetSelectedFontPointSize(int size)
{
	BOOL ret = FALSE;

	if (::IsWindow(m_cboFontSize.m_hWnd))
	{
		CString strSize;
		strSize.Format(_T("%2d"), size);
		int nCurSel = m_cboFontSize.FindStringExact(0, strSize);
		if (nCurSel > -1)
		{
			m_cboFontSize.SetCurSel(nCurSel);
			ret = TRUE;
		}
	}
	return ret;
}

//---------------------------------------------------------------
int CALLBACK CFontFormatBar::EnumFontFamProc(ENUMLOGFONT *lpelf, NEWTEXTMETRIC *lpntm,
										 int nFontType, LPARAM lParam)
{
	CFontFormatBar* pWnd = (CFontFormatBar*)lParam;

	// Add the font name to the combo
	pWnd->m_cboFontName.AddString(lpelf->elfLogFont.lfFaceName);

	return 1;		// 1 to continue enumeration
}

//---------------------------------------------------------------
int CALLBACK CFontFormatBar::EnumFontSizesProc(	ENUMLOGFONTEX  *lpelfe,	TEXTMETRIC *lpntme,
												int FontType, LPARAM lParam)
{
	int ret = 0;

	static int truetypesize[] = { 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26,	28, 36, 48, 72 };
	static TCHAR sizestr[256];

	CFontFormatBar* pWnd = (CFontFormatBar*)lParam;

	if(FontType == TRUETYPE_FONTTYPE)
	{
		int index = 0;
		for(int i = 0; i < (sizeof(truetypesize) / sizeof(truetypesize[0])); i++)
		{
			wsprintf(sizestr, _T("%2d"), truetypesize[i]);

			index = pWnd->m_cboFontSize.AddString(sizestr);
			if (index > -1)
			{
				pWnd->m_cboFontSize.SetItemData(index, truetypesize[i]);
			}
		}

		ret = 0;
	}
	else
	{
		/* work out the point size */

		int fontsize = lpntme->tmHeight - lpntme->tmInternalLeading;

		CClientDC dc(pWnd);
		int pixelsperinch = GetDeviceCaps(dc.GetSafeHdc(), LOGPIXELSY);
		long lsize = MulDiv(fontsize, 72, pixelsperinch);

		wsprintf(sizestr, _T("%2d"), lsize);
		if (-1 == pWnd->m_cboFontSize.FindStringExact(0, sizestr))
		{
			int index = pWnd->m_cboFontSize.AddString(sizestr);
			if (index > -1)
			{
				pWnd->m_cboFontSize.SetItemData(index, lsize);
			}
		}
		ret = 1;
	}

	return ret;
}


//---------------------------------------------------------------
//---------------------------------------------------------------
}//end namespace

