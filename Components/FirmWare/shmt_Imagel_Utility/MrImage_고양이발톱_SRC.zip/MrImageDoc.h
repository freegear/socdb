/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/
#pragma once

#include <vector>
#include <stack>
#include <map>

class CxImage;

namespace MrImage
{

typedef struct tagVOIDARGU
{
	char    *arg0;
	char    *arg1;
	int     arg2;
	int     arg3;
	int     arg4;
	int     arg5;
	int     arg6;
	int     arg7;
	int     arg8;
	int     arg9;
} VOIDARGU;

class Image;

class CMrImageDoc 
: public CDocument
{
protected: // create from serialization only
	CMrImageDoc();
	DECLARE_DYNCREATE(CMrImageDoc)

public:
	virtual ~CMrImageDoc();

	virtual BOOL OnNewDocument();
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void OnCloseDocument();
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual void SetModifiedFlag(BOOL bModified);	

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	//Render the current image to a device context
	void Render(CDC * pDC);

	//Size of the document in pixels
	CSize GetSize()const;

	//Pixel manipulation
	COLORREF GetPixel(int x, int y)const;
	COLORREF GetPixel(const CPoint & pt)const { return GetPixel(pt.x,pt.y); }
	void SetPixel(int x, int y, const COLORREF & color);
	void SetPixel(const CPoint & pt, const COLORREF & color){ SetPixel(pt.x, pt.y, color); }

	//Drawing fundamentals
	void DrawLine(const CPoint & ptStart, const CPoint & ptEnd, const COLORREF & color);
	void DrawEllipse(const CRect & rc, const COLORREF & color, const COLORREF * pFillColor = NULL);
	void FillEllipse(int x, int y, int YRADIUS, int MAX_WIDTH, const CPoint & ptCenter, const COLORREF & fillColor);
	void FloodFill(const CPoint & ptStart, const COLORREF & color,  const COLORREF & old);
	void DrawRectangle(const CPoint & ptStart, const CPoint & ptEnd, const COLORREF & color);
	void FillRectangle(const CPoint & ptStart, const CPoint & ptEnd, const COLORREF & color);
	BOOL DrawText(const CPoint & ptTopLeft, const CString & strText, const CFont & font, COLORREF clr);
	void DrawPattern(const CPoint & ptTopLeft, CBitmap & bmpMask, COLORREF color);

	//retrieve an 8-bit quantization of the image palette
	BOOL GetQuantizedPalette(std::vector<COLORREF> & colors);

	//Crop to a selection
	BOOL Crop(SELKEY key);

	//Resize the border area of the image
	BOOL ResizeCanvas(const CSize & sizeCanvas);

	//Removes the red-eye effect that is common in images
	BOOL RedEyeRemove(SELKEY key);
	
	BOOL Blur();
	BOOL Blur(SELKEY key);

	BOOL Emboss();
	BOOL Emboss(SELKEY key);

	BOOL Soften();
	BOOL Soften(SELKEY key);

	BOOL Sharpen();
	BOOL Sharpen(SELKEY key);

	BOOL Jitter();
	BOOL Jitter(SELKEY key);

	BOOL Contour();
	BOOL Contour(SELKEY key);

	BOOL Feather(UINT width);
	BOOL Feather(SELKEY key, UINT width);

	BOOL GrayScale();
	BOOL GrayScale(SELKEY key);

	//Resize the image or selection
	BOOL Resize(const CSize & size);
	BOOL Resize(SELKEY key, const CSize & size);

	BOOL Flip();
	BOOL Flip(SELKEY key);

	BOOL Mirror();
	BOOL Mirror(SELKEY key);

	BOOL Negative();
	BOOL Negative(SELKEY key);

	BOOL Rotate(float angle);
	BOOL Rotate(SELKEY key, float angle);

	//Rotate 90 degrees to the left
	BOOL RotateLeft(SELKEY key);
	BOOL RotateLeft();

	//Rotate 90 degrees to the right
	BOOL RotateRight();
	BOOL RotateRight(SELKEY key);

	//brightness value should be in the range -255 to 255
	//negative values make the image darker
	BOOL Brightness(short brightness);
	BOOL Brightness(SELKEY key, short brightness);

	//can be from -100 to 100, the neutral value is 0.
	BOOL Contrast(signed char contrast);
	BOOL Contrast(SELKEY key, signed char contrast);

	//Skew from ptPivot some horz degrees and/or some vert degrees 
	BOOL Skew(const CPoint & ptPivot, float horz, float vert);
	BOOL Skew(SELKEY key, const CPoint & ptPivot, float horz, float vert);

	//Transparency Support
	BOOL SetTransColorIndex(const CPoint & point);

	//Nudge - moves a selection 1 pixel in the specified direction
	typedef enum { NUDGE_LEFT = 0, NUDGE_RIGHT, NUDGE_UP, NUDGE_DOWN } eNudge;
	BOOL Nudge(SELKEY key, eNudge dir);

	//Clipboard operations
	BOOL Cut(SELKEY key);
	BOOL Copy(SELKEY key)const;
	BOOL Paste(SELKEY key);
	static BOOL CanPaste();
	static BOOL PasteAsNewImage();

	//Undo-Redo
	void ClearUndoRedo();
	void EnableUndoRedo(BOOL bEnabled){ m_bUndoRedoEnabled = bEnabled; }
	BOOL IsUndoRedoEnabled()const { return m_bUndoRedoEnabled; 	}
	void SetMaxUndoItems(UINT unMax){ m_unMaxUndoItems = unMax; }
	UINT GetMaxUndoItems()const { return m_unMaxUndoItems; 	}

	void Undo();
	BOOL CanUndo()const { return (m_Undo.empty() ? FALSE : TRUE); }
	void Redo();
	BOOL CanRedo()const { return (m_Redo.empty() ? FALSE : TRUE); }

	//begins an undo operation - all subsequent operations that are undoable
	//are grouped together into one undo until EndUndo is called
	void BeginUndo();
	void EndUndo();
	
	//this returns a unique key that is used to 
	//access selections. Views should
	//call this once and store the key per instance.
	//Views need this key in order to access their selections.
	SELKEY CreateSelectionKey()const;

	//creates a selection
	typedef enum { SEL_RECT = 0, SEL_ELLIPSE, SEL_POLYGON } eSelectionType;
	BOOL CreateSelection(SELKEY key, std::vector<POINT> & arrPoints, eSelectionType type);

	//destroys a selection
	BOOL DestroySelection(SELKEY key);

	//Moves a selection 
	BOOL MoveSelection(SELKEY key, const CPoint & ptTopLeft);
	
	//Merges a selection into the current image
	BOOL MergeSelection(SELKEY key);

	//returns TRUE if the specified point is within the selection
	//associated with the specified key
	BOOL PointInSelection(SELKEY key, const CPoint & pt)const;

	//Get the bounding rectangle for the specified selection
	BOOL GetSelectionRect(SELKEY key, CRect & rc)const;

	//returns TRUE, if the specified key has an associated selection
	BOOL HasSelection(SELKEY key)const;

	//returns the type of selection
	eSelectionType GetSelectionType(SELKEY key)const;

protected:
	afx_msg void OnViewImageAttributes();

	typedef enum
	{ 
		FT_NONE = 0,
		FT_GRAYSCALE,
		FT_FLIP,
		FT_MIRROR,
		FT_NEGATIVE,
		FT_ROTATE_LEFT,
		FT_ROTATE_RIGHT,
		FT_RESIZE,
		FT_ROTATE,
		FT_BRIGHTNESS,
		FT_CONTRAST,
		FT_BLUR,
		FT_EMBOSS,
		FT_SOFTEN,
		FT_SHARPEN,
		FT_SKEW,
		FT_FEATHER,
		FT_JITTER,
		FT_CONTOUR
	}FILTERTRANSFORM_ENUM;

	typedef struct 
	{
		POINT pivot;
		float horz;
		float vert;
	}SKEWARGS;

	typedef union
	{
		SIZE size;
		float angle;
		short brightness;
		signed char contrast;
		SKEWARGS skew;
	}FILTERTRANSFORM_ARGS;

	BOOL DoFilterTransform(FILTERTRANSFORM_ENUM type, SELKEY key = NULL, FILTERTRANSFORM_ARGS * pArgs = NULL);

	void CreateMask(CxImage * pImage, CxImage & mask, UINT unNumGrayTransitionBands, BOOL bBlurMask, BOOL bIsSelection);

	DECLARE_MESSAGE_MAP()

private:
	
	Image * m_pImage;

	// All of the undoable changes
	std::stack<Image*> m_Undo;

	// All of the redoable changes - usually 1
	std::stack<Image*> m_Redo;

	//if when BeginUndo is called this is zero,
	//a copy of the current image is pushed on the undo stack.
	//while this is greater than 0 subsequent calls to BeginUndo are ignored.
	//calling EndUndo decrements this value
	int m_nBeginUndoRefCount;

	//true if we are undoing or redoing
	BOOL m_bUndoing;

	//disables or enables undoing/redoing
	BOOL m_bUndoRedoEnabled;

	//maximum undo/redo items
	UINT m_unMaxUndoItems;
};

}//end namespace


