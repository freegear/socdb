// BinToHex.cpp : implementation file
//

#include "stdafx.h"
#include "MrImage.h"
#include "resource.h"
#include "BinToHex.h"
#include ".\bintohex.h"


#define swap16(x)   ((((x) >> 8) & 0xff) | (((x) & 0xff) << 8)) 
#define swap32(x)	((((x) & 0xff000000) >> 24) | (((x) & 0x00ff0000) >>  8) | (((x) & 0x0000ff00) <<  8) | (((x) & 0x000000ff) << 24))


// CBinToHex dialog

IMPLEMENT_DYNAMIC(CBinToHex, CDialog)
CBinToHex::CBinToHex(CWnd* pParent /*=NULL*/)
	: CDialog(CBinToHex::IDD, pParent)
{
}



CBinToHex::~CBinToHex()
{
}

void CBinToHex::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_RADIO_CHAR, m_vChar);
	DDX_Control(pDX, IDC_RADIO_SHORT, m_vShort);
	DDX_Control(pDX, IDC_RADIO_INT, m_vInt);

	DDX_Control(pDX, IDC_STATIC_INPUTFILE, m_inFileName);
	DDX_Control(pDX, IDC_STATIC_OUTFILE, m_outFileName);

	DDX_Control(pDX, IDC_CHECK_SWAP, m_vCheck);
}


BEGIN_MESSAGE_MAP(CBinToHex, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_INPUTFILE, OnBnClickedButtonInputfile)
	ON_BN_CLICKED(IDC_BUTTON_CONVERT, OnBnClickedButtonConvert)
END_MESSAGE_MAP()


// CBinToHex message handlers

BOOL CBinToHex::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	m_vChar.SetCheck(1);
	m_vCheck.SetCheck(0);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CBinToHex::OnBnClickedButtonInputfile()
{
	// TODO: Add your control notification handler code here

    char strFilter[] = { "BIN Files (*.*)|*.*|All Files (*.*)|*.*||" };
    CFileDialog FileDlg(FALSE, ".bin", NULL, 0, strFilter);	
	int len;
	char filename[256];

	memset(filename, 0x0, 256);

	if( FileDlg.DoModal() == IDOK )
	{
		m_SrcPathName = FileDlg.GetPathName();
		m_DstPathName = FileDlg.GetPathName();

		len = m_DstPathName.GetLength();

		memcpy(filename, (LPSTR)(LPCTSTR)m_DstPathName, len);
		filename[len-3] = 'h';
		filename[len-2] = '\0';
		filename[len-1] = '\0';
		memcpy((LPSTR)(LPCTSTR)m_DstPathName, filename, len);

		m_SrcFileName= FileDlg.GetFileName();

		m_DstFileName= FileDlg.GetFileName();
		len = m_SrcFileName.GetLength();
		memcpy(filename, (LPSTR)(LPCTSTR)m_DstFileName, len);
		filename[len-3] = 'h';
		filename[len-2] = '\0';
		filename[len-1] = '\0';
		m_DstFileName.Format("%s",filename); 
		



		m_inFileName.SetWindowText(m_SrcFileName);
		m_outFileName.SetWindowText(m_DstFileName);

/*
		m_SrcPathName = FileDlg.GetPathName();
		m_DstPathName = FileDlg.GetPathName();

		len = m_DstPathName.GetLength();

		memcpy(filename, (LPSTR)(LPCTSTR)m_DstPathName, len);
		filename[len-3] = 'h';
		filename[len-2] = '\0';
		filename[len-1] = '\0';
		memcpy((LPSTR)(LPCTSTR)m_DstPathName, filename, len);

		m_inFileName.SetWindowText(m_SrcFileName);
		m_outFileName.SetWindowText(m_DstFileName);


		/////////////////////////////////////////////////////////
		m_SrcFileName= FileDlg.GetFileName();
		len = m_SrcFileName.GetLength();

		memcpy(filename, (LPSTR)(LPCTSTR)m_SrcFileName, len);
		filename[len-3] = 'h';
		filename[len-2] = '\0';
		filename[len-1] = '\0';
		memcpy((LPSTR)(LPCTSTR)m_DstFileName, filename, len);

		m_PathName = FileDlg.GetPathName();
*/


	}
}

void CBinToHex::convertTypeShort(void)
{
	CString typeName;
	FILE *hexFileHandle, *binFileHandle;
	
	int i;
	unsigned short binValue;
	long binFileSize;	

#ifdef WIN32
	if ((binFileHandle=_tfopen((LPSTR)(LPCTSTR)m_SrcPathName,_T("rb")))==NULL)  return;
#else
	if ((binFileHandle=fopen((LPSTR)(LPCTSTR)m_SrcPathName,"rb"))==NULL)  return;
#endif

#ifdef WIN32
	if ((hexFileHandle=_tfopen((LPSTR)(LPCTSTR)m_DstPathName,_T("wb")))==NULL)  return;
#else
	if ((hexFileHandle=fopen((LPSTR)(LPCTSTR)m_DstPathName,"wb"))==NULL)  return;
#endif	

	fseek(binFileHandle, 0, SEEK_END);                                                  
	binFileSize = ftell(binFileHandle);
	fseek(binFileHandle, 0, SEEK_SET);

	typeName.Format("unsigned short image_buffer[] = {\n");	
	fprintf(hexFileHandle,(LPSTR)(LPCTSTR)typeName);

    for(i=2;i<(binFileSize+2);i+=2)
	{                                          
		fread(&binValue, 2, 1, binFileHandle);

		if(((i)%16)==0)
		{
			if(m_vSwap==1)
				fprintf(hexFileHandle,"0x%04X,\n", swap16(binValue));    
			else
				fprintf(hexFileHandle,"0x%04X,\n", binValue);    
		}
		else
		{
			if(m_vSwap==1)
				fprintf(hexFileHandle,"0x%04X, ", swap16(binValue));
			else
				fprintf(hexFileHandle,"0x%04X, ", binValue);
		}
    }                                        
	
	fseek(hexFileHandle, -2, SEEK_END);
	fprintf(hexFileHandle," };\n");
                                                                                        
    /* close files */                                                                  
    fclose(hexFileHandle);                                                      
    fclose(binFileHandle); 
}


void CBinToHex::convertTypeInt(void)
{
	CString typeName;
	FILE *hexFileHandle, *binFileHandle;
	
	int i;
	unsigned int binValue;
	long binFileSize;	

#ifdef WIN32
	if ((binFileHandle=_tfopen((LPSTR)(LPCTSTR)m_SrcPathName,_T("rb")))==NULL)  return;
#else
	if ((binFileHandle=fopen((LPSTR)(LPCTSTR)m_SrcPathName,"rb"))==NULL)  return;
#endif

#ifdef WIN32
	if ((hexFileHandle=_tfopen((LPSTR)(LPCTSTR)m_DstPathName,_T("wb")))==NULL)  return;
#else
	if ((hexFileHandle=fopen((LPSTR)(LPCTSTR)m_DstPathName,"wb"))==NULL)  return;
#endif

	fseek(binFileHandle, 0, SEEK_END);                                                  
	binFileSize = ftell(binFileHandle);
	fseek(binFileHandle, 0, SEEK_SET);
	
	typeName.Format("unsigned int image_buffer[] = {\n");	
	fprintf(hexFileHandle,(LPSTR)(LPCTSTR)typeName);


    for(i=4;i<(binFileSize+4);i+=4)
	{                                          

		fread(&binValue, 4, 1, binFileHandle); 

		if((i%16)==0)
		{
			if(m_vSwap==1)
				fprintf(hexFileHandle,"0x%08X\n", swap32(binValue));    
			else
				fprintf(hexFileHandle,"0x%08X\n", binValue);
		}
		else
		{
			if(m_vSwap==1)
				fprintf(hexFileHandle,"0x%08X ", swap32(binValue));
			else
				fprintf(hexFileHandle,"0x%08X ", binValue);
		}
    }                                        
    
	fseek(hexFileHandle, -2, SEEK_END);
	fprintf(hexFileHandle,"\n};\n");                                                  
                                                                                        
    /* close files */                                                                  
    fclose(hexFileHandle);                                                      
    fclose(binFileHandle); 

}
void CBinToHex::convertTypeChar(void)
{
	CString typeName;
	FILE *hexFileHandle, *binFileHandle;
	
	int i;
	unsigned char binValue;
	long binFileSize;	

#ifdef WIN32
	if ((binFileHandle=_tfopen((LPSTR)(LPCTSTR)m_SrcPathName,_T("rb")))==NULL)  return;
#else
	if ((binFileHandle=fopen((LPSTR)(LPCTSTR)m_SrcPathName,"rb"))==NULL)  return;
#endif

#ifdef WIN32
	if ((hexFileHandle=_tfopen((LPSTR)(LPCTSTR)m_DstPathName,_T("wb")))==NULL)  return;
#else
	if ((hexFileHandle=fopen((LPSTR)(LPCTSTR)m_DstPathName,"wb"))==NULL)  return;
#endif

	fseek(binFileHandle, 0, SEEK_END);                                                  
	binFileSize = ftell(binFileHandle);
	fseek(binFileHandle, 0, SEEK_SET);
	
	typeName.Format("unsigned char image_buffer[ ] = {\n");	
	fprintf(hexFileHandle,(LPSTR)(LPCTSTR)typeName);

    for(i=1;i<(binFileSize+1);++i)
	{                                          

		fread(&binValue, 1, 1, binFileHandle); 

		if((i%16)==0)
		{ 
			fprintf(hexFileHandle,"0x%02X,\n", binValue);    
		}
		else
		{
			fprintf(hexFileHandle,"0x%02X, ", binValue);                                  
		}
    }                                        
    
	fseek(hexFileHandle, -2, SEEK_END);
	fprintf(hexFileHandle,"\n};\n");                                                  
                                                                                        
    /* close files */                                                                  
    fclose(hexFileHandle);                                                      
    fclose(binFileHandle); 
}

void CBinToHex::OnBnClickedButtonConvert()
{
	// TODO: Add your control notification handler code here

	m_vSwap = m_vCheck.GetCheck();

	if(m_vShort.GetCheck())
	{
		convertTypeShort();		
	}
	else if(m_vInt.GetCheck())
	{
		convertTypeInt();		
	}
	else
	{
		convertTypeChar();		
	}

	ShellExecute(NULL,(LPCSTR)"open", (LPSTR)(LPCSTR)m_PathName, NULL, NULL, SW_SHOW);
}

