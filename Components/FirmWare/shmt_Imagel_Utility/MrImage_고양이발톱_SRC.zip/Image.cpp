/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "StdAfx.h"
#include ".\image.h"

namespace MrImage
{

//---------------------------------------------------------------
HRGN CopyRgn(HRGN rgn)
{
	HRGN rgnNew = ::CreateRectRgn(0,0,0,0);
	if (rgnNew)
	{
		int ret = ::CombineRgn((HRGN)rgnNew, rgn, NULL, RGN_COPY);
		if (NULLREGION == ret || ERROR == ret)
		{
			(void)DeleteObject(rgnNew);
			rgnNew = NULL;
		}
	}
	return rgnNew;
}

//---------------------------------------------------------------
Selection::Selection()
:CxImage()
,m_hRgn(NULL)
,m_pParent(NULL)
,m_type(0)//rect
{
}

//---------------------------------------------------------------
Selection::Selection(const Selection & rhs)
:CxImage(rhs)
,m_hRgn(NULL)
,m_pParent(rhs.m_pParent)
,m_type(rhs.m_type)
{
	if (NULL != rhs.m_hRgn)
	{
		m_hRgn = CopyRgn(rhs.m_hRgn);
	}
}

//---------------------------------------------------------------
Selection::Selection(const CxImage & rhs)
:CxImage(rhs)
,m_hRgn(NULL)
,m_pParent(&rhs)
,m_type(0)//sel rect
{
}

//---------------------------------------------------------------
Selection::~Selection()
{
	if (m_hRgn)
	{
		VERIFY(::DeleteObject(m_hRgn));
		m_hRgn = NULL;
	}
	m_pParent = NULL;
}

//---------------------------------------------------------------
Selection & Selection::operator=(const Selection & rhs)
{
	if (this != &rhs)
	{
		if (m_hRgn)
		{
			VERIFY(::DeleteObject(m_hRgn));
			m_hRgn = NULL;
		}
		if (NULL != rhs.m_hRgn)
		{
			m_hRgn = CopyRgn(rhs.m_hRgn);
		}
		m_pParent = rhs.m_pParent;
		m_type = rhs.m_type;
	}
	return (*this);
}

//---------------------------------------------------------------
void Selection::Render(CDC * pDC)
{
	ASSERT(m_hRgn);

	long x = 0;
	long y = 0;
	GetOffset(&x, &y);

	CRect rc(0,0,0,0);
	::GetRgnBox(m_hRgn, &rc);

	//move the region to its new location
	VERIFY(ERROR != ::OffsetRgn(m_hRgn, x - rc.left, y  - rc.top));
	
#ifdef _DEBUG
	//sanity check
	::GetRgnBox(m_hRgn, &rc);
	ASSERT(rc.left == x && rc.top == y);
#endif 

	//set the viewport to the offset
	//this simplifies things
	CPoint ptOld = pDC->SetViewportOrg(x, y);

#ifdef _DEBUG
	//sanity check
	CPoint ptViewPort = pDC->GetViewportOrg();
	ASSERT(ptViewPort.x == x && ptViewPort.y == y);
#endif

	//create a copy of our selection
	Image tmp;
	tmp.Copy(*this);

	ASSERT(m_pParent);

	//now for every pixel that is not in the region
	//set the pixel in our copy. This basically
	//clips our selection by filling in all the areas
	//outside the region with the pixels of the main image
	long x1 = 0, y1 = 0;
	RGBQUAD color;
	const long height = tmp.GetHeight();
	const long width = tmp.GetWidth();
	const long parent_height = ((CxImage*)m_pParent)->GetHeight();
	for (y1 = 0; y1 <= height; ++y1)
	{
		for (x1 = 0; x1 <= width; ++x1)
		{
			if (!::PtInRegion(m_hRgn, x + x1, y + y1))
			{
				color = ((CxImage*)m_pParent)->GetPixelColor(x + x1, parent_height - (y + y1) - 1,false);
				tmp.SetPixelColor(x1, height - y1 - 1, color);
			}
		}
	}

	//draw the copy
	tmp.Draw(pDC->GetSafeHdc(), 0, 0);

	//restore the viewport
	(void)pDC->SetViewportOrg(ptOld);
}

//---------------------------------------------------------------
BOOL Selection::Create(std::vector<POINT> & pts, int type)
{
	ASSERT(!pts.empty());

	if (m_hRgn)
	{
		VERIFY(::DeleteObject(m_hRgn));
	}
	m_type = type;
	if (1 == m_type)//ellipse
	{
		if (2 == pts.size())
		{
			m_hRgn = CreateEllipticRgn(pts[0].x, pts[0].y, pts[1].x, pts[1].y);
		}
	}
	else
	{
		m_hRgn = CreatePolygonRgn(&pts[0], (int)pts.size(), WINDING); 
	}
	return (NULL != m_hRgn);
}

//---------------------------------------------------------------
BOOL Selection::GetBoundingRect(CRect & rc)const
{
	BOOL ret = FALSE;
	if (m_hRgn)
	{
		(void)::GetRgnBox(m_hRgn, &rc); 
		ret = TRUE;
	}
	return ret;
}

//---------------------------------------------------------------
BOOL Selection::PointInSelection(const CPoint & pt)const
{
	ASSERT(m_hRgn);
	return ::PtInRegion(m_hRgn, (pt.x), (pt.y)); 
}

//---------------------------------------------------------------
Image::Image()
:CxImage()
,m_lastSelectionKey(0)
,m_mapSelections()
{
}

//---------------------------------------------------------------
Image::Image(const Image & rhs)
:CxImage(rhs)
,m_lastSelectionKey(rhs.m_lastSelectionKey)
,m_mapSelections()
{
	//make copies of all of the selections
	SELMAP_CITER it = rhs.m_mapSelections.begin();
	SELMAP_CITER end = rhs.m_mapSelections.end();
	while (it != end)
	{
		m_mapSelections[it->first] = new Selection(*it->second);
		++it;
	}
}

//---------------------------------------------------------------
Image::Image(DWORD dwWidth, DWORD dwHeight, DWORD wBpp, DWORD imagetype /*= 0*/)
:CxImage(dwWidth, dwHeight, wBpp, imagetype)
,m_lastSelectionKey(0)
,m_mapSelections()
{
}

//---------------------------------------------------------------
Image::~Image(void)
{
	DestroyAllSelections();
}

//---------------------------------------------------------------
int inchesToPixels(int distance, CDC & dc)
{
	return (dc.GetDeviceCaps(LOGPIXELSX) * distance) / 100;
}

//---------------------------------------------------------------
void Image::Render(CDC * pDC)
{
	if (pDC->IsPrinting())
	{
		const int PT_LEFTMARGINX = 30; // in hundredths of an inch
		const int PT_TOPMARGINY =  30; // in hundredths of an inch

		CSize pixels(pDC->GetDeviceCaps(HORZRES), pDC->GetDeviceCaps(VERTRES));
		CPoint margin(inchesToPixels(PT_TOPMARGINY, *pDC), inchesToPixels(PT_LEFTMARGINX, *pDC));
		CRect area(margin.x, margin.y, pixels.cx - margin.x, pixels.cy - margin.y);

		double scalingx = (double)(area.Width()) / (double)GetWidth();
		double scalingy = (double)(area.Height()) / (double)GetHeight();
		double scaling = min(scalingx, scalingy);

		// Do not overscale. We assume the resolution of a monitor is 90dpi
		// Reset the scaling to not exceed 90 points per inch
		// Note that we could have done this by selecting the mapping mode
		// MM_LOENGLISH but this illustrates how to do the computations
		// without that
		scaling = min(scaling, (double)pDC->GetDeviceCaps(LOGPIXELSX) / 90.0f);
		int width = (int)(scaling * (double)GetWidth());
		int height = (int)(scaling * (double)GetHeight());

		Image tmp;
		tmp.Copy(*this);
		RGBQUAD c = {255,255,255,0};
		if (tmp.GetTransIndex() >= 0)
		{
			tmp.SetPaletteColor((BYTE)tmp.GetTransIndex(),c);
		}
		tmp.SetTransColor(c);
		tmp.AlphaStrip();
		tmp.Stretch(pDC->GetSafeHdc(), CRect(area.left, area.top,width,height));
	}
	else
	{
		//draw the main image
		Draw(pDC->GetSafeHdc()); 
	}

	//draw any selections
	Selection * pSel = NULL;
	SELMAP_CITER it = m_mapSelections.begin();
	SELMAP_CITER end = m_mapSelections.end();
	while (it != end)
	{
		pSel = it->second;
		ASSERT(pSel);
		pSel->Render(pDC);
		++it;
	}//end while
}

//---------------------------------------------------------------
SELKEY Image::CreateSelectionKey()const
{
	return ++m_lastSelectionKey; 
}

//---------------------------------------------------------------
BOOL Image::CreateSelection(SELKEY key, std::vector<POINT> & arrPoints, int type)
{
	BOOL bGood = FALSE;
	if (!arrPoints.empty())
	{
		Selection * pSel = new Selection(*this);
		if (pSel)
		{
			if (pSel->Create(arrPoints, type))
			{
				CRect rcSel(0,0,0,0);
				pSel->GetBoundingRect(rcSel);
				if (pSel->Crop(rcSel))
				{
					CPoint ptTopLeft(rcSel.TopLeft());
					pSel->SetOffset(ptTopLeft.x, ptTopLeft.y);
					m_mapSelections[key] = pSel;
					bGood = TRUE;
				}
			}
			
			if (!bGood)
			{
				delete pSel;
				pSel = NULL;
			}
		}	
	}
	return bGood;
}

//---------------------------------------------------------------
BOOL Image::CreateSelectionFromHandle(SELKEY key, HANDLE hBitmap)
{
	BOOL bGood = FALSE;

	if (hBitmap)
	{
		Selection * pSel = new Selection(*this);
		if (pSel)
		{
			if (pSel->CreateFromHANDLE(hBitmap))
			{
				CRect rcSel(CPoint(0,0), CSize(pSel->GetWidth(), pSel->GetHeight()));

				std::vector<POINT> arrPoints;
				arrPoints.push_back(rcSel.TopLeft());
				arrPoints.push_back(CPoint(rcSel.right, rcSel.top));
				arrPoints.push_back(rcSel.BottomRight());
				arrPoints.push_back(CPoint(rcSel.left, rcSel.bottom));

				if (pSel->Create(arrPoints, 0/*rect*/))
				{
					if (pSel->Crop(rcSel))
					{
						CPoint ptTopLeft(rcSel.TopLeft());
						pSel->SetOffset(ptTopLeft.x, ptTopLeft.y);
						m_mapSelections[key] = pSel;
						bGood = TRUE;
					}
				}
			}

			if (!bGood)
			{
				delete pSel;
				pSel = NULL;
			}
		}
	}
	return bGood;
}

//---------------------------------------------------------------
BOOL Image::DestroySelection(SELKEY key)
{
	BOOL ret = FALSE;

	SELMAP_ITER it = m_mapSelections.find(key);
	if (it != m_mapSelections.end())
	{
		delete it->second;
		(void)m_mapSelections.erase(it);
		ret = TRUE;
	}
	return ret;
}

//---------------------------------------------------------------
void Image::DestroyAllSelections()
{
	SELMAP_ITER it = m_mapSelections.begin();
	while (it != m_mapSelections.end())
	{
		delete it->second;
		it = m_mapSelections.erase(it);
	}
}


//---------------------------------------------------------------
Selection * Image::GetSelection(SELKEY key)
{
	Selection * pImage = NULL;
	SELMAP_ITER it = m_mapSelections.find(key);
	if (it != m_mapSelections.end())
	{
		pImage = it->second;
	}
	return pImage;

}

//---------------------------------------------------------------
const Selection * Image::GetSelection(SELKEY key)const
{
	const Selection * pImage = NULL;
	SELMAP_CITER it = m_mapSelections.find(key);
	if (it != m_mapSelections.end())
	{
		pImage = it->second;
	}
	return pImage;
}

//---------------------------------------------------------------
BOOL Image::PointInSelection(SELKEY key, const CPoint & pt)const
{
	BOOL ret = FALSE;
	const Selection * pSel = GetSelection(key);
	if (pSel)
	{
		ret = pSel->PointInSelection(pt);
	}
	return ret;
}

//---------------------------------------------------------------
BOOL Image::GetSelectionRect(SELKEY key, CRect & rc)const
{
	BOOL ret = FALSE;
	const Selection * pSel = GetSelection(key);
	if (pSel)
	{
		pSel->GetBoundingRect(rc);
		ret = TRUE;
	}
	return ret;
}

//---------------------------------------------------------------
BOOL Image::MoveSelection(SELKEY key, const CPoint & ptTopLeft)
{
	BOOL ret = FALSE;

	Selection * pSel = GetSelection(key);
	if (pSel)
	{
		pSel->SetOffset(ptTopLeft.x, ptTopLeft.y);
		ret = TRUE;
	}
	return ret;
}

//---------------------------------------------------------------
BOOL Image::MergeSelection(SELKEY key)
{
	BOOL ret = FALSE;

	Selection * pSel = GetSelection(key);
	if (pSel)
	{
		long x = 0, y = 0;

		pSel->GetOffset(&x, &y);

		//flip the y
		y = GetHeight() - y - 1;
		y -= (pSel->GetHeight() - 1);

		MixFrom(*pSel, x, y);
		ret = TRUE;

		VERIFY(DestroySelection(key));
	}
	return ret;
}

//---------------------------------------------------------------
BOOL Image::MergeAllSelections()
{
	BOOL ret = TRUE;
	SELMAP_ITER it = m_mapSelections.begin();
	while (it != m_mapSelections.end())
	{
		ret = MergeSelection(it->first);
		if (!ret)
		{
			break;
		}
		it = m_mapSelections.begin();
	}
	return ret;
}

//---------------------------------------------------------------
BOOL Image::ResizeCanvas(const CSize & sizeCanvas)
{
	RGBQUAD rgb;
	rgb.rgbBlue = 255;
	rgb.rgbGreen = 255;
	rgb.rgbRed = 255;
	return Expand(sizeCanvas.cx, sizeCanvas.cy, rgb);
}

//---------------------------------------------------------------
//---------------------------------------------------------------
}//end namespace