; mrimage.nsi

;--------------------------------

; The name of the installer
Name "MrImage"

; The installer file to write
OutFile "mrimage_setup.exe"

; The default installation directory
InstallDir $PROGRAMFILES\MrImage

; Registry key to check for directory (so if you install again, it will 
; overwrite the old one automatically)
InstallDirRegKey HKLM "Software\MrImage" "Install_Dir"

; license text
LicenseData "..\redist\license.txt"

;--------------------------------

; Pages

Page license
Page components
Page directory
Page instfiles

UninstPage uninstConfirm
UninstPage instfiles

;--------------------------------

; The stuff to install
Section "MrImage (required)"

  SectionIn RO
  
  ; Set output path to the installation directory.
  SetOutPath $INSTDIR
  
  ; Put files there
  File "..\release\mrimage.exe"
  File "..\redist\license.txt"
  File "..\redist\mfc71.dll"
  File "..\redist\msvcp71.dll"
  File "..\redist\msvcr71.dll"
  File "..\history.txt"
    
  ; Write the installation path into the registry
  WriteRegStr HKLM SOFTWARE\MrImage "Install_Dir" "$INSTDIR"
  
  ; Write the uninstall keys for Windows
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MrImage" "DisplayName" "MrImage"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MrImage" "UninstallString" '"$INSTDIR\uninstall.exe"'
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MrImage" "NoModify" 1
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MrImage" "NoRepair" 1
  WriteUninstaller "uninstall.exe"
  
SectionEnd

; Optional section (can be disabled by the user)
Section "Documentation"

  ; Set output path to the documentation directory.
  SetOutPath "$INSTDIR\docs"

  ; Put files there
  File "..\docs\index.html"
  File "..\docs\features.html"
  File "..\docs\help.html"
  File "..\docs\style.css"
  
  ; Set output path to the images directory.
  SetOutPath "$INSTDIR\docs\images"
  File "..\docs\images\*.jpg"
  
SectionEnd

; Optional section (can be disabled by the user)
Section "Start Menu Shortcuts"

  CreateDirectory "$SMPROGRAMS\MrImage"
  CreateShortCut "$SMPROGRAMS\MrImage\Uninstall.lnk" "$INSTDIR\uninstall.exe" "" "$INSTDIR\uninstall.exe" 0
  CreateShortCut "$SMPROGRAMS\MrImage\MrImage (MrImage).lnk" "$INSTDIR\MrImage.exe" "" "$INSTDIR\MrImage.exe" 0
  
SectionEnd

;--------------------------------

; Uninstaller

Section "Uninstall"
  
  ; Remove registry keys
  DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\MrImage"
  DeleteRegKey HKLM SOFTWARE\MrImage

  ; Remove files
  Delete $INSTDIR\MrImage.exe
  Delete $INSTDIR\license.txt
  Delete $INSTDIR\mfc71.dll
  Delete $INSTDIR\msvcp71.dll
  Delete $INSTDIR\msvcr71.dll
  Delete $INSTDIR\history.txt

  ; Remove documentation
  Delete "$INSTDIR\docs\index.html"
  Delete "$INSTDIR\docs\features.html"
  Delete "$INSTDIR\docs\help.html"
  Delete "$INSTDIR\docs\style.css"
  Delete "$INSTDIR\docs\images\*.jpg"

  ; Remove uninstaller	
  Delete $INSTDIR\uninstall.exe

  ; Remove shortcuts, if any
  Delete "$SMPROGRAMS\MrImage\*.*"

  ; Remove directories used
  RMDir "$SMPROGRAMS\MrImage"
  RMDir "$INSTDIR\docs\images"
  RMDir "$INSTDIR\docs"
  RMDir "$INSTDIR"

SectionEnd