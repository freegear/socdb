/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "MrImageDoc.h"
#include "MrImageView.h"
#include "MemDC.h"
#include "resource.h"
#include "ResizeDlg.h"
#include "RotateDlg.h"
#include "SkewDlg.h"
#include "Mainfrm.h"
#include "OptionsDlg.h"
#include "FeatherDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace MrImage
{
IMPLEMENT_DYNAMIC(CSelectedColorChanged, CObject)

IMPLEMENT_DYNCREATE(CMrImageView, CScrollView)

const WORD WM_TEXTEDIT_COMPLETE =  WM_APP + 42;
const WORD STD_DRAWTOOLS_BAR_ID = (AFX_IDW_TOOLBAR + 50);

//---------------------------------------------------------------
BEGIN_MESSAGE_MAP(CMrImageView, CScrollView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
	ON_COMMAND_RANGE(ID_BUTTON_PENCIL_TOOL, ID_BUTTON_BRUSH_TOOL, OnSelectedStdDrawTool)
	ON_UPDATE_COMMAND_UI_RANGE(ID_BUTTON_PENCIL_TOOL, ID_BUTTON_BRUSH_TOOL, OnUpdateStdDrawTools)
	ON_WM_MOUSEMOVE()
	ON_MESSAGE(WM_MOUSELEAVE, OnMouseLeave)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_SETCURSOR()
	ON_WM_KEYDOWN()
	ON_MESSAGE(WM_TEXTEDIT_COMPLETE, OnTextEditComplete)

	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)

	ON_COMMAND(ID_EDIT_SELECT_ALL, OnEditSelectAll)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SELECT_ALL, OnUpdateEditSelectAll)
	ON_COMMAND(ID_EDIT_SELECT_NONE, OnEditSelectNone)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SELECT_NONE, OnUpdateEditSelectNone)
	ON_COMMAND(ID_REDEYE_REMOVE, OnRedEyeRemove)
	ON_UPDATE_COMMAND_UI(ID_REDEYE_REMOVE, OnUpdateRedEyeRemove)
	ON_COMMAND(ID_ZOOMIN, OnZoomIn)
	ON_COMMAND(ID_ZOOMOUT, OnZoomOut)
	ON_COMMAND(ID_NOZOOM, OnNoZoom)
	ON_UPDATE_COMMAND_UI(ID_NOZOOM, OnUpdateNoZoom)
	ON_COMMAND(ID_APPLY_TO_SELECTION, OnApplyToSelection)
	ON_UPDATE_COMMAND_UI(ID_APPLY_TO_SELECTION, OnUpdateApplyToSelection)
	ON_COMMAND(ID_SHOW_SELECTION_BORDER, OnShowSelectionBorder)
	ON_UPDATE_COMMAND_UI(ID_SHOW_SELECTION_BORDER, OnUpdateShowSelectionBorder)
	ON_COMMAND(ID_CROP, OnCrop)
	ON_UPDATE_COMMAND_UI(ID_CROP, OnUpdateCrop)
	ON_COMMAND_RANGE(ID_FLIP, ID_CONTOUR, OnFilterTransform)

	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_COMMAND(ID_EDIT_REDO, OnEditRedo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REDO, OnUpdateEditRedo)

	ON_COMMAND(ID_FONTNAME, OnFontNameChange)
	ON_UPDATE_COMMAND_UI(ID_FONTNAME, OnUpdateFontName)
	ON_COMMAND(ID_FONTSIZE, OnFontSizeChange)
	ON_UPDATE_COMMAND_UI(ID_FONTSIZE, OnUpdateFontSize)
	ON_COMMAND(ID_BOLD, OnFontBold)
	ON_COMMAND(ID_ITALICS, OnFontItalics)
	ON_COMMAND(ID_UNDERLINE, OnFontUnderline)

	ON_COMMAND_RANGE(ID_BUTTON_NUDGE_UP_TOOL,ID_BUTTON_NUDGE_LEFT_TOOL, OnNudge)
	ON_UPDATE_COMMAND_UI_RANGE(ID_BUTTON_NUDGE_UP_TOOL,ID_BUTTON_NUDGE_LEFT_TOOL, OnUpdateNudge)

	ON_NOTIFY(TBN_DROPDOWN, STD_DRAWTOOLS_BAR_ID, OnToolbarDropDown)
END_MESSAGE_MAP()

LPARAM CSelectedColorChanged::HINT_SELECTED_COLOR_CHANGED = 100;

//these are shared by all CMrImageView instances
UINT CMrImageView::m_unSelectedTool = 0;
UINT CMrImageView::m_unLastSelectedTool = 0;
UINT CMrImageView::m_unBrushStyle = 0;
BOOL CMrImageView::m_bApplyToSelection = FALSE;
BOOL CMrImageView::m_bShowSelectionBorder = TRUE;

//---------------------------------------------------------------
CMrImageView::CMrImageView()
:m_bSized(FALSE)
,m_bTrackingMouse(FALSE)
,m_pts()
,m_bMouseBtnSwapped(FALSE)
,m_foreColor(RGB(0,0,0))
,m_backColor(RGB(255,255,255))
,m_eMouseBtnDown(NO_MOUSE_BTN_DOWN)
,m_bTrackOutside(FALSE)
,m_unTimerID(0)
,m_hSelectionKey(NULL)
,m_fZoomFactor(1.00f)
,m_ptrEdit()
,m_TextFont()
{
	if (GetSystemMetrics(SM_SWAPBUTTON))
	{
		m_bMouseBtnSwapped = TRUE;
	}
}

//---------------------------------------------------------------
CMrImageView::~CMrImageView()
{
}

//---------------------------------------------------------------
BOOL CMrImageView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CScrollView::PreCreateWindow(cs);
}

//---------------------------------------------------------------
BOOL CMrImageView::CreateSelection(BOOL bConvertToImagePoints, int type)
{
	BOOL ret = FALSE;

	if (HasSelection())
	{
		ClearSelection();
	}

	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		int size = (int)m_pts.size();
		if (size > 1)
		{
			if (bConvertToImagePoints)
			{
				for (int i = 0; i < size; ++i)
				{
					m_pts[i] = GetImagePoint(m_pts[i]);
				}
			}
			
			if (m_hSelectionKey)
			{
				ret = pDoc->CreateSelection(m_hSelectionKey, m_pts, (CMrImageDoc::eSelectionType)type);
				m_pts.clear();
			}
		}
	}
	return ret;
}

//---------------------------------------------------------------
void CMrImageView::MergeSelection()
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		if (HasSelection())
		{
			VERIFY(pDoc->MergeSelection(m_hSelectionKey));
		}
	}
}

//---------------------------------------------------------------
void CMrImageView::ClearSelection()
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		if (HasSelection())
		{
			VERIFY(pDoc->DestroySelection(m_hSelectionKey));
			Invalidate();
		}
	}
}

//---------------------------------------------------------------
BOOL CMrImageView::HasSelection()const 
{
	BOOL ret = FALSE;

	if (m_hSelectionKey)
	{
		CMrImageDoc* pDoc = GetDocument();
		if (pDoc)
		{
			ret = pDoc->HasSelection(m_hSelectionKey);
		}
	}
	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageView::PtInSel(const CPoint & pt)const
{
	BOOL ret = FALSE;
	if (HasSelection())
	{
		CMrImageDoc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);
		if (pDoc)
		{
			ret = pDoc->PointInSelection(m_hSelectionKey, pt);
		}
	}
	return ret;
}

//---------------------------------------------------------------
BOOL CMrImageView::GetSelRect(CRect & rc)const
{
	BOOL ret = FALSE;
	if (HasSelection())
	{
		CMrImageDoc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);
		if (pDoc)
		{
			ret = pDoc->GetSelectionRect(m_hSelectionKey, rc);
		}
	}
	return ret;
}

//---------------------------------------------------------------
//Converts a point in the views client coordinates
//to an image coordinate.
CPoint CMrImageView::GetImagePoint(const CPoint & pt)const
{ 
	//offset the point by any amount of scrolling
	CPoint ptImage(pt + GetScrollPosition());

	//remove any zooming
	float x = (float)ptImage.x;
	x /= m_fZoomFactor;
	ptImage.x = (long)x;

	float y = (float)ptImage.y;
	y /= m_fZoomFactor;
	ptImage.y = (long)y;

	return ptImage;
}

//---------------------------------------------------------------
void CMrImageView::OnDraw(CDC* dc)
{
	CMrImageDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
	{
		return;
	}

	CRect rcUpdate(0,0,0,0);
	(void)dc->GetClipBox(&rcUpdate);

	CSize sizeImage = pDoc->GetSize();
	CSize sizeScaled(sizeImage);
	float fScaledX = (float)sizeScaled.cx;
	fScaledX /= m_fZoomFactor;
	sizeScaled.cx = (INT)fScaledX;
	float fScaledY = (float)sizeScaled.cy;
	fScaledY /= m_fZoomFactor;
	sizeScaled.cy = (INT)fScaledY;

	if (!dc->IsPrinting())
	{
		if (m_fZoomFactor < 1.00f)
		{
			rcUpdate = CRect(CPoint(0,0), sizeScaled);
		}
	}

	CMemDC pDC(dc, &rcUpdate);

	if (!dc->IsPrinting())
	{
		pDC->SetMapMode(MM_ANISOTROPIC);
		pDC->SetWindowExt(sizeImage);
		pDC->SetViewportExt(sizeScaled);
	}

	pDoc->Render(pDC);

	if (HasSelection() && CMrImageView::m_bShowSelectionBorder)
	{
		CRect rc(0,0,0,0);
		if (pDoc->GetSelectionRect(m_hSelectionKey, rc))
		{
			CMrImageDoc::eSelectionType type = pDoc->GetSelectionType(m_hSelectionKey);
			switch(type)
			{
				case CMrImageDoc::SEL_ELLIPSE:
				case CMrImageDoc::SEL_RECT:
				{
					CPoint ptTopLeft = rc.TopLeft();
					ptTopLeft.x *= m_fZoomFactor;
					ptTopLeft.y *= m_fZoomFactor;

					CPoint ptBottomRight = rc.BottomRight();
					ptBottomRight.x *= m_fZoomFactor;
					ptBottomRight.y *= m_fZoomFactor;
					
					if (CMrImageDoc::SEL_RECT == type)
					{
						RubberRect(pDC, ptTopLeft, ptBottomRight);
					}
					else
					if (CMrImageDoc::SEL_ELLIPSE == type)
					{
						RubberEllipse(pDC, ptTopLeft, ptBottomRight);
					}
				}
				break;

				case CMrImageDoc::SEL_POLYGON:
				{
					int x = 0;
					int yZoom = 0;
					bool inSelection = false;

					int oldMode = pDC->SetROP2(R2_NOT);

					COLORREF rgb = RGB(255,255,255);

					//top to bottom
					for (int y = rc.top; y < rc.bottom; ++y )
					{
						inSelection = false;

						yZoom = y * m_fZoomFactor;

						//left to right
						for (x = rc.left; x < rc.right; ++x)
						{
							if (pDoc->PointInSelection(m_hSelectionKey, CPoint(x,y)))
							{
								if (!inSelection)
								{
									//if the point is the first in the selection draw point before

									inSelection = true;
									if (x > 0)
									{
										pDC->SetPixel((x-1)*m_fZoomFactor,yZoom, rgb);
									}
								}
							}
							else
							{
								if (inSelection)
								{
									//if the point is the first out of the selection draw point
									inSelection = false;
									pDC->SetPixel(x * m_fZoomFactor,yZoom, rgb);
								}	
							}
						}
					}//end for

					pDC->SetROP2(oldMode);
				}
				break;

				default:
					;//ignore
			}//end switch
		}
	}
}

//---------------------------------------------------------------
BOOL CMrImageView::OnEraseBkgnd(CDC* pDC)
{
	return TRUE; //we don't need it to erase the background. CMemDC will handle everything
}

//---------------------------------------------------------------
void CMrImageView::OnSize(UINT nType, int cx, int cy) 
{
	CScrollView::OnSize(nType, cx, cy);
}

//---------------------------------------------------------------
BOOL CMrImageView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	pInfo->SetMaxPage(1);
	return DoPreparePrinting(pInfo);
}

//---------------------------------------------------------------
void CMrImageView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

//---------------------------------------------------------------
void CMrImageView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

//---------------------------------------------------------------
UINT CMrImageView::GetDropperSelectedColorMsgID()
{
	return RegisterWindowMessage(_T("MRIMAGEVIEW_DROPPERSELECTEDCOLOR_MSGID"));
}

//---------------------------------------------------------------
UINT CMrImageView::GetCursorPositionMsgID()
{
	return RegisterWindowMessage(_T("MRIMAGEVIEW_CURSORPOSITION_MSGID"));
}

//---------------------------------------------------------------
#ifdef _DEBUG
void CMrImageView::AssertValid() const
{
	CScrollView::AssertValid();
}

//---------------------------------------------------------------
void CMrImageView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

//---------------------------------------------------------------
CMrImageDoc* CMrImageView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMrImageDoc)));
	return (CMrImageDoc*)m_pDocument;
}
#endif //_DEBUG

//---------------------------------------------------------------
BOOL CMrImageView::IsSplit(void)const
{
	CSplitterWnd * parent = (CSplitterWnd*)GetParent();
	if (parent)
	{
		int rows = parent->GetRowCount();
		if (rows > 1)
		{
			return TRUE;
		}
		int cols = parent->GetColumnCount();
		if (cols > 1)
		{
			return(TRUE);
		}
	}
	return FALSE;
}

//---------------------------------------------------------------
void CMrImageView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	if (!m_bSized && !IsSplit()) 
	{
		// size window perfectly around frame
		GetParentFrame()->RecalcLayout();
		OnSizeToFit();
		m_bSized=TRUE;
	}

	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		UINT uTotalViews = 0;
		POSITION pos = pDoc->GetFirstViewPosition();
		while (pos)
		{
			++uTotalViews;
			(void)pDoc->GetNextView(pos);
		}

		if (1 == uTotalViews)
		{
			//restore "Apply To Selection" menu item check state
			COptionsDlg options;
			if (options.IsRememberApplyToSelectionEnabled())
			{
				CMrImageView::m_bApplyToSelection = options.IsApplyToSelectionEnabled();
			}
		}
	}

	CMainFrame * pMF = (CMainFrame*)AfxGetMainWnd();
	if (pMF)
	{
		m_foreColor = pMF->GetForegroundColor();
		m_backColor = pMF->GetBackgroundColor();
	}

	//create the selection key only if it has
	//already been created
	if (NULL == m_hSelectionKey)
	{
		m_hSelectionKey = pDoc->CreateSelectionKey();
	}
}

//---------------------------------------------------------------
void CMrImageView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint)
{
	CSize size(0,0);

	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		size = pDoc->GetSize();
		float cx = (float)size.cx;
		float cy = (float)size.cy;
		cx *= m_fZoomFactor;
		cy *= m_fZoomFactor;
		size.cx = (long)cx;
		size.cy = (long)cy;
	}

	SetScrollSizes(MM_TEXT,size);

	if (CSelectedColorChanged::HINT_SELECTED_COLOR_CHANGED == lHint)
	{
		ASSERT(pHint);
		ASSERT(pHint->IsKindOf(RUNTIME_CLASS(CSelectedColorChanged)));
		CSelectedColorChanged * pSelectedColor = dynamic_cast<CSelectedColorChanged *>(pHint);
		ASSERT(pSelectedColor);
		if (pSelectedColor)
		{
			COLORREF color = pSelectedColor->GetSelectedColor();
			TRACE(_T("Color Changed! R:%d G:%d B:%d\n"), GetRValue(color), GetGValue(color), GetBValue(color));

			if (pSelectedColor->IsForegroundColor())
			{
				m_foreColor = color;
			}
			else
			{
				m_backColor = color;
			}
		}
	}

	CScrollView::OnUpdate(pSender, lHint, pHint);
}

//---------------------------------------------------------------
void CMrImageView::OnSizeToFit()
{
	ResizeParentToFit(FALSE);

	// MFC might have grown the window off the screen--I'll fix it
	CRect rc, rcMax;
	CFrameWnd* pFrame = GetParentFrame();
	ASSERT_VALID(pFrame);
	pFrame->GetWindowRect(&rc);
	CWnd* pGrandParent = pFrame->GetParent();
	if (pGrandParent) 
	{
		// use top level window as maximum rectangle
		pGrandParent->ScreenToClient(&rc);
		pGrandParent->GetClientRect(&rcMax);
	}
	else 
	{
		// use whole screen as maximum rectangle
		rcMax.SetRect(0,0,GetSystemMetrics(SM_CXSCREEN),
			GetSystemMetrics(SM_CYSCREEN));
	}
	BOOL bTooBig = FALSE;
	if (rc.bottom > rcMax.bottom) 
	{
		rc.bottom = rcMax.bottom;
		rc.right += GetSystemMetrics(SM_CXVSCROLL) +
			GetSystemMetrics(SM_CXBORDER);
		bTooBig = TRUE;
	}
	if (rc.right > rcMax.right) 
	{
		rc.right = rcMax.right;
		bTooBig = TRUE;
	}
	if (bTooBig) 
	{
		pFrame->SetWindowPos(NULL, 0, 0, rc.Width(), rc.Height(),
			SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);
	}
}

//---------------------------------------------------------------
void CMrImageView::OnSelectedStdDrawTool(UINT nID)
{
	CMrImageView::m_unLastSelectedTool = CMrImageView::m_unSelectedTool;
	CMrImageView::m_unSelectedTool = nID;
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateStdDrawTools( CCmdUI* pCmdUI )
{
	//enable all the tools
	pCmdUI->Enable(TRUE);

	if (pCmdUI->m_pOther)
	{
		if (pCmdUI->m_pOther->IsKindOf(RUNTIME_CLASS(CToolBar)))
		{
			CToolBar * pToolBar = dynamic_cast<CToolBar*>(pCmdUI->m_pOther);
			if (pToolBar)
			{
				//set the check state for this tool button
				BOOL bShouldBeChecked = (pCmdUI->m_nID == CMrImageView::m_unSelectedTool);
				
				pToolBar->GetToolBarCtrl().CheckButton(pCmdUI->m_nID, bShouldBeChecked);
			}
		}
	}
}

//---------------------------------------------------------------
//Returns the mouse cursor in Screen Coordinates
CPoint CMrImageView::GetMouseCursorPos()const
{
	DWORD dw = GetMessagePos();
	POINTS pts = MAKEPOINTS(dw);
	CPoint pt(pts.x, pts.y);
	return pt;
}

//---------------------------------------------------------------
void CMrImageView::OnMouseMove(UINT nFlags, CPoint point)
{
	AfxGetMainWnd()->PostMessage(GetCursorPositionMsgID(),0, MAKELPARAM(point.x, point.y));

	if (!m_bTrackingMouse) 
	{
         // First time mouse entered my window:
         // request leave notification
         TRACKMOUSEEVENT tme;
         tme.cbSize = sizeof(tme);
         tme.hwndTrack = m_hWnd;
         tme.dwFlags = TME_LEAVE;
         _TrackMouseEvent(&tme);
         m_bTrackingMouse = TRUE;
     }

	//if there is a selected tool 
	//and a mouse button is down
	//call OnToolMove
	if (IsToolSelected())
	{
		if (NO_MOUSE_BTN_DOWN != m_eMouseBtnDown)
		{
			OnToolMove(point, m_eMouseBtnDown);
		}
	}

	CScrollView::OnMouseMove(nFlags, point);
}

//---------------------------------------------------------------
LPARAM CMrImageView::OnMouseLeave( WPARAM wp, LPARAM lp)
{
	if (m_bTrackOutside)
	{
		//since we're to track the mouse outside the client
		//area, we create a timer whose job it is to
		//watch the mouse and notify us of its position,
		//the state of its buttons, and when it re-enters
		//the client area
		ASSERT(IsToolSelected());
		if (NO_MOUSE_BTN_DOWN != m_eMouseBtnDown)
		{
			ASSERT(0 == m_unTimerID);
			m_unTimerID = (UINT)SetTimer(42, 100, NULL);
			ASSERT(m_unTimerID != 0);
		}
	}
	else
	{
		m_bTrackingMouse = FALSE;

		//if there is a selected tool 
		//and a mouse button was down
		//call OnToolEnd
		if (IsToolSelected())
		{
			if (NO_MOUSE_BTN_DOWN != m_eMouseBtnDown)
			{
				CPoint pt(GetMouseCursorPos());

				ScreenToClient(&pt);

				OnToolEnd(pt, m_eMouseBtnDown);
			}
		}

		m_eMouseBtnDown = NO_MOUSE_BTN_DOWN;
	}

    return 0;
}

//---------------------------------------------------------------
void CMrImageView::OnLButtonDown(UINT nFlags, CPoint point)
{
	m_eMouseBtnDown = LEFT_MOUSE_BTN_DOWN;

	//if there is a selected tool
	//call OnToolBegin
	if (IsToolSelected())
	{
		OnToolBegin(point, m_eMouseBtnDown);
	}

	CScrollView::OnLButtonDown(nFlags, point);
}

//---------------------------------------------------------------
void CMrImageView::OnLButtonUp(UINT nFlags, CPoint point)
{
	//if there was a selected tool 
	//call OnToolEnd
	if (IsToolSelected())
	{
		OnToolEnd(point, m_eMouseBtnDown);
	}

	m_eMouseBtnDown = NO_MOUSE_BTN_DOWN;

	CScrollView::OnLButtonUp(nFlags, point);
}

//---------------------------------------------------------------
void CMrImageView::OnRButtonDown(UINT nFlags, CPoint point)
{
	m_eMouseBtnDown = RIGHT_MOUSE_BTN_DOWN;

	//if there is a selected tool
	//call OnToolBegin
	if (IsToolSelected())
	{
		OnToolBegin(point, m_eMouseBtnDown);
	}

	CScrollView::OnRButtonDown(nFlags, point);
}

//---------------------------------------------------------------
void CMrImageView::OnTimer(UINT nIDEvent)
{
	if (nIDEvent == m_unTimerID)
	{
		ASSERT(m_bTrackOutside);

		CPoint ptScreen(GetMouseCursorPos());
		CPoint ptClient(ptScreen);
		ScreenToClient(&ptClient);

		CRect rc;
		GetWindowRect(&rc);

        if (rc.PtInRect(ptScreen))
		{
			//inside the window now
			//don't need the timer anymore
			KillTimer(m_unTimerID);
			m_unTimerID = 0;
			m_bTrackingMouse = FALSE;
			OnMouseMove(0, ptClient);
		}
		else
		{
			ASSERT(NO_MOUSE_BTN_DOWN != m_eMouseBtnDown);

			//outside the window
			if (LEFT_MOUSE_BTN_DOWN == m_eMouseBtnDown && !IsLeftMouseButtonDown())
			{
				//button is now up
				//don't need timer anymore
				KillTimer(m_unTimerID);
				m_unTimerID = 0;
				m_bTrackingMouse = FALSE;
				OnLButtonUp(0, ptClient);
			}
			else
			if (RIGHT_MOUSE_BTN_DOWN == m_eMouseBtnDown && !IsRightMouseButtonDown())
			{
				//button is now up
				//don't need timer anymore
				KillTimer(m_unTimerID);
				m_unTimerID = 0;
				m_bTrackingMouse = FALSE;
				OnRButtonUp(0, ptClient);
			}
			else
			{
				OnMouseMove(0, ptClient);
			}
		}
	}

	CScrollView::OnTimer(nIDEvent);
}

//---------------------------------------------------------------
void CMrImageView::OnDestroy()
{
	if (m_unTimerID)
	{
		KillTimer(m_unTimerID);
		m_unTimerID = 0;
	}

	//remember the check state of the "Apply To Selection" menu item
	COptionsDlg options;
	options.EnableApplyToSelection(CMrImageView::m_bApplyToSelection);

	if (m_ptrEdit.get())
	{
		if (::IsWindow(m_ptrEdit->m_hWnd))
		{
			m_ptrEdit->SetParent(NULL);
			VERIFY(m_ptrEdit->DestroyWindow());
		}
	}

	CScrollView::OnDestroy();
}

//---------------------------------------------------------------
void CMrImageView::OnRButtonUp(UINT nFlags, CPoint point)
{
	//if there was a selected tool 
	//call OnToolEnd
	if (IsToolSelected())
	{
		OnToolEnd(point, m_eMouseBtnDown);
	}

	m_eMouseBtnDown = NO_MOUSE_BTN_DOWN;

	CScrollView::OnRButtonUp(nFlags, point);
}

//---------------------------------------------------------------
void CMrImageView::RubberLine(CDC & dc, const CPoint & ptStart, const CPoint & ptEnd)
{
	int oldMode = dc.SetROP2(R2_NOT);
	dc.MoveTo(ptStart);
	dc.LineTo(ptEnd);
	dc.SetROP2(oldMode);
}

//---------------------------------------------------------------
void CMrImageView::RubberRect(CDC & dc, const CPoint & ptTopLeft, const CPoint & ptBottomRight)
{
	CRect rc(ptTopLeft, ptBottomRight);
	rc.NormalizeRect();

	int oldMode = dc.SetROP2(R2_NOT);
	HGDIOBJ old = ::SelectObject(dc.GetSafeHdc(), ::GetStockObject(NULL_BRUSH));
	dc.Rectangle(&rc);
	::SelectObject(dc.GetSafeHdc(), old);
	dc.SetROP2(oldMode);
}

//---------------------------------------------------------------
void CMrImageView::RubberEllipse(CDC & dc, const CPoint & ptTopLeft, const CPoint & ptBottomRight)
{
	CRect rc(ptTopLeft, ptBottomRight);
	rc.NormalizeRect();

	int oldMode = dc.SetROP2(R2_NOT);
	HGDIOBJ old = ::SelectObject(dc.GetSafeHdc(), ::GetStockObject(NULL_BRUSH));
	dc.Ellipse(&rc);
	::SelectObject(dc.GetSafeHdc(), old);
	dc.SetROP2(oldMode);
}

//---------------------------------------------------------------
BOOL CMrImageView::GetSelectedBrushStyleMask(CBitmap & bmp)
{
	BOOL ret = FALSE;

	CImageList ilStyle;
	ret = ilStyle.Create(IDR_BRUSHSTYLES, 8, 1, RGB(0,0,0));

	if (ret)
	{
		HICON icon = ilStyle.ExtractIcon(m_unBrushStyle);
		if (icon)
		{
			ICONINFO info;
			memset(&info, 0, sizeof(info));
			if (GetIconInfo(icon, &info))
			{
				ret = bmp.Attach(info.hbmMask);
			}
		}
	}
	return ret;
}

//---------------------------------------------------------------
void CMrImageView::OnToolBegin(const CPoint & point, MOUSE_BTN_DOWN mouse)
{
	if (m_unLastSelectedTool != m_unSelectedTool)
	{
		//pointer doesn't commit selections
		if (ID_BUTTON_POINTER_TOOL != m_unSelectedTool)
		{
			if (HasSelection())
			{
				MergeSelection();
			}
		}
	}

	if (m_ptrEdit.get())
	{
		if (::IsWindow(m_ptrEdit->m_hWnd))
		{
			VERIFY(m_ptrEdit->DestroyWindow());
		}
	}

	m_pts.clear();

	COLORREF color = m_foreColor;
	if (RIGHT_MOUSE_BTN_DOWN == mouse)
	{
		color = m_backColor;
	}

	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		switch(CMrImageView::m_unSelectedTool)
		{
			case ID_BUTTON_FILL_TOOL:
				{
					CPoint ptImage = GetImagePoint(point);
					COLORREF old = pDoc->GetPixel(ptImage);
					CWaitCursor wait;
					pDoc->FloodFill(ptImage, color, old);
				}
			break;

			case ID_BUTTON_TRANSPARENCY_TOOL:
			{
				VERIFY(pDoc->SetTransColorIndex(GetImagePoint(point)));
			}
			break;

			case ID_BUTTON_DROPPER_TOOL:
				{
					color = pDoc->GetPixel(GetImagePoint(point));
					if (LEFT_MOUSE_BTN_DOWN == mouse)
					{
						m_foreColor = color;
					}
					else
					{
						m_backColor = color;
					}
					
					AfxGetMainWnd()->PostMessage(GetDropperSelectedColorMsgID(),(LEFT_MOUSE_BTN_DOWN == mouse) ? 0 : 1, color);
				}
			break;

			case ID_BUTTON_BRUSH_TOOL:
			case ID_BUTTON_ERASE_TOOL:
			case ID_BUTTON_PENCIL_TOOL:
				
				m_pts.push_back(point);

				pDoc->BeginUndo();

				//call OnToolMove to modify the starting pixel
				//that way if they release the mouse button
				//without moving the mouse, the pixel will
				//get modified
				OnToolMove(point, mouse);
			break;

			case ID_BUTTON_POINTER_TOOL:
			{
				//test if we clicked within a selection
				if (PtInSel(GetImagePoint(point)))
				{
					m_pts.push_back(point);
				}
			}
			break;

			case ID_BUTTON_ELLIPSE_TOOL:
			case ID_BUTTON_FILLED_ELLIPSE_TOOL:
			case ID_BUTTON_RECT_TOOL:
			case ID_BUTTON_FILLED_RECT_TOOL:
			case ID_BUTTON_LINE_TOOL:
			case ID_BUTTON_RECTANGULAR_SELECTION_TOOL:
			case ID_BUTTON_TEXT_TOOL:
			case ID_BUTTON_FREEFORM_SELECTION_TOOL:
			case ID_BUTTON_ELLIPTICAL_SELECTION_TOOL:
			{
				if (HasSelection())
				{
					ClearSelection();
				}
				m_pts.push_back(point);
				m_bTrackOutside = TRUE;
			}
			break;

			default:
				;//ignore
		}//end switch
	}
}

//---------------------------------------------------------------
void CMrImageView::OnToolMove(const CPoint & point, MOUSE_BTN_DOWN mouse)
{
	COLORREF color = m_foreColor;
	if (RIGHT_MOUSE_BTN_DOWN == mouse)
	{
		color = m_backColor;
	}

	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		switch(CMrImageView::m_unSelectedTool)
		{
			case ID_BUTTON_ERASE_TOOL:
				//change to background color
				color = m_backColor;

				if (RIGHT_MOUSE_BTN_DOWN == mouse)
				{
					color = m_foreColor;
				}

				//fall thru - handle same as pencil
			case ID_BUTTON_PENCIL_TOOL:
			{
				ASSERT(!m_pts.empty());
				if (point == m_pts[0])
				{
					pDoc->SetPixel(GetImagePoint(point), color);
				}
				else
				{
					pDoc->DrawLine(GetImagePoint(m_pts[0]), GetImagePoint(point), color );
				}
				Invalidate();
				m_pts[0] = point;
			}
			break;

			case ID_BUTTON_BRUSH_TOOL:
			{
				CBitmap bmp;
				if (GetSelectedBrushStyleMask(bmp))
				{
					pDoc->DrawPattern(GetImagePoint(point), bmp, color);
					Invalidate();
				}
			}
			break;

			case ID_BUTTON_FILLED_ELLIPSE_TOOL:
			case ID_BUTTON_ELLIPSE_TOOL:
			case ID_BUTTON_ELLIPTICAL_SELECTION_TOOL:
			{
				CClientDC dc(this);

				if (2 == m_pts.size())
				{
					//erase old ellipse
					RubberEllipse(dc, m_pts[0], m_pts[1]);
					m_pts.pop_back();
				}

				RubberEllipse(dc, m_pts[0], point);

				m_pts.push_back(point);
			}
			break;

			case ID_BUTTON_POINTER_TOOL:
				if (!m_pts.empty())
				{
					CPoint ptAnchor(GetImagePoint(m_pts[0]));
					if (PtInSel(ptAnchor))
					{
						CRect rcSelection(0,0,0,0);
						if (GetSelRect(rcSelection))
						{
							int xOff = ptAnchor.x - rcSelection.left;
							int yOff = ptAnchor.y - rcSelection.top;
							CPoint ptOffset(GetImagePoint(point));
							ptOffset.x -= xOff;
							ptOffset.y -= yOff;
							VERIFY(pDoc->MoveSelection(m_hSelectionKey, ptOffset));
							m_pts[0] = point;
						}
					}
				}
			break;

			case ID_BUTTON_RECT_TOOL:
			case ID_BUTTON_FILLED_RECT_TOOL:
			case ID_BUTTON_RECTANGULAR_SELECTION_TOOL:
			case ID_BUTTON_TEXT_TOOL:
			{
				CClientDC dc(this);

				if (2 == m_pts.size())
				{
					//erase old rect
					RubberRect(dc, m_pts[0], m_pts[1]);
					m_pts.pop_back();
				}

				RubberRect(dc, m_pts[0], point);

				m_pts.push_back(point);
			}
			break;

			case ID_BUTTON_FREEFORM_SELECTION_TOOL:
			{
				CClientDC dc(this);
				if (!m_pts.empty())
				{
					//erase old lines
					int size = (int)m_pts.size();
					for (int i = 0; i < size - 1; ++i)
					{
						RubberLine(dc, m_pts[i], m_pts[i + 1]);
					}
				}
				m_pts.push_back(point);
				int size = (int)m_pts.size();
				for (int i = 0; i < size - 1; ++i)
				{
					RubberLine(dc, m_pts[i], m_pts[i + 1]);
				}
			}
			break;

			case ID_BUTTON_LINE_TOOL:
			{	
				CClientDC dc(this);
				
				if (2 == m_pts.size())
				{
					//erase old line
					RubberLine(dc,m_pts[0], m_pts[1]);
					m_pts.pop_back();
				}

				RubberLine(dc, m_pts[0], point);

				m_pts.push_back(point);
			}
			break;

			default:
			;//ignore
		}//end switch
	}
}

//---------------------------------------------------------------
void CMrImageView::OnToolEnd(const CPoint & point, MOUSE_BTN_DOWN mouse)
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		COLORREF color = m_foreColor;
		if (RIGHT_MOUSE_BTN_DOWN == mouse)
		{
			color = m_backColor;
		}

		switch(CMrImageView::m_unSelectedTool)
		{
			case ID_BUTTON_ELLIPSE_TOOL:
			case ID_BUTTON_FILLED_ELLIPSE_TOOL:
			{
				if (2 == m_pts.size())
				{
					//erase old ellipse
					CClientDC dc(this);
					RubberEllipse(dc, m_pts[0],  m_pts[1]);
					m_pts.pop_back();
				}

				COLORREF * pFillColor = NULL;
				if (ID_BUTTON_FILLED_ELLIPSE_TOOL == CMrImageView::m_unSelectedTool)
				{
					pFillColor = (color == m_foreColor) ? &m_backColor : &m_foreColor;
				}
				
				CRect rc(GetImagePoint(m_pts[0]), GetImagePoint(point));
				rc.NormalizeRect();
				
				CWaitCursor wait;
				pDoc->DrawEllipse(rc, color, pFillColor);
			}
			break;

			case ID_BUTTON_RECT_TOOL:
			case ID_BUTTON_FILLED_RECT_TOOL:
			{
				if (2 == m_pts.size())
				{
					//erase old rect
					CClientDC dc(this);
					RubberRect(dc, m_pts[0], m_pts[1]);
					m_pts.pop_back();
				}

				CWaitCursor wait;

				pDoc->BeginUndo();
				pDoc->DrawRectangle(GetImagePoint(m_pts[0]), GetImagePoint(point), color);

				if (ID_BUTTON_FILLED_RECT_TOOL == CMrImageView::m_unSelectedTool)
				{
					COLORREF fill = (color == m_foreColor) ? m_backColor : m_foreColor;
					pDoc->FillRectangle(GetImagePoint(m_pts[0]), GetImagePoint(point), fill);
				}
				pDoc->EndUndo();
			}
			break;

			case ID_BUTTON_ELLIPTICAL_SELECTION_TOOL:
				if (2 == m_pts.size())
				{
					//erase old ellipse
					CClientDC dc(this);
					RubberEllipse(dc, m_pts[0],  m_pts[1]);
					m_pts.pop_back();
				}
				m_pts.push_back(point);

				VERIFY(CreateSelection(TRUE, CMrImageDoc::SEL_ELLIPSE));
			break;

			case ID_BUTTON_RECTANGULAR_SELECTION_TOOL:
			{
				if (!m_pts.empty())
				{
					CRect rc(m_pts[0], point);
					m_pts.clear();
					m_pts.push_back(rc.TopLeft());
					m_pts.push_back(CPoint(rc.right, rc.top));
					m_pts.push_back(rc.BottomRight());
					m_pts.push_back(CPoint(rc.left, rc.bottom));

					VERIFY(CreateSelection(TRUE, CMrImageDoc::SEL_RECT));
					//CMrImageView::m_unSelectedTool = CMrImageView::m_unLastSelectedTool;
				}
			}
			break;

			case ID_BUTTON_TEXT_TOOL:
				if (!m_pts.empty())
				{
					CRect rc(m_pts[0], point);
				
					if (rc.Width() > 1 && rc.Height() > 1)
					{
						//create edit box that floats within the selection rectangle
						m_ptrEdit = std::auto_ptr<CTextEditCtrl>( new CTextEditCtrl );
						if (m_ptrEdit.get())
						{
							DWORD dwStyle =  WS_CHILD | WS_VISIBLE | ES_LEFT | ES_MULTILINE | WS_BORDER;
							VERIFY (m_ptrEdit->Create (dwStyle, rc, this, 42));
							CFont * pFont = GetTextFont();
							if (pFont)
							{
								m_ptrEdit->SetFont(pFont);
							}
						}
					}
				}
			break;

			case ID_BUTTON_FREEFORM_SELECTION_TOOL:
			{
				VERIFY(CreateSelection(TRUE, CMrImageDoc::SEL_POLYGON));
				//CMrImageView::m_unSelectedTool = CMrImageView::m_unLastSelectedTool;
			}
			break;

			case ID_BUTTON_LINE_TOOL:
			{
				if (2 == m_pts.size())
				{
					//erase old line
					CClientDC dc(this);
					RubberLine(dc, m_pts[0], m_pts[1]);
				}

				pDoc->DrawLine(GetImagePoint(m_pts[0]), GetImagePoint(m_pts[1]), color);
			}
			break;

			case ID_BUTTON_BRUSH_TOOL:
			case ID_BUTTON_PENCIL_TOOL:
			case ID_BUTTON_ERASE_TOOL:
				pDoc->EndUndo();
			break;

			case ID_BUTTON_TRANSPARENCY_TOOL:
			case ID_BUTTON_DROPPER_TOOL:
				//CMrImageView::m_unSelectedTool = CMrImageView::m_unLastSelectedTool;
				;//ignore
			break;

			case ID_BUTTON_POINTER_TOOL:			
			case ID_BUTTON_FILL_TOOL:
			default:
				;//ignore
		}//end switch
	}

	m_pts.clear();
	m_bTrackOutside = FALSE;
}

//---------------------------------------------------------------
void CMrImageView::OnToolCancel()
{
	if (IsToolSelected())
	{
		m_unSelectedTool = 0;
		OnToolEnd(GetMouseCursorPos(), m_eMouseBtnDown);
		Invalidate();
	}
}

//---------------------------------------------------------------
void CMrImageView::OnKeyDown( UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CScrollView::OnKeyDown(nChar, nRepCnt, nFlags);

	if (VK_ESCAPE == nChar)
	{
		OnToolCancel();
	}
}

//---------------------------------------------------------------
BOOL CMrImageView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	HCURSOR hCur = NULL;

	switch(CMrImageView::m_unSelectedTool)
	{
		case ID_BUTTON_PENCIL_TOOL:
			hCur = AfxGetApp()->LoadCursor(IDC_CURSOR_PENCIL);
		break;
		case ID_BUTTON_ERASE_TOOL:
			hCur = AfxGetApp()->LoadCursor(IDC_ERASER_CURSOR);
		break;

		case ID_BUTTON_TRANSPARENCY_TOOL:
		case ID_BUTTON_DROPPER_TOOL:
			hCur = AfxGetApp()->LoadCursor(IDC_DROPPER_CURSOR);
		break;

		case ID_BUTTON_FILL_TOOL:
			hCur = AfxGetApp()->LoadCursor(IDC_FILL_CURSOR);
		break;

		case ID_BUTTON_BRUSH_TOOL:
			hCur = AfxGetApp()->LoadCursor(IDC_BRUSH_CURSOR);
		break;

		case ID_BUTTON_ELLIPSE_TOOL:
		case ID_BUTTON_FILLED_ELLIPSE_TOOL:
		case ID_BUTTON_RECT_TOOL:
		case ID_BUTTON_FILLED_RECT_TOOL:
		case ID_BUTTON_LINE_TOOL:
		case ID_BUTTON_RECTANGULAR_SELECTION_TOOL:
		case ID_BUTTON_ELLIPTICAL_SELECTION_TOOL:
		case ID_BUTTON_FREEFORM_SELECTION_TOOL:
			hCur = AfxGetApp()->LoadStandardCursor(IDC_CROSS);
		break;

		case ID_BUTTON_POINTER_TOOL:
		default:
			hCur = NULL;//default
	}//end switch

	if (hCur)
	{
		SetCursor(hCur);
		return TRUE;
	}

	return CScrollView::OnSetCursor(pWnd, nHitTest, message);
}

//---------------------------------------------------------------
void CMrImageView::OnEditCopy()
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		if (HasSelection())
		{
			CWaitCursor wait;
			VERIFY(pDoc->Copy(m_hSelectionKey));
		}
	}
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateEditCopy(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(HasSelection());
}

//---------------------------------------------------------------
void CMrImageView::OnEditCut()
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		if (HasSelection())
		{
			CWaitCursor wait;
			VERIFY(pDoc->Cut(m_hSelectionKey));
		}
	}
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateEditCut(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(HasSelection());
}

//---------------------------------------------------------------
void CMrImageView::OnEditPaste()
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		CWaitCursor wait;

		if (HasSelection())
		{
			MergeSelection();
		}

		VERIFY(pDoc->Paste(m_hSelectionKey));
	}
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateEditPaste(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(CMrImageDoc::CanPaste());
}

//---------------------------------------------------------------
void CMrImageView::OnCrop()
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		if (HasSelection())
		{
			CWaitCursor wait;
			VERIFY(pDoc->Crop(m_hSelectionKey));
		}
	}
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateCrop(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(HasSelection());
}

//---------------------------------------------------------------
void CMrImageView::OnNudge(UINT nID)
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		if (HasSelection())
		{
			CWaitCursor wait;
			switch(nID)
			{
				case ID_BUTTON_NUDGE_UP_TOOL:
					VERIFY(pDoc->Nudge(m_hSelectionKey, CMrImageDoc::NUDGE_UP));
				break;
				case ID_BUTTON_NUDGE_RIGHT_TOOL:
					VERIFY(pDoc->Nudge(m_hSelectionKey, CMrImageDoc::NUDGE_RIGHT));
				break;
				case ID_BUTTON_NUDGE_DOWN_TOOL:
					VERIFY(pDoc->Nudge(m_hSelectionKey, CMrImageDoc::NUDGE_DOWN));
				break;
				case ID_BUTTON_NUDGE_LEFT_TOOL:
					VERIFY(pDoc->Nudge(m_hSelectionKey, CMrImageDoc::NUDGE_LEFT));
				break;
			}//end switch
		}
	}
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateNudge(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(HasSelection());
}

//---------------------------------------------------------------
void CMrImageView::OnFilterTransform(UINT nID)
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		CWaitCursor wait;

		BOOL bApplyToLayer = (HasSelection() && CMrImageView::m_bApplyToSelection);

		switch(nID)
		{
			case ID_FLIP:
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Flip(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->Flip());
				}
			break;

			case ID_GRAYSCALE:          
				if (bApplyToLayer)
				{
					VERIFY(pDoc->GrayScale(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->GrayScale());
				}
			break;

			case ID_MIRROR:             
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Mirror(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->Mirror());
				}
			break;

			case ID_ROTATE:
			{
				CRotateDlg rotate;
				if (IDOK == rotate.DoModal())
				{
					CWaitCursor wait;
					if (bApplyToLayer)
					{
						VERIFY(pDoc->Rotate(m_hSelectionKey, rotate.GetAngle()));
					}
					else
					{
						VERIFY(pDoc->Rotate(rotate.GetAngle()));
					}
				}
			}
			break;

			case ID_CONTRAST_DECREASE:  
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Contrast(m_hSelectionKey, -25));
				}
				else 
				{
					VERIFY(pDoc->Contrast(-25));
				}
			break;

			case ID_CONTRAST_INCREASE:  
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Contrast(m_hSelectionKey, 25));
				}
				else 
				{
					VERIFY(pDoc->Contrast(25));
				}
			break;

			case ID_BRIGHTNESS_DECREASE:
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Brightness(m_hSelectionKey, -20));
				}
				else 
				{
					VERIFY(pDoc->Brightness(-20));
				}
			break;

			case ID_BRIGHTNESS_INCREASE:
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Brightness(m_hSelectionKey, 20));
				}
				else 
				{
					VERIFY(pDoc->Brightness(20));
				}
			break;

			case ID_RESIZE: 
			{
				CResizeDlg resize;
				resize.SetSize(pDoc->GetSize());
				if (IDOK == resize.DoModal())
				{
					CWaitCursor wait;
					if (bApplyToLayer)
					{
						VERIFY(pDoc->Resize(m_hSelectionKey, resize.GetSize()));
					}
					else
					{
						VERIFY(pDoc->Resize(resize.GetSize()));
					}
				}
			}
			break;

			case ID_ROTATE_RIGHT:       
				if (bApplyToLayer)
				{
					VERIFY(pDoc->RotateRight(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->RotateRight());
				}
			break;

			case ID_ROTATE_LEFT:        
				if (bApplyToLayer)
				{
					VERIFY(pDoc->RotateLeft(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->RotateLeft());
				}
			break;

			case ID_NEGATIVE:
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Negative(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->Negative());
				}
			break;

			case ID_BLUR:
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Blur(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->Blur());
				}
			break;

			case ID_EMBOSS:
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Emboss(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->Emboss());
				}
			break;

			case ID_SOFTEN:
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Soften(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->Soften());
				}
			break;

			case ID_SHARPEN:
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Sharpen(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->Sharpen());
				}
			break;

			case ID_RESIZECANVAS:
			{
				CResizeDlg resize;
				CSize imageSize = pDoc->GetSize();
				resize.SetSize(imageSize);
				resize.EnableResizeSmallerThanOriginal(FALSE);
				if (IDOK == resize.DoModal())
				{
					CSize size = resize.GetSize();
					if (size.cx < imageSize.cx || size.cy < imageSize.cy)
					{
						AfxMessageBox(IDS_CANNOTMAKECANVASSMALLERTHANIMAGE, MB_OK | MB_ICONERROR);
						return;
					}
					CWaitCursor wait;
					VERIFY(pDoc->ResizeCanvas(size));
				}
			}
			break;

			case ID_SKEW:
			{
				CSkewDlg skew(this);
				skew.SetImageSize(pDoc->GetSize());
				if (IDOK == skew.DoModal())
				{
					CPoint ptPivot = skew.GetPivot();
					float horz = skew.GetHorizSkew();
					float vert = skew.GetVertSkew();
					CWaitCursor wait;
					if (bApplyToLayer)
					{
						VERIFY(pDoc->Skew(m_hSelectionKey, ptPivot, horz, vert));
					}
					else
					{
						VERIFY(pDoc->Skew(ptPivot, horz, vert));
					}
				}
			}
			break;

			case ID_FEATHER:
			{
				CFeatherDlg feather(this);
				if (IDOK == feather.DoModal())
				{
					if (bApplyToLayer)
					{
						VERIFY(pDoc->Feather(m_hSelectionKey, feather.GetWidth()));
					}
					else 
					{
						VERIFY(pDoc->Feather(feather.GetWidth()));
					}
				}
			}
			break;

			case ID_JITTER:
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Jitter(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->Jitter());
				}
			break;

			case ID_CONTOUR:
				if (bApplyToLayer)
				{
					VERIFY(pDoc->Contour(m_hSelectionKey));
				}
				else 
				{
					VERIFY(pDoc->Contour());
				}
			break;

			default:
				ASSERT(FALSE);//unknown ID value!!!
		}//end switch
	}
}

//---------------------------------------------------------------
void CMrImageView::OnEditSelectAll()
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		CWaitCursor wait;
		m_pts.clear();
		CRect rc(CPoint(0,0), pDoc->GetSize());
		m_pts.push_back(rc.TopLeft());
		m_pts.push_back(CPoint(rc.right, rc.top));
		m_pts.push_back(rc.BottomRight());
		m_pts.push_back(CPoint(rc.left, rc.bottom));
		VERIFY(CreateSelection(FALSE, CMrImageDoc::SEL_RECT));
	}
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateEditSelectAll(CCmdUI *pCmdUI)
{
	BOOL bEnable = FALSE;

	if (HasSelection())
	{
		//if there is a selection
		
		CMrImageDoc * pDoc = GetDocument();
		if (pDoc)
		{
			CRect rcImage(CPoint(0,0), pDoc->GetSize());

			//and it is not the size of the image
			//then enable select all

			CRect rcSelection(0,0,0,0);
			if (GetSelRect(rcSelection))
			{
				bEnable = (rcSelection != rcImage);
			}
		}
	}
	else
	{
		bEnable = TRUE;
	}

	pCmdUI->Enable(bEnable);
}

//---------------------------------------------------------------
void CMrImageView::OnEditSelectNone()
{
	if (HasSelection())
	{
		MergeSelection();
	}
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateEditSelectNone(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(HasSelection());
}

//---------------------------------------------------------------
void CMrImageView::OnRedEyeRemove()
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		if (HasSelection())
		{
			CWaitCursor wait;
			VERIFY(pDoc->RedEyeRemove(m_hSelectionKey));
		}
	}
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateRedEyeRemove(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(HasSelection());
}

//---------------------------------------------------------------
void CMrImageView::OnZoomIn()
{
	if (m_fZoomFactor >= 16.00f) 
		return;

	if (m_fZoomFactor == 0.50f)
		m_fZoomFactor = 0.75f;
	else if (m_fZoomFactor == 0.75f)
		m_fZoomFactor = 1.00f;
	else if (m_fZoomFactor == 1.00f)
		m_fZoomFactor = 1.50f;
	else if (m_fZoomFactor == 1.50f)
		m_fZoomFactor = 2.00f;
	else
		m_fZoomFactor*=2.00f;

	OnUpdate(NULL, 0, NULL);
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateZoomIn(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_fZoomFactor < 16.00f);
}

//---------------------------------------------------------------
void CMrImageView::OnZoomOut()
{
	if (m_fZoomFactor<=0.0625f) return;

	if(m_fZoomFactor == 2.00f) m_fZoomFactor = 1.50f;
	else if (m_fZoomFactor == 1.50f) m_fZoomFactor = 1.00f;
	else if (m_fZoomFactor == 1.00f)	m_fZoomFactor = 0.75f;
	else if (m_fZoomFactor == 0.75f)	m_fZoomFactor = 0.50f;
	else m_fZoomFactor/=2.00f;

	OnUpdate(NULL, 0, NULL);
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateZoomOut(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_fZoomFactor > 0.0625f);
}

//---------------------------------------------------------------
void CMrImageView::OnNoZoom()
{
	m_fZoomFactor = 1.00f;
	OnUpdate(NULL, 0, NULL);
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateNoZoom(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(1.00f != m_fZoomFactor);
}

//---------------------------------------------------------------
void CMrImageView::OnApplyToSelection()
{
	CMrImageView::m_bApplyToSelection = !CMrImageView::m_bApplyToSelection;
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateApplyToSelection(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(HasSelection());
	pCmdUI->SetCheck(CMrImageView::m_bApplyToSelection ? 1 : 0);
}

//---------------------------------------------------------------
void CMrImageView::OnShowSelectionBorder()
{
	CMrImageView::m_bShowSelectionBorder = !CMrImageView::m_bShowSelectionBorder;
	Invalidate();
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateShowSelectionBorder(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(HasSelection());
	pCmdUI->SetCheck(CMrImageView::m_bShowSelectionBorder ? 1 : 0);
}

//---------------------------------------------------------------
void CMrImageView::OnEditUndo()
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		if (pDoc->CanUndo())
		{
			CWaitCursor wait;
			pDoc->Undo();
		}
	}
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateEditUndo(CCmdUI *pCmdUI)
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		pCmdUI->Enable(pDoc->CanUndo());
	}
}

//---------------------------------------------------------------
void CMrImageView::OnEditRedo()
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		if (pDoc->CanRedo())
		{
			CWaitCursor wait;
			pDoc->Redo();
		}
	}
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateEditRedo(CCmdUI *pCmdUI)
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		pCmdUI->Enable(pDoc->CanRedo());
	}
}

//-----------------------------------------------------------------------------
CFont * CMrImageView::GetTextFont()
{
	CFont * pRet = NULL;

	if (NULL != m_TextFont.GetSafeHandle())
	{
		VERIFY(m_TextFont.DeleteObject());
	}

	CMainFrame * pMF = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pMF);
	
	CString strFontName = pMF->GetSelectedFontName();
	int nPointSize = pMF->GetSelectedFontPointSize();
	BOOL bBold = pMF->IsSelectedFontBold();
	BOOL bItalics = pMF->IsSelectedFontItalicized();
	BOOL bUnderline = pMF->IsSelectedFontUnderlined();

	//make sure we have a valid font name and size
	if (strFontName.IsEmpty() || nPointSize == -1)
	{
		TRACE(_T("Invalid selected font or size!\n"));
		return NULL;
	}

	//create the initial point font
	if (m_TextFont.CreatePointFont(nPointSize * 10, strFontName))
	{
		//see if we need to change the font
		if (bBold || bItalics || bUnderline)
		{
			LOGFONT lf;
			memset(&lf, 0, sizeof(lf));
			m_TextFont.GetLogFont(&lf);

			if (bBold)
			{
				lf.lfWeight = FW_BOLD;
			}

			if (bItalics)
			{
				lf.lfItalic = TRUE;
			}

			if (bUnderline)
			{
				lf.lfUnderline = TRUE;
			}

			VERIFY(m_TextFont.DeleteObject());
			if (m_TextFont.CreateFontIndirect(&lf))
			{
				pRet = &m_TextFont;
			}
		}
		else
		{
			pRet = &m_TextFont;
		}
	}
	return pRet;
}

//-----------------------------------------------------------------------------
LPARAM CMrImageView::OnTextEditComplete(WPARAM wp, LPARAM lp)
{
	CMrImageDoc * pDoc = GetDocument();
	if (pDoc)
	{
		if (m_ptrEdit.get() && ::IsWindow(m_ptrEdit->m_hWnd) && !m_ptrEdit->IsCancelled())
		{
			CString strText = m_ptrEdit->GetText();

			CRect rc;
			m_ptrEdit->GetWindowRect(rc);
			ScreenToClient(rc);
			m_pts.clear();
			m_pts.push_back(rc.TopLeft());
			m_pts.push_back(CPoint(rc.right, rc.top));
			m_pts.push_back(rc.BottomRight());
			m_pts.push_back(CPoint(rc.left, rc.bottom));
		
			CFont * pFnt = GetTextFont();
			if (pFnt)
			{
				CPoint ptTopLeft = GetImagePoint(rc.TopLeft());
				VERIFY(pDoc->DrawText(ptTopLeft, strText, *pFnt, m_foreColor));
			}
			else
			{
				TRACE(_T("Failed to create draw font!\n"));
			}
		}
	}
	return 0L;
}

//---------------------------------------------------------------
void CMrImageView::OnFontNameChange()
{
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateFontName(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(TRUE);
}

//---------------------------------------------------------------
void CMrImageView::OnFontSizeChange()
{
}

//---------------------------------------------------------------
void CMrImageView::OnUpdateFontSize(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(TRUE);
}

//---------------------------------------------------------------
void CMrImageView::OnFontBold()
{
}

//---------------------------------------------------------------
void CMrImageView::OnFontItalics()
{
}

//---------------------------------------------------------------
void CMrImageView::OnFontUnderline()
{
}

//-----------------------------------------------------------------------------
void CMrImageView::OnToolbarDropDown( NMHDR * pNotifyStruct, LRESULT * result )
{
	//get the toolbar that triggered the command
	CWnd * pToolbar = CWnd::FromHandle(pNotifyStruct->hwndFrom);
	if (NULL == pToolbar)
	{
		return;
	}

	//get the rect of the brush button on the toolbar
	CRect rc(0,0,0,0);
	pToolbar->SendMessage(TB_GETRECT, ID_BUTTON_BRUSH_TOOL, (LPARAM)&rc);
	pToolbar->ClientToScreen(&rc);

	CStyleMenu mnu;
	if (mnu.CreatePopupMenu())
	{
		CImageList ilStyle;
		VERIFY(ilStyle.Create(IDR_BRUSHSTYLES, 8, 1, RGB(0,0,0)));
		
		mnu.SetImageList(&ilStyle);

		//load the styles into the menu
		CString strItem;
		const int nTotalItems = ilStyle.GetImageCount();
		for (int i = 0; i < nTotalItems; ++i)
		{
			strItem.Format(_T("%d"), i);
			VERIFY(mnu.InsertMenu(i, MF_BYPOSITION|MF_OWNERDRAW, i, strItem));
		}

		//select the current brush style
		(void)mnu.CheckMenuItem(CMrImageView::m_unBrushStyle, MF_CHECKED);

		//display the menu and wait
		int ret = mnu.TrackPopupMenu(TPM_LEFTBUTTON | TPM_RETURNCMD, rc.left, rc.bottom, this);
		if (ret > -1 && ret < nTotalItems)
		{
			//set the new brush style
			CMrImageView::m_unBrushStyle = ret;
		}
	}
}

//-----------------------------------------------------------------------------
CTextEditCtrl::CTextEditCtrl ()
:m_strText()
,m_bCancelled(FALSE)
,m_Brush()
{	
}

//-----------------------------------------------------------------------------
CTextEditCtrl::~CTextEditCtrl()
{
}

//-----------------------------------------------------------------------------
BOOL CTextEditCtrl::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN)	
	{		
		if (pMsg->wParam == VK_ESCAPE)
		{			
			VERIFY(::TranslateMessage(pMsg));
			(void)::DispatchMessage(pMsg);
			return 1;
		}	
	}
	return CEdit::PreTranslateMessage(pMsg);
}

//-----------------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CTextEditCtrl, CEdit)
	//{{AFX_MSG_MAP(CTextEditCtrl)
	ON_WM_CHAR()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR_REFLECT()
	ON_CONTROL_REFLECT(EN_UPDATE, OnUpdate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//-----------------------------------------------------------------------------
int CTextEditCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CEdit::OnCreate(lpCreateStruct) == -1)		
		return -1;	

	CFont* font = GetParent()->GetFont();
	SetFont(font);

	SetWindowText(m_strText);

	(void)SetFocus();	
	SetSel (0,0);

	return 0;
}

//-----------------------------------------------------------------------------
void CTextEditCtrl::OnDestroy()
{
	GetWindowText(m_strText);

	CWnd * pParent = GetParent();
	if (pParent)
	{
		//notify parent that window is closing
		(void)pParent->SendMessage(WM_TEXTEDIT_COMPLETE);
	}

	CEdit::OnDestroy();
}

//-----------------------------------------------------------------------------
void CTextEditCtrl::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (nChar == VK_ESCAPE)	
	{		
		m_bCancelled = TRUE;		
		DestroyWindow();
		return;	
	}

	CEdit::OnChar(nChar, nRepCnt, nFlags);	
}

//-----------------------------------------------------------------------------
HBRUSH CTextEditCtrl::CtlColor(CDC* pDC, UINT nCtlColor) 
{
	m_Brush.DeleteObject();
	m_Brush.CreateStockObject(HOLLOW_BRUSH);
	pDC->SetBkMode(TRANSPARENT);
	return (HBRUSH)m_Brush;
}

//-----------------------------------------------------------------------------
void CTextEditCtrl::OnUpdate() 
{
	CWnd* pParent = GetParent();
	if (pParent)
	{
		CRect rect;
		GetWindowRect(rect);
		pParent->ScreenToClient(rect);
		rect.DeflateRect(2, 2);
		pParent->InvalidateRect(rect, FALSE); 
	}
}

//---------------------------------------------------------------
CStyleMenu::CStyleMenu()
:m_pImageList(NULL)
{
}

CStyleMenu::~CStyleMenu()
{
}

const int BRUSH_WIDTH = 8;
const int BRUSH_HEIGHT = 8;
const int BRUSH_BORDER_WIDTH = 4;
const int BRUSH_BORDER_HEIGHT = 4;

void CStyleMenu::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	ASSERT(NULL != m_hMenu);
	ASSERT(NULL != lpDrawItemStruct);
	ASSERT(ODT_MENU == lpDrawItemStruct->CtlType);
	ASSERT(m_pImageList);

	CDC dc;
	dc.Attach(lpDrawItemStruct->hDC);

	if (lpDrawItemStruct->itemID < 0 || lpDrawItemStruct->itemID > (UINT)m_pImageList->GetImageCount())
	{
		CRect rcClip(0,0,0,0);
		dc.GetClipBox(&rcClip);
		dc.FillSolidRect(rcClip, dc.GetBkColor());
	}
	else
	{
		VERIFY(m_pImageList->Draw(&dc, lpDrawItemStruct->itemID, CPoint(lpDrawItemStruct->rcItem.left + BRUSH_BORDER_WIDTH, lpDrawItemStruct->rcItem.top + BRUSH_BORDER_HEIGHT), ILD_MASK));

		if (MF_CHECKED & lpDrawItemStruct->itemState)
		{
			dc.DrawFocusRect(&lpDrawItemStruct->rcItem);
		}
	}
	dc.Detach(); 
}

void CStyleMenu::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	ASSERT(NULL != lpMeasureItemStruct);
	ASSERT(m_pImageList);

	lpMeasureItemStruct->itemWidth = BRUSH_WIDTH + (2 * BRUSH_BORDER_WIDTH);
	lpMeasureItemStruct->itemHeight = BRUSH_HEIGHT + (2 * BRUSH_BORDER_HEIGHT);
}

//---------------------------------------------------------------
//---------------------------------------------------------------
}//end namespace




