/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/
#pragma once

namespace MrImage
{

class CResizeDlg : public CDialog
{
	DECLARE_DYNAMIC(CResizeDlg)

public:
	CResizeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CResizeDlg();

// Dialog Data
	enum { IDD = IDD_RESIZE };

	void SetSize(const CSize & s){ m_nHoriz = s.cx; m_nVert = s.cy; }
	CSize GetSize()const{ return CSize(m_nHoriz, m_nVert); }

	void EnableResizeSmallerThanOriginal(BOOL bEnable){ m_bSizeSmaller = bEnable; }
    
	virtual BOOL OnInitDialog();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	afx_msg void OnBnClickedRadioPercentage();
	afx_msg void OnBnClickedRadioActual();
	afx_msg void OnOK();
	afx_msg void OnHorzChange( );
	afx_msg void OnVertChange( );

	DECLARE_MESSAGE_MAP()

	void CalcPercentage();
	void CalcActual();

protected:
	CSize m_sizeOriginal;
	BOOL m_bSizeSmaller;
	int m_nHoriz;
	int m_nVert;
	CSpinButtonCtrl m_wndSpinHorz;
	CSpinButtonCtrl m_wndSpinVert;
	BOOL m_bActual;
};

}//end namespace