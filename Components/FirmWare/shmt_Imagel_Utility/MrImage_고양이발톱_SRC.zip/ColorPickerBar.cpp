/*
Copyright (c) 2004, Matthew Page

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented;
you must not claim that you wrote the original software.
If you use this software in a product, an acknowledgment in
the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such,
and must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
*/

#include "stdafx.h"
#include "ColorPickerBar.h"
#include "MrImageView.h"
#include "resource.h"
#include "OptionsDlg.h"

namespace MrImage
{

const WORD ID_TAB_WND = 111;
const WORD SWITCHER_WIDTH = 50;
const WORD SWITCHER_HEIGHT = 75;

const UINT SELECTIONCHANGED_MSGID = CColorPicker::GetSelectionChangeMsgID();
const UINT SWAP_MSGID = CFgBgSwitcher::GetSwapMsgID();

IMPLEMENT_DYNAMIC(CColorPickerBar, CSizingControlBarG)
CColorPickerBar::CColorPickerBar()
{
}

CColorPickerBar::~CColorPickerBar()
{
}


BEGIN_MESSAGE_MAP(CColorPickerBar, CSizingControlBarG)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_NOTIFY(TCN_SELCHANGE, ID_TAB_WND, OnSelchangeTab)
	ON_REGISTERED_MESSAGE(SELECTIONCHANGED_MSGID, OnColorPickerSelectionChange)
	ON_REGISTERED_MESSAGE(SWAP_MSGID, OnFgBgSwitcherColorSwap)
END_MESSAGE_MAP()

int CColorPickerBar::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CSizingControlBarG::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rc;
	GetClientRect(&rc);

	CRect rcSwitcher(rc);
	rcSwitcher.right = rcSwitcher.left + SWITCHER_WIDTH;

	if (!m_FgBgSwitcher.Create(NULL, _T("Switcher"), WS_CHILD|WS_VISIBLE, rc, this, 16))
	{
		TRACE(_T("Failed to create the foreground/background switcher control!\n"));
		return -1;
	}

	//offset the left side of the tab control
	//so it doesn't cover up the switcher
	rc.left += rcSwitcher.Width();

	if (!m_Tab.Create(WS_VISIBLE|WS_CHILD|TCS_TABS|TCS_FOCUSNEVER,rc, this, ID_TAB_WND))
	{
		TRACE(_T("Failed to create tab control!\n"));
		return -1;
	}

	if (!m_Picker.Create(NULL, _T("Colors"), WS_CHILD|WS_VISIBLE, rc, &m_Tab, 42))
	{
		TRACE(_T("Failed to create picker control!\n"));
		return -1;
	}

	m_Picker.SetOwner(this);

	CString strTabName;
	VERIFY(strTabName.LoadString(IDS_TABNAME_COMMON));
	m_Tab.InsertItem(0, strTabName);
	VERIFY(strTabName.LoadString(IDS_TABNAME_WEB));
	m_Tab.InsertItem(1, strTabName);
	VERIFY(strTabName.LoadString(IDS_TABNAME_SYSTEM));
	m_Tab.InsertItem(2, strTabName);
	VERIFY(strTabName.LoadString(IDS_TABNAME_PALETTE));
	m_Tab.InsertItem(3, strTabName);

	COptionsDlg options;
	if (options.IsRememberColorTabEnabled())
	{
		//restore last selected tab
		UINT nCurTab = options.GetLastColorTab();
		(void)m_Tab.SetCurSel(nCurTab);
		OnSelchangeTab(NULL, NULL);
	}

	return 0;
}

void CColorPickerBar::OnDestroy()
{
	//save selected tab
	COptionsDlg options;
	options.SetLastColorTab(m_Tab.GetCurSel());

	CSizingControlBarG::OnDestroy();
}

void CColorPickerBar::OnSize(UINT nType, int cx, int cy)
{
	CSizingControlBarG::OnSize(nType, cx, cy);

	CRect rc;
	GetClientRect(&rc);

	CRect rcSwitcher(rc);

	if (CSizingControlBarG::IsVertDocked())
	{
		m_FgBgSwitcher.DisplayVertically(FALSE);

		//rcSwitcher.right = rcSwitcher.left + SWITCHER_WIDTH;
		rcSwitcher.bottom = rcSwitcher.top + SWITCHER_HEIGHT;

		//offset the top side of the tab control
		//so it doesn't cover up the switcher
		rc.top += rcSwitcher.Height();
	}
	else
	{
		m_FgBgSwitcher.DisplayVertically(TRUE);

		rcSwitcher.right = rcSwitcher.left + SWITCHER_WIDTH;

		//offset the left side of the tab control
		//so it doesn't cover up the switcher
		rc.left += rcSwitcher.Width();
	}

	m_FgBgSwitcher.MoveWindow(rcSwitcher);

	//size the tab window to fill the client area
	m_Tab.MoveWindow(&rc);

	m_Tab.GetClientRect(&rc);
	rc.DeflateRect(4,4,4,4);

	CRect rcTab;
	VERIFY(m_Tab.GetItemRect(0, &rcTab));

	rc.top += rcTab.Height();

	//size the picker window to fit within the tab window
	//but push it down an amount equal to the height of
	//one of the tabs
	m_Picker.MoveWindow(&rc);
}

void CColorPickerBar::OnSelchangeTab(NMHDR* pNMHDR, LRESULT* pResult)
{
	int nFocus = m_Tab.GetCurSel();

	switch (nFocus)
	{
		case 0:
			m_Picker.SetColorType(CColorPicker::COMMON_COLORS);
		break;

		case 1:
			m_Picker.SetColorType(CColorPicker::WEB_COLORS);
		break;

		case 2:
			m_Picker.SetColorType(CColorPicker::SYSTEM_COLORS);
		break;

		case 3:
			m_Picker.SetColorType(CColorPicker::IMAGE_COLORS);
		break;

		default:
			ASSERT(FALSE);
	}//end switch

	if (pResult)
	{
		*pResult = 0;
	}
}

LRESULT CColorPickerBar::OnFgBgSwitcherColorSwap (WPARAM, LPARAM)
{
	NotifySelectionChange(m_FgBgSwitcher.GetForegroundColor(), true);
	NotifySelectionChange(m_FgBgSwitcher.GetBackgroundColor(), false);
	return 0L;
}

void CColorPickerBar::NotifySelectionChange(COLORREF color, bool isForeground )
{
	CWinApp * pApp = AfxGetApp();
	POSITION posDoc = NULL;
	CDocument * pDoc = NULL;
	POSITION pos = pApp->m_pDocManager->GetFirstDocTemplatePosition();
	CDocTemplate * pDocTemplate = NULL;
	while (pos)
	{
		pDocTemplate = pApp->m_pDocManager->GetNextDocTemplate(pos);
		posDoc = pDocTemplate->GetFirstDocPosition();

		while (posDoc)
		{
			pDoc = pDocTemplate->GetNextDoc(posDoc);

			if (pDoc)
			{
				CSelectedColorChanged changed(color, isForeground);
				pDoc->UpdateAllViews(NULL, CSelectedColorChanged::HINT_SELECTED_COLOR_CHANGED, &changed);
			}
		}
	}
}

LRESULT CColorPickerBar::OnColorPickerSelectionChange (WPARAM wUnused, LPARAM lMouseBtnClicked)
{
	COLORREF selected = m_Picker.GetSelectedColor();

	if (0 == lMouseBtnClicked)
	{
		m_FgBgSwitcher.SetForegroundColor(selected);
	}
	else if (1 == lMouseBtnClicked)
	{
		m_FgBgSwitcher.SetBackgroundColor(selected);
	}

	NotifySelectionChange(m_Picker.GetSelectedColor(), (0 == lMouseBtnClicked));

	return 0L;
}

}//end namespace

