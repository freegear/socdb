;Cooperative Linux installer
;Written by NEBOR Regis
;Modified by Dan Aloni (c) 2004
;Modified 8/20/2004,2/4/2004 by George P Boutwell
;Modified 1/11/2006 by Henry Nestler

;-------------------------------------
;Good look
  !include "MUI.nsh"
  !include Sections.nsh

;  !include "coLinux_def.inc"
  !define DISTDIR     "colinux"
  !define VERSION     "2.4.0"
  !define LONGVERSION "0.6.3.0"

  !define PUBLISHER "www.colinux.org - www.shmt.co.kr"

  ;General
  Name "Cooperative Linux ${VERSION}"
  OutFile "setup_shmt_coLinux.exe"

  ShowInstDetails show
  ShowUninstDetails show

  ;Folder selection page
  InstallDir "$PROGRAMFILES\coLinux"
  
  ;Get install folder from registry if available
  InstallDirRegKey HKCU "Software\coLinux" ""

  BrandingText "${PUBLISHER}"

  VIAddVersionKey ProductName "Cooperative Linux"
  VIAddVersionKey CompanyName "${PUBLISHER}"
  VIAddVersionKey ProductVersion "${VERSION}"
  VIAddVersionKey FileVersion "${VERSION}"
  VIAddVersionKey FileDescription "An optimized virtual Linux system for Windows"
  VIAddVersionKey LegalCopyright "Copyright @ 2004 ${PUBLISHER}"
  VIProductVersion "${LONGVERSION}"

  XPStyle on

; For priority Unpack
  !insertmacro MUI_RESERVEFILE_INSTALLOPTIONS
 
;--------------------------------
;Interface Settings

  !define MUI_ABORTWARNING

;--------------------------------
;Pages

  !define MUI_HEADERIMAGE
  !define MUI_HEADERIMAGE_BITMAP "header.bmp"
  !define MUI_SPECIALBITMAP "startlogo.bmp"

  !define MUI_COMPONENTSPAGE_SMALLDESC

  !define MUI_WELCOMEPAGE_TITLE "Welcome to the coLinux ${VERSION} Setup Wizard"
  !define MUI_WELCOMEPAGE_TEXT "This wizard will guide you through the installation of Cooperative Linux ${VERSION}\r\n\r\n$_CLICK"

  !insertmacro MUI_PAGE_WELCOME

  !insertmacro MUI_PAGE_LICENSE "COPYING"
  !insertmacro MUI_PAGE_COMPONENTS
  !insertmacro MUI_PAGE_DIRECTORY
  !insertmacro MUI_PAGE_INSTFILES

  !define MUI_FINISHPAGE_LINK "Visit the Cooperative Linux website"
  !define MUI_FINISHPAGE_LINK_LOCATION "http://www.colinux.org/"
  !define MUI_FINISHPAGE_SHOWREADME "README.TXT"
  
  !insertmacro MUI_PAGE_FINISH
  !insertmacro MUI_UNPAGE_CONFIRM
  !insertmacro MUI_UNPAGE_INSTFILES
  
;--------------------------------
;Languages
 
  !insertmacro MUI_LANGUAGE "English"


;------------------------------------------------------------------------
;------------------------------------------------------------------------
;Custom Setup for image download

;Variables used to track user choice
 
 
; StartDlImageFunc down for reference resolution

Function .onInit
FunctionEnd

;------------------------------------------------------------------------
;------------------------------------------------------------------------
;Installer Sections


Section "coLinux" SeccoLinux

  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\coLinux" "DisplayName" "coLinux ${VERSION}"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\coLinux" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\coLinux" "DisplayIcon" "$INSTDIR\colinux-daemon.exe,0"
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\coLinux" "NoModify" "1"
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\coLinux" "NoRepair" "1"


  ;---------------------------------------------------------------FILES--
  ;----------------------------------------------------------------------
  ; Our Files . If you adds something here, Remember to delete it in 
  ; the uninstall section

  SetOutPath "$INSTDIR"
  File "${DISTDIR}\colinux-console-fltk.exe"
  File "${DISTDIR}\colinux-console-nt.exe"
  File "${DISTDIR}\colinux-net-daemon.exe"
  File "${DISTDIR}\colinux-slirp-net-daemon.exe"
  File "${DISTDIR}\colinux-debug-daemon.exe"
  File "${DISTDIR}\colinux-daemon.exe"
  File "${DISTDIR}\README.txt"
  File "${DISTDIR}\news.txt"
  File "${DISTDIR}\cofs.txt"
  File "${DISTDIR}\colinux-daemon.txt"
  
  ;Enable when working correctly
  ;File "${DISTDIR}\colinux-serial-daemon.exe"
  File "${DISTDIR}\linux.sys"
  File "${DISTDIR}\vmlinux"
  File /oname=vmlinux-modules.tar.gz "${DISTDIR}\vmlinux-modules.tar.gz"
  ; initrd replaces vmlinux-modules.tar.gz as preferred way to ship modules.
  File "premaid\initrd.gz"

  ;Backup config file if present
  IfFileExists "$INSTDIR\default.colinux.xml" 0 +1
  CopyFiles /SILENT "$INSTDIR\default.colinux.xml" "$INSTDIR\default.colinux.xml.old"
  File "${DISTDIR}\default.colinux.xml"

  ; Remove kludge from older installations	
  Delete "$INSTDIR\packet.dll"
  Delete "$INSTDIR\wpcap.dll"

  ;--------------------------------------------------------------/FILES--
  ;----------------------------------------------------------------------

  ;Store install folder
  WriteRegStr HKCU "Software\coLinux" "" "$INSTDIR"
  
  ;Create uninstaller
  WriteUninstaller "$INSTDIR\Uninstall.exe"

SectionEnd

Section "coLinux Virtual Ethernet Driver (TAP-Win32)" SeccoLinuxNet

  ;---------------------------------------------------------------FILES--
  ;----------------------------------------------------------------------
  ; Our Files . If you adds something here, Remember to delete it in 
  ; the uninstall section

  SetOutPath "$INSTDIR\netdriver"
  File "premaid\netdriver\OemWin2k.inf"
  File "premaid\netdriver\tap0801co.sys"
  File "premaid\netdriver\tapcontrol.exe"

  ;--------------------------------------------------------------/FILES--
  ;----------------------------------------------------------------------

SectionEnd


Section "Root Filesystem Image" SeccoLinuxImage

  ;---------------------------------------------------------------FILES--
  ;----------------------------------------------------------------------
  ; Our Files . If you adds something here, Remember to delete it in
  ; the uninstall section

  SetOutPath "$INSTDIR"
  File "7z.exe"

  CreateDirectory $INSTDIR\image
  ExecWait '"$INSTDIR\7z.exe" e "$EXEDIR\image\home_fs_2G.zip" -o"$INSTDIR\image\"'

  Delete $INSTDIR\7z.exe
  
  ;--------------------------------------------------------------/FILES--
  ;----------------------------------------------------------------------

SectionEnd
;--------------------
;Post-install section

Section -post

;---- Directly from OpenVPN install script , some minor mods

  SectionGetFlags ${SeccoLinuxNet} $R0
  IntOp $R0 $R0 & ${SF_SELECTED}
  IntCmp $R0 ${SF_SELECTED} "" notap notap
    ; TAP install/update was selected.
    ; Should we install or update?
    ; If tapcontrol error occurred, $5 will
    ; be nonzero.
    IntOp $5 0 & 0
    nsExec::ExecToStack '"$INSTDIR\netdriver\tapcontrol.exe" hwids TAP0801co'
    Pop $R0 # return value/error/timeout
    IntOp $5 $5 | $R0
    DetailPrint "tapcontrol hwids returned: $R0"

    ; If tapcontrol output string contains "TAP" we assume
    ; that TAP device has been previously installed,
    ; therefore we will update, not install.
    Push "TAP"
    Call StrStr
    Pop $R0

    IntCmp $5 0 +1 tapcontrol_check_error tapcontrol_check_error
    IntCmp $R0 -1 tapinstall

 ;tapupdate:
    DetailPrint "TAP-Win32 UPDATE (please confirm Windows-Logo-Test)"
    nsExec::ExecToLog '"$INSTDIR\netdriver\tapcontrol.exe" update "$INSTDIR\netdriver\OemWin2k.inf" TAP0801co'
    Pop $R0 # return value/error/timeout
    IntOp $5 $5 | $R0
    DetailPrint "tapcontrol update returned: $R0"
    Goto tapcontrol_check_error

 tapinstall:
    DetailPrint "TAP-Win32 INSTALL (please confirm Windows-Logo-Test)"
    nsExec::ExecToLog '"$INSTDIR\netdriver\tapcontrol.exe" install "$INSTDIR\netdriver\OemWin2k.inf" TAP0801co'
    Pop $R0 # return value/error/timeout
    IntOp $5 $5 | $R0
    DetailPrint "tapcontrol install returned: $R0"

 tapcontrol_check_error:
    IntCmp $5 +1 notap
    MessageBox MB_OK "An error occurred installing the TAP-Win32 device driver."

 notap:

SectionEnd

;--------------------
;Post-install section

Section -post
    nsExec::ExecToStack '"$INSTDIR\colinux-daemon.exe" --remove-driver'
    Pop $R0 # return value/error/timeout
    nsExec::ExecToStack '"$INSTDIR\colinux-daemon.exe" --install-driver'
    Pop $R0 # return value/error/timeout
SectionEnd


;--------------------------------
;Descriptions

  LangString DESC_SeccoLinux ${LANG_ENGLISH} "Install coLinux"
  LangString DESC_SeccoLinuxNet ${LANG_ENGLISH} "Install coLinux Virtual Ethernet Driver, which allows to create a network link between Linux and Windows"
  LangString DESC_SeccoLinuxImage ${LANG_ENGLISH} "Install coLinux Filesystem Image"
  !insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
    !insertmacro MUI_DESCRIPTION_TEXT ${SeccoLinux} $(DESC_SeccoLinux)
    !insertmacro MUI_DESCRIPTION_TEXT ${SeccoLinuxNet} $(DESC_SeccoLinuxNet)
    !insertmacro MUI_DESCRIPTION_TEXT ${SeccoLinuxImage} $(DESC_SeccoLinuxImage)
  !insertmacro MUI_FUNCTION_DESCRIPTION_END

;--------------------------------
;Uninstaller Section
;--------------------------------


Section "Uninstall"
  DeleteRegValue HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\coLinux" "DisplayName"
  DeleteRegValue HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\coLinux" "UninstallString"
  DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\coLinux"

  DetailPrint "TAP-Win32 REMOVE"
  nsExec::ExecToLog '"$INSTDIR\netdriver\tapcontrol.exe" remove TAP0801co'
  Pop $R0 # return value/error/timeout
  DetailPrint "tapcontrol remove returned: $R0"

  nsExec::ExecToStack '"$INSTDIR\colinux-daemon.exe" --remove-driver'
  Pop $R0 # return value/error/timeout

  ;---------------------------------------------------------------FILES--
  ;----------------------------------------------------------------------
  ;
  Delete "$INSTDIR\coLinux-console-fltk.exe"
  Delete "$INSTDIR\coLinux-console-nt.exe"
  Delete "$INSTDIR\coLinux-debug-daemon.exe"
  Delete "$INSTDIR\coLinux-serial-daemon.exe"
  Delete "$INSTDIR\coLinux-slirp-net-daemon.exe"
  Delete "$INSTDIR\coLinux-daemon.exe"
  Delete "$INSTDIR\coLinux-net-daemon.exe"
  Delete "$INSTDIR\coLinux-bridged-net-daemon.exe"
  Delete "$INSTDIR\linux.sys"
  Delete "$INSTDIR\vmlinux"
  Delete "$INSTDIR\initrd.gz"
  Delete "$INSTDIR\vmlinux-modules.tar.gz"
  Delete "$INSTDIR\default.coLinux.xml"
  Delete "$INSTDIR\README.txt"
  Delete "$INSTDIR\news.txt"
  Delete "$INSTDIR\cofs.txt"
  Delete "$INSTDIR\colinux-daemon.txt"

  Delete "$INSTDIR\netdriver\OemWin2k.inf"
  Delete "$INSTDIR\netdriver\tap0801co.sys"
  Delete "$INSTDIR\netdriver\tapcontrol.exe"
  
  Delete "$INSTDIR\image\home_fs_2G.zip"
  ;--------------------------------------------------------------/FILES--
  ;----------------------------------------------------------------------


  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR\netdriver"
  RMDir "$INSTDIR"

  DeleteRegKey /ifempty HKCU "Software\coLinux"

SectionEnd


; TODO coLinux runtime detection, to kill before install or upgrade

; LEGACY

;====================================================
; StrStr - Finds a given string in another given string.
;               Returns -1 if not found and the pos if found.
;          Input: head of the stack - string to find
;                      second in the stack - string to find in
;          Output: head of the stack
;====================================================
Function StrStr
  Push $0
  Exch
  Pop $0 ; $0 now have the string to find
  Push $1
  Exch 2
  Pop $1 ; $1 now have the string to find in
  Exch
  Push $2
  Push $3
  Push $4
  Push $5

  StrCpy $2 -1
  StrLen $3 $0
  StrLen $4 $1
  IntOp $4 $4 - $3

  StrStr_loop:
    IntOp $2 $2 + 1
    IntCmp $2 $4 0 0 StrStrReturn_notFound
    StrCpy $5 $1 $3 $2
    StrCmp $5 $0 StrStr_done StrStr_loop

  StrStrReturn_notFound:
    StrCpy $2 -1

  StrStr_done:
    Pop $5
    Pop $4
    Pop $3
    Exch $2
    Exch 2
    Pop $0
    Pop $1
FunctionEnd


