library verilog;
use verilog.vl_types.all;
entity mmc is
    port(
        MRESETn         : in     vl_logic;
        HCLK            : in     vl_logic;
        MCLK            : in     vl_logic;
        MCS             : in     vl_logic;
        MCMDIN          : in     vl_logic;
        MCMDOUT         : out    vl_logic;
        MCMDOUTEN       : out    vl_logic;
        MDATIN          : in     vl_logic_vector(7 downto 0);
        MDATOUT         : out    vl_logic_vector(7 downto 0);
        MDATOUTEN       : out    vl_logic
    );
end mmc;
