library verilog;
use verilog.vl_types.all;
entity S3F49SAX is
    port(
        MCLK            : in     vl_logic;
        MCMD            : inout  vl_logic;
        MDAT7           : inout  vl_logic;
        MDAT6           : inout  vl_logic;
        MDAT5           : inout  vl_logic;
        MDAT4           : inout  vl_logic;
        MDAT3           : inout  vl_logic;
        MDAT2           : inout  vl_logic;
        MDAT1           : inout  vl_logic;
        MDAT0           : inout  vl_logic
    );
end S3F49SAX;
