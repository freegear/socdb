library verilog;
use verilog.vl_types.all;
entity mmc_regmmc is
    port(
        MRESETn         : in     vl_logic;
        MSRESET         : in     vl_logic;
        HSRESET         : in     vl_logic;
        MCLK            : in     vl_logic;
        HMMCxWR         : in     vl_logic_vector(24 downto 0);
        HMMCxRD         : in     vl_logic_vector(24 downto 0);
        HCOMMAND_ok3WR  : in     vl_logic;
        HWDATA          : in     vl_logic_vector(31 downto 0);
        MOCR_update     : in     vl_logic;
        MRCA_update     : in     vl_logic;
        MRCA_up_data    : in     vl_logic_vector(15 downto 0);
        \Access\        : in     vl_logic_vector(1 downto 0);
        Index           : in     vl_logic_vector(7 downto 0);
        Value           : in     vl_logic_vector(7 downto 0);
        switch_error    : in     vl_logic;
        wr_block_buffer_4word: in     vl_logic_vector(127 downto 0);
        MCMDINDEX       : in     vl_logic_vector(5 downto 0);
        MCOMMAND_ok     : in     vl_logic;
        MWRFIELD        : in     vl_logic_vector(3 downto 0);
        wr_count        : in     vl_logic_vector(15 downto 0);
        cid_csd_overwrite: in     vl_logic;
        CSD_update      : in     vl_logic_vector(127 downto 0);
        HCID            : out    vl_logic_vector(127 downto 0);
        HRCA            : out    vl_logic_vector(15 downto 0);
        HDSR            : out    vl_logic_vector(15 downto 0);
        HCSD            : out    vl_logic_vector(127 downto 0);
        HEXT_CSD        : out    vl_logic_vector(191 downto 0);
        HSFR_OUT        : out    vl_logic_vector(7 downto 0);
        HSFR_READ       : out    vl_logic_vector(31 downto 0);
        HBUSWIDTH_CMD   : out    vl_logic_vector(31 downto 0);
        HOCR            : out    vl_logic_vector(31 downto 0);
        HCOMMAND_ok3    : out    vl_logic
    );
end mmc_regmmc;
