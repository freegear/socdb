library verilog;
use verilog.vl_types.all;
entity mmc_dmaio is
    port(
        MRESETn         : in     vl_logic;
        HCLK            : in     vl_logic;
        HSEL            : in     vl_logic;
        HADDR           : in     vl_logic_vector(31 downto 0);
        HTRANS          : in     vl_logic_vector(1 downto 0);
        HSIZE           : in     vl_logic_vector(2 downto 0);
        HWRITE          : in     vl_logic;
        HREADY          : in     vl_logic;
        HSFR00WR        : out    vl_logic;
        HSFR01WR        : out    vl_logic;
        HSFR00RD        : out    vl_logic;
        HSFR01RD        : out    vl_logic;
        HSFR02RD        : out    vl_logic;
        HSFR03RD        : out    vl_logic
    );
end mmc_dmaio;
