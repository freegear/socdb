library verilog;
use verilog.vl_types.all;
entity mmc_delay is
    port(
        MCMDOUT         : in     vl_logic;
        MCMDOUTEN       : in     vl_logic;
        MDATOUT         : in     vl_logic_vector(7 downto 0);
        MDATOUTEN       : in     vl_logic;
        MCSELECT        : in     vl_logic;
        bus1            : in     vl_logic;
        bus4            : in     vl_logic;
        bus8            : in     vl_logic;
        cmd_index       : in     vl_logic_vector(5 downto 0);
        MCMDOUT_dly     : out    vl_logic;
        MCMDOUTEN_dly   : out    vl_logic;
        MDATOUT_dly     : out    vl_logic_vector(7 downto 0);
        MDATOUTEN_dly   : out    vl_logic;
        HOUTDLY         : in     vl_logic_vector(5 downto 0)
    );
end mmc_delay;
