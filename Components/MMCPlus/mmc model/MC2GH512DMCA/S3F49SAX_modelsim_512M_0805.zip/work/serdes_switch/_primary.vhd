library verilog;
use verilog.vl_types.all;
entity serdes_switch is
    port(
        MCSTATE         : in     vl_logic_vector(4 downto 0);
        MCLK            : in     vl_logic;
        MRESETn         : in     vl_logic;
        MCS             : in     vl_logic;
        MCMDIN          : in     vl_logic;
        MDATIN          : in     vl_logic_vector(7 downto 0);
        cmdin           : out    vl_logic;
        datin           : out    vl_logic_vector(7 downto 0)
    );
end serdes_switch;
