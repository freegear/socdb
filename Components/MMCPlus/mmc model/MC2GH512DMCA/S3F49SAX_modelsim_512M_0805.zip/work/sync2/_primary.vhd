library verilog;
use verilog.vl_types.all;
entity sync2 is
    port(
        RESETn          : in     vl_logic;
        CLK1            : in     vl_logic;
        STB1            : in     vl_logic;
        CLK2            : in     vl_logic;
        STB2            : out    vl_logic
    );
end sync2;
