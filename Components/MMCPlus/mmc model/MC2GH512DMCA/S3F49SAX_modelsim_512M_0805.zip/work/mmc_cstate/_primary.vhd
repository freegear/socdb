library verilog;
use verilog.vl_types.all;
entity mmc_cstate is
    generic(
        MMC_IDLE        : integer := 0;
        MMC_READY       : integer := 1;
        MMC_IDENT       : integer := 2;
        MMC_STBY        : integer := 3;
        MMC_TRAN        : integer := 4;
        MMC_DATA        : integer := 5;
        MMC_RCV         : integer := 6;
        MMC_PRG         : integer := 7;
        MMC_DIS         : integer := 8;
        MMC_BTST        : integer := 9;
        MMC_IRQ         : integer := 10;
        SPI_IDLE        : integer := 16;
        SPI_STBY        : integer := 19;
        SPI_DATA        : integer := 21;
        SPI_RCV         : integer := 22;
        SPI_PRG         : integer := 23;
        SPI_DIS         : integer := 24;
        MMC_INA         : integer := 11;
        IFIELD          : integer := 0;
        SFIELD          : integer := 1;
        TFIELD          : integer := 2;
        XFIELD          : integer := 3;
        AFIELD          : integer := 4;
        CFIELD          : integer := 5;
        EFIELD          : integer := 6;
        HFIELD          : integer := 7;
        RFIELD          : integer := 8;
        LFIELD          : integer := 9;
        DFIELD          : integer := 10;
        UFIELD          : integer := 11;
        BFIELD          : integer := 12;
        PFIELD          : integer := 13;
        GFIELD          : integer := 14
    );
    port(
        MRESETn         : in     vl_logic;
        MCLK            : in     vl_logic;
        MCSELECT        : in     vl_logic;
        MCOMMAND        : in     vl_logic_vector(47 downto 0);
        MSTATUS         : in     vl_logic_vector(31 downto 0);
        MCSTATEWR       : in     vl_logic_vector(3 downto 0);
        MCSTATEWR_MANU  : in     vl_logic;
        rd_field        : in     vl_logic_vector(3 downto 0);
        crc16_ok        : in     vl_logic;
        cstnormal       : in     vl_logic_vector(4 downto 0);
        cststop         : in     vl_logic_vector(4 downto 0);
        MOCR            : in     vl_logic_vector(31 downto 0);
        MCSTNORM        : in     vl_logic_vector(4 downto 0);
        MCSTSTOP        : in     vl_logic_vector(4 downto 0);
        MCSTMANU        : in     vl_logic_vector(4 downto 0);
        MDIS2RCV        : in     vl_logic;
        MCSTATE         : out    vl_logic_vector(4 downto 0)
    );
end mmc_cstate;
