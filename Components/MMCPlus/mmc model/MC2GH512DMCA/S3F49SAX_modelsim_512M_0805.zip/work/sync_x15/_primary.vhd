library verilog;
use verilog.vl_types.all;
entity sync_x15 is
    port(
        RESETn          : in     vl_logic;
        CLK1            : in     vl_logic;
        STB1            : in     vl_logic_vector(14 downto 0);
        CLK2            : in     vl_logic;
        STB2            : out    vl_logic_vector(14 downto 0)
    );
end sync_x15;
