library verilog;
use verilog.vl_types.all;
entity mmc_fifosfr is
    port(
        MRESETn         : in     vl_logic;
        HCLK            : in     vl_logic;
        HWDATA          : in     vl_logic_vector(31 downto 0);
        HSFR00WR        : in     vl_logic
    );
end mmc_fifosfr;
