library verilog;
use verilog.vl_types.all;
entity mmc_dbg is
    port(
        MRESETn         : in     vl_logic;
        HCLK            : in     vl_logic;
        HSEL            : in     vl_logic;
        HADDR           : in     vl_logic_vector(31 downto 0);
        HTRANS          : in     vl_logic_vector(1 downto 0);
        HSIZE           : in     vl_logic_vector(2 downto 0);
        HWRITE          : in     vl_logic;
        HREADY          : in     vl_logic;
        HRDATA          : out    vl_logic_vector(31 downto 0);
        HRESP           : out    vl_logic_vector(1 downto 0);
        HREADYOUT       : out    vl_logic;
        HDECODE         : in     vl_logic_vector(15 downto 0);
        HCSTATE         : in     vl_logic_vector(4 downto 0);
        HCMDFIELD       : in     vl_logic_vector(3 downto 0);
        HRESPFIELD      : in     vl_logic_vector(3 downto 0);
        HWRFIELD        : in     vl_logic_vector(3 downto 0);
        HRDFIELD        : in     vl_logic_vector(3 downto 0)
    );
end mmc_dbg;
