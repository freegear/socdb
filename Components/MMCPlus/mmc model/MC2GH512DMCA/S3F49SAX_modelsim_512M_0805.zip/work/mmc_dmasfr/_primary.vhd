library verilog;
use verilog.vl_types.all;
entity mmc_dmasfr is
    port(
        MRESETn         : in     vl_logic;
        HCLK            : in     vl_logic;
        HSFR00WR        : in     vl_logic;
        HSFR01WR        : in     vl_logic;
        HWDATA          : in     vl_logic_vector(31 downto 0);
        HIADDR          : out    vl_logic_vector(29 downto 0);
        HDST            : out    vl_logic_vector(1 downto 0);
        HICNT           : out    vl_logic_vector(19 downto 0);
        HCCNT_CLR       : out    vl_logic;
        HIRBCNT         : out    vl_logic_vector(2 downto 0);
        HIRBSZ          : out    vl_logic_vector(4 downto 0);
        HXENABLE        : out    vl_logic;
        HXMODE          : out    vl_logic;
        HAR             : out    vl_logic;
        HDAE            : out    vl_logic
    );
end mmc_dmasfr;
