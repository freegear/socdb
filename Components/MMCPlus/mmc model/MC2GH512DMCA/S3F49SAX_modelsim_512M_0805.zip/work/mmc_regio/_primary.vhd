library verilog;
use verilog.vl_types.all;
entity mmc_regio is
    port(
        MRESETn         : in     vl_logic;
        MCLK            : in     vl_logic;
        HSEL            : in     vl_logic;
        HADDR           : in     vl_logic_vector(31 downto 0);
        HTRANS          : in     vl_logic_vector(1 downto 0);
        HSIZE           : in     vl_logic_vector(2 downto 0);
        HWRITE          : in     vl_logic;
        HREADY          : in     vl_logic;
        HMMCxWR         : out    vl_logic_vector(24 downto 0);
        HMMCxRD         : out    vl_logic_vector(24 downto 0);
        HSFRxWR         : out    vl_logic_vector(18 downto 0);
        HSFRxRD         : out    vl_logic_vector(18 downto 0)
    );
end mmc_regio;
