/****************************************************************************
 * file name	: nor_test.h
 * Date			: 15. 04. 2005
 * Version		: 1.0
 * Description	: NOR flash test menu display function
 *
 *
 ****************************************************************************/

#ifndef __NOR_TEST_H__
#define __NOR_TEST_H__


#define	NOR_FLASH_AMD		1
#define	NOR_FLASH_INTEL		2

static U32 Which_NOR_flash;

void NOR_flash_test(void);
void Check_NOR_flash(void);

#endif /*__NOR_TEST_H__*/
