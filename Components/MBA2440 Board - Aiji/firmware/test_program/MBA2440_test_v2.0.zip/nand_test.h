/****************************************************************************
 * file name	: nand_test.h
 * Date			: 15. 04. 2005
 * Version		: 1.0
 * Description	: NAND flash test menu display function
 *
 *
 ****************************************************************************/

#ifndef __NAND_TEST_H__
#define __NAND_TEST_H__


#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h"


#define NAND_CMD_READ0		0x00
#define NAND_CMD_READ1		0x01
#define NAND_CMD_PAGEPROG	0x10
#define NAND_CMD_READOOB	0x50
#define NAND_CMD_ERASE1		0x60
#define NAND_CMD_STATUS		0x70
#define NAND_CMD_SEQIN		0x80
#define NAND_CMD_READID		0x90
#define NAND_CMD_ERASE2		0xd0
#define NAND_CMD_RESET		0xff


#define NAND_OOB_SIZE		16
#define NAND_PAGE_SIZE		512
#define NAND_PAGE_COUNT		32
#define NAND_BLOCK_SIZE		(NAND_PAGE_SIZE*NAND_PAGE_COUNT)


#define TACLS				1
#define TWRPH0				5
#define TWRPH1				0



#define NF_SOFT_UnLock()	{rNFCONT&=~(1<<12);}
#define NF_MECC_UnLock()	{rNFCONT&=~(1<<5);}
#define NF_MECC_Lock()		{rNFCONT|=(1<<5);}
#define NF_SECC_UnLock()	{rNFCONT&=~(1<<6);}
#define NF_SECC_Lock()		{rNFCONT|=(1<<6);}
#define NF_CMD(cmd)			{rNFCMD=cmd;}
#define NF_ADDR(addr)		{rNFADDR=addr;}	
#define NF_nFCE_L()			{rNFCONT&=~(1<<1);}
#define NF_nFCE_H()			{rNFCONT|=(1<<1);}
#define NF_RSTECC()			{rNFCONT|=(1<<4);}
#define NF_RDDATA() 		(rNFDATA)
#define NF_RDDATA8() 		(rNFDATA8)
#define NF_WRDATA(data) 	{rNFDATA=data;}
#define NF_WRDATA8(data) 	{rNFDATA8=data;}

// RnB Signal
#define NF_CLEAR_RB()    	{rNFSTAT |= (1<<2);}	// Have write '1' to clear this bit.
#define NF_DETECT_RB()    	{while(!(rNFSTAT&(1<<2)));}



static U8 seBuf[16]= 
{0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};




void spin_wheel(void);
void NAND_flash_test(void);

void NAND_init(void);
void NAND_reset(void);
int NAND_readID(void);

void NAND_check_block(U32 blk_max_cnt);
int NAND_check_badblock(U32 block);
int NAND_mark_badblock(U32 block);

void NAND_erase(U32 blk_max_cnt);
int NAND_erase_block(U32 block);

void NAND_read(U32 blk_max_cnt);
int NAND_read_block(U32 b_num, U8 *dst_addr);
int NAND_read_page(U32 block, U32 page, U8 *buffer);

void NAND_write(U32 blk_max_cnt);
int NAND_write_block(U32 b_num, U8 *src_addr);
int NAND_write_page(U32 block, U32 page, U8 *buffer);

void __irq NAND_RxInt(void);


#endif /*__NAND_TEST_H__*/
