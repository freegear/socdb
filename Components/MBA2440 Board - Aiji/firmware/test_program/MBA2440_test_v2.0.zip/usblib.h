/****************************************************************
 NAME: usblib.h
 DESC: 
 HISTORY:
 Mar.25.2002:purnnamu: ported for S3C2410X.
 ****************************************************************/
#ifndef __USBLIB_H__
#define __USBLIB_H__

#include "usb.h"


void Ep0Handler(void);
void InitDescriptorTable(void);
void PrintEp0Pkt(unsigned char *pt);


#define EP0_STATE_INIT 			(0)  

//NOTE: The ep0State value in a same group should be added by 1.
#define EP0_STATE_GD_DEV_0	 	(10)  //10-10=0 
#define EP0_STATE_GD_DEV_1 		(11)  //11-10=1
#define EP0_STATE_GD_DEV_2 		(12)  //12-10=2

#define EP0_STATE_GD_CFG_0	 	(20)
#define EP0_STATE_GD_CFG_1 		(21)
#define EP0_STATE_GD_CFG_2 		(22)
#define EP0_STATE_GD_CFG_3 		(23)
#define EP0_STATE_GD_CFG_4 		(24)

#define EP0_STATE_GD_CFG_ONLY_0		(40)
#define EP0_STATE_GD_CFG_ONLY_1		(41)
#define EP0_STATE_GD_IF_ONLY_0 		(42)
#define EP0_STATE_GD_IF_ONLY_1 		(43)
#define EP0_STATE_GD_EP0_ONLY_0		(44)
#define EP0_STATE_GD_EP1_ONLY_0		(45)


#define EP0_STATE_GD_STR_I0	 	(30)  
#define EP0_STATE_GD_STR_I1	 	(31)  
#define EP0_STATE_GD_STR_I2	 	(32)  

extern unsigned int ep0State;

extern volatile int isUsbdSetConfiguration;



#define PWR_REG_DEFAULT_VALUE (DISABLE_SUSPEND)

#define EP0_STATE_INIT 			(0)  

//NOTE: The ep0State value in a same group should be added by 1.
#define EP0_STATE_GD_DEV_0	 	(10)  //10-10=0 
#define EP0_STATE_GD_DEV_1 		(11)  //11-10=1
#define EP0_STATE_GD_DEV_2 		(12)  //12-10=2

#define EP0_STATE_GD_CFG_0	 	(20)
#define EP0_STATE_GD_CFG_1 		(21)
#define EP0_STATE_GD_CFG_2 		(22)
#define EP0_STATE_GD_CFG_3 		(23)
#define EP0_STATE_GD_CFG_4 		(24)

#define EP0_STATE_GD_CFG_ONLY_0		(40)
#define EP0_STATE_GD_CFG_ONLY_1		(41)
#define EP0_STATE_GD_IF_ONLY_0 		(42)
#define EP0_STATE_GD_IF_ONLY_1 		(43)
#define EP0_STATE_GD_EP0_ONLY_0		(44)
#define EP0_STATE_GD_EP1_ONLY_0		(45)

#define EP0_STATE_GD_STR_I0	 	(30)  
#define EP0_STATE_GD_STR_I1	 	(31)  
#define EP0_STATE_GD_STR_I2	 	(32)  

//************************
//       Endpoint 0      
//************************

// Standard bmRequestTyje (Direction) 
#define HOST_TO_DEVICE              (0x00)
#define DEVICE_TO_HOST              (0x80)    

// Standard bmRequestType (Type) 
#define STANDARD_TYPE               (0x00)
#define CLASS_TYPE                  (0x20)
#define VENDOR_TYPE                 (0x40)
#define RESERVED_TYPE               (0x60)

// Standard bmRequestType (Recipient) 
#define DEVICE_RECIPIENT            (0)
#define INTERFACE_RECIPIENT         (1)
#define ENDPOINT_RECIPIENT          (2)
#define OTHER_RECIPIENT             (3)

// Feature Selectors 
#define DEVICE_REMOTE_WAKEUP        (1)
#define EP_STALL                    (0)

// Standard Request Codes 
#define GET_STATUS                  (0)
#define CLEAR_FEATURE               (1)
#define SET_FEATURE                 (3)
#define SET_ADDRESS                 (5)
#define GET_DESCRIPTOR              (6)
#define SET_DESCRIPTOR              (7)
#define GET_CONFIGURATION           (8)
#define SET_CONFIGURATION           (9)
#define GET_INTERFACE               (10)
#define SET_INTERFACE               (11)
#define SYNCH_FRAME                 (12)

// Class-specific Request Codes 
#define GET_DEVICE_ID               (0)
#define GET_PORT_STATUS             (1)
#define SOFT_RESET                  (2)

// Descriptor Types
#define DEVICE_TYPE                 (1)
#define CONFIGURATION_TYPE          (2)
#define STRING_TYPE                 (3)
#define INTERFACE_TYPE              (4)
#define ENDPOINT_TYPE               (5)

//configuration descriptor: bmAttributes 
#define CONF_ATTR_DEFAULT	    (0x80) //Spec 1.0 it was BUSPOWERED bit.
#define CONF_ATTR_REMOTE_WAKEUP (0x20)
#define CONF_ATTR_SELFPOWERED   (0x40)

//endpoint descriptor
#define EP_ADDR_IN		    	(0x80)	
#define EP_ADDR_OUT		    	(0x00)

#define EP_ATTR_CONTROL		    (0x0)	
#define EP_ATTR_ISOCHRONOUS	    (0x1)
#define EP_ATTR_BULK		    (0x2)
#define EP_ATTR_INTERRUPT	    (0x3)	


//string descriptor
#define LANGID_US_L 		    (0x09)  
#define LANGID_US_H 		    (0x04)


// USB
//#define USBDMA					(1)


struct USB_SETUP_DATA{
    unsigned char bmRequestType;    
    unsigned char bRequest;         
    unsigned char bValueL;          
    unsigned char bValueH;          
    unsigned char bIndexL;          
    unsigned char bIndexH;          
    unsigned char bLengthL;         
    unsigned char bLengthH;         
};


struct USB_DEVICE_DESCRIPTOR{
    unsigned char bLength;    
    unsigned char bDescriptorType;         
    unsigned char bcdUSBL;
    unsigned char bcdUSBH;
    unsigned char bDeviceClass;          
    unsigned char bDeviceSubClass;          
    unsigned char bDeviceProtocol;          
    unsigned char bMaxPacketSize0;         
    unsigned char idVendorL;
    unsigned char idVendorH;
    unsigned char idProductL;
    unsigned char idProductH;
    unsigned char bcdDeviceL;
    unsigned char bcdDeviceH;
    unsigned char iManufacturer;
    unsigned char iProduct;
    unsigned char iSerialNumber;
    unsigned char bNumConfigurations;
};


struct USB_CONFIGURATION_DESCRIPTOR{
    unsigned char bLength;    
    unsigned char bDescriptorType;         
    unsigned char wTotalLengthL;
    unsigned char wTotalLengthH;
    unsigned char bNumInterfaces;
    unsigned char bConfigurationValue;
    unsigned char iConfiguration;
    unsigned char bmAttributes;
    unsigned char maxPower;          
};
    

struct USB_INTERFACE_DESCRIPTOR{
    unsigned char bLength;    
    unsigned char bDescriptorType;         
    unsigned char bInterfaceNumber;
    unsigned char bAlternateSetting;
    unsigned char bNumEndpoints;
    unsigned char bInterfaceClass;
    unsigned char bInterfaceSubClass;
    unsigned char bInterfaceProtocol;
    unsigned char iInterface;
};


struct USB_ENDPOINT_DESCRIPTOR{
    unsigned char bLength;    
    unsigned char bDescriptorType;         
    unsigned char bEndpointAddress;
    unsigned char bmAttributes;
    unsigned char wMaxPacketSizeL;
    unsigned char wMaxPacketSizeH;
    unsigned char bInterval;
};


extern unsigned int ep0State;

extern volatile int isUsbdSetConfiguration;



void Ep1Handler(void);
void PrepareEp1Fifo(void);


void Ep3Handler(void);
void Ep3HandlerOptimized(void);

void __irq IsrDma2(void);
void ClearEp3OutPktReady(void);


void DbgPrintf(char *fmt,...);
void ConfigUsbd(void);
void ReconfigUsbd(void);

void RdPktEp0(unsigned char *buf,int num);
void WrPktEp0(unsigned char *buf,int num);
void WrPktEp1(unsigned char *buf,int num);
void WrPktEp2(unsigned char *buf,int num);
void RdPktEp3(unsigned char *buf,int num);
void RdPktEp4(unsigned char *buf,int num);

void ConfigEp3IntMode(void);
void ConfigEp3DmaMode(unsigned int bufAddr,unsigned int count);


void Ep0Handler(void);
void InitDescriptorTable(void);
void PrintEp0Pkt(unsigned char *pt);

#endif /*__USBLIB_H__*/

