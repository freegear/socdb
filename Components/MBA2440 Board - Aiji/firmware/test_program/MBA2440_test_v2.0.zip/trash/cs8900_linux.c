/*************************************************************************/
/*                                                                       */
/* FILE			CS8900.C                                                 */
/*                                                                       */
/* FUNCTION		CS8900 TEST ROUTINE                                      */
/*                                                                       */
/* DESCRIPTION                                                           */
/*                                                                       */
/* 		This is a CS8900 program for M300 system with samsung S3C2410.   */
/*                                                                       */
/* DEPENDENCIES                                                          */
/*                                                                       */
/* EDITED BY                                                             */
/* 		sjjo	Initialize                                               */
/*                                                                       */
/* Copyright (C) 1998-2005 AIJISYSTEM CO.,LTD.                           */
/*************************************************************************/
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "def.h"
#include "option.h"
//#include "s3c2410.h"
#include "2440lib.h"
#include "2440slib.h" 
#include "cs8900.h"
//#include <net.h>



#undef ETH_DEBUG

void * Items_CS8900[][2]=
{
    (void *)Get_CS8900_ID,	"Get_CS8900_ID     ",
    0,0
};

/*************************************************************************/
/* CS8900 Test Routine for M300                                          */
/*************************************************************************/
void TEST_CS8900(void)
{
	while(1)
    {
		int i=0;
		
		Uart_Printf("\n\n");
        Uart_Printf("$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        Uart_Printf("$                        $\n");
        Uart_Printf("$  CS8900 FUNCTION TEST  $\n");
        Uart_Printf("$                        $\n");
        Uart_Printf("$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        
        while(1) //display menu
        {   
            Uart_Printf("(%d) %s\n",i++,Items_CS8900[i][1]);
            if((int)(Items_CS8900[i][0])==0) break;
        }
        Uart_Printf("(ESC) Exit and Previous\n");
        
        Uart_Printf("\nSelect the Items to test : ");
        i = Uart_GetIntNum();
        Uart_Printf("\n");
        if(i==0x1b) break;
        
        if(i>=0 && (i<(sizeof(Items_CS8900)/8)) ) 
            ( (void (*)(void)) (Items_CS8900[i][0]) )();            
    }
}

// packet page register access functions
static unsigned short get_reg_init_bus (int regno)
{
	/* force 16 bit busmode */
	volatile unsigned char c;

#ifdef ETH_DEBUG
	c = CS8900_BUS16_0;
	c = CS8900_BUS16_1;
	c = CS8900_BUS16_0;
	c = CS8900_BUS16_1;
	c = CS8900_BUS16_0;
#endif

	CS8900_PPTR = regno;
	return (unsigned short) CS8900_PDATA;
}

#ifdef ETH_DEBUG
static unsigned short get_reg (int regno)
{
	CS8900_PPTR = regno;
	return (unsigned short) CS8900_PDATA;
}
#endif

#ifdef ETH_DEBUG
static void put_reg (int regno, unsigned short val)
{
	CS8900_PPTR = regno;
	CS8900_PDATA = val;
}
#endif

#ifdef ETH_DEBUG
static void eth_reset (void)
{
	int tmo;
	unsigned short us;

	/* reset NIC */
	put_reg (PP_SelfCTL, get_reg (PP_SelfCTL) | PP_SelfCTL_Reset);

	/* wait for 200ms */
	Delay (200000);
	/* Wait until the chip is reset */

//	tmo = get_timer (0) + 1 * CFG_HZ;
//	while ((((us = get_reg_init_bus (PP_SelfSTAT)) & PP_SelfSTAT_InitD) == 0)
//		   && tmo < get_timer (0))
		/*NOP*/;
}
#endif //ETH_DEBUG

#ifdef ETH_DEBUG
static void eth_reginit (void)
{
	/* receive only error free packets addressed to this card */
	put_reg (PP_RxCTL, PP_RxCTL_IA | PP_RxCTL_Broadcast | PP_RxCTL_RxOK);
	/* do not generate any interrupts on receive operations */
	put_reg (PP_RxCFG, 0);
	/* do not generate any interrupts on transmit operations */
	put_reg (PP_TxCFG, 0);
	/* do not generate any interrupts on buffer operations */
	put_reg (PP_BufCFG, 0);
	/* enable transmitter/receiver mode */
	put_reg (PP_LineCTL, PP_LineCTL_Rx | PP_LineCTL_Tx);
}
#endif //ETH_DEBUG

#ifdef ETH_DEBUG
void cs8900_get_enetaddr (U8 * addr)
{
	int i;
	unsigned char env_enetaddr[6];

	/* verify chip id */
	if (get_reg_init_bus (PP_ChipID) != 0x630e)
		return;
	eth_reset ();
}
#endif //ETH_DEBUG

#ifdef ETH_DEBUG
void eth_halt (void)
{
	/* disable transmitter/receiver mode */
	put_reg (PP_LineCTL, 0);

	/* "shutdown" to show ChipID or kernel wouldn't find he cs8900 ... */
	get_reg_init_bus (PP_ChipID);
}
#endif //ETH_DEBUG

int eth_init (void)
{

	/* verify chip id */
	if (get_reg_init_bus (PP_ChipID) != 0x630e) {
		printf ("CS8900 Ethernet chip not found?!\n");
		return 0;
	}

#ifdef ETH_DEBUG
//	eth_reset ();
	/* set the ethernet address */
//	put_reg (PP_IA + 0, bd->bi_enetaddr[0] | (bd->bi_enetaddr[1] << 8));
//	put_reg (PP_IA + 2, bd->bi_enetaddr[2] | (bd->bi_enetaddr[3] << 8));
//	put_reg (PP_IA + 4, bd->bi_enetaddr[4] | (bd->bi_enetaddr[5] << 8));

//	eth_reginit ();
#endif // ETH_DEBUG
	return 0;
}

#ifdef ETH_DEBUG
/* Get a data block via Ethernet */
extern int eth_rx (void)
{
	int i;
	unsigned short rxlen;
	unsigned short *addr;
	unsigned short status;

	status = get_reg (PP_RER);

	if ((status & PP_RER_RxOK) == 0)
		return 0;

	status = CS8900_RTDATA;		/* stat */
	rxlen = CS8900_RTDATA;		/* len */

#ifdef DEBUG
	if (rxlen > PKTSIZE_ALIGN + PKTALIGN)
		printf ("packet too big!\n");
#endif
//	for (addr = (unsigned short *) NetRxPackets[0], i = rxlen >> 1; i > 0; i--)
//		*addr++ = CS8900_RTDATA;
	if (rxlen & 1)
		*addr++ = CS8900_RTDATA;

	/* Pass the packet up to the protocol layers. */
//	NetReceive (NetRxPackets[0], rxlen);

	return rxlen;
}
#endif //ETH_RX

#ifdef ETH_DEBUG
/* Send a data block via Ethernet. */
extern int eth_send (volatile void *packet, int length)
{
	volatile unsigned short *addr;
	int tmo;
	unsigned short s;

retry:
	/* initiate a transmit sequence */
	CS8900_TxCMD = PP_TxCmd_TxStart_Full;
	CS8900_TxLEN = length;

	/* Test to see if the chip has allocated memory for the packet */
	if ((get_reg (PP_BusSTAT) & PP_BusSTAT_TxRDY) == 0) {
		/* Oops... this should not happen! */
#ifdef ETH_DEBUG
		printf ("cs: unable to send packet; retrying...\n");
#endif
//		for (tmo = get_timer (0) + 5 * CFG_HZ; get_timer (0) < tmo;)
			/*NOP*/;
		eth_reset ();
		eth_reginit ();
		goto retry;
	}

	/* Write the contents of the packet */
	/* assume even number of bytes */
	for (addr = packet; length > 0; length -= 2)
		CS8900_RTDATA = *addr++;

	/* wait for transfer to succeed */
//	tmo = get_timer (0) + 5 * CFG_HZ;
	while ((s = get_reg (PP_TER) & ~0x1F) == 0) {
//		if (get_timer (0) >= tmo)
			break;
	}

	/* nothing */ ;
	if ((s & (PP_TER_CRS | PP_TER_TxOK)) != PP_TER_TxOK) {
#ifdef ETH_DEBUG
		printf ("\ntransmission error %#x\n", s);
#endif
	}
	return 0;
}
#endif //ETH_DEBUG


void Get_CS8900_ID(void)
{
	unsigned short i;
	i = eth_init();
	Uart_Printf("ID[%x]\n",i);
}