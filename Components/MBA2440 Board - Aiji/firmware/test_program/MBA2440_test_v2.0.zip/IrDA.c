#include <string.h>
#include <stdlib.h>
#include "2440addr.h"
#include "2440lib.h"
#include "def.h"
#include "irda.h"


#define IrDA_BUFLEN 32

void IrDA_Port_Set(void);
void IrDA_Port_Return(void);

void __irq IrDA_TxInt(void);
void __irq IrDA_RxOrErr(void);
void __sub_IrDA_RxInt(void);
void __sub_IrDA_RxErrInt(void);

volatile U32 *debug_t;


volatile U8 *IrDAdataPt;
volatile U8 *IrDAdataFl;
volatile U32 IrDA_cnt,IrDA_end,IrDA_err,IrDA_BAUD;
volatile U32 sirda_rGPBCON,sirda_rGPBDAT,sirda_rGPBUP;
volatile U32 sirda_rGPHCON,sirda_rGPHDAT,sirda_rGPHUP;
volatile U32 sirda_ULCON2,sirda_UCON2,sirda_UFCON2,sirda_UMCON2,sirda_UBRDIV2;


void * func_irda_test[][2]=
{
//IrDA
	(void *)Test_IrDA_Rx, 				"UART2 IrDA Rx  ",
	(void *)Test_IrDA_Tx, 				"UART2 IrDA Tx  ",
	0,0
};

void IrDA_Test(void)
{
	int i, sel;

	while(1)
	{
		i = 0;
		Uart_Printf("+-----------------[ IrDA test ]-------------------+\n");
		while(1)
		{   //display menu
			Uart_Printf("| %2d:%s\n",i+1,func_irda_test[i][1]);
			i++;
			if((int)(func_irda_test[i][0])==0)	break;
		}
		Uart_Printf("| %2d:Previous menu\n", i+1);
		Uart_Printf("+-------------------------------------------------+\n");
		Uart_Printf(" Select the number to test : ");
		sel = Uart_GetIntNum();
		sel--;
		Uart_Printf("+-------------------------------------------------+\n\n\n");
		if(sel == i){
			return;
		}if(sel>=0 && (sel<((sizeof(func_irda_test)-1)/8)) ){
			( (void (*)(void)) (func_irda_test[sel][0]) )();
		}else{
			Uart_Printf("Wrong number seleted.. Try again!!\n\n\n");
		}
	}
}


void IrDA_Port_Set(void)
{
    //Push UART GPIO port configuration
    sirda_rGPBCON	= rGPBCON;
    sirda_rGPBDAT	= rGPBDAT;
    sirda_rGPBUP	= rGPBUP;
    sirda_rGPHCON	= rGPHCON;
    sirda_rGPHDAT	= rGPHDAT;
    sirda_rGPHUP	= rGPHUP;
    
    //Configure IrDA port
    rGPBDAT |= (1<<1);	
    rGPBCON &= 0x3ffff3;
    rGPBCON |= (1<<2);	// Output(nIrDATXDEN)
    rGPBUP  |= (1<<1);	//Uart port pull-up disable
    rGPHCON &= 0x3c0fff;
    rGPHCON |= 0x2a000;	// TXD2,RXD2
    rGPHUP  |= 0x1c0;	//Uart port pull-up disable
    //Push Uart control registers 
    sirda_ULCON2	= rULCON2;
    sirda_UCON2 	= rUCON2;
    sirda_UFCON2	= rUFCON2;
    sirda_UMCON2	= rUMCON2;
    sirda_UBRDIV2	= rUBRDIV2;
}       
        
void IrDA_Port_Return(void)
{       
    //Pop UART GPIO port configuration
    rGPBCON	=sirda_rGPBCON;
    rGPBDAT	=sirda_rGPBDAT;
    rGPBUP 	=sirda_rGPBUP;
    rGPHCON	=sirda_rGPHCON;
    rGPHDAT	=sirda_rGPHDAT;
    rGPHUP 	=sirda_rGPHUP;
    //Pop Uart control registers 
    rULCON2	=sirda_ULCON2;		
    rUCON2 	=sirda_UCON2;	
    rUFCON2	=sirda_UFCON2;		
    rUMCON2	=sirda_UMCON2;
    rUBRDIV2=sirda_UBRDIV2;
}

void __irq IrDA_TxInt(void)
{
    rINTSUBMSK|=(BIT_SUB_RXD2|BIT_SUB_TXD2|BIT_SUB_ERR2);
    
    if(IrDA_cnt < (IrDA_BUFLEN))
    {
		Uart_Printf("%d,",*IrDAdataPt);
		WrUTXH2(*IrDAdataPt++);
		IrDA_cnt++;
		ClearPending(BIT_UART2);
        rSUBSRCPND=(BIT_SUB_TXD2);
        rINTSUBMSK&=~(BIT_SUB_TXD2);
    }else{
		IrDA_end=1;
		while(rUFSTAT2 & 0x2f0);	//Until FIFO is empty
		while(!(rUTRSTAT2 & 0x4));	//Until Tx shifter is empty
	        ClearPending(BIT_UART2);
		rINTMSK|=BIT_UART2;
	}
}

void __irq IrDA_RxOrErr(void)
{
    rINTSUBMSK|=(BIT_SUB_RXD2|BIT_SUB_TXD2|BIT_SUB_ERR2);	// Just for the safety
    
    if(rSUBSRCPND&BIT_SUB_RXD2) __sub_IrDA_RxInt();
    else						__sub_IrDA_RxErrInt();
    
    rSUBSRCPND=(BIT_SUB_RXD2|BIT_SUB_TXD2|BIT_SUB_ERR2);
    rINTSUBMSK&=~(BIT_SUB_RXD2|BIT_SUB_ERR2);
    ClearPending(BIT_UART2);
}

void __sub_IrDA_RxInt(void)
{

    while( (rUFSTAT2 & 0x100) || (rUFSTAT2 & 0xf)  )
    {
		*IrDAdataPt=rURXH2;	
		*IrDAdataPt++;
		IrDA_cnt++;
    }

    if(IrDA_cnt >= IrDA_BUFLEN)
    {
    	IrDA_end=1;
    	rINTMSK|=BIT_UART2;
    }
}

void __sub_IrDA_RxErrInt(void)
{
    switch(rUERSTAT2)//to clear and check the status of register bits
    {
	case '1':
	    Uart_Printf("Overrun error\n");
	    break;
	case '2':
	    Uart_Printf("Parity error\n");
	    break;
	case '4':
	    Uart_Printf("Frame error\n");
	    break;
	case '8':
	    Uart_Printf("Breake detect\n");
	    break;
	default :
	    break;
    }
}

void Test_IrDA_Tx(void)
{
    int i;
    IrDA_cnt=0;
    IrDA_end=0;
    IrDAdataFl=(volatile U8 *)IrDABUFFER;
    IrDAdataPt=(volatile U8 *)IrDABUFFER;
    IrDA_Port_Set();
	
    Uart_Select(0);		 

    for(i=0;i<IrDA_BUFLEN;i++) *IrDAdataFl++=i;	// Initialize IrDA Tx data
	pISR_UART2=(U32)IrDA_TxInt;
 
	IrDA_BAUD = 9600;
 
    rUBRDIV2=( (int)(PCLK/16./IrDA_BAUD) -1 );
    Uart_Printf("\n\n\n[UART IrDA Tx Test]\n");
    Uart_Printf("rUBRDIV2=%d\n", rUBRDIV2);
    Uart_Printf("This test should be configured two MBA2440 boards...\n");
    Uart_Printf("You MUST Start Rx first and then start Tx...\n");
    Uart_Printf("press any key if you prepare...\n");
    Uart_TxEmpty(0);
	
	rUFCON2=(1<<6)|(0<<4)|(1<<2)|(1<<1)|(1);
    //Tx and Rx FIFO Trigger Level:4byte,Tx and Rx FIFO Reset,FIFO on
    rUCON2=(0<<10)|(1<<9)|(1<<8)|(0<<7)|(0<<6)|(0<<5)|(0<<4)|(0<<2)|(0); // From H/W    
    rULCON2=(1<<6)|(0<<3)|(0<<2)|(3);	// IrDA,No parity,One stop bit, 8bit
    
    Uart_Getch();
    
    rGPBDAT &= ~(1<<1);	// Enable nIrDATXDEN - GPB1
    rUCON2 |= (1<<2); // Tx enable
    Uart_Printf("\n\nNow... Transmit data with IrDA\n");   
   	Uart_Printf("transmitted data : ");
    rINTMSK=~(BIT_UART2);
    rINTSUBMSK=~(BIT_SUB_RXD2|BIT_SUB_TXD2|BIT_SUB_ERR2);

    while(!IrDA_end);

    rINTSUBMSK|=(BIT_SUB_RXD2|BIT_SUB_TXD2|BIT_SUB_ERR2);
    rUFCON2=(3<<6)|(2<<4)|(1<<2)|(1<<1)|(0);
    rGPBDAT|=(1<<1);	// Disable nIrDATXDEN
    Uart_Printf("\b\nComplete transmit data!! transmitted data count=%d bytes\n",IrDA_cnt);
    IrDA_Port_Return();
    Uart_Printf("\n\n\n");
}

void Test_IrDA_Rx(void)
{
	
    unsigned int i;
    debug_t=0;
    IrDA_cnt=0;
    IrDA_end=0;
    IrDA_err=0;	

    IrDA_Port_Set();  
	Uart_Select(0);	 //modify 11.009
    pISR_UART2=(unsigned)IrDA_RxOrErr;
    
    IrDA_BAUD=9600;    
    
    rUBRDIV2=( (int)(PCLK/16./IrDA_BAUD) -1 );
	Uart_Printf("\n\n\n[UART IrDA Tx Test]\n");
    Uart_Printf("rUBRDIV2=%d\n", rUBRDIV2);
    Uart_Printf("This test should be configured two MBA2440 boards...\n");
    Uart_Printf("You MUST Start Rx first and then start Tx...\n");
    Uart_Printf("press any key if you prepare...\n");
    Uart_TxEmpty(0);
    
    rUFCON2=(1<<6)|(0<<4)|(1<<2)|(1<<1)|(1);
    //Tx and Rx FIFO Trigger Level:4byte,Tx and Rx Reset,FIFO En
    rUCON2=(0<<10)|(1<<9)|(1<<8)|(0<<7)|(1<<6)|(0<<5)|(0<<4)|(0<<2)|(0); // From H/W
    rULCON2=(1<<6)|(0<<3)|(0<<2)|(3);	// IrDA,No parity,One stop bit, 8bit
    Uart_Getch();
    Uart_Printf("\n\nNow... Waiting for receive data with IrDA\n");

    for(i=0;i<IrDA_BUFLEN;i++)*IrDAdataPt++=0;	// Initialize IrDA Rx data
	IrDAdataPt =(volatile U8 *)IrDABUFFER;
       
    rUCON2 |= 1; // Rx enable
    rINTMSK=~(BIT_UART2);
    rINTSUBMSK=~(BIT_SUB_RXD2|BIT_SUB_ERR2);

    while(!IrDA_end) if(Uart_GetKey()=='\r') break;

    rINTSUBMSK|=(BIT_SUB_RXD2|BIT_SUB_TXD2|BIT_SUB_ERR2);
    rUFCON2=(3<<6)|(2<<4)|(1<<2)|(1<<1)|(0);
	
    IrDAdataPt =(volatile U8 *)IrDABUFFER; 

	Uart_Printf("received data : ");
    for(i=0;i<IrDA_BUFLEN;i++)   
    {
		if(i-(*IrDAdataPt))
		{
		    Uart_Printf("i=%d ,",i);
		    IrDA_err++;
		}
		else
  			Uart_Printf("%d,",*IrDAdataPt); 
  			debug_t+=*IrDAdataPt; 
    		IrDAdataPt++;  			   		   		
    }
 	Uart_Printf("\b\nComplete receive data!! received data count=%d\n", IrDA_cnt);
	
    if(IrDA_err)
    	Uart_Printf("\nIrDA test fail!! Error count=%d\n",IrDA_err);
    else
    	Uart_Printf("\nIrDA test is good!!\n");  
  	Uart_Printf("\n\n\n");
    IrDA_Port_Return();
}
