/**************************************************************
 NAME: usblib.c
 DESC: S3C2440X USB library functions
 HISTORY:
 **************************************************************/

#include "2440addr.h"
#include "2440lib.h"
#include "def.h"
#include "usb.h"
#include "usblib.h"

// *** End point information ***
//   EP0: control
//   EP1: bulk in end point
//   EP2: not used
//   EP3: bulk out end point
//   EP4: not used

// *** VERY IMPORTANT NOTE ***
// Every descriptor size of EP0 should be 8n+m(m=1~7).
// Otherwise, USB will not operate normally because the program
// doesn't prepare the case that the descriptor size is 8n+0.
// If the size of a descriptor is 8n, the 0 length packit should be sent. 
// Special thanks to E.S.Choi for reminding me of this USB specification.


// ===================================================================
// All following commands will operate only in case 
// - ep0_csr is valid.
// ===================================================================
#define CLR_EP0_OUT_PKT_RDY() 		rEP0_CSR=( ep0_csr & (~EP0_WR_BITS)| \
						EP0_SERVICED_OUT_PKT_RDY )	 
#define CLR_EP0_OUTPKTRDY_DATAEND() 	rEP0_CSR=( ep0_csr & (~EP0_WR_BITS)| \
						(EP0_SERVICED_OUT_PKT_RDY|EP0_DATA_END) )	 
					
#define SET_EP0_IN_PKT_RDY() 		rEP0_CSR=( ep0_csr & (~EP0_WR_BITS)| \
						(EP0_IN_PKT_READY) )	 
#define SET_EP0_INPKTRDY_DATAEND() 	rEP0_CSR=( ep0_csr & (~EP0_WR_BITS)| \
						(EP0_IN_PKT_READY|EP0_DATA_END) )	 
					
#define CLR_EP0_SETUP_END() 		rEP0_CSR=( ep0_csr & (~EP0_WR_BITS)| \
						(EP0_SERVICED_SETUP_END) )

#define CLR_EP0_SENT_STALL() 		rEP0_CSR=( ep0_csr & (~EP0_WR_BITS)& \
						(~EP0_SENT_STALL) )

#define FLUSH_EP0_FIFO() 		{while(rOUT_FIFO_CNT1_REG)rEP0_FIFO;}


static void PrintEpoPkt(U8 *pt,int cnt);
static void RdPktEp3_CheckSum(U8 *buf,int num);
// ===================================================================
// All following commands will operate in case 
// - out_csr3 is valid.
// ===================================================================
#define CLR_EP3_OUT_PKT_READY() rOUT_CSR1_REG= ( out_csr3 &(~ EPO_WR_BITS)\
					&(~EPO_OUT_PKT_READY) ) 
#define SET_EP3_SEND_STALL()	rOUT_CSR1_REG= ( out_csr3 & (~EPO_WR_BITS)\
					| EPO_SEND_STALL) )
#define CLR_EP3_SENT_STALL()	rOUT_CSR1_REG= ( out_csr3 & (~EPO_WR_BITS)\
					&(~EPO_SENT_STALL) )
#define FLUSH_EP3_FIFO() 	rOUT_CSR1_REG= ( out_csr3 & (~EPO_WR_BITS)\
					|EPO_FIFO_FLUSH) )



U32 ep0State;
U32 ep0SubState;

extern volatile int isUsbdSetConfiguration;

struct USB_SETUP_DATA descSetup;
struct USB_DEVICE_DESCRIPTOR descDev;
struct USB_CONFIGURATION_DESCRIPTOR descConf;
struct USB_INTERFACE_DESCRIPTOR descIf;
struct USB_ENDPOINT_DESCRIPTOR descEndpt0;
struct USB_ENDPOINT_DESCRIPTOR descEndpt1;




static const U8 descStr0[]={
	4,STRING_TYPE,LANGID_US_L,LANGID_US_H,  //codes representing languages
    };

static const U8 descStr1[]={  //Manufacturer  
        (0x14+2),STRING_TYPE, 
        'S',0x0,'y',0x0,'s',0x0,'t',0x0,'e',0x0,'m',0x0,' ',0x0,'M',0x0,
        'C',0x0,'U',0x0,
    };
    
static const U8 descStr2[]={  //Product  
        (0x2a+2),STRING_TYPE, 
        'S',0x0,'E',0x0,'C',0x0,' ',0x0,'S',0x0,'3',0x0,'C',0x0,'2',0x0,
        '4',0x0,'1',0x0,'0',0x0,'X',0x0,' ',0x0,'T',0x0,'e',0x0,'s',0x0,
        't',0x0,' ',0x0,'B',0x0,'/',0x0,'D',0x0
    };


void Ep0Handler(void)
{
    static int ep0SubState;
    int i;
    U8 ep0_csr;

    rINDEX_REG=0;
    ep0_csr=rEP0_CSR;
    
    if(ep0_csr & EP0_SETUP_END)
    {   
    	 // Host may end GET_DESCRIPTOR operation without completing the IN data stage.
    	 // If host does that, SETUP_END bit will be set.
    	 // OUT_PKT_RDY has to be also cleared because status stage sets OUT_PKT_RDY to 1.
//   	DbgPrintf("[SETUPEND]");
	CLR_EP0_SETUP_END();
	if(ep0_csr & EP0_OUT_PKT_READY) 
	{
	    FLUSH_EP0_FIFO(); //(???)
    	//I think this isn't needed because EP0 flush is done automatically.   
	    CLR_EP0_OUT_PKT_RDY();
	}
	
	ep0State=EP0_STATE_INIT;
	return;
    }	

    //I think that EP0_SENT_STALL will not be set to 1.
    if(ep0_csr & EP0_SENT_STALL)
    {   
//   	DbgPrintf("[STALL]");
   	CLR_EP0_SENT_STALL();
	if(ep0_csr & EP0_OUT_PKT_READY) 
	{
	    CLR_EP0_OUT_PKT_RDY();
	}
	
	ep0State=EP0_STATE_INIT;
	return;
    }	



    if((ep0_csr & EP0_OUT_PKT_READY) && (ep0State==EP0_STATE_INIT))
    {	
	RdPktEp0((U8 *)&descSetup,EP0_PKT_SIZE);

	PrintEp0Pkt((U8 *)(&descSetup)); //DEBUG
    
	switch(descSetup.bRequest)
    	{
    	case GET_DESCRIPTOR:
            switch(descSetup.bValueH)        
            {
            case DEVICE_TYPE:
// 	    	DbgPrintf("[GDD]");
 	    	CLR_EP0_OUT_PKT_RDY();
	    	ep0State=EP0_STATE_GD_DEV_0;	        
	    	break;	
	    case CONFIGURATION_TYPE:
// 	    	DbgPrintf("[GDC]");
 	    	CLR_EP0_OUT_PKT_RDY();
 	    	if((descSetup.bLengthL+(descSetup.bLengthH<<8))>0x9)
 	    	  //bLengthH should be used for bLength=0x209 at WIN2K.    	
	    	    ep0State=EP0_STATE_GD_CFG_0; //for WIN98,WIN2K
		else	    	    
  		    ep0State=EP0_STATE_GD_CFG_ONLY_0; //for WIN2K
	    	break;
   	    case STRING_TYPE:
// 	    	DbgPrintf("[GDS]");
 	    	CLR_EP0_OUT_PKT_RDY();
	    	switch(descSetup.bValueL)
	    	{
	    	    case 0:
	    	    	ep0State=EP0_STATE_GD_STR_I0;
	    	    	break;
	    	    case 1:
       	    	    	ep0State=EP0_STATE_GD_STR_I1;
	    	    	break;
	    	    case 2:	
	    	    	ep0State=EP0_STATE_GD_STR_I2;
	    	    	break;
	    	    default:
	    		DbgPrintf("[UE:STRI?]");
	    		break;
	    	}
	    	ep0SubState=0;
	    	break;
	    case INTERFACE_TYPE:
// 	    	DbgPrintf("[GDI]");
 	    	CLR_EP0_OUT_PKT_RDY();
	    	ep0State=EP0_STATE_GD_IF_ONLY_0; //for WIN98
	    	break;
	    case ENDPOINT_TYPE:	    	
// 	    	DbgPrintf("[GDE]");
 	    	CLR_EP0_OUT_PKT_RDY();
 	    	switch(descSetup.bValueL&0xf)
	    	{
	    	case 0:
	    	    ep0State=EP0_STATE_GD_EP0_ONLY_0;
	    	    break;
	    	case 1:
       	    	    ep0State=EP0_STATE_GD_EP1_ONLY_0;
	    	    break;
	    	default:
	    	    DbgPrintf("[UE:GDE?]");
	    	    break;
	    	}
	    	break;
	    default:
	    	DbgPrintf("[UE:GD?]");
	    	break;
	    }	
    	    break;

    	case SET_ADDRESS:
//            DbgPrintf("[SA:%d]",descSetup.bValueL);
            rFUNC_ADDR_REG=descSetup.bValueL | 0x80;
	    CLR_EP0_OUTPKTRDY_DATAEND(); //Because of no data control transfers.
            ep0State=EP0_STATE_INIT;
            break;
    	
	case SET_CONFIGURATION:
//            DbgPrintf("[SC]");
            CLR_EP0_OUTPKTRDY_DATAEND(); //Because of no data control transfers.
            ep0State=EP0_STATE_INIT;

            isUsbdSetConfiguration=1; 
    	    break;
  	default:
//	    DbgPrintf("[UE:SETUP=%x]",descSetup.bRequest);
    	    CLR_EP0_OUTPKTRDY_DATAEND(); //Because of no data control transfers.
	    ep0State=EP0_STATE_INIT;
	    break;
    
        }
    }
    
    switch(ep0State)
    {	
	case EP0_STATE_INIT:
	    break; 

	//=== GET_DESCRIPTOR:DEVICE ===
    	case EP0_STATE_GD_DEV_0:
//            DbgPrintf("[GDD0]");
            WrPktEp0((U8 *)&descDev+0,8); //EP0_PKT_SIZE
            SET_EP0_IN_PKT_RDY();
            ep0State=EP0_STATE_GD_DEV_1;
            break;
            
    	case EP0_STATE_GD_DEV_1:
//            DbgPrintf("[GDD1]");
            WrPktEp0((U8 *)&descDev+0x8,8); 
            SET_EP0_IN_PKT_RDY();
            
            ep0State=EP0_STATE_GD_DEV_2;
            break;

    	case EP0_STATE_GD_DEV_2:
//            DbgPrintf("[GDD2]");
            WrPktEp0((U8 *)&descDev+0x10,2);   //8+8+2=0x12
            SET_EP0_INPKTRDY_DATAEND();
            ep0State=EP0_STATE_INIT;
            break;
    

        //=== GET_DESCRIPTOR:CONFIGURATION+INTERFACE+ENDPOINT0+ENDPOINT1 ===
        //Windows98 gets these 4 descriptors all together by issuing only a request.
        //Windows2000 gets each descriptor seperately.
    	case EP0_STATE_GD_CFG_0:
//            DbgPrintf("[GDC0]");
            WrPktEp0((U8 *)&descConf+0,8); //EP0_PKT_SIZE
            SET_EP0_IN_PKT_RDY();
            ep0State=EP0_STATE_GD_CFG_1;
            break;
    
    	case EP0_STATE_GD_CFG_1:
//            DbgPrintf("[GDC1]");
            WrPktEp0((U8 *)&descConf+8,1); 
            WrPktEp0((U8 *)&descIf+0,7); 
            SET_EP0_IN_PKT_RDY();
            ep0State=EP0_STATE_GD_CFG_2;
            break;

    	case EP0_STATE_GD_CFG_2:
//            DbgPrintf("[GDC2]");
            WrPktEp0((U8 *)&descIf+7,2); 
            WrPktEp0((U8 *)&descEndpt0+0,6); 
            SET_EP0_IN_PKT_RDY();
            ep0State=EP0_STATE_GD_CFG_3;
            break;

    	case EP0_STATE_GD_CFG_3:
//            DbgPrintf("[GDC3]");
            WrPktEp0((U8 *)&descEndpt0+6,1); 
            WrPktEp0((U8 *)&descEndpt1+0,7); 
            SET_EP0_IN_PKT_RDY();
            ep0State=EP0_STATE_GD_CFG_4;            
            break;

    	case EP0_STATE_GD_CFG_4:
 //           DbgPrintf("[GDC4]");
            //zero length data packit 
            SET_EP0_INPKTRDY_DATAEND();
            ep0State=EP0_STATE_INIT;            
            break;

        //=== GET_DESCRIPTOR:CONFIGURATION ONLY===
    	case EP0_STATE_GD_CFG_ONLY_0:
  //          DbgPrintf("[GDCO0]");
            WrPktEp0((U8 *)&descConf+0,8); //EP0_PKT_SIZE
            SET_EP0_IN_PKT_RDY();
            ep0State=EP0_STATE_GD_CFG_ONLY_1;
            break;
    
    	case EP0_STATE_GD_CFG_ONLY_1:
  //          DbgPrintf("[GDCO1]");
            WrPktEp0((U8 *)&descConf+8,1); 
            SET_EP0_INPKTRDY_DATAEND();
            ep0State=EP0_STATE_INIT;            
            break;

        //=== GET_DESCRIPTOR:INTERFACE ONLY===
    	case EP0_STATE_GD_IF_ONLY_0:
  //          DbgPrintf("[GDI0]");
            WrPktEp0((U8 *)&descIf+0,8); 
            SET_EP0_IN_PKT_RDY();
            ep0State=EP0_STATE_GD_IF_ONLY_1;
            break;
    	case EP0_STATE_GD_IF_ONLY_1:
 //           DbgPrintf("[GDI1]");
            WrPktEp0((U8 *)&descIf+8,1); 
            SET_EP0_INPKTRDY_DATAEND();
            ep0State=EP0_STATE_INIT;            
            break;

        //=== GET_DESCRIPTOR:ENDPOINT 0 ONLY===
    	case EP0_STATE_GD_EP0_ONLY_0:
//            DbgPrintf("[GDE00]");
            WrPktEp0((U8 *)&descEndpt0+0,7); 
            SET_EP0_INPKTRDY_DATAEND();
            ep0State=EP0_STATE_INIT;            
            break;
            
        //=== GET_DESCRIPTOR:ENDPOINT 1 ONLY===
    	case EP0_STATE_GD_EP1_ONLY_0:
//            DbgPrintf("[GDE10]");
            WrPktEp0((U8 *)&descEndpt1+0,7); 
            SET_EP0_INPKTRDY_DATAEND();
            ep0State=EP0_STATE_INIT;            
            break;
 
        //=== GET_DESCRIPTOR:STRING ===

    	case EP0_STATE_GD_STR_I0:
//            DbgPrintf("[GDS0_0]");
	    WrPktEp0((U8 *)descStr0, 4 );  
	    SET_EP0_INPKTRDY_DATAEND();
	    ep0State=EP0_STATE_INIT;     
	    ep0SubState=0;
	    break;

	case EP0_STATE_GD_STR_I1:
 //           DbgPrintf("[GDS1_%d]",ep0SubState);
            if( (ep0SubState*EP0_PKT_SIZE+EP0_PKT_SIZE)<sizeof(descStr1) )
            {
            	WrPktEp0((U8 *)descStr1+(ep0SubState*EP0_PKT_SIZE),EP0_PKT_SIZE); 
            	SET_EP0_IN_PKT_RDY();
            	ep0State=EP0_STATE_GD_STR_I1;
            	ep0SubState++;
            }
	    else
	    {
	    	WrPktEp0((U8 *)descStr1+(ep0SubState*EP0_PKT_SIZE),
	    		 sizeof(descStr1)-(ep0SubState*EP0_PKT_SIZE)); 
		SET_EP0_INPKTRDY_DATAEND();
		ep0State=EP0_STATE_INIT;     
		ep0SubState=0;
	    }
	    break;

	case EP0_STATE_GD_STR_I2:
//            DbgPrintf("[GDS2_%d]",ep0SubState);
            if( (ep0SubState*EP0_PKT_SIZE+EP0_PKT_SIZE)<sizeof(descStr2) )
            {
            	WrPktEp0((U8 *)descStr2+(ep0SubState*EP0_PKT_SIZE),EP0_PKT_SIZE); 
            	SET_EP0_IN_PKT_RDY();
            	ep0State=EP0_STATE_GD_STR_I2;
            	ep0SubState++;
            }
	    else
	    {
//                DbgPrintf("[E]");
	    	WrPktEp0((U8 *)descStr2+(ep0SubState*EP0_PKT_SIZE),
	    		 sizeof(descStr2)-(ep0SubState*EP0_PKT_SIZE)); 
		SET_EP0_INPKTRDY_DATAEND();
		ep0State=EP0_STATE_INIT;     
		ep0SubState=0;
	    }
	    break;
     	default:
//	    DbgPrintf("UE:G?D");
    	    break;
    }
}


   
    
void PrintEp0Pkt(U8 *pt)
{
//    int i;
//    DbgPrintf("[RCV:");
//    for(i=0;i<EP0_PKT_SIZE;i++)
//        DbgPrintf("%x,",pt[i]);
//    DbgPrintf("]");
}




void InitDescriptorTable(void)
{	
    //Standard device descriptor
    descDev.bLength=0x12;	//EP0_DEV_DESC_SIZE=0x12 bytes    
    descDev.bDescriptorType=DEVICE_TYPE;         
    descDev.bcdUSBL=0x10;
    descDev.bcdUSBH=0x01; 	//Ver 1.10
    descDev.bDeviceClass=0xFF; //0x0          
    descDev.bDeviceSubClass=0x0;          
    descDev.bDeviceProtocol=0x0;          
    descDev.bMaxPacketSize0=0x8;         
    descDev.idVendorL=0x45;
    descDev.idVendorH=0x53;
    descDev.idProductL=0x34;
    descDev.idProductH=0x12;
    descDev.bcdDeviceL=0x00;
    descDev.bcdDeviceH=0x01;
    descDev.iManufacturer=0x1;  //index of string descriptor
    descDev.iProduct=0x2;	//index of string descriptor 
    descDev.iSerialNumber=0x0;
    descDev.bNumConfigurations=0x1;

    //Standard configuration descriptor
    descConf.bLength=0x9;    
    descConf.bDescriptorType=CONFIGURATION_TYPE;         
    descConf.wTotalLengthL=0x20; //<cfg desc>+<if desc>+<endp0 desc>+<endp1 desc>
    descConf.wTotalLengthH=0;
    descConf.bNumInterfaces=1;
//dbg    descConf.bConfigurationValue=2;  //why 2? There's no reason.
    descConf.bConfigurationValue=1;  
    descConf.iConfiguration=0;
    descConf.bmAttributes=CONF_ATTR_DEFAULT|CONF_ATTR_SELFPOWERED;;  //bus powered only.
    descConf.maxPower=25; //draws 50mA current from the USB bus.          

    //Standard interface descriptor
    descIf.bLength=0x9;    
    descIf.bDescriptorType=INTERFACE_TYPE;         
    descIf.bInterfaceNumber=0x0;
    descIf.bAlternateSetting=0x0; //?
    descIf.bNumEndpoints=2;	//# of endpoints except EP0
    descIf.bInterfaceClass=0xff; //0x0 ?
    descIf.bInterfaceSubClass=0x0;  
    descIf.bInterfaceProtocol=0x0;
    descIf.iInterface=0x0;

    //Standard endpoint0 descriptor
    descEndpt0.bLength=0x7;    
    descEndpt0.bDescriptorType=ENDPOINT_TYPE;         
    descEndpt0.bEndpointAddress=1|EP_ADDR_IN;   // 2400Xendpoint 1 is IN endpoint.
    descEndpt0.bmAttributes=EP_ATTR_BULK;
    descEndpt0.wMaxPacketSizeL=EP1_PKT_SIZE; //64
    descEndpt0.wMaxPacketSizeH=0x0;
    descEndpt0.bInterval=0x0; //not used

    //Standard endpoint1 descriptor
    descEndpt1.bLength=0x7;    
    descEndpt1.bDescriptorType=ENDPOINT_TYPE;         
    descEndpt1.bEndpointAddress=3|EP_ADDR_OUT;   // 2400X endpoint 3 is OUT endpoint.
    descEndpt1.bmAttributes=EP_ATTR_BULK;
    descEndpt1.wMaxPacketSizeL=EP3_PKT_SIZE; //64
    descEndpt1.wMaxPacketSizeH=0x0;
    descEndpt1.bInterval=0x0; //not used 
}


void DbgPrintf(char *fmt,...)
{
}


void ConfigUsbd(void)
{
    ReconfigUsbd();
    rINTMSK&=~(BIT_USBD);  
}


void ReconfigUsbd(void)
{
// *** End point information ***
//   EP0: control
//   EP1: bulk in end point
//   EP2: not used
//   EP3: bulk out end point
//   EP4: not used
    
    rPWR_REG=PWR_REG_DEFAULT_VALUE;	//disable suspend mode

    rINDEX_REG=0;	
    rMAXP_REG=FIFO_SIZE_8;   	//EP0 max packit size = 8 
    rEP0_CSR=EP0_SERVICED_OUT_PKT_RDY|EP0_SERVICED_SETUP_END;	
 				//EP0:clear OUT_PKT_RDY & SETUP_END
    rINDEX_REG=1;
#if (EP1_PKT_SIZE==32)
	rMAXP_REG=FIFO_SIZE_32;	//EP1:max packit size = 32
#else
	rMAXP_REG=FIFO_SIZE_64;	//EP1:max packit size = 64
#endif	
    rIN_CSR1_REG=EPI_FIFO_FLUSH|EPI_CDT;	
    rIN_CSR2_REG=EPI_MODE_IN|EPI_IN_DMA_INT_MASK|EPI_BULK; //IN mode, IN_DMA_INT=masked    
    rOUT_CSR1_REG=EPO_CDT;   	
    rOUT_CSR2_REG=EPO_BULK|EPO_OUT_DMA_INT_MASK;   	

    rINDEX_REG=2;
    rMAXP_REG=FIFO_SIZE_64;	//EP2:max packit size = 64
    rIN_CSR1_REG=EPI_FIFO_FLUSH|EPI_CDT|EPI_BULK;
    rIN_CSR2_REG=EPI_MODE_IN|EPI_IN_DMA_INT_MASK; //IN mode, IN_DMA_INT=masked    
    rOUT_CSR1_REG=EPO_CDT;   	
    rOUT_CSR2_REG=EPO_BULK|EPO_OUT_DMA_INT_MASK;   	

    rINDEX_REG=3;
#if (EP3_PKT_SIZE==32)
	rMAXP_REG=FIFO_SIZE_32;	//EP3:max packit size = 32
#else
	rMAXP_REG=FIFO_SIZE_64;	//EP3:max packit size = 64
#endif	
    rIN_CSR1_REG=EPI_FIFO_FLUSH|EPI_CDT|EPI_BULK;
    rIN_CSR2_REG=EPI_MODE_OUT|EPI_IN_DMA_INT_MASK; //OUT mode, IN_DMA_INT=masked    
    rOUT_CSR1_REG=EPO_CDT;   	
    //clear OUT_PKT_RDY, data_toggle_bit.
	//The data toggle bit should be cleared when initialization.
    rOUT_CSR2_REG=EPO_BULK|EPO_OUT_DMA_INT_MASK;   	

    rINDEX_REG=4;
    rMAXP_REG=FIFO_SIZE_64;	//EP4:max packit size = 64
    rIN_CSR1_REG=EPI_FIFO_FLUSH|EPI_CDT|EPI_BULK;
    rIN_CSR2_REG=EPI_MODE_OUT|EPI_IN_DMA_INT_MASK; //OUT mode, IN_DMA_INT=masked    
    rOUT_CSR1_REG=EPO_CDT;   	
    	//clear OUT_PKT_RDY, data_toggle_bit.
	//The data toggle bit should be cleared when initialization.
    rOUT_CSR2_REG=EPO_BULK|EPO_OUT_DMA_INT_MASK;   	
    
    rEP_INT_REG=EP0_INT|EP1_INT|EP2_INT|EP3_INT|EP4_INT;
    rUSB_INT_REG=RESET_INT|SUSPEND_INT|RESUME_INT; 
    	//Clear all usbd pending bits
    	
    //EP0,1,3 & reset interrupt are enabled
    rEP_INT_EN_REG=EP0_INT|EP1_INT|EP3_INT;
    rUSB_INT_EN_REG=RESET_INT;
    ep0State=EP0_STATE_INIT;
    
}


void RdPktEp0(U8 *buf,int num)
{
    int i;
    	
    for(i=0;i<num;i++)
    {
        buf[i]=(U8)rEP0_FIFO;	
    }
}
    

void WrPktEp0(U8 *buf,int num)
{
    int i;
    	
    for(i=0;i<num;i++)
    {
        rEP0_FIFO=buf[i];	
    }
}


void WrPktEp1(U8 *buf,int num)
{
    int i;
    	
    for(i=0;i<num;i++)
    {
        rEP1_FIFO=buf[i];	
    }
}


void WrPktEp2(U8 *buf,int num)
{
    int i;
    	
    for(i=0;i<num;i++)
    {
        rEP2_FIFO=buf[i];	
    }
}


void RdPktEp3(U8 *buf,int num)
{
    int i;
    	
    for(i=0;i<num;i++)
    {
        buf[i]=(U8)rEP3_FIFO;	
    }
}


void RdPktEp4(U8 *buf,int num)
{
    int i;
    	
    for(i=0;i<num;i++)
    {
        buf[i]=(U8)rEP4_FIFO;	
    }
}


void ConfigEp3DmaMode(U32 bufAddr,U32 count)
{
    int i;

    rINDEX_REG=3;
    count=count&0xfffff; //transfer size should be <1MB
    
    rDISRCC2=(1<<1)|(1<<0);
    rDISRC2=ADDR_EP3_FIFO; //src=APB,fixed,src=EP3_FIFO 
    rDIDSTC2=(0<<1)|(0<<0);
    rDIDST2=bufAddr;       //dst=AHB,increase,dst=bufAddr
#if USBDMA_DEMAND
    rDCON2=(count)|(0<<31)|(0<<30)|(1<<29)|(0<<28)|(0<<27)|(4<<24)|(1<<23)|(0<<22)|(0<<20); 
        //demand,requestor=APB,CURR_TC int enable,unit transfer,
        //single service,src=USBD,H/W request,autoreload,byte,CURR_TC
#else
    rDCON2=(count)|(1<<31)|(0<<30)|(1<<29)|(0<<28)|(0<<27)|(4<<24)|(1<<23)|(0<<22)|(0<<20); 
        //handshake,requestor=APB,CURR_TC int enable,unit transfer,
        //single service,src=USBD,H/W request,autoreload,byte,CURR_TC
#endif        
    rDMASKTRIG2= (1<<1); 
        //DMA 2 on

    //rEP3_DMA_FIFO=0x40; //not needed for OUT operation. 	

    rEP3_DMA_TTC_L=0xff;
    rEP3_DMA_TTC_M=0xff;
    rEP3_DMA_TTC_H=0x0f;

    rOUT_CSR2_REG=rOUT_CSR2_REG|EPO_AUTO_CLR|EPO_OUT_DMA_INT_MASK; 
    	//AUTO_CLR(OUT_PKT_READY is cleared automatically), interrupt_masking.
#if USBDMA_DEMAND
    rEP3_DMA_UNIT=EP3_PKT_SIZE; //DMA transfer unit=64 bytes
    rEP3_DMA_CON=UDMA_DEMAND_MODE|UDMA_OUT_DMA_RUN|UDMA_DMA_MODE_EN; 
        // deamnd enable,out_dma_run=run,in_dma_run=stop,DMA mode enable
#else        
    rEP3_DMA_UNIT=0x01; //DMA transfer unit=1byte
    rEP3_DMA_CON=UDMA_OUT_DMA_RUN|UDMA_DMA_MODE_EN;
        // deamnd disable,out_dma_run=run,in_dma_run=stop,DMA mode enable
#endif  
    //wait until DMA_CON is effective.
    rEP3_DMA_CON;
    for(i=0;i<10;i++);    	
}


void ConfigEp3IntMode(void)
{
    rINDEX_REG=3;
    
    rDMASKTRIG2= (0<<1);  // EP3=DMA ch 2
        //DMA channel off
    rOUT_CSR2_REG=rOUT_CSR2_REG&~(EPO_AUTO_CLR/*|EPO_OUT_DMA_INT_MASK*/); 
    	//AUTOCLEAR off,interrupt_enabled (???)
    rEP3_DMA_UNIT=1;	
    rEP3_DMA_CON=0; 
    	// deamnd disable,out_dma_run=stop,in_dma_run=stop,DMA mode disable
    //wait until DMA_CON is effective.
    rEP3_DMA_CON;
    
}


static void PrintEpiPkt(unsigned char *pt,int cnt);


// ===================================================================
// All following commands will operate in case 
// - in_csr1 is valid.
// ===================================================================

#define SET_EP1_IN_PKT_READY()  rIN_CSR1_REG= ( in_csr1 &(~ EPI_WR_BITS)\
					| EPI_IN_PKT_READY )	 
#define SET_EP1_SEND_STALL()	rIN_CSR1_REG= ( in_csr1 & (~EPI_WR_BITS)\
					| EPI_SEND_STALL) )
#define CLR_EP1_SENT_STALL()	rIN_CSR1_REG= ( in_csr1 & (~EPI_WR_BITS)\
					&(~EPI_SENT_STALL) )
#define FLUSH_EP1_FIFO() 	rIN_CSR1_REG= ( in_csr1 & (~EPI_WR_BITS)\
					| EPI_FIFO_FLUSH) )


// ***************************
// *** VERY IMPORTANT NOTE ***
// ***************************
// Prepare the code for the packit size constraint!!!

// EP1 = IN end point. 

unsigned char ep1Buf[EP1_PKT_SIZE];
int transferIndex=0;



void PrepareEp1Fifo(void) 
{
    int i;
    unsigned char in_csr1;
    rINDEX_REG=1;
    in_csr1=rIN_CSR1_REG;
    
    for(i=0;i<EP1_PKT_SIZE;i++)ep1Buf[i]=(unsigned char)(transferIndex+i);
    WrPktEp1(ep1Buf,EP1_PKT_SIZE);
    SET_EP1_IN_PKT_READY(); 
}


void Ep1Handler(void)
{
    unsigned char in_csr1;
    int i;
    rINDEX_REG=1;
    in_csr1=rIN_CSR1_REG;
    
    DbgPrintf("<1:%x]",in_csr1);

    //I think that EPI_SENT_STALL will not be set to 1.
    if(in_csr1 & EPI_SENT_STALL)
    {   
   	DbgPrintf("[STALL]");
   	CLR_EP1_SENT_STALL();
   	return;
    }	

    //IN_PKT_READY is cleared
    
    //The data transfered was ep1Buf[] which was already configured 

    PrintEpiPkt(ep1Buf,EP1_PKT_SIZE); 
    
    transferIndex++;

    PrepareEp1Fifo(); 
    	//IN_PKT_READY is set   
    	//This packit will be used for next IN packit.	

    return;
}


    
void PrintEpiPkt(unsigned char *pt,int cnt)
{
    int i;
    DbgPrintf("[B_IN:%d:",cnt);
    for(i=0;i<cnt;i++)
    	DbgPrintf("%x,",pt[i]);
    DbgPrintf("]");
}




// ***************************
// *** VERY IMPORTANT NOTE ***
// ***************************
// Prepare for the packit size constraint!!!

// EP3 = OUT end point. 

U8 ep3Buf[EP3_PKT_SIZE];
static U8 tempBuf[64+1];

void Ep3Handler(void)
{
    U8 out_csr3;
    int fifoCnt;
    rINDEX_REG=3;

    out_csr3=rOUT_CSR1_REG;
    
    DbgPrintf("<3:%x]",out_csr3);

    if(out_csr3 & EPO_OUT_PKT_READY)
    {   
	fifoCnt=rOUT_FIFO_CNT1_REG; 
#if 0
	RdPktEp3(ep3Buf,fifoCnt);
	PrintEpoPkt(ep3Buf,fifoCnt);
#else

	if(downloadFileSize==0)
	{
   	    RdPktEp3((U8 *)downPt,8); 	
   	    USBdownloadAddress=
    	*((U8 *)(downPt+0))+
		(*((U8 *)(downPt+1))<<8)+
		(*((U8 *)(downPt+2))<<16)+
		(*((U8 *)(downPt+3))<<24);

	    downloadFileSize=
	    *((U8 *)(downPt+4))+
		(*((U8 *)(downPt+5))<<8)+
		(*((U8 *)(downPt+6))<<16)+
		(*((U8 *)(downPt+7))<<24);

	    checkSum=0;
	    downPt=(U8 *)USBdownloadAddress;
  	    RdPktEp3_CheckSum((U8 *)downPt,fifoCnt-8); //The first 8-bytes are deleted.
  	    downPt+=fifoCnt-8;
  	    
  	#if USBDMA
     	    //CLR_EP3_OUT_PKT_READY() is not executed. 
     	    //So, USBD may generate NAK until DMA2 is configured for USB_EP3;
     	    rINTMSK|=BIT_USBD; //for debug
      	    return;	
  	#endif	
	}
	else
	{
	#if USBDMA    	
	    Uart_Printf("<ERROR>");
	#endif    
	    RdPktEp3_CheckSum((U8 *)downPt,fifoCnt); 	    
	    downPt+=fifoCnt;  //fifoCnt=64
	}
#endif
   	CLR_EP3_OUT_PKT_READY();
	return;
    }

    
    //I think that EPO_SENT_STALL will not be set to 1.
    if(out_csr3 & EPO_SENT_STALL)
    {   
   	DbgPrintf("[STALL]");
   	CLR_EP3_SENT_STALL();
   	return;
    }	
}



void PrintEpoPkt(U8 *pt,int cnt)
{
    int i;
    DbgPrintf("[BOUT:%d:",cnt);
    for(i=0;i<cnt;i++)
    	DbgPrintf("%x,",pt[i]);
    DbgPrintf("]");
}


void RdPktEp3_CheckSum(U8 *buf,int num)
{
    int i;
    	
    for(i=0;i<num;i++)
    {
        buf[i]=(U8)rEP3_FIFO;
        checkSum+=buf[i];
    }
}



void __irq IsrDma2(void)
{
    U8 out_csr3;
    U32 nextTotalDmaCount;
    U8 saveIndexReg=rINDEX_REG;

    rINDEX_REG=3;
    out_csr3=rOUT_CSR1_REG;
    
    ClearPending(BIT_DMA2);	    
    
    totalDmaCount+=0x80000;

    if(totalDmaCount>=downloadFileSize)// is last?
    {
    	totalDmaCount=downloadFileSize;
	
    	ConfigEp3IntMode();	

    	if(out_csr3& EPO_OUT_PKT_READY)
    	{
   	    CLR_EP3_OUT_PKT_READY();
	}
        rINTMSK|=BIT_DMA2;  
        rINTMSK&=~(BIT_USBD);  
    }
    else
    {
    	if((totalDmaCount+0x80000)<downloadFileSize)	
    	{
	    nextTotalDmaCount=totalDmaCount+0x80000;
    
    	    if((nextTotalDmaCount+0x80000)<downloadFileSize)
    	    {
        	//for (2~n)th autoreload.	 
		while((rDSTAT2&0xfffff)==0); //wait until autoreload occurs.
		rDIDST2=((U32)USBdownloadAddress+nextTotalDmaCount-8);  
		rDIDSTC2=(0<<1)|(0<<0);  
    	    	rDCON2=rDCON2&~(0xfffff)|(0x80000); 
    	    	
    	    	while(rEP3_DMA_TTC<0xfffff)
    	    	{
    	    	    rEP3_DMA_TTC_L=0xff;
    	    	    rEP3_DMA_TTC_M=0xff;
    	    	    rEP3_DMA_TTC_H=0xf;
    	    	    //0xfffff;
    	    	}
    	    }
 	    else
 	    {
		while((rDSTAT2&0xfffff)==0); //wait until autoreload occurs.
   	        rDIDST2=((U32)USBdownloadAddress+nextTotalDmaCount-8);  
      	        rDIDSTC2=(0<<1)|(0<<0);  
      	        rDCON2=rDCON2&~(0xfffff)|(downloadFileSize-nextTotalDmaCount); 		
    	    	while(rEP3_DMA_TTC<0xfffff)
    	    	{
    	    	    rEP3_DMA_TTC_L=0xff;
    	    	    rEP3_DMA_TTC_M=0xff;
    	    	    rEP3_DMA_TTC_H=0xf;
    	    	    //0xfffff;
    	    	}
	    }
	}
	else
	{
	    while((rDSTAT2&0xfffff)==0); //wait until autoreload occurs.
  	    rDIDST2=((U32)USBdownloadAddress+downloadFileSize-8);  //for next autoreload.	    		
  	    rDIDSTC2=(0<<1)|(0<<0);
  	    rDCON2=rDCON2&~(0xfffff)|(0); 		
		//There is no 2nd autoreload. This will not be used.  	    
	    //rDMA_TX+=0x0; //USBD register		
	}
    }
    rINDEX_REG=saveIndexReg;
}


void ClearEp3OutPktReady(void)
{
    U8 out_csr3;
    rINDEX_REG=3;
    out_csr3=rOUT_CSR1_REG;
    CLR_EP3_OUT_PKT_READY();
}
