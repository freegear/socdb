/****************************************************************************
 * file name	: strate32.c
 * Date			: 15. 04. 2005
 * Version		: 1.0
 * Description	: INTEL 28F128J3C150 NOR flash test menu display function
 *
 ****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include "Def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h"
#include "strata32.h"



extern void E28F128J3A_CheckId(void);
static int  CheckID(int targetAddr);
static int  CheckDevice(int targetAddr);

void EraseE28F128J3A(void);
static void Strata_EraseSector(int targetAddr);

void ReadE28F128J3A(void);

void WriteE28F128J3A(void);
static int  Strata_ProgFlash(U32 realAddr,U32 data);

static int  Strata_CheckBlockLock(int targetAddr);
static int  Strata_BlankCheck(int targetAddr,int targetSize);
static int  _WAIT(void);


static U32 base_address;

static U32 srcAddress;
static U32 srcSize;
static U32 targetAddress; 
static U32 targetSize; 


#define _WR(addr,data)  	*((volatile U32 *)(addr))=(U32)data 
#define _RD(addr)       	( *((volatile U32 *)(addr)) )
#define _RESET()    		_WR(targetAddress+8,0x00ff00ff)

#define INTEL_BLK_SIZE		0x40000
#define BLK_CNT				0x2000000/INTEL_BLK_SIZE

static int error_erase=0;       // Read Status Register, SR.5
static int error_program=0;     // Read Status Register, SR.4





void STRATA32_menu(void)
{
	int sel = 0;
	base_address = 0x08000000;

	while(1){
		Uart_Printf("+--------------[ 28F128J3C150 test ]--------------+\n");
		Uart_Printf("| 1:Check ID\n");
		Uart_Printf("| 2:Erase\n");
		Uart_Printf("| 3:Read data\n");
		Uart_Printf("| 4:Write data\n");
		Uart_Printf("| 5:Previous menu\n");
		Uart_Printf("+-------------------------------------------------+\n");
		Uart_Printf(" Select number : ");
		sel = Uart_GetIntNum();
		Uart_Printf("+-------------------------------------------------+\n\n\n");
		
		switch(sel){
			case 1 :
				E28F128J3A_CheckId();
				break;
			case 2 :
				EraseE28F128J3A();
				break;
			case 3 :
				ReadE28F128J3A();
				break;
			case 4 :
				WriteE28F128J3A();
				break;
			case 5 :
				return;
			default:
				Uart_Printf("Wrong number seleted.. Try again!!\n\n\n");
				break;
		}
	}
}

//========================================================================
int CheckID(int targetAddr) 
{
	_RESET();
	_WR(targetAddr+8, 0x00900090); 
	return _RD(targetAddr); 
}

int CheckDevice(int targetAddr) 
{
	_RESET();
	_WR(targetAddr+8, 0x00900090);
	return _RD(targetAddr+0x4); 
}

extern void E28F128J3A_CheckId(void)
{
	U16 manID, devID;
	Uart_Printf("Manufacture ID = 0x%x, ", manID = (CheckID(base_address) & 0xffff));
	Uart_Printf("Device ID = 0x%x\n", devID = (CheckDevice(base_address) & 0xffff));

	if(manID==0x0089 && devID==0x16)
		Uart_Printf("This device is 28F320J3A\n");
    else if(manID==0x0089 && devID==0x17)
    	Uart_Printf("This device is 28F640J3A\n");
    else if(manID==0x0089 && devID==0x18)
    	Uart_Printf("This device is 28F128J3A\n");
    else 
    	Uart_Printf("ID Check Error!!!\n");

		Uart_Printf("\n\n");
   	return;
}
//========================================================================

void Strata_EraseSector(int targetAddress) 
{
    unsigned long ReadStatus;
    unsigned long bSR5;     // Erase and Clear Lock-bits Status, lower 16bit, 8MB Intel Strate Flash ROM
    unsigned long bSR5_2;   // Erase and Clear Lock-bits Status, higher 16bit, 8MB Intel Strate Flash ROM
    unsigned long bSR7;     // Write State Machine Status, lower 16bit, 8MB Intel Strate Flash ROM
    unsigned long bSR7_2;   // Write State Machine Status, higher 16bit, 8MB Intel Strate Flash ROM

    _WR(targetAddress, 0x00200020); // Block Erase, First Bus Cycle, targetAddress is the address withint the block
    _WR(targetAddress, 0x00d000d0); // Block Erase, Second Bus Cycle, targetAddress is the address withint the block
    
    _WR(targetAddress, 0x00700070); // Read Status Register, First Bus Cycle, targetAddress is any valid address within the device
    ReadStatus=_RD(targetAddress);  // Read Status Register, Second Bus Cycle, targetAddress is any valid address within the device
    bSR7=ReadStatus & (1<<7);       // lower 16-bit 8MB Strata
    bSR7_2=ReadStatus & (1<<(7+16));// higher 16-bit 8MB Strata
    while(!bSR7 | !bSR7_2) 
    {
        _WR(targetAddress, 0x00700070);
        ReadStatus=_RD(targetAddress);
        bSR7=ReadStatus & (1<<7);
        bSR7_2=ReadStatus & (1<<(7+16));
    }

    _WR(targetAddress, 0x00700070); // When the block erase is complete, status register bit SR.5 should be checked. 
                    // If a block erase error is detected, the status register should be cleared before
                    // system software attempts correct actions.
    ReadStatus=_RD(targetAddress);  
    bSR5=ReadStatus & (1<<5);           // lower 16-bit 8MB Strata 
    bSR5_2=ReadStatus & (1<<(5+16));    // higher 16-bit 8MB Strata 
    if (bSR5==0 && bSR5_2==0) 
    {
        Uart_Printf("Block[%d] Erase O.K. \n",(targetAddress-base_address)/INTEL_BLK_SIZE);
    }else{
        //Uart_Printf("Error in Block Erasure!!\n");
        _WR(targetAddress, 0x00500050); // Clear Status Register
        error_erase=1;                  // But not major, is it casual ?
    }

    _RESET();   // write 0xffh(_RESET()) after the last opoeration to reset the device to read array mode.
}


void EraseE28F128J3A(void)
{
	int block_num;
	
	Uart_Printf("INTEL NOR flash Erase Test\nThis test erases only one block you select\n");
	Uart_Printf("\nYou MUST be well aware that\n");
	Uart_Printf("1. the block size of INTEL flash is 0x%x\n", INTEL_BLK_SIZE);
	Uart_Printf("2. the base address of INTEL flash is 0x%x\n", base_address);
	
	do{
		Uart_Printf("\n\nSelect target block number[0 ~ %d]: ", BLK_CNT-1);
		block_num = Uart_GetIntNum();
		targetAddress = base_address + (INTEL_BLK_SIZE * block_num);
		Uart_Printf("\n\n");
	
		Strata_EraseSector(targetAddress);
		Uart_Printf("\nDo you want to continue erasing block?[y/n]");
	}while(Uart_Getch()=='y');
		
	Uart_Printf("\n\n\n");
	
}
//========================================================================

int Strata_CheckBlockLock(int targetAddr) 
{
    _RESET();
    _WR(targetAddr, 0x00900090);
    return _RD(targetAddr+0x8); // Read Block Lock configuration, 
                                // targetAddress must be the beginning location of a Block Address
}

void Strata_Unlock(int targetAddr) 
{
    _RESET();
    _WR(targetAddr, 0x00600060);
    _WR(targetAddr, 0x00D000D0);
}

void Strata_SetBlockLock(int targetAddr)
{
	_RESET();
	_WR(targetAddr, 0x00600060);
	_WR(targetAddr, 0x00010001);
}

//==========================================================================================
int Strata_BlankCheck(int targetAddr,int targetSize) 
{
    int i,j;
    for (i=0; i<targetSize; i+=4) 
    {
        j=*((volatile U32 *)(i+targetAddr));
        if (j!=0xffffffff)      // In erasure it changes all block dta to 0xff
        {
            Uart_Printf("E : %x = %x\n", (i+targetAddr), j);
            return 0;
        }
    }
    return 1;
}

//==========================================================================================
void ReadE28F128J3A(void)
{
	U32 *rd_src, *rd_dst;
	int i, block_num;
	
	Uart_Printf("INTEL NOR flash Read Test\n");
	Uart_Printf("This test reads data from INTEL flash and copies data to memory\n");
	Uart_Printf("This test reads only one block you select\n");
	Uart_Printf("\nYou MUST be well aware that\n");
	Uart_Printf("1. the block size of INTEL flash is 0x%x\n", INTEL_BLK_SIZE);
	Uart_Printf("2. the base address of INTEL flash is 0x%x\n", base_address);
	
	srcSize = INTEL_BLK_SIZE;
	
	do{
	    Uart_Printf("\n\nSelect source block number you wanna read[0 ~ %d]: ", BLK_CNT-1);
		block_num = Uart_GetIntNum();
		srcAddress = base_address + (INTEL_BLK_SIZE * block_num);
	
		Uart_Printf("\nInput the target address to copy in memory[0x...]: ");
	    targetAddress = Uart_GetIntNum();
	
	    Uart_Printf("\n\ntarget address = 0x%x\n",targetAddress);
		Uart_Printf("source address = 0x%x(blcok[%3d])\n",srcAddress, block_num);
	    
		Uart_Printf("\nStart of the data reading.. size[0x%x]\n", srcSize);
		rd_dst = (U32 *)targetAddress;
		rd_src = (U32 *)srcAddress;
		for(i=0;i<srcSize;i+=4)		*rd_dst++ = *rd_src++;
		
		Uart_Printf("\nEnd of the data reading!!!\n");
		
		Uart_Printf("\nStart Verifying data\n");
	    for(i=0x0;i<targetSize;i+=2) 
	    {
	        if(*( (U32 *)(i+targetAddress) )!=*( (U32 *)(srcAddress+i) )  )
			{
			    Uart_Printf("\n%x = verify error\n\n\n",i+targetAddress);
			    return;
			}
	        if((i%0x8000)==0)	Uart_Printf("%x ",i);
	    }
	    Uart_Printf("\nVerifying End!!!\n");
		
	    Uart_Printf("\nDo you want to continue reading additional data?[y/n]");
    }while(Uart_Getch()=='y');
    
    Uart_Printf("\n\n\n");

}

//==========================================================================================
int Strata_ProgFlash(U32 realAddr, U32 data) 
{
    volatile U32 *ptargetAddr;
    unsigned long ReadStatus;
    unsigned long bSR4;    // Erase and Clear Lock-bits Status, lower 16bit, 8MB Intel Strate Flash ROM
    unsigned long bSR4_2;  // Erase and Clear Lock-bits Status, higher 16bit, 8MB Intel Strate Flash ROM
    unsigned long bSR7;    // Write State Machine Status, lower 16bit, 8MB Intel Strate Flash ROM
    unsigned long bSR7_2;  // Write State Machine Status, higher 16bit, 8MB Intel Strate Flash ROM

    ptargetAddr = (volatile U32 *)realAddr;

    _WR(realAddr, 0x00400040);  // realAddr is any valid adress within the device
                                // Word/Byte Program(or 0x00100010 can be used)
    *ptargetAddr = data;        // 32 bit data

    _WR(realAddr, 0x00700070);  // Read Status Register
    ReadStatus=_RD(realAddr);   // realAddr is any valid address within the device
    bSR7=ReadStatus & (1<<7);
    bSR7_2=ReadStatus & (1<<(7+16));
    while(!bSR7 || !bSR7_2) 
    {
        _WR(realAddr, 0x00700070);        // Read Status Register
        ReadStatus=_RD(realAddr);
        bSR7=ReadStatus & (1<<7);
        bSR7_2=ReadStatus & (1<<(7+16));
    }
    
    _WR(realAddr, 0x00700070); 
    ReadStatus=_RD(realAddr);             // Real Status Register
    bSR4=ReadStatus & (1<<4);
    bSR4_2=ReadStatus & (1<<(4+16));
    
    if (bSR4==0 && bSR4_2==0) 
    {
        //Uart_Printf("Successful Program!!\n");
        ;
    }else{
        //Uart_Printf("Error Program!!\n");
        _WR(realAddr, 0x00500050);          // Clear Status Register
        error_program=1;                    // But not major, is it casual ?
    }

    _RESET();

    return 0;
}


void WriteE28F128J3A(void)
{
    unsigned long interrupt_reservoir;
    int i, block_num;

	Uart_Printf("INTEL NOR flash Write Test\n");
	Uart_Printf("This test reads data from memory and writes data to INTEL flash\n");
	Uart_Printf("This test writes only one block you select\n");
	Uart_Printf("\nYou MUST be well aware that\n");
	Uart_Printf("1. the block size of INTEL flash is 0x%x\n", INTEL_BLK_SIZE);
	Uart_Printf("2. the base address of INTEL flash is 0x%x\n", base_address);
	
	targetSize = INTEL_BLK_SIZE;

	do{
		Uart_Printf("\n\nInput source data address you wanna read in memory[0x...]: ");
	    srcAddress = Uart_GetIntNum();
	
		Uart_Printf("\nSelect target block number you wanna write[0 ~ %d]: ", BLK_CNT-1);
		block_num = Uart_GetIntNum();
		targetAddress = base_address + (INTEL_BLK_SIZE * block_num);
		
	    Uart_Printf("\n\ntarget address = 0x%x(blcok[%3d])\n",targetAddress, block_num);
		Uart_Printf("source address = 0x%x\n",srcAddress);

	    Uart_Printf("\nErase the block you select[%3d:0x%x]\n", block_num, targetAddress);
		Strata_EraseSector(targetAddress);
    
		if(!Strata_BlankCheck(targetAddress, targetSize))
		{
			Uart_Printf("Blank Check Error!!!\n");
			return;
		}

	    Uart_Printf("\nStart of the data writing.. size[0x%x]\n", targetSize);
	    for (i=0; i<targetSize; i+=4) 
	    {
	        Strata_ProgFlash(targetAddress+i, *((U32 *)(srcAddress+i)));
	        if(i%0x8000==0)		Uart_Printf("%x ", i);
	    }
	    Uart_Printf("\nEnd of the data writing \n");

	    _RESET();

	    Uart_Printf("\nStart Verifying data\n");
	    for (i=0; i<targetSize; i+=4) 
	    {
	        if (*((U32 *)(targetAddress+i)) !=*((U32 *)(srcAddress+i)))
	        {
	            Uart_Printf("\n%x = verify error\n\n\n\n",i+targetAddress);
	            return;
	        }
	        if((i%0x8000)==0)	Uart_Printf("%x ",i);
	    }
	    Uart_Printf("\nVerifying End!!!\n");
    
	    Uart_Printf("\nDo you want to continue writing additional data?[y/n]");
	}while(Uart_Getch()=='y');
    
    Uart_Printf("\n\n\n");
}



