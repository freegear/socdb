#include <stdio.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"

#include "Uart_test.h"

#include "Uart0.h"
#include "Uart1.h"
#include "Uart2.h"


void * func_uart_test[][2]=
{	
//UART0
	(void *)Test_Uart0_Int, 	"UART0 Int      ",
	(void *)Test_Uart0_Dma, 	"UART0 DMA      ",
	(void *)Test_Uart0_Fifo,	"UART0 FIFO     ",
//	(void *)Test_Uart0_AfcTx, 	"UART0 AFC Tx   ",
//	(void *)Test_Uart0_AfcRx, 	"UART0 AFC Rx   ",
//	(void *)Test_Uart0_RxErr,	"UART0 RxErr    ",

//UART1	(developer wanna test this, you must modify)
//	(void *)Test_Uart1_Int, 	"UART1 Int      ",
//	(void *)Test_Uart1_Dma, 	"UART1 DMA      ",
//	(void *)Test_Uart1_Fifo,	"UART1 FIFO     ",
//	(void *)Test_Uart1_AfcTx, 	"UART1 AFC Tx   ",
//	(void *)Test_Uart1_AfcRx, 	"UART1 AFC Rx   ",

//UART2	(developer wanna test this, you must modify)
//	(void *)Test_Uart2_Int, 	"UART2 Int      ",
//	(void *)Test_Uart2_Dma, 	"UART2 DMA      ",
//	(void *)Test_Uart2_Fifo,	"UART2 FIFO     ",
	0,0
};

void Uart_Test(void)
{
	int i, sel;
	
	while(1)
	{
		i = 0;
		Uart_Printf("+-----------------[ UART test ]-------------------+\n");
		while(1)
		{   //display menu
			Uart_Printf("| %2d:%s\n",i+1,func_uart_test[i][1]);
			i++;
			if((int)(func_uart_test[i][0])==0)	break;
		}
		Uart_Printf("| %2d:Previous menu\n", i+1);
		Uart_Printf("+-------------------------------------------------+\n");
		Uart_Printf(" Select the number to test : ");
		sel = Uart_GetIntNum();
		sel--;
		Uart_Printf("+-------------------------------------------------+\n\n\n");
		if(sel == i){
			return;
		}if(sel>=0 && (sel<((sizeof(func_uart_test)-1)/8)) ){
			( (void (*)(void)) (func_uart_test[sel][0]) )();
		}else{
			Uart_Printf("Wrong number seleted.. Try again!!\n\n\n");
		}
	}
}

