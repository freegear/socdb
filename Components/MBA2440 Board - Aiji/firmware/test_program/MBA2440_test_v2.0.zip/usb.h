#ifndef __USB_H__
#define __USB_H__

extern volatile U8 		*downPt;
extern volatile int 	isUsbdSetConfiguration;
extern int 				download_run;
extern volatile U16 	checkSum;
extern volatile U32		tempdownloadAddress;
extern volatile U32		USBdownloadAddress;
extern volatile U32 	downloadFileSize;
extern volatile U32		totalDmaCount;



void USB_download(void);



#endif /*__USB_H__*/
