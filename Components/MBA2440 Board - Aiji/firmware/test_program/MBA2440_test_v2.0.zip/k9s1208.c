/****************************************************************************
 * file name	: k9s1208.c
 * Date			: 15. 04. 2005
 * Version		: 1.0
 * Description	: SMC(K9S1208) NAND flash test program
 *
 *
 ****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h" 

#include "k9s1208.h"
#include "nand_test.h"


#define K9S1208_BLOCK_COUNT		4096
#define K9S1208_MEM_SIZE		0x4000000	//64MB



void K9S1208_menu(void)
{
	int sel, K9S1208_NAND_id = 0;
	
	NAND_init();
	K9S1208_NAND_id = NAND_readID();
	if((K9S1208_NAND_id & 0xffff) != 0xec76){
		Uart_Printf("Unkown ID read!! ... 0x%x\n", K9S1208_NAND_id);
		Uart_Printf("Check whether J3 is 2-3 or Check SMC card in socket\n");
		Uart_Printf("and Try again!!\n\n\n");
		return;
	}

	while(1){
		Uart_Printf("+----------------[ K9S1208 test ]-----------------+\n");
		Uart_Printf("| Maker code = 0x%x, Device code = 0x%x\n",
			((K9S1208_NAND_id & 0xff00)>>8), (K9S1208_NAND_id & 0xff));
		Uart_Printf("+-------------------------------------------------+\n");
		Uart_Printf("| 1:Check bad block\n");
		Uart_Printf("| 2:Erase block\n");
		Uart_Printf("| 3:Read data from one block\n");
		Uart_Printf("| 4:Write data to one block\n");
		Uart_Printf("| 5:Previous menu\n");
		Uart_Printf("+-------------------------------------------------+\n");
		Uart_Printf(" Select number : ");
		sel = Uart_GetIntNum();
		Uart_Printf("+-------------------------------------------------+\n\n\n");
		
		switch(sel){
			case 1:
				NAND_check_block(K9S1208_BLOCK_COUNT);
				break;
			case 2:
				NAND_erase(K9S1208_BLOCK_COUNT);
				break;
			case 3 :
				NAND_read(K9S1208_BLOCK_COUNT);
				break;
			case 4 :
				NAND_write(K9S1208_BLOCK_COUNT);
				break;
			case 5 :
				return;
			default:
				Uart_Printf("Wrong number seleted.. Try again!!\n\n\n");
				break;
		}
	}
}


