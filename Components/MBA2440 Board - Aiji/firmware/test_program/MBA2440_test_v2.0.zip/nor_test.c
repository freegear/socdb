/****************************************************************************
 * file name	: nor_test.c
 * Date			: 15. 04. 2005
 * Version		: 1.0
 * Description	: NOR flash test menu display function
 *
 *
 ****************************************************************************/

#include <string.h>
#include "Def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h" 
#include "nor_test.h"




void NOR_flash_test(void)
{
	char sel = 0;
	
//	Check_NOR_flash();

	while(1){	
		Uart_Printf("+---------------[ NOR flash test ]----------------+\n");
		Uart_Printf("|  1:AM29LV800BB\n");
		Uart_Printf("|  2:INTEL E28F128J3C150\n");
		Uart_Printf("|  3:Previous menu\n");
		Uart_Printf("+-------------------------------------------------+\n");
		Uart_Printf(" Select the type of a NOR flash memory : ");
		sel = Uart_GetIntNum();
		Uart_Printf("+-------------------------------------------------+\n\n\n");
		
		switch(sel){
			case 1:
				AM29LV800_menu();
				break;
			case 2:
				STRATA32_menu();
				break;
			case 3:
				return;
			default:
				Uart_Printf("Wrong number seleted.. Try again!!\n\n\n");
				break;
		}
	}
}


void Check_NOR_flash(void)
{
    U16 manId;

    *((U16 *)(0x555<<1))=(U16)0xaaaa;
    *((U16 *)(0x2aa<<1))=(U16)0x5555;
    *((U16 *)(0x555<<1))=(U16)0x9090;
    manId = *((U16 *)(0x0<<1));
	
	if((manId & 0xff) == 0x1)		Which_NOR_flash = NOR_FLASH_AMD;
	else if((manId & 0xff) == 0x89)	Which_NOR_flash = NOR_FLASH_INTEL;
	
	return;
}


