/****************************************************************************
 * file name	: strate32.h
 * Date			: 15. 04. 2005
 * Version		: 1.0
 * Description	: INTEL 28F128J3C150 NOR flash test menu display function
 *
 *
 ****************************************************************************/

#ifndef __STRATA32_H__
#define __STRATA32_H__


void E28F128J3A_CheckId(void);
void ProgramE28F128J3A(void);
void EraseE28F128J3A(void);

#endif /*__STRATA32_H__*/

