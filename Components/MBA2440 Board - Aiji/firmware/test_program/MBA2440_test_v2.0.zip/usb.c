//====================================================================
// File Name : usb.c
// Function  : S3C2440 USB download program
//====================================================================

#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h"
#include "def.h"
#include "usb.h"
#include "usblib.h"


unsigned char *DFBuf,*usb_temp;


/******* for USB download *******/
volatile U32	USBdownloadAddress;
volatile U8 	*downPt;
volatile U32 	downloadFileSize;
volatile U16 	checkSum;
volatile U32	totalDmaCount;
volatile int 	isUsbdSetConfiguration;
int 			download_run=0;
volatile int	in_USB_Download;
volatile U32	tempdownloadAddress;


void dn_and_run(void);
void dn_only(void);
void dn_usb_start(int dn_flag);

void (*run)(void);

void __irq IsrUsbd(void);
void USB_Download(void);


void * Items_USB[][2]=
{
    (void *)dn_and_run,		"download binary and run   ",
    (void *)dn_only,		"download binary only      ",
    0,0
};

/*************************************************************************/
/* USB Test Routine for S3C2410                                          */
/*************************************************************************/
void USB_download(void)
{
	int i, sel;
	
	while(1)
    {
		int i=0;
		Uart_Printf("+-----------------[ USB download ]-------------------+\n");
		while(1)
		{   //display menu
			Uart_Printf("| %2d:%s\n",i+1,Items_USB[i][1]);
			i++;
			if((int)(Items_USB[i][0])==0)	break;
		}
		Uart_Printf("| %2d:Previous menu\n", i+1);
		Uart_Printf("+-------------------------------------------------+\n");
		Uart_Printf(" Select the number to test : ");
		sel = Uart_GetIntNum();
		sel--;
		Uart_Printf("+-------------------------------------------------+\n\n\n");
		if(sel == i){
			return;
		}if(sel>=0 && (sel<((sizeof(Items_USB)-1)/8)) ){
			( (void (*)(void)) (Items_USB[sel][0]) )();
		}else{
			Uart_Printf("Wrong number seleted.. Try again!!\n\n\n");
		}
    }
}

/*************************************************************************/
/* USB FILE DOWNLOAD                                                     */
/*************************************************************************/
void dn_only(void)
{
	dn_usb_start(0);
	return;
}

void dn_and_run(void)
{
	dn_usb_start(1);
	return;
}


void dn_usb_start(int dn_flag)
{
	if(dn_flag)		Uart_Printf("Download file and run the file...\n");
	else			Uart_Printf("Download file only...\n");

	Port_Init();
	
	// USB device detection control
	rGPGCON &= ~(3<<24);
	rGPGCON |=  (1<<24); // output
	rGPGUP  |=  (1<<12); // pullup disable
	rGPGDAT |=  (1<<12); // output
	
	//Interrupt initialization
   	pISR_USBD  = (unsigned)IsrUsbd;
	pISR_DMA2  = (unsigned)IsrDma2;
	
   	ClearPending(BIT_DMA2);
   	ClearPending(BIT_USBD);

   	rMISCCR &= ~(1<<3);		// USBD is selected instead of USBH1 
	rMISCCR &= ~(1<<13);	// USB port 1 is enabled.

	in_USB_Download = 1;
	//USBD should be initialized first of all.
   	isUsbdSetConfiguration = 0;

   	ChangeUPllValue(60,4,2);  //UCLK=48Mhz

	MMU_EnableICache();
	MMU_EnableICache();
	
	InitDescriptorTable();
    ConfigUsbd(); 
    PrepareEp1Fifo(); 
	Delay(0);  //calibrate Delay()
	
	pISR_SWI=(_ISR_STARTADDRESS+0xf0);	//for pSOS
	
	Clk0_Disable();
	Clk1_Disable();

	download_run = dn_flag;
	while(in_USB_Download == 1)	USB_Download();

	MMU_DisableICache();
	MMU_DisableDCache();
}


void USB_Download(void)
{
	int first = 1, i, j;
	U8 key = 0;
	U16 cs, dnCS, checkSum = 0;
	U32 temp;
	U8 tempMem[16];
	
	USBdownloadAddress = (U32)tempMem;
	downPt = (unsigned char *)USBdownloadAddress;
	downloadFileSize = 0;
	
	if(isUsbdSetConfiguration == 0){
		Uart_Printf("\nUSB host is not connected yet.\n");
		Uart_Printf("Connect USB cable to MBA2440 USB slave port\n");
	}
	
	while(downloadFileSize == 0){
		if(first == 1 && isUsbdSetConfiguration != 0)
		{
			Uart_Printf("\n\nUSB host is connected\n");
			Uart_Printf("Input download addrss in 'Configuration->Option' menu of DNW\n");
			Uart_Printf("and then select the file you wanna download in 'USB Port->Transmit' menu of DNW\n");
			Uart_Printf("Waiting a download... \n");
            first=0;
        }
		
		Led_Display(1);
		j = 1;
		while(j != 3){
			Delay(1500);
			Led_Display(1<<j);
			j++;
		}
		while(j != 0){
			Delay(1500);
			Led_Display(1<<j);
			j--;
		}
		Delay(1000);
		
		key = Uart_GetKey();
		if(key != 0)
		{
			Uart_Printf("USB host is not connected yet.\n");
			Uart_Printf("Connect USB cable to MBA2440 USB slave port\n");
			first = 1;
		}
	}
	
	rINTMSK &= ~(BIT_DMA2);
	
	ClearEp3OutPktReady();//in usbout.c
	// indicate the first packet is processed.
	// has been delayed for DMA2 cofiguration.
	
	if(downloadFileSize > EP3_PKT_SIZE)
	{
		if(downloadFileSize <= 0x80000)
		{
			ConfigEp3DmaMode(USBdownloadAddress+EP3_PKT_SIZE-8,downloadFileSize-EP3_PKT_SIZE);
		}else{
			ConfigEp3DmaMode(USBdownloadAddress+EP3_PKT_SIZE-8,0x80000-EP3_PKT_SIZE);
			
			if(downloadFileSize>(0x80000*2))//for 1st autoreload
			{
				rDIDST2=(USBdownloadAddress+0x80000-8);	//for 1st autoreload.
				rDIDSTC2=(1<<2)|(0<<1)|(0<<0);
				rDCON2=rDCON2&~(0xfffff)|(0x80000);
				
				while(rEP3_DMA_TTC<0xfffff)
				{
					rEP3_DMA_TTC_L=0xff;
					rEP3_DMA_TTC_M=0xff;
					rEP3_DMA_TTC_H=0xf;
				}
			}else{
				rDIDST2=(USBdownloadAddress+0x80000-8);
				rDIDSTC2=(1<<2)|(0<<1)|(0<<0);
				rDCON2=rDCON2&~(0xfffff)|(downloadFileSize-0x80000);
				
				while(rEP3_DMA_TTC<0xfffff)
				{
					rEP3_DMA_TTC_L=0xff;
					rEP3_DMA_TTC_M=0xff;
					rEP3_DMA_TTC_H=0xf;
				}
			}
		}
		
		totalDmaCount = 0;
	}else{
		totalDmaCount=downloadFileSize;	
	}

	Uart_Printf("\nNow, Downloading [ADDRESS:0x%x ,TOTAL:%d bytes]\n",
		USBdownloadAddress, downloadFileSize);

	Uart_Printf("RECEIVED FILE SIZE: %8d",0);
	
	j = 0x10000;
	
	while(1)
	{
		if( (rDCDST2-(U32)USBdownloadAddress+8) >= j)
		{
			Uart_Printf("\b\b\b\b\b\b\b\b%8d",j);
			j += 0x10000;
		}
		
		if(totalDmaCount >= downloadFileSize)		break;
	}

	Uart_Printf("\b\b\b\b\b\b\b\b%8d bytes", downloadFileSize);
	
	// Verify check sum
	Uart_Printf("\nNow, Checksum calculation\n");
	
	cs = 0;
	i = USBdownloadAddress;
	j = (USBdownloadAddress + downloadFileSize-10) & 0xfffffffc;
	
	while(i<j)
	{
		temp = *((U32 *)i);
		i += 4;
		cs += (U16)(temp&0xff);	
		cs += (U16)((temp&0xff00)>>8);
		cs += (U16)((temp&0xff0000)>>16);
		cs += (U16)((temp&0xff000000)>>24);
	}
	
	i = (USBdownloadAddress + downloadFileSize-10) & 0xfffffffc;
	j = (USBdownloadAddress + downloadFileSize-10);
	
	while(i<j)		cs += *((U8 *)i++);
	
	checkSum =cs;
	
	dnCS = *((unsigned char *)(USBdownloadAddress + downloadFileSize-8-2))+
		(*( (unsigned char *)(USBdownloadAddress + downloadFileSize-8-1))<<8);
		
	if(checkSum!=dnCS)
	{
		Uart_Printf("Checksum Error!!! MEM:%x DN:%x\n",checkSum,dnCS);
		return;
	
	}
	
	Uart_Printf("Download O.K.\n\n\n");
	Uart_TxEmpty(0);
	
	if(download_run == 1){
		rINTMSK=BIT_ALLMSK;
		run=(void (*)(void))USBdownloadAddress;
		Uart_Printf("run thd download file... (0x%x)\n\n\n\n",
			USBdownloadAddress);
		run();
	}
	
	in_USB_Download = 0;	
}


void __irq IsrUsbd(void)
{
    U8 usbdIntpnd,epIntpnd;
    U8 saveIndexReg=rINDEX_REG;
    usbdIntpnd=rUSB_INT_REG;
    epIntpnd=rEP_INT_REG;
//	Uart_Printf("[INT:EP_I=%x,USBI=%x]",epIntpnd,usbIntpnd);

    if(usbdIntpnd & SUSPEND_INT)
    {
    	rUSB_INT_REG=SUSPEND_INT;
//		Uart_Printf( "<SUS]");
    }
    if(usbdIntpnd & RESUME_INT)
    {
    	rUSB_INT_REG=RESUME_INT;
//		Uart_Printf("<RSM]");
    }
    if(usbdIntpnd & RESET_INT)
    {
//		Uart_Printf( "<RST]");
//		Uart_Printf("addr= 0x%x, down_file_size = %d\n", USBdownloadAddress, downloadFileSize);
    	ReconfigUsbd();
		//RESET_INT should be cleared after ResetUsbd()
    	rUSB_INT_REG=RESET_INT;   	

        PrepareEp1Fifo(); 
    }

    if(epIntpnd & EP0_INT)
    {
		rEP_INT_REG=EP0_INT;  
    	Ep0Handler();
    }
    if(epIntpnd & EP1_INT)
    {
    	rEP_INT_REG=EP1_INT;  
    	Ep1Handler();
    }

    if(epIntpnd & EP3_INT)
    {
    	rEP_INT_REG=EP3_INT;
    	Ep3Handler();
    }

    ClearPending(BIT_USBD);	 
    
    rINDEX_REG=saveIndexReg;
}

#if 0
void MarchCMinus32(int address,int unit,unsigned int pattern)
{
    int i;
    unsigned int *tempPt;
    
    tempPt=(unsigned int *)address;
    
    for(i=0;i<=unit;i++)
    {
        //Uart_Printf("P=%x",pattern);
        *tempPt++=pattern;
        //Uart_Printf("A=%x,P=%x\n",tempPt,*tempPt);
    }
    
	Uart_Printf("\nWaitting 1 Sec\n");
	Delay(10000);
	Uart_Printf("Start\n");    
    
    _MarchSub1((unsigned int *)address,unit,~pattern,1);
    _MarchSub1((unsigned int *)address,unit,pattern,1);
    _MarchSub1((unsigned int *)address+unit,unit,~pattern,-1);
    _MarchSub1((unsigned int *)address+unit,unit,pattern,-1); 
    
    tempPt=(unsigned int *)address;
    for(i=0;i<=unit;i++)
    {
        if(*tempPt!=pattern)
        {
            MarchError=1;
//          Uart_Printf("ERROR0:%x\n",tempPt);
            Uart_Printf("ERROR0 : Address= 0x%8x,    Write= 0x%8x,    Read= 0x%8x\n",tempPt,pattern,*tempPt);           
        }
        tempPt++;
    }
    //Uart_Printf("RP=%x,RA=%x\n",*tempPt,tempPt);
}


void _MarchSub1(unsigned int *pt,int unit,unsigned int pattern,int incdec)
{
    unsigned int i,rp;

    for(i=0;i<=unit;i++)
    {
        rp=*pt;
        //Uart_Printf("RP=%x",*pt);
        *pt=pattern;
        //Uart_Printf("j=%x,p=%x,pt=%x\n",rp,(~pattern),pt);
        if(rp!=(~pattern))
        {
            MarchError=1;
//          Uart_Printf("ERROR1:A=%x,RP=%x,WP=%x \n",pt,rp,(~pattern));
            Uart_Printf("ERROR1 : Address= 0x%8x,    Write= 0x%8x,    Read= 0x%8x\n",pt,(~pattern),rp);         
        }
        pt+=incdec;
    }
}
#endif

