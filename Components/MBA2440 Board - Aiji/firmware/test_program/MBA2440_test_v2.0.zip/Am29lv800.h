/****************************************************************************
 * file name	: Am29lv800.h
 * Date			: 15. 04. 2005
 * Version		: 1.0
 * Description	: AM29LV800BB NOR flash test menu display function
 *
 *
 ****************************************************************************/

#ifndef __AM29LV800_h__
#define __AM29LV800_h__


void AM29LV800_menu(void);


#endif /*AM29LV800*/

