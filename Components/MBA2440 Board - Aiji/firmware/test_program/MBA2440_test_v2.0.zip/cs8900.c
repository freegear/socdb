/*************************************************************************/
/* FILE			CS8900.C                                                 */
/*                                                                       */
/* FUNCTION		CS8900 TEST ROUTINE                                      */
/* DESCRIPTION                                                           */
/* 		This is a CS8900 program for M300 system with samsung S3C2410.   */
/*                                                                       */
/* DEPENDENCIES                                                          */
/*                                                                       */
/* EDITED BY                                                             */
/* 		sjjo	Initialize                                               */
/* Copyright (C) 1998-2005 AIJISYSTEM CO.,LTD.                           */
/*************************************************************************/
#include <string.h>
#include "def.h"
#include "2440addr.h"
#include "2440lib.h"
#include "cs8900.h"

void Send_Data(void);
void Rece_Data(void);

void * Items_CS8900[][2]=
{
    (void *)Get_CS8900_ID,	"Get_CS8900_ID     ",
//	(void *)Send_Data,		"Send_Data         ",
//	(void *)Rece_Data,		"Rece_Data         ",
    0,0
};

void CS8900_Test(void)
{
	int i, sel;
	while(1)
    {
		i = 0;
		Uart_Printf("+----------------[ CS8900 test ]-------------------+\n");
        while(1) //display menu
        {
            Uart_Printf("| %2d:%s\n",i+1,Items_CS8900[i][1]);
            i++;
			if((int)(Items_CS8900[i][0])==0)	break;
        }
		Uart_Printf("| %2d:Previous menu\n", i+1);
		Uart_Printf("+-------------------------------------------------+\n");
		Uart_Printf(" Select the number to test : ");
		sel = Uart_GetIntNum();
		sel--;
		Uart_Printf("+-------------------------------------------------+\n\n\n");
		if(sel == i){
			return;
		}if(sel>=0 && (sel<((sizeof(Items_CS8900)-1)/8)) ){
			( (void (*)(void)) (Items_CS8900[sel][0]) )();
		}else{
			Uart_Printf("Wrong number seleted.. Try again!!\n\n\n");
		}
    }
}


static unsigned short get_reg (int regno)
{
	CS8900_PPTR = regno;
	return (unsigned short) CS8900_PDATA;
}


static void put_reg (int regno, unsigned short val)
{
	CS8900_PPTR = regno;
	CS8900_PDATA = val;
}


static void readpkt(int from, short *to, int len)
{
	int i;
	volatile unsigned short *sptr;

	sptr = (unsigned short *)(CS8900_BASE + CS8900_RTDATA);
	for(i=0; i<len; i++)
		*to++ = *sptr++;
}

static void writepkt(int to, unsigned short *from, int len)
{
	int i;
	volatile unsigned short *dptr;

	dptr = (unsigned short *)(CS8900_BASE + CS8900_RTDATA);
	for(i=0; i<len; i++)
		*dptr = *from++;
}

static void cs8900_register(void)
{
   	Uart_Printf("PP_ChipID  [%x: %x]\n", PP_ChipID, get_reg(PP_ChipID));
   	Uart_Printf("PP_IOBASE  [%x: %x]\n", PP_IOBASE, get_reg(PP_IOBASE));
    Uart_Printf("PP_RxCFG   [%x: %x]\n", PP_RxCFG, get_reg(PP_RxCFG));
   	Uart_Printf("PP_RxCTL   [%x: %x]\n", PP_RxCTL, get_reg(PP_RxCTL));
    Uart_Printf("PP_TxCFG   [%x: %x]\n", PP_TxCFG, get_reg(PP_TxCFG));
   	Uart_Printf("PP_TxCMD   [%x: %x]\n", PP_TxCmd, get_reg(PP_TxCmd));
    Uart_Printf("PP_BufCFG  [%x: %x]\n", PP_BufCFG, get_reg(PP_BufCFG));
   	Uart_Printf("PP_LineCTL [%x: %x]\n", PP_LineCTL, get_reg(PP_LineCTL));
    Uart_Printf("PP_SelfCTL [%x: %x]\n", PP_SelfCTL, get_reg(PP_SelfCTL));
   	Uart_Printf("PP_BusCTL  [%x: %x]\n", PP_BusCTL, get_reg(PP_BusCTL));
    Uart_Printf("PP_TestCTL [%x: %x]\n", PP_TestCTL, get_reg(PP_TestCTL));
    Uart_Printf("\n\n\n");
}


static void eth_reginit (void)
{
	/* receive only error free packets addressed to this card */
	put_reg (PP_RxCTL, PP_RxCTL_IA | PP_RxCTL_Broadcast | PP_RxCTL_RxOK);

	/* do not generate any interrupts on receive operations */
	put_reg (PP_RxCFG, 0);

	/* do not generate any interrupts on transmit operations */
	put_reg (PP_TxCFG, 0);

	/* do not generate any interrupts on buffer operations */
	put_reg (PP_BufCFG, 0);

	/* enable transmitter/receiver mode */
	put_reg (PP_LineCTL, PP_LineCTL_Rx | PP_LineCTL_Tx);
}


static void eth_reset (void)
{
	int tmo;
	unsigned short us;

	/* reset NIC */
	put_reg (PP_SelfCTL, get_reg (PP_SelfCTL) | PP_SelfCTL_Reset);

	/* wait for 200ms */
	Delay (200);
	/* Wait until the chip is reset */
}


static unsigned short get_reg_init_bus(int regno)
{
	/* force 16 bit busmode */
	volatile unsigned char c;
	unsigned short ChipID;

	ChipID = CS8900_PPTR;
	Uart_Printf("ChipID[%x]\n",ChipID);

	c = CS8900_BUS16_0;
	c = CS8900_BUS16_1;
	c = CS8900_BUS16_0;
	c = CS8900_BUS16_1;
	c = CS8900_BUS16_0;


	CS8900_PPTR = regno;
	return (unsigned short) CS8900_PDATA;
}


void Get_CS8900_ID(void)
{
	int i;

	/* verify chip id */
	if (get_reg_init_bus(PP_ChipID) != 0x630e) {
		Uart_Printf("CS8900 Ethernet chip not found?!\n");
	}

	eth_reset ();

	/* set the ethernet address */
	put_reg (PP_IA + 0, 0x1122);
	put_reg (PP_IA + 2, 0x3344);
	put_reg (PP_IA + 4, 0x5566);

	eth_reginit ();
	cs8900_register();
}

void Send_Data(void)
{
	int i, length;
	static char tx_buff[10];
	volatile unsigned short *addr;
	unsigned long  flags;
	unsigned short packet[10]={0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99};

retry:
	// initiate a transmit sequence
	CS8900_TxCMD = PP_TxCmd_TxStart_Full;
	CS8900_TxLEN = length;

	/* Test to see if the chip has allocated memory for the packet */
	if ((get_reg (PP_BusSTAT) & PP_BusSTAT_TxRDY) == 0) {
		eth_reset ();
		eth_reginit ();
		goto retry;
	}

	for(i=0; i<10; i++)
	{
	length = 0;
	/* Write the contents of the packet */
	/* assume even number of bytes */
	for (addr = &packet[0]; length > 0; length -= 2)
		CS8900_RTDATA = *addr++;
	}

	{int i; for(i=0; i<0xff; i++);}
	
	/* nothing */ ;
	if ((get_reg (PP_TER) & (PP_TER_CRS | PP_TER_TxOK)) != PP_TER_TxOK) {
		Uart_Printf("transmission error\n");
	}

	return;
}


//extern int eth_rx (void)
void Rece_Data(void)
{
	int i;
	unsigned short rxlen,len;
	unsigned short *addr;
	unsigned short status;
	unsigned short NetRxPackets[1024];

	// Assign interrupt number
	put_reg(PP_IntReg, PP_IntReg_IRQ0);

	// set the Ethernet address
	put_reg(PP_IA+0,1122);
	put_reg(PP_IA+2,3344);
	put_reg(PP_IA+4,5566);

	// Turn on both receive and transmit operations
	put_reg(PP_LineCTL, get_reg(PP_LineCTL) | PP_LineCTL_Rx | PP_LineCTL_Tx);

	// Receive only error free packets addressed to this card
	put_reg(PP_RxCTL, PP_RxCTL_IA|PP_RxCTL_Broadcast|PP_RxCTL_RxOK);
	Uart_Printf("PP_RxCTL [%x: %x]\n", PP_RxCTL, get_reg(PP_RxCTL));

	put_reg(PP_RxCFG, PP_RxCFG_RxOK|PP_RxCFG_CRC|PP_RxCFG_BufferCRC);
	Uart_Printf("PP_RxCFG [%x: %x]\n", PP_RxCFG, get_reg(PP_RxCFG));

	put_reg(PP_TxCFG, PP_TxCFG_CRS|PP_TxCFG_SQE|PP_TxCFG_TxOK|PP_TxCFG_Late|PP_TxCFG_Jabber|PP_TxCFG_Collision|PP_TxCFG_16Collisions);
	Uart_Printf("PP_TxCFG [%x: %x]\n", PP_TxCFG, get_reg(PP_TxCFG));

	put_reg(PP_BufCFG, PP_BufCFG_TxRDY|PP_BufCFG_RxMiss|PP_BufCFG_TxCol|PP_BufCFG_TxUE);
	Uart_Printf("PP_BufCFG[%x: %x]\n", PP_BufCFG, get_reg(PP_BufCFG));

	// now that we've got our act together, enable everything
	Uart_Printf("PP_BusCTL[%x: %x]\n", PP_BusCTL, get_reg(PP_BusCTL));

	status = get_reg (PP_RER);
    Uart_Printf("RX_status[%x]\n",status);

	if ((status & PP_RER_RxOK) == 0)
	{
	    Uart_Printf("PP_RER_RxOK : 0\n");
		while(Uart_GetIntNum());

		// Reset
		put_reg(PP_SelfCTL, PP_SelfCTL_Reset);
	}

#if 0
	status = CS8900_RTDATA;		/* stat */
	rxlen = CS8900_RTDATA;		/* len */
	len = rxlen;

    Uart_Printf("Rece_stat[%x], Rece_rxlen[%x]\n",status,rxlen);

	for (addr = (unsigned short *) NetRxPackets[0], i = rxlen >> 1; i > 0; i--)
		*addr++ = CS8900_RTDATA;
	if (rxlen & 1)
		*addr++ = CS8900_RTDATA;

	addr = (unsigned short *) NetRxPackets[0];
	for(i=0; i<len; i++)
		Uart_Printf("%04x ",*(addr+i));

	/* Pass the packet up to the protocol layers. */
	NetReceive (NetRxPackets[0], rxlen);

	return rxlen;
#endif
}

#if 0
//===================================================================
void __irq EthInt(void)
{
    rSUBSRCPND = BIT_SUB_RXD1;          //Clear pending bit (Requested)
    rSUBSRCPND;

    ClearPending(BIT_UART1);

    *dnbuf ++= RdURXH1(); 
}
#endif
