/****************************************************************************
 * file name	: k9f5608.c
 * Date			: 15. 04. 2005
 * Version		: 1.0
 * Description	: SOP(K9F5608U0B) NAND flash test program
 *
 *
 ****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h" 

#include "k9f5608.h"
#include "nand_test.h"


#define K9F5608_BLOCK_COUNT		2048
#define K9F5608_MEM_SIZE		0x2000000	//32MB


void K9F5608_menu(void)
{
	int sel, K9F5608_NAND_id = 0;
	
	NAND_init();
	K9F5608_NAND_id = NAND_readID();
	if((K9F5608_NAND_id & 0xffff) != 0xec75){
		Uart_Printf("Unkown ID read!! ... 0x%x\n", K9F5608_NAND_id);
		Uart_Printf("Check whether J3 is 1-2 and Try again!!\n\n\n");
		return;
	}

	while(1){	
		Uart_Printf("+----------------[ K9F5608 test ]-----------------+\n");
		Uart_Printf("| Maker code = 0x%x, Device code = 0x%x\n",
			((K9F5608_NAND_id & 0xff00)>>8), (K9F5608_NAND_id & 0xff));
		Uart_Printf("+-------------------------------------------------+\n");
		Uart_Printf("| 1:Check bad block\n");
		Uart_Printf("| 2:Erase block\n");
		Uart_Printf("| 3:Read data from one block\n");
		Uart_Printf("| 4:Write data to one block\n");
		Uart_Printf("| 5:Previous menu\n");
		Uart_Printf("+-------------------------------------------------+\n");
		Uart_Printf(" Select number : ");
		sel = Uart_GetIntNum();
		Uart_Printf("+-------------------------------------------------+\n\n\n");
		
		switch(sel){
			case 1:
				NAND_check_block(K9F5608_BLOCK_COUNT);
				break;
			case 2:
				NAND_erase(K9F5608_BLOCK_COUNT);
				break;
			case 3 :
				NAND_read(K9F5608_BLOCK_COUNT);
				break;
			case 4 :
				NAND_write(K9F5608_BLOCK_COUNT);
				break;
			case 5 :
				return;
			default:
				Uart_Printf("Wrong number seleted.. Try again!!\n\n\n");
				break;
		}
	}
}






