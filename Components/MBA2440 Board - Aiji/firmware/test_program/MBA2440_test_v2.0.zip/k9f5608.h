/****************************************************************************
 * file name	: k9f5608.h
 * Date			: 15. 04. 2005
 * Version		: 1.0
 * Description	: SOP(K9F5608U0B) NAND flash test program
 *
 *
 ****************************************************************************/

#ifndef __K9F5608V0B_H__
#define __K9F5608V0B_H__


void K9F5608_menu(void);



#endif /*__K9F5608V0B_H__*/
