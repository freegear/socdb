/************************************************
 * NAME    : 2440loader.c
 * DESC    : 
 * History : 2002.02.25 ver 0.0
 * rev0.1  : 2003. 05.xx modified for 2440
 * rev0.2  : 2004. 02.xx modified for 2440A(xtal 16.9344MHz)
 * rev1.0  : 2005. 05.xx modified for MBA2440
 ************************************************/

#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440slib.h"
#include "Nand.h"


#define BOOT_IMAGE_SIZE				(0x1400000)	//size of WinCE image
#define BOOT_IMAGE_BLOCK_COUNT		(BOOT_IMAGE_SIZE/0x4000)


#ifndef BOOT_START_ADDR_OFFSET
#define	BOOT_START_ADDR_OFFSET 		(0x200000)
#endif


#ifndef	COREVOLT_M100
#define	COREVOLT_M100				(130)
#endif

#define DOWNLOAD_ADDRESS 	(_RAM_STARTADDRESS+BOOT_START_ADDR_OFFSET)

void (*run)(void)=(void (*)(void))(DOWNLOAD_ADDRESS);

void Port_Init(void);
void Led_Display(int);
void Delay(int);

volatile unsigned char *downPt;
volatile unsigned char *srcPt;

void Timer4_Start(void);
void Timer4_Stop(void);
char *hex2char(int val);

void Set_Pre(void);	// for current test


void Main(void)
{
    register page, block, blockcopy_count, copy_count;
    int i, j;

    MMU_EnableICache();
	Port_Init();
	Uart_Init(PCLK, 115200);
	Uart_Select(0);
	
	downPt=(unsigned char *)DOWNLOAD_ADDRESS;
	
	rGPACON = (rGPACON &~(0x3f<<17)) | (0x3f<<17);
	NF8_Init();
	
  	Max1718_Set(COREVOLT_M100);
  	Led_Display(1);

	Timer4_Start();	// To calculation copy time.
	
	block=0;
	blockcopy_count=0;
	while(blockcopy_count<BOOT_IMAGE_BLOCK_COUNT) {		 // Read OS image
		block++;
		if(!NF8_IsBadBlock(block))  continue;      // Skip bad block
		for(page=0;page<32;page++) {  // Read 32 page
			if(!NF8_ReadPage(block, page, (U8 *)downPt)) {
			 Led_Display(0x8);   // real ECC Error
			 while(1);
			}
	  		downPt += 512;	
		}
		blockcopy_count++;
	}
	
	Led_Display(0xf);
	Timer4_Stop();

	Set_Pre();
	run();
}


#define TIMER_IINIT_VAL	(0xffff)

void Timer4_Start(void)
{
    Uart_SendString("\n\nImage loading Start\n");
    
    rTCFG0=0xff00;		// Prescaler 0xff+1(256)
    rTCFG1=(0x3<<16);	//T4=PCLK period*256*16 = 
    rTCNTB4=TIMER_IINIT_VAL;
    rTCON=(1<<22)|(1<<21);  //Manual update, to validate TCNTB4 value.
    rTCON=(1<<22)|(1<<20);  //Start T4
}

void Timer4_Stop(void)
{
    int cnt;
	
	rTCON=(1<<22)|(0<<20);  //Stop T4
    cnt=TIMER_IINIT_VAL-rTCNTO4;	// actual count number

    Uart_SendString("Image loading End\n");
    Uart_SendString("Boot time=nTCNT*82uS. nTCNT=0x");
    Uart_SendString(hex2char((cnt&0xf000)>>12));
    Uart_SendString(hex2char((cnt&0x0f00)>>8));
    Uart_SendString(hex2char((cnt&0x00f0)>>4));
    Uart_SendString(hex2char((cnt&0x000f)>>0));
	Uart_SendString(". \n");
	
}


char *hex2char(int val)
{
    static char str[2];
	
    str[1]='\0';
    if(val<=9)str[0]='0'+val;
    else str[0]=('a'+val-10);
	
    return str;
}

void Set_Pre(void)
{
	int i;

	i = rGPDCON; 

	rGPDCON = (rGPFCON & ~(3<<4)) | (0<<4);
	if((rGPFDAT&(1<<2))==0) {    // If EINT2 key is pressed.
		Uart_SendString("I/O Strength Max\n\n\n");
		// Set I/O strength control.
		rDSC0 = (0<<31)|(0<<8)|(0<<0);
		rDSC1 = (0<<28)|(0<<26)|(0x000000<<0);
	} else {
		Uart_SendString("I/O Strength Min\n\n\n");
		// Set I/O strength control.
		rDSC0 = (0<<31)|(3<<8)|(3<<0);
		// nEN_DSC  [31]    : 0:I/O drive strength enable, 1:Disable
		// DSC_ADR  [9:8]   : Addr drive strength, 0:10mA, 1:8mA, 2:6mA, 3:4mA
		// DSC_DATA [7:0]   : DATA drive strength, 0:12mA, 1:10mA, 2:8mA, 3:6mA
		
		rDSC1 = (3<<28)|(3<<26)|(0xffffff<<0);
		// DSC_SCK1 [29:28] : SCLK1, 0:16mA, 1:12mA, 2:8mA, 3:6mA 
		// DSC_SCK0 [27:26] : SCLK0, 0:16mA, 1:12mA, 2:8mA, 3:6mA 
		// DSC_SCKE [25:24] : SCLKE, 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_SDR  [23:22] : nRAS/nCAS, 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_NFC  [21:20] : Nand flash(nFCE,nFRE,nFWE,CLE,ALE), 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_BE   [19:18] : nBE[3:0], 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_WOE  [17:16] : nBE[3:0], 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_CS7  [15:14] : nGCS7, 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_CS6  [13:12] : nGCS6, 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_CS5  [11:10] : nGCS5, 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_CS4  [9:8]   : nGCS4, 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_CS3  [7:6]   : nGCS3, 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_CS2  [5:4]   : nGCS2, 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_CS1  [3:2]   : nGCS1, 0:10mA, 1:8mA, 2:6mA, 3:4mA 
		// DSC_CS0  [1:0]   : nGCS0, 0:10mA, 1:8mA, 2:6mA, 3:4mA 
	}
	rGPDCON = i;
}
