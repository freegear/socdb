/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***  This file contains the VUSB OTG demo
***                                                               
**************************************************************************
**END*********************************************************/

/**************************************************************************
Include the USB stack header files.
**************************************************************************/

#ifdef __USB_OTG__
   #include "otgapi.h"
#else
   #include "hostapi.h"
   #include "devapi.h"
#endif

/**************************************************************************
Include the OS and BSP dependent files that define IO functions and
basic types. You may like to change these files for your board and RTOS 
**************************************************************************/

#ifdef __USB_OS_MQX__
   #include "bsp.h"
   #include "fio.h"
   #include "mqx_arc.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif   
   #include "stdlib.h"
#endif

#include "string.h"
/**************************************************************************
Local header files for this application
**************************************************************************/
#include "demo_d.h"
#include "demo.h"
#include "demo_h.h"

extern boolean  SUSPEND_ATTEMPTED;
extern boolean  RESUME_RECEIVED;

/**************************************************************************
The following is the way to define a multi tasking system in MQX. As seen
here,two tasks have been defined. They are called as MAIN_TASK and FILE_TASK.
MAIN TASK has been slightly higher priority (6L) that file system (7L),just
to ensure that OTG events are handled first then file system. Remove this
code and use your own RTOS way of defining tasks (or threads).
**************************************************************************/

#ifdef __USB_OS_MQX__
extern void Main_Task(uint_32 param);
#define MAIN_TASK       10

TASK_TEMPLATE_STRUCT  MQX_template_list[] =
{
   { MAIN_TASK,      Main_Task,      6000L,  7L, "Main",      MQX_AUTO_START_TASK},
   { 0L,             0L,             0L,   0L, 0L,          0L }
};
#endif

/**************************************************************************
A driver info table defines the devices that are supported and handled
by file system application. This table defines the PID, VID, class and
subclass of the USB device that this application listens to. If a device
that matches this table entry, USB stack will generate a attach callback.
As noted, this table defines no specific device and so the applictaion
will get event callbacks for all attach and detach events from stack.
**************************************************************************/

static USB_HOST_DRIVER_INFO DriverInfoTable[] =
{
   {
      {0x00,0x00},                  /* All-zero entry terminates        */
      {0x00,0x00},                  /*    driver info list.             */
      0,
      0,
      0,
      0,
      usb_host_device_event
   },

   {
      {0x00,0x00},                  /* All-zero entry terminates        */
      {0x00,0x00},                  /*    driver info list.             */
      0,
      0,
      0,
      0,
      NULL
   }

};

/**************************************************************************
   Global variables
**************************************************************************/

/*the following 3 handles are used to talk to each part of the stack API
device, host and OTG*/
_usb_device_handle   dev_handle;
_usb_host_handle     host_handle;
_usb_otg_handle      app_otg_handle;

uchar_ptr MASS_STORAGE_DISK;

uchar BOOT_SECTOR_AREA[512] = {
   /* Block 0 is the boot sector. Following is the data in the boot sector */
   /* 80x86 "short: jump instruction, indicating that the disk is formatted */
    0xEB, 
    /* 8-bit displacement */
    0x3C, 
    /* NOP OPCode */
    0x90, 
    /* 8-bytes for OEM identification: "ARC 4.3 " */
    0x41, 0x52, 0x43, 0x20, 0x34, 0x2E, 0x33, 0x20, 
    /* bytes/sector: 512 bytes (0x0200) */
    0x00, 0x02, 
    /* Sectors/allocation unit */
    0x01,
    /* Reserved sectors: 0x0001 */
    0x01, 0x00, 
    /* Number of File Allocation Tables (FATs): 2 */
    0x02,
    /* Number of root directory entries */
    0x70, 0x00, 
    /* Total sectors in logical volume: 720 */
    USB_uint_16_low(TOTAL_LOGICAL_ADDRESS_BLOCKS), 
    USB_uint_16_high(TOTAL_LOGICAL_ADDRESS_BLOCKS),
    /* Media descriptor byte: 0xF8: Fixed disk */
    0xFD,
    /* Sectors/FAT: 3 (Each FAT starts at a new sector) */
    0x03, 0x00, 
    /* Sectors/track: 9 */
    0x09, 0x00, 
    /* Number of heads */
    0x02, 0x00, 
    /* Number of hidden sectors: 0 */
    0x00, 0x00, 0x00, 0x00, 
    /* Total sectors in logical volume */
    0x00, 0x00, 0x00, 0x00, 
    /* Physical drive number */
    0x00, 
    /* Reserved */
    0x00, 
    /* Extended boot signature record: 0x29 */
    0x29,
    /* 32-bit binary volume ID */
    0x01, 0x02, 0x03, 0x04, 
    /* Volume label */
    0x56, 0x41, 0x75, 0x74, 0x6F, 0x6D, 0x61, 0x74, 0x69, 0x6F, 0x6E, 
    /* Reserved */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    /* Bootstrap */
    0x33, 0xC0, 0x8E, 0xD0, 0xBC, 0x00, 0x7C, 0xFC, 0xE8, 0x45, 0x00, 
    /* String: \r\nNon-System disk\r\nPress any key to reboot\r\n" */
    0x0D, 0x0A, 0x4E, 0x6F, 0x6E, 0x2D, 0x53, 0x79, 0x73, 0x74, 0x65,
    0x6D, 0x20, 0x64, 0x69, 0x73, 0x6B, 0x0D, 0x0A, 0x50, 0x72, 0x65, 
    0x73, 0x73, 0x20, 0x61, 0x6E, 0x79, 0x20, 0x6B, 0x65, 0x79, 0x20, 
    0x74, 0x6F, 0x20, 0x72, 0x65, 0x62, 0x6F, 0x6F, 0x74, 0x0D, 0x0A, 
    0x5E, 0xEB, 0x02, 0xCD, 0x10, 0xB4, 0x0E, 0xBB, 0x07, 0x00, 0x2E, 
    0xAC, 0x84, 0xC0, 0x75, 0xF3, 0x98, 0xCD, 0x16, 0xCD, 0x19, 0xEB, 
    0xB1, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    /* Partition descriptors */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA
};

uchar FAT16_SPECIAL_BYTES[3] = {
   /* FAT ID: Same as Media descriptor */
   0xFD, 0xFF, 0xFF
};

extern volatile APP_GLOBAL_STRUCT app_test_struct;
extern void device_main(_usb_device_handle dev_handle);
extern void host_main(_usb_host_handle host_handle);
/* file system routine that formats the disk */
extern void RAM_disk_start();

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : otg_device_startup
* Returned Value : None
* Comments       :
*     Start OTG in device mode.
* 
*END*--------------------------------------------------------------------*/
uint_8  otg_device_startup
   (
      void   
   )
{ /* Body */
   uint_8               error;
   uint_32              state=0;
   
   /* Initialize the USB interface */
   error = _usb_device_init(0, &dev_handle, 4);
   
   if (error != USB_OK) {
      printf("\nUSB Device Initialization failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */
   
   /* This is a Self-Powered Device so set device status to show that. */
   _usb_device_set_status(dev_handle, USB_STATUS_DEVICE, USB_SELF_POWERED);

   error = _usb_device_register_service(dev_handle, USB_SERVICE_EP0, 
      service_ep0);
   
   if (error != USB_OK) {
      printf("\nUSB Device Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   error = _usb_device_register_service(dev_handle, USB_SERVICE_EP1, 
      service_ep1);
   
   if (error != USB_OK) {
      printf("\nUSB Device Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */
   
   error = _usb_device_register_service(dev_handle, USB_SERVICE_BUS_RESET, 
      reset_ep0);
   
   if (error != USB_OK) {
      printf("\nUSB Device Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   error = _usb_device_register_service(dev_handle, USB_SERVICE_RESUME,
      app_process_device_resume);

   if (error != USB_OK) {
      printf("\nUSB Device Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   error = _usb_device_register_service(dev_handle, USB_SERVICE_SPEED_DETECTION, 
      detect_speed);
   
   if (error != USB_OK) {
      printf("\nUSB Device Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */
   
   
   /* we must register for bus suspend interrupt for B or A peripheral devices */
   error =  _usb_device_register_service(dev_handle, USB_SERVICE_SLEEP, bus_suspend);
   if (error != USB_OK) 
   {
         printf("\nUSB Device Service Registration failed. Error: %x", error);
         fflush(stdout);
   } /* Endif */
   
   return error;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : otg_device_shutdown
* Returned Value : None
* Comments       :
*     Start OTG in device shutdown
* 
*END*--------------------------------------------------------------------*/
uint_8  otg_device_shutdown
   (
      void      
   )
{ /* Body */
   
   uint_8               error;

   error = _usb_device_unregister_service(dev_handle, USB_SERVICE_BUS_RESET);
   
   if (error != USB_OK) {
      printf("\nUSB Service Un Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */
   
   error = _usb_device_unregister_service(dev_handle, USB_SERVICE_EP0);
   
   if (error != USB_OK) {
      printf("\nUSB Service un Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   error = _usb_device_unregister_service(dev_handle, USB_SERVICE_EP1);
   
   if (error != USB_OK) {
      printf("\nUSB Service un Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   error = _usb_device_unregister_service(dev_handle, USB_SERVICE_SPEED_DETECTION);

   if (error != USB_OK) {
      printf("\nUSB Device Service un Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   
    /* we must register for bus suspend interrupt for B or A peripheral devices */
   error =  _usb_device_unregister_service(dev_handle, USB_SERVICE_SLEEP);
   if (error != USB_OK) 
   {
         printf("\nUSB Device Service Registration failed. Error: %x", error);
         fflush(stdout);
   } /* Endif */

   
   /* shutdown  the USB interface */
   _usb_device_shutdown(dev_handle);
   
   return error;  
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : otg_host_startup
* Returned Value : None
* Comments       :
*     Start OTG in host mode.
* 
*END*--------------------------------------------------------------------*/
uint_8  otg_host_startup
   (
      void   
   )
{ /* Body */
   
   uint_8               error;

   //error = _usb_host_init(0, 1024, &host_handle);
   error = _usb_host_init(0, 4, &host_handle);
   if (error != USB_OK) {
      printf("\nUSB Host Initialization failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   /*
   ** Since we are going to act as the host driver, register the driver
   ** information for wanted class/subclass/protocols
   */
   error = _usb_host_driver_info_register(host_handle, DriverInfoTable);
   if (error != USB_OK) {
      printf("\nDriver Registration failed. STATUS: %x", error);
      fflush(stdout);
   } /* Endif */

   error = _usb_host_register_service(host_handle, USB_SERVICE_HOST_RESUME, 
      app_process_host_resume);
   
   if (error != USB_OK) {
      printf("\nUSB Host Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */
   
   return error;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : otg_host_shutdown
* Returned Value : None
* Comments       :
*     Shutdown the  OTG in host mode.
* 
*END*--------------------------------------------------------------------*/
uint_8  otg_host_shutdown
   (
      void   
   )
{ /* Body */
   
   uint_8               error;

   error = _usb_host_unregister_service(host_handle, USB_SERVICE_HOST_RESUME);
   
   if (error != USB_OK) {
      printf("\nUSB Service Unregistration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   _usb_host_shutdown(host_handle);
   
   return error;
} /* Endbody */



/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : otg_service
* Returned Value : None
* Comments       :
*     Called upon  OTG service state change.
* 
*END*--------------------------------------------------------------------*/
void otg_service
   (
      /* [IN] Handle of the USB device */
      _usb_otg_handle      handle,
      
      /* [IN] service type */
      uint_32              type
      
   )
{ /* Body */
   uint_8   error;
   uint_32  state;
  
   
   switch (type) {
      case USB_OTG_HOST_UP:
         error = otg_host_startup();
         if (error == USB_OK) {
            _usb_otg_set_status(handle, USB_OTG_HOST_ACTIVE, TRUE);
            _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);
            if (state < B_IDLE) {
               _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_DROP, FALSE);
               if (!app_test_struct.DO_SRP) {
                  _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_REQ, TRUE);
               } /* Endif */
            } /* Endif */
         } /* Endif */
         break;
      case USB_OTG_DEVICE_UP:  
         error = otg_device_startup();
         if (error== USB_OK) {
            _usb_otg_set_status(handle, USB_OTG_DEVICE_ACTIVE, TRUE);
         } /* Endif */
         break;
      case USB_OTG_HOST_DOWN:  
         error = otg_host_shutdown();
         if (error == USB_OK) {
            _usb_otg_set_status(handle, USB_OTG_HOST_ACTIVE, FALSE);
         } /* Endif */
         
         break;
      case USB_OTG_DEVICE_DOWN:
         error = otg_device_shutdown();
         if (error == USB_OK) {
            _usb_otg_set_status(handle, USB_OTG_DEVICE_ACTIVE, FALSE);
         } /* Endif */
         reset_ep0(dev_handle, FALSE, 0, NULL, 0, 0);
         break;
      
      case USB_OTG_SRP_ACTIVE:
         break;
         
      case USB_OTG_SRP_FAIL:
         app_test_struct.SRP_DONE = TRUE;
         break;
         
      case USB_OTG_OVER_CURRENT:
         break;
      
      case USB_OTG_HNP_FAILED:
         app_test_struct.HNP_FAILED = TRUE;
         break;
   
      default:
      break;
   } /* Endswitch */
   return;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : main
* Returned Value : None
* Comments       :
*     First function called. This rouine is just an infinite loop that keeps
* checking the state of OTG and calls individual routines such as host_main
or device_main depending upon the role. Note that customers must take the
proper action dpeneding upon the state of OTG. For example when OTG controller
is in suspend state, customer's embedded application may need to take some
actions such as suspending the hardware. This example program just prints the
state.
*END*--------------------------------------------------------------------*/

#ifdef __USB_OS_MQX__
void Main_Task
   (
      uint_32 param
   )
#else
void main
   (
      void
   )
#endif   

{ /* Body */
   
   uint_8               error;
   USB_OTG_INIT_STRUCT  init;
   volatile uint_32     i = 0;
   uint_32              state=0;
   char                 c;
   uint_32 last_state            = 0xFFFF;
   
   /* default configuration: A will be host B will be peripheral */
   init.A_BUS_DROP = FALSE;
   init.A_BUS_REQ = TRUE;
   init.B_BUS_REQ = FALSE;
   init.SERVICE = otg_service;
   app_test_struct.DO_HNP = FALSE;
   app_test_struct.DO_SRP = FALSE;
   app_test_struct.SRP_DONE = FALSE;
   app_test_struct.DO_NORMAL = TRUE;
   app_test_struct.HNP_FAILED = FALSE;
   
   USB_lock();
#ifdef __USB_OS_MQX__
    _int_install_unexpected_isr(); 
   _usb_driver_install(0, &_bsp_usb_callback_table);
#endif   

   /*Do the necessary time consuming preperation to respond like a device 
   we do all memory allocation for device in advance because 
   under OTG switch role, it can consume lot of CPU time and
   fail OPT complaince.*/   
   error = initialize_device();

   MASS_STORAGE_DISK =  (uchar_ptr) \
                        USB_memalloc(TOTAL_LOGICAL_ADDRESS_BLOCKS*LENGTH_OF_EACH_LAB);
   if(MASS_STORAGE_DISK == NULL)
   {
     printf("memory allocation failed \n");
     fflush(stdout);
     exit(1); 
   }
   memset(MASS_STORAGE_DISK, 0, 
      (TOTAL_LOGICAL_ADDRESS_BLOCKS*LENGTH_OF_EACH_LAB));
   /* Format the "disk" */      
   memcpy(MASS_STORAGE_DISK, BOOT_SECTOR_AREA, 512);
   memcpy(MASS_STORAGE_DISK + 512, FAT16_SPECIAL_BYTES, 3);
   memcpy(MASS_STORAGE_DISK + 512*4, FAT16_SPECIAL_BYTES, 3);
   #ifdef _DATA_CACHE_
   USB_dcache_flush_mlines
         (MASS_STORAGE_DISK,
         (TOTAL_LOGICAL_ADDRESS_BLOCKS*LENGTH_OF_EACH_LAB)
         );    
   #endif
#ifdef __USB_OS_MQX__
   #ifdef   HOSTLINK_IO
      c = getchar();
#endif
#endif   

   /* Initialize the USB interface */
   error = _usb_otg_init(0, &init, &app_otg_handle);
   if (error != USB_OK) {
      printf("\nUSB OTG Initialization failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */
   USB_unlock();
   
   while (TRUE) {
      _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);

      if ((state == A_HOST) || (state == B_HOST)) {

         if((last_state != A_HOST) && (last_state != B_HOST))
         {
            printf("HOST\n");
         }

         host_main(host_handle);
      }

      if ((state == A_PERIPHERAL) || (state == B_PERIPHERAL)) {

         if((last_state != A_PERIPHERAL) && (last_state != B_PERIPHERAL))
         {
            printf("PERIPHERAL\n");
         }
         
         if(app_test_struct.HNP_FAILED)
         {
            printf("HNP failed ...device not responding or not connected\n");
            app_test_struct.HNP_FAILED = FALSE;
         }

         device_main(dev_handle);
      }

      if (state == B_SRP_INIT) 
      {
         
         if(last_state != B_SRP_INIT)
         {
            printf("B_SRP_INIT\n");
         }
  
        }

      if (state == B_IDLE) 
      {
         
                
         if (app_test_struct.SRP_DONE) 
         {
            printf("Device not connected ..SRP attempt failed....\n");
            printf("Returning back to B_IDLE....\n");
            
            app_test_struct.SRP_DONE = FALSE;
         }

      /*only with OS support we have a non blocking input 
      so there is no need to printf again and again but when
      no RTOS is available, we use getchar() and block. In
      this case, we should do printf with every iteration*/   
      #ifdef __USB_OS_MQX__
         if(last_state != B_IDLE)
      #endif         
         {
            printf("B_IDLE\n");
            printf("B_IDLE:  Press 's' to generate SRP.\n");
            SUSPEND_ATTEMPTED = FALSE;
            RESUME_RECEIVED = FALSE;
            
         }
         /*if key pressed check for the character */
         if(status())
         {
            c = getchar();
            if ((c == 's') || (c == 'S')) 
            {
               printf("'s' pressed:  Generating SRP!\n");
               _usb_otg_set_status(app_otg_handle, USB_OTG_B_BUS_REQ, TRUE);
            }
            else
            {
               last_state = 0xFFFF;
            }
         }
      }
      if (state == B_WAIT_ACON) {
          
          if(last_state != B_WAIT_ACON)
            {
               printf("B_WAIT_ACON\n");
               SUSPEND_ATTEMPTED = FALSE;
               RESUME_RECEIVED = FALSE;

            }
      }

      if (state == A_IDLE) {

        #ifdef __USB_OS_MQX__
         if(last_state != A_IDLE)
        #endif 
         {
            printf("A_IDLE\n");
            printf("A_IDLE:  Press 'v' to turn on VBus.\n");
            SUSPEND_ATTEMPTED = FALSE;
            RESUME_RECEIVED = FALSE;

         }
         if(status())
         {
            c = getchar();
            if ((c == 'v') || (c == 'V')) 
            {
               printf("'v' pressed:  Turning on VBus\n");
               _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_REQ, TRUE);
            }
            else
            {
               last_state = 0xFFFF;
            }
          }

      }

      if (state == A_WAIT_VRISE) {

            if(last_state != A_WAIT_VRISE)
            {
               printf("A_WAIT_VRISE\n");
            }
      }

      if (state == A_WAIT_BCON) 
      {
             if(last_state != A_WAIT_BCON)
            {
               printf("A_WAIT_BCON\n");
               SUSPEND_ATTEMPTED = FALSE;
               RESUME_RECEIVED = FALSE;            }
      }

      if (state == A_SUSPEND) 
      {
             if(last_state != A_SUSPEND)
            {
               printf("A_SUSPEND\n");
            }
      }

      if (state == A_WAIT_VFALL) 
      {
      
            if(last_state != A_WAIT_VFALL)
            {
               printf("A_WAIT_VFALL\n");
            }

            if (last_state == A_WAIT_BCON) {
               printf("Device not connected or not responding\n");
            } /* Endif */
      }

            
      fflush(stdout);
      last_state = state;

    } /* Endwhile */
} /* Endbody */
/* EOF */
