/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains the host specific code for the demo
***
**************************************************************************
**END*********************************************************/

/**************************************************************************
Include the OS and BSP dependent files that define IO functions and
basic types. You may like to change these files for your board and RTOS 
**************************************************************************/
#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
   #include "bsp.h"
   #include "fio.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif
#include "stdlib.h"
#include "string.h"
#endif

/**************************************************************************
Include the USB stack header files.
**************************************************************************/

#ifdef __USB_OTG__
#include "otgapi.h"
#else
#include "hostapi.h"
#include "devapi.h"
#endif

/**************************************************************************
Local header files for this application
**************************************************************************/
#include "demo.h"
#include "demo_d.h"
#include "demo_h.h"


/**************************************************************************
   Global variables
**************************************************************************/
volatile DEVICE_STRUCT        device = { 0 }; /* device struct  */
volatile APP_GLOBAL_STRUCT    app_test_struct;

extern _usb_otg_handle        app_otg_handle;
extern _usb_device_handle     dev_handle;
_usb_pipe_handle              bulk_out_pipe_handle;
_usb_pipe_handle              bulk_in_pipe_handle;
uchar                         BULK_BUFFER[1000];




/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : app_process_host_resume
* Returned Value :
* Comments       :
*     Callback function to process the remote-wakeup/K-Attach event
*
*END*--------------------------------------------------------------------*/
void app_process_host_resume
   (
      _usb_host_handle  handle,
      uint_32           length
   )
{ /* Body */
   uint_32  state;

   _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);

   if (state < B_IDLE) {
      _usb_otg_set_status(app_otg_handle, USB_OTG_B_BUS_RESUME, TRUE);
   } else {
      _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_RESUME, TRUE);
   } /* Endif */

} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : app_process_HNP
* Returned Value :
* Comments       :
*     function to process the HNP request. This routine is called when
* Host wants to do an HNP. The procedure to do HNP is as follows.

1) Find whether device supports HNP or not from its config descriptor
2) Send a USB set feature command to do HNP

If command fails suspend the bus because Host does not know what to do now.
This is required behaviour from OTG compliance (run OPT tester to check this)

If command succeeds move to peripheral state by controlling the OTG
parameters (see OTG state machine diagram)
*
*END*--------------------------------------------------------------------*/
void app_process_HNP
   (
      _usb_host_handle  handle
   )
{ /* Body */
   uint_32                       state, i, total_len, error;
   boolean                       otg_des_found = FALSE;
   boolean                       hnp_capability = FALSE;


   _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);

   app_test_struct.TRANSACTION_COMPLETE = FALSE;

   /*******************************************************************
      Check if this device supports HNP or not
   *******************************************************************/

   /* Get the configuration descriptor */
   error = _usb_hostdev_get_descriptor((pointer)device.DEV_HANDLE,
         DESCTYPE_CONFIG, 0, 0,
         (pointer)&app_test_struct.RX_CONFIG_DESC);

   app_test_struct.TRANSACTION_COMPLETE = FALSE;

   /* Find out the length of the transfer */
   total_len = app_test_struct.RX_CONFIG_DESC[2];
   total_len |= app_test_struct.RX_CONFIG_DESC[3] << 8;
   for (i=0;i < total_len;)
   {
      /* checking for OTG descriptor type */
      if (app_test_struct.RX_CONFIG_DESC[i+1] ==
         USB_OTG_DESCRIPTOR_TYPE)
      {
         otg_des_found = TRUE;
         break;
      } else {
         i = i + app_test_struct.RX_CONFIG_DESC[i];
      } /* Endif */
   } /* Endfor */

    /* Check if HNP enabled for device */
   if ((otg_des_found) && ((app_test_struct.RX_CONFIG_DESC[i+2]) & 0x02))
   {

      hnp_capability  = TRUE;
   }

   /*******************************************************************
   ACTION 1 (if device supports HNP do it)
   *******************************************************************/

   if ((state < B_IDLE) && hnp_capability)
   {
      printf("Device supports HNP\n");
      printf("Attempting to set HNP enable ....\n");
      app_test_struct.TRANSACTION_STATUS = USB_OK;

      error = _usb_host_register_ch9_callback(device.DEV_HANDLE,
                                             app_process_pipe_transaction_done,
                                             device.INTF_HANDLE);

      _usb_host_ch9_set_feature(device.DEV_HANDLE,0,0,3);

      /*wait till the request completes */
      while (!app_test_struct.TRANSACTION_COMPLETE) {
         /* Wait until transaction is complete */
   
         if(device.STATE == USB_DEVICE_DETACHED)
         {
            printf("device gone returning\n");
            return;
         }
      }
            
      if(app_test_struct.TRANSACTION_STATUS == USB_OK)
      {
         printf("HNP enable successful with device\n");
         _usb_otg_set_status(app_otg_handle, USB_OTG_A_SET_B_HNP_ENABLE, TRUE);
         _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_SUSPEND_REQ, TRUE);
         _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_REQ, FALSE);
      }
      else
      {
         printf("HNP enable failed with device...suspending the bus\n");
         /* CALL the Host API function to suspend the bus */
         _usb_host_bus_control(handle, USB_SUSPEND_SOF);


      }

   }

   /*******************************************************************
   ACTION 2 (if device does not supports HNP just suspend the bus)
   *******************************************************************/

   else if (state < B_IDLE)
   {
         printf("Device does not supports HNP\n");
         printf("Suspending the bus ....\n");

         /* OPT tester expects that if we don't support the device
         we should suspend the bus. Test 4.10. It should not be done
         normally because test 4.1 documentation does not say this
         but test program makes it necessary to do this to pass the test.
         If this is done in a normal program, we have problem in reattaching
         the device.*/
         /* CALL the Host API function to suspend the bus */
         _usb_host_bus_control(handle, USB_SUSPEND_SOF);

   }

   /*******************************************************************
   ACTION 3 (we were in B_HOST so just release the host control)
   *******************************************************************/

   else //case when we are in B_HOST
   {
       printf("Releasing Host control....\n");
       /* CALL the Host API function to suspend the bus */
       _usb_host_bus_control(handle, USB_SUSPEND_SOF);

   }

}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : app_process_pipe_transaction_done
* Returned Value :
* Comments       :
*     Callback function to process the transaction done event.
* This routine is registered when sending a control pipe request.
*
*END*--------------------------------------------------------------------*/
void app_process_pipe_transaction_done
   (
      /* [IN] pointer to pipe */
      _usb_pipe_handle  pipe_handle,

      /* [IN] user-defined parameter */
      pointer           user_parm,

      /* [IN] buffer address */
      uchar_ptr         buffer,

      /* [IN] length of data transferred */
      uint_32           length_data_transfered,

      /* [IN] status, hopefully USB_OK or USB_DONE */
      uint_32           status
   )
{ /* Body */
   app_test_struct.TRANSACTION_COMPLETE = TRUE;
   app_test_struct.TRANSACTION_STATUS = status;
} /* EndBody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_device_event
* Returned Value : None
* Comments       :
*     called when non storage device has been attached, detached, etc.
* Note that this example supports only storage devices and hence it sets
device.SUPPORTED to FALSE when a non storage device is attached.
*END*--------------------------------------------------------------------*/
void usb_host_device_event
   (
      /* [IN] pointer to device instance */
      _usb_device_instance_handle      dev_handle,

      /* [IN] pointer to interface descriptor */
      _usb_interface_descriptor_handle intf_handle,

      /* [IN] code number for event causing callback */
      uint_32           event_code
   )
{
   INTERFACE_DESCRIPTOR_PTR   intf_ptr =
      (INTERFACE_DESCRIPTOR_PTR)intf_handle;

   switch (event_code) {
      case USB_CONFIG_EVENT:
         /* Drop through into attach, same processing */
      case USB_ATTACH_EVENT:
         if (device.STATE == USB_DEVICE_IDLE ||
            device.STATE == USB_DEVICE_DETACHED)
         {
            device.DEV_HANDLE = dev_handle;
            device.INTF_HANDLE = intf_handle;

            #if 0
               _usb_host_ch9_set_interface(device.DEV_HANDLE, 0, 0);
            #endif
            device.STATE = USB_DEVICE_ATTACHED;
         } /* EndIf */
         break;
      case USB_INTF_EVENT:
         device.STATE = USB_DEVICE_INTERFACED;
         break;
      case USB_DETACH_EVENT:
         device.STATE = USB_DEVICE_DETACHED;
         /*************************************************************************
         When we are exiting the HOST state because of a detach, we should
         reset the device state.
         _usb_host_cancel_transfer(dev_handle, bulk_in_pipe_handle, 0);
         _usb_host_cancel_transfer(dev_handle, bulk_out_pipe_handle, 0);
         *************************************************************************/
         device.DEV_HANDLE = NULL;
         device.INTF_HANDLE = NULL;
         device.STATE = USB_DEVICE_IDLE;
         
         break;
      default:
         device.STATE = USB_DEVICE_IDLE;
         break;
   } /* EndSwitch */

} /* Enbbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : host_main
* Returned Value :
* Comments       :
*     The Main function to handle HOST function of OTG example code.
*END*--------------------------------------------------------------------*/
void host_main
   (
      _usb_host_handle  handle
   )
{
   uint_32                       state = 0;
   USB_STATUS                    status;
   char                          c;
   uint_32 last_state            = 0xFFFF;
   TR_INIT_PARAM_STRUCT          tr_to_bulk_out = {0};
   TR_INIT_PARAM_STRUCT          tr_to_bulk_in  = {0};



   _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);

   /*************************************************************************
   Once the OTG application enters the host state, it loops through a busy
   while loop checking for the state change. If state does not remain
   as Host, it returns the control back to OTG main loop (see file demo.c)
   *************************************************************************/
   
   while ((state == A_HOST) | (state == B_HOST)) 
   {
      /*************************************************************************
      Keep taking action based on the event that ocsured      .
      *************************************************************************/

      switch ( device.STATE ) 
      {
            case USB_DEVICE_IDLE:
               break ;
            case USB_DEVICE_ATTACHED:
            /*************************************************************************
            If an attach has occured and device is supported, 
            select the interface, on the device now.
            *************************************************************************/
            status = _usb_hostdev_select_interface(device.DEV_HANDLE,
                        device.INTF_HANDLE, (pointer)&device.CLASS_INTF);
         
            if (status != USB_OK) 
            {
               printf("\nError in _usb_hostdev_select_interface: %x", status);
               fflush(stdout);
            }
            
            bulk_in_pipe_handle =
                         _usb_hostdev_find_pipe_handle(device.DEV_HANDLE, 
                           device.INTF_HANDLE, USB_BULK_PIPE, USB_RECV);

            bulk_out_pipe_handle =
                         _usb_hostdev_find_pipe_handle(device.DEV_HANDLE, 
                           device.INTF_HANDLE, USB_BULK_PIPE, USB_SEND);
            
            if((bulk_in_pipe_handle) && (bulk_out_pipe_handle))
            {
               device.STATE = USB_DEVICE_INTERFACED;
               printf("\nThis test will queue a buffer on BULK IN and send same data back");
               fflush(stdout);
            }
            else
            {
               printf("Unable to obtain pipe handles\n");
            }
                     
            break ;
         case USB_DEVICE_INTERFACED:
   
            /******************************************************************
                RECV
            ******************************************************************/
   
            app_test_struct.TRANSACTION_COMPLETE = FALSE;

            usb_hostdev_tr_init(&tr_to_bulk_in, app_process_pipe_transaction_done, NULL);
            tr_to_bulk_in.RX_BUFFER = (uchar_ptr)BULK_BUFFER;
            
            #ifdef __VUSBHS__
               tr_to_bulk_in.RX_LENGTH  = EP1_HS_MAX_PACKET_SIZE;
            #else
               tr_to_bulk_in.RX_LENGTH  = EP1_FS_MAX_PACKET_SIZE;
            #endif
            
            status = _usb_host_recv_data(handle, bulk_in_pipe_handle, &tr_to_bulk_in);

            if (status != USB_STATUS_TRANSFER_QUEUED) 
            {
                  printf("\nError in _usb_host_receive_data: %x", status);
                  fflush(stdout);
            }
            
            
            while(!app_test_struct.TRANSACTION_COMPLETE)
            {
               if (device.STATE != USB_DEVICE_INTERFACED) 
               {
                  return;
               }
            }

            printf(".");

            /******************************************************************
                SEND
            ******************************************************************/
            
            app_test_struct.TRANSACTION_COMPLETE = FALSE;

            usb_hostdev_tr_init(&tr_to_bulk_out, app_process_pipe_transaction_done, NULL);
            tr_to_bulk_out.TX_BUFFER = (uchar_ptr)BULK_BUFFER;
            #ifdef __VUSBHS__
               tr_to_bulk_out.TX_LENGTH  = EP1_HS_MAX_PACKET_SIZE;
            #else
               tr_to_bulk_out.TX_LENGTH  = EP1_FS_MAX_PACKET_SIZE;
            #endif


            status = _usb_host_send_data(handle, bulk_out_pipe_handle, &tr_to_bulk_out);

            if (status != USB_STATUS_TRANSFER_QUEUED) 
            {
                  printf("\nError in _usb_host_send_data: %x", status);
                  fflush(stdout);
            }
            
            
            while(!app_test_struct.TRANSACTION_COMPLETE)
            {
               if (device.STATE != USB_DEVICE_INTERFACED) 
               {
                  return;
               }
            }
            
            printf("x");
            
            fflush(stdout);
               
            break;

         case USB_DEVICE_DETACHED:
               _usb_host_cancel_transfer(handle, bulk_in_pipe_handle, 0);
               _usb_host_cancel_transfer(handle, bulk_out_pipe_handle, 0);

               device.DEV_HANDLE = NULL;
               device.INTF_HANDLE = NULL;
               device.STATE = USB_DEVICE_IDLE;
         break;

      }

      /*************************************************************************
      Keep checking the state of the OTG state machine
      *************************************************************************/

      _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);
   
   } /* Endwhile */

   
} /* Endbody */

/* EOF */
