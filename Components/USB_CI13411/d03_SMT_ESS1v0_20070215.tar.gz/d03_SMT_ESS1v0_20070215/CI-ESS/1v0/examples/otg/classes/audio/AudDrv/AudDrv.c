/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file is an example of device drivers for the audio class.
***
**************************************************************************
**END*********************************************************/

#include "usb_audio.h"
#include "AudDrv.h"

#ifdef __USB_OS_MQX__
#include "bsp.h"
#include "mqx_arc.h"
#include "fio.h"
#include <timer.h>
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif
#include "stdlib.h"
#endif


/***************************************
**
** Globals
*/

/* Table of driver capabilities this application wants to use */
static  USB_HOST_DRIVER_INFO DriverInfoTable[] =
{
   {
      {0x00,0x00},                  /* Vendor ID per USB-IF             */
      {0x00,0x00},                  /* Product ID per manufacturer      */
      USB_CLASS_AUDIO,              /* Class code                       */
      USB_SUBCLASS_AUD_CONTROL,     /* Sub-Class code                   */
      USB_PROTOCOL_UNDEFINED,       /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_aud_device_event     /* Application call back function   */
   },
   {
      {0x00,0x00},                  /* Vendor ID per USB-IF             */
      {0x00,0x00},                  /* Product ID per manufacturer      */
      USB_CLASS_AUDIO,              /* Class code                       */
      USB_SUBCLASS_AUD_STREAMING,   /* Sub-Class code                   */
      USB_PROTOCOL_UNDEFINED,       /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_aud_device_event     /* Application call back function   */
   },
   {
      {0x00,0x00},                  /* Vendor ID per USB-IF             */
      {0x00,0x00},                  /* Product ID per manufacturer      */
      USB_CLASS_AUDIO,              /* Class code                       */
      USB_SUBCLASS_AUD_MIDI_STRM,   /* Sub-Class code                   */
      USB_PROTOCOL_UNDEFINED,       /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_aud_device_event     /* Application call back function   */
   },
   {
      {0x00,0x00},                  /* All-zero entry terminates        */
      {0x00,0x00},                  /*    driver info list.             */
      0,
      0,
      0,
      0,
      NULL
   }
   
};

volatile DEVICE_STRUCT  aud_device = { 0 };
uchar_ptr               aud_buf = 0;
extern uchar            ucLaser48k[];
extern uint_32          dwSamplesPerSec;

#ifdef __USB_OS_MQX__
#define MAIN_TASK          (10)
extern void Main_Task(uint_32 param);
TASK_TEMPLATE_STRUCT  MQX_template_list[] =
{
   { MAIN_TASK,      Main_Task,      3000L,  7L, "Main",      MQX_AUTO_START_TASK},
   { 0L,             0L,             0L,     0L, 0L,          0L }
};
#endif

static void usb_host_aud_ctrl_callback(uint_32, pointer, uint_32, uint_32);
static void usb_host_aud_data_callback(uint_32, pointer, uint_32, uint_32);
static void usb_host_aud_cleanup(void);
static uint_32 usb_host_aud_init(void);
static uint_32 usb_host_aud_get_class_intf_ctlr(uint_8,uint_8,uint_8,uint_8,uint_8,uint_16,uchar_ptr);
static uint_32 usb_host_aud_set_class_intf_ctlr(uint_8,uint_8,uint_8,uint_8,uint_8,uint_16,uchar_ptr);
static uint_32 usb_host_aud_set_class_ep_ctlr(uint_8,uint_8,uint_8,uint_16,uchar_ptr);
static uint_32 usb_host_get_sample_freq(void);
static uint_8 usb_host_is_creative_extigy(void);
static uint_32 usb_host_get_as_alt_from_sampfreq(uint_32, uint_32);
static uint_32 usb_host_get_max_samp_freq(uint_32);
static uint_32 usb_host_get_max_min_volume(uint_8);            

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : main (Main_Task if using MQX)
* Returned Value : none
* Comments       :
*     Execution starts here
*
*END*--------------------------------------------------------------------*/

#ifdef __USB_OS_MQX__
void Main_Task ( uint_32 param )
#else
void main (void)
#endif

{ /* Body */
   USB_STATUS           status = USB_OK;
   USB_OTG_INIT_STRUCT  otg_init;
   _usb_otg_handle      otg_handle1;
   uint_32              dwAlt;
   uint_16              wTmp;
   uchar_ptr            wav_buf;
   uint_32              dwSize, dwSampFreq;
   char                 ch;
   
   /* default configuration: A = host, B = peripheral */
   otg_init.A_BUS_DROP  = FALSE;
   otg_init.A_BUS_REQ   = TRUE;
   otg_init.B_BUS_REQ   = FALSE;
   otg_init.SERVICE     = otg_service;

   /* _usb_otg_init needs to be done with interrupts disabled */
   _disable_interrupts();

#ifdef __USB_OS_MQX__
   _int_install_unexpected_isr();
   _usb_driver_install(0, &_bsp_usb_callback_table);
#endif

   /*
   ** Initialize the USB interface, causing a call back to the otg_service
   ** routine
   */
   status = _usb_otg_init(0, &otg_init, &otg_handle1);
   if (status != USB_OK) {
      printf("\nUSB OTG Initialization failed. Error Status: %x", status);
      fflush(stdout);
   } /* Endif */

   _enable_interrupts();

   /*
   ** Infinite loop, waiting for events requiring action
   */
   for ( ; ; ) {
      switch ( aud_device.DEV_STATE ) {
         case USB_DEVICE_IDLE:
            break;
         case USB_DEVICE_ATTACHED:
            if (!aud_device.DEV_HANDLE ||
                !aud_device.INTF_HANDLE_AC ||
                !aud_device.AudStream[0].ALT_NUM_AS ) { /* Body */
                usb_host_aud_cleanup();
               printf("Device is not a USB audio class device!\n");
               fflush(stdout);
               return;
            } /* Endbody */
            
            usb_host_get_sample_freq();
            
            aud_device.bIsExitigyDevice = usb_host_is_creative_extigy();
            
            aud_device.bPlayMode = '1';
            if (aud_device.bIsExitigyDevice) { 
               printf("\nPlease select play mode:\n");
               printf("1: Record & Playback\n2: Record only\n3: Playback only\n");
               ch = getchar();
               fflush(stdin);
               if (ch == '1' || ch == '2' || ch == '3')
                  aud_device.bPlayMode = ch;
            } 
                        
            status = _usb_hostdev_select_interface(aud_device.DEV_HANDLE,
                  aud_device.INTF_HANDLE_AC, (pointer)&aud_device.CLASS_INTF);
            if (status != USB_OK) {
               fflush(stdout); 
               printf("Select audio control interface failed!\n");
               fflush(stdout);
            }                
            
            printf("DEV_STATE: from %d to ", aud_device.DEV_STATE);
            fflush(stdout);
            aud_device.DEV_STATE = USB_DEVICE_SET_INTERFACE_STARTED;
            printf("%d.\n", aud_device.DEV_STATE);
            fflush(stdout);
            break;
            
        case USB_DEVICE_SET_INTERFACE_STARTED:
            /*
             * Select interface for the first audio stream with a maximum sample frequency
             */
            if (aud_device.AudStream[0].ALT_NUM_AS <= 0) { /* Body */
               printf("Error: no alternate setting for audio streaming interface 1.\n");
               fflush(stdout);
               return;
            } /* Endbody */
            
            aud_device.CurSampFreq = usb_host_get_max_samp_freq(0);
            if (aud_device.CurSampFreq == 0) { /* Body */
               printf("Error: maximum sample frequency for audio stream 1 is zero!\n");
               fflush(stdout);
               return;
            } /* Endbody */
            dwAlt = usb_host_get_as_alt_from_sampfreq(0, aud_device.CurSampFreq);
            if (dwAlt == 0) { /* Body */
               printf("Error: no alternate setting for audio streaming 1 with sample frequency = %d.\n", 
                     aud_device.CurSampFreq);
               fflush(stdout);
               return;
            } /* Endbody */                                     
                        
            status = _usb_hostdev_select_interface(aud_device.DEV_HANDLE,
                  aud_device.AudStream[0].INTF_HANDLE_AS[dwAlt], (pointer)&aud_device.CLASS_INTF);
            if (status != USB_OK) {
               fflush(stdout); 
               printf("Select #1 audio streaming interface failed!\n");
               fflush(stdout);
            }
            
            status = usb_audio_get_max_data_packet_size((CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF, 
               AUD_DIRECTION_IN, &wTmp);
            if (status == AUD_OK) { /* Body */
               // This an ISO In pipe. Record its max packet size and direction
               aud_device.AudStream[0].bAudDirection = AUD_DIRECTION_IN; 
               printf("Audio Stream #1 is an ISO IN pipe with Max packet size of 0x%x.\n", wTmp);
               fflush(stdout);
            } else { /* Body */
               status = usb_audio_get_max_data_packet_size((CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF, 
               AUD_DIRECTION_OUT, &wTmp);
               if (status == AUD_OK) { /* Body */
                  // This an ISO Out pipe. Record its max packet size and direction
                  aud_device.AudStream[0].bAudDirection = AUD_DIRECTION_OUT; 
                  printf("Audio Stream #1 is an ISO OUT pipe with Max packet size of 0x%x.\n", wTmp);
                  fflush(stdout);
               } else { /* Body */
                  printf("Error: failed to get max packet size for #1 audio stream.\n");
                  fflush(stdout);
               } /* Endbody */
            } /* Endbody */
            printf("DEV_STATE: from %d to ", aud_device.DEV_STATE);
            fflush(stdout);
            aud_device.DEV_STATE = USB_DEVICE_SET_INTERFACE_END;
            printf("%d.\n", aud_device.DEV_STATE);
            fflush(stdout);
            break;
       
        case USB_DEVICE_SET_INTERFACE_END:
            /*
             * If there is a second Audio Stream interface, select an interface with sample frequency
             * same as audio stream 1.
             */
            if (aud_device.AudStream[1].ALT_NUM_AS) { /* Body */
               dwAlt = usb_host_get_as_alt_from_sampfreq(1, aud_device.CurSampFreq);
               if (dwAlt == 0) { /* Body */
                  printf("Error: no alternate setting for audio streaming 2 with sample frequency = %d.\n", 
                         aud_device.CurSampFreq);
                  fflush(stdout);
                  return;
               } /* Endbody */
                   
               status = _usb_hostdev_select_interface(aud_device.DEV_HANDLE,
                     aud_device.AudStream[1].INTF_HANDLE_AS[dwAlt], (pointer)&aud_device.CLASS_INTF);
               if (status != USB_OK) {
                  fflush(stdout); 
                  printf("Select #2 audio streaming interface failed!\n");
                  fflush(stdout);
               }
               
               if (aud_device.AudStream[0].bAudDirection == AUD_DIRECTION_IN) { /* Body */
                  // Since #1 audio stream is ISO IN, we expect #2 is ISO OUT
                  status = usb_audio_get_max_data_packet_size((CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF, 
                     AUD_DIRECTION_OUT, &wTmp);
                  if (status == AUD_OK) { /* Body */
                     // This an ISO OUT pipe. Record its max packet size and direction
                     aud_device.AudStream[1].bAudDirection = AUD_DIRECTION_OUT; 
                     printf("Audio Stream #2 is an ISO OUT pipe with Max packet size of 0x%x.\n", wTmp);
                     fflush(stdout);
                  } 
               } else { /* Body */
                  // Otherwise, expect #2 audio stream is ISO IN
                  status = usb_audio_get_max_data_packet_size((CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF, 
                     AUD_DIRECTION_IN, &wTmp);
                  if (status == AUD_OK) { /* Body */
                     // This an ISO IN pipe. Record its max packet size and direction
                     aud_device.AudStream[1].bAudDirection = AUD_DIRECTION_IN; 
                     printf("Audio Stream #2 is an ISO IN pipe with Max packet size of 0x%x.\n", wTmp);
                     fflush(stdout);
                  } 
               } /* Endbody */
               if (status != AUD_OK) { /* Body */
                  printf("Error: failed to get max packet size for #2 audio stream.\n");
                  fflush(stdout);
                  aud_device.AudStream[1].bAudDirection = AUD_DIRECTION_NONE;
               }             
            } else { /* Body */
               aud_device.AudStream[1].bAudDirection = AUD_DIRECTION_NONE;
            } /* Endbody */
            
            printf("DEV_STATE: from %d to ", aud_device.DEV_STATE);
            aud_device.DEV_STATE = USB_DEVICE_INTERFACED;
            printf("%d.\n", aud_device.DEV_STATE);
            fflush(stdout);
            break;
         case USB_DEVICE_INTERFACED:
            
            printf("aud_device.DEV_STATE = USB_DEVICE_INTERFACED.\n");
            fflush(stdout);
            
            usb_host_aud_init();
            if (aud_device.bIsExitigyDevice) { /* Body */
               usb_host_aud_init_extigy();
               if (aud_device.bPlayMode == '2') { // Record Only
                  usb_host_aud_record_setup(1, aud_device.CurSampFreq);
                  usb_host_aud_record(aud_buf, AUD_RECORD_BUF_SIZE);
               } else if (aud_device.bPlayMode == '3') { // Playback Only
                  dwSampFreq = dwSamplesPerSec;
                  usb_host_aud_playback_setup(0, dwSampFreq);
                  for (wTmp=0; wTmp<16; wTmp++)
                     usb_host_aud_playback(ucLaser48k, AUD_WAV_STREAM_SIZE);
               }
            } 
            if (aud_device.bPlayMode == '1') {
               // Try to record first
               wTmp = 0;
               if (aud_device.AudStream[0].ALT_NUM_AS && 
                   aud_device.AudStream[0].bAudDirection == AUD_DIRECTION_IN) { 
                   wTmp = 1;
                   usb_host_aud_record_setup(0, aud_device.CurSampFreq);
                   usb_host_aud_record(aud_buf, AUD_RECORD_BUF_SIZE);
               } else if (aud_device.AudStream[1].ALT_NUM_AS && 
                   aud_device.AudStream[1].bAudDirection == AUD_DIRECTION_IN) {
                   wTmp = 1;
                   usb_host_aud_record_setup(1, aud_device.CurSampFreq);
                   usb_host_aud_record(aud_buf, AUD_RECORD_BUF_SIZE);
               }                                     
            
               // Playback
               if (wTmp == 1) { /* Body */
                  wav_buf = aud_buf;
                  dwSize = AUD_RECORD_BUF_SIZE;
                  dwSampFreq = aud_device.CurSampFreq;
               } else { /* Body */
                  wav_buf = ucLaser48k;
                  dwSize = AUD_WAV_STREAM_SIZE;
                  dwSampFreq = dwSamplesPerSec;
               } /* Endbody */              
               if (aud_device.AudStream[0].ALT_NUM_AS && 
                   aud_device.AudStream[0].bAudDirection == AUD_DIRECTION_OUT) { /* Body */
                   usb_host_aud_playback_setup(0, dwSampFreq);
                   usb_host_aud_playback(wav_buf, dwSize);
               } else if (aud_device.AudStream[1].ALT_NUM_AS && 
                   aud_device.AudStream[1].bAudDirection == AUD_DIRECTION_OUT) {
                   usb_host_aud_playback_setup(1, dwSampFreq);
                   usb_host_aud_playback(wav_buf, dwSize);
               }
            } 
                        
            aud_device.DEV_STATE = USB_DEVICE_OTHER;   
            
            break;
         case USB_DEVICE_DETACHED:
            usb_host_aud_cleanup();
            printf("Device detached.\n");
            fflush(stdout);
            aud_device.DEV_STATE = USB_DEVICE_IDLE;
            break;
         case USB_DEVICE_OTHER:
            break;
         default:
            printf("Unknown Device State = %d\n", aud_device.DEV_STATE);
            fflush(stdout);
            break;
      } /* Endswitch */
   } /* Endfor */
   
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : otg_service
* Returned Value : None
* Comments       :
*     Called upon OTG service state change.
*
*END*--------------------------------------------------------------------*/
static void otg_service
   (
      /* [IN] Handle to make OTG calls*/
      _usb_otg_handle    otg_handle,

      /* event on the OTG stack       */
      uint_32            event
   )
{ /* Body */
   uint_32              state;
   USB_STATUS           status = USB_OK;
   _usb_host_handle     host_handle;

   switch (event) {
      case USB_OTG_HOST_UP:

         /*
         ** It means that we are going to act like host, so we initialize the
         ** host stack. This call will allow USB system to allocate memory for
         ** data structures, it uses later (e.g pipes etc.).
         */
         status = _usb_host_init
            (HOST_CONTROLLER_NUMBER,   /* Use value in header file */
             MAX_FRAME_SIZE,            /* Frame size per USB spec  */
             &host_handle);             /* Returned pointer */

         if (status != USB_OK) {
            printf("\nUSB Host Initialization failed. STATUS: %x", status);
            fflush(stdout);
            return;
         } /* Endif */

         /*
         ** since we are going to act as the host driver, register the driver
         ** information for wanted class/subclass/protocols
         */
         status = _usb_host_driver_info_register
            (host_handle,
             DriverInfoTable);
         if (status != USB_OK) {
            printf("\nDriver Registration failed. STATUS: %x", status);
            fflush(stdout);
            return;
         } else {
            /* Success, set OTG state to active */
            _usb_otg_set_status(otg_handle, USB_OTG_HOST_ACTIVE, TRUE);
            _usb_otg_get_status(otg_handle, USB_OTG_STATE, &state);
            if (state < B_IDLE) {
               _usb_otg_set_status(otg_handle, USB_OTG_A_BUS_DROP, FALSE);
               _usb_otg_set_status(otg_handle, USB_OTG_A_BUS_REQ, TRUE);
            } /* Endif */
         } /* Endif */
         
         break;
      case USB_OTG_DEVICE_UP:
         break;
      case USB_OTG_HOST_DOWN:
         usb_host_aud_cleanup();
         break;
      case USB_OTG_DEVICE_DOWN:
         break;
      case USB_OTG_SRP_ACTIVE:
         break;
      case USB_OTG_SRP_FAIL:
         break;
      case USB_OTG_OVER_CURRENT:
         break;
      default:
         break;
   } /* Endswitch */
   return;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_device_event
* Returned Value : None
* Comments       :
*     Called when audio device has been attached, detached, etc.
*END*--------------------------------------------------------------------*/
static void usb_host_aud_device_event
   (
      /* [IN] pointer to device instance */
      _usb_device_instance_handle      dev_handle,

      /* [IN] pointer to interface descriptor */
      _usb_interface_descriptor_handle intf_handle,

      /* [IN] code number for event causing callback */
      uint_32           event_code
   )
{ /* Body */
   INTERFACE_DESCRIPTOR_PTR   intf_ptr =
      (INTERFACE_DESCRIPTOR_PTR)intf_handle;
   uint_8      i;

   fflush(stdout);
   switch (event_code) {
      case USB_CONFIG_EVENT:
         /* Drop through into attach, same processing */
      case USB_ATTACH_EVENT:
         //printf("Attach Event: State = %d intf_handle=0x%x\n", aud_device.DEV_STATE, intf_handle);
         if (intf_ptr->bInterfaceClass ==  USB_CLASS_AUDIO) { /* Body */
            if (intf_ptr->bInterfaceSubClass == USB_SUBCLASS_AUD_CONTROL) { /* Body */
               aud_device.INTF_HANDLE_AC = intf_handle;
               aud_device.DEV_HANDLE = dev_handle;
               aud_device.bACIntfNum = intf_ptr->bInterfaceNumber;
            } else if (intf_ptr->bInterfaceSubClass == USB_SUBCLASS_AUD_STREAMING) {
               for (i=0; i<MAX_AUDIO_STREAM_NUMBER; i++) { /* Body */
                  if (intf_ptr->bInterfaceNumber == aud_device.AudStream[i].bIntfNum) { /* Body */
                     aud_device.AudStream[i].INTF_HANDLE_AS[intf_ptr->bAlternateSetting] = intf_handle;
                     aud_device.AudStream[i].ALT_NUM_AS = intf_ptr->bAlternateSetting;
                     break;
                  } else if (aud_device.AudStream[i].bIntfNum == 0) { /* Body */
                     aud_device.AudStream[i].bIntfNum = intf_ptr->bInterfaceNumber;
                     aud_device.AudStream[i].INTF_HANDLE_AS[intf_ptr->bAlternateSetting] = intf_handle;
                     aud_device.AudStream[i].ALT_NUM_AS = intf_ptr->bAlternateSetting;
                     break;  
                  } /* Endbody */
               } /* Endbody */
            }
         } /* Endbody */
         if (aud_device.DEV_STATE != USB_DEVICE_ATTACHED) {
            if (aud_device.AudStream[0].ALT_NUM_AS > 0) 
               aud_device.DEV_STATE = USB_DEVICE_ATTACHED;
         } 
         break;
      case USB_INTF_EVENT:
         USBAUD_sync_post(&aud_device.Intf_Sync);
         break ;
      case USB_DETACH_EVENT:
         /* Use only the interface with desired protocol */
         if (aud_device.DEV_STATE != USB_DEVICE_DETACHED) {
            USB_memzero((pointer)&aud_device, sizeof(CLASS_CALL_STRUCT));
         }
         aud_device.DEV_STATE = USB_DEVICE_DETACHED;
         break;
      default:
         printf("CDC Device state = %d??\n", aud_device.DEV_STATE);
         fflush(stdout);
         aud_device.DEV_STATE = USB_DEVICE_IDLE;
         break;
   } /* EndSwitch */
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_init
* Returned Value : uint_32 
* Comments       :
*     Audio device initiation routine.
*END*--------------------------------------------------------------------*/
static uint_32 usb_host_aud_init(void)
{
   USB_STATUS        usbStatus = USB_OK;
   uint_8            bUnit, bBM;
   //uchar             data_buf[4];
      
   usbStatus = usb_audio_get_feature_unitID((CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF,
         aud_device.AudStream[0].bAudDirection, &bUnit, &bBM);
   if (usbStatus != USB_OK) { /* Body */
      printf("Error in getting #1 audio stream feature control unit ID.\n");
      fflush(stdout);
   } /* Endbody */
   aud_device.AudStream[0].bFeatureUnit = bUnit;
   aud_device.AudStream[0].bFeatureBMCrtl = bBM;
   
   // GET_MAX & GET_MIN of volume for #1 audio stream
   usb_host_get_max_min_volume(0);
      
   if (aud_device.AudStream[1].ALT_NUM_AS) {
       
      usbStatus = usb_audio_get_feature_unitID((CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF,
         aud_device.AudStream[1].bAudDirection, &bUnit, &bBM);
      if (usbStatus != USB_OK) { /* Body */
         printf("Error in getting #2 audio stream feature control unit ID.\n");
         fflush(stdout);
      } /* Endbody */
      aud_device.AudStream[1].bFeatureUnit = bUnit;
      aud_device.AudStream[1].bFeatureBMCrtl = bBM;
      
      // GET_MAX & GET_MIN of volume for #1 audio stream
      usb_host_get_max_min_volume(1);
   } /* Endbody */
   
   aud_buf = USB_memalloc(AUD_RECORD_BUF_SIZE);  // 200k mem for record and playback
   if (aud_buf == NULL) { /* Body */
      printf("Error in allocating global audio buffer.\n");
      fflush(stdout);
      return USBERR_ALLOC;
   } /* Endbody */
   USB_memzero(aud_buf, AUD_RECORD_BUF_SIZE);
   
   USBAUD_sync_init(&aud_device.Ctrl_Sync);
   USBAUD_sync_init(&aud_device.Data_Sync);
   USBAUD_sync_init(&aud_device.Intf_Sync);
   
   return usbStatus;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_init_extigy
* Returned Value : uint_32 
* Comments       :
*     Called to do device specific initiation for Creative Extigy.
*END*--------------------------------------------------------------------*/
uint_32 usb_host_aud_init_extigy(void)
{
   USB_STATUS        usbStatus;
   uchar             data_buf[4];
   int_16            intWord;
   uint_8            bUnit;  
   
   // SET_CUR Mute to 1 for feature 17
   bUnit = 0x17;
   data_buf[0] = 1;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 1 for feature 16 (for recording)
   bUnit = 0x16;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 1 for feature 1c
   bUnit = 0x1c;
   data_buf[0] = 1;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR UD_MODE_SELECT_CONTROL to 1 for Processing Unit 11
   bUnit = 0x11;
   data_buf[0] = 1;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_UD_ENABLE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR UD_MODE_SELECT = %d for Processing Unit %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR UD_ENABLE_CONTROL to 0 for Processing Unit 11
   bUnit = 0x11;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_UD_ENABLE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR UD_ENABLE = %d for Processing Unit %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */

   //SET_CUR volume for channel 1, feature 8 (Input Term 7)
   bUnit = 0x08;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,1,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for channel 1 of feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for channel 2, feature 8 (Input Term 7)
   bUnit = 0x08;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,2,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for channel 2 of feature %x to %d.\n",bUnit, intWord);
      fflush(stdout);
   } /* Endbody */

   // SET_CUR Mute to 1 for feature 8
   bUnit = 0x08;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for channel 1, feature 12 (Input Term 7)
   bUnit = 0x12;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,1,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for channel 1 of feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for channel 2, feature 12 (Input Term 7)
   bUnit = 0x12;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,2,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for channel 2 of feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 0 for feature 12
   bUnit = 0x12;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */

   // SET_CUR for Selector Unit b Parameter Block
   bUnit = 0x0b;
   data_buf[0] = 0x02;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,0,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Parameter Block = %d for Selector Unit %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 0 for feature 16
   bUnit = 0x16;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for Feature c
   bUnit = 0x0c;
   intWord = 0;  // 0x0000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR Bass for Feature 12
   bUnit = 0x12;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_BASS,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR Bass for %x to %d.\n", bUnit, data_buf[0]);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR Treble for Feature 12
   bUnit = 0x12;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_TREBLE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR Treble for feature %x to %d.\n", bUnit, data_buf[0]);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for Feature 6
   bUnit = 0x06;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 0 for feature 6
   bUnit = 0x06;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for Feature a
   bUnit = 0x0a;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 0 for feature a
   bUnit = 0x0a;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 0 for feature c
   bUnit = 0x0c;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 0 for feature 16
   bUnit = 0x16;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 0 for feature 19
   bUnit = 0x19;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */

   // GET_MAX of volume for feature 2
   bUnit = 0x02;
   usbStatus = usb_host_aud_get_class_intf_ctlr(AUD_GET_MAX,0,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      intWord = utoh16(data_buf);
      printf("GET_MAX for feature %x = %d\n", bUnit, intWord);
      fflush(stdout);
   }

   //SET_CUR volume for Feature 2
   bUnit = 0x02;
   intWord = 0x00;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */

   // SET_CUR ENABLE_CONTROL to 1 for Processing Unit 11
   bUnit = 0x11;
   data_buf[0] = 1;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_UD_ENABLE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR ENABLE_CONTROL = %d for Processing %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 0 for feature 1b
   bUnit = 0x1b;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 0 for feature 15
   bUnit = 0x15;
   data_buf[0] = 0;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR MODE_SELECT to 7 for Processing Unit 11
   bUnit = 0x11;
   data_buf[0] = 7; // 7??
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_UD_MODE_SELECT,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { 
      printf("SET_CUR MODE_SELECT = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   }

   // SET_CUR ENABLE_CONTROL to 1 for Processing Unit 11
   bUnit = 0x11;
   data_buf[0] = 1;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_UD_ENABLE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR ENABLE_CONTROL = %d for Processing Unit %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for channel 1 of Feature 12
   bUnit = 0x12;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,1,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Channel 1 Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for channel 2 of Feature 12
   bUnit = 0x12;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,2,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Channel 2 Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for channel 5 of Feature 12
   bUnit = 0x12;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,5,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Channel 5 Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for channel 6 of Feature 12
   bUnit = 0x12;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,6,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Channel 6 Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for channel 3 of Feature 12
   bUnit = 0x12;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,3,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Channel 3 Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for channel 4 of Feature 12
   bUnit = 0x12;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,4,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Channel 4 Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */

   // SET_CUR Mute to 1 for feature 17
   bUnit = 0x17;
   data_buf[0] = 1;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR Mute to 0 for feature 1c
   bUnit = 0x1c;
   data_buf[0] = 1;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   // SET_CUR ENABLE_CONTROL to 1 for Processing Unit 11
   bUnit = 0x11;
   data_buf[0] = 1;
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
               aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) { /* Body */
      printf("SET_CUR ENABLE_CONTROL = %d for Processing Unit %x.\n", data_buf[0], bUnit);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR ENABLE_CONTROL for Feature 12
   bUnit = 0x12;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,2,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Channel 2 Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   //SET_CUR volume for channel 1 of Feature 12
   bUnit = 0x12;
   intWord = -0x1000;  // 0xf000
   htou16(data_buf, intWord);
   usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,1,AUD_FU_VOLUME,
               aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
   if (usbStatus == AUD_OK) {
      printf("SET_CUR volume for Channel 1 Feature %x to %d.\n", bUnit, intWord);
      fflush(stdout);
   } /* Endbody */
   
   printf("Exit usb_host_aud_init_extigy.\n");
   fflush(stdout);
      
   return usbStatus;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_iso_recv_on
* Returned Value : uint_32 
* Comments       :
*     Timer routine to provide a signal for ISO In operation. This routine
* may not be needed for future USB stack release.
*END*--------------------------------------------------------------------*/
void usb_host_iso_recv_on
   (
      _timer_id id,
      pointer data_ptr,
      MQX_TICK_STRUCT_PTR tick_ptr
   )
{
   USBAUD_sync_post(&aud_device.Data_Sync);
}


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_init
* Returned Value : uint_32 
* Comments       :
*       Setup before recording an audio stream.
*END*--------------------------------------------------------------------*/
uint_32 usb_host_aud_record_setup
   (
      /* [IN] Audio Stream Index */
      uint_8      bASIndex,
      /* [IN] Sample Frequency */
      uint_32     dwSampFreq
   )
{
   USB_STATUS        usbStatus;
   uchar             data_buf[4];
   int_16            intWord;
   uint_8            bBM, bUnit;
   uint_32           dwAlt;
  
   dwAlt = usb_host_get_as_alt_from_sampfreq(bASIndex, dwSampFreq);
   if (dwAlt == 0) { 
      printf("Error in usb_host_aud_record:\n no alternate setting for audio streaming %d with sample frequency = %d.\n", 
                     bASIndex+1, dwSampFreq);
      fflush(stdout);
      return USBERR_BAD_STATUS;
   }
   
#ifndef __USB_OS_MQX__
      USBAUD_sync_init(&aud_device.Intf_Sync);
#endif                                                           
   usbStatus = _usb_hostdev_select_interface(aud_device.DEV_HANDLE,
                  aud_device.AudStream[bASIndex].INTF_HANDLE_AS[dwAlt], (pointer)&aud_device.CLASS_INTF);
   if (usbStatus != USB_OK) {
      fflush(stdout); 
      printf("Select #%d audio streaming to alternate setting %d failed!\n", bASIndex+1, dwAlt);
      fflush(stdout);
      return usbStatus;
   }
   USBAUD_sync_wait(&aud_device.Intf_Sync);
      
   bUnit = aud_device.AudStream[bASIndex].bFeatureUnit; // feature unit for AUD_DIRECTION_IN
   bBM = aud_device.AudStream[bASIndex].bFeatureBMCrtl; // audio control bitmap unit for AUD_DIRECTION_IN
   if (bUnit > 0) { /* Body */
      // Make sure feature unit Mute is off!
      if (bBM & AUD_FU_MUTE) { /* Body */
         data_buf[0] = 0;
         usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
                     aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
         if (usbStatus == AUD_OK) { /* Body */
            printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
            fflush(stdout);
         } /* Endbody */
      }
      
      // Set volume for feature unit
      if (bBM & AUD_FU_VOLUME) { /* Body */
         intWord = aud_device.AudStream[bASIndex].shMaxVolume - aud_device.AudStream[bASIndex].shMinVolume;
         intWord = (intWord/10)*9;  // Set volume to 90% of maximum
         intWord = intWord + aud_device.AudStream[bASIndex].shMinVolume;
         htou16(data_buf, intWord);
         usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_VOLUME,
                     aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
         if (usbStatus == AUD_OK) { /* Body */
            printf("SET_CUR Volume = %d for Feature %x.\n", intWord, bUnit);
            fflush(stdout);
         } /* Endbody */
      } /* Endbody */         
   }
}
   
/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_init
* Returned Value : uint_32 
* Comments       :
*     Record audio stream from an ISO In pipe
* Note: Since full speed USB stack does not provide call back for ISO IN
* operation, we use a timer for now. This will make this routine become OS
* dependent.
*END*--------------------------------------------------------------------*/
uint_32 usb_host_aud_record
   (
      /* [IN] pointer to the audio buffer */
      uchar_ptr      audio_buf,
      /* [IN] size of the audio buffer */
      uint_32        dwBufSize
   )
{
   USB_STATUS        usbStatus;
   uint_16           wMaxPacketSize, wRecvPktSize;
   uchar_ptr         pBuf, pBufEnd;
   AUDIO_COMMAND     aud_cmd;
   MQX_TICK_STRUCT   ticks;
   MQX_TICK_STRUCT   dticks;
   _timer_id         recv_timer;
   uint_32           i;
   
   usbStatus = usb_audio_get_max_data_packet_size((CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF, 
               AUD_DIRECTION_IN, &wMaxPacketSize);
   if (usbStatus != AUD_OK) { /* Body */
      printf("Error: failed to get ISO IN pipe max packet size.\n");
      fflush(stdout);
   } /* Endbody */    
#ifndef __VUSBHS__      
   /* 
   ** Create the timer component with more stack than the default
   ** in order to handle printf() requirements: 
   */
   _timer_create_component(TIMER_TASK_PRIORITY, TIMER_STACK_SIZE);

   _time_init_ticks(&dticks, 0);
   _time_add_msec_to_ticks(&dticks, 1);

   _time_get_ticks(&ticks);
   
   recv_timer = _timer_start_periodic_at_ticks(usb_host_iso_recv_on, 0, 
      TIMER_ELAPSED_TIME_MODE, &ticks, &dticks);
#endif
     
   printf("Start recording...\n");
   fflush(stdout);
   aud_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF;
   aud_cmd.CALLBACK_FN = usb_host_aud_data_callback;
   aud_cmd.CALLBACK_PARAM = (uint_32)(&aud_device);
   
   pBuf = audio_buf;
   pBufEnd = aud_buf + dwBufSize;
#ifdef __VUSBHS__
   wRecvPktSize = wMaxPacketSize*HIGH_SPEED_PACKET_NUM;
#else
   if (wMaxPacketSize == 200)
      wRecvPktSize = 196;
   else if (wMaxPacketSize == 90)
      wRecvPktSize = 88;
   else
      wRecvPktSize = wMaxPacketSize;
#endif

   while (pBuf < pBufEnd) {
#ifdef __VUSBHS__
      usbStatus = usb_audio_recv_data(&aud_cmd, pBuf, ((uint_32)wRecvPktSize));
#else
      usbStatus = usb_audio_recv_data(&aud_cmd, pBuf, ((uint_32)wMaxPacketSize));
#endif
      if (usbStatus == USB_STATUS_TRANSFER_QUEUED)
         USBAUD_sync_wait(&aud_device.Data_Sync);
      pBuf += wRecvPktSize;   // This should be replaced from actually return number from callback routine
   }
       
   printf("Record is done\n");
   fflush(stdout);   
#ifndef __VUSBHS__ 
   _timer_cancel(recv_timer);
#endif   
   for (i=0; i<1000000; i++);
      
   return usbStatus;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_init
* Returned Value : uint_32 
* Comments       :
*     Setup before a playback.
*END*--------------------------------------------------------------------*/
//static
uint_32 usb_host_aud_playback_setup
   (
      /* [IN] Audio Stream Index */
      uint_8         bASIndex,
      /* [IN] Sample Frequency */
      uint_32        dwSampFreq   
   )
{
   USB_STATUS        usbStatus;
   uchar             data_buf[4];
   int_16            intWord;
   uint_8            bBM, bUnit;
   uint_32           dwAlt;
   
   dwAlt = usb_host_get_as_alt_from_sampfreq(bASIndex, dwSampFreq);
   if (dwAlt == 0) { 
      printf("Error in usb_host_aud_playback:\n no alternate setting for audio streaming %d with sample frequency = %d.\n", 
                     bASIndex+1, dwSampFreq);
      fflush(stdout);
      return USBERR_BAD_STATUS;
   }                                      
 
#ifndef __USB_OS_MQX__
      USBAUD_sync_init(&aud_device.Intf_Sync);
#endif                       
   usbStatus = _usb_hostdev_select_interface(aud_device.DEV_HANDLE,
                  aud_device.AudStream[bASIndex].INTF_HANDLE_AS[dwAlt], (pointer)&aud_device.CLASS_INTF);
   if (usbStatus != USB_OK) {
      fflush(stdout); 
      printf("Select #%d audio streaming to alternate setting %d failed!\n", bASIndex+1, dwAlt);
      fflush(stdout);
      return usbStatus;
   }
   USBAUD_sync_wait(&aud_device.Intf_Sync);
      
   // Set current sample frequency
   usbStatus = usb_audio_get_iso_ep_address((CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF, AUD_DIRECTION_OUT, &bUnit);
   if (usbStatus == USB_OK) {    
      //dwSampFreq = aud_device.CurSampFreq;
      htou32(data_buf, dwSampFreq);
      usbStatus = usb_host_aud_set_class_ep_ctlr(AUD_SET_CUR, AUD_EP_SAMPLE_FREQ,bUnit,3,data_buf); 
      if (usbStatus == AUD_OK) { /* Body */
         printf("SET_CUR Sample Frequence to 0x%x for EP %x.\n", dwSampFreq, bUnit);
         fflush(stdout);
      }
   }
   
   bUnit = aud_device.AudStream[bASIndex].bFeatureUnit; // feature unit for AUD_DIRECTION_OUT
   bBM = aud_device.AudStream[bASIndex].bFeatureBMCrtl; // audio control bitmap unit for AUD_DIRECTION_OUT
   if (bUnit > 0) { /* Body */
      // Make sure feature unit Mute is off!
      if (bBM & AUD_FU_MUTE) { /* Body */
         data_buf[0] = 0;
         usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_MUTE,
                     aud_device.bACIntfNum, bUnit,0x01,(uchar_ptr)data_buf);
         if (usbStatus == AUD_OK) { /* Body */
            printf("SET_CUR Mute = %d for Feature %x.\n", data_buf[0], bUnit);
            fflush(stdout);
         } /* Endbody */
      }
      
      // Set volume for feature unit
      if (bBM & AUD_FU_VOLUME) { /* Body */
         intWord = aud_device.AudStream[bASIndex].shMaxVolume - aud_device.AudStream[bASIndex].shMinVolume;
         intWord = (intWord/10)*9;  // Set volume to 90% of maximum
         intWord = intWord + aud_device.AudStream[bASIndex].shMinVolume;
         htou16(data_buf, intWord);
         usbStatus = usb_host_aud_set_class_intf_ctlr(AUD_SET_CUR,0,AUD_FU_VOLUME,
                     aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
         if (usbStatus == AUD_OK) { /* Body */
            printf("SET_CUR Volume = %d for Feature %x.\n", intWord, bUnit);
            fflush(stdout);
         } /* Endbody */
      } /* Endbody */         
   }
   
   return usbStatus;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_init
* Returned Value : uint_32 
* Comments       :
*     Playback an audio stream.
*END*--------------------------------------------------------------------*/
//static
uint_32 usb_host_aud_playback
   (
      /* [IN] pointer to the audio stream */
      uchar_ptr      aud_stream,
      /* [IN] size of the audio stream */
      uint_32        dwStreamSize
   )
{ 
   USB_STATUS        usbStatus;
   uint_16           wMaxPacketSize;
   uchar_ptr         pBuf, pBufEnd;
   AUDIO_COMMAND     aud_cmd;
   uint_32           dwPacket;  
      
   usbStatus = usb_audio_get_max_data_packet_size((CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF, 
               AUD_DIRECTION_OUT, &wMaxPacketSize);
   if (usbStatus != AUD_OK) { /* Body */
      printf("Error: failed to get ISO OUT pipe max packet size.\n");
      fflush(stdout);
   } /* Endbody */  
   
   printf("Start playback...\n");
   fflush(stdout);
   aud_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF;
   aud_cmd.CALLBACK_FN = usb_host_aud_data_callback;
   aud_cmd.CALLBACK_PARAM = (uint_32)(&aud_device);
  
   pBuf = aud_stream;
   pBufEnd = aud_stream + dwStreamSize;
#ifdef __VUSBHS__
   dwPacket = wMaxPacketSize*HIGH_SPEED_PACKET_NUM;
   while (pBuf < pBufEnd) {
#ifndef __USB_OS_MQX__
      USBAUD_sync_init(&aud_device.Ctrl_Sync);
#endif  
      usbStatus = usb_audio_send_data(&aud_cmd, pBuf, dwPacket);
      if (usbStatus == USB_STATUS_TRANSFER_QUEUED) { /* Body */
         USBAUD_sync_wait(&aud_device.Data_Sync);
      } else { /* Body */
         printf("Playback Error: usbStatus = 0x%x.\n", usbStatus);
         fflush(stdout);
      }
      pBuf += dwPacket;    
   } /* Endbody */
#else
   dwPacket = (((uint_32)wMaxPacketSize-4)/4)*4;
   while (pBuf < pBufEnd) {
#ifndef __USB_OS_MQX__
      USBAUD_sync_init(&aud_device.Ctrl_Sync);
#endif
      usbStatus = USB_STATUS_TRANSFER_IN_PROGRESS;
      while (usbStatus == USB_STATUS_TRANSFER_IN_PROGRESS) {
         usbStatus = usb_audio_send_data(&aud_cmd, pBuf, dwPacket);
      }
      if (usbStatus == USB_STATUS_TRANSFER_QUEUED) { /* Body */
         USBAUD_sync_wait(&aud_device.Data_Sync);
      } else { /* Body */
         printf("Playback Error: usbStatus = 0x%x.\n", usbStatus);
         fflush(stdout);
      }
      pBuf += dwPacket;    
   } /* Endbody */
#endif
  
   printf("Playback is done.\n");
   fflush(stdout);
   
   return usbStatus;   
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_init
* Returned Value : uint_32 
* Comments       :
*     Called to get an audio class interface control.
*END*--------------------------------------------------------------------*/
static uint_32 usb_host_aud_get_class_intf_ctlr
   (
      uint_8      bRequest,       
      uint_8      bChNumber,     // wValue low byte
      uint_8      bCtrlSelector, // wValue high byte
      uint_8      bIntfNum,      // wIndex low byte
      uint_8      bUnitID,       // wIndex high byte
      uint_16     wLen,
      uchar_ptr   buffer
   )
{
   USB_STATUS        usbStatus;
   USB_SETUP         dev_req;
   AUDIO_COMMAND     aud_cmd;
   
   aud_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF;
   aud_cmd.CALLBACK_FN = usb_host_aud_ctrl_callback;
   aud_cmd.CALLBACK_PARAM = (uint_32)(&aud_device);
   USB_memzero(&dev_req, sizeof(USB_SETUP));
   
   dev_req.BMREQUESTTYPE = REQ_TYPE_IN + REQ_TYPE_CLASS + REQ_TYPE_INTERFACE;
   dev_req.BREQUEST = bRequest;
   dev_req.WVALUE[0] = bChNumber;
   dev_req.WVALUE[1] = bCtrlSelector; // High byte is Control Selector
   dev_req.WINDEX[0] = bIntfNum;
   dev_req.WINDEX[1] = bUnitID;          // Feature UnitID 02
   htou16(dev_req.WLENGTH, wLen);

#ifndef __USB_OS_MQX__
   USBAUD_sync_init(&aud_device.Ctrl_Sync);
#endif   
   usbStatus = usb_audio_control_request(&aud_cmd,
               &dev_req, wLen, buffer);
   if (usbStatus == USB_STATUS_TRANSFER_QUEUED)
      USBAUD_sync_wait(&aud_device.Ctrl_Sync);
   
   return AUD_OK;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_set_class_intf_ctlr
* Returned Value : uint_32 
* Comments       :
*     Called to set an audio class interface control.
*END*--------------------------------------------------------------------*/
static uint_32 usb_host_aud_set_class_intf_ctlr
   (
      uint_8      bRequest,   
      uint_8      bChNumber,     // wValue low byte
      uint_8      bCtrlSelector, // wValue high byte
      uint_8      bIntfNum,      // wIndex low byte
      uint_8      bUnitID,       // wIndex high byte
      uint_16     wLen,
      uchar_ptr   buffer
   )
{
   USB_STATUS        usbStatus;
   USB_SETUP         dev_req;
   AUDIO_COMMAND     aud_cmd;
   
   aud_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF;
   aud_cmd.CALLBACK_FN = usb_host_aud_ctrl_callback;
   aud_cmd.CALLBACK_PARAM = (uint_32)(&aud_device);
   USB_memzero(&dev_req, sizeof(USB_SETUP));
   
   dev_req.BMREQUESTTYPE = REQ_TYPE_OUT + REQ_TYPE_CLASS + REQ_TYPE_INTERFACE;
   dev_req.BREQUEST = bRequest;
   dev_req.WVALUE[0] = bChNumber;
   dev_req.WVALUE[1] = bCtrlSelector; // High byte is Control Selector
   dev_req.WINDEX[0] = bIntfNum;
   dev_req.WINDEX[1] = bUnitID;       // Feature UnitID
   htou16(dev_req.WLENGTH, wLen);

#ifndef __USB_OS_MQX__
   USBAUD_sync_init(&aud_device.Ctrl_Sync);
#endif   
   usbStatus = usb_audio_control_request(&aud_cmd,
               &dev_req, wLen, buffer);
   if (usbStatus == USB_STATUS_TRANSFER_QUEUED)
      USBAUD_sync_wait(&aud_device.Ctrl_Sync);
   
   return AUD_OK;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_get_class_ep_ctlr
* Returned Value : uint_32 
* Comments       :
*     Called to get an audio class endpoint control.
*END*--------------------------------------------------------------------*/
//static 
uint_32 usb_host_aud_get_class_ep_ctlr
(
      uint_8      bRequest,   
      uint_8      bCtrlSelector,    // wValue high byte
      uint_8      bEP,              // wIndex low byte
      uint_16     wLen,
      uchar_ptr   buffer
   )
{
   USB_STATUS        usbStatus;
   USB_SETUP         dev_req;
   AUDIO_COMMAND     aud_cmd;
   
   aud_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF;
   aud_cmd.CALLBACK_FN = usb_host_aud_ctrl_callback;
   aud_cmd.CALLBACK_PARAM = (uint_32)(&aud_device);
   USB_memzero(&dev_req, sizeof(USB_SETUP));
   
   dev_req.BMREQUESTTYPE = REQ_TYPE_IN + REQ_TYPE_CLASS + REQ_TYPE_ENDPOINT;
   dev_req.BREQUEST = bRequest;
   dev_req.WVALUE[1] = bCtrlSelector; // High byte is Control Selector
   dev_req.WINDEX[0] = bEP&0x0F;      // Endpoint
   htou16(dev_req.WLENGTH, wLen);

#ifndef __USB_OS_MQX__
   USBAUD_sync_init(&aud_device.Ctrl_Sync);
#endif   
   usbStatus = usb_audio_control_request(&aud_cmd,
               &dev_req, wLen, buffer);
   if (usbStatus == USB_STATUS_TRANSFER_QUEUED)
      USBAUD_sync_wait(&aud_device.Ctrl_Sync);
   
   return AUD_OK;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_set_class_ep_ctlr
* Returned Value : uint_32 
* Comments       :
*     Called to set an audio class endpoint control.
*END*--------------------------------------------------------------------*/
static 
uint_32 usb_host_aud_set_class_ep_ctlr
(
      uint_8      bRequest,   
      uint_8      bCtrlSelector,    // wValue high byte
      uint_8      bEP,              // wIndex low byte
      uint_16     wLen,
      uchar_ptr   buffer
   )
{
   USB_STATUS        usbStatus;
   USB_SETUP         dev_req;
   AUDIO_COMMAND     aud_cmd;
   
   aud_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&aud_device.CLASS_INTF;
   aud_cmd.CALLBACK_FN = usb_host_aud_ctrl_callback;
   aud_cmd.CALLBACK_PARAM = (uint_32)(&aud_device);
   USB_memzero(&dev_req, sizeof(USB_SETUP));
   
   dev_req.BMREQUESTTYPE = REQ_TYPE_OUT + REQ_TYPE_CLASS + REQ_TYPE_ENDPOINT;
   dev_req.BREQUEST = bRequest;
   dev_req.WVALUE[1] = bCtrlSelector; // High byte is Control Selector
   dev_req.WINDEX[0] = bEP;           // Endpoint
   htou16(dev_req.WLENGTH, wLen);

#ifndef __USB_OS_MQX__
   USBAUD_sync_init(&aud_device.Ctrl_Sync);
#endif   
   usbStatus = usb_audio_control_request(&aud_cmd,
               &dev_req, wLen, buffer);
   if (usbStatus == USB_STATUS_TRANSFER_QUEUED)
      USBAUD_sync_wait(&aud_device.Ctrl_Sync);
   
   return AUD_OK; 
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_ctrl_callback
* Returned Value : None
* Comments       :
*     Call back function for audio class control request.
*END*--------------------------------------------------------------------*/
static void usb_host_aud_ctrl_callback
   (
      /* [IN] Callback parameter */
      uint_32     param,
      /* [IN] pointer to class interface */
      pointer     if_ptr,
      /* [IN] Length of data transferred */
      uint_32     len,
      /* [IN] Error code (if any) */
      uint_32     status
   )
{ /* Body */
   DEVICE_STRUCT_PTR           audDev_ptr;

   audDev_ptr = (DEVICE_STRUCT_PTR)(pointer)param;

   USBAUD_sync_post(&audDev_ptr->Ctrl_Sync);
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_data_callback
* Returned Value : None
* Comments       :
*     Call back function for audio data transfers.
*END*--------------------------------------------------------------------*/
static void usb_host_aud_data_callback
   (
      /* [IN] Callback parameter */
      uint_32     param,
      /* [IN] pointer to class interface */
      pointer     if_ptr,
      /* [IN] Length of data transferred */
      uint_32     len,
      /* [IN] Error code (if any) */
      uint_32     status
   )
{ /* Body */
   DEVICE_STRUCT_PTR           audDev_ptr;

   audDev_ptr = (DEVICE_STRUCT_PTR)(pointer)param;
   
#ifdef __VUSBHS__
   audDev_ptr->Sync_Cnt++;
   if (audDev_ptr->Sync_Cnt >= HIGH_SPEED_PACKET_NUM) { 
     USBAUD_sync_post(&audDev_ptr->Data_Sync);
     audDev_ptr->Sync_Cnt = 0;
   }
#else
   USBAUD_sync_post(&audDev_ptr->Data_Sync);
#endif
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_is_creative_extigy
* Returned Value : None
* Comments       :
*     Called to check for Creative Extigy audio device, which has some
* audio extention unit and need special treatment.
*END*--------------------------------------------------------------------*/
static uint_8 usb_host_is_creative_extigy(void)
{
   uint_8 bRet = 0;
   DEV_INSTANCE_PTR dev_ptr;
   uint_16 wVendorID, wProductID;
   
   dev_ptr = (DEV_INSTANCE_PTR)aud_device.DEV_HANDLE;
   wVendorID = utoh16(dev_ptr->dev_descriptor.idVendor);
   wProductID = utoh16(dev_ptr->dev_descriptor.idProduct);
   
   if (wVendorID == 0x041e && wProductID == 0x3000)
      bRet = 1;
         
   return bRet;  
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_get_sample_freq
* Returned Value : None
* Comments       :
*     Called to get sample frequency for all audio interfaces.
*END*--------------------------------------------------------------------*/
static uint_32 usb_host_get_sample_freq(void)
{
   uint_32     altNum, altTmp;
   uint_32     i, uTmp;
   USB_STATUS  usbStatus;
   
   for (i=0; i<MAX_AUDIO_STREAM_NUMBER; i++) { /* Body */
      altNum = aud_device.AudStream[i].ALT_NUM_AS;
      if (altNum > 0) { /* Body */
         for (altTmp=1; altTmp <= altNum; altTmp++) { /* Body */
            usbStatus = usb_audio_get_sample_freq((pointer)aud_device.DEV_HANDLE,
                                      (pointer)aud_device.AudStream[i].INTF_HANDLE_AS[altTmp],
                                      &uTmp);
            if (usbStatus == USB_OK) { /* Body */
               aud_device.AudStream[i].SampFreq[altTmp] = uTmp;
            } 
         } /* Endbody */       
      } /* Endbody */
   } 
   
   return AUD_OK;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_get_max_min_volume
* Returned Value : None
* Comments       :
*     Called to get max & min audio volume for a audio stream and store 
* them into the global data structure - aud_device.
*END*--------------------------------------------------------------------*/
static uint_32 usb_host_get_max_min_volume
   (
      /* [IN] audio stream direction */
      uint_8      bASIndex
   )
{
   USB_STATUS  usbStatus;
   uint_8   bUnit, bBM;
   int_16   iTmp;
   uchar    data_buf[4];
   
   bUnit = aud_device.AudStream[bASIndex].bFeatureUnit;
   bBM = aud_device.AudStream[bASIndex].bFeatureBMCrtl;
   
   // GET_MAX & GET_MIN of volume for feature unit bUnit
   if (bBM & AUD_FU_VOLUME) { /* Body */
      data_buf[0] = 0;
      data_buf[1] = 0;
      usbStatus = usb_host_aud_get_class_intf_ctlr(AUD_GET_MAX,0,AUD_FU_VOLUME,
                  aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
      if (usbStatus == AUD_OK) {
         iTmp = utoh16(data_buf);
         aud_device.AudStream[bASIndex].shMaxVolume = iTmp;
         printf("GET_MAX for feature %x = %d\n", bUnit, iTmp);
         fflush(stdout);
      } else { /* Body */
         printf("Error in GET_MAX volume for feature unit %x\n", bUnit);
         fflush(stdout);
      } /* Endbody */
      
      data_buf[0] = 0;
      data_buf[1] = 0;
      usbStatus = usb_host_aud_get_class_intf_ctlr(AUD_GET_MIN,0,AUD_FU_VOLUME,
                  aud_device.bACIntfNum, bUnit,0x02,(uchar_ptr)data_buf);
      if (usbStatus == AUD_OK) {
         iTmp = utoh16(data_buf);
         aud_device.AudStream[bASIndex].shMinVolume = iTmp;
         printf("GET_MIN for feature %x = %d\n", bUnit, iTmp);
         fflush(stdout);
      } else { /* Body */
         printf("Error in GET_MIN volume for feature unit %x\n", bUnit);
         fflush(stdout);
      } /* Endbody */
   }

   return usbStatus;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_get_as_alt_from_sampfreq
* Returned Value : None
* Comments       :
*     Called to get altnate setting from a required sample frequency.
*END*--------------------------------------------------------------------*/
static uint_32 usb_host_get_as_alt_from_sampfreq
   (
      /* [IN] audio stream index */
      uint_32  dwIndex,
      /* [IN] required sample frequency */
      uint_32  dwSampFreq
   )
{
   uint_32  i;
   uint_32  dwAlt = 0;
   
   for (i=0; i<=aud_device.AudStream[dwIndex].ALT_NUM_AS; i++) { /* Body */
      if (aud_device.AudStream[dwIndex].SampFreq[i] >= dwSampFreq) { /* Body */
         dwAlt = i;
         break;
      } /* Endbody */
   } /* Endbody */
   
   return dwAlt;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_get_max_samp_freq
* Returned Value : None
* Comments       :
*     Called to get maximum sample frequency for an audio stream.
*END*--------------------------------------------------------------------*/
static uint_32 usb_host_get_max_samp_freq
   (
      /* [IN] audio stream index */
      uint_32  dwIndex
   )
{
   uint_32  i;
   uint_32  dwSFreq = 0;
   
   for (i=0; i<=aud_device.AudStream[dwIndex].ALT_NUM_AS; i++) { /* Body */
      if (aud_device.AudStream[dwIndex].SampFreq[i] > dwSFreq) { /* Body */
         dwSFreq = aud_device.AudStream[dwIndex].SampFreq[i];
      } /* Endbody */
   } /* Endbody */
      
   return dwSFreq;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_cleanup
* Returned Value : None
* Comments       :
*     Called to do cleanup.
*END*--------------------------------------------------------------------*/

static void usb_host_aud_cleanup(void)
{
   USBAUD_sync_destroy(&aud_device.Ctrl_Sync);
   USBAUD_sync_destroy(&aud_device.Data_Sync);
   USBAUD_sync_destroy(&aud_device.Intf_Sync);
   
   if (aud_buf) { 
      USB_memfree(aud_buf);
      aud_buf = NULL;
   }
}


/* EOF */

