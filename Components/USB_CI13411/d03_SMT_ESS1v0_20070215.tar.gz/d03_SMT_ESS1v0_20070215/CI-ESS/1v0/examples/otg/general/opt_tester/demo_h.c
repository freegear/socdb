/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the host specific code for the demo
***                                                               
**************************************************************************
**END*********************************************************/

/**************************************************************************
Include the OS and BSP dependent files that define IO functions and
basic types. You may like to change these files for your board and RTOS 
**************************************************************************/

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
   #include "bsp.h"
   #include "fio.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif   
#include "stdlib.h"
#include "string.h"
#endif
/**************************************************************************
Include the USB stack header files.
**************************************************************************/

#ifdef __USB_OTG__
#include "otgapi.h"
#else
#include "hostapi.h"
#include "devapi.h"
#endif
/**************************************************************************
Local header files for this application
**************************************************************************/

#include "demo.h"
#include "demo_d.h"
#include "demo_h.h"


/* Globals */
volatile DEVICE_STRUCT        device = { 0 }; /* device struct  */
volatile APP_GLOBAL_STRUCT    app_test_struct;


extern _usb_otg_handle        app_otg_handle;

extern _usb_device_handle     dev_handle;

_usb_pipe_handle              bulk_out_pipe_handle;
_usb_pipe_handle              bulk_in_pipe_handle;

PIPE_INIT_PARAM_STRUCT        bulk_out_pipe_init_struct;
PIPE_INIT_PARAM_STRUCT        bulk_in_pipe_init_struct;
volatile boolean  SUSPEND_ATTEMPTED = FALSE;
volatile boolean  RESUME_RECEIVED = FALSE;

/*TR structure to send set_feature HNP command */
TR_INIT_PARAM_STRUCT       tr;
USB_SETUP                  request;



/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : app_process_host_resume
* Returned Value : 
* Comments       :
*     Callback function to process the remote-wakeup/K-Attach event
* 
*END*--------------------------------------------------------------------*/
void app_process_host_resume
   (
      _usb_host_handle  handle,
      uint_32           length
   )
{ /* Body */
   uint_32  state;

   _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);
   /*set the resume to true since we came  here */
   RESUME_RECEIVED = TRUE;
   
   if (state < B_IDLE) {
      _usb_otg_set_status(app_otg_handle, USB_OTG_B_BUS_RESUME, TRUE);
   } else {
      _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_RESUME, TRUE);
   } /* Endif */
   
} /* EndBody */


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : app_process_HNP
* Returned Value : 
* Comments       :
*     function to process the HNP request
* 
*END*--------------------------------------------------------------------*/
void app_process_HNP
/*USB_STATUS app_process_HNP*/
   (
      _usb_host_handle  handle
   )
{ /* Body */
   uint_32                       state, i, total_len, error;
     boolean                       otg_des_found = FALSE;
   boolean                       hnp_capability = FALSE;
   
   _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);
   
   app_test_struct.TRANSACTION_COMPLETE = FALSE;
   
   /* Get the configuration descriptor */   
   error = _usb_hostdev_get_descriptor((pointer)device.DEV_HANDLE,
         DESCTYPE_CONFIG, 0, 0,
         (pointer)&app_test_struct.RX_CONFIG_DESC);

   //SGarg should wait here till transaction is complete
   //while (!app_test_struct.TRANSACTION_COMPLETE) {
         /* Wait until transaction is complete */
     //    if (app_test_struct.DEVICE_DETACHED) {
       //     return;
         //}
      //}

   app_test_struct.TRANSACTION_COMPLETE = FALSE;
      
   /* Find out the length of the transfer */
   total_len = app_test_struct.RX_CONFIG_DESC[2];
   total_len |= app_test_struct.RX_CONFIG_DESC[3] << 8;
   for (i=0;i < total_len;) 
   {
      /* checking for OTG descriptor type */
      if (app_test_struct.RX_CONFIG_DESC[i+1] == 
         USB_OTG_DESCRIPTOR_TYPE) 
      {
         otg_des_found = TRUE;
         break;
      } else {
         i = i + app_test_struct.RX_CONFIG_DESC[i];
      } /* Endif */
   } /* Endfor */
      
    /* Check if HNP enabled for device */
   if ((otg_des_found) && ((app_test_struct.RX_CONFIG_DESC[i+2]) & 0x02)) 
   {

      hnp_capability  = TRUE;
   }


   if ((state < B_IDLE) && hnp_capability)
   {
      printf("Device not supported\n");
      printf("Device supports HNP\n");
      printf("Attempting to set HNP enable ....\n");
      
      app_test_struct.TRANSACTION_STATUS = USB_OK;

      #if 0      
      /* we want to send set_feature HNP enable command but 
      select interface is not done yet. So we must use the
      HOST API (instead of Ch9 API) to send the request */
      usb_hostdev_tr_init (&tr, app_process_pipe_transaction_done, 
      NULL);
      /*prepare the request for set_feature */
      htou16(request.WINDEX, 0);
      request.BMREQUESTTYPE = 0 | REQ_TYPE_OUT;
      request.BREQUEST = REQ_SET_FEATURE;
      htou16(request.WVALUE, 3);
      /* fill rest of TR values */
      tr.DEV_REQ_PTR = (uchar_ptr)(&request);
      #endif

      error = _usb_host_register_ch9_callback(device.DEV_HANDLE,
                                             app_process_pipe_transaction_done,
                                             device.INTF_HANDLE);
                                             
      _usb_host_ch9_set_feature(device.DEV_HANDLE,0,0,3);

      while (!app_test_struct.TRANSACTION_COMPLETE) {
         /* Wait until transaction is complete */
         if (app_test_struct.DEVICE_DETACHED) {
            return;
         }
      }
      
      if(app_test_struct.TRANSACTION_STATUS == USB_OK)
      {
         printf("HNP enable successful with device\n"); 
         SUSPEND_ATTEMPTED = TRUE;
         _usb_otg_set_status(app_otg_handle, USB_OTG_A_SET_B_HNP_ENABLE, TRUE);
         _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_SUSPEND_REQ, TRUE);
         _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_REQ, FALSE);
      }
      else
      {
         printf("HNP enable failed with device...suspending the bus\n");
         SUSPEND_ATTEMPTED = TRUE;
         /* CALL the Host API function to suspend the bus */
         _usb_host_bus_control(handle, USB_SUSPEND_SOF);
         device.STATE = USB_DEVICE_SUSPEND_ATTEMPTED;
         
      }
     
   }

   else if (state < B_IDLE)
   {
         printf("Device not supported...\n");
         printf("Device does not support HNP\n");
         printf("Suspending the bus ....\n");

         /* OPT tester expects that if we don't support the device
         we should suspend the bus. Test 4.10. It should not be done
         normally because test 4.1 documentation does not say this
         but test program makes it necessary to do this to pass the test.
         If this is done in a normal program, we have problem in reattaching
         the device.*/
         /* CALL the Host API function to suspend the bus */
         /*ensure that we start monitoring for resume after this */
         SUSPEND_ATTEMPTED = TRUE;
         _usb_host_bus_control(handle, USB_SUSPEND_SOF);
         device.STATE = USB_DEVICE_SUSPEND_ATTEMPTED;


   }
   else //case when we are in B_HOST
   {
      /* OPT Test 5.6 requires that when we are in B_HOST and
      OPT is an unsupported device, we suspend the bus.*/
       printf("Device not supported...\n");
       printf("Suspending the bus ....\n");
       /*ensure that we start monitoring for resume after this */
       SUSPEND_ATTEMPTED = TRUE;
       /* CALL the Host API function to suspend the bus */
       _usb_host_bus_control(handle, USB_SUSPEND_SOF);
       device.STATE = USB_DEVICE_SUSPEND_ATTEMPTED;

   }

}

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : app_process_pipe_transaction_done
* Returned Value : 
* Comments       :
*     Callback function to process the transaction done event
* 
*END*--------------------------------------------------------------------*/
void app_process_pipe_transaction_done
   (
      /* [IN] pointer to pipe */
      _usb_pipe_handle  pipe_handle,

      /* [IN] user-defined parameter */
      pointer           user_parm,

      /* [IN] buffer address */
      uchar_ptr         buffer,

      /* [IN] length of data transferred */
      uint_32           length_data_transfered,

      /* [IN] status, hopefully USB_OK or USB_DONE */
      uint_32           status
   )
{ /* Body */
   app_test_struct.TRANSACTION_COMPLETE = TRUE;
   app_test_struct.TRANSACTION_STATUS = status;
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_device_event
* Returned Value : None
* Comments       :
*     called when device has been attached, detached, etc.
*END*--------------------------------------------------------------------*/
void usb_host_device_event
   (
      /* [IN] pointer to device instance */
      _usb_device_instance_handle      dev_handle,

      /* [IN] pointer to interface descriptor */
      _usb_interface_descriptor_handle intf_handle,

      /* [IN] code number for event causing callback */
      uint_32           event_code
   )
{
   INTERFACE_DESCRIPTOR_PTR   intf_ptr =
      (INTERFACE_DESCRIPTOR_PTR)intf_handle;

   switch (event_code) {
      case USB_CONFIG_EVENT:
         /* Drop through into attach, same processing */
      case USB_ATTACH_EVENT:
         if (device.STATE == USB_DEVICE_IDLE ||
            device.STATE == USB_DEVICE_DETACHED) 
         {
            device.DEV_HANDLE = dev_handle;
            device.INTF_HANDLE = intf_handle;
            device.STATE = USB_DEVICE_ATTACHED;
            /*attempt to select an interface on device */
            _usb_hostdev_select_interface(device.DEV_HANDLE,
            device.INTF_HANDLE, (pointer)&device.CLASS_INTF);
            device.STATE = USB_DEVICE_INTERFACED;

         } /* EndIf */
         break;
      case USB_INTF_EVENT:
         device.STATE = USB_DEVICE_INTERFACED;
         break;
      case USB_DETACH_EVENT:
         if (device.STATE == USB_DEVICE_INTERFACED || 
            device.STATE == USB_DEVICE_ATTACHED) 
         {
            device.DEV_HANDLE = NULL;
            device.INTF_HANDLE = NULL;
            device.STATE = USB_DEVICE_DETACHED;
               
         } /* EndIf */
         break;
      default:
         device.STATE = USB_DEVICE_IDLE;
         break;
   } /* EndSwitch */

} /* Enbbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : host_main
* Returned Value : 
* Comments       :
*     The echo test function
* 
*END*--------------------------------------------------------------------*/
void host_main
   (
      _usb_host_handle  handle
   ) 
{
   uint_32                       state = 0, loop_count = 0, error;
   char                          c;
   TR_INIT_PARAM_STRUCT          tr_to_bulk_out = {0};
   TR_INIT_PARAM_STRUCT          tr_to_bulk_in = {0};
   uint_32 last_state            = 0xFFFF;

   _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);
   /*************************************************************************
   Once the OTG application enters the host state, it loops through a busy
   while loop checking for the state change. If state does not remain
   as Host, it returns the control back to OTG main loop (see file demo.c)
   *************************************************************************/
   
   while ((state == A_HOST) | (state == B_HOST)) 
   {
      /*************************************************************************
      Keep taking action based on the event that ocsured      .
      *************************************************************************/
      switch ( device.STATE ) 
      {
            case USB_DEVICE_IDLE:
               break ;
            case USB_DEVICE_ATTACHED:
            break ;
         case USB_DEVICE_SUSPEND_ATTEMPTED:
            /*if a suspend is attempted by Host, software should
            not take any action. OTG state changes will take
            software out of while loop automatically */
         
            break;            
         case USB_DEVICE_INTERFACED:
             
             if(SUSPEND_ATTEMPTED) break; /*return if we attempted to suspend */
             /*****************************************************************
            If device is attached and communication has started with it. OTG
            specifictaion requires that we should read the OTG descriptor from
            device to find if device supports HNP or not. Then we should
            ask user if he would like to do an HNP or not.
            ******************************************************************/
            app_test_struct.DO_HNP = TRUE;
            app_test_struct.DO_SRP = FALSE;
            app_process_HNP(handle);
            
            /*if Host did not suspend the bus we should
            go ahead and select the interface on device */            
            if(device.STATE != USB_DEVICE_SUSPEND_ATTEMPTED)
            {
               /* select interface here if you want to communicate with
               device further */
            }
         
            break;
      }
      /*************************************************************************
      Keep checking the state of the OTG state machine
      *************************************************************************/

      _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);
   
   } /* Endwhile */

   /*If we attempted suspend and it is causing us to exit out
   of HOST state, we should ensure that our local device state 
   is IDLE now */
   if (device.STATE == USB_DEVICE_SUSPEND_ATTEMPTED)
   {
      device.STATE = USB_DEVICE_IDLE;
   }
   
} /* Endbody */

/* EOF */
