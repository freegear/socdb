/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:
***    This file contains the USB MFS mass storage link driver.
***
***
**************************************************************************
**END*********************************************************/
#include "types.h"
#include "fio.h"
#include "io.h"
#ifdef __USB_OTG__
#include "otgapi.h"
#else
#include "hostapi.h"
#include "devapi.h"
#endif
#include "usb_mass_bo.h"
#include "usbmfs.h"
#include "usbmfspr.h"
#include "usb_mass_ufi.h"

/*
** Define a global Interface handle that will be used for passing requests to
** the device at lower level
*/
volatile static uint_8        COMMAND_STATUS = MQX_OK;
static CLASS_CALL_STRUCT_PTR  class_interface = NULL;
static LWSEM_STRUCT           COMMAND_DONE;



/* Function declaration */
static void callback  (USB_STATUS,      /*status of this command*/
               pointer,     /*pointer to USB_MASS_BULK_ONLY_REQUEST_STRUCT*/
               pointer,     /*pointer to the command object*/
               uint_32       /* length of the data transfered if any */
               );

static void   init_command_object(COMMAND_OBJECT_PTR _PTR_, uint_32);
static void deinit_command_object(COMMAND_OBJECT_PTR);


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_install
* Returned Value   : uint_32 - a task error code or MQX_OK
* Comments         :
*    Install a  USB-MFS mass storage device driver.
*
*END*----------------------------------------------------------------------*/

uint_32 _io_usb_mfs_install
   (
      /* [IN] A string that identifies the device for fopen */
      char_ptr                      identifier,

      /* [IN] Logical unit number which driver need to install */
      uint_8                         logical_unit,

      /* [IN] Interface Handle */
      pointer                        mass_intf_handle

   )
{ /* Body */
  IO_USB_MFS_STRUCT_PTR               info_ptr;

   /* Allocate memory for the state structure */
   info_ptr = _mem_alloc_system_zero((uint_32)sizeof(IO_USB_MFS_STRUCT));

   if (info_ptr == NULL) {
      return(MQX_OUT_OF_MEMORY);
   } /* Endif */

   class_interface = mass_intf_handle; /* store the interface handle in global variable*/

   /* Fill in the state structure with the info we know */
   info_ptr->LUN           = logical_unit;
   info_ptr->SECTOR_SIZE   = USB_MFS_DEFAULT_SECTOR_SIZE;
   info_ptr->TEMP_BUFF_PTR = NULL;
   info_ptr->ERROR_CODE    = IO_OK;

   _lwsem_create(&info_ptr->LWSEM, 1);
   _lwsem_create(&COMMAND_DONE, 0);

   return (_io_dev_install(identifier,
      (int_32 (_CODE_PTR_)(FILE_PTR, char_ptr,  char_ptr))_io_usb_mfs_open,
      (int_32 (_CODE_PTR_)(FILE_PTR)                     )_io_usb_mfs_close,
      (int_32 (_CODE_PTR_)(FILE_PTR, char_ptr,  int_32)  )_io_usb_mfs_read,
      (int_32 (_CODE_PTR_)(FILE_PTR, char_ptr,  int_32)  )_io_usb_mfs_write,
      (int_32 (_CODE_PTR_)(FILE_PTR, _mqx_uint, pointer) ) _io_usb_mfs_ioctl,
      (pointer)info_ptr
      ));

} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_open
* Returned Value   : An error code or MQX_OK
* Comments         : Opens and initializes a USB-MFS mass storage device driver.
*                    Mass storage device should be initialized to prior to this
*                    this call.
*END*----------------------------------------------------------------------*/

int_32 _io_usb_mfs_open
   (
      /* [IN] the file handle for the device being opened */
      FILE_PTR           fd_ptr,

      /* [IN] the remaining portion of the name of the device */
      char_ptr             open_name_ptr,

      /* [IN] USB mass storage class handle */
      char_ptr             flags
   )
{ /* Body */
   IO_DEVICE_STRUCT_PTR             io_dev_ptr = fd_ptr->DEV_PTR;
   _usb_class_handle                handle = (_usb_class_handle)flags;
   uint_32                          rcv_len,i,j;
   USB_STATUS                       error;
   COMMAND_OBJECT_PTR               cmd = NULL;
   IO_USB_MFS_STRUCT_PTR            info_ptr;


   info_ptr = (IO_USB_MFS_STRUCT_PTR)io_dev_ptr->DRIVER_INIT_PTR;
   rcv_len = info_ptr->SECTOR_SIZE;
   info_ptr->TEMP_BUFF_PTR = (uchar_ptr)_mem_alloc_system_zero(rcv_len);

#if MQX_CHECK_MEMORY_ALLOCATION_ERRORS
   if (info_ptr->TEMP_BUFF_PTR == NULL) {
      return(MQX_OUT_OF_MEMORY);
   } /* Endif */
#endif

   /* Save the mass storage class handle. */
   info_ptr->MSC_STREAM = handle;

   /* Send the call now */
   init_command_object(&cmd, info_ptr->LUN);
   error = usb_mass_ufi_inquiry(cmd, info_ptr->TEMP_BUFF_PTR, sizeof(INQUIRY_DATA_FORMAT));

   if (!error) {
      /* Wait for the completion */
      _lwsem_wait(&COMMAND_DONE);
   } /* Endif */

   deinit_command_object(cmd);

   if (error || COMMAND_STATUS != MQX_OK) {
      return IO_ERROR;
   } /* Endif */

   /* The command is now done and successful */
   for (i=8,j=0;i<16;i++) {
      info_ptr->VENDOR_INFO[j++] = info_ptr->TEMP_BUFF_PTR[i];
   } /* Endfor */

   for (j=0;i<32;i++) {
      info_ptr->PRODUCT_ID[j++] = info_ptr->TEMP_BUFF_PTR[i];
   } /* Endfor */

   for (j=0;i<36;i++) {
      info_ptr->PRODUCT_REV[j++] = info_ptr->TEMP_BUFF_PTR[i];
   } /* Endfor */

   /*
   ** Initialize command object for sending call to low level
   */
   init_command_object(&cmd, info_ptr->LUN);

   /* Send the call now */
   error = usb_mass_ufi_read_capacity(cmd, info_ptr->TEMP_BUFF_PTR,
         sizeof(MASS_STORAGE_READ_CAPACITY_CMD_STRUCT_INFO));

   if (!error) {
       /* Wait for the completion*/
      _lwsem_wait(&COMMAND_DONE);
   } /* Endif */

   deinit_command_object(cmd);

   if (error || COMMAND_STATUS != MQX_OK) {
      return IO_ERROR;
   } /* Endif */

   info_ptr->NUM_SECTORS = HOST_READ_BEOCT_32(info_ptr->TEMP_BUFF_PTR);
   info_ptr->SIZE_SECTORS = HOST_READ_BEOCT_32(info_ptr->TEMP_BUFF_PTR + 4);

   /* should read this to support  low level format */
   info_ptr->NUMBER_OF_HEADS   = 0;
   info_ptr->NUMBER_OF_TRACKS  = 0;
   info_ptr->SECTORS_PER_TRACK = 0;

   info_ptr->SIZE_BYTES = info_ptr->SIZE_SECTORS * info_ptr->NUM_SECTORS;

   /* if the sector size is larger than default then allocate a new one */
   if (info_ptr->SECTOR_SIZE > USB_MFS_DEFAULT_SECTOR_SIZE) {
      _mem_free(info_ptr->TEMP_BUFF_PTR);
      info_ptr->TEMP_BUFF_PTR = _mem_alloc_system_zero(info_ptr->SECTOR_SIZE);
   } /* Endif */

   return MQX_OK;
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_close
* Returned Value   : ERROR CODE
* Comments         : Closes the USB mass storage link driver
*
*END*----------------------------------------------------------------------*/

int_32 _io_usb_mfs_close
   (
      /* [IN] the file handle for the device being closed */
      FILE_PTR fd_ptr
   )
{ /* Body */
   IO_DEVICE_STRUCT_PTR   io_dev_ptr = fd_ptr->DEV_PTR;
   IO_USB_MFS_STRUCT_PTR  info_ptr =
      (IO_USB_MFS_STRUCT_PTR)io_dev_ptr->DRIVER_INIT_PTR;

   _mem_free((pointer)info_ptr->TEMP_BUFF_PTR);
   info_ptr->TEMP_BUFF_PTR = NULL;

   return(MQX_OK);

} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_read
* Returned Value   : number of bytes read
* Comments         : Reads data from the USB mass storage device
*
*END*----------------------------------------------------------------------*/

int_32 _io_usb_mfs_read
   (
      /* [IN] the file handle for the device */
      FILE_PTR   fd_ptr,

      /* [IN] where the newly-read bytes are to be stored */
      char_ptr                 data_ptr,

      /* [IN] the number of bytes/sectors to read */
      int_32                 num
   )
{ /* Body */
   IO_DEVICE_STRUCT_PTR   io_dev_ptr = fd_ptr->DEV_PTR;
   IO_USB_MFS_STRUCT_PTR  info_ptr =
      (IO_USB_MFS_STRUCT_PTR)io_dev_ptr->DRIVER_INIT_PTR;
   uchar_ptr              dst_ptr;
   uint_32                total_size;
   uint_32                sector_size;
   int_32                results;
   uint_32                start_sector;
   uint_32                end_sector;
   uint_32                temp_num1;
   uint_32                offset;
   uint_32                remains;
   uint_32                num_sectors;
   uint_32                sectors_to_read;
   uint_32                error;

   _lwsem_wait(&info_ptr->LWSEM);

   /* Start CR 812 */
   if (info_ptr->BLOCK_MODE) {
      results = _io_usb_mfs_read_write_blocks(fd_ptr, info_ptr, data_ptr,
         num, FALSE);
      _lwsem_post(&info_ptr->LWSEM);
      return results;
   } /* Endif */
   /* End CR 812*/

   total_size = info_ptr->SIZE_BYTES;
   sector_size = info_ptr->SECTOR_SIZE;
   if (fd_ptr->LOCATION > total_size) {
      fd_ptr->ERROR = IO_ERROR_READ_ACCESS;
      _lwsem_post(&info_ptr->LWSEM);
      return(IO_ERROR);
   } else {
      if ((num + fd_ptr->LOCATION) > total_size) {
         fd_ptr->ERROR = IO_ERROR_READ_ACCESS;
         num = (int_32)(total_size - fd_ptr->LOCATION + 1);
      } /* Endif */
      start_sector = fd_ptr->LOCATION / info_ptr->SECTOR_SIZE;
      end_sector   = (fd_ptr->LOCATION + num - 1) / info_ptr->SECTOR_SIZE;
      num_sectors  = end_sector - start_sector + 1;
      temp_num1    = num;
      dst_ptr      = (uchar_ptr)data_ptr;

      /*
      ** We have three conditions:
      **   1. The read is contained in one USB mass storage device sector
      **   2. The read is contained in two adjacent USB mass storage device sectors
      **   3. The read spans many USB_MFS sectors
      **
      ** In case 1, it is possible to have a partial USB mass storage device sector.
      ** In case 2, it is possible that both the end and the start are only
      **  partial USB mass storage device sectors.
      ** In case 3(really a subset of case 2), the start and end may be partial
      **  but the others will all be complete USB mass storage device sectors.
      */

      offset = fd_ptr->LOCATION - info_ptr->SECTOR_SIZE * start_sector;

      if (offset > 0) {
         num_sectors--;
         remains = info_ptr->SECTOR_SIZE - offset;
         if (remains > temp_num1) {
            remains = temp_num1;
         }/* Endif */
         results = _io_usb_mfs_read_partial_sector(fd_ptr, start_sector, offset,
                     remains, dst_ptr);
         if (results == IO_ERROR)
         {
            fd_ptr->ERROR = IO_ERROR_WRITE;
            _lwsem_post(&info_ptr->LWSEM);
            return(results);
         } else {
            fd_ptr->LOCATION += results;
            dst_ptr           = (uchar_ptr)data_ptr + results;
            temp_num1        -= results;
            start_sector++;
         } /* Endif */
      } /* Endif */

      if (num_sectors > 1) {
         /*
         ** Read all the middle sectors (if any )
         */
         /* Calculate number of sectors to read but do not include last one */
         sectors_to_read = num_sectors - 1;
         if (num_sectors > 0xFFFE) {
            /* Read all the sectors at once */
            error =_io_usb_mfs_read_sector_long(info_ptr, start_sector,
               sectors_to_read, dst_ptr);
         } else {
            error =_io_usb_mfs_read_sector(info_ptr, start_sector,
               (uint_16)sectors_to_read, dst_ptr);
         } /* Endif */
         if (error == USB_MFS_NO_ERROR) {
            results          += (sector_size * sectors_to_read);
            fd_ptr->LOCATION += (sector_size * sectors_to_read);
            num_sectors -= sectors_to_read;
            dst_ptr          += (sector_size * sectors_to_read);
            temp_num1        -= (sector_size * sectors_to_read);
         } else {
            fd_ptr->ERROR = IO_ERROR_READ;
            _lwsem_post(&info_ptr->LWSEM);
            return(IO_ERROR);
         } /* Endif */
      } /* Endif */

      if (num_sectors) {
         /* Read the last mass storage device sector */
         offset  = 0;
         remains = temp_num1;
         results  = _io_usb_mfs_read_partial_sector(fd_ptr, end_sector, offset,
                        remains, dst_ptr);
         if (results == IO_ERROR) {
            fd_ptr->ERROR = IO_ERROR_WRITE;
            _lwsem_post(&info_ptr->LWSEM);
            return(results);
         } else {
            fd_ptr->LOCATION += results;
         } /* Endif */
      } /* Endif */
   } /* Endif */

   _lwsem_post(&info_ptr->LWSEM);
   return(num);

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_write
* Returned Value   : number of bytes written
* Comments         : Writes data to the USB mass storage device
*
*END*----------------------------------------------------------------------*/

int_32 _io_usb_mfs_write
   (
      /* [IN] the file handle for the device */
      FILE_PTR fd_ptr,
      /* [IN] where the outgoing data is store */
      char_ptr             data_ptr,
      /* [IN] the number of bytes to output */
      int_32               num
   )
{ /* Body */
   IO_DEVICE_STRUCT_PTR   io_dev_ptr = fd_ptr->DEV_PTR;
   IO_USB_MFS_STRUCT_PTR  info_ptr =
      (IO_USB_MFS_STRUCT_PTR)io_dev_ptr->DRIVER_INIT_PTR;
   uint_32                total_size;
   uint_32                sector_size;
   uchar_ptr              src_ptr;
   int_32                 results;
   uint_32                temp_num1;
   uint_32                start_sector;
   uint_32                end_sector;
   uint_32                offset;
   uint_32                remains;
   uint_32                num_sectors;
   uint_32                sectors_to_write;
   uint_32                error;

   _lwsem_wait(&info_ptr->LWSEM);

   /* Start CR 812 */
   if (info_ptr->BLOCK_MODE) {
      results = _io_usb_mfs_read_write_blocks(fd_ptr, info_ptr, data_ptr,
         num, TRUE);
      _lwsem_post(&info_ptr->LWSEM);
      return results;
   } /* Endif */
   /* End   CR 82 */

   total_size = info_ptr->SIZE_BYTES;
   sector_size = info_ptr->SECTOR_SIZE;
   if (fd_ptr->LOCATION > total_size)
   {
      fd_ptr->ERROR = IO_ERROR_WRITE_ACCESS;
      _lwsem_post(&info_ptr->LWSEM);
      return(IO_ERROR);
   } else {
      if ((num + fd_ptr->LOCATION) > total_size) {
          fd_ptr->ERROR = IO_ERROR_WRITE_ACCESS;
          num = (int_32)(total_size - fd_ptr->LOCATION + 1);
      } /* Endif */

      start_sector = fd_ptr->LOCATION / info_ptr->SECTOR_SIZE;
      end_sector   = (fd_ptr->LOCATION + num - 1) / info_ptr->SECTOR_SIZE;
      num_sectors  = end_sector - start_sector + 1;
      temp_num1    = num;
      src_ptr      = (uchar_ptr)data_ptr;

      /*
      ** We have three conditions:
      **   1. The write is contained in one USB mass storage device sector
      **   2. The write is contained in two adjacent USB mass storage device sectors
      **   3. The write spans many USB mass storage device sectors
      **
      ** In case 1, it is possible to have a partial USB_MFS sector.
      ** In case 2, it is possible that both the end and the start are only
      **  partial USB mass storage device sectors.
      ** In case 3(really a subset of case 2), the start and end maybe partial
      **  but the others will all be complete USB mass storage device sectors.
      */

      offset = fd_ptr->LOCATION - info_ptr->SECTOR_SIZE * start_sector;

      if (offset > 0) {
         num_sectors--;
         remains = info_ptr->SECTOR_SIZE - offset;
         if (remains > temp_num1) {
            remains = temp_num1;
         }/* Endif */
         results = _io_usb_mfs_write_partial_sector(fd_ptr, start_sector, offset,
                     remains, src_ptr);
         if (results == IO_ERROR)
         {
            fd_ptr->ERROR = IO_ERROR_WRITE;
            _lwsem_post(&info_ptr->LWSEM);
            return(results);
         } else {
            fd_ptr->LOCATION += results;
            src_ptr           = (uchar_ptr)data_ptr + results;
            temp_num1        -= results;
            start_sector++;
         } /* Endif */
      } /* Endif */

      if (num_sectors > 1) {
         /*
         ** Write the middle sectors (if any )
         */
         /* Calculate number of sectors to write but do not include last one */
         sectors_to_write = num_sectors - 1;

         if (num_sectors > 0xFFFE) {
            error =_io_usb_mfs_write_sector(info_ptr, start_sector,
               sectors_to_write, src_ptr);
         } else {
            error =_io_usb_mfs_write_sector(info_ptr, start_sector,
               (uint_16)sectors_to_write, src_ptr);
         } /* Endif */

         if (error == USB_MFS_NO_ERROR) {
            results          += (sector_size * sectors_to_write);
            fd_ptr->LOCATION += (sector_size * sectors_to_write);
            num_sectors--;
            src_ptr          += (sector_size * sectors_to_write);
            temp_num1        -= (sector_size * sectors_to_write);
         } else {
            fd_ptr->ERROR = IO_ERROR_WRITE;
            _lwsem_post(&info_ptr->LWSEM);
            return(IO_ERROR);
         } /* Endif */
      } /* Endif */

      if (num_sectors) {
         /* Write the last mass storage device sector */
         offset  = 0;
         remains = temp_num1;
         results  = _io_usb_mfs_write_partial_sector(fd_ptr, end_sector, offset,
                     remains, src_ptr);
         if (results == IO_ERROR) {
            fd_ptr->ERROR = IO_ERROR_WRITE;
            _lwsem_post(&info_ptr->LWSEM);
            return(results);
         } else {
            fd_ptr->LOCATION += results;
         } /* Endif */
      } /* Endif */
   } /* Endif */

   _lwsem_post(&info_ptr->LWSEM);
   return(num);

} /* Endbody */


/*FUNCTION*---------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_ioctl
* Returned Value   : int_32
* Comments         :
*    Returns result of ioctl operation.
*
*END*-------------------------------------------------------------------------*/

int_32 _io_usb_mfs_ioctl
   (
      /* [IN] the file handle for the device */
      FILE_PTR fd_ptr,

      /* [IN] the ioctl command */
      int_32               command,

      /* [IN] the ioctl parameters */
      pointer                input_param_ptr
   )
{ /* Body */
   USB_MFS_DRIVE_INFO_STRUCT_PTR drive_info_ptr;
   IO_DEVICE_STRUCT_PTR          io_dev_ptr = fd_ptr->DEV_PTR;
   IO_USB_MFS_STRUCT_PTR         info_ptr =
      (IO_USB_MFS_STRUCT_PTR)io_dev_ptr->DRIVER_INIT_PTR;
   int_32                        result = MQX_OK;
   uint_32_ptr                   param_ptr = input_param_ptr;
   MASS_STORAGE_START_STOP_UNIT_STRUCT_INFO  start_stop;
   USB_STATUS error;
   COMMAND_OBJECT_PTR cmd = NULL;


   switch (command) {
      case USB_MFS_IOCTL_GET_NUM_SECTORS:
         *param_ptr = info_ptr->NUM_SECTORS;
         break;
         /* Start CR 812 */
      case IO_IOCTL_GET_BLOCK_SIZE:
         /* End   CR 812 */
      case USB_MFS_IOCTL_GET_SECTOR_SIZE:
         *param_ptr = info_ptr->SECTOR_SIZE;
         break;
      case IO_IOCTL_DEVICE_IDENTIFY:
         param_ptr[0] = IO_DEV_TYPE_PHYS_USB_MFS;
         param_ptr[1] = IO_DEV_TYPE_LOGICAL_MFS;
         param_ptr[2] = IO_DEV_ATTR_ERASE | IO_DEV_ATTR_POLL
                         | IO_DEV_ATTR_READ | IO_DEV_ATTR_REMOVE
                         | IO_DEV_ATTR_SEEK | IO_DEV_ATTR_WRITE;
         /* Start CR 812 */
         if (info_ptr->BLOCK_MODE) {
            param_ptr[2] |= IO_DEV_ATTR_BLOCK_MODE;
         } /* Endif */
         /* End   CR 812 */

         break;
      case USB_MFS_IOCTL_GET_DRIVE_PARAMS:
         drive_info_ptr = (USB_MFS_DRIVE_INFO_STRUCT_PTR)((pointer)param_ptr);
         drive_info_ptr->NUMBER_OF_HEADS   = info_ptr->NUMBER_OF_HEADS;
         drive_info_ptr->NUMBER_OF_TRACKS  = info_ptr->NUMBER_OF_TRACKS;
         drive_info_ptr->SECTORS_PER_TRACK = info_ptr->SECTORS_PER_TRACK;
         break;
      case USB_MFS_VENDOR_INFO:
         *param_ptr = (uint_32)&(info_ptr->VENDOR_INFO);
         break;
      case USB_MFS_PRODUCT_ID:
         *param_ptr = (uint_32)&(info_ptr->PRODUCT_ID);
         break;
      case USB_MFS_PRODUCT_REV:
         *param_ptr = (uint_32)&(info_ptr->PRODUCT_REV);
         break;

      case USB_MFS_DEVICE_STOP:
         /* Send the call now */
         init_command_object(&cmd, info_ptr->LUN);
         error = usb_mass_ufi_start_stop(cmd, start_stop.LOEJ, start_stop.START);

         if (!error) {
            /* Wait for the completion*/
            _lwsem_wait(&COMMAND_DONE);
         } /* Endif */

         deinit_command_object(cmd);

         if (error || COMMAND_STATUS != MQX_OK) {
            return IO_ERROR;
         } /* Endif */
         break;

         /* Start CR 812 */
      case USB_MFS_SET_BLOCK_MODE:
         info_ptr->BLOCK_MODE = TRUE;
         break;
         /* End   CR 812 */

      default:
         result = IO_ERROR_INVALID_IOCTL_CMD;
         break;
   } /* Endswitch */
   return(result);

} /* Endbody */


/* Private functions */
/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_read_sector
* Returned Value   : error code
* Comments         :
*
*
*END*----------------------------------------------------------------------*/

uint_32 _io_usb_mfs_read_sector
   (
      /* [IN] USB MFS state structure */
      IO_USB_MFS_STRUCT_PTR  info_ptr,

      /* [IN] The sector number to read */
      uint_32                sector,

      /* [IN] How many sectors should read */
      uint_16                how_many_sectors,


      /* [IN] Location to read data into */
      uchar_ptr              data_ptr
   )
{ /* Body */
   uint_32                                rcv_len;
   USB_STATUS                             error;
   COMMAND_OBJECT_PTR cmd = NULL;

   /* UFI_READ10 command  */
   rcv_len = info_ptr->SECTOR_SIZE * how_many_sectors;

   /* Send the call now */
   init_command_object(&cmd, info_ptr->LUN);
   error = usb_mass_ufi_read_10(cmd, sector, data_ptr, rcv_len,
         how_many_sectors);

   if (!error) {
      /* Wait for the completion*/
      _lwsem_wait(&COMMAND_DONE);
   } /* Endif */

   deinit_command_object(cmd);

   if (error || COMMAND_STATUS != MQX_OK) {
      return USB_MFS_READ_ERROR;
   } /* Endif */

   return(USB_MFS_NO_ERROR);
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_read_sector_long
* Returned Value   : error code
* Comments         :
*
*
*END*----------------------------------------------------------------------*/

uint_32 _io_usb_mfs_read_sector_long
   (
      /* [IN] USB MFS state structure */
      IO_USB_MFS_STRUCT_PTR  info_ptr,

      /* [IN] The sector number to read */
      uint_32                sector,

      /* [IN] How many sectors should read */
      uint_32                how_many_sectors,

      /* [IN] Location to read data into */
      uchar_ptr              data_ptr
   )
{ /* Body */
   uint_32                                rcv_len;
   uint_8                                 error;
   COMMAND_OBJECT_PTR                     cmd = NULL;


   rcv_len = info_ptr->SECTOR_SIZE * how_many_sectors;

   /* Send the call now */
   init_command_object(&cmd, info_ptr->LUN);
   error = usb_mass_ufi_read_12(cmd,
         sector, data_ptr, rcv_len, how_many_sectors);

   if (!error) {
      /* Wait for the completion*/
      _lwsem_wait(&COMMAND_DONE);
   } /* Endif */

   deinit_command_object(cmd);

   if (error || COMMAND_STATUS != MQX_OK) {
      return IO_ERROR;
   } /* Endif */

   return (USB_MFS_NO_ERROR);
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_read_partial_sector
* Returned Value   : uint_32 - number of bytes read if successful,
*                    IO_ERROR otherwise
* Comments         : Read a partial USB_MFS sector
*END*----------------------------------------------------------------------*/

int_32 _io_usb_mfs_read_partial_sector
   (
      FILE_PTR fd_ptr,
      uint_32                sector_number,
      uint_32                offset_in_sector,
      uint_32                remains_in_sector,
      uchar_ptr              dst_ptr
   )
{ /* Body */
   IO_DEVICE_STRUCT_PTR    io_dev_ptr = fd_ptr->DEV_PTR;
   IO_USB_MFS_STRUCT_PTR   info_ptr   =
      (IO_USB_MFS_STRUCT_PTR)io_dev_ptr->DRIVER_INIT_PTR;
   uchar_ptr               tmp_ptr    = info_ptr->TEMP_BUFF_PTR;
   uint_32                 error;

   /* Read the sector into temporary buffer */
   error = _io_usb_mfs_read_sector(info_ptr, sector_number, 1, tmp_ptr);
   if (error != USB_MFS_NO_ERROR) {
      return(IO_ERROR);
   } /* Endif */

   /* Copy only the part of the sector we want */
   _mem_copy(tmp_ptr + offset_in_sector, dst_ptr, remains_in_sector);

   return(remains_in_sector);
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_write_sector
* Returned Value   : error code
* Comments         :
*
*
*END*----------------------------------------------------------------------*/

uint_32 _io_usb_mfs_write_sector
   (
      /* [IN] USB MFS state structure */
      IO_USB_MFS_STRUCT_PTR  info_ptr,

      /* [IN] The sector number to write */
      uint_32                sector,

      /* [IN] How many sectors should read */
      uint_16                how_many_sectors,

      /* [IN] Source data location */
      uchar_ptr              data_ptr
   )
{ /* Body */
   uint_32                      rcv_len;
   USB_STATUS                   error;
   COMMAND_OBJECT_PTR           cmd =  NULL;

   if (sector > info_ptr->NUM_SECTORS) {
      return(USB_MFS_INVALID_SECTOR);
   } /* Endif */

   rcv_len = info_ptr->SECTOR_SIZE * how_many_sectors;

   /* Send the call now */
   init_command_object(&cmd, info_ptr->LUN);
   error = usb_mass_ufi_write_10(cmd,
         sector, data_ptr, rcv_len, how_many_sectors);

   if (!error) {
       /* Wait for the completion*/
      _lwsem_wait(&COMMAND_DONE);
   } /* Endif */

   deinit_command_object(cmd);

   if (error || COMMAND_STATUS != MQX_OK) {
      return USB_MFS_WRITE_ERROR;
   } /* Endif */

   return(USB_MFS_NO_ERROR);
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_write_sector_long
* Returned Value   : error code
* Comments         :
*
*
*END*----------------------------------------------------------------------*/

uint_32 _io_usb_mfs_write_sector_long
   (
      /* [IN] USB MFS state structure */
      IO_USB_MFS_STRUCT_PTR  info_ptr,

      /* [IN] The sector number to write */
      uint_32                sector,

      /* [IN] How many sectors should read */
      uint_32                how_many_sectors,

      /* [IN] Source data location */
      uchar_ptr              data_ptr
   )
{ /* Body */
   uint_32                      rcv_len;
   USB_STATUS                   error;
   COMMAND_OBJECT_PTR           cmd = NULL;

   if (sector > info_ptr->NUM_SECTORS) {
      return(USB_MFS_INVALID_SECTOR);
   } /* Endif */

   rcv_len = info_ptr->SECTOR_SIZE * how_many_sectors;

   /* Send the call now */
   init_command_object(&cmd, info_ptr->LUN);
   error = usb_mass_ufi_write_12(cmd,
      sector, data_ptr, rcv_len, how_many_sectors);

   if (!error) {
      /* Wait for the completion*/
      _lwsem_wait(&COMMAND_DONE);
   } /* Endif */

   deinit_command_object(cmd);

   if (error || COMMAND_STATUS != MQX_OK) {
      return USB_MFS_WRITE_ERROR;
   } /* Endif */

   return (USB_MFS_NO_ERROR);
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_write_partial_sector
* Returned Value   : uint_32 - number of bytes written if successful,
*                    IO_ERROR otherwise
* Comments         : Writes a partial USB_MFS sector while preserving contents of
*                    unused portions of the sector
*
*END*----------------------------------------------------------------------*/

int_32 _io_usb_mfs_write_partial_sector
   (
      FILE_PTR fd_ptr,
      uint_32                sector_number,
      uint_32                offset_in_sector,
      uint_32                remains_in_sector,
      uchar_ptr              src_ptr
   )
{ /* Body */
   IO_DEVICE_STRUCT_PTR    io_dev_ptr = fd_ptr->DEV_PTR;
   IO_USB_MFS_STRUCT_PTR   info_ptr   =
      (IO_USB_MFS_STRUCT_PTR)io_dev_ptr->DRIVER_INIT_PTR;
   uint_32                 results;
   uchar_ptr               tmp_ptr    = info_ptr->TEMP_BUFF_PTR;
   uint_32                 error;

   /* Read the sector into temporary buffer */
   error = _io_usb_mfs_read_sector(info_ptr, sector_number, 1, tmp_ptr);
   if (error != USB_MFS_NO_ERROR) {
      return(IO_ERROR);
   } /* Endif */

   /* Write new data into temporary buffer */
   _mem_copy(src_ptr, tmp_ptr + offset_in_sector, remains_in_sector);

   /* Write the newly modified ram sector back into USB_MFS */
   if (_io_usb_mfs_write_sector\
   (info_ptr, sector_number, 1, tmp_ptr) == USB_MFS_NO_ERROR) {
      results = remains_in_sector;
      return(results);
   } else {
      return(IO_ERROR);
   } /* Endif */
} /* Endbody */


/* Start CR 812 */
/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : _io_usb_mfs_read_write_blocks
* Returned Value   : error or number of blocks read/written
* Comments         : This function is used to read/write blocks when driver
*   is in block mode
*
*END*----------------------------------------------------------------------*/

int_32 _io_usb_mfs_read_write_blocks
   (
      /* [IN] the file handle for the device */
      FILE_PTR   fd_ptr,

      /* [IN] USB MFS state structure */
      IO_USB_MFS_STRUCT_PTR  info_ptr,

      /* [IN] where the newly-read bytes are to be stored */
      char_ptr                 data_ptr,

      /* [IN] the number of sectors to read */
      uint_32                   num,

      /* [IN] Read/write mode */
      boolean                  write

   )
{ /* Body */
   int_32   error_code;
   uint_32 (_CODE_PTR_ rw_func_long)(IO_USB_MFS_STRUCT_PTR, uint_32, uint_32, uchar_ptr);
   uint_32 (_CODE_PTR_ rw_func)(IO_USB_MFS_STRUCT_PTR, uint_32, uint_16, uchar_ptr);

   if (write) {
      error_code = IO_ERROR_WRITE_ACCESS;
      rw_func    = _io_usb_mfs_write_sector;
      rw_func_long    = _io_usb_mfs_write_sector_long;
   } else {
      error_code = IO_ERROR_READ_ACCESS;
      rw_func    = _io_usb_mfs_read_sector;
      rw_func_long    = _io_usb_mfs_read_sector_long;
   } /* Endif */


   if (fd_ptr->LOCATION >= info_ptr->NUM_SECTORS) {
      fd_ptr->ERROR = error_code;
      return(IO_ERROR);
   } else {
      if ((num + fd_ptr->LOCATION) >= info_ptr->NUM_SECTORS) {
         fd_ptr->ERROR = error_code;
         num = (int_32)(info_ptr->NUM_SECTORS - fd_ptr->LOCATION + 1);
      } /* Endif */

      /* Read all the sectors, one at a time */
      if (num > 0xFFFE) {
         /* Read all the sectors at once */
          rw_func_long(info_ptr, fd_ptr->LOCATION,
            num, (uchar_ptr)data_ptr);
      } else {
          rw_func(info_ptr, fd_ptr->LOCATION,
            (uint_16)num, (uchar_ptr)data_ptr);
      } /* Endif */
      fd_ptr->LOCATION += num;
   } /* Endif */

   return(num);

} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : callback
* Returned Value   : None
* Comments         : This function is called by lowlevel drivers
when a command call back is set
*
*END*----------------------------------------------------------------------*/
void callback
   (
      USB_STATUS status,      /*status of this command*/
      pointer p1,     /* pointer to USB_MASS_BULK_ONLY_REQUEST_STRUCT*/
      pointer p2,     /* pointer to the command object*/
      uint_32 len     /* length of the data transfered if any */
   )
{ /* Body */

   _lwsem_post(&COMMAND_DONE);
   COMMAND_STATUS   = status;   /* set the status */

} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : Init command object
* Returned Value   : None
* Comments         : This function is called by other functions in this file to
allocate the memory for the command object.
*
*END*----------------------------------------------------------------------*/
void init_command_object
   (
      COMMAND_OBJECT_PTR _PTR_ cmd,
      uint_32                  lun
   )
{ /* Body */

   /* Allocate memory for the command object */
   *cmd = (COMMAND_OBJECT_PTR)_mem_alloc_system_zero(sizeof(COMMAND_OBJECT_STRUCT));

   /* Allocate memory for the CBW in the command object */
   (*cmd)->CBW_PTR = (CBW_STRUCT_PTR) _mem_alloc_system_zero(sizeof(CBW_STRUCT));

   /* Allocate memory for the CSW in the command object */
   (*cmd)->CSW_PTR = (CSW_STRUCT_PTR) _mem_alloc_system_zero(sizeof(CSW_STRUCT));

   /* Store the call back function pointer */
   (*cmd)->CALL_PTR = class_interface;
   (*cmd)->LUN = lun;
   (*cmd)->CALLBACK = callback;

   COMMAND_STATUS = MQX_OK;

   return;
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : Init command object
* Returned Value   : None
* Comments         : This function is called by lowlevel drivers
when a command call back is set
*
*END*----------------------------------------------------------------------*/
void deinit_command_object
   (
      COMMAND_OBJECT_PTR cmd
   )
{ /* Body */
   /* free memory allocated for the command object */
  _mem_free(cmd->CBW_PTR);
  _mem_free(cmd->CSW_PTR);
  _mem_free(cmd);
   return;
} /* Endbody */

/* End   CR 812 */
/* EOF */
