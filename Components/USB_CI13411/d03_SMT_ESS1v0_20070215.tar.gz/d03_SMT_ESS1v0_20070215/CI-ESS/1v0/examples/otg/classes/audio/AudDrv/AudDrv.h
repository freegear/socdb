#ifndef __usb_aud_app_h__
#define __usb_aud_app_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:      
***   This file contains printer-application types and definitions.
***                                                               
**************************************************************************
**END*********************************************************/
 /*
#include "usb_dev_list.h"
#include "host_common.h"
#include "otgapi.h"	 */ 

#ifdef __USB_OTG__
#include "otgapi.h"
#else
#include "hostapi.h"
#include "devapi.h"
#endif

#ifdef __USB_OS_MQX__
#define USBAUD_SYNC_VAR LWSEM_STRUCT
#define USBAUD_sync_init(a) _lwsem_create((LWSEM_STRUCT_PTR)a, 0);
#define USBAUD_sync_wait(a) _lwsem_wait((LWSEM_STRUCT_PTR)a)
#define USBAUD_sync_post(a) _lwsem_post((LWSEM_STRUCT_PTR)a)
#define USBAUD_sync_destroy(a) _lwsem_destroy((LWSEM_STRUCT_PTR)a);
#else
#define USBAUD_SYNC_VAR uint_32
#define USBAUD_sync_init(a) *(a) = FALSE
#define USBAUD_sync_wait(a) while (!*(a))
#define USBAUD_sync_post(a) *(a) = TRUE;
#define USBAUD_sync_destroy(a)
#endif

#define HIGH_SPEED_PACKET_NUM			8

#define AUD_RECORD_BUF_SIZE				409600
#define AUD_WAV_STREAM_SIZE				33320
#define AUD_OK							0
#define AUD_ERROR_PACKET_SIZE			0x10
#define AUD_ERROR_MEDIA_FORMAT			0x11 //(Not a PCM media format)

//#define TIMER_STACK_SIZE   TIMER_DEFAULT_STACK_SIZE+200
#define TIMER_TASK_PRIORITY  2
#define TIMER_STACK_SIZE				1000				

/* Application-specific definitions */
#define     MAX_PENDING_TRANSACTIONS      16
#define     MAX_FRAME_SIZE                1024
#define     HOST_CONTROLLER_NUMBER        0


#define  USB_DEVICE_IDLE                   (0)
#define  USB_DEVICE_ATTACHED               (1)
#define  USB_DEVICE_CONFIGURED             (2)
#define  USB_DEVICE_SET_INTERFACE_STARTED  (3)
#define  USB_DEVICE_SET_INTERFACE_END	   (4)
#define  USB_DEVICE_INTERFACED             (5)
#define  USB_DEVICE_DETACHED               (6)
#define  USB_DEVICE_OTHER                  (7)
#if 0
typedef void (_CODE_PTR_  AUD_CALLBACK_FN)
   (
      uint_32,                     /* [IN] Callback parameter */
      pointer,                     /* [IN] Pointer to class interface */
      uint_32,                     /* [IN] Length of data transferred */
      uint_32                      /* [IN] Error code */
   );
#endif
/*
** Following structs contain all states and pointers
** used by the application to control/operate devices.
*/
#define	MAX_ALTERNATE_SETTING	0x12
#define MAX_AUDIO_STREAM_NUMBER	2
typedef struct audio_stream_struct
{
   _usb_interface_descriptor_handle	INTF_HANDLE_AS[MAX_ALTERNATE_SETTING];
   uint_32							ALT_NUM_AS;		// Alternate setting number for the AS
   uint_32							SampFreq[MAX_ALTERNATE_SETTING];
   uint_8							bIntfNum;		// Interface number for this Audio Stream			
   uint_8							bAudDirection;	// Direction for this Audio Stream
   uint_8							bFeatureUnit;	// Feature Unit ID for this Audio Stream
   uint_8							bFeatureBMCrtl;	// Feature Unit control bitmap
   int_16							shMaxVolume;	// Max Volume for this Audio Stream
   int_16							shMinVolume;	// Min Volume for this Audio Stream
} AUDIO_STREAM_STRUCT, _PTR_ AUDIO_STREAM_STRUCT_PTR;

typedef struct device_struct
{
   USBAUD_SYNC_VAR					Ctrl_Sync;
   USBAUD_SYNC_VAR					Data_Sync;
   USBAUD_SYNC_VAR					Intf_Sync;
   uint_32							Sync_Cnt;
   uint_8							bACIntfNum;		// Audio Control Interface Number
   uint_8							bIsExitigyDevice;
   char								bPlayMode;
   uint_32							CurSampFreq;	// Current Sample Frequency
   uint_32                       	DEV_STATE;  	// Attach/detach state
   _usb_device_instance_handle   	DEV_HANDLE;		// Audio Device Handle
   _usb_interface_descriptor_handle INTF_HANDLE_AC;	// Audio Control interface handle
   AUDIO_STREAM_STRUCT				AudStream[MAX_AUDIO_STREAM_NUMBER];
   CLASS_CALL_STRUCT             	CLASS_INTF; 	// Class-specific info 
} DEVICE_STRUCT,  _PTR_ DEVICE_STRUCT_PTR;
 
                           
/* Alphabetical list of Function Prototypes */

#ifdef __cplusplus
extern "C" {
#endif

void    otg_service
                  (
                  _usb_otg_handle, 
                  uint_32
                  );
void    usb_host_aud_device_event
                  (
                  _usb_device_instance_handle,
                  _usb_interface_descriptor_handle,
                  uint_32
                  );

uint_32 usb_host_aud_init_extigy(void);
uint_32 usb_host_aud_record_setup(uint_8, uint_32);
uint_32 usb_host_aud_record(uchar_ptr, uint_32);
uint_32 usb_host_aud_playback_setup(uint_8, uint_32);
uint_32 usb_host_aud_playback(uchar_ptr, uint_32);
   
#ifdef __cplusplus
}
#endif                         


#endif

/* EOF */




     
