/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains routines for communication device data pipe.
***
**************************************************************************
**END*********************************************************/

#include "usb_cdc.h"
#include "modem.h"

#include "string.h"

#ifdef __USB_OS_MQX__
#include "bsp.h"
#include "mqx_arc.h"
#include "fio.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif
#include "stdlib.h"
#endif

extern volatile DEVICE_STRUCT  acm_device;
extern uchar_ptr   gDataBuf;
extern uchar       gReturnOk[];

volatile uint_32  BulkInCnt = 0;

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : MODEM_tx_callback
* Returned Value : None
* Comments       :
*     called on completion of data transfer.
*END*--------------------------------------------------------------------*/

static void usb_host_acm_data_callback
   (
      /* [IN] pointer to pipe */
      uint_32           callback_param,

      /* [IN] user-defined parameter */
      pointer           buffer,

      /* [IN] buffer address */
      uint_32           buflen,

      /* [IN] length of data transferred */
      uint_32           status
   )
{ /* Body */
   DEVICE_STRUCT_PTR           acmDev_ptr;

   acmDev_ptr = (DEVICE_STRUCT_PTR)(pointer)callback_param;
 
   USBCOM_sync_post(&acm_device.Data_Sync);

} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_data_callback
* Returned Value : None
* Comments       :
*     called on completion of a data receiving.
*END*--------------------------------------------------------------------*/

static void usb_host_acm_rx_callback
   (
      /* [IN] pointer to pipe */
      uint_32           callback_param,

      /* [IN] user-defined parameter */
      pointer           buffer,

      /* [IN] buffer address */
      uint_32           buflen,

      /* [IN] length of data transferred */
      uint_32           status
   )
{ /* Body */
   uint_32     i;
   uint_8      found = TRUE;
   
   //USBCOM_sync_post(&acm_device.Data_Sync);
   
   BulkInCnt++;
   if (buflen == strlen((char *)gReturnOk)) { /* Body */
      for (i=0; i<buflen; i++) { /* Body */
         if (gDataBuf[i] != gReturnOk[i]) { /* Body */
            found = FALSE;
            break;
         } /* Endbody */
      } /* Endbody */
      if (found)
         USBCOM_sync_post(&acm_device.Recv_Sync);
   } /* Endbody */
   usb_host_acm_poll_data(gDataBuf, DATA_BUFFER_LENGTH);
   
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_send_data
* Returned Value : None
* Comments       :
*     Called to send data through bulk out endpoint of data interface
*END*--------------------------------------------------------------------*/

USB_STATUS usb_host_acm_send_data
   (
      uchar_ptr   buffer,
      uint_32     buflen
   )
{ /* Body */
   USB_STATUS     error;
   CDC_COMMAND    cdc_cmd;

   cdc_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&acm_device.CLASS_INTF;
   cdc_cmd.CALLBACK_FN = (CDC_CALLBACK_USER_FN)usb_host_acm_data_callback;
   cdc_cmd.CALLBACK_PARAM = 0;
 
   error = usb_cdc_send_data(&cdc_cmd, buffer, buflen);

   return error;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_send_data
* Returned Value : None
* Comments       :
*     Called to send data through bulk out endpoint of data interface
*END*--------------------------------------------------------------------*/

USB_STATUS usb_host_acm_recv_data
   (
      uchar_ptr   buffer,
      uint_32     buflen
   )
{ /* Body */
   USB_STATUS     error;
   CDC_COMMAND    cdc_cmd;

   cdc_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&acm_device.CLASS_INTF;
   cdc_cmd.CALLBACK_FN = (CDC_CALLBACK_USER_FN)usb_host_acm_data_callback;
   cdc_cmd.CALLBACK_PARAM = 0;
 
   error = usb_cdc_recv_data(&cdc_cmd, buffer, buflen);

   return error;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_start_recv_data
* Returned Value : None
* Comments       :
*     Called to send data through bulk out endpoint of data interface
*END*--------------------------------------------------------------------*/

USB_STATUS usb_host_acm_poll_data
   (
      uchar_ptr   buffer,
      uint_32     buflen
   )
{ /* Body */
   USB_STATUS     error;
   CDC_COMMAND    cdc_cmd;
    /*
    * Use a different callback function, which will initiate another receiving
    * data transfer. Effectively, we are polling that bulk pipe.
    */
   cdc_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&acm_device.CLASS_INTF;
   cdc_cmd.CALLBACK_FN = (CDC_CALLBACK_USER_FN)usb_host_acm_rx_callback;
   cdc_cmd.CALLBACK_PARAM = 0;
 
   error = usb_cdc_recv_data(&cdc_cmd, buffer, buflen);

   return error;
}

