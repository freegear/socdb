/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the Device Framework Requests
***                                                               
**************************************************************************
**END*********************************************************/
#include "types.h"
#include "hostapi.h"
#include "demo_h.h"

USB_SETUP tx_get_status =
{
   0x80,    /* device-to-host, 0x80: default, 0x81: Interface, 0x82: Endpoint*/
   0,       /* Get Status */
   0,       /* WVALUE: 0: Default */
   0,       /* WINDEX: 0, Interface or Endpoint */
   2        /* WLENGTH: 2 bytes */
};

USB_SETUP tx_clear_feature =
{
   0x00,    /* host-to-device, 0: default, 1: Interface, 2: Endpoint */
   1,       /* Clear Feature */
   0,       /* WVALUE: 0: Endpoint Halt, 1: Device Remote Wakeup */
   0,       /* WINDEX: 0, Interface or Endpoint */
   0        /* WLENGTH */
};

USB_SETUP tx_set_feature =
{
   0,       /* host-to-device, 0: default, 1: Interface, 2: Endpoint */
   3,       /* Set Feature */
   3,       /* WVALUE: 0: Endpoint Halt, 1: Device Remote Wakeup,b_hnp_enable  */
   0,       /* WINDEX: 0, Interface or Endpoint */
   0        /* WLENGTH */
};

USB_SETUP tx_set_address =
{
   0,       /* host-to-device */
   5,       /* Set Address */
   0,       /* WVALUE: Device address to assign */
   0,       /* WINDEX: 0 */
   0        /* WLENGTH */
};

USB_SETUP tx_get_desc =
{
   0x80,    /* device-to-host */
   6,       /* Get Descriptor */
   0x0100,  /* WVALUE: HiByte: Descriptor Type (1: Device, 2: Configuration, 
            ** 3: String, 4: Interface, 5: Endpoint), LoByte: Descriptor Index 
            */
   0,       /* WINDEX: 0 (or language ID) */
   0x12     /* WLENGTH: Descriptor Length */
};

USB_SETUP tx_get_string_desc =
{
   0x80,    /* device-to-host */
   6,       /* Get Descriptor */
   0x0300,  /* WVALUE: HiByte: Descriptor Type (1: Device, 2: Configuration, 
            ** 3: String, 4: Interface, 5: Endpoint), LoByte: Descriptor Index 
            */
   0,       /* WINDEX: 0 (or language ID) */
   0x12     /* WLENGTH: Descriptor Length */
};

USB_SETUP tx_get_config_desc =
{
   0x80,    /* device-to-host */
   6,       /* Get Descriptor */
   0x0200,  /* WVALUE: HiByte: Descriptor Type (1: Device, 2: Configuration, 
            ** 3: String, 4: Interface, 5: Endpoint), LoByte: Descriptor Index 
            */
   0,       /* WINDEX: 0 (or language ID) */
   0x40     /* WLENGTH: Descriptor Length */
};

USB_SETUP tx_set_desc =
{
   0,       /* device-to-host */
   7,       /* Set Descriptor */
   0x0100,  /* WVALUE: HiByte: Descriptor Type (1: Device, 2: Configuration, 
            ** 3: String, 4: Interface, 5: Endpoint), LoByte: Descriptor Index 
            */
   0,       /* WINDEX: 0 (or language ID) */
   0x12     /* WLENGTH: Descriptor Length */
};

USB_SETUP tx_get_config =
{
   0x80,    /* device-to-host */
   8,       /* Get Config */
   0,       /* WVALUE: 0: default */
   0,       /* WINDEX: 0 = Default */
   1        /* WLENGTH: 1 byte */
};

USB_SETUP tx_set_config =
{
   0,       /* host-to-device */
   9,       /* Set Config */
   1,       /* WVALUE: Configuration value */
   0,       /* WINDEX: 0 */
   0        /* WLENGTH */
};

USB_SETUP tx_get_interface =
{
   0x81,    /* device-to-host */
   0x0A,    /* Get Interface */
   0,       /* 0: default */
   0,       /* WINDEX: Interface */
   1,       /* WLENGTH: 1 byte */
};

USB_SETUP tx_set_interface =
{
   0x21,    /* host-to-device, class, other */
   0x0B,    /* Set Interface */
   0,       /* WVALUE: Alternate Setting */
   0,       /* WINDEX: Zero or Interface or Endpoint (1 for port 1) */
   0,       /* WLENGTH */
};

USB_SETUP tx_synch_frame =
{
   0x82,    /* device-to-host */
   0x0C,    /* Synch Frame */
   0,       /* WVALUE: 0: Default */
   0,       /* WINDEX: Endpoint */
   2        /* WLENGTH: 2 bytes */
};

/* Example of a Vendor Specific Request */
USB_SETUP tx_enable_echo =
{
   0x40,    /* Vendor Specific request */
   0x02,
   0x001d,  /* WVALUE:  */
   0x0001,  /* WINDEX: Endpoint */
   0x0000   /* WLENGTH: 0 bytes */
};





