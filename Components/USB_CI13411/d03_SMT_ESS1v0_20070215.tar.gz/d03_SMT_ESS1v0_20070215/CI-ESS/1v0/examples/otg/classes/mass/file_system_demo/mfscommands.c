/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************/
#include <string.h>
#include "types.h"
#include "fio.h"
#include "mfs.h"
#include "mfsdemo.h"

char     *Test_Buffer;
char     *Test_Buffer2;
uint_32   Test_Buffer_Size;
uint_32   Test_Buffer_Size2;
extern MQX_INITIALIZATION_STRUCT MQX_init_struct;
extern uchar *MASS_STORAGE_DISK;
extern boolean HNP_ATTEMPTED;

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_dir_list
* Returned Value   : uint_32 error code
* Comments         :
*    This is the equivalent of "DIR".
*
*END*----------------------------------------------------------------------*/

uint_32  Test_dir_list
   (
       FILE_PTR         current_mfs
   )
{ /* Body */
   MFS_GET_LFN_STRUCT   lfn_data;
   MFS_SEARCH_DATA      search_data;
   MFS_SEARCH_PARAM     search;
   char                 filepath[PATHNAME_SIZE + 1];

   char                 lfn[FILENAME_SIZE + 1];
   uchar                attr;
   uint_32              error_code, file_count,
                        total_length, available_space;

   if (current_mfs == A_FD_PTR) { /* Body */
      available_space = RAMDISK_NUMBER_OF_SECTORS * BYTES_PER_SECT;
   } /* Endbody */

   strcpy (filepath, "*.*");
   attr = MFS_ATTR_ANY;

   search.ATTRIBUTE = attr;
   search.WILDCARD = filepath;
   search.SEARCH_DATA_PTR = &search_data;

   error_code = ioctl(current_mfs, IO_IOCTL_FIND_FIRST_FILE,
      (uint_32_ptr)&search);

   lfn_data.PATHNAME = search_data.NAME;
   lfn_data.LONG_FILENAME = lfn;
   file_count = 0;
   total_length = 0;
   while (error_code == MFS_NO_ERROR) {
      if (!(search_data.ATTRIBUTE & MFS_ATTR_VOLUME_NAME) &&
          !(search_data.ATTRIBUTE & MFS_ATTR_VOLUME_NAME))
      { /* Body */
         file_count++;
      } /* Endbody */
      total_length += search_data.FILE_SIZE;
      available_space -= search_data.FILE_SIZE;
      printf ("%-12.12s %8lu %02lu-%02lu-%04lu %02lu:%02lu:%02lu %s%s%s%s%s%s",
         search_data.NAME, search_data.FILE_SIZE,

         (uint_32)(search_data.DATE & MFS_MASK_MONTH) >> MFS_SHIFT_MONTH,
         (uint_32)(search_data.DATE & MFS_MASK_DAY)   >> MFS_SHIFT_DAY,
         (uint_32)((search_data.DATE & MFS_MASK_YEAR) >> MFS_SHIFT_YEAR) + 1980,

         (uint_32)(search_data.TIME & MFS_MASK_HOURS)   >> MFS_SHIFT_HOURS,
         (uint_32)(search_data.TIME & MFS_MASK_MINUTES) >> MFS_SHIFT_MINUTES,
         (uint_32)(search_data.TIME & MFS_MASK_SECONDS) << 1,

         (search_data.ATTRIBUTE & MFS_ATTR_READ_ONLY) ? "R":"    ",
         (search_data.ATTRIBUTE & MFS_ATTR_HIDDEN_FILE) ? "H":"    ",
         (search_data.ATTRIBUTE & MFS_ATTR_SYSTEM_FILE) ? "S":"    ",
         (search_data.ATTRIBUTE & MFS_ATTR_VOLUME_NAME) ? "V":"    ",
         (search_data.ATTRIBUTE & MFS_ATTR_DIR_NAME) ? "D":"    ",
         (search_data.ATTRIBUTE & MFS_ATTR_ARCHIVE) ? "A":"    ");

      error_code = ioctl(current_mfs, IO_IOCTL_GET_LFN, (pointer)&lfn_data);
      if (error_code != MFS_NO_ERROR) {
         printf("\n");
      } else {
         printf(" %s\n", lfn_data.LONG_FILENAME);
      } /* Endif */

      error_code = ioctl(current_mfs, IO_IOCTL_FIND_NEXT_FILE,
        (uint_32_ptr) &search_data);
   } /* Endwhile */

   printf("\n\t%d File(s) \t\t%8lu bytes", file_count, total_length);
   if (current_mfs == A_FD_PTR) { /* Body */
      printf("\n\t\t\t\t%8lu bytes free", available_space);
   } /* Endbody */
   if ( error_code == MFS_FILE_NOT_FOUND ) {
      error_code = MFS_NO_ERROR;
   }/* Endif */

   return( error_code );

} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_create_subdr_shell
* Returned Value   : uint_32 error code
* Comments         :
*    This function create a sub directory.
*
*END*----------------------------------------------------------------------*/

uint_32  Test_create_subdir_shell
   (
       FILE_PTR         current_mfs,
       /* directory name to create */
       char_ptr         dir_name
   )
{ /* Body */
   char                 pathname[PATHNAME_SIZE + 1];
   char                 current_dir[PATHNAME_SIZE + 1];

   ioctl(current_mfs, IO_IOCTL_GET_CURRENT_DIR, &current_dir);
   if (strlen(current_dir) < 2) {
      sprintf(pathname, "%s%s%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir, dir_name);
   } else {
      sprintf(pathname, "%s%s%c%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir,'\\', dir_name);
   } /* Endif */
   return ioctl(current_mfs, IO_IOCTL_CREATE_SUBDIR, pathname);

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_remove_subdir
* Returned Value   : uint_32 error_code
* Comments         :
*    This function changes the current directory.
*
*END*----------------------------------------------------------------------*/

uint_32  Test_remove_subdir
   (
       FILE_PTR         current_mfs,
       char_ptr         dir_name
   )
{ /* Body */
   char                 pathname[PATHNAME_SIZE + 1];
   char                 current_dir[PATHNAME_SIZE + 1];

   ioctl(current_mfs, IO_IOCTL_GET_CURRENT_DIR, &current_dir);
   if (strlen(current_dir) < 2) {
      sprintf(pathname, "%s%s%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir, dir_name);
   } else {
      sprintf(pathname, "%s%s%c%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir,'\\', dir_name);
   } /* Endif */
   return ioctl(current_mfs, IO_IOCTL_REMOVE_SUBDIR, pathname);

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_copy_file
* Returned Value   :  error code.
*
*END*---------------------------------------------------------------------*/

uint_32  Test_copy_file
   (
       FILE_PTR         current_mfs,
       char_ptr         src_file_name,
       char_ptr         dst_filepath
   )
{ /* Body */
   FILE_PTR         src_fd_ptr = NULL;
   FILE_PTR         dst_fd_ptr = NULL;
   char             src_filepath[PATHNAME_SIZE + 1];
//   char             dst_filepath[PATHNAME_SIZE + 1];
   char             current_dir[PATHNAME_SIZE + 1];
   uint_32          error, bytes, bytes2, read_bytes, total_bytes;

   ioctl(current_mfs, IO_IOCTL_GET_CURRENT_DIR, &current_dir);

   if (strlen(current_dir) < 2) {
      sprintf(src_filepath, "%s%s%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir, src_file_name);
//      sprintf(dst_filepath, "%s%s", (current_mfs==A_FD_PTR)?"b:":"a:", src_file_name);
   } else {
      sprintf(src_filepath, "%s%s%c%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir,'\\', src_file_name);
//      sprintf(dst_filepath, "%s%s", (current_mfs==A_FD_PTR)?"b:":"a:", src_file_name);
   } /* Endif */

   src_fd_ptr = fopen(src_filepath, "r");
   if (src_fd_ptr == NULL) {
      error = MFS_FILE_NOT_FOUND;
      return error;
   } /* Endif */

   bytes = src_fd_ptr->SIZE;

   /* create a file  and over write it */
   dst_fd_ptr = fopen(dst_filepath, "w+");
   if (dst_fd_ptr == NULL) {
      error = MFS_FILE_NOT_FOUND;
      return error;
   } /* Endif */

   printf("\nCopying %s (%d bytes)", src_file_name, bytes);
   total_bytes = 0;
   while (bytes > 0) { /* Body */
      if (bytes >= Test_Buffer_Size) { /* Body */
         read_bytes = Test_Buffer_Size;
      } else { /* Body */
         read_bytes = bytes;
      } /* Endbody */
      //_mem_zero(Test_Buffer, sizeof(Test_Buffer));
      bytes2 = read(src_fd_ptr, Test_Buffer, read_bytes);
      printf(".");
      bytes2 = write(dst_fd_ptr, Test_Buffer, bytes2);
      total_bytes += bytes2;
      if (bytes >= Test_Buffer_Size) { /* Body */
         bytes -= Test_Buffer_Size;
      } else { /* Body */
         bytes -= read_bytes;
      } /* Endbody */
   } /* Endbody */
   printf("\n--->%d bytes were copied.", total_bytes);
   fclose(dst_fd_ptr);
   fclose(src_fd_ptr);
   return((uint_32)dst_fd_ptr->ERROR);
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_throughput
* Returned Value   :  error code.
*
*END*---------------------------------------------------------------------*/

uint_32  Test_throughput
   (
       FILE_PTR         current_mfs,
       char_ptr         src_file_name
   )
{ /* Body */
   FILE_PTR          src_fd_ptr = NULL;
   FILE_PTR          dst_fd_ptr = NULL;
   char              src_filepath[PATHNAME_SIZE + 1];
   char              dst_filepath[PATHNAME_SIZE + 1];
   char              current_dir[PATHNAME_SIZE + 1];
   uint_32           error_code, bytes, bytes2;
   TIME_STRUCT       start_time, end_time, diff_time;
   long              throughput;

   ioctl(current_mfs, IO_IOCTL_GET_CURRENT_DIR, &current_dir);

   if (strlen(current_dir) < 2) {
      sprintf(src_filepath, "%s%s%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir, src_file_name);
      sprintf(dst_filepath, "%s%s_copy", (current_mfs==A_FD_PTR)?"a:":"b:", src_file_name);
   } else {
      sprintf(src_filepath, "%s%s%c%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir,'\\', src_file_name);
      sprintf(dst_filepath, "%s%s_copy", (current_mfs==A_FD_PTR)?"a:":"b:", src_file_name);
   } /* Endif */

   src_fd_ptr = fopen(src_filepath, "r");
   if (src_fd_ptr == NULL) {
      error_code = MFS_FILE_NOT_FOUND;
      return error_code;
   } /* Endif */

   bytes = src_fd_ptr->SIZE;

   if (bytes > Test_Buffer_Size) {
      if (Test_Buffer2) {
         error_code = _mem_free(Test_Buffer2);
         if (error_code != MQX_OK) {
            printf("\nError Freeing Memory (0x%x)", error_code);
         } else {
            Test_Buffer2 = NULL;
         } /* Endif */
      } /* Endif */
      if (Test_Buffer) {
         printf("\nFreeing Test_Buffer...");
         error_code = _mem_free(Test_Buffer);
         if (error_code != MQX_OK) {
            printf("\nError Freeing Memory (0x%x)", error_code);
         } /* Endif */
      } /* Endif */
      Test_Buffer_Size = bytes;

      Test_Buffer = _mem_alloc_system(Test_Buffer_Size);
      if (Test_Buffer == NULL) { /* Body */
         printf("\nError allocating Memory for Test_Buffer (0x%x)", error_code);
      } /* Endif */
   } /* Endif */

   printf("\nHit any key to start reading the file.....");
   getchar();
   printf("\nReading %s (%d bytes)", src_file_name, bytes);
   _time_get(&start_time);
   bytes2 = read(src_fd_ptr, Test_Buffer, bytes);
   _time_get(&end_time);
   _time_diff(&start_time, &end_time, &diff_time);
   printf("\n--->%d bytes were read:", bytes2);
   printf("%ld sec %ld millisec", diff_time.SECONDS, diff_time.MILLISECONDS);
   throughput = (bytes2)/
      ((diff_time.SECONDS*1024)+((diff_time.MILLISECONDS*1024)/1000));
   printf("\n--->Throughput = %d kBytes/sec", throughput);

   /* create a file  and over write it */
   dst_fd_ptr = fopen(dst_filepath, "w+");
   if (dst_fd_ptr == NULL) {
      error_code = MFS_FILE_NOT_FOUND;
      return error_code;
   } /* Endif */

   printf("\nHit any key to start writing the file.....");
   getchar();
   printf("\nWriting %s (%d bytes)", dst_filepath, bytes2);
   _time_get(&start_time);
   bytes2 = write(dst_fd_ptr, Test_Buffer, bytes2);
   _time_get(&end_time);
   _time_diff(&start_time, &end_time, &diff_time);
   printf("\n--->%d bytes were written:", bytes2);
   printf("%ld sec %ld millisec", diff_time.SECONDS, diff_time.MILLISECONDS);
   throughput = (bytes2*8)/
      ((diff_time.SECONDS*1024)+((diff_time.MILLISECONDS*1024)/1000));
   printf("\n--->Throughput = %d kbps", throughput);

   fclose(dst_fd_ptr);
   fclose(src_fd_ptr);
   return((uint_32)dst_fd_ptr->ERROR);
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_compare_file
* Returned Value   :  error code.
*
*END*---------------------------------------------------------------------*/

uint_32  Test_compare_file
   (
       FILE_PTR         current_mfs,
       char_ptr         src_file_name
   )
{ /* Body */
   FILE_PTR         src_fd_ptr = NULL;
   FILE_PTR         dst_fd_ptr = NULL;
   char             src_filepath[PATHNAME_SIZE + 1];
   char             dst_filepath[PATHNAME_SIZE + 1];
   char             current_dir[PATHNAME_SIZE + 1];
   uint_32          error, bytes, bytes2, read_bytes, total_bytes;

   if (Test_Buffer2 == NULL) { /* Body */
      printf("\nTest_Buffer2 wasn't allocated because of low memory.");
      printf("\nType ""buffer"" and chose a smaller buffer size");
      return(0);
   } /* Endif */

   ioctl(current_mfs, IO_IOCTL_GET_CURRENT_DIR, &current_dir);

   if (strlen(current_dir) < 2) {
      sprintf(src_filepath, "%s%s%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir, src_file_name);
      sprintf(dst_filepath, "%s%s", (current_mfs==A_FD_PTR)?"b:":"a:", src_file_name);
   } else {
      sprintf(src_filepath, "%s%s%c%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir,'\\', src_file_name);
      sprintf(dst_filepath, "%s%s", (current_mfs==A_FD_PTR)?"b:":"a:", src_file_name);
   } /* Endif */

   src_fd_ptr = fopen(src_filepath, "r");
   if (src_fd_ptr == NULL) {
      error = MFS_FILE_NOT_FOUND;
      return error;
   } /* Endif */
   bytes = src_fd_ptr->SIZE;
   printf("\nComparing %d bytes (source)", bytes);

   dst_fd_ptr = fopen(dst_filepath, "r");
   if (dst_fd_ptr == NULL) {
      error = MFS_FILE_NOT_FOUND;
      return error;
   } /* Endif */
   bytes = dst_fd_ptr->SIZE;
   printf(" with %d bytes (destination)", bytes);

   while (bytes > 0) { /* Body */
      if (bytes >= Test_Buffer_Size) { /* Body */
         read_bytes = Test_Buffer_Size;
      } else { /* Body */
         read_bytes = bytes;
      } /* Endbody */
      //_mem_zero(Test_Buffer, sizeof(Test_Buffer));
      bytes2 = read(src_fd_ptr, Test_Buffer, read_bytes);
      printf(".");
      //_mem_zero(Test_Buffer2, sizeof(Test_Buffer));
      bytes2 = read(dst_fd_ptr, Test_Buffer2, read_bytes);
      total_bytes += bytes2;
      if (strcmp(Test_Buffer, Test_Buffer2) != 0) {
         printf("\nFiles Differ");
      }
      if (bytes >= Test_Buffer_Size) { /* Body */
         bytes -= Test_Buffer_Size;
      } else { /* Body */
         bytes -= read_bytes;
      } /* Endbody */
   } /* Endbody */
   printf("\n%d bytes were compared.", total_bytes);

   fclose(dst_fd_ptr);
   fclose(src_fd_ptr);
   return((uint_32)dst_fd_ptr->ERROR);
} /* Endbody */


extern MFS_FORMAT_DATA MFS_format;
/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_format_disk
* Returned Value   :  error code.
*
*END*---------------------------------------------------------------------*/
uint_32  Test_format_disk
   (
       FILE_PTR         current_mfs
   )
{ /* Body */
   MFS_IOCTL_FORMAT_PARAM     format_struct;
   uint_32                    error_code;

   format_struct.FORMAT_PTR = &MFS_format;

   /* Formating */
   MFS_format.NUMBER_OF_SECTORS = RAMDISK_NUMBER_OF_SECTORS;
   error_code = ioctl(current_mfs, IO_IOCTL_FORMAT, (uint_32_ptr)&format_struct);
   if (error_code != MFS_NO_ERROR) {
      printf("\nError while formatting (%s)", Error_text(error_code));
   } /* Endif */
   if (!error_code) {
      error_code = ioctl(current_mfs, IO_IOCTL_SET_VOLUME, "ARC USBdisk");
      if (error_code != MFS_NO_ERROR) {
         printf("\nError while Setting Volume Name (%s)", Error_text(error_code));
      } /* Endif */
   } /* Endif */
   return(error_code);
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_process_camera
* Returned Value   : uint_32 error_code
* Comments         :
*    This function process the Camera demo
*
*END*----------------------------------------------------------------------*/

uint_32  Test_process_camera
   (
       FILE_PTR         current_mfs,
       char_ptr         dir_name
   )
{ /* Body */
   MFS_GET_LFN_STRUCT   lfn_data;
   MFS_SEARCH_DATA      search_data;
   MFS_SEARCH_PARAM     search;
   char                 filepath[PATHNAME_SIZE + 1];

   char                 lfn[FILENAME_SIZE + 1];
   uchar                attr;
   uint_32              error_code, count, available_space;

   Test_format_disk(A_FD_PTR);

   available_space = RAMDISK_NUMBER_OF_SECTORS * BYTES_PER_SECT;

   ioctl(current_mfs, IO_IOCTL_CHANGE_CURRENT_DIR, dir_name);

   strcpy (filepath, "*.*");
   attr = MFS_ATTR_ANY;

   search.ATTRIBUTE = attr;
   search.WILDCARD = filepath;
   search.SEARCH_DATA_PTR = &search_data;

   error_code = ioctl(current_mfs, IO_IOCTL_FIND_FIRST_FILE,
      (uint_32_ptr)&search);

   lfn_data.PATHNAME = search_data.NAME;
   lfn_data.LONG_FILENAME = lfn;
   count = 0;
   printf("\nReading files on attached device\n");
   while (error_code == MFS_NO_ERROR) {
      if (search_data.FILE_SIZE != 0) { /* Body */
         count++;
         printf ("-%-12.12s %6lu %02lu-%02lu-%04lu %02lu:%02lu:%02lu\n",
            search_data.NAME, search_data.FILE_SIZE,

            (uint_32)(search_data.DATE & MFS_MASK_MONTH) >> MFS_SHIFT_MONTH,
            (uint_32)(search_data.DATE & MFS_MASK_DAY)   >> MFS_SHIFT_DAY,
            (uint_32)((search_data.DATE & MFS_MASK_YEAR) >> MFS_SHIFT_YEAR) + 1980,

            (uint_32)(search_data.TIME & MFS_MASK_HOURS)   >> MFS_SHIFT_HOURS,
            (uint_32)(search_data.TIME & MFS_MASK_MINUTES) >> MFS_SHIFT_MINUTES,
            (uint_32)(search_data.TIME & MFS_MASK_SECONDS) << 1);
      } /* Endbody */

      error_code = ioctl(current_mfs, IO_IOCTL_FIND_NEXT_FILE,
        (uint_32_ptr) &search_data);
   } /* Endwhile */

   printf("--->%d files found", count);

   error_code = ioctl(current_mfs, IO_IOCTL_FIND_FIRST_FILE,
   (uint_32_ptr)&search);

   lfn_data.PATHNAME = search_data.NAME;
   lfn_data.LONG_FILENAME = lfn;
   count = 0;
   while (error_code == MFS_NO_ERROR) {
      if (available_space <= search_data.FILE_SIZE) { /* Body */
         printf("\n--->Not enough disk space on RAM storage to copy %s", search_data.NAME);
         break;
      } /* Endbody */
      available_space -= search_data.FILE_SIZE;
      if (search_data.FILE_SIZE != 0) { /* Body */
         // TODO: fix
//         error_code = Test_copy_file(current_mfs, (char_ptr)search_data.NAME);
         if (error_code) { /* Body */
            printf("\n--->Copying Failed! (0x%x)", error_code);
         } /* Endbody */
      } /* Endbody */

      error_code = ioctl(current_mfs, IO_IOCTL_FIND_NEXT_FILE,
        (uint_32_ptr) &search_data);
   } /* Endwhile */

   if ( error_code == MFS_FILE_NOT_FOUND ) {
      error_code = MFS_NO_ERROR;
   }/* Endif */

   return( error_code );

} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_change_directory_shell
* Returned Value   : uint_32 error_code
* Comments         :
*    This function changes the current directory.
*
*END*----------------------------------------------------------------------*/

uint_32  Test_change_directory_shell
   (
       FILE_PTR         current_mfs,
       char_ptr         dir_name
   )
{ /* Body */
   char                 pathname[PATHNAME_SIZE + 1];
   char                 current_dir[PATHNAME_SIZE + 1];
   char_ptr             temp_ptr;
   char                 c = 92; /* '\' */
   ioctl(current_mfs, IO_IOCTL_GET_CURRENT_DIR, &current_dir);

   if (strcmp(dir_name, "..") == 0) {
      /* remove the end directory */
      temp_ptr = strrchr(current_dir, c);
      temp_ptr++;
      *temp_ptr = '\0';
      sprintf(pathname, "%s%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir);
   } else {
      if (strlen(current_dir) < 2) {
         sprintf(pathname, "%s%s%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir, dir_name);
      } else {
         sprintf(pathname, "%s%s%c%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir,'\\', dir_name);
      } /* Endif */
   } /* Endif */

   return ioctl(current_mfs, IO_IOCTL_CHANGE_CURRENT_DIR, pathname);
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_fill_buffer
* Returned Value   :  void
* Comments  :   fills the contents of the read/write buffer with a
*               known sequence
*
*END*---------------------------------------------------------------------*/

void Test_fill_buffer
   (
        void
   )
{ /* Body */
   uint_32 i;
   uint_32 j;
   uint_32 test_pattern_size;
   char test_pattern[] = "Transdimension USB Now Integrated Hi-Speed USB2.0 On-The-Go IP Solution\n\r";

   test_pattern_size = strlen(test_pattern);
   j = 0;

   for ( i = 0; i < Test_Buffer_Size; i++ ) {
      Test_Buffer[i] = test_pattern[j];
      j++;
      if ( j >= test_pattern_size ) {
         j = 0;
      } /* Endif */
   } /* Endfor */

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Dump_memory
* Returned Value   : void
* Comments         :
*    This function dumps memory contents
*
*END*----------------------------------------------------------------------*/

void  Test_dump_memory
   (
       pointer    buffer,
       uint_32    length
   )
{ /* Body */
   char_ptr      phex, pchar;
   char          temp_str[17];
   char_ptr      str;
   uint_32       k;
   uint_16       i;
   uint_32       lines_displayed;


   phex = pchar = buffer;
   lines_displayed = 0;
   temp_str[16] = '\0';

   for (k = 0; k < length;) {

      printf ("%08lu  ", k);

      for (i = 0; i < 16; i++) {
         printf ("%02.2x ", (uint_32) (*phex++));
         k++;
      } /* Endfor */

      printf ("   ");

      str = temp_str;
      for (i = 0; i < 16; i++) {
         *str++ = (*pchar >= ' ') ? *pchar : '.';
         pchar++;
      } /* Endfor */

      printf("%s\n", temp_str);

      lines_displayed++;

      if (lines_displayed % 22 == 0) {
         printf ("Press any key to continue or ESC to stop\n");

         if (mfs_test_getchar() == 0x1b) {
            break;
         } /* Endif */
      } /* Endif */
   } /* Endfor */

} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_file_type
* Returned Value   :  FILE_PTR to the new file.
* Comments  :  Opens a file and returns it's FILE_PTR. Returns NULL if an
*              error occurs
*
*END*---------------------------------------------------------------------*/

uint_32  Test_file_display
   (
       FILE_PTR         current_mfs,
       char_ptr         file_name
   )
{ /* Body */
   FILE_PTR         fd_ptr= NULL;
   char             filepath[PATHNAME_SIZE + 1];
   char             current_dir[PATHNAME_SIZE + 1];
   uint_32          error, bytes, read_bytes;

   ioctl(current_mfs, IO_IOCTL_GET_CURRENT_DIR, &current_dir);

   if (strlen(current_dir) < 2) {
      sprintf(filepath, "%s%s%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir, file_name);
   } else {
      sprintf(filepath, "%s%s%c%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir,'\\', file_name);
   } /* Endif */
   fd_ptr = fopen(filepath, "r");
   if (fd_ptr == NULL) {
    error = MFS_FILE_NOT_FOUND;
    return error;
   } /* Endif */
   /* should get the number size of the file */

   read_bytes = bytes = fd_ptr->SIZE;

   while (bytes > 0) { /* Body */
      if (bytes >= Test_Buffer_Size) { /* Body */
         read_bytes = Test_Buffer_Size;
      } else { /* Body */
         read_bytes = bytes;
      } /* Endbody */
      //_mem_zero(Test_Buffer, sizeof(Test_Buffer));
      read(fd_ptr, Test_Buffer, read_bytes);
      Test_dump_memory(Test_Buffer+fd_ptr->SIZE-bytes, read_bytes);
      if (bytes >= Test_Buffer_Size) { /* Body */
         bytes -= Test_Buffer_Size;
      } else { /* Body */
         bytes -= read_bytes;
      } /* Endbody */
   } /* Endbody */

   fclose(fd_ptr);

   return(fd_ptr->ERROR);

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_delete_file
* Returned Value   : uint_32 error_code
* Comments         :
*    This deletes a file from the disk
*
*END*----------------------------------------------------------------------*/

uint_32  Test_delete_file
   (
         FILE_PTR    current_mfs,
         char_ptr    file_name
   )
{ /* Body */
   char              filepath[PATHNAME_SIZE + 1];
   char             current_dir[PATHNAME_SIZE + 1];

   ioctl(current_mfs, IO_IOCTL_GET_CURRENT_DIR, &current_dir);

   if (strlen(current_dir) < 2) {
      sprintf(filepath, "%s%s%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir, file_name);
   } else {
      sprintf(filepath, "%s%s%c%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir,'\\', file_name);
   } /* Endif */
   return ioctl(current_mfs, IO_IOCTL_DELETE_FILE, filepath);
} /* Endbody */



/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_write_file
* Returned Value   :  error code.
*
*END*---------------------------------------------------------------------*/

uint_32  Test_write_file
   (
       FILE_PTR         current_mfs,
       char_ptr         file_name
   )
{ /* Body */
   FILE_PTR         fd_ptr= NULL;
   char             filepath[PATHNAME_SIZE + 1];
   char             current_dir[PATHNAME_SIZE + 1];
   uint_32          error, bytes = 1000;
   char             c;

   ioctl(current_mfs, IO_IOCTL_GET_CURRENT_DIR, &current_dir);

   if (strlen(current_dir) < 2) {
      sprintf(filepath, "%s%s%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir, file_name);
   } else {
      sprintf(filepath, "%s%s%c%s", (current_mfs==A_FD_PTR)?"a:":"b:", current_dir,'\\', file_name);
   } /* Endif */

   fd_ptr = fopen(filepath, "r");
   if (fd_ptr) {
      printf("\nDo you want to overwrite existing files with same name? (Y/N)\n");
      c = mfs_test_getchar();
      if ( c == 'Y' ) {
         fclose(fd_ptr);
      } else  {
         error = MFS_NO_ERROR;
         return error;
      } /* Endif */
   } /* Endif */

   /* create a file  and over write it */
   fd_ptr = fopen(filepath, "w+");
   if (fd_ptr == NULL) {
      error = MFS_FILE_NOT_FOUND;
      return error;
   } /* Endif */
   Test_fill_buffer();
   bytes = write(fd_ptr, Test_Buffer, bytes);
   fclose(fd_ptr);
   return( fd_ptr->ERROR );
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_format_test
* Returned Value   :  error code.
*
*END*---------------------------------------------------------------------*/
uint_32  Test_format_test
   (
       FILE_PTR         current_mfs
   )
{ /* Body */
   MFS_IOCTL_FORMAT_PARAM     format_struct;
   uint_32                    bad_cluster_count;
   uint_32                    error_code;

   format_struct.FORMAT_PTR = &MFS_format;
   format_struct.COUNT_PTR = &bad_cluster_count;

   /* Formating */
   MFS_format.NUMBER_OF_SECTORS = RAMDISK_NUMBER_OF_SECTORS;
   error_code = ioctl(current_mfs, IO_IOCTL_FORMAT_TEST, (uint_32_ptr)&format_struct);
   if (error_code != MFS_NO_ERROR) {
      printf("\n%d bad cluster(s) found", bad_cluster_count);
   } else { /* Body */
      printf("\nNo bad clusters found.");
   } /* Endif */
   return(error_code);
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_set_mqx_date
* Returned Value   :  void
* Comments  :  This function sets MQX's internal clock (kernel time)
*
*END*---------------------------------------------------------------------*/

void  Test_set_mqx_date
   (
        void
   )
{ /* Body */
   TIME_STRUCT time;
   DATE_STRUCT clk_time;
   uint_32     w1,w2,w3;

   printf("\nWhat is the new date? (MM-DD-YYYY)\n");
   printf("eg:(05-10-2002)\n");

   scanf ("%d-%d-%d", &w1, &w2, &w3);

   clk_time.MONTH = (uint_16)w1;
   clk_time.DAY   = (uint_16)w2;
   clk_time.YEAR  = (uint_16)w3;

   printf("\nWhat is the new time? (HH-M-SS)\n");
   printf("eg:(05-10-45)\n");

   scanf ("%d-%d-%d", &w1, &w2, &w3);

   clk_time.HOUR   = (uint_16)w1;
   clk_time.MINUTE = (uint_16)w2;
   clk_time.SECOND = (uint_16)w3;

   _time_from_date(&clk_time, &time);
   _time_set(&time);

} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_display_mqx_date
* Returned Value   :  void
* Comments  :  This function displays MQX's internal clock (kernel time)
*
*END*---------------------------------------------------------------------*/

void  Test_display_mqx_date
   (
        void
   )
{ /* Body */
   TIME_STRUCT time;
   DATE_STRUCT clk_time;

   _time_get(&time);
   _time_to_date(&time, &clk_time);

   printf("Current Date (MM-DD-YYYY):\n");
   printf("%d-%d-%d\n",(uint_32)clk_time.MONTH,(uint_32)clk_time.DAY,
      (uint_32)clk_time.YEAR);

   printf("Current Time (HH:MM:SS)\n");
   printf("%d:%d:%d\n", (uint_32)clk_time.HOUR,(uint_32)clk_time.MINUTE,
      (uint_32)clk_time.SECOND);

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Test_setup_buffers
* Returned Value   :  error code.
*
*END*---------------------------------------------------------------------*/

uint_32  Test_setup_buffers
   (
       FILE_PTR         current_mfs
   )
{ /* Body */
   uint_32    error_code;

   printf("\nCurrent Buffer sizes:");
   printf("\n-Test_Buffer  is %d", Test_Buffer?Test_Buffer_Size/1024:0);
   printf("\n-Test_Buffer2 is %d", Test_Buffer2?Test_Buffer_Size/1024:0);
   if (Test_Buffer) {
      printf("\nFreeing Test_Buffer...");
      error_code = _mem_free(Test_Buffer);
      if (error_code != MQX_OK) {
         printf("\nError Freeing Memory (0x%x)", error_code);
      } else {
         Test_Buffer = NULL;
      } /* Endif */
   } /* Endif */

   if (Test_Buffer2) {
      printf("\nFreeing Test_Buffer2...");
      error_code = _mem_free(Test_Buffer2);
      if (error_code != MQX_OK) { /* Body */
         printf("\nError Freeing Memory (0x%x)", error_code);
      } else {
         Test_Buffer2 = NULL;
      } /* Endif */
   } /* Endif */

   printf("\nEnter size for Test_Buffer (in KBytes, default=%dK):",
      TEST_BUFFER_SIZE/1024);
   scanf ("%d", &Test_Buffer_Size);
   Test_Buffer_Size = Test_Buffer_Size * 1024;

   Test_Buffer = _mem_alloc_system(Test_Buffer_Size);
   if (Test_Buffer == NULL) { /* Body */
      printf("\nError allocating Memory for Test_Buffer (0x%x)", error_code);
   } /* Endif */

   printf("\nEnter new size for Test_Buffer2 (in KBytes, default=%dK):",
      TEST_BUFFER_SIZE/1024);
   scanf ("%d", &Test_Buffer_Size2);
   Test_Buffer_Size2 = Test_Buffer_Size2 * 1024;

   Test_Buffer2 = _mem_alloc_system(Test_Buffer_Size2);
   if (Test_Buffer2 == NULL) { /* Body */
      printf("\nError allocating Memory for Test_Buffer2 (0x%x)", error_code);
   } /* Endif */

   printf("\nNew Buffer sizes:");
   printf("\n-Test_Buffer  is %d", Test_Buffer?Test_Buffer_Size/1024:0);
   printf("\n-Test_Buffer2 is %d", Test_Buffer2?Test_Buffer_Size2/1024:0);

   return(0);

} /* Endbody */

extern FILE_PTR Dev_Handle1;

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  DosShell
* Returned Value   :  uint_32 error code
* Comments  :  emulate the behaviou of DOS
*
*END*---------------------------------------------------------------------*/

void  DosShell
   (
      uint_32 param
   )
{ /* Body */
   int_32            error_code;
   char              current_dir[PATHNAME_SIZE + 1];
   char              string[64];
   char_ptr          arg0, arg1, arg2, arg3;
   FILE_PTR          current_mfs = A_FD_PTR;

   Test_Buffer_Size = TEST_BUFFER_SIZE;
   Test_Buffer = NULL;
   Test_Buffer2 = NULL;

   Test_Buffer = _mem_alloc_system(Test_Buffer_Size);
   if (Test_Buffer == NULL) { /* Body */
      printf("\nError allocating Memory for Test_Buffer (0x%x)", error_code);
   } /* Endif */

#if 0 // Don't allocated initially, will be allocated and de-allocated as needed
   Test_Buffer2 = _mem_alloc_system(Test_Buffer_Size);
   if (Test_Buffer2 == NULL) { /* Body */
      printf("\nError allocating Memory for Test_Buffer2 (0x%x)", error_code);
   } /* Endif */
#endif

#if 0
   printf("\nCopying of files will start in a few seconds....");
   printf("\n\t *** press any key to DISABLE ***");
   _time_delay(3000);
   if (!status()) { /* Body */
      Test_process_camera(current_mfs, CAMERA_DIRECTORY);
   } /* Endif */
#endif
   error_code = fclose(A_FD_PTR);
   if ( error_code != IO_OK ) {
      printf("\nError closing RAM drive: 0x%X.", error_code);
   } /* Endif */
   error_code = _io_mfs_uninstall("a:");
   if (error_code != MFS_NO_ERROR) {
      printf("\nError while uninstalling MFS from RAM device");
   } /* Endif */

   error_code = _io_mfs_install(Dev_Handle1, "a:", 0);
   if (error_code != MFS_NO_ERROR) {
      printf("\nError initialising a:");
      _task_block();
   } else {
      printf("\n--->Refreshed RAM Disk a:\\");
   } /* Endif */

   A_FD_PTR = fopen("a:", 0);
   if ( A_FD_PTR == NULL) { 
      printf("\nError opening RAM drive: 0x%X.", error_code);
   } /* Endif */ 

   error_code = ioctl(A_FD_PTR, IO_IOCTL_FAT_CACHE_OFF, NULL);
   if (error_code != MFS_NO_ERROR) {
      printf("\nError while turning of FAT cache (%s)", Error_text(error_code));
      _task_block();
   } /* Endif */
   error_code = ioctl(A_FD_PTR, IO_IOCTL_WRITE_CACHE_OFF, NULL);
   if (error_code != MFS_NO_ERROR) {
      printf("\nError while turning of WRITE cache (%s)", Error_text(error_code));
      _task_block();
   } /* Endif */

   if(current_mfs != B_FD_PTR) { /* Body */
      current_mfs = A_FD_PTR;
   } /* Endbody */

   while (TRUE) {
      error_code = MFS_NO_ERROR;
      ioctl(current_mfs, IO_IOCTL_GET_CURRENT_DIR, &current_dir);

      printf("\n%s%s>", ((current_mfs==A_FD_PTR)?"a:\\":"b:\\"), current_dir);
#if (TEST_WITH_SIMULATOR == 1)
      fflush(stdout);
#endif

      if (!fgets(string, sizeof(string), stdin)) {
         break;
      } /* Endif */

      arg0 = string;
      while (*arg0 && !isgraph(*arg0)) arg0++;
      if (!*arg0) continue;

      arg1 = arg0;
      while (isgraph(*arg1)) arg1++;
      if (*arg1) *arg1++ = '\0';
      while (*arg1 && !isgraph(*arg1)) arg1++;

      if (!*arg1) {
         arg1 = NULL;
      } else {
         arg2 = arg1;
         while (isgraph(*arg2)) arg2++;
         if (*arg2) *arg2++ = '\0';
         while (*arg2 && !isgraph(*arg2)) arg2++;
         if (!*arg2) {
            arg2 = NULL;
         } else {
            arg3 = arg2;
            while (isgraph(*arg3)) arg3++;
            *arg3 = '\0';
         } /* Endif */
      } /* Endif */

      if (strcmp(arg0, "a:") == 0) {
         if (A_FD_PTR) {
            current_mfs = A_FD_PTR;
         } /* Endif */
      } else if (strcmp(arg0, "b:") == 0) {
         if (B_FD_PTR) {
            current_mfs = B_FD_PTR;
         } /* Endif */
      } else if (strcmp(arg0, "dir") == 0) {
         error_code = Test_dir_list(current_mfs);

      } else if (strcmp(arg0, "cd") == 0) {
         error_code = Test_change_directory_shell(current_mfs,arg1);
      } else if (strcmp(arg0, "cd..") == 0) {
         arg1 = "..";
         error_code = Test_change_directory_shell(current_mfs,arg1);
      } else if (strcmp(arg0, "mkdir") == 0) {
         error_code = Test_create_subdir_shell(current_mfs,arg1);
      } else if (strcmp(arg0, "rmdir") == 0) {
         error_code = Test_remove_subdir(current_mfs,arg1);

      } else if (strcmp(arg0, "type") == 0) {
         error_code = Test_file_display(current_mfs,arg1);
      } else if (strcmp(arg0, "write") == 0) {
         error_code = Test_write_file(current_mfs,arg1);
      } else if (strcmp(arg0, "copy") == 0) {
         error_code = Test_copy_file(current_mfs,arg1,arg2);
      } else if (strcmp(arg0, "diff") == 0) {
         error_code = Test_compare_file(current_mfs,arg1);
      } else if (strcmp(arg0, "del") == 0) {
         error_code = Test_delete_file(current_mfs,arg1);
      } else if (strcmp(arg0, "delete") == 0) {
         error_code = Test_delete_file(current_mfs,arg1);
      } else if (strcmp(arg0, "format") == 0) {
         error_code = Test_format_disk(current_mfs);
      } else if (strcmp(arg0, "formattest") == 0) {
         error_code = Test_format_test(current_mfs);

      } else if (strcmp(arg0, "mem") == 0) {
         printf("\n_mem_get_highwater = 0x%x", _mem_get_highwater());
         printf("\nFree system memory =  %dK",
            ((uint_32)MQX_init_struct.END_OF_KERNEL_MEMORY-(uint_32)_mem_get_highwater())/1024);
      } else if (strcmp(arg0, "buffers") == 0) {
         error_code = Test_setup_buffers(current_mfs);
      } else if (strcmp(arg0, "throughput") == 0) {
         error_code = Test_throughput(current_mfs, arg1);
      } else if (strcmp(arg0, "through") == 0) {
         error_code = Test_throughput(current_mfs, arg1);
      } else if (strcmp(arg0, "throu") == 0) {
         error_code = Test_throughput(current_mfs, arg1);
      } else if (strcmp(arg0, "thr") == 0) {
         error_code = Test_throughput(current_mfs, arg1);
      } else if (strcmp(arg0, "th") == 0) {
         error_code = Test_throughput(current_mfs, arg1);

      } else if (strcmp(arg0, "camera") == 0) {
         Test_process_camera(current_mfs, CAMERA_DIRECTORY);

      } else if ((strcmp(arg0, "help") == 0) || (arg0[0] == '?')) {

         printf("Available commands:\n");

         printf("\ta:             \t\tChange to RAM Drive\n");
         printf("\tb:             \t\tChange to Removable Drive\n");
         printf("\tdir            \t\tList the current directory\n");
         printf("\tcd <directory> \t\tchange directory\n");
         printf("\tmkdir <directory> \tCreate a sub directory\n");
         printf("\trmdir <directory> \tRemove a sub directory\n");

         printf("\ttype <filename> \ttype a file to the terminal\n");
         printf("\twrite <filename>\tCreate a file and fill with Transdimension.\n");
         printf("\tcopy <from> <to>\tCopy a file to the other Drive.\n");
         printf("\tdiff <filename> \tCompare file on current Drive to one on other Drive.\n");
         printf("\tdel <filename>  \tDeleate a file\n");

         printf("\tset date       \t\tSet the current date and time\n");
         printf("\tget date       \t\tGet the current date and time\n");
         printf("\thelp           \t\tDisplay Help information\n");
         printf("\teject          \t\tEject the disk\n");
         printf("\thnp            \t\tAttempt an HNP with device\n");
         printf("\tmem            \t\tCheck highest MQX memory used\n");
         printf("\tthroughput <filename> \tMeasure throughput\n");


      } else if (strcmp(arg0, "set") == 0) {
         if (strcmp(arg1, "date") == 0) {
            Test_set_mqx_date();
         } else {
            printf("\tset what??\n");
         } /* Endif */
      } else if (strcmp(arg0, "get") == 0) {
         if (strcmp(arg1, "date") == 0) {
            Test_display_mqx_date();
         } else {
            printf("\tget what??\n");
         } /* Endif */

      } else if (strcmp(arg0, "eject") == 0) {
         if (current_mfs == A_FD_PTR) {
            current_mfs = B_FD_PTR;
         } else {
            break;
         } /* Endif */

      } else if (strcmp(arg0, "hnp") == 0) {
            HNP_ATTEMPTED = TRUE;
            break;

      } else {
         printf("\nInvalid command.  Type 'help' for a list of commands.");
      } /* Endif */

      if ( error_code != MFS_NO_ERROR ) {
         printf("\n%s(%d)", Error_text(error_code), error_code);
      } /* Endif */
   } /* Endwhile */

} /* EndBody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  mfs_test_getchar
* Returned Value   :
* Comments  :  Displays a help menu.
*
*END*---------------------------------------------------------------------*/
int_32  mfs_test_getchar
   (
      void
   )
{
   char answer;

   answer = getchar();
//   putchar(8);
   answer = CAPITALIZE(answer);
   return( answer );
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    :  Error_text
* Returned Value   : char_ptr
* Comments         :
*    Takes a MFS error code and returns the error description ptr.
*
*END*----------------------------------------------------------------------*/

char_ptr  Error_text
   (
       uint_32 error_code
   )
{ /* Body */

   switch (error_code) {
      case MFS_NO_ERROR :
         return ("MFS NO ERROR");
      case MFS_INVALID_FUNCTION_CODE :
         return ("MFS INVALID FUNCTION CODE");
      case MFS_FILE_NOT_FOUND :
         return ("MFS FILE NOT FOUND");
      case MFS_PATH_NOT_FOUND :
         return ("MFS PATH NOT FOUND");
      case MFS_ACCESS_DENIED :
         return ("MFS ACCESS DENIED");
      case MFS_INVALID_HANDLE :
         return ("MFS INVALID HANDLE");
      case MFS_INSUFFICIENT_MEMORY :
         return ("MFS INSUFFICIENT MEMORY");
      case MFS_INVALID_MEMORY_BLOCK_ADDRESS :
         return ("MFS INVALID MEMORY BLOCK ADDRESS");
      case MFS_ATTEMPT_TO_REMOVE_CURRENT_DIR :
         return ("MFS ATTEMPT TO REMOVE CURRENT DIR");
      case MFS_DISK_IS_WRITE_PROTECTED :
         return ("MFS DISK IS WRITE PROTECTED");
      case MFS_BAD_DISK_UNIT :
         return ("MFS BAD DISK UNIT");
      case MFS_INVALID_LENGTH_IN_DISK_OPERATION:
         return("MFS INVALID LENGTH IN DISK OPERATION" );
      case MFS_NOT_A_DOS_DISK :
         return ("MFS NOT A DOS DISK");
      case MFS_SECTOR_NOT_FOUND :
         return ("MFS SECTOR NOT FOUND");
      case MFS_WRITE_FAULT :
         return ("MFS WRITE FAULT");
      case MFS_READ_FAULT :
         return ("MFS READ FAULT");
      case MFS_SHARING_VIOLATION :
         return ("MFS SHARING VIOLATION");
      case MFS_FILE_EXISTS :
         return ("MFS FILE EXISTS");
      case MFS_ALREADY_ASSIGNED :
         return ("MFS ALREADY ASSIGNED");
      case MFS_INVALID_PARAMETER :
         return ("MFS INVALID PARAMETER");
      case MFS_DISK_FULL :
         return ("MFS DISK FULL");
      case MFS_ROOT_DIR_FULL:
         return("MFS ROOT DIR FULL");
      case MFS_EOF :
         return ("MFS EOF");
      case MFS_CANNOT_CREATE_DIRECTORY:
         return ("MFS CANNOT CREATE DIRECTORY");
      case MFS_NOT_INITIALIZED:
         return( "MFS NOT INITIALIZED" );
      case MFS_OPERATION_NOT_ALLOWED:
         return ("MFS OPERATION NOT ALLOWED");
      case MFS_ERROR_INVALID_DRIVE_HANDLE:
         return("MFS INVALID DRIVE HANDLE" );
      case MFS_ERROR_INVALID_FILE_HANDLE:
         return( "MFS INVALID FILE HANDLE" );
      case MFS_ERROR_UNKNOWN_FS_VERSION:
         return( "MFS UNKNOWN FILESYSTEM VERSION" );
      default: return ("UNKNOWN ERROR !!!");
   } /* Endswitch */

} /* Endbody */

/* EOF */
