/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file is an example of device drivers for a Mouse device.
*** It has been tested in a Dell USB 3 button wheel Mouse. The program
*** queues transfers on Interrupt USB pipe and waits till the data comes
*** back. It prints the data and queues another transfer on the same pipe.
*** See the code for details.
***
**************************************************************************
**END*********************************************************/
#include "hidmouse.h"
#include "usb_hid.h"


#ifdef __USB_OS_MQX__
#include "bsp.h"
#include "mqx_arc.h"
#include "fio.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif
#include "stdlib.h"
#endif



/************************************************************************************
**
** Globals
************************************************************************************/

volatile boolean Interrupt_received = FALSE; /* This boolean controls queuing of transfers */

volatile DEVICE_STRUCT  hid_device = { 0 };  /* structure defined by this driver */

volatile uint_32        hid_conf_phase = 0;  /*simple integer to track phases    */

_usb_host_handle        host_handle;         /* global handle for calling host   */

/************************************************************************************
Table of driver capabilities this application wants to use. See Host API document for
details on How to define a driver info table. This table defines that this driver
supports a HID class, boot subclass and mouse protocol. 
************************************************************************************/

static  USB_HOST_DRIVER_INFO DriverInfoTable[] =
{
   {
      {0x00,0x00},                  /* Vendor ID per USB-IF             */
      {0x00,0x00},                  /* Product ID per manufacturer      */
      USB_CLASS_HID,                /* Class code                       */
      USB_SUBCLASS_HID_BOOT,        /* Sub-Class code                   */
      USB_PROTOCOL_HID_MOUSE,       /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_hid_mouse_event      /* Application call back function   */
   },
   {
      {0x00,0x00},                  /* All-zero entry terminates        */
      {0x00,0x00},                  /* driver info list.                */
      0,
      0,
      0,
      0,
      NULL
   }
};



#ifdef __USB_OS_MQX__
#define MAIN_TASK          (10)
extern void Main_Task(uint_32 param);
TASK_TEMPLATE_STRUCT  MQX_template_list[] =
{
   { MAIN_TASK,      Main_Task,      3000L,  7L, "Main",      MQX_AUTO_START_TASK},
   { 0L,             0L,             0L,     0L, 0L,          0L }
};
#endif


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : main (Main_Task if using MQX)
* Returned Value : none
* Comments       :
*     Execution starts here
*
*END*--------------------------------------------------------------------*/

#ifdef __USB_OS_MQX__
void Main_Task ( uint_32 param )
#else
void main (void)
#endif

{ /* Body */
   USB_OTG_INIT_STRUCT  otg_init;
   _usb_otg_handle      otg_handle1;
   _usb_pipe_handle     pipe;
   TR_INIT_PARAM_STRUCT tr,tr1,tr2;
   HID_COMMAND          hid_com;
   uchar_ptr            buffer;
   char                 c;
   USB_STATUS           status = USB_OK;
   uint_32              state=0;
   uint_32              last_state= 0xFFFF; /*used just to avoid too much printing */


   /* default configuration: A = host, B = peripheral */
   otg_init.A_BUS_DROP  = FALSE;
   otg_init.A_BUS_REQ   = TRUE;
   otg_init.B_BUS_REQ   = FALSE;
   otg_init.SERVICE     = otg_service;

   /* _usb_otg_init needs to be done with interrupts disabled */
   USB_lock();
   
#ifdef __USB_OS_MQX__
   _int_install_unexpected_isr();
   _usb_driver_install(0, &_bsp_usb_callback_table);
#endif

   /*
   ** Initialize the USB interface, causing a call back to the otg_service
   ** routine
   */
   status = _usb_otg_init(0, &otg_init, &otg_handle1);
   if (status != USB_OK) {
      printf("\nUSB OTG Initialization failed. Error Status: %x", status);
      fflush(stdout);
      exit(1);
   } /* Endif */

   USB_unlock();

   buffer = USB_memalloc(HID_BUFFER_SIZE);
   if (!buffer) {
      printf("\nError allocating buffer!");
      fflush(stdout);
      exit(1);
   } /* Endif */

   /*
   ** Infinite loop, waiting for events requiring action
   */
   for ( ; ; ) {
   
      /***************************************************
      First check for OTG state and ensure that we are
      not in A_IDLE state.As long as stay in A_IDLE,
      just print once the message 'Press 'v' to turn on VBus'
      ***************************************************/
      _usb_otg_get_status(otg_handle1, USB_OTG_STATE, &state);
      if (state == A_IDLE) 
      {

            if(last_state != A_IDLE)
            {
               printf("A_IDLE\n");
               printf("A_IDLE:  Press 'v' to turn on VBus.\n");
            }
            if(status())
            {
               c = getchar();
               if ((c == 'v') || (c == 'V'))
               {
                  printf("'v' pressed:  Turning on VBus\n");
                  _usb_otg_set_status(otg_handle1, USB_OTG_A_BUS_REQ, TRUE);
               }
               else
               {
                  last_state = 0xFFFF;
               }
             }

          last_state = state;

      }
      else /*if we leave A_IDLE state, we should reset the last_state */
      {
          last_state = 0xFFFF;
      }

      /***************************************************
      Now proceed with examining the event that occured
      if any.
      ***************************************************/
      
      switch ( hid_device.DEV_STATE ) {
         case USB_DEVICE_IDLE:
            break;
         case USB_DEVICE_ATTACHED:
            printf("\nHid device attached\n");
            hid_device.DEV_STATE = USB_DEVICE_SET_INTERFACE_STARTED;
            status = _usb_hostdev_select_interface(hid_device.DEV_HANDLE,
               hid_device.INTF_HANDLE, (pointer)&hid_device.CLASS_INTF);
              if (status != USB_OK) {
               printf("\nError in _usb_hostdev_select_interface: %x", status);
               fflush(stdout);
               exit(1);
            } /* Endif */
            break;
         case USB_DEVICE_SET_INTERFACE_STARTED:
            break;
         case USB_DEVICE_INTERFACED:
            if (!hid_conf_phase) 
            {
               hid_com.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&hid_device.CLASS_INTF;
               hid_com.CALLBACK_PARAM = 0;
#if 0
               hid_com.CALLBACK_FN = usb_host_hid_ctrl_callback;
               hid_conf_phase = 1;

//             status = usb_class_hid_set_protocol(&hid_com, USB_HID_PROTOCOL_BOOT);
               status = usb_class_hid_set_idle(&hid_com,0,0);
               if (status != USB_STATUS_TRANSFER_QUEUED) {
                  printf("\nError in usb_class_hid_set_protocol: %x", status);
                  fflush(stdout);
                  exit(1);
               } /* Endif */
#else
               hid_conf_phase = 2;

               usb_class_hid_set_idle(&hid_com,0,0);
#endif
            } else if (hid_conf_phase == 1) 
            {
               /* Do nothing */
            } 
            
            else 
            
            {
               pipe = _usb_hostdev_find_pipe_handle(hid_device.DEV_HANDLE,
               hid_device.INTF_HANDLE, USB_INTERRUPT_PIPE, USB_RECV);
               if (pipe) 
               {

                  usb_hostdev_tr_init(&tr, usb_host_hid_recv_callback, NULL);
                  tr.RX_BUFFER = buffer;
                  tr.RX_LENGTH = HID_BUFFER_SIZE;
                  status = _usb_host_recv_data(host_handle, pipe, &tr);
                  if (status != USB_STATUS_TRANSFER_QUEUED) {
                  printf("\nError in _usb_host_recv_data: %x", status);
                  fflush(stdout);
                  exit(1);
                  } 

                  /******************************************************************
                   Wait in a loop till we get the data from mouse. Note that this
                   is not necessary to loop and an application could proceed and
                   do something else. It will notified when the transfer is complete
                   when the callback comes in the routine registered by driver info
                   table at the top of this file.
                  ******************************************************************/

                  while ((Interrupt_received == FALSE) && 
                        (hid_device.DEV_STATE != USB_DEVICE_DETACHED))
                  {;}

                  /*print the data received from the mouse */
               
                  /*****************************************************
                  The following will print the data in numbers                  
                  ******************************************************/
               
                  /*****************************************************
                  if (buffer[0] & 0x01) printf("1 ");
                  else printf("0 ");
                  if (buffer[0] & 0x02) printf("1 ");
                  else printf("0 ");
                  if (buffer[0] & 0x04) printf("1 ");
                  else printf("0 ");

                  printf("X:%d ", buffer[1]);
                  printf("Y:%d ", buffer[2]);
                  printf("Z:%d ", buffer[3]);
                  printf("\n");
                  fflush(stdout);
                  ******************************************************/


                  /*****************************************************
                  The following will print the data in text strings                  
                  ******************************************************/

               
                  if (buffer[0] & 0x01) printf("Left Click ");
                  else printf("           ");
                  if (buffer[0] & 0x02) printf("Right Click ");
                  else printf("            ");
                  if (buffer[0] & 0x04) printf("Middle Click ");
                  else printf("             ");

                  if(buffer[1]) 
                  { 
                     if(buffer[1] > 127) printf("Left  ");
                     else printf("Right ");
                  }
                  else { printf("      ");}
               
                  if(buffer[2]) 
                  { 
                     if(buffer[2] > 127) printf("UP   ");
                     else printf("Down ");
                  }
                  else { printf("     ");}
               
                   if(buffer[3]) 
                  { 
                     if(buffer[3] > 127) printf("Wheel Down");
                     else printf("Wheel UP  ");
                  }
                  else { printf("          ");}

                  printf("\n");
                  fflush(stdout);
               
                  Interrupt_received = FALSE;
               
               } //end if pipe
            }
            break;
         case USB_DEVICE_DETACHED:
            printf("\nHid device detached\n");
            hid_device.DEV_STATE = USB_DEVICE_IDLE;
            break;
         case USB_DEVICE_OTHER:
            break;
         default:
            printf("Unknown Mouse Device State = %d\n", hid_device.DEV_STATE);
            fflush(stdout);
            break;
      } /* Endswitch */
   } /* Endfor */
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : otg_service
* Returned Value : None
* Comments       :
*     Called upon  OTG service state change.
*
*END*--------------------------------------------------------------------*/

static void otg_service
   (
      /* [IN] Handle to make OTG calls*/
      _usb_otg_handle    otg_handle,

      /* event on the OTG stack       */
      uint_32            event
   )
{ /* Body */
   uint_32              state;
   USB_STATUS           status = USB_OK;

   switch (event) {
      case USB_OTG_HOST_UP:

         /*
         ** It means that we are going to act like host, so we initialize the
         ** host stack. This call will allow USB system to allocate memory for
         ** data structures, it uses later (e.g pipes etc.).
         */
         status = _usb_host_init
            (HOST_CONTROLLER_NUMBER,   /* Use value in header file */
             MAX_FRAME_SIZE,            /* Frame size per USB spec  */
             &host_handle);             /* Returned pointer */

         if (status != USB_OK) {
            printf("\nUSB Host Initialization failed. STATUS: %x", status);
            fflush(stdout);
            return;
         } /* Endif */

         /*
         ** since we are going to act as the host driver, register the driver
         ** information for wanted class/subclass/protocols
         */
         status = _usb_host_driver_info_register
            (host_handle,
             DriverInfoTable);
         if (status != USB_OK) {
            printf("\nDriver Registration failed. STATUS: %x", status);
            fflush(stdout);
            return;
         } else {
            /* Success, set OTG state to active */
            _usb_otg_set_status(otg_handle, USB_OTG_HOST_ACTIVE, TRUE);
            _usb_otg_get_status(otg_handle, USB_OTG_STATE, &state);
            if (state < B_IDLE) {
               _usb_otg_set_status(otg_handle, USB_OTG_A_BUS_DROP, FALSE);
               _usb_otg_set_status(otg_handle, USB_OTG_A_BUS_REQ, TRUE);
            } /* Endif */
         } /* Endif */
         break;
      case USB_OTG_DEVICE_UP:
         break;
      case USB_OTG_HOST_DOWN:
         break;
      case USB_OTG_DEVICE_DOWN:
         break;
      case USB_OTG_SRP_ACTIVE:
         break;
      case USB_OTG_SRP_FAIL:
         break;
      case USB_OTG_OVER_CURRENT:
         break;
      default:
         break;
   } /* Endswitch */
   return;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_hid_mouse_event
* Returned Value : None
* Comments       :
*     Called when HID device has been attached, detached, etc.
*END*--------------------------------------------------------------------*/

void usb_host_hid_mouse_event
   (
      /* [IN] pointer to device instance */
      _usb_device_instance_handle      dev_handle,

      /* [IN] pointer to interface descriptor */
      _usb_interface_descriptor_handle intf_handle,

      /* [IN] code number for event causing callback */
      uint_32                          event_code
   )
{ /* Body */
   INTERFACE_DESCRIPTOR_PTR   intf_ptr =
      (INTERFACE_DESCRIPTOR_PTR)intf_handle;

   fflush(stdout);
   switch (event_code) {
      case USB_CONFIG_EVENT:
         /* Drop through into attach, same processing */
      case USB_ATTACH_EVENT:
         /******************************************************
         This code is being executed under an attach interupt
         and so Print the following only if printing is allowed
         under an interrupt.
         /******************************************************/
         
         #if 0
         fflush(stdout);
         printf("State = %d", hid_device.DEV_STATE);
         printf("  Class = %d", intf_ptr->bInterfaceClass);
         printf("  SubClass = %d", intf_ptr->bInterfaceSubClass);
         printf("  Protocol = %d\n", intf_ptr->bInterfaceProtocol);
         fflush(stdout);
        #endif
         if (hid_device.DEV_STATE == USB_DEVICE_IDLE) {
            hid_device.DEV_HANDLE = dev_handle;
            hid_device.INTF_HANDLE = intf_handle;
            hid_device.DEV_STATE = USB_DEVICE_ATTACHED;
         } else {
            printf("HID device already attached\n");
            fflush(stdout);
         } /* Endif */
         break;
      case USB_INTF_EVENT:
         hid_device.DEV_STATE = USB_DEVICE_INTERFACED;
         break ;
      case USB_DETACH_EVENT:
         /******************************************************
         This code is being executed under an attach interupt
         and so Print the following only if printing is allowed
         under an interrupt.
         /******************************************************/
         
         #if 0
         /* Use only the interface with desired protocol */
         printf("----- Detach Event -----\n");
         fflush(stdout);
         printf("State = %d", hid_device.DEV_STATE);
         printf("  Class = %d", intf_ptr->bInterfaceClass);
         printf("  SubClass = %d", intf_ptr->bInterfaceSubClass);
         printf("  Protocol = %d\n", intf_ptr->bInterfaceProtocol);
         fflush(stdout);
         #endif
         
         if (hid_device.DEV_STATE == USB_DEVICE_INTERFACED) {
            hid_device.DEV_HANDLE = NULL;
            hid_device.INTF_HANDLE = NULL;
            hid_device.DEV_STATE = USB_DEVICE_DETACHED;
         } else {
            printf("HID Device Not Attached\n");
            fflush(stdout);
         } /* Endif */
         break;
      default:
         printf("HID Device state = %d??\n", hid_device.DEV_STATE);
         fflush(stdout);
         hid_device.DEV_STATE = USB_DEVICE_IDLE;
         break;
   } /* EndSwitch */
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_hid_ctrl_callback
* Returned Value : None
* Comments       :
*     Called when a command is completed
*END*--------------------------------------------------------------------*/

void usb_host_hid_ctrl_callback
   (
      /* [IN] pointer to pipe */
      _usb_pipe_handle  pipe_handle,

      /* [IN] user-defined parameter */
      pointer           user_parm,

      /* [IN] buffer address */
      uchar_ptr         buffer,

      /* [IN] length of data transferred */
      uint_32           buflen,

      /* [IN] status, hopefully USB_OK or USB_DONE */
      uint_32           status
   )
{ /* Body */

   if (status) {
      printf("\nHID Set_Protocol Request BOOT failed!: %x", status);
      fflush(stdout);
      exit(1);
   } /* Endif */

   hid_conf_phase++;

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_hid_recv_callback
* Returned Value : None
* Comments       :
*     Called when data is received on a pipe
*END*--------------------------------------------------------------------*/

void usb_host_hid_recv_callback
   (
      /* [IN] pointer to pipe */
      _usb_pipe_handle  pipe_handle,

      /* [IN] user-defined parameter */
      pointer           user_parm,

      /* [IN] buffer address */
      uchar_ptr         buffer,

      /* [IN] length of data transferred */
      uint_32           buflen,

      /* [IN] status, hopefully USB_OK or USB_DONE */
      uint_32           status
   )
{ /* Body */
   Interrupt_received = TRUE;
   if ((status != USB_OK) | (buflen < 3)) 
   {
      printf("\nTransfer failed!: %x", status);
      fflush(stdout);

   }

}



/* EOF */

