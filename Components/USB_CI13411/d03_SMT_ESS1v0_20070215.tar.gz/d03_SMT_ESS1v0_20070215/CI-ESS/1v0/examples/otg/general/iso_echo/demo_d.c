/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***  This file handles the device functioality of the OTG application
***
**************************************************************************
**END*********************************************************/

/**************************************************************************
Include the USB stack header files.
**************************************************************************/

#ifdef __USB_OTG__
#include "otgapi.h"
#else
#include "hostapi.h"
#include "devapi.h"
#endif

/**************************************************************************
Local header files for this application
**************************************************************************/

#include "demo.h"
#include "demo_d.h"
#include "demo_h.h"

/**************************************************************************
Include the OS and BSP dependent files that define IO functions and
basic types. You may like to change these files for your board and RTOS 
**************************************************************************/

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
   #include "fio.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif
   #include "stdlib.h"
   #include "string.h"
#endif

#include "string.h"

/**************************************************************************
global variables and some defines for device.
**************************************************************************/


/* choose the endpoint to echo 
#define  ECHO_ENDPOINT       USB_CONTROL_ENDPOINT
#define  ECHO_ENDPOINT       USB_ISOCHRONOUS_ENDPOINT
#define  ECHO_ENDPOINT       USB_BULK_ENDPOINT
#define  ECHO_ENDPOINT       USB_INTERRUPT_ENDPOINT
*/

uchar    ECHO_ENDPOINT_BUFFER_1[1000];
uchar    ECHO_ENDPOINT_BUFFER_2[1000];
uchar    ECHO_ENDPOINT_RECV_BUFFER[1000];

boolean  toggle_buffer = FALSE;
//boolean  ECHO_PACKET_RECEIVED = FALSE;

extern _usb_otg_handle                    app_otg_handle;
extern _usb_device_handle                 dev_handle;


volatile boolean OKAY_TO_DO_HNP = FALSE;
volatile uchar    device_speed = 0;

extern APP_GLOBAL_STRUCT app_test_struct;

/*The following global variables are used for USB electrical testing 
in which device should switch to test mode under a control command*/

volatile boolean  ENTER_TEST_MODE = FALSE; 
volatile uint_16  test_mode_index = 0;


/**************************************************************************
DESCRIPTORS DESCRIPTORS DESCRIPTORS DESCRIPTORS DESCRIPTORS DESCRIPTORS
**************************************************************************/
#define DEVICE_DESCRIPTOR_SIZE 18

/* Device descriptors are always 18 bytes */
uint_8  DevDesc[DEVICE_DESCRIPTOR_SIZE] =
{
   /* Length of DevDesc */
   DEVICE_DESCRIPTOR_SIZE,
   /* "Device" Type of descriptor */
   1,
   /* BCD USB version */
   0, 2,
   /* Device Class is indicated in the interface descriptors */
   0x00,
   /* Device Subclass is indicated in the interface descriptors */
   0x00,
   /* Mass storage devices do not use class-specific protocols */
   0x00,
   /* Max packet size */
   APP_CONTROL_MAX_PKT_SIZE,
   /* Vendor ID */
   USB_uint_16_low(0x0B20), USB_uint_16_high(0x0B20),
   /* Product ID */
   USB_uint_16_low(0x4), USB_uint_16_high(0x4),
   /* BCD Device version */
   USB_uint_16_low(0x0002), USB_uint_16_high(0x0002),
   /* Manufacturer string index */
   0x1,
   /* Product string index */
   0x2,
   /* Serial number string index */
   0x0,
   /* Number of configurations available */
   0x1
};

/* USB 2.0 specific descriptor */
#define DEVICE_QUALIFIER_DESCRIPTOR_SIZE 10
uint_8  DevQualifierDesc[DEVICE_QUALIFIER_DESCRIPTOR_SIZE] =
{
   DEVICE_QUALIFIER_DESCRIPTOR_SIZE,  /* bLength Length of this descriptor */
   6,                         /* bDescType This is a DEVICE Qualifier descr */
   0,2,                       /* bcdUSB USB revision 2.0 */
   0,                         /* bDeviceClass */
   0,                         /* bDeviceSubClass */
   0,                         /* bDeviceProtocol */
   APP_CONTROL_MAX_PKT_SIZE,  /* bMaxPacketSize0 */
   0x01,                      /* bNumConfigurations */
   0
};

#define CONFIG_DESC_NUM_INTERFACES  (1)
/* This must be counted manually and updated with the descriptor */
/* 1*Config(9) + 1*Interface(9) + 2*Endpoint(9) + 3 bytes OTG = 39 bytes */
#define CONFIG_DESC_SIZE            (39)

uint_8 ConfigDesc[CONFIG_DESC_SIZE] =
{
   /**************************************************
      CONFIGURATION DESCRIPTOR
   **************************************************/
   
   /* Configuration Descriptor - always 9 bytes */
   9,
   /* "Configuration" type of descriptor */
   2,
   /* Total length of the Configuration descriptor */
   USB_uint_16_low(CONFIG_DESC_SIZE), USB_uint_16_high(CONFIG_DESC_SIZE),
   /* NumInterfaces */
   1,
   /* Configuration Value */
   1,
   /* Configuration Description String Index*/
   4,
   /* Attributes.  Self-powered */
   0xc0,
   /* Current draw from bus */
   1,
   
   /**************************************************
      INTERFACE DESCRIPTOR
   **************************************************/
   
   /* Interface 0 Descriptor - always 9 bytes */
   9,
   /* "Interface" type of descriptor */
   4,
   /* Number of this interface */
   0,
   /* Alternate Setting */
   0,
   /* Number of endpoints on this interface */
   2,
   /* Interface Class audio*/
   0x01,
   /* Interface Subclass: streaming */
   0x02,
   /* Interface Protocol: none */
   0x00,
   /* Interface Description String Index */
   0,

   /**************************************************
      ENDPOINT DESCRIPTOR
   **************************************************/
   9,         /* bLength   Length of this descriptor */

   5,         /* bDescType   5=ENDPOINT */

   /*
   ** Endpoint address.  The low nibble contains the endpoint number and the
   ** high bit indicates TX(1) or RX(0).
   */
   0x81,

   0x09,      /* bmAttr   ISO adaptive rate */

   /* Max Packet Size for this endpoint */
   USB_uint_16_low(EP1_HS_MAX_PACKET_SIZE),

   USB_uint_16_high(EP1_HS_MAX_PACKET_SIZE),

   ISO_INTERVAL,         /* bInterval */

   0,         /* bRefresh */

   0,         /* SyncAddr   None */

   /**************************************************
      ENDPOINT DESCRIPTOR
   **************************************************/
   9,         /* bLength   Length of this descriptor */

   5,         /* bDescType   5=ENDPOINT */

   /*
   ** Endpoint address.  The low nibble contains the endpoint number and the
   ** high bit indicates TX(1) or RX(0).
   */
   0x01,

   0x09,      /* bmAttr   ISO adaptive rate */

   /* Max Packet Size for this endpoint */
   USB_uint_16_low(EP1_HS_MAX_PACKET_SIZE),

   USB_uint_16_high(EP1_HS_MAX_PACKET_SIZE),

   ISO_INTERVAL,         /* bInterval */

   0,         /* bRefresh */

   0,         /* SyncAddr   None */


   /**************************************************
      OTG DESCRIPTOR
   **************************************************/

   /* OTG descriptor */
   3,
   9,    /* OTG type */
   3     /* HNP and SRP support */
};
#define OTHER_SPEED_CONFIG_DESC_SIZE  CONFIG_DESC_SIZE
uint_8  other_speed_config[OTHER_SPEED_CONFIG_DESC_SIZE] =
{
   /**************************************************
      CONFIGURATION DESCRIPTOR
   **************************************************/

   9,                         /* bLength Length of this descriptor */
   7,                         /* bDescType This is a Other speed config descr */
   OTHER_SPEED_CONFIG_DESC_SIZE & 0xff, 
   OTHER_SPEED_CONFIG_DESC_SIZE >> 8,
   1,
   1,
   4,
   /* Attributes.  Self-powered */
   0xc0,
   /* Current draw from bus */
   1,

   /**************************************************
      INTERFACE DESCRIPTOR
   **************************************************/
   
   /* Interface 0 Descriptor - always 9 bytes */
   9,
   /* "Interface" type of descriptor */
   4,
   /* Number of this interface */
   0,
   /* Alternate Setting */
   0,
   /* Number of endpoints on this interface */
   2,
   /* Interface Class */
   0x08,
   /* Interface Subclass: SCSI transparent command set */
   0x06,
   /* Interface Protocol: Bulk only protocol */
   0x50,
   /* Interface Description String Index */
   0,
   /**************************************************
      ENDPOINT DESCRIPTOR
   **************************************************/
   9,         /* bLength   Length of this descriptor */

   5,         /* bDescType   5=ENDPOINT */

   /*
   ** Endpoint address.  The low nibble contains the endpoint number and the
   ** high bit indicates TX(1) or RX(0).
   */
   0x81,

   0x09,      /* bmAttr   ISO adaptive rate */

   /* Max Packet Size for this endpoint */
   USB_uint_16_low(EP1_HS_MAX_PACKET_SIZE),

   USB_uint_16_high(EP1_HS_MAX_PACKET_SIZE),

   ISO_INTERVAL,         /* bInterval */

   0,         /* bRefresh */

   0,         /* SyncAddr   None */

   /**************************************************
      ENDPOINT DESCRIPTOR
   **************************************************/
   9,         /* bLength   Length of this descriptor */

   5,         /* bDescType   5=ENDPOINT */

   /*
   ** Endpoint address.  The low nibble contains the endpoint number and the
   ** high bit indicates TX(1) or RX(0).
   */
   0x01,

   0x09,      /* bmAttr   ISO adaptive rate */

   /* Max Packet Size for this endpoint */
   USB_uint_16_low(EP1_HS_MAX_PACKET_SIZE),

   USB_uint_16_high(EP1_HS_MAX_PACKET_SIZE),

   ISO_INTERVAL,         /* bInterval */

   0,         /* bRefresh */

   0,         /* SyncAddr   None */

   /**************************************************
      OTG DESCRIPTOR
   **************************************************/
   /* OTG descriptor */
   3,
   9,    /* OTG type */
   3     /* HNP and SRP support */
};

uchar USB_IF_ALT[4] = {0, 0, 0, 0};

/* number of strings in the table not including 0 or n. */
const uint_8 USB_STR_NUM = 6;

/*
** if the number of strings changes, look for USB_STR_0 everywhere and make
** the obvious changes.  It should be found in 3 places.
*/

uint_16 USB_STR_0[ 2] = {0x300 + sizeof(USB_STR_0),0x0409};
const uint_16 USB_STR_1[18] = {0x300 + sizeof(USB_STR_1),
      'T','R','A','N','S','D','I','M','E','N','S','I','O','N','I','N','C'};
const uint_16 USB_STR_2[24] = {0x300 + sizeof(USB_STR_2),
      'T','D','I',' ','M','a','s','s',' ','S','t','o','r','a','g','e',' ',\
      'D','e','v','i','c','e'};
uint_16 USB_STR_3[ 5] = {0x300 + sizeof(USB_STR_3),
      'B','E','T','A'};
uint_16 USB_STR_4[ 4] = {0x300 + sizeof(USB_STR_4),
      '#','0','2'};
uint_16 USB_STR_5[ 4] = {0x300 + sizeof(USB_STR_5),
      '_','A','1'};
uint_16 USB_STR_6[15] = {0x300 + sizeof(USB_STR_6),
      'Y','o','u','r',' ','n','a','m','e',' ','h','e','r','e'};
uint_16 USB_STR_n[17] = {0x300 + sizeof(USB_STR_n),
      'B','A','D',' ','S','T','R','I','N','G',' ','I','n','d','e','x'};

#define USB_STRING_ARRAY_SIZE  9
const uint_8_ptr USB_STRING_DESC[USB_STRING_ARRAY_SIZE] =
{
   (uint_8_ptr)((pointer)USB_STR_0),
   (uint_8_ptr)((pointer)USB_STR_1),
   (uint_8_ptr)((pointer)USB_STR_2),
   (uint_8_ptr)((pointer)USB_STR_3),
   (uint_8_ptr)((pointer)USB_STR_4),
   (uint_8_ptr)((pointer)USB_STR_5),
   (uint_8_ptr)((pointer)USB_STR_6),
   (uint_8_ptr)((pointer)USB_STR_n)
};


/**************************************************************************
APPLICATION SPECIFIC GLOBALS
**************************************************************************/

uint_16        usb_status;
uint_8         endpoint, if_status;
uint_8         data_to_send;
uint_16        sof_count;

SETUP_STRUCT   local_setup_packet;

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9GetStatus
* Returned Value : None
* Comments       :
*     Chapter 9 GetStatus command
*     WVALUE=Zero
*     WINDEX=Zero
*     WLENGTH=1
*     DATA=bmERR_STAT
*     The GET_STATUS command is used to read the bmERR_STAT register.
*
*     Return the status based on the bRrequestType bits:
*     device (0) = bit 0 = 1 = self powered
*                  bit 1 = 0 = DEVICE_REMOTE_WAKEUP which can be modified
*     with a SET_FEATURE/CLEAR_FEATURE command.
*     interface(1) = 0000.
*     endpoint(2) = bit 0 = stall.
*     static uint_8_ptr pData;
*
*     See section 9.4.5 (page 190) of the USB 1.1 Specification.
*
*END*--------------------------------------------------------------------*/
void ch9GetStatus
   (
      /* USB handle */
      _usb_device_handle handle,

      /* Is it a Setup phase? */
      boolean setup,

      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   if (setup) {
      switch (setup_ptr->REQUESTTYPE) {

         case 0x80:
            /* Device request */
            _usb_device_get_status(handle, USB_STATUS_DEVICE, &usb_status);
            /* Send the requested data */
            _usb_device_send_data(handle, 0, (uchar_ptr)((pointer)&usb_status),
               sizeof(usb_status));
            break;

         case 0x81:
            /* Interface request */
            if_status = USB_IF_ALT[setup_ptr->INDEX & 0x00FF];
            /* Send the requested data */
            _usb_device_send_data(handle, 0, &if_status, sizeof(if_status));
            break;

         case 0x82:
            /* Endpoint request */
            endpoint = setup_ptr->INDEX & USB_STATUS_ENDPOINT_NUMBER_MASK;
            _usb_device_get_status(handle,
               USB_STATUS_ENDPOINT | endpoint, &usb_status);
            /* Send the requested data */
            _usb_device_send_data(handle, 0, (uchar_ptr)((pointer)&usb_status),
               sizeof(usb_status));
            break;

         default:
            /* Unknown request */
            _usb_device_stall_endpoint(handle, 0, 0);
            return;

      } /* Endswitch */

      /* status phase */
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9ClearFeature
* Returned Value : None
* Comments       :
*     Chapter 9 ClearFeature command
*
*END*--------------------------------------------------------------------*/
void ch9ClearFeature
   (
      /* USB handle */
      _usb_device_handle handle,

      /* Is it a Setup phase? */
      boolean setup,

      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   static uint_8           endpoint;
   uint_16                 usb_status;

   _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, &usb_status);

   if ((usb_status != USB_STATE_CONFIG) && (usb_status != USB_STATE_ADDRESS)) {
      _usb_device_stall_endpoint(handle, 0, 0);
      return;
   } /* Endif */

   if (setup) {
      switch (setup_ptr->REQUESTTYPE) {

         case 0:
            /* DEVICE */
            if (setup_ptr->VALUE == 1) {
               /* clear remote wakeup */
               _usb_device_get_status(handle, USB_STATUS_DEVICE, &usb_status);
               usb_status &= ~USB_REMOTE_WAKEUP;
               _usb_device_set_status(handle, USB_STATUS_DEVICE, usb_status);
            } else {
               _usb_device_stall_endpoint(handle, 0, 0);
               return;
            } /* Endif */
            break;

         case 2:
            /* ENDPOINT */
            if (setup_ptr->VALUE != 0) {
               _usb_device_stall_endpoint(handle, 0, 0);
               return;
            } /* Endif */
            endpoint = setup_ptr->INDEX & USB_STATUS_ENDPOINT_NUMBER_MASK;
            _usb_device_get_status(handle, USB_STATUS_ENDPOINT | endpoint,
               &usb_status);
            /* unstall */
            _usb_device_set_status(handle, USB_STATUS_ENDPOINT | endpoint,
               0);
            break;
         default:
            _usb_device_stall_endpoint(handle, 0, 0);
            return;

      } /* Endswitch */
      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9SetFeature
* Returned Value : None
* Comments       :
*     Chapter 9 SetFeature command
*
*END*--------------------------------------------------------------------*/
void ch9SetFeature
   (
      /* USB handle */
      _usb_device_handle handle,

      /* Is it a Setup phase? */
      boolean setup,

      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16           usb_status;
   uint_8            endpoint;

   if (setup) {
      switch (setup_ptr->REQUESTTYPE) {

         case 0:
            /* DEVICE */
            if (setup_ptr->VALUE == 1) {
               /* set remote wakeup */
               _usb_device_get_status(handle, USB_STATUS_DEVICE, &usb_status);
               usb_status |= USB_REMOTE_WAKEUP;
               _usb_device_set_status(handle, USB_STATUS_DEVICE, usb_status);
            } /* Endif */
            if (setup_ptr->VALUE == 2) 
            {

                 /* Test Mode */
                  if ((setup_ptr->INDEX & 0x00FF) || 
                     (device_speed != USB_SPEED_HIGH)) 
                  {
                     _usb_device_stall_endpoint(handle, 0, 0);
                     return;
                  } /* Endif */

                  
                  _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, 
                     &usb_status);
                  if ((usb_status == USB_STATE_CONFIG) || 
                     (usb_status == USB_STATE_ADDRESS) || 
                     (usb_status == USB_STATE_DEFAULT)) 
                  {
                     ENTER_TEST_MODE = TRUE;
                     test_mode_index = (setup_ptr->INDEX & 0xFF00);
                  } else {
                     _usb_device_stall_endpoint(handle, 0, 0);
                     return;
                  } /* Endif */

            }
            
            if (setup_ptr->VALUE & 0x05) {
               /* set a_alt_hnp_support */
            } else if (setup_ptr->VALUE & 0x04) {
               /* set a_hnp_support */
            } else if (setup_ptr->VALUE & 0x02) {
               /* set a_hnp_support */
               
            } else {
               _usb_device_stall_endpoint(handle, 0, 0);
               return;
            } /* Endif */
            break;

         case 2:
            /* ENDPOINT */
            if (setup_ptr->VALUE != 0) {
               _usb_device_stall_endpoint(handle, 0, 0);
               return;
            } /* Endif */
            endpoint = setup_ptr->INDEX & USB_STATUS_ENDPOINT_NUMBER_MASK;
            _usb_device_get_status(handle, USB_STATUS_ENDPOINT | endpoint,
               &usb_status);
            /* set stall */
            _usb_device_set_status(handle, USB_STATUS_ENDPOINT | endpoint,
               1);
            break;

         default:
            _usb_device_stall_endpoint(handle, 0, 0);
            return;

      } /* Endswitch */

      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } else {
   
      if (ENTER_TEST_MODE) {
         /* Enter Test Mode */
         _usb_device_set_status(handle, USB_STATUS_TEST_MODE, 
            test_mode_index);
      } /* Endif */

      if (setup_ptr->VALUE & 0x03) {
         /* sleep callback should be installed for HNP capable Dual role device */
         //_usb_device_register_service(handle, USB_SERVICE_SLEEP, bus_suspend);
         OKAY_TO_DO_HNP = TRUE;

         /* set b_hnp_enable */
         _usb_otg_set_status(app_otg_handle, USB_OTG_B_HNP_ENABLE, TRUE);
         _usb_otg_set_status(app_otg_handle, USB_OTG_B_BUS_REQ, TRUE);
         app_test_struct.DO_HNP = TRUE;
         //TEST_ECHO_ENABLED = FALSE;
      } /* Endif */
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9SetAddress
* Returned Value : None
* Comments       :
*     Chapter 9 SetAddress command
*     We setup a TX packet of 0 length ready for the IN token
*     Once we get the TOK_DNE interrupt for the IN token, then
*     we change the ADDR register and go to the ADDRESS state.
*     See section 9.4.6 (page 192) of the USB 1.1 Specification.
*
*END*--------------------------------------------------------------------*/
void ch9SetAddress
   (
      /* USB handle */
      _usb_device_handle handle,

      /* Is it a Setup phase? */
      boolean setup,

      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   static uint_8 new_address;
   uint_32  max_pkt_size;  


   if (setup) {
      new_address = setup_ptr->VALUE;
      /*******************************************************
      if hardware assitance is enabled for set_address (see
      hardware rev for details) we need to do the set_address
      before queuing the status phase.
      *******************************************************/
      #ifdef SET_ADDRESS_HARDWARE_ASSISTANCE      
         _usb_device_set_status(handle, USB_STATUS_ADDRESS, new_address);
      #endif
      
      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
      

     /***********************************************************
      Set address is a good place to initialize other endpoints.
      At this point speed of the core is known, reset has
      occured and host is interested in talking.     
     ***********************************************************/
           
         #if 1   
         if(device_speed == USB_SPEED_HIGH) 
         {
            max_pkt_size = EP1_HS_MAX_PACKET_SIZE;
         } else 
         {
            max_pkt_size = EP1_FS_MAX_PACKET_SIZE;
         }

         _usb_device_init_endpoint(handle, 1, max_pkt_size, USB_RECV,
            ECHO_ENDPOINT, USB_DEVICE_DONT_ZERO_TERMINATE);
         _usb_device_init_endpoint(handle, 1, max_pkt_size, USB_SEND,
            ECHO_ENDPOINT, USB_DEVICE_DONT_ZERO_TERMINATE);

         //if (_usb_device_get_transfer_status(handle, 1, USB_RECV) == USB_OK) {
            _usb_device_recv_data(handle, 1, ECHO_ENDPOINT_RECV_BUFFER, max_pkt_size);
            _usb_device_send_data(handle, 1, ECHO_ENDPOINT_BUFFER_1, max_pkt_size);

         //} /* Endif */
      #endif

   } else {
      #ifndef SET_ADDRESS_HARDWARE_ASSISTANCE
         _usb_device_set_status(handle, USB_STATUS_ADDRESS, new_address);
      #endif
      _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
         USB_STATE_ADDRESS);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9GetDescription
* Returned Value : None
* Comments       :
*     Chapter 9 GetDescription command
*     The Device Request can ask for Device/Config/string/interface/endpoint
*     descriptors (via WVALUE). We then post an IN response to return the
*     requested descriptor.
*     And then wait for the OUT which terminates the control transfer.
*     See section 9.4.3 (page 189) of the USB 1.1 Specification.
*
*END*--------------------------------------------------------------------*/
void ch9GetDescription
   (
      /* USB handle */
      _usb_device_handle handle,

      /* Is it a Setup phase? */
      boolean setup,

      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_32  max_pkt_size;

   if (setup) {
      /* Load the appropriate string depending on the descriptor requested.*/
      switch (setup_ptr->VALUE & 0xFF00) {

         case 0x0100:
            _usb_device_send_data(handle, 0, (uchar_ptr)((pointer)&DevDesc),
               MIN(setup_ptr->LENGTH, DEVICE_DESCRIPTOR_SIZE));
            break;

         case 0x0200:
            /* Set the Max Packet Size in the config and other speed config */
            if(device_speed == USB_SPEED_HIGH) {
               max_pkt_size = EP1_HS_MAX_PACKET_SIZE;
            } else {
               max_pkt_size = EP1_FS_MAX_PACKET_SIZE;
            } /* Endif */

            ConfigDesc[CFG_DESC_EP1TX_MAX_PACKET_SIZE] =
               USB_uint_16_low(max_pkt_size);
            ConfigDesc[CFG_DESC_EP1TX_MAX_PACKET_SIZE+1] =
               USB_uint_16_high(max_pkt_size);
            ConfigDesc[CFG_DESC_EP1RX_MAX_PACKET_SIZE] =
               USB_uint_16_low(max_pkt_size);
            ConfigDesc[CFG_DESC_EP1RX_MAX_PACKET_SIZE+1] =
               USB_uint_16_high(max_pkt_size);

            _usb_device_send_data(handle, 0, (uchar_ptr)((pointer)&ConfigDesc),
               MIN(setup_ptr->LENGTH, CONFIG_DESC_SIZE));
            break;

         case 0x0300:
            if ((setup_ptr->VALUE & 0x00FF) > USB_STR_NUM) {
               _usb_device_send_data(handle, 0, USB_STRING_DESC[USB_STR_NUM+1],
                  MIN(setup_ptr->LENGTH, USB_STRING_DESC[USB_STR_NUM+1][0]));
            } else {
               _usb_device_send_data(handle, 0,
                  USB_STRING_DESC[setup_ptr->VALUE & 0x00FF],
                  MIN(setup_ptr->LENGTH,
                     USB_STRING_DESC[setup_ptr->VALUE & 0x00FF][0]));
            } /* Endif */

            break;

         case 0x600:
            _usb_device_send_data(handle, 0, (uchar_ptr)DevQualifierDesc,
               MIN(setup_ptr->LENGTH, DEVICE_QUALIFIER_DESCRIPTOR_SIZE));
            break;

         case 0x700:
            if(device_speed == USB_SPEED_HIGH) {
               max_pkt_size = EP1_FS_MAX_PACKET_SIZE;
            } else {
               max_pkt_size = EP1_HS_MAX_PACKET_SIZE;
            } /* Endif */

            other_speed_config[CFG_DESC_EP1TX_MAX_PACKET_SIZE] =
               USB_uint_16_low(max_pkt_size);
            other_speed_config[CFG_DESC_EP1TX_MAX_PACKET_SIZE+1] =
               USB_uint_16_high(max_pkt_size);
            other_speed_config[CFG_DESC_EP1RX_MAX_PACKET_SIZE] =
               USB_uint_16_low(max_pkt_size);
            other_speed_config[CFG_DESC_EP1RX_MAX_PACKET_SIZE+1] =
               USB_uint_16_high(max_pkt_size);

            _usb_device_send_data(handle, 0, (uchar_ptr)other_speed_config,
               MIN(setup_ptr->LENGTH, OTHER_SPEED_CONFIG_DESC_SIZE));
            break;

         default:
            _usb_device_stall_endpoint(handle, 0, 0);
            return;
      } /* Endswitch */
      /* status phase */
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9SetDescription
* Returned Value : None
* Comments       :
*     Chapter 9 SetDescription command
*     See section 9.4.8 (page 193) of the USB 1.1 Specification.
*
*END*--------------------------------------------------------------------*/
void ch9SetDescription
   (
      /* USB handle */
      _usb_device_handle handle,

      /* Is it a Setup phase? */
      boolean setup,

      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   _usb_device_stall_endpoint(handle, 0, 0);
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9GetConfig
* Returned Value : None
* Comments       :
*     Chapter 9 GetConfig command
*     See section 9.4.2 (page 189) of the USB 1.1 Specification.
*
*END*--------------------------------------------------------------------*/
void ch9GetConfig
   (
      /* USB handle */
      _usb_device_handle handle,

      /* Is it a Setup phase? */
      boolean setup,

      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16 current_config;
   /* Return the currently selected configuration */
   if (setup){
      _usb_device_get_status(handle, USB_STATUS_CURRENT_CONFIG,
         &current_config);
      data_to_send = current_config;
      _usb_device_send_data(handle, 0, &data_to_send, sizeof(data_to_send));
      /* status phase */
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9SetConfig
* Returned Value : None
* Comments       :
*     Chapter 9 SetConfig command
*
*END*--------------------------------------------------------------------*/
void ch9SetConfig
   (
      /* USB handle */
      _usb_device_handle handle,

      /* Is it a Setup phase? */
      boolean setup,

      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16 usb_state;

   if (setup) {
      if ((setup_ptr->VALUE & 0x00FF) > 1) {
         /* generate stall */
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */
      /* 0 indicates return to unconfigured state */
      if ((setup_ptr->VALUE & 0x00FF) == 0) {
         _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, &usb_state);
         if ((usb_state == USB_STATE_CONFIG) ||
            (usb_state == USB_STATE_ADDRESS))
         {
            /* clear the currently selected config value */
            _usb_device_set_status(handle, USB_STATUS_CURRENT_CONFIG, 0);
            _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
               USB_STATE_ADDRESS);
            /* status phase */
            _usb_device_send_data(handle, 0, 0, 0);
         } else {
            _usb_device_stall_endpoint(handle, 0, 0);
         } /* Endif */
         return;
      } /* Endif */


      /*
      ** If the configuration value (setup_ptr->VALUE & 0x00FF) differs
      ** from the current configuration value, then endpoints must be
      ** reconfigured to match the new device configuration
      */
      _usb_device_get_status(handle, USB_STATUS_CURRENT_CONFIG,
         &usb_state);
      if (usb_state != (setup_ptr->VALUE & 0x00FF)) {
         /* Reconfigure endpoints here */
         switch (setup_ptr->VALUE & 0x00FF) {

            default:
               break;
         } /* Endswitch */
         _usb_device_set_status(handle, USB_STATUS_CURRENT_CONFIG,
            setup_ptr->VALUE & 0x00FF);
         _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
            USB_STATE_CONFIG);
         /* status phase */
         _usb_device_send_data(handle, 0, 0, 0);
         return;
      } /* Endif */
      _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
         USB_STATE_CONFIG);
      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9GetInterface
* Returned Value : None
* Comments       :
*     Chapter 9 GetInterface command
*     See section 9.4.4 (page 190) of the USB 1.1 Specification.
*
*END*--------------------------------------------------------------------*/
void ch9GetInterface
   (
      /* USB handle */
      _usb_device_handle handle,

      /* Is it a Setup phase? */
      boolean setup,

      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16 usb_state;

   _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, &usb_state);
   if (usb_state != USB_STATE_CONFIG) {
      _usb_device_stall_endpoint(handle, 0, 0);
      return;
   } /* Endif */

   if (setup) {
      _usb_device_send_data(handle, 0, &USB_IF_ALT[setup_ptr->INDEX & 0x00FF],
         MIN(setup_ptr->LENGTH, sizeof(uint_8)));
      /* status phase */
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9SetInterface
* Returned Value : None
* Comments       :
*     Chapter 9 SetInterface command
*     See section 9.4.10 (page 195) of the USB 1.1 Specification.
*
*END*--------------------------------------------------------------------*/
void ch9SetInterface
   (
      /* USB handle */
      _usb_device_handle handle,

      /* Is it a Setup phase? */
      boolean setup,

      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   if (setup) {
      if (setup_ptr->REQUESTTYPE != 0x01) {
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */

      /*
      ** If the alternate value (setup_ptr->VALUE & 0x00FF) differs
      ** from the current alternate value for the specified interface,
      ** then endpoints must be reconfigured to match the new alternate
      */
      if (USB_IF_ALT[setup_ptr->INDEX & 0x00FF]
         != (setup_ptr->VALUE & 0x00FF))
      {
         USB_IF_ALT[setup_ptr->INDEX & 0x00FF] = (setup_ptr->VALUE & 0x00FF);
         /* Reconfigure endpoints here. */

      } /* Endif */

      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } /* Endif */

   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9SynchFrame
* Returned Value :
* Comments       :
*     Chapter 9 SynchFrame command
*     See section 9.4.11 (page 195) of the USB 1.1 Specification.
*
*END*--------------------------------------------------------------------*/
void ch9SynchFrame
   (
      /* USB handle */
      _usb_device_handle handle,

      /* Is it a Setup phase? */
      boolean setup,

      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */

   if (setup) {
      if (setup_ptr->REQUESTTYPE != 0x02) {
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */

      if ((setup_ptr->INDEX & 0x00FF) >=
         ConfigDesc[CONFIG_DESC_NUM_INTERFACES])
      {
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */

      _usb_device_get_status(handle, USB_STATUS_SOF_COUNT, &sof_count);
      _usb_device_send_data(handle, 0, (uchar_ptr)((pointer)&sof_count),
         MIN(setup_ptr->LENGTH, sizeof(sof_count)));
      /* status phase */
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : ch9Vendor
* Returned Value :
* Comments       :
*     Chapter 9 SynchFrame command
*     See section 9.4.11 (page 195) of the USB 1.1 Specification.
*
*END*--------------------------------------------------------------------*/
void ch9Vendor
   (
      _usb_device_handle handle,
      boolean setup,
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */

   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : service_ep0
* Returned Value : None
* Comments       :
*     Called upon a completed endpoint 0 (USB 1.1 Chapter 9) transfer
*
*END*--------------------------------------------------------------------*/
void service_ep0
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,

      /* [IN] Is it a setup packet? */
      boolean              setup,

      /* [IN] Direction of the transfer.  Is it transmit? */
      uint_8               direction,

      /* [IN] Pointer to the data buffer */
      uint_8_ptr           buffer,

      /* [IN] Length of the transfer */
      uint_32              length,

      /* [IN] Error, if any */
      uint_8               error
   )
{ /* Body */
   boolean  class_request = FALSE;

   if (setup) {
      _usb_device_read_setup_data(handle, 0, (uchar_ptr)&local_setup_packet);
   } else if (class_request) {
      class_request = FALSE;
      /* Finish your class or vendor request here */

      return;
   } /* Endif */

   switch (local_setup_packet.REQUESTTYPE & 0x60) {

      case 0x00:
         switch (local_setup_packet.REQUEST) {

            case 0x0:
               ch9GetStatus(handle, setup, &local_setup_packet);
               break;

            case 0x1:
               ch9ClearFeature(handle, setup, &local_setup_packet);
               break;

            case 0x3:
               ch9SetFeature(handle, setup, &local_setup_packet);
               break;

            case 0x5:
               ch9SetAddress(handle, setup, &local_setup_packet);
               break;

            case 0x6:
               ch9GetDescription(handle, setup, &local_setup_packet);
               break;

            case 0x7:
               ch9SetDescription(handle, setup, &local_setup_packet);
               break;

            case 0x8:
               ch9GetConfig(handle, setup, &local_setup_packet);
               break;

            case 0x9:
               ch9SetConfig(handle, setup, &local_setup_packet);
               break;

            case 0xa:
               ch9GetInterface(handle, setup, &local_setup_packet);
               break;

            case 0xb:
               ch9SetInterface(handle, setup, &local_setup_packet);
               break;

            case 0xc:
               ch9SynchFrame(handle, setup, &local_setup_packet);
               break;

            default:
               _usb_device_stall_endpoint(handle, 0, 0);
               break;

         } /* Endswitch */

         break;

      case 0x20:
         /* class specific request */
         class_request = TRUE;
         /* Queue your own packet for class data here */

         /* For Get Max LUN use any of these responses*/
         _usb_device_stall_endpoint(handle, 0, 0);
         return;

      case 0x40:
         /* vendor specific request */
         ch9Vendor(handle, setup, &local_setup_packet);
         break;

      default:
         _usb_device_stall_endpoint(handle, 0, 0);
         break;

   } /* Endswitch */

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : service_ep1
* Returned Value : None
* Comments       :
*     Called upon a completed endpoint 1 (USB 1.1 Chapter 9) transfer
*
*END*--------------------------------------------------------------------*/
void service_ep1
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,

      /* [IN] Is it a setup packet? */
      boolean              setup,

      /* [IN] Direction of the transfer.  Is it transmit? */
      uint_8               direction,

      /* [IN] Pointer to the data buffer */
      uint_8_ptr           buffer,

      /* [IN] Length of the transfer */
      uint_32              length,

      /* [IN] Error, if any */
      uint_8               error
   )
{ /* Body */
   uint_32 max_pkt_size;
   
   if(device_speed == USB_SPEED_HIGH) 
   {
      max_pkt_size = EP1_HS_MAX_PACKET_SIZE;
   } 
   else 
   {
      max_pkt_size = EP1_FS_MAX_PACKET_SIZE;
   }

   if(direction == USB_RECV) /* means an  OUT has been received */
   {
            //if(toggle_buffer)
            //{
               _usb_device_recv_data(handle, 1, ECHO_ENDPOINT_RECV_BUFFER, max_pkt_size);
           //    toggle_buffer = FALSE;
           // }
           // else
           // {
            //   _usb_device_recv_data(handle, 1, ECHO_ENDPOINT_BUFFER_2, max_pkt_size);
            //   toggle_buffer = TRUE;

           // }
   }
   else
   {
   
            if(toggle_buffer)
            {
                _usb_device_send_data (
                        handle,
                        1,
                        (uchar_ptr) ECHO_ENDPOINT_BUFFER_1,
                        max_pkt_size); 

               toggle_buffer = FALSE;
            }
            else
            {
      
               _usb_device_send_data (
                        handle,
                        1,
                        (uchar_ptr) ECHO_ENDPOINT_BUFFER_2,
                        max_pkt_size); 

               //_usb_device_recv_data(handle, 1, ECHO_ENDPOINT_BUFFER_2, max_pkt_size);
               toggle_buffer = TRUE;

            }

   }
   
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : detect_speed
* Returned Value : None
* Comments       :
*     Called when the speed is set
*
*END*--------------------------------------------------------------------*/
void detect_speed
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,

      /* [IN] Unused */
      boolean              setup,

      /* [IN] Unused */
      uint_8               direction,

      /* [IN] Unused */
      uint_8_ptr           buffer,

      /* [IN] speed */
      uint_32              speed,

      /* [IN] Error, if any */
      uint_8               error
   )
{ /* Body */
   device_speed = speed;
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : reset_ep0
* Returned Value : None
* Comments       :
*     Called upon a bus reset event.  Initialises the control endpoint.
*
*END*--------------------------------------------------------------------*/
void reset_ep0
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,

      /* [IN] Unused */
      boolean              setup,

      /* [IN] Unused */
      uint_8               direction,

      /* [IN] Unused */
      uint_8_ptr           buffer,

      /* [IN] Unused */
      uint_32              length,

      /* [IN] Error, if any */
      uint_8               error
   )
{ /* Body */
   uint_32 state;

   OKAY_TO_DO_HNP = FALSE;

   /* on a reset always ensure all transfers are cancelled on all EP*/
   _usb_device_cancel_transfer(handle, 0, USB_RECV);
   _usb_device_cancel_transfer(handle, 0, USB_SEND);
   _usb_device_cancel_transfer(handle, 1, USB_RECV);
   _usb_device_cancel_transfer(handle, 1, USB_SEND);
   

   _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);

   _usb_device_init_endpoint(handle, 0, DevDesc[DEV_DESC_MAX_PACKET_SIZE], 0,
      USB_CONTROL_ENDPOINT, 0);
   _usb_device_init_endpoint(handle, 0, DevDesc[DEV_DESC_MAX_PACKET_SIZE], 1,
      USB_CONTROL_ENDPOINT, 0);


   if (state >= B_IDLE) 
   {
      _usb_otg_set_status(app_otg_handle, USB_OTG_B_BUS_REQ, FALSE);
   } /* Endif */

   return;
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : bus_suspend
* Returned Value : None
* Comments       :
*     Called upon a SLEEP interrupt.
*
*END*--------------------------------------------------------------------*/
void bus_suspend
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,

      /* [IN] Unused */
      boolean              setup,

      /* [IN] Unused */
      uint_8               direction,

      /* [IN] Unused */
      uint_8_ptr           buffer,

      /* [IN] Unused */
      uint_32              length,

      /* [IN] Error, if any */
      uint_8               error
   )
{ /* Body */

   uint_32 state;

   _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);

   if (state == B_PERIPHERAL) {
      if (OKAY_TO_DO_HNP) {
         _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_SUSPEND, TRUE);
      } /* Endif */
   } else if (state == A_PERIPHERAL)  {
      _usb_otg_set_status(app_otg_handle, USB_OTG_B_BUS_SUSPEND,TRUE);
   } /* Endif */
   /*
   ** when we executed the set status; the OTG state machine runs and we are
   ** not device any more we should quit the device application.
   */
   return;
} /* EndBody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : device_main
* Returned Value : None
* Comments       :
*     First function called.  Initialises the USB and registers Chapter 9
*     callback functions.
*
*END*--------------------------------------------------------------------*/
void device_main
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle

   )
{ /* Body */

   uint_32 max_packet_size;
   int i,j;

   #ifdef __VUSBHS__
      max_packet_size  = EP1_HS_MAX_PACKET_SIZE;
   #else
      max_packet_size  = EP1_FS_MAX_PACKET_SIZE;
   #endif

   for(i=0; i < max_packet_size; i++)
   {
      ECHO_ENDPOINT_BUFFER_1[i] = (uint_8) i;
   }
   
   i = 0;
   for(j=max_packet_size; j > 0; j--)
   {
      ECHO_ENDPOINT_BUFFER_2[i] = (uint_8) j;
      i++;
   }

   while (TRUE) 
   {

      if (app_test_struct.DO_HNP) {
         return;
      } else if (app_test_struct.DO_SRP) {
         return;
      } else if (app_test_struct.DO_NORMAL) {
         return;
      } 
   } /* Endwhile */
} /* Endbody */

/* EOF */
