/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains device driver for mass storage class. This code tests
***   the UFI set of commands.
***
**************************************************************************
**END*********************************************************/

/**************************************************************************
Include the OS and BSP dependent files that define IO functions and
basic types. You may like to change these files for your board and RTOS 
**************************************************************************/

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
   #include "bsp.h"
   #include "fio.h"
#else
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif
   #include "stdlib.h"
#endif

/**************************************************************************
Include the USB stack header files.
**************************************************************************/

#ifdef __USB_OTG__
#include "otgapi.h"
#else
#include "hostapi.h"
#include "devapi.h"
#endif

/**************************************************************************
Local header files for this application
**************************************************************************/
#include "msc_commands.h"

/**************************************************************************
Class driver files for this application
**************************************************************************/

#include "usb_mass_bo.h"
#include "usb_mass_ufi.h"


/**************************************************************************
A driver info table defines the devices that are supported and handled
by file system application. This table defines the PID, VID, class and
subclass of the USB device that this application listens to. If a device
that matches this table entry, USB stack will generate a attach callback.
As noted, this table defines a UFI class device and a USB
SCSI class device (e.g. high-speed hard disk) as supported devices.
see the declaration of structure USB_HOST_DRIVER_INFO for details
or consult the software architecture guide.
**************************************************************************/


static  USB_HOST_DRIVER_INFO DriverInfoTable[] =
{
   /* Floppy drive */
   {
      {0x00,0x00},                  /* Vendor ID per USB-IF             */
      {0x00,0x00},                  /* Product ID per manufacturer      */
      USB_CLASS_MASS_STORAGE,       /* Class code                       */
      USB_SUBCLASS_MASS_UFI,        /* Sub-Class code                   */
      USB_PROTOCOL_MASS_BULK,       /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_mass_device_event    /* Application call back function   */
   },

   /* USB 2.0 hard drive */
   {

      {0x49,0x0D},                  /* Vendor ID per USB-IF             */
      {0x00,0x30},                  /* Product ID per manufacturer      */
      USB_CLASS_MASS_STORAGE,       /* Class code                       */
      USB_SUBCLASS_MASS_SCSI,       /* Sub-Class code                   */
      USB_PROTOCOL_MASS_BULK,       /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_mass_device_event    /* Application call back function   */
   },

   {
      {0x00,0x00},                  /* All-zero entry terminates        */
      {0x00,0x00},                  /*    driver info list.             */
      0,
      0,
      0,
      0,
      NULL
   }

};

/**************************************************************************
   Global variables
**************************************************************************/
volatile DEVICE_STRUCT       mass_device = { 0 };   /* mass storage device struct */
volatile boolean bCallBack = FALSE;
volatile USB_STATUS bStatus       = USB_OK;
volatile uint_32  dBuffer_length = 0;
boolean  Attach_Notification = FALSE;

/* the following is the mass storage class driver object structure. This is
used to send commands down to  the class driver. See the Class API document
for details */

COMMAND_OBJECT_PTR pCmd, pCmd1;

/*some handles for communicating with USB stack */
_usb_otg_handle      otg_handle1; /* handle for calls to OTG API */
_usb_host_handle     host_handle; /* host controller status etc. */

/**************************************************************************
The following is the way to define a multi tasking system in MQX RTOS.
Remove this code and use your own RTOS way of defining tasks (or threads).
**************************************************************************/

#ifdef __USB_OS_MQX__
#define MAIN_TASK          (10)
extern void Main_Task(uint_32 param);
TASK_TEMPLATE_STRUCT  MQX_template_list[] =
{
   { MAIN_TASK,      Main_Task,      3000L,  7L, "Main",      MQX_AUTO_START_TASK},
   { 0L,             0L,             0L,   0L, 0L,          0L }
};

#endif



/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : main
* Returned Value : none
* Comments       :
*     Execution starts here
*
*END*--------------------------------------------------------------------*/

#ifdef __USB_OS_MQX__
void Main_Task ( uint_32 param )
#else
void main (void)
#endif

{ /* Body */

   USB_STATUS           status = USB_OK   ;
   USB_OTG_INIT_STRUCT  otg_init          ;

   /* default configuration: A = host, B = peripheral */
   otg_init.A_BUS_DROP  = FALSE           ;
   otg_init.A_BUS_REQ   = TRUE            ;
   otg_init.B_BUS_REQ   = FALSE           ;
   otg_init.SERVICE     = otg_service     ;

   _disable_interrupts();
#ifdef __USB_OS_MQX__
   _int_install_unexpected_isr ( )         ;
   status = _usb_driver_install(0, &_bsp_usb_callback_table);
   if (status) {
      printf("ERROR: %ls", status);
      exit(1);
   } /* Endif */
#endif



   /*
   ** Initialize the USB interface, causing a call back to the otg_service
   ** routine
   */
   status = _usb_otg_init(0, &otg_init, &otg_handle1);
   _enable_interrupts();
   if ( status != USB_OK ) {
      printf( "\nUSB OTG Initialization failed. Error Status: %x", status );
         fflush(stdout);
      exit ( 1 );
   } /* Endif */


   /*----------------------------------------------------**
   ** Infinite loop, waiting for events requiring action **
   **----------------------------------------------------*/
   for ( ; ; ) {
      switch ( mass_device.dev_state ) {
         case USB_DEVICE_IDLE:
            break ;
         case USB_DEVICE_ATTACHED:
            printf( "Mass Storage Attached\n" );
            fflush(stdout);
            mass_device.dev_state = USB_DEVICE_SET_INTERFACE_STARTED;
            status = _usb_hostdev_select_interface(mass_device.dev_handle,
                 mass_device.intf_handle, (pointer)&mass_device.class_intf);
            break ;
         case USB_DEVICE_SET_INTERFACE_STARTED:
            break;
         case USB_DEVICE_INTERFACED:
            usb_host_mass_test_storage();
            mass_device.dev_state = USB_DEVICE_OTHER;
            break ;
         case USB_DEVICE_DETACHED:
            printf ( "Mass Storage Detached\n" );
               fflush(stdout);
            mass_device.dev_state = USB_DEVICE_IDLE;
            break;
         case USB_DEVICE_OTHER:
            break ;
         default:
            printf ( "Unknown Mass Storage Device State = %d\n",\
               mass_device.dev_state );
               fflush(stdout);
            break ;
      } /* Endswitch */
   } /* Endfor */

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : otg_service
* Returned Value : None
* Comments       :
*     Called upon  OTG service state change.This is the OTG decision
* making rouitine that decides the role of the OTG controller.As you
can see in the code that depending upon the event generated from
stack, host or device role is entered or exited.
*
* Note this routine is called at interrupt level because it is executed
under a callback.

*END*--------------------------------------------------------------------*/

static void otg_service
   (
      /* [IN] Handle to make OTG calls*/
      _usb_otg_handle    otg_handle,

      /* event on the OTG stack       */
      uint_32            event
   )
{ /* Body */
   uint_32              state;
   USB_STATUS           status = USB_OK;

   switch (event) {
      case USB_OTG_HOST_UP:

         /*
         ** It means that we are going to act like host, so we initialize
         ** the host stack. This call will allow USB system to allocate memory for
         ** data structures, it uses later (e.g pipes etc.).
         */
         status = _usb_host_init
            (HOST_CONTROLLER_NUMBER,    /* Use value in header file */
             MAX_FRAME_SIZE,            /* Frame size per USB spec  */
             &host_handle);             /* Returned pointer */

         if (status != USB_OK) {
            printf("\nUSB Host Initialization failed. STATUS: %x", status);
            fflush(stdout);
            return;
         } /* Endif */

         /*
         ** Since we are going to act as the host driver, register
         ** the driver information for wanted class/subclass/protocols
         */
         status = _usb_host_driver_info_register(host_handle, DriverInfoTable);
         if (status != USB_OK) {
            printf("\nDriver Registration failed. STATUS: %x", status);
            fflush(stdout);
            return;
         } else {
            /* Success, set OTG state to active */
            _usb_otg_set_status(otg_handle, USB_OTG_HOST_ACTIVE, TRUE)  ;
            _usb_otg_get_status(otg_handle, USB_OTG_STATE, &state)      ;
            if (state < B_IDLE) {
               _usb_otg_set_status(otg_handle, USB_OTG_A_BUS_DROP, FALSE);
               _usb_otg_set_status(otg_handle, USB_OTG_A_BUS_REQ, TRUE)  ;
            } /* Endif */
         } /* Endif */
         break;
      /*this is a host only application so we don't take any action on
      a device role */
      case USB_OTG_DEVICE_UP:
         break;
      case USB_OTG_HOST_DOWN:
         break;
      case USB_OTG_DEVICE_DOWN:
         break;
      case USB_OTG_SRP_ACTIVE:
         break;
      case USB_OTG_SRP_FAIL:
         break;
      case USB_OTG_OVER_CURRENT:
         break;
      default:
         break;
   } /* Endswitch */
   return;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_mass_device_event
* Returned Value : None
* Comments       :
*     called when mass storage device has been attached, detached, etc.
*END*--------------------------------------------------------------------*/
static void usb_host_mass_device_event
   (
      /* [IN] pointer to device instance */
      _usb_device_instance_handle      dev_handle,

      /* [IN] pointer to interface descriptor */
      _usb_interface_descriptor_handle intf_handle,

      /* [IN] code number for event causing callback */
      uint_32           event_code
   )
{ /* Body */
   INTERFACE_DESCRIPTOR_PTR   intf_ptr =
      (INTERFACE_DESCRIPTOR_PTR)intf_handle;

   fflush(stdout);
   switch (event_code) {
      case USB_CONFIG_EVENT:
         /* Drop through into attach, same processing */
      case USB_ATTACH_EVENT:
         if (mass_device.dev_state == USB_DEVICE_IDLE) {
            mass_device.dev_handle = dev_handle;
            mass_device.intf_handle = intf_handle;
            mass_device.dev_state = USB_DEVICE_ATTACHED;
         } else {
            printf("Mass Storage Already Attached\n");
            fflush(stdout);
         } /* EndIf */
         break;
      case USB_INTF_EVENT:
         mass_device.dev_state = USB_DEVICE_INTERFACED;
         break;
      case USB_DETACH_EVENT:
         if (mass_device.dev_state == USB_DEVICE_INTERFACED) {
            mass_device.dev_handle = NULL;
            mass_device.intf_handle = NULL;
            mass_device.dev_state = USB_DEVICE_DETACHED;
         } else {
            printf("Mass Storage Not Attached\n");
            fflush(stdout);
         } /* EndIf */
         break;
      default:
         mass_device.dev_state = USB_DEVICE_IDLE;
         break;
   } /* EndSwitch */
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_mass_ctrl_calback
* Returned Value : None
* Comments       :
*     called on completion of a control-pipe transaction.
*
*END*--------------------------------------------------------------------*/

static void usb_host_mass_ctrl_callback
   (
      /* [IN] pointer to pipe */
      _usb_pipe_handle  pipe_handle,

      /* [IN] user-defined parameter */
      pointer           user_parm,

      /* [IN] buffer address */
      uchar_ptr         buffer,

      /* [IN] length of data transferred */
      uint_32           buflen,

      /* [IN] status, hopefully USB_OK or USB_DONE */
      uint_32           status
   )
{ /* Body */

   bCallBack = TRUE;
   bStatus = status;

} /* Endbody */


void callback_bulk_pipe
   (
      /* [IN] Status of this command */
      USB_STATUS status,

      /* [IN] pointer to USB_MASS_BULK_ONLY_REQUEST_STRUCT*/
      pointer p1,

      /* [IN] pointer to the command object*/
      pointer  p2,

      /* [IN] Length of data transmitted */
      uint_32 buffer_length
   )
{ /* Body */

   dBuffer_length = buffer_length;
   bCallBack = TRUE;
   bStatus = status;

} /* Endbody */



/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_mass_test_storage
* Returned Value : None
* Comments       :
*     Calls the UFI command set for testing
*END*--------------------------------------------------------------------*/

static void usb_host_mass_test_storage
   (
      void
   )
{ /* Body */
   USB_STATUS                                 status = USB_OK;
   uint_8                                     bLun = 0;
   uchar_ptr                                  buff_out, buff_in;
   INQUIRY_DATA_FORMAT                        inquiry;
   CAPACITY_LIST                              capacity_list;
   MODE_SELECT_PARAMETER_LIST                 md_list;
   MASS_STORAGE_READ_CAPACITY_CMD_STRUCT_INFO read_capacity;
   REQ_SENSE_DATA_FORMAT                      req_sense;
   FORMAT_UNIT_PARAMETER_BLOCK                formatunit = { 0};

   pCmd = (COMMAND_OBJECT_PTR) USB_memalloc(sizeof(COMMAND_OBJECT_STRUCT));
   USB_memzero(pCmd,sizeof(COMMAND_OBJECT_STRUCT));

   pCmd->LUN      = bLun;
   pCmd->CALL_PTR = (pointer)&mass_device.class_intf;
   pCmd->CALLBACK = callback_bulk_pipe;

   pCmd->CBW_PTR = (CBW_STRUCT_PTR) USB_memalloc(sizeof(CBW_STRUCT));
   USB_memzero(pCmd->CBW_PTR,sizeof(CBW_STRUCT));

   pCmd->CSW_PTR = (CSW_STRUCT_PTR) USB_memalloc(sizeof(CSW_STRUCT));
   USB_memzero(pCmd->CSW_PTR,sizeof(CSW_STRUCT));


   buff_in = (uchar_ptr)USB_memalloc(0x400C);
   printf("\n =============START OF A NEW SESSION==================");

   /* Test the GET MAX LUN command */
   printf("\nTesting: GETMAXLUN Command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_class_mass_getmaxlun_bulkonly(
      (pointer)&mass_device.class_intf, &bLun,
      usb_host_mass_ctrl_callback);

   /* Wait till command comes back */
   while (!bCallBack) {;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the TEST UNIT READY command */
   printf("Testing: TEST UNIT READY Command");
   fflush(stdout);

   bCallBack = FALSE;

   status =  usb_mass_ufi_test_unit_ready(pCmd);

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the REQUEST SENSE command */
   printf("Testing: REQUEST SENSE  command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_request_sense(pCmd, &req_sense,
      sizeof(REQ_SENSE_DATA_FORMAT));

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the INQUIRY command */
   printf("Testing: UFI_INQUIRY command");
   fflush(stdout);

   bCallBack = FALSE;

   status = usb_mass_ufi_inquiry(pCmd, (uchar_ptr) &inquiry,
      sizeof(INQUIRY_DATA_FORMAT));

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the REQUEST SENSE command */
   printf("Testing: REQUEST SENSE  command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_request_sense(pCmd, &req_sense,
      sizeof(REQ_SENSE_DATA_FORMAT));

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the READ FORMAT CAPACITY command */
   printf("Testing: READ FORMAT CAPACITY command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_format_capacity(pCmd, (uchar_ptr)&capacity_list,
      sizeof(CAPACITY_LIST));

   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the REQUEST SENSE command */
   printf("Testing: REQUEST SENSE  command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_request_sense(pCmd, &req_sense,
      sizeof(REQ_SENSE_DATA_FORMAT));

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the READ CAPACITY command */
   printf("Testing: READ FORMAT CAPACITY command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_read_capacity(pCmd, (uchar_ptr)&read_capacity,
      sizeof(MASS_STORAGE_READ_CAPACITY_CMD_STRUCT_INFO));

   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the MODE SELECT command */
   printf("Testing: MODE SELECT command");
   fflush(stdout);
   bCallBack = FALSE;

   //md_list. Fill parameters here
   status = usb_mass_ufi_mode_select(pCmd, &md_list);

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the REQUEST SENSE command */
   printf("Testing: REQUEST SENSE  command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_request_sense(pCmd, &req_sense,
      sizeof(REQ_SENSE_DATA_FORMAT));

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the READ 10 command */
   printf("Testing: READ 10 command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_read_10(pCmd, 0, buff_in, 512, 1);

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the MODE SENSE command */
   printf("Testing: MODE SENSE  command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_mode_sense(pCmd,
      2, //PC
      0x3F, //page code
      buff_in,
      0x08);

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the PREVENT ALLOW command */
   printf("Testing: PREVENT ALLOW   command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_prevent_allow_medium_removal(
      pCmd,
      1 // prevent
      );

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the REQUEST SENSE command */
   printf("Testing: REQUEST SENSE  command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_request_sense(pCmd, &req_sense,
      sizeof(REQ_SENSE_DATA_FORMAT));

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the VERIFY command */
   printf("Testing: VERIFY   command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_verify(
      pCmd,
      0x400, // block address
      1 //length to be verified
      );

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */

   /* Test the WRITE 10 command */
   printf("Testing: WRITE 10 command");
   fflush(stdout);
   bCallBack = FALSE;

   buff_out = (uchar_ptr) USB_memalloc(0x0F);
   status = usb_mass_ufi_write_10(pCmd, 8, buff_out, 512, 1);

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */


   /* Test the REQUEST SENSE command */
   printf("Testing: REQUEST SENSE  command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_request_sense(pCmd, &req_sense,
      sizeof(REQ_SENSE_DATA_FORMAT));

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */


   /* Test the usb_mass_ufi_start_stop command */
   printf("Testing: START STOP command");
   fflush(stdout);
   bCallBack = FALSE;

   status = usb_mass_ufi_start_stop(pCmd, 0, 1);

   /* Wait till command comes back */
   while (!bCallBack){;}
   if (!bStatus) {
      printf("...OK\n");
   } /* Endif */


   printf("\nTest done!");
   fflush(stdout);
} /* Endbody */

/* EOF */

