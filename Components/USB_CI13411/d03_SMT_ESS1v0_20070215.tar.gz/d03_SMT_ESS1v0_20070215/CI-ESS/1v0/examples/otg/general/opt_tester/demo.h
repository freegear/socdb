#ifndef _demo_h_
#define _demo_h_ 1
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:  
***            
***
************************************************************************
**END*********************************************************/

/*define the way to take input from the user if MQX is not available
Customers should write status() macro to their code that can take
input from the user without blocking. In this example code, it is
just defined to 1 and getchar() is used as a blocking input from user */
#include "types.h"

#ifndef __USB_OS_MQX__
	#define status()  1
#endif

#ifdef __cplusplus
extern "C" {
#endif
extern void usb_host_device_event(_usb_device_instance_handle, 
   _usb_interface_descriptor_handle, uint_32);
extern void service_ep0(_usb_device_handle, boolean, uint_8, 
   uint_8_ptr, uint_32, uint_8);
extern void reset_ep0(_usb_device_handle, boolean, uint_8, uint_8_ptr, 
   uint_32, uint_8);
extern void detect_speed(_usb_device_handle, boolean, uint_8, uint_8_ptr, 
   uint_32, uint_8);
extern void service_ep1(_usb_device_handle, boolean, uint_8, uint_8_ptr, 
   uint_32, uint_8);
extern void app_process_device_resume (_usb_device_handle, boolean, uint_8, uint_8_ptr, 
   uint_32, uint_8);
extern void app_process_attach(_usb_host_handle, uint_32);
extern void app_process_enumeration_done(_usb_host_handle, uint_32);
extern void app_process_detach(_usb_host_handle, uint_32);
extern void app_process_host_resume(_usb_host_handle, uint_32);
#if 1
extern void app_process_HNP(_usb_host_handle);
#else
extern USB_STATUS app_process_HNP(_usb_host_handle);
#endif

extern void app_process_pipe_transaction_done(_usb_pipe_handle, pointer, 
   uchar_ptr, uint_32, uint_32);
extern void _otg_host_shutdown(void);
extern void bus_suspend(_usb_device_handle, boolean, uint_8, uint_8_ptr, 
   uint_32, uint_8);
extern void bus_sof(_usb_device_handle, boolean, uint_8, uint_8_ptr, 
   uint_32, uint_8);
extern void uninitialize_device(void);
extern USB_STATUS initialize_device(void);


#ifdef __cplusplus
}
#endif
#endif
/* EOF */
