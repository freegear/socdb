/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:
***    This file contains the initialization and menu source code for
***    the USB mass storage MFS test example program using USB mass storage
**     link driver.
***
**************************************************************************
**END*********************************************************/
#include "types.h"
#include "bsp.h"
#ifdef __USB_OTG__
#include "otgapi.h"
#else
#include "hostapi.h"
#include "devapi.h"
#endif
#include "mqx_arc.h"
#include "fio.h"
#include "mfs.h"
#include "part_mgr.h"
#include "usbmfs.h"
#include "demo.h"
#include "mfsdemo.h"

extern char     *Test_Buffer;
extern char     *Test_Buffer2;
extern MQX_INITIALIZATION_STRUCT MQX_init_struct;
extern boolean HNP_ATTEMPTED;
extern _usb_host_handle     host_handle;

FILE_PTR       A_FD_PTR, B_FD_PTR, DEV_FD_PTR, PM_FD_PTR, MFS_FD_PTR;
LWSEM_STRUCT   file_task_sem;
_task_id       FILE_TASK_ID = MQX_NULL_TASK_ID;

typedef struct io_mem_struct
{
   /* Type of memory, dynamic or static */
   _mqx_uint        TYPE;

   /* Address of the fdv_ram device */
   uchar_ptr        BASE_ADDR;

   /* The total size of memory in the ram disk */
   _file_size       SIZE;

   /* Light weight semaphore struct */
   LWSEM_STRUCT     LWSEM;

   /* The current error code for the device */
   _mqx_uint        ERROR_CODE;

   /* Start CR 810 */
   /* The current mode for the device */
   boolean          BLOCK_MODE;

   /* The number of blocks for the device */
   _file_size       NUM_BLOCKS;
   /* End   CR 810 */

} IO_MEM_STRUCT, _PTR_ IO_MEM_STRUCT_PTR;

extern volatile boolean              golbal_mass_storge_device_found;
extern volatile _usb_class_handle    global_class_handle;
extern uchar *MASS_STORAGE_DISK;

MFS_FORMAT_DATA MFS_format =
{
   /* PHYSICAL_DRIVE;    */   HD_PHYSICAL_DRIVE,
   /* MEDIA_DESCRIPTOR;  */   HD_MEDIA_DESC,
   /* BYTES_PER_SECTOR;  */   BYTES_PER_SECT,
   /* SECTORS_PER_TRACK; */   SECTS_PER_TRACK,
   /* NUMBER_OF_HEADS;   */   NUM_OF_HEADS,
   /* NUMBER_OF_SECTORS; */   0,             /* depends on specific drive */
   /* HIDDEN_SECTORS;    */   HIDDEN_SECTS,
   /* RESERVED_SECTORS;  */   RESERVED_SECTS
};

FILE_PTR Dev_Handle1;


void RAM_disk_start
   (
   )
{ /* Body */
   FILE_PTR                   dev_handle1,
                              a_fd_ptr;
   int_32                     error_code;
   MFS_IOCTL_FORMAT_PARAM     format_struct;

   a_fd_ptr = 0;

   format_struct.FORMAT_PTR = &MFS_format;
   /* Install the memory device */
   error_code = _io_mem_install("mfsram:", NULL,
      MFS_format.BYTES_PER_SECTOR * RAMDISK_NUMBER_OF_SECTORS);
   if ( error_code != MQX_OK ) {
      printf("\nError installing memory device (0x%x)", error_code);
      _task_block();
   } /* Endif */

   /* Open the device which MFS will be installed on */
   Dev_Handle1 = dev_handle1 = fopen("mfsram:", 0);
   if ( dev_handle1 == NULL ) {
      printf("\nUnable to open ramdisk device");
      _task_block();
   } /* Endif */

   /* Install MFS  */
   error_code = _io_mfs_install(dev_handle1, "a:", 0);
   if (error_code != MFS_NO_ERROR) {
      printf("\nError initialising a:");
      _task_block();
   } else {
      printf("\n--->Initialized RAM Disk to a:\\");
   } /* Endif */

   /* Open the filesystem and format it if necessary */
   A_FD_PTR = a_fd_ptr = fopen("a:", 0);
   error_code    = ferror(a_fd_ptr);
   if ((error_code != MFS_NO_ERROR) && (error_code != MFS_NOT_A_DOS_DISK))
   {
      printf("\nError while openning a:\\ (%s)", Error_text(error_code));
      _task_block();
   } /* Endif */
   MASS_STORAGE_DISK = ((IO_MEM_STRUCT_PTR)
         (dev_handle1->DEV_PTR->DRIVER_INIT_PTR))->BASE_ADDR;
   printf(" (Sector Data at 0x%x)", MASS_STORAGE_DISK);

   /* Formating */
   MFS_format.NUMBER_OF_SECTORS = RAMDISK_NUMBER_OF_SECTORS;
   error_code = ioctl(a_fd_ptr, IO_IOCTL_FORMAT, (uint_32_ptr)&format_struct);
   if (error_code != MFS_NO_ERROR) {
      printf("\nError while formatting (%s)", Error_text(error_code));
      _task_block();
   } /* Endif */
   if (!error_code) {
      error_code = ioctl(a_fd_ptr, IO_IOCTL_SET_VOLUME, "ARC USBdisk");
      if (error_code != MFS_NO_ERROR) {
         printf("\nError while Setting Volume Name (%s)", Error_text(error_code));
         _task_block();
      } /* Endif */
   } /* Endif */
} /* Endbody */


/*TASK*-------------------------------------------------------------------
*
* Task Name    : File_task
* Comments     :
*    This file tests functions in the mfsdemo1.C module.
*
*END*----------------------------------------------------------------------*/

void File_task
   (
      uint_32 parameter
   )
{
#if (TEST_WITH_MEMORY_DEVICE == 0)
   uint_32                    i;
   FILE_PTR                   pm_fd_ptr;
   uchar_ptr                  dev_info;
#else
   MFS_IOCTL_FORMAT_PARAM     format_struct;
#endif
   int_32                     error_code;
   FILE_PTR                   dev_handle2,
                              b_fd_ptr;

   boolean                    partition_found = FALSE;

   B_FD_PTR = b_fd_ptr = 0;

   printf("\n--->Removable disk found");

#if (TEST_WITH_MEMORY_DEVICE == 1)
   format_struct.FORMAT_PTR = &MFS_format;
   error_code = _io_mfs_install(dev_handle2, "b:", 0);
   if (error_code != MFS_NO_ERROR) {
      printf("\nError while initialising b:\n");
      _task_block();
   } else {
      printf("\nInitialized %s", "b:");
   } /* Endif */

   B_FD_PTR = b_fd_ptr = fopen("b:", 0);
   error_code    = ferror(b_fd_ptr);
   if ( error_code == MFS_NOT_A_DOS_DISK ) {
      printf("NOT A DOS DISK! You must format to continue.");
   } /* Endif */
   printf("\nFormating...");
   MFS_format.NUMBER_OF_SECTORS = RAMDISK_NUMBER_OF_SECTORS;
   error_code = ioctl(b_fd_ptr, IO_IOCTL_FORMAT,
      (uint_32_ptr) &format_struct);
   if ( !error_code ) {
      error_code = ioctl(b_fd_ptr, IO_IOCTL_SET_VOLUME, "NO NAME");
   } /* Endif */
   if (error_code != MFS_NO_ERROR) {
      printf("\nError while formatting: %s",
         Error_text(error_code));
         _task_block();
   } /* Endif */
   printf("\nDone.");

#else
   /* Open the USB mass storage  device */
   //_time_delay(50);
   dev_handle2 = fopen(USB_DISK, (char_ptr) parameter);
   if (dev_handle2 == NULL) {
      printf("\nUnable to open USB disk");
      FILE_TASK_ID = MQX_NULL_TASK_ID;
      _lwsem_post(&file_task_sem);
      return;
   } /* Endif */

   _io_ioctl(dev_handle2, USB_MFS_SET_BLOCK_MODE, NULL);
   DEV_FD_PTR = dev_handle2;

   printf("\n*************************************************");
   printf("***********************");

   /* get the vendor information and display it */
   _io_ioctl(dev_handle2, USB_MFS_VENDOR_INFO, &dev_info);
   printf("\n           Vendor Information:            ");
   for (i=0; i<8;i++) {
      printf("%c", dev_info[i]);
      fflush(stdout);
   } /* Endfor */
   printf(" Mass Storage Device");
   _io_ioctl(dev_handle2, USB_MFS_PRODUCT_ID, &dev_info);
   printf("\n           Product Identification:        ");
   for (i=0;i<16;i++) {
      printf("%c", dev_info[i]);
      fflush(stdout);
   } /* Endfor */
   _io_ioctl(dev_handle2, USB_MFS_PRODUCT_REV, &dev_info);
   printf("\n           Product Revision Level:        ");
   for (i=0;i<4;i++) {
      printf("%c", dev_info[i]);
      fflush(stdout);
   } /* Endfor */

   printf("\n*************************************************");
   printf("***********************");

   /* Try Installing a the partition manager */
   error_code = _io_part_mgr_install(dev_handle2, "PM:", 0);
   if (error_code != MFS_NO_ERROR) {
      printf("\nError while initializing (%s)", Error_text(error_code));
      _task_block();
   } /* Endif */
   pm_fd_ptr = fopen("PM:", NULL);
   if (pm_fd_ptr == NULL) {
      error_code = ferror(pm_fd_ptr);
      printf("\nError while openning partition (%s)", Error_text(error_code));
      _task_block();
   } /* Endif */
   PM_FD_PTR = pm_fd_ptr;

   printf("\n--->USB Mass storage device opened");

   i = 1;
   error_code = _io_ioctl(pm_fd_ptr, IO_IOCTL_VAL_PART, &i);
   if (error_code == PMGR_INVALID_PARTITION) {
      printf("\n--->No partition availible on this device");
      /* uninitialize and exit */
      fclose(pm_fd_ptr);
      _io_part_mgr_uninstall("PM:");
      /* install MFS without partition */
      error_code = _io_mfs_install(dev_handle2, "b:", 0);
      PM_FD_PTR = NULL;
   } else {
      printf("\n--->Partition Manager installed");
      partition_found = TRUE;
      /* Install MFS on the partition #1 */
      error_code = _io_mfs_install(pm_fd_ptr, "b:", 1);
   } /* Endif */

   if (error_code != MFS_NO_ERROR) {
      printf("\nError initialising MFS (%s)", Error_text(error_code));
      /* uninitialize and exit */
       if (partition_found) {
         fclose(pm_fd_ptr);
         _io_part_mgr_uninstall("PM:");
       } /* Endif */
       fclose(dev_handle2);
      _task_block();
   } else {
      printf("\n--->Mounting the device to b:\\\n");
   } /* Endif */

   /* Open the filesystem and format it if necessary */
   B_FD_PTR = b_fd_ptr = fopen("b:", 0);
   MFS_FD_PTR = b_fd_ptr;
   if (b_fd_ptr == NULL) {
      error_code = _task_get_error();
      printf("\nError while openning b:\\ (task error=0x%x - %s)", error_code,
         Error_text(error_code));
      _task_block();
   } /* Endif */

   printf("USB filesystem opened!\n");
   error_code = ferror(b_fd_ptr);
   if ( error_code == MFS_NOT_A_DOS_DISK ) {
      printf("\n--->NOT A DOS DISK! You must format the disk using a PC");
      /* uninitialize and exit */
       _io_mfs_uninstall("b:");
       if (partition_found) {
         fclose(pm_fd_ptr);
         _io_part_mgr_uninstall("PM:");
       } /* Endif */
       fclose(dev_handle2);
      _task_block();
   } /* Endif */
#endif

   error_code = MFS_NO_ERROR;

   DosShell(0);

   fclose(B_FD_PTR);

   File_destroy_task(1);

} /* Endbody */


/*TASK*-------------------------------------------------------------------
*
* Task Name    : File_destroy_task
* Comments      : Uninitiializes the file task.
*
*END*----------------------------------------------------------------------*/

void File_destroy_task
   (
      uint_32  parameter
   )
{ /* Body */
   int_32    devnum, error_code = IO_OK;
   _task_id  temp_task_id;

   //printf("\n_mem_get_highwater = 0x%x", _mem_get_highwater());
   //printf("\nFree system memory =  %dK",
   //   ((uint_32)MQX_init_struct.END_OF_KERNEL_MEMORY-(uint_32)_mem_get_highwater())/1024);

   devnum = 0;
   _int_disable();
   if (!parameter) {
      printf("\n--->Device removed");
      error_code = fclose(MFS_FD_PTR);
      if ( error_code != IO_OK ) {
         printf("\nError closing MFS device: 0x%X.", error_code);
      } /* Endif */
      MFS_FD_PTR = NULL;
   } else {
      /*Display the following message only if we did not come here
      because user wanted to do an HNP */
      if(!HNP_ATTEMPTED)
      {
         printf("\nThe Device can now be removed from the system.");
      }
   } /* Endif */

   error_code = _io_mfs_uninstall("b:");
   if (error_code != MFS_NO_ERROR) {
      printf("\nError while uninstalling MFS on device");
      _mqx_exit(1);
   } /* Endif */

   if (PM_FD_PTR != NULL) {
      /* Close partition device */
      error_code = fclose(PM_FD_PTR);
      if ( error_code != IO_OK ) {
         printf("\nError closing Partition device %d: 0x%X.", devnum, error_code);
         _mqx_exit(1);
      } /* Endif */
      PM_FD_PTR = NULL;

      /* Uninstall the partition manager */
      error_code = _io_part_mgr_uninstall("PM:");
      if ( error_code != IO_OK ) {
         printf("\nError uninstalling Partition device %d: 0x%X.", devnum, error_code);
         _mqx_exit(1);
      } /* Endif */
   } /* Endif */

   /* USB mass storage link device */
   error_code = fclose(DEV_FD_PTR);
   if ( error_code != IO_OK ) {
      printf("\nError closing disk (0x%X)", error_code);
      _mqx_exit(1);
   } /* Endif */
   DEV_FD_PTR = NULL;
   /* Destroy the file system task */

   if (Test_Buffer) {
      error_code = _mem_free(Test_Buffer);
      if (error_code != MQX_OK) {
         printf("\nError Freeing Test_Buffer Memory (0x%x)", error_code);
      } else {
         Test_Buffer = NULL;
      } /* Endif */
   } /* Endif */

   if (Test_Buffer2) {
      error_code = _mem_free(Test_Buffer2);
      if (error_code != MQX_OK) { /* Body */
         printf("\nError Freeing Test_Buffer2 Memory (0x%x)", error_code);
      } else {
         Test_Buffer2 = NULL;
      } /* Endif */
   } /* Endif */

   temp_task_id = FILE_TASK_ID;
   FILE_TASK_ID = MQX_NULL_TASK_ID;
   _lwsem_post(&file_task_sem);
   _int_enable();

   if (!parameter) {
      _task_destroy(temp_task_id);
   } /* Endif */

} /* Endif */


void file_task_launch(pointer ccs_ptr) 
{
   _io_usb_mfs_install(USB_DISK, 0, ccs_ptr);
   _lwsem_create(&file_task_sem, 0);
#if 0
   File_task(0);
#else
   FILE_TASK_ID = _task_create(0, FILE_TASK, 0);
#endif
}

void file_task_destroy_if_active() 
{
   /*
   ** This function should mark the filesystem task to be destroyed. It may not
   ** happen immediately, because we may be in an ISR which is running in the
   ** context of the filesystem task. We can destroy the filesystem task
   ** gracefully (by allowing it to end by itself) or it can also be destroyed
   ** from the context of the Main_task
   */
   if (FILE_TASK_ID) {
      _lwsem_post(&file_task_sem);
   } /* Endif */
}

void file_task_block_until_destroyed() 
{
   _lwsem_wait(&file_task_sem);
   if (FILE_TASK_ID) {
      File_destroy_task(0);
   } /* Endif */
   _lwsem_destroy(&file_task_sem);
}

/* EOF */
