/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains the host specific code for the demo
***
**************************************************************************
**END*********************************************************/

/**************************************************************************
Include the OS and BSP dependent files that define IO functions and
basic types. You may like to change these files for your board and RTOS 
**************************************************************************/
#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
   #include "bsp.h"
   #include "fio.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif
#include "stdlib.h"
#include "string.h"
#endif

/**************************************************************************
Include the USB stack header files.
**************************************************************************/

#ifdef __USB_OTG__
#include "otgapi.h"
#else
#include "hostapi.h"
#include "devapi.h"
#endif

/**************************************************************************
Local header files for this application
**************************************************************************/
#include "mfsdemo.h"
#include "demo.h"
#include "demo_d.h"
#include "demo_h.h"


/**************************************************************************
   Global variables
**************************************************************************/
volatile DEVICE_STRUCT        device = { 0 }; /* device struct  */
volatile APP_GLOBAL_STRUCT    app_test_struct;
boolean  HNP_ATTEMPTED = FALSE;
volatile boolean  SUSPEND_ATTEMPTED = FALSE;
volatile boolean  RESUME_RECEIVED = FALSE;
extern _usb_otg_handle        app_otg_handle;
extern _usb_device_handle     dev_handle;

/* Run this test mode the next time a device connects. */ 
extern uint_16                hc_test_mode;

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : app_process_host_resume
* Returned Value :
* Comments       :
*     Callback function to process the remote-wakeup/K-Attach event
*
*END*--------------------------------------------------------------------*/
void app_process_host_resume
   (
      _usb_host_handle  handle,
      uint_32           length
   )
{ /* Body */
   uint_32  state;

   _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);
   /*set the resume to true since we came  here */
   RESUME_RECEIVED = TRUE;
   if (state < B_IDLE) {
      _usb_otg_set_status(app_otg_handle, USB_OTG_B_BUS_RESUME, TRUE);
   } else {
      _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_RESUME, TRUE);
   } /* Endif */

} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : app_process_HNP
* Returned Value :
* Comments       :
*     function to process the HNP request. This routine is called when
* Host wants to do an HNP. The procedure to do HNP is as follows.

1) Find whether device supports HNP or not from its config descriptor
2) Send a USB set feature command to do HNP

If command fails suspend the bus because Host does not know what to do now.
This is required behaviour from OTG compliance (run OPT tester to check this)

If command succeeds move to peripheral state by controlling the OTG
parameters (see OTG state machine diagram)
*
*END*--------------------------------------------------------------------*/
void app_process_HNP
   (
      _usb_host_handle  handle
   )
{ /* Body */
   uint_32                       state, i, total_len, error;
   boolean                       otg_des_found = FALSE;
   boolean                       hnp_capability = FALSE;


   _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);

   app_test_struct.TRANSACTION_COMPLETE = FALSE;

   /*******************************************************************
      Check if this device supports HNP or not
   *******************************************************************/

   /* Get the configuration descriptor */
   error = _usb_hostdev_get_descriptor((pointer)device.DEV_HANDLE,
         DESCTYPE_CONFIG, 0, 0,
         (pointer)&app_test_struct.RX_CONFIG_DESC);

   if (error) {
       printf("HNP Failed: _usb_hostdev_get_descriptor returned %d\n", error);
       return;
   }

   app_test_struct.TRANSACTION_COMPLETE = FALSE;

   /* Find out the length of the transfer */
   total_len = app_test_struct.RX_CONFIG_DESC[2];
   total_len |= app_test_struct.RX_CONFIG_DESC[3] << 8;
   for (i=0;i < total_len;)
   {
      /* checking for OTG descriptor type */
      if (app_test_struct.RX_CONFIG_DESC[i+1] ==
         USB_OTG_DESCRIPTOR_TYPE)
      {
         otg_des_found = TRUE;
         break;
      } else {
         i = i + app_test_struct.RX_CONFIG_DESC[i];
      } /* Endif */
   } /* Endfor */

    /* Check if HNP enabled for device */
   if ((otg_des_found) && ((app_test_struct.RX_CONFIG_DESC[i+2]) & 0x02))
   {

      hnp_capability  = TRUE;
   }

   /*******************************************************************
   ACTION 1 (if device supports HNP do it)
   *******************************************************************/

   if ((state < B_IDLE) && hnp_capability)
   {
      printf("Device supports HNP\n");
      printf("Attempting to set HNP enable ....\n");
      app_test_struct.TRANSACTION_STATUS = USB_OK;

      error = _usb_host_register_ch9_callback(device.DEV_HANDLE,
                                             app_process_pipe_transaction_done,
                                             device.INTF_HANDLE);

      if (error) {
          printf("HNP Failed: _usb_host_register_ch9_callback returned %d\n",
                 error);
          return;
      }


      error = _usb_host_ch9_set_feature(device.DEV_HANDLE,0,0,3);

      if (error) {
          printf("HNP Failed: _usb_host_ch9_set_feature returned %d\n",
                 error);
          return;
      }

      /*wait till the request completes */
      while (!app_test_struct.TRANSACTION_COMPLETE) {
         /* Wait until transaction is complete */
   
         if(device.STATE == USB_DEVICE_DETACHED)
         {
            printf("device gone returning\n");
            return;
         }
      }
            
      if(app_test_struct.TRANSACTION_STATUS == USB_OK)
      {
         printf("HNP enable successful with device\n");
         SUSPEND_ATTEMPTED = TRUE;
         _usb_otg_set_status(app_otg_handle, USB_OTG_A_SET_B_HNP_ENABLE, TRUE);
         _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_SUSPEND_REQ, TRUE);
         _usb_otg_set_status(app_otg_handle, USB_OTG_A_BUS_REQ, FALSE);
      }
      else
      {
         printf("HNP enable failed with device...suspending the bus\n");
         SUSPEND_ATTEMPTED = TRUE;
         device.STATE = USB_DEVICE_SUSPEND_ATTEMPTED;
         /* CALL the Host API function to suspend the bus */
         _usb_host_bus_control(handle, USB_SUSPEND_SOF);

      }

   }

   /*******************************************************************
   ACTION 2 (if device does not supports HNP just suspend the bus)
   *******************************************************************/

   else if (state < B_IDLE)
   {
         printf("Device does not supports HNP\n");
         printf("Suspending the bus ....\n");

         /* OPT tester expects that if we don't support the device
         we should suspend the bus. Test 4.10. It should not be done
         normally because test 4.1 documentation does not say this
         but test program makes it necessary to do this to pass the test.
         If this is done in a normal program, we have problem in reattaching
         the device.*/
         /* CALL the Host API function to suspend the bus */
         /*ensure that we start monitoring for resume after this */
         SUSPEND_ATTEMPTED = TRUE;
         device.STATE = USB_DEVICE_SUSPEND_ATTEMPTED;
         _usb_host_bus_control(handle, USB_SUSPEND_SOF);

   }

   /*******************************************************************
   ACTION 3 (we were in B_HOST so just release the host control)
   *******************************************************************/

   else //case when we are in B_HOST
   {
       printf("Releasing Host control and suspending the bus..\n");
       device.STATE = USB_DEVICE_SUSPEND_ATTEMPTED;
       /*ensure that we start monitoring for resume after this */
       SUSPEND_ATTEMPTED = TRUE;
       /* CALL the Host API function to suspend the bus */
       _usb_host_bus_control(handle, USB_SUSPEND_SOF);
   }

}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : app_process_pipe_transaction_done
* Returned Value :
* Comments       :
*     Callback function to process the transaction done event.
* This routine is registered when sending a control pipe request.
*
*END*--------------------------------------------------------------------*/
void app_process_pipe_transaction_done
   (
      /* [IN] pointer to pipe */
      _usb_pipe_handle  pipe_handle,

      /* [IN] user-defined parameter */
      pointer           user_parm,

      /* [IN] buffer address */
      uchar_ptr         buffer,

      /* [IN] length of data transferred */
      uint_32           length_data_transfered,

      /* [IN] status, hopefully USB_OK or USB_DONE */
      uint_32           status
   )
{ /* Body */
   app_test_struct.TRANSACTION_COMPLETE = TRUE;
   app_test_struct.TRANSACTION_STATUS = status;
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_mass_device_event
* Returned Value : None
* Comments       :
*     called when a mass storage device has been attached, detached, etc.
*END*--------------------------------------------------------------------*/
void usb_host_mass_device_event
   (
      /* [IN] pointer to device instance */
      _usb_device_instance_handle      dev_handle,

      /* [IN] pointer to interface descriptor */
      _usb_interface_descriptor_handle intf_handle,

      /* [IN] code number for event causing callback */
      uint_32           event_code
   )
{
   INTERFACE_DESCRIPTOR_PTR   intf_ptr =
      (INTERFACE_DESCRIPTOR_PTR)intf_handle;

   switch (event_code) {
      case USB_CONFIG_EVENT:
         /* Drop through into attach, same processing */
      case USB_ATTACH_EVENT:
         if (device.STATE == USB_DEVICE_IDLE ||
            device.STATE == USB_DEVICE_DETACHED)
         {
            device.DEV_HANDLE = dev_handle;
            device.INTF_HANDLE = intf_handle;
            device.STATE = USB_DEVICE_ATTACHED;
            device.SUPPORTED = TRUE;
         }
         break;
      case USB_INTF_EVENT:
         device.STATE = USB_DEVICE_INTERFACED;
         break;
      case USB_DETACH_EVENT:
         device.DEV_HANDLE = NULL;
         device.INTF_HANDLE = NULL;
         device.STATE = USB_DEVICE_DETACHED;
         file_task_destroy_if_active();
         break;
      default:
         device.STATE = USB_DEVICE_IDLE;
         break;
   } /* EndSwitch */

} /* Enbbody */
/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_device_event
* Returned Value : None
* Comments       :
*     called when non storage device has been attached, detached, etc.
* Note that this example supports only storage devices and hence it sets
device.SUPPORTED to FALSE when a non storage device is attached.
*END*--------------------------------------------------------------------*/
void usb_host_device_event
   (
      /* [IN] pointer to device instance */
      _usb_device_instance_handle      dev_handle,

      /* [IN] pointer to interface descriptor */
      _usb_interface_descriptor_handle intf_handle,

      /* [IN] code number for event causing callback */
      uint_32           event_code
   )
{
   INTERFACE_DESCRIPTOR_PTR   intf_ptr =
      (INTERFACE_DESCRIPTOR_PTR)intf_handle;

   switch (event_code) {
      case USB_CONFIG_EVENT:
         /* Drop through into attach, same processing */
      case USB_ATTACH_EVENT:
         if (device.STATE == USB_DEVICE_IDLE ||
            device.STATE == USB_DEVICE_DETACHED)
         {
            device.DEV_HANDLE = dev_handle;
            device.INTF_HANDLE = intf_handle;
            device.SUPPORTED = FALSE;
            _usb_host_ch9_set_interface(device.DEV_HANDLE, 0, 0);
            device.STATE = USB_DEVICE_INTERFACED;
         } /* EndIf */
         break;
      case USB_INTF_EVENT:
         device.STATE = USB_DEVICE_INTERFACED;
         break;
      case USB_DETACH_EVENT:
         device.DEV_HANDLE = NULL;
         device.INTF_HANDLE = NULL;
         device.STATE = USB_DEVICE_DETACHED;
         break;
      default:
         device.STATE = USB_DEVICE_IDLE;
         break;
   } /* EndSwitch */

} /* Enbbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : host_main
* Returned Value :
* Comments       :
*     The Main function to handle HOST function of OTG example code.
*END*--------------------------------------------------------------------*/
void host_main
   (
      _usb_host_handle  handle
   )
{
   uint_32                       state = 0;
   char                          c;
   uint_32 last_state            = 0xFFFF;
   USB_HOST_STATE_STRUCT_PTR     usb_host_ptr;

   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);

   /*************************************************************************
   Once the OTG application enters the host state, it loops through a busy
   while loop checking for the state change. If state does not remain
   as Host, it returns the control back to OTG main loop (see file demo.c)
   *************************************************************************/
   
   while ((state == A_HOST) | (state == B_HOST)) 
   {
      DEV_INSTANCE_PTR           dev_inst_ptr;

      dev_inst_ptr = (DEV_INSTANCE_PTR)device.DEV_HANDLE;

      /*************************************************************************
      Keep taking action based on the event that ocsured      .
      *************************************************************************/

      switch ( device.STATE ) 
      {
            case USB_DEVICE_IDLE:
               break ;
            case USB_DEVICE_SUSPEND_ATTEMPTED:
               /*if a suspend is attempted by Host, software should
               not take any action. OTG state changes will take
               software out of while loop automatically */
               break;                  
            case USB_DEVICE_ATTACHED:
            /*************************************************************************
            If an attach has occured and device is supported, 
            select the interface, on the device now. If we came
            here because of a resume, we don't need to repeat the
            select interface process.
            *************************************************************************/

            /* Check to see if this is HS Host Electrical Test Fixture */
            if (utoh16(dev_inst_ptr->dev_descriptor.idVendor) == 0x1A0A)
            {
               uint_16 idProduct = utoh16(dev_inst_ptr->dev_descriptor.idProduct);

               if (idProduct >= 0x0101 && idProduct <= 0x0108)
               {
                  _usb_host_test_mode(handle, dev_inst_ptr,
                        utoh16(dev_inst_ptr->dev_descriptor.idProduct), 0);
               }
            }

            if (hc_test_mode)
            {
               _usb_host_test_mode(handle, dev_inst_ptr, hc_test_mode, 0);
            }

            if ((device.SUPPORTED) && (!SUSPEND_ATTEMPTED) &&
                (!RESUME_RECEIVED))
            {
                  _usb_hostdev_select_interface(device.DEV_HANDLE,
                     device.INTF_HANDLE, (pointer)&device.CLASS_INTF);
                  device.STATE = USB_DEVICE_INTERFACED;\
                  /*********************************************************
                  The following is an OS dependent code. Use your OS
                  way of launching file system in a separate thread.
                  **********************************************************/
               
                  /* Launch the filesystem task */
                  file_task_launch((pointer)&device.CLASS_INTF);
                  file_task_block_until_destroyed();
             }
             /*********************************************************
             For non supported device we do HNP to give them an 
             opportunity to be coem host
             *********************************************************/
 
             else
             {
                  printf("Device not supported\n");
                  printf("test\n");
                  fflush(stdout);
                  device.STATE = USB_DEVICE_INTERFACED;
             }

            break ;
         case USB_DEVICE_INTERFACED:
            /*************************************************************************
            If device is interfaced and communictaion has started with it. 
            If it is an unsupported device, we should go ahead and start
            attempting an HNP. If it is a supported device, we just take
            no action because we want to stay as it is and keep communictaing
            with it..
            *************************************************************************/

            /* Check to see if this is HS Host Electrical Test Fixture */
            if (utoh16(dev_inst_ptr->dev_descriptor.idVendor) == 0x1A0A)
            {
               uint_16 idProduct = utoh16(dev_inst_ptr->dev_descriptor.idProduct);

               if (idProduct >= 0x0101 && idProduct <= 0x0108)
               {
                  _usb_host_test_mode(handle, dev_inst_ptr,
                        utoh16(dev_inst_ptr->dev_descriptor.idProduct), 0);
               }
            }
            if (hc_test_mode)
            {
               _usb_host_test_mode(handle, dev_inst_ptr, hc_test_mode, 0);
            }

            if(SUSPEND_ATTEMPTED) break; /*return if we attempted to suspend */

             if (!device.SUPPORTED);
            {

                printf("Device not supported\n");
                printf("suspend attempted = %d\n",SUSPEND_ATTEMPTED);
                fflush(stdout);
                app_process_HNP(handle);
            }
            /*****************************************************
            In file system demo, when user types the command 'hnp'
            it sets the HNP_ATTEMPTED boolean to TRUE and program
            comes to this loop. The following code will ensure
            that user is able to do HNP with the device.
            *****************************************************/
            
            if (HNP_ATTEMPTED) 
            {
                printf("\nAttempting an HNP with device...\n");
                fflush(stdout);
                app_process_HNP(handle);
                HNP_ATTEMPTED = FALSE;
            }
            
            break;
      }
      /*************************************************************************
      Keep checking the state of the OTG state machine
      *************************************************************************/

      _usb_otg_get_status(app_otg_handle, USB_OTG_STATE, &state);
   
   } /* Endwhile */

} /* Endbody */

/* EOF */
