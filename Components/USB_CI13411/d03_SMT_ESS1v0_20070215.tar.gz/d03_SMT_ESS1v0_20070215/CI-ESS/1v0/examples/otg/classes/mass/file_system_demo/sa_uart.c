//	 SSSS   AAA          U   U   AAA   RRRR   TTTTT
//	S      A   A         U   U  A   A  R   R    T  
//	 SSS   AAAAA         U   U  AAAAA  RRRR     T  
//	    S  A   A         U   U  A   A  R  R     T  
//	SSSS   A   A  _____   UUU   A   A  R   R    T  

#ifdef __USB_OTG__
#include "otgapi.h"
#else
#include "hostapi.h"
#include "devapi.h"
#endif
//#include "demo_d.h"
//#include "demo.h"
//#include "demo_h.h"
#ifdef __USB_OS_MQX__
//   #include "bsp.h"
//   #include "mqx_arc.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif   
   #include "stdlib.h"
#endif

#include "string.h"

#include "sa_uart.h"


typedef volatile unsigned char *PREG;

PREG	uart;
PREG	uartTx;
PREG	uartBaudLo;
PREG	uartBaudHi;
PREG	uartStatus;

#define	ENABLE_TX_INTERRUPT		*uartStatus = 0x40
#define	DISABLE_TX_INTERRUPT	*uartStatus = 0x00


uint_8	uartBuffer[0x10000];
volatile uint_16	uartHead = 0;
volatile uint_16	uartTail = 0;


_Interrupt1 void uartISR()
{
	if (*uartStatus & 0x80)	// TXEMPTY
		{
		if (uartHead != uartTail)	// something in queue
			*uartTx = uartBuffer[uartTail++];
		else						// nothing in queue
			DISABLE_TX_INTERRUPT;
		}

	return;
}

uint_16	*pint4 = (uint_16 *)(4*8);


void uartInit(void)
{
//	uint_16		baud;
//	uint_32		clock;

	uart = (PREG)
		(
			(read_aux_reg(BCR_PERIPHERAL_BASE_ADDR) & 0xffffff00) +
			PERIPHERAL_OFFSET_TO_UART
		);

	uartTx = &uart[0x10];
	uartBaudLo = &uart[0x18];
	uartBaudHi = &uart[0x1c];
	uartStatus = &uart[0x14];

//	clock = _bsp_get_system_clock();
//
//#if defined(_HIGHSPEED_)
//	baud = 30000000 / 9600 / 4 - 1;	// HS clock rate is 30mhz
//#elif defined (_FULLSPEED_)
//	baud = 24000000 / 9600 / 4 - 1;	// FS clock rate is 24mhz
//#else
//	error "Must define _HIGHSPEED_ or _FULLSPEED_"
//#endif
//
//	*uartBaudLo = (uint_8)baud;
//	*uartBaudHi = (uint_8)(baud>>8);

	pint4[0] = 0x2020; /* Hi word of JL */
	pint4[1] = 0x0F80; /* Lo word of JL */
	pint4[2] = ((uint_32)uartISR) >> 16;
	pint4[3] = (uint_16)uartISR;

//#if defined(_HIGHSPEED_)
//	uartputs("\n\nUART set to 9600 BAUD\nHIGH Speed");
//#else
//	uartputs("\n\nUART set to 9600 BAUD\nFULL Speed");
//#endif

	uartputs("\n\nUART running at default speed");

	return;
}

#ifdef _SA_UART_

uint_32		waits = 0;

void uartputc(char c)	// does not block
{

	if (uartHead == uartTail)		// nothing in queue
		if (*uartStatus & 0x80)		// TXEMPTY
			{
			*uartTx = c;			// send this char pronto
			return;
			}

	if ((uartHead+1) != uartTail)	// queue not full
		{
		uartBuffer[uartHead++] = c;	// add char to queue
		ENABLE_TX_INTERRUPT;
		}

	return;
}

void uartflush(void)
{
	DISABLE_TX_INTERRUPT;

	while (uartHead != uartTail)
		{
		if (*uartStatus & 0x80)	// TXEMPTY
			*uartTx = uartBuffer[uartTail++];
		}
	return;
}


void uartputs(char *s)		// doesn't block while UART is not ready for tx
{

	while (*s)
		{
//		while ((*uartStatus & 0x80) == 0x00)
//			waits++;
		uartputc(*s++);
		}

	return;
}

static char uartprintf_buffer[129];

void uartprintf(char *format, ...)
{
	va_list ap;

	va_start(ap, format);
	vsprintf(uartprintf_buffer, format, ap);	/* format into string */
	va_end(ap);
	uartputs(uartprintf_buffer);
	return;
}

char hex[17] = "0123456789abcdef";

void uartput8(uint_8 u8)	// doesn't block while UART is not ready for tx
{
	char	buff[3];

	buff[0] = hex[(u8>> 4) & 0x0f];
	buff[1] = hex[(u8>> 0) & 0x0f];
	buff[2] = '\0';
	uartputs(buff);
	return;
}
void uartput16(uint_16 u16)	// doesn't block while UART is not ready for tx
{
	uartput8((uint_8) (u16 >> 8));
	uartput8((uint_8) (u16 >> 0));
	return;
}

void uartput32(uint_32 u32)	// doesn't block while UART is not ready for tx
{
	uartput16((uint_16) (u32 >> 16));
	uartput16((uint_16) (u32 >>  0));
	return;
}


char	*state_name[13] =
	{
	"OTG_START",
	"A_IDLE",
	"A_WAIT_VRISE",
	"A_WAIT_BCON",
	"A_HOST",
	"A_SUSPEND",
	"A_PERIPHERAL",
	"A_WAIT_VFALL",
	"B_IDLE",
	"B_SRP_INIT",
	"B_PERIPHERAL",
	"B_WAIT_ACON",
	"B_HOST"
	};

#endif	// _SA_UART_

