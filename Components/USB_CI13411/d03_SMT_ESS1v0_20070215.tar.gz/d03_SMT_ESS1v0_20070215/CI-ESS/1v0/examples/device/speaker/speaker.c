/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***  This file contains the USB speaker application that demonstrates
*** how to use an ISO pipe with ARC USB stack. It pretends as a USB
*** speaker to windows PC and if PC sends an ISO OUT data, it receives
*** it in a buffer. This program also changes the max packetsize of the
*** end point based on the alternate setting selected by the host.
***                                                               
**************************************************************************
**END*********************************************************/

/**************************************************************************
Include the USB stack header files.
**************************************************************************/
#include "usb.h"
#include "devapi.h"
#include "speaker.h"

/**************************************************************************
Include the OS and BSP dependent files that define IO functions and
basic types. You may like to change these files for your board and RTOS 
**************************************************************************/

#ifdef __USB_OS_MQX__
   #include "bsp.h"
   #include "fio.h"
   #include "mqx_arc.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif   
   #include "stdlib.h"
#endif
#include "string.h"


#define  DEV_DESC_MAX_PACKET_SIZE      (7)
#define  APP_CONTROL_MAX_PKT_SIZE      (64)
#define  TEST_SIZE                     (300)
#define  ISO_BUFFER_SIZE               1024
uchar  ISO_BUFFER[ISO_BUFFER_SIZE];

volatile boolean  ENTER_TEST_MODE = FALSE;
volatile uint_16  test_mode_index = 0;
volatile uchar    speed = 0;

#ifdef __USB_OS_MQX__
extern void Main_Task(uint_32 param);
#define MAIN_TASK       10

TASK_TEMPLATE_STRUCT  MQX_template_list[] =
{
   { MAIN_TASK,      Main_Task,      3000L,  7L, "Main",      MQX_AUTO_START_TASK},
   { 0L,             0L,             0L,   0L, 0L,          0L }
};
#endif

/**************************************************************************
DESCRIPTORS DESCRIPTORS DESCRIPTORS DESCRIPTORS DESCRIPTORS DESCRIPTORS
**************************************************************************/

/* Device descriptors are always 18 bytes */
uint_8  DevDesc[18] =
{
   18,                        /* bLength Length of this descriptor */
   1,                         /* bDescType This is a DEVICE descriptor */
   /* BCD USB version */
   0,2,                       /* bcdUSB USB revision 2.0 */
   0,                         /* bDeviceClass */
   0,                         /* bDeviceSubClass */
   0,                         /* bDeviceProtocol */
   APP_CONTROL_MAX_PKT_SIZE,  /* bMaxPacketSize0 */
   /* Vendor ID */
   USB_uint_16_low(0x0B20), USB_uint_16_high(0x0B20),
   /* Product ID */
   USB_uint_16_low(0x1), USB_uint_16_high(0x1),
   /* BCD Device version */
   USB_uint_16_low(0x0002), USB_uint_16_high(0x0002),
   0x01,                      /* iManufacturer */
   0x02,                      /* iProduct */
   0x00,                      /* iSerialNumber */
   0x01                       /* bNumConfigurations */
};

/* USB 2.0 specific descriptor */
uint_8  DevQualifierDesc[10] =
{
   sizeof(DevQualifierDesc),  /* bLength Length of this descriptor */
   6,                         /* bDescType This is a DEVICE Qualifier descr */
   0,2,                       /* bcdUSB USB revision 2.0 */
   0,                         /* bDeviceClass */
   0,                         /* bDeviceSubClass */
   0,                         /* bDeviceProtocol */
   APP_CONTROL_MAX_PKT_SIZE,  /* bMaxPacketSize0 */
   0x01,                      /* bNumConfigurations */
   0
};

#define CONFIG_DESC_NUM_INTERFACES  (4)

/* This must be counted manually and updated with the descriptor */
#define  CONFIG_DESC_SIZE           (0x86)
#define  USB_NUM_IFACES             (0x02)

#define  ENDPOINT_SPEAKER           (0x01)
#define  ENDPOINT_CONTROL           (0x00)

#define  IFC1_ALT0_MAX_LO           (0x00)
#define  IFC1_ALT0_MAX_HI           (0x00)
#define  IFC1_ALT1_MAX_HI           (0x00)
#define  IFC1_ALT1_MAX_LO           (0xFF)
uchar    USB_IF_ALT[4] = { 0, 0, 0, 0};

uint_32  USB_ISO_MAX_PACKET_SIZES[4] = 
{
  (IFC1_ALT0_MAX_HI << 16 ) | IFC1_ALT0_MAX_LO,
  (IFC1_ALT1_MAX_HI << 16 ) | IFC1_ALT1_MAX_LO,
};

uint_8 ConfigDesc[CONFIG_DESC_SIZE] =
{
   /* This table is retrieved by the host after the address has been set.
   ** This table defines the configurations available for the device.
   ** See section 9.6.2 of the Rev 1.0 USB specification (page 184).
   ** These fields are application DEPENDENT. 
   ** Be sure to modify these to meet your specifications.
   */
   9,      /* bLength   Length of this descriptor */
   2,      /* bDescType   2=CONFIGURATION */

   CONFIG_DESC_SIZE & 0xff, CONFIG_DESC_SIZE >> 8,
   USB_NUM_IFACES,      /* bNumInterfaces   Number of interfaces */

   /* USB_CONFIG_VAL: */
   0x01,   /* bConfigValue   Configuration Value */
   0x04,   /* iConfig   String Index for this config = #01 */
   0xc0,   /* bmAttributes   attributes - self powered */
   1,      /* MaxPower   self-powered draws 2 mA from the bus. */
   /*   IIIII  FFFFF   CCCC   000 
   **     I    F      C      0   0
   **     I    FFF    C      0   0
   **     I    F      C      0   0
   **   IIIII  F       CCCC   000 
   */

   /* AUDIO CONTROL: See section 9.6.3, Rev 1.0 USB spec (page 185) */

   0x09,   /* blength   Length of this desriptor */
   4,      /* bDescriptorType   4=INTERFACE */
   0,      /* bIfaceNum   interface number */
   0,      /* bAltSetting   Alternate setting 0 (no others) */
   0,      /* bNumEndpoints   Number of endpoints= use EP0 only */
   0x01,   /* bIfaceClass   Interface class 01=AUDIO */
   0x01,   /* bIfaceSubClass   Audio COntrol */
   0x00,   /* bIfaceProtocol   none */
   0,      /* iInterface */

   /* USB_AC_IFACE: Audio Class Specific Audio Control (AC) I/F desc */
   0x09,      /* bLength */
   0x24,      /* Audio class specific interface descriptor */
   0x01,      /* HEADER type */
   0x09,0x00, /* spec rev = 0009 */
   0x1e,0x00, /* total length=001e */
   0x01,      /* number of streaming interfaces=1 */
   0x01,      /* Interface number=1 */

   0x0c,      /* bLength */
   0x24,      /* Audio class specific interface desc */
   0x02,      /* Input Terminal */
   0x01,      /* TerminalID */
   0x01,0x01, /* TerminalType=0101=Audio Streaming */
   0x00,      /* output AssocTerminal */
   0x02,      /* Number of Channels=2 */
   0x03,0x00, /* wChannelConfig=L,R */
   0x00,      /* iChannelNames=none */
   0x00,      /* iTerminal */

   0x09,      /* bLength */
   0x24,      /* Type=Audio class specific interface desc */
   0x03,      /* Output Terminal */
   0x02,      /* TerminalID */
   0x01,0x03, /* TerminalType=0301=Generic Speakers */
   0x00,      /* bAssocTerminal=terminalID connect to=0? */
   0x01,      /* bSourceID=TerminalID which is the source for this 
              ** terminal=feature unit 
              */
   0x00,      /* iTerminal=string */

   /*   IIIII  FFFFF   CCCC    1  
   **     I    F      C       11  
   **     I    FFF    C        1  
   **     I    F      C        1  
   **   IIIII  F       CCCC  11111
   */

   /* AUDIO STREAM See section 9.6.3, Rev 1.0 USB spec (page 185) */

   /*       AAA   L      TTTTT   000 
   **      A   A  L        T    0   0
   **      AAAAA  L        T    0   0
   **      A   A  L        T    0   0
   **      A   A  LLLLL    T     000 
   */

   0x09,   /* blength   Length of this desriptor */
   4,      /* bDescriptorType   4=INTERFACE */
   1,      /* bIfaceNum   interface number #1 */
   0,      /* bAltSetting   Alternate setting 0 Zero ISO Bandwidth 
           ** version which is required by Win98 
           */
   1,      /* bNumEndpoints   Number of endpoints= use EP0 only */
   0x01,   /* bIfaceClass   Interface class 01=AUDIO */
   0x02,   /* bIfaceSubClass   Audio Streaming */
   0x00,   /* bIfaceProtocol   none */
   4,      /* iInterface   String=#01 */

   0x07,   /* bLength */
   0x24,   /* Audio Class Specific AS Interface Desc. */
   0x01,   /* AS_GENERAL */
   0x01,   /* TermLink connected to terminal #1 */
   0x00,   /* Delay=0 */
   0x00,0x01,   /* FormatTag=PCM */

   0x0b,   /* bLength   Format Specification */
   0x24,   /* Audio Class Specific AS Interface Desc. */
   0x02,   /* FORMAT_TYPE */
   0x01,   /* formatType */
   0x02,   /* NrChannels=2 */
   0x02,   /* SubFrameSize=2 byte */
   16,     /* BitResolution=16 bits */
   0x01,   /* SamFreqType=1 type */
   0x00,0x00, /* ZERO BANDWIDTH */
   0x00,      /* SamFreq MSB (it's a 24 bit number in HZ) */

   9,         /* bLength   Length of this descriptor */
   5,         /* bDescType   5=ENDPOINT */
   ENDPOINT_SPEAKER,   /* bEndpntAddr   End Point address (EP1=out) */
   0x09,      /* bmAttr   ISO adaptive rate */
   IFC1_ALT0_MAX_LO,IFC1_ALT0_MAX_HI, /* wMaxPktSize   Max Packet Size */
   1,         /* bInterval */
   0,         /* bRefresh */
   0,         /* SyncAddr   None */

   /* USB_AS_DESC1: Class Specific Audio AS EP descriptor */
   7,         /* bLength   Length of this descriptor */
   0x25,      /* bDescType   Class specific ENDPOINT */
   1,         /* SubType   GENERAL */
   0,         /* bmAttr   none */
   2,         /* bDelayUnits   PCM samples */
   0x01,0x00, /* bLockDelay   1 sample delay */

   /*       AAA   L      TTTTT    1  
   **      A   A  L        T     11  
   **      AAAAA  L        T      1  
   **      A   A  L        T      1  
   **      A   A  LLLLL    T    11111
   */

   0x09,      /* blength   Length of this desriptor */
   4,         /* bDescriptorType   4=INTERFACE */
   1,         /* bIfaceNum   interface number #1 */
   1,         /* bAltSetting   Alternate setting #1 */
   1,         /* bNumEndpoints   Number of endpoints=1 */
   0x01,      /* bIfaceClass   Interface class 01=AUDIO */
   0x02,      /* bIfaceSubClass   Subclass 02=AUDIO_STREAMING */
   0x00,      /* bIfaceProtocol   protocol */
   05,        /* iInterface   String Index */

   /* USB_AS_IFACE: Audio Class Specific Audio Streaming (AS) Interface 
   ** desc 
   */
   0x07,      /* bLength */
   0x24,      /* Audio Class Specific AS Interface Desc. */
   0x01,      /* AS_GENERAL */
   0x01,      /* TermLink connected to terminal #1 */
   0x00,      /* Delay=0 */
   0x01,0x00, /* FormatTag=PCM */

   0x0b,      /* bLength Format Specification */
   0x24,      /* Audio Class Specific AS Interface Desc. */
   0x02,      /* FORMAT_TYPE */
   0x01,      /* formatType */
   0x02,      /* NrChannels=2 */
   0x02,      /* SubFrameSize=2 byte */
   16,        /* BitResolution=16 bits */
   0x01,      /* SamFreqType=1 type */
   0x11,0x2b, /*  SamFreq=11.025Khz */
   0x00,      /* SamFreq MSB (it's a 24 bit number in HZ) */

   /* USB_EP_DESC1:  table for the USB ENDPOINT Descriptor */
   /* See section 9.6.4 of the Rev 1.0 USB spec (page 187) */
   9,                /* bLength   Length of this descriptor */
   5,                /* bDescType   5=ENDPOINT */
   ENDPOINT_SPEAKER, /* bEndpntAddr   End Point address (EP1=out) */
   0x09,             /* bmAttr   ISO adaptive rate */
   IFC1_ALT1_MAX_LO,IFC1_ALT1_MAX_HI, /* wMaxPktSize   Max Packet Size */
   1,         /* bInterval  */
   0,         /* bRefresh */
   0,         /* SyncAddr   None */

   /* USB_AS_DESC1: Class Specific Audio AS EP descriptor */
   7,         /* bLength   Length of this descriptor */
   0x25,      /* bDescType   Class specific ENDPOINT */
   1,         /* SubType   GENERAL */
   0,         /* bmAttr   none */
   2,         /* bDelayUnits   PCM samples */
   0x01,0x00  /* bLockDelay   1 sample delay */
};

uint_8  other_speed_config[CONFIG_DESC_SIZE] =
{
   9,                         /* bLength Length of this descriptor */
   7,                         /* bDescType This is a Other speed config descr */
   sizeof(other_speed_config) & 0xff, sizeof(other_speed_config) >> 8,
   USB_NUM_IFACES,
   1,
   4,
   0xc0,   /* bmAttributes   attributes - self powered */
   1,      /* MaxPower   self-powered draws 2 mA from the bus. */
   /* AUDIO CONTROL: See section 9.6.3, Rev 1.0 USB spec (page 185) */

   0x09,   /* blength   Length of this desriptor */
   4,      /* bDescriptorType   4=INTERFACE */
   0,      /* bIfaceNum   interface number */
   0,      /* bAltSetting   Alternate setting 0 (no others) */
   0,      /* bNumEndpoints   Number of endpoints= use EP0 only */
   0x01,   /* bIfaceClass   Interface class 01=AUDIO */
   0x01,   /* bIfaceSubClass   Audio COntrol */
   0x00,   /* bIfaceProtocol   none */
   0,      /* iInterface */

   /* USB_AC_IFACE: Audio Class Specific Audio Control (AC) I/F desc */
   0x09,      /* bLength */
   0x24,      /* Audio class specific interface descriptor */
   0x01,      /* HEADER type */
   0x09,0x00, /* spec rev = 0009 */
   0x1e,0x00, /* total length=001e */
   0x01,      /* number of streaming interfaces=1 */
   0x01,      /* Interface number=1 */

   0x0c,      /* bLength */
   0x24,      /* Audio class specific interface desc */
   0x02,      /* Input Terminal */
   0x01,      /* TerminalID */
   0x01,0x01, /* TerminalType=0101=Audio Streaming */
   0x00,      /* output AssocTerminal */
   0x02,      /* Number of Channels=2 */
   0x03,0x00, /* wChannelConfig=L,R */
   0x00,      /* iChannelNames=none */
   0x00,      /* iTerminal */

   0x09,      /* bLength */
   0x24,      /* Type=Audio class specific interface desc */
   0x03,      /* Output Terminal */
   0x02,      /* TerminalID */
   0x01,0x03, /* TerminalType=0301=Generic Speakers */
   0x00,      /* bAssocTerminal=terminalID connect to=0? */
   0x01,      /* bSourceID=TerminalID which is the source for this 
              ** terminal=feature unit 
              */
   0x00,      /* iTerminal=string */

   /*   IIIII  FFFFF   CCCC    1  
   **     I    F      C       11  
   **     I    FFF    C        1  
   **     I    F      C        1  
   **   IIIII  F       CCCC  11111
   */

   /* AUDIO STREAM See section 9.6.3, Rev 1.0 USB spec (page 185) */

   /*       AAA   L      TTTTT   000 
   **      A   A  L        T    0   0
   **      AAAAA  L        T    0   0
   **      A   A  L        T    0   0
   **      A   A  LLLLL    T     000 
   */

   0x09,   /* blength   Length of this desriptor */
   4,      /* bDescriptorType   4=INTERFACE */
   1,      /* bIfaceNum   interface number #1 */
   0,      /* bAltSetting   Alternate setting 0 Zero ISO Bandwidth 
           ** version which is required by Win98 
           */
   1,      /* bNumEndpoints   Number of endpoints */
   0x01,   /* bIfaceClass   Interface class 01=AUDIO */
   0x02,   /* bIfaceSubClass   Audio Streaming */
   0x00,   /* bIfaceProtocol   none */
   4,      /* iInterface   String=#01 */

   0x07,   /* bLength */
   0x24,   /* Audio Class Specific AS Interface Desc. */
   0x01,   /* AS_GENERAL */
   0x01,   /* TermLink connected to terminal #1 */
   0x00,   /* Delay=0 */
   0x00,0x01,   /* FormatTag=PCM */

   0x0b,   /* bLength   Format Specification */
   0x24,   /* Audio Class Specific AS Interface Desc. */
   0x02,   /* FORMAT_TYPE */
   0x01,   /* formatType */
   0x02,   /* NrChannels=2 */
   0x02,   /* SubFrameSize=2 byte */
   16,     /* BitResolution=16 bits */
   0x01,   /* SamFreqType=1 type */
   0x00,0x00, /* ZERO BANDWIDTH */
   0x00,      /* SamFreq MSB (it's a 24 bit number in HZ) */

   9,         /* bLength   Length of this descriptor */
   5,         /* bDescType   5=ENDPOINT */
   ENDPOINT_SPEAKER,   /* bEndpntAddr   End Point address (EP1=out) */
   0x09,      /* bmAttr   ISO adaptive rate */
   IFC1_ALT0_MAX_LO,IFC1_ALT0_MAX_HI, /* wMaxPktSize   Max Packet Size */
   1,         /* bInterval */
   0,         /* bRefresh */
   0,         /* SyncAddr   None */

   /* USB_AS_DESC1: Class Specific Audio AS EP descriptor */
   7,         /* bLength   Length of this descriptor */
   0x25,      /* bDescType   Class specific ENDPOINT */
   1,         /* SubType   GENERAL */
   0,         /* bmAttr   none */
   2,         /* bDelayUnits   PCM samples */
   0x01,0x00, /* bLockDelay   1 sample delay */

   /*       AAA   L      TTTTT    1  
   **      A   A  L        T     11  
   **      AAAAA  L        T      1  
   **      A   A  L        T      1  
   **      A   A  LLLLL    T    11111
   */

   0x09,      /* blength   Length of this desriptor */
   4,         /* bDescriptorType   4=INTERFACE */
   1,         /* bIfaceNum   interface number #1 */
   1,         /* bAltSetting   Alternate setting #1 */
   1,         /* bNumEndpoints   Number of endpoints=1 */
   0x01,      /* bIfaceClass   Interface class 01=AUDIO */
   0x02,      /* bIfaceSubClass   Subclass 02=AUDIO_STREAMING */
   0x00,      /* bIfaceProtocol   protocol */
   05,        /* iInterface   String Index */

   /* USB_AS_IFACE: Audio Class Specific Audio Streaming (AS) Interface 
   ** desc 
   */
   0x07,      /* bLength */
   0x24,      /* Audio Class Specific AS Interface Desc. */
   0x01,      /* AS_GENERAL */
   0x01,      /* TermLink connected to terminal #1 */
   0x00,      /* Delay=0 */
   0x01,0x00, /* FormatTag=PCM */

   0x0b,      /* bLength Format Specification */
   0x24,      /* Audio Class Specific AS Interface Desc. */
   0x02,      /* FORMAT_TYPE */
   0x01,      /* formatType */
   0x02,      /* NrChannels=2 */
   0x02,      /* SubFrameSize=2 byte */
   16,        /* BitResolution=16 bits */
   0x01,      /* SamFreqType=1 type */
   0x11,0x2b, /*  SamFreq=11.025Khz */
   0x00,      /* SamFreq MSB (it's a 24 bit number in HZ) */

   /* USB_EP_DESC1:  table for the USB ENDPOINT Descriptor */
   /* See section 9.6.4 of the Rev 1.0 USB spec (page 187) */
   9,                /* bLength   Length of this descriptor */
   5,                /* bDescType   5=ENDPOINT */
   ENDPOINT_SPEAKER, /* bEndpntAddr   End Point address (EP1=out) */
   0x09,             /* bmAttr   ISO adaptive rate */
   IFC1_ALT1_MAX_LO,IFC1_ALT1_MAX_HI, /* wMaxPktSize   Max Packet Size */
   1,         /* bInterval  */
   0,         /* bRefresh */
   0,         /* SyncAddr   None */

   /* USB_AS_DESC1: Class Specific Audio AS EP descriptor */
   7,         /* bLength   Length of this descriptor */
   0x25,      /* bDescType   Class specific ENDPOINT */
   1,         /* SubType   GENERAL */
   0,         /* bmAttr   none */
   2,         /* bDelayUnits   PCM samples */
   0x01,0x00  /* bLockDelay   1 sample delay */
};


/* number of strings in the table not including 0 or n. */
const uint_8 USB_STR_NUM = 6;

/*
** if the number of strings changes, look for USB_STR_0 everywhere and make 
** the obvious changes.  It should be found in 3 places.
*/

uint_16 USB_STR_0[ 2] = {0x300 + sizeof(USB_STR_0),0x0409};
uint_16 USB_STR_1[16] = {0x300 + sizeof(USB_STR_1),
      'T','D','I',' ','U','S','B',' ','A','U','D','I','O',' ',' '};
uint_16 USB_STR_2[29] = {0x300 + sizeof(USB_STR_2),
      'V','U','S','B',' ','S','y','n','t','h','e','s','i','z','a','b','l','e',' ',\
      'C','o','r','e',' ','D','e','m','o'};
uint_16 USB_STR_3[ 5] = {0x300 + sizeof(USB_STR_3),
      'B','E','T','A'};
uint_16 USB_STR_4[ 4] = {0x300 + sizeof(USB_STR_4),
      '#','0','2'};
uint_16 USB_STR_5[ 4] = {0x300 + sizeof(USB_STR_5),
      '_','A','1'};
uint_16 USB_STR_6[15] = {0x300 + sizeof(USB_STR_6),
      'Y','o','u','r',' ','n','a','m','e',' ','h','e','r','e'};
uint_16 USB_STR_n[17] = {0x300 + sizeof(USB_STR_n),
      'B','A','D',' ','S','T','R','I','N','G',' ','I','n','d','e','x'};

#define USB_STRING_ARRAY_SIZE  8

const uint_8_ptr USB_STRING_DESC[USB_STRING_ARRAY_SIZE] =
{
   (uint_8_ptr)((pointer)USB_STR_0),
   (uint_8_ptr)((pointer)USB_STR_1),
   (uint_8_ptr)((pointer)USB_STR_2),
   (uint_8_ptr)((pointer)USB_STR_3),
   (uint_8_ptr)((pointer)USB_STR_4),
   (uint_8_ptr)((pointer)USB_STR_5),
   (uint_8_ptr)((pointer)USB_STR_6),
   (uint_8_ptr)((pointer)USB_STR_n)
};

uint_16        usb_status;
uint_8         endpoint, if_status;
uint_8         data_to_send;
uint_16        sof_count;
uint_8         setup_packet[sizeof(SETUP_STRUCT)];
SETUP_STRUCT   local_setup_packet;

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9GetStatus
* Returned Value : None
* Comments       :
*     Chapter 9 GetStatus command
*     wValue=Zero
*     wIndex=Zero
*     wLength=1
*     DATA=bmERR_STAT
*     The GET_STATUS command is used to read the bmERR_STAT register.
*     
*     Return the status based on the bRrequestType bits:
*     device (0) = bit 0 = 1 = self powered
*                  bit 1 = 0 = DEVICE_REMOTE_WAKEUP which can be modified
*     with a SET_FEATURE/CLEAR_FEATURE command.
*     interface(1) = 0000.
*     endpoint(2) = bit 0 = stall.
*     static uint_8_ptr pData;
*
* 
*END*--------------------------------------------------------------------*/
void ch9GetStatus
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   if (setup) {
      switch (setup_ptr->REQUESTTYPE) {

         case 0x80:
            /* Device request */
            _usb_device_get_status(handle, USB_STATUS_DEVICE, &usb_status);
            /* Send the requested data */
            _usb_device_send_data(handle, 0, (uchar_ptr)((pointer)&usb_status), 
               sizeof(usb_status));
            break;

         case 0x81:
            /* Interface request */
            if_status = USB_IF_ALT[setup_ptr->INDEX & 0x00FF];
            /* Send the requested data */
            _usb_device_send_data(handle, 0, &if_status, sizeof(if_status));
            break;
      
         case 0x82:
            /* Endpoint request */
            endpoint = setup_ptr->INDEX & USB_STATUS_ENDPOINT_NUMBER_MASK;
            _usb_device_get_status(handle,
               USB_STATUS_ENDPOINT | endpoint, &usb_status);
            /* Send the requested data */
            _usb_device_send_data(handle, 0, (uchar_ptr)((pointer)&usb_status), 
               sizeof(usb_status));      
            break;
         
         default:
            /* Unknown request */
            _usb_device_stall_endpoint(handle, 0, 0);
            return;

      } /* Endswitch */
      
      /* status phase */
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9ClearFeature
* Returned Value : None
* Comments       :
*     Chapter 9 ClearFeature command
* 
*END*--------------------------------------------------------------------*/
void ch9ClearFeature
   (
      /* USB handle */
      _usb_device_handle handle,
            
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   static uint_8           endpoint;
   uint_16                 usb_status;

   _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, &usb_status);

   if ((usb_status != USB_STATE_CONFIG) && (usb_status != USB_STATE_ADDRESS)) {
      _usb_device_stall_endpoint(handle, 0, 0);
      return;
   } /* Endif */

   if (setup) {
      switch (setup_ptr->REQUESTTYPE) {
      
         case 0:
            /* DEVICE */
            if (setup_ptr->VALUE == 1) {
               /* clear remote wakeup */
               _usb_device_get_status(handle, USB_STATUS_DEVICE, &usb_status);
               usb_status &= ~USB_REMOTE_WAKEUP;
               _usb_device_set_status(handle, USB_STATUS_DEVICE, usb_status);
            } else {
               _usb_device_stall_endpoint(handle, 0, 0);
               return;
            } /* Endif */
            break;
         
         case 2:
            /* ENDPOINT */
            if (setup_ptr->VALUE != 0) {
               _usb_device_stall_endpoint(handle, 0, 0);
               return;
            } /* Endif */
            endpoint = setup_ptr->INDEX & USB_STATUS_ENDPOINT_NUMBER_MASK;
            _usb_device_get_status(handle, USB_STATUS_ENDPOINT | endpoint,
               &usb_status);
            /* unstall */
            _usb_device_set_status(handle, USB_STATUS_ENDPOINT | endpoint,
               0);
            break;
         default:
            _usb_device_stall_endpoint(handle, 0, 0);
            return;
      } /* Endswitch */
      
      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SetFeature
* Returned Value : None
* Comments       :
*     Chapter 9 SetFeature command
* 
*END*--------------------------------------------------------------------*/
void ch9SetFeature
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16           usb_status;
   uint_8            endpoint;

   if (setup) {
      switch (setup_ptr->REQUESTTYPE) {

         case 0:
            /* DEVICE */
            switch (setup_ptr->VALUE) {
               case 1:
                  /* set remote wakeup */
                  _usb_device_get_status(handle, USB_STATUS_DEVICE, &usb_status);
                  usb_status |= USB_REMOTE_WAKEUP;
                  _usb_device_set_status(handle, USB_STATUS_DEVICE, usb_status);
                  break;
               case 2:
                  /* Test Mode */
                  if ((setup_ptr->INDEX & 0x00FF) || 
                     (speed != USB_SPEED_HIGH)) 
                  {
                     _usb_device_stall_endpoint(handle, 0, 0);
                     return;
                  } /* Endif */
                  _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, 
                     &usb_status);
                  if ((usb_status == USB_STATE_CONFIG) || 
                     (usb_status == USB_STATE_ADDRESS) || 
                     (usb_status == USB_STATE_DEFAULT)) 
                  {
                     ENTER_TEST_MODE = TRUE;
                     test_mode_index = (setup_ptr->INDEX & 0xFF00);
                  } else {
                     _usb_device_stall_endpoint(handle, 0, 0);
                     return;
                  } /* Endif */
                  break;
               default:
                  _usb_device_stall_endpoint(handle, 0, 0);
                  return;
            } /* Endswitch */
            break;
            
         case 2:
            /* ENDPOINT */
            if (setup_ptr->VALUE != 0) {
               _usb_device_stall_endpoint(handle, 0, 0);
               return;
            } /* Endif */
            endpoint = setup_ptr->INDEX & USB_STATUS_ENDPOINT_NUMBER_MASK;
            _usb_device_get_status(handle, USB_STATUS_ENDPOINT | endpoint,
               &usb_status);
            /* set stall */
            _usb_device_set_status(handle, USB_STATUS_ENDPOINT | endpoint,
               1);
            break;

         default:
            _usb_device_stall_endpoint(handle, 0, 0);
            return;
      } /* Endswitch */
      
      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } else {
      if (ENTER_TEST_MODE) {
         /* Enter Test Mode */
         _usb_device_set_status(handle, USB_STATUS_TEST_MODE, 
            test_mode_index);
      } /* Endif */
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SetAddress
* Returned Value : None
* Comments       :
*     Chapter 9 SetAddress command
*     We setup a TX packet of 0 length ready for the IN token
*     Once we get the TOK_DNE interrupt for the IN token, then
*     we change the ADDR register and go to the ADDRESS state.
* 
*END*--------------------------------------------------------------------*/
void ch9SetAddress
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   static uint_8 new_address;

   if (setup) {
      new_address = setup_ptr->VALUE;
      /*******************************************************
      if hardware assitance is enabled for set_address (see
      hardware rev for details) we need to do the set_address
      before queuing the status phase.
      *******************************************************/
      #ifdef SET_ADDRESS_HARDWARE_ASSISTANCE      
         _usb_device_set_status(handle, USB_STATUS_ADDRESS, new_address);
      #endif
                            
      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } else {
      #ifndef SET_ADDRESS_HARDWARE_ASSISTANCE
         _usb_device_set_status(handle, USB_STATUS_ADDRESS, new_address);
      #endif
      _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
         USB_STATE_ADDRESS);
         
      /*set address is good place to initialize endpoints 
      initialize the endpoint with maximum alternate setting size*/
      _usb_device_init_endpoint(handle
                                ,ENDPOINT_SPEAKER, 
                                 ((IFC1_ALT1_MAX_HI<<16)|IFC1_ALT1_MAX_LO),
                                 USB_RECV,
                                 USB_ISOCHRONOUS_ENDPOINT,
                                 0);
               
     /* queue an advance receive at ISO endpoint */          
      if (_usb_device_get_transfer_status(handle, ENDPOINT_SPEAKER, USB_RECV) == USB_OK) 
      {
      
         _usb_device_recv_data(handle, ENDPOINT_SPEAKER,
                            ISO_BUFFER,ISO_BUFFER_SIZE);               
      }   
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9GetDescription
* Returned Value : None
* Comments       :
*     Chapter 9 GetDescription command
*     The Device Request can ask for Device/Config/string/interface/endpoint
*     descriptors (via wValue). We then post an IN response to return the
*     requested descriptor.
*     And then wait for the OUT which terminates the control transfer.
* 
*END*--------------------------------------------------------------------*/
void ch9GetDescription
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   if (setup) {
      /* Load the appropriate string depending on the descriptor requested.*/
      switch (setup_ptr->VALUE & 0xFF00) {

         case 0x0100:
            _usb_device_send_data(handle, 0, (uchar_ptr)((pointer)&DevDesc),
               MIN(setup_ptr->LENGTH, sizeof(DevDesc)));
            break;

         case 0x0200:
            _usb_device_send_data(handle, 0, (uchar_ptr)((pointer)&ConfigDesc),
               MIN(setup_ptr->LENGTH, sizeof(ConfigDesc)));
            break;

         case 0x0300:
            if ((setup_ptr->VALUE & 0x00FF) > USB_STR_NUM) {
               _usb_device_send_data(handle, 0, USB_STRING_DESC[USB_STR_NUM+1],
                  MIN(setup_ptr->LENGTH, USB_STRING_DESC[USB_STR_NUM+1][0]));
            } else {
               _usb_device_send_data(handle, 0,
                  USB_STRING_DESC[setup_ptr->VALUE & 0x00FF],
                  MIN(setup_ptr->LENGTH,
                     USB_STRING_DESC[setup_ptr->VALUE & 0x00FF][0]));
            } /* Endif */      
            break;
            
         case 0x600:
            _usb_device_send_data(handle, 0, (uchar_ptr)DevQualifierDesc, 
               MIN(setup_ptr->LENGTH, sizeof(DevQualifierDesc)));
            break;
            
         case 0x700:      
            _usb_device_send_data(handle, 0, (uchar_ptr)other_speed_config, 
               MIN(setup_ptr->LENGTH, sizeof(other_speed_config)));
            break;

         default:
            _usb_device_stall_endpoint(handle, 0, 0);
            return;
      } /* Endswitch */
      
      /* status phase */
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SetDescription
* Returned Value : None
* Comments       :
*     Chapter 9 SetDescription command
* 
*END*--------------------------------------------------------------------*/
void ch9SetDescription
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   _usb_device_stall_endpoint(handle, 0, 0);
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9GetConfig
* Returned Value : None
* Comments       :
*     Chapter 9 GetConfig command
* 
*END*--------------------------------------------------------------------*/
void ch9GetConfig
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16 current_config;
   /* Return the currently selected configuration */
   if (setup){ 
      _usb_device_get_status(handle, USB_STATUS_CURRENT_CONFIG,
         &current_config);
      data_to_send = current_config;      
      _usb_device_send_data(handle, 0, &data_to_send, sizeof(data_to_send));
      /* status phase */
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SetConfig
* Returned Value : None
* Comments       :
*     Chapter 9 SetConfig command
* 
*END*--------------------------------------------------------------------*/
void ch9SetConfig
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16 usb_state;
   
   if (setup) {
      if ((setup_ptr->VALUE & 0x00FF) > 1) {
         /* generate stall */
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */
      /* 0 indicates return to unconfigured state */
      if ((setup_ptr->VALUE & 0x00FF) == 0) {
         _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, &usb_state);
         if ((usb_state == USB_STATE_CONFIG) || 
            (usb_state == USB_STATE_ADDRESS)) 
         {
            /* clear the currently selected config value */
            _usb_device_set_status(handle, USB_STATUS_CURRENT_CONFIG, 0);
            _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
               USB_STATE_ADDRESS);
            /* status phase */      
            _usb_device_send_data(handle, 0, 0, 0);
         } else {
            _usb_device_stall_endpoint(handle, 0, 0);
         } /* Endif */
         return;
      } /* Endif */

      /*
      ** If the configuration value (setup_ptr->VALUE & 0x00FF) differs
      ** from the current configuration value, then endpoints must be
      ** reconfigured to match the new device configuration
      */
      _usb_device_get_status(handle, USB_STATUS_CURRENT_CONFIG,
         &usb_state);
      if (usb_state != (setup_ptr->VALUE & 0x00FF)) {
         /* Reconfigure endpoints here */
         switch (setup_ptr->VALUE & 0x00FF) {
      
            default:
               break;
         } /* Endswitch */
         _usb_device_set_status(handle, USB_STATUS_CURRENT_CONFIG,
            setup_ptr->VALUE & 0x00FF);
         _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
            USB_STATE_CONFIG);      
         /* status phase */      
         _usb_device_send_data(handle, 0, 0, 0);
         return;
      } /* Endif */
      _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
         USB_STATE_CONFIG);
      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9GetInterface
* Returned Value : None
* Comments       :
*     Chapter 9 GetInterface command
* 
*END*--------------------------------------------------------------------*/
void ch9GetInterface
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16 usb_state;
   
   _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, &usb_state);
   if (usb_state != USB_STATE_CONFIG) {
      _usb_device_stall_endpoint(handle, 0, 0);
      return;
   } /* Endif */

   if (setup) {
      _usb_device_send_data(handle, 0, &USB_IF_ALT[setup_ptr->INDEX & 0x00FF],
         MIN(setup_ptr->LENGTH, sizeof(uint_8)));
      /* status phase */      
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SetInterface
* Returned Value : None
* Comments       :
*     Chapter 9 SetInterface command
* 
*END*--------------------------------------------------------------------*/
void ch9SetInterface
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   if (setup) {
      if (setup_ptr->REQUESTTYPE != 0x01) {
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */

      /*
      ** If the alternate value (setup_ptr->VALUE & 0x00FF) differs
      ** from the current alternate value for the specified interface,
      ** then endpoints must be reconfigured to match the new alternate
      */
      if (USB_IF_ALT[setup_ptr->INDEX & 0x00FF]
         != (setup_ptr->VALUE & 0x00FF))
      {
         USB_IF_ALT[setup_ptr->INDEX & 0x00FF] = (setup_ptr->VALUE & 0x00FF);
         /* Reconfigure endpoints here. */
         
         /*cancel all pending ISO transfers */
         _usb_device_cancel_transfer(handle,ENDPOINT_SPEAKER,USB_RECV);
         
          /*set address is good place to initialize endpoints 
         initialize the endpoint with new alternate setting size*/
         _usb_device_init_endpoint(handle
                                   ,ENDPOINT_SPEAKER, 
                                    USB_ISO_MAX_PACKET_SIZES[setup_ptr->INDEX & 0x00FF],
                                    USB_RECV,
                                    USB_ISOCHRONOUS_ENDPOINT,
                                    0);
               
        /* queue an advance receive at ISO endpoint */          
         _usb_device_recv_data(handle, ENDPOINT_SPEAKER,
                               ISO_BUFFER,ISO_BUFFER_SIZE);  

      } /* Endif */

      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SynchFrame
* Returned Value : 
* Comments       :
*     Chapter 9 SynchFrame command
* 
*END*--------------------------------------------------------------------*/
void ch9SynchFrame
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   
   if (setup) {
      if (setup_ptr->REQUESTTYPE != 0x02) {
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */

      if ((setup_ptr->INDEX & 0x00FF) >=
         ConfigDesc[CONFIG_DESC_NUM_INTERFACES])
      {
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */

      _usb_device_get_status(handle, USB_STATUS_SOF_COUNT, &sof_count);
      _usb_device_send_data(handle, 0, (uchar_ptr)((pointer)&sof_count),
         MIN(setup_ptr->LENGTH, sizeof(sof_count)));
      /* status phase */      
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9Vendor
* Returned Value : 
* Comments       :
*     Chapter 9 Vendor specific commands must be handled here
* 
*END*--------------------------------------------------------------------*/
void ch9Vendor
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */

   /*place your vendor specific commands here */
   return;

} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : service_ep1
* Returned Value : None
* Comments       :
*     Called upon a completed endpoint 1 ISO transfer
* 
*END*--------------------------------------------------------------------*/
void service_ep1
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
      
      /* [IN] Is it a setup packet? */
      boolean              setup,
      
      /* [IN] Direction of the transfer.  Is it transmit? */
      uint_8               direction,
      
      /* [IN] Pointer to the data buffer */
      uint_8_ptr           buffer,
      
      /* [IN] Length of the transfer */
      uint_32              length,
      
      /* [IN] Error, if any */
      uint_8               error
            
   )
{ /* Body */

   /* queue an advance receive at ISO endpoint */          
   _usb_device_recv_data(handle, ENDPOINT_SPEAKER,
                         ISO_BUFFER,ISO_BUFFER_SIZE);
   return;
} /* Endbody */



/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : service_ep0
* Returned Value : None
* Comments       :
*     Called upon a completed endpoint 0 transfer
* 
*END*--------------------------------------------------------------------*/
void service_ep0
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
      
      /* [IN] Is it a setup packet? */
      boolean              setup,
      
      /* [IN] Direction of the transfer.  Is it transmit? */
      uint_8               direction,
      
      /* [IN] Pointer to the data buffer */
      uint_8_ptr           buffer,
      
      /* [IN] Length of the transfer */
      uint_32              length,
      
      /* [IN] Error, if any */
      uint_8               error
            
   )
{ /* Body */
   boolean       class_request = FALSE;
   
   if (setup) {
      _usb_device_read_setup_data(handle, 0, (uchar_ptr)&local_setup_packet);
   } else if (class_request) {
      class_request = FALSE;
      /* Finish your class or vendor request here */
      
      return;
   } /* Endif */
   
   switch (local_setup_packet.REQUESTTYPE & 0x60) {

      case 0x00:
         switch (local_setup_packet.REQUEST) {

            case 0x0:
               ch9GetStatus(handle, setup, &local_setup_packet);
               break;

            case 0x1:
               ch9ClearFeature(handle, setup, &local_setup_packet);
               break;

            case 0x3:
               ch9SetFeature(handle, setup, &local_setup_packet);
               break;

            case 0x5:
               ch9SetAddress(handle, setup, &local_setup_packet);
               break;

            case 0x6:
               ch9GetDescription(handle, setup, &local_setup_packet);
               break;

            case 0x7:
               ch9SetDescription(handle, setup, &local_setup_packet);
               break;

            case 0x8:
               ch9GetConfig(handle, setup, &local_setup_packet);
               break;

            case 0x9:
               ch9SetConfig(handle, setup, &local_setup_packet);
               break;

            case 0xa:
               ch9GetInterface(handle, setup, &local_setup_packet);
               break;

            case 0xb:
               ch9SetInterface(handle, setup, &local_setup_packet);
               break;

            case 0xc:
               ch9SynchFrame(handle, setup, &local_setup_packet);
               break;

            default:
               _usb_device_stall_endpoint(handle, 0, 0);
               break;

         } /* Endswitch */
         
         break;

      case 0x20:
         /* class specific request */
         class_request = TRUE;
         /* Queue your own packet for class data here */
         return;

      case 0x40:
         /* vendor specific request */
         ch9Vendor(handle, setup, &local_setup_packet);
         break;
      
      default:
         _usb_device_stall_endpoint(handle, 0, 0);
         break;
         
   } /* Endswitch */
   
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : reset_ep0
* Returned Value : None
* Comments       :
*     Called upon a bus reset event.  Initializes the control endpoint.
* 
*END*--------------------------------------------------------------------*/
void reset_ep0
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
   
      /* [IN] Unused */
      boolean              setup,
   
      /* [IN] Unused */
      uint_8               direction,
   
      /* [IN] Unused */
      uint_8_ptr           buffer,
   
      /* [IN] Unused */
      uint_32              length,
      
      /* [IN] Error, if any */
      uint_8               error
            
   )
{ /* Body */

   /* cancel all transfers at control end point */
   _usb_device_cancel_transfer(handle,ENDPOINT_CONTROL,USB_SEND);
   _usb_device_cancel_transfer(handle,ENDPOINT_CONTROL,USB_RECV);
   _usb_device_cancel_transfer(handle,ENDPOINT_SPEAKER,USB_SEND);
   _usb_device_cancel_transfer(handle,ENDPOINT_SPEAKER,USB_RECV);
   
   _usb_device_init_endpoint(handle,
                           ENDPOINT_CONTROL,
                           DevDesc[DEV_DESC_MAX_PACKET_SIZE], 
                           USB_RECV,
                           USB_CONTROL_ENDPOINT,
                           0);
                           
   _usb_device_init_endpoint(handle,
                             ENDPOINT_CONTROL, 
                             DevDesc[DEV_DESC_MAX_PACKET_SIZE], 
                             USB_SEND, 
                             USB_CONTROL_ENDPOINT,
                             0);
   
  return;
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : main
* Returned Value : None
* Comments       :
*     First function called.  Initializes the USB and registers callback 
*  functions and then waits in a infinite loop for Host commands.
* 
*END*--------------------------------------------------------------------*/
#ifdef __USB_OS_MQX__
void Main_Task
   (
      uint_32 param
   )
#else
void main
   (
      void
   )
#endif   
{ /* Body */
   _usb_device_handle   handle;
   uint_8               error;
   

   USB_lock(); /* lock interrupts */
   
#ifdef __USB_OS_MQX__
    _int_install_unexpected_isr(); 
   _usb_driver_install(0, &_bsp_usb_callback_table);
#endif   
   
   /* initialize the USB interface */
   error = _usb_device_init(0, &handle, 4);
   
   if (error != USB_OK) {
      printf("\nUSB Initialization failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */
   
   /* Register callback functions for necessary events */
   error = _usb_device_register_service(handle, USB_SERVICE_EP0, service_ep0);
   
   if (error != USB_OK) {
      printf("\nUSB Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   /* Register callback functions for necessary events */
   error = _usb_device_register_service(handle, USB_SERVICE_EP1, service_ep1);
   
   if (error != USB_OK) {
      printf("\nUSB Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */
   
   
   error = _usb_device_register_service(handle, USB_SERVICE_BUS_RESET, 
      reset_ep0);

   if (error != USB_OK) {
      printf("\nUSB Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   /* This is a Self-Powered Device so set device status to show that. */
   _usb_device_set_status(handle, USB_STATUS_DEVICE, USB_SELF_POWERED);

   USB_unlock();

   /* Run the program forever */
   while (TRUE) 
   {
   } /* Endwhile */
} /* Endbody */

/* EOF */