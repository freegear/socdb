/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***  This file contains the USB Mass storage disk example application.
*** Notice the fact that this example acts like a full speed disk on a
*** ARC full speed core and high-speed disk on a high-speed core. It
*** actually detects the speed by registering the speed detection with
**** the stack and changes descriptors for each speed.***                                                               
**************************************************************************
**END*********************************************************/

/**************************************************************************
Include the USB stack and local header files.
**************************************************************************/

#include "usb.h"
#include "devapi.h"
#include "usbprv_dev.h"

/**************************************************************************
Include the OS and BSP dependent files that define IO functions and
basic types. You may like to change these files for your board and RTOS 
**************************************************************************/

#ifdef __USB_OS_MQX__   
   #include "bsp.h"
   #include "fio.h"
   #include "mqx_arc.h"
   
   /***************************************************
   When this example was prepared, MQX did not have support
   for data cache. But To avoid the compilation problem,
   we just define the necessary macro here which should
   have been defined by MQX header files above.Remove
   the following line if MQX defines this macro already
   ***************************************************/
   #define PSP_CACHE_LINE_SIZE 32
   
#else


/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif   
   #include "stdlib.h"
#endif
#include "string.h"

#include "disk.h"


/**************************************************************************
Global variables and some defines for device.
**************************************************************************/

#define  APP_CONTROL_MAX_PKT_SIZE         (64)
#define  DEV_DESC_MAX_PACKET_SIZE         (7)
#define  EP1_FS_MAX_PACKET_SIZE           (64)
#define  EP1_HS_MAX_PACKET_SIZE           (512)
#define  CFG_DESC_EP1TX_MAX_PACKET_SIZE   (22)
#define  CFG_DESC_EP1RX_MAX_PACKET_SIZE   (29)

/*#define  TOTAL_LOGICAL_ADDRESS_BLOCKS     (720)*/
#define  TOTAL_LOGICAL_ADDRESS_BLOCKS     (400)
#define  LENGTH_OF_EACH_LAB               (512)

uchar_ptr ep1_buf;

/* A temproray buffer for control enpoint to send data */
uchar_ptr epTemp_buf;

/**************************************************
The following switch can be enabled to demonstrate
the capability of real time monitoring of USB
transfers.
***************************************************/
/*This switches enables the code which monitors the progress
of IN transfer on endpoint 1 */
/*#define DEMO_TRANSFER_PROGRESS*/
#ifdef DEMO_TRANSFER_PROGRESS
   XD_STRUCT_PTR        info;
#endif
/**************************************************
The following switch can be enabled to force
the device controlle in full speed mode. By
default it is disabled because this example
runs on cores that are full speed only but
if you are using VUSBHS core, you can enable this
define switch.
***************************************************/
/*#define DEMO_FULL_SPEED_MODE*/

/**********************************
Buffers for use by this application
***********************************/
uchar_ptr Send_Buffer_Unaligned;
uchar_ptr Send_Buffer_aligned;

volatile boolean TEST_ENABLED = FALSE;

/*All high-speed device are supposed to support test mode
see USB specification*/

volatile boolean  ENTER_TEST_MODE = FALSE; 
volatile uint_16  test_mode_index = 0;
volatile uchar    speed = 0;

/**************************************************************************
The following is the way to define a multi tasking system in MQX. As seen
here,two tasks have been defined. They are called as MAIN_TASK and FILE_TASK.
MAIN TASK has been slightly higher priority (6L) that file system (7L),just
to ensure that OTG events are handled first then file system. Remove this
code and use your own RTOS way of defining tasks (or threads).
**************************************************************************/

#ifdef __USB_OS_MQX__
extern void Main_Task(uint_32 param);
#define MAIN_TASK       10

TASK_TEMPLATE_STRUCT  MQX_template_list[] =
{
   { MAIN_TASK,      Main_Task,      3000L,  7L, "Main",      MQX_AUTO_START_TASK},
   { 0L,             0L,             0L,   0L, 0L,          0L }
};
#endif

/**************************************************************************
DESCRIPTORS DESCRIPTORS DESCRIPTORS DESCRIPTORS DESCRIPTORS DESCRIPTORS
**************************************************************************/

#define DEVICE_DESCRIPTOR_SIZE 18
uchar_ptr DevDesc;
uint_8  DevDescData[DEVICE_DESCRIPTOR_SIZE] =
{
   /* Length of DevDesc */
   DEVICE_DESCRIPTOR_SIZE,
   /* "Device" Type of descriptor */
   1,
   /* BCD USB version */
   0, 2,
   /* Device Class is indicated in the interface descriptors */
   0x00,
   /* Device Subclass is indicated in the interface descriptors */
   0x00,
   /* Mass storage devices do not use class-specific protocols */
   0x00,
   /* Max packet size */
   APP_CONTROL_MAX_PKT_SIZE,
   /* Vendor ID */
   USB_uint_16_low(0x0B20), USB_uint_16_high(0x0B20),
   /* Product ID */
   USB_uint_16_low(0x1), USB_uint_16_high(0x1),
   /* BCD Device version */
   USB_uint_16_low(0x0002), USB_uint_16_high(0x0002),
   /* Manufacturer string index */
   0x1,
   /* Product string index */
   0x2,
   /* Serial number string index */
   0x6,
   /* Number of configurations available */
   0x1
};

/* USB 2.0 specific descriptor */
#define DEVICE_QUALIFIER_DESCRIPTOR_SIZE 10
uchar_ptr DevQualifierDesc;
uint_8  DevQualifierDescData[DEVICE_QUALIFIER_DESCRIPTOR_SIZE] =
{
   DEVICE_QUALIFIER_DESCRIPTOR_SIZE,  /* bLength Length of this descriptor */
   6,                         /* bDescType This is a DEVICE Qualifier descr */
   0,2,                       /* bcdUSB USB revision 2.0 */
   0,                         /* bDeviceClass */
   0,                         /* bDeviceSubClass */
   0,                         /* bDeviceProtocol */
   APP_CONTROL_MAX_PKT_SIZE,  /* bMaxPacketSize0 */
   0x01,                      /* bNumConfigurations */
   0
};

#define CONFIG_DESC_NUM_INTERFACES  (4)
/* This must be counted manually and updated with the descriptor */
/* 1*Config(9) + 1*Interface(9) + 2*Endpoint(7) = 32 bytes */
#define CONFIG_DESC_SIZE            (32)

uchar_ptr ConfigDesc_Unaligned;

/**************************************************************
we declare the config desc as USB_Uncached because this descriptor
is updated on the fly for max packet size during enumeration. Making
it uncached ensures that main memory is updated whenever this
descriptor pointer is used.
**************************************************************/
USB_Uncached uchar_ptr ConfigDesc;

uint_8 ConfigDescData[CONFIG_DESC_SIZE] =
{
   /* Configuration Descriptor - always 9 bytes */
   9,
   /* "Configuration" type of descriptor */
   2,
   /* Total length of the Configuration descriptor */
   USB_uint_16_low(CONFIG_DESC_SIZE), USB_uint_16_high(CONFIG_DESC_SIZE),
   /* NumInterfaces */
   1,
   /* Configuration Value */
   1,
   /* Configuration Description String Index*/
   4,
   /* Attributes.  Self-powered */
   0xc0,
   /* Current draw from bus */
   1,
   /* Interface 0 Descriptor - always 9 bytes */
   9,
   /* "Interface" type of descriptor */
   4,
   /* Number of this interface */
   MASS_STORAGE_INTERFACE,
   /* Alternate Setting */
   0,
   /* Number of endpoints on this interface */
   2,
   /* Interface Class */
   0x08,
   /* Interface Subclass: SCSI transparent command set */
   0x06,
   /* Interface Protocol: Bulk only protocol */
   0x50,
   /* Interface Description String Index */
   0,
   /* Endpoint 1 (Bulk In Endpoint), Interface 0 Descriptor - always 7 bytes*/
   7,
   /* "Endpoint" type of descriptor */
   5,
   /*
   ** Endpoint address.  The low nibble contains the endpoint number and the
   ** high bit indicates TX(1) or RX(0).
   */
   0x81,
   /* Attributes.  0=Control 1=Isochronous 2=Bulk 3=Interrupt */
   0x02,
   /* Max Packet Size for this endpoint */
   USB_uint_16_low(EP1_FS_MAX_PACKET_SIZE), 
   USB_uint_16_high(EP1_FS_MAX_PACKET_SIZE),
   /* Polling Interval (ms) */
   0,
   /* Endpoint 2 (Bulk Out Endpoint), Interface 0 Descriptor - always 7 bytes*/
   7,
   /* "Endpoint" type of descriptor */
   5,
   /*
   ** Endpoint address.  The low nibble contains the endpoint number and the
   ** high bit indicates TX(1) or RX(0).
   */
   0x01,
   /* Attributes.  0=Control 1=Isochronous 2=Bulk 3=Interrupt */
   0x02,
   /* Max Packet Size for this endpoint */
   USB_uint_16_low(EP1_FS_MAX_PACKET_SIZE), 
   USB_uint_16_high(EP1_FS_MAX_PACKET_SIZE),
   /* Polling Interval (ms) */
   0
};

#define OTHER_SPEED_CONFIG_DESC_SIZE  CONFIG_DESC_SIZE
USB_Uncached uchar_ptr  other_speed_config;
uint_8  other_speed_config_data[CONFIG_DESC_SIZE] =
{
   9,                         /* bLength Length of this descriptor */
   7,                         /* bDescType This is a Other speed config descr */
   OTHER_SPEED_CONFIG_DESC_SIZE & 0xff, 
   OTHER_SPEED_CONFIG_DESC_SIZE >> 8,
   1,
   1,
   4,
   /* Attributes.  Self-powered */
   0xc0,
   /* Current draw from bus */
   1,
   /* Interface 0 Descriptor - always 9 bytes */
   9,
   /* "Interface" type of descriptor */
   4,
   /* Number of this interface */
   MASS_STORAGE_INTERFACE,
   /* Alternate Setting */
   0,
   /* Number of endpoints on this interface */
   2,
   /* Interface Class */
   0x08,
   /* Interface Subclass: SCSI transparent command set */
   0x06,
   /* Interface Protocol: Bulk only protocol */
   0x50,
   /* Interface Description String Index */
   0,
   /* Endpoint 1 (Bulk In Endpoint), Interface 0 Descriptor - always 7 bytes*/
   7,
   /* "Endpoint" type of descriptor */
   5,
   /*
   ** Endpoint address.  The low nibble contains the endpoint number and the
   ** high bit indicates TX(1) or RX(0).
   */
   0x81,
   /* Attributes.  0=Control 1=Isochronous 2=Bulk 3=Interrupt */
   0x02,
   /* Max Packet Size for this endpoint */
   USB_uint_16_low(EP1_HS_MAX_PACKET_SIZE), 
   USB_uint_16_high(EP1_HS_MAX_PACKET_SIZE),
   /* Polling Interval (ms) */
   0,
   /* Endpoint 2 (Bulk Out Endpoint), Interface 0 Descriptor - always 7 bytes*/
   7,
   /* "Endpoint" type of descriptor */
   5,
   /*
   ** Endpoint address.  The low nibble contains the endpoint number and the
   ** high bit indicates TX(1) or RX(0).
   */
   0x01,
   /* Attributes.  0=Control 1=Isochronous 2=Bulk 3=Interrupt */
   0x02,
   /* Max Packet Size for this endpoint */
   USB_uint_16_low(EP1_HS_MAX_PACKET_SIZE), 
   USB_uint_16_high(EP1_HS_MAX_PACKET_SIZE),
   /* Polling Interval (ms) */
   0
};

uchar USB_IF_ALT[4] = { 0, 0, 0, 0};

/* number of strings in the table not including 0 or n. */
uint_8 USB_STR_NUM = 7;

/*
** if the number of strings changes, look for USB_STR_0 everywhere and make 
** the obvious changes.  It should be found in 3 places.
*/

const uint_16 USB_STR_0[ 2] = {0x300 + sizeof(USB_STR_0),0x0409};
const uint_16 USB_STR_1[16] = {0x300 + sizeof(USB_STR_1),
      'V','A','u','t','o','m','a','t','i','o','n',' ','I','n','c'};
const uint_16 USB_STR_2[24] = {0x300 + sizeof(USB_STR_2),
      'T','D','I',' ','M','a','s','s',' ','S','t','o','r','a','g','e',' ',\
      'D','e','v','i','c','e'};
const uint_16 USB_STR_3[ 5] = {0x300 + sizeof(USB_STR_3),
      'B','E','T','A'};
const uint_16 USB_STR_4[ 4] = {0x300 + sizeof(USB_STR_4),
      '#','0','2'};
const uint_16 USB_STR_5[ 4] = {0x300 + sizeof(USB_STR_5),
      '_','A','1'};
      /* Serial number has to be at least 12 bytes */
const uint_16 USB_STR_6[ 13] = {0x300 + sizeof(USB_STR_6),
      '0','0','0','0','0','0','0','0','0','0','0','1'};     
const uint_16 USB_STR_7[15] = {0x300 + sizeof(USB_STR_7),
      'Y','o','u','r',' ','n','a','m','e',' ','h','e','r','e'};
const uint_16 USB_STR_n[17] = {0x300 + sizeof(USB_STR_n),
      'B','A','D',' ','S','T','R','I','N','G',' ','I','n','d','e','x'};

#define USB_STRING_ARRAY_SIZE  9
const uint_8_ptr USB_STRING_DESC[USB_STRING_ARRAY_SIZE] =
{
   (uint_8_ptr)((pointer)USB_STR_0),
   (uint_8_ptr)((pointer)USB_STR_1),
   (uint_8_ptr)((pointer)USB_STR_2),
   (uint_8_ptr)((pointer)USB_STR_3),
   (uint_8_ptr)((pointer)USB_STR_4),
   (uint_8_ptr)((pointer)USB_STR_5),
   (uint_8_ptr)((pointer)USB_STR_6),
   (uint_8_ptr)((pointer)USB_STR_7),
   (uint_8_ptr)((pointer)USB_STR_n)
};

/*****************************************************************
MASS STORAGE SPECIFIC GLOBALS
*****************************************************************/

USB_Uncached boolean        CBW_PROCESSED = FALSE;
USB_Uncached boolean        ZERO_TERMINATE = FALSE;
CSW_STRUCT     csw;

const MASS_STORAGE_DEVICE_INFO_STRUCT device_information_data = {
   0, 0x80, 0, 0x01, 0x1F, 0, 0, 0, 
   /* Vendor information: "TDI     " */
   {0x54, 0x44, 0x49, 0x20, 0x20, 0x20, 0x20, 0x20,}, 
   /* Product information: "Disk            " */
   {0x44, 0x69, 0x73, 0x6B, 0x20, 0x20, 0x20, 0x20,
   0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20}, 
   /* Product Revision level: "Demo" */
   {0x44, 0x65, 0x6D, 0x6F}
}; 

const MASS_STORAGE_READ_CAPACITY_STRUCT read_capacity = {
   /* Data for the capacity */
   {
      0x00, 0x00, USB_uint_16_high(TOTAL_LOGICAL_ADDRESS_BLOCKS-14), 
      USB_uint_16_low(TOTAL_LOGICAL_ADDRESS_BLOCKS-14)
   }, 
   {
      0x00, 0x00, USB_uint_16_high(LENGTH_OF_EACH_LAB), 
      USB_uint_16_low(LENGTH_OF_EACH_LAB)
   }
};

uchar_ptr MASS_STORAGE_DISK_UNALIGNED;
uchar_ptr MASS_STORAGE_DISK;

uchar BOOT_SECTOR_AREA[512] = {
   /* Block 0 is the boot sector. Following is the data in the boot sector */
   /* 80x86 "short: jump instruction, indicating that the disk is formatted */
    0xEB, 
    /* 8-bit displacement */
    0x3C, 
    /* NOP OPCode */
    0x90, 
    /* 8-bytes for OEM identification: "ARC 4.3 " */
    0x41, 0x52, 0x43, 0x20, 0x34, 0x2E, 0x33, 0x20, 
    /* bytes/sector: 512 bytes (0x0200) */
    0x00, 0x02, 
    /* Sectors/allocation unit */
    0x01,
    /* Reserved sectors: 0x0001 */
    0x01, 0x00, 
    /* Number of File Allocation Tables (FATs): 2 */
    0x02,
    /* Number of root directory entries */
    0x70, 0x00, 
    /* Total sectors in logical volume */
    USB_uint_16_low(TOTAL_LOGICAL_ADDRESS_BLOCKS), 
    USB_uint_16_high(TOTAL_LOGICAL_ADDRESS_BLOCKS),
    /* Media descriptor byte: 0xF8: Fixed disk */
    0xFD,
    /* Sectors/FAT: 3 (Each FAT starts at a new sector) */
    0x03, 0x00, 
    /* Sectors/track: 9 */
    0x09, 0x00, 
    /* Number of heads */
    0x02, 0x00, 
    /* Number of hidden sectors: 0 */
    0x00, 0x00, 0x00, 0x00, 
    /* Total sectors in logical volume */
    0x00, 0x00, 0x00, 0x00, 
    /* Physical drive number */
    0x00, 
    /* Reserved */
    0x00, 
    /* Extended boot signature record: 0x29 */
    0x29,
    /* 32-bit binary volume ID */
    0x01, 0x02, 0x03, 0x04, 
    /* Volume label */
    0x56, 0x41, 0x75, 0x74, 0x6F, 0x6D, 0x61, 0x74, 0x69, 0x6F, 0x6E, 
    /* Reserved */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    /* Bootstrap */
    0x33, 0xC0, 0x8E, 0xD0, 0xBC, 0x00, 0x7C, 0xFC, 0xE8, 0x45, 0x00, 
    /* String: \r\nNon-System disk\r\nPress any key to reboot\r\n" */
    0x0D, 0x0A, 0x4E, 0x6F, 0x6E, 0x2D, 0x53, 0x79, 0x73, 0x74, 0x65,
    0x6D, 0x20, 0x64, 0x69, 0x73, 0x6B, 0x0D, 0x0A, 0x50, 0x72, 0x65, 
    0x73, 0x73, 0x20, 0x61, 0x6E, 0x79, 0x20, 0x6B, 0x65, 0x79, 0x20, 
    0x74, 0x6F, 0x20, 0x72, 0x65, 0x62, 0x6F, 0x6F, 0x74, 0x0D, 0x0A, 
    0x5E, 0xEB, 0x02, 0xCD, 0x10, 0xB4, 0x0E, 0xBB, 0x07, 0x00, 0x2E, 
    0xAC, 0x84, 0xC0, 0x75, 0xF3, 0x98, 0xCD, 0x16, 0xCD, 0x19, 0xEB, 
    0xB1, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    /* Partition descriptors */
    0x00, 0x01, 0x01, 0x00, 0x01, 0x04, 0x02, 0xC8, 0x11, 0x00, 0x00, 
    0x00, 0x02, 0xD0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA
};

const uchar FAT16_SPECIAL_BYTES[3] = {
   /* FAT ID: Same as Media descriptor */
   0xFD, 0xFF, 0xFF
};

USB_Uncached uchar          usb_status[2];
USB_Uncached uint_8         endpoint, if_status;
USB_Uncached uchar         data_to_send;
uint_16        sof_count;
uint_8         setup_packet[sizeof(SETUP_STRUCT)];
SETUP_STRUCT   local_setup_packet;

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9GetStatus
* Returned Value : None
* Comments       :
*     Chapter 9 GetStatus command
*     wValue=Zero
*     wIndex=Zero
*     wLength=1
*     DATA=bmERR_STAT
*     The GET_STATUS command is used to read the bmERR_STAT register.
*     
*     Return the status based on the bRrequestType bits:
*     device (0) = bit 0 = 1 = self powered
*                  bit 1 = 0 = DEVICE_REMOTE_WAKEUP which can be modified
*     with a SET_FEATURE/CLEAR_FEATURE command.
*     interface(1) = 0000.
*     endpoint(2) = bit 0 = stall.
*     static uint_8_ptr pData;
*
*     See section 9.4.5 (page 190) of the USB 1.1 Specification.
* 
*END*--------------------------------------------------------------------*/
void ch9GetStatus
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16 temp_status;
   
   if (setup) {
      switch (setup_ptr->REQUESTTYPE) {

         case 0x80:
            /* Device request */
            _usb_device_get_status(handle, 
                                    USB_STATUS_DEVICE, 
                                    (uint_16_ptr)&usb_status);
            /* Send the requested data */
            _usb_device_send_data(
                  handle, 
                  0, 
                  (uchar_ptr)&usb_status, 
                  2 /*two bytes */
                  );
            break;

         case 0x81:
            /* Interface request */
            if_status = USB_IF_ALT[setup_ptr->INDEX & 0x00FF];
            /* Send the requested data */
            _usb_device_send_data(handle, 0, (pointer) &if_status, sizeof(if_status));
            break;
      
         case 0x82:
            /* Endpoint request */
            endpoint = setup_ptr->INDEX & USB_STATUS_ENDPOINT_NUMBER_MASK;

            _usb_device_get_status(handle,
               USB_STATUS_ENDPOINT | endpoint,&temp_status);
            
            /*copy status to usb_status global buffer for uncached access */
            usb_status[0] = temp_status & 0xFF;
            usb_status[1] = (temp_status >> 8)& 0xFF;
            
            /* Send the requested data */
            _usb_device_send_data(handle,
                                 0,
                                 (uchar_ptr) &usb_status, 
                                 2 //sizeof(usb_status)
                                 );      
            break;
         
         default:
            /* Unknown request */
            _usb_device_stall_endpoint(handle, 0, 0);
            return;

      } /* Endswitch */
      
      /* status phase */
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9ClearFeature
* Returned Value : None
* Comments       :
*     Chapter 9 ClearFeature command
* 
*END*--------------------------------------------------------------------*/
void ch9ClearFeature
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   static uint_8           endpoint;
   uint_16                 usb_status;

   _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, &usb_status);

   if ((usb_status != USB_STATE_CONFIG) && (usb_status != USB_STATE_ADDRESS)) {
      _usb_device_stall_endpoint(handle, 0, 0);
      return;
   } /* Endif */

   if (setup) {
      switch (setup_ptr->REQUESTTYPE) {
      
         case 0:
            /* DEVICE */
            if (setup_ptr->VALUE == 1) {
               /* clear remote wakeup */
               _usb_device_get_status(handle, USB_STATUS_DEVICE, &usb_status);
               usb_status &= ~USB_REMOTE_WAKEUP;
               _usb_device_set_status(handle, USB_STATUS_DEVICE, usb_status);
            } else {
               _usb_device_stall_endpoint(handle, 0, 0);
               return;
            } /* Endif */
            break;
         
         case 2:
            /* ENDPOINT */
            if (setup_ptr->VALUE != 0) {
               _usb_device_stall_endpoint(handle, 0, 0);
               return;
            } /* Endif */
            endpoint = setup_ptr->INDEX & USB_STATUS_ENDPOINT_NUMBER_MASK;
            _usb_device_get_status(handle, USB_STATUS_ENDPOINT | endpoint,
               &usb_status);
            /* unstall */
            _usb_device_set_status(handle, USB_STATUS_ENDPOINT | endpoint,
               0);
            break;
         default:
            _usb_device_stall_endpoint(handle, 0, 0);
            return;
      } /* Endswitch */
      
      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SetFeature
* Returned Value : None
* Comments       :
*     Chapter 9 SetFeature command
* 
*END*--------------------------------------------------------------------*/
void ch9SetFeature
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16           usb_status;
   uint_8            endpoint;

   if (setup) {
      switch (setup_ptr->REQUESTTYPE) {

         case 0:
            /* DEVICE */
            switch (setup_ptr->VALUE) {
               case 1:
                  /* set remote wakeup */
                  _usb_device_get_status(handle, USB_STATUS_DEVICE, &usb_status);
                  usb_status |= USB_REMOTE_WAKEUP;
                  _usb_device_set_status(handle, USB_STATUS_DEVICE, usb_status);
                  break;
               case 2:
                  /* Test Mode */
                  if ((setup_ptr->INDEX & 0x00FF) || 
                     (speed != USB_SPEED_HIGH)) 
                  {
                     _usb_device_stall_endpoint(handle, 0, 0);
                     return;
                  } /* Endif */
                  _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, 
                     &usb_status);
                  if ((usb_status == USB_STATE_CONFIG) || 
                     (usb_status == USB_STATE_ADDRESS) || 
                     (usb_status == USB_STATE_DEFAULT)) 
                  {
                     ENTER_TEST_MODE = TRUE;
                     test_mode_index = (setup_ptr->INDEX & 0xFF00);
                  } else {
                     _usb_device_stall_endpoint(handle, 0, 0);
                     return;
                  } /* Endif */
                  break;
               default:
                  _usb_device_stall_endpoint(handle, 0, 0);
                  return;
            } /* Endswitch */
            break;
            
         case 2:
            /* ENDPOINT */
            if (setup_ptr->VALUE != 0) {
               _usb_device_stall_endpoint(handle, 0, 0);
               return;
            } /* Endif */
            endpoint = setup_ptr->INDEX & USB_STATUS_ENDPOINT_NUMBER_MASK;
            _usb_device_get_status(handle, USB_STATUS_ENDPOINT | endpoint,
               &usb_status);
            /* set stall */
            _usb_device_set_status(handle, USB_STATUS_ENDPOINT | endpoint,
               1);
            break;

         default:
            _usb_device_stall_endpoint(handle, 0, 0);
            return;
      } /* Endswitch */
      
      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } else {
      if (ENTER_TEST_MODE) {
         /* Enter Test Mode */
         _usb_device_set_status(handle, USB_STATUS_TEST_MODE, 
            test_mode_index);
      } /* Endif */
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SetAddress
* Returned Value : None
* Comments       :
*     Chapter 9 SetAddress command
*     We setup a TX packet of 0 length ready for the IN token
*     Once we get the TOK_DNE interrupt for the IN token, then
*     we change the ADDR register and go to the ADDRESS state.
* 
*END*--------------------------------------------------------------------*/
void ch9SetAddress
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   static uint_8  new_address;
   uint_32        max_pkt_size;

   if (setup) {
      new_address = setup_ptr->VALUE;
      /*******************************************************
      if hardware assitance is enabled for set_address (see
      hardware rev for details) we need to do the set_address
      before queuing the status phase.
      *******************************************************/
      #ifdef SET_ADDRESS_HARDWARE_ASSISTANCE      
         _usb_device_set_status(handle, USB_STATUS_ADDRESS, new_address);
      #endif
      /* ack */
      _usb_device_send_data(handle, 0, 0, 0);
      
   } else {
      #ifndef SET_ADDRESS_HARDWARE_ASSISTANCE
         _usb_device_set_status(handle, USB_STATUS_ADDRESS, new_address);
      #endif
      
      _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
         USB_STATE_ADDRESS);
         
      if (speed == USB_SPEED_HIGH) {
         max_pkt_size = EP1_HS_MAX_PACKET_SIZE;
	   } else {
         max_pkt_size = EP1_FS_MAX_PACKET_SIZE;
	   } /* Endif */
      
      _usb_device_init_endpoint(handle, 1, max_pkt_size,
			USB_RECV, USB_BULK_ENDPOINT, USB_DEVICE_DONT_ZERO_TERMINATE);
	   _usb_device_init_endpoint(handle, 1, max_pkt_size,
		   USB_SEND, USB_BULK_ENDPOINT, USB_DEVICE_DONT_ZERO_TERMINATE);
	
      if (_usb_device_get_transfer_status(handle, 1, USB_RECV) == USB_OK) {
         _usb_device_recv_data(handle, 1, ep1_buf, 31);
      } /* Endif */      
      
      TEST_ENABLED = TRUE;
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9GetDescription
* Returned Value : None
* Comments       :
*     Chapter 9 GetDescription command
*     The Device Request can ask for Device/Config/string/interface/endpoint
*     descriptors (via wValue). We then post an IN response to return the
*     requested descriptor.
*     And then wait for the OUT which terminates the control transfer.
* 
*END*--------------------------------------------------------------------*/
void ch9GetDescription
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_32  max_pkt_size;
   
   if (setup) {
      /* Load the appropriate string depending on the descriptor requested.*/
      switch (setup_ptr->VALUE & 0xFF00) {

         case 0x0100:
            _usb_device_send_data(handle, 0, DevDesc,
               MIN(setup_ptr->LENGTH, DEVICE_DESCRIPTOR_SIZE));
            break;

         case 0x0200:
	         /* Set the Max Packet Size in the config and other speed config */
            if(speed == USB_SPEED_HIGH) {
               max_pkt_size = EP1_HS_MAX_PACKET_SIZE;
            } else {
               max_pkt_size = EP1_FS_MAX_PACKET_SIZE;
            } /* Endif */

            *(ConfigDesc + CFG_DESC_EP1TX_MAX_PACKET_SIZE) = 
               USB_uint_16_low(max_pkt_size);
            *(ConfigDesc +CFG_DESC_EP1TX_MAX_PACKET_SIZE+1) = 
               USB_uint_16_high(max_pkt_size);
            *(ConfigDesc +CFG_DESC_EP1RX_MAX_PACKET_SIZE) = 
               USB_uint_16_low(max_pkt_size);
            *(ConfigDesc +CFG_DESC_EP1RX_MAX_PACKET_SIZE+1) = 
               USB_uint_16_high(max_pkt_size);


            _usb_device_send_data(handle, 0, ConfigDesc,
               MIN(setup_ptr->LENGTH, CONFIG_DESC_SIZE));
            break;

         case 0x0300:
            if ((setup_ptr->VALUE & 0x00FF) > USB_STR_NUM) {
               _usb_device_send_data(handle, 0, USB_STRING_DESC[USB_STR_NUM+1],
                  MIN(setup_ptr->LENGTH, USB_STRING_DESC[USB_STR_NUM+1][0]));
            } else {
               _usb_device_send_data(handle, 0,
                  USB_STRING_DESC[setup_ptr->VALUE & 0x00FF],
                  MIN(setup_ptr->LENGTH,
                     USB_STRING_DESC[setup_ptr->VALUE & 0x00FF][0]));
            } /* Endif */      
            break;
            
         case 0x600:
            _usb_device_send_data(handle, 0, (uchar_ptr)DevQualifierDesc, 
               MIN(setup_ptr->LENGTH, DEVICE_QUALIFIER_DESCRIPTOR_SIZE));
            break;
            
         case 0x700:
            if(speed == USB_SPEED_HIGH) {
               max_pkt_size = EP1_FS_MAX_PACKET_SIZE;
            } else {
               max_pkt_size = EP1_HS_MAX_PACKET_SIZE;
            } /* Endif */
            
            *(other_speed_config + CFG_DESC_EP1TX_MAX_PACKET_SIZE) = 
               USB_uint_16_low(max_pkt_size);
            *(other_speed_config +CFG_DESC_EP1TX_MAX_PACKET_SIZE+1) = 
               USB_uint_16_high(max_pkt_size);
            *(other_speed_config +CFG_DESC_EP1RX_MAX_PACKET_SIZE) = 
               USB_uint_16_low(max_pkt_size);
            *(other_speed_config +CFG_DESC_EP1RX_MAX_PACKET_SIZE+1) = 
               USB_uint_16_high(max_pkt_size);
            
            _usb_device_send_data(handle, 0, (uchar_ptr)other_speed_config, 
               MIN(setup_ptr->LENGTH, OTHER_SPEED_CONFIG_DESC_SIZE));
               
            break;

         default:
            _usb_device_stall_endpoint(handle, 0, 0);
            return;
      } /* Endswitch */
      /* status phase */
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SetDescription
* Returned Value : None
* Comments       :
*     Chapter 9 SetDescription command
* 
*END*--------------------------------------------------------------------*/
void ch9SetDescription
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   _usb_device_stall_endpoint(handle, 0, 0);
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9GetConfig
* Returned Value : None
* Comments       :
*     Chapter 9 GetConfig command
* 
*END*--------------------------------------------------------------------*/
void ch9GetConfig
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16 current_config;
   /* Return the currently selected configuration */
   if (setup){ 
      _usb_device_get_status(handle, USB_STATUS_CURRENT_CONFIG,
         &current_config);
      *epTemp_buf = current_config;      
      _usb_device_send_data(handle, 0, epTemp_buf, sizeof(uchar));
      /* status phase */
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SetConfig
* Returned Value : None
* Comments       :
*     Chapter 9 SetConfig command
* 
*END*--------------------------------------------------------------------*/
void ch9SetConfig
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16 usb_state;
   
   if (setup) {
      if ((setup_ptr->VALUE & 0x00FF) > 1) {
         /* generate stall */
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */
      /* 0 indicates return to unconfigured state */
      if ((setup_ptr->VALUE & 0x00FF) == 0) {
         _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, &usb_state);
         if ((usb_state == USB_STATE_CONFIG) || 
            (usb_state == USB_STATE_ADDRESS)) 
         {
            /* clear the currently selected config value */
            _usb_device_set_status(handle, USB_STATUS_CURRENT_CONFIG, 0);
            _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
               USB_STATE_ADDRESS);
            /* status phase */      
            _usb_device_send_data(handle, 0, 0, 0);
         } else {
            _usb_device_stall_endpoint(handle, 0, 0);
         } /* Endif */
         return;
      } /* Endif */

      /*
      ** If the configuration value (setup_ptr->VALUE & 0x00FF) differs
      ** from the current configuration value, then endpoints must be
      ** reconfigured to match the new device configuration
      */
      _usb_device_get_status(handle, USB_STATUS_CURRENT_CONFIG,
         &usb_state);
      if (usb_state != (setup_ptr->VALUE & 0x00FF)) {
         /* Reconfigure endpoints here */
         switch (setup_ptr->VALUE & 0x00FF) {
      
            default:
               break;
         } /* Endswitch */
         _usb_device_set_status(handle, USB_STATUS_CURRENT_CONFIG,
            setup_ptr->VALUE & 0x00FF);
         _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
            USB_STATE_CONFIG);      
         /* status phase */      
         _usb_device_send_data(handle, 0, 0, 0);
         return;
      } /* Endif */
      _usb_device_set_status(handle, USB_STATUS_DEVICE_STATE,
         USB_STATE_CONFIG);
      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9GetInterface
* Returned Value : None
* Comments       :
*     Chapter 9 GetInterface command
* 
*END*--------------------------------------------------------------------*/
void ch9GetInterface
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   uint_16 usb_state;
   
   _usb_device_get_status(handle, USB_STATUS_DEVICE_STATE, &usb_state);
   if (usb_state != USB_STATE_CONFIG) {
      _usb_device_stall_endpoint(handle, 0, 0);
      return;
   } /* Endif */

   if (setup) {
      _usb_device_send_data(handle, 0, &USB_IF_ALT[setup_ptr->INDEX & 0x00FF],
         MIN(setup_ptr->LENGTH, sizeof(uint_8)));
      /* status phase */      
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SetInterface
* Returned Value : None
* Comments       :
*     Chapter 9 SetInterface command
* 
*END*--------------------------------------------------------------------*/
void ch9SetInterface
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   if (setup) {
      if (setup_ptr->REQUESTTYPE != 0x01) {
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */

      /*
      ** If the alternate value (setup_ptr->VALUE & 0x00FF) differs
      ** from the current alternate value for the specified interface,
      ** then endpoints must be reconfigured to match the new alternate
      */
      if (USB_IF_ALT[setup_ptr->INDEX & 0x00FF]
         != (setup_ptr->VALUE & 0x00FF))
      {
         USB_IF_ALT[setup_ptr->INDEX & 0x00FF] = (setup_ptr->VALUE & 0x00FF);
         /* Reconfigure endpoints here. */
         
      } /* Endif */

      /* status phase */
      _usb_device_send_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9SynchFrame
* Returned Value : 
* Comments       :
*     Chapter 9 SynchFrame command
* 
*END*--------------------------------------------------------------------*/
void ch9SynchFrame
   (
      /* USB handle */
      _usb_device_handle handle,
      
      /* Is it a Setup phase? */
      boolean setup,
            
      /* The setup packet pointer */
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   
   if (setup) {
      if (setup_ptr->REQUESTTYPE != 0x02) {
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */

      if ((setup_ptr->INDEX & 0x00FF) >=
         ConfigDesc[CONFIG_DESC_NUM_INTERFACES])
      {
         _usb_device_stall_endpoint(handle, 0, 0);
         return;
      } /* Endif */

      _usb_device_get_status(handle, USB_STATUS_SOF_COUNT, (uint_16_ptr)epTemp_buf);
      _usb_device_send_data(handle, 0, epTemp_buf,
         MIN(setup_ptr->LENGTH, sizeof(uint_16)));
      /* status phase */      
      _usb_device_recv_data(handle, 0, 0, 0);
   } /* Endif */
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : ch9Class
* Returned Value : 
* Comments       :
*     Chapter 9 Class specific request
*     See section 9.4.11 (page 195) of the USB 1.1 Specification.
* 
*END*--------------------------------------------------------------------*/
void ch9Class
   (
      _usb_device_handle handle,
      boolean setup,
      uint_8  direction,
      SETUP_STRUCT_PTR setup_ptr
   )
{ /* Body */
   
   if (setup) {
      switch (setup_ptr->REQUEST) {
         case 0xFF:
            /* Bulk-Only Mass Storage Reset: Ready the device for the next 
            ** CBW from the host 
            */
            if ((setup_ptr->VALUE != 0) || 
                (setup_ptr->INDEX != MASS_STORAGE_INTERFACE) ||
                (setup_ptr->LENGTH != 0)) {
                _usb_device_stall_endpoint(handle, 0, 0);
            } else { /* Body */
               CBW_PROCESSED = FALSE;
               ZERO_TERMINATE = FALSE;
               _usb_device_cancel_transfer(handle, 1, USB_RECV);
               _usb_device_cancel_transfer(handle, 1, USB_SEND);
               
               /* unstall bulk endpoint */
               _usb_device_unstall_endpoint(handle, 1, 0);
               _usb_device_unstall_endpoint(handle, 1, 1);
               /* 
               _usb_device_set_status(handle, USB_STATUS_ENDPOINT | 1, 0); */
               
               _usb_device_recv_data(handle, 1, ep1_buf, 31);
               /* send zero packet to control pipe */
               _usb_device_send_data(handle, 0, 0, 0);
            } /* Endbody */
            return;
         case 0xFE:
            /* For Get Max LUN use any of these responses*/
            if (setup_ptr->LENGTH == 0) { /* Body */
               _usb_device_stall_endpoint(handle, 0, 0);
            } else if ((setup_ptr->VALUE != 0) ||
                (setup_ptr->INDEX != MASS_STORAGE_INTERFACE) ||
                (setup_ptr->LENGTH != 1)) { /* Body */
                _usb_device_stall_endpoint(handle, 0, 0);
             } else { /* Body */
               /* Send Max LUN = 0 to the the control pipe */
               *epTemp_buf = 0;
               _usb_device_send_data(handle, 0, epTemp_buf, 1);
                 /* status phase */
               _usb_device_recv_data(handle, 0, 0, 0);
               
             } /* Endbody */     
            return;
         default :
            _usb_device_stall_endpoint(handle, 0, 0);
            return;
      } /* EndSwitch */
   } 

} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : service_ep0
* Returned Value : None
* Comments       :
*     Called upon a completed endpoint 0 (USB 1.1 Chapter 9) transfer
* 
*END*--------------------------------------------------------------------*/
void service_ep0
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
      
      /* [IN] Is it a setup packet? */
      boolean              setup,
      
      /* [IN] Direction of the transfer.  Is it transmit? */
      uint_8               direction,
      
      /* [IN] Pointer to the data buffer */
      uint_8_ptr           buffer,
      
      /* [IN] Length of the transfer */
      uint_32              length,
      
      /* [IN] Error, if any */
      uint_8               error
            
   )
{ /* Body */
   
   if (setup) {
      _usb_device_read_setup_data(handle, 0, (uchar_ptr)&local_setup_packet);
   }
   
   switch (local_setup_packet.REQUESTTYPE & 0x60) {

      case 0x00:
         switch (local_setup_packet.REQUEST) {

            case 0x0:
               ch9GetStatus(handle, setup, &local_setup_packet);
               break;

            case 0x1:
               ch9ClearFeature(handle, setup, &local_setup_packet);
               break;

            case 0x3:
               ch9SetFeature(handle, setup, &local_setup_packet);
               break;

            case 0x5:
               ch9SetAddress(handle, setup, &local_setup_packet);
               break;

            case 0x6:
               ch9GetDescription(handle, setup, &local_setup_packet);
               break;

            case 0x7:
               ch9SetDescription(handle, setup, &local_setup_packet);
               break;

            case 0x8:
               ch9GetConfig(handle, setup, &local_setup_packet);
               break;

            case 0x9:
               ch9SetConfig(handle, setup, &local_setup_packet);
               break;

            case 0xa:
               ch9GetInterface(handle, setup, &local_setup_packet);
               break;

            case 0xb:
               ch9SetInterface(handle, setup, &local_setup_packet);
               break;

            case 0xc:
               ch9SynchFrame(handle, setup, &local_setup_packet);
               break;

            default:
               _usb_device_stall_endpoint(handle, 0, 0);
               break;

         } /* Endswitch */
         
         break;

      case 0x20:
         /* class specific request */
         ch9Class(handle, setup, direction, &local_setup_packet);
         return;

      case 0x40:
         /* vendor specific request can be handled here*/
         _usb_device_stall_endpoint(handle, 0, 0);
         break;
      
      default:
         _usb_device_stall_endpoint(handle, 0, 0);
         break;
         
   } /* Endswitch */
   
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _process_inquiry_command
* Returned Value : None
* Comments       :
*     Process a Mass storage class Inquiry command
* 
*END*--------------------------------------------------------------------*/
void _process_inquiry_command
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
            
      /* [IN] Endpoint number */
      uint_8               ep_num,
      
      /* [IN] Pointer to the data buffer */
      CBW_STRUCT_PTR       cbw_ptr
   )
{ /* Body */
   MASS_STORAGE_INQUIRY_PTR   inquiry_cmd_ptr = 
      (MASS_STORAGE_INQUIRY_PTR)((pointer)cbw_ptr->CBWCB);

   if (cbw_ptr->DCBWDATALENGTH) {
      if (cbw_ptr->BMCBWFLAGS & USB_CBW_DIRECTION_BIT) {      
         /* Send the device information */
         _usb_device_send_data(handle, 1, (uchar_ptr)&device_information_data, 
            36);
      } /* Endif */
   } /* Endif */
   
   /* The actual length will never exceed the DCBWDATALENGTH */            
   csw.DCSWDATARESIDUE = (cbw_ptr->DCBWDATALENGTH - 36);
   csw.BCSWSTATUS = 0;
   
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _process_unsupported_command
* Returned Value : None
* Comments       :
*     Responds appropriately to unsupported commands
* 
*END*--------------------------------------------------------------------*/
void _process_unsupported_command
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
            
      /* [IN] Endpoint number */
      uint_8               ep_num,
      
      /* [IN] Pointer to the data buffer */
      CBW_STRUCT_PTR       cbw_ptr
   )
{ /* Body */
   
   /* The actual length will never exceed the DCBWDATALENGTH */
   csw.DCSWDATARESIDUE = 0;
   csw.BCSWSTATUS = 0;

   if (cbw_ptr->BMCBWFLAGS & USB_CBW_DIRECTION_BIT) {      
      /* Send a zero-length packet */
      _usb_device_send_data(handle, ep_num, 
         (uchar_ptr)&device_information_data, 0);
   } else {
      CBW_PROCESSED = FALSE;
      /* Send the command status information */
      _usb_device_send_data(handle, 1, (uchar_ptr)&csw, 13);
      _usb_device_recv_data(handle, 1, ep1_buf, 31);
   } /* Endif */
   
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _process_report_capacity
* Returned Value : None
* Comments       :
*     Reports the media capacity as a response to READ CAPACITY Command.
* 
*END*--------------------------------------------------------------------*/
void _process_report_capacity
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
            
      /* [IN] Endpoint number */
      uint_8               ep_num,
      
      /* [IN] Pointer to the data buffer */
      CBW_STRUCT_PTR       cbw_ptr
   )
{ /* Body */

   if (cbw_ptr->BMCBWFLAGS & USB_CBW_DIRECTION_BIT) {      
      /* Send a zero-length packet */
         _usb_device_send_data(handle, ep_num, (uchar_ptr)&read_capacity, 8);
      
   } /* Endif */
   
   /* The actual length will never exceed the DCBWDATALENGTH */            
   csw.DCSWDATARESIDUE = 0;
   csw.BCSWSTATUS = 0;
   
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _process_read_command
* Returned Value : None
* Comments       :
*     Sends data as a response to READ Command.
* 
*END*--------------------------------------------------------------------*/
void _process_read_command
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
            
      /* [IN] Endpoint number */
      uint_8               ep_num,
      
      /* [IN] Pointer to the data buffer */
      CBW_STRUCT_PTR       cbw_ptr
   )
{ /* Body */
   uint_32 index1 = 0, index2 = 0;
   uint_32 max_pkt_size;

   if (cbw_ptr->BMCBWFLAGS & USB_CBW_DIRECTION_BIT) {      
      /* Send a zero-length packet */
      index1  = ((uint_32)cbw_ptr->CBWCB[4] << 8);
      index1  |= cbw_ptr->CBWCB[5];
      index2 = ((uint_32)cbw_ptr->CBWCB[7] << 8);
      index2 |= (uint_32)cbw_ptr->CBWCB[8];
      
      index2 *= LENGTH_OF_EACH_LAB;
      
      if (cbw_ptr->DCBWDATALENGTH == 0) { /* Body */
         csw.DCSWDATARESIDUE = 0;
         csw.BCSWSTATUS = 2;
         CBW_PROCESSED = FALSE;
         /* Send the command status information */
         _usb_device_send_data(handle, ep_num, (uchar_ptr)&csw, 13);
         _usb_device_recv_data(handle, ep_num, ep1_buf, 31);
         return;
      } else { /* Body */
         csw.DCSWDATARESIDUE = 0;
         csw.BCSWSTATUS = 0;         
         if (index2 > cbw_ptr->DCBWDATALENGTH) { /* Body */
            index2 = cbw_ptr->DCBWDATALENGTH;
            csw.DCSWDATARESIDUE = cbw_ptr->DCBWDATALENGTH;
            csw.BCSWSTATUS = 2;
         } else if (index2 < cbw_ptr->DCBWDATALENGTH) { /* Body */
            csw.DCSWDATARESIDUE = cbw_ptr->DCBWDATALENGTH - index2;
            if (index2 > 0) { /* Body */
               if (speed == USB_SPEED_HIGH) {
                  max_pkt_size = EP1_HS_MAX_PACKET_SIZE;
	            } else {
                  max_pkt_size = EP1_FS_MAX_PACKET_SIZE;
	            }
               if (index2%max_pkt_size == 0) { /* Body */
                  /* Need send a zero terminate packet to host */
                  ZERO_TERMINATE = TRUE;
               } /* Endbody */
            } /* Endbody */  
         } /* Endbody */
         _usb_device_send_data(handle, ep_num, 
            MASS_STORAGE_DISK + (index1*LENGTH_OF_EACH_LAB), 
            index2);
      } /* Endbody */
   } else { /* Body */
      /* Incorrect but valid CBW */
      if (cbw_ptr->DCBWDATALENGTH > BUFFERSIZE)
         index2 = BUFFERSIZE;
      else
         index2 = cbw_ptr->DCBWDATALENGTH;
      csw.DCSWDATARESIDUE = cbw_ptr->DCBWDATALENGTH;
      csw.BCSWSTATUS = 2;
       _usb_device_recv_data(handle, ep_num, ep1_buf, index2);   
   } /* Endbody */  
   
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _process_write_command
* Returned Value : None
* Comments       :
*     Sends data as a response to WRITE Command.
* 
*END*--------------------------------------------------------------------*/
void _process_write_command
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
            
      /* [IN] Endpoint number */
      uint_8               ep_num,
      
      /* [IN] Pointer to the data buffer */
      CBW_STRUCT_PTR       cbw_ptr
   )
{ /* Body */
   uint_32 index1 = 0, index2 = 0;

   if (!(cbw_ptr->BMCBWFLAGS & USB_CBW_DIRECTION_BIT)) {
      index1  = ((uint_32)cbw_ptr->CBWCB[4] << 8);
      index1  |= cbw_ptr->CBWCB[5];
      index2 = ((uint_32)cbw_ptr->CBWCB[7] << 8);
      index2 |= (uint_32)cbw_ptr->CBWCB[8];
      
      if (cbw_ptr->DCBWDATALENGTH == 0) { /* Body */
         /* Zero transfer length */
         csw.DCSWDATARESIDUE = 0;
         csw.BCSWSTATUS = 2;
         CBW_PROCESSED = FALSE;
         /* Send the command status information */
         _usb_device_send_data(handle, ep_num, (uchar_ptr)&csw, 13);
         _usb_device_recv_data(handle, ep_num, ep1_buf, 31);
         return;
      } else { /* Body */
         csw.DCSWDATARESIDUE = 0;
         csw.BCSWSTATUS = 0;
         index2 *= LENGTH_OF_EACH_LAB;
         
         if (index2 < cbw_ptr->DCBWDATALENGTH) { /* Body */
            /* The actual length will never exceed the DCBWDATALENGTH */
            csw.DCSWDATARESIDUE = cbw_ptr->DCBWDATALENGTH - index2;
            index2 = cbw_ptr->DCBWDATALENGTH;
         } else if (index2 > cbw_ptr->DCBWDATALENGTH) { /* Body */
            csw.DCSWDATARESIDUE = cbw_ptr->DCBWDATALENGTH;
            csw.BCSWSTATUS = 2;
            index2 = cbw_ptr->DCBWDATALENGTH;
         } /* Endbody */
            
         if (_usb_device_get_transfer_status(handle, ep_num, USB_RECV) != USB_OK) {
            _usb_device_cancel_transfer(handle, ep_num, USB_RECV);
         } /* Endif */
               
         _usb_device_recv_data(handle, ep_num, 
            MASS_STORAGE_DISK + (index1*LENGTH_OF_EACH_LAB), 
            index2);
      }
   } else { /* Body */
      /* Incorrect but valid CBW */
      csw.DCSWDATARESIDUE = cbw_ptr->DCBWDATALENGTH;
      csw.BCSWSTATUS = 2;
      _usb_device_send_data(handle, ep_num, 0, 0);
      return;
   } /* Endbody */
   
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _process_test_unit_ready
* Returned Value : None
* Comments       :
*     Responds appropriately to unit ready query
* 
*END*--------------------------------------------------------------------*/
void _process_test_unit_ready
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
            
      /* [IN] Endpoint number */
      uint_8               ep_num,
      
      /* [IN] Pointer to the data buffer */
      CBW_STRUCT_PTR       cbw_ptr
   )
{ /* Body */
   uint_32 BufSize;
   
   if ((cbw_ptr->BMCBWFLAGS & USB_CBW_DIRECTION_BIT) ||
       (cbw_ptr->DCBWDATALENGTH == 0)) {
      /* The actual length will never exceed the DCBWDATALENGTH */
      csw.DCSWDATARESIDUE = 0;
      csw.BCSWSTATUS = 0;
   
      CBW_PROCESSED = FALSE;
      /* Send the command status information */
      _usb_device_send_data(handle, 1, (uchar_ptr)&csw, 13);
      _usb_device_recv_data(handle, 1, ep1_buf, 31);
   } else { /* Body */
      /* Incorrect but valid CBW */
      if (cbw_ptr->DCBWDATALENGTH > BUFFERSIZE)
         BufSize = BUFFERSIZE;
      else
         BufSize = cbw_ptr->DCBWDATALENGTH;
      csw.DCSWDATARESIDUE = cbw_ptr->DCBWDATALENGTH;
      csw.BCSWSTATUS = 1;
      _usb_device_recv_data(handle, ep_num, ep1_buf, BufSize);
   } /* Endbody */
   
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _process_prevent_allow_medium_removal
* Returned Value : None
* Comments       :
*     Responds appropriately to unit ready query
* 
*END*--------------------------------------------------------------------*/
void _process_prevent_allow_medium_removal
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
            
      /* [IN] Endpoint number */
      uint_8               ep_num,
      
      /* [IN] Pointer to the data buffer */
      CBW_STRUCT_PTR       cbw_ptr
   )
{ /* Body */

   /* The actual length will never exceed the DCBWDATALENGTH */
   csw.DCSWDATARESIDUE = 0;
   csw.BCSWSTATUS = 0;
   
   CBW_PROCESSED = FALSE;
   /* Send the command status information */
   _usb_device_send_data(handle, 1, (uchar_ptr)&csw, 13);

   _usb_device_recv_data(handle, 1, ep1_buf, 31);
   
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _process_mass_storage_command
* Returned Value : None
* Comments       :
*     Process a Mass storage class command
* 
*END*--------------------------------------------------------------------*/
void _process_mass_storage_command
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
            
      /* [IN] Endpoint number */
      uint_8               ep_num,
      
      /* [IN] Pointer to the data buffer */
      CBW_STRUCT_PTR       cbw_ptr
   )
{ /* Body */
   switch (cbw_ptr->CBWCB[0]) {
      case 0x00: /* Request the device to report if it is ready */
         _process_test_unit_ready(handle, ep_num, cbw_ptr);
         break;
      case 0x12: /* Inquity command. Get device information */

         _process_inquiry_command(handle, ep_num, cbw_ptr);
         break;
      case 0x1A:
         _process_unsupported_command(handle, ep_num, cbw_ptr);
         break;
      case 0x1E: /* Prevent or allow the removal of media from a removable 
                 ** media device 
                 */
         _process_prevent_allow_medium_removal(handle, ep_num, cbw_ptr);
         break;
      case 0x23: /* Read Format Capacities. Report current media capacity and 
                 ** formattable capacities supported by media 
                 */
         /* We bahave like already installed medium. No need to send any data */
         _process_unsupported_command(handle, ep_num, cbw_ptr);
         break;
      case 0x25: /* Report current media capacity */
         _process_report_capacity(handle, ep_num, cbw_ptr);
         break;
      case 0x28: /* Read (10) Transfer binary data from media to the host */
         _process_read_command(handle, ep_num, cbw_ptr);
         break;
      case 0x2A: /* Write (10) Transfer binary data from the host to the 
                 ** media 
                 */
         _process_write_command(handle, ep_num, cbw_ptr);
         break;
      case 0x01: /* Position a head of the drive to zero track */
      case 0x03: /* Transfer status sense data to the host */
      case 0x04: /* Format unformatted media */
      case 0x1B: /* Request a request a removable-media device to load or 
                 ** unload its media 
                 */
      case 0x1D: /* Perform a hard reset and execute diagnostics */
      case 0x2B: /* Seek the device to a specified address */
      case 0x2E: /* Transfer binary data from the host to the media and 
                 ** verify data 
                 */
      case 0x2F: /* Verify data on the media */
      case 0x55: /* Allow the host to set parameters in a peripheral */
      case 0x5A: /* Report parameters to the host */
      case 0xA8: /* Read (12) Transfer binary data from the media to the host */
      case 0xAA: /* Write (12) Transfer binary data from the host to the 
                 ** media 
                 */
      default:
         _process_unsupported_command(handle, ep_num, cbw_ptr);
         break;
   } /* Endswitch */

} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : service_ep1
* Returned Value : None
* Comments       :
*     Called upon a completed endpoint 1 (USB 1.1 Chapter 9) transfer
* 
*END*--------------------------------------------------------------------*/
void service_ep1
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
      
      /* [IN] Is it a setup packet? */
      boolean              setup,
      
      /* [IN] Direction of the transfer.  Is it transmit? */
      uint_8               direction,
      
      /* [IN] Pointer to the data buffer */
      uint_8_ptr           buffer,
      
      /* [IN] Length of the transfer */
      uint_32              length,

      /* [IN] Error, if any */
      uint_8               error
            
   )
{ /* Body */
   CBW_STRUCT_PTR cbw_ptr;      

   if ((!direction) && (!CBW_PROCESSED)) {
      cbw_ptr = (CBW_STRUCT_PTR)((pointer)buffer);
   } /* Endif */

   if ((!direction) && (!CBW_PROCESSED) && (length == 31) && 
      (cbw_ptr->DCBWSIGNATURE == USB_DCBWSIGNATURE)) 
   {
      /* A valid CBW was received */
      csw.DCSWSIGNATURE = USB_DCSWSIGNATURE;
      csw.DCSWTAG = cbw_ptr->DCBWTAG;
      CBW_PROCESSED = TRUE;
      /* Process the command */
      _process_mass_storage_command(handle, 1, cbw_ptr);
   } else {
      /* If a CBW was processed then send the status information and 
      ** queue another cbw receive request, else just queue another CBW receive
      ** request if we received an invalid CBW 
      */
      if (CBW_PROCESSED) {
         if (ZERO_TERMINATE) { /* Body */
            ZERO_TERMINATE = FALSE;
            _usb_device_send_data(handle, 1, 0, 0);
         } else { /* Body */
            CBW_PROCESSED = FALSE;
            /* Send the command status information */
            _usb_device_send_data(handle, 1, (uchar_ptr)&csw, 13);        
            _usb_device_recv_data(handle, 1, ep1_buf, 31);
         }
      } else if (!direction) {
         _usb_device_stall_endpoint(handle, 1, 0);
         _usb_device_stall_endpoint(handle, 1, 1);

         /* Invalid CBW received. Queue another receive buffer */
         _usb_device_recv_data(handle, 1, ep1_buf, 31);  
      } /* Endif */
   } /* Endif */
   
   return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : service_speed
* Returned Value : None
* Comments       :
*     Called upon a speed detection event.
* 
*END*--------------------------------------------------------------------*/
void service_speed
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
   
      /* [IN] Unused */
      boolean              setup,
   
      /* [IN] Unused */
      uint_8               direction,
   
      /* [IN] Unused */
      uint_8_ptr           buffer,
   
      /* [IN] Unused */
      uint_32              length,

      /* [IN] Error, if any */
      uint_8               error
            
   )
{ /* EndBody */
   speed = length;
   return;
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : reset_ep0
* Returned Value : None
* Comments       :
*     Called upon a bus reset event.  Initialises the control endpoint.
* 
*END*--------------------------------------------------------------------*/
void reset_ep0
   (
      /* [IN] Handle of the USB device */
      _usb_device_handle   handle,
   
      /* [IN] Unused */
      boolean              setup,
   
      /* [IN] Unused */
      uint_8               direction,
   
      /* [IN] Unused */
      uint_8_ptr           buffer,
   
      /* [IN] Unused */
      uint_32              length,

      /* [IN] Error, if any */
      uint_8               error
            
   )
{ /* Body */

   /* on a reset always ensure all transfers are cancelled on control EP*/
   _usb_device_cancel_transfer(handle, 0, USB_RECV);
   _usb_device_cancel_transfer(handle, 0, USB_SEND);

   
   /* Initialize the endpoint 0 in both directions */
   _usb_device_init_endpoint(handle, 0, DevDesc[DEV_DESC_MAX_PACKET_SIZE], 
      USB_RECV, USB_CONTROL_ENDPOINT, 0);
   _usb_device_init_endpoint(handle, 0, DevDesc[DEV_DESC_MAX_PACKET_SIZE], 
      USB_SEND, USB_CONTROL_ENDPOINT, 0);

   if (TEST_ENABLED) {
      _usb_device_cancel_transfer(handle, 1, USB_RECV);
      _usb_device_cancel_transfer(handle, 1, USB_SEND);
   } /* Endif */
   
   TEST_ENABLED = FALSE;
   
   return;
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : main
* Returned Value : None
* Comments       :
*     First function called.  Initialises the USB and registers Chapter 9
*     callback functions.
* 
*END*--------------------------------------------------------------------*/
#ifdef __USB_OS_MQX__
void Main_Task
   (
      uint_32 param
   )
#else
void main
   (
      void
   )
#endif   
{ /* Body */
   _usb_device_handle   handle;
   uint_8               error;
   uint_32              send_data_buffer_size=0;
   uchar_ptr            temp;
                              
   /*lock interrupts */
   USB_lock();
   
#ifdef __USB_OS_MQX__
    _int_install_unexpected_isr(); 
   _usb_driver_install(0, &_bsp_usb_callback_table);
#endif   
   
   /* Initialize the USB interface */
   error = _usb_device_init(0, &handle, 2);
   
   if (error != USB_OK) {
      printf("\nUSB Initialization failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

/**********************************************************
When customers need to generate extremely small sizes of
code, device stack provides the capability that they should
not need to register for services. Instead they can hardcode
the routine names (to be called for each service) inside
stack source files and recompile the stack. The switch
called 'SMALL_CODE_SIZE' can be enabled from config.mk
inside stack build directory.
**********************************************************/
   
#ifndef SMALL_CODE_SIZE   
   
   error = _usb_device_register_service(handle, USB_SERVICE_EP0, service_ep0);
   
   if (error != USB_OK) {
      printf("\nUSB Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */
   
   error = _usb_device_register_service(handle, USB_SERVICE_BUS_RESET, 
      reset_ep0);
   
   if (error != USB_OK) {
      printf("\nUSB Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */
   
   error = _usb_device_register_service(handle, USB_SERVICE_SPEED_DETECTION, 
      service_speed);

   if (error != USB_OK) {
      printf("\nUSB Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */
         
   error = _usb_device_register_service(handle, USB_SERVICE_EP1, service_ep1);
   
   if (error != USB_OK) {
      printf("\nUSB Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

#endif

   /**************************************************************************
   Best way to handle the Data cache is to allocate a large buffer that is
   cache aligned and keep all data inside it. Flush the line of the cache
   that you have changed. In this program, we have static data such as 
   descriptors which never changes. Such data can be kept in this buffer
   and flushed only once. Note that you can reduce the size of this buffer
   by aligning the addresses in a different way.   
   ***************************************************************************/
   send_data_buffer_size =  (DEVICE_DESCRIPTOR_SIZE +  PSP_CACHE_LINE_SIZE) +
                            (CONFIG_DESC_SIZE + PSP_CACHE_LINE_SIZE) +
                            (DEVICE_QUALIFIER_DESCRIPTOR_SIZE + PSP_CACHE_LINE_SIZE) +
                            (OTHER_SPEED_CONFIG_DESC_SIZE + PSP_CACHE_LINE_SIZE) +
                            (BUFFERSIZE + PSP_CACHE_LINE_SIZE) +
                            (EP_TEMP_BUFFERSIZE + PSP_CACHE_LINE_SIZE) + 
                            (TOTAL_LOGICAL_ADDRESS_BLOCKS*LENGTH_OF_EACH_LAB + PSP_CACHE_LINE_SIZE);
                               
   Send_Buffer_Unaligned   = (uchar_ptr) USB_memalloc(send_data_buffer_size);
   if (Send_Buffer_Unaligned == NULL) {
      printf("\nBuffer allocation failed");
      fflush(stdout);
   }
   
   Send_Buffer_aligned = (uchar_ptr) USB_CACHE_ALIGN((uint_32) Send_Buffer_Unaligned);
   /* keep a temporary copy of the aligned address */
   temp = Send_Buffer_aligned;
   

   /**************************************************************************
   Assign pointers to different buffers from it and copy data inside.
   ***************************************************************************/
   DevDesc =  (uchar_ptr) Send_Buffer_aligned;
   USB_memcopy(DevDescData, DevDesc, DEVICE_DESCRIPTOR_SIZE);
   Send_Buffer_aligned += ((DEVICE_DESCRIPTOR_SIZE/PSP_CACHE_LINE_SIZE) + 1)* PSP_CACHE_LINE_SIZE; 
   
   ConfigDesc =  (uchar_ptr) Send_Buffer_aligned;
   USB_memcopy(ConfigDescData, ConfigDesc, CONFIG_DESC_SIZE);
   Send_Buffer_aligned += ((CONFIG_DESC_SIZE/PSP_CACHE_LINE_SIZE) + 1)* PSP_CACHE_LINE_SIZE; 
   
   DevQualifierDesc =  (uchar_ptr) Send_Buffer_aligned;
   USB_memcopy(DevQualifierDescData, DevQualifierDesc, DEVICE_QUALIFIER_DESCRIPTOR_SIZE);
   Send_Buffer_aligned += ((DEVICE_QUALIFIER_DESCRIPTOR_SIZE/PSP_CACHE_LINE_SIZE) + \
                           1)* PSP_CACHE_LINE_SIZE;

   other_speed_config =  (uchar_ptr) Send_Buffer_aligned;
   USB_memcopy(other_speed_config_data, other_speed_config, OTHER_SPEED_CONFIG_DESC_SIZE);
   Send_Buffer_aligned += ((OTHER_SPEED_CONFIG_DESC_SIZE/PSP_CACHE_LINE_SIZE) + 1)* PSP_CACHE_LINE_SIZE; 

   /*buffer to receive data from Bulk OUT */
   ep1_buf =  (uchar_ptr) Send_Buffer_aligned;
   USB_memzero(ep1_buf,BUFFERSIZE);
   Send_Buffer_aligned += ((BUFFERSIZE/PSP_CACHE_LINE_SIZE) + 1)* PSP_CACHE_LINE_SIZE;
   
   /*buffer for control endpoint to send data */
   epTemp_buf =  (uchar_ptr) Send_Buffer_aligned;
   /* USB_memzero(epTemp_buf,EP_TEMP_BUFFERSIZE); */
   Send_Buffer_aligned += ((EP_TEMP_BUFFERSIZE/PSP_CACHE_LINE_SIZE) + 1)* PSP_CACHE_LINE_SIZE; 

   /*buffer for storage disk */
   MASS_STORAGE_DISK =  (uchar_ptr) Send_Buffer_aligned;

   memset(MASS_STORAGE_DISK, 0,
      (TOTAL_LOGICAL_ADDRESS_BLOCKS*LENGTH_OF_EACH_LAB));
   /* Format the "disk" */      
   memcpy(MASS_STORAGE_DISK, BOOT_SECTOR_AREA, 512);
   memcpy(MASS_STORAGE_DISK + 512, FAT16_SPECIAL_BYTES, 3);
   memcpy(MASS_STORAGE_DISK + 512*4, FAT16_SPECIAL_BYTES, 3);
                          
   /**************************************************************************
   Flush the cache to ensure main memory is updated.
   ***************************************************************************/
   USB_dcache_flush_mlines(temp, send_data_buffer_size);

   #ifdef DEMO_FULL_SPEED_MODE
      /* Make the following call to set the HS core to full speed */
      _usb_device_set_status(handle, USB_FORCE_FULL_SPEED, 0);
   #endif

   /* This is a Self-Powered Device so set device status to show that. */
   _usb_device_set_status(handle, USB_STATUS_DEVICE, USB_SELF_POWERED);

   USB_unlock();
   
   while (TRUE) 
   {
      /* Do nothing */
         #ifdef DEMO_TRANSFER_PROGRESS
            _usb_device_get_transfer_details(handle, 1, USB_SEND, &((uint_32_ptr)info));
            if(info != NULL)
            {
               printf("\nBytes Done so far =", (uint_32)info->WSOFAR);
            }
         #endif
   } /* Endwhile */
   
} /* Endbody */

/* EOF */
