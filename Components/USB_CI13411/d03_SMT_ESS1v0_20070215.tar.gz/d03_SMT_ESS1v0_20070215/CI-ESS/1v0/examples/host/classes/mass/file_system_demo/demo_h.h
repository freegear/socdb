#ifndef __demo_h_h__
#define __demo_h_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the Test specific data structures and defines
***                                                               
**************************************************************************
**END*********************************************************/
#include "host_dev_list.h"
#include "host_common.h"

#define  USB_DEVICE_IDLE                   (0)
#define  USB_DEVICE_ATTACHED               (1)
#define  USB_DEVICE_CONFIGURED             (2)
#define  USB_DEVICE_SET_INTERFACE_STARTED  (3)
#define  USB_DEVICE_INTERFACED             (4)
#define  USB_DEVICE_DETACHED               (5)
#define  USB_DEVICE_OTHER                  (6)

typedef struct device_struct {
   uint_32                          STATE;
   _usb_device_instance_handle      DEV_HANDLE;
   _usb_interface_descriptor_handle INTF_HANDLE;
   CLASS_CALL_STRUCT                CLASS_INTF;
   boolean                          SUPPORTED;
} DEVICE_STRUCT,  _PTR_ DEVICE_STRUCT_PTR;


typedef struct app_global_struct
{
   uchar_ptr               RX_CONFIG_DESC;
} APP_GLOBAL_STRUCT, _PTR_ APP_GLOBAL_STRUCT_PTR;

	extern USB_SETUP tx_get_status;
	extern USB_SETUP tx_clear_feature;
	extern USB_SETUP tx_set_feature;
	extern USB_SETUP tx_synch_frame;
	extern USB_SETUP tx_get_desc;
	extern USB_SETUP tx_get_string_desc;
	extern USB_SETUP tx_get_config_desc;
	extern USB_SETUP tx_set_address;
	extern USB_SETUP tx_get_config;
	extern USB_SETUP tx_set_config;
	extern USB_SETUP tx_set_interface;
	extern USB_SETUP tx_get_interface;
	extern USB_SETUP tx_get_alt_interface;
	extern USB_SETUP tx_get_port_status;
	extern USB_SETUP tx_enable_echo;


#endif



