/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
*** This file is the main file for filesystem demo. Note that this example
*** is a multi tasking example and needs an operating system to run. This 
*** means that customers who are not using MQX should change the operating system
*** dependent code. An attempt has been made to comment out the code
*** however, a programmer must review all lines of code to ensure that
*** it correctly compiles with their libraries of operating system and
*** targetcompiler. This program has been compiled and tested for ARC AA3
***  processor with MQX real time operating system.
***
**************************************************************************
**END*********************************************************/




/**************************************************************************
Include the USB stack header files.
**************************************************************************/

#include "types.h"
#ifdef __USB_OTG__
   #include "otgapi.h"
   #include "devapi.h"

#else
   #include "hostapi.h"
#endif

/**************************************************************************
Include the OS and BSP dependent files that define IO functions and
basic types. You may like to change these files for your board and RTOS 
**************************************************************************/

#ifdef __USB_OS_MQX__
   #include "bsp.h"
   #include "fio.h"
   #include "mqx_arc.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif
   #include "stdlib.h"
#endif
#include "string.h"

/**************************************************************************
Local header files for this application
**************************************************************************/

#include "demo.h"
#include "demo_h.h"
#include "mfsdemo.h"

/**************************************************************************
Some MQX specific macros
**************************************************************************/

#ifndef MQX_DEVICE
#define MQX_DEVICE BSP_DEFAULT_IO_CHANNEL
#endif


/**************************************************************************
The following is the way to define a multi tasking system in MQX. As seen
here,two tasks have been defined. They are called as MAIN_TASK and FILE_TASK.
MAIN TASK has been slightly higher priority (6L) that file system (7L),just
to ensure that OTG events are handled first then file system. Remove this
code and use your own RTOS way of defining tasks (or threads).
**************************************************************************/

extern void Main_Task(uint_32 param);
#define MAIN_TASK       10

TASK_TEMPLATE_STRUCT  MQX_template_list[] =
{
   { MAIN_TASK,      Main_Task,      6000L,  6L, "Main",      MQX_AUTO_START_TASK},
   { FILE_TASK,      File_task,      6000L,  7L, "File",      0L},
   { 0L,             0L,             0L,   0L, 0L,          0L }
};

/**************************************************************************
A driver info table defines the devices that are supported and handled
by file system application. This table defines the PID, VID, class and
subclass of the USB device that this application listens to. If a device
that matches this table entry, USB stack will generate a attach callback.
As noted, this table defines OPT tester, a UFI class device and a USB
SCSI class device (e.g. high-speed hard disk) as supported devices.
see the declaration of structure USB_HOST_DRIVER_INFO for details
or consult the software architecture guide.
**************************************************************************/


/* Table of driver capabilities this application want to use */
static USB_HOST_DRIVER_INFO DriverInfoTable[] =
{
   /* OPT Tester*/
   {

      {0x0A,0x1A},                  /* Vendor ID per USB-IF             */
      {0x34,0x12},                  /* Product ID per manufacturer      */
      USB_CLASS_MASS_STORAGE,       /* Class code                       */
      USB_SUBCLASS_MASS_UFI,        /* Sub-Class code                   */
      USB_PROTOCOL_MASS_BULK,       /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_device_event         /* Application call back function   */
   },

   /* OPT */
   {

      {0x0A,0x1A},                  /* Vendor ID per USB-IF             */
      {0xDD,0xBA},                  /* Product ID per manufacturer      */
      USB_CLASS_MASS_STORAGE,       /* Class code                       */
      USB_SUBCLASS_MASS_UFI,        /* Sub-Class code                   */
      USB_PROTOCOL_MASS_BULK,       /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_device_event         /* Application call back function   */
   },

   /* Floppy drive */
   {
      {0x00,0x00},                  /* Vendor ID per USB-IF             */
      {0x00,0x00},                  /* Product ID per manufacturer      */
      USB_CLASS_MASS_STORAGE,       /* Class code                       */
      USB_SUBCLASS_MASS_UFI,        /* Sub-Class code                   */
      USB_PROTOCOL_MASS_BULK,       /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_mass_device_event    /* Application call back function   */
   },

   /* USB 2.0 hard drive */
   {

      {0x49,0x0D},                  /* Vendor ID per USB-IF             */
      {0x00,0x30},                  /* Product ID per manufacturer      */
      USB_CLASS_MASS_STORAGE,       /* Class code                       */
      USB_SUBCLASS_MASS_SCSI,       /* Sub-Class code                   */
      USB_PROTOCOL_MASS_BULK,       /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_mass_device_event    /* Application call back function   */
   },
   {
      {0x00,0x00},                  /* Default call back for all other devices */
      {0x00,0x00},
      0,
      0,
      0,
      0,
      usb_host_device_event
   },

   {
      {0x00,0x00},                  /* All-zero entry terminates        */
      {0x00,0x00},                  /*    driver info list.             */
      0,
      0,
      0,
      0,
      NULL
   }

};

/**************************************************************************
   Global variables
**************************************************************************/

_usb_host_handle     host_handle;

/* a useful local structure to track state of the applictaion */
extern volatile APP_GLOBAL_STRUCT app_test_struct;              

/*main routine that handles host role completely*/ 
extern void host_main(_usb_host_handle host_handle);

/* file system routine that formats the disk */
extern void RAM_disk_start();

/**************************************************************************
The following code defines MASS STORAGE DISK storage area as an extern
if file system is enabled or it defines hardware codes array with boot
sector area. This array will bw used as a storage disk area if
MFS is not enabled. In general in this example, MFS is always enabled
at compile time and boot sector array is just provided for example
to customers. You may like to omit this array in your final application
code.
**************************************************************************/

#ifdef MFS_MASS_STORAGE_DISK
uchar *MASS_STORAGE_DISK;
#else
uchar MASS_STORAGE_DISK[TOTAL_LOGICAL_ADDRESS_BLOCKS*LENGTH_OF_EACH_LAB];



uchar BOOT_SECTOR_AREA[512] = {
   /* Block 0 is the boot sector. Following is the data in the boot sector */
   /* 80x86 "short: jump instruction, indicating that the disk is formatted */
    0xEB,
    /* 8-bit displacement */
    0x3C,
    /* NOP OPCode */
    0x90,
    /* 8-bytes for OEM identification: "ARC 4.3 " */
    0x41, 0x52, 0x43, 0x20, 0x34, 0x2E, 0x33, 0x20,
    /* bytes/sector: 512 bytes (0x0200) */
    0x00, 0x02,
    /* Sectors/allocation unit */
    0x01,
    /* Reserved sectors: 0x0001 */
    0x01, 0x00,
    /* Number of File Allocation Tables (FATs): 2 */
    0x02,
    /* Number of root directory entries */
    0x70, 0x00,
    /* Total sectors in logical volume: 720 */
    USB_uint_16_low(TOTAL_LOGICAL_ADDRESS_BLOCKS),
    USB_uint_16_high(TOTAL_LOGICAL_ADDRESS_BLOCKS),
    /* Media descriptor byte: 0xF8: Fixed disk */
    0xFD,
    /* Sectors/FAT: 3 (Each FAT starts at a new sector) */
    0x03, 0x00,
    /* Sectors/track: 9 */
    0x09, 0x00,
    /* Number of heads */
    0x02, 0x00,
    /* Number of hidden sectors: 0 */
    0x00, 0x00, 0x00, 0x00,
    /* Total sectors in logical volume */
    0x00, 0x00, 0x00, 0x00,
    /* Physical drive number */
    0x00,
    /* Reserved */
    0x00,
    /* Extended boot signature record: 0x29 */
    0x29,
    /* 32-bit binary volume ID */
    0x01, 0x02, 0x03, 0x04,
    /* Volume label */
    0x56, 0x41, 0x75, 0x74, 0x6F, 0x6D, 0x61, 0x74, 0x69, 0x6F, 0x6E,
    /* Reserved */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    /* Bootstrap */
    0x33, 0xC0, 0x8E, 0xD0, 0xBC, 0x00, 0x7C, 0xFC, 0xE8, 0x45, 0x00,
    /* String: \r\nNon-System disk\r\nPress any key to reboot\r\n" */
    0x0D, 0x0A, 0x4E, 0x6F, 0x6E, 0x2D, 0x53, 0x79, 0x73, 0x74, 0x65,
    0x6D, 0x20, 0x64, 0x69, 0x73, 0x6B, 0x0D, 0x0A, 0x50, 0x72, 0x65,
    0x73, 0x73, 0x20, 0x61, 0x6E, 0x79, 0x20, 0x6B, 0x65, 0x79, 0x20,
    0x74, 0x6F, 0x20, 0x72, 0x65, 0x62, 0x6F, 0x6F, 0x74, 0x0D, 0x0A,
    0x5E, 0xEB, 0x02, 0xCD, 0x10, 0xB4, 0x0E, 0xBB, 0x07, 0x00, 0x2E,
    0xAC, 0x84, 0xC0, 0x75, 0xF3, 0x98, 0xCD, 0x16, 0xCD, 0x19, 0xEB,
    0xB1, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    /* Partition descriptors */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA
};

uchar FAT16_SPECIAL_BYTES[3] = {
   /* FAT ID: Same as Media descriptor */
   0xFD, 0xFF, 0xFF
};
#endif




/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : main
* Returned Value : None
* Comments       :
*     First function called. This rouine just transfers control to host main
*END*--------------------------------------------------------------------*/
#ifdef __USB_OS_MQX__
void Main_Task
   (
      uint_32 param
   )
#else
void main
   (
      void
   )
#endif

{ /* Body */

   uint_8               error;
   volatile uint_32     i = 0;
   uint_32              state=0;
   char                 c;
   uint_32 last_state            = 0xFFFF; /*used just to avoid too much printing */

   /*********************************************************
   Format the disk
   **********************************************************/
   RAM_disk_start();


   _disable_interrupts();
#ifdef __USB_OS_MQX__
    _int_install_unexpected_isr();
   _usb_driver_install(0, &_bsp_usb_callback_table);
#endif

#ifdef   HOSTLINK_IO
   c = getchar();
#endif


/************************************************************/
   error = _usb_host_init(0, 4, &host_handle);
   if (error != USB_OK) {
      printf("\nUSB Host Initialization failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   /*
   ** Since we are going to act as the host driver, register the driver
   ** information for wanted class/subclass/protocols
   */
   error = _usb_host_driver_info_register(host_handle, DriverInfoTable);
   if (error != USB_OK) {
      printf("\nDriver Registration failed. STATUS: %x", error);
      fflush(stdout);
   } /* Endif */

   error = _usb_host_register_service(host_handle, USB_SERVICE_HOST_RESUME,
      app_process_host_resume);

   if (error != USB_OK) {
      printf("\nUSB Host Service Registration failed. Error: %x", error);
      fflush(stdout);
   } /* Endif */

   _enable_interrupts();

   host_main(host_handle);
   
}


/* EOF */
