#ifndef _usbmfspr_h_
#define _usbmfspr_h_
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments: The file contains functions prototype, defines, structure 
***           definitions private to the USB mass storage link driver
***           to MFS.
*** 
***
**************************************************************************
**END*********************************************************/


/*----------------------------------------------------------------------*/
/*
**                          CONSTANT DEFINITIONS
*/

/* Error codes from lower layers */
#define USB_MFS_DEFAULT_SECTOR_SIZE  (512)

/*----------------------------------------------------------------------*/
/*
**                          ERROR CODES
*/

/* Error codes from lower layers */
#define USB_MFS_NO_ERROR             (0)
#define USB_MFS_READ_ERROR           (1)
#define USB_MFS_WRITE_ERROR          (2)
#define USB_MFS_INVALID_SECTOR       (3)

/*----------------------------------------------------------------------*/
/*
**                    DATATYPE DEFINITIONS
*/


/*
** USB_MFS_INFO_STRUCT
** Run time state information for each USB mass storage device
*/
typedef struct io_usb_mfs_info_struct
{
   /* Handle for mass storage class  calls */
   pointer     MSC_STREAM;
   
   /* 8 bytes of ASCI Data identifying the vendor of the product */
   uchar        VENDOR_INFO[8];
   
   /* 16 bytes of ASCI Data defined by the vendor */
   uchar        PRODUCT_ID[16];
  
   /* 4 bytes of ASCI Data defined by the vendor */
   uchar        PRODUCT_REV[4];
   
   /* CBW tag used for commands */
   uint_32       CBW_TAG;         
   
   /* Drive number to associate with this slot */
   uint_8        LUN;         

   /* Sector size in bytes */
   uint_32       SECTOR_SIZE;   

   /* The total number of sectors in the device */
   uint_32       NUM_SECTORS;

   /* Total size of Drive in bytes */
   uint_32       SIZE_BYTES; 
            
   /* Total size of in sectors */
   uint_32       SIZE_SECTORS;          

   /* The number of heads as reported  */
   uint_32       NUMBER_OF_HEADS;          

   /* The number of tracks as reported  */
   uint_32       NUMBER_OF_TRACKS;

   /* The number of sectos per cylinder as reported */
   uint_32       SECTORS_PER_TRACK;

   /* Light weight semaphore struct */
   LWSEM_STRUCT  LWSEM;
   
   /* The address of temp buffer */
   uchar_ptr     TEMP_BUFF_PTR;

   /* The current error code for the device */
   uint_32       ERROR_CODE;
   
   /* Start CR 812 */
   /* Indicates if the device is running in block mode or character mode */
   boolean       BLOCK_MODE;
   /* End   CR 812 */

} IO_USB_MFS_STRUCT, _PTR_ IO_USB_MFS_STRUCT_PTR;

#ifdef __cplusplus
extern "C" {
#endif

extern int_32 _io_usb_mfs_open(FILE _PTR_, char _PTR_, char _PTR_);
extern int_32 _io_usb_mfs_close(FILE _PTR_);
extern int_32 _io_usb_mfs_read (FILE _PTR_, char_ptr, int_32);
extern int_32 _io_usb_mfs_write(FILE _PTR_, char_ptr, int_32);
extern int_32 _io_usb_mfs_ioctl(FILE _PTR_, int_32, pointer);
extern uint_32 _io_usb_mfs_read_sector(IO_USB_MFS_STRUCT_PTR, uint_32, uint_16, 
   uchar_ptr);
extern uint_32 _io_usb_mfs_read_sector_long(IO_USB_MFS_STRUCT_PTR, uint_32, uint_32, 
   uchar_ptr);
   
extern int_32  _io_usb_mfs_read_partial_sector(FILE _PTR_, uint_32, 
   uint_32, uint_32, uchar_ptr);
extern uint_32 _io_usb_mfs_write_sector(IO_USB_MFS_STRUCT_PTR, uint_32, uint_16, 
   uchar_ptr);
extern uint_32 _io_usb_mfs_write_sector_long(IO_USB_MFS_STRUCT_PTR, uint_32, uint_32,
   uchar_ptr);
   
extern int_32  _io_usb_mfs_write_partial_sector(FILE _PTR_, 
   uint_32, uint_32, uint_32, uchar_ptr);
   
/* Start CR 812 */
extern _mqx_int _io_usb_mfs_read_write_blocks(FILE _PTR_, 
   IO_USB_MFS_STRUCT_PTR, char_ptr, uint_32, boolean);
/* End   CR 812 */
   
#ifdef __cplusplus
}
#endif

#endif
/* EOF */
