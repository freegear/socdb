/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file is an example of device drivers for the printer classe
***
**************************************************************************
**END*********************************************************/

#include "types.h"

#ifdef __USB_OS_MQX__
#include "bsp.h"
#include "mqx_arc.h"
#include "fio.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif
#include "stdlib.h"
#endif

#include "prt_app.h"
#include "usb_printer.h"


/***************************************
**
** Globals
*/

_usb_host_handle        host_handle;         /* global handle for calling host   */


/* Table of driver capabilities this application wants to use */
static  USB_HOST_DRIVER_INFO DriverInfoTable[] =
{
   {
      {0x00,0x00},                  /* Vendor ID per USB-IF             */
      {0x00,0x00},                  /* Product ID per manufacturer      */
      USB_CLASS_PRINTER,            /* Class code                       */
      USB_SUBCLASS_PRINTER,         /* Sub-Class code                   */
      USB_PROTOCOL_PRT_BIDIR,       /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_prt_device_event     /* Application call back function   */
   },
   {
      {0x00,0x00},                  /* All-zero entry terminates        */
      {0x00,0x00},                  /* driver info list.                */
      0,
      0,
      0,
      0,
      NULL
   }
};

volatile DEVICE_STRUCT  prt_device = { 0 };          /* printer data */
volatile uint_32        prt_status = 0;              /* Set in callback */
volatile uint_32        prt_length;                  /* Set in callback */
volatile uint_8         prt_state = 0x00;            /* Incremented in callback */
char_ptr                prt_job;

/* Data buffers */
uchar                   prt_ID[USB_PRINTER_DEVICE_ID_SIZE];
uchar                   prt_buffer[PRT_LINE_CHARS+2];
uchar                   prt_data[] = \
   "Transdimension USB Now Integrated Hi-Speed USB2.0 On-The-Go IP Solution\n\r" \
   "Transdimension USB Now Integrated Hi-Speed USB2.0 On-The-Go IP Solution\n\r" \
   "Transdimension USB Now Integrated Hi-Speed USB2.0 On-The-Go IP Solution\n\r" \
   "Transdimension USB Now Integrated Hi-Speed USB2.0 On-The-Go IP Solution\n\r" \
   "Transdimension USB Now Integrated Hi-Speed USB2.0 On-The-Go IP Solution\n\r" \
   "Transdimension USB Now Integrated Hi-Speed USB2.0 On-The-Go IP Solution\n\r";


#ifdef __USB_OS_MQX__
#define MAIN_TASK          (10)
extern void Main_Task(uint_32 param);
TASK_TEMPLATE_STRUCT  MQX_template_list[] =
{
   { MAIN_TASK,      Main_Task,      3000L,  7L, "Main",      MQX_AUTO_START_TASK},
   { 0L,             0L,             0L,     0L, 0L,          0L }
};
#endif


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : main (Main_Task if using MQX)
* Returned Value : none
* Comments       :
*     Execution starts here
*
*END*--------------------------------------------------------------------*/

#ifdef __USB_OS_MQX__
void Main_Task ( uint_32 param )
#else
void main (void)
#endif

{ /* Body */
   USB_STATUS           status = USB_OK;
   uint_32              index;

   /* _usb_otg_init needs to be done with interrupts disabled */
   _disable_interrupts();

#ifdef __USB_OS_MQX__
   _int_install_unexpected_isr();
   _usb_driver_install(0, &_bsp_usb_callback_table);
#endif

   status = _usb_host_init
      (HOST_CONTROLLER_NUMBER,   /* Use value in header file */
       MAX_FRAME_SIZE,            /* Frame size per USB spec  */
       &host_handle);             /* Returned pointer */

   if (status != USB_OK) {
      printf("\nUSB Host Initialization failed. STATUS: %x", status);
      fflush(stdout);
      return;
   } /* Endif */

   /*
   ** since we are going to act as the host driver, register the driver
   ** information for wanted class/subclass/protocols
   */
   status = _usb_host_driver_info_register
      (host_handle,
       DriverInfoTable);

   if (status != USB_OK) {
      printf("\nDriver Registration failed. STATUS: %x", status);
      fflush(stdout);
   }


   _enable_interrupts();

   /*
   ** Infinite loop, waiting for events requiring action
   */
   for ( ; ; ) {
      switch ( prt_device.DEV_STATE ) {
         case USB_DEVICE_IDLE:
            break;
         case USB_DEVICE_ATTACHED:
            prt_device.DEV_STATE = USB_DEVICE_SET_INTERFACE_STARTED;
            status = _usb_hostdev_select_interface(prt_device.DEV_HANDLE,
               prt_device.INTF_HANDLE, (pointer)&prt_device.CLASS_INTF);
            prt_state = 0;
            break;
         case USB_DEVICE_SET_INTERFACE_STARTED:
            break;
         case USB_DEVICE_INTERFACED:
            /* All odd-numbered states are waiting for callback */
            if (prt_state & PRT_STATE_WAIT)
               break;

            /* Check for errors */
            if (prt_status) {
               printf("Error %s: %lx", prt_job, prt_status);
            } /* Endif */

            if (prt_state == PRT_STATE_GETID) {
               prt_job = "getting device ID";
               status = usb_printer_get_device_ID(
                  (pointer)&prt_device.CLASS_INTF,
                  usb_host_prt_ctrl_callback,
                  NULL,
                  USB_PRINTER_DEVICE_ID_SIZE,
                  prt_ID);
               printf("Get ID call status = %2.2X\n", status);
               fflush(stdout);
            } else if (prt_state == PRT_STATE_STARTJOB) {

               printf("\n***************************************************\n");
               printf("Printer detected:\n");

               /* First two bytes of ID are big endian length of ID */
               for (index = 2; index < prt_length; index++) {
                  printf("%c", prt_ID[index]);
                  if (prt_ID[index] == ';') {
                     printf("\n");
                  } /* Endif */
               } /* Endfor */
               printf("\nNow sending data to printer\n");
               fflush(stdout);

               prt_job = "sending UEL command";
               status = usb_printer_send_data(
                  (pointer)&prt_device.CLASS_INTF,
                  usb_host_prt_ctrl_callback,
                  NULL,
                  PRT_UEL_STRINGLEN,
                  (uchar_ptr)PRT_UEL_STRING);

            } else if (prt_state >= PRT_STATE_PRINT_MIN &&
               prt_state < PRT_STATE_ENDJOB)
            {
               prt_job = "sending data";
               for (index = 0; index < PRT_LINE_CHARS; index++) {
                  prt_buffer[index] = (prt_buffer[index] < PRT_MAX_CHAR) ?
                     prt_buffer[index]+1 : PRT_MIN_CHAR;
               } /* Endfor */
               status = usb_printer_send_data(
                  (pointer)&prt_device.CLASS_INTF,
                  usb_host_prt_ctrl_callback,
                  NULL,
                  sizeof(prt_data),
                  prt_data);
            } else if (prt_state == PRT_STATE_ENDJOB) {
               prt_job = "sending UEL command";
               status = usb_printer_send_data(
                  (pointer)&prt_device.CLASS_INTF,
                  usb_host_prt_ctrl_callback,
                  NULL,
                  PRT_UEL_STRINGLEN,
                  (uchar_ptr)PRT_UEL_STRING);
            } else if (prt_state == PRT_STATE_DONEJOB) {
               if (prt_status == USB_OK) {
                  printf("Data sent successfully!\n");
               } /* Endif */
            } /* Endif */
            prt_state++;
            break;
         case USB_DEVICE_DETACHED:
            prt_state = 0;
            prt_device.DEV_STATE = USB_DEVICE_IDLE;
            break;
         case USB_DEVICE_OTHER:
            break;
         default:
            break;
      } /* Endswitch */
   } /* Endfor */
} /* Endbody */



/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_prt_device_event
* Returned Value : None
* Comments       :
*     Called when printer device has been attached, detached, etc.
*END*--------------------------------------------------------------------*/

static void usb_host_prt_device_event
   (
      /* [IN] pointer to device instance */
      _usb_device_instance_handle      dev_handle,

      /* [IN] pointer to interface descriptor */
      _usb_interface_descriptor_handle intf_handle,

      /* [IN] code number for event causing callback */
      uint_32           event_code
   )
{ /* Body */
   INTERFACE_DESCRIPTOR_PTR   intf_ptr =
      (INTERFACE_DESCRIPTOR_PTR)intf_handle;

   switch (event_code) {
      case USB_CONFIG_EVENT:
         /* Drop through into attach, same processing */
      case USB_ATTACH_EVENT:
         /* Use only the interface having the desired protocol */
         if ( (intf_ptr->iInterface == 0) &&
            (intf_ptr->bInterfaceProtocol == USB_PROTOCOL_PRT_BIDIR) )
         {
            if (prt_device.DEV_STATE == USB_DEVICE_IDLE) {
               prt_device.DEV_HANDLE = dev_handle;
               prt_device.INTF_HANDLE = intf_handle;
               prt_device.DEV_STATE = USB_DEVICE_ATTACHED;
            } /* Endif */
         } /* Endif */
         break;
      case USB_INTF_EVENT:
         prt_device.DEV_STATE = USB_DEVICE_INTERFACED;
         break ;
      case USB_DETACH_EVENT:
         /* Use only the interface with desired protocol */
         if ( (intf_ptr->iInterface == 0) &&
            (intf_ptr->bInterfaceProtocol == USB_PROTOCOL_PRT_BIDIR) )
         {
            if (prt_device.DEV_STATE == USB_DEVICE_INTERFACED) {
               prt_device.DEV_HANDLE = NULL;
               prt_device.INTF_HANDLE = NULL;
               prt_device.DEV_STATE = USB_DEVICE_DETACHED;
            } /* Endif */
         } /* Endif */
         break;
      default:
         prt_device.DEV_STATE = USB_DEVICE_IDLE;
         break;
   } /* EndSwitch */
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_prt_ctrl_calback
* Returned Value : None
* Comments       :
*     called on completion of a control-pipe transaction.
*END*--------------------------------------------------------------------*/

static void usb_host_prt_ctrl_callback
   (
      /* [IN] pointer to pipe */
      _usb_pipe_handle  pipe_handle,

      /* [IN] user-defined parameter */
      pointer           user_parm,

      /* [IN] buffer address */
      uchar_ptr         buffer,

      /* [IN] length of data transferred */
      uint_32           buflen,

      /* [IN] status, hopefully USB_OK or USB_DONE */
      uint_32           status
   )
{ /* Body */

   prt_length = buflen;
   prt_status = status;
   prt_state++;

} /* Endbody */

/* EOF */

