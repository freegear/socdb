#ifndef _usbmfs_h_
#define _usbmfs_h_
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments: The file contains functions prototype, defines, structure 
***           definitions specific for USB MFS mass storage link driver.
*** 
***
**************************************************************************
**END*********************************************************/

/*----------------------------------------------------------------------*/
/*
**                          CONSTANT DEFINITIONS
*/

/*
** USB_MFS IOCTL calls
*/
#define USB_MFS_IOCTL_GET_NUM_SECTORS     (0x0102)
#define USB_MFS_IOCTL_GET_SECTOR_SIZE     (0x0103)
#define USB_MFS_IOCTL_GET_DRIVE_PARAMS    (0x0105)
#define USB_MFS_VENDOR_INFO               (0x0106)
#define USB_MFS_PRODUCT_ID                (0x0107)
#define USB_MFS_PRODUCT_REV               (0x0108)
#define USB_MFS_DEVICE_STOP               (0x0109)
#define USB_MFS_SET_BLOCK_MODE            (0x010A)

#define IO_DEV_TYPE_PHYS_USB_MFS          (0x0)

#define USB_MFS_VERY_LARGE_DRIVE           (3)

/*--------------------------------------------------------------------------*/
/*
**                    DATATYPE DECLARATIONS
*/

typedef struct usb_mfs_drive_info_struct
{
   uint_32  NUMBER_OF_HEADS; 
   uint_32  NUMBER_OF_TRACKS;
   uint_32  SECTORS_PER_TRACK;
} USB_MFS_DRIVE_INFO_STRUCT, _PTR_ USB_MFS_DRIVE_INFO_STRUCT_PTR;
    
/*----------------------------------------------------------------------*/
/*
**                    FUNCTION PROTOTYPES
*/

#ifdef __cplusplus
extern "C" {
#endif
uint_32 _io_usb_mfs_install(char_ptr, uint_8, pointer);
#ifdef __cplusplus
}
#endif
#endif
/* EOF */
