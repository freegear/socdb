/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains the host specific code for the demo
***
**************************************************************************
**END*********************************************************/

/**************************************************************************
Include the OS and BSP dependent files that define IO functions and
basic types. You may like to change these files for your board and RTOS 
**************************************************************************/


/**************************************************************************
Include the USB stack header files.
**************************************************************************/
#include "types.h"
#ifdef __USB_OTG__
   #include "otgapi.h"
   #include "devapi.h"
#else
   #include "hostapi.h"
#endif

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
   #include "bsp.h"
   #include "fio.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif
#include "stdlib.h"
#include "string.h"
#endif


/**************************************************************************
Local header files for this application
**************************************************************************/

#include "demo.h"
#include "demo_h.h"


/**************************************************************************
   Global variables
**************************************************************************/
volatile DEVICE_STRUCT        device = { 0 }; /* device struct  */
volatile APP_GLOBAL_STRUCT    app_test_struct;

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : app_process_host_resume
* Returned Value :
* Comments       :
*     Callback function to process the remote-wakeup/K-Attach event
*
*END*--------------------------------------------------------------------*/
void app_process_host_resume
   (
      _usb_host_handle  handle,
      uint_32           length
   )
{ /* Body */

   return;
   
} /* EndBody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_mass_device_event
* Returned Value : None
* Comments       :
*     called when a mass storage device has been attached, detached, etc.
*END*--------------------------------------------------------------------*/
void usb_host_mass_device_event
   (
      /* [IN] pointer to device instance */
      _usb_device_instance_handle      dev_handle,

      /* [IN] pointer to interface descriptor */
      _usb_interface_descriptor_handle intf_handle,

      /* [IN] code number for event causing callback */
      uint_32           event_code
   )
{
   INTERFACE_DESCRIPTOR_PTR   intf_ptr =
      (INTERFACE_DESCRIPTOR_PTR)intf_handle;

   switch (event_code) {
      case USB_CONFIG_EVENT:
         /* Drop through into attach, same processing */
      case USB_ATTACH_EVENT:
         if (device.STATE == USB_DEVICE_IDLE ||
            device.STATE == USB_DEVICE_DETACHED)
         {
            device.DEV_HANDLE = dev_handle;
            device.INTF_HANDLE = intf_handle;
            device.STATE = USB_DEVICE_ATTACHED;
            device.SUPPORTED = TRUE;
         }
         break;
      case USB_INTF_EVENT:
         device.STATE = USB_DEVICE_INTERFACED;
         break;
      case USB_DETACH_EVENT:
         device.DEV_HANDLE = NULL;
         device.INTF_HANDLE = NULL;
         device.STATE = USB_DEVICE_DETACHED;
         file_task_destroy_if_active();
         break;
      default:
         device.STATE = USB_DEVICE_IDLE;
         break;
   } /* EndSwitch */

} /* Enbbody */
/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_device_event
* Returned Value : None
* Comments       :
*     called when non storage device has been attached, detached, etc.
* Note that this example supports only storage devices and hence it sets
device.SUPPORTED to FALSE when a non storage device is attached.
*END*--------------------------------------------------------------------*/
void usb_host_device_event
   (
      /* [IN] pointer to device instance */
      _usb_device_instance_handle      dev_handle,

      /* [IN] pointer to interface descriptor */
      _usb_interface_descriptor_handle intf_handle,

      /* [IN] code number for event causing callback */
      uint_32           event_code
   )
{
   INTERFACE_DESCRIPTOR_PTR   intf_ptr =
      (INTERFACE_DESCRIPTOR_PTR)intf_handle;

   switch (event_code) {
      case USB_CONFIG_EVENT:
         /* Drop through into attach, same processing */
      case USB_ATTACH_EVENT:
         if (device.STATE == USB_DEVICE_IDLE ||
            device.STATE == USB_DEVICE_DETACHED)
         {
            device.DEV_HANDLE = dev_handle;
            device.INTF_HANDLE = intf_handle;
            device.SUPPORTED = FALSE;
            _usb_host_ch9_set_interface(device.DEV_HANDLE, 0, 0);
            device.STATE = USB_DEVICE_INTERFACED;
         } /* EndIf */
         break;
      case USB_INTF_EVENT:
         device.STATE = USB_DEVICE_INTERFACED;
         break;
      case USB_DETACH_EVENT:
         device.DEV_HANDLE = NULL;
         device.INTF_HANDLE = NULL;
         device.STATE = USB_DEVICE_DETACHED;
         break;
      default:
         device.STATE = USB_DEVICE_IDLE;
         break;
   } /* EndSwitch */

} /* Enbbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : host_main
* Returned Value :
* Comments       :
*     The Main function to handle HOST 
*END*--------------------------------------------------------------------*/
void host_main
   (
      _usb_host_handle  handle
   )
{
   uint_32                       state = 0;
   USB_STATUS                    status = USB_OK;
   char                          c;
   uint_32 last_state            = 0xFFFF;

   /*************************************************************************
   infinite loop checking for the state of device
   *************************************************************************/
     for ( ; ; )
     {
            switch ( device.STATE ) 
            {
                  case USB_DEVICE_IDLE:
                     break ;
                  case USB_DEVICE_ATTACHED:
                  /*************************************************************************
                  If an attach has occured and device is supported, 
                  select the interface, on the device now.
                  *************************************************************************/
                  if (device.SUPPORTED) 
                  {
                        status = _usb_hostdev_select_interface(device.DEV_HANDLE,
                           device.INTF_HANDLE, (pointer)&device.CLASS_INTF);
                        if(status == USB_OK)
                        {
                           device.STATE = USB_DEVICE_INTERFACED;\
                           /*********************************************************
                           The following is an OS dependent code. Use your OS
                           way of launching file system in a separate thread.
                           **********************************************************/
               
                           /* Launch the filesystem task */
                           file_task_launch(&device.CLASS_INTF);
                           file_task_block_until_destroyed();
                        }
                        else
                        {
                            printf("\nCould not select interface on the device");
                        }
                   }
                   /*********************************************************
                   For non supported device we just display a message
                   *********************************************************/
       
                   else
                   {
                        printf("Device not supported\n");
                        fflush(stdout);
                        device.STATE = USB_DEVICE_INTERFACED;
                   }

                  break ;
               case USB_DEVICE_INTERFACED:
                  break;
            }
   
         }/*end for */

} /* Endbody */

/* EOF */
