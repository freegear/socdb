#ifndef _demo_h_
#define _demo_h_ 1
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:  
***            
***
************************************************************************
**END*********************************************************/

#ifdef __cplusplus
extern "C" {
#endif
extern void usb_host_device_event(_usb_device_instance_handle, 
   _usb_interface_descriptor_handle, uint_32);
extern void app_process_host_resume(_usb_host_handle, uint_32);

#ifdef __cplusplus
}
#endif
#endif
/* EOF */
