#ifndef __modem_h__
#define __modem_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:
***   This file contains printer-application types and definitions.
***
**************************************************************************
**END*********************************************************/
#include "types.h"

#ifdef __USB_OTG__
#include "otgapi.h"
#include "devapi.h"
#else
#include "hostapi.h"
#endif

//#include "usb_cdc.h"

/***************************************
**
** Application-specific definitions
*/

#ifdef __USB_OS_MQX__
#define USBCOM_SYNC_VAR LWSEM_STRUCT
#define USBCOM_sync_init(a) _lwsem_create((LWSEM_STRUCT_PTR)a, 0);
#define USBCOM_sync_wait(a) _lwsem_wait((LWSEM_STRUCT_PTR)a)
#define USBCOM_sync_post(a) _lwsem_post((LWSEM_STRUCT_PTR)a)
#define USBCOM_sync_destroy(a) _lwsem_destroy((LWSEM_STRUCT_PTR)a);
#else
#define USBCOM_SYNC_VAR uint_32
#define USBCOM_sync_init(a) *(a) = FALSE
#define USBCOM_sync_wait(a) while (!*(a))
#define USBCOM_sync_post(a) *(a) = TRUE;
#define USBCOM_sync_destroy(a)
#endif


/* Used to initialize USB controller */
#define MAX_FRAME_SIZE           1024
#define HOST_CONTROLLER_NUMBER      0


#define  USB_DEVICE_IDLE                   (0)
#define  USB_DEVICE_ATTACHED               (1)
#define  USB_DEVICE_CONFIGURED             (2)
#define  USB_DEVICE_SET_INTERFACE_STARTED  (3)
#define  USB_DEVICE_INTERFACED             (4)
#define  USB_DEVICE_DETACHED               (5)
#define  USB_DEVICE_OTHER                  (6)


/*
** Following structs contain all states and pointers
** used by the application to control/operate devices.
*/

typedef struct device_struct {
   USBCOM_SYNC_VAR					Ctrl_Sync;
   USBCOM_SYNC_VAR					Data_Sync;
   uint_32                          DEV_STATE;  /* Attach/detach state */
   _usb_device_instance_handle      DEV_HANDLE;
   _usb_interface_descriptor_handle INTF_HANDLE_COMM; /* Comm Class INTF */
   _usb_interface_descriptor_handle INTF_HANDLE_DATA; /* Data Class INTF */
   CLASS_CALL_STRUCT                CLASS_INTF_COMM; /* Class-specific info */
   CLASS_CALL_STRUCT                CLASS_INTF_DATA; /* Class-specific info */
} DEVICE_STRUCT,  _PTR_ DEVICE_STRUCT_PTR;


/* Alphabetical list of Function Prototypes */

#ifdef __cplusplus
extern "C" {
#endif

#if 0
void otg_service(_usb_otg_handle, uint_32);
#endif

void usb_host_acm_device_event(_usb_device_instance_handle,
   _usb_interface_descriptor_handle, uint_32);

//CDC_CALLBACK_NOTIF_FN usb_host_acm_notif_callback(_usb_pipe_handle  pipe_handle,
void usb_host_acm_notif_callback(uint_32, pointer, uchar_ptr, uint_32, uint_32);

/*
 * Routines for ACM Requsts
 */
USB_STATUS usb_host_acm_set_line_coding(LINE_CODING_STRUCT_PTR);
USB_STATUS usb_host_acm_get_line_coding(LINE_CODING_STRUCT_PTR);
USB_STATUS usb_host_acm_set_control_line_state(uint_16  CtrlSignal);
USB_STATUS usb_host_acm_send_encapsulated_command(uchar_ptr, uint_16);
USB_STATUS usb_host_acm_get_encapsulated_command(uchar_ptr, uint_16);
USB_STATUS usb_host_acm_set_comm_feature(uint_16, uchar_ptr, uint_16);
USB_STATUS usb_host_acm_get_comm_feature(uint_16, uchar_ptr, uint_16);
USB_STATUS usb_host_acm_clear_comm_feature(uint_16);
USB_STATUS usb_host_acm_send_break(uint_16);

/*
 * Routines for Data interface
 */
USB_STATUS usb_host_acm_send_data(uchar_ptr, uint_32);
USB_STATUS usb_host_acm_recv_data(uchar_ptr, uint_32); 

#ifdef __cplusplus
}
#endif


#endif

/* EOF */





