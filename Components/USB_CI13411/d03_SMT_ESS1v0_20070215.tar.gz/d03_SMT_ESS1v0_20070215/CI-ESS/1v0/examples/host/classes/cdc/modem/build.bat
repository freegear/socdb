set MQX_CONFIG=C:\Zhou\usb_software_stack3.00\build\config.mk
set PATH=C:\ARC\mktools\mkbin;%PATH%
make
