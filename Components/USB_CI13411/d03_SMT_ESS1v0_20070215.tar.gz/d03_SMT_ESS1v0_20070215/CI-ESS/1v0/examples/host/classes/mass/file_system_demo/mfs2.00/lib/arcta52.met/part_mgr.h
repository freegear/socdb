#ifndef __part_mgr_h__
#define __part_mgr_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments: This file contains internal data structures and constants
***           used to manage partitions.
***                     
***
**************************************************************************
**END*********************************************************/


#ifndef IO_IOCTL_GET_BLOCK_SIZE
#define IO_IOCTL_GET_BLOCK_SIZE  999
#endif


/*
**  Defines constant for partiton
*/
#define  PMGR_VALID_STATE              1
#define  PMGR_INVALID_STATE            0

#define  PMGR_PARTITION_TABLE_OFFSET   0x01BE
#define  PMGR_MAX_PARTITIONS           0x04
#define  PMGR_ENTRY_SIZE               0x10
#define  PMGR_DEFAULT_SECTOR_SIZE      512

/* The 2 extra bytes store a validation signature */
#define  PMGR_PART_TABLE_SIZE          PMGR_ENTRY_SIZE * PMGR_MAX_PARTITIONS + 2


/*
** Partition types 
*/
#define  PMGR_PARTITION_NOT_USED        0x00
#define  PMGR_PARTITION_FAT_12_BIT      0x01
#define  PMGR_PARTITION_FAT_16_BIT      0x04
#define  PMGR_PARTITION_HUGE            0x06
#define  PMGR_PARTITION_FAT32           0x0B
#define  PMGR_PARTITION_FAT32_LBA       0x0C
#define  PMGR_PARTITION_HUGE_LBA        0x0E

/*
** Error Codes
*/ 
#define PMGR_INVALID_PARTITION          0x20156
#define PMGR_INSUF_MEMORY               0x20157                 

/*
** IOCTL codes for internal use
*/
#define IO_IOCTL_DEV_LOCK                    0x2015
#define IO_IOCTL_DEV_UNLOCK                  0x2016
#define IO_IOCTL_VAL_PART                    0x2017

/*
** IOCTL codes for application use 
*/
#define IO_IOCTL_SET_PARTITION               0x2018
#define IO_IOCTL_GET_PARTITION               0x2019
#define IO_IOCTL_CLEAR_PARTITION             0x2020


/* Structure of a partition entry on the disk */
typedef struct pmgr_part_entry_struct
{
   /* Active flag (0 = not bootable, 0x80 = bootable) */
   uchar     ACTIVE_FLAG;

   /* Starting head */
   uchar     START_HEAD;

   /* Starting cylinder/sector */
   uchar     START_CYLINDER[2];

   /* Partition type (0 not used, 1 FAT 12 bit, 4 FAT 16 bit, 5 extended,
   **                 6 huge - DOS 4.0+, 0x0B FAT32, 0x0C FAT32 LBA, 
   **                 0x0E FAT16 LBA)
   */
   uchar     TYPE;

   /* Ending head */
   uchar     ENDING_HEAD;

   /* Ending cylinder/sector */
   uchar     ENDING_CYLINDER[2];

   /* Starting sector for partition, relative to beginning of disk */
   uchar     START_SECTOR[4];

   /* Partition length in sectors */
   uchar     LENGTH[4];

} PMGR_PART_ENTRY_STRUCT, _PTR_ PMGR_PART_ENTRY_STRUCT_PTR;


typedef struct pmgr_part_info_struct
{
   /* Partition slot (1 to 4) */
   uchar     SLOT;
   
   /* Heads per Cylinder */
   uchar     HEADS;
   
   /* Sectors per head */
   uchar     SECTORS;
   
   /* 
   ** Partition type (0 not used, 1 FAT 12 bit, 4 FAT 16 bit, 5 extended,
   ** 6 huge - DOS 4.0+, other = unknown OS)
   */
   uchar     TYPE;

   /* Cylinders on the device */   
   uint_16   CYLINDERS;

   uint_16   RESERVED;
           
   /* Starting sector for partition, relative to beginning of disk */
   uint_32   START_SECTOR;

   /* Partition length in sectors */
   uint_32   LENGTH;

} PMGR_PART_INFO_STRUCT, _PTR_ PMGR_PART_INFO_STRUCT_PTR;

  
typedef struct part_mgr_struct
{
   FILE_PTR                         DEV_HANDLE;
   LWSEM_STRUCT                     SEM;
   uint_32                          ACTIVE_PART;   
   uint_32                          PART_START_SECTOR[4];
   uchar                            VALID[4];
   uint_32                          DEV_SECTOR_SIZE;
   uint_32                          STATE;
   boolean                          BLOCK_MODE;
   char_ptr                         BUFFER;
} PART_MGR_STRUCT, _PTR_ PART_MGR_STRUCT_PTR;


/* Macros for byte exchange between disk and host */
#if (PSP_MEMORY_ADDRESSING_CAPABILITY == 8)
#define pmgr_htodl(p,x) \
                   ((p)[3] = ((x) >> 24) , \
                    (p)[2] = ((x) >> 16) , \
                    (p)[1] = ((x) >>  8) , \
                    (p)[0] = ((x)      )  \
                    )

#define pmgr_htods(p,x) \
                   ((p)[1] = ((x) >>  8) , \
                    (p)[0] = ((x)      )  \
                   )

#define pmgr_htodc(p,x) \
                   ((p)[0] = ((x)      ) , \
                    )

#define pmgr_dtohl(p)   \
                   ((((uint_32)(p)[3] ) << 24) | \
                    (((uint_32)(p)[2] ) << 16) | \
                    (((uint_32)(p)[1] ) <<  8) | \
                    (((uint_32)(p)[0] )      ))

#define pmgr_dtohs(p)  \
                  ((((uint_16)(p)[1] ) <<  8) | \
                   (((uint_16)(p)[0] )      ))

#define pmgr_dtohc(p)   ((((  uchar)(p)[0] )      ))
#else
#define pmgr_htodl(p,x) \
                   ((p)[3] = ((x) >> 24) & 0xFF, \
                    (p)[2] = ((x) >> 16) & 0xFF, \
                    (p)[1] = ((x) >>  8) & 0xFF, \
                    (p)[0] = ((x)      ) & 0xFF \
                    )

#define pmgr_htods(p,x) \
                   ((p)[1] = ((x) >>  8) & 0xFF, \
                    (p)[0] = ((x)      ) & 0xFF \
                   )

#define pmgr_htodc(p,x) \
                   ((p)[0] = ((x)      ) & 0xFF, \
                    )

#define pmgr_dtohl(p)   \
                   ((((uint_32)(p)[3] & 0xFF) << 24) | \
                    (((uint_32)(p)[2] & 0xFF) << 16) | \
                    (((uint_32)(p)[1] & 0xFF) <<  8) | \
                    (((uint_32)(p)[0] & 0xFF)      ))

#define pmgr_dtohs(p)  \
                  ((((uint_16)(p)[1] & 0xFF) <<  8) | \
                   (((uint_16)(p)[0] & 0xFF)      ))

#define pmgr_dtohc(p)   ((((  uchar)(p)[0] & 0xFF)      ))
#endif



#ifdef __cplusplus
extern "C" {
#endif

extern int_32
   _io_part_mgr_install(
      FILE_PTR                      dev_fd,
      char_ptr                      identifier,
      uint_32                       sector_size);

extern int_32
   _io_part_mgr_uninstall(
      char_ptr                      identifier);

   
extern int_32 
   _io_part_mgr_open(
      FILE_PTR                      fd_ptr,
      char_ptr                      open_name_ptr,
      char_ptr                      flags_str);

extern int_32 
   _io_part_mgr_close(
      FILE_PTR                      fd_ptr);
      
extern int_32 
   _io_part_mgr_read( 
      FILE_PTR                      file_ptr,
      char_ptr                      data_ptr,
      int_32                        num);

extern int_32 
   _io_part_mgr_write(
      FILE_PTR                      file_ptr,
      char_ptr                      data_ptr,
      int_32                        num);


extern int_32 
   _io_part_mgr_ioctl( 
      FILE_PTR                      file_ptr,
      uint_32                       cmd,
      uint_32_ptr                   param_ptr);
   

extern int_32 
   _pmgr_get_part_info(
      PART_MGR_STRUCT_PTR                 part_mgr_ptr,
      PMGR_PART_INFO_STRUCT_PTR           entry_ptr);
   
extern int_32
   _pmgr_set_part_info(
      PART_MGR_STRUCT_PTR                 part_mgr_ptr,
      PMGR_PART_INFO_STRUCT_PTR           entry,
      uint_32                             opcode);  

extern void 
   _pmgr_disk_to_host(
      PMGR_PART_ENTRY_STRUCT_PTR          disk_entry,
      PMGR_PART_INFO_STRUCT_PTR           part_entry);

extern void
   _pmgr_host_to_disk(
      PMGR_PART_INFO_STRUCT_PTR          part_entry,
      PMGR_PART_ENTRY_STRUCT_PTR           disk_entry);

extern int_32 
   _io_part_mgr_uninstall_internal(
      IO_DEVICE_STRUCT_PTR        dev_ptr);


#ifdef __cplusplus
}
#endif

#endif
/* EOF */
