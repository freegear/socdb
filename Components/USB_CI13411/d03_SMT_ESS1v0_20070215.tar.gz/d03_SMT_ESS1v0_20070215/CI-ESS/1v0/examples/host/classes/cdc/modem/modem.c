/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains an example driver for USB ACM communication class
***   device.
***
**************************************************************************
**END*********************************************************/

#include "usb_cdc.h"
#include "modem.h"

#ifdef __USB_OS_MQX__
#include "bsp.h"
#include "mqx_arc.h"
#include "fio.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif
#include "stdlib.h"
#endif


/***************************************
**
** Globals
*/

/* Table of driver capabilities this application wants to use */
static  USB_HOST_DRIVER_INFO DriverInfoTable[] =
{
   {
      {0x00,0x00},                  /* Vendor ID per USB-IF             */
      {0x00,0x00},                  /* Product ID per manufacturer      */
      USB_CLASS_COMMUNICATION,      /* Class code                       */
      USB_SUBCLASS_COM_ABSTRACT,    /* Sub-Class code                   */
      USB_PROTOCOL_COM_V25,         /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_acm_device_event     /* Application call back function   */
   },
   {
      {0x00,0x00},                  /* Vendor ID per USB-IF             */
      {0x00,0x00},                  /* Product ID per manufacturer      */
      USB_CLASS_DATA,               /* Class code                       */
      0,                            /* Sub-Class code                   */
      0,                            /* Protocol                         */
      0,                            /* Reserved                         */
      usb_host_acm_device_event     /* Application call back function   */
   },

   {
      {0x00,0x00},                  /* All-zero entry terminates        */
      {0x00,0x00},                  /* driver info list.                */
      0,
      0,
      0,
      0,
      NULL
   }
};

volatile DEVICE_STRUCT  acm_device = { 0 };

volatile uint_16 wUARTState = 0xff;
volatile uint_16 wNetConnectionStatue = 0;
volatile boolean bEncapsulatedResponseAvailable = FALSE;

LINE_CODING_STRUCT   gLineCoding;

#define     DATA_BUFFER_LENGTH   2048
#define     CMD_BUFFER_LENGTH    128
uchar       cmdBuffer[CMD_BUFFER_LENGTH];
uchar_ptr   gDataBuf = NULL; 
uchar       gReturnOk[6] = {0x0d, 0x0a, 0x4f, 0x4b, 0x0d, 0x0a};


/* global handle to access host routines */
//_usb_host_handle     host_handle;

#ifdef __USB_OS_MQX__
#define MAIN_TASK          (10)
extern void Main_Task(uint_32 param);
TASK_TEMPLATE_STRUCT  MQX_template_list[] =
{
   { MAIN_TASK,      Main_Task,      3000L,  7L, "Main",      MQX_AUTO_START_TASK},
   { 0L,             0L,             0L,     0L, 0L,          0L }
};
#endif

static USB_STATUS usb_host_acm_check_device(void);
static USB_STATUS usb_host_acm_init_device(void);
static USB_STATUS usb_host_acm_dial_up(LINE_CODING_STRUCT_PTR);
static USB_STATUS usb_host_acm_hang_up(LINE_CODING_STRUCT_PTR pgLineCoding);
static void usb_host_acm_cleanup(void);
static void usb_host_acm_ctrl_callback(uint_32, pointer, uint_32, uint_32);          

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : main (Main_Task if using MQX)
* Returned Value : none
* Comments       :
*     Execution starts here
*
*END*--------------------------------------------------------------------*/

#ifdef __USB_OS_MQX__
void Main_Task ( uint_32 param )
#else
void main (void)
#endif

{ /* Body */
   USB_STATUS           status = USB_OK;

_usb_host_handle     host_handle;

   
   uint_32              uiTmp;

   /* _usb_otg_init needs to be done with interrupts disabled */
   _disable_interrupts();

#ifdef __USB_OS_MQX__
   _int_install_unexpected_isr();
   _usb_driver_install(0, &_bsp_usb_callback_table);
#endif


         /*
         ** It means that we are going to act like host, so we initialize the
         ** host stack. This call will allow USB system to allocate memory for
         ** data structures, it uses later (e.g pipes etc.).
         */
         printf("Host init started\n");
         status = _usb_host_init
            (HOST_CONTROLLER_NUMBER,   /* Use value in header file */
             MAX_FRAME_SIZE,            /* Frame size per USB spec  */
             &host_handle);             /* Returned pointer */

         if (status != USB_OK) {
            printf("\nUSB Host Initialization failed. STATUS: %x", status);
            fflush(stdout);
            return;
         } /* Endif */
         printf("Host initdone \n");

         /*
         ** since we are going to act as the host driver, register the driver
         ** information for wanted class/subclass/protocols
         */
         status = _usb_host_driver_info_register
            (host_handle,
             DriverInfoTable);
         if (status != USB_OK) {
            printf("\nDriver Registration failed. STATUS: %x", status);
            fflush(stdout);
            return;
         }
         
   _enable_interrupts();

   /*
   ** Infinite loop, waiting for events requiring action
   */
   for ( ; ; ) {
         switch ( acm_device.DEV_STATE ) {
         case USB_DEVICE_IDLE:
            break;
         case USB_DEVICE_ATTACHED:
            if (!acm_device.DEV_HANDLE || 
                !acm_device.INTF_HANDLE_COMM || 
                !acm_device.INTF_HANDLE_DATA) {
               printf("Device is not a USB communication class device!\n");
               fflush(stdout);
               return;
            }
             
            acm_device.DEV_STATE = USB_DEVICE_SET_INTERFACE_STARTED;
            status = _usb_hostdev_select_interface(acm_device.DEV_HANDLE,
                  acm_device.INTF_HANDLE_COMM, (pointer)&acm_device.CLASS_INTF_COMM);
            if (status != USB_OK) {
               fflush(stdout); 
               printf("Select COMM interface failed!\n");
               fflush(stdout);
            } else { 
               status = _usb_hostdev_select_interface(acm_device.DEV_HANDLE,
                  acm_device.INTF_HANDLE_DATA, (pointer)&acm_device.CLASS_INTF_DATA);
               if (status != USB_OK) {
                  fflush(stdout); 
                  printf("Select DATA interface failed!\n");
                  fflush(stdout); 
               }
               status = usb_cdc_set_notif_callback((CLASS_CALL_STRUCT_PTR)&acm_device.CLASS_INTF_COMM, 
                                          (CDC_CALLBACK_NOTIF_FN)usb_host_acm_notif_callback);         
            } 
            break;
         case USB_DEVICE_SET_INTERFACE_STARTED:
            break;
         case USB_DEVICE_INTERFACED:
            status = usb_host_acm_check_device();
            if (status != USB_OK) { /* Body */
               printf("Device does not support using data interface to do call management.\n");
               fflush(stdout);
            } else {    
               usb_host_acm_init_device();
               printf("Device initialized.\n");
               fflush(stdout);
               htou32(gLineCoding.DTE_RATE, 115200);
               gLineCoding.CHAR_FORMAT[0] = 0x00;  // 1 stop bit
               gLineCoding.PARITY_TYPE[0] = 0x00;  // bParityType = None
               gLineCoding.DATA_BITS[0] = 0x08;    // bDataBits = 8;
               printf("Dialing...\n");
               fflush(stdout);
               usb_host_acm_dial_up(&gLineCoding);
               for (uiTmp=0; uiTmp<0x1000000; uiTmp++);
               printf("Hang up...\n");
               fflush(stdout);
               usb_host_acm_hang_up(&gLineCoding);
            } /* Endbody */
            acm_device.DEV_STATE = USB_DEVICE_OTHER;
            break;
         case USB_DEVICE_DETACHED:
            printf("Device detached.\n");
            fflush(stdout);
            acm_device.DEV_STATE = USB_DEVICE_IDLE;
            break;
         case USB_DEVICE_OTHER:
            break;
         default:
            printf("Unknown Printer Device State = %d\n", acm_device.DEV_STATE);
            fflush(stdout);
            break;
      } /* Endswitch */
   } /* Endfor */
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_device_event
* Returned Value : None
* Comments       :
*     Called when CDC device has been attached, detached, etc.
*END*--------------------------------------------------------------------*/

static void usb_host_acm_device_event
   (
      /* [IN] pointer to device instance */
      _usb_device_instance_handle      dev_handle,

      /* [IN] pointer to interface descriptor */
      _usb_interface_descriptor_handle intf_handle,

      /* [IN] code number for event causing callback */
      uint_32           event_code
   )
{ /* Body */
   INTERFACE_DESCRIPTOR_PTR   intf_ptr =
      (INTERFACE_DESCRIPTOR_PTR)intf_handle;

   fflush(stdout);
   switch (event_code) {
      case USB_CONFIG_EVENT:
         /* Drop through into attach, same processing */
      case USB_ATTACH_EVENT:
         /* There are two ATTACH event for device with two interfaces */
         if (acm_device.DEV_STATE == USB_DEVICE_IDLE) {
            acm_device.DEV_HANDLE = dev_handle;
            if (intf_ptr->bInterfaceClass == USB_CLASS_COMMUNICATION) { 
               acm_device.INTF_HANDLE_COMM = intf_handle;
               printf("COMM interface attached\n");
               fflush(stdout);
            } else if (intf_ptr->bInterfaceClass == USB_CLASS_DATA) {
               acm_device.INTF_HANDLE_DATA = intf_handle;
               printf("DATA interface attached\n");
               fflush(stdout);
            }
               
            if (acm_device.INTF_HANDLE_COMM && acm_device.INTF_HANDLE_DATA)
               acm_device.DEV_STATE = USB_DEVICE_ATTACHED;
         } else {
            printf("CDC device already attached\n");
            fflush(stdout);
         }
         break;
      case USB_INTF_EVENT:
         /*fflush(stdout);
         printf("----- Intf Event -----\n");
         printf("State = %d", acm_device.DEV_STATE);
         printf("  Class = %d", intf_ptr->bInterfaceClass);
         printf("  SubClass = %d", intf_ptr->bInterfaceSubClass);
         printf("  Protocol = %d\n", intf_ptr->bInterfaceProtocol);
         fflush(stdout); */

         if (acm_device.DEV_STATE != USB_DEVICE_INTERFACED)
            acm_device.DEV_STATE = USB_DEVICE_INTERFACED;                    
         
         break ;
      case USB_DETACH_EVENT:
         /* Use only the interface with desired protocol */
         /*fflush(stdout);
         printf("----- Detach Event -----\n");
         printf("State = %d", acm_device.DEV_STATE);
         printf("  Class = %d", intf_ptr->bInterfaceClass);
         printf("  SubClass = %d", intf_ptr->bInterfaceSubClass);
         printf("  Protocol = %d\n", intf_ptr->bInterfaceProtocol);
         fflush(stdout); */
         /*if (acm_device.DEV_STATE == USB_DEVICE_INTERFACED) {
            acm_device.DEV_HANDLE = NULL;
            acm_device.INTF_HANDLE_COMM = NULL;
            acm_device.DEV_STATE = USB_DEVICE_DETACHED;
         } else {
            printf("CDC Device Not Attached\n");
            fflush(stdout);
         } */
         if (acm_device.DEV_STATE != USB_DEVICE_DETACHED) {
            acm_device.DEV_HANDLE = NULL;
            acm_device.INTF_HANDLE_COMM = NULL;
            acm_device.DEV_STATE = USB_DEVICE_DETACHED;
         }
         break;
      default:
         printf("CDC Device state = %d??\n", acm_device.DEV_STATE);
         fflush(stdout);
         acm_device.DEV_STATE = USB_DEVICE_IDLE;
         break;
   } /* EndSwitch */
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_notif_callback
* Returned Value : None
* Comments       :
*     Called when data is received on the nofif interrupt pipe
*END*--------------------------------------------------------------------*/

//CDC_CALLBACK_NOTIF_FN usb_host_acm_notif_callback
void usb_host_acm_notif_callback
   (
      /* [IN] pointer to pipe */
      uint_32           Callbak_param,

      /* [IN] user-defined parameter */
      pointer           ifhandle,

      /* [IN] buffer address */
      uchar_ptr         buffer,

      /* [IN] length of data transferred */
      uint_32           buflen,

      /* [IN] status, hopefully USB_OK or USB_DONE */
      uint_32           status
   )
{ /* Body */
   USB_STATUS           error = USB_OK;
   CDC_NOTIF_PTR        pNotif;
   uchar_ptr            pData;
   uint_16              wLength;
   
   //fflush(stdout);
   //printf("Notif received. State = %d\n", acm_device.DEV_STATE);
   //fflush(stdout);
   
   pNotif = (CDC_NOTIF_PTR)buffer;
   pData = buffer+8;
   wLength = utoh16(pNotif->wLength);
   if (pNotif->bNotification == CDC_NOTIF_SERIAL_STATE) {
      if (buflen >= (uint_32)(sizeof(CDC_NOTIF) + wLength))
         wUARTState = utoh16(pData);
   } else if (pNotif->bNotification == CDC_NOTIF_NETWORK_CONNECTION) {
      wNetConnectionStatue = utoh16(pNotif->wValue);
   } else if (pNotif->bNotification == CDC_NOTIF_RESPONSE_AVAILABLE) {
         bEncapsulatedResponseAvailable = TRUE;
   }
   
   /* Keep one extra reading for NOTIF interrupt pipe */
   error = usb_cdc_recv_notif((CLASS_CALL_STRUCT_PTR)&acm_device.CLASS_INTF_COMM);
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_init_device
* Returned Value : USB_OK if success
* Comments       :
*     Called to initialize the acm comm device
*END*--------------------------------------------------------------------*/
static USB_STATUS usb_host_acm_init_device(void)
{
   USB_STATUS           error;
   LINE_CODING_STRUCT   LineCoding;
   uint_16              CtrlSignal;
   CDC_COMMAND          cdc_cmd;
   
   if (!gDataBuf)
      gDataBuf = USB_memalloc(DATA_BUFFER_LENGTH);
      if (!gDataBuf) {
         printf("USB allocate memory failed\n");
      return USBERR_ALLOC;
   } /* Endbody */

   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   USBCOM_sync_init(&acm_device.Data_Sync);
   
   cdc_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&acm_device.CLASS_INTF_COMM;
   cdc_cmd.CALLBACK_FN = (CDC_CALLBACK_USER_FN)usb_host_acm_ctrl_callback;
   cdc_cmd.CALLBACK_PARAM = 0;
   
   //#ifndef __USB_OS_MQX__
   //USBCOM_sync_init(&acm_device.Ctrl_Sync);
   //#endif
   error = usb_acm_get_line_coding(&cdc_cmd, (uchar_ptr)(&LineCoding));
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
     
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   CtrlSignal = 0x0000;
   error = usb_acm_set_control_line_state(&cdc_cmd, CtrlSignal); 
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Ctrl_Sync);
         
   ////usb_cdc_recv_notif((CLASS_CALL_STRUCT_PTR)&acm_device.CLASS_INTF_COMM);
         
   return error;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_dial_up
* Returned Value : USB_OK if success
* Comments       :
*     Called to dial a remote system through a phone line
*END*--------------------------------------------------------------------*/

#define PHONE_NUMBER_SIZE  36
static USB_STATUS usb_host_acm_dial_up(LINE_CODING_STRUCT_PTR pgLineCoding)
{
   USB_STATUS           error;
   //uint_16              wSerialState;
   uint_16              wTmp;
   LINE_CODING_STRUCT   LineCoding;
   CDC_COMMAND          cdc_cmd;
   uchar                ch, chBuf[PHONE_NUMBER_SIZE+2]; 
   
   printf("\nPlease input the phone number to dial:(for example: 98242022)\n");
   for (wTmp=0; wTmp<PHONE_NUMBER_SIZE; wTmp++) {                
      ch = getchar();
      if (ch == '\n' || ch == '\r') { /* Body */
         chBuf[wTmp] = '\r';
         chBuf[++wTmp] = 0;
         break;
      } /* Endbody */
      chBuf[wTmp] = ch;
   }
   fflush(stdin);
   
   cdc_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&acm_device.CLASS_INTF_COMM;
   cdc_cmd.CALLBACK_FN = (CDC_CALLBACK_USER_FN)usb_host_acm_ctrl_callback;
   cdc_cmd.CALLBACK_PARAM = 0;
   
   /* Waite for serial state ready
    */  
 /*  do { 
      wSerialState = wUARTState;
      wSerialState = wSerialState & ~(bRxCarrier | bTxCarrier);
   } while (wSerialState); */
   
   /* Set Control line state:
    * Deactivates carrrier; indicates DTE is present.
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   wTmp = 0x0001;
   error = usb_acm_set_control_line_state(&cdc_cmd, wTmp);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Read line coding twice
    */
   for (wTmp=0; wTmp<2; wTmp++) {    
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Ctrl_Sync);
      #endif
      error = usb_acm_get_line_coding(&cdc_cmd, (uchar_ptr)(&LineCoding));
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Ctrl_Sync);
   }

   /* Set line coding
    */    
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_set_line_coding(&cdc_cmd, (uchar_ptr)pgLineCoding);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Read line coding again
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_get_line_coding(&cdc_cmd, (uchar_ptr)(&LineCoding));
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Set Control line state:
    * Deactivates carrrier; indicates DTE is present.
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   wTmp = 0x0001;
   error = usb_acm_set_control_line_state(&cdc_cmd, wTmp);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Set line coding
    */    
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_set_line_coding(&cdc_cmd, (uchar_ptr)pgLineCoding);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);

   /* Read line coding again
    */
   for (wTmp=0; wTmp<3; wTmp++) { /* Body */   
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Ctrl_Sync);
      #endif
      error = usb_acm_get_line_coding(&cdc_cmd, (uchar_ptr)(&LineCoding));
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Ctrl_Sync);
   }
   
   /* Set line coding again
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_set_line_coding(&cdc_cmd, (uchar_ptr)pgLineCoding);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Read line coding again
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_get_line_coding(&cdc_cmd, (uchar_ptr)(&LineCoding));
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);

   /* Set Control line state:
    * Deactivates carrrier; indicates DTE is present.
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   wTmp = 0x0001;
   error = usb_acm_set_control_line_state(&cdc_cmd, wTmp);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Set line coding again
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_set_line_coding(&cdc_cmd, (uchar_ptr)pgLineCoding);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Read line coding again
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_get_line_coding(&cdc_cmd, (uchar_ptr)(&LineCoding));
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
   
   /* Set Control line state:
    * Deactivates carrrier; indicates DTE is present.
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   wTmp = 0x0001;
   error = usb_acm_set_control_line_state(&cdc_cmd, wTmp);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
   
   /* Reset modem
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "ATZ\r");
   error = usb_host_acm_send_data(cmdBuffer, 4);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
 
   do { 
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Data_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   } while (strncmp((char *)gDataBuf, (char *)gReturnOk, sizeof(gReturnOk)) != 0);
   //strncmp((char *)gDataBuf, (char *)gReturnOk, sizeof(gReturnOk));
   
   /*
    */
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "AT&F+IBC=0,0,0,,,,,0;+PCW= ;+P");
   error = usb_host_acm_send_data(cmdBuffer, 30);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
         
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "MH=1\r");
   error = usb_host_acm_send_data(cmdBuffer, 5);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
 
   do { 
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Data_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   } while (strncmp((char *)gDataBuf, (char *)gReturnOk, sizeof(gReturnOk)) != 0);
   
   /* Disable echo of characters to the screen
    */
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "ATE0V1S0=0&C1&D2+MR=2;+DR=1;+E");
   error = usb_host_acm_send_data(cmdBuffer, 30);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
         
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "R=1;W2\r");
   error = usb_host_acm_send_data(cmdBuffer, 7);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
 
   do { 
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Data_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   } while (strncmp((char *)gDataBuf, (char *)gReturnOk, sizeof(gReturnOk)) != 0);
   
   /* Set value in modem 'S' register
    */
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "ATS7=60S30=0L1M1+ES=3,0,2;+DS=");
   error = usb_host_acm_send_data(cmdBuffer, 30);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
         
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "3;+IFC=2,2;BX4\r");
   error = usb_host_acm_send_data(cmdBuffer, 15);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
 
   do { 
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Data_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   } while (strncmp((char *)gDataBuf, (char *)gReturnOk, sizeof(gReturnOk)) != 0);
   
   /* Dial a telephone number
    */
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   //strcpy((char *)cmdBuffer, "ATDT98242022\r");
   sprintf(cmdBuffer, "ATDT%s", chBuf);
   error = usb_host_acm_send_data(cmdBuffer, 13);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
          
   for (wTmp=0; wTmp<5; wTmp++) { /* Body */ 
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Ctrl_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   }
   
   /* Read line coding     
    */
   for (wTmp=0; wTmp<6; wTmp++) {    
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Ctrl_Sync);
      #endif
      error = usb_acm_get_line_coding(&cdc_cmd, (uchar_ptr)(&LineCoding));
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Ctrl_Sync);
   }

   /* Set line coding
    */    
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_set_line_coding(&cdc_cmd, (uchar_ptr)pgLineCoding);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Set Control line state:
    * Deactivates carrrier; indicates DTE is present.
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   wTmp = 0x0001;
   error = usb_acm_set_control_line_state(&cdc_cmd, wTmp);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Set line coding
    */    
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_set_line_coding(&cdc_cmd, (uchar_ptr)pgLineCoding);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Read line coding     
    */    
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_get_line_coding(&cdc_cmd, (uchar_ptr)(&LineCoding));
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
   
   printf("\nDialup is done\n");
   fflush(stdout);

    
   return error;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_hang_up
* Returned Value : USB_OK if success
* Comments       :
*     Called to hang up the phone line
*END*--------------------------------------------------------------------*/

static USB_STATUS usb_host_acm_hang_up(LINE_CODING_STRUCT_PTR pgLineCoding)
{
   USB_STATUS           error;
   uint_16              wTmp;
   LINE_CODING_STRUCT   LineCoding;
   CDC_COMMAND          cdc_cmd;
   
   cdc_cmd.CLASS_PTR = (CLASS_CALL_STRUCT_PTR)&acm_device.CLASS_INTF_COMM;
   cdc_cmd.CALLBACK_FN = (CDC_CALLBACK_USER_FN)usb_host_acm_ctrl_callback;
   cdc_cmd.CALLBACK_PARAM = 0;

   /* Set Control line state:
    * Deactivates carrrier; indicates DTE is not present.
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   wTmp = 0x0000;
   error = usb_acm_set_control_line_state(&cdc_cmd, wTmp);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Set Control line state:
    * Deactivates carrrier; indicates DTE is present.
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   wTmp = 0x0001;
   error = usb_acm_set_control_line_state(&cdc_cmd, wTmp);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Hang up the phone
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "ATH\r");
   error = usb_host_acm_send_data(cmdBuffer, 4);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
 
   //do { 
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Data_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   //} while (strncmp((char *)gDataBuf, (char *)gReturnOk, sizeof(gReturnOk)) != 0);
   
   /* Read line coding     
    */
   for (wTmp=0; wTmp<2; wTmp++) {    
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Ctrl_Sync);
      #endif
      error = usb_acm_get_line_coding(&cdc_cmd, (uchar_ptr)(&LineCoding));
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Ctrl_Sync);
   }

   /* Set line coding
    */    
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_set_line_coding(&cdc_cmd, (uchar_ptr)pgLineCoding);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);

   /* Set Control line state:
    * Deactivates carrrier; indicates DTE is present.
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   wTmp = 0x0001;
   error = usb_acm_set_control_line_state(&cdc_cmd, wTmp);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Set line coding
    */    
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_set_line_coding(&cdc_cmd, (uchar_ptr)pgLineCoding);
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
   /* Get line coding
    */  
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Ctrl_Sync);
   #endif
   error = usb_acm_get_line_coding(&cdc_cmd, (uchar_ptr)(&LineCoding));
   if (error == USB_STATUS_TRANSFER_QUEUED)
      USBCOM_sync_wait(&acm_device.Ctrl_Sync);
      
   /* Reset modem
    */   
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "ATZ\r");
   error = usb_host_acm_send_data(cmdBuffer, 4);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
 
   //do { 
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Data_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   //} while (strncmp((char *)gDataBuf, (char *)gReturnOk, sizeof(gReturnOk)) != 0);
   
   /*
    */
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "AT&F+IBC=0,0,0,,,,,0;+PCW= ;+P");
   error = usb_host_acm_send_data(cmdBuffer, 30);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
         
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "MH=1\r");
   error = usb_host_acm_send_data(cmdBuffer, 5);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
         
   for (wTmp=0; wTmp<3; wTmp++) {  
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Data_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   } 
         
   /* Disable echo of characters to the screen
    */
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "ATE0V1S0=0&C1&D2+MR=2;+DR=1;+E");
   error = usb_host_acm_send_data(cmdBuffer, 30);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
         
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "R=1;W2\r");
   error = usb_host_acm_send_data(cmdBuffer, 7);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   
   for (wTmp=0; wTmp<3; wTmp++) { 
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Data_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   }
   
   /* Set value in modem 'S' register
    */
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "ATS7=60S30=0L1M1+ES=3,0,2;+DS=");
   error = usb_host_acm_send_data(cmdBuffer, 30);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
         
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "3;+IFC=2,2;BX4\r");
   error = usb_host_acm_send_data(cmdBuffer, 15);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
 
   //do { 
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Data_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   //} while (strncmp((char *)gDataBuf, (char *)gReturnOk, sizeof(gReturnOk)) != 0);
   
   /* 
    */
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "AT+VCID=1\r");
   error = usb_host_acm_send_data(cmdBuffer, 10);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
    
   //do { 
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Data_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   //} while (strncmp((char *)gDataBuf, (char *)gReturnOk, sizeof(gReturnOk)) != 0);
   
   /* Set value in modem 'S' register
    */
   #ifndef __USB_OS_MQX__
   USBCOM_sync_init(&acm_device.Data_Sync);
   #endif
   strcpy((char *)cmdBuffer, "ATS0=0\r");
   error = usb_host_acm_send_data(cmdBuffer, 7);
   if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
    
   //do { 
      #ifndef __USB_OS_MQX__
      USBCOM_sync_init(&acm_device.Data_Sync);
      #endif
      error = usb_host_acm_recv_data(gDataBuf, DATA_BUFFER_LENGTH);
      if (error == USB_STATUS_TRANSFER_QUEUED)
         USBCOM_sync_wait(&acm_device.Data_Sync);
   //} while (strncmp((char *)gDataBuf, (char *)gReturnOk, sizeof(gReturnOk)) != 0);
   
   printf("\nHang up is done\n");
   fflush(stdout);

   return error;
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_ctrl_callback
* Returned Value : None
* Comments       :
*     called on completion of a control-pipe transaction.
*END*--------------------------------------------------------------------*/

static void usb_host_acm_ctrl_callback
   (
      /* [IN] pointer to pipe */
      uint_32           callback_param,

      /* [IN] user-defined parameter */
      pointer           buffer,

      /* [IN] buffer address */
      uint_32         buflen,

      /* [IN] length of data transferred */
      uint_32           status
   )
{ /* Body */

 //printf("Ctrl callback received. State = %d\n", acm_device.DEV_STATE);
 //fflush(stdout);
 DEVICE_STRUCT_PTR           acmDev_ptr;

 acmDev_ptr = (DEVICE_STRUCT_PTR)(pointer)callback_param;
 
 USBCOM_sync_post(&acm_device.Ctrl_Sync);
 
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_check_device
* Returned Value : USB_OK if success
* Comments       :
*     Called to make sure device can send/recv call management info
*     over data class interface.
*END*--------------------------------------------------------------------*/

static USB_STATUS usb_host_acm_check_device(void)
{
   USB_STATUS           error = USBERR_BAD_STATUS;
   USB_INTF_DESC_PTR    intf_ptr = NULL;
   char *               ch_ptr;
   USB_COMM_CALL_MANAGEMENT_DESC_PTR   desc_ptr = NULL;
   
   /* Two interfaces (COMM & DATA) have been attached. Now we need check
    * COMM interface for Class Specific Call Management Functional
    * descriptor for its capability of send/recv call management info
    * over data class interface.
    */
    error = _usb_hostdev_get_descriptor(acm_device.DEV_HANDLE,
            DESCTYPE_INTERFACE, 0, 0, (pointer *)(&intf_ptr));
    if (error != USB_OK)
       return error;
    if (intf_ptr && (intf_ptr->bInterfaceSubClass != USB_CLASS_COMMUNICATION)){ /* Body */           
       error = _usb_hostdev_get_descriptor(acm_device.DEV_HANDLE,
               DESCTYPE_INTERFACE, 1, 0, (pointer *)(&intf_ptr));
       if (error != USB_OK)
          return error;
       if (intf_ptr && (intf_ptr->bInterfaceSubClass != USB_CLASS_COMMUNICATION))
          return USBERR_NO_DESCRIPTOR;
    }
    
    ch_ptr = (char *)intf_ptr;
    ch_ptr += intf_ptr->bLength;
    while (ch_ptr) { /* Body */
         desc_ptr = (USB_COMM_CALL_MANAGEMENT_DESC_PTR)ch_ptr;
         if (desc_ptr->bDescriptorType == CS_INTERFACE &&  
             desc_ptr->bDescriptorSubType == 0x01) { //SubType = Call Management
             /* check device handle call management and can use data intf to do it */
             if (desc_ptr->bmCapability && 0x03)
                return USB_OK;
             else
                return USBERR_BAD_STATUS;
         } else if ((desc_ptr->bDescriptorType != CS_INTERFACE) && 
                    (desc_ptr->bDescriptorType != CS_ENDPOINT) && 
                    (desc_ptr->bDescriptorType != DESCTYPE_ENDPOINT)) {
             return USBERR_BAD_STATUS; 
         } else {
             ch_ptr += desc_ptr->bLength;
         } /* Endbody */    
    } /* Endbody */            

   return error;   
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_acm_cleanup
* Returned Value : None
* Comments       :
*     Called to do cleanup
*END*--------------------------------------------------------------------*/

static void usb_host_acm_cleanup(void)
{
   USBCOM_sync_destroy(&acm_device.Ctrl_Sync);
   USBCOM_sync_destroy(&acm_device.Data_Sync);
   
   if (gDataBuf) { /* Body */            
      USB_memfree((pointer)gDataBuf);
      gDataBuf = 0;
   }  
}


/* EOF */

