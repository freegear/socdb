#ifndef __mfs_h__
#define __mfs_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:
***    This file contains the structure definitions and constants for a
***    user who will be compiling programs that will use the Embedded MS-DOS
***    File System (MFS)
***                     
***
**************************************************************************
**END*********************************************************/

#include "rev_mfs.h"
/*
** Defines specific to MFS
*/

#define MFS_VERSION           (0x0020000 | MFS_REVISION)   /* version 2.00 */

/* search attributes  */
#define  MFS_SEARCH_NORMAL      0x00
#define  MFS_SEARCH_HIDDEN      0x02
#define  MFS_SEARCH_SYSTEM      0x04
#define  MFS_SEARCH_VOLUME      0x08
#define  MFS_SEARCH_SUBDIR      0x10
#define  MFS_SEARCH_ARCHIVE     0x20

/* file open access modes */
#define  MFS_ACCESS_READ_ONLY   0x00
#define  MFS_ACCESS_WRITE_ONLY  0x01
#define  MFS_ACCESS_READ_WRITE  0x02

/* file entry attributes */
#define  MFS_ATTR_READ_ONLY     0x01
#define  MFS_ATTR_HIDDEN_FILE   0x02
#define  MFS_ATTR_SYSTEM_FILE   0x04
#define  MFS_ATTR_VOLUME_NAME   0x08
#define  MFS_ATTR_DIR_NAME      0x10
#define  MFS_ATTR_ARCHIVE       0x20
#define  MFS_ATTR_LFN           0x0F

/* mask values for the date and time as recorded in the
** file entries
*/
#define  MFS_MASK_DAY           0x001F
#define  MFS_MASK_MONTH         0x01E0
#define  MFS_MASK_YEAR          0xFE00
#define  MFS_MASK_SECONDS       0x001F
#define  MFS_MASK_MINUTES       0x07E0
#define  MFS_MASK_HOURS         0xF800

/*
** shift for the above date and time masks
*/
#define  MFS_SHIFT_DAY          0
#define  MFS_SHIFT_MONTH        5
#define  MFS_SHIFT_YEAR         9
#define  MFS_SHIFT_SECONDS      0
#define  MFS_SHIFT_MINUTES      5
#define  MFS_SHIFT_HOURS        11

/*
** control for the write cache
*/
#define  MFS_WRCACHE_OFF        0
#define  MFS_WRCACHE_ON         1
#define  MFS_WRCACHE_FLUSH      2

#define  MFS_DEFAULT_SECTOR_SIZE    512

/* 
** Can be modified to customize MFS 
*/

/* Maximun bytes for 1 read or write */
#define  MFS_MAX_BYTES_PER_RW       0x8000  

/* Value must be 1 or 2. 2 is tthe standard */
#define  MFS_NUM_OF_FATS            2       

/* Must be 1 (TRUE) or 0 (FALSE). Determines when a file entry is updated. */
#define  MFS_IMMEDIATE_FILE_UPDATE  1       

/* # of fat sectors in FAT cache. Minimun value of 2 required. */           
#define  FAT_BUFFER_SIZE            100
 
/* 
** The amount of times MFS will attempt to read or write to the device 
** unsuccessfully before reporting an error
*/
#define MFS_MAX_WRITE_RETRIES       3
#define MFS_MAX_READ_RETRIES        3

/*
** Sector boundries that determine the cluster size, the root dir size
** and the FAT type 
*/

/* TYPE: FAT12, Root dir: 7 * 32 root entries, CLUSTER SIZE: 1 sector */
#define  SECTOR_BOUND1     2048  

/* TYPE: FAT12, Root dir: 14 * 32 root entries, CLUSTER SIZE: 1 sector */
#define  SECTOR_BOUND2     4096

/* TYPE: FAT12, Root dir: 32 * 32 root entries, CLUSTER SIZE: 2 sectors */
#define  SECTOR_BOUND3     8192

/* TYPE: FAT12, Root dir: 32 * 32 root entries, CLUSTER SIZE: 4 sectors */
#define  SECTOR_BOUND4     16384

/* TYPE: FAT12, Root dir: 32 * 32 root entries, CLUSTER SIZE: 2 sectors */
#define  SECTOR_BOUND5     32768

/* TYPE: FAT16, Root dir: 32 * 32 root entries, CLUSTER SIZE: 8 sectors */
#define  SECTOR_BOUND6     524288

/* TYPE: FAT16, Root dir: 32 * 32 root entries, CLUSTER SIZE: 16 sectors */
#define  SECTOR_BOUND7     1048576

/* TYPE: FAT32, Root dir: 64k entries, CLUSTER SIZE: 8  sectors */
#define  SECTOR_BOUND8     16777216

/* TYPE: FAT32, Root dir: 64k entries, CLUSTER SIZE: 16  sectors */
#define  SECTOR_BOUND9     33554432

/* TYPE: FAT32, Root dir: 64k entries, CLUSTER SIZE: 32  sectors */
#define  SECTOR_BOUND10    67108864

                                            

/* 
** FILENAME LENGTH CONSTANTS
*/
#define PATHNAME_SIZE         260
#define FILENAME_SIZE         255
#define SFILENAME_SIZE        12


/*
** error codes
*/
#define MFS_NO_ERROR                          0
#define MFS_INVALID_FUNCTION_CODE             1
#define MFS_FILE_NOT_FOUND                    2
#define MFS_PATH_NOT_FOUND                    3
#define MFS_ACCESS_DENIED                     5
#define MFS_INVALID_HANDLE                    6
#define MFS_INSUFFICIENT_MEMORY               8
#define MFS_INVALID_MEMORY_BLOCK_ADDRESS      9
#define MFS_ATTEMPT_TO_REMOVE_CURRENT_DIR     16
#define MFS_DISK_IS_WRITE_PROTECTED           19
#define MFS_BAD_DISK_UNIT                     20
#define MFS_INVALID_LENGTH_IN_DISK_OPERATION  24
#define MFS_NOT_A_DOS_DISK                    26
#define MFS_SECTOR_NOT_FOUND                  27
#define MFS_WRITE_FAULT                       29
#define MFS_READ_FAULT                        30
#define MFS_SHARING_VIOLATION                 32
#define MFS_FILE_EXISTS                       80
#define MFS_ALREADY_ASSIGNED                  85
#define MFS_INVALID_PARAMETER                 87

#define MFS_DISK_FULL                        101
#define MFS_ROOT_DIR_FULL                    102
#define MFS_EOF                              103
#define MFS_CANNOT_CREATE_DIRECTORY          104
#define MFS_NOT_INITIALIZED                  151
#define MFS_OPERATION_NOT_ALLOWED            152
#define MFS_ERROR_INVALID_DRIVE_HANDLE       157
#define MFS_ERROR_INVALID_FILE_HANDLE        158  
#define MFS_ERROR_UNKNOWN_FS_VERSION         159   
#define MFS_LOST_CHAIN                       160

#define MFS_INVALID_DEVICE                   161

/*
** Extra IO_IOCTL codes
*/
#define IO_IOCTL_DELETE_FILE                 0x3002
#define IO_IOCTL_BAD_CLUSTERS                0x3003
#define IO_IOCTL_FREE_SPACE                  0x3004
#define IO_IOCTL_TEST_UNUSED_CLUSTERS        0x3005
#define IO_IOCTL_CREATE_SUBDIR               0x3006
#define IO_IOCTL_REMOVE_SUBDIR               0x3007
#define IO_IOCTL_GET_CURRENT_DIR             0x3008
#define IO_IOCTL_CHANGE_CURRENT_DIR          0x3009
#define IO_IOCTL_WRITE_CACHE_ON              0x300A
#define IO_IOCTL_WRITE_CACHE_OFF             0x300B
#define IO_IOCTL_FORMAT                      0x300C
#define IO_IOCTL_FORMAT_TEST                 0x300D
#define IO_IOCTL_FIND_FIRST_FILE             0x300E
#define IO_IOCTL_FIND_NEXT_FILE              0x300F
#define IO_IOCTL_RENAME_FILE                 0x3010
#define IO_IOCTL_GET_FILE_ATTR               0x3011
#define IO_IOCTL_SET_FILE_ATTR               0x3012
#define IO_IOCTL_GET_DATE_TIME               0x3013
#define IO_IOCTL_SET_DATE_TIME               0x3014
#define IO_IOCTL_FLUSH_FAT                   0x3015
#define IO_IOCTL_FAT_CACHE_ON                0x3016
#define IO_IOCTL_FAT_CACHE_OFF               0x3017
#define IO_IOCTL_SET_VOLUME                  0x3018
#define IO_IOCTL_GET_VOLUME                  0x3019
#define IO_IOCTL_GET_LFN                     0x301A
#define IO_IOCTL_FREE_CLUSTERS               0x301B
#define IO_IOCTL_GET_CLUSTER_SIZE            0x301C


/*
** Data Structures specific to MFS
*/

/*
** Information required for high-level format
*/
typedef struct mfs_format_data
{
   uchar    PHYSICAL_DRIVE;
   uchar    MEDIA_DESCRIPTOR;
   uint_16  BYTES_PER_SECTOR;
   uint_16  SECTORS_PER_TRACK;
   uint_16  NUMBER_OF_HEADS;
   uint_32  NUMBER_OF_SECTORS;
   uint_32  HIDDEN_SECTORS;
   uint_16  RESERVED_SECTORS;
} MFS_FORMAT_DATA, _PTR_ MFS_FORMAT_DATA_PTR;

/*
** Format information for ioctl calls involving format operations
*/
typedef struct mfs_ioctl_format
{
   MFS_FORMAT_DATA_PTR     FORMAT_PTR;
   uint_32_ptr             COUNT_PTR;      /* To count the bad clusters */
} MFS_IOCTL_FORMAT_PARAM, _PTR_ MFS_IOCTL_FORMAT_PARAM_PTR;


/*  
** search data block, used for Find_first and Find_next
*/
typedef struct mfs_search_data
{
   pointer  DRIVE_PTR;
   uchar    RESERVED[29];     /* Sizeof Internal search struct */
   uchar    ATTRIBUTE;
   uint_16  TIME;
   uint_16  DATE;
   uint_16  RESERVED2;
   uint_32  FILE_SIZE;
   char     NAME[13];
} MFS_SEARCH_DATA, _PTR_ MFS_SEARCH_DATA_PTR;


/*
** Search information for ioctl find file first search calls
*/
typedef struct mfs_search_param
{
   uchar                   ATTRIBUTE;
   uchar                   RESERVED[3];
   char_ptr                WILDCARD;
   MFS_SEARCH_DATA_PTR     SEARCH_DATA_PTR;
} MFS_SEARCH_PARAM, _PTR_ MFS_SEARCH_PARAM_PTR;

/*
** Pathname information for the rename_file ioctl call
*/
typedef struct mfs_rename_param
{
   char_ptr                OLD_PATHNAME;
   char_ptr                NEW_PATHNAME;
} MFS_RENAME_PARAM, _PTR_ MFS_RENAME_PARAM_PTR;


/*
** Paramater information for get and set file attribute ioctl calls
*/
typedef struct mfs_file_attr_param
{
   char_ptr                PATHNAME;
   uchar_ptr               ATTRIBUTE_PTR;
} MFS_FILE_ATTR_PARAM, _PTR_ MFS_FILE_ATTR_PARAM_PTR;  

typedef struct mfs_get_lfn_struct
{
   char_ptr                PATHNAME;
   char_ptr                LONG_FILENAME;   
} MFS_GET_LFN_STRUCT, _PTR_ MFS_GET_LFN_STRUCT_PTR;

 
/*
** Parameter information for get/set date time ioctl calls
*/
typedef struct mfs_date_time_param
{
   uint_16_ptr             DATE_PTR;
   uint_16_ptr             TIME_PTR;
} MFS_DATE_TIME_PARAM, _PTR_ MFS_DATE_TIME_PARAM_PTR;  


/*
** extern statements for MFS
*/

#ifdef __cplusplus
extern "C" {
#endif

extern uint_32
   _io_mfs_install(
      FILE_PTR                      dev_fd,
      char_ptr                      identifier,
      uint_32                       part_num);

extern uint_32 
   _io_mfs_uninstall(
      char_ptr                      identifier);
    
extern int_32 
   _io_mfs_open(
      FILE_PTR                      fd_ptr,
      char_ptr                      open_name_ptr,
      char_ptr                      flags_str);

extern int_32 
   _io_mfs_close(
      FILE_PTR                      fd_ptr);
      
extern int_32 
   _io_mfs_read( 
      FILE_PTR                      file_ptr,
      char_ptr                      data_ptr,
      int_32                        num);

extern int_32 
   _io_mfs_write(
      FILE_PTR                      file_ptr,
      char_ptr                      data_ptr,
      int_32                        num);

extern int_32 
   _io_mfs_ioctl( 
      FILE_PTR                      file_ptr,
      uint_32                       cmd,
      uint_32_ptr                   param_ptr);

#ifdef __cplusplus
}
#endif

#if (MFS_NUM_OF_FATS == 0)
#error "Illegal number of FATS"
#endif

#endif
/* EOF */

