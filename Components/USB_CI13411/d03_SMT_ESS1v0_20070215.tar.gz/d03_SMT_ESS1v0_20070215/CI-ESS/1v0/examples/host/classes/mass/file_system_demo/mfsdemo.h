#ifndef _mfsdemo_h_
#define _mfsdemo_h_ 1
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:
***   This include file is used to define the demonstation constants
***
***
**************************************************************************
**END*********************************************************/

#include "types.h"
#include "bsp.h"
#ifdef __USB_OTG__
#include "otgapi.h"
#include "devapi.h"
#else
#include "hostapi.h"
#endif
#include "usb_mass_bo.h"
#include "mqx_arc.h"
#include "fio.h"
#include "mfs.h"
#include "part_mgr.h"
#include "usbmfs.h"

#define MFS_MASS_STORAGE_DISK

#define MAIN_TASK               10
#define FILE_TASK               11
#define FILE_DESTROY_TASK       12
#define SHELL_TASK              13

#define LOCAL_ID               	0

#define MFS1            		"mfs1:"
#define USB_DISK        		"usbdisk:"

#define CAMERA_DIRECTORY		"b:\\DCIM\\100OLYMP"

/* For reading and writing to disk. There are 1 global variables this size */
//#define TEST_BUFFER_SIZE 		0x400	    // 1k
#define TEST_BUFFER_SIZE 		0x19000		// 100k

#define TEST_WITH_MEMORY_DEVICE 0
#define TEST_WITH_SIMULATOR   	0
/*
** Defines about the disk infomation
**
** TOTAL NUMBER OF SECTORS =
**   SECTS_PER_TRACK * NUM_OF_HEADS * MFS_CYL - HIDDEN_SECTS
**
*/
#define MFS_CYL          			7
#define HD_PHYSICAL_DRIVE  			0x80	// hard disk
#define HD_MEDIA_DESC     			0xF8	// hard disk
#define BYTES_PER_SECT   			512
#define SECTS_PER_TRACK  			25
#define NUM_OF_HEADS     			4
#define HIDDEN_SECTS     			32
#define RESERVED_SECTS   			1
/* #define RAMDISK_NUMBER_OF_SECTORS  	10   5K (512*10) */
#define RAMDISK_NUMBER_OF_SECTORS  	400   /*200K (512*400) */
/* #define RAMDISK_NUMBER_OF_SECTORS   1024  512K (512*1024) */
/*#define RAMDISK_NUMBER_OF_SECTORS   700    1M (512*2048) */
/*#define RAMDISK_NUMBER_OF_SECTORS   2560   1.25M (512*2560) */
/*#define RAMDISK_NUMBER_OF_SECTORS   3072   1.5M (512*3072) */

#define CAPITALIZE(c)  (c&((c>='a'&&c<='z')?(~0x20):~0))

#define MFS_ATTR_ANY              0x80

#define MAX_FRAME_SIZE              1024
#define HOST_CONTROLLER_NUMBER      0

#define BUFFERSIZE      1023

#define  DATA_SIZE                   (300)
#define  DEMO_CONFIG_DESC_SIZE       (64)

#define  USB_DEVICE_IDLE                   (0)
#define  USB_DEVICE_ATTACHED               (1)
#define  USB_DEVICE_CONFIGURED             (2)
#define  USB_DEVICE_SET_INTERFACE_STARTED  (3)
#define  USB_DEVICE_INTERFACED             (4)
#define  USB_DEVICE_DETACHED               (5)
#define  USB_DEVICE_OTHER                  (6)

/*
** Following structs contain all states and pointers
** used by the application to control/operate devices.
*/



typedef struct
{
  FILE_PTR                   DEV_HANDLE1;
  FILE_PTR                   PM_FD_PTR;
  FILE_PTR                   MFS_FD_PTR;
  boolean                    ACTIVE;
  _task_id                   TASK_ID;
   /* Light weight semaphore struct */
  LWSEM_STRUCT               LWSEM;
} APP_INIT_VARIABLES, _PTR_ APP_INIT_VARIABLES_PTR;

extern FILE_PTR A_FD_PTR, B_FD_PTR;
extern volatile APP_INIT_VARIABLES app_init;
extern volatile _task_id  shell_task_id;
char_ptr Error_text(uint_32);
int_32 mfs_test_getchar(void);


#ifdef __cplusplus
extern "C" {
#endif
extern void Main_Task(uint_32 param);
extern void File_task(uint_32 param);
extern void Application_task(uint_32 param);
extern void File_destroy_task(uint_32 param);
extern void DosShell(uint_32 param);
extern	int	isgraph(int __c);
extern void usb_host_mass_device_event(_usb_device_instance_handle, _usb_interface_descriptor_handle, uint_32);
extern void usb_host_unknown_device_event(_usb_device_instance_handle, _usb_interface_descriptor_handle, uint_32);

#ifdef __cplusplus
}
#endif

#endif
/* EOF */
