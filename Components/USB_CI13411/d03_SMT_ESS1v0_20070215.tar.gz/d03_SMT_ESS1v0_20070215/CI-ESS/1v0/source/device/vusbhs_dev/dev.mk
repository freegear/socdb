# VUSBHS device driver

MQX_INCDIRS      +=$(USB_ROOT)$(PS)source$(PS)device$(PS)vusbhs_dev

srcdirs += device$(PS)$(USB_DRIVER)_dev
device_srcs    += \
	vusbhs_dev_cncl vusbhs_dev_deinit vusbhs_dev_main vusbhs_dev_shut vusbhs_dev_utl

