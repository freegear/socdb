/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the low-level VUSB32 Device Controller Interface
***   (DCI) initialization routines.
***                                                               
**************************************************************************
**END*********************************************************/
#include "devapi.h"
#include "usb.h"
#include "vusb32.h"
#include "usbprv.h"
#include "usbprv_dev.h"

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
#endif

USB_DEV_STATE_STRUCT_PTR global_usb_device_state_struct_ptr;
#ifndef __USB_OS_MQX__
extern volatile boolean IN_ISR;
#endif

/* All global variable used for double buffering of EP0 Recv will be prefix with "dbl_" */

BDT_STRUCT_PTR	dbl_pbdt0recv[2];		/* where the actual bdts are */
uchar_ptr	dbl_buffer0, dbl_buffer1;
uchar_ptr	dbl_buffer[2];
BDT_STRUCT	dbl_user[2];			/* what the user tried to set */

#define DEBUG	0

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_init
* Returned Value : USB_OK or error code
* Comments       :
*     Initializes the device layer, i.e. the VUSB, the VUSB DMA Buffer 
*     Descriptor Tables after which the VUSB device will be able to respond
*     to events on the bus. The initial
*     state for the USB device after initialization is the powered state.
* 
*END*--------------------------------------------------------------------*/
uint_8 _usb_dci_vusb11_init
   (
      /* [IN] handle to the usb device */
      _usb_device_handle handle
   )
{ /* Body */
	uint_32 i;
	USB_DEV_STATE_STRUCT_PTR usb_dev_ptr;
	USB_STRUCT _PTR_    dev_ptr;
	USB_REGISTER _PTR_  endpt_reg;
   uchar_ptr           driver_memory;
   uint_32             total_memory=0;
   

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_init");
   #endif
   
	usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;

	usb_dev_ptr->USB = (pointer)_bsp_get_usb_base(usb_dev_ptr->DEV_NUM);
	usb_dev_ptr->ENDPT_REGS = (USB_REGISTER_PTR)((uint_32)usb_dev_ptr->USB + 0x40);

	dev_ptr = (USB_STRUCT _PTR_)usb_dev_ptr->USB;
	endpt_reg = (USB_REGISTER _PTR_)usb_dev_ptr->ENDPT_REGS;
   
    /****************************************************************   
      Consolidated memory allocation  done once inside driver   
    ****************************************************************/   
   total_memory = (sizeof(VUSB_ENDPOINT_BDT_STRUCT) * 
		            usb_dev_ptr->MAX_ENDPOINTS + USB_BDT_ALIGN(1)) +
                  EP0_RECV_BUFFER_SIZE + PSP_CACHE_LINE_SIZE +
                  EP0_RECV_BUFFER_SIZE + PSP_CACHE_LINE_SIZE;
      
   driver_memory =  (uchar_ptr) USB_Uncached_memalloc(total_memory);
   if (driver_memory == NULL)
	{
      #ifdef _DEVICE_DEBUG_
         DEBUG_LOG_TRACE("_usb_dci_vusb11_init, malloc error");
      #endif
		return USBERR_ALLOC;
	}
   
   USB_memzero(driver_memory,total_memory);
   
   #ifdef _DATA_CACHE_   
   /****************************************************************   
      Flush the zeroed memory if cache is enabled
   ****************************************************************/   
   USB_dcache_flush_mlines((pointer)driver_memory,total_memory);
   
   #endif


   usb_dev_ptr->DRIVER_MEMORY = driver_memory;

    /****************************************************************   
    Point the BDT memory inside memory we received.
    ****************************************************************/   
   usb_dev_ptr->USB_BDT_PAGE = (VUSB_ENDPOINT_BDT_STRUCT_PTR)
		USB_BDT_ALIGN((uint_32)driver_memory);

   driver_memory +=  (sizeof(VUSB_ENDPOINT_BDT_STRUCT) * 
		            usb_dev_ptr->MAX_ENDPOINTS + USB_BDT_ALIGN(1));

   
	/* init double buffering stuff */
	dbl_pbdt0recv[0] = &usb_dev_ptr->USB_BDT_PAGE[0][0][0];
	dbl_user[0].PID_OWN_DATA01_BC = 0;
	dbl_user[0].ADDRESS = NULL;
	VUSB_INIT_BDT(dbl_pbdt0recv[0], 0, 0, 0);

	dbl_pbdt0recv[1] = &usb_dev_ptr->USB_BDT_PAGE[0][0][1];
	dbl_user[1].PID_OWN_DATA01_BC = 0;
	dbl_user[1].ADDRESS = NULL;
	VUSB_INIT_BDT(dbl_pbdt0recv[1], 0, 0, 0);

   /****************************************************************   
    Point the double buffers
   ****************************************************************/   
   dbl_buffer0 = (uchar_ptr) USB_CACHE_ALIGN((uint_32) driver_memory);
   driver_memory += EP0_RECV_BUFFER_SIZE + PSP_CACHE_LINE_SIZE;
   
   dbl_buffer1 = (uchar_ptr) USB_CACHE_ALIGN((uint_32)driver_memory);
   
   
   /****************************************************************/
   
   /*assign the buffers to the array of buffers */
   dbl_buffer[0] = dbl_buffer0;
   dbl_buffer[1] = dbl_buffer1;
   
	/* 
	** _usb_device_init initializes the USB interface.
	** The BDTs are NOT intialized here. They
	** are initialized as they are enabled.
	*/

	/* disable the VUSB */
	dev_ptr->CONTROL = 0;
	/* mask all interupts */
	dev_ptr->INTENABLE = 0;
	/* Clear all interrupt */
	dev_ptr->INTSTATUS = 0xFF;

	/* mask no errors */
	dev_ptr->ERRORENABLE = 0xff;

	/* Current USB state (POWERED,DEFAULT,ADDRESS,CONFIG,SUSPEND) */
	usb_dev_ptr->USB_STATE = USB_STATE_POWERED;
	/* Current USB configuration selected */
	usb_dev_ptr->USB_CURR_CONFIG = 0;

	/* Set the Buffer Descriptor Table location in the USB regs */
	USB_SET_BDT_PAGE(dev_ptr, usb_dev_ptr->USB_BDT_PAGE);

	/* disable all endpoints */
	for (i = 0; i < usb_dev_ptr->MAX_ENDPOINTS; i++)
		{
		endpt_reg[i] = VUSB_ENDPT_DISABLE;
		} /* Endfor */

	/* reserve 2 bytes for a frame counter */
	usb_dev_ptr->USB_SOF_COUNT = 0xffff;

#ifndef __USB_OTG__

#ifdef __USB_OS_MQX__
	if (!(USB_install_isr(_bsp_get_usb_vector(usb_dev_ptr->DEV_NUM), 
		_usb_dci_vusb11_isr, (pointer)usb_dev_ptr)))
		{
         #ifdef _DEVICE_DEBUG_
            DEBUG_LOG_TRACE("_usb_dci_vusb11_init,error installing ISR");
         #endif
		   return USBERR_INSTALL_ISR;
		} /* Endbody */
#else
	USB_install_isr(_bsp_get_usb_vector(usb_dev_ptr->DEV_NUM), 
		_usb_dci_vusb11_isr, (pointer)usb_dev_ptr);
#endif /* USB_OS_MQX */

#endif /* USB_OTG */

	/* Reset the BDT Odd ping/pong bits to 0 */
	dev_ptr->CONTROL = VUSB_CTL_ODD_RST;

	/* enable the USB */
	dev_ptr->CONTROL = VUSB_CTL_USB_EN;

	/* Init the service structure */
	usb_dev_ptr->SERVICE_HEAD_PTR = NULL;

	/* enable only bus reset interrupts at this point */
	dev_ptr->INTENABLE = VUSB_INT_ENB_USB_RST | VUSB_INT_ENB_SLEEP;

	global_usb_device_state_struct_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_init, SUCCESSFUL");
   #endif
   
	return USB_OK;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_isr
* Returned Value : None
* Comments       :
*     Catchall ISR for USB interrupts.  Handles all aspects of USB
*     interrupts.
* 
*END*--------------------------------------------------------------------*/
#ifndef __USB_OS_MQX__
DEVICE_INTERRUPT_ROUTINE_KEYWORD void _usb_dci_vusb11_isr
   (
      void
   )
#else
void _usb_dci_vusb11_isr
   (
      _usb_device_handle handle
   )
#endif
{ /* Body */
	XD_STRUCT_PTR                 pxd;
	XD_STRUCT_PTR                 pxdOther;
	BDT_STRUCT_PTR                temp_BDT_PTR;
	USB_DEV_STATE_STRUCT_PTR      usb_dev_ptr;
	uint_8                        direction, status, odd_even;
	uint_16                       k, wBytes;
	uint_8						      bToken, b;
	USB_STRUCT _PTR_              dev_ptr;
	USB_REGISTER _PTR_            endpt_reg;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_isr");
   #endif

#ifdef __USB_OS_MQX__
	usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
#else
	usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)global_usb_device_state_struct_ptr;
#ifndef __USB_OTG__   
	IN_ISR = TRUE;
#endif
#endif

	dev_ptr     = (USB_STRUCT _PTR_)usb_dev_ptr->USB;
	endpt_reg   = (USB_REGISTER _PTR_)usb_dev_ptr->ENDPT_REGS;

	while (TRUE)
		{
		/* clear error bits that we've seen */
		status = dev_ptr->ERRORSTATUS;
		dev_ptr->ERRORSTATUS = status;

		status = (dev_ptr->INTSTATUS & dev_ptr->INTENABLE);

		if (!status)
			{
			break;
			} /* Endif */

		direction = USB_REGISTER_STATUS_TXRX(dev_ptr);
		odd_even = USB_REGISTER_STATUS_ODDEVEN(dev_ptr);
		usb_dev_ptr->EP = USB_REGISTER_STATUS_ENDPOINT(dev_ptr);
		usb_dev_ptr->BDT_PTR = &usb_dev_ptr->USB_BDT_PAGE[usb_dev_ptr->EP][direction][odd_even];

      /* Clear all enabled interrupts */
		dev_ptr->INTSTATUS = status;

		if (status & VUSB_INT_STAT_RESET)
		{
			/* A USB Bus Reset has occurred */
			_usb_dci_vusb11_bus_reset((_usb_device_handle)usb_dev_ptr);
			_usb_device_call_service((_usb_device_handle)usb_dev_ptr, USB_SERVICE_BUS_RESET, 0, 0, 0, 0, 0);

			/* Enqueue a recv buffer for receiving setup packet */
			usb_dev_ptr->XDRECV[0].SETUP_BUFFER_QUEUED = FALSE;
			usb_dev_ptr->XDSEND[0].SETUP_BUFFER_QUEUED = FALSE;
			_usb_device_recv_data((_usb_device_handle)usb_dev_ptr, 0, (uchar_ptr)&usb_dev_ptr->XDRECV[0].SETUP_BUFFER, 8);
			usb_dev_ptr->XDRECV[0].SETUP_BUFFER_QUEUED = TRUE;
			usb_dev_ptr->XDSEND[0].SETUP_BUFFER_QUEUED = TRUE;
		}

		pxd = pxdOther = NULL;

/*      
	EEEEE  PPPP    000       RRRR   EEEEE   CCC   V   V
	E      P   P  0   0      R   R  E      C   C  V   V
	EEE    PPPP   0   0  ==  RRRR   EEE    C       V V 
	E      P      0   0      R  R   E      C   C   V V 
	EEEEE  P       000       R   R  EEEEE   CCC     V  
*/

		if ((usb_dev_ptr->EP == 0) && (direction == USB_RECV))
		{

			bToken = VUSB_GET_TOKEN(usb_dev_ptr->BDT_PTR);
         wBytes = VUSB_GET_BC(usb_dev_ptr->BDT_PTR);
			bToken = VUSB_GET_TOKEN(usb_dev_ptr->BDT_PTR);
			b = (((uint_32)usb_dev_ptr->BDT_PTR) & 0x08) ? 1 : 0;

			if (bToken == TOKEN_SETUP)
			if (dev_ptr->CONTROL & VUSB_CTL_TXD_SUSPEND)
			{

					temp_BDT_PTR = &usb_dev_ptr->USB_BDT_PAGE[usb_dev_ptr->EP][USB_SEND][0];

					if (temp_BDT_PTR->PID_OWN_DATA01_BC & VUSB32_OWNS_BIT_MASK)
					{
						if (temp_BDT_PTR->PID_OWN_DATA01_BC & VUSB_BDT_STALL_BIT)
						{
							temp_BDT_PTR->PID_OWN_DATA01_BC &= ~(VUSB_BDT_STALL_BIT);
							temp_BDT_PTR->PID_OWN_DATA01_BC &= ~VUSB32_OWNS_BIT_MASK;
						}
					}

					temp_BDT_PTR = &usb_dev_ptr->USB_BDT_PAGE[usb_dev_ptr->EP][USB_SEND][1];

					if (temp_BDT_PTR->PID_OWN_DATA01_BC & VUSB32_OWNS_BIT_MASK)
					{
						if (temp_BDT_PTR->PID_OWN_DATA01_BC & VUSB_BDT_STALL_BIT)
						{
							temp_BDT_PTR->PID_OWN_DATA01_BC &= ~(VUSB_BDT_STALL_BIT);
							temp_BDT_PTR->PID_OWN_DATA01_BC &= ~VUSB32_OWNS_BIT_MASK;
						}
					}

					/* Setup packet received so clear endpoint stall bit here in 
					** case of a protcol stall 
					*/

					endpt_reg[usb_dev_ptr->EP] &= ~VUSB_EP_CTRL_STALL;
					usb_dev_ptr->XDSEND[usb_dev_ptr->EP].CTL &= ~VUSB_EP_CTRL_STALL;
					usb_dev_ptr->XDRECV[usb_dev_ptr->EP].CTL &= ~VUSB_EP_CTRL_STALL;

					/* dequeue any pending packets */
					if (usb_dev_ptr->XDSEND[usb_dev_ptr->EP].PACKETPENDING)
					{
						_usb_device_cancel_transfer((_usb_device_handle)usb_dev_ptr, usb_dev_ptr->EP, USB_SEND);
					}

					/* clear the txd_suspend bit */
					dev_ptr->CONTROL &= ~VUSB_CTL_TXD_SUSPEND;
			 } /* Endif */

   	 	if (status & VUSB_INT_STAT_TOKEN_DONE)
			{

				pxd = &usb_dev_ptr->XDRECV[0];
				
				if (pxd->STATUS != USB_STATUS_TRANSFER_PENDING && pxd->STATUS != USB_STATUS_TRANSFER_IN_PROGRESS)
					continue;	/* xd not appropriate */

				pxdOther = &usb_dev_ptr->XDSEND[0];

            /* Read the setup packet */
            for(k=0; k < wBytes; k++)
            {
               *(dbl_user[b].ADDRESS + k) = *(usb_dev_ptr->BDT_PTR->ADDRESS + k);
            }
            
            /******************************************************
            Invalidate the Receive Buffer to ensure that we fetch from memory
            next time.
            *******************************************************/
            #ifdef  _DATA_CACHE_
               USB_dcache_invalidate_line((void *)dbl_buffer[b]);                      
            #endif
            VUSB_INIT_BDT(dbl_pbdt0recv[b], dbl_buffer[b], 64, VUSB_BDT_OWNS_BIT /*| VUSB_BDT_DATA01_BIT | VUSB_BDT_DTS_BIT*/);


				pxd->SOFAR += wBytes;
				pxd->UNACKNOWLEDGEDBYTES -= wBytes;


				if ((bToken == TOKEN_SETUP) || (!(pxd->CTL & VUSB_ENDPT_HSHK_BIT)))
				{
					/* clear endpoint stall bit here in case of a protcol stall */
					endpt_reg[0] &= ~VUSB_EP_CTRL_STALL;

					/*
					** Setup packets always arrive in their entirety, as they're only 8
					** bytes and require no terminating null.  The same is true for
					** isochronous endpoints (which don't even get acknowledgements).
					*/
					/* The transfer has completed.  Reset the XD. */
					pxd->PACKETPENDING--;

					pxd->BDTCTL = 0;
					pxd->STATUS = USB_STATUS_IDLE;
					_usb_device_call_service((_usb_device_handle)usb_dev_ptr, usb_dev_ptr->EP,
						/* If we have handshakes, it is a control endpoint -> setup */
						((pxd->CTL & VUSB_ENDPT_HSHK_BIT) ? 1 : 0),
						direction, pxd->STARTADDRESS, pxd->SOFAR, 0);

					/* Check if its Isochronous packet or Setup packet */
					if (pxd->CTL & VUSB_ENDPT_HSHK_BIT)
					{
						pxd->SETUP_BUFFER_QUEUED = FALSE;
						pxdOther->SETUP_BUFFER_QUEUED = FALSE;
		
						/* Enqueue a recv buffer for receiving setup packet */
						_usb_device_recv_data((_usb_device_handle)usb_dev_ptr, usb_dev_ptr->EP,
							(uchar_ptr)&usb_dev_ptr->XDRECV[usb_dev_ptr->EP].SETUP_BUFFER, 8);

						pxd->SETUP_BUFFER_QUEUED = TRUE;
						pxdOther->SETUP_BUFFER_QUEUED = TRUE;
					} /* Endif */
				}
				else if (wBytes == pxd->MAXPACKET)
				{
					pxd->PACKETPENDING--;
					/*
					** If there is still data for which a BDT has not been sent, we must
					** send another BDT.  This includes zero-length BDTs on non-control
					** endpoints for transactions that are a multiple of the endpoint's
					** max packet size.
					*/
					if (pxd->TODO || pxd->MUSTSENDNULL)
					{
						pxd->STATUS = USB_STATUS_TRANSFER_IN_PROGRESS;
						_usb_dci_vusb11_submit_BDT(usb_dev_ptr->BDT_PTR, pxd);
					}
					else if (pxd->PACKETPENDING  && pxd->UNACKNOWLEDGEDBYTES)
					{
						pxd->STATUS = USB_STATUS_TRANSFER_IN_PROGRESS;
					}
					else
					{ 
						pxd->BDTCTL = 0;
						pxd->STATUS = USB_STATUS_IDLE;

						_usb_device_call_service((_usb_device_handle)usb_dev_ptr,
							usb_dev_ptr->EP, 0, direction, pxd->STARTADDRESS, pxd->SOFAR, 0);
					} /* Endif */
				}
				else if (wBytes < pxd->MAXPACKET)
				{
					/*
					** If we have received a short packet, the transaction is complete
					** regardless of endpoint or the expected size.
					*/
					pxd->PACKETPENDING = 0;
					pxd->BDTCTL = 0;
					pxd->STATUS = USB_STATUS_IDLE;

					_usb_device_call_service((_usb_device_handle)usb_dev_ptr, 
						usb_dev_ptr->EP, 0, direction, pxd->STARTADDRESS, pxd->SOFAR, 0);

					if (pxd->TYPE == USB_CONTROL_ENDPOINT)
						{
						/* protocol stall - stall the other BD */
						temp_BDT_PTR = VUSB_TOGGLE_BDT(usb_dev_ptr->BDT_PTR);
						/* Set the STALL bit */
/* rf					temp_BDT_PTR->PID_OWN_DATA01_BC |= (VUSB_BDT_STALL_BIT);*/
						/* Set the OWNS bit */
						temp_BDT_PTR->PID_OWN_DATA01_BC |= VUSB32_OWNS_BIT_MASK;
						if ((!direction) && (!wBytes))
							{
							pxd->CTL |= VUSB_EP_CTRL_STALL;

							pxd->SETUP_BUFFER_QUEUED = FALSE;
							usb_dev_ptr->XDSEND[usb_dev_ptr->EP].SETUP_BUFFER_QUEUED = FALSE;
							/* Enqueue a recv buffer for receiving setup packet */
							_usb_device_recv_data((_usb_device_handle)usb_dev_ptr, usb_dev_ptr->EP, (uchar_ptr)&pxd->SETUP_BUFFER, 8);
							pxd->SETUP_BUFFER_QUEUED = TRUE;
							usb_dev_ptr->XDSEND[usb_dev_ptr->EP].SETUP_BUFFER_QUEUED = TRUE;
							} /* Endif */
						} /* Endif */

					} /* Endif */

				}

			if (status & VUSB_INT_STAT_TOKEN_DONE)
				continue;	/* done with EP0 Recv */
			}

/*
	N   N   OOO   TTTTT    EEEEE  PPPP    000       RRRR   EEEEE   CCC   V   V
	NN  N  O   O    T      E      P   P  0   0      R   R  E      C   C  V   V
	N N N  O   O    T      EEE    PPPP   0   0  ==  RRRR   EEE    C       V V 
	N  NN  O   O    T      E      P      0   0      R  R   E      C   C   V V 
	N   N   OOO     T      EEEEE  P       000       R   R  EEEEE   CCC     V  
*/
		if (status & VUSB_INT_STAT_TOKEN_DONE)
		{
			wBytes = VUSB_GET_BC(usb_dev_ptr->BDT_PTR);
			bToken = VUSB_GET_TOKEN(usb_dev_ptr->BDT_PTR);

			if (direction == USB_SEND)
			{
				pxd = &usb_dev_ptr->XDSEND[usb_dev_ptr->EP];
				pxdOther = &usb_dev_ptr->XDRECV[usb_dev_ptr->EP];
			}
			else
			{
				pxd = &usb_dev_ptr->XDRECV[usb_dev_ptr->EP];
				pxdOther = &usb_dev_ptr->XDSEND[usb_dev_ptr->EP];
			}

			pxd->SOFAR += wBytes;
			pxd->UNACKNOWLEDGEDBYTES -= wBytes;

			if ((bToken == TOKEN_SETUP) || (!(pxd->CTL & VUSB_ENDPT_HSHK_BIT)))
			{

				/* clear endpoint stall bit here in case of a protcol stall */
				endpt_reg[0] &= ~VUSB_EP_CTRL_STALL;

				/*
				** Setup packets always arrive in their entirety, as they're only 8
				** bytes and require no terminating null.  The same is true for
				** isochronous endpoints (which don't even get acknowledgements).
				*/
				/* The transfer has completed.  Reset the XD. */
				VUSB_CLEAR_CURRENT_BDT(usb_dev_ptr->BDT_PTR, pxd);
				if (pxd->PACKETPENDING)
				{
					/*
					** Any remaining BDT should be removed, as it's not needed to
					** complete this transaction.
					*/
					VUSB_CLEAR_OTHER_BDT(usb_dev_ptr->BDT_PTR, pxd);
				} /* Endif */

				pxd->BDTCTL = 0;
				pxd->STATUS = USB_STATUS_IDLE;
				_usb_device_call_service((_usb_device_handle)usb_dev_ptr, usb_dev_ptr->EP,
					/* If we have handshakes, it is a control endpoint -> setup */
					((pxd->CTL & VUSB_ENDPT_HSHK_BIT) ? 1 : 0),
					direction, pxd->STARTADDRESS, pxd->SOFAR, 0);

				/* Check if its Isochronous packet or Setup packet */
				if (pxd->CTL & VUSB_ENDPT_HSHK_BIT)
				{
					pxd->SETUP_BUFFER_QUEUED = FALSE;
					pxdOther->SETUP_BUFFER_QUEUED = FALSE;
	
					/* Enqueue a recv buffer for receiving setup packet */
					_usb_device_recv_data((_usb_device_handle)usb_dev_ptr, usb_dev_ptr->EP,
						(uchar_ptr)&usb_dev_ptr->XDRECV[usb_dev_ptr->EP].SETUP_BUFFER, 8);

					pxd->SETUP_BUFFER_QUEUED = TRUE;
					pxdOther->SETUP_BUFFER_QUEUED = TRUE;
				} /* Endif */
			}
			else if (wBytes == pxd->MAXPACKET)
			{
				VUSB_CLEAR_CURRENT_BDT(usb_dev_ptr->BDT_PTR, pxd);
				/*
				** If there is still data for which a BDT has not been sent, we must
				** send another BDT.  This includes zero-length BDTs on non-control
				** endpoints for transactions that are a multiple of the endpoint's
				** max packet size.
				*/
				if (pxd->TODO || pxd->MUSTSENDNULL)
				{
					pxd->STATUS = USB_STATUS_TRANSFER_IN_PROGRESS;
					_usb_dci_vusb11_submit_BDT(usb_dev_ptr->BDT_PTR, pxd);
				}
            /* CR 1445 */
				/*else if (pxd->PACKETPENDING  && pxd->UNACKNOWLEDGEDBYTES)*/
            else if (pxd->PACKETPENDING  || pxd->UNACKNOWLEDGEDBYTES)            
				{
					pxd->STATUS = USB_STATUS_TRANSFER_IN_PROGRESS;
				}
				else
				{ 
					pxd->BDTCTL = 0;
					pxd->STATUS = USB_STATUS_IDLE;

					_usb_device_call_service((_usb_device_handle)usb_dev_ptr,
						usb_dev_ptr->EP, 0, direction, pxd->STARTADDRESS, pxd->SOFAR, 0);
				} /* Endif */
			}
			else if (wBytes < pxd->MAXPACKET)
			{
				/*
				** If we have received a short packet, the transaction is complete
				** regardless of endpoint or the expected size.
				*/
				VUSB_CLEAR_CURRENT_BDT(usb_dev_ptr->BDT_PTR, pxd);

				if (pxd->PACKETPENDING)
				{
					/*
					** Any remaining BDT should be removed, as it's not needed to
					** complete this transaction.
					*/
					VUSB_CLEAR_OTHER_BDT(usb_dev_ptr->BDT_PTR, pxd);
				} /* Endif */

				pxd->BDTCTL = 0;
				pxd->STATUS = USB_STATUS_IDLE;

				_usb_device_call_service((_usb_device_handle)usb_dev_ptr, 
					usb_dev_ptr->EP, 0, direction, pxd->STARTADDRESS, pxd->SOFAR, 0);

				if (pxd->TYPE == USB_CONTROL_ENDPOINT)
				{
					/* protocol stall - stall the other BD */
					temp_BDT_PTR = VUSB_TOGGLE_BDT(usb_dev_ptr->BDT_PTR);
					/* Set the STALL bit */
					temp_BDT_PTR->PID_OWN_DATA01_BC |= (VUSB_BDT_STALL_BIT);
					/* Set the OWNS bit */
					temp_BDT_PTR->PID_OWN_DATA01_BC |= VUSB32_OWNS_BIT_MASK;
				}

			} /* Endif */
		} /* Endif Token done interrupt*/

		if (status & VUSB_INT_STAT_RESUME)
			{
			_usb_device_call_service((_usb_device_handle)usb_dev_ptr, USB_SERVICE_RESUME, 0 , 0, NULL, 0, 0);
			}  /* Endif */

		if (status & VUSB_INT_STAT_SOF)
			{
			_usb_device_call_service((_usb_device_handle)usb_dev_ptr, USB_SERVICE_SOF, 0 , 0, NULL, 0, 0);
			}  /* Endif */

		if (status & VUSB_INT_STAT_SLEEP)
			{
			_usb_device_call_service((_usb_device_handle)usb_dev_ptr, USB_SERVICE_SLEEP, 0 , 0, NULL, 0, 0);
			return;
			} /* Endif */

		if (status & VUSB_INT_STAT_ERROR)
			{
			_usb_device_call_service((_usb_device_handle)usb_dev_ptr, USB_SERVICE_ERROR, 0 , 0, NULL, dev_ptr->ERRORSTATUS, dev_ptr->ERRORSTATUS);
			} /* Endif */

		if (status & VUSB_INT_STAT_STALL)
			{
			_usb_device_call_service((_usb_device_handle)usb_dev_ptr, USB_SERVICE_STALL, 0 , 0, NULL, 
				(dev_ptr->INTSTATUS & VUSB_INT_STAT_STALL), 0);
			} /* Endif */

		} /* Endwhile */

#ifndef __USB_OS_MQX__
#ifndef __USB_OTG__
	IN_ISR = FALSE;
#endif   
#endif

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_isr, SUCCESSFUL");
   #endif


} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_submit_BDT
* Returned Value : None
* Comments       :
*     Submits a BDT (along with packet buffer) to the VUSB.
* 
*END*--------------------------------------------------------------------*/
void _usb_dci_vusb11_submit_BDT
   (
      /* [IN] Pointer to the BDT to be released to the VUSB */
      BDT_STRUCT_PTR pBDT,
      
      /* [IN] Pointer to the transfer descriptor (XD) for this BDT */
      XD_STRUCT_PTR pxd
   )
{ /* Body */
	uint_16  wActualBytes;
	BDT_STRUCT pid;
	uint_8_ptr	address;


   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_submit_BDT");
   #endif

	pid.PID_OWN_DATA01_BC = 0;

	pxd->NEXTODDEVEN = VUSB_TOGGLE_BIT(pxd->NEXTODDEVEN);

	address = pxd->NEXTADDRESS;

	/* Use the specified size */
	wActualBytes = pxd->TODO;

	if (pxd->TODO > pxd->MAXPACKET)
		{
		/* Unless we can't.  Then just use max packet size */
		wActualBytes = pxd->MAXPACKET;
		} /* Endif */

	/* compute the BDT */
	/* Copy everything from the XD */
	pid.PID_OWN_DATA01_BC = pxd->BDTCTL;
	/* Set Data Toggle Synch */
	pid.PID_OWN_DATA01_BC |= (VUSB_BDT_DTS_BIT);
	/* Sumbit the BDT */
	pid.PID_OWN_DATA01_BC |= (VUSB32_OWNS_BIT_MASK);

	/* if DATA01 is clear */
	if ((pxd->BDTCTL & VUSB_BDT_DATA01_BIT) == 0)
		{
		/* get value from bNextData01 */
		pid.PID_OWN_DATA01_BC |= (pxd->NEXTDATA01 << VUSB32_DATA01_BIT_POS);
		} /* Endif */

	/* clear DATA01 flag so we'll use bNextData01 next time */
	pxd->BDTCTL &= ~VUSB_BDT_DATA01_BIT;

	/* toggle bit for next packet */
	pxd->NEXTDATA01 = VUSB_TOGGLE_BIT(((pid.PID_OWN_DATA01_BC & VUSB32_DATA01_BIT_MASK) >> VUSB32_DATA01_BIT_POS));

	/* inc count of packets queued */
	pxd->PACKETPENDING++;

	/* Default is not to terminate with a null packet. */
	pxd->MUSTSENDNULL = FALSE;

	/*
	** if it is not an ISO endpoint
	** check if we need to 
	** terminate with a null packet
	*/
	if (pxd->CTL & VUSB_ENDPT_HSHK_BIT)
		{
		if (pxd->TODO == pxd->MAXPACKET)
			{
			/* Don't set the MUSTSENDNULL if it is a Setup packet */
			if (((pxd->TYPE != USB_CONTROL_ENDPOINT) && (!pxd->DONT_ZERO_TERMINATE)) || 
				((pxd->TYPE == USB_CONTROL_ENDPOINT) && (pxd->SETUP_BUFFER_QUEUED)))
				{
				pxd->MUSTSENDNULL = TRUE;
				} /* Endif */
			} /* Endif */
		} /* Endif */

	pxd->NEXTADDRESS += wActualBytes;
	pxd->TODO -= wActualBytes;

	pid.PID_OWN_DATA01_BC |= (((uint_32)(wActualBytes << 16)) & 0xFFFF0000);

	/* Actually write the BDT PID/DATA01/OWNS/BC data */

	if (pBDT == dbl_pbdt0recv[0])
		{
		/* don't release real bdts here */
		VUSB_SET_ADDRESS(&dbl_user[0], address);
		VUSB_COPY_OWN_DATA_PID(&dbl_user[0], &pid);
		}
	else if (pBDT == dbl_pbdt0recv[1])
		{
		/* don't release real bdts here */
		VUSB_SET_ADDRESS(&dbl_user[1], address);
		VUSB_COPY_OWN_DATA_PID(&dbl_user[1], &pid);
		}
	else
		{
		VUSB_SET_ADDRESS(pBDT, address);
		VUSB_COPY_OWN_DATA_PID(pBDT, &pid);
		}

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_submit_BDT, SUCCESSFUL");
   #endif
      
	return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_read_setup
* Returned Value : None
* Comments       :
*     Reads the setup packet into the buffer provided by the user.
* 
*END*--------------------------------------------------------------------*/
void _usb_dci_vusb11_read_setup
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle      handle,

      /* [IN] the Endpoint number */      
      uint_8                  ep_num,
            
      /* [IN] buffer for receiving Setup packet */
      uchar_ptr               buff_ptr
   )
{ /* Body */
   USB_DEV_STATE_STRUCT_PTR usb_dev_ptr;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_read_setup");
   #endif
   
   usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
   
   /* Copy the setup packet from the BD to the user's buffer */
   USB_memcopy((uchar_ptr)usb_dev_ptr->BDT_PTR->ADDRESS, buff_ptr, 8);

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_read_setup, SUCCESSFUL");
   #endif
   
   
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_submit_transfer
* Returned Value : None
* Comments       :
*     Submits a prepared transfer to the VUSB
* 
*END*--------------------------------------------------------------------*/
void _usb_dci_vusb11_submit_transfer
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle handle,
      
      /* [IN] Direction of transfer.  Is it transmit? */
      uint_8             direction,
      
      /* [IN] Endpoint to submit transfer on */
      uint_8             ep
   )
{ /* Body */
   USB_DEV_STATE_STRUCT_PTR usb_dev_ptr;
   XD_STRUCT_PTR pxd;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_submit_transfer");
   #endif
   
   usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
   
   if (direction == USB_SEND) {
      pxd = &usb_dev_ptr->XDSEND[ep];
   } else { 
      pxd = &usb_dev_ptr->XDRECV[ep];
   } /* Endif */
   
   if (pxd->TYPE == USB_CONTROL_ENDPOINT) {
      if ((pxd->CTL & VUSB_EP_CTRL_STALL) && (!direction)) {
         pxd->BDTCTL = (VUSB_BDT_DATA01_BIT | VUSB_EP_CTRL_STALL);
      } else {
         pxd->BDTCTL = VUSB_BDT_DATA01_BIT;
      } /* Endif */
   } else { 
      pxd->BDTCTL = 0;
   } /* Endif */
   
   /* Set the owns bit in the transfer descriptor */
   pxd->BDTCTL |= VUSB_BDT_OWNS_BIT;
   
   _usb_dci_vusb11_submit_BDT(
      &usb_dev_ptr->USB_BDT_PAGE[ep][direction][pxd->NEXTODDEVEN & 1], pxd);
      
   if (pxd->TODO || pxd->MUSTSENDNULL) {
      _usb_dci_vusb11_submit_BDT(
         &usb_dev_ptr->USB_BDT_PAGE[ep][direction][pxd->NEXTODDEVEN & 1], pxd);
   } /* Endif */

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_submit_transfer, SUCCESSFUL");
   #endif
   
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_bus_reset
* Returned Value : None
* Comments       :
*     Called when a USB bus reset is asserted by the host
* 
*END*--------------------------------------------------------------------*/
void _usb_dci_vusb11_bus_reset
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle handle
   )
{ /* Body */
	USB_DEV_STATE_STRUCT_PTR   usb_dev_ptr;
	USB_STRUCT _PTR_  dev_ptr;
	uchar                      i;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_bus_reset");
   #endif
   
	usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;

	dev_ptr = (USB_STRUCT _PTR_)usb_dev_ptr->USB;

	/* saw a USB Bus Reset
	**
	** we got the USB RESET indication. We simply need to go to the
	** DEFAULT state and enable endpoint 0 at addr 0.
	** First, assign EP0 an RX buffer
	*/

	/* Reset BDT page. */
   
   USB_memzero((void *)usb_dev_ptr->USB_BDT_PAGE, sizeof(VUSB_ENDPOINT_BDT_STRUCT) *
		usb_dev_ptr->MAX_ENDPOINTS * 2 * 2);
   
	usb_dev_ptr->USB_STATE = USB_STATE_DEFAULT;
	/* Current USB configuration is reset back to zero */
	usb_dev_ptr->USB_CURR_CONFIG = 0;

	/*
	** These are special hardware writes that clear the status FIFO which
	** is four bytes deep.
	**
	** clear pending token done
	*/
	dev_ptr->INTSTATUS = VUSB_INT_STAT_TOKEN_DONE;
	dev_ptr->INTSTATUS = VUSB_INT_STAT_TOKEN_DONE;
	dev_ptr->INTSTATUS = VUSB_INT_STAT_TOKEN_DONE;
	dev_ptr->INTSTATUS = VUSB_INT_STAT_TOKEN_DONE;

	/* Clear all interrupt */
	dev_ptr->INTSTATUS = 0xFF;

	/* USB addr=0 (default) */
	dev_ptr->ADDRESS = 0;

	/* clear the BDT ODD bits in the VUSB and keep VUSB enabled */
	dev_ptr->CONTROL = (VUSB_CTL_ODD_RST | VUSB_CTL_USB_EN);

	USB_memzero((uchar_ptr)usb_dev_ptr->XDSEND, sizeof(XD_STRUCT) * usb_dev_ptr->MAX_ENDPOINTS);

	USB_memzero((uchar_ptr)usb_dev_ptr->XDRECV, sizeof(XD_STRUCT) * usb_dev_ptr->MAX_ENDPOINTS);

	for (i = 0; i < usb_dev_ptr->MAX_ENDPOINTS; i++)
		{
		/*
		** initialize the endpoint status of all endpoints to Disabled
		** on Bus reset.
		*/
		usb_dev_ptr->XDSEND[i].STATUS = USB_STATUS_DISABLED;
		usb_dev_ptr->XDRECV[i].STATUS = USB_STATUS_DISABLED;
		} /* Endfor */


   /******************************************************
   Flush the BDTs to ensure that cache is written to memory
   *******************************************************/
   #ifdef  _DATA_CACHE_ 

   /*flush endpoint 0 cache line to ensure it is in sync with memory */ 
    _dcache_flush_mlines((void *)usb_dev_ptr->USB_BDT_PAGE,1);

   USB_dcache_invalidate_mlines((void *)usb_dev_ptr->USB_BDT_PAGE,1);

   USB_dcache_invalidate_line(dbl_buffer[0]);                      

   USB_dcache_invalidate_line(dbl_buffer[1]);                      
                         
   #endif

/* For double buffering of EP0, release two recv BDTs here. */

	VUSB_INIT_BDT(dbl_pbdt0recv[0],
                dbl_buffer[0],
                EP0_RECV_BUFFER_SIZE,
                VUSB_BDT_OWNS_BIT);

	VUSB_INIT_BDT(dbl_pbdt0recv[1],
                 dbl_buffer[1],
                 EP0_RECV_BUFFER_SIZE,
                 VUSB_BDT_OWNS_BIT);

	/* enable the VUSB */
	dev_ptr->CONTROL = VUSB_CTL_USB_EN;

	/*
	** enable all ints
	*/
	dev_ptr->INTENABLE = 0xFF; 

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_bus_reset, SUCCESSFUL");
   #endif
   
	return;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_get_address
* Returned Value : The device address
* Comments       :
*     Return the device address
* 
*END*--------------------------------------------------------------------*/
uint_16 _usb_dci_vusb11_get_address
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle handle
   )
{ /* Body */
   USB_DEV_STATE_STRUCT_PTR      usb_dev_ptr;
   volatile USB_STRUCT_PTR     dev_ptr;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_get_address");
   #endif

   usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
   dev_ptr = (volatile USB_STRUCT_PTR)usb_dev_ptr->USB;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_get_address, SUCCESSFUL");
   #endif
   
   return (dev_ptr->ADDRESS);
   
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_set_address
* Returned Value : None
* Comments       :
*     Sets the device address
* 
*END*--------------------------------------------------------------------*/
void _usb_dci_vusb11_set_address
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle   handle,
      
      /* [IN] the address to set */
      uint_16              address
   )
{ /* Body */
   USB_DEV_STATE_STRUCT_PTR      usb_dev_ptr;
   volatile USB_STRUCT_PTR     dev_ptr;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_set_address");
   #endif
   
   usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
   dev_ptr = (volatile USB_STRUCT_PTR)usb_dev_ptr->USB;

   dev_ptr->ADDRESS = address;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_set_address, SUCCESSFUL");
   #endif
   
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_init_endpoint
* Returned Value : None
* Comments       :
*     Sets the endpoint registers e.g. to enable TX, RX, control
* 
*END*--------------------------------------------------------------------*/
void _usb_dci_vusb11_init_endpoint
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle   handle,
            
      /* [IN] the endpoint number */
      uint_8               ep,
      
      /* [IN] The transfer descriptor for this endpoint */
      XD_STRUCT_PTR        pxd
   )
{ /* Body */
	USB_DEV_STATE_STRUCT_PTR      usb_dev_ptr;
	volatile USB_REGISTER _PTR_   endpt_reg;
	uint_32                       ep_enable_bit_masks;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_init_endpoint");
   #endif

	usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
	endpt_reg = (volatile USB_REGISTER _PTR_)usb_dev_ptr->ENDPT_REGS;

	switch (pxd->TYPE)
		{
		case USB_ISOCHRONOUS_ENDPOINT:
			ep_enable_bit_masks = (
				VUSB_ENDPT_CTL_EP_CTL_DIS | 
				VUSB_ENDPT_CTL_RETRY_DIS | 
				(pxd->DIRECTION ? VUSB_ENDPT_ISO_TX : VUSB_ENDPT_ISO_RX)
				);
			pxd->CTL |= ep_enable_bit_masks;
			endpt_reg[ep] |= ep_enable_bit_masks;
			break;
		case USB_INTERRUPT_ENDPOINT:
			ep_enable_bit_masks = (
				VUSB_ENDPT_HSHK_BIT | 
				VUSB_ENDPT_CTL_EP_CTL_DIS | 
				(pxd->DIRECTION ? VUSB_ENDPT_BULK_TX : VUSB_ENDPT_BULK_RX)
				);
			pxd->CTL |= ep_enable_bit_masks;
			endpt_reg[ep] |= ep_enable_bit_masks;
			break;
		case USB_CONTROL_ENDPOINT:
			pxd->CTL = VUSB_ENDPT_CONTROL;
			endpt_reg[ep] = VUSB_ENDPT_CONTROL;
			break;
		case USB_BULK_ENDPOINT:
			ep_enable_bit_masks = (
				VUSB_ENDPT_HSHK_BIT | 
				VUSB_ENDPT_CTL_EP_CTL_DIS | 
				(pxd->DIRECTION ? VUSB_ENDPT_BULK_TX : VUSB_ENDPT_BULK_RX)
				);
			pxd->CTL |= ep_enable_bit_masks;
			endpt_reg[ep] |= ep_enable_bit_masks;
		default:
			break;
		} /* Endswitch */

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_init_endpoint, SUCCESSFUL");
   #endif

	return;
} /* EndBody */

/* EOF */
