/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the low-level VUSB32 Device Controller Interface
***   (DCI) shut-down routine.
***                                                               
**************************************************************************
**END*********************************************************/
#include "devapi.h"
#include "usb.h"
#include "vusb32.h"
#include "usbprv.h"
#include "usbprv_dev.h"
#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
#endif


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_shutdown
* Returned Value : None
* Comments       :
*     Shutdown the device
* 
*END*--------------------------------------------------------------------*/
void _usb_dci_vusb11_shutdown
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle   handle
   )
{ /* Body */
      USB_DEV_STATE_STRUCT_PTR      usb_dev_ptr;
      volatile USB_STRUCT_PTR     dev_ptr;
      volatile USB_REGISTER _PTR_   endpt_reg;
      uint_8 i;

      #ifdef _DEVICE_DEBUG_
         DEBUG_LOG_TRACE("_usb_dci_vusb11_shutdown");
      #endif
      
      usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
      
      dev_ptr = (volatile USB_STRUCT_PTR)usb_dev_ptr->USB;
      endpt_reg = (volatile USB_REGISTER _PTR_)usb_dev_ptr->ENDPT_REGS;

      /* disable the VUSB */
      dev_ptr->CONTROL = 0;
      /* mask all interrupts */
      dev_ptr->INTENABLE = 0;
      
      /* disable all endpoints */
      for (i = 0; i < usb_dev_ptr->MAX_ENDPOINTS; i++) {
         endpt_reg[i] = VUSB_ENDPT_DISABLE;
      } /* Endfor */

      USB_memfree((pointer)usb_dev_ptr->DRIVER_MEMORY);

      
      #ifdef _DEVICE_DEBUG_
         DEBUG_LOG_TRACE("_usb_dci_vusb11_shutdown, SUCCESSFUL");
      #endif
      
} /* EndBody */

/* EOF */