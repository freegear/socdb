# VUSBHS device driver

MQX_INCDIRS      +=$(USB_ROOT)$(PS)source$(PS)device$(PS)vusbhs_dev

srcdirs += device$(PS)$(USB_DRIVER)_dev
device_srcs    += \
	vusb32_dev_cancel vusb32_dev_deinit vusb32_dev_main vusb32_dev_shut vusb32_dev_status

