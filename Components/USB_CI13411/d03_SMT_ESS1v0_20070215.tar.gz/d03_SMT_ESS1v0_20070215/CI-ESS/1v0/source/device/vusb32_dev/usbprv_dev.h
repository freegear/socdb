#ifndef __usbprv_dev_h__
#define __usbprv_dev_h__ 
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains definitions private to the USB Device API for VUSB.
***                                                               
**************************************************************************
**END*********************************************************/

#include <vusb32.h>

/* USB 1.1 token types */
#define TOKEN_SETUP                 (0x0d)
#define TOKEN_IN                    (0x9)
#define TOKEN_OUT                   (0x1)

/********some configurable macros */
#define EP0_RECV_BUFFER_SIZE  64



/* Structures */
/* Callback function storage structure */
typedef struct service_struct {
   uint_32              TYPE;
   void                 (_CODE_PTR_ SERVICE)(pointer,
      boolean, uint_8, uint_8_ptr, uint_32, uint_8);
   struct service_struct _PTR_ NEXT;
} SERVICE_STRUCT, _PTR_ SERVICE_STRUCT_PTR;

typedef BDT_STRUCT   VUSB_ENDPOINT_BDT_STRUCT[2][2],
                     (_PTR_ VUSB_ENDPOINT_BDT_STRUCT_PTR)[2][2];

typedef struct xd_struct {
   uint_8      STATUS;        /* Current transfer status */
   uint_8      DIRECTION;     /* direction */
   uint_8      BDTCTL;        /* USB BDT control byte*/
   uint_16     MAXPACKET;     /* Max Packet size */
   uint_8_ptr  STARTADDRESS;  /* address of first byte */
   uint_8_ptr  NEXTADDRESS;   /* address of next byte */
   uint_32     TODO;          /* number of bytes to send/recv */
   /* number of bytes not yet accounted for so far (not incl. pending BDTs) */
   uint_32     UNACKNOWLEDGEDBYTES;
   uint_32     SOFAR;         /* number of bytes received so far */
   /* Last packet zero-length if length == MAX_PACKET_SIZE */
   boolean     DONT_ZERO_TERMINATE;
   uint_8      TYPE;          /* Endpoint type */
   uint_8      CTL;           /* USB Endpoint Control byte */
   uint_8      NEXTDATA01;    /* Data 0/1 to use on next packet */
   uint_8      NEXTODDEVEN;   /* Odd/Even of Next BDT to queue */
   uint_8      LASTODDEVEN;   /* Odd/Even of Last BDT used */
   uint_8      PACKETPENDING; /* Number of queued packets on the VUSB. */
   uint_8      MUSTSENDNULL;  /* TRUE if last packet was full and not control */
   uint_8      SETUP_TOKEN_RECEIVED;
   uint_8      SETUP_BUFFER_QUEUED;
   uint_8      SETUP_BUFFER[8];
   uint_8      RESERVED1[XD_RESERVED_FOR_ALIGNMENT];  /* Padding to make 2^n byte structure */
} XD_STRUCT, _PTR_ XD_STRUCT_PTR;

/* The USB Device State structure */                     
typedef struct usb_dev_state_struct {
   pointer                       USB;
   #ifdef _DATA_CACHE_
   USB_REGISTER_PTR              ENDPT_REGS;
   #else
   pointer                       ENDPT_REGS;
   #endif
   BDT_STRUCT_PTR                BDT_PTR;
   uint_8_ptr                    USB_BDT_PAGE_BLOCK;
   VUSB_ENDPOINT_BDT_STRUCT_PTR  USB_BDT_PAGE;
   pointer                       CALLBACK_STRUCT_PTR;
   XD_STRUCT_PTR                 XDSEND;
   XD_STRUCT_PTR                 XDRECV;
   SERVICE_STRUCT_PTR            SERVICE_HEAD_PTR;
   uchar_ptr                     DRIVER_MEMORY;
   uint_16                       USB_STATE;
   uint_16                       USB_DEVICE_STATE;
   uint_16                       USB_SOF_COUNT;
   uint_8                        USB_CURR_CONFIG;
   uint_8                        EP;
   uint_8                        MAX_ENDPOINTS;
   uint_8                        DEV_NUM;
} USB_DEV_STATE_STRUCT, _PTR_ USB_DEV_STATE_STRUCT_PTR;

/* Prototypes */
/* USB device handle */
typedef  pointer  _usb_device_handle;

#ifdef __cplusplus
extern "C" {
#endif
extern void _usb_dci_vusb11_submit_BDT(BDT_STRUCT_PTR pBDT, XD_STRUCT_PTR pxd);
#ifndef __USB_OS_MQX__
extern DEVICE_INTERRUPT_ROUTINE_KEYWORD void _usb_dci_vusb11_isr(void);
#else
extern void _usb_dci_vusb11_isr(_usb_device_handle handle);
#endif
extern uint_8 _usb_dci_vusb11_init(_usb_device_handle handle);
extern void _usb_dci_vusb11_bus_reset(_usb_device_handle handle);
extern void _usb_dci_vusb11_unstall_endpoint(_usb_device_handle, uint_8);
extern uint_8 _usb_dci_vusb11_get_endpoint_status(_usb_device_handle, uint_8);
extern void _usb_dci_vusb11_set_endpoint_status(_usb_device_handle, uint_8, uint_8);
extern uint_16 _usb_dci_vusb11_get_address(_usb_device_handle);
extern void _usb_dci_vusb11_set_address(_usb_device_handle, uint_16);
extern void _usb_dci_vusb11_cancel_transfer(_usb_device_handle, uint_8, uint_8);
extern void _usb_dci_vusb11_submit_transfer(_usb_device_handle, uint_8, uint_8);
extern void _usb_dci_vusb11_init_endpoint(_usb_device_handle, uint_8, XD_STRUCT_PTR);
extern void _usb_dci_vusb11_deinit_endpoint(_usb_device_handle, uint_8, XD_STRUCT_PTR);
extern void _usb_dci_vusb11_shutdown(_usb_device_handle);
extern void _usb_dci_vusb11_assert_resume(_usb_device_handle);
extern void _usb_dci_vusb11_read_setup(_usb_device_handle, uint_8, uchar_ptr);
extern uint_8 _bsp_get_usb_vector(uint_8);
extern pointer _bsp_get_usb_base(uint_8);
#ifdef __cplusplus
}
#endif

#endif

/* EOF */
