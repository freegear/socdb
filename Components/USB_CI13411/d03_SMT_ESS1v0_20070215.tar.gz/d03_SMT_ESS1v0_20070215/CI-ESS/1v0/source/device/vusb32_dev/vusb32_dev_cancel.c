/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the low-level VUSB32 Device Controller Interface
***   (DCI) un-stall routines.
***                                                               
**************************************************************************
**END*********************************************************/
#include "devapi.h"
#include "usb.h"
#include "vusb32.h"
#include "usbprv.h"
#include "usbprv_dev.h"

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
#endif

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_unstall_endpoint
* Returned Value : None
* Comments       :
*     Unstalls and endpoint and clears out its BDTs
* 
*END*--------------------------------------------------------------------*/
void _usb_dci_vusb11_unstall_endpoint
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle handle,
      
      /* [IN] Endpoint to clear */
      uint_8 ep
   )
{

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_unstall_endpoint");
   #endif

   USB_DEV_STATE_STRUCT_PTR      usb_dev_ptr;
   USB_REGISTER_PTR   endpt_reg;
   
   usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
   endpt_reg = (USB_REGISTER_PTR)usb_dev_ptr->ENDPT_REGS;
   
   usb_dev_ptr->XDSEND[ep].CTL &= ~VUSB_EP_CTRL_STALL;
   usb_dev_ptr->XDRECV[ep].CTL &= ~VUSB_EP_CTRL_STALL;

   _usb_dci_vusb11_cancel_transfer(handle, USB_SEND, ep);
   _usb_dci_vusb11_cancel_transfer(handle, USB_RECV, ep);
   
   /* clear stall bit */
   endpt_reg[ep] &= ~VUSB_EP_CTRL_STALL;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_unstall_endpoint, SUCCESSFUL");
   #endif
   
   return;
}   

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_cancel_transfer
* Returned Value : None
* Comments       :
*     Cancels the BDTs on the specified endpoint in the specified direction.
* 
*END*--------------------------------------------------------------------*/
void _usb_dci_vusb11_cancel_transfer
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle handle,
      
      /* [IN] Direction to cancel */
      uint_8             direction,
      
      /* [IN] Endpoint to cancel */
      uint_8             ep
   )
{
   USB_DEV_STATE_STRUCT_PTR usb_dev_ptr;
   XD_STRUCT_PTR            pxd;
   BDT_STRUCT_PTR           BDT_PTR;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_cancel_transfer");
   #endif
   
   
   usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
   
   if (direction == USB_SEND) {
      pxd = &usb_dev_ptr->XDSEND[ep];
   } else {
      pxd = &usb_dev_ptr->XDRECV[ep];
   } /* Endif */

   /* If packet pending: 
   **    If 2 packets pending, dont toggle ODDEVEN
   **    If OWNS bit is set, disable ep reset owns toggle next oddeven
   ** . 
   */   
   
   if (pxd->PACKETPENDING == 1) {
      BDT_PTR = &usb_dev_ptr->USB_BDT_PAGE[ep][direction]\
         [VUSB_TOGGLE_BIT(pxd->NEXTODDEVEN)];
      if (BDT_PTR->PID_OWN_DATA01_BC & VUSB32_OWNS_BIT_MASK) {
         /* clear current BDT for this direction */
         VUSB_CLEAR_CURRENT_BDT(&usb_dev_ptr->USB_BDT_PAGE[ep][direction]\
            [VUSB_TOGGLE_BIT(pxd->NEXTODDEVEN)], pxd);
         pxd->NEXTODDEVEN = VUSB_TOGGLE_BIT(pxd->NEXTODDEVEN);
      } /* Endif */
   } /* Endif */

   if (pxd->PACKETPENDING == 2) {
      BDT_PTR = &usb_dev_ptr->USB_BDT_PAGE[ep][direction][pxd->NEXTODDEVEN];
      if (BDT_PTR->PID_OWN_DATA01_BC & VUSB32_OWNS_BIT_MASK) {
         /* clear current BDT for this direction */
         VUSB_CLEAR_CURRENT_BDT(&usb_dev_ptr->USB_BDT_PAGE[ep][direction]\
            [pxd->NEXTODDEVEN], pxd);
      } /* Endif */
      BDT_PTR = &usb_dev_ptr->USB_BDT_PAGE[ep][direction]\
         [VUSB_TOGGLE_BIT(pxd->NEXTODDEVEN)];
      if (BDT_PTR->PID_OWN_DATA01_BC & VUSB32_OWNS_BIT_MASK) {
         VUSB_CLEAR_CURRENT_BDT(&usb_dev_ptr->USB_BDT_PAGE[ep][direction]\
            [VUSB_TOGGLE_BIT(pxd->NEXTODDEVEN)], pxd);
      } /* Endif */
   } /* Endif */
   
   /* clear owns bit and flag as dequeued */
   pxd->BDTCTL = (uint_8)VUSB_BDT_DEQUEUED;

   /*
   ** Check the endpoint control register image to see if the endpoint
   ** is disabled or stalled, and update the status byte.
   */
   if (pxd->CTL & VUSB_ENDPT_STALL_BIT) {
      usb_dev_ptr->XDRECV[ep].STATUS = USB_STATUS_STALLED;
   } else { 
      pxd->STATUS = USB_STATUS_IDLE;
   } /* Endif */
   

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_cancel_transfer, SUCCESSFUL");
   #endif

   return;  
}   

/* EOF */