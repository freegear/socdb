/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the low-level VUSB32 Device Controller Interface
***   (DCI) status routines.
***                                                               
**************************************************************************
**END*********************************************************/
#include "devapi.h"
#include "usb.h"
#include "vusb32.h"
#include "usbprv.h"
#include "usbprv_dev.h"

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
#endif

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_get_endpoint_status
* Returned Value : None
* Comments       :
*     Gets the endpoint status
* 
*END*--------------------------------------------------------------------*/
uint_8 _usb_dci_vusb11_get_endpoint_status
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle handle,
      
      /* [IN] Endpoint to get */
      uint_8             ep
   )
{ /* Body */
   USB_DEV_STATE_STRUCT_PTR      usb_dev_ptr;
   volatile USB_REGISTER _PTR_   endpt_reg;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_get_endpoint_status");
   #endif
   
   usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
   endpt_reg = (volatile USB_REGISTER _PTR_)usb_dev_ptr->ENDPT_REGS;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_get_endpoint_status, SUCCESSFUL");
   #endif
   
   return ((endpt_reg[ep] & VUSB_EP_CTRL_STALL) ? 1 : 0);
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_set_endpoint_status
* Returned Value : None
* Comments       :
*     Sets the endpoint registers e.g. to enable TX, RX, control
* 
*END*--------------------------------------------------------------------*/
void _usb_dci_vusb11_set_endpoint_status
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle handle,
      
      /* [IN] Endpoint to set */
      uint_8             ep,
      
      /* [IN] Endpoint characteristics */
      uint_8             stall
   )
{
   USB_DEV_STATE_STRUCT_PTR      usb_dev_ptr;
   volatile USB_REGISTER _PTR_   endpt_reg;
   
   usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
   endpt_reg = (volatile USB_REGISTER _PTR_)usb_dev_ptr->ENDPT_REGS;
      
      if (stall) {
         /* the CTL byte is updated */
         usb_dev_ptr->XDSEND[ep].CTL |= VUSB_EP_CTRL_STALL;
         usb_dev_ptr->XDRECV[ep].CTL |= VUSB_EP_CTRL_STALL;
         endpt_reg[ep] |= VUSB_EP_CTRL_STALL;
      } else {
         /* the CTL byte is updated */
         usb_dev_ptr->XDSEND[ep].CTL &= ~VUSB_EP_CTRL_STALL;
         usb_dev_ptr->XDRECV[ep].CTL &= ~VUSB_EP_CTRL_STALL;
         usb_dev_ptr->XDSEND[ep].NEXTDATA01 = 0;
         usb_dev_ptr->XDRECV[ep].NEXTDATA01 = 0;
         endpt_reg[ep] &= ~VUSB_EP_CTRL_STALL;
      } /* Endif */      
      
} /* Endif */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_dci_vusb11_assert_resume
*  Returned Value : None
*  Comments       :
*        Resume signalling for remote wakeup
*
*END*-----------------------------------------------------------------*/
void _usb_dci_vusb11_assert_resume
   (
      /* [IN] the USB_dev_initialize state structure */
      _usb_device_handle         handle
   )
{ /* Body */

   USB_DEV_STATE_STRUCT_PTR      usb_dev_ptr;
   volatile USB_STRUCT_PTR     dev_ptr;
   uint_32  i;

   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_assert_resume");
   #endif
   
   usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;      
   dev_ptr = (volatile USB_STRUCT_PTR)usb_dev_ptr->USB;
   
   /* Turn on RESUME bit of the control register */
   dev_ptr->CONTROL |= VUSB_CTL_TXD_RESUME;
   
   /*
    * Device only needs to hold resume signal for a short while
    * before turning off RESUME bit for control register.
   */
   for (i=0; i<10; i++);
   
   /* Turn off RESUME bit of the control register now. */
   dev_ptr->CONTROL &= ~VUSB_CTL_TXD_RESUME;
   
   #ifdef _DEVICE_DEBUG_
      DEBUG_LOG_TRACE("_usb_dci_vusb11_assert_resume, SUCCESSFUL");
   #endif

} /* EndBody */

/* EOF */