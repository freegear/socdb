/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the low-level VUSB32 Device Controller Interface
***   (DCI) de-initialize routine.
***                                                               
**************************************************************************
**END*********************************************************/
#include "devapi.h"
#include "usb.h"
#include "vusb32.h"
#include "usbprv.h"
#include "usbprv_dev.h"

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
#endif

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_dci_vusb11_deinit_endpoint
* Returned Value : None
* Comments       :
*     Resets the endpoint registers e.g. to disable TX, RX, control
* 
*END*--------------------------------------------------------------------*/
void _usb_dci_vusb11_deinit_endpoint
   (
      /* [IN] Handle to the USB device */
      _usb_device_handle   handle,
            
      /* [IN] the endpoint number */
      uint_8               ep,
      
      /* [IN] The transfer descriptor for this endpoint */
      XD_STRUCT_PTR        pxd
   )
{ /* Body */
      USB_DEV_STATE_STRUCT_PTR      usb_dev_ptr;
      USB_REGISTER_PTR   endpt_reg;

      #ifdef _DEVICE_DEBUG_
         DEBUG_LOG_TRACE("_usb_dci_vusb11_deinit_endpoint");
      #endif
      
      usb_dev_ptr = (USB_DEV_STATE_STRUCT_PTR)handle;
      endpt_reg = (USB_REGISTER_PTR)usb_dev_ptr->ENDPT_REGS;
      
      switch (pxd->TYPE) {
         case USB_ISOCHRONOUS_ENDPOINT:
            pxd->CTL = 0;
            endpt_reg[ep] &= ~VUSB_ENDPT_ISO_BIDIR;
            break;
         case USB_INTERRUPT_ENDPOINT:
            pxd->CTL = 0;
            endpt_reg[ep] &= ~VUSB_ENDPT_BULK_BIDIR;
            break;
         case USB_CONTROL_ENDPOINT:
            pxd->CTL = 0;
            endpt_reg[ep] &= ~VUSB_ENDPT_CONTROL;
            break;
         case USB_BULK_ENDPOINT:
            pxd->CTL = 0;
            endpt_reg[ep] &= ~VUSB_ENDPT_BULK_BIDIR;
         default:
            break;
      } /* Endswitch */

      #ifdef _DEVICE_DEBUG_
         DEBUG_LOG_TRACE("_usb_dci_vusb11_deinit_endpoint, SUCCESSFUL");
      #endif
      
} /* EndBody */

/* EOF */