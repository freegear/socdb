// otg_i2c.h

// contains definitions for interfacing with otg via i2c


typedef struct
	{
	uint_8		SOURCE;
	uint_8		LATCH;
	uint_8		FALLING;
	uint_8		RISING;
	} OTG_I2C_REGISTERS;

extern OTG_I2C_REGISTERS	I2C;

_Interrupt1 void otg_i2c_isr();

void otg_i2c_init(USB_OTG_STATE_STRUCT_PTR usb_otg_ptr);


