// i2c.c

#ifdef __USB_OTG__
#include "otgapi.h"
#include "usbprv_otg.h"
#else
#include "hostapi.h"
#include "devapi.h"
#endif
//#include "demo_d.h"
//#include "demo.h"
//#include "demo_h.h"
#ifdef __USB_OS_MQX__
//   #include "bsp.h"
//   #include "mqx_arc.h"
#else
/* skip the inclusion in dependency statge */
#ifndef __NO_SETJMP
   #include "stdio.h"
#endif   
   #include "stdlib.h"
#endif

#include "i2c.h"
#include "sa_uart.h"

static uint_8 count = 0;

#define DEBUG_SET_CLR			0
#define DEBUG_STATE_AND_DELTA	0

volatile uint_8	*i2c_base_addr;

P1301_REGS	p1301Regs;

uint_8 why_me(uint_8 this)	// this function prevents the debugger from lying
{							// about the value of 'u'.  without it, 'r14' never
	return this;			// gets updated with the value returned from 
}							// get1301()

uint_32	i2cCount = 1;

// this function should never get called because we disable all i2c interrupts.

#ifdef __USB_OS_MQX__
void isrI2C
   (
      /* [IN] the USB Host state structure */
      pointer        ignore_me
   )
#else
void HOST_INTERRUPT_ROUTINE_KEYWORD isrI2C
   (
      void
   )
#endif
{

//	I2C_INTERRUPT = 0xff;	// clear all interrupts

	i2cCount++;
	return;
}

#ifdef __USB_OS_MQX__
void isrMemRef
   (
      /* [IN] the USB Host state structure */
      pointer        ignore_me
   )
#else
void HOST_INTERRUPT_ROUTINE_KEYWORD isrMemRef
   (
      void
   )
#endif
{
	// trap invalid memory references to learn what code caused them
	uartputs("\nisrMemRef\n");
	uartflush();
	return;
}

extern _usb_otg_handle	app_otg_handle;

#ifdef __USB_OS_MQX__
void isr1301
   (
      /* [IN] the USB Host state structure */
      pointer        ignore_me
   )
#else
void HOST_INTERRUPT_ROUTINE_KEYWORD isr1301
   (
      void
   )
#endif
{
	read1301StateAndDelta("\nisr1301", TRUE);
	processOTGevent((USB_OTG_STATE_STRUCT_PTR)app_otg_handle, TRUE);

//uartputs("\nisr1301: done.");

	return;
}

void read1301StateAndDelta(char *desc, boolean bClearDelta)
{

// We need to read the "interrupt state" and "interrupt delta" registers.
// Because i2c is ssssllloooowww, we MUST read delta first.
// After reading delta, we clear the delta bits.
// Then we read the state byte.

// When we read 'state' first, we got into a scenario where we saw VBUS=FALSE
// but while reading 'delta', VBUS went TRUE.  We were left believing that VBUS 
// had changed and was FALSE when in fact it had changed twice and was now TRUE.
// This usually happened when entering A_WAIT_VRISE, causing us to wait until
// TA_WAIT_VRISE_TMR expired.  This made OPT 4.3 fail.

	p1301Regs.delta   = get1301(REG_1301_INTERRUPT_DELTA);

	if (bClearDelta)
		clr1301(REG_1301_INTERRUPT_DELTA, p1301Regs.delta);	// clear bits now that we've seen them

	p1301Regs.state  = get1301(REG_1301_INTERRUPT_STATE);

#if DEBUG_STATE_AND_DELTA
	if (desc)	// if desc is NULL, we don't want debug output
		{
#if 1
		uartputs(desc);
		uartputs(":[s=");
		uartput8(p1301Regs.state);
		uartputs(",d=");
		uartput8(p1301Regs.delta);
#if 1
		if (p1301Regs.delta & P1301_B_SESS_END)	// if this changed
			{
			if (p1301Regs.state & P1301_B_SESS_END)
				uartputs(" +B_SESS_END");
			else
				uartputs(" -B_SESS_END");
			}
		if (p1301Regs.delta & (1<<5))		// if this changed
			{
			if (p1301Regs.state & (1<<5))
				uartputs(" +ID_F");
			else
				uartputs(" -ID_F");
			}
		if (p1301Regs.delta & (1<<4))		// if this changed
			{
			if (p1301Regs.state & (1<<4))
				uartputs(" +ID_R");
			else
				uartputs(" -ID_R");
			}
		if (p1301Regs.delta & P1301_ID_GND)	// if this changed
			{
			if (p1301Regs.state & P1301_ID_GND)
				uartputs(" +ID_GND");
			else
				uartputs(" -ID_GND");
			}
		if (p1301Regs.delta & P1301_SESS_VLD)	// if this changed
			{
			if (p1301Regs.state & P1301_SESS_VLD)
				uartputs(" +SESS_VLD");
			else
				uartputs(" -SESS_VLD");
			}
		if (p1301Regs.delta & P1301_VBUS_VLD)	// if this changed
			{
			if (p1301Regs.state & P1301_VBUS_VLD)
				uartputs(" +VBUS_VLD");
			else
				uartputs(" -VBUS_VLD");
			}
#endif
		uartputc(']');
#endif
		}
#endif

	return;
}


void initMemRef(void)	// handle int1, memory reference errors
{

	USB_install_isr(1, isrMemRef, 0);

	return;
}


void i2cInit(void)
{
	uint_32		priority_levels;

	USB_install_isr(7, isrI2C, 0);

	USB_install_isr(8, isr1301, 0);

	// set all interrupts to level 1 priority
	// 
	// priority level is set with AUX_IRQ_LEV aux reg (0x200). see pg 15
	// Tangent-A4 Ancillary Components Reference doc
	// 0 = priority level 1
	// 1 = priority level 2

	priority_levels = read_aux_reg(AUX_IRQ_LEV);
	// set interrupts 3-31 to priority level 1
	priority_levels &= 0x007; 
	write_aux_reg(priority_levels,AUX_IRQ_LEV);


	// get peripheral base address value.  Read from Build Configuration 
	// Register located at 0x69 in aux space.  Returns something like 0x00fc0001 
	// but the bottom eight bits are the BCR version number so we will mask
	// them off

	i2c_base_addr = (volatile uint_8 *)
		(
			(read_aux_reg(BCR_PERIPHERAL_BASE_ADDR) & 0xffffff00) +
			PERIPHERAL_OFFSET_TO_I2C
		);

	// set the clock divider to run at 100kbs
	I2C_CLOCK_DIV_HI = 0x00;
	I2C_CLOCK_DIV_LO = 0x70;

	// disable all the interrupts
	// we poll the interrupt status register ourselves
	I2C_ENABLE = 0x00;

	// put I2C into master mode
	I2C_MODE = 0x01;

	return;
}



void	enable1301(uint_8 bEnable)
{
#if 0
	{
	uint_8	u;

	setclr1301(REG_1301_FALLING_EDGE, 0x00, 0xff);
	u = get1301(REG_1301_FALLING_EDGE);
	why_me(u);
	if (u != 0x00)	_flag(1);

	setclr1301(REG_1301_FALLING_EDGE, 0xff, 0x00);
	u = get1301(REG_1301_FALLING_EDGE);
	why_me(u);
	if (u != 0xff)	_flag(1);

	set1301(REG_1301_FALLING_EDGE, 0xff);
	u = get1301(REG_1301_FALLING_EDGE);
	why_me(u);
	if (u != 0xff)	_flag(1);

	setclr1301(REG_1301_FALLING_EDGE, 0x00, 0xaa);
	u = get1301(REG_1301_FALLING_EDGE);
	why_me(u);
	if (u != 0x55)	_flag(1);

	setclr1301(REG_1301_FALLING_EDGE, 0xaa, 0x55);
	u = get1301(REG_1301_FALLING_EDGE);
	why_me(u);
	if (u != 0xaa)	_flag(1);

	setclr1301(REG_1301_FALLING_EDGE, 0x0f, 0xf0);
	u = get1301(REG_1301_FALLING_EDGE);
	why_me(u);
	if (u != 0x0f)	_flag(1);

	setclr1301(REG_1301_FALLING_EDGE, 0xf0, 0x0f);
	u = get1301(REG_1301_FALLING_EDGE);
	why_me(u);
	if (u != 0xf0)	_flag(1);

	setclr1301(REG_1301_FALLING_EDGE, 0x55, 0xaa);
	u = get1301(REG_1301_FALLING_EDGE);
	why_me(u);
	if (u != 0x55)	_flag(1);

	setclr1301(REG_1301_FALLING_EDGE, 0xaa, 0x55);
	u = get1301(REG_1301_FALLING_EDGE);
	why_me(u);
	if (u != 0xaa)	_flag(1);
	}
#endif

	if (bEnable)
		{
		clr1301(REG_1301_INTERRUPT_DELTA, 0xff);
		setclr1301(REG_1301_FALLING_EDGE, 0xcf, 0x30);	// enable some disable others
		setclr1301(REG_1301_RISING_EDGE, 0xcf, 0x30);	// enable some disable others
		}
	else
		{
		clr1301(REG_1301_INTERRUPT_DELTA, 0xff);
		clr1301(REG_1301_FALLING_EDGE, 0xff);			// disable all 8
		clr1301(REG_1301_RISING_EDGE, 0xff);			// disable all 8
		}

	// init these registers as we don't get an interrupt to prompt us
	// to read the initial values

	read1301StateAndDelta("\nenable1301", FALSE);

	return;
}


#define MAX_WAIT_LOOP_SIZE 1000000

#if DEBUG_SET_CLR
void dumpBits(char *desc, uint_8 reg_addr, uint_8 bits)
{
	uartputs(desc);
	switch (reg_addr)
		{
#if 1
		case REG_1301_OTG_CONTROL:
			uartputs("OTG_CONTROL <-");
			if (bits & P1301_VBUS_CHARGE)
				uartputs(" VBUS_CHARGE");
			if (bits & P1301_VBUS_DISCHARGE)
				uartputs(" VBUS_DISCHARGE");
			if (bits & P1301_VBUS_DRV)
				uartputs(" VBUS_DRV");
			if (bits & P1301_ID_PULLDOWN)
				uartputs(" ID_PULLDOWN");
			if (bits & P1301_DM_PULLDOWN)
				uartputs(" DM_PULLDOWN");
			if (bits & P1301_DP_PULLDOWN)
				uartputs(" DP_PULLDOWN");
			if (bits & P1301_DM_PULLUP)
				uartputs(" DM_PULLUP");
			if (bits & P1301_DP_PULLUP)
				uartputs(" DP_PULLUP");
			break;

		case REG_1301_MODE_CONTROL1:
			uartputs("MODE_CONTROL1 <-");
			if (bits & (1<<5))
				uartputs(" OE_INT_EN");
			if (bits & (1<<4))
				uartputs(" BDIS_ACON_EN");
			if (bits & (1<<3))
				uartputs(" TRANSP_EN");
			if (bits & (1<<2))
				uartputs(" DAT_SE0");
			if (bits & (1<<1))
				uartputs(" SUSPEND_REG");
			if (bits & (1<<0))
				uartputs(" SPEED_REG");
			break;

		case REG_1301_MODE_CONTROL2:
			uartputs("MODE_CONTROL2 <-");
			if (bits & (1<<4))
				uartputs(" TRANSP_BIR1");
			if (bits & (1<<3))
				uartputs(" TRANSP_BDIR0");
			if (bits & (1<<2))
				uartputs(" BI_DI");
			if (bits & (1<<1))
				uartputs(" SPS_SUSP_CTRL");
			if (bits & (1<<0))
				uartputs(" GLOBAL_PWR_DN");
			break;

		case REG_1301_INTERRUPT_DELTA:
		case REG_1301_FALLING_EDGE:
		case REG_1301_RISING_EDGE:
			if (reg_addr == REG_1301_INTERRUPT_DELTA)
				uartputs("DELTA <-");
			else if (reg_addr == REG_1301_FALLING_EDGE)
				uartputs("FALLING <-");
			else
				uartputs("RISING <-");
			if (bits & (1<<7))
				uartputs(" B_SESS_END");
			if (bits & (1<<6))
				uartputs(" BDIS_ACON");
			if (bits & (1<<5))
				uartputs(" ID_FLOAT");
			if (bits & (1<<4))
				uartputs(" ID_RESISTIVE");
			if (bits & (1<<3))
				uartputs(" ID_GND");
			if (bits & (1<<2))
				uartputs(" DP_SRP");
			if (bits & (1<<1))
				uartputs(" SESS_VLD");
			if (bits & (1<<0))
				uartputs(" VBUS_VLD");
			break;
#endif

		default:
			uartput8(reg_addr);
			uartputs(" <- ");
			uartput8(bits);
			break;
		}
	return;
}

#endif

////////////////////////////////////////////////////////////////////////
// setclr1301
//
// description: set bits in one register, clear bits in the next register in the 1301
////////////////////////////////////////////////////////////////////////
void setclr1301(uint_8 reg_addr, uint_8 bitsToSet, uint_8 bitsToClear)
{
	uint_8	xfer_succeeded = 0;
	uint_32		i;
	uint_8		u;

count++;

#if DEBUG_SET_CLR
//if (reg_addr == REG_1301_OTG_CONTROL)
	{
	dumpBits("\nset1301:", reg_addr, bitsToSet);
	dumpBits("\nclr1301:", reg_addr, bitsToClear);
	}
#endif

	if (reg_addr & 1)	// "sets" are done on even addresses
		{
		uartputs("\nsetclr1301: addr is odd");
		uartflush();
		HALT_CPU(BASE_I2C_TEST_CODE | FAILED);
		}

	// write the control register
	I2C_CONTROL = I2C_CONTROL_HOLD;

	// write the transfer count register
	I2C_COUNT = 0x03;

	// the first byte of data is the register address
	I2C_DATA = reg_addr;
	// the second byte of data is the actual bits to set
	I2C_DATA = bitsToSet;
	// the third byte of data is the actual bits to clear
	I2C_DATA = bitsToClear;

	// Write the address, this will also start the transfer
	I2C_ADDRESS_LO = 0x2c;

	// wait for transfer to finish on the bus
	for (i=0; i < MAX_WAIT_LOOP_SIZE; i++)
		{
		u = I2C_INTERRUPT;
		if (u & I2C_INT_DONE)
			{
			xfer_succeeded = 1;
			I2C_INTERRUPT = I2C_INT_DONE;
			break;
			}
		}

	if (!xfer_succeeded)
		{
		uartputs("\nsetclr1301: xfer failed addr=");
		uartput8(reg_addr);
		uartputs(" count=");
		uartput8(count);
		uartflush();
		HALT_CPU(BASE_I2C_TEST_CODE | FAILED);
		}

	I2C_INTERRUPT = I2C_INT_DONE; // clear the done interrupt

count--;
}

////////////////////////////////////////////////////////////////////////
// set1301
//
// description: set bits in a register in the 1301
////////////////////////////////////////////////////////////////////////
void set1301(uint_8 reg_addr, uint_8 bitsToSet)
{
	uint_8	xfer_succeeded = 0;
	uint_32		i;
	uint_8		u;

count++;

#if DEBUG_SET_CLR
//if (reg_addr == REG_1301_OTG_CONTROL)
	{
	dumpBits("\nset1301:", reg_addr, bitsToSet);
	}
#endif

	
	if (reg_addr & 1)	// "sets" are done on even addresses
		{
		uartputs("\nset1301: addr is odd");
		uartflush();
		HALT_CPU(BASE_I2C_TEST_CODE | FAILED);
		}

	// write the control register
	I2C_CONTROL = I2C_CONTROL_HOLD;

	// write the transfer count register
	I2C_COUNT = 0x02;

	// the first byte of data is the register address
	I2C_DATA = reg_addr;
	// the second byte of data is the actual data
	I2C_DATA = bitsToSet;

	// Write the address, this will also start the transfer
	I2C_ADDRESS_LO = 0x2c;

	// wait for transfer to finish on the bus
	for (i=0; i < MAX_WAIT_LOOP_SIZE; i++)
		{
		u = I2C_INTERRUPT;
		if (u & I2C_INT_DONE)
			{
			xfer_succeeded = 1;
			I2C_INTERRUPT = I2C_INT_DONE;
			break;
			}
		}

	if (!xfer_succeeded)
		{
		uartputs("\nset1301: xfer failed addr=");
		uartput8(reg_addr);
		uartputs(" count=");
		uartput8(count);
		uartflush();
		HALT_CPU(BASE_I2C_TEST_CODE | FAILED);
		}

	I2C_INTERRUPT = I2C_INT_DONE; // clear the done interrupt

count--;
}

////////////////////////////////////////////////////////////////////////
// clr1301
//
// description: clear bits in a register in the 1301
////////////////////////////////////////////////////////////////////////
void clr1301(uint_8 reg_addr, uint_8 bitsToClear)
{
	uint_8	xfer_succeeded = 0;
	uint_32		i;
	uint_8		u;
	uint_8		retries = 0;

count++;

#if DEBUG_SET_CLR
//if (reg_addr == REG_1301_OTG_CONTROL)
	{
	dumpBits("\nclr1301:", reg_addr, bitsToClear);
	}
#endif

	if (reg_addr & 1)	// "clears" are done on odd addresses
		{				// we expect an even address and we'll make it odd
		uartputs("\nclr1301: addr is odd");
		uartflush();
		HALT_CPU(BASE_I2C_TEST_CODE | FAILED);
		}

retry:
	// write the control register
	I2C_CONTROL = I2C_CONTROL_HOLD;

	// write the transfer count register
	I2C_COUNT = 0x02;

	// the first byte of data is the register address
	I2C_DATA = reg_addr | 1;
	// the second byte of data is the actual data
	I2C_DATA = bitsToClear;

	// Write the address, this will also start the transfer
	I2C_ADDRESS_LO = 0x2c;

	// wait for transfer to finish on the bus
	for (i=0; i < MAX_WAIT_LOOP_SIZE; i++)
		{
		u = I2C_INTERRUPT;
		if (u & I2C_INT_DONE)
			{
			xfer_succeeded = 1;
			I2C_INTERRUPT = I2C_INT_DONE;
			break;
			}
		}

	if (!xfer_succeeded)
		{
		if (!retries)
			{
			uartputs("\nclr1301: xfer failed addr=");
			uartput8(reg_addr);
			uartputs(" count=");
			uartput8(count);
			}
		uartputc('#');
		uartputc('0' + retries);
		retries++;
		if (retries < 10)
			goto retry;
		uartflush();
//		HALT_CPU(BASE_I2C_TEST_CODE | FAILED);
		}

	I2C_INTERRUPT = I2C_INT_DONE; // clear the done interrupt

count--;
}

////////////////////////////////////////////////////////////////////////
// get1301
//
// description: read a register in the 1301
//
// We should be able to read more than one byte at a time, BUT, 
// when we read 3 bytes at REG_1301_INTERRUPT_STATE, it hoses
// the OTG interrupt.  Therefore, we'll read one byte at a time.
////////////////////////////////////////////////////////////////////////
uint_8 get1301(uint_8 reg_addr)
{
	uint_32		i;
	uint_8		xfer_succeeded = 0;
	uint_8		ctl_temp;
	uint_8		u;
	uint_8		retCode;
	uint_8		retries = 0;

count++;

retry:
	// write the control register
	I2C_CONTROL = I2C_CONTROL_HOLD_BUS | I2C_CONTROL_HOLD;

	// write the transfer count register
	I2C_COUNT = 0x01;

	// first must write the address register
	I2C_DATA = reg_addr;

	// Write the address, this will also start the transfer
	I2C_ADDRESS_LO = 0x2c;

	// wait for transfer to finish on the bus
	for (i=0; i < MAX_WAIT_LOOP_SIZE; i++)
		{
		u = I2C_INTERRUPT;
		if (u & I2C_INT_DONE)
			{
			xfer_succeeded = 1;
			I2C_INTERRUPT = I2C_INT_DONE;
			break;
			}
		}

	if (!xfer_succeeded)
		{
		if (!retries)
			{
			uartputs("\nget1301: xfer failed 1 addr=");
			uartput8(reg_addr);
			uartputs(" count=");
			uartput8(count);
			}
		uartputc('#' );
		uartputc('0' + retries);
		uartflush();
		retries++;
		if (retries < 10)
			goto retry;
		retCode = 0;
		goto done;
//		HALT_CPU(BASE_I2C_TEST_CODE | FAILED);
		}

	I2C_INTERRUPT = I2C_INT_DONE; // clear the done interrupt

	// now receive the data
	// write the control register
	I2C_CONTROL = I2C_CONTROL_RDWR | I2C_CONTROL_HOLD;

	// write the transfer count register
	I2C_COUNT = 1;

	// write the address to start the transfer
	I2C_ADDRESS_LO = 0x2c;

	// wait for transfer to finish on the bus
	xfer_succeeded = 0;
	for (i=0; i < MAX_WAIT_LOOP_SIZE; i++)
		{
		u = I2C_INTERRUPT;
		if (u & I2C_INT_DONE)
			{
			xfer_succeeded = 1;
			I2C_INTERRUPT = I2C_INT_DONE;
			break;
			}
		}

	if (!xfer_succeeded)
		{
		if (!retries)
			{
			uartputs("\nget1301: xfer failed 2 addr=");
			uartput8(reg_addr);
			uartputs(" count=");
			uartput8(count);
			}
		uartputc('#');
		uartputc('0' + retries);
		uartflush();

// set the clock divider to run at 100kbs
I2C_CLOCK_DIV_HI = 0x00;
I2C_CLOCK_DIV_LO = 0x70;

// disable all the interrupts
// we poll the interrupt status register ourselves
I2C_ENABLE = 0x00;

// put I2C into master mode
I2C_MODE = 0x01;

		retries++;
		if (retries < 10)
			goto retry;
		retCode = 0;
		goto done;
//		HALT_CPU(BASE_I2C_TEST_CODE | FAILED);
		}

	I2C_INTERRUPT = I2C_INT_DONE; // clear the done interrupt

	ctl_temp = I2C_CONTROL;
	retCode = I2C_DATA;

	I2C_CONTROL = ctl_temp | I2C_CONTROL_POP_FIFO;

done:

count--;
	return retCode;
}

