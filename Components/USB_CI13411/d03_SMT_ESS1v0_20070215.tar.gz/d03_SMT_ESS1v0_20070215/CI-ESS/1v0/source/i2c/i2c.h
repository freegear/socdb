// i2c.h

typedef volatile uint_8 *PREG;

#define read_aux_reg(addr)		_lr(addr)		// Load r0 with what's @ addr

#define write_aux_reg(val,addr)	_sr(val,addr)	// store val @ addr

// Aux space build configuration registers
#define BCR_PERIPHERAL_BASE_ADDR	0x69
#define AUX_IRQ_LEV					0x200	// see pg 15 Tangent-A4 Ancillary Components Reference doc


#define PERIPHERAL_OFFSET_TO_I2C	0x7000

// Russell did the math.
// One pointer to the base of i2c I/O space is much more efficeint than
// individual pointers to each register.
extern volatile uint_8	*i2c_base_addr;

void initMemRef(void);

void	i2cInit(void);
void	enable1301(uint_8 bEnable);


#define HALT_CPU(val)	 _core_write(val,25);_flag(1)	// stop when critical error is detected


//
// test code syntax:  (see $ARCHOME/tests/files/metaware/code.s)
// 3  2 2  2 2       1 1
// 1  8 7  4 3       6 5            4 3  0
//
// 0000.0000.0000.0000.0000.0000.0000.0000
// -+-- -+-- ------+-- ---------+---- -+--
//  |    |         |            |      |
//  |    |         |            |      +--> Error Definition
//  |    |         |            |
//  |    |         |            +---------> Part under test
//  |    |         |
//  |    |         +----------------------> Error Number
//  |    |
//  |    +--------------------------------> Test System
//  |
//  +-------------------------------------> Responsible Dept

// test code constants
//
//                           8 ------ Nashua (Responsible Dept.)
//                            3 ----- VHDL TB (Test System)
//                                7 - I2C (Part under Test)
#define BASE_I2C_TEST_CODE 0x83000700 // 8 - Nashua 3 - VHDL 1 - VUART

// Error Definitions
#define PASSED  0x00000001
#define WARNING 0x00000002
#define FAILED  0x00000003

// Part Under Test
//
// Nashua syntax for 'Part Under Test' subclass
//
// 0000.0000.0000
// ^^^^^^^^^ ^^^^
//     |       |
//     |       +- Peripheral Number: 1-15
//     +--------- Peripheral Type(1-255):   1 = vuart
//                                          2 = vmac


////////////////////////////////////////////////////////////////////////////////
///////                        I/O MAP                                  ////////
////////////////////////////////////////////////////////////////////////////////


/*	Peripheral ID register (PER_ID 00)
	Access:  Read Only
	Address: 0x00
	Code Reference:  id_field

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   0    |   0    |                       ID(5:0)                       |
	+--------+--------+--------+--------+--------+--------+--------+--------+
*/
#define I2C_PERIPHERAL_ID		i2c_base_addr[0x00]

/*	Peripheral ID complement register (ID_COMP 04)
	Access:  Read Only
	Address: 0x04
	Code Reference:  id_comp

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   1    |   1    |                      !ID(5:0)                       |
	+--------+--------+--------+--------+--------+--------+--------+--------+
*/
#define I2C_ID_COMPLEMENT		i2c_base_addr[0x04]


/*	Peripheral revision register (REV 08)
	Access:  Read Only
	Address: 0x08
	Code Reference:  rev

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|                               REV(7:0)                                |
	+--------+--------+--------+--------+--------+--------+--------+--------+
*/
#define I2C_REVISION		i2c_base_addr[0x08]


/*	Peripheral additional info register (ADD_INFO 0C)
	Access:  Read Only
	Address: 0x0C
	Code Reference:  add_info

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|                                  TBD                                  |
	+--------+--------+--------+--------+--------+--------+--------+--------+
*/
#define I2C_ADDITIONAL_INFO		i2c_base_addr[0x0c]


/*	Clock Divisor Low (CLK_DIV_LOW 10)
	Access:  Read/Write
	Address: 0x10
	Code Reference:  clk_div_low

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|                           CLK_DIVISOR(7:0)                            |
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Divisor for clock divider low byte. 
*/
#define I2C_CLOCK_DIV_LO		i2c_base_addr[0x10]


/*	Clock Divisor (CLK_DIV_HI 14)
	Access:  Read/Write
	Address: 0x14
	Code Reference:  clk_div_hi

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|                           CLK_DIVISOR(15:8)                           |
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Divisor for clock divider high byte.
*/
#define I2C_CLOCK_DIV_HI		i2c_base_addr[0x14]


/*	Interrupt status register (INT_STAT 18)
	Access:  Write '1' to clear???
	Address: 0x18
	Code Reference:  int_stat

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|  rsvd  |  rsvd  |FIFO_ERR|   TO   |  NACK  |  ARB   |  DATA  |  DONE  |
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Name				Description
	FIFO_ERR	BOTH	one of the fifo error conditions caused interrupt, the 
						FIFO_ERR register will contain more information
	TO			MASTER	slave held SCL low longer than max timeout time
				SLAVE	unused
	NACK		MASTER	slave nack'd transfer
				SLAVE	On read this bit is set when the master completes a 
						transfer while there is still data to be transmitted in 
						the fifo.  Unused for slave writes.
	ARB			MASTER	lost arbitration
				SLAVE	unused
	DATA		MASTER	transmits and receives - fifo is half full
				SLAVE	writes - fifo is half full
				SLAVE	reads - fifo is half full or when a request if first 
						received.
	DONE		MASTER	bit will be set when all data has been transmitted or 
						received.
				SLAVE	bit will be set when master terminates the transfer and 
						there is no data left in the fifo
*/
#define I2C_INTERRUPT		i2c_base_addr[0x18]

#define I2C_INT_FIFO_ERR	(1<<5)
#define I2C_INT_TO			(1<<4)
#define I2C_INT_NACK		(1<<3)
#define I2C_INT_ARB			(1<<2)
#define I2C_INT_DATA		(1<<1)
#define I2C_INT_DONE		(1<<0)


/*	FIFO Error register (FIFO_ERR 1C)
	Access:  Write '1' to clear???
	Address: 0x1c
	Code Reference:  fifo_err

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|  rsvd  |  rsvd  |  rsvd  |  rsvd  | RX_UNF | TX_OVF | RX_OVF | TX_UNF |
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Name	Description
	RX_UNF	Master receives and Slave writes - this bit will be set when the 
				data register is read and there is no more data available 
	TX_OVF	Master transmits and Slave reads - this bit will be set when the 
				data register is written and the fifo is full
	RX_OVF	BOTH	this error occurs when on a master receive or 
					slave write a byte was discarded because the FIFO was full.
			NOTE:	this error can only happen when the HOLD bit in the control 
					register is low
	TX_UNF	MASTER	this error occurs when on a transmit the transfer is 
					terminated prematurely (before the transfer count reaches 
					zero) because of an empty FIFO.
			SLAVE	this error occurs when on a read the slave sends a NACK 
					because the FIFO is empty.Note: for both master and slave 
					this error can only happen when the HOLD bit in the control 
					register is low.
*/
#define I2C_FIFO_ERROR		i2c_base_addr[0x1c]

#define I2C_ERROR_RX_UNF	(1<<3)
#define I2C_ERROR_TX_OVF	(1<<2)
#define I2C_ERROR_RX_OVF	(1<<1)
#define I2C_ERROR_TX_UNF	(1<<0)


/*	Interrupt enable register (INT_EN 20)
	Access:  Read/Write
	Address: 0x20
	Code Reference:  int_en

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|  rsvd  |  rsvd  |FIFO_ERR| TO_EN  | NACK_EN| ARB_EN | DATA_EN| DNE_EN |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	Enables for each of the above interrupts.
*/
#define I2C_ENABLE		i2c_base_addr[0x20]


/*	Status register (STAT 24)
	Access:  Read Only
	Address: 0x24
	Code Reference:  stat		

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|  rsvd  | rsvd   |  rsvd  | FIFO_FU| FIFO_EM| SL_RDWR|   DV   |   BA   |
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Name			Description
	FIFO_FU	BOTH	fifo is full
	FIFO_EM	BOTH	fifo is empty
	SL_RDWR	MASTER	unused
			SLAVE	Indicates direction of current slave transfer
	DV		BOTH	indicates that there is valid data in the fifo or shift 
					register 
	BA		MASTER	indicates whether the I2C bus is currently active
*/
#define I2C_STATUS		i2c_base_addr[0x24]

#define I2C_STATUS_FIFO_FULL		(1<<4)
#define I2C_STATUS_FIFO_EMPTY		(1<<3)
#define I2C_STATUS_SL_RDWR			(1<<2)
#define I2C_STATUS_DV				(1<<1)
#define I2C_STATUS_BA				(1<<0)

/*	Mode register (MODE 28)
	Access:  Read/Write
	Address: 0x28
	Code Reference:  mode

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	| rsvd   |  rsvd  |  rsvd  |  rsvd  |  rsvd  | GC_ACK | EXT_ADD| MAS_SLV|
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Name			Description
	GC_ACK	MASTER	unused
			SLAVE	'1' - acknowledge general call address
					'0' - don't acknowledge general call address
	EXT_ADD	BOTH	'1' use extended addressing mode (10 bit)
					'0' use normal addressing mode (7 bit)
	MAS_SLV	MASTER	'1'
			SLAVE	'0'
*/
#define I2C_MODE		i2c_base_addr[0x28]

#define I2C_MODE_GC_ACK		(1<<2)
#define I2C_MODE_EXT_ADD	(1<<1)	// We NEVER use extended addressing!
#define I2C_MODE_MAS_SLV	(1<<0)


/*	Control register (CTL 2C)
	Access:  Read/Write
	Address: 0x2C
	Code Reference:  ctl

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|  rsvd  |  rsvd  | RESET  |CLR_FIFO|POP_FIFO|HOLD_BUS|  RDWR  |  HOLD  |
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Name				Description
	RESET		BOTH	Reset the state machines
	CLR_FIFO	BOTH	clear the fifo, this bit is automatically cleared on 
						the next clock cycle after being set
	POP_FIFO	BOTH	pops the next byte from the fifo.  This bit is 
						automatically cleared on the next clock cycle after 
						being set.
	HOLD_BUS	MASTER	When this bit is a '1' the master will hold on to the 
						bus when the current transfer completes.  When another 
						transfer is initiated the master will generate a repeat 
						start condition.
				SLAVE	unused
	RDWR		MASTER	'1' transfer is a receive
						'0' transfer is a transmit
				SLAVE	unused
	HOLD		MASTER	When this bit is set the master will hold SCLK low 
						when the FIFO is empty on transmits or when the FIFO is 
						full on receives.  When this bit is not set the master 
						will terminate the transfer when the FIFO is empty on 
						transmits or when the FIFO is full on receives.  If the 
						transfer is prematurely terminated than a TX_UNF or 
						RX_OVF error will occur.
				SLAVE	When this bit is set the slave will hold SCLK low when 
						the FIFO is empty on slave reads or when the FIFO is 
						full on slave writes.  When this bit is not set the 
						slave write than when the FIFO is full the slave will 
						NACK the next data byte, discard the data and set the 
						TX_OVF error bit.  On a slave read when HOLD bit is 
						low, when the FIFO is empty the slave will NACK the 
						next byte request and set the RX_UNF error bit.
*/
#define I2C_CONTROL		i2c_base_addr[0x2c]

#define I2C_CONTROL_RESET		(1<<5)
#define I2C_CONTROL_CLR_FIFO	(1<<4)
#define I2C_CONTROL_POP_FIFO	(1<<3)
#define I2C_CONTROL_HOLD_BUS	(1<<2)
#define I2C_CONTROL_RDWR		(1<<1)
#define I2C_CONTROL_HOLD		(1<<0)

/*	Address register low byte (ADDR_LO 30)
	Access:  Read/Write
	Address: 0x30
	Code Reference:  addr_lo

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|                             ADDRESS(7:0)                              |
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Name					Description
	ADDRESS(7:0)	MASTER	address to read/write, writing this register will 
							initiate a transfer.
					SLAVE	slave address
					NOTE:	bit 7 is only used when extended addressing mode is 
							enabled.
*/
#define I2C_ADDRESS_LO		i2c_base_addr[0x30]


/*	Address register high bits (ADDR_HI 34)	!!!NOT USED!!!
	Access:  Read/Write
	Address: 0x34
	Code Reference:  addr_hi

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|  rsvd  |  rsvd  |  rsvd  |  rsvd  |  rsvd  |  rsvd  |  ADDRESS(9:8)   |
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Name					Description
	ADDRESS(9:8)	MASTER	address to read/write
					SLAVE	slave address
					NOTE:	This register is only used when extended addressing 
							mode is enabled
*/

//#define I2C_ADDRESS_HI		i2c_base_addr[0x34]


/*	Data register (DATA 38)
	Access:  Read/Write
	Address: 0x38
	Code Reference:  data

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|                              DATA(7:0)                                |
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Name		Description
	DATA(7:0)	8 bits of data
*/
#define I2C_DATA		i2c_base_addr[0x38]


/*	Transfer count register (CNT 3C)
	Access:  Read/Write
	Address: 0x3c
	Code Reference:  cnt

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	| rsvd   |  rsvd  |  rsvd  |  rsvd  |            COUNT(3:0)             |
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Name				Description
	COUNT(3:0)	MASTER	number of bytes remaining to be transmitted or received
				SLAVE	unused
*/
#define I2C_COUNT		i2c_base_addr[0x3c]


/*	Timeout register (TO 40)
	Access:  Read/Write
	Address: 0x40
	Code Reference:  to

	+--------+--------+--------+--------+--------+--------+--------+--------+
	|   7    |   6    |   5    |   4    |   3    |   2    |   1    |   0    |
	+--------+--------+--------+--------+--------+--------+--------+--------+
	|  rsvd  |  rsvd  |  rsvd  |                  TO(4:0)                   |
	+--------+--------+--------+--------+--------+--------+--------+--------+

	Name			Description
	TO		MASTER	number of bit times to wait before generating an interrupt 
					when the slave holds SCLK low during a transmit or receive.
			SLAVE	unused
*/
#define I2C_TIMEOUT		i2c_base_addr[0x40]



/*******************************************************************************
	MASTER	transmit

	1)	Write mode register, MAS_SLV=1.
	2)	Write control register, RDWR=0
	3)	Write number of bytes of data to be transmitted to the transfer count 
		register.
	4)	Write data to fifo
	5)	Write addr_hi register if using extended addressing mode
	6)	Write addr_lo register to setup address and initiate transfer
//------------------------------------------------------------------------------

	MASTER	receive

	1)	Write mode register MAS_SLV=1.
	2)	Write control register, RDWR=1
	3)	Write number of bytes of data to be received to the transfer count 
		register
	4)	Write addr_hi register if using extended addressing mode
	5)	Write addr_lo register to setup address and initiate transfer
//------------------------------------------------------------------------------

	1301 register write

	1)	Write mode register MAS_SLV=1
	2)	Write control register, RDWR=0
	3)	Write Address of 1301 register to fifo
	4)	Write data to fifo
	5)	Write number of bytes + 1 to transfer count register
	6)	Write 0x2c to ADDR_LO to initiate transfer
//------------------------------------------------------------------------------

	1301 register read

	1)	Write mode register MAS_SLV=1
	2)	Write control register, MAS_HOLD_BUS=1, RDWR=0
	3)	Write address of 1301 register to fifo
	4)	Write 0x01 to transfer count register
	5)	Write 0x2c to ADDR_LO to initiate transfer
	6)	Wait for transfer to complete
	7)	Clear transfer done interrupt
	8)	Write to control register, MAS_HOLD_BUS=0, RDWR=1
	9)	Write number of bytes to be read to transfer count register
	10)	 Write 0x2c to ADDR_LO to initiate transfer
*******************************************************************************/

////////	1301 registers	////////

#define REG_1301_VENDOR_ID			0x00	// read only

#define REG_1301_PRODUCT_ID			0x02	// read only

#define REG_1301_MODE_CONTROL1		0x04	// read, set, clear

#define REG_1301_MODE_CONTROL2		0x12	// read, set, clear

#define REG_1301_OTG_CONTROL		0x06	// read, set, clear

#define REG_1301_INTERRUPT_STATE	0x08	// read only

#define REG_1301_INTERRUPT_DELTA	0x0a	// read, set, clear

#define REG_1301_FALLING_EDGE		0x0c	// read, set, clear

#define REG_1301_RISING_EDGE		0x0e	// read, set, clear

#define REG_1301_BCD_DEVICE			0x14	// read only

uint_8	get1301(uint_8 reg_addr);
void	setclr1301(uint_8 reg_addr, uint_8 bitsToSet, uint_8 bitsToClear);
void	set1301(uint_8 reg_addr, uint_8 bitsToSet);
void	clr1301(uint_8 reg_addr, uint_8 bitsToClear);

void read1301StateAndDelta(char *desc, boolean bClearDelta);

typedef struct
	{
	uint_8		state;		// current state of 8 different signals
	uint_8		delta;		// which bits changed
//	uint_8		falling;	// which bits we care about when they fall
//	uint_8		rising;		// which bits we care about when they rise
	} P1301_REGS;

extern P1301_REGS	p1301Regs;

