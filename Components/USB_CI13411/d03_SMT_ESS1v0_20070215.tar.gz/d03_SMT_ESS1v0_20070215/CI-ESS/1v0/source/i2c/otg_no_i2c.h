// otg_no_i2c.h

// contains dummy routines 

#define otg_i2c_init(x)



