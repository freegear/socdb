#ifndef __otgapi_h__
#define __otgapi_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***  This file contains USB OTG device API definitions.
***
**************************************************************************
**END*********************************************************/
#include "types.h"
#include "hostapi.h"
#include "devapi.h"

#ifdef HOST_TESTING
  #include "vusbhs.h"
#endif

/*
** State status returned by the OTG state machine.
** The application should identify these events and
** take action according to the event.
*/
#define  USB_OTG_HOST_UP                    (0x01)
#define  USB_OTG_DEVICE_UP                  (0x02)
#define  USB_OTG_HOST_DOWN                  (0x03)
#define  USB_OTG_DEVICE_DOWN                (0x04)
#define  USB_OTG_SRP_ACTIVE                 (0x05)
#define  USB_OTG_SRP_FAIL                   (0x06)
#define  USB_OTG_EXCEPTION                  (0x07)
#define  USB_OTG_OVER_CURRENT               (0x08)
#define  USB_OTG_NO_CONNECTION              (0x09)
#define  USB_OTG_HNP_FAILED                 (0x0A)


/* Informational Request/Set Types */
#define  USB_OTG_A_SET_B_HNP_ENABLE         (0x01)
#define  USB_OTG_B_HNP_ENABLE               (0x02)
#define  USB_OTG_A_BUS_REQ                  (0x03)
#define  USB_OTG_B_BUS_REQ                  (0x04)
#define  USB_OTG_A_VBUS_ON                  (0x05)
#define  USB_OTG_B_SRP_REQ                  (0x06)
#define  USB_OTG_B_HNP_REQ                  (0x07)
#define  USB_OTG_B_CONN                     (0x08)
#define  USB_OTG_B_BUS_SUSPEND              (0x09)
#define  USB_OTG_A_BUS_SUSPEND              (0x0A)
#define  USB_OTG_J_ATTACH                    (0x0B)
#define  USB_OTG_A_BUS_RESUME               (0x0C)
#define  USB_OTG_A_CONN                     (0x0D)
#define  USB_OTG_STATE                       (0x0E)
#define  USB_OTG_A_BUS_SUSPEND_REQ            (0x0F)
#define  USB_OTG_B_BUS_RESUME               (0x10)

/* no action require with this change */
#define  USB_OTG_A_BUS_DROP                 (0x11)
#define  USB_OTG_HOST_ACTIVE                 (0x12)
#define  USB_OTG_DEVICE_ACTIVE              (0x13)


/* OTG HNP/SRP states */
#define    OTG_START                            (0)
#define    A_IDLE                             (1)
#define    A_WAIT_VRISE                       (2)
#define    A_WAIT_BCON                          (3)
#define    A_HOST                             (4)
#define    A_SUSPEND                          (5)
#define    A_PERIPHERAL                       (6)
#define    A_WAIT_VFALL                       (7)

#define    B_IDLE                             (8)
#define    B_SRP_INIT                          (9)
#define    B_PERIPHERAL                       (10)
#define    B_WAIT_ACON                          (11)
#define    B_HOST                             (12)

typedef pointer _usb_otg_handle;
/* OTG init structure */
typedef struct otg_init_struct {
   boolean              A_BUS_DROP;
   boolean              A_BUS_REQ;
   boolean              B_BUS_REQ;
   void (_CODE_PTR_     SERVICE)(pointer, uint_32);
} USB_OTG_INIT_STRUCT, _PTR_ USB_OTG_INIT_STRUCT_PTR;

/* #define TA_WAIT_BCON_TMR_FOR_EVER */

/* Enable this for debug */
#define OTG_LOG_STATE            

/*
**  A-DEVICE timing  constants
*/

/* Wait for VBUS Rise  */
#ifdef _I2C_
	#define TA_WAIT_VRISE       (122)    /* a_wait_vrise 100 ms, section: 6.6.5.1 */
#else
	#define TA_WAIT_VRISE       (102)    /* a_wait_vrise 100 ms, section: 6.6.5.1 */
#endif

/* Wait for B-Connect */
#define TA_WAIT_BCON  		(5002) 	/* a_wait_bcon > 1 sec, section: 6.6.5.2 
                                    ** This is only used to get out of A_WAIT_BCON state 
                                    ** state if there was no connection for 
                                    ** these many milliseconds 
                                    */

/* A-Idle to B-Disconnect */
/* It is necessary for this timer to be more than 750 ms because of a bug in OPT
test 5.4 in which B OPT disconnects after 750 ms instead of 75ms as stated in the
test description */
#define TA_AIDL_BDIS        (800)    /* a_suspend minimum 200 ms, section: 6.6.5.3 */

/* B-Idle to A-Disconnect */
#define TA_BIDL_ADIS       (12)     /* 3 to 200 ms */

/*
**  B-DEVICE timing constants.
*/

/* SE0 Time Before SRP */
#define TB_SE0_SRP          (5)       /* b_idle 2 ms 5.3.2 */

#ifdef _I2C_
	#define TB_DATA_PLS         (8)		/* b_srp_init 5 to 10 ms, section: 5.3.3 */
#else
	/* Data-Line Pulse Time*/
	#define TB_DATA_PLS        (9)      /* b_srp_init 5 to 10 ms, section: 5.3.3 */
#endif


#define TB_DATA_PLS_MIN      (5)       /* b_srp_init 5 to 10 ms, section: 5.3.3 */
#define TB_DATA_PLS_MAX      (10)      /* b_srp_init 5 to 10 ms, section: 5.3.3 */

/* SRP Initiate Time  */
#define TB_SRP_INIT        (102)    /* b_srp_init 100 ms, section: 5.3.8 */

/* SRP Fail Time  */
#define TB_SRP_FAIL        (7002)    /* b_srp_init 5 to 30 sec,section: 6.8.2.2*/

/* VBus timer */
#ifdef _I2C_
	#define TB_VBUS_PLS			20		/* sufficient time to keep Vbus pulsing asserted */ 
#else
	/* VBus timer */
	#define TB_VBUS_PLS        (10)     /* sufficient time to keep Vbus pulsing asserted */ 
#endif

/* Discharge timer */
#ifdef _I2C_
	#define TB_VBUS_DSCHRG		20		/* i2c needs longer */
#else
 /* This time should be less than 10ms. It varies from system to
 system. ON ARCADE boards it has been seen that with Philips PHY 8ms
 is enough time for the VBUS to discharge */
	#define TB_VBUS_DSCHRG		8		
#endif



/* A-SE0 to B-Reset  */
#define TB_ASE0_BRST        (6)       /* b_wait_acon 3.125, section: 6.8.2.4 */

/* A bus suspend timer before we can switch to B_WAIT_ACON */
#define TB_A_SUSPEND       (60)

#define TB_BUS_RESUME      (12)

/* Timer Macros */
#define TB_SRP_FAIL_TMR_ON(s,t)          ((s)->TB_SRP_FAIL_TMR = t)
#define TB_SRP_FAIL_TMR_OFF(s)           ((s)->TB_SRP_FAIL_TMR = -1)
#define TB_SRP_FAIL_TMR_EXPIRED(s)     ((s)->TB_SRP_FAIL_TMR ==  0)

#define TB_SRP_INIT_TMR_ON(s,t)         ((s)->TB_SRP_INIT_TMR = t)
#define TB_SRP_INIT_TMR_OFF(s)          ((s)->TB_SRP_INIT_TMR = -1)
#define TB_SRP_INIT_TMR_EXPIRED(s)       ((s)->TB_SRP_INIT_TMR == 0)

#define TB_DATA_PLS_TMR_ON(s,t)          ((s)->TB_DATA_PLS_TMR = t)
#define TB_DATA_PLS_TMR_OFF(s)          ((s)->TB_DATA_PLS_TMR = -1)
#define TB_DATA_PLS_TMR_EXPIRED(s)       ((s)->TB_DATA_PLS_TMR == 0)

#define TB_VBUS_PLS_TMR_ON(s,t) 			((s)->TB_VBUS_PLS_TMR = t)
#define TB_VBUS_PLS_TMR_OFF(s) 			((s)->TB_VBUS_PLS_TMR = -1)
#define TB_VBUS_PLS_TMR_EXPIRED(s) 		((s)->TB_VBUS_PLS_TMR == 0)

#define TB_ASE0_BRST_TMR_ON(s,t)        ((s)->TB_ASE0_BRST_TMR = t)
#define TB_ASE0_BRST_TMR_OFF(s)          ((s)->TB_ASE0_BRST_TMR = -1)
#define TB_ASE0_BRST_TMR_EXPIRED(s)    ((s)->TB_ASE0_BRST_TMR == 0)

#define TB_A_SUSPEND_TMR_ON(s,t)  		((s)->TB_A_SUSPEND_TMR = t)
#define TB_A_SUSPEND_TMR_OFF(s)    		((s)->TB_A_SUSPEND_TMR = -1)
#define TB_A_SUSPEND_TMR_EXPIRED(s) 	((s)->TB_A_SUSPEND_TMR == 0)

#define TB_VBUS_DSCHRG_TMR_ON(s,t)  		((s)->TB_VBUS_DSCHRG_TMR = t)
#define TB_VBUS_DSCHRG_TMR_OFF(s)    		((s)->TB_VBUS_DSCHRG_TMR = -1)
#define TB_VBUS_DSCHRG_TMR_EXPIRED(s) 	((s)->TB_VBUS_DSCHRG_TMR == 0)

#define TA_WAIT_VRISE_TMR_ON(s,t)        ((s)->TA_WAIT_VRISE_TMR = t)
#define TA_WAIT_VRISE_TMR_OFF(s)       ((s)->TA_WAIT_VRISE_TMR = -1)
#define TA_WAIT_VRISE_TMR_EXPIRED(s)    ((s)->TA_WAIT_VRISE_TMR == 0)

#define TA_WAIT_BCON_TMR_ON(s,t)        ((s)->TA_WAIT_BCON_TMR = t)
#define TA_WAIT_BCON_TMR_OFF(s)          ((s)->TA_WAIT_BCON_TMR = -1)
#define TA_WAIT_BCON_TMR_EXPIRED(s)    ((s)->TA_WAIT_BCON_TMR == 0)

#define TA_AIDL_BDIS_TMR_ON(s,t)        ((s)->TA_AIDL_BDIS_TMR = t)
#define TA_AIDL_BDIS_TMR_OFF(s)          ((s)->TA_AIDL_BDIS_TMR = -1)
#define TA_AIDL_BDIS_TMR_EXPIRED(s)    ((s)->TA_AIDL_BDIS_TMR == 0)

#define TA_BIDL_ADIS_TMR_ON(s,t)  		((s)->TA_BIDL_ADIS_TMR = t)
#define TA_BIDL_ADIS_TMR_OFF(s)    		((s)->TA_BIDL_ADIS_TMR = -1)
#define TA_BIDL_ADIS_TMR_EXPIRED(s) 	((s)->TA_BIDL_ADIS_TMR == 0)

#define TB_SE0_SRP_TMR_ON(s,t)           ((s)->TB_SE0_SRP_TMR = t)
#define TB_SE0_SRP_TMR_OFF(s)          ((s)->TB_SE0_SRP_TMR = -1)
#define CHECK_TB_SE0_SRP_TMR_OFF(s)    ((s)->TB_SE0_SRP_TMR == -1)
#define TB_SE0_SRP_TMR_EXPIRED(s)       ((s)->TB_SE0_SRP_TMR == 0)

#define A_SRP_TMR_ON(s,t)              ((s)->A_SRP_TMR = t)
#define A_SRP_TMR_OFF(s)                ((s)->A_SRP_TMR = -1)
#define A_SRP_TMR_EXPIRED(s)             ((s)->A_SRP_TMR == 0)


typedef struct otg_state_machine_struct {

   boolean              A_BUS_DROP;
   boolean              A_BUS_REQ;
   boolean              B_BUS_REQ;
   boolean              HOST_UP;
   boolean              DEVICE_UP;
   boolean              A_SRP_DET;
   int_32               A_SRP_TMR;
   boolean                A_DATA_PULSE_DET;
   int_32               TB_SE0_SRP_TMR;
   boolean              B_SE0_SRP;
   uint_32              OTG_INT_STATUS;
   boolean              A_BUS_RESUME;
   boolean              A_BUS_SUSPEND;
   boolean              A_BUS_SUSPEND_REQ;
   boolean              A_CONN;
   boolean              B_BUS_RESUME;
   boolean              B_BUS_SUSPEND;
   boolean              B_CONN;
   boolean              A_SET_B_HNP_EN;
   boolean              B_SESS_REQ;
   boolean              B_SRP_DONE;
   boolean              B_HNP_ENABLE;
   boolean              A_CONNECTED;
   boolean              B_DISCONNECTED;
   boolean              CHECK_SESSION;
   boolean              A_SUSPEND_TIMER_ON;
   /* A device specific timers */
   int_32               TA_WAIT_VRISE_TMR;
   int_32               TA_WAIT_BCON_TMR;
   int_32               TA_AIDL_BDIS_TMR;
   int_32               TA_BIDL_ADIS_TMR;
   /* B device specific timers */
   int_32               TB_DATA_PLS_TMR;
   int_32               TB_SRP_INIT_TMR;
   int_32               TB_SRP_FAIL_TMR;
   int_32               TB_VBUS_PLS_TMR;
   int_32               TB_ASE0_BRST_TMR;
   int_32               TB_A_SUSPEND_TMR;
   int_32               TB_VBUS_DSCHRG_TMR;
   uint_8               STATE;
} OTG_STATE_MACHINE_STRUCT, _PTR_ OTG_STATE_MACHINE_STRUCT_PTR;

typedef struct usb_otg_state_structure {
   pointer                             OTG_REG_PTR;
   pointer                             USB_REG_PTR;
   OTG_STATE_MACHINE_STRUCT_PTR        STATE_STRUCT_PTR;
   void (_CODE_PTR_                    SERVICE)(pointer, uint_32);
   uint_8                                 DEV_NUM;
   pointer                               CALLBACK_STRUCT_PTR;
   uint_32                             ENABLED_INTERRUPTS;
#ifdef OTG_LOG_STATE
   uchar                               LOG_STATE[100];
   uint_32                             LOG_STATE_COUNT;
#endif

#ifdef HOST_TESTING
     #define HOST_LOG_MOD                100
   EHCI_ITD_STRUCT                     ITD_QUEUE_LOG[HOST_LOG_MOD];
   EHCI_SITD_STRUCT                     SITD_QUEUE_LOG[HOST_LOG_MOD];
   uint_32                             LOG_FRAME_COUNT;
   uint_32                             NEXT_LINK[HOST_LOG_MOD];
   uint_32                             NEXT_LINK_COUNT;   
   
   EHCI_ITD_STRUCT                     LOG_INTERRUPT_ITDS[HOST_LOG_MOD];
   uint_32                             LOG_ITD_COUNT;

   EHCI_SITD_STRUCT                    LOG_INTERRUPT_SITDS[HOST_LOG_MOD];
   uint_32                             LOG_SITD_COUNT;

   uint_32                             STATUS_STARTS[HOST_LOG_MOD];
   uint_32                             NUMBER_OF_TRANS_STARTS[HOST_LOG_MOD];
   uint_32                             NUMBER_OF_TRANS_FREE[HOST_LOG_MOD];
   uint_32                             STATUS[HOST_LOG_MOD];

#endif

#ifdef OPT_TESTING
#define OTG_LOG_MOD                    100
   uint_32                             LOG_INTERRUPTS[OTG_LOG_MOD];
   uint_32                             LOG_INTERRUPTS_STATE[OTG_LOG_MOD][7];
   uint_32                             LOG_STATE_CHANGE[OTG_LOG_MOD];
   uint_32                             PORT_CHANGE[OTG_LOG_MOD];
   uint_32                             PORT_ATTACH[OTG_LOG_MOD];
   uint_32                             LOG_PORT_COUNT;
   uint_32                             ATTACH;
   uint_32                             LOG_INTR_COUNT;
#endif
} USB_OTG_STATE_STRUCT, _PTR_ USB_OTG_STATE_STRUCT_PTR;

extern USB_OTG_STATE_STRUCT_PTR usb_otg_state_struct_ptr;

/* Prototypes */
#ifdef __cplusplus
extern "C" {
#endif
extern uint_8 _usb_otg_init(uint_8, USB_OTG_INIT_STRUCT_PTR,
   _usb_otg_handle _PTR_);
extern uint_8 _usb_otg_get_status(_usb_otg_handle, uint_8, uint_32_ptr);
extern uint_8 _usb_otg_set_status(_usb_otg_handle, uint_8, boolean);
extern void _usb_otg_shutdown(_usb_otg_handle);
extern void _usb_otg_state_machine(_usb_otg_handle);
extern boolean  _usb_otg_hnp_assistance_check (_usb_otg_handle);

extern void _usb_otg_process_b_idle(_usb_otg_handle);
extern void _usb_otg_process_a_idle(_usb_otg_handle);
extern void _usb_otg_process_a_wait_vrise(_usb_otg_handle);
extern void _usb_otg_process_a_wait_vfall(_usb_otg_handle);
extern void _usb_otg_process_b_device_session_valid(_usb_otg_handle);
extern void _usb_otg_process_b_srp_init(_usb_otg_handle);
extern boolean _usb_otg_process_timers(_usb_otg_handle);
extern boolean _usb_otg_process_exceptions(_usb_otg_handle);
extern void  _usb_otg_reset_state_machine(_usb_otg_handle);
extern void _usb_host_bus_control(pointer, uint_8); 
#ifdef __cplusplus
}
#endif

#endif

/* EOF */
