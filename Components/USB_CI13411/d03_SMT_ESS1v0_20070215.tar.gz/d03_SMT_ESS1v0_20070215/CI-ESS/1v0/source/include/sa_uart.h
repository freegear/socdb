//	U   U   AAA   RRRR   TTTTT
//	U   U  A   A  R   R    T  
//	U   U  AAAAA  RRRR     T  
//	U   U  A   A  R  R     T  
//	 UUU   A   A  R   R    T  

#define read_aux_reg(addr)		_lr(addr)		// Load r0 with what's @ addr

#define BCR_PERIPHERAL_BASE_ADDR	0x69
#define PERIPHERAL_OFFSET_TO_UART	0x1000

void uartInit(void);

#ifdef _SA_UART_
void uartputc(char c);			// does not block
void uartputs(char *s);			// no longer blocks while UART is not ready for tx
void uartprintf(char *format, ...);

void uartput8(uint_8 u8);		// blocks while UART is not ready for tx
void uartput16(uint_16 u16);	// blocks while UART is not ready for tx
void uartput32(uint_32 u32);	// blocks while UART is not ready for tx

void uartflush(void);

#else

#define uartputc(c)
#define uartputs(s)
#define uartprintf			printf

#define uartput8(u8)
#define uartput16(u16)
#define uartput32(u32)

#define uartflush()

#endif

extern char	*state_name[13];

