#ifndef __types_h__
#define __types_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains appropriate processor specific header file include.
***                                                               
**************************************************************************
**END*********************************************************/
#include "usbprv.h"
#ifdef __USB_OS_MQX__
   #include "mqx.h"
   #include "psptypes.h"
#else
	#ifndef __ARM__
		#include "arc.h"
	#else
		#include "arm.h"
	#endif
#endif
#endif
/* EOF */

