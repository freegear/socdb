/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the default callback functions for the VUSB32 host 
***   and device.
***                                                               
**************************************************************************
**END*********************************************************/
#include "mqx_arc.h"



USB_CALLBACK_FUNCTIONS_STRUCT _bsp_usb_callback_table =
{
#ifdef __USB_OTG__
   
   0,
   /* The Host/Device init function */
   _usb_dci_vusb11_init,

   /* The function to send data */
   _usb_dci_vusb11_submit_transfer,

   /* The function to receive data */
   _usb_dci_vusb11_submit_transfer,
   
   /* The function to cancel the transfer */
   _usb_dci_vusb11_cancel_transfer,
         
   _usb_dci_vusb11_init_endpoint,
   
   _usb_dci_vusb11_deinit_endpoint,
   
   _usb_dci_vusb11_unstall_endpoint,
   
   _usb_dci_vusb11_get_endpoint_status,
   
   _usb_dci_vusb11_set_endpoint_status,
   
   _usb_dci_vusb11_get_address,
   
   _usb_dci_vusb11_set_address,
   
   _usb_dci_vusb11_shutdown,
   
   _usb_dci_vusb11_assert_resume,
  
   /* The Host/Device init function */
   _usb_hci_vusb11_init,

   /* The function to shutdown the host/device */
   _usb_hci_vusb11_shutdown,

   /* The function to send data */
   _usb_hci_vusb11_send_data,

   /* The function to send setup data */
   _usb_hci_vusb11_send_setup,

   /* The function to receive data */
   _usb_hci_vusb11_recv_data,
   
   /* The function to get the transfer status */
   NULL,
   
   /* The function to cancel the transfer */
   _usb_hci_vusb11_cancel_transfer,
   
   /* The function to do USB sleep */
   NULL,
   
   /* The function for USB bus control */
   _usb_hci_vusb11_bus_control,

    /* The function for OTG initialization */
    _usb_otg_vusb11_init,
    
   /* The function for OTG shutdown */
   _usb_otg_vusb11_shutdown
#endif

#ifdef __USB_HOST__
   
   0,
   /* The Host/Device init function */
   _usb_hci_vusb11_init,

   /* The function to shutdown the host/device */
   _usb_hci_vusb11_shutdown,

   /* The function to send data */
   _usb_hci_vusb11_send_data,

   /* The function to send setup data */
   _usb_hci_vusb11_send_setup,

   /* The function to receive data */
   _usb_hci_vusb11_recv_data,
   
   /* The function to get the transfer status */
   NULL,
   
   /* The function to cancel the transfer */
   _usb_hci_vusb11_cancel_transfer,
   
   /* The function to do USB sleep */
   NULL,
   
   /* The function for USB bus control */
   _usb_hci_vusb11_bus_control,
#endif
#ifdef __USB_DEVICE__
   
   0,
   /* The Device init function */
   _usb_dci_vusb11_init,

   /* The function to send data */
   _usb_dci_vusb11_submit_transfer,

   /* The function to receive data */
   _usb_dci_vusb11_submit_transfer,
   
   /* The function to cancel the transfer */
   _usb_dci_vusb11_cancel_transfer,
         
   _usb_dci_vusb11_init_endpoint,
   
   _usb_dci_vusb11_deinit_endpoint,
   
   _usb_dci_vusb11_unstall_endpoint,
   
   _usb_dci_vusb11_get_endpoint_status,
   
   _usb_dci_vusb11_set_endpoint_status,
   
   _usb_dci_vusb11_get_address,
   
   _usb_dci_vusb11_set_address,
   
   _usb_dci_vusb11_shutdown,
   
   /* Device remote wakeup function */
   _usb_dci_vusb11_assert_resume,
  
#endif

};

/* EOF */


