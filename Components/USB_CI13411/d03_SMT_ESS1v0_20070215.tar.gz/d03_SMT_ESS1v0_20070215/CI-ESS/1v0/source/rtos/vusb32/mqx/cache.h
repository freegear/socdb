#ifndef __mqx_cache_h__
#define __mqx_cache_h__

#ifdef _DATA_CACHE_
	#define USB_Uncached			     		 volatile _Uncached
#else
	#define USB_Uncached						 volatile
#endif
/* Macro for aligning the EP queue head to 32 byte boundary */
#define USB_MEM32_ALIGN(n)                   ((n) + (-(n) & 31))
#define USB_CACHE_ALIGN(n)     		     USB_MEM32_ALIGN(n)	


#endif
