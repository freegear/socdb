/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:      
***   This file contains the default callback function for the vusbhs 
***   and device.
***                                                               
**************************************************************************
**END*********************************************************/
#include "types.h"
#include "mqx_arc.h"

#ifdef __USB_HOST__ 
#include "hostapi.h"
#include "usbprv_host.h"
#endif

#ifdef __USB_DEVICE__
#include "devapi.h"
#include "usbprv_dev.h"
#endif

#ifdef __USB_OTG__
#include "otgapi.h"
#include "usbprv_dev.h"
#include "usbprv_host.h"
#include "usbprv_otg.h"
#endif


USB_CALLBACK_FUNCTIONS_STRUCT _bsp_usb_callback_table =
{
#ifdef __USB_OTG__
   
   0,
   /* The Host/Device init function */
   _usb_dci_vusb20_init,

   /* The function to send data */
   _usb_dci_vusb20_send_data,

   /* The function to receive data */
   _usb_dci_vusb20_recv_data,
   
   /* The function to cancel the transfer */
   _usb_dci_vusb20_cancel_transfer,
         
   _usb_dci_vusb20_init_endpoint,
   
   _usb_dci_vusb20_deinit_endpoint,
   
   _usb_dci_vusb20_unstall_endpoint,
   
   _usb_dci_vusb20_get_endpoint_status,
   
   _usb_dci_vusb20_set_endpoint_status,

   _usb_dci_vusb20_reset_data_toggle,

   _usb_dci_vusb20_get_transfer_status,
   
   _usb_dci_vusb20_set_address,
   
   _usb_dci_vusb20_shutdown,
   
   _usb_dci_vusb20_get_setup_data,
   
   _usb_dci_vusb20_assert_resume,
   
   _usb_dci_vusb20_stall_endpoint,
   
  
   /* The Host/Device init function */
   _usb_hci_vusb20_init,

   /* The function to shutdown the host/device */
   _usb_hci_vusb20_shutdown,

   /* The function to send data */
   _usb_hci_vusb20_send_data,

   /* The function to send setup data */
   _usb_hci_vusb20_send_setup,

   /* The function to receive data */
   _usb_hci_vusb20_recv_data,
   
   /* The function to get the transfer status */
   NULL,
   
   /* The function to cancel the transfer */
   _usb_hci_vusb20_cancel_transfer,
   
   /* The function to do USB sleep */
   NULL,
   
   /* The function for USB bus control */
   _usb_hci_vusb20_bus_control,

   _usb_ehci_allocate_bandwidth,

   _usb_ehci_free_resources,
    
   _usb_ehci_get_frame_number,
   
   _usb_ehci_get_micro_frame_number,
    
    /* The function for OTG initialization */
    _usb_otg_vusbhs_init,
    
   /* The function for OTG shutdown */
   _usb_otg_vusbhs_shutdown
#endif

#ifdef __USB_HOST__
   
   0,
   /* The Host/Device init function */
   _usb_hci_vusb20_init,

   /* The function to shutdown the host/device */
   _usb_hci_vusb20_shutdown,

   /* The function to send data */
   _usb_hci_vusb20_send_data,

   /* The function to send setup data */
   _usb_hci_vusb20_send_setup,

   /* The function to receive data */
   _usb_hci_vusb20_recv_data,
   
   /* The function to get the transfer status */
   NULL,
   
   /* The function to cancel the transfer */
   _usb_hci_vusb20_cancel_transfer,
   
   /* The function to do USB sleep */
   NULL,
   
   /* The function for USB bus control */
   _usb_hci_vusb20_bus_control,

   _usb_ehci_allocate_bandwidth,

   _usb_ehci_free_resources,
    
   _usb_ehci_get_frame_number,
   
   _usb_ehci_get_micro_frame_number

#endif
#ifdef __USB_DEVICE__
   0,
   /* The Host/Device init function */
   _usb_dci_vusb20_init,

   /* The function to send data */
   _usb_dci_vusb20_send_data,

   /* The function to receive data */
   _usb_dci_vusb20_recv_data,
   
   /* The function to cancel the transfer */
   _usb_dci_vusb20_cancel_transfer,
         
   _usb_dci_vusb20_init_endpoint,
   
   _usb_dci_vusb20_deinit_endpoint,
   
   _usb_dci_vusb20_unstall_endpoint,
   
   _usb_dci_vusb20_get_endpoint_status,
   
   _usb_dci_vusb20_set_endpoint_status,

   _usb_dci_vusb20_reset_data_toggle,

   _usb_dci_vusb20_get_transfer_status,
   
   _usb_dci_vusb20_set_address,
   
   _usb_dci_vusb20_shutdown,
   
   _usb_dci_vusb20_get_setup_data,
   
   _usb_dci_vusb20_assert_resume,
   
   _usb_dci_vusb20_stall_endpoint,
  
#endif

};

/* EOF */


