/*******************************************************************************
** File          : vuart.h  for VAutomation Inc. V8 based UART
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************

    Unless otherwise specified, all registers are typically reset to zero when the RESET signal is active.
The VUART module is a very simple UART with an integrated BAUD rate generator. The UART only
supports 8 data bits, 1 start bit and 1 stop bit with no parity. This is the most common mode required for
most embedded applications. Several other variations of UARTs are available from VAutomation.
A programmable BAUD rate generator is provided which generates a 4X oversampled bit clock and a 1X
bit clock. The baud rate registers are write only. To compute the value to be programmed into the BAUD
registers, us the following equation:

BAUD = (CLK_FREQ/BAUD RATE/4)-1

Example: if the desired baud rate is 115200 baud and the clock frequency of the V8 is 12Mhz:
BAUD = (12,000,000/115200/4)-1 = 25.04 = 0x19

Often the clock frequency of the V8 is not an even multiple of the desired BAUD rate. Typically you will
want to round the value to the nearest whole integer. This will introduce some error in the BAUD rate,
but at BAUD rates below 57.6K the error is negligible.

    The UART is full duplex capable and both the transmit and receive channels effectively have a single
byte FIFO built in. To transmit a byte, simply write to the DataTX register. This will cause the TXEMPTY
bit in the STATUS register to go low. Once the byte has been transferred from the holding register into
the shift register, TXEMPTY will go high indicating that another byte can be written to DataTX. Typically,
once all bytes have been written to the UART, the TXENB bit is cleared to zero which masks the interrupt
until more data is available for transmission.

  To receive data, simply enable RX interrupts by setting RXENB to a one. RXFULL will go to a one when
a character has been received and the interrupt will be activated if RXENB is a one. Reading DataRX
will clear RXFULL. If another character is received before the previous one has been read (RXFULL is
still a one), then the RXOFLO bit is set indicating that data has been lost. If there is a framing error, the
RXFRAM bit is set. RXOFLO and RXFRAM must be cleared by software by writing a zero to these bits.

Register Definition:

ADDR	NAME	R/W			DESCRIPTION

0		ID		R			Identity

4		DataRX	R			Receive data holding register

4		DataTX	W			Transmit data holding register

8		STATUS	R/W			Status Register:
		
			[7]=TXEMPTY (read only)
				1=DataTX can be written with the next
				character, 0=transmission in progress.
				Cleared to zero when a write to DataTX
				is performed.
			[6]=TXENB
				1=enable TXEMPTY to activate IRQ,
				0=masked
			[5]=RXEMPTY (read only)
				1=FIFO buffer (3byte) is empty 
			[4]=RXFULL_1 (read only)
				1=FIFO buffer (3byte) is full
			[3]=RXFULL (read only)
				1=Data available in DataRX, 0=no data
				available. Cleared to zero when DataRX
				is read.
			[2]=RXENB
				1=enable RXFULL or RXOFLO or
				RXFRAM to activate IRQ, 0=masked.
			[1]=RXOFLO
				1=character received but RXFULL was
				still high.
			[0]=RXFRAM framing error  
				1=STOP bit not detected.

12		BAUDL	W			Baud Rate Register Low [7:0]

16		BAUDH	W			Baud Rate Register High [7:0].
				
*********************************************************************************/

#ifndef VUART_H
#define VUART_H 

#define CARRIAGE_RETURN 0x0D
#define LINE_FEED       0x0A

	
#define TXEMPTY ((unsigned char) 0x80) // [7]= TXEMPTY (read only)
                        //	1=DataTX can be written with the next
			//	character, 0=transmission in progress.
			//	Cleared to zero when a write to DataTX
			//	is performed.

#define TXENB ((unsigned char)0x40)	//[6]=TXENB
			//	1=enable TXEMPTY to activate IRQ,
			//	0=masked

#define RES45_CLEAR ((unsigned char)0x30) //[5:4]=reserved, write zeroes.

#define RXEMPTY ((unsigned char)0x20)   //[5]=RXEMPTY (read only)
			//	1=FIFO buffer (3byte) is empty 
#define RXFULL_1 ((unsigned char)0x10)   //[4]=RXEMPTY (read only)
			//	1=FIFO buffer (3byte) is partly full 

#define RXFULL ((unsigned char)0x08)   //[3]=RXFULL (read only)
			//	1=Data available in DataRX, 0=no data
			//	available. Cleared to zero when DataRX
			//	is read.

#define RXENB ((unsigned char)0x04)    //[2]=RXENB
			//	1=enable RXFULL or RXOFLO or
			//	RXFRAM to activate IRQ, 0=masked.

#define RXOFLO ((unsigned char)0x02)    //[1]=RXOFLO   I.E. Overflow
			//	1=character received but RXFULL was
			//	still high.

#define RXFRAM ((unsigned char)0x01)    //[0]=RX framing error
			//	1=STOP bit not detected.

#define DEFAULT_VUART_BASE_ADDRESS (0xfc1000)
#define DEFAULT_VUART_OFFSET 0x100
#define VUART_FIFO_LEN 4


#ifdef BSP_NON_BVCI_VUART

enum uart_enum {     
					  VUART_ID_OFFSET=0,
					  VUART_READ_OFFSET=4,
		              VUART_WRITE_OFFSET=4,
					  VUART_STATUS_OFFSET=8,
					  VUART_CONTROL_OFFSET=8,
					  VUART_BAUD_LO_OFFSET=12,
					  VUART_BAUD_HI_OFFSET=16 
				};

#define  VUART_LENGTH 20;

#else

enum uart_enum {     
					  VUART_ID_OFFSET=0,
					  VUART_READ_OFFSET=16,
		              VUART_WRITE_OFFSET=16,
					  VUART_STATUS_OFFSET=20,
					  VUART_CONTROL_OFFSET=20,
					  VUART_BAUD_LO_OFFSET=24,
					  VUART_BAUD_HI_OFFSET=28 
				};

#define  VUART_LENGTH 32;

#endif




#endif
