/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:      
***   This file contains the function to install the low-level driver functions
***                                                               
**************************************************************************
**END*********************************************************/
#include "types.h"
#include "mqx_arc.h"

#ifdef __USB_HOST__ 
#include "hostapi.h"
#include "usbprv_host.h"
#endif

#ifdef __USB_DEVICE__
#include "devapi.h"
#include "usbprv_dev.h"
#endif

#ifdef __USB_OTG__
#include "otgapi.h"
#include "usbprv_dev.h"
#include "usbprv_host.h"
#include "usbprv_otg.h"
#endif


/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_driver_install
*  Returned Value : None
*  Comments       :
*        Installs the device
*END*-----------------------------------------------------------------*/
uint_8 _usb_driver_install
   (
      /* [IN] device number */
      uint_32  device_number,
            
      /* [IN] address if the callback functions structure */
      pointer  callback_struct_ptr
   )
{ /* Body */
   pointer callback_struct_table_ptr;
   
   callback_struct_table_ptr = _mqx_get_io_component_handle(IO_USB_COMPONENT);
   
   if (!callback_struct_table_ptr) {
      callback_struct_table_ptr = 
         USB_memalloc(BSP_MAX_USB_DRIVERS*
            sizeof(USB_CALLBACK_FUNCTIONS_STRUCT));
      
      if (!callback_struct_table_ptr) {
         return USBERR_DRIVER_INSTALL_FAILED;
      } /* Endif */
      
      USB_memzero((uchar_ptr)callback_struct_table_ptr, 
         sizeof(callback_struct_table_ptr));
      
      _mqx_set_io_component_handle(IO_USB_COMPONENT, 
         callback_struct_table_ptr);
   } /* Endif */

   *((USB_CALLBACK_FUNCTIONS_STRUCT_PTR)\
      (((USB_CALLBACK_FUNCTIONS_STRUCT_PTR)callback_struct_table_ptr) + 
      device_number)) = 
      *((USB_CALLBACK_FUNCTIONS_STRUCT_PTR)callback_struct_ptr);

   return USB_OK;

} /* EndBody */

/* EOF */


