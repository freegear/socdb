/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the USB functions specific to ARC processor.
***                                                               
**************************************************************************
**END*********************************************************/
#include "types.h"
#include "mqx_arc.h"

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _bsp_get_usb_vector
*  Returned Value : interrupt vector number
*  Comments       :
*        Get the vector number for the specified device number
*END*-----------------------------------------------------------------*/

uint_8 _bsp_get_usb_vector
   (
      uint_8 device_number
   )
{ /* Body */
#ifdef __USB_HOST__
   if (device_number == 0) {
      return BSP_VUSB11_HOST_VECTOR0;
   } /* Endif */
#endif

#ifdef __USB_DEVICE__
   if (device_number == 0) {
      return BSP_VUSB11_DEVICE_VECTOR0;
   } /* Endif */
#endif

#ifdef __USB_OTG__
   if (device_number == 0) {
      return BSP_VUSB11_OTG_VECTOR0;
   } /* Endif */
#endif
 
} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _bsp_get_usb_base
*  Returned Value : Address of the VUSB1.1 register base
*  Comments       :
*        Get the USB register base address
*END*-----------------------------------------------------------------*/

pointer _bsp_get_usb_base
   (
      uint_8 device_number
   )
{ /* Body */
#ifdef __USB_HOST__
   if (device_number == 0) {
      return (pointer)BSP_VUSB11_HOST_BASE_ADDRESS0;
   } /* Endif */
#endif

#ifdef __USB_DEVICE__
   if (device_number == 0) {
      return (pointer)BSP_VUSB11_DEVICE_BASE_ADDRESS0;
   } /* Endif */
#endif

#ifdef __USB_OTG__
   if (device_number == 0) {
      return (pointer)BSP_VUSB11_OTG_BASE_ADDRESS0;
   } /* Endif */
#endif
   
} /* EndBody */

/* EOF */
   