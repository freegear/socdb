/*******************************************************************************
** File          : lib_aa3uart.c Example Simulator File I/O VAutomation VUART 	
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
	       	  
 12 APR 2004 - automatically open at 115200 or AA3_UART_DEFAULT_BAUD_RATE

-----------------------------------------------------------------------*/

//#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <ctype.h>
#include "vuart.h"
#include "lib_aa3uart.h"



/*

    Unless otherwise specified, all registers are typically reset to zero when the RESET signal is active.
The VUART module is a very simple UART with an integrated BAUD rate generator. The UART only
supports 8 data bits, 1 start bit and 1 stop bit with no parity. This is the most common mode required for
most embedded applications. Several other variations of UARTs are available from VAutomation.
A programmable BAUD rate generator is provided which generates a 4X oversampled bit clock and a 1X
bit clock. The baud rate registers are write only. To compute the value to be programmed into the BAUD
registers, us the following equation:

BAUD = (CLK_FREQ/BAUD RATE/4)-1

Example: if the desired baud rate is 115200 baud and the clock frequency of the VUART is 12Mhz:
BAUD = (12,000,000/115200/4)-1 = 25.04 = 0x19

Often the clock frequency of the VUART is not an even multiple of the desired BAUD rate. Typically you will
want to round the value to the nearest whole integer. This will introduce some error in the BAUD rate,
but at BAUD rates below 57.6K the error is negligible.

    The UART is full duplex capable and both the transmit and receive channels effectively have a single
byte FIFO built in. To transmit a byte, simply write to the DataTX register. This will cause the TXEMPTY
bit in the STATUS register to go low. Once the byte has been transferred from the holding register into
the shift register, TXEMPTY will go high indicating that another byte can be written to DataTX. Typically,
once all bytes have been written to the UART, the TXENB bit is cleared to zero which masks the interrupt
until more data is available for transmission.

  To receive data, simply enable RX interrupts by setting RXENB to a one. RXFULL will go to a one when
a character has been received and the interrupt will be activated if RXENB is a one. Reading DataRX
will clear RXFULL. If another character is received before the previous one has been read (RXFULL is
still a one), then the RXOFLO bit is set indicating that data has been lost. If there is a framing error, the
RXFRAM bit is set. RXOFLO and RXFRAM must be cleared by software by writing a zero to these bits.

Register Definition:

ADDR	NAME	R/W			DESCRIPTION

0		ID		R			Identity

4		DataRX	R			Receive data holding register

4		DataTX	W			Transmit data holding register

8		STATUS	R/W			Status Register:
		
			[7]=TXEMPTY (read only)
				1=DataTX can be written with the next
				character, 0=transmission in progress.
				Cleared to zero when a write to DataTX
				is performed.
			[6]=TXENB
				1=enable TXEMPTY to activate IRQ,
				0=masked
			[5]=RXEMPTY (read only)
				1=FIFO buffer (3byte) is empty
			[4]=RXFULL_1 (read only)
				1=FIFO buffer (3byte) is full
			[3]=RXFULL (read only)
				1=Data available in DataRX, 0=no data
				available. Cleared to zero when DataRX
				is read.
			[2]=RXENB
				1=enable RXFULL or RXOFLO or
				RXFRAM to activate IRQ, 0=masked.
			[1]=RXOFLO
				1=character received but RXFULL was
				still high.
			[0]=RXFRAM framing error  
				1=STOP bit not detected.

12		BAUDL	W			Baud Rate Register Low [7:0]

16		BAUDH	W			Baud Rate Register High [7:0].
				

 (C) Copyright APR 2000  MetaWare Incorporated;  Santa Cruz, CA 95060
                         VAutomation Inc.  Nashua, NH
						 ARC Cores Inc.  Edgeware, UK
  

	
#define TXEMPTY ((unsigned char) 0x80) // [7]= TXEMPTY (read only)
                        //	1=DataTX can be written with the next
			//	character, 0=transmission in progress.
			//	Cleared to zero when a write to DataTX
			//	is performed.

#define TXENB ((unsigned char)0x40)	//[6]=TXENB
			//	1=enable TXEMPTY to activate IRQ,
			//	0=masked

#define RES45_CLEAR ((unsigned char)0x30) //[5:4]=reserved, write zeroes.

#define RXFULL ((unsigned char)0x08)   //[3]=RXFULL (read only)
			//	1=Data available in DataRX, 0=no data
			//	available. Cleared to zero when DataRX
			//	is read.
#define RXFULL_1 ((unsigned char)0x10)   //[4]=RXFULL_1 (read only)

			//	1=FIFO buffer (3byte) is full
#define RXEMPTY ((unsigned char)0x20)   //[4]=RXEMPTY (read only)
			//	1=FIFO buffer (3byte) is empty 

#define RXENB ((unsigned char)0x04)    //[2]=RXENB
			//	1=enable RXFULL or RXOFLO or
			//	RXFRAM to activate IRQ, 0=masked.

#define RXOFLO ((unsigned char)0x02)    //[1]=RXOFLO   I.E. Overflow
			//	1=character received but RXFULL was
			//	still high.

#define RXFRAM ((unsigned char)0x01)    //[0]=RX framing error
			//	1=STOP bit not detected.

#define DEFAULT_VUART_BASE_ADDRESS (0xfc1000)
#define DEFAULT_VUART_OFFSET 0x100
#define VUART_FIFO_LEN 4


enum uart_enum {     
					  VUART_ID_OFFSET=0,
					  aa3_UART_READ_OFFSET=4,
		              VUART_WRITE_OFFSET=4,
					  VUART_STATUS_OFFSET=8,
					  VUART_CONTROL_OFFSET=8,
					  VUART_BAUD_LO_OFFSET=12,
					  VUART_BAUD_HI_OFFSET=16 
				};
*/




volatile unsigned char  * uart_read_ptr =
        (volatile unsigned char *) (DEFAULT_VUART_BASE_ADDRESS + VUART_READ_OFFSET);
volatile unsigned char  * uart_write_ptr =
        (volatile unsigned char *) (DEFAULT_VUART_BASE_ADDRESS + VUART_WRITE_OFFSET);
volatile unsigned char  * uart_baud_hi_ptr =
        (volatile unsigned char *) (DEFAULT_VUART_BASE_ADDRESS + VUART_BAUD_HI_OFFSET);
volatile unsigned char  * uart_baud_lo_ptr =
        (volatile unsigned char *) (DEFAULT_VUART_BASE_ADDRESS + VUART_BAUD_LO_OFFSET);

volatile unsigned char  * uart_status_ptr =
        (volatile unsigned char *) (DEFAULT_VUART_BASE_ADDRESS + VUART_STATUS_OFFSET);




unsigned char aa3uart_read_buffer[MAX_CIRC_BUFFER+1]; 
unsigned char aa3uart_write_buffer[MAX_CIRC_BUFFER+1]; 
int aa3uart_write_buffer_bytes=0;
int aa3uart_read_buffer_bytes = 0;
int aa3r_end_index = 0;
int aa3r_read_index = 0;

int aa3w_end_index = 0;
int aa3w_read_index = 0;

#define DEFAULT_AA3_CRYSTAL_FREQ 30000000

#define PERIPHERAL_BASE_ADDR_REG 0x69
#define DEFAULT_VUART_OFFSET 0x1000
#define AA3_CLOCK_DIVISOR_REG 0x56

#define DEFAULT_AA3_UART_BAUD_RATE 115200



// This overrides the C Runtime _write used by  printf

_write(int FD, char * buffer, int length) {
    for (int i = 0; i< length; i++) 
       {
       if (*(buffer+i) == '\n') aa3uart_putc('\r',FALSE) ;
       aa3uart_putc(*(buffer+i),FALSE) ;
       }
}



int aa3have_data(void)
{
	int result = FALSE;
	result = (aa3uart_read_buffer_bytes > 0);
	return result;
}


static int aa3uart_is_open=0;
int aa3uart_open(unsigned long baud)
           // returns 1 on success, else 0
{

    unsigned long uart_address;
    unsigned long baud_setting;
    unsigned char low, high;
    unsigned speed;
    unsigned settings=0;

    unsigned char temp_byte = 0;

    aa3uart_is_open=TRUE;

    uart_address= (_lr(PERIPHERAL_BASE_ADDR_REG) & 0xffffff00) + DEFAULT_VUART_OFFSET;
  

  // settings = _lr(AA3_CLOCK_DIVISOR_REG);

   if (!settings) {
       speed = (DEFAULT_AA3_CRYSTAL_FREQ);
   } /* Endif */
   else
   {
   settings &= 0x0C;

   switch (settings) {
      case 0x00:
         /* Divide by 1 */
         speed = DEFAULT_AA3_CRYSTAL_FREQ;
         break;
      case 0x08:
         /* Divide by 4 */
         speed = DEFAULT_AA3_CRYSTAL_FREQ >> 2;
         break;
      case 0x04:
         /* Divide by 2 */
         speed = DEFAULT_AA3_CRYSTAL_FREQ >> 1;
         break;
      default:
         /* Divide by 8 */
         speed = DEFAULT_AA3_CRYSTAL_FREQ >> 3;
         break;
   } /* Endswitch */
   } // non-zero baud

    

    aa3uart_write_buffer_bytes=0;
    aa3uart_read_buffer_bytes = 0;
    aa3r_end_index = 0;
    aa3r_read_index = 0;
    aa3w_end_index = 0;
    aa3w_read_index = 0;
     uart_read_ptr =
        (volatile unsigned char *) (uart_address + VUART_READ_OFFSET);
       uart_write_ptr =
        (volatile unsigned char *) (uart_address + VUART_WRITE_OFFSET);
       uart_baud_hi_ptr =
        (volatile unsigned char *) (uart_address + VUART_BAUD_HI_OFFSET);
       uart_baud_lo_ptr =
        (volatile unsigned char *) (uart_address + VUART_BAUD_LO_OFFSET);
       uart_status_ptr =
        (volatile unsigned char *) (uart_address + VUART_STATUS_OFFSET);
 



    if (baud < MIN_BAUD_RATE || baud > MAX_BAUD_RATE ) return FALSE;

	baud_setting = ((speed/baud)/4)-1;


 	aa3uart_read_buffer_bytes = 0;

        low = (baud_setting & 0xff);
        high = ((baud_setting >> 8) & 0xff);
        *uart_baud_lo_ptr = low;
	*uart_baud_hi_ptr = high;
	*uart_status_ptr = temp_byte; 

	return TRUE; 
}


int aa3uart_close()
{
    *uart_status_ptr =0; 

   aa3uart_is_open=FALSE;

    return TRUE;
}


int aa3uart_getc(unsigned char *cp) //direct from uart unbuffered
{
      if (!aa3uart_is_open && !aa3uart_open(DEFAULT_AA3_UART_BAUD_RATE)) return FALSE;

          if (*uart_status_ptr & RXEMPTY) return FALSE;
	     *cp =  *uart_read_ptr;
          return TRUE;

}


int aa3uart_putc(unsigned char c, int echo)
{
      if (!aa3uart_is_open && !aa3uart_open(DEFAULT_AA3_UART_BAUD_RATE)) return FALSE;

	while (!(*uart_status_ptr & TXEMPTY)) {};

	*uart_write_ptr = c;
//	if (echo) fputc(c, stdout);
	if (echo) fputc(c, 0);

	return TRUE;
}



 #define MAX_GETLINE_GETC 10

    // not interrupt driven  - waits for carriage return
int aa3uart_getline(unsigned char * buf, int max_bytes) // returns 0 on no data, else bytes read
{
	int i =0;
        int fail_count;
        unsigned char c;

	

        fail_count = 0;
	
	while( fail_count < MAX_GETLINE_GETC && i < max_bytes )
         {

          if( aa3uart_getc(&c))
	   {
               buf[i++] = c;

             if (c == LINE_FEED || !c || c == 3 || c == 4 || c  == 10 ||
                 c == 11 || c == 12 || c== 13)
              {
		buf[i] = '\0';
                break;
	      }
            }
          else ++fail_count;

	}

	buf[i] = '\0';



	return i;

}
 
   

int aa3uart_puts(unsigned char * buf, int max_bytes, int echo) // returns 0 on no data, else bytes read
{
	int i =0;
	char c;


	
	if (buf == aa3uart_read_buffer) 
	{

        for (i =0; i < max_bytes && aa3uart_read_buffer_bytes > 0 ; i++)
  	   {
	      c = aa3uart_read_buffer[aa3r_read_index++];
	      if (aa3r_read_index >= MAX_CIRC_BUFFER) aa3r_read_index = 0;
	      --aa3uart_read_buffer_bytes;
		  aa3uart_putc(c, echo);
	   }
	 
	}
	else
	{
	   for (i =0; i < max_bytes && buf[i]; i++)
	   {
	    aa3uart_putc(buf[i], echo);
	   }
	}

	


	return i;
}


 




