#ifndef __mqx_arc_h__
#define __mqx_arc_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***  This file contains ARC-specifc defins with MQX RTOS.
***                                                               
**************************************************************************
**END*********************************************************/


#include "mqx.h"
#include "psp.h"
#include "cache.h"

#define _disable_interrupts()                _int_disable()
#define _enable_interrupts()                 _int_enable()

typedef  uint_32  VUSB_REGISTER;
#define  BSP_MAX_USB_DRIVERS                 (1)
#define  BSP_VUSB20_HOST_BASE_ADDRESS0       (0xFC5100)
#define  BSP_VUSB20_HOST_VECTOR0             (5)
#define  ARC_JMP_TO_ADDR_INSTRN              ((uint_32)(0x381F0000))

#define  BSP_VUSB20_DEVICE_BASE_ADDRESS0     (0xFC5100)
#define  BSP_VUSB20_DEVICE_VECTOR0           (5)
#define  ARC_JMP_TO_ADDR_INSTRN              ((uint_32)(0x381F0000))

#define  BSP_VUSB20_OTG_BASE_ADDRESS0        (0xFC5100)
#define  BSP_VUSB20_OTG_VECTOR0              (5)
#define  BSP_VUSB20_OTG_USB_OFFSET           (0x70)

/* The ARC is little-endian, just like USB */
#define USB_uint_16_low(x)          ((x) & 0xFF)
#define USB_uint_16_high(x)         (((x) >> 8) & 0xFF)

#ifdef __USB_OTG__
#include "hostapi.h"
#include "devapi.h"
#include "otgapi.h"
#include "usbprv_host.h"
#include "usbprv_dev.h"
#include "usbprv_otg.h"
#endif

#ifdef __USB_HOST__
#include "hostapi.h"
#include "usbprv_host.h"
#endif

#ifdef __USB_DEVICE__
#include "devapi.h"
#include "usbprv_dev.h"
#endif

/*
**
** Low-level function list structure for USB
**
** This is the structure used to store chip specific functions to be called 
** by generic layer
*/
typedef struct usb_chip_function_struct
{
#ifdef __USB_OTG__
   /* The device number */
   uint_32             DEV_NUM;
  
   /* The Host/Device init function */
   uint_8   (_CODE_PTR_ DEV_INIT)(uint_8, _usb_device_handle);

   /* The function to send data */
   uint_8 (_CODE_PTR_ DEV_SEND)(_usb_device_handle, XD_STRUCT_PTR);

   /* The function to receive data */
   uint_8 (_CODE_PTR_ DEV_RECV)(_usb_device_handle, XD_STRUCT_PTR);
   
   /* The function to cancel the transfer */
   uint_8 (_CODE_PTR_ DEV_CANCEL_TRANSFER)(_usb_device_handle, uint_8, uint_8);
   
   uint_8 (_CODE_PTR_ DEV_INIT_ENDPOINT)(_usb_device_handle, XD_STRUCT_PTR);
   
   uint_8 (_CODE_PTR_ DEV_DEINIT_ENDPOINT)(_usb_device_handle, uint_8, uint_8);
   
   void (_CODE_PTR_ DEV_UNSTALL_ENDPOINT)(_usb_device_handle, uint_8, uint_8);
   
   uint_8 (_CODE_PTR_ DEV_GET_ENDPOINT_STATUS)(_usb_device_handle, uint_8);
   
   void (_CODE_PTR_ DEV_SET_ENDPOINT_STATUS)(_usb_device_handle, uint_8, uint_8);

   void (_CODE_PTR_ DEV_RESET_DATA_TOGGLE)(_usb_device_handle, uint_8, uint_8);

   uint_8 (_CODE_PTR_ DEV_GET_TRANSFER_STATUS)(_usb_device_handle, uint_8, uint_8);
   
   void (_CODE_PTR_ DEV_SET_ADDRESS)(_usb_device_handle, uint_8);
   
   void (_CODE_PTR_ DEV_SHUTDOWN)(_usb_device_handle);
   
   void (_CODE_PTR_ DEV_GET_SETUP_DATA)(_usb_device_handle, uint_8, uchar_ptr);
   
   void (_CODE_PTR_ DEV_ASSERT_RESUME)(_usb_device_handle);
   
   void (_CODE_PTR_ DEV_STALL_ENDPOINT)(_usb_device_handle, uint_8, uint_8);
   
   /* The Host/Device init function */
   uint_8   (_CODE_PTR_ HOST_INIT)(_usb_host_handle);

   /* The function to shutdown the host/device */
   void   (_CODE_PTR_ HOST_SHUTDOWN)(_usb_host_handle);

   /* The function to send data */
   USB_STATUS (_CODE_PTR_ HOST_SEND)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR, PIPE_TR_STRUCT_PTR);

   /* The function to send setup data */
   USB_STATUS (_CODE_PTR_ HOST_SEND_SETUP)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR, PIPE_TR_STRUCT_PTR);

   /* The function to receive data */
   USB_STATUS (_CODE_PTR_ HOST_RECV)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR, PIPE_TR_STRUCT_PTR);
   
   /* The function to get the transfer status */
   uint_8 (_CODE_PTR_ HOST_STATUS)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR); 
   
   /* The function to cancel the transfer */
   void (_CODE_PTR_ HOST_CANCEL)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR, PIPE_TR_STRUCT_PTR);
   
   /* The function to do USB sleep */
   void (_CODE_PTR_ HOST_SLEEP)(_usb_host_handle); 
   
   /* The function for USB bus control */
   void  (_CODE_PTR_ HOST_BUS_CONTROL)(_usb_host_handle, uint_8);

   uint_32 (_CODE_PTR_ HOST_ALLOC_BANDWIDTH)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);

   void (_CODE_PTR_ HOST_FREE_CONTROLLER_RESOURCE)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
  
   uint_32 (_CODE_PTR_ HOST_EHCI_GET_FRAME_NUM)(_usb_host_handle); 
   
   uint_32 (_CODE_PTR_ HOST_EHCI_GET_MICRO_FRAME_NUM)(_usb_host_handle); 
  
   /* The USB OTG init function */
   uint_8   (_CODE_PTR_ OTG_INIT)(_usb_otg_handle);

   /* The function to shutdown the host/device */
   void   (_CODE_PTR_ OTG_SHUTDOWN)(_usb_otg_handle);
#endif

#ifdef __USB_HOST__
   /* The device number */
   uint_32             DEV_NUM;
   /* The Host/Device init function */
   uint_8   (_CODE_PTR_ HOST_INIT)(_usb_host_handle);

   /* The function to shutdown the host/device */                                 \
   void   (_CODE_PTR_ HOST_SHUTDOWN)(_usb_host_handle);

   /* The function to send data */
   USB_STATUS (_CODE_PTR_ HOST_SEND)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR, PIPE_TR_STRUCT_PTR);

   /* The function to send setup data */
   USB_STATUS (_CODE_PTR_ HOST_SEND_SETUP)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR, PIPE_TR_STRUCT_PTR);

   /* The function to receive data */
   USB_STATUS (_CODE_PTR_ HOST_RECV)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR, PIPE_TR_STRUCT_PTR);
   
   /* The function to get the transfer status */
   uint_8 (_CODE_PTR_ HOST_STATUS)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR); 
   
   /* The function to cancel the transfer */
   void (_CODE_PTR_ HOST_CANCEL)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR, PIPE_TR_STRUCT_PTR);
   
   /* The function to do USB sleep */
    void (_CODE_PTR_ HOST_SLEEP)(_usb_host_handle); 
   
   /* The function for USB bus control */
   void  (_CODE_PTR_ HOST_BUS_CONTROL)(_usb_host_handle, uint_8);

   uint_32 (_CODE_PTR_ HOST_ALLOC_BANDWIDTH)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);

   void (_CODE_PTR_ HOST_FREE_CONTROLLER_RESOURCE)(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
  
   uint_32 (_CODE_PTR_ HOST_EHCI_GET_FRAME_NUM)(_usb_host_handle); 
   
   uint_32 (_CODE_PTR_ HOST_EHCI_GET_MICRO_FRAME_NUM)(_usb_host_handle); 
   
#endif
#ifdef __USB_DEVICE__
   /* The device number */
   uint_32             DEV_NUM;

   /* The Host/Device init function */
   uint_8   (_CODE_PTR_ DEV_INIT)(uint_8, _usb_device_handle);

   /* The function to send data */
   uint_8 (_CODE_PTR_ DEV_SEND)(_usb_device_handle, XD_STRUCT_PTR);

   /* The function to receive data */
   uint_8 (_CODE_PTR_ DEV_RECV)(_usb_device_handle, XD_STRUCT_PTR);
   
   /* The function to cancel the transfer */
   uint_8 (_CODE_PTR_ DEV_CANCEL_TRANSFER)(_usb_device_handle, uint_8, uint_8);
   
   uint_8 (_CODE_PTR_ DEV_INIT_ENDPOINT)(_usb_device_handle, XD_STRUCT_PTR);
   
   uint_8 (_CODE_PTR_ DEV_DEINIT_ENDPOINT)(_usb_device_handle, uint_8, uint_8);
   
   void (_CODE_PTR_ DEV_UNSTALL_ENDPOINT)(_usb_device_handle, uint_8, uint_8);
   
   uint_8 (_CODE_PTR_ DEV_GET_ENDPOINT_STATUS)(_usb_device_handle, uint_8);
   
   void (_CODE_PTR_ DEV_SET_ENDPOINT_STATUS)(_usb_device_handle, uint_8, uint_8);

   void (_CODE_PTR_ DEV_RESET_DATA_TOGGLE)(_usb_device_handle, uint_8, uint_8);

   uint_8 (_CODE_PTR_ DEV_GET_TRANSFER_STATUS)(_usb_device_handle, uint_8, uint_8);
   
   void (_CODE_PTR_ DEV_SET_ADDRESS)(_usb_device_handle, uint_8);
   
   void (_CODE_PTR_ DEV_SHUTDOWN)(_usb_device_handle);
   
   void (_CODE_PTR_ DEV_GET_SETUP_DATA)(_usb_device_handle, uint_8, uchar_ptr);
   
   void (_CODE_PTR_ DEV_ASSERT_RESUME)(_usb_device_handle);
   
   void (_CODE_PTR_ DEV_STALL_ENDPOINT)(_usb_device_handle, uint_8, uint_8);
#endif

} USB_CALLBACK_FUNCTIONS_STRUCT, _PTR_ USB_CALLBACK_FUNCTIONS_STRUCT_PTR;


extern USB_CALLBACK_FUNCTIONS_STRUCT _bsp_usb_callback_table;

#ifdef __cplusplus
extern "C" {
#endif
extern uint_8 _usb_driver_install(uint_32, pointer);
#ifdef __cplusplus
}
#endif

#endif
