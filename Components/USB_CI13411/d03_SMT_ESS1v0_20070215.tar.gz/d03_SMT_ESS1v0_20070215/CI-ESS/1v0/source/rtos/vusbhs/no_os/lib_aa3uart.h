#ifndef LIB_AA3UART_H
#define LIB_AA3UART_H

/*******************************************************************************
** File          : lib_aa3uart.h Example Simulator File I/O
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************/

#ifdef __CPLUSPLUS__ 
extern "C" {
#endif

#ifdef __cplusplus 
extern "C" {
#endif

#define CARRIAGE_RETURN 0x0D
#define LINE_FEED       0x0A

#ifndef MAX_PATH
   #define MAX_PATH 250
#endif

#define TRUE 1
#define FALSE 0


#define SEMBIT0 1 // constant to indicate semaphore bit 0

#define STATUS_REG 0


#define UART_ADDRESS_DIFF (1<<8) 

#define MAX_CIRC_BUFFER 0x512
#define MAX_BAUD_RATE 115200 
#define MIN_BAUD_RATE 300 

#pragma on(volatile_cache_bypass)
extern volatile unsigned char  * uart_status_reg_ptr;
extern volatile unsigned char  * uart_read_ptr;
extern volatile unsigned char  * uart_write_ptr;
extern volatile unsigned char  * uart_baud_hi_ptr;
extern volatile unsigned char  * uart_baud_lo_ptr;
//#pragma pop(volatile_cache_bypass)

extern unsigned char aa3uart_read_buffer[]; 
extern int aa3uart_read_buffer_bytes;


extern int aa3uart_open(unsigned long baud);
           // returns 1 on success, else 0

extern int aa3uart_close(void); // turns off interrupts

extern int aa3uart_getc(unsigned char * cp); // returns 0 on not data direct from port

extern int aa3uart_getline(unsigned char * buf, int max_bytes); // returns 0 on no data, else bytes read

extern int aa3uart_putc(unsigned char c, int echo); // return 1 if written, 0 on error

extern int aa3uart_puts(unsigned char *buf, int max_bytes, int echo);  // return number of bytes written, 0 on error


#ifdef __CPLUSPLUS__
}
#endif

#ifdef __cplusplus
}
#endif

#endif
