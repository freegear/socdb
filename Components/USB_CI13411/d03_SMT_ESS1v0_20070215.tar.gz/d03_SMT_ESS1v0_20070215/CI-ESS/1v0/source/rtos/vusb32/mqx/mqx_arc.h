#ifndef __mqx_arc_h__
#define __mqx_arc_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***  This file contains ARC-specifc defins with MQX RTOS.
***                                                               
**************************************************************************
**END*********************************************************/
#include "mqx.h"
#include "psp.h"
#include "cache.h"
/**********************************************************/

#define _disable_interrupts()                _int_disable()
#define _enable_interrupts()                 _int_enable()

typedef  uint_32  VUSB_REGISTER;
#define  BSP_MAX_USB_DRIVERS                 (1)

#define  ARC_JMP_TO_ADDR_INSTRN              ((uint_32)(0x381F0000))

#ifdef _DATA_CACHE_
	#define  BSP_VUSB11_HOST_BASE_ADDRESS0       (0xFC4080)
	#define  BSP_VUSB11_HOST_VECTOR0             (4)
	#define  BSP_VUSB11_DEVICE_BASE_ADDRESS0     (0xFC4080)
	#define  BSP_VUSB11_DEVICE_VECTOR0           (4)
	#define  BSP_VUSB11_OTG_BASE_ADDRESS0        (0xFC4080)
	#define  BSP_VUSB11_OTG_VECTOR0              (4)
	#define  BSP_VUSB11_OTG_USB_OFFSET           (0x70)
#else
	#define  BSP_VUSB11_HOST_BASE_ADDRESS0       (0xFC4080)
	#define  BSP_VUSB11_HOST_VECTOR0             (6)
	#define  BSP_VUSB11_DEVICE_BASE_ADDRESS0     (0xFC4080)
	#define  BSP_VUSB11_DEVICE_VECTOR0           (6)
	#define  BSP_VUSB11_OTG_BASE_ADDRESS0        (0xFC4080)
	#define  BSP_VUSB11_OTG_VECTOR0              (6)
	#define  BSP_VUSB11_OTG_USB_OFFSET           (0x70)
#endif

#define  ARC_JMP_TO_ADDR_INSTRN              ((uint_32)(0x381F0000))


/* The ARC is little-endian, just like USB */
#define USB_uint_16_low(x)                   ((x) & 0xFF)
#define USB_uint_16_high(x)                  (((x) >> 8) & 0xFF)

#define  VUSB_ARC_BDT_OUT_BIT                (0x10)
#define  VUSB_ARC_BDT_IN_BIT                 (0x00)
#define  VUSB_ARC_BDT_ODD_EVEN_BIT           (0x08)

#define  VUSB_BDT_OUT_BIT                    (VUSB_ARC_BDT_OUT_BIT)
#define  VUSB_BDT_IN_BIT                     (VUSB_ARC_BDT_IN_BIT)
#define  VUSB_BDT_ODD_EVEN_BIT               (VUSB_ARC_BDT_ODD_EVEN_BIT)

#define  VUSB_GET_STATUS(BDT_ptr)            (BDT_ptr->PID & VUSB_BD_PID_MASKS)
#define  VUSB_GET_BYTE_COUNT(BDT_ptr)        (BDT_ptr->BC)
#define  VUSB_ENDPT_REG_OFFSET               (0x40)


#include "vusb32.h"

#ifdef __USB_OTG__
#include "hostapi.h"
#include "devapi.h"
#include "otgapi.h"
#include "usbprv_host.h"
#include "usbprv_dev.h"
#include "usbprv_otg.h"
#endif

#ifdef __USB_HOST__ 
#include "hostapi.h"
#include "usbprv_host.h"
#endif

#ifdef __USB_DEVICE__
#include "usbprv_dev.h"
#endif


/*
**
** Low-level function list structure for USB
**
** This is the structure used to store chip specific functions to be called 
** by generic layer
*/
typedef struct usb_chip_function_struct
{
#ifdef __USB_OTG__
   /* The device number */
   uint_32             DEV_NUM;
  
   /* The Host/Device init function */
   uint_8   (_CODE_PTR_ DEV_INIT)(pointer);

   /* The function to send data */
   void (_CODE_PTR_ DEV_SEND)(pointer, uint_8, uint_8);

   /* The function to receive data */
   void (_CODE_PTR_ DEV_RECV)(pointer, uint_8, uint_8);
   
   /* The function to cancel the transfer */
   void (_CODE_PTR_ DEV_CANCEL_TRANSFER)(pointer, uint_8, uint_8);
   
   void (_CODE_PTR_ DEV_INIT_ENDPOINT)(pointer, uint_8, XD_STRUCT_PTR);
   
   void (_CODE_PTR_ DEV_DEINIT_ENDPOINT)(pointer, uint_8, XD_STRUCT_PTR);
   
   void (_CODE_PTR_ DEV_UNSTALL_ENDPOINT)(pointer, uint_8);
   
   uint_8 (_CODE_PTR_ DEV_GET_ENDPOINT_STATUS)(pointer, uint_8);
   
   void (_CODE_PTR_ DEV_SET_ENDPOINT_STATUS)(pointer, uint_8, uint_8);
   
   uint_16 (_CODE_PTR_ DEV_GET_ADDRESS)(pointer);
   
   void (_CODE_PTR_ DEV_SET_ADDRESS)(pointer, uint_16);
   
   void (_CODE_PTR_ DEV_SHUTDOWN)(pointer);

   void (_CODE_PTR_ DEV_ASSERT_RESUME)(pointer);
   
   /* The Host/Device init function */
   uint_8   (_CODE_PTR_ HOST_INIT)(pointer);

   /* The function to shutdown the host/device */
   void   (_CODE_PTR_ HOST_SHUTDOWN)(pointer);

   /* The function to send data */
   void (_CODE_PTR_ HOST_SEND)(pointer, PIPE_DESCRIPTOR_STRUCT_PTR);

   /* The function to send setup data */
   void (_CODE_PTR_ HOST_SEND_SETUP)(pointer, PIPE_DESCRIPTOR_STRUCT_PTR);

   /* The function to receive data */
   void (_CODE_PTR_ HOST_RECV)(pointer, PIPE_DESCRIPTOR_STRUCT_PTR);
   
   /* The function to get the transfer status */
   uint_8 (_CODE_PTR_ HOST_STATUS)(pointer, PIPE_DESCRIPTOR_STRUCT_PTR);
   
   /* The function to cancel the transfer */
   void (_CODE_PTR_ HOST_CANCEL)(pointer, PIPE_DESCRIPTOR_STRUCT_PTR);
   
   /* The function to do USB sleep */
   void (_CODE_PTR_ HOST_SLEEP)(pointer);
   
   /* The function for USB bus control */
   void (_CODE_PTR_ HOST_BUS_CONTROL)(pointer, uint_8);

   /* The USB OTG init function */
   uint_8   (_CODE_PTR_ OTG_INIT)(_usb_otg_handle);

   /* The function to shutdown the host/device */
   void   (_CODE_PTR_ OTG_SHUTDOWN)(_usb_otg_handle);
#endif

#ifdef __USB_HOST__
   /* The device number */
   uint_32             DEV_NUM;
   
   /* The Host/Device init function */
   uint_8   (_CODE_PTR_ HOST_INIT)(pointer);

   /* The function to shutdown the host/device */
   void   (_CODE_PTR_ HOST_SHUTDOWN)(pointer);

   /* The function to send data */
   void (_CODE_PTR_ HOST_SEND)(pointer, PIPE_DESCRIPTOR_STRUCT_PTR);

   /* The function to send setup data */
   void (_CODE_PTR_ HOST_SEND_SETUP)(pointer, PIPE_DESCRIPTOR_STRUCT_PTR);

   /* The function to receive data */
   void (_CODE_PTR_ HOST_RECV)(pointer, PIPE_DESCRIPTOR_STRUCT_PTR);
   
   /* The function to get the transfer status */
   uint_8 (_CODE_PTR_ HOST_STATUS)(pointer, PIPE_DESCRIPTOR_STRUCT_PTR);
   
   /* The function to cancel the transfer */
   void (_CODE_PTR_ HOST_CANCEL)(pointer, PIPE_DESCRIPTOR_STRUCT_PTR);
   
   /* The function to do USB sleep */
   void (_CODE_PTR_ HOST_SLEEP)(pointer);
   
   /* The function for USB bus control */
   void (_CODE_PTR_ HOST_BUS_CONTROL)(pointer, uint_8);

   /* The USB OTG init function */
   uint_8   (_CODE_PTR_ OTG_INIT)(_usb_otg_handle);

   /* The function to shutdown the host/device */
   void   (_CODE_PTR_ OTG_SHUTDOWN)(_usb_otg_handle);
#endif
#ifdef __USB_DEVICE__
   /* The device number */
   uint_32             DEV_NUM;
  
   /* The Host/Device init function */
   uint_8   (_CODE_PTR_ DEV_INIT)(pointer);

   /* The function to send data */
   void (_CODE_PTR_ DEV_SEND)(pointer, uint_8, uint_8);

   /* The function to receive data */
   void (_CODE_PTR_ DEV_RECV)(pointer, uint_8, uint_8);
   
   /* The function to cancel the transfer */
   void (_CODE_PTR_ DEV_CANCEL_TRANSFER)(pointer, uint_8, uint_8);
   
   void (_CODE_PTR_ DEV_INIT_ENDPOINT)(pointer, uint_8, XD_STRUCT_PTR);
   
   void (_CODE_PTR_ DEV_DEINIT_ENDPOINT)(pointer, uint_8, XD_STRUCT_PTR);
   
   void (_CODE_PTR_ DEV_UNSTALL_ENDPOINT)(pointer, uint_8);
   
   uint_8 (_CODE_PTR_ DEV_GET_ENDPOINT_STATUS)(pointer, uint_8);
   
   void (_CODE_PTR_ DEV_SET_ENDPOINT_STATUS)(pointer, uint_8, uint_8);
   
   uint_16 (_CODE_PTR_ DEV_GET_ADDRESS)(pointer);
   
   void (_CODE_PTR_ DEV_SET_ADDRESS)(pointer, uint_16);
   
   void (_CODE_PTR_ DEV_SHUTDOWN)(pointer);

   void (_CODE_PTR_ DEV_ASSERT_RESUME)(pointer);
   
#endif

} USB_CALLBACK_FUNCTIONS_STRUCT, _PTR_ USB_CALLBACK_FUNCTIONS_STRUCT_PTR;


extern USB_CALLBACK_FUNCTIONS_STRUCT _bsp_usb_callback_table ;
extern uint_8 _usb_driver_install(uint_32, pointer);

#endif
