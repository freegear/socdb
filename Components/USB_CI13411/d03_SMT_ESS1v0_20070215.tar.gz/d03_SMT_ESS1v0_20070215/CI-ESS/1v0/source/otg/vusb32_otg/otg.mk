# VUSBHS otg driver

MQX_INCDIRS      +=$(USB_ROOT)$(PS)source$(PS)otg$(PS)vusb32_otg

srcdirs += otg$(PS)$(USB_DRIVER)_otg
otg_srcs    += \
    vusb32_otg


