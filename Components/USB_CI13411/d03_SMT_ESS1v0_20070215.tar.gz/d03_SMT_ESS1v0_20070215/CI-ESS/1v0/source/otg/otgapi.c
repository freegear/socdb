/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***  This file contains the USB On-The-Go generic functions.
***                                                               
**************************************************************************
**END*********************************************************/
#include "otgapi.h"
#include "usbprv_dev.h"
#include "usbprv_host.h"
#include "usbprv_otg.h"

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
#endif 

#ifdef _I2C_
   #include "i2c.h"
   #include "otg_i2c.h"
   #include "sa_uart.h"
#endif

#define LOG_TIMER(str)	/*uartputs(str)*/

#if defined(_I2C_) && defined(_SA_UART_)
boolean debug_set_state = FALSE;

#define SET_STATE(state, ordinal)			\
	{										\
	s_ptr->STATE = (state);					\
	if (debug_set_state)					\
		{									\
		if (state == OTG_START)				\
			uartputs("\n_>");				\
		if (state == A_IDLE)				\
			uartputs("\nA>");				\
		if (state == B_IDLE)				\
			uartputs("\nB>");				\
		if (1)								\
			{								\
			uartputs("\n");					\
			uartputs(state_name[state]);	\
			uartputs("-");					\
			uartputs(ordinal);				\
			}								\
		}									\
	}
#else
#define SET_STATE(state, ordinal)		 s_ptr->STATE = (state)
#endif

USB_OTG_STATE_STRUCT_PTR usb_otg_state_struct_ptr;
extern USB_DEV_STATE_STRUCT_PTR global_usb_device_state_struct_ptr;
#ifndef PERIPHERAL_ONLY
extern USB_HOST_STATE_STRUCT_PTR usb_host_state_struct_ptr;
#endif

boolean	bVRISE_TIMEDOUT;
uint_32 suspend_done = FALSE;

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_init
* Returned Value : USB_OK or error code
* Comments       :
*     The _usb_otg_init routine initializes the USB OTG API data structures
*     and the OTG hardware.
* 
*END*--------------------------------------------------------------------*/
uint_8 _usb_otg_init
   (
      /* [IN] Device number to initialize */
      uint_8                     device_number,

      /* [IN] the usb otg initialize data structure */
      USB_OTG_INIT_STRUCT_PTR    init_ptr,

      /* [OUT] the usb device handle */
      _usb_otg_handle _PTR_      handle
   )
{ /* Body */
   uint_8                        returncode;
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   
#ifdef __USB_OS_MQX__   
   USB_CALLBACK_FUNCTIONS_STRUCT_PTR call_back_table_ptr;
#endif
   
   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_init");
   #endif
   /* 
   ** Check the input data: When a_bus_drop is TRUE, then a_bus_req must be 
   ** FALSE. Section 6.6.1.1.
   */
   if (init_ptr->A_BUS_DROP && init_ptr->A_BUS_REQ) {
      return USBERR_INIT_DATA; 
   } /* Endif */ 
   
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)
      USB_memalloc(sizeof(USB_OTG_STATE_STRUCT));
      
   if (usb_otg_ptr == NULL) 
   {
      #ifdef _OTG_DEBUG_
         DEBUG_LOG_TRACE("_usb_otg_init, malloc error");
      #endif
      return USBERR_ALLOC;
   } /* Endif */
   
   USB_memzero((uchar_ptr)usb_otg_ptr, sizeof(USB_OTG_STATE_STRUCT));
   
   usb_otg_ptr->STATE_STRUCT_PTR = (OTG_STATE_MACHINE_STRUCT_PTR)
      USB_memalloc(sizeof(OTG_STATE_MACHINE_STRUCT));
      
   if (usb_otg_ptr->STATE_STRUCT_PTR == NULL) 
   {
      #ifdef _OTG_DEBUG_
         DEBUG_LOG_TRACE("_usb_otg_init, malloc error");
      #endif
      return USBERR_ALLOC;
   } /* Endif */
   
   USB_memzero((uchar_ptr)usb_otg_ptr->STATE_STRUCT_PTR, sizeof(OTG_STATE_MACHINE_STRUCT));
   
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   
   usb_otg_ptr->DEV_NUM = device_number;
   
#ifdef __USB_OS_MQX__   
   call_back_table_ptr = (USB_CALLBACK_FUNCTIONS_STRUCT_PTR)
      _mqx_get_io_component_handle(IO_USB_COMPONENT);
   
   usb_otg_ptr->CALLBACK_STRUCT_PTR = (call_back_table_ptr + device_number);
      
   if (!usb_otg_ptr->CALLBACK_STRUCT_PTR) {
      USB_memfree((pointer)usb_otg_ptr);
      #ifdef _OTG_DEBUG_
         DEBUG_LOG_TRACE("_usb_otg_init, MQX driver not installed");
      #endif
      return USBERR_DRIVER_NOT_INSTALLED;
   } /* Endif */
#endif

   /* Initialize the state structure with default values.*/
   s_ptr->A_BUS_DROP = init_ptr->A_BUS_DROP;
   s_ptr->A_BUS_REQ  = init_ptr->A_BUS_REQ;
   s_ptr->B_BUS_REQ  = init_ptr->B_BUS_REQ;
   SET_STATE(OTG_START, "c ");
   usb_otg_ptr->SERVICE = init_ptr->SERVICE;
   
   /* Don't automatically do SRP. Let the application control it */
#if 0
   if ((!init_ptr->A_BUS_REQ) && (init_ptr->B_BUS_REQ)) {
      usb_otg_ptr->DO_SRP = TRUE;
   } /* Endif */
#endif
      
   /* Initialize the state structure */
   _usb_otg_reset_state_machine(usb_otg_ptr);
   
   *handle = (_usb_otg_handle)usb_otg_ptr;
   usb_otg_state_struct_ptr = usb_otg_ptr;
   
   
#ifndef __USB_OS_MQX__
#ifdef __VUSB32__
   returncode = _usb_otg_vusb11_init(*handle);
#endif
#ifdef __VUSBHS__
   returncode = _usb_otg_vusbhs_init(*handle);
#endif
#else
   returncode = ((USB_CALLBACK_FUNCTIONS_STRUCT_PTR)\
      usb_otg_ptr->CALLBACK_STRUCT_PTR)->OTG_INIT((_usb_otg_handle)usb_otg_ptr);
#endif
   
   if (returncode != USB_OK) {
      /* There was an error during initialization. Free all the 
      ** allocated memory 
      */
      USB_memfree((pointer)usb_otg_ptr);
      #ifdef _OTG_DEBUG_
         DEBUG_LOG_TRACE("_usb_otg_init, error failed");
      #endif
      return returncode;
   } /* Endif */

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_init, SUCCESSFUL");
   #endif
   return USB_OK;
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_otg_shutdown
*  Returned Value : 
*  Comments       :
*        Shutdown an initialized USB OTG device.
*
*END*-----------------------------------------------------------------*/
void _usb_otg_shutdown
   (
      /* [IN] the USB_otg_initialize state structure */
      _usb_otg_handle         handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR   usb_otg_ptr;
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_shutdown");
   #endif
   
   if (usb_otg_ptr->STATE_STRUCT_PTR->DEVICE_UP) {
       _usb_device_shutdown(global_usb_device_state_struct_ptr);
   } /* Endif */

#ifndef PERIPHERAL_ONLY   
   if(usb_otg_ptr->STATE_STRUCT_PTR->HOST_UP){
       _usb_host_shutdown(usb_host_state_struct_ptr);
   } /* Endif */
#endif
   
#ifndef __USB_OS_MQX__   
#ifdef __VUSB32__
   _usb_otg_vusb11_shutdown((_usb_otg_handle)usb_otg_ptr);
#endif

#ifdef __VUSBHS__
   _usb_otg_vusbhs_shutdown((_usb_otg_handle)usb_otg_ptr);
#endif
#else
    ((USB_CALLBACK_FUNCTIONS_STRUCT_PTR)\
      usb_otg_ptr->CALLBACK_STRUCT_PTR)->OTG_SHUTDOWN((_usb_otg_handle)usb_otg_ptr);
#endif
   /* Free the state infor struct */
   USB_memfree((pointer)usb_otg_ptr->STATE_STRUCT_PTR);
   
   /* Free all internal resources allocated */
   USB_memfree((pointer)usb_otg_ptr);

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_shutdown, SUCCESSFUL");
   #endif
   
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_set_status
* Returned Value : USB_OK or error code
* Comments       :
*     Set the value of a specified OTG parameter.
* 
*END*--------------------------------------------------------------------*/
uint_8 _usb_otg_set_status
   (
      /* [IN] Handle to the usb device */
      _usb_otg_handle   handle,
      
      /* [IN] What to set the status of */
      uint_8            component,
      
      /* [IN] What to set the status to */
      boolean           status
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR   usb_otg_ptr;
   boolean                    state_change;
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_set_status");
   #endif
   
   if (component < USB_OTG_A_BUS_DROP) {
      state_change = TRUE;
   } else {
      state_change = FALSE;
   } /* Endif */
   USB_lock();
   switch (component) {
      
#ifndef PERIPHERAL_ONLY
      case USB_OTG_A_SET_B_HNP_ENABLE:
         usb_otg_ptr->STATE_STRUCT_PTR->A_SET_B_HNP_EN = status;
         break;

      case USB_OTG_A_BUS_DROP:
         usb_otg_ptr->STATE_STRUCT_PTR->A_BUS_DROP = status;
         break;

      case USB_OTG_A_BUS_REQ:
         usb_otg_ptr->STATE_STRUCT_PTR->A_BUS_REQ = status;
         break;
      
      case USB_OTG_A_BUS_SUSPEND_REQ:
         usb_otg_ptr->STATE_STRUCT_PTR->A_BUS_SUSPEND_REQ = status;
         break;
      
      case USB_OTG_A_BUS_SUSPEND:
         usb_otg_ptr->STATE_STRUCT_PTR->A_BUS_SUSPEND = status;
         break;
      
      case USB_OTG_A_CONN:
         usb_otg_ptr->STATE_STRUCT_PTR->A_CONN = status;
         break;
      
      case USB_OTG_HOST_ACTIVE:
         usb_otg_ptr->STATE_STRUCT_PTR->HOST_UP = status;
         break;
      
      case USB_OTG_A_VBUS_ON:
        /*
        ** The A-device turn ON V_BUS:
        ** if the A-device application is not wanting to drop 
        ** the bus (a_bus_drop = FALSE), and if the A-device Application 
        ** is requesting the bus (a_bus_req = TRUE), or SRP is detected 
        ** on the bus (a_srp_det = TRUE).
        */
        usb_otg_ptr->STATE_STRUCT_PTR->A_BUS_DROP = FALSE;
        usb_otg_ptr->STATE_STRUCT_PTR->A_BUS_REQ = TRUE;
        break;
      
      case USB_OTG_A_BUS_RESUME:
         usb_otg_ptr->STATE_STRUCT_PTR->A_BUS_RESUME = status;
         break;
#endif         
     
      case USB_OTG_B_HNP_ENABLE:
         usb_otg_ptr->STATE_STRUCT_PTR->B_HNP_ENABLE = status;
         break;
      
      case USB_OTG_B_BUS_REQ:
         usb_otg_ptr->STATE_STRUCT_PTR->B_BUS_REQ = status;
         break;
     
      case USB_OTG_B_CONN:
#if 0
uartputs("\nsetting USB_OTG_B_CONN=");
if (status)
	uartputs("TRUE");
else
	uartputs("FALSE");
#endif

         usb_otg_ptr->STATE_STRUCT_PTR->B_CONN = status;
         break;
     
      case USB_OTG_B_BUS_SUSPEND:
         usb_otg_ptr->STATE_STRUCT_PTR->B_BUS_SUSPEND = status;
         break;

      case USB_OTG_B_BUS_RESUME:
         usb_otg_ptr->STATE_STRUCT_PTR->B_BUS_RESUME = status;
         break;
     
      case USB_OTG_DEVICE_ACTIVE:
         usb_otg_ptr->STATE_STRUCT_PTR->DEVICE_UP = status;
         break;
    
      case USB_OTG_B_SRP_REQ:
        if (usb_otg_ptr->STATE_STRUCT_PTR->STATE != B_IDLE) {
           USB_unlock();
         #ifdef _OTG_DEBUG_
            DEBUG_LOG_TRACE("_usb_otg_set_status, invalid state");
         #endif
           return  USBERR_SRP_REQ_INVALID_STATE;
        } /* Endif */
        /* 
        ** set the user condition to start SRP. When we call the state 
        ** machine  SRP req will be activated if preconditions are met
        */
#ifdef PERIPHERAL_ONLY
        usb_otg_ptr->STATE_STRUCT_PTR->B_SESS_REQ = TRUE;
#endif        
        usb_otg_ptr->STATE_STRUCT_PTR->B_BUS_REQ = TRUE;
        break;
      
      default:
        USB_unlock();

         #ifdef _OTG_DEBUG_
            DEBUG_LOG_TRACE("_usb_otg_set_status, bad status");
         #endif
        
        return USBERR_BAD_STATUS;
   } /* Endswitch */
   
   if (state_change) {
      _usb_otg_state_machine((_usb_otg_handle)usb_otg_ptr);
   } /* Endif */
   USB_unlock();
   
   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_set_status, SUCCESSFUL");
   #endif
   
   return USB_OK;   
} /* EndBody */   


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_get_status
* Returned Value : USB_OK or error code
* Comments       :
*     Get the value of a specified OTG parameter.
* 
*END*--------------------------------------------------------------------*/
uint_8 _usb_otg_get_status
   (
      /* [IN] Handle to the USB otg */
      _usb_otg_handle      handle,
      
      /* [IN] What to get the status of */
      uint_8               component,
      
      /* [OUT] The requested status */
      uint_32_ptr          status
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR usb_otg_ptr;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_get_status");
   #endif
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   
   USB_lock();
   switch (component) {
#ifndef PERIPHERAL_ONLY
      case USB_OTG_A_SET_B_HNP_ENABLE:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->A_SET_B_HNP_EN;
         break;
      
      case USB_OTG_A_BUS_DROP:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->A_BUS_DROP;
         break;
      
      case USB_OTG_A_BUS_REQ:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->A_BUS_REQ;
         break;
    
      case USB_OTG_A_BUS_SUSPEND:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->A_BUS_SUSPEND;
         break;
    
      case USB_OTG_A_CONN:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->A_CONN;
         break;
       
      case USB_OTG_A_BUS_RESUME:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->A_BUS_RESUME;
         break;
    
      case USB_OTG_HOST_ACTIVE:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->HOST_UP;
         break;
#endif     
      case USB_OTG_STATE:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->STATE;
         break;

      case USB_OTG_B_HNP_ENABLE:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->B_HNP_ENABLE;
         break;

      case USB_OTG_B_BUS_REQ:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->B_BUS_REQ;
         break;
     
      case USB_OTG_B_CONN:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->B_CONN;
         break;
     
      case USB_OTG_B_BUS_SUSPEND:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->B_BUS_SUSPEND;
         break;
     
      case USB_OTG_B_BUS_RESUME:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->B_BUS_RESUME;
         break;
     
      case USB_OTG_DEVICE_ACTIVE:
         *status = usb_otg_ptr->STATE_STRUCT_PTR->DEVICE_UP;
         break;
     
      default:
         USB_unlock();
         #ifdef _OTG_DEBUG_
            DEBUG_LOG_TRACE("_usb_otg_get_status, bad status");
         #endif
         return USBERR_BAD_STATUS;
   } /* Endswitch */
   USB_unlock();

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_get_status, SUCCESSFUL");
   #endif
   return USB_OK;   
} /* EndBody */  

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_state_machine
* Returned Value : None
* Comments       :
*                The OTG state machine.
* 
*END*--------------------------------------------------------------------*/
void  _usb_otg_state_machine
   (
      /* [IN] Handle to the USB otg */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   OTG_STRUCT_PTR                otg_reg;
   USB_STRUCT_PTR                usb_reg;
   uint_8                        state;
   uint_32                       hw_signal;
   static uint_32                recursive = 0xffffffff;
   static boolean                bTriedToRecurse = FALSE;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_state_machine");
   #endif

   
   /*
   ** We prevent recursion to make sure that all state transition actions occur
   ** in the proper sequence, but we do call _usb_otg_state_machine again at the
   ** end of the function if recursion was attempted
   */
   recursive++;
   if (recursive) {
      bTriedToRecurse = TRUE;
      goto done;
   } /* Endif */
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   otg_reg = usb_otg_ptr->OTG_REG_PTR; 
   usb_reg = usb_otg_ptr->USB_REG_PTR;
   state = s_ptr->STATE;
   hw_signal = s_ptr->OTG_INT_STATUS;
 
#ifdef OTG_LOG_STATE
   usb_otg_ptr->LOG_STATE[usb_otg_ptr->LOG_STATE_COUNT++] = 
      usb_otg_ptr->STATE_STRUCT_PTR->STATE;
   if (usb_otg_ptr->LOG_STATE_COUNT >= 99) {
      usb_otg_ptr->LOG_STATE_COUNT = 0;
  } /* Endif */
#endif 
   
#ifdef PERIPHERAL_ONLY 
   switch (state) {
      case B_IDLE:
         _usb_otg_process_b_idle((pointer)usb_otg_ptr);
         break;
      case B_SRP_INIT:
         _usb_otg_process_b_srp_init((pointer)usb_otg_ptr);
         break;
      case B_PERIPHERAL:
         if (SESS_VLD_FALSE(otg_reg)) {
            SET_STATE(B_IDLE, "C ");
            s_ptr->B_BUS_REQ = FALSE;
            VBUS_CHG_OFF(otg_reg);
            VBUS_DSCHG_ON(otg_reg);
         } /* Endif */
         break;
      default:
         break;
   } /* Endswitch */
#else 
   
   /*
   ** process exception if  not start state
   */
   if (state) {
      if (_usb_otg_process_exceptions((pointer)usb_otg_ptr) ){
         if (state != s_ptr->STATE) {
#ifdef OTG_LOG_STATE
            usb_otg_ptr->LOG_STATE[usb_otg_ptr->LOG_STATE_COUNT++] = 
               usb_otg_ptr->STATE_STRUCT_PTR->STATE;
            if (usb_otg_ptr->LOG_STATE_COUNT>=99) {
               usb_otg_ptr->LOG_STATE_COUNT = 0;
            } /* Endif */
#endif 
         goto done;  /* state is changed so return */
         }
      } /* Endif */
   } /* Endif */
   
   switch (state) {
      case OTG_START:
         if(ID(otg_reg)) {
            SET_STATE(B_IDLE, "D ");
            _usb_otg_process_b_idle((pointer)usb_otg_ptr);
            break;
         } else {
            /* ID is false when A device is identified */
            SET_STATE(A_IDLE, "E ");
         } /* Endif */
         /* Fall through the A_IDLE state */
      case A_IDLE:
         _usb_otg_process_a_idle((pointer)usb_otg_ptr);
         break;
      
      case A_WAIT_VRISE:
         _usb_otg_process_a_wait_vrise((pointer)usb_otg_ptr);
         break;
      
      case A_WAIT_BCON:
         /*
         ** After waiting long enough to insure that the D+ line cannot 
         ** be high due to the residual effect of the A-device pull-up, 
         ** (see Section 5.1.9), the A-device sees that the D+ line 
         ** is high (and D- low) indicating that the B-device is 
         ** signaling a connect and is ready to respond as a Peripheral. 
         ** At this point, the A-device becomes Host and asserts bus 
         ** reset to start using the bus.
         */
         if (s_ptr->B_CONN) {
            s_ptr->B_BUS_SUSPEND = FALSE;
            SET_STATE(A_HOST, "d ");

            /* Turn Off the A_WAIT_BCON timer since we are exiting the state */
            TA_WAIT_BCON_TMR_OFF(s_ptr);
            /* 
            ** If the B device is not supported by A device 
            ** a _bus_req = FALSE will set by the application  
            ** during initial communication with the device
            */
         } else if (TA_WAIT_BCON_TMR_EXPIRED(s_ptr)) {
            TA_WAIT_BCON_TMR_OFF(s_ptr);
            SET_STATE(A_WAIT_VFALL, "e ");
            _usb_otg_process_a_wait_vfall(usb_otg_ptr);
         } /* Endif */
         /* Turn off this timer if it is still on from the A-peripheral state */
         TA_BIDL_ADIS_TMR_OFF(s_ptr);
         break;
      
      case A_HOST:
         /*
         ** If mini B plug is removed RESET (DETACH) interrupt will 
         ** happen on A-Device.The DETACH will processed by the host 
         ** ISR  and set b_conn to  FALSE 
         */
         if (!s_ptr->B_CONN) {
            /* switch to  a_wait_bcon */
            SET_STATE(A_WAIT_BCON, "f ");

            /* Turn on the A_WAIT_BCON timer since we are in A_WAIT_BCON state */
            TA_WAIT_BCON_TMR_ON(s_ptr, TA_WAIT_BCON);
            break;
         } /* Endif */
      
         /************   Starting HNP **************************************
         ** When the A-device is in the a_host state and has set the dual-role 
         ** B-device's HNP enable bit (b_hnp_enable = TRUE ie, a_suspend_req
         ** = TRUE) the A-device shall place the connection to the B-device into 
         ** Suspend when it is finished using the bus.  We can go to the 
         ** suspend state also if user want to power down.
         */
         if (!s_ptr->A_BUS_REQ || s_ptr->A_BUS_SUSPEND_REQ) {
            SET_STATE(A_SUSPEND, "g ");
            s_ptr->A_BUS_REQ = FALSE;
            s_ptr->A_SET_B_HNP_EN = TRUE;
            TA_AIDL_BDIS_TMR_ON(s_ptr, TA_AIDL_BDIS); 

            #ifdef HNP_HARDWARE_ASSISTANCE
            /***********************************************************
            Set the HABA bit in OTGSC to enable hardware assitance
            for HNP. Please see the latest hardware revision manual and
            documentation of OTGSC register to develop and understanding
            for the functionality of the bit being set by the code here. 
            ***********************************************************/
            AUTO_HNP_ON(otg_reg);
            #endif
            
            /* CALL the Host API function to suspend the bus */
            _usb_host_bus_control(usb_host_state_struct_ptr, USB_SUSPEND_SOF);
            suspend_done = TRUE;


           /*while(TRUE);  */

         } /* Endif */   
         break;
      
      case A_SUSPEND:
      

         /* b_conn = FALSE if a RESET interrupt happens and it will set by
         ** the application; a_set_b_hnp_en is false as default and set to
         ** if the request is not stalled
         */
         if (!s_ptr->B_CONN && !s_ptr->A_SET_B_HNP_EN) {
            TA_AIDL_BDIS_TMR_OFF(s_ptr);
            s_ptr->B_BUS_RESUME = FALSE;
            #ifdef HNP_HARDWARE_ASSISTANCE
               /*set the HABA bit in OTGSC to enable hardware assitance */
               AUTO_HNP_OFF(otg_reg);
            #endif
            /* switch to  a_wait_bcon */
            SET_STATE(A_WAIT_BCON, "h ");
            TA_WAIT_BCON_TMR_ON(s_ptr, TA_WAIT_BCON);
            break;
         } /* Endif */
         
         /*
         ** If the B-device disconnects after the bus has been suspended, 
         ** then this is an indication that the B-device is attempting 
         ** to become Host. When the A-device detects the disconnect 
         ** from the B-device, it shall turn on its D+ pull-up resistor 
         ** within 3 ms (TA_BDIS_ACON max) to acknowledge
         ** the request from the B-device.
         */
         if ((!s_ptr->B_CONN || s_ptr->B_DISCONNECTED) && 
            (s_ptr->A_SET_B_HNP_EN)) 
         {
            PULL_UP_PULL_DOWN_IDLE(otg_reg);
            if (s_ptr->HOST_UP) {
               s_ptr->HOST_UP = FALSE;
               usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_HOST_DOWN); 
            } /* Endif */
            OTG_DEVICE_INIT(usb_otg_ptr, otg_reg);
            SET_STATE(A_PERIPHERAL, "j ");
            TA_AIDL_BDIS_TMR_OFF(s_ptr);
            s_ptr->A_SET_B_HNP_EN = FALSE ;
            s_ptr->A_BUS_SUSPEND_REQ = FALSE;
            s_ptr->B_DISCONNECTED = FALSE;
            break;
         } /* Endif */
         
         if (s_ptr->A_BUS_REQ || s_ptr->B_BUS_RESUME) {
            #ifdef HNP_HARDWARE_ASSISTANCE
               /*set the HABA bit in OTGSC to enable hardware assitance */
               AUTO_HNP_OFF(otg_reg);
            #endif
            SET_STATE(A_HOST, "k ");
            s_ptr->B_BUS_RESUME = FALSE;
            TA_AIDL_BDIS_TMR_OFF(s_ptr);
            s_ptr->A_BUS_SUSPEND_REQ = FALSE;
            s_ptr->A_BUS_REQ = TRUE;

         } /* Endif */
         break;
      
      case A_PERIPHERAL:
         /*
         ** A-device detects lack of bus activity for more than 3 ms 
         ** (TA_BIDL_ADIS min) and turns off its D+ pull-up.Alternatively, 
         ** if the A-device has no further need to communicate with the 
         ** B-device, the A-device may turn off VBUS and end the session.
         ** Sleep INT will be processed by the  device ISR b_bus_suspend
         ** variable will be set by the application
         ** The following will be done when this happens:
         **   
         **   - disconnect its pull up
         **   - allow time for the data line to discharge
         **   - check if the B-device has connected its pull up
         */
      
         if (s_ptr->B_BUS_SUSPEND) {
            if (s_ptr->DEVICE_UP) {
               s_ptr->DEVICE_UP = FALSE;
               usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_DEVICE_DOWN);
               PULL_UP_PULL_DOWN_IDLE(otg_reg);
            } /* Endif */
            if (!s_ptr->HOST_UP) {
               OTG_HOST_INIT(usb_otg_ptr, otg_reg);
            } /* Endif */
            /* switch to  a_wait_bcon */
            SET_STATE(A_WAIT_BCON, "m ");
#ifndef  TA_WAIT_BCON_TMR_FOR_EVER
            TA_WAIT_BCON_TMR_ON(s_ptr, TA_WAIT_BCON);
            s_ptr->B_BUS_SUSPEND = FALSE;
#endif
         } /* Endif */
         break;
      
      case A_WAIT_VFALL:
         _usb_otg_process_a_wait_vfall(usb_otg_ptr);
         break;
      
      case B_IDLE:
         _usb_otg_process_b_idle((pointer)usb_otg_ptr);
         break;
      
      case B_SRP_INIT:
         _usb_otg_process_b_srp_init((pointer)usb_otg_ptr);
         break;
      
      case B_PERIPHERAL:
            
         /* a_bus_suspend (SLEEP_INT) will be processed by the DEVICE ISR */
         /*
         ** B-device detects that bus is idle for more than 3 ms 
         ** (TB_AIDL_BDIS min) and begins HNP by turning off pull-up on D+. 
         ** This allows the bus to discharge to the SE0 state. 
         ** If the bus was operating in HS mode, the B-device will first 
         ** enter the full-speed mode and turn on its D+ pull-up resistor 
         ** for at least TB_FS_BDIS min before turning off its pull up 
         ** to start the HNP sequence.
         ** The following will be done when this happens:
         **   
         **   disconnect its pull up
         **   allow time for the data line to discharge
         **   check if the A-device has connected its pull up
         */
        
         if (s_ptr->B_HNP_ENABLE && s_ptr->B_BUS_REQ && 
            s_ptr->A_BUS_SUSPEND && (!s_ptr->A_SUSPEND_TIMER_ON))
         {

            TB_A_SUSPEND_TMR_ON(s_ptr, TB_A_SUSPEND);
            s_ptr->A_SUSPEND_TIMER_ON = TRUE;
            /*ensure that A_BUS_RESUME is false so that we look for
            a fresh resume on the bus */
            s_ptr->A_BUS_RESUME = FALSE;
         } /* Endif */
         
         
         /*
          when in suspended state in B_PERIPHERAL and host drives a resume
         we should recover back to B_PERIPHERAL state 
         */

         if((s_ptr->A_BUS_RESUME) && s_ptr->A_SUSPEND_TIMER_ON)
         {
            TB_A_SUSPEND_TMR_OFF(s_ptr);
            AUTO_RESET_OFF(otg_reg);
            s_ptr->A_BUS_SUSPEND = FALSE;

         }

         if (s_ptr->A_SUSPEND_TIMER_ON) {
         
          /*****************************************************  
           To meet the 1ms reset requirement for OPT test 5.4
           , latest hardware revisions provide the autoreset bit
           When this bit is set, hardware will drive a reset on
           the bus, the moment device connects. This will ensure
           that reset is hardware driver in a timely manner,
           rather than driver by software when a 'connect'
           interrupt happens. The bit has been added to meet
           the OTP timing requirement for customers have large
           interrupt latencies in their design
           
           SG 06/18/2004
          *****************************************************/  
           AUTO_RESET_ON(otg_reg);

           
            /* 7ms timer to let the bus discharge to SE0 state */
            if (TB_A_SUSPEND_TMR_EXPIRED(s_ptr)) {
               s_ptr->A_SUSPEND_TIMER_ON = FALSE;
               TB_A_SUSPEND_TMR_OFF(s_ptr);
               
               s_ptr->A_BUS_SUSPEND = FALSE;

               if (s_ptr->DEVICE_UP) {
                  s_ptr->DEVICE_UP = FALSE;
                  usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_DEVICE_DOWN);
                  PULL_UP_PULL_DOWN_IDLE(otg_reg);
               } /* Endif */

               if (!s_ptr->HOST_UP) {

                 OTG_HOST_INIT(usb_otg_ptr, otg_reg);
                  
                  /* No VBUS_ON */
               } /* Endif */
               TB_ASE0_BRST_TMR_ON(s_ptr, TB_ASE0_BRST);
               SET_STATE(B_WAIT_ACON, "n ");
               
            } /* Endif */
         } /* Endif */
         break;
      
      case B_WAIT_ACON:
         /*
         ** After waiting long enough to insure that the D+ line 
         ** cannot be high due to the residual effect of the B-device 
         ** pull-up,(see Section 5.1.9), the B-device sees that the 
         ** D+ line is high and D- low, (i.e. J state). This indicates 
         ** that the A-device has recognized the HNP request from the 
         ** B-device. At this point, the B-device becomes Host and 
         ** asserts bus reset to start using the bus. The B-device 
         ** must assert the bus reset (SE0) within 1 ms (TB_ACON_BSE0 max) 
         ** of the time that the A-device turns on its
         ** pull-up.
         */
         /* ATTACH_INT will be processed by the host ISR */
         if (s_ptr->A_CONN) {
            s_ptr->A_CONNECTED = FALSE;
            s_ptr->A_BUS_SUSPEND = FALSE;
            s_ptr->B_HNP_ENABLE = FALSE;
            TB_ASE0_BRST_TMR_OFF(s_ptr);
            SET_STATE(B_HOST, "p ");
            break;
         } /* Endif */
         
         /*
         ** While waiting in the b_wait_acon state, the B-device 
         ** may detect a K state on the bus. This indicates that the 
         ** A-device is signaling a resume condition and is retaining 
         ** control of the bus. In this case, the B-device will return 
         ** to the b_peripheral state.
         */
         /* 
         ** a_bus_resume will be set by the host ISR when K state is 
         ** detected  if (a_bus_resume || b_ase0_brst_tmr) 
         */
         if (s_ptr->A_BUS_RESUME || (TB_ASE0_BRST_TMR_EXPIRED(s_ptr) && 
            (!s_ptr->A_CONNECTED))) 
         {
            s_ptr->A_BUS_RESUME = FALSE;
            if (s_ptr->HOST_UP) {
               s_ptr->HOST_UP = FALSE;
               usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_HOST_DOWN); 
               PULL_UP_PULL_DOWN_IDLE(otg_reg);
            } /* Endif */
            /***********************************************************
            OPT test 5.8 and 5.9 require that we must display a message
            when a HNP fails. This event should allow the application
            to know  that HNP failed with Host.            
            ***********************************************************/
            if((TB_ASE0_BRST_TMR_EXPIRED(s_ptr)) && s_ptr->B_HNP_ENABLE)
            {
               usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_HNP_FAILED);
            }

            TB_ASE0_BRST_TMR_OFF(s_ptr);
            OTG_DEVICE_INIT(usb_otg_ptr, otg_reg);
            SET_STATE(B_PERIPHERAL, "q ");
            s_ptr->A_BUS_SUSPEND = FALSE;
            s_ptr->B_HNP_ENABLE = FALSE;
            break;
         } /* Endif */

         if (TB_ASE0_BRST_TMR_EXPIRED(s_ptr)) {
            TB_ASE0_BRST_TMR_OFF(s_ptr);
         } /* Endif */
         break;
      
      case B_HOST:
         /* 
         ** If the B-device at any time detects more than 3.125 ms of SE0 
         ** (TB_ASE0_BRST min), then this is an indication that the 
         ** A-device is remaining Host and is resetting the bus. In this 
         ** case the B-device shall return to the b_peripheral state 
         ** and start to process the bus reset before TB_ASE0_BRST max.
         */
         if (!s_ptr->B_BUS_REQ || !s_ptr->A_CONN) {
            PULL_UP_PULL_DOWN_IDLE(otg_reg);
            if (s_ptr->HOST_UP) {
               s_ptr->HOST_UP = FALSE;
               usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_HOST_DOWN); 
            } /* Endif */

            OTG_DEVICE_INIT(usb_otg_ptr, otg_reg);

            SET_STATE(B_PERIPHERAL, "r ");
         } /* Endif */
         break;
      default:
         break;
   } /* Endswitch */   
#endif  /* PERIPHERAL-ONLY */  
   
   if ((s_ptr->TA_WAIT_VRISE_TMR > 0) ||
       (s_ptr->TA_WAIT_BCON_TMR > 0)  ||
       (s_ptr->TA_AIDL_BDIS_TMR > 0)  ||
       (s_ptr->TA_BIDL_ADIS_TMR > 0)  ||
       (s_ptr->TB_DATA_PLS_TMR > 0)   ||
       (s_ptr->TB_SRP_INIT_TMR > 0)   ||
       (s_ptr->TB_SRP_FAIL_TMR > 0)   ||
       (s_ptr->TB_VBUS_PLS_TMR > 0)   ||
       (s_ptr->TB_ASE0_BRST_TMR > 0)  ||
       (s_ptr->TB_SE0_SRP_TMR > 0)    ||
       (s_ptr->TB_VBUS_DSCHRG_TMR > 0)  ||
       (s_ptr->TB_A_SUSPEND_TMR > 0)  ||
       (s_ptr->A_SRP_TMR > 0)) 
   {
      START_TIMER(otg_reg); 
   } else {
      STOP_TIMER(otg_reg);
   } /* Endif */
   
#ifdef OTG_LOG_STATE
   if (state != s_ptr->STATE) {
      usb_otg_ptr->LOG_STATE[usb_otg_ptr->LOG_STATE_COUNT++] = 
            usb_otg_ptr->STATE_STRUCT_PTR->STATE;
      if (usb_otg_ptr->LOG_STATE_COUNT>=99) {
         usb_otg_ptr->LOG_STATE_COUNT = 0;
      } /* Endif */
   }
#endif 

done:
   recursive--;

   /*
   ** If we are at the top level, and we had tried to recurse, we clear the
   ** recurse flag and we call _usb_otg_state_machine again.
   */
   if (recursive == 0xffffffff) {
      if (bTriedToRecurse) {
         bTriedToRecurse = FALSE;
         _usb_otg_state_machine((pointer)usb_otg_ptr);  /* fake recursion */
      } /* Endif */
   } /* Endif */

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_state_machine, SUCCESSFUL");
   #endif

   return;
} /* EndBody */

#ifdef HNP_HARDWARE_ASSISTANCE
/*FUNCTION*-----------------------------------------------------------
* 
* Function Name  : _usb_otg_hnp_assistance_check
* Returned Value : TRUE or FALSE
* Comments       :
   In the later hardware revisions, HNP event is assisted
   by hardware, In such a case when A device moves from
   A_SUSPEND to A_PERIPHERAL, hardware resets the OTG core
   and moves the core into device mode. This feature in
   harware removes the burdon from software when software
   should initialize the core in device mode. On systems
   with large interrupt latency, software may take long time
   response time may exceed 3 mili second limit defined
   by OTG for TA_BDIS_ACON.
   
   When software has such an assistance available from
   hardware, we need to check if hardware has moved the
   core to A_PERIPHERAL state before we read the OTG
   ISR and take any action. If hardware has done so,
   we immidiately need to shutdown the Host and
   intialize the core in device mode. 
*END*
--------------------------------------------------------------------*/
boolean  _usb_otg_hnp_assistance_check
   (
      /* [IN] The OTG handle */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR   usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   OTG_STRUCT_PTR                otg_reg;
//   uint_32 temp;
   boolean  auto_hnp = FALSE;
   boolean  is_device_mode = FALSE;

   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   otg_reg = usb_otg_ptr->OTG_REG_PTR;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;

   
   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_hnp_assistance_check");
   #endif
   
   if (s_ptr->STATE == A_SUSPEND)
   {
         /****************************************************
         Hardware HNP assistance works only when software
         is in A_SUSPEND state.
         ****************************************************/
         //temp = otg_reg->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC;
         //auto_hnp = ((temp & VUSBHS_OTGSC_HABA)? TRUE : FALSE); \

         IS_AUTO_HNP_ON(otg_reg,auto_hnp);
         IS_DEVICE_MODE_ON(otg_reg,is_device_mode);
         //temp = (otg_reg)->REGISTERS.OPERATIONAL_HOST_REGISTERS.USB_MODE & 0x3; \
         //is_device_mode = ((temp == VUSBHS_MODE_DEV)? TRUE : FALSE); 
   
         if((auto_hnp) && (is_device_mode))
         {
               /* this means that a disconnect has occured and
               core has switched to device mode */
               s_ptr->B_CONN = FALSE;

               /*set the HABA bit off in OTGSC to disable hardware assitance */
               AUTO_HNP_OFF(otg_reg);
      
               /* Call the Host controller driver to process the detach */
              _usb_ehci_process_hnp_hW_assisted_detach(
                     (pointer)usb_host_state_struct_ptr
                     ); 
      
               /* call otg state machine to ensure that it moves to
               next state */
               _usb_otg_state_machine((pointer)handle);
      
      
               /* Call device ISR to handle the interrupt*/
      
               /* HNP took place so return true*/
               return TRUE;
      
            }
   
   }
   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_hnp_assistance_check, SUCCESSFUL");
   #endif

   return FALSE;   
} /* EndBody */
#endif


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_reset_state_machine
* Returned Value : TRUE or FALSE
* Comments       :
*     Reset the state machine to its orginal state.
*END*--------------------------------------------------------------------*/
void  _usb_otg_reset_state_machine
   (
      /* [IN] The OTG handle */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR   usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_reset_state_machine");
   #endif
   
   s_ptr->OTG_INT_STATUS = 0;
   s_ptr->A_BUS_RESUME = 0;
   s_ptr->A_BUS_SUSPEND = 0;
   s_ptr->A_BUS_SUSPEND_REQ = 0;
   s_ptr->A_CONN = 0;
   s_ptr->B_BUS_RESUME = 0;
   s_ptr->B_BUS_SUSPEND = 0;
   s_ptr->B_CONN = 0;
   s_ptr->A_SET_B_HNP_EN = 0;
   s_ptr->B_SESS_REQ = 0;
   s_ptr->B_SRP_DONE = 0;
   s_ptr->B_HNP_ENABLE = 0;
   s_ptr->A_CONNECTED = 0;
   s_ptr->B_DISCONNECTED = 0;
   s_ptr->CHECK_SESSION = TRUE;
   s_ptr->A_SUSPEND_TIMER_ON = 0;

   TB_SE0_SRP_TMR_OFF(s_ptr);
   A_SRP_TMR_OFF(s_ptr);

   TA_WAIT_VRISE_TMR_OFF(s_ptr);
   TA_WAIT_BCON_TMR_OFF(s_ptr);
   TA_AIDL_BDIS_TMR_OFF(s_ptr);
   TA_BIDL_ADIS_TMR_OFF(s_ptr);

   TB_DATA_PLS_TMR_OFF(s_ptr);
   TB_SRP_INIT_TMR_OFF(s_ptr);
   TB_SRP_FAIL_TMR_OFF(s_ptr);
   TB_VBUS_PLS_TMR_OFF(s_ptr);
   TB_ASE0_BRST_TMR_OFF(s_ptr);
   TB_A_SUSPEND_TMR_OFF(s_ptr);
   TB_VBUS_DSCHRG_TMR_OFF(s_ptr);

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_reset_state_machine, SUCCESSFUL");
   #endif
   
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_process_exceptions
* Returned Value : TRUE or FALSE
* Comments       :
*     process the  exception signals and switch  state and return TRUE.
*END*--------------------------------------------------------------------*/
boolean  _usb_otg_process_exceptions
   (
      /* [IN] The OTG handle */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   OTG_STRUCT_PTR                otg_reg;
   uint_8                        previous_state;
   uint_8                        state;
   uint_32                       otg_int_status;
   
#ifdef OPT_TESTING
#pragma Offwarn(833)
   volatile uint_32              m1=0,m2=0,m3=0,m4=0,m5=0,m6=0;
#pragma Popwarn()
#endif

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_exceptions");
   #endif
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   otg_reg = usb_otg_ptr->OTG_REG_PTR;
   state = s_ptr->STATE;
   otg_int_status = s_ptr->OTG_INT_STATUS;

   

   /* Check exception for A device */
   previous_state = state;
   
   if ((state < B_IDLE)) {
      /* 
      ** Exceptions are as follows.
      ** 1. Transition to B_IDLE when id = TRUE.
      ** 2. Transition to A_WAIT_VFALL when V_BUS is voltage is fallen below 
      ** 3. 4 VDC or not able to set the V_BUS voltage.
      ** 4. If a_wait_b_con_timout  is set.
      ** 5. If  a_aidl_bdis_tmout  is set.
      */ 
      
    #ifdef OPT_TESTING

      m1 =  ID_CHG(otg_int_status) && ID(otg_reg);
      m2 =  A_VBUS_CHG(otg_int_status) && A_VBUS_VLD_FALSE(otg_reg);
      m3 =  TA_WAIT_VRISE_TMR_EXPIRED(s_ptr);
      m4 =  TA_WAIT_BCON_TMR_EXPIRED(s_ptr);
      m5 =  TA_AIDL_BDIS_TMR_EXPIRED(s_ptr);
      m6 =  A_VBUS_CHG(otg_int_status);
      
   usb_otg_ptr->LOG_INTERRUPTS[usb_otg_ptr->LOG_INTR_COUNT % OTG_LOG_MOD] = 
      otg_int_status;
   usb_otg_ptr->LOG_INTERRUPTS_STATE[usb_otg_ptr->LOG_INTR_COUNT % OTG_LOG_MOD][0] = 
      state;
   usb_otg_ptr->LOG_INTERRUPTS_STATE[usb_otg_ptr->LOG_INTR_COUNT % OTG_LOG_MOD][1] = 
      m1;
   usb_otg_ptr->LOG_INTERRUPTS_STATE[usb_otg_ptr->LOG_INTR_COUNT % OTG_LOG_MOD][2] = 
      m2;
   usb_otg_ptr->LOG_INTERRUPTS_STATE[usb_otg_ptr->LOG_INTR_COUNT % OTG_LOG_MOD][3] = 
      m3;
   usb_otg_ptr->LOG_INTERRUPTS_STATE[usb_otg_ptr->LOG_INTR_COUNT % OTG_LOG_MOD][4] = 
      m4;
   usb_otg_ptr->LOG_INTERRUPTS_STATE[usb_otg_ptr->LOG_INTR_COUNT % OTG_LOG_MOD][5] = 
      m5;
      
      usb_otg_ptr->LOG_INTR_COUNT++;

      
   if (usb_otg_ptr->LOG_INTR_COUNT >= 99) {
      usb_otg_ptr->LOG_INTR_COUNT = 0;
  } /* Endif */
#endif 
      
/*      if(m1 || m2 || m3 || m4 || m5) */
      
      if ((ID_CHG(otg_int_status) && ID(otg_reg))|| 
           ((A_VBUS_CHG(otg_int_status) && A_VBUS_VLD_FALSE(otg_reg)) ) ||
           (SESS_VLD_CHG(otg_int_status) && SESS_VLD_FALSE(otg_reg)) ||
           (TA_WAIT_VRISE_TMR_EXPIRED(s_ptr)) || 
           (TA_WAIT_BCON_TMR_EXPIRED(s_ptr)) ||  
           (TA_AIDL_BDIS_TMR_EXPIRED(s_ptr)))
  
      {
#ifndef PERIPHERAL_ONLY
            if ((state == A_IDLE) && (ID_CHG(otg_int_status) && ID(otg_reg))) 
            {
               SET_STATE(B_IDLE, "F ");
               s_ptr->B_BUS_REQ = FALSE;
               _usb_otg_process_b_idle((pointer)usb_otg_ptr);
            #ifdef OPT_TESTING
               usb_otg_ptr->LOG_STATE_CHANGE[usb_otg_ptr->LOG_INTR_COUNT % OTG_LOG_MOD] = 1;
            #endif   

            } 
/* change made after I2C code merge the line containing && (state != A_WAIT_VRISE)
 should work for I2C and non-I2C hardware.
*/
#ifdef _I2C_
            else if ((state != A_IDLE) && (state != A_WAIT_VFALL) && (state != A_WAIT_VRISE)) 
#else
            else if ((state != A_IDLE) && (state != A_WAIT_VFALL)) 
#endif            
            
            {
#if 0
if (TA_WAIT_VRISE_TMR_EXPIRED(s_ptr))
	uartputs("\nTA_WAIT_VRISE_TMR_EXPIRED(s_ptr) == TRUE");
else
	uartputs("\nTA_WAIT_VRISE_TMR_EXPIRED(s_ptr) == FALSE");
if (A_VBUS_CHG(otg_int_status))
	uartputs("\nA_VBUS_CHG(otg_int_status) == TRUE");
else
	uartputs("\nA_VBUS_CHG(otg_int_status) == FALSE");
if (A_VBUS_VLD_FALSE(otg_reg))
	uartputs("\nA_VBUS_VLD_FALSE() == TRUE");
else
	uartputs("\nA_VBUS_VLD_FALSE() == FALSE");
#endif
            
               if ((TA_WAIT_VRISE_TMR_EXPIRED(s_ptr)) || 
                  (A_VBUS_CHG(otg_int_status) && A_VBUS_VLD_FALSE(otg_reg)))
               {
                  usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_OVER_CURRENT); 
               } /* Endif */

               #ifdef HNP_HARDWARE_ASSISTANCE
                   /*set the HABA bit off in OTGSC to disable hardware assitance */
                  AUTO_HNP_OFF(otg_reg);
               #endif
                   
                  SET_STATE(A_WAIT_VFALL, "s ");
               #ifdef OPT_TESTING
                  usb_otg_ptr->LOG_STATE_CHANGE[usb_otg_ptr->LOG_INTR_COUNT % OTG_LOG_MOD] = 1;
               #endif   

               if (TA_WAIT_BCON_TMR_EXPIRED(s_ptr)) 
               {
                  TA_WAIT_BCON_TMR_OFF(s_ptr);
                  usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_NO_CONNECTION);
               } /* Endif */

               #ifdef _I2C_
				               VBUS_OFF_CHG_OFF_DSCHG_ON();
               #else
                              VBUS_CHG_OFF(otg_reg);
                              VBUS_OFF(otg_reg);
               #endif
               _usb_otg_process_a_wait_vfall(usb_otg_ptr);
            } /* Endif */
            
#endif            
      } /* Endif */         
   } else {
      /*
      ** Process B- device exceptions
      */
      if ((ID_CHG(otg_int_status) && ID_FALSE(otg_reg)) ||
         (SESS_VLD_CHG(otg_int_status) && SESS_VLD_FALSE(otg_reg) && s_ptr->STATE != B_SRP_INIT)) 
      {
         #ifdef _I2C_
		         VBUS_OFF_CHG_OFF();
         #else
                  VBUS_CHG_OFF(otg_reg);
                  VBUS_OFF(otg_reg);
         #endif
         s_ptr->B_BUS_REQ = FALSE;
         if (ID(otg_reg) ) {
            /************************************************************
            SG 8/18/2003.
            When software is about to move to B_IDLE state, it should
            generate an HNP failure message if it is coming from
            B_WAIT_ACON state. This is necessary to pass OPT on
            test 5.9 because on some OTG PHY cards, VBUS can drop
            faster (before B_ASE0_BRST_TMOUT timer expires) and
            we can get a session valid interrupt. This interrupt
            has caused the software to come here and it should
            post the message to application saying that HNP has
            failed.
            ************************************************************/
            if ((state == B_WAIT_ACON) && s_ptr->B_HNP_ENABLE)
            {
               usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_HNP_FAILED);
            }

            /*if we are not running a suspend timer and waiting for HNP
            to finish, we should move to B_IDLE state */
            //if(!((state == B_PERIPHERAL) && s_ptr->A_SUSPEND_TIMER_ON))
            {
                /* proceed to B_IDLE state */

                SET_STATE(B_IDLE, "G ");
                PULL_UP_PULL_DOWN_IDLE(otg_reg);
                _usb_otg_process_b_idle((pointer)usb_otg_ptr);
            
            }
         } else {
#ifndef PERIPHERAL_ONLY
            SET_STATE(A_IDLE, "H ");
            /* A unique case where we need to set this to TRUE */
            s_ptr->A_BUS_REQ = TRUE;
            _usb_otg_process_a_idle((pointer)usb_otg_ptr);
#endif            
         } /* Endif */
      } /* endif */
   } /* Endif */
   if (s_ptr->STATE != previous_state){
      #ifdef _OTG_DEBUG_
         DEBUG_LOG_TRACE("_usb_otg_process_exceptions, SUCCESSFUL state changed");
      #endif
     return (TRUE);
   } else {
      #ifdef _OTG_DEBUG_
         DEBUG_LOG_TRACE("_usb_otg_process_exceptions, SUCCESSFUL no state change");
      #endif
     return (FALSE);
   }
} /* EndBody */


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_process_b_idle
* Returned Value : None
* Comments       :
*     Process B_IDLE state.
* 
*END*--------------------------------------------------------------------*/
void _usb_otg_process_b_idle
   (
      /* [IN] The OTG handle */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   OTG_STRUCT_PTR                otg_reg;
   int_32                        srp_tmr;
   boolean                       se0_srp;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_b_idle");
   #endif
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   otg_reg = usb_otg_ptr->OTG_REG_PTR; 
   
   srp_tmr = s_ptr->TB_SE0_SRP_TMR;
   se0_srp = s_ptr->B_SE0_SRP;
   _usb_otg_reset_state_machine(usb_otg_ptr);
   s_ptr->TB_SE0_SRP_TMR = srp_tmr;
   s_ptr->B_SE0_SRP = se0_srp;
   
   if (s_ptr->HOST_UP) {
      s_ptr->HOST_UP = FALSE;
      usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_HOST_DOWN);
      PULL_UP_PULL_DOWN_IDLE(otg_reg);
   } /* Endif */
      
   OTG_DEVICE_INIT(usb_otg_ptr, otg_reg);
   
   /*
   ** When a B-device detects that the voltage on VBUS is greater 
   ** than the B-Device Session Valid threshold (VSESS_VLD), 
   ** then the B-device shall consider a session to be in progress. 
   ** After the VBUS voltage crosses this threshold, the B-device 
   ** shall assert either the D+ or D- data-line within 100 ms.
   */
   if (SESS_VLD(otg_reg)) {
      _usb_otg_process_b_device_session_valid(handle);
   } else if (s_ptr->B_BUS_REQ || s_ptr->B_SESS_REQ) {
      /*  ********* Starting  SRP *****************************************
      ** When the B-device detects that VBUS has gone below its Session End 
      ** threshold and detects that both D+ and D- have been low (SE0) for 
      ** at least 2 ms (TB_SE0_SRP min), then any previous session on the 
      ** A-device is over and a new session may start. The B-device may 
      ** initiate the SRP any time the initial conditions of Section 5.3.2 
      ** are met.
      */
      /* activate the timer only if we want to do SRP */
      if ((s_ptr->B_BUS_REQ || s_ptr->B_SESS_REQ) && 
         (CHECK_TB_SE0_SRP_TMR_OFF(s_ptr))) 
      {
         TB_SE0_SRP_TMR_ON(s_ptr, TB_SE0_SRP);
      } /* Endif */
     
      if ((s_ptr->B_BUS_REQ || s_ptr->B_SESS_REQ) && (B_SESS_END(otg_reg)) && 
         (s_ptr->B_SE0_SRP)) 
      {
         TB_SE0_SRP_TMR_OFF(s_ptr);
         s_ptr->B_SE0_SRP = FALSE;
         /*
         ** initial conditions are met as described above and then turns 
         ** on its data line pull-up resistor (either D+ or D-) for a 
         ** period of 5 ms to 10 ms (TB_DATA_PLS). A dual-role B-device is 
         ** only allowed to initiate SRP at full-speed, and thus shall 
         ** only pull up D+. The duration of such a data line pulse is 
         ** sufficient to allow the A-device to reject spurious voltage 
         ** transients on the data lines.
         */
         DP_HIGH_ON(otg_reg);  
         TB_SRP_FAIL_TMR_ON(s_ptr, TB_SRP_FAIL);
         TB_SRP_INIT_TMR_ON(s_ptr, TB_SRP_INIT);
         TB_DATA_PLS_TMR_ON(s_ptr, TB_DATA_PLS);
         SET_STATE(B_SRP_INIT, "t ");
         s_ptr->B_SRP_DONE = FALSE;
         usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_SRP_ACTIVE); 
      } /* Endf */
   } /* Endif */

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_b_idle, SUCCESSFUL");
   #endif
   
} /* EndBody */

#ifndef PERIPHERAL_ONLY
/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_process_a_idle
* Returned Value : None
* Comments       :
*     Process B_IDLE state.
* 
*END*--------------------------------------------------------------------*/
void _usb_otg_process_a_idle
   (
      /* [IN] The OTG handle */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   OTG_STRUCT_PTR                otg_reg;
   boolean                       a_srp_det;
   int_32                        a_srp_tmr;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_a_idle");
   #endif
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   otg_reg = usb_otg_ptr->OTG_REG_PTR; 
   
   a_srp_det = s_ptr->A_SRP_DET;
   a_srp_tmr = s_ptr->A_SRP_TMR;
   _usb_otg_reset_state_machine(usb_otg_ptr);
   s_ptr->A_SRP_DET = a_srp_det;
   s_ptr->A_SRP_TMR = a_srp_tmr;
   
   if (ID(otg_reg)) {
      SET_STATE(B_IDLE, "J ");
      _usb_otg_process_b_idle((pointer)usb_otg_ptr);
      #ifdef _OTG_DEBUG_
         DEBUG_LOG_TRACE("_usb_otg_process_a_idle, SUCCESSFUL (state to B_IDLE)");
      #endif
      return;
   } /* Endif */

   if (s_ptr->DEVICE_UP) {
      s_ptr->DEVICE_UP = FALSE;
      usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_DEVICE_DOWN);
      PULL_UP_PULL_DOWN_IDLE(otg_reg);
   } /* Endif */
   
   if (!s_ptr->HOST_UP) {
      OTG_HOST_INIT(usb_otg_ptr, otg_reg);
   } /* Endif */
   
   if ((!s_ptr->A_BUS_REQ) && (s_ptr->A_SRP_TMR == -1) && 
      (s_ptr->A_DATA_PULSE_DET)) 
   {
      A_SRP_TMR_ON(s_ptr, TB_DATA_PLS_MAX);
   } /* Endif */
   
   /* ************  SRP detection ****************************
   ** The A-device continuously monitors VBUS as long as power is 
   ** available on the A-device. An A-device that is designed to 
   ** detect the VBUS pulsing method will detect that VBUS has 
   ** gone above the A-device Session Valid threshold (VA_SESS_VLD) 
   ** and generate an indication that SRP has been detected.
   */
   if ((!s_ptr->A_BUS_DROP) && (SESS_VLD(otg_reg) || s_ptr->A_SRP_DET || 
      s_ptr->A_BUS_REQ))
   {
      s_ptr->A_SRP_DET = FALSE;
      SET_STATE(A_WAIT_VRISE, "u ");
      VBUS_ON(otg_reg);
      TA_WAIT_VRISE_TMR_ON(s_ptr, TA_WAIT_VRISE);
      _usb_otg_process_a_wait_vrise((pointer)usb_otg_ptr);
   } /* Endif */

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_a_idle, SUCCESSFUL");
   #endif
   
} /* EndBody */


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_process_a_wait_vrise
* Returned Value : None
* Comments       :
*     Process A_WAIT_VRISE state.
* 
*END*--------------------------------------------------------------------*/
void _usb_otg_process_a_wait_vrise
   (
      /* [IN] The OTG handle */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   OTG_STRUCT_PTR                otg_reg;
   
   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_a_wait_vrise");
   #endif
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   otg_reg = usb_otg_ptr->OTG_REG_PTR;
   
   if (A_VBUS_VLD(otg_reg)) {
      TA_WAIT_VRISE_TMR_OFF(s_ptr);
      /* switch to  a_wait_bcon */
      bVRISE_TIMEDOUT = 0;
      SET_STATE(A_WAIT_BCON, "v ");
#ifndef TA_WAIT_BCON_TMR_FOR_EVER
      TA_WAIT_BCON_TMR_ON(s_ptr, TA_WAIT_BCON);
#endif
   } /* Endif */
   else
	{
		if (TA_WAIT_VRISE_TMR_EXPIRED(s_ptr))
		{
            bVRISE_TIMEDOUT = 1;
			SET_STATE(A_WAIT_BCON, "v2 ");
			TA_WAIT_BCON_TMR_ON(s_ptr, TA_WAIT_BCON);
		}
	}


   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_a_wait_vrise, SUCCESSFUL");
   #endif
   
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_process_a_wait_vfall
* Returned Value : None
* Comments       :
*     Process A_WAIT_VFALL state.
* 
*END*--------------------------------------------------------------------*/
void _usb_otg_process_a_wait_vfall
   (
      /* [IN] The OTG handle */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   OTG_STRUCT_PTR                otg_reg;
   uint_32                       hw_signal;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_a_wait_vfall");
   #endif
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   otg_reg = usb_otg_ptr->OTG_REG_PTR;
   hw_signal = s_ptr->OTG_INT_STATUS;
   
   /* Turn this timer off if it is still on from A_peripheral state */
   TA_BIDL_ADIS_TMR_OFF(s_ptr);

   if (
      (/*SESS_VLD_CHG(hw_signal) && */SESS_VLD_FALSE(otg_reg) /*&& (!s_ptr->B_CONN)*/) || 
      ID(otg_reg) || 
      s_ptr->A_BUS_REQ
      ) 
   {
      SET_STATE(A_IDLE, "K ");
      #ifdef _I2C_
            VBUS_OFF_CHG_OFF_DSCHG_OFF();
      #else
            VBUS_CHG_OFF(otg_reg);
            VBUS_OFF(otg_reg);
      #endif
      s_ptr->A_BUS_REQ = FALSE;
      _usb_otg_process_a_idle((pointer)usb_otg_ptr);
   } /* Endif */

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_a_wait_vfall, SUCCESSFUL");
   #endif
   
} /* EndBody */

#endif

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_process_b_device_session_valid
* Returned Value : None
* Comments       :
*     Process B device session valid.
* 
*END*--------------------------------------------------------------------*/
void _usb_otg_process_b_device_session_valid
   (
      /* [IN] The OTG handle */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   OTG_STRUCT_PTR                otg_reg;
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   otg_reg = usb_otg_ptr->OTG_REG_PTR;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_b_device_session_valid");
   #endif
   
   
   if (s_ptr->STATE == B_SRP_INIT) {
      TB_SRP_FAIL_TMR_OFF(s_ptr);
      TB_SRP_INIT_TMR_OFF(s_ptr);
      TB_DATA_PLS_TMR_OFF(s_ptr);
      TB_SE0_SRP_TMR_OFF(s_ptr);
      TB_VBUS_DSCHRG_TMR_OFF(s_ptr);
   } /* Endif */

   DP_HIGH_OFF(otg_reg);   
   VBUS_CHG_OFF(otg_reg);
   VBUS_DSCHG_OFF(otg_reg);
   
   SET_STATE(B_PERIPHERAL, "w ");
   
   OTG_DEVICE_INIT(usb_otg_ptr, otg_reg);

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_b_device_session_valid, SUCCESSFUL, state to B_PERIPHERAL");
   #endif
   

} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_process_b_srp_init
* Returned Value : None
* Comments       :
*     Process B_SRP_INIT state.
* 
*END*--------------------------------------------------------------------*/
void _usb_otg_process_b_srp_init
   (
      /* [IN] The OTG handle */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   OTG_STRUCT_PTR                otg_reg;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_b_srp_init");
   #endif
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   otg_reg = usb_otg_ptr->OTG_REG_PTR;
   /*usb_otg_ptr->DO_SRP = FALSE;*/
   
   /*
   ** When a B-device detects that the voltage on VBUS is greater than the 
   ** B-Device Session Valid threshold (VSESS_VLD), then the B-device 
   ** shall consider a session to be in progress. After the VBUS voltage
   ** crosses this threshold, the B-device shall assert either the D+ or 
   ** D- data-line within 100 ms(TB_SVLD_BCON max).
   */
   if ((SESS_VLD(otg_reg)) && (s_ptr->CHECK_SESSION)) {
      _usb_otg_process_b_device_session_valid(handle);
   } else {
      /* check_srp_activity */
      if (TB_DATA_PLS_TMR_EXPIRED(s_ptr))
      {
         TB_DATA_PLS_TMR_OFF(s_ptr);
         DP_HIGH_OFF(otg_reg);
         /* An A-device is only required to respond to one of the two 
         ** SRP signaling methods. A B-device shall use both methods 
         ** when initiating SRP to insure that the A-device responds.
         */
         s_ptr->CHECK_SESSION = FALSE;
         VBUS_CHG_ON(otg_reg);
         /* Turn on the timer so as to keep VBUS pusling ON for 8 ms */
         TB_VBUS_PLS_TMR_ON(s_ptr, TB_VBUS_PLS);
      } /*Endif */

      if (TB_VBUS_PLS_TMR_EXPIRED(s_ptr)) {
         /* Turn off the VBus pulsing timer */
         TB_VBUS_PLS_TMR_OFF(s_ptr);
         /* Stop VBus pulsing */
         VBUS_CHG_OFF(otg_reg);
#if 0
         s_ptr->CHECK_SESSION = TRUE;
         /* If session is valid then proceed */
         if (SESS_VLD(otg_reg)) {
            _usb_otg_process_b_device_session_valid(handle);
         } /* Endif */
#endif
         VBUS_DSCHG_ON(otg_reg);
         TB_VBUS_DSCHRG_TMR_ON(s_ptr, TB_VBUS_DSCHRG);
      } /* Endif */

      if (TB_VBUS_DSCHRG_TMR_EXPIRED(s_ptr)) {
         VBUS_DSCHG_OFF(otg_reg);
         TB_VBUS_DSCHRG_TMR_OFF(s_ptr);
         s_ptr->CHECK_SESSION = TRUE;
         /* If session is valid then proceed */
         if (SESS_VLD(otg_reg)) {
            _usb_otg_process_b_device_session_valid(handle);
         } /* Endif */
      } /* Endif */
   
      if (TB_SRP_INIT_TMR_EXPIRED(s_ptr))
      {
         TB_SRP_INIT_TMR_OFF(s_ptr);
         VBUS_CHG_OFF(otg_reg);
      } /* Endif */
      
      /*
      ** The error call back have the following requirement:
      ** After initiating SRP, the B-device is required to wait at least 
      ** 5 seconds (TB_TB_SRP_FAIL min) for the A-device to respond, 
      ** before informing the user that the communication attempt 
      ** has failed.
      **
        */
      if (TB_SRP_FAIL_TMR_EXPIRED(s_ptr)) {
         TB_SRP_FAIL_TMR_OFF(s_ptr);
         s_ptr->B_SRP_DONE = FALSE;
         s_ptr->B_BUS_REQ = FALSE; /*we should set this to false to avoid looping with B_IDLE */
         SET_STATE(B_IDLE, "M ");
         DP_HIGH_OFF(otg_reg);
         VBUS_CHG_OFF(otg_reg);
         usb_otg_ptr->SERVICE((pointer)usb_otg_ptr, USB_OTG_SRP_FAIL); 
         _usb_otg_process_b_idle((pointer)usb_otg_ptr);
      } /* Endif*/
   } /* Endif */
   
   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_b_srp_init, SUCCESSFUL");
   #endif
   
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_process_timers
* Returned Value : TRUE/ FALSE
* Comments       :
*     If any timers expired, the state machine will be executed and returns
*     TRUE, otherwise it will return FALSE.
* 
*END*--------------------------------------------------------------------*/
boolean _usb_otg_process_timers
   (
      /* [IN]  OTG device handle */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   USB_STRUCT_PTR                usb_reg;
   OTG_STRUCT_PTR                otg_reg;
   boolean                       timer_expired = FALSE;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_timers");
   #endif
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   otg_reg = usb_otg_ptr->OTG_REG_PTR; 
   usb_reg = usb_otg_ptr->USB_REG_PTR; 

   /* Process all the A timers */
   if (s_ptr->TA_WAIT_VRISE_TMR > 0) {
      s_ptr->TA_WAIT_VRISE_TMR--;
      if (TA_WAIT_VRISE_TMR_EXPIRED(s_ptr)) {
         timer_expired = TRUE;
         LOG_TIMER("\nTA_WAIT_VRISE_TMR_EXPIRED ");
      } /* Endif */
   } /* Endif */

   if (s_ptr->TA_WAIT_BCON_TMR > 0) {
      s_ptr->TA_WAIT_BCON_TMR--;
      if (TA_WAIT_BCON_TMR_EXPIRED(s_ptr)) {
         timer_expired = TRUE;
	      LOG_TIMER("\nTA_WAIT_BCON_TMR_EXPIRED ");
      } /* Endif */
   } /* Endif */

   if (s_ptr->TA_AIDL_BDIS_TMR > 0) {
      s_ptr->TA_AIDL_BDIS_TMR--;
      if (TA_AIDL_BDIS_TMR_EXPIRED(s_ptr)) {
         timer_expired = TRUE;
	      LOG_TIMER("\nTA_AIDL_BDIS_TMR_EXPIRED ");
      } /* Endif */
   } /* Endif */

   if (s_ptr->TA_BIDL_ADIS_TMR > 0) {
      s_ptr->TA_BIDL_ADIS_TMR--;
      if (TA_BIDL_ADIS_TMR_EXPIRED(s_ptr)) {
	      LOG_TIMER("\nTA_BIDL_ADIS_TMR_EXPIRED ");
	      timer_expired = TRUE;
	   } /* Endif */
	} /* Endif */

   /* 
   ** Process all the debouncing timers first
   */
   if (s_ptr->TB_SE0_SRP_TMR > 0) {
      
      if (SE0(usb_reg) && 
         (STABLE_J_SE0_LINE_STATE(otg_reg))) 
      {
         /* signal is constant for 1 ms, so decrement counter */
         s_ptr->TB_SE0_SRP_TMR--;
      } else {
        /* random behaviour; Reset the counter */
        TB_SE0_SRP_TMR_ON(s_ptr, TB_SE0_SRP);
      } /* Endif */
      
      if (TB_SE0_SRP_TMR_EXPIRED(s_ptr)) {
         s_ptr->B_SE0_SRP = TRUE;
	      LOG_TIMER("\nTB_SE0_SRP_TMR_EXPIRED ");
         timer_expired = TRUE;
      } /* Endif */

   } /* Endif */

   /* process all the B timers */
   if (s_ptr->TB_DATA_PLS_TMR > 0) {
      s_ptr->TB_DATA_PLS_TMR--;
      if (TB_DATA_PLS_TMR_EXPIRED(s_ptr)) {
	      LOG_TIMER("\nTB_DATA_PLS_TMR_EXPIRED ");
	      timer_expired = TRUE;
	   } /* Endif */
	} /* Endif */

   if (s_ptr->TB_VBUS_PLS_TMR > 0) {
      /* VBus pulsing timer */
      s_ptr->TB_VBUS_PLS_TMR--;
      if (TB_VBUS_PLS_TMR_EXPIRED(s_ptr)) {
	      LOG_TIMER("\nTB_VBUS_PLS_TMR_EXPIRED ");
         timer_expired = TRUE;
#if 0
         s_ptr->CHECK_SESSION = TRUE;
#endif
      } /* Endif */
   } /* Endif */
	
   if (s_ptr->TB_SRP_INIT_TMR > 0) {
	   s_ptr->TB_SRP_INIT_TMR--;
	   if (TB_SRP_INIT_TMR_EXPIRED(s_ptr)) {
	      LOG_TIMER("\nTB_SRP_INIT_TMR_EXPIRED ");
	      timer_expired = TRUE;
	   } /* Endif */
	} /* Endif */
   
   if (s_ptr->TB_VBUS_DSCHRG_TMR > 0) {
      s_ptr->TB_VBUS_DSCHRG_TMR--;
      if (TB_VBUS_DSCHRG_TMR_EXPIRED(s_ptr)) {
         timer_expired = TRUE;
         /* Test GR */
         /*s_ptr->CHECK_SESSION = TRUE;*/
	      LOG_TIMER("\nTB_VBUS_DSCHRG_TMR_EXPIRED ");
      } /* Endif */

   } /* Endif */
   if (s_ptr->TB_SRP_FAIL_TMR > 0) {
      s_ptr->TB_SRP_FAIL_TMR--;
      if (TB_SRP_FAIL_TMR_EXPIRED(s_ptr)) {
	      LOG_TIMER("\nTB_SRP_FAIL_TMR_EXPIRED ");
         timer_expired = TRUE;
      } /* Endif */
   } /* Endif */
   
   if (s_ptr->TB_ASE0_BRST_TMR > 0) {
      s_ptr->TB_ASE0_BRST_TMR--;
      if (TB_ASE0_BRST_TMR_EXPIRED(s_ptr)) {
	      LOG_TIMER("\nTB_ASE0_BRST_TMR_EXPIRED ");
         timer_expired = TRUE;
      } /* Endif */
   } /* Endif */

   if (s_ptr->TB_A_SUSPEND_TMR > 0) {
      s_ptr->TB_A_SUSPEND_TMR--;
      if (TB_A_SUSPEND_TMR_EXPIRED(s_ptr)) {
	      LOG_TIMER("\nTB_A_SUSPEND_TMR_EXPIRED ");
         timer_expired = TRUE;
      } /* Endif */
   } /* Endif */
   
   if (s_ptr->A_SRP_TMR > 0) {
#ifdef __VUSBHS__
      s_ptr->A_SRP_TMR = -1;
      s_ptr->A_DATA_PULSE_DET = FALSE;
      timer_expired = TRUE;
      s_ptr->A_SRP_DET = TRUE;
#else
      s_ptr->A_SRP_TMR--;
      if (A_SRP_TMR_EXPIRED(s_ptr)) {
         s_ptr->A_SRP_TMR = -1;
         s_ptr->A_DATA_PULSE_DET = FALSE;
	      LOG_TIMER("\nA_SRP_TMR_EXPIRED ");
         timer_expired = TRUE;
         if (JSTATE(usb_reg) && 
            (STABLE_J_SE0_LINE_STATE(otg_reg))) 
         {
            s_ptr->A_SRP_DET = TRUE;
         } /* Endif */
      } /* Endif */
#endif
   } /* Endif */
   
   if (timer_expired) {
      _usb_otg_state_machine((pointer)usb_otg_ptr);
   } /* Endif */

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_process_timers, SUCCESSFUL");
   #endif
   
   return timer_expired;
} /* EndBody */

/* EOF */
