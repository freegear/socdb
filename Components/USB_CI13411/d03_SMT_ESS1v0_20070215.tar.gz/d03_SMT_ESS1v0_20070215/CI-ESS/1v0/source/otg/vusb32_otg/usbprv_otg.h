#ifndef __usbprv_otg_h__
#define __usbprv_otg_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:  This file contains the defnitions which is private to
***            the OTG implementation.
***
************************************************************************
**END*********************************************************/
#include "vusb32.h"
#ifndef __USB_OS_MQX__
#include <string.h>
#include <stdlib.h>
#endif

/*the following defines have been added specific to I2C change */
#ifdef _I2C_

	#define P1301_B_SESS_END					0x80
	#define P1301_ID_GND						0x08
	#define P1301_SESS_VLD						0x02

	/*
	 DANGER
	 Bit 0 is supposed to indicate VBUS VALID, byt it currently isn't
	 So we're hijacking bit 1 for now
	*/
	#define P1301_VBUS_VLD						0x01
	/* #define P1301_VBUS_VLD						0x02

	 End of DANGER  */

	#define P1301_VBUS_CHARGE					0x80
	#define P1301_VBUS_DISCHARGE				0x40
	#define P1301_VBUS_DRV						0x20
	#define P1301_ID_PULLDOWN					0x10
	#define P1301_DM_PULLDOWN					0x08
	#define P1301_DP_PULLDOWN					0x04
	#define P1301_DM_PULLUP						0x02
	#define P1301_DP_PULLUP						0x01

#endif

/* define the hardware specific registers */
/* OTG Interrupt Status Register Bit Masks */
#define  OTG_INT_STATUS_A_VBUS                   (0x01)
#define  OTG_INT_STATUS_B_SESS                   (0x04)
#define  OTG_INT_STATUS_SESS_VLD                 (0x08)
#define  OTG_INT_STATUS_LINE_STATE_CHANGE       (0x20)
#define  OTG_INT_STATUS_1_MSEC                  (0x40)
#define  OTG_INT_STATUS_ID                      (0x80)

/* OTG Interrupt Enable Register Bit Masks */
#define  OTG_INT_ENABLE_A_VBUS                   (0x01)
#define  OTG_INT_ENABLE_B_SESS                    (0x04)
#define  OTG_INT_ENABLE_SESS_VLD                 (0x08)
#define  OTG_INT_ENABLE_1_MSEC                    (0x40)
#define  OTG_INT_ENABLE_ID                        (0x80)

/* OTG   Status Register Bit Masks */
#define  OTG_STAT_A_VBUS_VLD                     (0x01)
#define  OTG_STAT_B_SESS_END                     (0x04)
#define  OTG_STAT_SESS_VLD                       (0x08)
#define  OTG_STAT_LINE_STATE_CHANGE             (0x20)
#define  OTG_STAT_1_MSEC_VLD                     (0x40)
#define  OTG_STAT_ID_VLD                         (0x80)


/* OTG  Control Register Bit Masks */
#define  OTG_CTL_VBUS_DSCHG                      (0x01)
#define  OTG_CTL_VBUS_CHG                         (0x02)
#define  OTG_CTL_OTG_ENABLE                       (0x04)
#define  OTG_CTL_VBUS_ON                          (0x08)
#define  OTG_CTL_DM_LOW                         (0x10)
#define  OTG_CTL_DP_LOW                         (0x20)
#define  OTG_CTL_DM_HIGH                          (0x40)
#define  OTG_CTL_DP_HIGH                          (0x80)


#define START_TIMER(x)   ((x)->OTG_INT_ENABLE |= OTG_INT_ENABLE_1_MSEC)
#define STOP_TIMER(x)  ((x)->OTG_INT_ENABLE &= ~OTG_INT_ENABLE_1_MSEC)
#define IS_OTG_TIMER_RUNNING(x)  ((x)->OTG_INT_ENABLE & OTG_INT_ENABLE_1_MSEC)
#define STABLE_J_SE0_LINE_STATE(x) (((x)->OTG_STAT) & OTG_STAT_LINE_STATE_CHANGE)


/*I2C specific definitions */
#ifdef _I2C_

	#define	ID_CHG(mask)				(p1301Regs.delta & P1301_ID_GND)
	#define ID_FALSE(x)					(p1301Regs.state & P1301_ID_GND)
	#define ID(x)						(!ID_FALSE(x))

	#define	SESS_VLD_CHG(mask)			(p1301Regs.delta & P1301_SESS_VLD)
	#define	SESS_VLD(x)					(p1301Regs.state & P1301_SESS_VLD)
	#define	SESS_VLD_FALSE(x)			(!SESS_VLD(x))

	#define	A_VBUS_CHG(mask)			(p1301Regs.delta & P1301_VBUS_VLD)
	#define	A_VBUS_VLD(x)				(p1301Regs.state & P1301_VBUS_VLD)
	#define	A_VBUS_VLD_FALSE(x)			(!A_VBUS_VLD(x))

	#define	B_SESS_END(x)				(p1301Regs.state & P1301_B_SESS_END)

	#define	VBUS_OFF_CHG_OFF_DSCHG_ON()	setclr1301(REG_1301_OTG_CONTROL, P1301_VBUS_DISCHARGE, P1301_VBUS_DRV | P1301_VBUS_CHARGE)
	#define	VBUS_OFF_CHG_OFF()			clr1301(REG_1301_OTG_CONTROL, P1301_VBUS_DRV | P1301_VBUS_CHARGE)
	#define	VBUS_OFF_CHG_OFF_DSCHG_OFF()	clr1301(REG_1301_OTG_CONTROL, P1301_VBUS_DISCHARGE | P1301_VBUS_DRV | P1301_VBUS_CHARGE)

	#define	VBUS_DSCHG_ON(x)				set1301(REG_1301_OTG_CONTROL, P1301_VBUS_DISCHARGE)
	#define	VBUS_DSCHG_OFF(x)			clr1301(REG_1301_OTG_CONTROL, P1301_VBUS_DISCHARGE)

	#define	VBUS_CHG_ON(x)				set1301(REG_1301_OTG_CONTROL, P1301_VBUS_CHARGE)
	#define	VBUS_CHG_OFF(x)				clr1301(REG_1301_OTG_CONTROL, P1301_VBUS_CHARGE)

	#define	VBUS_ON(x)					set1301(REG_1301_OTG_CONTROL, P1301_VBUS_DRV)
	#define	VBUS_OFF(x)					clr1301(REG_1301_OTG_CONTROL, P1301_VBUS_DRV)

	#define	VBUS_DM_LOW_ON(x)			set1301(REG_1301_OTG_CONTROL, P1301_DM_PULLDOWN)/* (otg.CONTROL |= OTG_CONTROL_DM_LOW) */
	#define	VBUS_DM_LOW_OFF(x)			clr1301(REG_1301_OTG_CONTROL, P1301_DM_PULLDOWN)/*(otg.CONTROL &= ~OTG_CONTROL_DM_LOW)*/

	#define	VBUS_DP_LOW_ON(x)			set1301(REG_1301_OTG_CONTROL, P1301_DP_PULLDOWN)/*(otg.CONTROL |= OTG_CONTROL_DP_LOW) */
	#define	VBUS_DP_LOW_OFF(x)			clr1301(REG_1301_OTG_CONTROL, P1301_DP_PULLDOWN)/*(otg.CONTROL &= ~OTG_CONTROL_DP_LOW)*/

	#define	DM_HIGH_ON(x)				set1301(REG_1301_OTG_CONTROL, P1301_DM_PULLUP)/*(otg.CONTROL |= OTG_CONTROL_DM_HIGH) */
	#define	DM_HIGH_OFF(x)				clr1301(REG_1301_OTG_CONTROL, P1301_DM_PULLUP)/*(otg.CONTROL &= ~OTG_CONTROL_DM_HIGH)*/

	#define	DP_HIGH_ON(x)				set1301(REG_1301_OTG_CONTROL, P1301_DP_PULLUP)/*(otg.CONTROL |= OTG_CONTROL_DP_HIGH)*/
	#define	DP_HIGH_OFF(x)				clr1301(REG_1301_OTG_CONTROL, P1301_DP_PULLUP)/*(otg.CONTROL &= ~OTG_CONTROL_DP_HIGH)*/

	#define	PULL_UP_PULL_DOWN_HOST_CTRL(x)	setclr1301(REG_1301_OTG_CONTROL, \
												P1301_DP_PULLDOWN | P1301_DM_PULLDOWN, \
												P1301_DP_PULLUP | P1301_DM_PULLUP);

	#define	PULL_UP_PULL_DOWN_DEVICE_CTRL(x)	setclr1301(REG_1301_OTG_CONTROL, \
												P1301_DP_PULLUP | P1301_DM_PULLDOWN, \
												P1301_DP_PULLDOWN | P1301_DM_PULLUP);

	#define	PULL_UP_PULL_DOWN_IDLE(x)		PULL_UP_PULL_DOWN_HOST_CTRL(x)

	#define OTG_HOST_INIT(x, y) \
		(x)->SERVICE((pointer)(x), USB_OTG_HOST_UP); \
		PULL_UP_PULL_DOWN_HOST_CTRL(x); \
		(x)->STATE_STRUCT_PTR->HOST_UP = TRUE;

	#define OTG_DEVICE_INIT(x, y) \
		if (!((x)->STATE_STRUCT_PTR->DEVICE_UP)) { \
				(x)->SERVICE((pointer)(x), USB_OTG_DEVICE_UP); \
				(x)->STATE_STRUCT_PTR->DEVICE_UP = TRUE; \
		} /* Endif */ \
		if (((x)->STATE_STRUCT_PTR->STATE) != B_IDLE) { \
				PULL_UP_PULL_DOWN_DEVICE_CTRL(x); \
		} /* Endif */

#else

	/*
	** Interrupt status register signals
	*/

	#define ID_CHG(mask)          ((mask & OTG_INT_STATUS_ID))
	#define ID_FALSE(x)           (!((x)->OTG_STAT & OTG_STAT_ID_VLD))
	#define ID(x)                 (((x)->OTG_STAT & OTG_STAT_ID_VLD))

	#define SESS_VLD_CHG(mask)    ((mask & OTG_INT_STATUS_SESS_VLD))
	#define SESS_VLD_FALSE(x)     (!((x)->OTG_STAT & OTG_STAT_SESS_VLD))
	#define SESS_VLD(x)           (((x)->OTG_STAT & OTG_STAT_SESS_VLD))

	#define A_VBUS_CHG(mask)      ((mask & OTG_INT_STATUS_A_VBUS))
	#define A_VBUS_VLD(x)         (((x)->OTG_STAT & OTG_STAT_A_VBUS_VLD))
	#define A_VBUS_VLD_FALSE(x)   (!((x)->OTG_STAT & OTG_STAT_A_VBUS_VLD))


	#define B_SESS_END(x)         (((x)->OTG_STAT & OTG_STAT_B_SESS_END))

	/* discharge the VBUS */
	#define VBUS_DSCHG_ON(x)      ((x)->OTG_CTL |= OTG_CTL_VBUS_DSCHG)
	#define VBUS_DSCHG_OFF(x)     ((x)->OTG_CTL &= ~OTG_CTL_VBUS_DSCHG)

	/* TURN OFF VBUS chraging. */
	#define VBUS_CHG_ON(x)        ((x)->OTG_CTL |= OTG_CTL_VBUS_CHG)
	#define VBUS_CHG_OFF(x)       ((x)->OTG_CTL &= ~OTG_CTL_VBUS_CHG)

	#define VBUS_ON(x)            ((x)->OTG_CTL |= OTG_CTL_VBUS_ON)
	#define VBUS_OFF(x)           ((x)->OTG_CTL &= ~OTG_CTL_VBUS_ON)

	#define VBUS_DM_LOW_ON(x)     ((x)->OTG_CTL |= OTG_CTL_DM_LOW)
	#define VBUS_DM_LOW_OFF(x)    ((x)->OTG_CTL &= ~OTG_CTL_DM_LOW)

	#define VBUS_DP_LOW_ON(x)     ((x)->OTG_CTL |= OTG_CTL_DP_LOW)
	#define VBUS_DP_LOW_OFF(x)    ((x)->OTG_CTL &= ~OTG_CTL_DP_LOW)

	#define DM_HIGH_ON(x)         ((x)->OTG_CTL |= OTG_CTL_DM_HIGH )
	#define DM_HIGH_OFF(x)        ((x)->OTG_CTL &= ~OTG_CTL_DM_HIGH )

	#define DP_HIGH_ON(x)         ((x)->OTG_CTL |= OTG_CTL_DP_HIGH )
	#define DP_HIGH_OFF(x)        ((x)->OTG_CTL &= ~OTG_CTL_DP_HIGH )


	#define PULL_UP_PULL_DOWN_HOST_CTRL(x)      (x)->OTG_CTL |= (OTG_CTL_DP_LOW | OTG_CTL_DM_LOW); \
	                                          (x)->OTG_CTL &= ~(OTG_CTL_DP_HIGH | OTG_CTL_DM_HIGH); 

	#define PULL_UP_PULL_DOWN_DEVICE_CTRL(x)  (x)->OTG_CTL |= (OTG_CTL_DP_HIGH | OTG_CTL_DM_LOW); \
	                                          (x)->OTG_CTL &= ~(OTG_CTL_DM_HIGH | OTG_CTL_DP_LOW )


	#define PULL_UP_PULL_DOWN_IDLE(x)         PULL_UP_PULL_DOWN_HOST_CTRL(x)

	/* clear D + */
	#define PULL_UP_PULL_DOWN_LOW_SPEED(x)    (x)->OTG_CTL &= ~OTG_CTL_DM_LOW; 

	/* clear D - */
	#define PULL_UP_PULL_DOWN_FULL_SPEED(x)   (x)->OTG_CTL &= ~OTG_CTL_DP_LOW;

	#define OTG_HOST_INIT(x, y) \
	   (x)->SERVICE((pointer)(x), USB_OTG_HOST_UP); \
	   PULL_UP_PULL_DOWN_HOST_CTRL(y); \
	   (x)->STATE_STRUCT_PTR->HOST_UP = TRUE;

	#define OTG_DEVICE_INIT(x, y) \
	   if (!((x)->STATE_STRUCT_PTR->DEVICE_UP)) { \
	      (x)->SERVICE((pointer)(x), USB_OTG_DEVICE_UP); \
	      /*(x)->STATE_STRUCT_PTR->DEVICE_UP = TRUE;*/ \
	   } /* Endif */ \
	   if (((x)->STATE_STRUCT_PTR->STATE) != B_IDLE) { \
	      PULL_UP_PULL_DOWN_DEVICE_CTRL(y); \
	   } /* Endif */


#endif

#define AUTO_RESET_ON(x)
#define AUTO_RESET_OFF(x)
#define IS_AUTO_RESET_ON(x,y)
#define AUTO_HNP_ON(x)
#define AUTO_HNP_OFF(x)
#define IS_AUTO_HNP_ON(x,y) 
#define IS_DEVICE_MODE_ON(x,y) 

/*
** USB core signals
*/

#define SE0(x)  ((x)->CONTROL & VUSB_CTRL_SINGLE_ENDED_0 )
#define JSTATE(x)  ((x)->CONTROL & VUSB_CTRL_JSTATE)
#define SPEED(x)  ((x)->ADDRESS & VUSB_ADDR_LS_EN)
#define SUSPEND(x) ((x)->INTSTATUS & VUSB_INT_STAT_SLEEP)

typedef USB_Uncached struct otg_struct
{
   USB_REGISTER  OTG_INT_STAT;         /* OTG Interrupt Status Register */
   USB_REGISTER  OTG_INT_ENABLE;       /* OTG Interrupt Enable Register */
   USB_REGISTER  OTG_STAT;             /* OTG status Register */
   USB_REGISTER  OTG_CTL;              /* OTG Control Register */
} OTG_STRUCT, _PTR_ OTG_STRUCT_PTR;



/* Prototypes */

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __USB_OS_MQX__
   extern void _usb_otg_vusb11_isr(_usb_otg_handle);
   extern void _usb_hci_vusb11_isr(pointer);
   extern void _usb_dci_vusb11_isr(pointer);
#else
   extern void OTG_INTERRUPT_ROUTINE_KEYWORD _usb_otg_vusb11_isr(void);
   extern void HOST_INTERRUPT_ROUTINE_KEYWORD _usb_hci_vusb11_isr(void);
   extern void DEVICE_INTERRUPT_ROUTINE_KEYWORD _usb_dci_vusb11_isr(void);
#endif

#ifdef _I2C_
void processOTGevent(USB_OTG_STATE_STRUCT_PTR usb_otg_ptr, boolean b1301);
#else
void processOTGevent(USB_OTG_STATE_STRUCT_PTR usb_otg_ptr);
#endif
	
   uint_8 _usb_otg_vusb11_init(_usb_otg_handle);
   extern void _usb_otg_vusb11_shutdown(_usb_otg_handle);

boolean waitForAttachOrReset(USB_STRUCT _PTR_ host_device_dev_ptr);

#ifdef __cplusplus
}
#endif
#endif

/* EOF */
   





