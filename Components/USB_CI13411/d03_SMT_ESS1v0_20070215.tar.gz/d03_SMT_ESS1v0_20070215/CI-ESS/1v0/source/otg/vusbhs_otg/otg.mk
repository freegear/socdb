# VUSBHS otg driver

MQX_INCDIRS      +=$(USB_ROOT)$(PS)source$(PS)otg$(PS)vusbhs_otg

srcdirs += otg$(PS)$(USB_DRIVER)_otg
otg_srcs    += \
    vusbhs_otg


