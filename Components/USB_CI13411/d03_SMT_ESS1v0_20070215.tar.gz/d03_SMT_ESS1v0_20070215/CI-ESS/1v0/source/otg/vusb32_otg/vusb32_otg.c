/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***  This file contains the low-level VUSB32  On-The-Go routines.
***                                                               
**************************************************************************
**END*********************************************************/
#include "types.h"
#include "hostapi.h"
#include "devapi.h"
#include "otgapi.h"
#include "usb.h"
#include "vusb32.h"
#include "usbprv.h"
#include "usbprv_dev.h"
#include "usbprv_host.h"
#include "usbprv_otg.h"

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
#endif

/*the following files are required for I2C work */
#ifdef _I2C_
   #include "sa_uart.h"
   #include "otg_i2c.h"
   #include "i2c.h"
#endif


USB_OTG_STATE_STRUCT_PTR otg_handle;
extern USB_DEV_STATE_STRUCT_PTR global_usb_device_state_struct_ptr;
#ifndef PERIPHERAL_ONLY
extern USB_HOST_STATE_STRUCT_PTR usb_host_state_struct_ptr;
#endif

#ifndef __USB_OS_MQX__
extern volatile boolean IN_ISR;
#else
boolean IN_ISR = FALSE;
#endif



/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_vusb11_init
* Returned Value : USB_OK or error code
* Comments       :
*     Initialises the OTG Hardware.  
* 
*END*--------------------------------------------------------------------*/
uint_8 _usb_otg_vusb11_init
   (
      /* [IN] handle to the usb otg */
      _usb_otg_handle handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   OTG_STRUCT _PTR_              dev_ptr;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_vusb11_init");
   #endif
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;

   usb_otg_ptr->USB_REG_PTR = _bsp_get_usb_base(usb_otg_ptr->DEV_NUM);
   
   usb_otg_ptr->OTG_REG_PTR = (pointer)((uint_32)usb_otg_ptr->USB_REG_PTR 
      - BSP_VUSB11_OTG_USB_OFFSET);

   dev_ptr = (OTG_STRUCT _PTR_)usb_otg_ptr->OTG_REG_PTR;

   /* mask all OTG interupts */
   dev_ptr->OTG_INT_ENABLE = 0x0;
   /* Clear all OTG interrupts */
   dev_ptr->OTG_INT_STAT = 0xFF;
   
   /*  Turn off all the signals; 
   ** The following are initial condition for A-device and B-device.
   **  !drv_vbus; !charg_vbus; !loc_conn; loc_sof
   */
   dev_ptr->OTG_CTL = OTG_CTL_OTG_ENABLE;

#ifdef __USB_OS_MQX__                                          
   if (!(USB_install_isr((_bsp_get_usb_vector(usb_otg_ptr->DEV_NUM)), 
      _usb_otg_vusb11_isr, (pointer)usb_otg_ptr)))
   {
      #ifdef _OTG_DEBUG_
         DEBUG_LOG_TRACE("_usb_otg_vusb11_init, MQX ISR installation failed");
      #endif
      return USBERR_INSTALL_ISR;
   } /* Endbody */
#else
   USB_install_isr(_bsp_get_usb_vector(usb_otg_ptr->DEV_NUM), 
      _usb_otg_vusb11_isr, (pointer)usb_otg_ptr);
#endif

#ifdef PERIPHERAL_ONLY
    usb_otg_ptr->STATE_STRUCT.STATE = B_IDLE;
#else
   /*
   ** The identification (id) input is FALSE when a Mini-A plug is inserted 
   ** in the device�s Mini-AB receptacle. Otherwise, this input is TRUE.
   */
   if (ID_FALSE(dev_ptr)) {
      usb_otg_ptr->STATE_STRUCT_PTR->STATE = A_IDLE;
   } else {
      usb_otg_ptr->STATE_STRUCT_PTR->STATE = OTG_START;
   } /* Endif */
#endif   


   /* Enable the OTG specific interrupts */
   dev_ptr->OTG_INT_ENABLE = OTG_INT_ENABLE_A_VBUS |  
                                OTG_INT_ENABLE_B_SESS|  
                                OTG_INT_ENABLE_SESS_VLD| 
                                OTG_INT_ENABLE_ID;

   /* keep a global copy  of the handle */
   otg_handle = (USB_OTG_STATE_STRUCT_PTR)handle;

   /* start the state machine once to keep going */
   _usb_otg_state_machine((pointer)usb_otg_ptr);
   
   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_vusb11_init, SUCCESSFUL");
   #endif
   return USB_OK;

} /* Endbody */   

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_vusb11_shutdown
* Returned Value : None
* Comments       :
*     Shutdown the otg  device.
* 
*END*--------------------------------------------------------------------*/
void _usb_otg_vusb11_shutdown
   (
      /* [IN] Handle to the USB otg */
      _usb_otg_handle   handle
   )
{ /* Body */
      USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
      OTG_STRUCT _PTR_              dev_ptr;

      #ifdef _OTG_DEBUG_
         DEBUG_LOG_TRACE("_usb_otg_vusb11_shutdown");
      #endif
      
      usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
      dev_ptr = (OTG_STRUCT _PTR_)usb_otg_ptr->OTG_REG_PTR;
      
      /* mask all OTG interupts */
      dev_ptr->OTG_INT_ENABLE = 0x0;
      /* Clear all OTG interrupts */
      dev_ptr->OTG_INT_STAT = 0xFF;
      /*  Turn off all the OTG signals */
      dev_ptr->OTG_CTL = 0x0;

      #ifdef _OTG_DEBUG_
         DEBUG_LOG_TRACE("_usb_otg_vusb11_shutdown, SUCCESSFUL");
      #endif
      
} /* EndBody */

#ifdef _I2C_
/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_vusb11_isr
* Returned Value : None
* Comments       :
*     Service all OTG and VUSB32 and I2C interrupts.
* 
*END*--------------------------------------------------------------------*/

#ifndef __USB_OS_MQX__
void OTG_INTERRUPT_ROUTINE_KEYWORD _usb_otg_vusb11_isr(void)
{

	IN_ISR = TRUE;
#ifdef _I2C
	processOTGevent((USB_OTG_STATE_STRUCT_PTR)otg_handle, FALSE);
#else
	processOTGevent((USB_OTG_STATE_STRUCT_PTR)otg_handle);
#endif
	IN_ISR = FALSE;
	return;
}

#else

void _usb_otg_vusb11_isr(_usb_otg_handle handle)
{

	IN_ISR = TRUE;
#ifdef _I2C_
	processOTGevent((USB_OTG_STATE_STRUCT_PTR)handle, FALSE);
#else
	processOTGevent((USB_OTG_STATE_STRUCT_PTR)handle);
#endif
	IN_ISR = FALSE;
	return;
}
#endif
/*********************************************************
When I2C is used for interrupts. The interrupt handler
is different.
*********************************************************/

#ifdef _I2C_
void processOTGevent(USB_OTG_STATE_STRUCT_PTR usb_otg_ptr, boolean b1301)
#else
void processOTGevent(USB_OTG_STATE_STRUCT_PTR usb_otg_ptr)
#endif
{ /* Body */
   volatile OTG_STRUCT _PTR_           dev_ptr;
   volatile USB_STRUCT _PTR_           host_device_dev_ptr;
   uint_32                             otg_status;
   OTG_STATE_MACHINE_STRUCT_PTR        s_ptr;
   boolean                             timer_expired = FALSE;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("processOTGevent");
   #endif
   
   #ifdef _DATA_CACHE_
      dev_ptr = (OTG_STRUCT _PTR_)usb_otg_ptr->OTG_REG_PTR;
   #else      
      dev_ptr = (volatile OTG_STRUCT _PTR_)usb_otg_ptr->OTG_REG_PTR;
   #endif   

   host_device_dev_ptr = (volatile USB_STRUCT _PTR_)usb_otg_ptr->USB_REG_PTR;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   otg_status = (dev_ptr->OTG_INT_STAT & dev_ptr->OTG_INT_ENABLE);
   
#ifdef _I2C_
	if (b1301)
		{
#if 0
		uartputs("\nprocessOTGevent: 1301.");
		if (IN_ISR)
			{
			uartputs("\nIN_ISR = TRUE");
			}
		else
			{
			uartputs("\nIN_ISR = FALSE");
			}
		if (ID_CHG(otg_int_status))
			{
			uartputs("\nID_CHG = TRUE");
			}
		else
			{
			uartputs("\nID_CHG = FALSE");
			}
		if (ID(otg_reg))
			{
			uartputs("\nID = TRUE");
			}
		else
			{
			uartputs("\nID = FALSE");
			}
		if (s_ptr->HOST_UP)
			{
			uartputs("\nHOST_UP = TRUE");
			}
		else
			{
			uartputs("\nHOST_UP = FALSE");
			}
		if (s_ptr->A_BUS_REQ)
			{
			uartputs("\nA_BUS_REQ = TRUE");
			}
		else
			{
			uartputs("\nA_BUS_REQ = FALSE");
			}

		uartputs("\nINTSTATUS=");
		uartput8(host_device_dev_ptr->INTSTATUS);

		uartputs("\nA_SRP_TMR=");
		uartput32(s_ptr->A_SRP_TMR);

		uartputs("\nSTATE=");
		uartputs(state_name[s_ptr->STATE]);
#endif
		}

#endif
   
   do {
      /* Clear all enabled interrupts */
      dev_ptr->OTG_INT_STAT = otg_status;
      
      /* If we have OTG interrupt call the state machine */
#ifdef _I2C_
      if (otg_status || b1301) {
#else
      if (otg_status) {
#endif      
         s_ptr->OTG_INT_STATUS = otg_status;
         /*
         ** If any timers expired  it will process the event and
         ** any other signals at that time. We don't need to call
         ** the state machine if this is the case.
         */
         if (otg_status & OTG_STAT_1_MSEC_VLD) 
         {
            timer_expired = _usb_otg_process_timers((pointer)usb_otg_ptr);
            otg_status &= ~OTG_STAT_1_MSEC_VLD;
         } /* Endif */

/*************************************************************
In Non I2C mode, we use the normal interrupt handler routine.
*************************************************************/
         
#ifdef _I2C_
        if (b1301 || (otg_status && (!timer_expired))) {
#else
         if (otg_status && (!timer_expired)) {
#endif         
            _usb_otg_state_machine((pointer)usb_otg_ptr);
         } else {
            timer_expired = FALSE;
         } /* Endif */
         
         s_ptr->OTG_INT_STATUS = 0;
      } /* Endif */
      
#ifndef PERIPHERAL_ONLY
      /* A_DEVICE */
      if (s_ptr->HOST_UP) 
      {
         /* Check data line pulsing by B device */
         if ((s_ptr->STATE == A_IDLE) && 
            (!s_ptr->A_BUS_REQ) &&  
            (host_device_dev_ptr->INTSTATUS & VUSB_INT_STAT_ATTACH) && 
            (s_ptr->A_SRP_TMR == -1)) 
         {
            s_ptr->A_DATA_PULSE_DET = TRUE;
            _usb_otg_state_machine((pointer)usb_otg_ptr);
            #ifdef _OTG_DEBUG_
               DEBUG_LOG_TRACE("_usb_otg_vusb11_isr, SUCCESSFUL state machine called");
            #endif
            return ;
         } /* Endif */
         if (s_ptr->A_SRP_TMR == -1) 
				{
				if ((s_ptr->STATE == B_WAIT_ACON) && (host_device_dev_ptr->INTSTATUS & VUSB_INT_STAT_ATTACH)) 
					{

					#ifdef _I2C_
					s_ptr->A_CONNECTED = waitForAttachOrReset(host_device_dev_ptr);
					#else
					      /* Clear the Attach interrupt 10 times and assert JSTATE 
			               ** to TRUE on 11th time. Wait here for 15 usecs delay.
			               */
					      int count = 0;

					      while (count < 10) {
					         count++;
					         host_device_dev_ptr->INTSTATUS = VUSB_INT_STAT_ATTACH;
						      while (!(host_device_dev_ptr->INTSTATUS & VUSB_INT_STAT_ATTACH)) {
						      } /* EndWhile */
					      } /* EndWhile */

		               s_ptr->A_CONNECTED = TRUE;

					#endif

					_usb_otg_state_machine((pointer)usb_otg_ptr);
					} /* Endif */
				} /* Endif */


#ifndef __USB_OS_MQX__
            _usb_hci_vusb11_isr();
#else
            _usb_hci_vusb11_isr((pointer)usb_host_state_struct_ptr); 
#endif
      }/* Endif */
#endif
      /* B_DEVICE */
      if (s_ptr->DEVICE_UP)
      {
         if ((s_ptr->STATE == B_IDLE) && 
            (host_device_dev_ptr->INTSTATUS & VUSB_INT_STAT_RESET)) 
         {
            /* Clear the enabled interrupts */
            otg_status = host_device_dev_ptr->INTSTATUS & host_device_dev_ptr->INTENABLE;
            host_device_dev_ptr->INTSTATUS = otg_status;
            #ifdef _OTG_DEBUG_
               DEBUG_LOG_TRACE("_usb_otg_vusb11_isr, SUCCESSFUL no action in device mode");
            #endif
            return;
         } /* Endif */
#ifndef __USB_OS_MQX__
         _usb_dci_vusb11_isr();
#else
         _usb_dci_vusb11_isr((pointer)global_usb_device_state_struct_ptr); 
#endif
      }/* Endif */
      
      /* check the interrupt again */
      otg_status = (dev_ptr->OTG_INT_STAT & dev_ptr->OTG_INT_ENABLE);
   } while(otg_status);
#ifndef __USB_OS_MQX__   
   IN_ISR = FALSE;
#endif

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_vusb11_isr, SUCCESSFUL");
   #endif

} /* Endbody */
#else
/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_vusb11_isr
* Returned Value : None
* Comments       :
*     Service all OTG and VUSB32 interrupts.
* 
*END*--------------------------------------------------------------------*/
#ifndef __USB_OS_MQX__
OTG_INTERRUPT_ROUTINE_KEYWORD void _usb_otg_vusb11_isr
   (
      void
   )
#else
void _usb_otg_vusb11_isr
   (
      _usb_otg_handle handle
   )
#endif
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR            usb_otg_ptr;
   OTG_STRUCT _PTR_                    dev_ptr;
   USB_STRUCT _PTR_                    host_device_dev_ptr;
   uint_32                             otg_status;
   uint_32                             count;
   OTG_STATE_MACHINE_STRUCT_PTR        s_ptr;
   boolean                             timer_expired = FALSE;

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_vusb11_isr");
   #endif
   
#ifndef __USB_OS_MQX__   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)otg_handle;
   IN_ISR = TRUE;
#else
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
#endif

      dev_ptr = (OTG_STRUCT _PTR_)usb_otg_ptr->OTG_REG_PTR;

#ifdef _I2C_
   bGot1301int = FALSE;
#endif   

   host_device_dev_ptr = (USB_STRUCT _PTR_)usb_otg_ptr->USB_REG_PTR;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;
   otg_status = (dev_ptr->OTG_INT_STAT & dev_ptr->OTG_INT_ENABLE);
   
   do {
      /* Clear all enabled interrupts */
      dev_ptr->OTG_INT_STAT = otg_status;
      
      /* If we have OTG interrupt call the state machine */
#ifdef _I2C_
      if (otg_status || bGot1301int) {
#else
      if (otg_status) {
#endif      
         s_ptr->OTG_INT_STATUS = otg_status;
         /*
         ** If any timers expired  it will process the event and
         ** any other signals at that time. We don't need to call
         ** the state machine if this is the case.
         */
         if (otg_status & OTG_STAT_1_MSEC_VLD) {
            timer_expired = _usb_otg_process_timers((pointer)usb_otg_ptr);
            otg_status &= ~OTG_STAT_1_MSEC_VLD;
         } /* Endif */
         
#ifdef _I2C_
         if ((otg_status || bGot1301int) && (!timer_expired)) {
#else
         if (otg_status && (!timer_expired)) {
#endif         
            _usb_otg_state_machine((pointer)usb_otg_ptr);
         } else {
            timer_expired = FALSE;
         } /* Endif */
         
         s_ptr->OTG_INT_STATUS = 0;
      } /* Endif */
      
#ifndef PERIPHERAL_ONLY
      /* A_DEVICE */
      if (s_ptr->HOST_UP) {
         /* Check data line pulsing by B device */
         if ((s_ptr->STATE == A_IDLE) && 
            (!s_ptr->A_BUS_REQ) &&  
            (host_device_dev_ptr->INTSTATUS & VUSB_INT_STAT_ATTACH) && 
            (s_ptr->A_SRP_TMR == -1)) 
         {
            s_ptr->A_DATA_PULSE_DET = TRUE;
            _usb_otg_state_machine((pointer)usb_otg_ptr);
            #ifdef _OTG_DEBUG_
               DEBUG_LOG_TRACE("_usb_otg_vusb11_isr, SUCCESSFUL state machine called");
            #endif
            return ;
         } /* Endif */
         if (s_ptr->A_SRP_TMR == -1) {
            if ((s_ptr->STATE == B_WAIT_ACON) && 
               (host_device_dev_ptr->INTSTATUS & VUSB_INT_STAT_ATTACH)) 
            {

#if 0  /* This is an old workaround for a bug in an early version of the hardware. */
			      /* Clear the Attach interrupt 10 times and assert JSTATE 
               ** to TRUE on 11th time. Wait here for 15 usecs delay.
               */
			      count = 0;

			      while (count < 10) {
			         count++;
			         host_device_dev_ptr->INTSTATUS = VUSB_INT_STAT_ATTACH;
				      while (!(host_device_dev_ptr->INTSTATUS & VUSB_INT_STAT_ATTACH)) {
				      } /* EndWhile */
			      } /* EndWhile */

#endif

               s_ptr->A_CONNECTED = TRUE;

               _usb_otg_state_machine((pointer)usb_otg_ptr);
            } /* Endif */

#if 0            
            if ((s_ptr->STATE == A_SUSPEND) && 
               (host_device_dev_ptr->INTSTATUS & VUSB_INT_STAT_RESET)) 
            {

               s_ptr->B_DISCONNECTED = TRUE;

               _usb_otg_state_machine((pointer)usb_otg_ptr);
            } /* Endif */
#endif
            

#ifndef __USB_OS_MQX__
            _usb_hci_vusb11_isr();
#else
            _usb_hci_vusb11_isr((pointer)usb_host_state_struct_ptr); 
#endif
         } /* Endif */
      }/* Endif */
#endif
      /* B_DEVICE */
      if (s_ptr->DEVICE_UP){
         if ((s_ptr->STATE == B_IDLE) && 
            (host_device_dev_ptr->INTSTATUS & VUSB_INT_STAT_RESET)) 
         {
            /* Clear the enabled interrupts */
            otg_status = host_device_dev_ptr->INTSTATUS & host_device_dev_ptr->INTENABLE;
            host_device_dev_ptr->INTSTATUS = otg_status;
            #ifdef _OTG_DEBUG_
               DEBUG_LOG_TRACE("_usb_otg_vusb11_isr, SUCCESSFUL no action in device mode");
            #endif
            return;
         } /* Endif */
#ifndef __USB_OS_MQX__
         _usb_dci_vusb11_isr();
#else
         _usb_dci_vusb11_isr((pointer)global_usb_device_state_struct_ptr); 
#endif
      }/* Endif */
      
      /* check the interrupt again */
      otg_status = (dev_ptr->OTG_INT_STAT & dev_ptr->OTG_INT_ENABLE);
   } while(otg_status);
#ifndef __USB_OS_MQX__   
   IN_ISR = FALSE;
#endif

   #ifdef _OTG_DEBUG_
      DEBUG_LOG_TRACE("_usb_otg_vusb11_isr, SUCCESSFUL");
   #endif

} /* Endbody */
/* EOF */


#endif


#ifdef _I2C_
boolean waitForAttachOrReset(volatile USB_STRUCT _PTR_ host_device_dev_ptr)
{

#if 0
uartputs("\nwaitForAttachOrReset");
uartputs(" Stat=");
uartput8(host_device_dev_ptr->INTSTATUS);
uartputs(" Enb=");
uartput8(host_device_dev_ptr->INTENABLE);
uartputs(" Ctl=");
uartput8(host_device_dev_ptr->CONTROL);
#endif
	register uint_8		u8_stat;
	uint_32				count;
	uint_32				timeout;

	/*	Clear the Attach interrupt 10 times 
		Wait here for 25 usecs delay.
	*/

	/* clear ATTACH and RESET */
	host_device_dev_ptr->INTSTATUS = VUSB_INT_STAT_ATTACH | VUSB_INT_STAT_RESET;

#define TIMEOUT	10

	for (count = 0, timeout = 0; /*count < 10 &&*/ timeout < TIMEOUT; timeout++)
		{
		/* read ATTACH and RESET */
		u8_stat = host_device_dev_ptr->INTSTATUS;

		if (u8_stat & VUSB_INT_STAT_RESET)	/* if RESET is set, we're done */
			return FALSE;

		if (u8_stat & VUSB_INT_STAT_ATTACH)	/* if ATTACH is set, inc count */
			count++;
		}

#if 0
	if (timeout == TIMEOUT)
		{
		uartputs("\nTIMEOUT count=");
		uartput32(count);
#if 0
		uartputs(" Stat=");
		uartput8(host_device_dev_ptr->INTSTATUS);
		uartputs(" Enb=");
		uartput8(host_device_dev_ptr->INTENABLE);
		uartputs(" Ctl=");
		uartput8(host_device_dev_ptr->CONTROL);
#endif
		}
#endif

	return TRUE;	/* got 10 ATTACHES */
}

#endif

/* EOF */
