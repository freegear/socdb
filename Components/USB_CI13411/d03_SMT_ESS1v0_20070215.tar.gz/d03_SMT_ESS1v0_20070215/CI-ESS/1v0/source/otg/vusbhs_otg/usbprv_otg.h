#ifndef __usbprv_otg_h__
#define __usbprv_otg_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:  This file contains the defnitions which is private to
***            the OTG implementation.
***
************************************************************************
**END*********************************************************/
#include "vusbhs.h"
#ifndef __USB_OS_MQX__
#include <string.h>
#include <stdlib.h>
#endif


/* define the hardware specific registers */

#define START_TIMER(x) \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp | VUSBHS_OTGSC_1MSIE)); \
      (usb_otg_ptr->ENABLED_INTERRUPTS |= VUSBHS_OTGSC_1MSIE); \
   }


#define STOP_TIMER(x) \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp & ~VUSBHS_OTGSC_1MSIE)); \
      (usb_otg_ptr->ENABLED_INTERRUPTS &= ~VUSBHS_OTGSC_1MSIE); \
   }

/*
** Interrupt status register signals
*/

#define ID_CHG(mask)          (mask & VUSBHS_OTGSC_IDIS)
#define SESS_VLD_CHG(mask)    (mask & (VUSBHS_OTGSC_ASVIS | VUSBHS_OTGSC_BSVIS))
#define A_VBUS_CHG(mask)      (mask & VUSBHS_OTGSC_AVVIS)

/*
** status register signals
*/
#define SESS_VLD_FALSE(x)     \
   (!((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & \
   (VUSBHS_OTGSC_BSV | VUSBHS_OTGSC_ASV)))
   
#define SESS_VLD(x)           \
   (((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & \
   (VUSBHS_OTGSC_BSV | VUSBHS_OTGSC_ASV)))
   
#define B_SESS_END(x)         \
   (((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & \
   VUSBHS_OTGSC_BSE))

#define ID(x)                 \
   (((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & VUSBHS_OTGSC_ID))
   
#define ID_FALSE(x)           \
   (!((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & VUSBHS_OTGSC_ID))
   
#define A_VBUS_VLD(x)         \
   (((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & VUSBHS_OTGSC_AVV))

#define A_VBUS_VLD_FALSE(x)   \
   (!((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & \
   VUSBHS_OTGSC_AVV))
   
#define STABLE_J_SE0_LINE_STATE(x) (TRUE)

/*
** OTG control register signals
*/
/* discharge the VBUS */
#define VBUS_DSCHG_ON(x)      \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp | VUSBHS_OTGSC_VD)); \
   }
   
#define VBUS_DSCHG_OFF(x)     \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp & ~VUSBHS_OTGSC_VD)); \
   }

/* TURN ON/OFF VBUS charging */
#define VBUS_CHG_ON(x)        \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp | VUSBHS_OTGSC_VC)); \
   }
   
#define VBUS_CHG_OFF(x)       \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp & ~VUSBHS_OTGSC_VC)); \
   }

#define VBUS_ON(x)            \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.PORTSCX[0]); \
      temp &= ~EHCI_PORTSCX_W1C_BITS; \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.PORTSCX[0] = (temp | EHCI_PORTSCX_PORT_POWER)); \
   }
   
#define VBUS_OFF(x)           \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.PORTSCX[0]); \
      temp &= ~EHCI_PORTSCX_W1C_BITS; \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.PORTSCX[0] = (temp & ~EHCI_PORTSCX_PORT_POWER)); \
   }

#define DM_HIGH_ON(x)

#define DM_HIGH_OFF(x)

/***************************************************************
SG 06/21/2004
During SRP, software controls the duration of data pulse.
This control depends upon the system's interrupt latency
because in a system with large interrupt time, software
execution can take longer and data pulse may exceed
the max 10 mili second deadline. Latest hardware provides
a way that instead of setting D+ ON, we can just set the
HADP bit in hardware. This bit will set the D+ On and
after 7 mili second, it will turn off the DP.
***************************************************************/

#define DP_HIGH_ON(x)         \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp | VUSBHS_OTGSC_HADP)); \
   }
   
#define DP_HIGH_OFF(x)        \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp & ~VUSBHS_OTGSC_HADP)); \
   }

/*
#define DP_HIGH_ON(x)         \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp | VUSBHS_OTGSC_DP)); \
   }
   
#define DP_HIGH_OFF(x)        \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp & ~VUSBHS_OTGSC_DP)); \
   }
*/
#define SE0(x)                \
   (((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.PORTSCX[0] & \
      EHCI_PORTSCX_LINE_STATUS_BITS) == EHCI_PORTSCX_LINE_STATUS_SE0)
      
#define JSTATE(x)    (TRUE)

#define KSTATE(x)             \
   (((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.PORTSCX[0] & \
      EHCI_PORTSCX_LINE_STATUS_BITS) == EHCI_PORTSCX_LINE_STATUS_KSTATE)

/*hardware assistance can be used by setting the auto reset
bit in OTG register. This will help meet 1 ms reset
requirement under 5.4 OPT complaince test */
#define AUTO_RESET_ON(x)             \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp | VUSBHS_OTGSC_HAAR)); \
   }

#define AUTO_RESET_OFF(x)             \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp & ~VUSBHS_OTGSC_HAAR)); \
   }

#define IS_AUTO_RESET_ON(x,y)             \
   { \
      uint_32  temp; \
      temp = (x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC; \
      y = ((temp & VUSBHS_OTGSC_HAAR)? TRUE : FALSE); \
   }

/*hardware assistance can be used by setting the auto reset
bit in OTG register. This will help meet 1 ms reset
requirement under 5.4 OPT complaince test */
#define AUTO_HNP_ON(x)             \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp | VUSBHS_OTGSC_HABA)); \
   }

#define AUTO_HNP_OFF(x)             \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp & ~VUSBHS_OTGSC_HABA)); \
   }

#define IS_AUTO_HNP_ON(x,y)             \
   { \
      uint_32  temp; \
      temp = (x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC; \
      y = ((temp & VUSBHS_OTGSC_HABA)? TRUE : FALSE); \
   }

#define  VUSBHS_MODE_DEV                 (0x00000002)

#define IS_DEVICE_MODE_ON(x,y)             \
   { \
      uint_32  temp; \
      temp = (x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.USB_MODE & 0x3; \
      y = ((temp == VUSBHS_MODE_DEV)? TRUE : FALSE); \
   }

/*the patch_3 is enabled to make software compatable with
revision 4.0 of hardware */
#ifdef PATCH_3
	/* WEB20040409 below changed to reflect  VUSBHS_OTGSC_B_HOST_EN is no longer used. 
	      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
	      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp | VUSBHS_OTGSC_B_HOST_EN)); \   */
	/* to this */ 
	#define PULL_UP_PULL_DOWN_HOST_CTRL(x) \
	   { \
	      uint_32  temp; \
	      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
	      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp)); \
	 	  }

#else
	#define PULL_UP_PULL_DOWN_HOST_CTRL(x) \
	   { \
	      uint_32  temp; \
	      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
	      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp | VUSBHS_OTGSC_B_HOST_EN)); \
	   }
#endif      

#define PULL_UP_PULL_DOWN_DEVICE_CTRL(x)  \
   { \
      uint_32  temp; \
      temp = ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & ~VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK); \
      ((x)->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = (temp | VUSBHS_OTGSC_OT)); \
   }

#define PULL_UP_PULL_DOWN_IDLE(x)

#define OTG_HOST_INIT(x, y) \
   (x)->SERVICE((pointer)(x), USB_OTG_HOST_UP); \
   PULL_UP_PULL_DOWN_HOST_CTRL(y); \
   (x)->STATE_STRUCT_PTR->HOST_UP = TRUE;
         
#define OTG_DEVICE_INIT(x, y) \
   if (!((x)->STATE_STRUCT_PTR->DEVICE_UP)) { \
      (x)->SERVICE((pointer)(x), USB_OTG_DEVICE_UP); \
      /*(x)->STATE_STRUCT_PTR->DEVICE_UP = TRUE; */\
   } /* Endif */ \
   if (((x)->STATE_STRUCT_PTR->STATE) != B_IDLE) { \
      PULL_UP_PULL_DOWN_DEVICE_CTRL(y); \
   } /* Endif */

typedef  VUSB20_REG_STRUCT       USB_STRUCT;
typedef  VUSB20_REG_STRUCT       OTG_STRUCT;

typedef  VUSB20_REG_STRUCT_PTR   USB_STRUCT_PTR;
typedef  VUSB20_REG_STRUCT_PTR   OTG_STRUCT_PTR;


/* Prototypes */

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __USB_OS_MQX__
   extern void _usb_otg_vusbhs_isr(_usb_otg_handle);
   extern void _usb_hci_vusb20_isr(pointer);
   extern void _usb_dci_vusb20_isr(pointer);
#else
   extern void OTG_INTERRUPT_ROUTINE_KEYWORD _usb_otg_vusbhs_isr(void);
   extern void HOST_INTERRUPT_ROUTINE_KEYWORD _usb_hci_vusb20_isr(void);
   extern void DEVICE_INTERRUPT_ROUTINE_KEYWORD _usb_dci_vusb20_isr(void);
#endif
   uint_8 _usb_otg_vusbhs_init(_usb_otg_handle);
   extern void _usb_otg_vusbhs_shutdown(_usb_otg_handle);

#ifdef __cplusplus
}
#endif
#endif

/* EOF */
   





