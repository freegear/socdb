/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***  This file contains the low-level VUSBHS  On-The-Go routines.
***                                                               
**************************************************************************
**END*********************************************************/
#include "otgapi.h"
#include "usbprv_dev.h"
#include "usbprv_host.h"
#include "usbprv_otg.h"

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
#endif 

USB_OTG_STATE_STRUCT_PTR otg_handle;
extern USB_DEV_STATE_STRUCT_PTR global_usb_device_state_struct_ptr;
#ifndef PERIPHERAL_ONLY
extern USB_HOST_STATE_STRUCT_PTR usb_host_state_struct_ptr;
#endif

#ifndef __USB_OS_MQX__
extern volatile boolean IN_ISR;
#endif


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_vusbhs_init
* Returned Value : USB_OK or error code
* Comments       :
*     Initialises the OTG Hardware.  
* 
*END*--------------------------------------------------------------------*/
uint_8 _usb_otg_vusbhs_init
   (
      /* [IN] handle to the usb otg */
      _usb_otg_handle handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR      usb_otg_ptr;
   VUSB20_REG_STRUCT _PTR_       dev_ptr;
   VUSB20_REG_STRUCT _PTR_       cap_dev_ptr;
   VUSB20_REG_STRUCT _PTR_       otg_reg_ptr;
   uint_32                       temp;
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   
   cap_dev_ptr = (VUSB20_REG_STRUCT _PTR_)
      _bsp_get_usb_capability_register_base(usb_otg_ptr->DEV_NUM);

   /* Get the base address of the VUSB_HS registers */   
      
   usb_otg_ptr->USB_REG_PTR = (pointer)((uint_32)cap_dev_ptr + 
      (cap_dev_ptr->REGISTERS.CAPABILITY_REGISTERS.CAPLENGTH_HCIVER & 
         EHCI_CAP_LEN_MASK));
   
   usb_otg_ptr->OTG_REG_PTR = usb_otg_ptr->USB_REG_PTR;
   usb_otg_ptr->ENABLED_INTERRUPTS = VUSBHS_OTGSC_INTERRUPT_ENABLE_BITS_MASK;
   
   dev_ptr = (VUSB20_REG_STRUCT _PTR_)usb_otg_ptr->USB_REG_PTR;
   
   otg_reg_ptr = dev_ptr;
   
   /* Configure the VUSBHS as idle (both host and device ) */
   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.USB_MODE = 
      VUSBHS_MODE_CTRL_MODE_IDLE;
      
   temp = dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC;
   
   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = temp;
   
   /* mask all OTG interupts */
   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC &= 
      ~VUSBHS_OTGSC_INTERRUPT_ENABLE_BITS_MASK;
   
   /* Clear all OTG interrupts */
   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC |= 
      VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK;

#ifdef __USB_OS_MQX__                                          
   if (!(USB_install_isr((_bsp_get_usb_vector(usb_otg_ptr->DEV_NUM)), 
      _usb_otg_vusbhs_isr, (pointer)usb_otg_ptr)))
   {
      return USBERR_INSTALL_ISR;
   } /* Endbody */
#else

   USB_install_isr(_bsp_get_usb_vector(usb_otg_ptr->DEV_NUM), 
      _usb_otg_vusbhs_isr, (pointer)usb_otg_ptr);
#endif

#ifdef PERIPHERAL_ONLY
    usb_otg_ptr->STATE_STRUCT.STATE = B_IDLE;
#else
   /*
   ** The identification (id) input is FALSE when a Mini-A plug is inserted 
   ** in the device�s Mini-AB receptacle. Otherwise, this input is TRUE.
   */
   if (ID_FALSE(otg_reg_ptr)) {
      usb_otg_ptr->STATE_STRUCT_PTR->STATE = A_IDLE;
   } else {
      usb_otg_ptr->STATE_STRUCT_PTR->STATE = OTG_START;
   } /* Endif */
#endif   

/*Hardware revision 4.0 onwards need the switch PATCH_3 enabled. */
#ifdef PATCH_3
   /* WEB20040409 Below lines changed to take into account new VUSBHS_OTGSC_IDPU 
   bit in OTGSC register. This bit must remain enabled to allow proper 
   detection of ID line. */

   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = 
      (VUSBHS_OTGSC_DPIE | VUSBHS_OTGSC_BSEIE | VUSBHS_OTGSC_BSVIE | 
      VUSBHS_OTGSC_ASVIE | VUSBHS_OTGSC_AVVIE | VUSBHS_OTGSC_IDIE |
      VUSBHS_OTGSC_IDPU);       

#else
   /* Enable the OTG specific interrupts */
   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = 
      (VUSBHS_OTGSC_DPIE | VUSBHS_OTGSC_BSEIE | VUSBHS_OTGSC_BSVIE | 
      VUSBHS_OTGSC_ASVIE | VUSBHS_OTGSC_AVVIE | VUSBHS_OTGSC_IDIE);

#endif
      
#ifndef __USB_OS_MQX__   
   /* keep a global copy  of the handle */
   otg_handle = (USB_OTG_STATE_STRUCT_PTR)handle;
#endif
   /* start the state machine once to keep going */
   _usb_otg_state_machine((pointer)usb_otg_ptr);
   return USB_OK;
} /* Endbody */   

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_vusbhs_shutdown
* Returned Value : None
* Comments       :
*     Shutdown the otg  device.
* 
*END*--------------------------------------------------------------------*/
void _usb_otg_vusbhs_shutdown
   (
      /* [IN] Handle to the USB otg */
      _usb_otg_handle   handle
   )
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR   usb_otg_ptr;
   VUSB20_REG_STRUCT _PTR_       dev_ptr;
   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
   dev_ptr = usb_otg_ptr->USB_REG_PTR;
   
   /* mask all OTG interupts */
   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC &= 
      ~(usb_otg_ptr->ENABLED_INTERRUPTS);
      
   /* Clear all OTG interrupts */
   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC |= 
      VUSBHS_OTGSC_INTERRUPT_STATUS_BITS_MASK;
      
   /* Configure the VUSBHS as idle (both host and device ) */
   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.USB_MODE = 
      VUSBHS_MODE_CTRL_MODE_IDLE;
} /* EndBody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_otg_vusbhs_isr
* Returned Value : None
* Comments       :
*     Service all OTG and VUSB32 interrupts.
* 
*END*--------------------------------------------------------------------*/
#ifndef __USB_OS_MQX__
OTG_INTERRUPT_ROUTINE_KEYWORD void _usb_otg_vusbhs_isr
   (
      void
   )
#else
void _usb_otg_vusbhs_isr
   (
      _usb_otg_handle handle
   )
#endif
{ /* Body */
   USB_OTG_STATE_STRUCT_PTR               usb_otg_ptr;
   VUSB20_REG_STRUCT _PTR_                dev_ptr;
   uint_32                                otg_status, port_control, temp;
   OTG_STATE_MACHINE_STRUCT_PTR           s_ptr;
   boolean                                timer_expired = FALSE;

#ifndef __USB_OS_MQX__   
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)otg_handle;
   IN_ISR = TRUE;
#else
   usb_otg_ptr = (USB_OTG_STATE_STRUCT_PTR)handle;
#endif
   dev_ptr = usb_otg_ptr->USB_REG_PTR;
   s_ptr = usb_otg_ptr->STATE_STRUCT_PTR;

   /**********************************************************
   SG 06/22/2004
   In the later hardware revisions, HNP event is assisted
   by hardware, In such a case when A device moves from
   A_SUSPEND to A_PERIPHERAL, hardware resets the OTG core
   and moves the core into device mode. This feature in
   harware removes the burdon from software when software
   should initialize the core in device mode. On systems
   with large interrupt latency, software may take long time
   response time may exceed 3 mili second limit defined
   by OTG for TA_BDIS_ACON.
   
   When software has such as assistance available from
   hardware, we need to check if hardware has moved the
   core to A_PERIPHERAL state before we read the OTG
   ISR and take any action. If hardware has done so,
   we immidiately need to shutdown the Host and
   intialize the core in device mode. 
   **********************************************************/

   #ifdef   HNP_HARDWARE_ASSISTANCE
   /*if interrupt has come because hardware assisted in
   HNP, we should return */
       if(_usb_otg_hnp_assistance_check((pointer)usb_otg_ptr))
       {
            #ifndef __USB_OS_MQX__
            _usb_dci_vusb20_isr();
            #else
            _usb_dci_vusb20_isr((pointer)global_usb_device_state_struct_ptr); 
            #endif
             return;
        }
   #endif
   
   
   /* Get the status of enabled interrupts */
   otg_status = (dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & 
      (usb_otg_ptr->ENABLED_INTERRUPTS >> 8));
   
   do {
      /* Clear all enabled interrupts */
      temp = dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC;
      dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC = 
         (temp | otg_status);
      
      /* If we have OTG interrupt call the state machine */
      if (otg_status) {
         s_ptr->OTG_INT_STATUS = otg_status;
         
         if ((otg_status & VUSBHS_OTGSC_DPIS) && 
            (!s_ptr->A_DATA_PULSE_DET)) 
         {
            s_ptr->A_DATA_PULSE_DET = TRUE;
         } /* Endif */
         
         /*
         ** If any timers expired  it will process the event and
         ** any other signals at that time. We don't need to call
         ** the state machine if this is the case.
         */
         if (otg_status & VUSBHS_OTGSC_1MSIS) {
            timer_expired = _usb_otg_process_timers((pointer)usb_otg_ptr);
            otg_status &= ~VUSBHS_OTGSC_1MSIS;
         } /* Endif */
         
         if (otg_status && (!timer_expired)) {
            _usb_otg_state_machine((pointer)usb_otg_ptr);
         } else {
            timer_expired = FALSE;
         } /* Endif */
         s_ptr->OTG_INT_STATUS = 0;
      } /* Endif */
      
#ifndef PERIPHERAL_ONLY
      /* A_DEVICE */
      if (s_ptr->HOST_UP) {
         /* Check data line pulsing by B device */
         port_control = dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.PORTSCX[0];
      
         if (s_ptr->A_SRP_TMR == -1) {
            if ((s_ptr->STATE == B_WAIT_ACON) && 
               ((port_control & EHCI_PORTSCX_CURRENT_CONNECT_STATUS) && 
                (port_control & EHCI_PORTSCX_CONNECT_STATUS_CHANGE))) 
            {
               s_ptr->A_CONNECTED = TRUE;
            } /* Endif */
            
#ifndef __USB_OS_MQX__
            _usb_hci_vusb20_isr();
#else
            _usb_hci_vusb20_isr((pointer)usb_host_state_struct_ptr); 
#endif
         } /* Endif */
      } /* Endif */
#endif
      /* B_DEVICE */
      if (s_ptr->DEVICE_UP){
         if ((s_ptr->STATE == B_IDLE) && 
            (dev_ptr->REGISTERS.OPERATIONAL_DEVICE_REGISTERS.USB_STS & 
               EHCI_STS_RESET)) 
         {
            return;
         } /* Endif */
#ifndef __USB_OS_MQX__
         _usb_dci_vusb20_isr();
#else
         _usb_dci_vusb20_isr((pointer)global_usb_device_state_struct_ptr); 
#endif
      } /* Endif */
      
      /* check the interrupt again */
      /* Get the status of enabled interrupts */
      otg_status = (dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.OTGSC & 
         (usb_otg_ptr->ENABLED_INTERRUPTS >> 8));
         
   } while(otg_status);
#ifndef __USB_OS_MQX__   
   IN_ISR = FALSE;
#endif
} /* Endbody */
/* EOF */
