# Communication Class

#
# Define the following variables for the class:
#
#     srcs          list of source files without extensions
#     srcdirs       list of directories containing source files
#
#     dups          list of files to be copied to the output directory
#     dupdirs       list of directories containing the 'dups' files
#
# NOTE: Always use += when defining variables!
#

CPPFLAGS         +=-DUSBCLASS_INC_CDC
MQX_INCDIRS      +=$(USB_ROOT)\source\classes\cdc

dupdirs  += classes$(PS)cdc
dups     += usb_cdc.h

srcdirs  += classes$(PS)cdc
class_srcs     += usb_cdc usb_data usb_cdc_reqs usb_acm usb_ecm

