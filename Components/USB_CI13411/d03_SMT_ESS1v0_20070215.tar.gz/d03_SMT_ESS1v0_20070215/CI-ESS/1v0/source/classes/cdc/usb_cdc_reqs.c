/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description: 
***   This file implementes USB communication class control requests.
***
**************************************************************************
**END*********************************************************/

#include "usb_cdc.h"


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_send_encap_command
* Returned Value : USB_STATUS
* Comments       :
*     Issues a command in the format of the supported control protocol
*     using an CDC class command.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_cdc_send_encap_command
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN] The encapsulated command */
      uchar_ptr   encap_ptr,
      /* [IN] The length of the command */
      uint_16     length
   )
{ /* Body */

   return usb_cdc_setup_common(
      command, CDC_REQ_OUT, SEND_ENCAPSULATED_COMMAND, 0, length, encap_ptr);

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_get_encap_command
* Returned Value : USB_STATUS
* Comments       :
*     Requests a response in the format of the supported control protocol
*     of the Comminications Class interface using an CDC class command.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_cdc_get_encap_command
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN/OUT] The buffer in which to place the command */
      uchar_ptr   encap_ptr,
      /* [IN] The lenght of the buffer */
      uint_16     length
   )
{ /* Body */

   return usb_cdc_setup_common(
      command, CDC_REQ_IN, GET_ENCAPSULATED_COMMAND, 0, length, encap_ptr);

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_set_comm_feature
* Returned Value : USB_STATUS
* Comments       :
*     Controls the settings for a particular communication feature.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_cdc_set_comm_feature
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN] Multicast filters in buffer, each 6 bytes in network order */
      uint_16     feature,
      /* [IN] The length of the data */
      uint_16     len,
      /* [IN] The feature data buffer */
      uchar_ptr   data
   )
{ /* Body */

   return usb_cdc_setup_common(
      command, CDC_REQ_OUT, SET_COMM_FEATURE, feature, len, data);

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_get_comm_feature
* Returned Value : USB_STATUS
* Comments       :
*     Returns the current settings for the communication feature.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_cdc_get_comm_feature
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN] Multicast filters in buffer, each 6 bytes in network order */
      uint_16     feature,
      /* [IN] The length of the data */
      uint_16     len,
      /* [IN] The location to place the feature data */
      uchar_ptr   data
   )
{ /* Body */

   return usb_cdc_setup_common(
      command, CDC_REQ_IN, GET_COMM_FEATURE, feature, len, data);

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_clear_comm_feature
* Returned Value : USB_STATUS
* Comments       :
*     Clears the settings for a particular communication feature.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_cdc_clear_comm_feature
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN] Multicast filters in buffer, each 6 bytes in network order */
      uint_16     feature
   )
{ /* Body */

   return usb_cdc_setup_common(
      command, CDC_REQ_OUT, CLEAR_COMM_FEATURE, feature, 0, NULL);

} /* Endbody */


/* EOF */

