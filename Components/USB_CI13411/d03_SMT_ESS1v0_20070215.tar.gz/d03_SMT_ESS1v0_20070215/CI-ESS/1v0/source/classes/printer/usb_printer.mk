# Printer Class

#
# Define the following variables for the class:
#
#     srcs          list of source files without extensions
#     srcdirs       list of directories containing source files
#
#     dups          list of files to be copied to the output directory
#     dupdirs       list of directories containing the 'dups' files
#
# NOTE: Always use += when defining variables!
#

CPPFLAGS         +=-DUSBCLASS_INC_PRINTER
MQX_INCDIRS      +=$(USB_ROOT)\source\classes\printer

dupdirs  += classes\printer
dups     += usb_printer.h usb_printer_version.h


srcdirs  += classes\printer
class_srcs     += usb_printer

