# Mass Class

#
# Define the following variables for the class:
#
#     srcs          list of source files without extensions
#     srcdirs       list of directories containing source files
#
#     dups          list of files to be copied to the output directory
#     dupdirs       list of directories containing the 'dups' files
#
# NOTE: Always use += when defining variables!
#

CPPFLAGS       +=-DUSBCLASS_INC_MASS
MQX_INCDIRS    +=$(USB_ROOT)$(PS)source$(PS)classes$(PS)mass

dupdirs        += classes$(PS)mass
#dups           += usb_mass_bo.h usb_mass_ufi.h usb_mass_version.h
dups           += usb_mass_ufi.h


srcdirs        += classes$(PS)mass
class_srcs     += usb_mass_bo usb_mass_ufi usb_mass_queue

