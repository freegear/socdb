/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains the USB Communications class driver
***
**************************************************************************
**END*********************************************************/


#include "usb_cdc.h"


static void usb_cdc_notif_callback ( pointer, pointer, uchar_ptr, uint_32, USB_STATUS);

/* Linked list of all CDC class interfaces */
static CDC_INTERFACE_STRUCT_PTR cdc_head_ptr = NULL;


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_init
* Returned Value : none
* Comments       :
*     Initialize a generic CDC class interface struct.
*
*END*--------------------------------------------------------------------*/

void usb_cdc_init
   (
      /* [IN] device/descriptor/pipe handles */
      PIPE_BUNDLE_STRUCT_PTR  pbs_ptr,
      /* [IN] CDC call struct pointer */
      CLASS_CALL_STRUCT_PTR   cdc_call_ptr
   )
{ /* Body */
   CDC_INTERFACE_STRUCT_PTR     intf = cdc_call_ptr->class_intf_handle;
   TR_INIT_PARAM_STRUCT         tr;
   USB_STATUS                   status = USB_OK;
   
   INTERFACE_DESCRIPTOR_PTR     pTmp;

   /* Pointer validity-checking, clear memory, init header */
   if (usb_host_class_intf_init(pbs_ptr, &intf->G, &cdc_head_ptr)) return;

   USB_lock();
   cdc_call_ptr->code_key = 0;
   cdc_call_ptr->code_key = usb_host_class_intf_validate(cdc_call_ptr);
   if (cdc_call_ptr->code_key == 0) {
      USB_unlock();
      return;
   } /* Endif */

   pTmp = (INTERFACE_DESCRIPTOR_PTR)intf->G.intf_handle;
   /* Get the CONTROL pipe handle and interface number */
   intf->IFNUM = ((INTERFACE_DESCRIPTOR_PTR)intf->G.intf_handle)->bInterfaceNumber;
   intf->PIPE.CTRL  = usb_hostdev_get_pipe_handle(pbs_ptr, USB_CONTROL_PIPE,   0);

   /* Make sure the CONTROL pipe is open */
   if (!intf->PIPE.CTRL) {
      /* Invalidate class instance */
      intf->G.key_code = 0;
      status = USBERR_CLASS_DRIVER_INSTALL;
   } /* Endif */

   /* Try to setup the notification call back, if there is a notif endpoint */
   if (!status) {
      intf->PIPE.NOTIF = usb_hostdev_get_pipe_handle(pbs_ptr, USB_INTERRUPT_PIPE, USB_RECV);

      /* If it's there configure it to recv notifications */
      /*if (intf->PIPE.NOTIF) {
         tr.RX_BUFFER = intf->NOTIF_BUFFER;
         tr.RX_LENGTH = CDC_MAX_NOTIFICATION_SIZE;
         usb_hostdev_tr_init(&tr, usb_cdc_notif_callback, intf);
          J.Zhou: call this function to get NOTIF at application level after interface
             selecting for both COMM and DATA completed.
         status = _usb_host_recv_data(intf->G.host_handle, intf->PIPE.NOTIF, &tr);
      } */
   } /* Endif */

   USB_unlock();
   return;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_notif_callback
* Returned Value : none
* Comments       :
*    An CDC specific callback function used to by the lower level when a
*    notification arrives.
*
*END*--------------------------------------------------------------------*/

static void usb_cdc_notif_callback
   (
      /* [IN] Unused */
      pointer     dummy,
      /* [IN] Pointer to the class interface instance */
      pointer     param,
      /* [IN] Pointer to the buffer */
      uchar_ptr   buffer,
      /* [IN] Length of the buffer */
      uint_32     len,
      /* [IN] Error code (if any) */
      USB_STATUS  status
   )
{ /* Body */
   CDC_INTERFACE_STRUCT_PTR      intf;
   USB_SETUP_PTR                 setup = (USB_SETUP_PTR)buffer;

   /*
   ** There is no need for USB_lock in the callback function, and there is also no
   ** need to check if the device is still attached (otherwise this callback
   ** would never have been called!
   */

   /* Get class interface handle and call callback */
   intf = (CDC_INTERFACE_STRUCT_PTR)param;

   if (intf->NOTIF_CALLBACK)
      intf->NOTIF_CALLBACK(intf->NOTIF_PARAM, intf, buffer, len, status);

} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_recv_notif
* Returned Value : USB_STATUS
* Comments       :
*     Read the notification interrupt pipe for notifications from the device
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_cdc_recv_notif
   (
      /* [IN] The CDC class interface */
      CLASS_CALL_STRUCT_PTR   cdc_call_ptr
   )
{ /* Body */
   CDC_INTERFACE_STRUCT_PTR     intf;
   TR_INIT_PARAM_STRUCT         tr;
   USB_STATUS                   error = USBERR_BAD_STATUS;

   USB_lock();
   
   /* Make sure device has not been detached */
   if (usb_host_class_intf_validate(cdc_call_ptr)) {
      intf = (CDC_INTERFACE_STRUCT_PTR)cdc_call_ptr->class_intf_handle;
      error = usb_hostdev_validate(intf->G.dev_handle);
   } /* Endif */


   if (intf->PIPE.NOTIF) {
         usb_hostdev_tr_init(&tr, usb_cdc_notif_callback, intf);
         tr.RX_BUFFER = intf->NOTIF_BUFFER;
         tr.RX_LENGTH = CDC_MAX_NOTIFICATION_SIZE;
         error = _usb_host_recv_data(intf->G.host_handle, intf->PIPE.NOTIF, &tr);
      }
         
   USB_unlock();
   return error;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_set_notif_callback
* Returned Value : USB_STATUS
* Comments       :
*     Sets the callback function used to inform higher level of notifications
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_cdc_set_notif_callback
   (
      /* [IN] The CDC class interface for which to set a callback */
      CLASS_CALL_STRUCT_PTR   CLASS_PTR,
      /* [IN] The callback function to call when a notification event occurs */
      CDC_CALLBACK_NOTIF_FN   callback
   )
{ /* Body */
   CDC_INTERFACE_STRUCT_PTR         intf;
   USB_STATUS                       error = USB_OK;
   
   intf = (CDC_INTERFACE_STRUCT_PTR)CLASS_PTR->class_intf_handle;
   intf->NOTIF_CALLBACK = callback;

   return error;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_setup_callback
* Returned Value : none
* Comments       :
*    An CDC specific callback function used to cleanup the CDC interface struct
*    and call back to application drivers after a COMM class request completes.
*
*END*--------------------------------------------------------------------*/

static void usb_cdc_setup_callback
   (
      /* [IN] Unused */
      pointer     dummy,
      /* [IN] Pointer to the class interface instance */
      pointer     param,
      /* [IN] Data buffer */
      uchar_ptr   buffer,
      /* [IN] Length of buffer */
      uint_32     len,
      /* [IN] Error code (if any) */
      USB_STATUS  status
   )
{ /* Body */
   CDC_INTERFACE_STRUCT_PTR      intf;

   /*
   ** There is no need for USB_lock in the callback function, and there is also no
   ** need to check if the device is still attached (otherwise this callback
   ** would never have been called!
   */

   /* Get class interface handle, reset IN_SETUP and call callback */
   intf = (CDC_INTERFACE_STRUCT_PTR)param;

#if 0
   /*
   ** This can't happen unless somebody corrupted memory! Even so, we can't do
   ** anything about it.
   */
   if (!intf) {
      return;
   } /* Endif */
#endif

   intf->IN_SETUP = FALSE;

   if (intf->FREE) {
      USB_memfree(intf->FREE);
   } /* Endif */

   if (intf->USER_CALLBACK) {
      intf->USER_CALLBACK(intf->USER_PARAM, intf, len, status);
   } /* Endif */

} /* Endbody */



/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_setup_common
* Returned Value : uint_32
* Comments       :
*     A common function used to send requests for all CDC class commands
*
*END*--------------------------------------------------------------------*/

uint_32 usb_cdc_setup_common
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR         command,
      /* [IN] Bitmask of the request type */
      uint_8                  BMREQUESTTYPE,
      /* [IN] Request code */
      uint_8                  BREQUEST,
      /* [IN] Value to copy into WVALUE field of the REQUEST */
      uint_16                 WVALUE,
      /* [IN] Length of the data associated with REQUEST */
      uint_16                 WLENGTH,
      /* [IN] Pointer to data buffer used to send/recv */
      uchar_ptr               data
   )
{ /* Body */
   CDC_INTERFACE_STRUCT_PTR      intf;
   TR_INIT_PARAM_STRUCT          tr;
   USB_SETUP                     dev_req;
   USB_STATUS                    error = USBERR_NO_DEVICE_CLASS;

   USB_lock();

   /* Make sure device has not been detached */
   if (usb_host_class_intf_validate(command->CLASS_PTR)) {
      intf = (CDC_INTERFACE_STRUCT_PTR)command->CLASS_PTR->class_intf_handle;
      error = usb_hostdev_validate(intf->G.dev_handle);
   } /* Endif */

   /*
   ** If the device was detached, or the previous SETUP transfer has not been
   ** complete, return an error
   */
   if (!error && intf->IN_SETUP) {
      error = USBERR_TRANSFER_IN_PROGRESS;
   } /* Endif */

   if (error) {
      USB_unlock();
      return error;
   } /* Endif */

   /* Setup the Request */
   intf->IN_SETUP = TRUE;
   dev_req.BMREQUESTTYPE = BMREQUESTTYPE;
   dev_req.BREQUEST = BREQUEST;
   htou16(dev_req.WVALUE, WVALUE);
   htou16(dev_req.WINDEX, intf->IFNUM);
   htou16(dev_req.WLENGTH, WLENGTH);

   /* Setup the transaction, callback and callback param */
   usb_hostdev_tr_init(&tr, usb_cdc_setup_callback, (pointer)intf);
   tr.DEV_REQ_PTR = (uchar_ptr)&dev_req;

   /* Different buffers used for different directions */
   if (BMREQUESTTYPE & REQ_TYPE_IN) {
      tr.RX_BUFFER = data;
      tr.RX_LENGTH = WLENGTH;
   } else {
      tr.TX_BUFFER = data;
      tr.TX_LENGTH = WLENGTH;
   }

   /* Save the higher level callback and ID */
   intf->USER_CALLBACK = command->CALLBACK_FN;
   intf->USER_PARAM = command->CALLBACK_PARAM;

   /* Send the SETUP command */
   error = _usb_host_send_setup(intf->G.host_handle, intf->PIPE.CTRL, &tr);
   USB_unlock();

   return error;
} /* Endbody */



/* EOF */


