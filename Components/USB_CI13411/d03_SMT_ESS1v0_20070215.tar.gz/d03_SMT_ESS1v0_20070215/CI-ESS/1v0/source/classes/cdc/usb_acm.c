/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains the Abstract control model specifics of the
***   USB Communications class driver
***
**************************************************************************
**END*********************************************************/

#include "usb_cdc.h"


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_acm_init
* Returned Value : none
* Comments       :
*     Initialize the Abstract Control Model interface info struct.
*
*END*--------------------------------------------------------------------*/

void usb_acm_init
   (
      /* [IN] device/descriptor/pipe handles */
      PIPE_BUNDLE_STRUCT_PTR  pbs_ptr,
      /* [IN] ACM call struct pointer */
      CLASS_CALL_STRUCT_PTR   acm_call_ptr
   )
{ /* Body */

   /* Initialize common CDC struct */
   usb_cdc_init(pbs_ptr, acm_call_ptr);

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_acm_set_line_coding
* Returned Value : USB_STATUS
* Comments       :
*     Configures DTE rate, stop-bits, parity and number of character bits.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_acm_set_line_coding
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN] The line coding data structure */
      uchar_ptr           lc_ptr
   )
{ /* Body */

   return usb_cdc_setup_common(command,
      CDC_REQ_OUT, SET_LINE_CODING, 0, sizeof(LINE_CODING_STRUCT), lc_ptr);

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_acm_get_line_coding
* Returned Value : USB_STATUS
* Comments       :
*     Requests current DTE rate, stop-bits, parity and number of character
*     bits.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_acm_get_line_coding
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR     command,
      /* [OUT] Pointer to a LINE_CODING_STRUCT */
      uchar_ptr           lc_ptr
   )
{ /* Body */

   return usb_cdc_setup_common(command,
      CDC_REQ_IN, GET_LINE_CODING, 0, sizeof(LINE_CODING_STRUCT), lc_ptr);

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_acm_set_control_line_state
* Returned Value : USB_STATUS
* Comments       :
*     RS-232 signal used to tell the DCE device the DTE device is now present.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_acm_set_control_line_state
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN] The state */
      uint_16                 state
   )
{ /* Body */

   return usb_cdc_setup_common(command,
      CDC_REQ_OUT, SET_CONTROL_LINE_STATE, state, 0, NULL);

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_acm_send_break
* Returned Value : USB_STATUS
* Comments       :
*     Sends a special carrier modulation used to specify RS-232 style break.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_acm_send_break
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR     command
   )
{ /* Body */

   return usb_cdc_setup_common(command, CDC_REQ_OUT, SEND_BREAK, 0, 0, NULL);

} /* Endbody */


/* EOF */

