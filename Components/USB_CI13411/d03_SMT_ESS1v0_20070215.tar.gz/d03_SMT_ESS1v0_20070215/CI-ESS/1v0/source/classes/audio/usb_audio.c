/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains  the USB audio class driver
***
*** Implementation notes:
***   It is essential that an application select first the audio
***      control interface of an interface collection, to build
***      the class-interface struct.  Later selections of MIDI
***      or audio-streaming interfaces then complete their own
***      regions within the struct for associated interfaces.
***   Frequently streaming interfaces use alternate zero as a
***      no-endpoint/no-bandwidth starting point.  If another
***      alternate is then selected, the earlier one is torn
***      down and new data written over that region.
***                                                               
**************************************************************************
**END*********************************************************/
#include "usb_audio.h"
#include "types.h"

/*--------------------------------------------------------------**
** This anchor points to the first class/interface in a linked  **
**   chain of structs, one for each functional print interface. **
**   Items are added by calling "select interface" and removed  **
**   by "delete interface".  Typically an application will call **
**   these select in its attach callback routine.  It may later **
**   call delete, or the call may be automatic during detach.   **
**--------------------------------------------------------------*/

static AUDIO_INTERFACE_STRUCT_PTR aud_anchor = NULL;

/* Private functions for use within this file only */
static USB_STATUS usb_audio_get_descriptor
   (AUDIO_DESCRIPTOR_PARMS_PTR,
    pointer _PTR_
    );
static USB_STATUS usb_audio_get_as_ep_descriptor
   (AUDIO_DESCRIPTOR_PARMS_PTR,
    pointer _PTR_
    );
static uint_32 usb_audio_intf_validate
   (
      PIPE_BUNDLE_STRUCT_PTR,
      CLASS_CALL_STRUCT_PTR
   );
static void usb_audio_subclass_control
   (
      PIPE_BUNDLE_STRUCT_PTR,
      CLASS_CALL_STRUCT_PTR
   );
static void usb_audio_subclass_MIDI
   (
      PIPE_BUNDLE_STRUCT_PTR,
      CLASS_CALL_STRUCT_PTR
   );
static void usb_audio_subclass_stream
   (
      PIPE_BUNDLE_STRUCT_PTR,
      CLASS_CALL_STRUCT_PTR
   );

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : usb_class_aud_cntrl_callback
* Returned Value : Max packet size in uint_16
* Comments       :
*     Call to get max packet size for a data pipe 
* 
*END*--------------------------------------------------------------------*/

USB_STATUS usb_audio_get_max_data_packet_size
   (
      /* [IN] device instance handle */
      CLASS_CALL_STRUCT_PTR      cc_ptr,
      /* [IN] Data pipe direction */
      uint_8                     bDirection,
      /* [OUT] max data packet size */
      uint_16                    *wMaxPacketSize
   )
{
   //uint16                        wSize;
   AUDIO_INTERFACE_STRUCT_PTR    ais_ptr;
   SD_AUDIO_DATA_EP_DESCRIPTOR_PTR   saep;
   
   ais_ptr = (AUDIO_INTERFACE_STRUCT_PTR)
      cc_ptr->class_intf_handle;
   if (bDirection == AUD_DIRECTION_IN)
      saep = ais_ptr->AS_in_ep.saep;
   else
      saep = ais_ptr->AS_out_ep.saep;
   
   if (saep && saep->bLength > 0) { /* Body */
      *wMaxPacketSize = utoh16(saep->wMaxPacketSize);  
      return USB_OK;
   } else
      return USBERR_BAD_STATUS;  
}

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : usb_audio_get_feature_unitID
* Returned Value : Max packet size in uint_16
* Comments       :
*     Call to the feature unitID for an audio stream 
* 
*END*--------------------------------------------------------------------*/
USB_STATUS usb_audio_get_feature_unitID
   (
      /* [IN] device instance handle */
      CLASS_CALL_STRUCT_PTR      cc_ptr,
      /* streaming pipe direction */
      uint_8                     bDirection,
      /* [OUT] feature unitID */
      uint_8                    *bUnit,
      /* [OUT] feature control bitmap */
      uint_8                    *bBMCtrl
   )
{
   USB_STATUS                    usbStatus = USBERR_BAD_STATUS;
   AUDIO_INTERFACE_STRUCT_PTR    ais_ptr;
   AS_INTERFACE_DESCRIPTOR_PTR   asid;
   uint_8                        i, bTmp;
   CLASS_UNION                   cDesc;
   
   ais_ptr = (AUDIO_INTERFACE_STRUCT_PTR)
      cc_ptr->class_intf_handle;
   if (bDirection == AUD_DIRECTION_IN)
      asid = ais_ptr->AS_in_general.asid;
   else
      asid = ais_ptr->AS_out_general.asid;
   if (!asid)
      return USBERR_BAD_STATUS;
   
   // Get related terminal ID   
   bTmp = asid->bTerminalLink;
   if (bTmp >= MAX_UNIT_ID)
      return USBERR_BAD_STATUS;
   cDesc = ais_ptr->unitID[bTmp];
   // Get TerminalID for that terminal (itrm or otrm)
   bTmp = cDesc.otrm->bDescriptorSubtype;
   if (bTmp == AUD_AC_OUTPUT_TERMINAL) { /* Body */
      bTmp = cDesc.otrm->iSourceID;
      if (ais_ptr->unitID[bTmp].pntr != NULL &&
         ais_ptr->unitID[bTmp].fead->bDescriptorSubtype == AUD_AC_FEATURE_UNIT) { /* Body */
         usbStatus = USB_OK;
         *bUnit = bTmp;
         // We are only intrested in the first byte
         *bBMCtrl = ais_ptr->unitID[bTmp].fead->bmaControls[0][0];  
      } /* Endbody */
   } else { /* Body */
      bTmp = cDesc.itrm->bTerminalID;
      for (i=0; i<MAX_UNIT_ID; i++) { /* Body */
         if (ais_ptr->unitID[i].pntr != NULL &&
             ais_ptr->unitID[i].fead->bDescriptorSubtype == AUD_AC_FEATURE_UNIT &&
             ais_ptr->unitID[i].fead->iSourceID == bTmp) { /* Body */
             usbStatus = USB_OK;
             *bUnit = i;
             // We are only intrested in the first byte
             *bBMCtrl = ais_ptr->unitID[i].fead->bmaControls[0][0];  
             break;
         } /* Endbody */
      }
   } /* Endbody */      
   
   return usbStatus; 
}

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_get_iso_ep_number
* Returned Value : None
* Comments       :
*     Called to get maximum sample frequence for an audio stream
*END*--------------------------------------------------------------------*/
USB_STATUS usb_audio_get_iso_ep_address
   (
      /* [IN] device instance handle */
      CLASS_CALL_STRUCT_PTR      cc_ptr,
      /* [IN] audio stream index */
      uint_8                     bDirection,
      /* [OUT] ISO EP number */
      uint_8                     *bEP
   )
{
   AUDIO_INTERFACE_STRUCT_PTR       ais_ptr;
   SD_AUDIO_DATA_EP_DESCRIPTOR_PTR  saep;
      
   ais_ptr = (AUDIO_INTERFACE_STRUCT_PTR)
      cc_ptr->class_intf_handle;
   if (bDirection == AUD_DIRECTION_IN)
      saep = ais_ptr->AS_in_ep.saep;
   else
      saep = ais_ptr->AS_out_ep.saep;
   if (saep) { /* Body */
      *bEP = saep->bEndpointAddress;
      return USB_OK;
   } else
      return USBERR_BAD_STATUS;
 }


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : usb_audio_cntrl_callback
* Returned Value : None
* Comments       :
*     Call audio control back function 
* 
*END*--------------------------------------------------------------------*/

static void usb_audio_cntrl_callback
   (
      /* [IN] Unused */
      pointer     pipe,
      /* [IN] Pointer to the class interface instance */
      pointer     param,
      /* [IN] Data buffer */
      uchar_ptr   buffer,
      /* [IN] Length of buffer */
      uint_32     len,
      /* [IN] Error code (if any) */
      USB_STATUS  status
   )
{ /* Body */
   AUDIO_INTERFACE_STRUCT_PTR      if_ptr;

   /*
   ** There is need for USB_lock in the callback function, and there is also no
   ** need to check if the device is still attached (otherwise this callback
   ** would never have been called!
   */

   /* Get class interface handle, reset IN_SETUP and call callback */
   if_ptr = (AUDIO_INTERFACE_STRUCT_PTR)param;

   if_ptr->IN_SETUP = FALSE;

   if (if_ptr->USER_CALLBACK) {
      if_ptr->USER_CALLBACK(if_ptr->USER_PARAM, if_ptr, len, status);
   } /* Endif */

} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : usb_audio_control_request
* Returned Value : USB_OK or error code
* Comments       :
*     With the wide variety of valid requests that can be made,
*     the application is afforded only limited error checks here.
* 
*END*--------------------------------------------------------------------*/

USB_STATUS usb_audio_control_request 
   (
      /* [IN] device instance handle */
      AUDIO_COMMAND_PTR          cmd_ptr,
      
      /* [IN] setup packet for request */
      USB_SETUP_PTR              dev_req,
      
      /* [IN] buffer length */
      uint_16                    buf_size,
      
      /* [IN/OUT] parameter-block buffer */
      uchar_ptr                  buffer
      )
   { /* Body */

   AUDIO_INTERFACE_STRUCT_PTR    ais_ptr;
   USB_STATUS                    error = USBERR_NO_DEVICE_CLASS;

   USB_lock ();
   
   /* Make sure device has not been detached */
   if (usb_host_class_intf_validate(cmd_ptr->CLASS_PTR)) {
      ais_ptr = (AUDIO_INTERFACE_STRUCT_PTR)cmd_ptr->CLASS_PTR->class_intf_handle;
      error = usb_hostdev_validate(ais_ptr->G.dev_handle);
   } /* Endif */
   
   /*
   ** If the device was detached, or the previous SETUP transfer has not been
   ** complete, return an error
   */
   if (!error && ais_ptr->IN_SETUP) {
      error = USBERR_TRANSFER_IN_PROGRESS;
   } /* Endif */
   
   if (error != USB_OK)
      goto Exit_Now;
  /* if (ais_ptr->control_callback == NULL)
      {
      error = USBERR_NULL_CALLBACK;
      goto Exit_Now;
      }  */

   /* Verify valid Request Type */
   switch (dev_req->BMREQUESTTYPE)
      {
      case REQ_TYPE_INTERFACE | REQ_TYPE_CLASS | REQ_TYPE_IN:
      case REQ_TYPE_INTERFACE | REQ_TYPE_CLASS | REQ_TYPE_OUT:
      case REQ_TYPE_ENDPOINT | REQ_TYPE_CLASS | REQ_TYPE_IN:
      case REQ_TYPE_ENDPOINT | REQ_TYPE_CLASS | REQ_TYPE_OUT:
         break ;
      default:
         error = USBERR_INVALID_BMREQ_TYPE;
         goto Exit_Now;
      } /* EndCase */

   /* Verify valid Request */
   switch (dev_req->BREQUEST)
      {
      case AUD_SET_CUR:
      case AUD_GET_CUR:
      case AUD_SET_MIN:
      case AUD_GET_MIN:
      case AUD_SET_MAX:
      case AUD_GET_MAX:
      case AUD_SET_RES:
      case AUD_GET_RES:
      case AUD_SET_MEM:
      case AUD_GET_MEM:
      case AUD_GET_STAT:
         break ;
      default:
         error = USBERR_INVALID_REQ_TYPE;
         goto Exit_Now;

      } /* EndCase */

   ais_ptr->USER_CALLBACK = cmd_ptr->CALLBACK_FN;
   ais_ptr->USER_PARAM = cmd_ptr->CALLBACK_PARAM;

   error = _usb_hostdev_cntrl_request(ais_ptr->G.dev_handle, dev_req, buffer,
         usb_audio_cntrl_callback, ais_ptr);
   if (error == USB_STATUS_TRANSFER_QUEUED) {
         ais_ptr->IN_SETUP = TRUE;
   }

   Exit_Now:
   USB_unlock ();
   return error;

} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_audio_data_callback
* Returned Value : USB_STATUS
* Comments       :
*    An CDC specific callback function used to cleanup the CDC interface struct
*    after a data transfer completes.
*
*END*--------------------------------------------------------------------*/

static void usb_audio_data_callback
   (
      /* [IN] Unused */
      pointer     dummy,
      /* [IN] Pointer to the class interface instance */
      pointer     param,
      /* [IN] Data buffer */
      uchar_ptr   buffer,
      /* [IN] Length of buffer */
      uint_32     len,
      /* [IN] Error code (if any) */
      USB_STATUS  status
   )
{ /* Body */
   AUDIO_INTERFACE_STRUCT_PTR      intf;

   /*
   ** There is no need for USB_lock in the callback function, and there is also no
   ** need to check if the device is still attached (otherwise this callback
   ** would never have been called!
   */

   /* Get class interface handle, reset IN_SETUP and call callback */
   intf = (AUDIO_INTERFACE_STRUCT_PTR)param;

   intf->IN_DATA = FALSE;

   /*intf->FREE) {
      USB_memfree(intf->FREE);
   } */

   if (intf->DATA_CALLBACK) {
      intf->DATA_CALLBACK(intf->USER_PARAM, intf, len, status);
   } /* Endif */


} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_audio_send_data
* Returned Value : USB_STATUS
* Comments       :
*     A common function used to send data for all CDC classes
*
*END*--------------------------------------------------------------------*/

uint_32 usb_audio_send_data
   (
      /* [IN] The communication device common command structure */
      AUDIO_COMMAND_PTR       command,
      /* [IN] Pointer to data buffer used to send/recv */
      uchar_ptr               data,
      /* [IN] Length of the data associated with REQUEST */
      uint_32                 len
   )
{ /* Body */
   AUDIO_INTERFACE_STRUCT_PTR    intf;
   TR_INIT_PARAM_STRUCT          tr;
   USB_STATUS                    error = USBERR_NO_DEVICE_CLASS;

   USB_lock();

   /* Make sure device has not been detached */
   if (usb_host_class_intf_validate(command->CLASS_PTR)) {
      intf = (AUDIO_INTERFACE_STRUCT_PTR)command->CLASS_PTR->class_intf_handle;
      error = usb_hostdev_validate(intf->G.dev_handle);
   } /* Endif */

   if (error) {
      USB_unlock();
      return error;
   } /* Endif */

   intf->IN_DATA = TRUE;
   
   /* Setup the transaction, callback and callback param */
   usb_hostdev_tr_init(&tr, usb_audio_data_callback, (pointer)intf);
   tr.TX_BUFFER = data;
   tr.TX_LENGTH = len;
   
   /* Save the higher level callback and ID */
   intf->DATA_CALLBACK = command->CALLBACK_FN;
   intf->DATA_PARAM = command->CALLBACK_PARAM;

   /* Send the SETUP command */
   error = _usb_host_send_data(intf->G.host_handle, intf->iso_out_data_pipe, &tr);
   USB_unlock();

   return error;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_audio_recv_data
* Returned Value : USB_STATUS
* Comments       :
*     A common function used to recv data for all CDC classes
*
*END*--------------------------------------------------------------------*/

uint_32 usb_audio_recv_data
   (
      /* [IN] The communication device common command structure */
      AUDIO_COMMAND_PTR       command,
      /* [IN] Pointer to data buffer used to send/recv */
      uchar_ptr               data,
      /* [IN] Length of the data associated with REQUEST */
      uint_32                 len
   )
{ /* Body */
   AUDIO_INTERFACE_STRUCT_PTR    intf;
   TR_INIT_PARAM_STRUCT          tr;
   USB_STATUS                    error = USBERR_NO_DEVICE_CLASS;

   USB_lock();

   /* Make sure device has not been detached */
   if (usb_host_class_intf_validate(command->CLASS_PTR)) {
      intf = (AUDIO_INTERFACE_STRUCT_PTR)command->CLASS_PTR->class_intf_handle;
      error = usb_hostdev_validate(intf->G.dev_handle);
   } /* Endif */

   if (error) {
      USB_unlock();
      return error;
   } /* Endif */

   intf->IN_DATA = TRUE;
   
   /* Setup the transaction, callback and callback param */
   usb_hostdev_tr_init(&tr, usb_audio_data_callback, (pointer)intf);
   tr.RX_BUFFER = data;
   tr.RX_LENGTH = len;

   /* Save the higher level callback and ID */
   intf->DATA_CALLBACK = command->CALLBACK_FN;
   intf->DATA_PARAM = command->CALLBACK_PARAM;
   
   /* Send the SETUP command */
   error = _usb_host_recv_data(intf->G.host_handle, intf->iso_in_data_pipe, &tr);
   USB_unlock();

   return error;
} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_host_aud_data_callback
* Returned Value : None
* Comments       :
*     Call back function for audio data transfer
*END*--------------------------------------------------------------------*/
USB_STATUS usb_audio_get_sample_freq
   (
      pointer  dev_handle,
      /* [IN] pointer to class interface */
      pointer  if_handle,
      /* [IN] Length of data transferred */
      uint_32  *SmapFreq
   )
{ /* Body */

   USB_STATUS                    usbStatus;
   AUDIO_DESCRIPTOR_PARMS        parms;
   CLASS_UNION                   csDesc;
   uint_32                       uTmp = 0;
   //DATA_FORMAT_1_DESCRIPTOR_PTR  dat1;
   
   // Make sure the wFormatTag == PCM (0x0001)
   parms.dev_ptr = (DEV_INSTANCE_PTR)dev_handle;
   parms.intf_desc = (INTERFACE_DESCRIPTOR_PTR)if_handle;
   parms.desc_index = 1;
   parms.desc_size = 0;
   parms.desc_type = AUD_CS_INTERFACE;
   parms.desc_subtype = AUD_AS_GENERAL;
   usbStatus = usb_audio_get_descriptor(&parms, (pointer)&csDesc);
   if (usbStatus == USB_OK) { /* Body */
      if ((csDesc.asid->wFormatTag[0] != 0x01) || (csDesc.asid->wFormatTag[1] != 0x00))
         return USBERR_BAD_STATUS;      
   } else { /* Body */
      return USBERR_BAD_STATUS;
   } /* Endbody */
   
   parms.desc_index = 1;
   parms.desc_subtype = AUD_FORMAT_TYPE;
   
   // Get the sample Frequence from Audio Format type Descriptor
   usbStatus = usb_audio_get_descriptor(&parms, (pointer)&csDesc);
   if (usbStatus == USB_OK) { /* Body */
      if (csDesc.dat1->bFormatType != Aud_Fmt_Type1)
         return USBERR_BAD_STATUS;
      uTmp = ((uint_32)csDesc.dat1->iSamFreq[0][2])<<8;
      uTmp = (uTmp + (uint_32)csDesc.dat1->iSamFreq[0][1])<<8;
      uTmp = uTmp + (uint_32)csDesc.dat1->iSamFreq[0][0];
      *SmapFreq = uTmp; 
   } else { /* Body */
      return USBERR_BAD_STATUS;
   } /* Endbody */   
   
   return USB_OK;
}
  

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : usb_audio_get_descriptor
*  Returned Value : handle of the descriptor, or NULL + error
*  Comments       :
*     Due to the large number of parameters, a pointer is passed
*       to a specially-defined struct rather than a long list.
*  
*END*-----------------------------------------------------------------*/
static USB_STATUS usb_audio_get_descriptor
   (
      /* [IN] parameters in function-specific struct */
      AUDIO_DESCRIPTOR_PARMS_PTR    parms, 

      /* [OUT] handle of the descriptor, or NULL */
      pointer                 _PTR_ descriptor
   )
{ /* Body */
   CLASS_UNION    ptr1, ptr2;

   /*--------------------------------------------------------**
   ** To prevent parsing past the config buffer, ptr2 is     **
   **    set to the starting address plus its total size.    **
   **--------------------------------------------------------*/
   ptr1.pntr = parms->dev_ptr->memlist;    /* config. memory */
   ptr1.word += MEM_HEADER_LEN;    /* offset past the header */
   //ptr2.word = ptr1.word + LITTLE_2_INT (ptr1.cfig->wTotalLength);
   ptr2.word = ptr1.word + (uint_32)ptr1.cfig->wTotalLength;

   ptr1.intf = parms->intf_desc;  /* wanted desc. after this */
   do
      {
      ptr1.word += ptr1.cfig->bLength;
      if (ptr1.word >= ptr2.word)
         {
         _PTR_ descriptor = NULL;     
         return USBERR_NO_DESCRIPTOR;
         }
      if (parms->desc_type != ptr1.asid->bDescriptorType)
         continue;
      if (parms->desc_subtype != ptr1.asid->bDescriptorSubtype)
         continue;
      if (parms->desc_size != 0)
         {
         if (parms->desc_size != ptr1.asid->bLength)
            continue;
         }
      parms->desc_index--;
      } while (parms->desc_index > 0);

   _PTR_ descriptor = ptr1.pntr;

   return USB_OK;
   
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : usb_audio_get_as_ep_descriptor
*  Returned Value : handle of the descriptor, or NULL + error
*  Comments       :
*     Get the main data endpoint for an AS interface (not the sync endpoint)  
*  
*END*-----------------------------------------------------------------*/
static USB_STATUS usb_audio_get_as_ep_descriptor
   (
      /* [IN] parameters in function-specific struct */
      AUDIO_DESCRIPTOR_PARMS_PTR    parms, 

      /* [OUT] handle of the descriptor, or NULL */
      pointer                 _PTR_ descriptor
   )
{ /* Body */
   CLASS_UNION    ptr1, ptr2;
   uint_16        uTmp;

   /*--------------------------------------------------------**
   ** To prevent parsing past the config buffer, ptr2 is     **
   **    set to the starting address plus its total size.    **
   **--------------------------------------------------------*/
   ptr1.pntr = parms->dev_ptr->memlist;    /* config. memory */
   ptr1.bufr += MEM_HEADER_LEN;    /* offset past the header */
   //ptr2.word = ptr1.word + LITTLE_2_INT (ptr1.cfig->wTotalLength);
   uTmp = utoh16(ptr1.cfig->wTotalLength);
   ptr2.bufr = ptr1.bufr + uTmp;

   ptr1.intf = parms->intf_desc;  /* wanted desc. after this */
   do
   {
      ptr1.bufr += ptr1.cfig->bLength;
      if (ptr1.bufr >= ptr2.bufr)
         {
         _PTR_ descriptor = NULL;     
         return USBERR_NO_DESCRIPTOR;
         }
      if (parms->desc_type != ptr1.saep->bDescriptorType)
         continue;
      
      if (parms->desc_size != 0)
         {
         if (parms->desc_size != ptr1.saep->bLength)
            continue;
         }
      //if (ptr1.saep->bSyncAddress != 0)
      //   break;   /* the standard audio endpoint has been found */
      parms->desc_index--;
   } while (parms->desc_index > 0);

   _PTR_ descriptor = ptr1.pntr;

   return USB_OK;
   
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : usb_audio_init
* Returned Value : none
* Comments       :
*     Initialize audio class-interface, one call per USB interface.
*     The user must call for Audio-Control initialization first.
* 
*END*--------------------------------------------------------------------*/

void usb_audio_init
   (
      /* [IN] device/descriptor/pipe handles */
      PIPE_BUNDLE_STRUCT_PTR  pbs_ptr,
      
      /* [IN] audio call struct pointer */
      CLASS_CALL_STRUCT_PTR   aud_call_ptr
   )
{ /* Body */
   uint_32  iSubClass;

   USB_lock ();
   
   iSubClass = usb_audio_intf_validate (pbs_ptr, aud_call_ptr);
   /* Pointer validity-checking, get Sub-Class of the interface */
   switch (iSubClass)
      {
      case USB_SUBCLASS_UNDEFINED:
         break ;
      case USB_SUBCLASS_AUD_CONTROL:
         usb_audio_subclass_control(pbs_ptr, aud_call_ptr);
         break ;
      case USB_SUBCLASS_AUD_STREAMING:
         usb_audio_subclass_stream(pbs_ptr, aud_call_ptr);
         break ;
      case USB_SUBCLASS_AUD_MIDI_STRM :
         usb_audio_subclass_MIDI(pbs_ptr, aud_call_ptr);
         break ;
      } /* EndCase */

   USB_unlock ();

} /* Endbody */

                        
/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : usb_audio_intf_validate
* Returned Value : USB_SUBCLASS_XXXXX
* Comments       :
*     Verify pointers, return XXXXX = UNKNOWN for invalid parms.
* 
*END*--------------------------------------------------------------------*/

static uint_32 usb_audio_intf_validate
   (
      /* [IN] device/descriptor/pipe handles */
      PIPE_BUNDLE_STRUCT_PTR  pbs_ptr,
   
      /* [IN] class-call struct pointer */
      CLASS_CALL_STRUCT_PTR   aud_call_ptr
   )
{ /* Body */

   DEV_INSTANCE_PTR              dev_ptr;
   GENERAL_CLASS_PTR             class_ptr;
   INTERFACE_DESCRIPTOR_PTR      intf_desc;
   USB_STATUS                    error;

   error = usb_hostdev_validate (pbs_ptr->dev_handle);
   if (error != USB_OK)
      return USB_SUBCLASS_UNDEFINED;

   dev_ptr = (DEV_INSTANCE_PTR)pbs_ptr->dev_handle;   
   intf_desc = (INTERFACE_DESCRIPTOR_PTR)pbs_ptr->intf_handle;
   if ((intf_desc->bDescriptorType != DESCTYPE_INTERFACE) ||
         (intf_desc->bLength != sizeof(INTERFACE_DESCRIPTOR) ))
      return USB_SUBCLASS_UNDEFINED;

   switch (intf_desc->bInterfaceSubClass)
      {
      default:
         break ;
         
      case USB_SUBCLASS_AUD_STREAMING:
      case USB_SUBCLASS_AUD_MIDI_STRM:
      
         if (!usb_host_class_intf_validate ((pointer)aud_call_ptr))
            return USB_SUBCLASS_UNDEFINED;

         class_ptr = (pointer)aud_call_ptr->class_intf_handle;
         if (class_ptr->dev_handle != pbs_ptr->dev_handle)
            return USB_SUBCLASS_UNDEFINED;
         // Commented by J.Zhou: for associated intf, we my have different INTFs.
         //if (class_ptr->intf_handle != pbs_ptr->intf_handle)
         //   return USB_SUBCLASS_UNDEFINED;
      } /* EndCase */

   return intf_desc->bInterfaceSubClass;

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : usb_audio_subclass_control
* Returned Value : None
* Comments       :
*     Allocate & initialize audio class-interface struct.
* 
*END*--------------------------------------------------------------------*/

static void usb_audio_subclass_control
   (
      /* [IN] device/descriptor/pipe handles */
      PIPE_BUNDLE_STRUCT_PTR  pbs_ptr,
   
      /* [IN] audio call struct pointer */
      CLASS_CALL_STRUCT_PTR   aud_call_ptr
   )
{ /* Body */
   AUDIO_DESCRIPTOR_PARMS      aud_parm;
   AUDIO_INTERFACE_STRUCT_PTR  aud_intf;
   CLASS_UNION                 desc_ptr;
   uint_8      int_no;

   /* If memory does not allocate, can't do anything... */
   aud_intf = aud_call_ptr->class_intf_handle;
   if (USB_OK != usb_host_class_intf_init (pbs_ptr,
         &aud_intf->G, (pointer)&aud_anchor))
      return;

   /* Validate class-interface correctly set up & addressed */
   aud_call_ptr->code_key = 0;
   aud_call_ptr->code_key = usb_host_class_intf_validate 
         (aud_call_ptr);
   if (aud_call_ptr->code_key == 0)
      goto Bad_Exit;

   /* Get control interface pipe handles */
   aud_intf->control_pipe = usb_hostdev_get_pipe_handle 
         (pbs_ptr, USB_CONTROL_PIPE, 0);
   if (NULL == aud_intf->control_pipe)
      goto Bad_Exit;
   aud_intf->AC_irrpt_pipe = usb_hostdev_get_pipe_handle 
         (pbs_ptr, USB_INTERRUPT_PIPE, USB_RECV);

   /* Set up parms to get AC Interface Descriptor ptr */
   aud_parm.dev_ptr = aud_intf->G.dev_handle;
   aud_parm.intf_desc = aud_intf->G.intf_handle;
   aud_parm.desc_index = 1;
   aud_parm.desc_size = 0;
   aud_parm.desc_type = AUD_CS_INTERFACE;
   aud_parm.desc_subtype = AUD_AC_HEADER;
   if (USB_OK != usb_audio_get_descriptor 
         (&aud_parm, 
         (pointer)&aud_intf->AC_header))
      goto Bad_Exit;

//#ifdef _DBUG_
#if 0
   DEBUG_PRINT ("Associated Interfaces")
   for (int_no = 0; 
         int_no < aud_intf->AC_header.chdr->bInCollection;
         int_no++)
      DEBUG_PRINT2 (" %2.2X",aud_intf->AC_header.\
            chdr->baInterface[int_no]);
   DEBUG_PRINT ("\n");
   DEBUG_FLUSH;      
#endif

   /* Find descriptors for entities by ID number */
   desc_ptr.intf = aud_intf->G.intf_handle;
   for (; ;)
      {
      desc_ptr.word += desc_ptr.cfig->bLength;
      if (desc_ptr.intf->bDescriptorType == DESCTYPE_INTERFACE)
         break;
      if (desc_ptr.asid->bDescriptorType != AUD_CS_INTERFACE)
         continue;
      /*--------------------------------------**
      **          *** WARNING ***             **
      ** If associated interface descriptors  **
      ** are defined by later versions of the **
      ** Audio Class Spec the following "if"  **
      ** must be revised to bypass them.      **
      **--------------------------------------*/
      if (desc_ptr.asid->bDescriptorSubtype <= AUD_AC_HEADER)
         continue;
      else;
      int_no = desc_ptr.fead->bUnitID;
      if (int_no < MAX_UNIT_ID)
         aud_intf->unitID[int_no].pntr = desc_ptr.pntr;
      }

   return;  /* Good exit, interface struct initialized */

   Bad_Exit:
   USB_memzero (aud_intf,sizeof(AUDIO_INTERFACE_STRUCT_PTR));
   aud_call_ptr->class_intf_handle = NULL;
   aud_call_ptr->code_key = 0;

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : usb_audio_subclass_MIDI
* Returned Value : None
* Comments       :
*     Initialize MIDI intf in existing audio class-interface.
* 
*END*--------------------------------------------------------------------*/

static void usb_audio_subclass_MIDI
   (
      /* [IN] device/descriptor/pipe handles */
      PIPE_BUNDLE_STRUCT_PTR  pbs_ptr,
   
      /* [IN] audio call struct pointer */
      CLASS_CALL_STRUCT_PTR   aud_call_ptr
   )
{ /* Body */
   AUDIO_INTERFACE_STRUCT_PTR  aud_intf;

   /* If memory not allocated, can't do anything... */
   if (!usb_host_class_intf_validate (aud_call_ptr) )
      return;

   /* Also check that control pipe is opened OK */
   aud_intf = aud_call_ptr->class_intf_handle;
   if (NULL == aud_intf->control_pipe)
      return;

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : usb_audio_subclass_stream
* Returned Value : None
* Comments       :
*     Initialize streaming intf in existing audio class-interface.
* 
*END*--------------------------------------------------------------------*/

static void usb_audio_subclass_stream
   (
      /* [IN] device/descriptor/pipe handles */
      PIPE_BUNDLE_STRUCT_PTR  pbs_ptr,
   
      /* [IN] audio call struct pointer */
      CLASS_CALL_STRUCT_PTR   aud_call_ptr
   )
{ /* Body */
   AUDIO_INTERFACE_STRUCT_PTR  aud_intf;
   AUDIO_DESCRIPTOR_PARMS      aud_parm;
   SD_AUDIO_DATA_EP_DESCRIPTOR_PTR  asep; /* AS_DATA_EN_DESCRIPTOR */

   /* If memory not allocated, can't do anything... */
   if (!usb_host_class_intf_validate (aud_call_ptr) )
      return;

   /* Also check that control pipe is opened OK */
   aud_intf = aud_call_ptr->class_intf_handle;
   if (NULL == aud_intf->control_pipe)
      return;
      
   /* Set up parms to get AC Interface Descriptor ptr */
   aud_parm.dev_ptr = aud_intf->G.dev_handle;
   aud_parm.intf_desc = pbs_ptr->intf_handle;
   aud_parm.desc_index = 1; // search one endpoints
   aud_parm.desc_size = 0;
   aud_parm.desc_type = DESCTYPE_ENDPOINT;
   aud_parm.desc_subtype = 0; // No subtype
   if (USB_OK != usb_audio_get_as_ep_descriptor 
         (&aud_parm, 
         (pointer)&asep))
      return;
   if (asep->bEndpointAddress & 0x80) { /* Body */
      aud_intf->iso_in_data_pipe = usb_hostdev_get_pipe_handle 
         (pbs_ptr, USB_ISOCHRONOUS_PIPE, USB_RECV);
      /* Can we have another IN endpoint as sync type? */
      aud_intf->AS_in_ep.saep = asep;
      /* Get point to AS class specific interface descriptor */
      aud_parm.desc_index = 1; // search one endpoints
      aud_parm.desc_size = 0;
      aud_parm.desc_type = AUD_CS_INTERFACE;
      aud_parm.desc_subtype = AUD_AS_GENERAL;
      usb_audio_get_descriptor(&aud_parm, (pointer)&aud_intf->AS_in_general);
      /* Get point to AS class format type descriptor */
      aud_parm.desc_index = 1; // search one endpoints
      aud_parm.desc_size = 0;
      aud_parm.desc_type = AUD_CS_INTERFACE;
      aud_parm.desc_subtype = AUD_FORMAT_TYPE;
      usb_audio_get_descriptor(&aud_parm, (pointer)&aud_intf->AS_in_format);   
   } else { /* Body */      
      aud_intf->iso_out_data_pipe = usb_hostdev_get_pipe_handle 
         (pbs_ptr, USB_ISOCHRONOUS_PIPE, USB_SEND);
      aud_intf->iso_out_sync_pipe = usb_hostdev_get_pipe_handle 
         (pbs_ptr, USB_ISOCHRONOUS_PIPE, USB_RECV);
      aud_intf->AS_out_ep.saep = asep;
      /* Get point to AS class specific interface descriptor */
      aud_parm.desc_index = 1; // search one endpoints
      aud_parm.desc_size = 0;
      aud_parm.desc_type = AUD_CS_INTERFACE;
      aud_parm.desc_subtype = AUD_AS_GENERAL;
      usb_audio_get_descriptor(&aud_parm, (pointer)&aud_intf->AS_out_general);
      /* Get point to AS class format type descriptor */
      aud_parm.desc_index = 1; // search one endpoints
      aud_parm.desc_size = 0;
      aud_parm.desc_type = AUD_CS_INTERFACE;
      aud_parm.desc_subtype = AUD_FORMAT_TYPE;
      usb_audio_get_descriptor(&aud_parm, (pointer)&aud_intf->AS_out_format); 
   } /* Endbody */
} /* Endbody */                  

  
/* EOF */
