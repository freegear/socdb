/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains  the USB class driver mapping table
***
**************************************************************************
**END*********************************************************/


#include "hostapi.h"
#include "host_ch9.h"
#include "host_common.h"

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
#endif

#ifdef USBCLASS_INC_MASS
#include "usb_mass_bo.h"
#endif

#ifdef USBCLASS_INC_PRINTER
#include "usb_printer.h"
#endif

#ifdef USBCLASS_INC_HID
#include "usb_hid.h"
#endif

#ifdef USBCLASS_INC_CDC
#include "usb_cdc.h"
#endif

#ifdef USBCLASS_INC_AUDIO
#include "usb_audio.h"
#endif

CLASS_MAP class_interface_map[] =
{
#ifdef USBCLASS_INC_MASS
   {
      usb_class_mass_init,
      sizeof(USB_MASS_CLASS_INTF_STRUCT),
      USB_CLASS_MASS_STORAGE,
      USB_SUBCLASS_MASS_UFI,
      USB_PROTOCOL_MASS_BULK,
      0xFF, 0x00, 0x00
   },
#endif
#ifdef USBCLASS_INC_PRINTER
   {
      usb_printer_init,
      sizeof(PRINTER_INTERFACE_STRUCT),
      USB_CLASS_PRINTER,
      USB_SUBCLASS_PRINTER,
      USB_PROTOCOL_PRT_BIDIR,
      0xFF, 0xFF, 0xFF
   },
#endif
#ifdef USBCLASS_INC_HID
   {
      usb_class_hid_init,
      sizeof(USB_HID_CLASS_INTF_STRUCT),
      USB_CLASS_HID,
      0,
      0,
      0xFF, 0x00, 0x00
   },
#endif
#ifdef USBCLASS_INC_CDC
   {
      usb_ecm_init,
      sizeof(CDC_INTERFACE_STRUCT),
      USB_CLASS_COMMUNICATION,
      USB_SUBCLASS_COM_ETHERNET,
      0,
      0xFF, 0xFF, 0xFF
   },
   {
      usb_acm_init,
      sizeof(CDC_INTERFACE_STRUCT),
      USB_CLASS_COMMUNICATION,
      USB_SUBCLASS_COM_ABSTRACT,
      USB_PROTOCOL_COM_V25,
      0xFF, 0xFF, 0xFF
   },
   {
      usb_acm_init,
      sizeof(CDC_INTERFACE_STRUCT),
      USB_CLASS_COMMUNICATION,
      USB_SUBCLASS_COM_ABSTRACT,
      0xFF,                      /* Vendor Specific Protocol */
      0xFF, 0xFF, 0xFF
   },
   {
      usb_data_init,
      sizeof(CDC_INTERFACE_STRUCT),
      USB_CLASS_DATA,
      0,
      0,
      0xFF, 0x00, 0x00
   },
#endif
#ifdef USBCLASS_INC_AUDIO
   {
      usb_audio_init,
      sizeof(AUDIO_INTERFACE_STRUCT),
      USB_CLASS_AUDIO,
      USB_SUBCLASS_AUD_CONTROL,
      0,
      0xFF, 0x00, 0x00
   },
   {
      usb_audio_init,
      sizeof(AUDIO_INTERFACE_STRUCT),
      USB_CLASS_AUDIO,
      USB_SUBCLASS_AUD_STREAMING,
      0,
      0xFF, 0x00, 0x00
   },
#endif
   {
      NULL,
      0,
      0, 0, 0,
      0, 0, 0
   }
};

/* EOF */
