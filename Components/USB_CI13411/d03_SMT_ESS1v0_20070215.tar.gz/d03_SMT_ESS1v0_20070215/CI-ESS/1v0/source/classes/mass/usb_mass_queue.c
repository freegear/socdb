/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   Implements the queue system for the mass storage class.
***
**************************************************************************
**END*********************************************************/

#include "usb_mass_bo.h"


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_class_mass_q_init
* Returned Value : None
* Comments       :
*     This function initializes a mass storage class queue.
*
*END*--------------------------------------------------------------------*/

void usb_class_mass_q_init
   (
      /* [IN] interface structure pointer */
      USB_MASS_CLASS_INTF_STRUCT_PTR intf_ptr
   )
{ /* Body */
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("usb_class_mass_q_init");
   #endif

   intf_ptr->QUEUE.FIRST      = 0;
   intf_ptr->QUEUE.LAST       = 0;
   intf_ptr->QUEUE.AVAILABLE  = TRUE;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("usb_class_mass_q_init, SUCCESSFUL");
   #endif
   
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_class_mass_q_insert
* Returned Value : Position at which insertion took place in the queue.
* Comments       :
*     This function is called by class driver for inserting a command in the
*     queue.
*END*--------------------------------------------------------------------*/

int_32 usb_class_mass_q_insert
   (
      /* [IN] interface structure pointer */
      USB_MASS_CLASS_INTF_STRUCT_PTR intf_ptr,

      /* [IN] command object to be inserted in the queue*/
      COMMAND_OBJECT_PTR pCmd
   )
{ /* Body */
   MASS_QUEUE_STRUCT_PTR   Q =  &intf_ptr->QUEUE;
   int_32                  tmp = -1;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("usb_class_mass_q_insert");
   #endif

   /*
   ** Insert into queue, update LAST, check if full and return queue position.
   ** If queue is full -1 will be returned
   */
   USB_lock();
   if (Q->AVAILABLE) {
      Q->ELEMENTS[Q->LAST] = pCmd;
      tmp = Q->LAST;
      Q->LAST = (Q->LAST + 1) & (QUEUE_SIZE - 1);
      if ((Q->LAST + 1) & (QUEUE_SIZE - 1) == Q->FIRST) {
         Q->AVAILABLE = FALSE;
      } /* Endif */
   } /* Endif */
   USB_unlock();

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("usb_class_mass_q_insert, SUCCESSFUL");
   #endif

   return tmp;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_class_mass_deleteq
* Returned Value : None
* Comments       :
*     This routine deletes the pending request in the queue
*END*--------------------------------------------------------------------*/

void usb_class_mass_deleteq
   (
      /* [IN] interface structure pointer */
      USB_MASS_CLASS_INTF_STRUCT_PTR intf_ptr
   )
{ /* Body */
   MASS_QUEUE_STRUCT_PTR   Q =  &intf_ptr->QUEUE;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("usb_class_mass_deleteq");
   #endif

   /* Remove current command and increment FIRST modulo the Q size */
   USB_lock();
   Q->ELEMENTS[Q->FIRST] = NULL;
   Q->FIRST = (Q->FIRST + 1) & (QUEUE_SIZE - 1);
   Q->AVAILABLE = TRUE;
   USB_unlock();
   
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("usb_class_mass_deleteq, SUCCESSFUL");
   #endif
   
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_class_mass_get_pending_request
* Returned Value : None
* Comments       :
*     This routine fetches the pointer to the first (pending) request in
*     the queue, or NULL if there is no pending requests.
*END*--------------------------------------------------------------------*/

void usb_class_mass_get_pending_request
   (
      /* [IN] interface structure pointer */
      USB_MASS_CLASS_INTF_STRUCT_PTR   intf_ptr,

      /* [OUT] pointer to pointer which will hold the pending request */
      COMMAND_OBJECT_PTR _PTR_         cmd_ptr_ptr
   )
{ /* Body */
   MASS_QUEUE_STRUCT_PTR   Q = &intf_ptr->QUEUE;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("usb_class_mass_get_pending_request");
   #endif

   USB_lock();
   if (Q->FIRST == Q->LAST) {
      *cmd_ptr_ptr = NULL;
   } else {
      *cmd_ptr_ptr = (COMMAND_OBJECT_PTR)Q->ELEMENTS[Q->FIRST];
   } /* Endif */
   USB_unlock();

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("usb_class_mass_get_pending_request, SUCCESSFUL");
   #endif
   
   return;
} /* Endbody */

/* EOF */
