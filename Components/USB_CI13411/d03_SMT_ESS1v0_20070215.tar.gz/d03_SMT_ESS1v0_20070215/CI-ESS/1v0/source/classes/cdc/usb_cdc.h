#ifndef __communication_class_h__
#define __communication_class_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains definitions for the USB Communications class.
***
**************************************************************************
**END*********************************************************/



#include <hostapi.h>

#define CLASS_INTERFACE_REQUEST							0x21
#define GET_REQUEST										0x80
#define SET_REQUEST										0x00

#define COMM_FEATURE_ABSTRACT_STATE						0x01
#define COMM_FEATURE_COUNTRY_SETTING					0x02

#define bOverRun										0x40
#define bParity											0x20
#define bFraming										0x10
#define bRingSignal										0x08
#define	bBreak											0x04
#define bTxCarrier										0x02
#define bRxCarrier										0x01

/************************************
**
** Class specific request codes
*/
#define SEND_ENCAPSULATED_COMMAND                        0x00
#define GET_ENCAPSULATED_COMMAND                         0x01
#define SET_COMM_FEATURE                                 0x02
#define GET_COMM_FEATURE                                 0x03
#define CLEAR_COMM_FEATURE                               0x04
#define SET_AUX_LINE_STATE                               0x10
#define SET_HOOK_STATE                                   0x11
#define PULSE_SETUP                                      0x12
#define SEND_PULSE                                       0x13
#define SET_PULSE_TIME                                   0x14
#define RING_AUX_JACK                                    0x15
#define SET_LINE_CODING                                  0x20
#define GET_LINE_CODING                                  0x21
#define SET_CONTROL_LINE_STATE                           0x22
#define SEND_BREAK                                       0x23
#define SET_RINGER_PARMS                                 0x30
#define GET_RINGER_PARMS                                 0x31
#define SET_OPERATION_PARMS                              0x32
#define GET_OPERATION_PARMS                              0x33
#define SET_LINE_PARMS                                   0x34
#define GET_LINE_PARMS                                   0x35
#define DIAL_DIGITS                                      0x36
#define SET_UNIT_PARAMETER                               0x37
#define GET_UNIT_PARAMETER                               0x38
#define CLEAR_UNIT_PARAMETER                             0x39
#define GET_PROFILE                                      0x3A
#define SET_ETHERNET_MULTICAST_FILTERS                   0x40
#define SET_ETHERNET_POWER_MANAGEMENT_PATTERN_FILTER     0x41
#define GET_ETHERNET_POWER_MANAGEMENT_PATTERN_FILTER     0x42
#define SET_ETHERNET_PACKET_FILTER                       0x43
#define GET_ETHERNET_STATISTIC                           0x44
#define SET_ATM_DATA_FORMAT                              0x50
#define GET_ATM_DEVICE_STATISTICS                        0x51
#define SET_ATM_DEFAULT_VC                               0x52
#define GET_ATM_VC_STATISTICS                            0x53



/* Type values for the bDescriptorType field in functional descriptors */
#define CS_INTERFACE                      0x24
#define CS_ENDPOINT                       0x25

#define CS_DESCSUBTYPE_ECM                0x0F


#define CDC_MAX_NOTIFICATION_SIZE           32

#define CDC_REQ_NOTIF                    (REQ_TYPE_IN | REQ_TYPE_CLASS | REQ_TYPE_INTERFACE)
#define CDC_REQ_OUT                      (REQ_TYPE_OUT | REQ_TYPE_CLASS | REQ_TYPE_INTERFACE)
#define CDC_REQ_IN                       (REQ_TYPE_IN | REQ_TYPE_CLASS | REQ_TYPE_INTERFACE)

#define CDC_STATE_DISCONNECTED            0x00
#define CDC_STATE_CONNECTED               0x01

#define CDC_STATE_ON_HOOK                 0x0000
#define CDC_STATE_OFF_HOOK                0x0001
#define CDC_STATE_SNOOPING                0x0002

#define CDC_OPMODE_SIMPLE                 0x00
#define CDC_OPMODE_STANDALONE             0x01
#define CDC_OPMODE_HOSTCENTRIC            0x02

/************************************
**
** Class Specific Notification Codes
*/
#define CDC_NOTIF_NETWORK_CONNECTION		0x00
#define CDC_NOTIF_RESPONSE_AVAILABLE		0x01
#define CDC_NOTIF_AUX_JACK_HOOK_STATE		0x08
#define CDC_NOTIF_RING_DETECT				0x09
#define CDC_NOTIF_SERIAL_STATE				0x20
#define CDC_NOTIF_CALL_STATE_CHANGE			0x28
#define CDC_NOTIF_LINE_STATE_CHANGE			0x29
#define CDC_NOTIF_CONNECTION_SPEED_CHANGE	0x2a


typedef void (_CODE_PTR_  CDC_CALLBACK_NOTIF_FN)
   (
      uint_32     callback_param,  /* [IN] Callback parameter */
      pointer     ifhandle,        /* [IN] Notification event interface */
      uchar_ptr   data_ptr,        /* [IN] Notification header and data */
      uint_32     data_len,        /* [IN] Length of the notification data */
      uint_32     status           /* [IN] Error code */
   );

typedef void (_CODE_PTR_  CDC_CALLBACK_USER_FN)
   (
      uint_32,                     /* [IN] Callback parameter */
      pointer,                     /* [IN] Pointer to class interface */
      uint_32,                     /* [IN] Length of data transferred */
      uint_32                      /* [IN] Error code */
   );

typedef struct cdc_interface
{
   GENERAL_CLASS                    G;

   /* The number of the Class interface */
   uint_32                          IFNUM;

   /* The pipes used by most CDC classes */
   struct {
      _usb_pipe_handle              CTRL;
      _usb_pipe_handle              NOTIF;
      _usb_pipe_handle              BOUT;
      _usb_pipe_handle              BIN;
   } PIPE;

   /* Notification event callback */
   CDC_CALLBACK_NOTIF_FN            NOTIF_CALLBACK;
   uint_32                          NOTIF_PARAM;

   /* Only 1 command can be issued at one time */
   boolean                          IN_SETUP;
   pointer                          FREE;

   /* Setup Req callback and parameter */
   CDC_CALLBACK_USER_FN             USER_CALLBACK;
   uint_32                          USER_PARAM;

   /* Data In callback and parameter */
   CDC_CALLBACK_USER_FN				DATA_IN_CALLBACK;
   uint_32							DATA_IN_PARAM;

   /* Data Out callback and parameter */
   CDC_CALLBACK_USER_FN				DATA_OUT_CALLBACK;
   uint_32							DATA_OUT_PARAM;

   boolean							IN_DATA;

   /* A buffer to receive notifications */
   uchar                            NOTIF_BUFFER[CDC_MAX_NOTIFICATION_SIZE];

} CDC_INTERFACE_STRUCT, _PTR_ CDC_INTERFACE_STRUCT_PTR;


typedef struct {
   CLASS_CALL_STRUCT_PTR   CLASS_PTR;
   CDC_CALLBACK_USER_FN    CALLBACK_FN;
   uint_32                 CALLBACK_PARAM;
} CDC_COMMAND, _PTR_ CDC_COMMAND_PTR;

typedef struct {
	uint_8			bmRequestType;
	uint_8			bNotification;
	uint_8			wValue[2];
	uint_8			wIndex[2];
	uint_8			wLength[2];
} CDC_NOTIF, _PTR_ CDC_NOTIF_PTR;

/* Standard Interface decriptors */
typedef struct intf_desc
{
   uchar    bLength;
   uchar    bDescriptorType;
   uchar    bInterfaceNumber;
   uchar    bAlternateSetting;
   uchar    bNumEndpoints;
   uchar    bInterfaceClass;
   uchar    bInterfaceSubClass;
   uchar  	bInterfaceProtocol;
   uchar	iInterface;
} USB_INTF_DESC, _PTR_ USB_INTF_DESC_PTR;

/****************************************************
**
** Class Specific Functional Descriptors
*/

/* Comm Class Specific Call Header Format Functional Descriptor */
typedef struct call_header_format_desc
{
	uchar	bLength;				/* 0x05 */
	uchar	bDescriptorType;		/* 0x24 = CS_INTERFACE */
	uchar	bDescriptorSubType;		/* 0x00 */
	uchar	bcdCDC[2];
} USB_COMM_HEADER_FORMAT_DESC, _PTR_ USB_COMM_HEADER_FORMAT_DESC_PTR;

/* Comm Class Specific Management Functional Descriptor */
typedef struct call_manage_desc
{
	uchar	bLength;				/* 0x05 */
	uchar	bDescriptorType;		/* 0x24 = CS_INTERFACE */
	uchar	bDescriptorSubType;		/* 0x01 */
	uchar	bmCapability;			/* Bitmap for device capabilities */
	uchar	bDataInterface;			/* Interface number for data class intf */
} USB_COMM_CALL_MANAGEMENT_DESC, _PTR_ USB_COMM_CALL_MANAGEMENT_DESC_PTR;

/* Comm Class Specific Abstract Control Management Functional Descriptor */
typedef struct acm_desc
{
	uchar	bLength;				/* 0x04 */
	uchar	bDescriptorType;		/* 0x24 = CS_INTERFACE */
	uchar	bDescriptorSubType;		/* 0x02 */
	uchar	bmCapabilities;			/* Bitmap for device capabilities */
} USB_COMM_ABSTRACT_CTRL_MANAGEMENT_DESC, _PTR_ USB_COMM_ABSTRACT_CTRL_MANAGEMENT_DESC_PTR;

/* Comm Class Specific union Functional Descriptor */
typedef struct union_desc
{
	uchar	bLength;				/* 0x04 + p; p = Slave intf number */
	uchar	bDescriptorType;		/* 0x24 = CS_INTERFACE */
	uchar	bDescriptorSubType;		/* 0x06	*/
	uchar	bMasterInterface;		/* Interface number for master interface */
	uchar	bSlaveInterface[1];		/* Slave interfaces */
} USB_COMM_UNION_DESC, _PTR_ USB_COMM_UNION_DESC_PTR;

/* Comm Class Specific Country Selection Functional Descriptor */
typedef struct country_selection_desc
{
	uchar	bLength;				/* 0x04 + 2*p; p = country code number */
	uchar	bDescriptorType;		/* 0x24 = CS_INTERFACE */
	uchar	bDescriptorSubType;		/* 0x07 */
	uchar	iCountryCodeRelDate;	/* index of string for release date */
	uchar	bCountryCode[2][1];		/* Country code in hex format */
} USB_COMM_COUNTRY_SELECTION_DESC, _PTR_ USB_COMM_COUNTRY_SELECTION_PTR;

/* Comm Class Specific Ethernet Networking Functional Descriptor */
typedef struct ethernet_networking_desc
{
	uchar	bLength;				/* 0x0d */
	uchar	bDescriptorType;		/* 0x24 = CS_INTERFACE */
	uchar	bDescriptorSubType;		/* 0x0f */
	uchar	iMACAddress;			/* index of string for MAC address */
	uchar	bmEthernetStatistics[4];/* Ethernet statistics functions for the device */
	uchar	wMaxSegmentSize[2];		/* Maximum segment size */
	uchar 	wNumberMCFilters[2];	/* MultiCast filter number */
	uchar 	bNumberPowerFilters;	/* Power filter number */
} USB_COMM_ETHERNET_NETWORKING_DESC, _PTR_ USB_COMM_ETHERNET_NETWORKING_PTR;

/* Comm Class Specific ATM Networking Functional Descriptor */
typedef struct atm_networking_desc
{
	uchar	bLength;				/* 0x0b */
	uchar	bDescriptorType;		/* 0x24 = CS_INTERFACE */
	uchar	bDescriptorSubType;		/* 0x10 */
	uchar	iEndSystemIdentifier;	/* index of End System Identifier */
	uchar	bmDataCapabilities;		/* bitmap for ATM support data type */
	uchar	bmATMDeviceStatistics;	/* bitmap for device statistics functions */
	uchar 	wType2MaxSegmentSize[2];/* Type 2 device maximum segment size */
	uchar 	wType3MaxSegmentSize[2];/* Power filter number */
	uchar	wMaxVC;					/* Max number of simultaneous virtual circuits */
} USB_COMM_ATM_NETWORKING_DESC, _PTR_ USB_COMM_ATM_NETWORKING_PTR;


/****************************************************
**
** ECM
*/

/* Ethernet Statistic Feature Selector Codes */
#define ECM_STAT_XMIT_OK                  0x01
#define ECM_STAT_RCV_OK                   0x02
#define ECM_STAT_XMIT_ERROR               0x03
#define ECM_STAT_RCV_ERROR                0x04
#define ECM_STAT_RCV_NO_BUFFER            0x05
#define ECM_STAT_DIRECTED_BYTES_XMIT      0x06
#define ECM_STAT_DIRECTED_FRAMES_XMIT     0x07
#define ECM_STAT_MULTICAST_BYTES_XMIT     0x08
#define ECM_STAT_MULTICAST_FRAMES_XMIT    0x09
#define ECM_STAT_BROADCAST_BYTES_XMIT     0x0A
#define ECM_STAT_BROADCAST_FRAMES_XMIT    0x0B
#define ECM_STAT_DIRECTED_BYTED_RCV       0x0C
#define ECM_STAT_DIRECTED_FRAMES_RCV      0x0D
#define ECM_STAT_MULTICAST_BYTES_RCV      0x0E
#define ECM_STAT_MULTICAST_FRAMES_RCV     0x0F
#define ECM_STAT_BROADCAST_BYTES_RCV      0x10
#define ECM_STAT_BROADCAST_FRAMES_RCV     0x11
#define ECM_STAT_RCV_CRC_ERROR            0x12
#define ECM_STAT_TRANSMIT_QUEUE_LENGTH    0x13
#define ECM_STAT_RCV_ERROR_ALIGNMENT      0x14
#define ECM_STAT_XMIT_ONE_COLLISION       0x15
#define ECM_STAT_XMIT_MORE_COLLISIONS     0x16
#define ECM_STAT_XMIT_DEFERED             0x17
#define ECM_STAT_XMIT_MAC_COLLISIONS      0x18
#define ECM_STAT_RCV_OVERRUN              0x19
#define ECM_STAT_XMIT_UNDERRUN            0x1A
#define ECM_STAT_XMIT_HEARTBEAT_FAILURE   0x1B
#define ECM_STAT_XMIT_TIMES_CRS_LOST      0x1C
#define ECM_STAT_XMIT_LATE_COLLISIONS     0x1D


#define ECM_BYTES_IN_MAC_ADDR              6
#define ECM_BYTES_IN_MAC_ADDR_STRING_DESC 26

typedef struct {
   uchar             BFUNCTIONALLENGTH[1];
   uchar             BDESCRIPTORTYPE[1];
   uchar             BDESCRIPTORSUBTYPE[1];
   uchar             IMACADDRESS[1];
   uchar             BMETHERNETSTATISTICS[4];
   uchar             WMAXSEGMENTSIZE[2];
   uchar             WNUMBERMCFILTERS[2];
   uchar             BNUMBERPOWERFILTERS[1];
   uchar             PADDING[3];
} ECM_FUNCTIONAL_DESC, _PTR_ ECM_FUNCTIONAL_DESC_PTR;


#define usb_ecm_send_encap_command  usb_cdc_send_encap_command
#define usb_ecm_get_encap_command   usb_cdc_get_encap_command

typedef struct {
   CDC_INTERFACE_STRUCT       CDC;
   ECM_FUNCTIONAL_DESC_PTR    FUNC_DESC_PTR;
   uchar                      MAC_ADDR_STRING_DESC[ECM_BYTES_IN_MAC_ADDR_STRING_DESC];
   uchar_ptr                  USER_BUF;
} ECM_INTERFACE_STRUCT, _PTR_ ECM_INTERFACE_STRUCT_PTR;

/********************************************
**
** ACM
*/

#define ACM_REQUEST_SEND_ENCAPSULATED_COMMAND	0x00
#define ACM_REQUEST_GET_ENCAPSULATED_COMMAND	0x01
#define ACM_REQUEST_SET_COMM_FEATURE			0x02
#define ACM_REQUEST_GET_COMM_FEATURE			0x03
#define ACM_REQUEST_CLEAR_COMM_FEATURE			0x04
#define ACM_REQUEST_SET_LINE_CODING				0x20
#define ACM_REQUEST_GET_LINE_CODING				0x21
#define ACM_REQUEST_SET_CONTROL_LINE_STATE		0x22
#define ACM_REQUEST_SEND_BREAK					0x23

typedef struct {
   uchar          DTE_RATE[4];
   uchar          CHAR_FORMAT[1];
   uchar          PARITY_TYPE[1];
   uchar          DATA_BITS[1];
} LINE_CODING_STRUCT, _PTR_ LINE_CODING_STRUCT_PTR;

#define usb_acm_send_encap_command  usb_cdc_send_encap_command
#define usb_acm_get_encap_command   usb_cdc_get_encap_command
#define usb_acm_set_comm_feature    usb_cdc_set_comm_feature
#define usb_acm_get_comm_feautre    usb_cdc_get_comm_feature
#define usb_acm_clear_comm_feature  usb_cdc_clear_comm_feature

/********************************************
**
** Others
*/

#define usb_tcm_set_comm_feature    usb_cdc_set_comm_feature
#define usb_tcm_get_comm_feature    usb_cdc_get_comm_feature
#define usb_tcm_clear_comm_feature  usb_cdc_clear_comm_feature

#define usb_atmcm_send_ecap_command     usb_cdc_send_encap_command
#define usb_atmcm_get_ecap_command      usb_cdc_get_encap_command

/********************************************
**
** Functions
*/

#ifdef __cplusplus
extern "C" {
#endif

extern void       usb_cdc_init(PIPE_BUNDLE_STRUCT_PTR, CLASS_CALL_STRUCT_PTR);
extern uint_32    usb_cdc_setup_common(CDC_COMMAND_PTR, uint_8, uint_8, uint_16, uint_16, uchar_ptr);
extern USB_STATUS usb_cdc_set_notif_callback(CLASS_CALL_STRUCT_PTR, CDC_CALLBACK_NOTIF_FN);

extern void       usb_acm_init(PIPE_BUNDLE_STRUCT_PTR, CLASS_CALL_STRUCT_PTR);
extern USB_STATUS usb_acm_set_line_coding(CDC_COMMAND_PTR, uchar_ptr);
extern USB_STATUS usb_acm_get_line_coding(CDC_COMMAND_PTR, uchar_ptr);
extern USB_STATUS usb_acm_set_control_line_state(CDC_COMMAND_PTR, uint_16);
extern USB_STATUS usb_acm_send_break(CDC_COMMAND_PTR);

extern void       usb_data_init(PIPE_BUNDLE_STRUCT_PTR, CLASS_CALL_STRUCT_PTR);
extern USB_STATUS usb_cdc_recv_notif(CLASS_CALL_STRUCT_PTR   cdc_call_ptr);

extern void       usb_ecm_init(PIPE_BUNDLE_STRUCT_PTR, CLASS_CALL_STRUCT_PTR);
extern USB_STATUS usb_ecm_get_func_desc(CLASS_CALL_STRUCT_PTR, ECM_FUNCTIONAL_DESC_PTR);
extern USB_STATUS usb_ecm_get_mac_addr(CDC_COMMAND_PTR, uchar_ptr);
extern uint_32    usb_cdc_recv_data(CDC_COMMAND_PTR, uchar_ptr, uint_32);
extern uint_32    usb_cdc_send_data(CDC_COMMAND_PTR, uchar_ptr, uint_32);

#ifdef __cplusplus
}
#endif

#endif  /* __communication_class_h__  */

/* EOF */

