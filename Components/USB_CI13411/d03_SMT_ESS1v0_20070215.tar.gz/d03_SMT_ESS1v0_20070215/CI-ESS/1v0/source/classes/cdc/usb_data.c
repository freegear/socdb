/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains the CDC Data Interface Class
***
**************************************************************************
**END*********************************************************/

#include "usb_cdc.h"


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_data_init
* Returned Value : none
* Comments       :
*     Initialize data pipe struct for Data Interface class.
*
*END*--------------------------------------------------------------------*/

void usb_data_init
   (
      /* [IN] device/descriptor/pipe handles */
      PIPE_BUNDLE_STRUCT_PTR  pbs_ptr,
      /* [IN] Data class call struct pointer */
      CLASS_CALL_STRUCT_PTR   data_call_ptr
   )
{ /* Body */
   CDC_INTERFACE_STRUCT_PTR     intf;

   USB_lock();

   /* Initialize common CDC struct */
   usb_cdc_init(pbs_ptr, data_call_ptr);  
   intf = data_call_ptr->class_intf_handle;
   intf->PIPE.BOUT = usb_hostdev_get_pipe_handle(pbs_ptr, USB_BULK_PIPE, USB_SEND);
   intf->PIPE.BIN = usb_hostdev_get_pipe_handle(pbs_ptr, USB_BULK_PIPE, USB_RECV);

   if (!intf->PIPE.BOUT || !intf->PIPE.BIN) {
      /* Invalidate class instance */
      intf->G.key_code = 0;
      /* status = USBERR_CLASS_DRIVER_INSTALL; */
   } /* Endif */

   USB_unlock();

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_data_in_callback
* Returned Value : none
* Comments       :
*    An CDC specific callback function used to cleanup the CDC interface struct
*    and call back to applications drivers after a data transfer completes.
*
*END*--------------------------------------------------------------------*/

static void usb_cdc_data_in_callback
   (
      /* [IN] Unused */
      pointer     dummy,
      /* [IN] Pointer to the class interface instance */
      pointer     param,
      /* [IN] Data buffer */
      uchar_ptr   buffer,
      /* [IN] Length of buffer */
      uint_32     len,
      /* [IN] Error code (if any) */
      USB_STATUS  status
   )
{ /* Body */
   CDC_INTERFACE_STRUCT_PTR      intf;

   /*
   ** There is no need for USB_lock in the callback function, and there is also no
   ** need to check if the device is still attached (otherwise this callback
   ** would never have been called!
   */

   /* Get class interface handle, reset IN_SETUP and call callback */
   intf = (CDC_INTERFACE_STRUCT_PTR)param;

   intf->IN_DATA = FALSE;

   if (intf->FREE) {
      USB_memfree(intf->FREE);
   } /* Endif */

   if (intf->DATA_IN_CALLBACK) {
      intf->DATA_IN_CALLBACK(intf->DATA_IN_PARAM, intf, len, status);
   } /* Endif */

} /* Endbody */

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_data_out_callback
* Returned Value : none
* Comments       :
*    An CDC specific callback function used to cleanup the CDC interface struct
*    and call back to applications drivers after a data transfer completes.
*
*END*--------------------------------------------------------------------*/

static void usb_cdc_data_out_callback
   (
      /* [IN] Unused */
      pointer     dummy,
      /* [IN] Pointer to the class interface instance */
      pointer     param,
      /* [IN] Data buffer */
      uchar_ptr   buffer,
      /* [IN] Length of buffer */
      uint_32     len,
      /* [IN] Error code (if any) */
      USB_STATUS  status
   )
{ /* Body */
   CDC_INTERFACE_STRUCT_PTR      intf;

   /*
   ** There is no need for USB_lock in the callback function, and there is also no
   ** need to check if the device is still attached (otherwise this callback
   ** would never have been called!
   */

   /* Get class interface handle, reset IN_SETUP and call callback */
   intf = (CDC_INTERFACE_STRUCT_PTR)param;

   intf->IN_DATA = FALSE;

   if (intf->FREE) {
      USB_memfree(intf->FREE);
   } /* Endif */

   if (intf->DATA_OUT_CALLBACK) {
      intf->DATA_OUT_CALLBACK(intf->DATA_OUT_PARAM, intf, len, status);
   } /* Endif */

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_send_data
* Returned Value : USB_STATUS
* Comments       :
*     A common function used to send data for all CDC classes
*
*END*--------------------------------------------------------------------*/

uint_32 usb_cdc_send_data
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR         command,
      /* [IN] Pointer to data buffer used to send/recv */
      uchar_ptr               data,
      /* [IN] Length of the data associated with REQUEST */
      uint_32                 len
   )
{ /* Body */
   CDC_INTERFACE_STRUCT_PTR      intf;
   TR_INIT_PARAM_STRUCT          tr;
   USB_STATUS                    error = USBERR_NO_DEVICE_CLASS;

   USB_lock();

   /* Make sure device has not been detached */
   if (usb_host_class_intf_validate(command->CLASS_PTR)) {
      intf = (CDC_INTERFACE_STRUCT_PTR)command->CLASS_PTR->class_intf_handle;
      error = usb_hostdev_validate(intf->G.dev_handle);
   } /* Endif */

   if (error) {
      USB_unlock();
      return error;
   } /* Endif */

   intf->IN_DATA = TRUE;
   
   /* Setup the transaction, callback and callback param */
   usb_hostdev_tr_init(&tr, usb_cdc_data_out_callback, (pointer)intf);
   tr.TX_BUFFER = data;
   tr.TX_LENGTH = len;
   
   /* Save the higher level callback and ID */
   intf->DATA_OUT_CALLBACK = command->CALLBACK_FN;
   intf->DATA_OUT_PARAM = command->CALLBACK_PARAM;

   /* Send the SETUP command */
   error = _usb_host_send_data(intf->G.host_handle, intf->PIPE.BOUT, &tr);
   USB_unlock();

   return error;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_cdc_recv_data
* Returned Value : USB_STATUS
* Comments       :
*     A common function used to recv data for all CDC classes
*
*END*--------------------------------------------------------------------*/

uint_32 usb_cdc_recv_data
   (
      /* [IN] The communication device common command structure */
      CDC_COMMAND_PTR         command,
      /* [IN] Pointer to data buffer used to send/recv */
      uchar_ptr               data,
      /* [IN] Length of the data associated with REQUEST */
      uint_32                 len
   )
{ /* Body */
   CDC_INTERFACE_STRUCT_PTR      intf;
   TR_INIT_PARAM_STRUCT          tr;
   USB_STATUS                    error = USBERR_NO_DEVICE_CLASS;

   USB_lock();

   /* Make sure device has not been detached */
   if (usb_host_class_intf_validate(command->CLASS_PTR)) {
      intf = (CDC_INTERFACE_STRUCT_PTR)command->CLASS_PTR->class_intf_handle;
      error = usb_hostdev_validate(intf->G.dev_handle);
   } /* Endif */

   if (error) {
      USB_unlock();
      return error;
   } /* Endif */

   intf->IN_DATA = TRUE;
   
   /* Setup the transaction, callback and callback param */
   usb_hostdev_tr_init(&tr, usb_cdc_data_in_callback, (pointer)intf);
   tr.RX_BUFFER = data;
   tr.RX_LENGTH = len;

   /* Save the higher level callback and ID */
   intf->DATA_IN_CALLBACK = command->CALLBACK_FN;
   intf->DATA_IN_PARAM = command->CALLBACK_PARAM;
   
   /* Send the SETUP command */
   error = _usb_host_recv_data(intf->G.host_handle, intf->PIPE.BIN, &tr);
   USB_unlock();

   return error;
} /* Endbody */


/* EOF */

