#ifndef __audio_class_h__
#define __audio_class_h__
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains definitions for  USB audio class.
*** Reference Specifications:
***   "USB Device Class Definition for Audio Devices" version 1.0
***     March 18, 1998, from USB Implementers Forum.
***   "USB Device Class Definition for Audio Data Formats" version 1.0
***     March 18, 1998, from USB Implementers Forum.
***   "USB Device Class Definition for MIDI Devices" version 1.0
***     Nov 1, 1999, from USB Implementers Forum.
***   "USB Device Class Definition for Terminal Typess" version 1.0
***     March 18, 1998, from USB Implementers Forum.
***                                                               
**************************************************************************
**END*********************************************************/

//#include "usb_dev_list.h"
//#include "usb_common.h"

#include <usb.h>
#include <hostapi.h>
#include <host_ch9.h>
#include <host_dev_list.h>
#include <host_common.h>
#include <usbprv.h>

#define  MAX_UNIT_ID    48    /* Max. units on Control interface */

#define  AUD_DIRECTION_IN        0x80
#define  AUD_DIRECTION_OUT       0x00
#define  AUD_DIRECTION_NONE		 0xff

/* Class-specific descriptor types & sub-types */
#define  AUD_CS_UNDEFINED     0x20
#define  AUD_CS_DEVICE        0x21
#define  AUD_CS_CONFIGURATION 0x22
#define  AUD_CS_STRING        0x23
#define  AUD_CS_INTERFACE     0x24
   /* Audio Control Interfaces */
   #define  AUD_AC_UNDEFINED        0
   #define  AUD_AC_HEADER           1
   #define  AUD_AC_INPUT_TERMINAL   2
   #define  AUD_AC_OUTPUT_TERMINAL  3
   #define  AUD_AC_MIXER_UNIT       4
   #define  AUD_AC_SELECTOR_UNIT    5
   #define  AUD_AC_FEATURE_UNIT     6
   #define  AUD_AC_PROCESSING_UNIT  7
   #define  AUD_AC_EXTENSION_UNIT   8
   /* Audio Streaming Interfaces */
   #define  AUD_AS_UNDEFINED        0
   #define  AUD_AS_GENERAL          1
   #define  AUD_FORMAT_TYPE         2
   #define  AUD_FORMAT_SPECIFIC     3
   /* Audio MIDI-Streaming Interfaces */
   #define  AUD_MS_UNDEFINED        0
   #define  AUD_MS_HEADER           1
   #define  AUD_MS_MIDI_IN_JACK     2
   #define  AUD_MS_MIDI_OUT_JACK    3
   #define  AUD_MS_ELEMENT          4
   /* Audio Processors */
   #define  AUD_PROCESS_UNDEFINED      0
   #define  AUD_PROCESS_UP_DOWNMIX     1
   #define  AUD_PROCESS_DOLBY_PROLOGIC 2
   #define  AUD_PROCESS_3D_STEREO_EXT  3
   #define  AUD_PROCESS_REVERBERATION  4
   #define  AUD_PROCESS_CHORUS         5
   #define  AUD_PROCESS_DYN_RANGE_COMP 6
#define  AUD_CS_ENDPOINT      0x25
   #define  AUD_EP_UNDEFINED        0
   #define  AUD_EP_GENERAL          1   
/* Audio Class-Specific Request Codes */
#define  AUD_REQ_UNDEFINED 0x00
#define  AUD_SET_CUR       0x01
#define  AUD_GET_CUR       0x81
#define  AUD_SET_MIN       0x02
#define  AUD_GET_MIN       0x82
#define  AUD_SET_MAX       0x03
#define  AUD_GET_MAX       0x83
#define  AUD_SET_RES       0x04
#define  AUD_GET_RES       0x84
#define  AUD_SET_MEM       0x05
#define  AUD_GET_MEM       0x85
#define  AUD_GET_STAT      0xFF

/* Terminal Control Selectors */
#define  AUD_TE_CONTROL_UNDEFINED      0
#define  AUD_TE_CONTROL_COPY_PROTECT   1

/* Feature-Unit Control Selectors */
#define  AUD_FU_UNDEFINED     0x00
#define  AUD_FU_MUTE          0x01
#define  AUD_FU_VOLUME        0x02
#define  AUD_FU_BASS          0x03
#define  AUD_FU_MID           0x04
#define  AUD_FU_TREBLE        0x05
#define  AUD_FU_EQUALIZER     0x06
#define  AUD_FU_AUTOGAIN      0x07
#define  AUD_FU_DELAY         0x08
#define  AUD_FU_BASS_BOOST    0x09
#define  AUD_FU_LOUDNESS      0x0A

/* Up/Down Mix Processing Control Selectors */
#define  AUD_UD_UNDEFINED     0
#define  AUD_UD_ENABLE        1
#define  AUD_UD_MODE_SELECT   2

/* Dolby Processing Control Selectors */
#define  AUD_DP_UNDEFINED     0
#define  AUD_DP_ENABLE        1
#define  AUD_DP_MODE_SELECT   2

/* 3D Processing Control Selectors */
#define  AUD_3D_UNDEFINED     0
#define  AUD_3D_ENABLE        1
#define  AUD_3D_SPACIOUSNESS  2

/* Reverb Processing Control Selectors */
#define  AUD_RV_UNDEFINED     0
#define  AUD_RV_ENABLE        1
#define  AUD_RV_LEVEL         2
#define  AUD_RV_TIME          3
#define  AUD_RV_FEEDBACK      4

/* Chorus Processing Control Selectors */
#define  AUD_CH_UNDEFINED     0
#define  AUD_CH_ENABLE        1
#define  AUD_CH_LEVEL         2
#define  AUD_CH_RATE          3
#define  AUD_CH_DEPTH         4

/* Dynamic Range Processing Control Selectors */
#define  AUD_DR_UNDEFINED     0
#define  AUD_DR_ENABLE        1
#define  AUD_DR_COMP_RATE     2
#define  AUD_DR_MAX_AMPLITUDE 3
#define  AUD_DR_THRESHOLD     4
#define  AUD_DR_ATTACK_TIME   5
#define  AUD_DR_RELEASE_TIME  6

/* Extension Unit Control Selectors */
#define  AUD_XU_UNDEFINED     0
#define  AUD_XU_ENABLE        1

/* Endpoint Control Selectors */
#define  AUD_EP_UNDEFINED     0
#define  AUD_EP_SAMPLE_FREQ   1
#define  AUD_EP_PITCH         2
   /* MIDI Control Selector */
   #define  AUD_EP_ASSOCIATION_CONTROL    1

/* MPEG Control Selectors */
#define  AUD_MP_UNDEFINED     0
#define  AUD_MP_DUAL_CHANNEL  1
#define  AUD_MP_SECOND_STEREO 2
#define  AUD_MP_MULTILINGUAL  3
#define  AUD_MP_DYN_RANGE     4
#define  AUD_MP_SCALING       5
#define  AUD_MP_HILO_SCALING  6

/* AC-3 Control Selectors */
#define  AUD_AC_UNDEFINED     0
#define  AUD_AC_MODE          1
#define  AUD_AC_DYN_RANGE     2
#define  AUD_AC_SCALING       3
#define  AUD_AC_HILO_SCALING  4


/* Audio Data Format Types */
enum Audio_Format_Types
{
   Aud_Fmt_Undefined   = 0,
   Aud_Fmt_Type1,
   Aud_Fmt_Type2,
   Aud_Fmt_Type3
};
/* Audio Data Format I Types */
enum Audio_Format_1
{
   Fmt_1_Undefined   = 0x0000,
   Fmt_1_PCM,
   Fmt_1_PCM8,
   Fmt_1_IEEE_FLOAT,
   Fmt_1_ALAW,
   Fmt_1_MULAW
};
typedef enum Audio_Format_1   Audio_Format_1;

/* Audio Data Format II Types */
enum Audio_Format_2
{
   Fmt_2_Undefined   = 0x1000,
   Fmt_2_MPEG,
   Fmt_2_AC3
};
typedef enum Audio_Format_2   Audio_Format_2;

/* Audio Data Format III Types */
enum Audio_Format_3
{
   Fmt_3_Undefined   = 0x2000,
   Fmt_3_AC3,
   Fmt_3_MPEG1_Layer1,
   Fmt_3_MPEG1_Layer2_3,
   Fmt_3_MPEG2_EXT,
   Fmt_3_MPEG2_Layer1_LS,
   Fmt_3_MPEG2_Layer2_3_LS
};
typedef enum Audio_Format_3   Audio_Format_3;

/* MIDI Jack Types */
enum MIDI_Jack_Types
{
   MIDI_Undefined       = 0,
   MIDI_Embedded,
   MIDI_External
};

/* Terminal Types */
enum USB_Terminal_Types
{
   USB_Undefined        = 0x0100,
   USB_Streaming,
   USB_Vendor_Specific  = 0x01FF
};
typedef enum USB_Terminal_Types  USB_Terminal_Types;

enum Input_Terminal_Types
{
   Input_Undefined      = 0x0200,
   Input_Microphone,
   Input_Desktop_Microphone,
   Input_Personal_Microphone,
   Input_OmniDirection_Microphone,
   Input_Microphone_Array,
   Input_Processing_Array
};
typedef enum Input_Terminal_Types   Input_Terminal_Types;

enum Output_Terminal_Types
{
   Output_Undefined     = 0x0300,
   Output_Speaker,
   Output_Headphones,
   Output_Head_Mounted,
   Output_Desktop_Speaker,
   Output_Room_Speaker,
   Output_Communication_Speaker,
   Output_Low_Freq_Effects_Speaker
};
typedef enum Output_Terminal_Types  Output_Terminal_Types;

enum BiDir_Terminal_Types
{
   BiDir_Undefined      = 0x0400,
   BiDir_Handset,
   BiDir_Headset,
   BiDir_Speakerphone_noEchoSuppress,
   BiDir_Speakerphone_EchoSuppress,
   BiDir_Speakerphone_EchoCancelling
};
typedef enum BiDir_Terminal_Types   BiDir_Terminal_Types;

enum Telephony_Terminal_Types
{
   Tele_Undefined       = 0x0500,
   Tele_Telephone,
   Tele_Down_Line_Phone
};
typedef enum Telephony_Terminal_Types  Telephony_Terminal_Types;

enum External_Terminal_Types
{
   Ext_Undefined        = 0x0600,
   Ext_Analog_Connector,
   Ext_Digital_Audio_IF,
   Ext_Line_Connector,
   Ext_Legacy_Audio,
   Ext_SPDIF,
   Ext_1394_DA,
   Ext_1395_DV_Soundtrack
};
typedef enum External_Terminal_Types   External_Terminal_Types;

enum Embedded_Function_Terminal_Types
{
   Embed_Undefined      = 0x0700,
   Embed_Level_Cal_Noise_Source,
   Embed_Equalization_Noise,
   Embed_CD_Player,
   Embed_DAT,
   Embed_DCC,
   Embed_MiniDisk,
   Embed_Analog_Tape,
   Embed_Phonograph,
   Embed_VCR_Audio,
   Embed_Video_Disc_Audio,
   Embed_DVD_Audio,
   Embed_TV_Tuner_Audio,
   Embed_Satellite_Receiver_Audio,
   Embed_Cable_Tuner_Audio,
   Embed_DSS_Audio,
   Embed_Radio_Receiver,
   Embed_Radio_Transmitter,
   Embed_Multi_Track_Recorder,
   Embed_Synthesizer
};

#define USB_AUDIO_DUMMY    4;    /* dummy request */
/*----------------------------------------------------------**
** Following descriptors & formats from Audio Devices spec. **
** NOTE: Standard descriptors are not redefined here.  For  **
**    example, the Standard AC Interface Descriptor (p. 36) **
**    has exactly the fields of an INTERFACE_DESCRIPTOR in  **
**    usb_header.h file already included by line 33 above.  **
**----------------------------------------------------------*/
   
/* Status Word Format p. 31 */
typedef struct usb_audio_status_word_format
{
   uint_8   bStatusType;   /* Pending & type of irrpt */
   #define  AUD_ASW_IRRPT_PEND      0x80
   #define  AUD_ASW_MEMORY_CHANGED  0x40
   #define  AUD_ASW_ORIGIN_MASK     0x0F
      #define  AUD_ASW_AUDCTRL_INTF    0x00
      #define  AUD_ASW_AUSTREAM_INTF   0x01
      #define  AUD_ASW_AUSTREAM_EP     0x02
   uint_8   bOriginator;   /* ID of terminal/unit/intf/EP */   
} STATUS_WORD_FORMAT, _PTR_ STATUS_WORD_FORMAT_PTR;

/* Dolby cluster p. 34 */
typedef struct usb_audio_dolby_cluster
{
   uint_8   bNrChannels;      /* No. of channels in cluster */
   uint_8   wChannelConfig[2];/* Spatial locations of channels */
   uint_8   iChannelNames;    /* Index of 1st 'non-defined' string */
} DOLBY_CLUSTER_DESCRIPTOR, _PTR_ DOLBY_CLUSTER_DESCRIPTOR_PTR;

/* Audio AC Interface Header Descriptor p. 37 */
typedef struct usb_audio_control_intf_header
{
   uint_8   bLength;          /* 8 + n (n = bInCollection) */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x01 = HEADER */
   uint_8   bcdADC[2];        /* Class Spec. Release in BCD */
   uint_8   wTotalLength[2];  /* Size of this + following descs. */
   uint_8   bInCollection;    /* No. of streaming intfs */
   uint_8   baInterface[1];   /* Array of n interface numbers */
} CONTROL_HEADER_DESCRIPTOR, _PTR_ CONTROL_HEADER_DESCRIPTOR_PTR;

/* Audio Input Terminal Descriptor p. 39 */
typedef struct usb_audio_input_terminal
{
   uint_8   bLength;          /* 12 */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x02 = INPUT TERMINAL */
   uint_8   bTerminalID;      /* Number used to address terminal */
   uint_8   wTerminalType[2]; /* See types above */
   uint_8   bAssocTerminal;   /* ID of associated output terminal */
   uint_8   bNrChannels;      /* No. of output-cluster channels */
   uint_8   wChannelConfig[2];/* Spatial location of channels */
   uint_8   iChannelNames;    /* Index of 1st channel's string */
   uint_8   iTerminal;        /* Index of terminal's string */
} INPUT_TERMINAL_DESCRIPTOR, _PTR_ INPUT_TERMINAL_DESCRIPTOR_PTR;

/* Audio Output Terminal Descriptor p. 40 */
typedef struct usb_audio_output_terminal
{
   uint_8   bLength;          /* 9 */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x03 = OUTPUT TERMINAL */
   uint_8   bTerminalID;      /* Number used to address terminal */
   uint_8   wTerminalType[2]; /* See types above */
   uint_8   bAssocTerminal;   /* ID of associated input terminal */
   uint_8   iSourceID;        /* ID of connected Unit/Terminal */
   uint_8   iTerminal;        /* Index of terminal's string */
} OUTPUT_TERMINAL_DESCRIPTOR, _PTR_ OUTPUT_TERMINAL_DESCRIPTOR_PTR;

/* Audio Mixer Unit Descriptor p. 41 */
typedef struct usb_audio_mixer_string
{
   uint_8   iMixer;           /* Index of mixer string descriptor */
} AUDIO_MIXER_STRING, _PTR_ AUDIO_MIXER_STRING_PTR;

typedef struct usb_audio_mixer_channels
{
   uint_8   bNrChannels;      /* No. of channels in output cluster */
   uint_8   wChannelConfig[2];/* Spatial location of channels */
   uint_8   iChannelNames;    /* No. of 1st channel string */
   uint_8   bmControls[1];    /* Bitmap array of programmability */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_MIXER_STRING struct immediately follows   */
   /*    this variable-length mixer-channels struct.     */
   /*    The struct must be addressed by a pointer set   */
   /*    to the byte after the mixer-channels struct.    */
   /*    Dynamic address calculation is ALWAYS required. */
   /*    Data to calculate N, the byte size of the bitmap*/
   /*    is NOT all available here, only M = bNrChannels.*/
   /*    To get N, baSourceID must be used to find the   */
   /*    ID of the input unit or terminal, and trace up  */
   /*    to the input terminal's number of pins/channels.*/
   /*    Only then with total inputs N can NxM be rounded*/
   /*    up to the next multiple of 8 bits -- the last   */
   /*    byte is padded with unused bits.                */
   #define  MIXER_STRING_PTR(y,n)   ((AUDIO_MIXER_STRING_PTR)\
                  &y->bmControls[(n*y->bNrChannels+7)/8])

} AUDIO_MIXER_CHANNELS, _PTR_ AUDIO_MIXER_CHANNELS_PTR;

typedef struct usb_audio_mixer_unit
{
   uint_8   bLength;          /* 10 + p + N, p = No. input pins */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x04 = MIXER UNIT */
   uint_8   bUnitID;          /* Number used to address Unit */
   uint_8   bNrInPins;        /* No. of input pins = p */
   uint_8   baSourceID[1];    /* Array of p terminals */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_MIXER_CHANNELS struct immediately follows */
   /*    the variable-length source-ID array (size = p). */
   /*    The struct must be addressed by a pointer set   */
   /*    to the address of mixer-unit struct + 5 + p.    */
   /*    Dynamic address calculation is ALWAYS required. */
   #define  MIXER_CHANNELS_PTR(x)   ((AUDIO_MIXER_CHANNELS_PTR)\
                  &x->baSourceID[x->bNrInPins])

} MIXER_UNIT_DESCRIPTOR, _PTR_ MIXER_UNIT_DESCRIPTOR_PTR;

/* Audio Selector Unit Descriptor p. 43 */
typedef struct usb_audio_selector_string
{
   uint_8   iSelector;     /* Index of selector string descriptor */
} AUDIO_SELECTOR_STRING, _PTR_ AUDIO_SELECTOR_STRING_PTR;

typedef struct usb_audio_selector_unit
{
   uint_8   bLength;          /* 6 + p, p = No. input pins */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x05 = SELECTOR UNIT */
   uint_8   bUnitID;          /* Number used to address Unit */
   uint_8   bNrInPins;        /* No. of input pins = p */
   uint_8   baSourceID[1];    /* Array of p terminals */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_SELECTOR_STRING immediately follows       */
   /*    the variable-length source-ID array (size = p). */
   /*    The struct must be addressed by a pointer set   */
   /*    to the address of selector-unit struct + 5 + p. */
   /*    Dynamic address calculation is ALWAYS required. */
   #define  SELECTOR_STRING_PTR(x)   ((AUDIO_SELECTOR_STRING_PTR)\
                  &x->baSourceID[x->bNrInPins])

} SELECTOR_UNIT_DESCRIPTOR, _PTR_ SELECTOR_UNIT_DESCRIPTOR_PTR;

/* Audio Feature Unit Descriptor p. 43 */
typedef struct usb_audio_feature_string
{
   uint_8   iFeature;     /* Index of feature string descriptor */
} AUDIO_FEATURE_STRING, _PTR_ AUDIO_FEATURE_STRING_PTR;

typedef struct usb_audio_feature_unit
{
   uint_8   bLength;          /* 7 + (ch + 1)*n  */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x06 = FEATURE UNIT */
   uint_8   bUnitID;          /* Number used to address Unit */
   uint_8   iSourceID;        /* ID of connected Unit/Terminal */
   uint_8   bControlSize;     /* Bytes n in array subscript 2 */
   uint_8   bmaControls[1][1]; /* Array of ch n-byte bitmaps */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_FEATURE_STRING immediately follows        */
   /*    the variable-length controls array.             */
   /*    The struct must be addressed by a pointer set   */
   /*    to the address of feature-unit + (ch+1)*n.      */
   /*    Dynamic address calculation is ALWAYS required. */
   /*    Data to calculate ch, the number of bitmaps,    */
   /*    is NOT all available here, only bControlSize.   */
   /*    To get ch, baSourceID must be used to find the   */
   /*    ID of the input unit or terminal, and trace up  */
   /*    to the input terminal's number of pins/channels.*/
   #define  FEATURE_STRING_PTR(x,n)   ((AUDIO_FEATURE_STRING_PTR)\
                  &x->bmaControls[(n+1)*x->bControlSize])

} FEATURE_UNIT_DESCRIPTOR, _PTR_ FEATURE_UNIT_DESCRIPTOR_PTR;

/* Audio Processing Unit Descriptor p. 45 */
typedef struct usb_audio_processor_string
{
   uint_8   iProcessing;      /* Index of processing string descr. */
   uint_8   bLength;          /* Length of process-specific descr. */
                              /* Various descr. structs continue.  */

   /*       ******   DANGER!!!   ******   */
   /*    PROCESSOR_SPECIFIC struct immediately follows  */
   /*    iProcessing, i.e. bLength is its 1st byte.     */
   /*    Dynamic address calculation is ALWAYS required.*/
   /*    A union of pointers such as UNIT_UNION defined */
   /*    later in this file can be set to the address   */
   /*    of variable bLength, and parsed by its subtype.*/ 
   
} AUDIO_PROCESSOR_STRING, _PTR_ AUDIO_PROCESSOR_STRING_PTR;

typedef struct usb_audio_process_channels
{
   uint_8   bNrChannels;      /* No. of channels in cluster */
   uint_8   wChannelConfig[2];/* Spatial location of channels */
   uint_8   iChannelNames;    /* No. of 1st channel string */
   uint_8   bControlSize;     /* No. of bytes for control = n */
   uint_8   bmControls[1];    /* Bitmap array of programmability */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_PROCESSOR_STRING struct immediately follows   */
   /*    this variable-length processing-unit struct.    */
   /*    The struct must be addressed by a pointer set   */
   /*    to the byte after the processing-unit struct.   */
   /*    Dynamic address calculation is ALWAYS required. */
   #define  PROCESSOR_STRING_PTR(y)   ((AUDIO_PROCESSOR_STRING_PTR)\
                  &y->bmControls[y->bControlSize])

} AUDIO_PROCESSOR_CHANNELS, _PTR_ AUDIO_PROCESSOR_CHANNELS_PTR;

typedef struct usb_audio_processing_unit
{
   uint_8   bLength;          /* 13 + p + n + x */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x07 = PROCESSOR UNIT */
   uint_8   bUnitID;          /* Number used to address Unit */
   uint_8   wProcessType[2];  /* Type of processing */
   uint_8   bNrInPins;        /* No. of input pins = p */
   uint_8   baSourceID[1];    /* Array of p terminals */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_PROCESSOR_CHANNELS struct immediately follows */
   /*    the variable-length source-ID array (size = p). */
   /*    The struct must be addressed by a pointer set   */
   /*    to the address of processing-unit struct + 5 + p*/
   /*    Dynamic address calculation is ALWAYS required. */
   #define  PROCESSOR_CHANNELS_PTR(x)   ((AUDIO_PROCESSOR_CHANNELS_PTR)\
                  &x->baSourceID[x->bNrInPins])

} PROCESSOR_UNIT_DESCRIPTOR, _PTR_ PROCESSOR_UNIT_DESCRIPTOR_PTR;


/* Audio Extension Unit Descriptor p. 56 */
typedef struct usb_audio_extension_string
{
   uint_8   iExtension;      /* Index of processing string descr. */
} AUDIO_EXTENSION_STRING, _PTR_ AUDIO_EXTENSION_STRING_PTR;

typedef struct usb_audio_extension_channels
{
   uint_8   bNrChannels;      /* No. of channels in cluster */
   uint_8   wChannelConfig[2];/* Spatial location of channels */
   uint_8   iChannelNames;    /* No. of 1st channel string */
   uint_8   bControlSize;     /* No. of bytes for control = n */
   uint_8   bmControls[1];    /* Bitmap array of programmability */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_EXTENSION_STRING struct immediately follows   */
   /*    this variable-length extensioning-unit struct.    */
   /*    The struct must be addressed by a pointer set   */
   /*    to the byte after the extensioning-unit struct.   */
   /*    Dynamic address calculation is ALWAYS required. */
   #define  EXTENSION_STRING_PTR(y)   ((AUDIO_EXTENSION_STRING_PTR)\
                  &y->bmControls[y->bControlSize])

} AUDIO_EXTENSION_CHANNELS, _PTR_ AUDIO_EXTENSION_CHANNELS_PTR;

typedef struct usb_audio_extension_unit
{
   uint_8   bLength;          /* 13 + p + n */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x08 = EXTENSION UNIT */
   uint_8   bUnitID;          /* Number used to address Unit */
   uint_8   wExtensionCode[2];/* Type of extension */
   uint_8   bNrInPins;        /* No. of input pins = p */
   uint_8   baSourceID[1];    /* Array of p terminals */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_EXTENSION_CHANNELS struct immediately follows */
   /*    the variable-length source-ID array (size = p). */
   /*    The struct must be addressed by a pointer set   */
   /*    to the address of processing-unit struct + 5 + p*/
   /*    Dynamic address calculation is ALWAYS required. */
   #define  EXTENSION_CHANNELS_PTR(x)   ((AUDIO_EXTENSION_CHANNELS_PTR)\
                  &x->baSourceID[x->bNrInPins])

} EXTENSION_UNIT_DESCRIPTOR, _PTR_ EXTENSION_UNIT_DESCRIPTOR_PTR;

/* Associated Device Descriptor p. 57        **
**    Not defined in this version of spec.   */

/*---------------------------------------------------**
** Process-Specific-Unit Descriptors pp. 47 - 57.    **
** One of these variants is appended to the common   **
**    part of a Process-Unit Descriptor, pp. 45 -46. **
**---------------------------------------------------*/

/* Up/Down-mix Processing Unit Descriptor p. 47 */
typedef struct usb_audio_updown_modes
{
   uint_8   iProcessing;      /* Index of processing string descr. */
   uint_8   bNrModes;         /* No. of modes = m */
   uint_8   waModes[1][2];    /* m * 2-byte active channel map */
} AUDIO_UPDOWN_MODES, _PTR_ AUDIO_UPDOWN_MODES_PTR;

typedef struct usb_audio_updown_mix_unit
{
   uint_8   bLength;          /* 15 +  n + 2*m */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x07 = PROCESSING UNIT */
   uint_8   bUnitID;          /* Number used to address Unit */
   uint_8   wProcessType[2];  /* 0x01 = UP/DOWN MIX */
   uint_8   bNrInPins;        /* No. of input pins = 1 */
   uint_8   bsourceID;        /* Input terminal no. */
   uint_8   bNrChannels;      /* No. of output channels */
   uint_8   wChannelConfig[2];/* Spatial location of channels */
   uint_8   iChannelNames;    /* No. of 1st channel string */
   uint_8   bControlSize;     /* No. of bytes for control = n */
   uint_8   bmControls[1];    /* Bitmap array of programmability */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_UPDOWN_MODES struct immediately follows   */
   /*    the variable-length controls array (size = n).  */
   /*    The struct must be addressed by a pointer set   */
   /*    to the address of processing-unit struct+13+n.  */
   /*    Dynamic address calculation is ALWAYS required. */
   #define  UPDOWN_MODES_PTR(x)   ((AUDIO_UPDOWN_MODES_PTR)\
                  &x->bmControls[x->bControlSize])

} UPDOWN_MIX_UNIT_DESCRIPTOR, _PTR_ UPDOWN_MIX_UNIT_DESCRIPTOR_PTR;

/* Dolby Prologic Processing Unit Descriptor p. 49 */
typedef struct usb_audio_dolby_modes
{
   uint_8   iProcessing;      /* Index of processing string descr. */
   uint_8   bNrModes;         /* No. of modes = m */
   uint_8   waModes[1][2];    /* m * 2-byte active channel maps */
} AUDIO_DOLBY_MODES, _PTR_ AUDIO_DOLBY_MODES_PTR;

typedef struct usb_audio_dolby_unit
{
   uint_8   bLength;          /* 15 +  n + 2*m */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x07 = PROCESSING UNIT */
   uint_8   bUnitID;          /* Number used to address Unit */
   uint_8   wProcessType[2];  /* 0x02 = DOLBY */
   uint_8   bNrInPins;        /* No. of input pins = 1 */
   uint_8   bsourceID;        /* Input terminal no. */
   uint_8   bNrChannels;      /* No. of output channels */
   uint_8   wChannelConfig[2];/* Spatial location of channels */
   uint_8   iChannelNames;    /* No. of 1st channel string */
   uint_8   bControlSize;     /* No. of bytes for control = n */
   uint_8   bmControls[1];    /* Bitmap array of programmability */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_UPDOWN_MODES struct immediately follows   */
   /*    the variable-length controls array (size = n).  */
   /*    The struct must be addressed by a pointer set   */
   /*    to the address of processing-unit struct+13+n.  */
   /*    Dynamic address calculation is ALWAYS required. */
   #define  DOLBY_MODES_PTR(x)   ((AUDIO_DOLBY_MODES_PTR)\
                  &x->bmControls[x->bControlSize])

} DOLBY_UNIT_DESCRIPTOR, _PTR_ DOLBY_UNIT_DESCRIPTOR_PTR;

/* Use the following 2 structs with ProcessType set to
**    match the respective Unit types:
**    3D-Stereo Extender         p. 50
**    Reverberation              p. 52
**    Chorus                     p. 53
**    Dynamic Range Compressor   p. 54   */
typedef struct usb_audio_unit_string
{
   uint_8   iProcessing;      /* Index of processing string descr. */
} AUDIO_UNIT_STRING, _PTR_ AUDIO_UNIT_STRING_PTR;

typedef struct usb_audio_3Dext_unit
{
   uint_8   bLength;          /* 14 +  n */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x07 = PROCESSING UNIT */
   uint_8   bUnitID;          /* Number used to address Unit */
   uint_8   wProcessType[2];  /* 3D Extender/Reverb/etc. */
   uint_8   bNrInPins;        /* No. of input pins = 1 */
   uint_8   bsourceID;        /* Input terminal no. */
   uint_8   bNrChannels;      /* No. of output channels */
   uint_8   wChannelConfig[2];/* Spatial location of channels */
   uint_8   iChannelNames;    /* No. of 1st channel string */
   uint_8   bControlSize;     /* No. of bytes for control = n */
   uint_8   bmControls[1];    /* Bitmap array of programmability */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_UPDOWN_MODES struct immediately follows   */
   /*    the variable-length controls array (size = n).  */
   /*    The struct must be addressed by a pointer set   */
   /*    to the address of processing-unit struct+13+n.  */
   /*    Dynamic address calculation is ALWAYS required. */
   #define  UNIT_STRING_PTR(x)   ((AUDIO_UNIT_STRING_PTR)\
                  &x->bmControls[x->bControlSize])

} AUDIO_UNIT_DESCRIPTOR, _PTR_ AUDIO_UNIT_DESCRIPTOR_PTR;

/* Class-specific AS Interface Descriptor p. 60 */
typedef struct usb_audio_streaming_interface
{
   uint_8   bLength;          /* 7 */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x01 = AS GENERAL */
   uint_8   bTerminalLink;    /* Terminal endpoint conn. */
   uint_8   bDelay;           /* Path delay, frames */
   uint_8   wFormatTag[2];    /* Audio data format required */
} AS_INTERFACE_DESCRIPTOR, _PTR_ AS_INTERFACE_DESCRIPTOR_PTR;

/* AS Isoch. Audio Data Endpoint Descriptor */
typedef struct usb_audio_AS_data_endpoint
{
   uint_8   bLength;          /* 7 */
   uint_8   bDescriptorType;  /* 0x25 = CS_ENDPOINT */
   uint_8   bDescriptorSubtype;  /* 0x01 = EP_GENERAL */
   uint_8   bmAttributes;     /* D6:0 = 1, control supported */
   #define  AUD_AS_MAX_PACKETS   0x80  /* Max. packets only */
   #define  AUD_AS_PITCH         0x02  /* Pitch control */
   #define  AUD_AS_SAMP_FREQ     0x01  /* Sampling Frequency */
   uint_8   bLockDelayUnits;     /* Units for lock delay field */
   #define  AUD_LDU_MSEC   1     /* Milliseconds */
   #define  AUD_LDU_PCMSAM 2     /* PCM samples */  
   uint_8   wLockDelay[2];       /* Clock recovery lock time */
} AS_DATA_EP_DESCRIPTOR, _PTR_ AS_DATA_EP_DESCRIPTOR_PTR;

typedef struct usb_audio_sd_iso_endpoint
{
   uint_8   bLength;          /* Descriptor size in bytes = 9 */
   uint_8   bDescriptorType;  /* ENDPOINT descriptor type = 5 */
   uint_8   bEndpointAddress; /* Endpoint # 0 - 15 | IN/OUT */
   uint_8   bmAttributes;     /* Transfer type */
   uint_8   wMaxPacketSize[2];   /* Bits 10:0 = max. packet size */
   uint_8   iInterval;        /* Polling interval in (micro) frames */
   uint_8	bRefresh;		  /* Reset to 0 (*/
   uint_8	bSyncAddress;	  /* Sync endpoint address */
} SD_AUDIO_DATA_EP_DESCRIPTOR, _PTR_ SD_AUDIO_DATA_EP_DESCRIPTOR_PTR;


/*-----------------------------------------------------**
** Following descriptors from Audio Data Formats spec. **
**-----------------------------------------------------*/
typedef struct usb_audio_data_format_1 /* p. 10 */
{
   uint_8   bLength;          /* 8 + ns*3 bytes */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x02 = FORMAT TYPE */
   uint_8   bFormatType;      /* 0x01 type 1 */
   uint_8   bNrChannels;      /* No of channels = nr */
   uint_8   bSubframeSize;    /* 1, 2, 3, or 4-byte subs */
   uint_8   bBitResolution;   /* No. used bits in subs */
   uint_8   bSamFreqType;     /* Sampling freqs. = ns */
   uint_8   iSamFreq[1][3];   /* 24-bit freq. in Hz */
} DATA_FORMAT_1_DESCRIPTOR, _PTR_ DATA_FORMAT_1_DESCRIPTOR_PTR;

typedef struct usb_audio_data_format_2 /* p. 14 */
{
   uint_8   bLength;          /* 9 + ns*3 bytes */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x02 = FORMAT TYPE */
   uint_8   bFormatType;      /* 0x02 type 2 */
   uint_8   wMaxBitRate[2];   /* Max. kbits/sec on interface */
   uint_8   wSamplesPerFrame[2]; /* No. PCM samples / frame */
   uint_8   bBitResolution;   /* No. used bits in subs */
   uint_8   bSamFreqType;     /* Sampling freqs. = ns */
   uint_8   iSamFreq[1][3];   /* 24-bit freq. in Hz */
} DATA_FORMAT_2_DESCRIPTOR, _PTR_ DATA_FORMAT_2_DESCRIPTOR_PTR;

/* For format-3 use the format-1 descriptor with:
**    bFormatType          0x03
**    bNrChannels          2
**    bSubFrameSize        2     */


typedef struct usb_audio_mpeg_format   /* p. 16 */
{
   uint_8   bLength;          /* 9 */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x03 = FORMAT SPECIFIC */
   uint_8   wFormatTag;       /* MPEG const. for audio format */
   uint_8   mbMPEGCapabilities[2];
   #define  MPEG_CAP_LAYER1         0x0001   /* Layer 1 */
   #define  MPEG_CAP_LAYER2         0x0002   /* Layer 2 */
   #define  MPEG_CAP_LAYER3         0x0004   /* Layer 3 */
   #define  MPEG_CAP_1_ONLY         0x0008   /* MPEG 1 only */
   #define  MPEG_CAP_DUAL           0x0010   /* MPEG 1 dual-chan */
   #define  MPEG_CAP_2_SECND        0x0020   /* MPEG 2 2nd stereo */
   #define  MPEG_CAP_2_7_1          0x0040   /* MPEG 2 7.1 chan */
   #define  MPEG_CAP_ADAPT          0x0080   /* Adaptive multi-chan */
   #define  MPEG_CAP_MULTI_FS       0x0100   /* MPEG 2 multi at Fs */
   #define  MPEG_CAP_MULTI_FS2      0x0300   /* MPEG 2 multi Fs, Fs/2 */
   uint_8   bmMPEGFeature;    /* Decoder-supported features */
   #define  MPG_FEAT_NO_SCALE    0x10  /* supported, not scalable */
   #define  MPG_FEAT_COMMON      0x20  /* common boost & cut */
   #define  MPG_FEAT_SEPARATE    0x30  /* separate boost/cut */
} MPEG_FORMAT_DESCRIPTOR, _PTR_ MPEG_FORMAT_DESCRIPTOR_PTR;


/*-----------------------------------------------**
** Following Descriptors from MIDI Devices spec. **
**-----------------------------------------------*/
typedef struct usb_audio_MIDI_event_packet /* p. 16 */
{
   uint_8   nCableCode;    /* Hi nibble = cable, Lo nibble = code */
   #define  MS_PAKT_CABLE_MASK   0xF0
   #define  MS_PAKT_CODE_MASK    0x0F
   #define  MD_PAKT_CABLE_SHIFT  4     /* Right-shift Cable No. */
   uint_8   MIDI_0, MIDI_1, MIDI_2;    /* Parsed event packet */
} MIDI_EVENT_PACKET, _PTR_ MIDI_EVENT_PACKET_PTR;

typedef struct usb_audio_MS_interface /* p. 21 */
{
   uint_8   bLength;          /* 7 */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x01 = MS HEADER */
   uint_8   bcdMSC[2];        /* MIDI release in BCD = 01.00 */
   uint_8   wTotalLength[2];  /* Bytes = this desc. + jacks/elements */
} MS_INTERFACE_DESCRIPTOR, _PTR_ MS_INTERFACE_DESCRIPTOR_PTR;

typedef struct usb_audio_jack_string
{
   uint_8   iJack;      /* Index of jack's string descr. */
} AUDIO_JACK_STRING, _PTR_ AUDIO_JACK_STRING_PTR;

typedef struct usb_audio_MIDI_in_jack /* p. 22 */
{
   uint_8   bLength;          /* 6 */
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x02 = IN JACK */
   uint_8   bJackType;        /* 1, 2 == Embedded, External */
   uint_8   bJackID;          /* Jack ID number */
   uint_8   iJack;            /* Index of string descriptor */
} MIDI_IN_JACK_DESCRIPTOR, _PTR_ MIDI_IN_JACK_DESCRIPTOR_PTR;

typedef struct usb_audio_MIDI_out_jack /* p. 22 */
{
   uint_8   bLength;          /* 6 + 2p*/
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x03 = OUT JACK */
   uint_8   bJackType;        /* 1, 2 == Embedded, External */
   uint_8   bJackID;          /* Jack ID number */
   uint_8   bNrInputPins;     /* No. of input pins = p */
   uint_8   baSourceIDPin[1][2]; /* Connected entity ID + pin No. */

   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_JACK_STRING immediately follows the       */
   /*    variable-length array (size = 2p) of pairs,     */
   /*    each an ID number of the entity an input pin    */
   /*    1, 2, ... p is connected to, and the output pin */
   /*    number that input pin connects to.              */
   /*    The struct must be addressed by a pointer set   */
   /*    to the address of selector-unit struct + 6 + 2p.*/
   /*    Dynamic address calculation is ALWAYS required. */
   #define  JACK_STRING_PTR(x)   ((AUDIO_JACK_STRING_PTR)\
                  &x->baSourceID[2*x->bNrInputPins])

} MIDI_OUT_JACK_DESCRIPTOR, _PTR_ MIDI_OUT_JACK_DESCRIPTOR_PTR;

typedef struct usb_audio_element_string
{
   uint_8   iElement;      /* Index of element string descr. */
} AUDIO_ELEMENT_STRING, _PTR_ AUDIO_ELEMENT_STRING_PTR;

typedef struct usb_audio_MIDI_element_continued
{
   uint_8   bNrOutputPins;    /* No. of output pins = q */
   uint_8   bInTerminalLink;  /* Input terminal No. */
   uint_8   bOutTerminalLink; /* Output terminal No. */
   uint_8   bElCapsSize;      /* Byte size of Element Caps */
   uint_8   bmElementCaps[1]; /* Element capabilities bitmap */
   #define  AUD_MS_MIDI_CUSTOM   0x0001  /* custom, undefined */
   #define  AUD_MS_MIDI_CLOCK    0x0002  /* MIDI clock */
   #define  AUD_MS_MIDI_MTC      0x0004
   #define  AUD_MS_MIDI_MMC      0x0008
   #define  AUD_MS_MIDI_GM1      0x0010
   #define  AUD_MS_MIDI_GM2      0x0020
   #define  AUD_MS_MIDI_GS       0x0040
   #define  AUD_MS_MIDI_XG       0x0080
   #define  AUD_MS_MIDI_EFX      0x0100
   #define  AUD_MS_MIDI_PATCHBAY 0x0200
   #define  AUD_MS_MIDI_DLS1     0x0400
   #define  AUD_MS_MIDI_DLS2     0x0800
   
   /*       ******   DANGER!!!   ******   */
   /*    AUDIO_JACK_STRING immediately follows the       */
   /*    variable-length array (size = n).               */
   /*    Dynamic address calculation is ALWAYS required. */
   #define  ELEMENT_STRING_PTR(x)   ((AUDIO_ELEMENT_STRING_PTR)\
                  &x->baSourceID[2*x->bNrInputPins])

} MIDI_ELEMENT_DESC_CONT, _PTR_ MIDI_ELEMENT_DESC_CONT_PTR;

typedef struct usb_audio_MIDI_element /* p. 24 */
{
   uint_8   bLength;          /* 10 + 2p + n*/
   uint_8   bDescriptorType;  /* 0x24 = CS_INTERFACE */
   uint_8   bDescriptorSubtype;  /* 0x04 = ELEMENT */
   uint_8   bElementID;       /* Element ID number */
   uint_8   bNrInputPins;     /* No. of input pins = p */
   uint_8   baSourceIDPin[1][2]; /* Connected entity ID + pin No. */

   /*       ******   DANGER!!!   ******   */
   /*    MIDI_ELEMENT_DESC_CONT immediately follows the  */
   /*    variable-length array (size = 2p) of pairs,     */
   /*    each an ID number of the entity an input pin    */
   /*    1, 2, ... p is connected to, and the output pin */
   /*    number that input pin connects to.              */
   /*    The struct must be addressed by a pointer set   */
   /*    to the address of selector-unit struct + 5 + 2p.*/
   /*    Dynamic address calculation is ALWAYS required. */
   #define  ELEMENT_CONT_PTR(x)   ((AUDIO_JACK_STRING_PTR)\
                  &x->baSourceID[2*x->bNrInputPins])

} MIDI_ELEMENT_DESCRIPTOR, _PTR_ MIDI_ELEMENT_DESCRIPTOR_PTR;


typedef struct usb_audio_bulk_data_endpoint /* p. 26 */
{
   uint_8   bLength;          /* 4 + n */
   uint_8   bDescriptorType;  /* 0x25 = CS_ENDPOINT */
   uint_8   bDescriptorSubtype;  /* 0x01 = GENERAL */
   uint_8   bJNumEmbMIDIJack; /* No. of embedded jacks = n */
   uint_8   baAssocJackID[1]; /* Associated Jack ID numbers */
} MS_BULK_EP_DESCRIPTOR, _PTR_ MS_BULK_EP_DESCRIPTOR_PTR;

/*-------------------------------------------------------**
** For parsing configurations, the Swiss Army Knife that **
**   can address anything is a union of all standard or  **
**   class-specific descriptors and their sub-structs.   **
** Since there are so many audio-specific structs, it    **
**   is a user-friendly to sort them alphabetically by   **
**   variable names.  This becomes a reverse-index for   **
**   looking up what type of struct is being parsed.     **
**-------------------------------------------------------*/

typedef union class_descriptor_union
{
   /* non-descriptor data types */
   uchar_ptr                  bufr;
   pointer                    pntr;
   uint_32                    word;
   /* standard Chapter 9 descriptors */
   DEVICE_DESCRIPTOR_PTR         dvic;
   CONFIGURATION_DESCRIPTOR_PTR  cfig;
   INTERFACE_DESCRIPTOR_PTR      intf;
   ENDPOINT_DESCRIPTOR_PTR       ndpt;
   QUALIFIER_DESCRIPTOR_PTR      qual;
   /* audio-specific descriptors in this file */
   AS_INTERFACE_DESCRIPTOR_PTR      asid;
   AS_DATA_EP_DESCRIPTOR_PTR        asep;
   SD_AUDIO_DATA_EP_DESCRIPTOR_PTR  saep; //Standard audio Iso endpoint descriptor
   CONTROL_HEADER_DESCRIPTOR_PTR    chdr;
   DATA_FORMAT_1_DESCRIPTOR_PTR     dat1;
   DATA_FORMAT_2_DESCRIPTOR_PTR     dat2;
   DOLBY_CLUSTER_DESCRIPTOR_PTR     dolb;
   AUDIO_DOLBY_MODES_PTR            dolm;
   DOLBY_UNIT_DESCRIPTOR_PTR        dolu;
   MIDI_ELEMENT_DESC_CONT_PTR       elec;
   AUDIO_ELEMENT_STRING_PTR         eles;
   MIDI_ELEMENT_DESCRIPTOR_PTR      eled;
   AUDIO_EXTENSION_CHANNELS_PTR     extc;
   AUDIO_EXTENSION_STRING_PTR       exts;
   EXTENSION_UNIT_DESCRIPTOR_PTR    extu;
   FEATURE_UNIT_DESCRIPTOR_PTR      fead;
   AUDIO_FEATURE_STRING_PTR         feas;
   INPUT_TERMINAL_DESCRIPTOR_PTR    itrm;
   AUDIO_JACK_STRING_PTR            jaks;
   MS_BULK_EP_DESCRIPTOR_PTR        mbed;
   MIDI_EVENT_PACKET_PTR            mevt;
   MIDI_IN_JACK_DESCRIPTOR_PTR      mijd;
   AUDIO_MIXER_STRING_PTR           mixs;
   AUDIO_MIXER_CHANNELS_PTR         mixc;
   MIXER_UNIT_DESCRIPTOR_PTR        mixu;
   MIDI_OUT_JACK_DESCRIPTOR_PTR     mojd;
   MPEG_FORMAT_DESCRIPTOR_PTR       mpeg;
   MS_INTERFACE_DESCRIPTOR_PTR      msid;
   OUTPUT_TERMINAL_DESCRIPTOR_PTR   otrm;
   AUDIO_PROCESSOR_CHANNELS_PTR     proc;
   AUDIO_PROCESSOR_STRING_PTR       pros;
   PROCESSOR_UNIT_DESCRIPTOR_PTR    prou;
   AUDIO_SELECTOR_STRING_PTR        sels;
   SELECTOR_UNIT_DESCRIPTOR_PTR     selu;
   STATUS_WORD_FORMAT_PTR           stfw;
   AUDIO_UPDOWN_MODES_PTR           udnm;
   UPDOWN_MIX_UNIT_DESCRIPTOR_PTR   umxu;
   AUDIO_UNIT_STRING_PTR            unis;
   AUDIO_UNIT_DESCRIPTOR_PTR        unid;
}  CLASS_UNION, _PTR_ CLASS_UNION_PTR;

/* Reduce parameter count by packing into struct */
typedef struct audio_descriptor_parms
{
   DEV_INSTANCE_PTR           dev_ptr;
   INTERFACE_DESCRIPTOR_PTR   intf_desc;
   uint_8   desc_index;    /* 1st, 2nd, etc. of type  */
   uint_8   desc_size;     /* descriptor size         */
   uint_8   desc_type;     /* descriptor type code    */
   uint_8   desc_subtype;  /* sub-type code           */
} AUDIO_DESCRIPTOR_PARMS, _PTR_ AUDIO_DESCRIPTOR_PARMS_PTR;

typedef void (_CODE_PTR_  AUDIO_CALLBACK_USER_FN)
   (
      uint_32,                     /* [IN] Callback parameter */
      pointer,                     /* [IN] Pointer to class interface */
      uint_32,                     /* [IN] Length of data transferred */
      uint_32                      /* [IN] Error code */
   );

/*---------------------------------------------------**
** Class-specific interface info struct, useful for  **
**       an application to send/receive on in/out    **
**       pipes by name without internal details.     **
** NOTE: Since the class may have to handle several  **
**       audio interfaces attached simultaneously,   **
**       it is essential to have an array or list.   **
**---------------------------------------------------*/

typedef struct audio_interface
{
   GENERAL_CLASS                    G;

   /* Only 1 command can be issued at one time */
   boolean                          IN_SETUP;
   boolean							IN_DATA;
   
   /* Setup Req callback and parameter */
   AUDIO_CALLBACK_USER_FN           USER_CALLBACK;
   uint_32                          USER_PARAM;
   /* Data pipe callback and parameter */
   AUDIO_CALLBACK_USER_FN           DATA_CALLBACK;
   uint_32                          DATA_PARAM;
        
   /* Fields for the audio control (AC) interface */
   _usb_pipe_handle                 control_pipe;
   tr_callback                      control_callback;
   _usb_pipe_handle                 AC_irrpt_pipe; /* optional */
   CLASS_UNION                      AC_header;     /* intf #'s */
   CLASS_UNION                      unitID[MAX_UNIT_ID]; /* ID's */
                                    /* Use unit 0 for HEADER */
   /* Fields for an audio streaming (AS) interfaces */
   _usb_interface_descriptor_handle AS_in_handle;
   CLASS_UNION                      AS_in_general;
   CLASS_UNION                      AS_in_format;
   CLASS_UNION						AS_in_ep;
   _usb_pipe_handle                 iso_in_data_pipe;
   _usb_pipe_handle                 iso_in_sync_pipe;
   _usb_interface_descriptor_handle AS_out_handle;
   CLASS_UNION                      AS_out_general;
   CLASS_UNION                      AS_out_format;
   CLASS_UNION						AS_out_ep;
   _usb_pipe_handle                 iso_out_data_pipe;
   _usb_pipe_handle                 iso_out_sync_pipe;
   
   /* Fields for a MIDI streaming (MS) interface */
   _usb_interface_descriptor_handle MS_intf_handle;
   CLASS_UNION_PTR                  MS_format;
   _usb_pipe_handle                 bulk_in_pipe;
   _usb_pipe_handle                 bulk_out_pipe;
   
   /* TBD -- add structs for associated interfaces */

} AUDIO_INTERFACE_STRUCT, _PTR_ AUDIO_INTERFACE_STRUCT_PTR;

typedef struct {
   CLASS_CALL_STRUCT_PTR   CLASS_PTR;
   AUDIO_CALLBACK_USER_FN  CALLBACK_FN;
   uint_32                 CALLBACK_PARAM;
} AUDIO_COMMAND, _PTR_ AUDIO_COMMAND_PTR;


/* Alphabetical list of Function Prototypes */

#ifdef __cplusplus
extern "C" {
#endif

USB_STATUS usb_audio_control_request (AUDIO_COMMAND_PTR, USB_SETUP_PTR, uint_16, uchar_ptr);
void       usb_audio_init  (PIPE_BUNDLE_STRUCT_PTR, CLASS_CALL_STRUCT_PTR);
USB_STATUS usb_audio_get_max_data_packet_size(CLASS_CALL_STRUCT_PTR, uint_8, uint_16 *);
uint_32    usb_audio_send_data(AUDIO_COMMAND_PTR, uchar_ptr, uint_32);
uint_32    usb_audio_recv_data(AUDIO_COMMAND_PTR, uchar_ptr, uint_32);
USB_STATUS usb_audio_get_sample_freq(pointer, pointer, uint_32*);
USB_STATUS usb_audio_get_feature_unitID(CLASS_CALL_STRUCT_PTR, uint_8, uint_8 *, uint_8 *);
USB_STATUS usb_audio_get_iso_ep_address(CLASS_CALL_STRUCT_PTR, uint_8, uint_8 *);
   
            
#ifdef __cplusplus
}
#endif                         

                         
#endif


