# Common class table

#
# Define the following variables for the class:
#
#     srcs          list of source files without extensions
#     srcdirs       list of directories containing source files
#
#     dups          list of files to be copied to the output directory
#     dupdirs       list of directories containing the 'dups' files
#
# NOTE: Always use += when defining variables!
#

srcdirs        += classes$(PS)common
class_srcs     += usb_classes
