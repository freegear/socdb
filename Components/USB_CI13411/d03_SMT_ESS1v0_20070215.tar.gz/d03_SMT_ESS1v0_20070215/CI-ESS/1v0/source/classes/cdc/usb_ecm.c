/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file contains the Ethernet control model specifics of the
***   USB Communications class driver
***
**************************************************************************
**END*********************************************************/

#include "usb_cdc.h"

/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_ecm_init
* Returned Value : none
* Comments       :
*     Initialize Ethernet Networking Control Model interface info struct.
*
*END*--------------------------------------------------------------------*/

void usb_ecm_init
   (
      /* [IN] device/descriptor/pipe handles */
      PIPE_BUNDLE_STRUCT_PTR  pbs_ptr,
      /* [IN] ECM call struct pointer */
      CLASS_CALL_STRUCT_PTR   ecm_call_ptr
   )
{ /* Body */

   /* Initialize common CDC struct */
   usb_cdc_init(pbs_ptr, ecm_call_ptr);

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_ecm_get_func_desc
* Returned Value : USB_STATUS
* Comments       :
*          Get Ethernet Networking Functional Descriptor.
*END*--------------------------------------------------------------------*/

USB_STATUS usb_ecm_get_func_desc
   (
      /* [IN] The class call struct */
      CLASS_CALL_STRUCT_PTR      ccs_ptr,
      /* [OUT] The ECM_DEV_INFO_STRUCT */
      ECM_FUNCTIONAL_DESC_PTR    outfunc_ptr
   )
{ /* Body */
   ECM_INTERFACE_STRUCT_PTR      intf;
   USB_STATUS                    error = USBERR_NO_DEVICE_CLASS;
   DESCRIPTOR_UNION              desc_union;
   ECM_FUNCTIONAL_DESC_PTR       ecm_desc_ptr;
   uint_32                       len;

   USB_lock();

   /* Make sure device has not been detached */
   if (usb_host_class_intf_validate(ccs_ptr)) {
      intf = (ECM_INTERFACE_STRUCT_PTR)ccs_ptr->class_intf_handle;
      error = usb_hostdev_validate(intf->CDC.G.dev_handle);
   } /* Endif */

   /* If the device was detached return an error */
   if (error) {
      USB_unlock();
      return error;
   } /* Endif */

   /* Get the device configuration descriptor */
   error = _usb_hostdev_get_descriptor(intf->CDC.G.dev_handle, DESCTYPE_CONFIG,
      0, 0, &desc_union.pntr);
   if (!error && desc_union.pntr) {
      len = utoh16(desc_union.cfig->wTotalLength);
      ecm_desc_ptr = desc_union.pntr;
      error = USBERR_NO_DESCRIPTOR;

      /* Find the Ethernet Networking Functional Descriptor */
      while (len >= sizeof(ECM_FUNCTIONAL_DESC)) {
         if (utoh8(ecm_desc_ptr->BDESCRIPTORTYPE) == CS_INTERFACE &&
             utoh8(ecm_desc_ptr->BDESCRIPTORSUBTYPE) == CS_DESCSUBTYPE_ECM)
         {
            if (outfunc_ptr) {
               *outfunc_ptr = *ecm_desc_ptr;
            } /* Endif */
            intf->FUNC_DESC_PTR = ecm_desc_ptr;
            error = USB_OK;
            break;
         } /* Endif */
         ecm_desc_ptr = (ECM_FUNCTIONAL_DESC_PTR)((uchar_ptr)ecm_desc_ptr +
            utoh8(ecm_desc_ptr->BFUNCTIONALLENGTH));
         len -= utoh8(ecm_desc_ptr->BFUNCTIONALLENGTH);
      } /* Endwhile */
   } /* Endif */

   USB_unlock();
   return error;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_ecm_get_mac_addr_cb
* Returned Value : USB_STATUS
* Comments       :
*
*END*--------------------------------------------------------------------*/

static void usb_ecm_get_mac_addr_cb
   (
      /* [IN] Unused */
      pointer     dummy,
      /* [IN] Pointer to the class interface instance */
      pointer     param,
      /* [IN] Data buffer */
      uchar_ptr   buffer,
      /* [IN] Length of buffer */
      uint_32     len,
      /* [IN] Error code (if any) */
      USB_STATUS  status
   )
{ /* Body */
   ECM_INTERFACE_STRUCT_PTR      intf;
   uint_32                       i;
   uint_16                       num;

   /*
   ** There is need for USB_lock in the callback function, and there is also no
   ** need to check if the device is still attached (otherwise this callback
   ** would never have been called!
   */

   /* Get class interface handle, reset IN_SETUP and call callback */
   intf = (ECM_INTERFACE_STRUCT_PTR)param;

   intf->CDC.IN_SETUP = FALSE;

   if (intf->CDC.FREE) {
      USB_memfree(intf->CDC.FREE);
   } /* Endif */

   if (!status) {
      /* Copy the MAC address into the user buffer */
      for (i = 0; i < ECM_BYTES_IN_MAC_ADDR; i++) {
         num = buffer[i * 4 + 2];
         if (num >= '0' && num <= '9') {
            num = num - '0';
         } else if (num >= 'A' && num <= 'F') {
            num = num - 'A' + 0xA;
         } /* Endif */
         intf->USER_BUF[i] = num << 4;

         num = buffer[i * 4 + 4];
         if (num >= '0' && num <= '9') {
            num = num - '0';
         } else if (num >= 'A' && num <= 'F') {
            num = num - 'A' + 0xA;
         } /* Endif */
         intf->USER_BUF[i] = intf->USER_BUF[i] | num;
      } /* Endfor */
   } /* Endif */

   if (intf->CDC.USER_CALLBACK) {
      intf->CDC.USER_CALLBACK(intf->CDC.USER_PARAM, intf, len, status);
   } /* Endif */

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_ecm_get_mac_addr
* Returned Value : USB_STATUS
* Comments       :
*           Get ethernet MAC address
*END*--------------------------------------------------------------------*/

USB_STATUS usb_ecm_get_mac_addr
   (
      /* [IN] The communcation device common command structure */
      CDC_COMMAND_PTR     command,
      /* [OUT] The MAC address (6 bytes) */
      uchar_ptr                  mac_addr
   )
{ /* Body */
   USB_STATUS                    error = USBERR_NO_DEVICE_CLASS;
   ECM_INTERFACE_STRUCT_PTR      intf;

   USB_lock();

   /* Make sure device has not been detached */
   if (usb_host_class_intf_validate(command->CLASS_PTR)) {
      intf = (ECM_INTERFACE_STRUCT_PTR)command->CLASS_PTR->class_intf_handle;
      error = usb_hostdev_validate(intf->CDC.G.dev_handle);
   } /* Endif */

   /*
   ** If the device was detached, or the previous SETUP transfer has not been
   ** complete, return an error
   */
   if (!error && intf->CDC.IN_SETUP) {
      error = USBERR_TRANSFER_IN_PROGRESS;
   } /* Endif */

   if (error) {
      USB_unlock();
      return error;
   } /* Endif */

   if (!intf->FUNC_DESC_PTR) {
      error = usb_ecm_get_func_desc(command->CLASS_PTR, NULL);
   } /* Endif */

   if (!error) {
      /* Save the higher level callback and ID */
      intf->CDC.USER_CALLBACK = command->CALLBACK_FN;
      intf->CDC.USER_PARAM = command->CALLBACK_PARAM;
      intf->CDC.IN_SETUP = TRUE;
      intf->USER_BUF = mac_addr;

      error = _usb_host_register_ch9_callback(intf->CDC.G.dev_handle,
         usb_ecm_get_mac_addr_cb, intf);

      error = _usb_host_ch9_get_descriptor(intf->CDC.G.dev_handle,
         (DESCTYPE_STRING << 8) | utoh8(intf->FUNC_DESC_PTR->IMACADDRESS),
         0x0409, ECM_BYTES_IN_MAC_ADDR_STRING_DESC, intf->MAC_ADDR_STRING_DESC);
   } /* Endif */

   USB_unlock();
   return error;
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_ecm_set_eth_mcfilters
* Returned Value : USB_STATUS
* Comments       :
*     Sends a request to set the Ethernet device multicast filters as
*     specified in the sequential list of 48 bit Ethernet multicast
*     addresses.
*END*--------------------------------------------------------------------*/

USB_STATUS usb_ecm_set_eth_mcfilters
   (
      /* [IN] The communcation device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN] Multicast filters in buffer, each 6 bytes in network order */
      uchar_ptr         mc_filters,
      /* [IN] The number of filters in the array */
      uint_16           number
   )
{ /* Body */

   return usb_cdc_setup_common(
      command, CDC_REQ_OUT, SET_ETHERNET_MULTICAST_FILTERS, number,
      number * ECM_BYTES_IN_MAC_ADDR, mc_filters);

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_ecm_set_powermgt_filter
* Returned Value : USB_STATUS
* Comments       :
*     Set the status of the specified Ethernet power managemnet
*     pattern filter for a device using an ECM class command.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_ecm_set_powermgt_filter
   (
      /* [IN] The communcation device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN] The filter number */
      uint_16     filter_num,
#if 0
      /* [IN] The size of the mask in bytes*/
      uint_32     mask_size,
      /* [IN] The mask followed by the pattern */
      uchar_ptr   mask,
      /* [IN] The pattern */
      uchar_ptr   pattern
#else
      uchar_ptr   buffer,
      uint_16     len
#endif
   )
{ /* Body */
#if 1
   return usb_cdc_setup_common(
      command, CDC_REQ_OUT, SET_ETHERNET_POWER_MANAGEMENT_PATTERN_FILTER,
      filter_num, len, buffer);
#else
   CDC_INTERFACE_STRUCT_PTR      intf;
   USB_STATUS                    error;
   uchar_ptr                     buf;
   uchar                         temp;
   int                           extra_mask_bits;

   /*
   ** We need to build a Power Management Pattern Filter Structure
   **
   ** Field       Size           Value       Desc
   ** ------------------------------------------------------------------------
   ** MaskSize    2              Number      Size in bytes of the Mask
   ** Mask        MaskSize       Bitmask     Each byte contains 8 masking bits
   ** Pattern     MaskSize * 8   Number      String of bytes (one for each
   **                                        masking bit)
   **
   ** The max buffer size needed is 2 + MaskSize + MaskSize * 8, and the minimum
   ** buffer size at most 7 bytes shorter then the max
   */

   /* Start by looking at the last byte of the mask */
   temp = mask[mask_size - 1] & 0xFF;

   /*
   ** Starting with the LSB count bits until no more bits are set. Subtract this
   ** number from 8 to get the number of trailing 0 bits.
   */
   extra_mask_bits = 8;
   while (temp) {
      temp = temp >> 1;
      extra_mask_bits--;
   } /* Endwhile */

   /* We don't send pattern bytes for trailing 0 bits so don't count them */
   /* TODO: use _usb_hostdev_get_buffer */
   buf = (pointer)USB_memalloc(2 + mask_size + mask_size * 8 - extra_mask_bits);
   if (!buf) {
      return USBERR_ALLOC;
   } /* Endif */

   /* Build the data structure to transmit */
   htou16(buf, mask_size);
   USB_memcopy(mask, buf + 2, mask_size);
   USB_memcopy(pattern, buf + 2 + mask_size, 8 * mask_size - extra_mask_bits);


   USB_lock();

   /* Make sure device has not been detached */
   if (usb_host_class_intf_validate(command->CLASS_PTR)) {
      intf = (CDC_INTERFACE_STRUCT_PTR)command->CLASS_PTR->class_intf_handle;
      error = usb_hostdev_validate(intf->G.dev_handle);
   } /* Endif */

   /*
   ** If the device was detached, or the previous SETUP transfer has not been
   ** complete, return an error
   */
   if (!error && intf->IN_SETUP) {
      error = USBERR_TRANSFER_IN_PROGRESS;
   } /* Endif */

   intf->FREE = buf;

   if (!error) {
      error = usb_cdc_setup_common(
         command, CDC_REQ_OUT, SET_ETHERNET_POWER_MANAGEMENT_PATTERN_FILTER,
         filter_num, 2 + mask_size + mask_size * 8 - extra_mask_bits, buf);
   } /* Endif */

   if (error) {
      USB_memfree(intf->FREE);
      intf->FREE = NULL;
   } /* Endif */

   USB_unlock();

   return error;
#endif
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_ecm_get_powermgt_filter
* Returned Value : USB_STATUS
* Comments       :
*     Retrieves the status of the specified Ethernet power managemnet
*     pattern filter from the device using an ECM class command.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_ecm_get_powermgt_filter
   (
      /* [IN] The communcation device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN] The filter number */
      uint_32        filter_num,
      /* [OUT] Where result should be stored */
      uchar_ptr      bool_ptr
   )
{ /* Body */

   return usb_cdc_setup_common(command, CDC_REQ_IN,
      GET_ETHERNET_POWER_MANAGEMENT_PATTERN_FILTER, filter_num, 2, bool_ptr);
} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_ecm_set_eth_pktfilter
* Returned Value : USB_STATUS
* Comments       :
*     Configures the device Ethernet packet fileter settings using an ECM
*     class command.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_ecm_set_eth_pktfilter
   (
      /* [IN] The communcation device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN] The packet filter bitmap */
      uint_16     filter
   )
{ /* Body */

   return usb_cdc_setup_common(
      command, CDC_REQ_OUT, SET_ETHERNET_PACKET_FILTER, filter, 0, NULL);

} /* Endbody */


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_ecm_get_eth_stat
* Returned Value : USB_STATUS
* Comments       :
*     Requests an Ethernet statistic from the device using an ECM
*     class command.
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_ecm_get_eth_stat
   (
      /* [IN] The communcation device common command structure */
      CDC_COMMAND_PTR     command,
      /* [IN] The statistic requested */
      uint_16                 stat_code,
      /* [IN/OUT] Pointer to a uint_32 in which to store stat stat */
      uchar_ptr               stat_ptr
   )
{ /* Body */

   return usb_cdc_setup_common(
      command, CDC_REQ_IN, GET_ETHERNET_STATISTIC, stat_code, 4, stat_ptr);

} /* Endbody */



/* EOF */

