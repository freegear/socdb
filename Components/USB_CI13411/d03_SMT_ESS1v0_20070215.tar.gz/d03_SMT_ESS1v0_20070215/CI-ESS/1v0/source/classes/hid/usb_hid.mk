# Printer Class

#
# Define the following variables for the class:
#
#     srcs          list of source files without extensions
#     srcdirs       list of directories containing source files
#
#     dups          list of files to be copied to the output directory
#     dupdirs       list of directories containing the 'dups' files
#
# NOTE: Always use += when defining variables!
#

CPPFLAGS         +=-DUSBCLASS_INC_HID
MQX_INCDIRS      +=$(USB_ROOT)\source\classes\hid

dupdirs  += classes\hid
dups     += usb_hid.h usb_hid_vers.h


srcdirs  += classes\hid
class_srcs     += usb_hid

