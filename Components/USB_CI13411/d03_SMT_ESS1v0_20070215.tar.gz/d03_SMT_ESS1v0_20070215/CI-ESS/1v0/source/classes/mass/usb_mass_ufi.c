/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:
***   This file creates the mass storage class UFI command headers
***
**************************************************************************
**END*********************************************************/

#include "usb_mass_bo.h"
#include "usb_mass_ufi.h"


/*FUNCTION*----------------------------------------------------------------
*
* Function Name  : usb_mass_ufi_generic
* Returned Value : None
* Comments       :
*     This function initializes the mass storage class
*
*END*--------------------------------------------------------------------*/

USB_STATUS usb_mass_ufi_generic
   (
      /* [IN] command object allocated by application*/
      COMMAND_OBJECT_PTR         cmd_ptr,
      uint_8                     opcode,
      uint_8                     lun,
      uint_32                    lbaddr,
      uint_32                    blen,

      uint_8                     cbwflags,

      uchar_ptr                  buf,
      uint_32                    buf_len
   )
{ /* Body */
   USB_STATUS                    status = USB_OK;
   UFI_CBWCB_EXTENDED_STRUCT_PTR ufi_ptr = NULL;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("usb_mass_ufi_generic");
   #endif

   ufi_ptr = (pointer) &(cmd_ptr->CBW_PTR->CMD_BLOCK);

   /* Construct UFI command buffer */
   ufi_ptr->BUFIOPCODE = opcode;
   ufi_ptr->BUFILUN = lun;
   HOST_WRITE_BEOCT_32(ufi_ptr->BUFILOGICALBLOCKADDRESS, lbaddr);
   HOST_WRITE_BEOCT_32(ufi_ptr->BLENGTH, blen);

   /* Construct CBW fields (sig and tag will be filled up by class driver)*/
   htou32(cmd_ptr->CBW_PTR->DCBWDATATRANSFERLENGTH, buf_len);
   cmd_ptr->CBW_PTR->BMCBWFLAGS = cbwflags;
   TRANSFER_LOW_NIBBLE(cmd_ptr->LUN, cmd_ptr->CBW_PTR->BCBWLUN);
   TRANSFER_LOW_NIBBLE(sizeof(UFI_CBWCB_STRUCT),
      cmd_ptr->CBW_PTR->BCBWCBLENGTH);

   /* Construct Command object */
   cmd_ptr->DATA_BUFFER = buf;
   cmd_ptr->BUFFER_LEN = buf_len;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("usb_mass_ufi_generic, SUCCESSFUL");
   #endif

   /* Pass this request to class driver */
   return usb_class_mass_storage_device_command(cmd_ptr->CALL_PTR, cmd_ptr);
} /* Endbody */

/* EOF */
