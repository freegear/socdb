#ifndef __usbprv_host_h__
#define __usbprv_host_h__ 1
/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the internal USB Host speicifc type definitions
***                                                               
**************************************************************************
**END*********************************************************/
#ifdef __USB_OS_MQX__
	#include "cache.h"
#endif
#include "vusb32.h"
#include "types.h"

#define  USBERR_ALLOC_BD_TABLE            (0xFE)

/***************************************
**
** Code macros
**
*/

/* Macro for aligning the BDT PAGE to 512 byte boundary */
#define USB_MEM512_ALIGN(n)                  ((n) + (-(n) & 511))

#define  USB_MAX_INTERFACES                  (10)
#define  RX_BUFFER_SIZE                      (0xFF)
#define  DEFAULT_MAX_NAK_COUNT               (15)

#define  USB_RESUME_DELAY                    (2)
#define  MAX_TOKEN_TRANSFER_NUM				 (8)

/* Setup */   
typedef struct
{
   uint_8   BREQUESTTYPE;   /* (bits 6:5 must be 00) */
   uint_8   BREQUEST;
   uint_16  WVALUE;
   uint_16  WINDEX;
   uint_16  WLENGTH;
} INTERNAL_USB_SETUP, _PTR_ INTERNAL_USB_SETUP_PTR;

/* Callback function storage structure */
typedef struct host_service_struct {
   uint_32              TYPE;
   void                 (_CODE_PTR_ SERVICE)(pointer, uint_32);
   struct host_service_struct _PTR_ NEXT;
} USB_SERVICE_STRUCT, _PTR_ USB_SERVICE_STRUCT_PTR;

typedef struct pipe_tr_struct
{
   TR_INFO_FIELDS
   struct pipe_tr_struct   _PTR_ next;
   uint_32                       status;
   /* Second phase of setup packet: 
   ** Send/Receive 
   */
   boolean                       SEND_PHASE;
   USB_SETUP                     setup_packet;
} PIPE_TR_STRUCT, _PTR_ PIPE_TR_STRUCT_PTR;

typedef struct
{
   PIPE_INFO_FIELDS						  /* 34 bytes in size */
   uint_32              SOFAR;            /* number of bytes sent/recv'd so far */
   uint_32              TODO1;            /* number of bytes to send for first 
                                          ** phase 
                                          */
   uint_32              TODO2;            /* number of bytes to send for second 
                                          ** phase 
                                          */
   boolean              OPEN;
   boolean              SEND_PHASE;       /* Second phase of setup packet: 
                                          ** Send/Receive 
                                          */                                          
   boolean              PACKETPENDING;    /* Transaction pending */                                          

   boolean              FIRST_PHASE;
   /* Terminate xfer with zero length packet */
   boolean              DONT_ZERO_TERMINATE;

   uchar_ptr            TX1_PTR;          /* address of transmit buffer for 
                                          ** first phase 
                                          */
   uchar_ptr            TX2_PTR;          /* address of transmit buffer for 
                                          ** second phase 
                                          */
   uchar_ptr            RX_PTR;           /* address of receive buffer */

   
   int_16               PIPE_ID;          /* Pipe ID */
   int_16               NEXT_PIPE;        /* Next pipe id for the same type of 
                                          ** pkt 
                                          */
   uint_8               CURRENT_INTERVAL;
   uint_8               CURRENT_NAK_COUNT;
   uint_8               USB_PIPE_TRANSACTION_STATE;
   uint_8               STATUS;           /* 0: Current transfer status */

	/* 52 + 34 = 86 bytes so far */  
   uint_8               NEXTDATA01;       /* Data 0/1 synch bit for the PID */
   uint_8               MUSTSENDNULL;     /* Status stage of control transfer */
   uint_8               RESERVED[PIPE_RESERVED_FOR_ALIGNMENT];
   PIPE_TR_STRUCT_PTR   tr_list_ptr;
   TR_INIT_PARAM_STRUCT TR;		 /* 32 byte in size */

   /****************************************************
   Data cache requirement is that any buffer that stores
   the data should be cache aligned. This means that the
   setup packet buffer must be cache aligned too. Structure
   fields above this have occupied 94 + 32 = 126 bytes.
   We add a 2 bytes padding to makesure that it is aligned
   on a 32 byte boundry since 126 + 2 = 128; We also
   add a padding at the end to ensure that we don't correupt
   someother memory when we flush the setup packet
   from cache.
   ****************************************************/
   USB_SETUP            SETUP; /* 8 bytes */
#ifdef _DATA_CACHE_
   uint_8               RESERVED2[PSP_CACHE_LINE_SIZE-8];
#endif

} PIPE_DESCRIPTOR_STRUCT, _PTR_ PIPE_DESCRIPTOR_STRUCT_PTR;

/* Class Callback function storage structure */
typedef struct class_service_struct {
   uint_8               CLASS_TYPE;
   uint_8               SUB_CLASS;
   uint_8               PROTOCOL;
   /* index of the instance */
   uint_8               INDEX;
   /* identification string unique to this type */
   char_ptr             CLASS_ID_STRING;
   /* class handle will be NULL if it is not initialized */
   pointer              CLASS_HANDLE;
   pointer (_CODE_PTR_  INIT)(pointer, uint_32);
   void    (_CODE_PTR_  DEINIT)(pointer);
   void    (_CODE_PTR_  CALL_BACK_INIT)(pointer, char_ptr);
   void    (_CODE_PTR_  CALL_BACK_REMOVE)(pointer);
   struct class_service_struct _PTR_ NEXT_INSTANCE;
   struct class_service_struct _PTR_ NEXT;
} USB_HOST_CLASS_DRIVER_STRUCT, _PTR_ USB_HOST_CLASS_DRIVER_STRUCT_PTR;

typedef struct usb_host_state_structure {
   uint_32                             FRAME_LIST_SIZE;
   HOST_BDT_STRUCT_PTR                 USB_BUFFERED_BDT_PTR;
   HOST_BDT_STRUCT_PTR                 USB_NEXT_BUFFERED_BDT_PTR;
   HOST_BDT_STRUCT_PTR                 USB_TEMP_SND_BDT_PTR;
   HOST_BDT_STRUCT_PTR                 USB_TEMP_RCV_BDT_PTR;
   pointer                             DEV_PTR;
   pointer                             DEVICE_LIST_PTR;
   pointer                			   ENDPT_HOST_RG;
   HOST_BDT_STRUCT_PTR                 USB_BDT_PAGE_BASE;
   HOST_BDT_STRUCT_PTR                 USB_BDT_PAGE;
   USB_SERVICE_STRUCT_PTR              SERVICE_HEAD_PTR;
   PIPE_DESCRIPTOR_STRUCT_PTR          PIPE_DESCRIPTOR_BASE_PTR;
   pointer                             CALLBACK_STRUCT_PTR;
   HOST_BDT_STRUCT_PTR                 CURRENT_BDT;
   boolean                             SND_TOK_IN_PROGRESS;
   boolean                             NEXT_PKT_QUEUED;
   boolean                             USB_TOKEN_BUFFERED;
   uint_32                             HOST_WAIT;
   int_16                              CTRL_PIPE1;
   int_16                              CURRENT_PIPE_ID; 
   int_16                              NEXT_PIPE_ID;
   int_16                              CURRENT_ISO_HEAD;
   int_16                              CURRENT_ISO_TAIL;
   int_16                              CURRENT_INTR_HEAD;
   int_16                              CURRENT_INTR_TAIL;
   int_16                              CURRENT_CTRL_HEAD;
   int_16                              CURRENT_CTRL_TAIL;
   int_16                              CURRENT_BULK_HEAD;
   int_16                              CURRENT_BULK_TAIL;
   uint_8                              DEV_NUM;
   uint_8                              USB_OUT;             
   uint_8                              USB_IN;
   /* Use this variable to limit the number of software retry in one USB 
   ** frame when a token is naked by the device
   */
   uint_8							   TOKEN_TRANSFER_NUM;
   /* we now use these even when we aren't buffering tokens for xmit on the 
   ** next token_done this is so we can re-xmit if an error is returned
   */
   uint_8                              USB_BUFFERED;
   uint_8                              USB_BUFFERED_TOKEN;
   uint_8                              USB_BUFFERED_ADDRESS;
   uint_8                              USB_BUFFERED_TYPE; 
   uint_8                              USB_NEXT_BUFFERED_ADDRESS;
   uint_8                              USB_NEXT_BUFFERED_TOKEN;
   uint_8                              USB_NEXT_BUFFERED_TYPE;
   uint_8                              USB_PKT_PENDING;
   uint_8                              NO_HUB;
   uint_8                              SPEED;
   uint_8                              MAX_PIPES;
   PIPE_INIT_PARAM_STRUCT_PTR          DEFAULT_PIPE_INIT_STRUCT_PTR;
   _usb_pipe_handle                    DEFAULT_PIPE_HANDLE;
   pointer                             ATTACHED_DEV_INFO_PTR;
   USB_HOST_CLASS_DRIVER_STRUCT_PTR    CLASS_DRIVER_HEAD_PTR;
   uint_32                             RESUME_TIMER;
   pointer                             DEVICE_INFO_TABLE;
} USB_HOST_STATE_STRUCT, _PTR_ USB_HOST_STATE_STRUCT_PTR;

extern USB_HOST_STATE_STRUCT_PTR usb_host_state_struct_ptr;

/* Prototypes */

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __USB_OS_MQX__
extern void _usb_hci_vusb11_isr(_usb_host_handle);
#else
extern void HOST_INTERRUPT_ROUTINE_KEYWORD _usb_hci_vusb11_isr(void);
#endif
extern void _usb_host_delay(_usb_host_handle, uint_32);
extern void _usb_host_vusb11_reset_the_device(_usb_host_handle);
extern void _usb_host_vusb11_process_attach(_usb_host_handle);
extern void _usb_host_vusb11_process_detach(_usb_host_handle);
extern void _usb_host_process_detach(_usb_host_handle handle, uint_32 length);
extern void _usb_host_vusb11_process_token_done(_usb_host_handle, uint_8, uint_32);
extern void _usb_host_vusb11_pipe_transaction_state_02(_usb_host_handle);
extern HOST_BDT_STRUCT_PTR _usb_host_vusb11_get_next_in_bdt(_usb_host_handle);
extern HOST_BDT_STRUCT_PTR _usb_host_vusb11_get_next_out_bdt(_usb_host_handle);
extern uint_8 _bsp_get_usb_vector(uint_8);
extern pointer _bsp_get_usb_base(uint_8);
extern void _usb_host_vusb11_set_bdt_page(_usb_host_handle);
extern void _usb_host_vusb11_init_send_bdt(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
extern void _usb_host_vusb11_init_setup_bdt(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
extern void _usb_host_vusb11_init_recv_bdt(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
extern void _usb_host_vusb11_sched_pending_pkts(_usb_host_handle);
extern void _usb_host_vusb11_sched_iso_pkts(_usb_host_handle);
extern void _usb_host_buffer_bdt(_usb_host_handle, HOST_BDT_STRUCT_PTR);
extern void _usb_host_buffer_next_bdt(_usb_host_handle, HOST_BDT_STRUCT_PTR);
extern void _usb_host_queue_pkts(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
extern void _usb_host_update_current_head(_usb_host_handle, uint_8);
extern void _usb_host_update_interval_for_pipes(_usb_host_handle);
extern void _usb_host_vusb11_send_in_token(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
extern void _usb_host_vusb11_send_out_token(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
extern void _usb_host_vusb11_send_token(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR, uint_8, uint_8, uint_8);
extern void _usb_host_vusb11_resend_token(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR, uint_8);
extern void _usb_host_buffer_token(_usb_host_handle, uint_8, uint_8, uint_8);
extern void _usb_host_buffer_next_token(_usb_host_handle, uint_8, uint_8, uint_8);
extern void _usb_host_vusb11_initiate_correct_bdt(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
extern uint_8 _usb_hci_vusb11_init(_usb_host_handle);
extern void _usb_hci_vusb11_send_data(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
extern void _usb_hci_vusb11_send_setup(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
extern void _usb_hci_vusb11_recv_data(_usb_host_handle, PIPE_DESCRIPTOR_STRUCT_PTR);
extern void _usb_hci_vusb11_cancel_transfer(_usb_host_handle, 
   PIPE_DESCRIPTOR_STRUCT_PTR);
extern void _usb_hci_vusb11_bus_control(_usb_host_handle, uint_8);   
extern void _usb_hci_vusb11_shutdown(_usb_host_handle);

#ifdef __cplusplus
}
#endif

#endif

/* EOF */
   

