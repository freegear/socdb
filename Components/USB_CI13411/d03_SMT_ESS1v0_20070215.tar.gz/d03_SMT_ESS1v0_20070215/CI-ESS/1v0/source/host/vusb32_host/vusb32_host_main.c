/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the low-level VUSB32 Host Controller Interface
***   (HCI) routines.
***                                                               
**************************************************************************
**END*********************************************************/
#include "types.h"
#include "vusb32.h"
#include "usb.h"
#include "hostapi.h"
#include "usbprv.h"
#include "usbprv_host.h"

#ifdef __USB_OTG__
   #include "otgapi.h"
   #include "usbprv_otg.h"
   extern USB_OTG_STATE_STRUCT_PTR otg_handle;

#endif

#ifdef __USB_OS_MQX__
#include "mqx_arc.h"
#endif

#ifndef __USB_OS_MQX__
extern volatile boolean IN_ISR;
#endif


/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_update_current_interval_on_queue
*  Returned Value : None
*  Comments       :
*        Update the interval for the given pipe
*END*-----------------------------------------------------------------*/

void _usb_host_update_current_interval_on_queue
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle           handle,
      
      /* [IN] the USB Host state structure */
      PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_update_current_interval_on_queue");
   #endif
   
   
   while(TRUE) {
      /* Update the current interval for all pipes */
      if (pipe_descr_ptr->CURRENT_INTERVAL) {
         pipe_descr_ptr->CURRENT_INTERVAL--;
         if ((!pipe_descr_ptr->CURRENT_INTERVAL) && (pipe_descr_ptr->PIPETYPE != USB_INTERRUPT_PIPE)) {
            pipe_descr_ptr->CURRENT_NAK_COUNT = pipe_descr_ptr->NAK_COUNT;
         } /* Endif */
      } /* Endif */
      if (pipe_descr_ptr->NEXT_PIPE != -1) {
         pipe_descr_ptr = &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
            [pipe_descr_ptr->NEXT_PIPE];
      } else {
         break;
      } /* Endif */
   } /* EndWhile */

#ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_update_current_interval_on_queue, SUCCESSFUL");
#endif
      
} /* EndBody */


/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_queue_pkts
*  Returned Value : None
*  Comments       :
*        Queue the Pipe's transaction for processing
*END*-----------------------------------------------------------------*/

void _usb_host_queue_pkts
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle                  handle,

      /* [IN] Pipe descriptor to queue */      
      PIPE_DESCRIPTOR_STRUCT_PTR        pipe_descr_ptr
   )
{ /* Body */
   int_16 pipe_head, pipe_tail;
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_queue_pkts");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   USB_lock();

   pipe_descr_ptr->NEXT_PIPE = -1;
   
   /* Get the relevant Pipe Head and Tail */
   if (pipe_descr_ptr->PIPETYPE == USB_ISOCHRONOUS_PIPE) {
      pipe_head = usb_host_ptr->CURRENT_ISO_HEAD;
      pipe_tail = usb_host_ptr->CURRENT_ISO_TAIL;
   } else if (pipe_descr_ptr->PIPETYPE == USB_INTERRUPT_PIPE) {
      pipe_head = usb_host_ptr->CURRENT_INTR_HEAD;
      pipe_tail = usb_host_ptr->CURRENT_INTR_TAIL;
   } else if (pipe_descr_ptr->PIPETYPE == USB_CONTROL_PIPE) {
      pipe_head = usb_host_ptr->CURRENT_CTRL_HEAD;
      pipe_tail = usb_host_ptr->CURRENT_CTRL_TAIL;
   } else if (pipe_descr_ptr->PIPETYPE == USB_BULK_PIPE) {
      pipe_head = usb_host_ptr->CURRENT_BULK_HEAD;
      pipe_tail = usb_host_ptr->CURRENT_BULK_TAIL;
   } /* Endif */
   
   if (pipe_head == -1) {
      /* First pipe added to the Active Pipe List */
      pipe_head = pipe_descr_ptr->PIPE_ID;
   } else { 
   
      if (pipe_tail != -1) {
         /* Add it to the Next pointer of the Tail */
         usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR[pipe_tail].NEXT_PIPE = 
            pipe_descr_ptr->PIPE_ID;
      } else {
         /* This is only the second Active Pipe added to the Active list. 
         ** Add it to the next pointer of the head.
         */
         usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR[pipe_head].NEXT_PIPE = 
            pipe_descr_ptr->PIPE_ID;
      } /* Endif */
      
      /* New Tail */
      pipe_tail = pipe_descr_ptr->PIPE_ID;
   } /* Endif */
   
   /* Re-set the relevant Pipe Head and Tail */
   if (pipe_descr_ptr->PIPETYPE == USB_ISOCHRONOUS_PIPE) {
      usb_host_ptr->CURRENT_ISO_HEAD = pipe_head;
      usb_host_ptr->CURRENT_ISO_TAIL = pipe_tail;
   } else if (pipe_descr_ptr->PIPETYPE == USB_INTERRUPT_PIPE) {
      usb_host_ptr->CURRENT_INTR_HEAD = pipe_head;
      usb_host_ptr->CURRENT_INTR_TAIL = pipe_tail;
   } else if (pipe_descr_ptr->PIPETYPE == USB_CONTROL_PIPE) {
      usb_host_ptr->CURRENT_CTRL_HEAD = pipe_head;
      usb_host_ptr->CURRENT_CTRL_TAIL = pipe_tail;
   } else if (pipe_descr_ptr->PIPETYPE == USB_BULK_PIPE) {
      usb_host_ptr->CURRENT_BULK_HEAD = pipe_head;
      usb_host_ptr->CURRENT_BULK_TAIL = pipe_tail;
   } /* Endif */

   USB_unlock();
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_queue_pkts, SUCCESSFUL");
   #endif
   
} /* EndBody */      


/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_update_current_head
*  Returned Value : None
*  Comments       :
*        Update the respective (based on the pipe type) Queue Head
*END*-----------------------------------------------------------------*/

void _usb_host_update_current_head
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle           handle,
      
      /* [IN] The pipe type */
      uint_8 pipetype
   )
{ /* Body */
   PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr;
   int_16 pipe_head, pipe_tail;
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_update_current_head");
   #endif
   
   USB_lock();
   
   pipe_descr_ptr = NULL;

   if (pipetype == USB_ISOCHRONOUS_PIPE) {
      /* Check if the type of queue is empty */
      if (usb_host_ptr->CURRENT_ISO_HEAD != -1) {
         pipe_descr_ptr = 
            &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
            [usb_host_ptr->CURRENT_ISO_HEAD];
      } /* Endif */
      
      /* Initialize the new queue head and tail */
      pipe_head = usb_host_ptr->CURRENT_ISO_HEAD;
      pipe_tail = usb_host_ptr->CURRENT_ISO_TAIL;
   } else if (pipetype == USB_INTERRUPT_PIPE) {
      /* Check if the type of queue is empty */
      if (usb_host_ptr->CURRENT_INTR_HEAD != -1) {
         pipe_descr_ptr = 
            &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
            [usb_host_ptr->CURRENT_INTR_HEAD];
      } /* Endif */
      
      /* Initialize the new queue head and tail */
      pipe_head = usb_host_ptr->CURRENT_INTR_HEAD;
      pipe_tail = usb_host_ptr->CURRENT_INTR_TAIL;
   } else if (pipetype == USB_CONTROL_PIPE) {
      /* Check if the type of queue is empty */
      if (usb_host_ptr->CURRENT_CTRL_HEAD != -1) {
         pipe_descr_ptr = 
            &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
            [usb_host_ptr->CURRENT_CTRL_HEAD];
      } /* Endif */
      
      /* Initialize the new queue head and tail */
      pipe_head = usb_host_ptr->CURRENT_CTRL_HEAD;
      pipe_tail = usb_host_ptr->CURRENT_CTRL_TAIL;
   } else if (pipetype == USB_BULK_PIPE) {
      /* Check if the type of queue is empty */
      if (usb_host_ptr->CURRENT_BULK_HEAD != -1) {
         pipe_descr_ptr = &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
         [usb_host_ptr->CURRENT_BULK_HEAD];
      } /* Endif */
      /* Initialize the new queue head and tail */
      pipe_head = usb_host_ptr->CURRENT_BULK_HEAD;
      pipe_tail = usb_host_ptr->CURRENT_BULK_TAIL;
   } /* Endif */

   /* Check if another pipe was found on the respective type queue */
   if (pipe_descr_ptr) {
      /* Check if there is another pipe after this */
      if (pipe_descr_ptr->NEXT_PIPE != -1) {
         if ((pipe_descr_ptr->STATUS != USB_STATUS_IDLE) && 
            (pipe_tail != -1)) 
         {
            usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR[pipe_tail].NEXT_PIPE = 
               pipe_head;
            pipe_tail = pipe_head;
         } /* Endif */
         /* Initialize the new pipe head */
         pipe_head = pipe_descr_ptr->NEXT_PIPE;
         if (pipe_tail != -1) {
            usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR[pipe_tail].NEXT_PIPE = -1;
         } /* Endif */
      } else {
         if (pipe_descr_ptr->STATUS == USB_STATUS_IDLE) {
            pipe_head = -1;
            pipe_tail = -1;
         } /* Endif */
      } /* Endif */
   } /* Endif */

   /* Update the new heads and tails of the respective pipes types */   
   if (pipetype == USB_ISOCHRONOUS_PIPE) {
      usb_host_ptr->CURRENT_ISO_HEAD = pipe_head;
      usb_host_ptr->CURRENT_ISO_TAIL = pipe_tail;
   } else if (pipetype == USB_INTERRUPT_PIPE) {
      usb_host_ptr->CURRENT_INTR_HEAD = pipe_head;
      usb_host_ptr->CURRENT_INTR_TAIL = pipe_tail;
   } else if (pipetype == USB_CONTROL_PIPE) {
      usb_host_ptr->CURRENT_CTRL_HEAD = pipe_head;
      usb_host_ptr->CURRENT_CTRL_TAIL = pipe_tail;
   } else if (pipetype == USB_BULK_PIPE) {
      usb_host_ptr->CURRENT_BULK_HEAD = pipe_head;
      usb_host_ptr->CURRENT_BULK_TAIL = pipe_tail;
   } /* Endif */

   USB_unlock();
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_update_current_head, SUCCESSFUL");
   #endif
      
} /* Endbody */


/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_update_interval_for_pipes
*  Returned Value : None
*  Comments       :
*        Update the interval for the interrupt pipe
*END*-----------------------------------------------------------------*/

void _usb_host_update_interval_for_pipes
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle           handle
   )
{ /* Body */
#ifdef V8
   static PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr;
#else
   PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr;
#endif
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_update_interval_for_pipes");
   #endif
   
   USB_lock();

   /* Check if there are any Interrupt pipes on the Interrupt pipe queue */
   if (usb_host_ptr->CURRENT_INTR_HEAD != -1) {
      pipe_descr_ptr = 
         &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
         [usb_host_ptr->CURRENT_INTR_HEAD];
      _usb_host_update_current_interval_on_queue((pointer)usb_host_ptr, pipe_descr_ptr);
   } /* Endif */
   
   /* Check if any control pipes are NAK deferred */
   if (usb_host_ptr->CURRENT_CTRL_HEAD != -1) {
      pipe_descr_ptr = 
         &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
         [usb_host_ptr->CURRENT_CTRL_HEAD];
      _usb_host_update_current_interval_on_queue((pointer)usb_host_ptr, pipe_descr_ptr);
   } /* Endif */
   
   /* Check if any bulk pipes are NAK deferred */
   if (usb_host_ptr->CURRENT_BULK_HEAD != -1) {
      pipe_descr_ptr = 
         &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
         [usb_host_ptr->CURRENT_BULK_HEAD];
      _usb_host_update_current_interval_on_queue((pointer)usb_host_ptr, pipe_descr_ptr);
   } /* Endif */

   USB_unlock();
   
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_update_interval_for_pipes, SUCCESSFUL");
   #endif
  
} /* EndBody */      


/*FUNCTION*----------------------------------------------------------------
* 
* Function Name  : _usb_host_process_detach
* Returned Value : 
* Comments       :
*     This function will be called as default when detach interrupt happens.
* 
*END*--------------------------------------------------------------------*/
void _usb_host_process_detach
   (
      _usb_host_handle  handle,
      uint_32           length
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR                 usb_host_ptr;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_process_detach");
   #endif
     
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   if ((_usb_host_check_service((pointer)usb_host_ptr, 
            USB_SERVICE_DETACH, 0)) == USB_OK) 
   {
      _usb_host_call_service(usb_host_ptr, USB_SERVICE_DETACH, 0);
   } else {
      /* call device detach (host pointer, speed, hub #, port #) */
      usb_dev_list_detach_device((pointer)usb_host_ptr, 0, 0);
   } /* Endif */

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_process_detach, SUCCESSFUL");
   #endif
    

} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_hci_vusb11_send_data
*  Returned Value : None
*  Comments       :
*        Send the data
*END*-----------------------------------------------------------------*/

void _usb_hci_vusb11_send_data
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,

      /* The pipe descriptor to queue */            
      PIPE_DESCRIPTOR_STRUCT_PTR     pipe_descr_ptr
   )
{ /* Body */
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_send_data");
   #endif

   _usb_host_queue_pkts(handle, pipe_descr_ptr);
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_send_data, SUCCESSFUL");
   #endif
   
} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_hci_vusb11_send_setup
*  Returned Value : None
*  Comments       :
*        Send Setup packet
*END*-----------------------------------------------------------------*/

void _usb_hci_vusb11_send_setup
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,

      /* The pipe descriptor to queue */            
      PIPE_DESCRIPTOR_STRUCT_PTR     pipe_descr_ptr
   )
{ /* Body */
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_send_setup");
   #endif

   _usb_host_queue_pkts(handle, pipe_descr_ptr);

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_send_setup, SUCCESSFUL");
   #endif
   
} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_hci_vusb11_recv_data
*  Returned Value : None
*  Comments       :
*        Receive data
*END*-----------------------------------------------------------------*/

void _usb_hci_vusb11_recv_data
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,

      /* The pipe descriptor to queue */            
      PIPE_DESCRIPTOR_STRUCT_PTR     pipe_descr_ptr
   )
{ /* Body */

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_recv_data");
   #endif

   _usb_host_queue_pkts(handle, pipe_descr_ptr);
   
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_recv_data, SUCCESSFUL");
   #endif
   
} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_hci_vusb11_cancel_transfer
*  Returned Value : None
*  Comments       :
*        Cancel a transfer
*END*-----------------------------------------------------------------*/

void _usb_hci_vusb11_cancel_transfer
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,

      /* The pipe descriptor to queue */            
      PIPE_DESCRIPTOR_STRUCT_PTR     pipe_descr_ptr
   )
{ /* Body */
   /* Cancel the transaction at hardware level if required */
} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_set_bdt_page
*  Returned Value : None
*  Comments       :
*        Initialize the VUSB BDT Page register
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_set_bdt_page
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR     usb_host_ptr;
   USB_STRUCT_PTR     dev_ptr;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_set_bdt_page");
   #endif
   
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
      dev_ptr = (USB_STRUCT_PTR)usb_host_ptr->DEV_PTR;
   
   dev_ptr->BDTPAGE1 =
      (((uint_32)usb_host_ptr->USB_BDT_PAGE) >> 8);
   dev_ptr->BDTPAGE2 =
      (((uint_32)usb_host_ptr->USB_BDT_PAGE) >> 16);
   dev_ptr->BDTPAGE3 =
      (((uint_32)usb_host_ptr->USB_BDT_PAGE) >> 24);

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_set_bdt_page, SUCCESSFUL");
   #endif
      
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_get_next_in_bdt
*  Returned Value : Address of the next IN BDT to use
*  Comments       :
*        Get the address of the next IN BDT
*END*-----------------------------------------------------------------*/

HOST_BDT_STRUCT_PTR _usb_host_vusb11_get_next_in_bdt
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle
   )
{ /* Body */                                   
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_get_next_in_bdt");
   #endif
   
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   usb_host_ptr->USB_IN ^= VUSB_BDT_ODD_EVEN_BIT;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_get_next_in_bdt, SUCCESSFUL");
   #endif
   return ((HOST_BDT_STRUCT_PTR)((uint_32)usb_host_ptr->USB_BDT_PAGE | 
      usb_host_ptr->USB_IN));
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_get_next_out_bdt
*  Returned Value : Address of the next OUT BDT to use
*  Comments       :
*        Get the address of the next OUT BDT
*END*-----------------------------------------------------------------*/

HOST_BDT_STRUCT_PTR _usb_host_vusb11_get_next_out_bdt
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle
   )
{ /* Body */                                   
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_get_next_out_bdt");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   /* toggle odd/even and use result */   
   usb_host_ptr->USB_OUT ^= VUSB_BDT_ODD_EVEN_BIT;
   /* create pointer to current out bdt */
   
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_get_next_out_bdt, SUCCESSFUL");
   #endif

   return ((HOST_BDT_STRUCT_PTR)((uint_32)usb_host_ptr->USB_BDT_PAGE | 
      usb_host_ptr->USB_OUT));
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_sched_pending_pkts
*  Returned Value : None
*  Comments       :
*        Schedule the pending packets based on the types (not for isochronous 
*  packets)
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_sched_pending_pkts
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle           handle
   )
{ /* Body */
   PIPE_DESCRIPTOR_STRUCT_PTR    pipe_descr_ptr;
   boolean sched_int_pipe, sched_ctrl_pipe, sched_bulk_pipe;
   
   USB_HOST_STATE_STRUCT_PTR  usb_host_ptr;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_sched_pending_pkts");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   /* The original schedule scheme intends to schedule two transfers at once to use
    * hardware double buffer. But, since our software use only one "CURRENT_PIPE_ID"
    * and hardware does not provide any assistance on which pipe is current, there is
    * no way we can use that double buffer unless we make change on software. For now,
    * we only schedule one transfer and use "TOKEN_DONE" to schedule multiple transfer
    * within one USB frame.
    */
   sched_int_pipe = FALSE;
   sched_ctrl_pipe = FALSE;
   sched_bulk_pipe = FALSE;
   pipe_descr_ptr = &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
      [usb_host_ptr->CURRENT_INTR_HEAD];
   if ((usb_host_ptr->CURRENT_INTR_HEAD != -1) && 
       (!pipe_descr_ptr->CURRENT_INTERVAL)) {       
		sched_int_pipe = TRUE;
      pipe_descr_ptr->CURRENT_INTERVAL = pipe_descr_ptr->INTERVAL;
   } else if (usb_host_ptr->CURRENT_CTRL_HEAD != -1) {
  		sched_ctrl_pipe = TRUE;
      pipe_descr_ptr = &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
               [usb_host_ptr->CURRENT_CTRL_HEAD];
   } else if (usb_host_ptr->CURRENT_BULK_HEAD != -1) {
  		sched_bulk_pipe = TRUE;
      pipe_descr_ptr = &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
            [usb_host_ptr->CURRENT_BULK_HEAD];
   } /* Endif */
      
   /* Initiate the appropriate transfer and update the current head of the 
   ** respective pipe 
   */
   if (sched_int_pipe || sched_ctrl_pipe || sched_bulk_pipe) { 
      _usb_host_vusb11_initiate_correct_bdt(handle, pipe_descr_ptr);
      _usb_host_update_current_head(handle, pipe_descr_ptr->PIPETYPE);
   } /* Endif */

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_sched_pending_pkts, SUCCESSFUL");
   #endif
   
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_sched_iso_pkts
*  Returned Value : None
*  Comments       :
*        Schedule the pending Isochronous packets
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_sched_iso_pkts
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle           handle
   )
{ /* Body */
   PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr, temp;
   uint_8 i;
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_sched_iso_pkts");
   #endif
   

   /* Schedule 2 transfers if they are on different pipes */
   for (i=0;i<2;i++) {
      if (usb_host_ptr->CURRENT_ISO_HEAD != -1) {
         pipe_descr_ptr = 
            &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
            [usb_host_ptr->CURRENT_ISO_HEAD];
         /* Initiate the appropriate transfer and update the current head for 
         ** that pipe type queue 
         */
         if (!(i && (temp == pipe_descr_ptr))) {
            temp = pipe_descr_ptr;
            _usb_host_vusb11_initiate_correct_bdt(handle, pipe_descr_ptr);
            _usb_host_update_current_head(handle, pipe_descr_ptr->PIPETYPE);
         } /* Endif */
      } else {
         break;
      } /* Endif */
   } /* Endfor */
   
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_sched_iso_pkts, SUCCESSFUL");
   #endif
   
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_initiate_correct_bdt
*  Returned Value : None
*  Comments       :
*        Initiate the correct BDT while scheduling
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_initiate_correct_bdt
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle                  handle,
            
      /* [IN] the pipe descriptor address */
      PIPE_DESCRIPTOR_STRUCT_PTR        pipe_descr_ptr
   )
{ /* Body */

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_initiate_correct_bdt");
   #endif

   /* Check if a packet is pending on this pipe */   
   if (pipe_descr_ptr->PACKETPENDING) {
      if (pipe_descr_ptr->PIPETYPE == USB_CONTROL_PIPE) {
         if (pipe_descr_ptr->FIRST_PHASE) {
            _usb_host_vusb11_init_setup_bdt(handle, pipe_descr_ptr);
         } else {
            if (pipe_descr_ptr->SEND_PHASE) {
               if (!pipe_descr_ptr->TODO2) { /* Complete */
                  /* Setup transaction complete. Send an opposite 
                  ** direction token on Data1 
                  */
                  _usb_host_vusb11_send_in_token(handle, pipe_descr_ptr);
               } else { /* partial */
                  /* Setup transaction not complete. Send more data */
                  _usb_host_vusb11_send_out_token(handle, pipe_descr_ptr);
               } /* Endif */
            } else {
               if (!pipe_descr_ptr->TODO1) { /* Complete */
                  /* Setup transaction complete. Send an opposite 
                  ** direction token on Data1 
                  */
                  _usb_host_vusb11_send_out_token(handle, pipe_descr_ptr);
               } else { /* partial */
                  _usb_host_vusb11_send_in_token(handle, pipe_descr_ptr);
               } /* Endif */
            } /* Endif */
         } /* Endif */
      } else { 
         if (pipe_descr_ptr->DIRECTION == USB_SEND) {
            _usb_host_vusb11_init_send_bdt(handle, pipe_descr_ptr);
         } else {
            _usb_host_vusb11_init_recv_bdt(handle, pipe_descr_ptr);
         } /* Endif */
      } /* Endif */
   } /* Endif */
   
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_initiate_correct_bdt, SUCCESSFUL");
   #endif
   
} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_hci_vusb11_isr
*  Returned Value : None
*  Comments       :
*        Service all the interrupts in the VUSB1.1 hardware
*END*-----------------------------------------------------------------*/

#ifdef __USB_OS_MQX__
void _usb_hci_vusb11_isr
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle
   )
#else
void HOST_INTERRUPT_ROUTINE_KEYWORD _usb_hci_vusb11_isr
   (
      void
   )
#endif
{ /* Body */
   uint_8 status_flag = 0, direction;
   PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr = NULL;
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;
   USB_STRUCT_PTR    dev_ptr;
   
   uint_32  status, error_status;
   
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_isr");
   #endif
   
   
#ifdef __USB_OS_MQX__
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
#else
#ifndef __USB_OTG__
   IN_ISR = TRUE;
#endif
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)usb_host_state_struct_ptr;
#endif

      dev_ptr = (USB_STRUCT _PTR_)usb_host_ptr->DEV_PTR;

   /* We use a while loop to process all the interrupts while we are in the 
   ** loop so that we don't miss any interrupts 
   */
   
   while (TRUE) {

      /* Check the error status */
      error_status = (dev_ptr->ERRORSTATUS & dev_ptr->ERRORENABLE);
      
      /* Clear the errors */   
      dev_ptr->ERRORSTATUS = error_status;

      /* Check if any of the enabled interrupts are asserted */
      status = (dev_ptr->INTSTATUS & dev_ptr->INTENABLE);

      if (!status) {
         /* No more interrupts pending to be serviced */
         break;
      } /* Endif */

      /* Get the direction of the transfer */      
      direction = ((dev_ptr->STATUS >> VUSB_STAT_DIRECTION_BIT) & 
         0x01);
      
      /* Clear all enabled interrupts */
      dev_ptr->INTSTATUS = status;

      /* Check if Reset interrupt */      
      if (status & VUSB_INT_STAT_RESET) {
         dev_ptr->INTENABLE = (VUSB_INT_ENB_ATTACH | 
            VUSB_INT_ENB_SOF_TOK);
         _usb_host_vusb11_process_attach((pointer)usb_host_ptr);
         return ;
      } else {
         /* Check if token done interrupt */      
         if (status & VUSB_INT_STAT_TOKEN_DONE) {
            usb_host_ptr->USB_PKT_PENDING--;
            usb_host_ptr->SND_TOK_IN_PROGRESS = FALSE;
            
            _usb_host_vusb11_process_token_done((pointer)usb_host_ptr, 
               direction, error_status);
            /* If there are no packet being processed then schedule any other 
            ** pending packets (except the isochronous transactions) 
            */
            if ((!usb_host_ptr->SND_TOK_IN_PROGRESS) && 
               !(status & VUSB_INT_STAT_SOF) && 
               (usb_host_ptr->TOKEN_TRANSFER_NUM < MAX_TOKEN_TRANSFER_NUM)) 
            {
               usb_host_ptr->TOKEN_TRANSFER_NUM++;
               _usb_host_vusb11_sched_pending_pkts((pointer)usb_host_ptr);
            } /* Endif */
            
         } /* Endif */
         
         if (status & VUSB_INT_STAT_SOF) {
            usb_host_ptr->TOKEN_TRANSFER_NUM = 0;
            /* Schedule Isochronous transfer everytime there is a SOF 
            ** interrupt 
            */
            if (usb_host_ptr->RESUME_TIMER) {
               usb_host_ptr->RESUME_TIMER--;
               if (!usb_host_ptr->RESUME_TIMER) {
                  dev_ptr->CONTROL &= ~VUSB_CTRL_RESUME;
               } /* Endif */
            } /* Endif */

            if (!usb_host_ptr->SND_TOK_IN_PROGRESS) {
               _usb_host_vusb11_sched_iso_pkts((pointer)usb_host_ptr);
            } /* Endif */
            
            /* Update the current interval on the interrupt pipes if any on the 
            ** interrupt pipe queue
            */
            _usb_host_update_interval_for_pipes((pointer)usb_host_ptr);
            
            if (!usb_host_ptr->SND_TOK_IN_PROGRESS) {
               _usb_host_vusb11_sched_pending_pkts((pointer)usb_host_ptr);
            } /* Endif */
         } /* Endif */

         /* Check if attach interrupt */      
         if (status & VUSB_INT_STAT_ATTACH) {
            _usb_host_vusb11_process_attach((pointer)usb_host_ptr);
         } /* Endif */
         
         if (status & VUSB_INT_STAT_RESUME) {
            /* Call the callback function if there was one registered for 
            ** the remote-wakeup/resume 
            */
            dev_ptr->INTENABLE &= ~VUSB_INT_ENB_RESUME;
            _usb_host_call_service((pointer)usb_host_ptr, USB_SERVICE_HOST_RESUME, 0);
            dev_ptr->CONTROL |= VUSB_CTRL_RESUME;
            usb_host_ptr->RESUME_TIMER = USB_RESUME_DELAY;
         } /* Endif */

         if (status & VUSB_INT_STAT_STALL) {
            _usb_host_call_service((pointer)usb_host_ptr, USB_SERVICE_STALL_PACKET, 0);
            /* Find the pipe on which the stall occurred */
            pipe_descr_ptr = &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR[usb_host_ptr->CURRENT_PIPE_ID];


            if (pipe_descr_ptr->TR.CALLBACK) {
               pipe_descr_ptr->TR.CALLBACK(pipe_descr_ptr,
                  pipe_descr_ptr->TR.CALLBACK_PARAM,
                  direction == USB_RECV ? pipe_descr_ptr->TR.RX_BUFFER : pipe_descr_ptr->TR.TX_BUFFER,
                  pipe_descr_ptr->SOFAR,
                  USBERR_ENDPOINT_STALLED);
            } /* Endif */

            pipe_descr_ptr->STATUS = USB_STATUS_IDLE;
            _usb_host_update_current_head((pointer)usb_host_ptr, pipe_descr_ptr->PIPETYPE);
         } /* Endif */
         
      } /* Endif */
   } /* EndWhile */

#ifndef __USB_OS_MQX__   
#ifndef __USB_OTG__
   IN_ISR = FALSE;
#endif
#endif

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_isr, SUCCESSFUL");
   #endif
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_hci_vusb11_init
*  Returned Value : error or USB_OK
*  Comments       :
*        Initialize the VUSB1.1 hardware
*END*-----------------------------------------------------------------*/

uint_8  _usb_hci_vusb11_init
   (
      /* the USB Host State structure */
      _usb_host_handle     handle
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR     usb_host_ptr;
   USB_STRUCT_PTR     dev_ptr;
   USB_REGISTER_PTR   endpt_reg;
   uint_8   vector;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_init");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   /* Allocate memory for the Buffer descriptor table */   
   usb_host_ptr->USB_BDT_PAGE_BASE = 
      (HOST_BDT_STRUCT_PTR)USB_Uncached_memalloc((sizeof(HOST_BDT_STRUCT) * 2 * 2) + 512);
      
   if (usb_host_ptr->USB_BDT_PAGE_BASE == NULL) 
   {
      #ifdef _HOST_DEBUG_
            DEBUG_LOG_TRACE("_usb_hci_vusb11_init, malloc failed");
      #endif
      return USBERR_ALLOC;
   } /* Endif */
   
   /* Align the BDT page on a 512 byte boundary */      
   usb_host_ptr->USB_BDT_PAGE = (HOST_BDT_STRUCT_PTR)USB_MEM512_ALIGN\
      ((uint_32)usb_host_ptr->USB_BDT_PAGE_BASE);

   #ifdef _DATA_CACHE_   
   
   /******************************************************
   Memzero the BDT to ensure that BDT is initialized.
   ******************************************************/
   USB_memzero((void *)usb_host_ptr->USB_BDT_PAGE, 
               (sizeof(HOST_BDT_STRUCT) * 2 * 2));   

   /******************************************************
   Flush 1 cache line of the BDT to ensure that memory is updated.
   ******************************************************/
   USB_dcache_flush_mlines((void *)usb_host_ptr->USB_BDT_PAGE,1);
   
   #endif
         
   /* Allocate memory for internal structure */   
      usb_host_ptr->USB_BUFFERED_BDT_PTR = 
      (HOST_BDT_STRUCT_PTR)USB_Uncached_memalloc(sizeof(HOST_BDT_STRUCT));
      
   if (usb_host_ptr->USB_BUFFERED_BDT_PTR == NULL) {
      #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_init, malloc failed");
      #endif
      return USBERR_ALLOC;
   } /* Endif */
   
   
   usb_host_ptr->USB_NEXT_BUFFERED_BDT_PTR = 
      (HOST_BDT_STRUCT_PTR)USB_Uncached_memalloc(sizeof(HOST_BDT_STRUCT));
      
   if (usb_host_ptr->USB_NEXT_BUFFERED_BDT_PTR == NULL) 
   {
      #ifdef _HOST_DEBUG_
            DEBUG_LOG_TRACE("_usb_hci_vusb11_init, malloc failed");
      #endif
      return USBERR_ALLOC;
   } /* Endif */
   
   usb_host_ptr->USB_TEMP_SND_BDT_PTR = 
      (HOST_BDT_STRUCT_PTR)USB_Uncached_memalloc(sizeof(HOST_BDT_STRUCT));
      
   if (usb_host_ptr->USB_TEMP_SND_BDT_PTR == NULL) 
   {
      #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_init, malloc failed");
      #endif
      return USBERR_ALLOC;
   } /* Endif */
   
   usb_host_ptr->USB_TEMP_RCV_BDT_PTR = 
      (HOST_BDT_STRUCT_PTR)USB_Uncached_memalloc(sizeof(HOST_BDT_STRUCT));
      
   if (usb_host_ptr->USB_TEMP_RCV_BDT_PTR == NULL) 
   {
      #ifdef _HOST_DEBUG_
            DEBUG_LOG_TRACE("_usb_hci_vusb11_init, malloc failed");
      #endif
      return USBERR_ALLOC;
   } /* Endif */

   /* Get the base address of the VUSB registers */
   usb_host_ptr->DEV_PTR = _bsp_get_usb_base(usb_host_ptr->DEV_NUM);
      
   dev_ptr = (USB_STRUCT_PTR)usb_host_ptr->DEV_PTR;

   /* The address of the endpoint registers */      
   usb_host_ptr->ENDPT_HOST_RG = (pointer)((uchar_ptr)usb_host_ptr->DEV_PTR + 
      VUSB_ENDPT_REG_OFFSET);
      
   endpt_reg = (USB_REGISTER_PTR)usb_host_ptr->ENDPT_HOST_RG;
   
   *endpt_reg = VUSB_ENDPT_DISABLE;
   dev_ptr->CONTROL = 0x00;        /* Disable VUSB */
   dev_ptr->INTENABLE = 0x00; /* Mask all interupts */
   dev_ptr->INTSTATUS = 0xFF;   /* Clear all interupts */
   dev_ptr->ADDRESS = 0;

   /* Set the Buffer Descriptor Table address */
   _usb_host_vusb11_set_bdt_page(handle);
   
   /* Get the interrupt vector number for the VUSB host */
   vector = _bsp_get_usb_vector(usb_host_ptr->DEV_NUM);

#ifndef __USB_OTG__

#ifdef __USB_OS_MQX__
   if (!(USB_install_isr(vector, _usb_hci_vusb11_isr, (pointer)usb_host_ptr))) 
   {
      #ifdef _HOST_DEBUG_
            DEBUG_LOG_TRACE("_usb_hci_vusb11_init, install ISR failed");
      #endif
      return USBERR_INSTALL_ISR;
   } /* Endbody */
#else
   USB_install_isr(vector, _usb_hci_vusb11_isr, 
      (pointer)usb_host_ptr);
#endif /* USB_OS_MQX */

#endif /* ARC_USB_OTG */

   /* Enable the host mode */   
   dev_ptr->CONTROL = VUSB_CTRL_HOST_MODE_EN;

   /* Typical value for 64 bytes packets is 74 so we keep enough time for 
   ** the transaction to complete 
   */
   dev_ptr->SOFTHRESHOLDLO = 74;
   
   /* Enable Attach interrupt only */                                          
   dev_ptr->INTENABLE = VUSB_INT_ENB_ATTACH;

   /* controller should be enabled always */
   /* Enable host mode and start generating SOFs */   

   dev_ptr->CONTROL = (VUSB_CTRL_ODD_RST | VUSB_CTRL_HOST_MODE_EN | VUSB_CTRL_USB_EN);

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_hci_vusb11_init, SUCCESSFUL");
   #endif
   
   return USB_OK;
   
} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_delay
*  Returned Value : None
*  Comments       :
*        Delay for specified number of milliseconds.
*END*-----------------------------------------------------------------*/

void _usb_host_delay
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,
      
      /* [IN] time to wait in ms */
      uint_32 delay
   )
{ /* Body */
   uint_32 delay_count;
   OTG_STATE_MACHINE_STRUCT_PTR  s_ptr;
   OTG_STRUCT_PTR     otg_reg;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_delay");
   #endif
   
   s_ptr = otg_handle->STATE_STRUCT_PTR;
   otg_reg = otg_handle->OTG_REG_PTR;

   delay_count = delay;

   /************************************************************
   When we arrive in host delay, there might already be other
   OTG timers running. So we should not START or STOP
   timer interrupt. This happens when some spurious signals on
   the bus cause a attach and A_WAIT_BECON timer is running
   because device is gone. That timer will stop if we 
   call STOP timer. This will cause OTG state machine to
   never return in A_IDLE state. Sgarg 11/18/2003
   ************************************************************/
   
   /* Forced to use OTG timer because no other timer available 
   start the timer only if timer is not already running.*/
   if(IS_OTG_TIMER_RUNNING(otg_reg))
   {
      while (delay_count) {
         if (otg_reg->OTG_INT_STAT & OTG_STAT_1_MSEC_VLD) {
            /* Clear the interrupt */
            otg_reg->OTG_INT_STAT = OTG_STAT_1_MSEC_VLD;
            delay_count--;
         } /* Endif */   
      } /* Endwhile */
   }
   else
   {
      START_TIMER(otg_reg);

      while (delay_count) {
         if (otg_reg->OTG_INT_STAT & OTG_STAT_1_MSEC_VLD) {
            /* Clear the interrupt */
            otg_reg->OTG_INT_STAT = OTG_STAT_1_MSEC_VLD;
            delay_count--;
         } /* Endif */   
      } /* Endwhile */
   
      STOP_TIMER(otg_reg);
   }

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_delay, SUCCESSFUL");
   #endif

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_reset_the_device
*  Returned Value : None
*  Comments       :
*        Reset the device after it is attached to the host
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_reset_the_device
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR     usb_host_ptr;
   USB_STRUCT_PTR     dev_ptr;

   
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_reset_the_device");
   #endif

   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   dev_ptr = (USB_STRUCT_PTR)usb_host_ptr->DEV_PTR;

#ifdef __USB_OTG__
   /* For OPT: Wait for 1 millisecond before starting the reset process */
   /* _usb_host_delay(handle, 0); */
#endif
   
   /* assert reset on the USB */
   dev_ptr->CONTROL = (VUSB_CTRL_HOST_MODE_EN | VUSB_CTRL_RESET);
   
   /* Delay for the reset process to complete */
   _usb_host_delay(handle, USB_RESET_DELAY);
   
   /* End the reset */
   dev_ptr->CONTROL = VUSB_CTRL_HOST_MODE_EN;
   
   /* Enable host mode and start generating SOFs */   
   dev_ptr->CONTROL = (VUSB_CTRL_HOST_MODE_EN | VUSB_CTRL_USB_EN);

   /* Delay for the reset recovery period */
   _usb_host_delay(handle, USB_RESET_RECOVERY_DELAY);   
   
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_reset_the_device, SUCCESFUL");
   #endif

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_process_attach
*  Returned Value : None
*  Comments       :
*        Process the VUSB Attach interrupt
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_process_attach
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle
   )
{ /* Body */
   uint_32  b;
   USB_HOST_STATE_STRUCT_PTR     usb_host_ptr;
   USB_STRUCT_PTR     dev_ptr;

   USB_REGISTER_PTR   endpt_rg;
   uint_32                       speed=0;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_process_attach");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   dev_ptr = (USB_STRUCT_PTR)usb_host_ptr->DEV_PTR;
   endpt_rg = (USB_REGISTER_PTR)usb_host_ptr->ENDPT_HOST_RG;

   dev_ptr->ERRORENABLE = 0xff;          /* enable all errors */

   /* Zero the control register. It is okay to do this because JSTATE 
   ** and SE0 are read-only bits 
   */
   dev_ptr->CONTROL = VUSB_CTRL_HOST_MODE_EN;

#ifdef __USB_OTG__
   if ((otg_handle->STATE_STRUCT_PTR->STATE != A_SUSPEND) && 
      (otg_handle->STATE_STRUCT_PTR->STATE != B_WAIT_ACON)) 
  {
      /* Delay for the debounce interval */   
      _usb_host_delay(handle, USB_DEBOUNCE_DELAY + 1);
   } /* Endif */
#endif

   /* Check if the device is attached or detached */
   b = dev_ptr->CONTROL;

   if (b & VUSB_CTRL_SINGLE_ENDED_0) {
      _usb_host_vusb11_process_detach(handle);
      #ifdef _HOST_DEBUG_
            DEBUG_LOG_TRACE("_usb_host_vusb11_process_attach, device gone");
      #endif
      return;
   } /* Endif */
   
   dev_ptr->CONTROL = VUSB_CTRL_HOST_MODE_EN;
   
   /* check the low speed bit */   
   if (dev_ptr->ADDRESS & VUSB_ADDR_LS_EN) {
      /* currently low speed */
      if (b & VUSB_CTRL_JSTATE) {
         usb_host_ptr->SPEED = USB_SPEED_LOW;
         usb_host_ptr->NO_HUB = VUSB_ENDPT_CTL_HOST_WO_HUB;
      } else {
         usb_host_ptr->SPEED = USB_SPEED_FULL;
         usb_host_ptr->NO_HUB = 0;  /* if we see a full speed device there 
                                    ** may be a hub. 
                                    */
      } /* Endif */
   } else { /* currently high speed */
      if (b & VUSB_CTRL_JSTATE) {
         /* Full-speed device */
         usb_host_ptr->SPEED = USB_SPEED_FULL;
         usb_host_ptr->NO_HUB = 0x00;
         
         /* Tell VUSB that we have a high-speed device */
         dev_ptr->ADDRESS = 0x00;
      } else {
         /* Low-speed device */
         usb_host_ptr->SPEED = USB_SPEED_LOW;
         
         /* if we see a low speed device there is no hub. */
         usb_host_ptr->NO_HUB = VUSB_ENDPT_CTL_HOST_WO_HUB;
         
         /* Tell VUSB that we have a low-speed device */
         dev_ptr->ADDRESS = VUSB_ADDR_LS_EN;
      } /* Endif */
   } /* Endif */

   /* enable ep0 */   
   *endpt_rg = (VUSB_ENDPT_CONTROL | usb_host_ptr->NO_HUB);
   
   /* Reset the device */
   _usb_host_vusb11_reset_the_device(handle);

   /* Clear the attach and reset interrupt */   
   dev_ptr->INTSTATUS = (VUSB_INT_STAT_ATTACH | 
      VUSB_INT_STAT_RESET);

   /* Enable the token done, SOF and reset interrupts */   
   
   dev_ptr->INTENABLE = (VUSB_INT_ENB_TOK_DNE | 
      VUSB_INT_ENB_USB_RST | VUSB_INT_ENB_SOF_TOK | 
      VUSB_INT_ENB_STALL); 
   
   
   /* Set the Odd data out */
   usb_host_ptr->USB_OUT = (VUSB_BDT_ODD_EVEN_BIT |
      VUSB_BDT_OUT_BIT);
   
   /* Set the Odd data In */
   usb_host_ptr->USB_IN = (VUSB_BDT_ODD_EVEN_BIT |
     VUSB_BDT_IN_BIT);

   /* Call the callback function of there was one register for the attach 
   ** event 
   */
   /* call device attach (host pointer, speed, hub #, port #) */
   if ((_usb_host_check_service((pointer)usb_host_ptr, 
      USB_SERVICE_ATTACH, usb_host_ptr->SPEED)) == USB_OK) 
   {
      _usb_host_call_service(usb_host_ptr, USB_SERVICE_ATTACH, 
         usb_host_ptr->SPEED);
   } else {
      usb_dev_list_attach_device((pointer)usb_host_ptr, 
         usb_host_ptr->SPEED, 0, 0);
   } /* Endif */ 

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_process_attach, SUCCESSFUL");
   #endif
   
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_process_detach
*  Returned Value : None
*  Comments       :
*        Process the VUSB Detach event
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_process_detach
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR     usb_host_ptr;
   USB_STRUCT_PTR     dev_ptr;
   USB_REGISTER_PTR   endpt_reg;
   uint_32                       speed=0;
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_process_detach");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   dev_ptr = (USB_STRUCT_PTR)usb_host_ptr->DEV_PTR;
   endpt_reg = (USB_REGISTER_PTR)usb_host_ptr->ENDPT_HOST_RG;

   /* Cancel if there are any pending tokens */
   usb_host_ptr->SND_TOK_IN_PROGRESS = FALSE;

   /* Set the Buffer Descriptor Table address */
   _usb_host_vusb11_set_bdt_page((pointer)usb_host_ptr);

   /* Reset all the attached device specific values */
   dev_ptr->ADDRESS = 0;
   usb_host_ptr->SPEED = 0x00;  /* causes speed bit to be cleared */
   usb_host_ptr->NO_HUB = 0x00; /* hub bit cleared */
   *endpt_reg = (VUSB_ENDPT_CONTROL | usb_host_ptr->NO_HUB);   /* enable ep0 */

   /* Set the ODD/EVEN BDT to even and enable the host mode */   
   dev_ptr->CONTROL = VUSB_CTRL_ODD_RST;
   dev_ptr->CONTROL = VUSB_CTRL_HOST_MODE_EN;
   
   /* Clear all interrupts */
   dev_ptr->INTSTATUS = 0xFF;
   
   /* Enable attach interrupt */
   dev_ptr->INTENABLE = VUSB_INT_ENB_ATTACH;
   
   /* Call the callback function if there was one registered for a detach 
   ** event 
   */
   speed = usb_host_ptr->SPEED;
   _usb_host_process_detach((pointer)usb_host_ptr, speed);

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_process_detach, SUCCESSFUL");
   #endif
   
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_send_in_token
*  Returned Value : None
*  Comments       :
*        Send the IN token to receive data after the first phase of Setup 
*  transaction is complete. This routine is also used for sending a zero length 
*  IN packet for the handshake phase of a Setup transaction.
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_send_in_token
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle               handle,
      
      /* Pipe descriptor address */      
      PIPE_DESCRIPTOR_STRUCT_PTR     pipe_descr_ptr
   )
{ /* Body */
   MP_STRUCT                  mp_struct;
   uint_16                    newPid;
   USB_HOST_STATE_STRUCT_PTR  usb_host_ptr;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_send_in_token");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   /* Get Next IN BDT */   
   mp_struct.BDT_PTR = _usb_host_vusb11_get_next_in_bdt(handle);

   /* Buffer to receive data */
   mp_struct.BDT_PTR->ADDR.PB = (uchar_ptr)pipe_descr_ptr->RX_PTR;
   newPid = (pipe_descr_ptr->NEXTDATA01 | VUSB_BD_DTS_ENABLE | VUSB_BD_PID_OWN);

   if (pipe_descr_ptr->MUSTSENDNULL) {
      /* Send a zero length token */
      mp_struct.BDT_PTR->BC = 0;
      /* Send it on Data1 */
      newPid |= VUSB_BD_PID_DATA01;
   } else {
      /* Doesn't matter what length. The device will packetize into 
      ** MAX_PACKET_SIZE and send 
      */
      mp_struct.BDT_PTR->BC = 0xFF;
   } /* Endif */
   
   mp_struct.BDT_PTR->PID = newPid;
   
   _usb_host_buffer_bdt(handle, mp_struct.BDT_PTR);

   _usb_host_buffer_token(handle, pipe_descr_ptr->DEVICE_ADDRESS, (VUSB_TOKEN_IN | 
      pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_CONTROL);
   
   /* IN Token */
   _usb_host_vusb11_send_token(handle, pipe_descr_ptr, pipe_descr_ptr->DEVICE_ADDRESS, (VUSB_TOKEN_IN | 
      pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_CONTROL);
   pipe_descr_ptr->NEXTDATA01 ^= VUSB_BD_PID_DATA01;
   
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_send_in_token, SUCCESSFUL");
   #endif
   
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_send_out_token
*  Returned Value : None
*  Comments       :
*        Send the OUT token to send data after the first phase of Setup 
*  transaction is complete. This routine is also used for sending a zero length 
*  OUT packet for the handshake phase of a setup token
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_send_out_token
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,
      
      /* [IN] the pipe descriptor address */
      PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr
   )
{ /* Body */
   MP_STRUCT                         mp_struct;
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_send_out_token");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   /* Get the Next OUT BDT */
   mp_struct.BDT_PTR = (HOST_BDT_STRUCT_PTR)_usb_host_vusb11_get_next_out_bdt(handle);

   /* Data to send */   
   mp_struct.BDT_PTR->ADDR.PB = (uchar_ptr)pipe_descr_ptr->TX2_PTR;
   
   if (pipe_descr_ptr->MUSTSENDNULL) {
      /* Send a zero length token */
      mp_struct.BDT_PTR->BC = 0;
      /* Send it on Data1 */
      mp_struct.BDT_PTR->PID = (pipe_descr_ptr->NEXTDATA01 | 
         VUSB_BD_PID_OWN | VUSB_BD_PID_DATA01);
   } else {
      if (pipe_descr_ptr->TODO2 > pipe_descr_ptr->MAX_PACKET_SIZE) {
         /* Send only MAX_PACKET_SIZE packets */
         mp_struct.BDT_PTR->BC = pipe_descr_ptr->MAX_PACKET_SIZE;
      } else {
         mp_struct.BDT_PTR->BC = pipe_descr_ptr->TODO2;
      } /* Endif */
      mp_struct.BDT_PTR->PID = (pipe_descr_ptr->NEXTDATA01 | VUSB_BD_PID_OWN);
   } /* Endif */
   
   _usb_host_buffer_bdt(handle, mp_struct.BDT_PTR);

   _usb_host_buffer_token(handle, pipe_descr_ptr->DEVICE_ADDRESS, (VUSB_TOKEN_OUT | 
      pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_CONTROL);

   /* setup */
   _usb_host_vusb11_send_token(handle, pipe_descr_ptr, pipe_descr_ptr->DEVICE_ADDRESS, 
      (VUSB_TOKEN_OUT | pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_CONTROL);
   pipe_descr_ptr->NEXTDATA01 ^= VUSB_BD_PID_DATA01;
   /* pipe_descr_ptr->PACKETPENDING = FALSE; */

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_send_out_token, SUCCESSFUL");
   #endif
   
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_send_token
*  Returned Value : None
*  Comments       :
*     Send a Token
*
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_send_token
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,
      
      /* [IN] the pipe descriptor address */
      PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr,
      
      /* Address */
      uint_8 bAddress,
      
      /* Token */
      uint_8 bToken,
      
      /* Type of token */
      uint_8 bType
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR     usb_host_ptr;
   USB_STRUCT_PTR     dev_ptr;
   USB_REGISTER_PTR   endpt_reg;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_send_token");
   #endif
   
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   dev_ptr = (USB_STRUCT_PTR)usb_host_ptr->DEV_PTR;
   endpt_reg = (USB_REGISTER_PTR)usb_host_ptr->ENDPT_HOST_RG;
   
   usb_host_ptr->USB_PKT_PENDING++;
   usb_host_ptr->SND_TOK_IN_PROGRESS = TRUE;

   while (dev_ptr->CONTROL & VUSB_CTRL_TOKEN_BUSY) {
      /* Wait until previous token transmission is done */
   } /* EndWhile */

   usb_host_ptr->CURRENT_PIPE_ID = pipe_descr_ptr->PIPE_ID;
   *endpt_reg = (bType | usb_host_ptr->NO_HUB);
   
   if (usb_host_ptr->SPEED == USB_SPEED_LOW) {
      dev_ptr->ADDRESS = (bAddress | VUSB_ADDR_LS_EN);
   } else {
      dev_ptr->ADDRESS = bAddress;
   } /* Endif */

   dev_ptr->TOKEN = bToken;
   
   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_send_token, SUCCESSFUL");
   #endif
   
   
   return;
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_process_token_done
*  Returned Value : None
*  Comments       :
*     Process the Token Done interrupt on the VUSB1.1 hardware
*
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_process_token_done
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,
            
      /* [IN] direction of the last processed token */
      uint_8                  direction,
            
      /* The error status register value */
      uint_32                 error_status
   )
{ /* Body */
   MP_STRUCT   mp_struct;
   uint_32 status;
   HOST_BDT_STRUCT_PTR BDT_ptr;
   PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr;
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_process_token_done, SUCCESSFUL");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   pipe_descr_ptr = 
      &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
      [usb_host_ptr->CURRENT_PIPE_ID]; 


   /* Get the correct BDT */
   if (direction == USB_SEND)  {
      BDT_ptr = (HOST_BDT_STRUCT_PTR)
         ((uint_32)usb_host_ptr->USB_BDT_PAGE | 
         usb_host_ptr->USB_OUT);

	  if (BDT_ptr->PID & VUSB_BD_PID_OWN) {
	     BDT_ptr = (HOST_BDT_STRUCT_PTR)
            ((uint_32)usb_host_ptr->USB_BDT_PAGE | 
             (usb_host_ptr->USB_OUT ^ VUSB_BDT_ODD_EVEN_BIT));
	  } /* Endif */
   } else {
      BDT_ptr = (HOST_BDT_STRUCT_PTR)
         ((uint_32)usb_host_ptr->USB_BDT_PAGE | 
         usb_host_ptr->USB_IN);

	  if (BDT_ptr->PID & VUSB_BD_PID_OWN) {
	     BDT_ptr = (HOST_BDT_STRUCT_PTR)
            ((uint_32)usb_host_ptr->USB_BDT_PAGE | 
             (usb_host_ptr->USB_IN ^ VUSB_BDT_ODD_EVEN_BIT));
	  } /* Endif */
   } /* Endif */
   
   /* Following is used to look ahead and transmit tokens */
   if (usb_host_ptr->USB_TOKEN_BUFFERED && 
      usb_host_ptr->NEXT_PKT_QUEUED) 
   {
      if (usb_host_ptr->CURRENT_PIPE_ID == 
         usb_host_ptr->NEXT_PIPE_ID) 
      {
         usb_host_ptr->NEXT_PKT_QUEUED = FALSE;
      } else {
         usb_host_ptr->USB_TOKEN_BUFFERED = FALSE;
      } /* Endif */
   } else if (usb_host_ptr->USB_TOKEN_BUFFERED) {
      usb_host_ptr->USB_TOKEN_BUFFERED = FALSE;   
   } else if ((usb_host_ptr->NEXT_PKT_QUEUED) && 
      (usb_host_ptr->CURRENT_PIPE_ID == usb_host_ptr->NEXT_PIPE_ID)) 
   {
      usb_host_ptr->NEXT_PKT_QUEUED = FALSE;
   } /* Endif */

   /* Get the status */
   status = VUSB_GET_STATUS(BDT_ptr);
   
   /* Get the number of bytes received */
#ifdef V8
   mp_struct.B.H = VUSB_GET_BYTE_COUNT_HIGH(BDT_ptr);
   mp_struct.B.L = VUSB_GET_BYTE_COUNT_LOW(BDT_ptr);
#else   
   mp_struct.W = VUSB_GET_BYTE_COUNT(BDT_ptr);
#endif

   /* if not an Isochronous transfer */   
   if (pipe_descr_ptr->PIPETYPE != USB_ISOCHRONOUS_PIPE) {
      if ((!status) || (status == VUSB_BD_NAK_PID) || 
         (status == 0x3C) || (error_status)) 
      {
         pipe_descr_ptr->NEXTDATA01 ^= VUSB_BD_PID_DATA01; /* Need to check */
         if (status == VUSB_BD_NAK_PID) {
            if (pipe_descr_ptr->CURRENT_NAK_COUNT) {
               pipe_descr_ptr->CURRENT_NAK_COUNT--;
               if (!pipe_descr_ptr->CURRENT_NAK_COUNT) {
                  pipe_descr_ptr->CURRENT_INTERVAL = 1;
               } /* Endif */
            } /* Endif */
         } /* Endif */
         
         /* Look ahead for transmitting next token */
         if (usb_host_ptr->NEXT_PKT_QUEUED) 
         {
            usb_host_ptr->CURRENT_PIPE_ID = usb_host_ptr->NEXT_PIPE_ID;
            _usb_host_vusb11_resend_token(handle,
               pipe_descr_ptr, 
               usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
               [usb_host_ptr->CURRENT_PIPE_ID].DIRECTION);
         } /* Endif */
         {
            #ifdef _HOST_DEBUG_
                  DEBUG_LOG_TRACE("_usb_host_vusb11_process_token_done, next token scheduled");
            #endif

            return;
         }

      } /* Endif */
   } /* Endif */
   
   /* reset the counter if a non-NAK, valid transfer occured */
   pipe_descr_ptr->CURRENT_NAK_COUNT = pipe_descr_ptr->NAK_COUNT;

   if (pipe_descr_ptr->PIPETYPE != USB_CONTROL_PIPE) {
   
      /* Increment the buffer pointer */
      if (direction == USB_SEND)  {

         pipe_descr_ptr->TX1_PTR += mp_struct.W;
      } else {

         pipe_descr_ptr->RX_PTR += mp_struct.W;
      } /* Endif */
      /* Decrement the total bytes to be sent/received */
      pipe_descr_ptr->TODO1 -= mp_struct.W;
      /* Increment the total number of bytes sent/received */
      pipe_descr_ptr->SOFAR += mp_struct.W;
   } else {
   
      /* Increment the buffer pointers for Setup transactions */
      if ((pipe_descr_ptr->SEND_PHASE) && (!pipe_descr_ptr->FIRST_PHASE)) {
         pipe_descr_ptr->TX2_PTR += mp_struct.W;
         pipe_descr_ptr->TODO2 -= mp_struct.W;
         /* Increment the total number of bytes sent/received */
         pipe_descr_ptr->SOFAR += mp_struct.W;
      } /* Endif */
      
      if (direction == USB_RECV)  {
         pipe_descr_ptr->RX_PTR += mp_struct.W;
         pipe_descr_ptr->TODO1 -= mp_struct.W;
         /* Increment the total number of bytes sent/received */
         pipe_descr_ptr->SOFAR += mp_struct.W;
      } /* Endif */
   } /* Endif */
   
   /* Look ahead for transmitting next token */
   if (usb_host_ptr->NEXT_PKT_QUEUED) {
      usb_host_ptr->CURRENT_PIPE_ID = usb_host_ptr->NEXT_PIPE_ID;
      _usb_host_vusb11_resend_token(handle,
         pipe_descr_ptr, 
         usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR\
         [usb_host_ptr->CURRENT_PIPE_ID].DIRECTION);
   } /* Endif */
   
   switch (pipe_descr_ptr->USB_PIPE_TRANSACTION_STATE) {
      case 0:
         /* Case for Non-Control transactions */
         if ((!pipe_descr_ptr->TODO1) || 
            (mp_struct.W < pipe_descr_ptr->MAX_PACKET_SIZE))
         {
            if (pipe_descr_ptr->PIPETYPE != USB_ISOCHRONOUS_PIPE) {
               if ((!pipe_descr_ptr->DONT_ZERO_TERMINATE) && 
                  (mp_struct.W == pipe_descr_ptr->MAX_PACKET_SIZE)) 
               {
                  break;
               } /* Endif */
            } /* Endif */
            pipe_descr_ptr->STATUS = USB_STATUS_IDLE;
            pipe_descr_ptr->PACKETPENDING = FALSE;
            _usb_host_update_current_head((pointer)usb_host_ptr, pipe_descr_ptr->PIPETYPE);
            if (pipe_descr_ptr->TR.CALLBACK) {
               pipe_descr_ptr->TR.CALLBACK(pipe_descr_ptr,
                  pipe_descr_ptr->TR.CALLBACK_PARAM,
                  direction == USB_RECV ? pipe_descr_ptr->TR.RX_BUFFER : pipe_descr_ptr->TR.TX_BUFFER,
                  pipe_descr_ptr->SOFAR,
                  USB_OK);
            } /* Endif */
         } /* Endif */
         break;
      case 1:
         /* Following case is for Control transfers */
         if (pipe_descr_ptr->SEND_PHASE) {
            if (!pipe_descr_ptr->TODO2) { /* Complete */
               pipe_descr_ptr->USB_PIPE_TRANSACTION_STATE++;
               /* Setup transaction complete. Send an opposite 
               ** direction token on Data1 
               */
               pipe_descr_ptr->MUSTSENDNULL = TRUE;
               _usb_host_vusb11_send_in_token(handle, pipe_descr_ptr);
            } else { /* partial */
               /* Setup transaction not complete. Send more data */
               _usb_host_vusb11_send_out_token(handle, pipe_descr_ptr);
            } /* Endif */
         } else {
            if (!pipe_descr_ptr->TODO1) { /* Complete */
               pipe_descr_ptr->MUSTSENDNULL = TRUE;
               /* Setup transaction complete. Send an opposite 
               ** direction token on Data1 
               */
               _usb_host_vusb11_send_out_token(handle, pipe_descr_ptr);
               pipe_descr_ptr->USB_PIPE_TRANSACTION_STATE++;
            } else { /* partial */
               if ((mp_struct.W < pipe_descr_ptr->MAX_PACKET_SIZE) && 
                  (!pipe_descr_ptr->FIRST_PHASE)) 
               {
                  /* This is a bug. Since the Tx/Rx of data phase is done, 
                  ** we need to reset the TODO1 
                  */
                  pipe_descr_ptr->TODO1 = 0;
                  pipe_descr_ptr->MUSTSENDNULL = TRUE;
                  _usb_host_vusb11_send_out_token(handle, pipe_descr_ptr);
                  pipe_descr_ptr->USB_PIPE_TRANSACTION_STATE++;
               } else {
                  _usb_host_vusb11_send_in_token(handle, pipe_descr_ptr);
               } /* Endif */
            } /* Endif */
         } /* Endif */
         pipe_descr_ptr->FIRST_PHASE = FALSE;
         break;
      case 2:
         /* Following case is for Control transfers */
         /* Transaction complete */
         pipe_descr_ptr->PACKETPENDING = FALSE;
         pipe_descr_ptr->STATUS = USB_STATUS_IDLE;
         pipe_descr_ptr->SEND_PHASE = FALSE;
         
         /* This is a bug. Since the status phase is ACKed, we need to 
         ** set the MUSTSENDNULL to FALSE 
         */
         pipe_descr_ptr->MUSTSENDNULL = FALSE;
         _usb_host_update_current_head((pointer)usb_host_ptr, pipe_descr_ptr->PIPETYPE);
         
         if (pipe_descr_ptr->TR.CALLBACK) {
            pipe_descr_ptr->TR.CALLBACK(pipe_descr_ptr,
               pipe_descr_ptr->TR.CALLBACK_PARAM,
               direction == USB_RECV ? pipe_descr_ptr->TR.RX_BUFFER : pipe_descr_ptr->TR.TX_BUFFER,
               pipe_descr_ptr->SOFAR,
               USB_OK);
         } /* Endif */
         break;
      default:
         #ifdef _HOST_DEBUG_
            DEBUG_LOG_TRACE("_usb_host_vusb11_process_token_done, unknown state");
         #endif

         return;
   } /* EndSwitch */

   #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_process_token_done, SUCCESSFUL");
   #endif
   
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_init_send_bdt
*  Returned Value : None
*  Comments       :
*     Initialize a BDT for a send operation
*
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_init_send_bdt
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,

      /* Pipe descriptor */
      PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr
   )
{ /* Body */
   MP_STRUCT                  mp_struct;
   USB_HOST_STATE_STRUCT_PTR  usb_host_ptr;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_vusb11_init_send_bdt");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   pipe_descr_ptr->STATUS = USB_STATUS_TRANSFER_IN_PROGRESS;
   
   mp_struct.BDT_PTR = usb_host_ptr->USB_TEMP_SND_BDT_PTR;
   
   mp_struct.BDT_PTR->ADDR.PB = (uchar_ptr)pipe_descr_ptr->TX1_PTR;
   mp_struct.BDT_PTR->PID = (VUSB_BD_PID_OWN | pipe_descr_ptr->NEXTDATA01);
   pipe_descr_ptr->NEXTDATA01 ^= VUSB_BD_PID_DATA01;
   
   if (pipe_descr_ptr->TODO1 > pipe_descr_ptr->MAX_PACKET_SIZE) {
      mp_struct.BDT_PTR->BC = pipe_descr_ptr->MAX_PACKET_SIZE;
   } else {
      mp_struct.BDT_PTR->BC = pipe_descr_ptr->TODO1;
   } /* Endif */
   
   if (!usb_host_ptr->USB_TOKEN_BUFFERED) {
      pipe_descr_ptr->USB_PIPE_TRANSACTION_STATE = 0;
      _usb_host_buffer_bdt(handle, mp_struct.BDT_PTR);
      
      if (pipe_descr_ptr->PIPETYPE == USB_ISOCHRONOUS_PIPE) {
         _usb_host_buffer_token(handle, pipe_descr_ptr->DEVICE_ADDRESS, 
            (VUSB_TOKEN_OUT | pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_ISO_TX);
      } else {
         _usb_host_buffer_token(handle, pipe_descr_ptr->DEVICE_ADDRESS, 
            (VUSB_TOKEN_OUT | pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_CONTROL);
      } /* Endif */
      
      _usb_host_vusb11_resend_token(handle, pipe_descr_ptr, USB_SEND);
   } else if (!usb_host_ptr->NEXT_PKT_QUEUED) {
      _usb_host_buffer_next_bdt(handle, mp_struct.BDT_PTR);
      
      if (pipe_descr_ptr->PIPETYPE == USB_ISOCHRONOUS_PIPE) {
         _usb_host_buffer_next_token(handle, pipe_descr_ptr->DEVICE_ADDRESS, 
            (VUSB_TOKEN_OUT | pipe_descr_ptr->ENDPOINT_NUMBER), 
            VUSB_ENDPT_ISO_TX);
      } else {
         _usb_host_buffer_next_token(handle, pipe_descr_ptr->DEVICE_ADDRESS, 
            (VUSB_TOKEN_OUT | pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_CONTROL);
      } /* Endif */
      
      usb_host_ptr->NEXT_PIPE_ID = pipe_descr_ptr->PIPE_ID;
   } /* Endif */

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_vusb11_init_send_bdt, SUCCESSFUL");
   #endif

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_init_recv_bdt
*  Returned Value : None
*  Comments       :
*     Initialize a BDT for a Receive operation
*
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_init_recv_bdt
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,

      /* Pipe descriptor */
      PIPE_DESCRIPTOR_STRUCT_PTR     pipe_descr_ptr
   )
{ /* Body */
   MP_STRUCT                  mp_struct;
   USB_HOST_STATE_STRUCT_PTR  usb_host_ptr;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_vusb11_init_recv_bdt");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   pipe_descr_ptr->STATUS = USB_STATUS_TRANSFER_IN_PROGRESS;   
   
   mp_struct.BDT_PTR = usb_host_ptr->USB_TEMP_RCV_BDT_PTR;

   mp_struct.BDT_PTR->ADDR.PB = (uchar_ptr)pipe_descr_ptr->RX_PTR;
   /* Also enable data toggle synchronization */
   mp_struct.BDT_PTR->PID = (pipe_descr_ptr->NEXTDATA01 | VUSB_BD_DTS_ENABLE | 
      VUSB_BD_PID_OWN);
   pipe_descr_ptr->NEXTDATA01 ^= VUSB_BD_PID_DATA01;

   if (pipe_descr_ptr->TODO1 > pipe_descr_ptr->MAX_PACKET_SIZE) {
      mp_struct.BDT_PTR->BC = pipe_descr_ptr->MAX_PACKET_SIZE;
   } else {
      mp_struct.BDT_PTR->BC = pipe_descr_ptr->TODO1;
   } /* Endif */

   if (!usb_host_ptr->USB_TOKEN_BUFFERED) {
      pipe_descr_ptr->USB_PIPE_TRANSACTION_STATE = 0;
      _usb_host_buffer_bdt(handle, mp_struct.BDT_PTR);
      
      if (pipe_descr_ptr->PIPETYPE == USB_ISOCHRONOUS_PIPE) {
         _usb_host_buffer_token(handle, pipe_descr_ptr->DEVICE_ADDRESS, 
            (VUSB_TOKEN_IN | pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_ISO_RX);
      } else {
         _usb_host_buffer_token(handle, pipe_descr_ptr->DEVICE_ADDRESS, 
            (VUSB_TOKEN_IN | pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_CONTROL);
      } /* Endif */
      
      _usb_host_vusb11_resend_token(handle, pipe_descr_ptr, USB_RECV);
   } else if (!usb_host_ptr->NEXT_PKT_QUEUED) {
      _usb_host_buffer_next_bdt(handle, mp_struct.BDT_PTR);
      
      if (pipe_descr_ptr->PIPETYPE == USB_ISOCHRONOUS_PIPE) {
         _usb_host_buffer_next_token(handle, pipe_descr_ptr->DEVICE_ADDRESS, 
            (VUSB_TOKEN_IN | pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_ISO_RX);
      } else {
         _usb_host_buffer_next_token(handle, pipe_descr_ptr->DEVICE_ADDRESS, 
            (VUSB_TOKEN_IN | pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_CONTROL);
      } /* Endif */
      
      usb_host_ptr->NEXT_PIPE_ID = pipe_descr_ptr->PIPE_ID;
   } /* Endif */

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_vusb11_init_recv_bdt, SUCCESSFUL");
   #endif

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_init_setup_bdt
*  Returned Value : None
*  Comments       :
*     Initialize a BDT for a Setup tranaction
*
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_init_setup_bdt
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,
      
      /* Pipe descriptor */
      PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr
   )
{ /* Body */
   static MP_STRUCT                  mp_struct;
   USB_HOST_STATE_STRUCT_PTR         usb_host_ptr;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_vusb11_init_setup_bdt");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   pipe_descr_ptr->USB_PIPE_TRANSACTION_STATE = 1;
   pipe_descr_ptr->STATUS = USB_STATUS_TRANSFER_IN_PROGRESS;
   


   mp_struct.BDT_PTR = (HOST_BDT_STRUCT_PTR)_usb_host_vusb11_get_next_out_bdt(handle);
   mp_struct.BDT_PTR->BC = 0x08;
   mp_struct.BDT_PTR->ADDR.PB = (uchar_ptr)pipe_descr_ptr->TX1_PTR;
   mp_struct.BDT_PTR->PID = (pipe_descr_ptr->NEXTDATA01 | VUSB_BD_PID_OWN);
   pipe_descr_ptr->NEXTDATA01 ^= VUSB_BD_PID_DATA01;
   _usb_host_buffer_bdt(handle, mp_struct.BDT_PTR);

   _usb_host_buffer_token(handle, pipe_descr_ptr->DEVICE_ADDRESS, 
      VUSB_TOKEN_SETUP, VUSB_ENDPT_CONTROL);

   /* setup ep0 */
   _usb_host_vusb11_send_token(handle, pipe_descr_ptr, pipe_descr_ptr->DEVICE_ADDRESS, 
      (VUSB_TOKEN_SETUP | pipe_descr_ptr->ENDPOINT_NUMBER), VUSB_ENDPT_CONTROL);

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_vusb11_init_setup_bdt, SUCCESSFUL");
   #endif
      

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_vusb11_resend_token
*  Returned Value : None
*  Comments       :
*     Resend a Token
*
*END*-----------------------------------------------------------------*/

void _usb_host_vusb11_resend_token
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle           handle,
      
      /* [IN] the pipe descriptor address */
      PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr,
      
      /* Send/Receive */
      uint_8  bDirection
   )
{ /* Body */
   MP_STRUCT   mp_struct;
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_vusb11_resend_token, SUCCESSFUL");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   /* resend last token after resetting the bdt */
   if (bDirection == USB_SEND)  {
      mp_struct.BDT_PTR = _usb_host_vusb11_get_next_out_bdt(handle);
   } else {
      mp_struct.BDT_PTR = _usb_host_vusb11_get_next_in_bdt(handle);
   } /* Endif */
   
   if (usb_host_ptr->USB_TOKEN_BUFFERED) {
      mp_struct.BDT_PTR->BC = usb_host_ptr->USB_BUFFERED_BDT_PTR->BC;
      mp_struct.BDT_PTR->ADDR = usb_host_ptr->USB_BUFFERED_BDT_PTR->ADDR;
      mp_struct.BDT_PTR->PID = usb_host_ptr->USB_BUFFERED_BDT_PTR->PID;
      _usb_host_vusb11_send_token(handle, pipe_descr_ptr, usb_host_ptr->USB_BUFFERED_ADDRESS, 
         usb_host_ptr->USB_BUFFERED_TOKEN, 
         usb_host_ptr->USB_BUFFERED_TYPE);
      _usb_host_buffer_token(handle, usb_host_ptr->USB_BUFFERED_ADDRESS, 
         usb_host_ptr->USB_BUFFERED_TOKEN, 
         usb_host_ptr->USB_BUFFERED_TYPE);
      #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_vusb11_resend_token, next token sent");
      #endif
      return;      
   } /* Endif */  
   
   if (usb_host_ptr->NEXT_PKT_QUEUED) {
      mp_struct.BDT_PTR->BC = usb_host_ptr->USB_NEXT_BUFFERED_BDT_PTR->BC;
      mp_struct.BDT_PTR->ADDR = usb_host_ptr->USB_NEXT_BUFFERED_BDT_PTR->ADDR;
      mp_struct.BDT_PTR->PID = usb_host_ptr->USB_NEXT_BUFFERED_BDT_PTR->PID;
      _usb_host_vusb11_send_token(handle, pipe_descr_ptr, usb_host_ptr->USB_NEXT_BUFFERED_ADDRESS, 
         usb_host_ptr->USB_NEXT_BUFFERED_TOKEN, 
         usb_host_ptr->USB_NEXT_BUFFERED_TYPE);
      _usb_host_buffer_next_token(handle, usb_host_ptr->USB_NEXT_BUFFERED_ADDRESS, 
         usb_host_ptr->USB_NEXT_BUFFERED_TOKEN, 
         usb_host_ptr->USB_NEXT_BUFFERED_TYPE);
   } /* Endif */

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_vusb11_resend_token,SUCCESSFUL");
   #endif
  
} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_buffer_bdt
*  Returned Value : None
*  Comments       :
*        Buffer a BDT
*END*-----------------------------------------------------------------*/

void _usb_host_buffer_bdt
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle           handle,
            
      /* The descriptor to buffer */
      HOST_BDT_STRUCT_PTR BDT_ptr
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;
   
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_buffer_bdt");
   #endif
   
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   usb_host_ptr->USB_BUFFERED_BDT_PTR->PID = BDT_ptr->PID;
   usb_host_ptr->USB_BUFFERED_BDT_PTR->BC = BDT_ptr->BC;
   usb_host_ptr->USB_BUFFERED_BDT_PTR->ADDR = BDT_ptr->ADDR;
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_buffer_bdt,SUCCESSFUL");
   #endif
   
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_buffer_next_bdt
*  Returned Value : None
*  Comments       :
*        Buffer the Next BDT to be processed
*END*-----------------------------------------------------------------*/

void _usb_host_buffer_next_bdt
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle           handle,
      
      /* [IN] the address of the descriptor to buffer */
      HOST_BDT_STRUCT_PTR BDT_ptr
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_buffer_next_bdt");
   #endif
   
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   usb_host_ptr->USB_NEXT_BUFFERED_BDT_PTR->PID = BDT_ptr->PID;
   usb_host_ptr->USB_NEXT_BUFFERED_BDT_PTR->BC = BDT_ptr->BC;
   usb_host_ptr->USB_NEXT_BUFFERED_BDT_PTR->ADDR = BDT_ptr->ADDR;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_buffer_next_bdt,SUCCESSFUL");
   #endif
   
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_buffer_token
*  Returned Value : None
*  Comments       :
*        Buffer a Token to transmit
*END*-----------------------------------------------------------------*/

void _usb_host_buffer_token
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle           handle,
      
      /* Address */
      uint_8 bAddress,
      
      /* Token */
      uint_8 bToken,
      
      /* Type of token */
      uint_8 bType
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_buffer_token");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   usb_host_ptr->USB_BUFFERED_ADDRESS = bAddress;
   usb_host_ptr->USB_BUFFERED_TOKEN = bToken;
   usb_host_ptr->USB_BUFFERED_TYPE = bType;
   usb_host_ptr->USB_TOKEN_BUFFERED = TRUE;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_buffer_token,SUCCESSFUL");
   #endif
   
} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_buffer_next_token
*  Returned Value : None
*  Comments       :
*        Buffer the next Token to transmit
*END*-----------------------------------------------------------------*/

void _usb_host_buffer_next_token
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle           handle,
      
      /* Address */
      uint_8 bAddress,
      
      /* Token */
      uint_8 bToken,
      
      /* Type of token */
      uint_8 bType
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_buffer_next_token");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   usb_host_ptr->USB_NEXT_BUFFERED_ADDRESS = bAddress;
   usb_host_ptr->USB_NEXT_BUFFERED_TOKEN = bToken;
   usb_host_ptr->USB_NEXT_BUFFERED_TYPE = bType;
   usb_host_ptr->NEXT_PKT_QUEUED = TRUE;
   
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_buffer_next_token,SUCCESSFUL");
   #endif
   
} /* EndBody */

/* EOF */


   
      


      
   

