# VUSBHS host driver

MQX_INCDIRS      +=$(USB_ROOT)$(PS)source$(PS)host$(PS)vusbhs_host

srcdirs += host$(PS)$(USB_DRIVER)_host
host_srcs    += \
	vusbhs_host_utl vusbhs_host_main vusbhs_host_bw vusbhs_host_cncl vusbhs_host_intr vusbhs_host_iso vusbhs_host_shut	

