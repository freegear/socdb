/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:      
***   This file contains the low-level Host API functions specific to the VUSB 
***   chip for shutting down the host controller.
***                                                               
**************************************************************************
**END*********************************************************/
#include "hostapi.h"
#include "usbprv_host.h"

#ifdef __USB_OS_MQX__
#include "mqx_arc.h"
#endif


#ifndef __USB_OS_MQX__
extern boolean IN_ISR;
#endif

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_hci_vusb20_shutdown
*  Returned Value : None
*  Comments       :
*     Shutdown and de-initialize the VUSB1.1 hardware
*
*END*-----------------------------------------------------------------*/

void _usb_hci_vusb20_shutdown
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR         usb_host_ptr;
   VUSB20_REG_STRUCT_PTR             dev_ptr;
   ACTIVE_QH_MGMT_STRUCT_PTR         active_list_member_ptr, temp_ptr = NULL;
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   dev_ptr      = (VUSB20_REG_STRUCT_PTR)usb_host_ptr->DEV_PTR;
   
   /* Disable interrupts */
   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.USB_INTR &= 
      ~VUSB20_HOST_INTR_EN_BITS;
      
   /* Stop the controller */
   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.USB_CMD &= 
      ~EHCI_CMD_RUN_STOP;
   
   /* Reset the controller to get default values */
   dev_ptr->REGISTERS.OPERATIONAL_HOST_REGISTERS.USB_CMD = EHCI_CMD_CTRL_RESET;
   
   /**********************************************************
   ensure that periodic list in uninitilized.
   **********************************************************/
   usb_host_ptr->ITD_LIST_INITIALIZED = FALSE;
   usb_host_ptr->SITD_LIST_INITIALIZED = FALSE;
   usb_host_ptr->PERIODIC_LIST_INITIALIZED = FALSE;
   usb_host_ptr->ALIGNED_PERIODIC_LIST_BASE_ADDR = NULL;
   
   /**********************************************************
   Free all memory occupied by active transfers   
   **********************************************************/
   active_list_member_ptr = usb_host_ptr->ACTIVE_ASYNC_LIST_PTR;
   while(active_list_member_ptr) 
   {
      temp_ptr =  active_list_member_ptr;
      active_list_member_ptr = (ACTIVE_QH_MGMT_STRUCT_PTR) \
                              active_list_member_ptr->NEXT_ACTIVE_QH_MGMT_STRUCT_PTR;
      USB_memfree(temp_ptr);
      
   }

   active_list_member_ptr = usb_host_ptr->ACTIVE_INTERRUPT_PERIODIC_LIST_PTR;
   while(active_list_member_ptr) 
   {
      temp_ptr =  active_list_member_ptr;
      active_list_member_ptr = (ACTIVE_QH_MGMT_STRUCT_PTR) \
                              active_list_member_ptr->NEXT_ACTIVE_QH_MGMT_STRUCT_PTR;
      USB_memfree(temp_ptr);
      
   }

   /* Free all controller specific memory */
   USB_memfree((pointer)usb_host_ptr->CONTROLLER_MEMORY);
   
#if 0      
   /* Free all controller specific memory */
   USB_memfree((pointer)usb_host_ptr->PERIODIC_FRAME_LIST_BW_PTR);
   USB_memfree((pointer)usb_host_ptr->ASYNC_LIST_BASE_ADDR);
   USB_memfree((pointer)usb_host_ptr->ITD_BASE_PTR);
   USB_memfree((pointer)usb_host_ptr->ITD_SCRATCH_STRUCT_BASE);
   USB_memfree((pointer)usb_host_ptr->SITD_BASE_PTR);
   USB_memfree((pointer)usb_host_ptr->QTD_BASE_PTR);
   USB_memfree((pointer)usb_host_ptr->QTD_SCRATCH_STRUCT_BASE);
   USB_memfree((pointer)usb_host_ptr->SITD_SCRATCH_STRUCT_BASE);
   USB_memfree((pointer)usb_host_ptr->PERIODIC_LIST_BASE_ADDR);
   USB_memfree((pointer)usb_host_ptr->QH_SCRATCH_STRUCT_BASE);
#endif
   
} /* EndBody */

/* EOF */


   
      


      
   

