/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:      
***   This file contains the USB Host API specific function to shutdown 
***   the host
***                                                               
**************************************************************************
**END*********************************************************/
#include "hostapi.h"
#include "usbprv_host.h"

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
#endif

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_shutdown
*  Returned Value : USB_OK or error code
*  Comments       :
*        Shutdown an initialized USB Host
*
*END*-----------------------------------------------------------------*/
void _usb_host_shutdown
   (
      /* [IN] the USB_host handle */
      _usb_host_handle         handle
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR   usb_host_ptr;
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_shutdown");
   #endif


#ifdef __USB_OS_MQX__   
   /* De-initialize and disconnect the host hardware from the bus */
   ((USB_CALLBACK_FUNCTIONS_STRUCT_PTR)usb_host_ptr->CALLBACK_STRUCT_PTR)->\
      HOST_SHUTDOWN(handle);
#else
#ifdef __VUSB32__
   _usb_hci_vusb11_shutdown(handle);
#else
   _usb_hci_vusb20_shutdown(handle);
#endif
#endif
   /* Free all Pipe Descriptors */
   USB_memfree((pointer)usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR);

   /* Free the USB state structure */
   USB_memfree(handle);
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_shutdown SUCCESSFUL");
   #endif

   
} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_bus_control
*  Returned Value : None
*  Comments       :
* _usb_host_bus_control controls the bus operations such as asserting and 
* deasserting the bus reset, asserting and deasserting resume, 
* suspending and resuming the SOF generation
*
*END*-----------------------------------------------------------------*/

void _usb_host_bus_control
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle           handle,
      
      /* The operation to be performed on the bus */
      uint_8                     bcontrol
   )
{ /* Body */
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_bus_control");
   #endif

#ifdef __USB_OS_MQX__   
   USB_HOST_STATE_STRUCT_PTR         usb_host_ptr;
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   ((USB_CALLBACK_FUNCTIONS_STRUCT_PTR)usb_host_ptr->CALLBACK_STRUCT_PTR)->\
      HOST_BUS_CONTROL(handle, bcontrol);
#else
#ifdef __VUSB32__
   _usb_hci_vusb11_bus_control(handle, bcontrol);
#else
   _usb_hci_vusb20_bus_control(handle, bcontrol);
#endif
#endif
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_bus_control SUCCESSFUL");
   #endif
  
} /* Endbody */

/* EOF */


   

