# VUSBHS host driver

MQX_INCDIRS      +=$(USB_ROOT)$(PS)source$(PS)host$(PS)vusb32_host

srcdirs += host$(PS)$(USB_DRIVER)_host
host_srcs    += \
	vusb32_host_main vusb32_host_shut

