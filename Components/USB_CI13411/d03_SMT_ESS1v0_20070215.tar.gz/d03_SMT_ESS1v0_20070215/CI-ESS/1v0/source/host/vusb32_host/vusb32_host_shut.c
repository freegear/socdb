/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Description:      
***   This file contains the low-level VUSB32 Host Controller Interface
***   (HCI) shutdown routines.
***                                                               
**************************************************************************
**END*********************************************************/
#include "types.h"
#include "vusb32.h"
#include "usb.h"
#include "hostapi.h"
#include "usbprv.h"
#include "usbprv_host.h"

#ifdef __USB_OS_MQX__
#include "mqx_arc.h"
#endif

#ifndef __USB_OS_MQX__
extern boolean IN_ISR;
#endif

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_hci_vusb11_bus_control
*  Returned Value : None
*  Comments       :
*        Bus control
*END*-----------------------------------------------------------------*/

void _usb_hci_vusb11_bus_control
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle,

      /* The operation to be performed on the bus */
      uint_8                  bControl
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR     usb_host_ptr;
   USB_STRUCT_PTR     dev_ptr;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_hci_vusb11_bus_control");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   dev_ptr = (USB_STRUCT_PTR)usb_host_ptr->DEV_PTR;
   
   switch(bControl) {
      case USB_ASSERT_BUS_RESET:
         dev_ptr->CONTROL = (VUSB_CTRL_HOST_MODE_EN | 
            VUSB_CTRL_USB_EN | VUSB_CTRL_RESET);
         break;
      case USB_ASSERT_RESUME:
         dev_ptr->CONTROL = (VUSB_CTRL_HOST_MODE_EN 
            | VUSB_CTRL_USB_EN | VUSB_CTRL_RESUME);
         break;
      case USB_SUSPEND_SOF:
         dev_ptr->CONTROL = VUSB_CTRL_HOST_MODE_EN;
         /* Enable the resume interrupt when suspended */
         dev_ptr->INTENABLE |= VUSB_INT_ENB_RESUME;
         break;
      case USB_DEASSERT_BUS_RESET:
      case USB_RESUME_SOF:
      case USB_DEASSERT_RESUME:
         /* Resume interrupt should not be enabled when not suspended */
         dev_ptr->INTENABLE &= ~VUSB_INT_ENB_RESUME;
         dev_ptr->CONTROL = (VUSB_CTRL_HOST_MODE_EN | 
            VUSB_CTRL_USB_EN);
      default:
         break;
   } /* EndSwitch */

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_hci_vusb11_bus_control,SUCCESSFUL");
   #endif
   
} /* EndBody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_hci_vusb11_shutdown
*  Returned Value : None
*  Comments       :
*     Shutdown and de-initialize the VUSB1.1 hardware
*
*END*-----------------------------------------------------------------*/

void _usb_hci_vusb11_shutdown
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle        handle
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR           usb_host_ptr;
   USB_STRUCT_PTR                      dev_ptr;
   USB_REGISTER_PTR         endpt_reg;
   
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_hci_vusb11_shutdown");
   #endif

   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   
   dev_ptr = (USB_STRUCT_PTR)usb_host_ptr->DEV_PTR;
   endpt_reg = (USB_REGISTER_PTR)usb_host_ptr->ENDPT_HOST_RG;
   
   *endpt_reg = VUSB_ENDPT_DISABLE;
   dev_ptr->CONTROL = 0x00;        /* Disable VUSB */
   dev_ptr->INTENABLE = 0x00; /* Mask all interupts */
   dev_ptr->INTSTATUS = 0xFF;   /* Clear all interupts */
   dev_ptr->ADDRESS = 0;
   
   /* Free the Buffer Descriptor Table */
   USB_memfree((void *) usb_host_ptr->USB_BDT_PAGE_BASE);

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_hci_vusb11_shutdown,SUCCESSFUL");
   #endif
   
   
} /* EndBody */

/* EOF */


   
      


      
   

