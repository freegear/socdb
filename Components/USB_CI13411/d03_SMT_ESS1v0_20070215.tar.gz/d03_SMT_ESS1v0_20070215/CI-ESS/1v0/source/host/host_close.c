/*******************************************************************************
** File          : $HeadURL$ 
** Author        : $Author$
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date$
** $Revision$
*******************************************************************************
*** Comments:      
***   This file contains the USB Host API specific functions to close pipe(s).
***                                                               
**************************************************************************
**END*********************************************************/
#include "hostapi.h"
#include "usbprv_host.h"

#ifdef __USB_OS_MQX__
   #include "mqx_arc.h"
#endif

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_close_pipe
*  Returned Value : None
*  Comments       :
*        _usb_host_close_pipe routine removes the pipe from the open pipe list
*
*END*-----------------------------------------------------------------*/
uint_32 _usb_host_close_pipe
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle     handle,
      
      /* [IN] the pipe (handle) to close */
      _usb_pipe_handle     pipe_handle
   )
{ /* Body */
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;
   PIPE_DESCRIPTOR_STRUCT_PTR pipe_descr_ptr;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_close_pipe");
   #endif
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;
   pipe_descr_ptr = (PIPE_DESCRIPTOR_STRUCT_PTR)pipe_handle;
  
   if (pipe_descr_ptr->PIPE_ID > USB_MAX_PIPES) {
      #ifdef _HOST_DEBUG_
         DEBUG_LOG_TRACE("_usb_host_close_pipe invalid pipe");
      #endif
      return USBERR_INVALID_PIPE_HANDLE;
   } /* Endif */

   USB_lock();

#ifndef __VUSB32__
#ifdef __USB_OS_MQX__
      /* Call the low-level routine to free the controller specific resources */
      ((USB_CALLBACK_FUNCTIONS_STRUCT_PTR)
         usb_host_ptr->CALLBACK_STRUCT_PTR)->\
         HOST_FREE_CONTROLLER_RESOURCE(handle, pipe_descr_ptr);
#else
      /* Call the low-level routine to free the controller specific resources */
      _usb_ehci_free_resources(handle, pipe_descr_ptr);
#endif
#endif

   /* de-initialise the pipe descriptor */
   USB_memzero(pipe_descr_ptr, sizeof(PIPE_DESCRIPTOR_STRUCT));   

   USB_unlock();

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_close_pipe SUCCESSFUL");
   #endif

   return USB_OK;

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------
*
*  Function Name  : _usb_host_close_all_pipes
*  Returned Value : None
*  Comments       :
*  _usb_host_close_all_pipes routine removes the pipe from the open pipe list
*
*END*-----------------------------------------------------------------*/
void  _usb_host_close_all_pipes
   (
      /* [IN] the USB Host state structure */
      _usb_host_handle  handle
   )
{ /* Body */
   int_16 i;
   USB_HOST_STATE_STRUCT_PTR usb_host_ptr;
   
   usb_host_ptr = (USB_HOST_STATE_STRUCT_PTR)handle;

   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_close_all_pipes");
   #endif

   USB_lock();

#ifdef __VUSB32__
   for (i=0; i<usb_host_ptr->MAX_PIPES; i++) {
      if (!(usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR[i].OPEN)) {
         break;
      } else {
#else
   for (i=0; i < USB_MAX_PIPES; i++) {
      if (!(usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR[i].OPEN)) {
         break;
      } else {
#ifdef __USB_OS_MQX__
         /* Call the low-level routine to free the controller specific 
         ** resources for this pipe 
         */
         ((USB_CALLBACK_FUNCTIONS_STRUCT_PTR)\
            usb_host_ptr->CALLBACK_STRUCT_PTR)->\
            HOST_FREE_CONTROLLER_RESOURCE(handle, 
               &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR[i]);
#else
         /* Allocate bandwidth if periodic pipe */
         _usb_ehci_free_resources(handle, 
            &usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR[i]);
#endif
#endif
         /* de-initialise the pipe descriptor */
         USB_memzero(&usb_host_ptr->PIPE_DESCRIPTOR_BASE_PTR[i], 
            sizeof(PIPE_DESCRIPTOR_STRUCT));
      } /* Endif */
   } /* Endfor */
   
#ifdef __VUSB32__
   /* Initialize the current pipe id to -1 indicating that there are no pipes 
   ** queued
   */
   usb_host_ptr->CURRENT_PIPE_ID = -1;
#endif

   USB_unlock();
   #ifdef _HOST_DEBUG_
      DEBUG_LOG_TRACE("_usb_host_close_all_pipes SUCCESSFUL");
   #endif
   
} /* Endbody */

/* EOF */


   

