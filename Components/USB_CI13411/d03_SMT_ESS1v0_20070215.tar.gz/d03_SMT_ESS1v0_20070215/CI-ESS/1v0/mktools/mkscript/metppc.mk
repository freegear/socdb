################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################


###########################################################
#
# Now define the executables used to build the project.
# We need a compiler (CC), assembler (AS), archiver (AR)
# and linker (LD).  We may also define a map file generator
# (NM) (if not done by the linker), a binary conversion
# utility (CV)
#

CV=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)elf2hex

CC=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcppc
AS=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)asppc
AR=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)arppc
LD=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcppc -Heos=mqx -Bstatic -Bgrouplib -Hnocrt
LIBC=libmw.a

###########################################################
#
# Define various PSP-dependant variables needed for
# compiler/assembler/linker options.
#
# There are two ways to do this:
#
#       processor: variable=value
#
# and
#
#       ifeq ($(MQX_PSP),processor)
#           variable=value
#       endif
#
# There's a very important difference between them:
# In the first case, variable is only defined during
# the 'start' rule (and not when compiling, assembling,
# archiving or linking), and in the second, variable
# is defined for all rules.
#
# Special variables:
#
#     CFLAGS            C compiler options, overridable
#                       on a per-file basis.
#
#     ASFLAGS           Assembler options, overridable
#                       on a per-file basis.
#
#     CPPFLAGS          C preprocessor options.  This
#                       variable shouldn't be set here.
#                       It's intended for users who want
#                       to override preprocessor variables
#                       without having to modify source
#                       code.
#
#     CFLAGS_EXTRA      C compiler options common to
#                       all C files.
#
#     ASFLAGS_EXTRA     Assembler options common to
#                       all assembly files.
#
#     CPPFLAGS_EXTRA    C preprocessor options, common
#                       to all C files.
#
#     MQX_INCDIRS       A list of include directories.
#                       This list already contains the
#                       BSP and PSP directories, as well
#                       as project-specific directories.
#                       We must add compiler include
#                       directories here.
#
# CPPFLAGS_EXTRA and MQX_INCDIRS are also used by
# 'make depend', so they must be defined using the
# second form above.
#

CFLAGS   =
ASFLAGS  =

ifdef MQX_SMALL_SIZE
CFLAGS += -Os
CFLAGS_EXTRA += -DMQX_COMPILE_FOR_SMALL_SIZE
else
ifndef MQX_NO_OPTIMIZATION
CFLAGS   +=-O
endif
endif

CFLAGS_EXTRA   +=-Hon=Long_enums -Hnocopyr -Xa
ASFLAGS_EXTRA  +=-c -Eo -DMQX_CPU=$(MQX_CPU)

ifeq ($(MQX_ENDIAN),l)
ASFLAGS_EXTRA  +=-le
CFLAGS_EXTRA   +=-HL
met_lib =lib\le
LD +=-HL
else
ASFLAGS_EXTRA  +=-be
CFLAGS_EXTRA   +=-HB
met_lib =lib\be
LD +=-HB
endif

ifndef MQX_NO_DEBUG
ASFLAGS += -g
CFLAGS  += -g
endif

ifdef MQX_DO_CPPLUS
CFLAGS_EXTRA   +=-Hcplus
else
CFLAGS_EXTRA   +=-Hnocplus
LD += -Hnocplus
endif

ifdef MQX_COMPRESS_INITDATA
CFLAGS_EXTRA += -DMQX_COMPRESS_INITDATA
endif

ifneq ($(findstring -DMQX_KERNEL_LOGGING=0,$(CPPFLAGS)),)
ASFLAGS_EXTRA += -DMQX_KERNEL_LOGGING=0
endif

#---------------------------------------------------------------------------

ppc400:  CFLAGS_EXTRA +=-Hppc400  ; ASFLAGS_EXTRA +=-tPPC400
ppc401:  CFLAGS_EXTRA +=-Hppc401  ; ASFLAGS_EXTRA +=-tPPC401
ppc403:  CFLAGS_EXTRA +=-Hppc403  ; ASFLAGS_EXTRA +=-tPPC403
ppc405:  CFLAGS_EXTRA +=-Hppc405  ; ASFLAGS_EXTRA +=-tPPC405
ppc440:  CFLAGS_EXTRA +=-Hppc440  ; ASFLAGS_EXTRA +=-tPPC440
mpc505:  CFLAGS_EXTRA +=-Hppc505 -nofsoft -Hoff=use_fp_move ; ASFLAGS_EXTRA +=-tPPC505
mpc509:  CFLAGS_EXTRA +=-Hppc509 -nofsoft -Hoff=use_fp_move ; ASFLAGS_EXTRA +=-tPPC509
mpc555:  CFLAGS_EXTRA +=-Hppc555  ; ASFLAGS_EXTRA +=-tPPC555
ppc603:  CFLAGS_EXTRA +=-Hppc603 -nofsoft -Hoff=use_fp_move ; ASFLAGS_EXTRA +=-tPPC603
ppc604:  CFLAGS_EXTRA +=-Hppc604 -nofsoft -Hoff=use_fp_move ; ASFLAGS_EXTRA +=-tPPC604
ppc740:  CFLAGS_EXTRA +=-Hppc740 -nofsoft -Hoff=use_fp_move ; ASFLAGS_EXTRA +=-tPPC740
ppc750:  CFLAGS_EXTRA +=-Hppc750 -nofsoft -Hoff=use_fp_move ; ASFLAGS_EXTRA +=-tPPC750
mpc801:  CFLAGS_EXTRA +=-Hppc801  ; ASFLAGS_EXTRA +=-tppc801
mpc821:  CFLAGS_EXTRA +=-Hppc821  ; ASFLAGS_EXTRA +=-tPPC821
mpc823:  CFLAGS_EXTRA +=-Hppc823  ; ASFLAGS_EXTRA +=-tPPC823
mpc850:  CFLAGS_EXTRA +=-Hppc850  ; ASFLAGS_EXTRA +=-tPPC850
mpc855:  CFLAGS_EXTRA +=-Hppc860  ; ASFLAGS_EXTRA +=-tPPC860
mpc860:  CFLAGS_EXTRA +=-Hppc860  ; ASFLAGS_EXTRA +=-tPPC860
mpc7400: CFLAGS_EXTRA +=-Hppc7400 -nofsoft -Hoff=use_fp_move -Haltivec; ASFLAGS_EXTRA +=-tPPC7400
mpc8240: CFLAGS_EXTRA +=-Hppc8240 -nofsoft -Hoff=use_fp_move ; ASFLAGS_EXTRA +=-tPPC8240
mpc8260: CFLAGS_EXTRA +=-Hppc8260 -nofsoft -Hoff=use_fp_move ; ASFLAGS_EXTRA +=-tPPC8260
# END CR 318

MQX_INCDIRS +=$(MQX_COMPILER_ROOT)$(PS)inc

met_boot =$(MQX_BSP_LIB_DIR)$(PS)boot.o

ifneq ($(findstring $(MQX_PSP),$(met_procs_ppch)),)
met_lib :=$(met_lib)$(PS)fp
endif
ifneq ($(findstring $(MQX_PSP),$(met_procs_ppcs)),)
met_lib :=$(met_lib)$(PS)fsoft
endif

# EOF
