################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################


CV=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)elf2hex
CC=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcarm
AS=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)asarm
AR=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)ararm

ifdef MQX_NO_C_COMPILER_RUNTIME
LD=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcarm -Heos=mqx -Bstatic -Bgrouplib -Hnocrt
LIBC=libc.a
else
ifneq ($(MQX_PSP),ep7312)
LD=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcarm -Heos=mqx -Bstatic -Bgrouplib -Hnocrt
LIBC=libc.a
else
LD=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcarm -Heos=mqx -Bstatic -Bgrouplib -Hhostlink
LIBC=libmqx.a
endif
endif

###########################################################
#
# Define various PSP-dependant variables needed for
# compiler/assembler/linker options.
#
# There are two ways to do this:
#
#       processor: variable=value
#
# and
#
#       ifeq ($(MQX_PSP),processor)
#           variable=value
#       endif
#
# There's a very important difference between them:
# In the first case, variable is only defined during
# the 'start' rule (and not when compiling, assembling,
# archiving or linking), and in the second, variable
# is defined for all rules.
#
# Special variables:
#
#     CFLAGS            C compiler options, overridable
#                       on a per-file basis.
#
#     ASFLAGS           Assembler options, overridable
#                       on a per-file basis.
#
#     CPPFLAGS          C preprocessor options.  This
#                       variable shouldn't be set here.
#                       It's intended for users who want
#                       to override preprocessor variables
#                       without having to modify source
#                       code.
#
#     CFLAGS_EXTRA      C compiler options common to
#                       all C files.
#
#     ASFLAGS_EXTRA     Assembler options common to
#                       all assembly files.
#
#     CPPFLAGS_EXTRA    C preprocessor options, common
#                       to all C files.
#
#     MQX_INCDIRS       A list of include directories.
#                       This list already contains the
#                       BSP and PSP directories, as well
#                       as project-specific directories.
#                       We must add compiler include
#                       directories here.
#
# CPPFLAGS_EXTRA and MQX_INCDIRS are also used by
# 'make depend', so they must be defined using the
# second form above.
#

CFLAGS   =
ASFLAGS  =

CFLAGS_EXTRA   +=-Hon=Long_enums -Hnoreent -Hnoswst -Hnosdata -Hoff=Behaved
ASFLAGS_EXTRA  +=-c -Eo -DMQX_CPU=$(MQX_CPU) -noswst

ifndef MQX_NO_OPTIMIZATION
CFLAGS   +=-Os
endif

ifdef MQX_SMALL_SIZE
CFLAGS_EXTRA += -DMQX_COMPILE_FOR_SMALL_SIZE
endif

ifndef MQX_NO_DEBUG
ASFLAGS += -g
CFLAGS  += -g
endif

ifdef MQX_DO_PROFILING
CFLAGS += -pg -D__PROFILE__
LD += -pg -Hheap=32768
else
LD += -Hheap=0
endif

ifdef MQX_NO_C_COMPILER_RUNTIME
CFLAGS_EXTRA += -DMQX_NO_C_COMPILER_RUNTIME
endif

ifdef MQX_DO_CPPLUS
CFLAGS_EXTRA   +=-Hcplus
else
CFLAGS_EXTRA   +=-Hnocplus
LD += -Hnocplus
endif

ifdef MQX_COMPRESS_INITDATA
CFLAGS_EXTRA += -DMQX_COMPRESS_INITDATA
else
CFLAGS_EXTRA += -Hnocopyr
LD += -Hnocopyr
endif

ifneq ($(findstring -DMQX_KERNEL_LOGGING=0,$(CPPFLAGS)),)
ASFLAGS_EXTRA += -DMQX_KERNEL_LOGGING=0
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_sarm)),)
CFLAGS_EXTRA   +=-Hstrongarm
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_thumb)),)
CFLAGS_EXTRA   +=-Hthumb -Hinter
ASFLAGS_EXTRA  +=-thumb -inter
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_xscale)),)
CFLAGS_EXTRA   +=-Harch5
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_arm7v4)),)
CFLAGS_EXTRA   +=-Hon=Version4
endif

MQX_INCDIRS +=$(MQX_COMPILER_ROOT)$(PS)inc

met_boot =$(MQX_BSP_LIB_DIR)$(PS)met.o

met_lib =lib
ifeq ($(MQX_ENDIAN),l)
met_lib :=$(met_lib)$(PS)le
LD +=-HL
CFLAGS_EXTRA  +=-HL
ASFLAGS_EXTRA +=-le
else
met_lib :=$(met_lib)$(PS)be
LD +=-HB
CFLAGS_EXTRA  +=-HB
ASFLAGS_EXTRA +=-be
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_thumb)),)
met_lib :=$(met_lib)$(PS)thumb
endif


# EOF
