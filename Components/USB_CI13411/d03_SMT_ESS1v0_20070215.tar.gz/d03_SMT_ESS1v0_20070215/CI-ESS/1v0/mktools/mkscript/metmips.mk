################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################

###########################################################
#
# Now define the executables used to build the project.
# We need a compiler (CC), assembler (AS), archiver (AR)
# and linker (LD).  We may also define a map file generator
# (NM) (if not done by the linker), a binary conversion
# utility (CV)
#

CV=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)elf2hex

CC=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcmips
AS=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)asmips
AR=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)armips

ifdef MQX_NO_C_COMPILER_RUNTIME
LD=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcmips -Bstatic -Bgrouplib -Hnocrt
else
LD=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcmips -Heos=mqx -Bstatic -Bgrouplib -Hhostlink
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_mips_soft)),)
LD +=-fsoft
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_mips_hard)),)
ASFLAGS_EXTRA +=-DMQX_FP_REGISTERS_EXIST=1
endif

LD += -Hcrt=$(MQX_BSP_LIB_DIR)$(PS)boot.o
LIBC=libct.a
ifdef MIPS16
LD+= -mips16
endif

###########################################################
#
# Define various PSP-dependant variables needed for
# compiler/assembler/linker options.
#
# There are two ways to do this:
#
#       processor: variable=value
#
# and
#
#       ifeq ($(MQX_PSP),processor)
#           variable=value
#       endif
#
# There's a very important difference between them:
# In the first case, variable is only defined during
# the 'start' rule (and not when compiling, assembling,
# archiving or linking), and in the second, variable
# is defined for all rules.
#
# Special variables:
#
#     CFLAGS            C compiler options, overridable
#                       on a per-file basis.
#
#     ASFLAGS           Assembler options, overridable
#                       on a per-file basis.
#
#     CPPFLAGS          C preprocessor options.  This
#                       variable shouldn't be set here.
#                       It's intended for users who want
#                       to override preprocessor variables
#                       without having to modify source
#                       code.
#
#     CFLAGS_EXTRA      C compiler options common to
#                       all C files.
#
#     ASFLAGS_EXTRA     Assembler options common to
#                       all assembly files.
#
#     CPPFLAGS_EXTRA    C preprocessor options, common
#                       to all C files.
#
#     MQX_INCDIRS       A list of include directories.
#                       This list already contains the
#                       BSP and PSP directories, as well
#                       as project-specific directories.
#                       We must add compiler include
#                       directories here.
#
# CPPFLAGS_EXTRA and MQX_INCDIRS are also used by
# 'make depend', so they must be defined using the
# second form above.
#

CFLAGS   =
ASFLAGS  =

ifdef MQX_SMALL_SIZE
CFLAGS += -Os
CFLAGS_EXTRA += -DMQX_COMPILE_FOR_SMALL_SIZE
else
ifndef MQX_NO_OPTIMIZATION
CFLAGS   +=-O
endif
endif

CFLAGS_EXTRA   +=-Hon=Long_enums  
ASFLAGS_EXTRA  +=-c -Eo -DMQX_CPU=$(MQX_CPU)

ifndef MQX_NO_DEBUG
ASFLAGS += -g
CFLAGS  += -g
endif

ifdef MQX_DO_PROFILING
CFLAGS += -pg -D__PROFILE__
LD += -pg -Hheap=32768
else
LD += -Hheap=0
endif

ifdef MQX_NO_C_COMPILER_RUNTIME
CFLAGS_EXTRA += -DMQX_NO_C_COMPILER_RUNTIME
endif

ifdef MQX_DO_CPPLUS
CFLAGS_EXTRA   +=-Hcplus
else
CFLAGS_EXTRA   +=-Hnocplus
LD += -Hnocplus
endif

ifdef MQX_COMPRESS_INITDATA
CFLAGS_EXTRA += -DMQX_COMPRESS_INITDATA
else
CFLAGS_EXTRA += -Hnocopyr
LD += -Hnocopyr
endif

ifneq ($(findstring -DMQX_KERNEL_LOGGING=0,$(CPPFLAGS)),)
ASFLAGS_EXTRA += -DMQX_KERNEL_LOGGING=0
endif


CFLAGS_EXTRA   +=-Hoff=check_divide_by_zero
ifeq ($(MQX_PSP),pr1900)
CFLAGS_EXTRA += -Hpr1900
endif
ifeq ($(MQX_PSP),pr1910)
CFLAGS_EXTRA += -Hpr1900
endif
ifdef MIPS16
CFLAGS_EXTRA += -mips16
endif
ifneq ($(findstring $(MQX_PSP),$(met_procs_mips_soft)),)
CFLAGS_EXTRA   +=-fsoft
endif

MQX_INCDIRS +=$(MQX_COMPILER_ROOT)$(PS)inc

met_boot =$(MQX_BSP_LIB_DIR)$(PS)met.o

met_lib =lib

ifeq ($(MQX_ENDIAN),l)
CFLAGS_EXTRA  +=-HL
ASFLAGS_EXTRA +=-le
met_lib :=$(met_lib)$(PS)le
LD +=-HL
else
CFLAGS_EXTRA  +=-HB
ASFLAGS_EXTRA +=-be
LD +=-HB
met_lib :=$(met_lib)$(PS)be
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_mips_hard)),)
met_lib :=$(met_lib)$(PS)fp
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_mips_soft)),)
met_lib :=$(met_lib)$(PS)fsoft
endif

ifdef MIPS16
met_lib :=$(met_lib)$(PS)mips16
endif

# EOF
