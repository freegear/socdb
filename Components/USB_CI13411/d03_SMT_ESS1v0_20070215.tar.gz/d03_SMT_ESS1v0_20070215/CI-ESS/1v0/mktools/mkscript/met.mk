################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################


###########################################################
#
# Define groups of PSPs.  This grouping is only used
# by this file, so we're free to group (or not group)
# any way that makes things convenient.
#
# The grouping is used mainly for choosing compiler,
# assembler and linker options that depend on the PSP.
#
# However, three things must be done here:
#   1) make .PHONY depend on all supported PSPs
#   2) make all supported PSPs depend on 'start'
#   3) check if MQX_PSP is in the supported list; if
#      not, delete the MQX_CPU variable
#

# START CR 315
met_procs_arc   = arca arctc arcsim arcta4 arcta5 arcta422t arcta52
# END CR 315

met_procs_sarm   = sa110 sa1100
met_procs_arm7v4 = aat4040
met_procs_xscale = i80200 cotulla
# START CR 314
met_procs_thumb = am7tdmi ks50100 ep7312 $(met_procs_xscale)
# END CR 314
met_procs_arm   = $(met_procs_sarm) $(met_procs_thumb) $(met_procs_arm7v4)

met_procs_ppch  = ppc603 ppc604 ppc740 ppc7400 ppc750 mpc8240 mpc8260
met_procs_ppcs  = ppc401 ppc403 ppc405 mpc505  mpc801 mpc821  mpc823 mpc850 mpc855 mpc860
met_procs_ppc   = $(met_procs_ppcs) $(met_procs_ppch)

# START CR 316
met_procs_mips_soft = f731940 pr1900 pr1910
# END CR 316
met_procs_mips      = $(met_procs_mips_soft) $(met_procs_mips_hard)

met_procs_all = $(met_procs_arc) $(met_procs_arm) $(met_procs_ppc) \
   $(met_procs_mips)

.PHONY: $(met_procs_all)

$(met_procs_all): start

ifeq ($(findstring $(MQX_PSP),$(met_procs_all)),)
    MQX_CPU=
endif

###########################################################
#
# Define the filename extensions used for assembly files,
# object files, archives, and binaries.
#

MQX_AEXT=met
MQX_OEXT=o
MQX_LEXT=a
MQX_XEXT=elf

###########################################################
#
# Now define the executables used to build the project.
# We need a compiler (CC), assembler (AS), archiver (AR)
# and linker (LD).  We may also define a map file generator
# (NM) (if not done by the linker), a binary conversion
# utility (CV)
#

CV=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)elf2hex

ifneq ($(findstring $(MQX_PSP),$(met_procs_arc)),)
include $(MQX_MAKEFILE_DIR)/metarc.mk
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_arm)),)
include $(MQX_MAKEFILE_DIR)/metarm.mk
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_ppc)),)
include $(MQX_MAKEFILE_DIR)/metppc.mk
endif

ifneq ($(findstring $(MQX_PSP),$(met_procs_mips)),)
include $(MQX_MAKEFILE_DIR)/metmips.mk
endif

# This must be defined for the processors
CPPFLAGS_EXTRA +=-D__MET__

###########################################################
#
# The start rule.  This rule's purpose is to create
# any command files that may be required by the compiler,
# assembler or linker.
#
# Special variables:
#
#   MQX_BSP             If MQX_BSP is not defined, then
#                       we are building a library that
#                       depends only on the PSP.  Also
#                       note that if MQX_BSP is not
#                       defined, then MQX isn't defined
#                       either.
#
#   MQX_INCDIRS         A space-separated list of
#                       directories that need to be placed
#                       on the compiler's include path.
#
#   MQX_LIBS            A space-separated list of library
#                       files (without extensions) that
#                       need to be linked with the
#                       executable.
#
# Special files:
#   mqx.cmd         Compiler command file
#   mqx.lmd         Linker command file
#   met_as.cmd      File to be .include'd in assembly source files
#

start:
ifeq ($(MQX_PROJ),mqx)
	@$(ECHO) Building the $(MQX_PSP) PSP with $(MQX_COMPILER)
else
ifeq ($(MQX_PROJ),$(MQX_BSP))
	@$(ECHO) Building the $(MQX_BSP) BSP with $(MQX_COMPILER)
else
	@$(ECHO) Building $(MQX_PROJ) for the $(MQX_BSP) BSP with $(MQX_COMPILER)
endif
endif
	@$(IFEXISTFILE)errors$(ENDIFEXISTFILE) $(RM) errors
	@$(ECHO) -c -Hefile=@ > mqx.cmd
	@$(ECHO) $(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA) >> mqx.cmd
	@$(ECHO) $(addprefix -I,$(MQX_INCDIRS)) >> mqx.cmd
ifdef MQX_BSP
	@$(ECHO) $(addsuffix .a,$(MQX_LIBS)) > mqx.lmd
	@$(ECHO) $(MQX_COMPILER_ROOT)$(PS)$(met_lib)$(PS)$(LIBC) >> mqx.lmd
endif

###########################################################
#
# Finally, the meta-commands.  These are sequences of
# commands for assembling, compiling, archiving and linking.
# There should also by a 'mostlyclean' that deletes all
# intermediary files.
#

define MQX_CC
	@$(IFEXISTFILE)$@$(ENDIFEXISTFILE) $(RM) $@
	@$(ECHO) $(CC) $(CFLAGS) $(CPPFLAGS) $< @mqx.cmd >> errors
	@$(ECHO) $(CC) $(CFLAGS) $(CPPFLAGS) $< @mqx.cmd
	@$(CC) $(CFLAGS) $(CPPFLAGS) $< @mqx.cmd >> errors
endef

define MQX_AS
	@$(IFEXISTFILE)$@$(ENDIFEXISTFILE) $(RM) $@
	@$(CP) $< $(basename $<).s
	@$(ECHO) $(AS) $(ASFLAGS_EXTRA) $(ASFLAGS) $(basename $<).s >> errors
	@$(ECHO) $(AS) $(ASFLAGS_EXTRA) $(ASFLAGS) $(basename $<).s
	@$(AS) $(ASFLAGS_EXTRA) $(ASFLAGS) $(basename $<).s >> errors
endef

define MQX_AR
	$(AR) -rvs $(MQX_PROJ).a $?
	$(AR) -t $(MQX_PROJ).a > $(MQX_PROJ).lst
	@$(IFEXISTFILE)mqx.cmd$(ENDIFEXISTFILE) $(RM) mqx.cmd
	@$(IFEXISTFILE)mqx.lmd$(ENDIFEXISTFILE) $(RM) mqx.lmd
	@$(IFEXISTFILE)met_as.cmd$(ENDIFEXISTFILE) $(RM) met_as.cmd
endef

define MQX_LD
	@$(CP) $(MQX_BSP_LIB_DIR)$(PS)link.met . > $(NULL)
	@$(IFEXISTFILE)$(PROJECT_SRC_DIR)$(PS)link.met$(ENDIFEXISTFILE) $(CP) $(PROJECT_SRC_DIR)$(PS)link.met . > $(NULL)
	@$(ECHO) $(LD) link.met -m -o $(MQX_PROJ).elf $(met_boot) $^ @mqx.lmd
	@$(LD) link.met -m -o $(MQX_PROJ).elf $(met_boot) $^ @mqx.lmd > $(MQX_PROJ).map
	$(CV) $(MQX_PROJ).elf
	@$(IFEXISTFILE)mqx.cmd$(ENDIFEXISTFILE) $(RM) mqx.cmd
	@$(IFEXISTFILE)mqx.lmd$(ENDIFEXISTFILE) $(RM) mqx.lmd
	@$(IFEXISTFILE)met_as.cmd$(ENDIFEXISTFILE) $(RM) met_as.cmd
endef

define NO_OS_LD
	@$(ECHO) $(addsuffix .a,$(NO_OS_LIBS)) > no_os.lmd
	@$(ECHO) $(addsuffix .a,$(NO_OS_LIBS)) >> no_os.lmd
	@$(ECHO) $(MQX_COMPILER_ROOT)$(PS)$(met_lib)$(PS)$(LIBC) >> no_os.lmd
	@$(IFEXISTFILE)$(PROJECT_SRC_DIR)$(PS)link.met$(ENDIFEXISTFILE) $(CP) $(PROJECT_SRC_DIR)$(PS)link.met . > $(NULL)
	@$(ECHO) $(NO_OS_LD_CMD) -m -o $(MQX_PROJ).elf $^ @no_os.lmd
	@$(NO_OS_LD_CMD) -m -o $(MQX_PROJ).elf $^ @no_os.lmd > $(MQX_PROJ).map
	$(CV) $(MQX_PROJ).elf
	@$(IFEXISTFILE)no_os.lmd$(ENDIFEXISTFILE) $(RM) no_os.lmd
endef

ifeq ($(MQX_CMD),)
define MQX_DEPEND
	$(CC) -Hmakeof=$@ -E -D__NO_SETJMP $(CPPFLAGS_EXTRA) $(CPPFLAGS) $(addprefix -I ,$(MQX_INCDIRS)) $< > $(NULL)
endef
else
define MQX_DEPEND
	$(CPP) -M -D__NO_SETJMP $(CPPFLAGS_EXTRA) $(CPPFLAGS) $(addprefix -I ,$(MQX_INCDIRS)) $< > $@
endef
endif

define MQX_MOSTLYCLEAN
	@$(IFEXISTFILE)*.o$(ENDIFEXISTFILE) $(RM) *.o
	@$(IFEXISTFILE)*.d$(ENDIFEXISTFILE) $(RM) *.d
	@$(IFEXISTFILE)mqx.cmd$(ENDIFEXISTFILE) $(RM) mqx.cmd
	@$(IFEXISTFILE)mqx.lmd$(ENDIFEXISTFILE) $(RM) mqx.lmd
	@$(IFEXISTFILE)met_as.cmd$(ENDIFEXISTFILE) $(RM) met_as.cmd
endef

# EOF
