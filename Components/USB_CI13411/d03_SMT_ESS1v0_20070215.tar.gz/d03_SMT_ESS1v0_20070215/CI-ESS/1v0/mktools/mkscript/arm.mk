################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################


###########################################################
#
# Define groups of PSPs.  This grouping is only used
# by this file, so we're free to group (or not group)
# any way that makes things convenient.
#
# The grouping is used mainly for choosing compiler,
# assembler and linker options that depend on the PSP.
#
# However, three things must be done here:
#   1) make .PHONY depend on all supported PSPs
#   2) make all supported PSPs depend on 'start'
#   3) check if MQX_PSP is in the supported list; if
#      not, delete the MQX_CPU variable
#

arm_procs_sarm   = sa110 sa1100
arm_procs_arm7v4 = aat4040
arm_procs_xscale = i80200 cotulla
arm_procs_thumb  = arm7tdmi am7tdmi at40400 ks41000 ks50100 3205472 $(arm_procs_xscale) ep7312
arm_procs_arm    = $(arm_procs_sarm) $(arm_procs_thumb) $(arm_procs_arm7v4)
arm_procs_all = $(arm_procs_sarm) $(arm_procs_thumb) $(arm_procs_arm7v4) $(arm_procs_xscale)

.PHONY: $(arm_procs_all)

$(arm_procs_all): start

ifeq ($(findstring $(MQX_PSP),$(arm_procs_all)),)
    MQX_CPU=
endif

###########################################################
#
# Define the filename extensions used for assembly files,
# object files, archives, and binaries.
#

MQX_AEXT=arm
MQX_OEXT=o
MQX_LEXT=lib
MQX_XEXT=elf

###########################################################
#
# Now define the executables used to build the project.
# We need a compiler (CC), assembler (AS), archiver (AR)
# and linker (LD).  We may also define a map file generator
# (NM) (if not done by the linker), and a binary conversion
# utility (CV) (if not done by the linker).
#
                                
ifneq ($(findstring $(MQX_PSP),$(arm_procs_thumb)),)
ifeq ($(ARMCONF),)
CC=$(MQX_COMPILER_ROOT)\bin\tcc
AS=$(MQX_COMPILER_ROOT)\bin\tasm
AR=$(MQX_COMPILER_ROOT)\bin\armlib
LD=$(MQX_COMPILER_ROOT)\bin\armlink
LIBC=embedded\armlib_i.16
CFLAGS =-g+ -gtp -gxr -Ospace
else
CC=$(MQX_COMPILER_ROOT)\bin\tcc
AS=$(MQX_COMPILER_ROOT)\bin\armasm -16
AR=$(MQX_COMPILER_ROOT)\bin\armar
LD=$(MQX_COMPILER_ROOT)\bin\armlink
FE=$(MQX_COMPILER_ROOT)\bin\fromelf
CFLAGS =-g -Ospace
endif
else
ifeq ($(ARMCONF),)
CC=$(MQX_COMPILER_ROOT)\bin\armcc
AS=$(MQX_COMPILER_ROOT)\bin\armasm
AR=$(MQX_COMPILER_ROOT)\bin\armlib
LD=$(MQX_COMPILER_ROOT)\bin\armlink
LIBC=embedded\armlib_cn.32
CFLAGS =-g+ -gtp -gxr -Otime
else
CC=$(MQX_COMPILER_ROOT)\bin\armcc
AS=$(MQX_COMPILER_ROOT)\bin\armasm -32 
AR=$(MQX_COMPILER_ROOT)\bin\armar
LD=$(MQX_COMPILER_ROOT)\bin\armlink
FE=$(MQX_COMPILER_ROOT)\bin\fromelf
CFLAGS =-g -Otime
endif
endif

###########################################################
#
# Define various PSP-dependant variables needed for
# compiler/assembler/linker options.
#
# There are two ways to do this:
#
#       processor: variable=value
#
# and
#
#       ifeq ($(MQX_PSP),processor)
#           variable=value
#       endif
#
# There's a very important difference between them:
# In the first case, variable is only defined during
# the 'start' rule (and not when compiling, assembling,
# archiving or linking), and in the second, variable
# is defined for all rules.
#
# Special variables:
#
#     CFLAGS            C compiler options, overridable
#                       on a per-file basis.
#
#     ASFLAGS           Assembler options, overridable
#                       on a per-file basis.
#
#     CPPFLAGS          C preprocessor options.  This
#                       variable shouldn't be set here.
#                       It's intended for users who want
#                       to override preprocessor variables
#                       without having to modify source
#                       code.
#
#     CFLAGS_EXTRA      C compiler options common to
#                       all C files.
#
#     ASFLAGS_EXTRA     Assembler options common to
#                       all assembly files.
#
#     CPPFLAGS_EXTRA    C preprocessor options, common
#                       to all C files.
#
#     MQX_INCDIRS       A list of include directories.
#                       This list already contains the
#                       BSP and PSP directories, as well
#                       as project-specific directories.
#                       We must add compiler include
#                       directories here.
#
# CPPFLAGS_EXTRA and MQX_INCDIRS are also used by
# 'make depend', so they must be defined using the
# second form above.
#

ASFLAGS  =-g

ifeq ($(ARMCONF),)
CFLAGS_EXTRA   =-ef -ec -apcs /32bit/nonreentrant/noswstackcheck -Wu -Wd -Wf -c -zas1 -fyi -errors err 
ASFLAGS_EXTRA  =-apcs /32bit/noswstackcheck -checkreglist -errors err
else
CFLAGS_EXTRA   =-ef -ec -apcs /noswstackcheck -Wu -Wd -Wf -c -zas1 -fyi -errors err 
ASFLAGS_EXTRA  =-apcs /noswstackcheck -checkreglist -errors err
endif
# Start CR 293
CPPFLAGS_EXTRA +=-D__ARM__
# End CR 293

ifneq ($(findstring $(MQX_PSP),$(arm_procs_sarm)),)
CFLAGS_EXTRA   +=-cpu StrongARM1
ASFLAGS_EXTRA  +=-cpu StrongARM1
endif
ifneq ($(findstring $(MQX_PSP),$(arm_procs_thumb)),)
CFLAGS_EXTRA   +=-cpu ARM7TM
ASFLAGS_EXTRA  +=-cpu ARM7TM
endif
ifneq ($(findstring $(MQX_PSP),$(arm_procs_arm7v4)),)
CFLAGS_EXTRA   +=-architecture 4
ASFLAGS_EXTRA  +=-cpu ARM7
endif
ifneq ($(findstring $(MQX_PSP),$(arm_procs_xscale)),)
CFLAGS_EXTRA   +=-cpu xscale  
ASFLAGS_EXTRA  +=-cpu xscale
endif

ifeq ($(MQX_ENDIAN),l)
CFLAGS_EXTRA  +=-littleend
ASFLAGS_EXTRA +=-littleend
else
CFLAGS_EXTRA  +=-bigend
ASFLAGS_EXTRA +=-bigend
endif

MQX_INCDIRS +=$(MQX_COMPILER_ROOT)\include

arm_boot =$(MQX_BSP_LIB_DIR)\boot.o

ifeq ($(ARMCONF),)
arm_lib =$(LIBC)
ifeq ($(MQX_ENDIAN),b)
arm_lib :=lib\$(arm_lib)b
else
arm_lib :=lib\$(arm_lib)l
endif
endif


###########################################################
#
# The start rule.  This rule's purpose is to create
# any command files that may be required by the compiler,
# assembler or linker.
#
# Special variables:
#
#   MQX_BSP             If MQX_BSP is not defined, then
#                       we are building a library that
#                       depends only on the PSP.  Also
#                       note that if MQX_BSP is not
#                       defined, then MQX isn't defined
#                       either.
#
#   MQX_INCDIRS         A space-separated list of
#                       directories that need to be placed
#                       on the compiler's include path.
#
#   MQX_LIBS            A space-separated list of library
#                       files (without extensions) that
#                       need to be linked with the
#                       executable.
#
# Special files:
#   mqx.cmd         Compiler command file
#   mqx.lmd         Linker command file
#

start:
ifdef MQX_BSP
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_BSP) BSP with $(MQX_COMPILER)
else
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_PSP) with $(MQX_COMPILER)
endif
	@$(MQX_CMD) if exist errors del errors
	@$(MQX_CMD) echo $(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA) >  mqx.cmd
	@$(MQX_CMD) echo $(addprefix -I,$(MQX_INCDIRS))    >> mqx.cmd
ifdef MQX_BSP
	@$(MQX_CMD) echo $(MQX_BSP_LIB_DIR)\boot.o          >  mqx.lmd
	@$(MQX_CMD) echo $(addsuffix .lib,$(MQX_LIBS))      >> mqx.lmd
ifeq ($(ARMCONF),)
	@$(MQX_CMD) echo $(MQX_COMPILER_ROOT)\$(arm_lib)    >> mqx.lmd
endif
endif

###########################################################
#
# Finally, the meta-commands.  These are sequences of
# commands for assembling, compiling, archiving and linking.
# There should also by a 'mostlyclean' that deletes all
# intermediary files.
#

define MQX_CC
	@$(MQX_CMD) if exist $@ del $@
	$(CC) $(CFLAGS) $(CPPFLAGS) $< -via mqx.cmd
	@$(MQX_CMD) if exist err type err >> errors
	@$(MQX_CMD) if exist err del  err
endef

define MQX_AS
	@$(MQX_CMD) if exist $@ del $@
    @$(MQX_CMD) echo MQX_CPU EQU $(MQX_CPU) > arm_asm.cmd
	$(AS) $(ASFLAGS_EXTRA) $(ASFLAGS) $<
	@$(MQX_CMD) if exist err type err >> errors
	@$(MQX_CMD) if exist err del  err
endef

ifeq ($(ARMCONF),)
define MQX_AR
	@$(MQX_CMD) if not exist $(MQX_PROJ).lib $(AR) -o -c $(MQX_PROJ).lib
	$(AR) -o -i $(MQX_PROJ).lib $?
	$(AR) -l $(MQX_PROJ).lib > $(MQX_PROJ).lst
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

define MQX_LD
	$(LD) -via mqx.lmd -FIRST "boot.o(S_BOOT)" -base $(MQX_BSP_ENTRY) -elf -info totals -map -symbols - -errors err -o $(MQX_PROJ).elf $^ > $(MQX_PROJ).map
	@$(MQX_CMD) if exist err type err >> errors
	@$(MQX_CMD) if exist err del  err
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef
else
define MQX_AR
	$(AR) -r $(MQX_PROJ).lib $?
	$(AR) -t $(MQX_PROJ).lib > $(MQX_PROJ).lst
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

define MQX_LD
   $(LD) -via mqx.lmd -FIRST "boot.o(S_BOOT)" -ro-base $(MQX_BSP_ENTRY) -elf -info totals -map -symbols -list $(MQX_PROJ).map -errors err -o $(MQX_PROJ).elf $^ 
   $(FE) -m32 -output $(MQX_PROJ).hex $(MQX_PROJ).elf
	@$(MQX_CMD) if exist err type err >> errors
	@$(MQX_CMD) if exist err del  err
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef
endif


define MQX_DEPEND
	$(CPP) -M $(CPPFLAGS_EXTRA) $(CPPFLAGS) $(addprefix -I ,$(MQX_INCDIRS)) $< > $@
endef

define MQX_MOSTLYCLEAN
	@$(MQX_CMD) if exist *.o del *.o
	@$(MQX_CMD) if exist *.d del *.d
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

# EOF
