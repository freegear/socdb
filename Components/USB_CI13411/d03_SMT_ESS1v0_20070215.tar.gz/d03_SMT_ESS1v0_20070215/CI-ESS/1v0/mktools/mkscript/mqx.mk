################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################

#
# Under Win9x, COMSPEC is defined, but ComSpec isn't,
# and under WinNT, ComSpec is defined, but COMSPEC isn't!
#

ifdef ComSpec
    MQX_CMD=$(ComSpec) /C
endif
ifdef COMSPEC
    MQX_CMD=$(COMSPEC) /C
endif

nullstring=
space=$(nullstring) # one space

ifdef MQX_CMD
    PS=\$(nullstring)
    NULL=nul
    OPENPAREN=(
    CLOSEPAREN=)

    IFNOTEXISTDIR=$(MQX_CMD) if not exist$(space)
    ENDIFNOTEXISTDIR=\nul

    IFEXISTFILE=$(MQX_CMD) if exist$(space)
    ENDIFEXISTFILE=

    ECHO=$(MQX_CMD) echo
    CP=$(MQX_CMD) copy
    RM=del
    MKDIR=md
    RMDIR=$(MQX_CMD) rd

    CAT=copy
    CATWITH=+
    CATTO=
    CATEND=

    RMALL=@$(MQX_CMD) echo y | del$(space)
    ENDRMALL=$(space)> nul
else
    PS=/
    NULL=/dev/null
    OPENPAREN=\(
    CLOSEPAREN=\)

    IFNOTEXISTDIR=[ -d$(space)
    ENDIFNOTEXISTDIR=$(space)] ||

    IFEXISTFILE=[ ! -f$(space)
    ENDIFEXISTFILE=$(space)] ||

    ECHO=echo
    CP=cp -p
    RM=rm
    MKDIR=mkdir -p
    RMDIR=rmdir

    CAT=( cat
    CATWITH=
    CATTO=tmp && mv tmp
    CATEND=)

    RMALL=rm -f$(space)
    ENDRMALL=/*
endif


#
# Define the variable MQX_CPU to be a number based on
# MQX_PSP.  MQX_CPU will be available in the source as
# preprocessor variable MQX_CPU.
#
# (So why does MQX_CPU have to be numeric?  Why not
# just use MQX_PSP?  Because it will also be available
# as variable MQX_CPU in assembly files, and some
# assemblers require all variables to be numeric.)
#
# Define MQX_PSP_SRC_DIR which is the directory
# in the psp directory where the source for the psp can
# be found
#
# Define MQX_CPU_SUPPORT (optional) which is the file
# containing CPU support functions, compiled from the psp
#

########################## 68000 #################################

ifneq ($(findstring $(MQX_PSP),68000 68306 68307 68322),)
    MQX_CPU=68000
    MQX_PSP_SRC_DIR=68000
endif
ifneq ($(findstring $(MQX_PSP),68302),)
    MQX_CPU=68302
    MQX_PSP_SRC_DIR=68000
    MQX_CPU_SUPPORT=mc68302
endif
ifneq ($(findstring $(MQX_PSP),68lc302),)
    MQX_CPU=683021
    MQX_PSP_SRC_DIR=68000
    MQX_CPU_SUPPORT=mc68302
endif
ifneq ($(findstring $(MQX_PSP),68en302),)
    MQX_CPU=683022
    MQX_PSP_SRC_DIR=68000
    MQX_CPU_SUPPORT=mc68302
endif
ifneq ($(findstring $(MQX_PSP),68328),)
    MQX_CPU=68328
    MQX_PSP_SRC_DIR=68000
    MQX_CPU_SUPPORT=mc68328
endif
ifneq ($(findstring $(MQX_PSP),68ez328),)
    MQX_CPU=683281
    MQX_PSP_SRC_DIR=68000
    MQX_CPU_SUPPORT=mc68328
endif
ifneq ($(findstring $(MQX_PSP),68356),)
    MQX_CPU=68356
    MQX_PSP_SRC_DIR=68000
endif

########################## CPU32 #################################

ifneq ($(findstring $(MQX_PSP),68330 68331 68332 68333 68334 68336 68340 68341 68349 68376 cpu32),)
    MQX_CPU=68332
    MQX_PSP_SRC_DIR=CPU32
endif
ifneq ($(findstring $(MQX_PSP),68360),)
    MQX_CPU=68360
    MQX_PSP_SRC_DIR=CPU32
    MQX_CPU_SUPPORT=mc68360
endif

########################## 68020 #################################

ifneq ($(findstring $(MQX_PSP),68020),)
    MQX_CPU=68020
    MQX_PSP_SRC_DIR=68020
endif

########################## 68040 #################################

ifneq ($(findstring $(MQX_PSP),68040),)
    MQX_CPU=68040
    MQX_PSP_SRC_DIR=68040
endif
ifneq ($(findstring $(MQX_PSP),68l40),)
    MQX_CPU=68041
    MQX_PSP_SRC_DIR=68040
endif
ifneq ($(findstring $(MQX_PSP),68e40),)
    MQX_CPU=68042
    MQX_PSP_SRC_DIR=68040
endif

########################## 68060 #################################

ifneq ($(findstring $(MQX_PSP),68060),)
    MQX_CPU=68060
    MQX_PSP_SRC_DIR=68060
endif
ifneq ($(findstring $(MQX_PSP),68l60),)
    MQX_CPU=68061
    MQX_PSP_SRC_DIR=68060
endif
ifneq ($(findstring $(MQX_PSP),68e60),)
    MQX_CPU=68062
    MQX_PSP_SRC_DIR=68060
endif

########################## ARC #################################

ifneq ($(findstring $(MQX_PSP),arca),)
    MQX_CPU=0xAC00
    MQX_PSP_SRC_DIR=arc
endif
ifneq ($(findstring $(MQX_PSP),arctc),)
    MQX_CPU=0xAC01
    MQX_PSP_SRC_DIR=arc
endif
ifneq ($(findstring $(MQX_PSP),arcsim),)
    MQX_CPU=0xAC02
    MQX_PSP_SRC_DIR=arc
endif
ifneq ($(findstring $(MQX_PSP),arcta4),)
    MQX_CPU=0xACA4
    MQX_PSP_SRC_DIR=arc
    MQX_CPU_SUPPORT=arcta4
endif
# START CR 315
ifneq ($(findstring $(MQX_PSP),arcta5),)
    MQX_CPU=0xACA5
    MQX_PSP_SRC_DIR=arc5
    MQX_CPU_SUPPORT=arcta5
endif
# END CR 315
ifneq ($(findstring $(MQX_PSP),arcta52),)
    MQX_CPU=0xACA52
    MQX_PSP_SRC_DIR=arc5
    MQX_CPU_SUPPORT=arcta52
endif

# START CR 481
ifeq ($(MQX_PSP),arcta422t)
    MQX_CPU=0xACA41
    MQX_PSP_SRC_DIR=arc
endif
# END CR 481 

########################## ARM #################################

ifeq ($(MQX_PSP),sa1100)
    MQX_CPU=1100
    MQX_PSP_SRC_DIR=arm
    MQX_CPU_SUPPORT=sa1100
endif
ifeq ($(MQX_PSP),sa110)
    MQX_CPU=110
    MQX_PSP_SRC_DIR=arm
    MQX_CPU_SUPPORT=sa110
endif

########################## ARM THUMB #################################

ifneq ($(findstring $(MQX_PSP),arm7tdmi),)
    override MQX_PSP=am7tdmi
    MQX_CPU=900
    MQX_PSP_SRC_DIR=armth
    MQX_CPU_SUPPORT=arm7tdmi
endif
ifneq ($(findstring $(MQX_PSP),ks41000),)
    MQX_CPU=901
    MQX_PSP_SRC_DIR=armth
    MQX_CPU_SUPPORT=ks41000
endif
ifneq ($(findstring $(MQX_PSP),at40400),)
    MQX_CPU=902
    MQX_PSP_SRC_DIR=armth
    MQX_CPU_SUPPORT=at40400
endif
ifneq ($(findstring $(MQX_PSP),ks50100),)
    MQX_CPU=903
    MQX_PSP_SRC_DIR=armth
    MQX_CPU_SUPPORT=ks50100
endif
ifneq ($(findstring $(MQX_PSP),3205472),)
    MQX_CPU=905
    MQX_PSP_SRC_DIR=armth
    MQX_CPU_SUPPORT=3205472
endif
ifneq ($(findstring $(MQX_PSP),i80200),)
    MQX_CPU=906
    MQX_PSP_SRC_DIR=armth
    MQX_CPU_SUPPORT=i80200
endif
# START CR 314
ifneq ($(findstring $(MQX_PSP),ep7312),)
    MQX_CPU=907
    MQX_PSP_SRC_DIR=armth
    MQX_CPU_SUPPORT=ep7312
endif
# END CR 314
ifneq ($(findstring $(MQX_PSP),cotulla),)
    MQX_CPU=908
    MQX_PSP_SRC_DIR=armth
    MQX_CPU_SUPPORT=cotulla
endif

########################## COLDFIRE #######################################

ifneq ($(findstring $(MQX_PSP),mcf5206),)
    MQX_CPU=5206
    MQX_PSP_SRC_DIR=coldfire
    MQX_CPU_SUPPORT=mcf5206
endif
ifneq ($(findstring $(MQX_PSP),mcf5206e),)
    MQX_CPU=52061
    MQX_PSP_SRC_DIR=coldfire
    MQX_CPU_SUPPORT=mcf5206e
endif
ifneq ($(findstring $(MQX_PSP),mcf5307),)
    MQX_CPU=5307
    MQX_PSP_SRC_DIR=coldfire
    MQX_CPU_SUPPORT=mcf5307
endif

########################## MCORE #######################################

ifneq ($(findstring $(MQX_PSP),mcore),)
    MQX_CPU=0x1200
    MQX_PSP_SRC_DIR=mcore
endif
ifneq ($(findstring $(MQX_PSP),mmc2001),)
    MQX_CPU=0x1201
    MQX_PSP_SRC_DIR=mcore
    MQX_CPU_SUPPORT=mmc2001
endif
ifneq ($(findstring $(MQX_PSP),mmc2080),)
    MQX_CPU=0x1202
    MQX_PSP_SRC_DIR=mcore
endif

########################## POWERPC #######################################

ifneq ($(findstring $(MQX_PSP),iop480),)
    MQX_CPU=480
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=iop480
endif

ifneq ($(findstring $(MQX_PSP),ppc401),)
    MQX_CPU=401
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=ppc401
endif
ifneq ($(findstring $(MQX_PSP),ppc403),)
    MQX_CPU=403
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=ppc403
endif
ifneq ($(findstring $(MQX_PSP),ppc405),)
    MQX_CPU=405
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=ppc405
endif
ifneq ($(findstring $(MQX_PSP),ppc603),)
    MQX_CPU=603
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=ppc603
endif
ifneq ($(findstring $(MQX_PSP),ppc604),)
    MQX_CPU=604
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=ppc604
endif
ifneq ($(findstring $(MQX_PSP),ppc740),)
    MQX_CPU=740
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=ppc740
endif
ifneq ($(findstring $(MQX_PSP),ppc7400),)
    MQX_CPU=7400
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=ppc7400
endif
ifneq ($(findstring $(MQX_PSP),ppc750),)
    MQX_CPU=750
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=ppc750
endif

ifneq ($(findstring $(MQX_PSP),mpc505),)
    MQX_CPU=505
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=mpc505
endif
ifneq ($(findstring $(MQX_PSP),mpc555),)
    MQX_CPU=555
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=mpc555
endif
ifneq ($(findstring $(MQX_PSP),mpc801),)
    MQX_CPU=801
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=mpc801
endif
ifneq ($(findstring $(MQX_PSP),mpc821),)
    MQX_CPU=821
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=mpc821
endif
ifneq ($(findstring $(MQX_PSP),mpc823),)
    MQX_CPU=823
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=mpc823
endif
ifneq ($(findstring $(MQX_PSP),mpc850),)
    MQX_CPU=850
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=mpc850
endif
ifneq ($(findstring $(MQX_PSP),mpc855),)
    MQX_CPU=855
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=mpc855
endif
ifneq ($(findstring $(MQX_PSP),mpc860),)
    MQX_CPU=860
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=mpc860
endif
ifneq ($(findstring $(MQX_PSP),mpc8240),)
    MQX_CPU=8240
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=mpc8240
endif
ifneq ($(findstring $(MQX_PSP),mpc8260),)
    MQX_CPU=8260
    MQX_PSP_SRC_DIR=powerpc
    MQX_CPU_SUPPORT=mpc8260
endif

# START CR 316
########################## MIPS ###################################

ifeq ($(MQX_PSP),r3000)
    MQX_CPU=0x3000
    MQX_PSP_SRC_DIR=mips
endif
ifeq ($(MQX_PSP),rap)
    MQX_CPU=0xC4011
    MQX_PSP_SRC_DIR=mips
    MQX_CPU_SUPPORT=cw4011
endif
ifeq ($(MQX_PSP),lr4025)
    MQX_CPU=0xC4011
    MQX_PSP_SRC_DIR=mips
    MQX_CPU_SUPPORT=cw4011
endif
ifeq ($(MQX_PSP),atmizr2p)
    MQX_CPU=0xC4011
    MQX_PSP_SRC_DIR=mips
    MQX_CPU_SUPPORT=cw4011
endif
ifeq ($(MQX_PSP),saa7214)
    MQX_CPU=0xC4011
    MQX_PSP_SRC_DIR=mips
    MQX_CPU_SUPPORT=cw4011
endif
ifeq ($(MQX_PSP),f731940)
    MQX_CPU=0xF731940
    MQX_PSP_SRC_DIR=mips
    MQX_CPU_SUPPORT=f731940
endif
ifeq ($(MQX_PSP),pr1900)
    MQX_CPU=0x1900
    MQX_PSP_SRC_DIR=mips
    MQX_CPU_SUPPORT=pr1900
endif
ifeq ($(MQX_PSP),pr1910)
    MQX_CPU=0x1910
    MQX_PSP_SRC_DIR=mips
    MQX_CPU_SUPPORT=pr1910
endif
# END CR 316


########################## TMS320C30 ###################################

ifneq ($(findstring $(MQX_PSP),32030),)
    MQX_CPU=32030
    MQX_PSP_SRC_DIR=32030
endif
ifneq ($(findstring $(MQX_PSP),32031),)
    MQX_CPU=32031
    MQX_PSP_SRC_DIR=32030
endif
ifneq ($(findstring $(MQX_PSP),32032),)
    MQX_CPU=32032
    MQX_PSP_SRC_DIR=32030
    MQX_CPU_SUPPORT=32032
endif

########################## TMS320C40 ###################################

ifneq ($(findstring $(MQX_PSP),32040),)
    MQX_CPU=32040
    MQX_PSP_SRC_DIR=32040
    MQX_CPU_SUPPORT=32040
endif
ifneq ($(findstring $(MQX_PSP),32040b),)
    MQX_CPU=32040b
    MQX_PSP_SRC_DIR=32040
    MQX_CPU_SUPPORT=32040
endif

########################## TMS320C6XXX #################################

ifneq ($(findstring $(MQX_PSP),3206201),)
    MQX_CPU=3206201
    MQX_PSP_SRC_DIR=32060
    MQX_CPU_SUPPORT=3206201
endif
ifneq ($(findstring $(MQX_PSP),3206211),)
    MQX_CPU=3206211
    MQX_PSP_SRC_DIR=32060
    MQX_CPU_SUPPORT=3206211
endif
ifneq ($(findstring $(MQX_PSP),3206701),)
    MQX_CPU=3206701
    MQX_PSP_SRC_DIR=32060
    MQX_CPU_SUPPORT=3206701
endif
ifneq ($(findstring $(MQX_PSP),3206711),)
    MQX_CPU=3206711
    MQX_PSP_SRC_DIR=32060
    MQX_CPU_SUPPORT=3206711
endif

########################## TMS320C5XXX #################################

ifneq ($(findstring $(MQX_PSP),320542),)
    MQX_CPU=320542
    MQX_PSP_SRC_DIR=32054
endif
ifneq ($(findstring $(MQX_PSP),320548),)
    MQX_CPU=320548
    MQX_PSP_SRC_DIR=32054
endif
ifneq ($(findstring $(MQX_PSP),320549),)
    MQX_CPU=320549
    MQX_PSP_SRC_DIR=32054
endif

#################################################################
#
# Define some variables:
#
#     MQX_PSPLIB        The default PSP library directory name
#     MQX_PSP_LIB_DIR   The full path to the PSP library
#
# If MQX_BSP is defined, then also define:
#
#     MQX_BSPLIB        The default BSP library directory name
#     MQX_BSP_LIB_DIR   The full path to the BSP library
#     MQX_BSP_SRC_DIR   Where the BSP source can be found
#

    MQX_PSPLIB=$(MQX_PSP)$(MQX_ENDIAN).$(MQX_COMPILER)
ifeq ($(MQX_PSP_LIB_DIR),)
ifneq ($(MQX_ROOT),)
    MQX_PSP_LIB_DIR=$(MQX_ROOT)$(PS)lib$(PS)$(MQX_PSPLIB)
endif
endif

ifdef MQX_BSP
    MQX_BSPLIB=$(MQX_BSP)$(MQX_ENDIAN).$(MQX_COMPILER)
    MQX_BSP_SRC_DIR=$(MQX_BSP)
ifeq ($(MQX_BSP_LIB_DIR),)
ifneq ($(MQX_ROOT),)
    MQX_BSP_LIB_DIR=$(MQX_ROOT)$(PS)lib$(PS)$(MQX_BSPLIB)
endif
endif
endif

# START CR 293
#
# Initialize CPPFLAGS_EXTRA to include the CPU type
# (MQX_CPU) and the operating system (RTCS_OS)
#

RTCS_OS := $(subst m,M,$(subst q,Q,$(subst x,X,$(RTCS_OS))))
RTCS_OS := $(subst b,B,$(subst i,I,$(subst o,O,$(subst s,S,$(RTCS_OS)))))
CPPFLAGS_EXTRA =-DMQX_CPU=$(MQX_CPU) -DRTCS_OS_$(RTCS_OS)

ifneq ($(RTCS_OS),)
ifeq ($(findstring MQX,$(RTCS_OS)),)
MQX_NOMQXINCDIRS=1
endif
endif
# END CR 293

#
# Update MQX_INCDIRS and MQX_LIBS to include the BSP and PSP
# libraries.  Note: we want the BSP to be first and
# the PSP to be second.
#
# Special variables:
#
#   MQX_NOMQXINCDIRS    If MQX_NOMQXINCDIRS is defined,
#                       then we don't put MQX on the
#                       include path.  This is used when
#                       building MQX.
#
#   MQX_BSP             If MQX_BSP is not defined, then
#                       we are building a library that
#                       depends only on the PSP, so we
#                       can't include a BSP directory.
#

ifndef MQX_NOMQXINCDIRS
    MQX_INCDIRS :=$(MQX_PSP_LIB_DIR) $(MQX_INCDIRS)
    MQX_LIBS    :=$(MQX_PSP_LIB_DIR)$(PS)mqx $(MQX_LIBS)
ifdef MQX_BSP
    MQX_INCDIRS :=$(MQX_BSP_LIB_DIR) $(MQX_INCDIRS)
    MQX_LIBS    :=$(MQX_BSP_LIB_DIR)$(PS)$(MQX_BSP) $(MQX_LIBS)
endif
endif

# EOF
