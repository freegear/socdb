################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################


###########################################################
#
# Define groups of PSPs.  This grouping is only used
# by this file, so we're free to group (or not group)
# any way that makes things convenient.
#
# The grouping is used mainly for choosing compiler,
# assembler and linker options that depend on the PSP.
#
# However, three things must be done here:
#   1) make .PHONY depend on all supported PSPs
#   2) make all supported PSPs depend on 'start'
#   3) check if MQX_PSP is in the supported list; if
#      not, delete the MQX_CPU variable
#

it_procs_000 = 68000 68306 68307 68322 \
               68328 68ez328

it_procs_302 = 68302 68lc302 68en302 68356

it_procs_cpu = cpu32 \
               68330 68331 68332 68333 68334 68336 68376 \
               68349

it_procs_340 = 68340 68341

it_procs_360 = 68360

it_procs_all = $(it_procs_000) $(it_procs_302) $(it_procs_cpu) \
               $(it_procs_340) $(it_procs_360) \
               68020 68040 68l40 68e40 68060 68l60 68e60

.PHONY: $(it_procs_all)

$(it_procs_all): start

ifeq ($(findstring $(MQX_PSP),$(it_procs_all)),)
    MQX_CPU=
endif

###########################################################
#
# Define the filename extensions used for assembly files,
# object files, archives, and binaries.
#

MQX_AEXT=it
MQX_OEXT=ol
MQX_LEXT=lib
MQX_XEXT=abs

###########################################################
#
# Now define the executables used to build the project.
# We need a compiler (CC), assembler (AS), archiver (AR)
# and linker (LD).  We may also define a map file generator
# (NM) (if not done by the linker), and a binary conversion
# utility (CV) (if not done by the linker).
#

CC=$(MQX_COMPILER_ROOT)\bin\c$(it_cbin)
AS=$(MQX_COMPILER_ROOT)\bin\asm$(it_abin)
AR=$(MQX_COMPILER_ROOT)\bin\libr
LD=$(MQX_COMPILER_ROOT)\bin\llink
LD2=$(MQX_COMPILER_ROOT)\bin\form695
NM=$(MQX_COMPILER_ROOT)\bin\gsmap
CV=$(MQX_COMPILER_ROOT)\bin\form

###########################################################
#
# Define various PSP-dependant variables needed for
# compiler/assembler/linker options.
#
# There are two ways to do this:
#
#       processor: variable=value
#
# and
#
#       ifeq ($(MQX_PSP),processor)
#           variable=value
#       endif
#
# There's a very important difference between them:
# In the first case, variable is only defined during
# the 'start' rule (and not when compiling, assembling,
# archiving or linking), and in the second, variable
# is defined for all rules.
#
# Special variables:
#
#     CFLAGS            C compiler options, overridable
#                       on a per-file basis.
#
#     ASFLAGS           Assembler options, overridable
#                       on a per-file basis.
#
#     CPPFLAGS          C preprocessor options.  This
#                       variable shouldn't be set here.
#                       It's intended for users who want
#                       to override preprocessor variables
#                       without having to modify source
#                       code.
#
#     CFLAGS_EXTRA      C compiler options common to
#                       all C files.
#
#     CPPFLAGS_EXTRA    C preprocessor options, common
#                       to all C files.
#
#     MQX_INCDIRS       A list of include directories.
#                       This list already contains the
#                       BSP and PSP directories, as well
#                       as project-specific directories.
#                       We must add compiler include
#                       directories here.
#
# CPPFLAGS_EXTRA and MQX_INCDIRS are also used by
# 'make depend', so they must be defined using the
# second form above.
#

CFLAGS   =-d -ot
ASFLAGS  =-d

CFLAGS_EXTRA =-pack 2 -D e4s -L -n5 -sd -cs -j -ia -nl -pw

# Start CR 293
CPPFLAGS_EXTRA +=-D__ITOOLS__
# End CR 293

ifneq ($(findstring $(MQX_PSP),$(it_procs_000)),)
    it_cbin   =68000
    it_abin   =68000
    it_libdir =000
    it_lib    =000
endif
ifneq ($(findstring $(MQX_PSP),$(it_procs_302)),)
    it_cbin   =68302
    it_abin   =68302
    it_libdir =000
    it_lib    =302
endif
ifneq ($(findstring $(MQX_PSP),$(it_procs_cpu)),)
    it_cbin   =68332
    it_abin   =68332
    it_libdir =020s
    it_lib    =332
endif
ifneq ($(findstring $(MQX_PSP),$(it_procs_340)),)
    it_cbin   =68340
    it_abin   =68340
    it_libdir =020s
    it_lib    =340
endif
ifneq ($(findstring $(MQX_PSP),$(it_procs_360)),)
    it_cbin   =68360
    it_abin   =68360
    it_libdir =020s
    it_lib    =360
endif
ifneq ($(findstring $(MQX_PSP),68020),)
    it_cbin   =68020
    it_abin   =68020
    it_libdir =020s
    it_lib    =020s
endif
ifneq ($(findstring $(MQX_PSP),68040),)
    it_cbin   =68040
    it_abin   =68040
    it_libdir =040h
    it_lib    =040
endif
ifneq ($(findstring $(MQX_PSP),68l40),)
    it_cbin   =ec040
    it_abin   =68040
    it_libdir =040s
    it_lib    =e40
endif
ifneq ($(findstring $(MQX_PSP),68e40),)
    it_cbin   =ec040
    it_abin   =ec040
    it_libdir =040s
    it_lib    =e40
endif
ifneq ($(findstring $(MQX_PSP),68060),)
    it_cbin   =68060
    it_abin   =68060
    it_libdir =060h
    it_lib    =060
endif
ifneq ($(findstring $(MQX_PSP),68l60),)
    it_cbin   =ec060
    it_abin   =68060
    it_libdir =060s
    it_lib    =e60
endif
ifneq ($(findstring $(MQX_PSP),68e60),)
    it_cbin   =ec060
    it_abin   =ec060
    it_libdir =060s
    it_lib    =e60
endif

it_libdir :=$(MQX_COMPILER_ROOT)\rtlibs\lib$(it_libdir)

MQX_INCDIRS +=$(it_libdir)\inc

###########################################################
#
# The start rule.  This rule's purpose is to create
# any command files that may be required by the compiler,
# assembler or linker.
#
# Special variables:
#
#   MQX_BSP             If MQX_BSP is not defined, then
#                       we are building a library that
#                       depends only on the PSP.  Also
#                       note that if MQX_BSP is not
#                       defined, then MQX isn't defined
#                       either.
#
#   MQX_INCDIRS         A space-separated list of
#                       directories that need to be placed
#                       on the compiler's include path.
#
#   MQX_LIBS            A space-separated list of library
#                       files (without extensions) that
#                       need to be linked with the
#                       executable.
#
# Special files:
#   mqx.cmd         Compiler command file
#   mqx.amd         Assembler command file
#

start:
ifdef MQX_BSP
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_BSP) BSP with $(MQX_COMPILER)
else
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_PSP) with $(MQX_COMPILER)
endif
	@$(MQX_CMD) if exist errors del errors
	@$(MQX_CMD) echo -err+ errors > mqx.cmd
	@$(MQX_CMD) echo $(CFLAGS_EXTRA) $(patsubst -D%,-P %,$(CPPFLAGS_EXTRA)) >> mqx.cmd
	@$(MQX_CMD) echo $(addprefix -I ,$(MQX_INCDIRS)) >> mqx.cmd
	@$(MQX_CMD) echo $(addprefix -S ,$(MQX_INCDIRS)) >> mqx.cmd

###########################################################
#
# Finally, the itools-commands.  These are sequences of
# commands for assembling, compiling, archiving and linking.
# There should also by a 'mostlyclean' that deletes all
# intermediary files.
#

define MQX_CC
	@$(MQX_CMD) if exist $@ del $@
	$(CC) $< -opfile mqx.cmd $(CFLAGS) $(patsubst -D%,-P %,$(CPPFLAGS))
endef

define MQX_AS
	@$(MQX_CMD) if exist $@ del $@
	$(AS) $< -M mqx.amd $(ASFLAGS)
endef

define MQX_AR
	$(AR) $? -0 -i -b -l -v -err+ errors -L $(MQX_PROJ).lib
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.amd del mqx.amd
endef

define MQX_LD
	@$(MQX_CMD) echo RESERVE ( #0  to   #$(MQX_BSP_ENTRY) );  > link.it
	@$(MQX_CMD) echo LOCATE  ( S_BOOT : #$(MQX_BSP_ENTRY) ); >> link.it
	@$(MQX_CMD) echo START            ( #$(MQX_BSP_ENTRY) ); >> link.it
	@$(MQX_CMD) if exist $(MQX_BSP_LIB_DIR)\link.it copy $(MQX_BSP_LIB_DIR)\link.it . > nul
	@$(MQX_CMD) if exist $(PROJECT_SRC_DIR)\link.it copy $(PROJECT_SRC_DIR)\link.it . > nul
	$(LD) $(MQX_BSP_LIB_DIR)\boot.ol $^ $(it_libdir)\lib\end.ln -L $(addsuffix .lib,$(MQX_LIBS)) $(it_libdir)\lib\lib$(it_lib).l -c link.it -0 -v -err+ errors -o $(MQX_PROJ).ab
	$(LD2) $(MQX_PROJ).ab -0 -d abs -t L -err+ errors -o $(MQX_PROJ).abs
	$(CV) $(MQX_PROJ).ab -f pm -err+ errors -o $(MQX_PROJ).hex
	$(NM) $(MQX_PROJ).ab -0 -n -o -err+ errors
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.amd del mqx.amd
endef

define MQX_DEPEND
	$(CPP) -M $(CPPFLAGS_EXTRA) $(CPPFLAGS) $(addprefix -I ,$(MQX_INCDIRS)) $< > $@
endef

define MQX_MOSTLYCLEAN
	@$(MQX_CMD) if exist *.d del *.d
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.amd del mqx.amd
endef

# EOF
