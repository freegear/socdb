################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################


###########################################################
#
# Define groups of PSPs.  This grouping is only used
# by this file, so we're free to group (or not group)
# any way that makes things convenient.
#
# The grouping is used mainly for choosing compiler,
# assembler and linker options that depend on the PSP.
#
# However, three things must be done here:
#   1) make .PHONY depend on all supported PSPs
#   2) make all supported PSPs depend on 'start'
#   3) check if MQX_PSP is in the supported list; if
#      not, delete the MQX_CPU variable
#

ti_procs_c54far  = 320548 320549
ti_procs_c54near = 320542
ti_procs_c54     = $(ti_procs_c54far) $(ti_procs_c54near)
ti_procs_c62     = 3206201 3206211
ti_procs_c67     = 3206701 3206711
ti_procs_c3x     = 32030 32031 32032
ti_procs_c4x     = 32040 32040b

ti_procs_all = $(ti_procs_c54) $(ti_procs_c62) $(ti_procs_c67) $(ti_procs_c3x) $(ti_procs_c4x)

.PHONY: $(ti_procs_all)

$(ti_procs_all): start

ifeq ($(findstring $(MQX_PSP),$(ti_procs_all)),)
    MQX_CPU=
endif

###########################################################
#
# Define the filename extensions used for assembly files,
# object files, archives, and binaries.
#

MQX_AEXT=ti
MQX_OEXT=obj
MQX_LEXT=lib
MQX_XEXT=out

###########################################################
#
# Now define the executables used to build the project.
# We need a compiler (CC), assembler (AS), archiver (AR)
# and linker (LD).  We may also define a map file generator
# (NM) (if not done by the linker), and a binary conversion
# utility (CV) (if not done by the linker).
#

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c54)),)
CC=$(MQX_COMPILER_ROOT)\bin\cl500
AS=$(MQX_COMPILER_ROOT)\bin\asm500
AR=$(MQX_COMPILER_ROOT)\bin\ar500
LD=$(MQX_COMPILER_ROOT)\bin\lnk500
LIBC=rts
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c62)),)
CC=$(MQX_COMPILER_ROOT)\bin\cl6x
AS=$(MQX_COMPILER_ROOT)\bin\asm6x
AR=$(MQX_COMPILER_ROOT)\bin\ar6x
LD=$(MQX_COMPILER_ROOT)\bin\lnk6x
LIBC=rts6201
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c67)),)
CC=$(MQX_COMPILER_ROOT)\bin\cl6x
AS=$(MQX_COMPILER_ROOT)\bin\asm6x
AR=$(MQX_COMPILER_ROOT)\bin\ar6x
LD=$(MQX_COMPILER_ROOT)\bin\lnk6x
LIBC=rts6701
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c3x)),)
CC=$(MQX_COMPILER_ROOT)\cl30
AS=$(MQX_COMPILER_ROOT)\asm60
AR=$(MQX_COMPILER_ROOT)\ar30
LD=$(MQX_COMPILER_ROOT)\lnk30
LIBC=rts30r
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c4x)),)
CC=$(MQX_COMPILER_ROOT)\cl30
AS=$(MQX_COMPILER_ROOT)\asm60
AR=$(MQX_COMPILER_ROOT)\ar30
LD=$(MQX_COMPILER_ROOT)\lnk30
LIBC=rts40r
endif


###########################################################
#
# Define various PSP-dependant variables needed for
# compiler/assembler/linker options.
#
# There are two ways to do this:
#
#       processor: variable=value
#
# and
#
#       ifeq ($(MQX_PSP),processor)
#           variable=value
#       endif
#
# There's a very important difference between them:
# In the first case, variable is only defined during
# the 'start' rule (and not when compiling, assembling,
# archiving or linking), and in the second, variable
# is defined for all rules.
#
# Special variables:
#
#     CFLAGS            C compiler options, overridable
#                       on a per-file basis.
#
#     ASFLAGS           Assembler options, overridable
#                       on a per-file basis.
#
#     CPPFLAGS          C preprocessor options.  This
#                       variable shouldn't be set here.
#                       It's intended for users who want
#                       to override preprocessor variables
#                       without having to modify source
#                       code.
#
#     CFLAGS_EXTRA      C compiler options common to
#                       all C files.
#
#     ASFLAGS_EXTRA     Assembler options common to
#                       all assembly files.
#
#     CPPFLAGS_EXTRA    C preprocessor options, common
#                       to all C files.
#
#     MQX_INCDIRS       A list of include directories.
#                       This list already contains the
#                       BSP and PSP directories, as well
#                       as project-specific directories.
#                       We must add compiler include
#                       directories here.
#
# CPPFLAGS_EXTRA and MQX_INCDIRS are also used by
# 'make depend', so they must be defined using the
# second form above.
#

CFLAGS   =-g
ASFLAGS  =-g

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c54far)),)
ifneq ($(MQX_MODEL),near)
CFLAGS  +=-D_FAR_MODE -mf
ASFLAGS +=-mf
endif
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c62)),)
CFLAGS +=-o0
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c67)),)
CFLAGS +=-o0
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c3x)),)
CFLAGS +=-ou
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c4x)),)
CFLAGS +=-ou
endif


CFLAGS_EXTRA   =-c
ASFLAGS_EXTRA  =-DMQX_CPU=$(MQX_CPU)
# Start CR 293
#CPPFLAGS_EXTRA +=
# End CR 293

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c54)),)
CFLAGS_EXTRA  +=-ms -mx -D__TIC54__ -q -pdf -pdr
ASFLAGS_EXTRA +=-pw -q
ifneq ($(findstring $(MQX_PSP),320542),)
CFLAGS_EXTRA  +=-v542
ASFLAGS_EXTRA +=-v542
endif
ifneq ($(findstring $(MQX_PSP),320548),)
CFLAGS_EXTRA  +=-v548
ASFLAGS_EXTRA +=-v548
endif
ifneq ($(findstring $(MQX_PSP),320549),)
CFLAGS_EXTRA  +=-v549
ASFLAGS_EXTRA +=-v549
endif
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c62)),)
CFLAGS_EXTRA  +=-pr -q -ml -D__TIC6X__ -pdf
ASFLAGS_EXTRA +=-s -f
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c67)),)
CFLAGS_EXTRA  +=-pr -q -ml -D__TIC6X__ -pdf -mv6701
ASFLAGS_EXTRA +=-s -f
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c3x)),)
CFLAGS_EXTRA  +=-q -x2 -v30 -mf -mi -mr -tf -tp -pk
ASFLAGS_EXTRA +=-q -mr -v30
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c4x)),)
ifneq ($(findstring $(MQX_PSP),32040),)
CFLAGS_EXTRA  +=-q -x2 -v40 -mf -mi -mr -tf -tp -pk
endif
ifneq ($(findstring $(MQX_PSP),32040b),)
CFLAGS_EXTRA  +=-q -x2 -v40 -mf -mi -mr -tf -tp -mb -pk
endif
ASFLAGS_EXTRA +=-q -mr -v40
endif


ifeq ($(MQX_ENDIAN),b)
CFLAGS_EXTRA  +=-me
ASFLAGS_EXTRA +=-me
endif

# ifneq ($(findstring $(MQX_PSP),$(ti_procs_c62)),)
# ti_boot =$(MQX_BSP_LIB_DIR)\ti.obj
# endif

ifeq ($(MQX_ENDIAN),b)
ti_lib :=$(LIBC)e
else
ti_lib :=$(LIBC)
endif

ifneq ($(findstring -mf,$(CFLAGS)),)
ti_lib :=$(ti_lib)_ext
endif

ifneq ($(findstring $(MQX_PSP),$(ti_procs_c3x) $(ti_procs_c4x)),)
MQX_INCDIRS +=$(MQX_COMPILER_ROOT)
MQX_LIBS    +=$(MQX_COMPILER_ROOT)\$(ti_lib)
export C_DIR=$(MQX_INCDIRS)
endif
ifneq ($(findstring $(MQX_PSP),$(ti_procs_c54) $(ti_procs_c62) $(ti_procs_c67)),)
MQX_INCDIRS +=$(MQX_COMPILER_ROOT)\include
MQX_LIBS    +=$(MQX_COMPILER_ROOT)\lib\$(ti_lib)
endif

export DOS4G=quiet


###########################################################
#
# The start rule.  This rule's purpose is to create
# any command files that may be required by the compiler,
# assembler or linker.
#
# Special variables:
#
#   MQX_BSP             If MQX_BSP is not defined, then
#                       we are building a library that
#                       depends only on the PSP.  Also
#                       note that if MQX_BSP is not
#                       defined, then MQX isn't defined
#                       either.
#
#   MQX_INCDIRS         A space-separated list of
#                       directories that need to be placed
#                       on the compiler's include path.
#
#   MQX_LIBS            A space-separated list of library
#                       files (without extensions) that
#                       need to be linked with the
#                       executable.
#
# Special files:
#   mqx.cmd         Compiler command file
#   mqx.lmd         Linker command file
#   ti_as.cmd      File to be .include'd in assembly source files
#

start:
ifdef MQX_BSP
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_BSP) BSP with $(MQX_COMPILER)
else
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_PSP) with $(MQX_COMPILER)
endif
	@$(MQX_CMD) if exist errors del errors
	@$(MQX_CMD) echo $(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA) > mqx.cmd
ifeq ($(findstring $(MQX_PSP),$(ti_procs_c3x) $(ti_procs_c4x)),)
	@$(MQX_CMD) echo $(addprefix -i,$(MQX_INCDIRS)) >> mqx.cmd
endif
ifdef MQX_BSP
	@$(MQX_CMD) echo $(addsuffix .lib,$(MQX_LIBS)) > mqx.lmd
	@$(MQX_CMD) echo $(addsuffix .lib,$(MQX_LIBS)) >> mqx.lmd
endif

###########################################################
#
# Finally, the meta-commands.  These are sequences of
# commands for assembling, compiling, archiving and linking.
# There should also by a 'mostlyclean' that deletes all
# intermediary files.
#

define MQX_CC
	@$(MQX_CMD) if exist $@ del $@
	$(CC) $(CFLAGS) $(CPPFLAGS) -@mqx.cmd $< >> errors
	@$(MQX_CMD) if exist $*.err type $*.err >> errors
	@$(MQX_CMD) if exist $*.err del $*.err
endef

define MQX_AS
	@$(MQX_CMD) if exist $@ del $@
	$(AS) $(ASFLAGS_EXTRA) $(ASFLAGS) $(addprefix -i,$(MQX_INCDIRS)) $< $@ >> errors
endef



#
# The TI 4.70 (C3x and C4x) archiver can't handle more than
# 10 object files on the command line, and it can't take a
# command file, so we always add *.obj to the library.
#
# Otherwise, we'd
#   $(AR) r $(MQX_PROJ).lib $?
#
define MQX_AR
	$(AR) r $(MQX_PROJ).lib *.obj
	$(AR) t $(MQX_PROJ).lib > $(MQX_PROJ).lst
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
	@$(MQX_CMD) if exist ti_as.cmd del ti_as.cmd
endef

define MQX_LD
	@$(MQX_CMD) copy $(MQX_BSP_LIB_DIR)\link.ti . > nul
	@$(MQX_CMD) if exist $(PROJECT_SRC_DIR)\link.ti copy $(PROJECT_SRC_DIR)\link.ti . > nul
	$(LD) -x -c $^ link.ti mqx.lmd -o $(MQX_PROJ).out -m $(MQX_PROJ).map >> errors
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
	@$(MQX_CMD) if exist ti_as.cmd del ti_as.cmd
endef

define MQX_DEPEND
	$(CPP) -M $(CPPFLAGS_EXTRA) $(CPPFLAGS) $(addprefix -I ,$(MQX_INCDIRS)) $< | $(AWK) {gsub(/o:/,\"obj:\",$$0);print} > $@
endef

define MQX_MOSTLYCLEAN
	@$(MQX_CMD) if exist *.obj del *.obj
	@$(MQX_CMD) if exist *.d del *.d
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
	@$(MQX_CMD) if exist ti_as.cmd del ti_as.cmd
endef

# EOF
