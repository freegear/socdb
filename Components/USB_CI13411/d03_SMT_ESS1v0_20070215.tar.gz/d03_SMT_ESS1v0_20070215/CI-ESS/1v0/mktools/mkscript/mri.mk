################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################


###########################################################
#
# Define groups of PSPs.  This grouping is only used
# by this file, so we're free to group (or not group)
# any way that makes things convenient.
#
# The grouping is used mainly for choosing compiler,
# assembler and linker options that depend on the PSP.
#
# However, three things must be done here:
#   1) make .PHONY depend on all supported PSPs
#   2) make all supported PSPs depend on 'start'
#   3) check if MQX_PSP is in the supported list; if
#      not, delete the MQX_CPU variable
#

mri_procs_ppc   = mpc505 mpc801 mpc821 mpc823 mpc850 mpc860

mri_procs_all   = $(mri_procs_ppc)

.PHONY: $(mri_procs_all)

$(mri_procs_all): start

ifeq ($(findstring $(MQX_PSP),$(mri_procs_all)),)
    MQX_CPU=
endif

###########################################################
#
# Define the filename extensions used for assembly files,
# object files, archives, and binaries.
#

MQX_AEXT=mri
MQX_OEXT=o
MQX_LEXT=lib
MQX_XEXT=abs

###########################################################
#
# Now define the executables used to build the project.
# We need a compiler (CC), assembler (AS), archiver (AR)
# and linker (LD).  We may also define a map file generator
# (NM) (if not done by the linker), and a binary conversion
# utility (CV) (if not done by the linker).
#

ifneq ($(findstring $(MQX_PSP),$(mri_procs_ppc)),)
AS=$(MQX_COMPILER_ROOT)\bin\asmppc
CC=$(MQX_COMPILER_ROOT)\bin\mccppc
AR=$(MQX_COMPILER_ROOT)\bin\libppc
LD=$(MQX_COMPILER_ROOT)\bin\lnkppc
export MRI_PPC_BIN=%mqxc_root%\etc\mccppc ;%mqxc_root%\etc\asmppc
export MRI_PPC_LIB=%mqxc_root%\lib\mccppc
endif


###########################################################
#
# Define various PSP-dependant variables needed for
# compiler/assembler/linker options.
#
# There are two ways to do this:
#
#       processor: variable=value
#
# and
#
#       ifeq ($(MQX_PSP),processor)
#           variable=value
#       endif
#
# There's a very important difference between them:
# In the first case, variable is only defined during
# the 'start' rule (and not when compiling, assembling,
# archiving or linking), and in the second, variable
# is defined for all rules.
#
# Special variables:
#
#     CFLAGS            C compiler options, overridable
#                       on a per-file basis.
#
#     ASFLAGS           Assembler options, overridable
#                       on a per-file basis.
#
#     CPPFLAGS          C preprocessor options.  This
#                       variable shouldn't be set here.
#                       It's intended for users who want
#                       to override preprocessor variables
#                       without having to modify source
#                       code.
#
#     CFLAGS_EXTRA      C compiler options common to
#                       all C files.
#
#     CPPFLAGS_EXTRA    C preprocessor options, common
#                       to all C files.
#
#     MQX_INCDIRS       A list of include directories.
#                       This list already contains the
#                       BSP and PSP directories, as well
#                       as project-specific directories.
#                       We must add compiler include
#                       directories here.
#
# CPPFLAGS_EXTRA and MQX_INCDIRS are also used by
# 'make depend', so they must be defined using the
# second form above.
#

CFLAGS   =-g -O
ASFLAGS  =-g

CFLAGS_EXTRA = -c


ifneq ($(findstring $(MQX_PSP),$(mri_procs_ppc)),)
CFLAGS_EXTRA +=-Kf -KP -Kv -nf -KLi1 -KLf0 -p%mri_target%
ASFLAGS = -DMQX_CPU=%mqx_cpu% -p %mri_target% -Q msA0683
endif

# Start CR 293
CPPFLAGS_EXTRA +=-D__MRI__
# End CR 293

MQX_INCDIRS +=$(MQX_COMPILER_ROOT)\include

mpc505: 				mri_target =505
mpc801: 				mri_target =801
mpc821:					mri_target =821
mpc823:                 mri_target =823
mpc850: 				mri_target =850
mpc860:                 mri_target =860

CFLAGS_EXTRA +=-p%mri_target%

$(mri_procs_ppc):        mri_lib =mppcsb

###########################################################
#
# The start rule.  This rule's purpose is to create
# any command files that may be required by the compiler,
# assembler or linker.
#
# Special variables:
#
#   MQX_BSP             If MQX_BSP is not defined, then
#                       we are building a library that
#                       depends only on the PSP.  Also
#                       note that if MQX_BSP is not
#                       defined, then MQX isn't defined
#                       either.
#
#   MQX_INCDIRS         A space-separated list of
#                       directories that need to be placed
#                       on the compiler's include path.
#
#   MQX_LIBS            A space-separated list of library
#                       files (without extensions) that
#                       need to be linked with the
#                       executable.
#
# Special files:
#   mqx.amd         Archiver (librarian) command file
#   mqx.cmd         Compiler command file
#   mqx.lmd         Linker command file
#

start:
ifdef MQX_BSP
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_BSP) BSP with $(MQX_COMPILER)
else
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_PSP) with $(MQX_COMPILER)
endif
	@$(MQX_CMD) if exist errors del errors
	@$(MQX_CMD) echo $(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA) >  mqx.cmd
	@$(MQX_CMD) echo $(addprefix -I,$(MQX_INCDIRS))    >> mqx.cmd
	@$(MQX_CMD) echo $(addprefix -J,$(MQX_INCDIRS))    >> mqx.cmd
ifdef MQX_BSP
	@$(MQX_CMD) echo LOAD $(MQX_BSP_LIB_DIR)\boot.o               >  mqx.lmd
	@$(MQX_CMD) echo LOAD $(addsuffix .lib,$(MQX_LIBS))           >> mqx.lmd
	@$(MQX_CMD) echo LOAD $(MQX_COMPILER_ROOT)\lib\$(mri_library) >> mqx.lmd
endif

###########################################################
#
# Finally, the meta-commands.  These are sequences of
# commands for assembling, compiling, archiving and linking.
# There should also by a 'mostlyclean' that deletes all
# intermediary files.
#

define MQX_CC
	@$(MQX_CMD) if exist $@ del $@
	$(CC) -d mqx.cmd $(CFLAGS) $(CPPFLAGS) -o$@ $< 
endef

define MQX_AS
	@$(MQX_CMD) if exist $@ del $@
	$(AS) $(addprefix -I,$(MQX_INCDIRS)) $(ASFLAGS) -o$@ $<
endef

define MQX_AR
    @$(MQX_CMD) if exist $(MQX_PROJ).lib echo OPEN $(MQX_PROJ).lib > mqx.amd
    @$(MQX_CMD) if not exist $(MQX_PROJ).lib echo CREATE $(MQX_PROJ).lib > mqx.amd
	@$(MQX_CMD) echo REPLACE $(addsuffix ','  ,$?) >> mqx.amd
	@$(MQX_CMD) echo SAVE >> mqx.amd
	@$(MQX_CMD) echo END >> mqx.amd
	$(AR) < lib.amd
	@$(MQX_CMD) echo DI $(MQX_PROJ).lib $(MQX_PROJ).lst > mqx.amd
	$(AR) < lib.amd
	@$(MQX_CMD) if exist mqx.cmd del mqx.amd
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

define MQX_LD
	@$(MQX_CMD) copy $(MQX_BSP_LIB_DIR)\link.mri . > nul
	@$(MQX_CMD) if exist $(PROJECT_SRC_DIR)\link.mri copy $(PROJECT_SRC_DIR)\link.mri . > nul
	$(LD) $(MQX_BSP_LIB_DIR)\boot.o $^ -@mqx.lmd -o $(MQX_PROJ).elf -m2 link.mri > $(MQX_PROJ).map
	$(CV) -R $(MQX_PROJ).elf -o $(MQX_PROJ).hex
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.amd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

define MQX_DEPEND
	$(CPP) -M $(CPPFLAGS_EXTRA) $(CPPFLAGS) $(addprefix -I ,$(MQX_INCDIRS)) $< > $@
endef

define MQX_MOSTLYCLEAN
	@$(MQX_CMD) if exist *.o del *.o
	@$(MQX_CMD) if exist *.d del *.d
	@$(MQX_CMD) if exist mqx.cmd del mqx.amd
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

# EOF
