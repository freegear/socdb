################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################


###########################################################
#
# Define groups of PSPs.  This grouping is only used
# by this file, so we're free to group (or not group)
# any way that makes things convenient.
#
# The grouping is used mainly for choosing compiler,
# assembler and linker options that depend on the PSP.
#
# However, three things must be done here:
#   1) make .PHONY depend on all supported PSPs
#   2) make all supported PSPs depend on 'start'
#   3) check if MQX_PSP is in the supported list; if
#      not, delete the MQX_CPU variable
#

sds_procs_68k_000 = 68000 68306 68307 68322 68356 \
                    68302 68lc302 68en302 \
                    68328 68ez328 \
                    68330 68331 68332 68333 68334 68336 68376 \
                    68340 68341 68349

sds_procs_68k_cpu = 68360 cpu32

sds_procs_all = $(sds_procs_68k_000) $(sds_procs_68k_cpu) \
                68020 68040 68l40 68e40 68060 68l60 68e60

.PHONY: $(sds_procs_all)

$(sds_procs_all): start

ifeq ($(findstring $(MQX_PSP),$(sds_procs_all)),)
    MQX_CPU=
endif

###########################################################
#
# Define the filename extensions used for assembly files,
# object files, archives, and binaries.
#

MQX_AEXT=sds
MQX_OEXT=o
MQX_LEXT=a
MQX_XEXT=out

###########################################################
#
# Now define the executables used to build the project.
# We need a compiler (CC), assembler (AS), archiver (AR)
# and linker (LD).  We may also define a map file generator
# (NM) (if not done by the linker), and a binary conversion
# utility (CV) (if not done by the linker).
#

CC=$(MQX_COMPILER_ROOT)\cmd\cc68000
AS=$(MQX_COMPILER_ROOT)\cmd\as68000
AR=$(MQX_COMPILER_ROOT)\cmd\liber
LD=$(MQX_COMPILER_ROOT)\cmd\linker
NM=$(MQX_COMPILER_ROOT)\cmd\sym
CV=$(MQX_COMPILER_ROOT)\cmd\down

###########################################################
#
# Define various PSP-dependant variables needed for
# compiler/assembler/linker options.
#
# There are two ways to do this:
#
#       processor: variable=value
#
# and
#
#       ifeq ($(MQX_PSP),processor)
#           variable=value
#       endif
#
# There's a very important difference between them:
# In the first case, variable is only defined during
# the 'start' rule (and not when compiling, assembling,
# archiving or linking), and in the second, variable
# is defined for all rules.
#
# Special variables:
#
#     CFLAGS            C compiler options, overridable
#                       on a per-file basis.
#
#     ASFLAGS           Assembler options, overridable
#                       on a per-file basis.
#
#     CPPFLAGS          C preprocessor options.  This
#                       variable shouldn't be set here.
#                       It's intended for users who want
#                       to override preprocessor variables
#                       without having to modify source
#                       code.
#
#     CFLAGS_EXTRA      C compiler options common to
#                       all C files.
#
#     CPPFLAGS_EXTRA    C preprocessor options, common
#                       to all C files.
#
#     MQX_INCDIRS       A list of include directories.
#                       This list already contains the
#                       BSP and PSP directories, as well
#                       as project-specific directories.
#                       We must add compiler include
#                       directories here.
#
# CPPFLAGS_EXTRA and MQX_INCDIRS are also used by
# 'make depend', so they must be defined using the
# second form above.
#

CFLAGS  =-f -Odsg
ASFLAGS =-f

CFLAGS_EXTRA   =-s enum=4 -G "\#pragma maxalign(2)"
# Start CR 293
CPPFLAGS_EXTRA +=-D__SDS__
# End CR 293

MQX_INCDIRS +=$(MQX_COMPILER_ROOT)\lib68000\include

$(sds_procs_68k_000): sds_proc = 68000
$(sds_procs_68k_cpu): sds_proc = cpu32
68020:                sds_proc = 68020
68040:                sds_proc = 68040
68l40:                sds_proc = 68LC040
68e40:                sds_proc = 68EC040
68060:                sds_proc = 68060
68l60:                sds_proc = 68LC060
68e60:                sds_proc = 68EC060

$(sds_procs_68k_000): sds_lib = lib68000
$(sds_procs_68k_cpu): sds_lib = lib68000
68020:                sds_lib = lib68020
68040:                sds_lib = lib68040
68l40:                sds_lib = lib68l40
68e40:                sds_lib = lib68e40
68060 68l60 68e60:    sds_lib = lib68060

###########################################################
#
# The start rule.  This rule's purpose is to create
# any command files that may be required by the compiler,
# assembler or linker.
#
# Special variables:
#
#   MQX_BSP             If MQX_BSP is not defined, then
#                       we are building a library that
#                       depends only on the PSP.  Also
#                       note that if MQX_BSP is not
#                       defined, then MQX isn't defined
#                       either.
#
#   MQX_INCDIRS         A space-separated list of
#                       directories that need to be placed
#                       on the compiler's include path.
#
#   MQX_LIBS            A space-separated list of library
#                       files (without extensions) that
#                       need to be linked with the
#                       executable.
#
# Special files:
#   mqx.cmd         Compiler command file
#   mqx.amd         Assembler command file
#   mqx.lmd         Linker command file
#

start:
ifdef MQX_BSP
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_BSP) BSP with $(MQX_COMPILER)
else
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_PSP) with $(MQX_COMPILER)
endif
	@$(MQX_CMD) if exist errors del errors
	@$(MQX_CMD) echo -V $(sds_proc) -E+errors > mqx.cmd
	@$(MQX_CMD) echo $(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA) >> mqx.cmd
	@$(MQX_CMD) echo $(addprefix -I ,$(MQX_INCDIRS)) >> mqx.cmd
	@$(MQX_CMD) echo -V $(sds_proc) -DMQX_CPU=$(MQX_CPU) -E+errors > mqx.amd
ifdef MQX_BSP
	@$(MQX_CMD) echo -y -v -E+errors > mqx.lmd
	@$(MQX_CMD) echo $(addsuffix .a,$(MQX_LIBS)) >> mqx.lmd
	@$(MQX_CMD) echo $(MQX_ROOT)\sds\$(sds_lib)\libc.a >> mqx.lmd
	@$(MQX_CMD) echo $(MQX_ROOT)\sds\$(sds_lib)\libf.a >> mqx.lmd
endif

###########################################################
#
# Finally, the meta-commands.  These are sequences of
# commands for assembling, compiling, archiving and linking.
# There should also by a 'mostlyclean' that deletes all
# intermediary files.
#

define MQX_CC
	@$(MQX_CMD) if exist $@ del $@
	$(CC) -F mqx.cmd $(CFLAGS) $(CPPFLAGS) $<
endef

define MQX_AS
	@$(MQX_CMD) if exist $@ del $@
	$(AS) -F mqx.amd $(ASFLAGS) $<
endef

define MQX_AR
	@$(MQX_CMD) if not exist $(MQX_PROJ).a $(AR) -c $(MQX_PROJ).a
	$(AR) -ry $(MQX_PROJ).a $?
	$(AR) -t $(MQX_PROJ).a > $(MQX_PROJ).lst
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.amd del mqx.amd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

define MQX_LD
	@$(MQX_CMD) copy $(MQX_BSP_LIB_DIR)\link.sds . > nul
	@$(MQX_CMD) if exist $(PROJECT_SRC_DIR)\link.sds copy $(PROJECT_SRC_DIR)\link.sds . > nul
	$(LD) -f link.sds $(MQX_BSP_LIB_DIR)\boot.o $^ -F mqx.lmd -o $(MQX_PROJ).out
	$(NM) -d -m $(MQX_PROJ).out > $(MQX_PROJ).map
	$(NM) -w 40.40 $(MQX_PROJ).out >> $(MQX_PROJ).map
	$(CV) $(MQX_PROJ).out -d mot -m data,DATA -o $(MQX_PROJ).hex
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.amd del mqx.amd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

define MQX_DEPEND
	$(CPP) -M $(CPPFLAGS_EXTRA) $(CPPFLAGS) $(addprefix -I ,$(MQX_INCDIRS)) $< > $@
endef

define MQX_MOSTLYCLEAN
	@$(MQX_CMD) if exist *.o del *.o
	@$(MQX_CMD) if exist *.d del *.d
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.amd del mqx.amd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

# EOF
