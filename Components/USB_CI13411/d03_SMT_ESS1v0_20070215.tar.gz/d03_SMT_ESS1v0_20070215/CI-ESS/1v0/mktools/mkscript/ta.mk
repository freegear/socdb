################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################


###########################################################
#
# Define groups of PSPs.  This grouping is only used
# by this file, so we're free to group (or not group)
# any way that makes things convenient.
#
# The grouping is used mainly for choosing compiler,
# assembler and linker options that depend on the PSP.
#
# However, three things must be done here:
#   1) make .PHONY depend on all supported PSPs
#   2) make all supported PSPs depend on 'start'
#   3) check if MQX_PSP is in the supported list; if
#      not, delete the MQX_CPU variable
#

ta_procs_ppch  = ppc603 ppc604 ppc740 ppc750 mpc8240
ta_procs_ppcs  = ppc401 ppc403 mpc505 mpc801 mpc821 mpc823 mpc850 mpc860 mpc8260
ta_procs_ppc   = $(ta_procs_ppcs) $(ta_procs_ppch)

ta_procs_all = $(ta_procs_ppc)

.PHONY: $(ta_procs_all)

$(ta_procs_all): start

ifeq ($(findstring $(MQX_PSP),$(ta_procs_all)),)
    MQX_CPU=
endif

###########################################################
#
# Define the filename extensions used for assembly files,
# object files, archives, and binaries.
#

MQX_AEXT=ta
MQX_OEXT=o
MQX_LEXT=a
MQX_XEXT=elf

###########################################################
#
# Now define the executables used to build the project.
# We need a compiler (CC), assembler (AS), archiver (AR)
# and linker (LD).  We may also define a map file generator
# (NM) (if not done by the linker), and a binary conversion
# utility (CV) (if not done by the linker).
#

CC=$(MQX_COMPILER_ROOT)\bin\cppc
AS=$(MQX_COMPILER_ROOT)\bin\asppc
AR=$(MQX_COMPILER_ROOT)\bin\arppc
LD=$(MQX_COMPILER_ROOT)\bin\ldppc
LIBC=libc.a

###########################################################
#
# Define various PSP-dependant variables needed for
# compiler/assembler/linker options.
#
# There are two ways to do this:
#
#       processor: variable=value
#
# and
#
#       ifeq ($(MQX_PSP),processor)
#           variable=value
#       endif
#
# There's a very important difference between them:
# In the first case, variable is only defined during
# the 'start' rule (and not when compiling, assembling,
# archiving or linking), and in the second, variable
# is defined for all rules.
#
# Special variables:
#
#     CFLAGS            C compiler options, overridable
#                       on a per-file basis.
#
#     ASFLAGS           Assembler options, overridable
#                       on a per-file basis.
#
#     CPPFLAGS          C preprocessor options.  This
#                       variable shouldn't be set here.
#                       It's intended for users who want
#                       to override preprocessor variables
#                       without having to modify source
#                       code.
#
#     CFLAGS_EXTRA      C compiler options common to
#                       all C files.
#
#     ASFLAGS_EXTRA     Assembler options common to
#                       all assembly files.
#
#     CPPFLAGS_EXTRA    C preprocessor options, common
#                       to all C files.
#
#     MQX_INCDIRS       A list of include directories.
#                       This list already contains the
#                       BSP and PSP directories, as well
#                       as project-specific directories.
#                       We must add compiler include
#                       directories here.
#
# CPPFLAGS_EXTRA and MQX_INCDIRS are also used by
# 'make depend', so they must be defined using the
# second form above.
#

CFLAGS   =-g -O
ASFLAGS  =-g

CFLAGS_EXTRA   =-Hnocplus -Hon=Long_enums
ASFLAGS_EXTRA  =-c -Eo -DMQX_CPU=$(MQX_CPU)
# Start CR 293
CPPFLAGS_EXTRA +=-D__ta__
# End CR 293

ppc401:  CFLAGS_EXTRA +=-Hppc401
ppc403:  CFLAGS_EXTRA +=-Hppc403
mpc505:  CFLAGS_EXTRA +=-Hppc505
ppc603:  CFLAGS_EXTRA +=-Hppc603
ppc604:  CFLAGS_EXTRA +=-Hppc604
ppc740:  CFLAGS_EXTRA +=-Hppc740
ppc750:  CFLAGS_EXTRA +=-Hppc750
mpc801:  CFLAGS_EXTRA +=-Hppc801
mpc821:  CFLAGS_EXTRA +=-Hppc821
mpc823:  CFLAGS_EXTRA +=-Hppc823
mpc850:  CFLAGS_EXTRA +=-Hppc850
mpc860:  CFLAGS_EXTRA +=-Hppc860
mpc8240: CFLAGS_EXTRA +=-Hppc603
mpc8260: CFLAGS_EXTRA +=-Hppc603 -fsoft

ifeq ($(MQX_ENDIAN),l)
CFLAGS_EXTRA  +=-HL
ASFLAGS_EXTRA +=-le
else
CFLAGS_EXTRA  +=-HB
ASFLAGS_EXTRA +=-be
endif

MQX_INCDIRS +=$(MQX_COMPILER_ROOT)\inc

ta_boot =$(MQX_BSP_LIB_DIR)\boot.o

ta_lib =lib
ifeq ($(MQX_ENDIAN),l)
ta_lib :=$(ta_lib)\le
else
ta_lib :=$(ta_lib)\be
endif
ifneq ($(findstring $(MQX_PSP),$(ta_procs_ppch)),)
ta_lib :=$(ta_lib)\fp
endif
ifneq ($(findstring $(MQX_PSP),$(ta_procs_ppcs)),)
ta_lib :=$(ta_lib)\fsoft
endif

###########################################################
#
# The start rule.  This rule's purpose is to create
# any command files that may be required by the compiler,
# assembler or linker.
#
# Special variables:
#
#   MQX_BSP             If MQX_BSP is not defined, then
#                       we are building a library that
#                       depends only on the PSP.  Also
#                       note that if MQX_BSP is not
#                       defined, then MQX isn't defined
#                       either.
#
#   MQX_INCDIRS         A space-separated list of
#                       directories that need to be placed
#                       on the compiler's include path.
#
#   MQX_LIBS            A space-separated list of library
#                       files (without extensions) that
#                       need to be linked with the
#                       executable.
#
# Special files:
#   mqx.cmd         Compiler command file
#   mqx.lmd         Linker command file
#   ta_as.cmd      File to be .include'd in assembly source files
#

start:
ifdef MQX_BSP
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_BSP) BSP with $(MQX_COMPILER)
else
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_PSP) with $(MQX_COMPILER)
endif
	@$(MQX_CMD) if exist errors del errors
	@$(MQX_CMD) echo -c -Hnocopyr -Hefile=@ > mqx.cmd
	@$(MQX_CMD) echo $(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA) >> mqx.cmd
	@$(MQX_CMD) echo $(addprefix -I,$(MQX_INCDIRS)) >> mqx.cmd
ifdef ta_extreg
	@$(MQX_CMD) echo .equ PSP_NUM_EXTENSION_REGISTERS,$(ta_extreg_num) > ta_as.cmd
	@$(MQX_CMD) echo .equ PSP_EXTENSION_REGISTERS,$(ta_extreg) >> ta_as.cmd
endif
ifdef MQX_BSP
	@$(MQX_CMD) echo $(addsuffix .a,$(MQX_LIBS)) > mqx.lmd
	@$(MQX_CMD) echo $(addsuffix .a,$(MQX_LIBS)) >> mqx.lmd
	@$(MQX_CMD) echo $(MQX_COMPILER_ROOT)\$(ta_lib)\$(LIBC) >> mqx.lmd
endif

###########################################################
#
# Finally, the meta-commands.  These are sequences of
# commands for assembling, compiling, archiving and linking.
# There should also by a 'mostlyclean' that deletes all
# intermediary files.
#

define MQX_CC
	@$(MQX_CMD) if exist $@ del $@
	$(CC) $(CFLAGS) $(CPPFLAGS) $< @mqx.cmd >> errors
endef

define MQX_AS
	@$(MQX_CMD) if exist $@ del $@
	$(AS) $(ASFLAGS_EXTRA) $(ASFLAGS) $< >> errors
endef

define MQX_AR
	$(AR) -rvs $(MQX_PROJ).a $?
	$(AR) -t $(MQX_PROJ).a > $(MQX_PROJ).lst
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
	@$(MQX_CMD) if exist ta_as.cmd del ta_as.cmd
endef

define MQX_LD
	@$(MQX_CMD) copy $(MQX_BSP_LIB_DIR)\link.ta . > nul
	@$(MQX_CMD) if exist $(PROJECT_SRC_DIR)\link.ta copy $(PROJECT_SRC_DIR)\link.ta . > nul
	$(LD) link.ta -m -o $(MQX_PROJ).elf $(ta_boot) $^ @mqx.lmd > $(MQX_PROJ).map
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
	@$(MQX_CMD) if exist ta_as.cmd del ta_as.cmd
endef

define MQX_DEPEND
	$(CPP) -M $(CPPFLAGS_EXTRA) $(CPPFLAGS) $(addprefix -I ,$(MQX_INCDIRS)) $< > $@
endef

define MQX_MOSTLYCLEAN
	@$(MQX_CMD) if exist *.o del *.o
	@$(MQX_CMD) if exist *.d del *.d
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
	@$(MQX_CMD) if exist ta_as.cmd del ta_as.cmd
endef

# EOF
