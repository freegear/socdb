################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################


###########################################################
#
# Define groups of PSPs.  This grouping is only used
# by this file, so we're free to group (or not group)
# any way that makes things convenient.
#
# The grouping is used mainly for choosing compiler,
# assembler and linker options that depend on the PSP.
#
# However, three things must be done here:
#   1) make .PHONY depend on all supported PSPs
#   2) make all supported PSPs depend on 'start'
#   3) check if MQX_PSP is in the supported list; if
#      not, delete the MQX_CPU variable
#

dd_procs_68k00 = 68000 68302 68lc302 68en302 68328 68ez328
dd_procs_68k60 = 68020 cpu32 68360 68040 68l40 68e40 68060 68l60 68e60
dd_procs_68k   = $(dd_procs_68k00) $(dd_procs_68k60)

dd_procs_cf    = mcf5206 mcf5206e mcf5307

dd_procs_ppc16 = ppc401 ppc403 mpc505 mpc555 mpc801 mpc821 mpc823 mpc850 mpc855 mpc860
dd_procs_ppc32 = ppc603 ppc604 ppc740 ppc750 ppc7400 mpc8240 mpc8260
dd_procs_ppc   = $(dd_procs_ppc16) $(dd_procs_ppc32)

dd_procs_mcore = mcore mmc2001 mmc2080

dd_procs_all   = $(dd_procs_68k) $(dd_procs_cf) $(dd_procs_ppc) $(dd_procs_mcore)

.PHONY: $(dd_procs_all)

$(dd_procs_all): start

ifeq ($(findstring $(MQX_PSP),$(dd_procs_all)),)
    MQX_CPU=
endif

###########################################################
#
# Define the filename extensions used for assembly files,
# object files, archives, and binaries.
#

MQX_AEXT=dd
MQX_OEXT=o
MQX_LEXT=a
MQX_XEXT=elf

###########################################################
#
# Now define the executables used to build the project.
# We need a compiler (CC), assembler (AS), archiver (AR)
# and linker (LD).  We may also define a map file generator
# (NM) (if not done by the linker), and a binary conversion
# utility (CV) (if not done by the linker).
#

CC=$(MQX_COMPILER_ROOT)\win32\bin\dcc
AS=$(MQX_COMPILER_ROOT)\win32\bin\das
AR=$(MQX_COMPILER_ROOT)\win32\bin\dar
LD=$(MQX_COMPILER_ROOT)\win32\bin\dld
CV=$(MQX_COMPILER_ROOT)\win32\bin\ddump

###########################################################
#
# Define various PSP-dependant variables needed for
# compiler/assembler/linker options.
#
# There are two ways to do this:
#
#       processor: variable=value
#
# and
#
#       ifeq ($(MQX_PSP),processor)
#           variable=value
#       endif
#
# There's a very important difference between them:
# In the first case, variable is only defined during
# the 'start' rule (and not when compiling, assembling,
# archiving or linking), and in the second, variable
# is defined for all rules.
#
# Special variables:
#
#     CFLAGS            C compiler options, overridable
#                       on a per-file basis.
#
#     ASFLAGS           Assembler options, overridable
#                       on a per-file basis.
#
#     CPPFLAGS          C preprocessor options.  This
#                       variable shouldn't be set here.
#                       It's intended for users who want
#                       to override preprocessor variables
#                       without having to modify source
#                       code.
#
#     CFLAGS_EXTRA      C compiler options common to
#                       all C files.
#
#     CPPFLAGS_EXTRA    C preprocessor options, common
#                       to all C files.
#
#     MQX_INCDIRS       A list of include directories.
#                       This list already contains the
#                       BSP and PSP directories, as well
#                       as project-specific directories.
#                       We must add compiler include
#                       directories here.
#
# CPPFLAGS_EXTRA and MQX_INCDIRS are also used by
# 'make depend', so they must be defined using the
# second form above.
#

CFLAGS   =
ASFLAGS  =

ifndef MQX_NO_OPTIMIZATION
CFLAGS   +=-O
endif

ifndef MQX_NO_DEBUG
ASFLAGS += -g
CFLAGS  += -g
endif

ifdef MQX_DO_PROFILING
endif

CFLAGS_EXTRA =-Xenum-is-int -Xforce-prototypes -Xdebug-struct-compact -Xsmall-data=0 -Xsmall-const=0
CFLAGS_EXTRA +=-Xmember-max-align=2 -Xalign-min=2
ifneq ($(findstring $(MQX_PSP),$(dd_procs_cf) $(dd_procs_ppc16)),)
CFLAGS_EXTRA +=-Xalign-functions=16
endif
ifneq ($(findstring $(MQX_PSP),$(dd_procs_ppc32)),)
CFLAGS_EXTRA +=-Xalign-functions=32
endif
ifneq ($(findstring $(MQX_PSP),$(dd_procs_mcore)),)
CFLAGS_EXTRA +=-Xsection-split
endif

# Start CR 293
#CPPFLAGS_EXTRA +=
# End CR 293

# START CR 317
ifneq ($(findstring -DMQX_KERNEL_LOGGING=0,$(CPPFLAGS)),)
ASFLAGS_EXTRA += -DMQX_KERNEL_LOGGING=0
endif
# END CR 317

MQX_INCDIRS +=$(MQX_COMPILER_ROOT)\include

export DIABLIB=$(MQX_COMPILER_ROOT)

68000 68328 68ez328:    dd_target =MC68000
68302 68lc302 68en302:  dd_target =MC68000
cpu32:                  dd_target =CPU32
68360:                  dd_target =MC68360
68020:                  dd_target =MC68020
68040:                  dd_target =MC68040
68l40:                  dd_target =MC68LC040
68e40:                  dd_target =MC68EC040
68060:                  dd_target =MC68060
68l60:                  dd_target =MC68LC060
68e60:                  dd_target =MC68EC060
mcf5206:                dd_target =MCF5206
mcf5206e mcf5307:       dd_target =MCF5307
ppc401:                 dd_target =PPC401
ppc403:                 dd_target =PPC403
ppc405:                 dd_target =PPC405
ppc603:                 dd_target =PPC603
ppc604:                 dd_target =PPC604
ppc740:                 dd_target =PPC740
ppc750:                 dd_target =PPC750
ppc7400:                dd_target =PPC7400
mpc505:                 dd_target =PPC505
mpc555:                 dd_target =PPC555
mpc801:                 dd_target =PPC820
mpc821:                 dd_target =PPC821
mpc823:                 dd_target =PPC823
mpc850:                 dd_target =PPC850
mpc855:                 dd_target =PPC855
mpc860:                 dd_target =PPC860
mpc8240:                dd_target =PPC8240
mpc8260:                dd_target =PPC8260
$(dd_procs_mcore):      dd_target =MCORE

$(dd_procs_68k):        dd_object =F
$(dd_procs_cf):         dd_object =F
$(dd_procs_ppc):        dd_object =E
$(dd_procs_mcore):      dd_object =E

68000 68328 68ez328:    dd_fp =S
68302 68lc302 68en302:  dd_fp =S
68020 cpu32 68360:      dd_fp =S
68040:                  dd_fp =H
68e40 68l40:            dd_fp =S
68060:                  dd_fp =H
68e60 68l60:            dd_fp =S
$(dd_procs_cf):         dd_fp =S
ppc401 ppc403:          dd_fp =S
ppc603 ppc604 mpc8240 mpc8260:  dd_fp =H
ppc740 ppc750:          dd_fp =H
mpc505:                 dd_fp =S
mpc555:                 dd_fp =H
mpc801 mpc821 mpc823:   dd_fp =S
mpc850 mpc855 mpc860:   dd_fp =S
ppc7400:                dd_fp =V
$(dd_procs_mcore):      dd_fp =S

$(dd_procs_68k00):      dd_lib =mc00f
$(dd_procs_68k60):      dd_lib =mc60f
$(dd_procs_cf):         dd_lib =ace0f
$(dd_procs_ppc):        dd_lib =ppce
$(dd_procs_mcore):      dd_lib =mcoree

###########################################################
#
# The start rule.  This rule's purpose is to create
# any command files that may be required by the compiler,
# assembler or linker.
#
# Special variables:
#
#   MQX_BSP             If MQX_BSP is not defined, then
#                       we are building a library that
#                       depends only on the PSP.  Also
#                       note that if MQX_BSP is not
#                       defined, then MQX isn't defined
#                       either.
#
#   MQX_INCDIRS         A space-separated list of
#                       directories that need to be placed
#                       on the compiler's include path.
#
#   MQX_LIBS            A space-separated list of library
#                       files (without extensions) that
#                       need to be linked with the
#                       executable.
#
# Special files:
#   mqx.cmd         Compiler command file
#   mqx.amd         Assembler command file
#   mqx.lmd         Linker command file
#

start:
ifdef MQX_BSP
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_BSP) BSP with $(MQX_COMPILER)
else
	@$(MQX_CMD) echo Building $(MQX_PROJ) for the $(MQX_PSP) with $(MQX_COMPILER)
endif
	@$(MQX_CMD) if exist errors del errors
	@$(MQX_CMD) echo -c -t$(dd_target)$(dd_object)$(dd_fp) -@E+errors > mqx.cmd
	@$(MQX_CMD) echo $(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA) >> mqx.cmd
	@$(MQX_CMD) echo $(addprefix -I,$(MQX_INCDIRS)) >> mqx.cmd
	@$(MQX_CMD) echo -t$(dd_target)$(dd_object)$(dd_fp) -x -DMQX_CPU=$(MQX_CPU) -@E+errors > mqx.amd
	@$(MQX_CMD) echo $(addprefix -I,$(MQX_INCDIRS)) >> mqx.amd
ifdef MQX_BSP
	@$(MQX_CMD) echo -t$(dd_target)$(dd_object)$(dd_fp) -e _main -@E+errors > mqx.lmd
	@$(MQX_CMD) echo $(addsuffix .a,$(MQX_LIBS)) >> mqx.lmd
	@$(MQX_CMD) echo $(MQX_COMPILER_ROOT)\$(dd_lib)$(dd_fp)\libm.a >> mqx.lmd
	@$(MQX_CMD) echo $(MQX_COMPILER_ROOT)\$(dd_lib)\libc.a >> mqx.lmd
endif

###########################################################
#
# Finally, the meta-commands.  These are sequences of
# commands for assembling, compiling, archiving and linking.
# There should also by a 'mostlyclean' that deletes all
# intermediary files.
#

define MQX_CC
	@$(MQX_CMD) if exist $@ del $@
	@$(MQX_CMD) echo $(CC) -@mqx.cmd $(CFLAGS) $(CPPFLAGS) $< >> errors
	$(CC) -@mqx.cmd $(CFLAGS) $(CPPFLAGS) $<
endef

define MQX_AS
	@$(MQX_CMD) if exist $@ del $@
	@$(MQX_CMD) echo $(AS) $(ASFLAGS_EXTRA) $(ASFLAGS) -@mqx.amd -o $@ $< >> errors
	$(AS) $(ASFLAGS_EXTRA) $(ASFLAGS) -@mqx.amd -o $@ $<
endef

define MQX_AR
	$(AR) -rv $(MQX_PROJ).a $?
	$(AR) -t $(MQX_PROJ).a > $(MQX_PROJ).lst
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.amd del mqx.amd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

define MQX_LD
	@$(MQX_CMD) copy $(MQX_BSP_LIB_DIR)\link.dd . > nul
	@$(MQX_CMD) if exist $(PROJECT_SRC_DIR)\link.dd copy $(PROJECT_SRC_DIR)\link.dd . > nul
	$(LD) $(MQX_BSP_LIB_DIR)\boot.o $^ -@mqx.lmd -o $(MQX_PROJ).elf -m2 link.dd > $(MQX_PROJ).map
	$(CV) -R $(MQX_PROJ).elf -o $(MQX_PROJ).hex
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.amd del mqx.amd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

# Start CR 402
# define MQX_DEPEND
#	$(CPP) -M $(CPPFLAGS_EXTRA) $(CPPFLAGS) $(addprefix -I ,$(MQX_INCDIRS)) $< > $@
# endef
define MQX_DEPEND
	$(CPP) -D__DCC__ -M -D__NO_SETJMP $(CPPFLAGS_EXTRA) $(CPPFLAGS) $(addprefix -I ,$(MQX_INCDIRS)) $< > $@
endef
# End CR 402

define MQX_MOSTLYCLEAN
	@$(MQX_CMD) if exist *.o del *.o
	@$(MQX_CMD) if exist *.d del *.d
	@$(MQX_CMD) if exist mqx.cmd del mqx.cmd
	@$(MQX_CMD) if exist mqx.amd del mqx.amd
	@$(MQX_CMD) if exist mqx.lmd del mqx.lmd
endef

# EOF
