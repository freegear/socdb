################################################################################
## File          : $HeadURL$ 
## Author        : $Author$
## Project       : HSCTRL 
## Instances     : 
## Creation date : 
################################################################################
################################################################################
## ChipIdea Microelectronica - IPCS
## TECMAIA, Rua Eng. Frederico Ulrich, n 2650
## 4470-920 MOREIRA MAIA
## Portugal
## Tel: +351 229471010
## Fax: +351 229471011
## e_mail: chipidea.com
################################################################################
## ISO 9001:2000 - Certified Company
## (C) 2005 Copyright Chipidea(R)
## Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
## the information contained herein without notice. No liability shall be
## incurred as a result of its use or application.
################################################################################
## Modification history:
## $Date$
## $Revision$
################################################################################


###########################################################
#
# Define the executables used to build the project.
# We need a compiler (CC), assembler (AS), archiver (AR)
# and linker (LD).  We may also define a map file generator
# (NM) (if not done by the linker), a binary conversion
# utility (CV)
#

ifneq ($(findstring $(MQX_PSP),arcta5 arcta52),)
   CC=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcac
   AS=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcac @mqx.cmd
   AR=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)arac
   LD=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcac
else
   CC=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcarc
   AS=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcarc @mqx.cmd
   AR=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)ararc
   LD=$(MQX_COMPILER_ROOT)$(PS)bin$(PS)hcarc
endif

ifdef MQX_NO_C_COMPILER_RUNTIME
   LD +=-Bstatic -Bgrouplib -Hhostlib=
else
//   LD +=-Heos=mqx -Bstatic -Bgrouplib -Hhostlink
   LD +=-Heos=mqx -Bstatic -Bgrouplib -Hhostlib=  
endif

LIBC=libct.a


###########################################################
#
# Define various PSP-dependant variables needed for
# compiler/assembler/linker options.
#
# There are two ways to do this:
#
#       processor: variable=value
#
# and
#
#       ifeq ($(MQX_PSP),processor)
#           variable=value
#       endif
#
# There's a very important difference between them:
# In the first case, variable is only defined during
# the 'start' rule (and not when compiling, assembling,
# archiving or linking), and in the second, variable
# is defined for all rules.
#
# Special variables:
#
#     CFLAGS            C compiler options, overridable
#                       on a per-file basis.
#
#     ASFLAGS           Assembler options, overridable
#                       on a per-file basis.
#
#     CPPFLAGS          C preprocessor options.  This
#                       variable shouldn't be set here.
#                       It's intended for users who want
#                       to override preprocessor variables
#                       without having to modify source
#                       code.
#
#     CFLAGS_EXTRA      C compiler options common to
#                       all C files.
#
#     ASFLAGS_EXTRA     Assembler options common to
#                       all assembly files.
#
#     CPPFLAGS_EXTRA    C preprocessor options, common
#                       to all C files.
#
#     MQX_INCDIRS       A list of include directories.
#                       This list already contains the
#                       BSP and PSP directories, as well
#                       as project-specific directories.
#                       We must add compiler include
#                       directories here.
#
# CPPFLAGS_EXTRA and MQX_INCDIRS are also used by
# 'make depend', so they must be defined using the
# second form above.
#

CFLAGS   = -Hoff=Volatile_cache_bypass
ASFLAGS  =

ifdef MQX_SMALL_SIZE
   CFLAGS += -Os
   CFLAGS_EXTRA += -DMQX_COMPILE_FOR_SMALL_SIZE
else
   ifndef MQX_NO_OPTIMIZATION
      CFLAGS   +=-O
   endif
endif

CFLAGS_EXTRA   +=-Hon=Long_enums
ASFLAGS_EXTRA  +=-c -Eo -DMQX_CPU=$(MQX_CPU)

#take off debugging SG 02/24/2003
ifndef MQX_NO_DEBUG
   ASFLAGS += -g
   CFLAGS  += -g
endif

ifdef MQX_DO_PROFILING
   CFLAGS += -pg -D__PROFILE__
   LD += -pg -Hheap=32768
else
   LD += -Hheap=0
endif

ifdef MQX_NO_C_COMPILER_RUNTIME
   CFLAGS_EXTRA += -DMQX_NO_C_COMPILER_RUNTIME
endif

ifdef MQX_DO_CPPLUS
   CFLAGS_EXTRA   +=-Hcplus
else
   CFLAGS_EXTRA   +=-Hnocplus
   LD += -Hnocplus
endif

ifdef MQX_COMPRESS_INITDATA
   CFLAGS_EXTRA += -DMQX_COMPRESS_INITDATA
else
   CFLAGS_EXTRA += -Hnocopyr
   LD += -Hnocopyr
endif

ifneq ($(findstring -DMQX_KERNEL_LOGGING=0,$(CPPFLAGS)),)
   ASFLAGS_EXTRA += -DMQX_KERNEL_LOGGING=0
endif

#---------------------------------------------------------------------------

ifneq ($(findstring $(MQX_PSP),arca),)

# compiler options for extra instructions
# -DPSP_SAVE_MUL_MAC -DPSP_SAVE_XMAC
# -Xmul_mac -Xbarrel_shifter -Xmin_max
# -Xmul_mac -Xmult32 -Xnorm -Xswap
# Number of extension registers
# -DPSP_NUM_EXTENSION_REGISTERS=0
# Bit mask of extra extension registers,
# bit0 => save R32, bit1 => save R33 etc
# -DPSP_EXTENSION_REGISTERS=0

CFLAGS_EXTRA   +=-arc6 -Hsdata0
CPPFLAGS_EXTRA +=-DPSP_NUM_EXTENSION_REGISTERS=0 -DPSP_EXTENSION_REGISTERS=0
ASFLAGS_EXTRA  =$(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA)
endif

ifneq ($(findstring $(MQX_PSP),arcta4),)
# compiler options for extra instructions
# -Xbarrel_shifter   # barrel shifter
# -Xmin_max          # MIN & MAX instructions
# -Xmult32           # 32x32 scoreboarded multiplier
# -Xmult32_old       # back revision of 32x32 multiplier
# -Xnorm             # NORM instruction
# -Xscratch_ram      # Scratch RAM extension
# -Xsliding_pointers # Sliding pointers extension (with Scratch RAM)
# -Xswap             # SWAP instruction
# -Xxy               # XY memory extension
# -DPSP_SAVE_XMAC    # if using any of the xmacs
# -Xxmac_16          # XMAC multiply-accumulate block
# -Xxmac_d16
# -Xxmac_24
# if -Xmult32  is defined, then registers 57 and 59 need to be saved
# Number of extension registers
# -DPSP_NUM_EXTENSION_REGISTERS=0
# Bit mask of extra extension registers,
# bit0 => save R32, bit1 => save R33 etc
# -DPSP_EXTENSION_REGISTERS=0

CFLAGS_EXTRA   +=-arc8 -Hsdata0
CPPFLAGS_EXTRA +=-DPSP_NUM_EXTENSION_REGISTERS=0 -DPSP_EXTENSION_REGISTERS=0
ASFLAGS_EXTRA  =$(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA)
endif

# START CR 315
ifeq ($(MQX_PSP),arcta5)
# compiler options for extra instructions
# -Xbarrel_shifter   # barrel shifter
# -Xmin_max          # MIN & MAX instructions
# -Xmult32           # 32x32 scoreboarded multiplier
# -Xmult32_old       # back revision of 32x32 multiplier
# -Xnorm             # NORM instruction
# -Xscratch_ram      # Scratch RAM extension
# -Xsliding_pointers # Sliding pointers extension (with Scratch RAM)
# -Xswap             # SWAP instruction
# -Xxy               # XY memory extension
# -DPSP_SAVE_XMAC    # if using any of the xmacs
# -Xxmac_16          # XMAC multiply-accumulate block
# -Xxmac_d16
# -Xxmac_24
# if -Xmult32  is defined, then registers 57 and 59 need to be saved
# Number of extension registers
# -DPSP_NUM_EXTENSION_REGISTERS=0
# Bit mask of extra extension registers,
# bit0 => save R32, bit1 => save R33 etc
# -DPSP_EXTENSION_REGISTERS=0

ARC_COMPACT = 1

CFLAGS_EXTRA   +=-core1 -Hsdata0
CPPFLAGS_EXTRA +=-DPSP_NUM_EXTENSION_REGISTERS=0 -DPSP_EXTENSION_REGISTERS=0
ASFLAGS_EXTRA  =$(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA)

endif
# END CR 315

ifeq ($(MQX_PSP),arcta52)
# compiler options for extra instructions
# -Xadds             # Saturating add/subtract
# -Xmult32           # 32x32 scoreboarded multiplier
# -Xnorm             # NORM instruction
# -Xscratch_ram      # Scratch RAM extension
# -Xswap             # SWAP instruction
# -Xxmac_d16         # XMAC multiply-accumulate block
# -Xxmac_24
# -Xxy               # XY memory extension
# -Xcrc              # CRC extension
# -Xvbfdw            # Dual Viterbi Butterfly extension
# Options not currently support directly by the compiler
# -DMQX_DSP_REGISTERS_EXIST=1 # overides default in psp_cfg.met.
#     Specifies MQX to save and restore DSP 3.1 registers.
#
# Number of extension registers
# -DPSP_NUM_EXTENSION_REGISTERS=0
# Bit mask of extra extension registers,
# bit0 => save R32, bit1 => save R33 etc
# -DPSP_EXTENSION_REGISTERS=0

ARC_COMPACT = 1

CFLAGS_EXTRA   +=-Hsdata0 -core3
CPPFLAGS_EXTRA +=-DPSP_NUM_EXTENSION_REGISTERS=0 -DPSP_EXTENSION_REGISTERS=0
ASFLAGS_EXTRA  =$(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA) $(CPPFLAGS)

endif

ifneq ($(findstring $(MQX_PSP),arctc),)
CFLAGS_EXTRA   +=-arc5 -Hsdata0 -Xbarrel_shifter -Xmin_max -Xmul_mac -Xmult32 -Xnorm -Xswap
CPPFLAGS_EXTRA +=-DPSP_NUM_EXTENSION_REGISTERS=0 -DPSP_EXTENSION_REGISTERS=0
ASFLAGS_EXTRA  =$(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA)
endif

ifneq ($(findstring $(MQX_PSP),arcsim),)
CFLAGS_EXTRA   +=-arc6 -Hsdata0 -Xbarrel_shifter -Xmin_max -Xmul_mac -Xmult32 -Xnorm -Xswap
CPPFLAGS_EXTRA +=-DPSP_NUM_EXTENSION_REGISTERS=0 -DPSP_EXTENSION_REGISTERS=0
ASFLAGS_EXTRA  =$(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA)
endif

CFLAGS_EXTRA   +=-Hpragma=Offwarn$(OPENPAREN)572$(CLOSEPAREN) -Hpragma=Offwarn$(OPENPAREN)827$(CLOSEPAREN)

# Start CR 481
ifeq ($(MQX_PSP),arcta422t)
# compiler options for extra instructions
# -Xbarrel_shifter   # barrel shifter
# -Xmin_max          # MIN & MAX instructions
# -Xmult32           # 32x32 scoreboarded multiplier
# -Xmult32_old       # back revision of 32x32 multiplier
# -Xnorm             # NORM instruction
# -Xscratch_ram      # Scratch RAM extension
# -Xsliding_pointers # Sliding pointers extension (with Scratch RAM)
# -Xswap             # SWAP instruction
# -Xxy               # XY memory extension
# -DPSP_SAVE_XMAC    # if using any of the xmacs
# -Xxmac_16          # XMAC multiply-accumulate block
# -Xxmac_d16
# -Xxmac_24
# if -Xmult32  is defined, then registers 57 and 59 need to be saved
# Number of extension registers
# -DPSP_NUM_EXTENSION_REGISTERS=0
# Bit mask of extra extension registers,
# bit0 => save R32, bit1 => save R33 etc
# -DPSP_EXTENSION_REGISTERS=0
CFLAGS_EXTRA   +=-arc8 -Hsdata0	-O7 -Xtelephony 
CPPFLAGS_EXTRA +=-DPSP_NUM_EXTENSION_REGISTERS=0 -DPSP_EXTENSION_REGISTERS=0
ASFLAGS_EXTRA  =$(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA)
endif
# End CR 481


ifneq ($(findstring $(MQX_PSP),arctc),)
CFLAGS_EXTRA   +=-arc5 -Hsdata0 -Xbarrel_shifter -Xmin_max -Xmul_mac -Xmult32 -Xnorm -Xswap
CPPFLAGS_EXTRA +=-DPSP_NUM_EXTENSION_REGISTERS=0 -DPSP_EXTENSION_REGISTERS=0
ASFLAGS_EXTRA  =$(CFLAGS_EXTRA) $(CPPFLAGS_EXTRA)
endif


MQX_INCDIRS +=$(MQX_COMPILER_ROOT)$(PS)inc
met_lib =lib

ifeq ($(MQX_ENDIAN),b)
   LD +=-HB
   CFLAGS_EXTRA  +=-HB
   ASFLAGS_EXTRA +=-be
   met_lib :=$(met_lib)$(PS)be
else
   LD +=-HL
   CFLAGS_EXTRA  +=-HL
   ASFLAGS_EXTRA +=-le
   met_lib :=$(met_lib)$(PS)le
endif

# EOF
