/*******************************************************************************
** File          : $HeadURL: file:///ci/svn/USBCTRL/HSCTRL/tags/HSCTRL_1.1.A/digital/design/hsctrl/testbench/bfm/co_simulation/common_include/DataTypes.h $ 
** Author        : $Author: valentim $
** Project       : HSCTRL 
** Instances     : 
** Creation date : 
********************************************************************************
********************************************************************************
** ChipIdea Microelectronica - IPCS
** TECMAIA, Rua Eng. Frederico Ulrich, n 2650
** 4470-920 MOREIRA MAIA
** Portugal
** Tel: +351 229471010
** Fax: +351 229471011
** e_mail: chipidea.com
********************************************************************************
** ISO 9001:2000 - Certified Company
** (C) 2005 Copyright Chipidea(R)
** Chipidea(R) - Microelectronica, S.A. reserves the right to make changes to
** the information contained herein without notice. No liability shall be
** incurred as a result of its use or application.
********************************************************************************
** Modification history:
** $Date: 2006-11-24 19:48:27 +0000 (Fri, 24 Nov 2006) $
** $Revision: 483 $
*******************************************************************************/


//==========================================================
// DataTypes.h
//
//==========================================================
#ifdef WIN32

#pragma warning(disable:4786)

#endif

#define PRAGMA_OFF_BEHAVED 
#define PRAGMA_ON_BEHAVED 
 
typedef unsigned char Data8Bit;
typedef unsigned short Data16Bit;
typedef unsigned long Data32Bit; // Common data types that will need to stay 32bit
typedef Data32Bit UnSignedLong;
typedef Data32Bit AddressType;
typedef Data16Bit UnSignedShort;
typedef Data8Bit  StdLogic;
typedef Data8Bit  UnSignedChar;

#ifdef EMBEDDED_COMPILE
	
	typedef  volatile UnSignedLong* VolatileUnSignedLongPtr;
	typedef  volatile UnSignedShort* VolatileUnSignedShortPtr;
	typedef  volatile UnSignedChar* VolatileUnSignedCharPtr;
	typedef  volatile UnSignedLong VolatileUnSignedLong;
	typedef  volatile UnSignedShort VolatileUnSignedShort;
	typedef  volatile UnSignedChar VolatileUnSignedChar;
  
/*
  #define DEBUG_MSG(x)			//TODO EMBEDDED: could be set to { printf(x); }
	#define DEBUG_INTERRUPT_START() //TODO EMBEDDED: could be set to { printf("START INTERRUPT"); }
	#define DEBUG_INTERRUPT_END()	//TODO EMBEDDED: could be set to { printf("END INTERRUPT"); }
	#define FATAL_ERROR(x)			//TODO EMBEDDED: could be set to { printf(x); abort(); }
	#define FATAL_ASSERT(x,y)		//TODO EMBEDDED: could be set to { if(x) { printf(y); abort(); }}
*/

#define VolatileMemoryCopy memcpy
#else

	extern void DEBUG_MSG( char* string );
	extern void DEBUG_INTERRUPT_START();
	extern void DEBUG_INTERRUPT_END();
	extern void DEBUG_MSG( unsigned long value );
	extern void FATAL_ERROR( char* string );
	extern void FATAL_ASSERT( bool assert, char* string );

#include "TVolatileDataPointerType.h"

	typedef TVolatileDataPointerType< UnSignedLong > VolatileUnSignedLongPtr;
	typedef TVolatileDataPointerType< UnSignedShort > VolatileUnSignedShortPtr;
	typedef TVolatileDataPointerType< UnSignedChar > VolatileUnSignedCharPtr;
	typedef TVolatileDataType< UnSignedLong > VolatileUnSignedLong;
	typedef TVolatileDataType< UnSignedShort > VolatileUnSignedShort;
	typedef TVolatileDataType< UnSignedChar > VolatileUnSignedChar;
 
	void MemoryCopyToVolatile( UnSignedLong target_ptr, UnSignedLong source_ptr, UnSignedLong size );
	void MemoryCopyFromVolatile( UnSignedLong target_ptr, UnSignedLong source_ptr, UnSignedLong size );


#endif
