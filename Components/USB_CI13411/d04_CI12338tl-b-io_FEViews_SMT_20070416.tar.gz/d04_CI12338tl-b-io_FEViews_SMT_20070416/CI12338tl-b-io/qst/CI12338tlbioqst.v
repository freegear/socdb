/***************************************************************************************************
--
-- Description   : QuickStart Testbench
--
----------------------------------------------------------------------------------------------------
-- History:
-- Date         Version    Comment
-- 16Apr2007       1v0      First version
----------------------------------------------------------------------------------------------------
-- ChipIdea Microelectronica - Digital Technology Center
-- TECMAIA, Rua Eng. Frederico Ulrich, n 2650
-- 4470-605 Moreira da Maia
-- Portugal
-- Tel: +351 229471010
-- Fax: +351 229471011
****************************************************************************************************/


`timescale 1ns/1ps

`define PHY
`define SYSCLOCK_12MHZ
`define WITHOUT_CHARGEPUMP


module CI12338tlbioqst;

//-- TESTBENCH PARAMETERS -----------------------------------------------------
//--
parameter      STIMULI_DIR                 = "./"   ;
parameter      RESULTS_DIR                 = "./"   ;

`ifdef SYSCLOCK_12MHZ
parameter      MAX_SYSCLOCK_PERIOD         = 83.290 ;           // Maximum frequency for master clock fMAX=12MHz+520ppm
parameter      TYP_SYSCLOCK_PERIOD         = 83.333 ;           // Typical frequency for master clock fTYP=12MHz
parameter      MIN_SYSCLOCK_PERIOD         = 83.380 ;           // Minimum frequency for master clock fMIN=12MHz-560ppm
`elsif SYSCLOCK_24MHZ
parameter      MAX_SYSCLOCK_PERIOD         = 41.645 ;           // Maximum frequency for master clock fMAX=24MHz+520ppm
parameter      TYP_SYSCLOCK_PERIOD         = 41.667 ;           // Typical frequency for master clock fTYP=24MHz
parameter      MIN_SYSCLOCK_PERIOD         = 41.690 ;           // Minimum frequency for master clock fMIN=24MHz-560ppm
`elsif SYSCLOCK_96MHZ
parameter      MAX_SYSCLOCK_PERIOD         = 10.411 ;           // Maximum frequency for master clock fMAX=96MHz+520ppm
parameter      TYP_SYSCLOCK_PERIOD         = 10.417 ;           // Typical frequency for master clock fTYP=96MHz
parameter      MIN_SYSCLOCK_PERIOD         = 10.423 ;           // Minimum frequency for master clock fMIN=96MHz-560ppm
`else
parameter      MAX_SYSCLOCK_PERIOD         = 0.000  ;
parameter      TYP_SYSCLOCK_PERIOD         = 0.000  ;
parameter      MIN_SYSCLOCK_PERIOD         = 0.000  ;
initial
begin
   $display("\nERROR! SYSCLOCK Clock Value Not Defined - Valid Options are : `define SYSCLOCK_12MHZ or `define SYSCLOCK_24MHZ or `define SYSCLOCK_96MHZ");
   $display("If Using NCVERILOG Add one of the following lines in your script");
   $display("             +define+SYSCLOCK_12MHZ \\");
   $display("             +define+SYSCLOCK_24MHZ \\");
   $display("             +define+SYSCLOCK_96MHZ \\ \n\n");
   $finish;
end
`endif

parameter      SIECLOCK_TO_DATA_DELAY      = 5  ;               // Delay from sieclock rising edge to update of input interface signals

parameter      TESTER_TESTMODE_CHARGING    = "SUSPEND_NEEDED" ; //Let it open if suspend is not needed for testmode charging

real           HOST_SYSCLOCK_PERIOD             ;
real           DEVICE_SYSCLOCK_PERIOD           ;
real           HOST_SYSCLOCK_FREQUENCY          ;
real           DEVICE_SYSCLOCK_FREQUENCY        ;

real           TESTBENCH_HOST_SYSCLOCK_PERIOD   ;
real           TESTBENCH_DEVICE_SYSCLOCK_PERIOD ;

//-- TESTBENCH SIGNALS --------------------------------------------------------
//--
reg     [200:0] errors                  ;
reg     [200:0] warnings                ;
reg     [511:0] production_test         ;   //production test mode in progress (for information only)
reg     [7:0]   aData[1:8192]           ;
reg     [7:0]   bData[1:8192]           ;
reg     [7:0]   cData[1:8192]           ;
integer         spec                    ;
integer         bytes_received, host_bytes_received, bytes_transmitted;

//-- COMMON PORTS -------------------------------------------------------------
//--
wire            common_dp               ;       // USB cable D+ signal
wire            common_dn               ;       // USB cable D- signal

//-- USB 2.0 DOWNSTREAM PHY PORTS ---------------------------------------------
//--
reg             host_sysclock           ;
wire            host_sieclock           ;
reg             host_databus16_8        ;
reg     [15:0]  host_datain             ;
reg             host_txvalid            ;
reg             host_txvalidh           ;
wire            host_txready            ;
wire    [15:0]  host_dataout            ;
wire            host_rxvalid            ;
wire            host_rxvalidh           ;
wire            host_rxactive           ;
wire            host_rxerror            ;
reg             host_reset              ;
reg             host_suspend            ;
reg     [1:0]   host_xcvrsel            ;
reg             host_termsel            ;
reg     [1:0]   host_opmode             ;
wire    [1:0]   host_linestate          ;
wire            host_rrefext            ;
reg             host_vload              ;
reg     [3:0]   host_vcontrol           ;
wire    [7:0]   host_vstatus            ;
reg             host_scanmode           ;
reg             host_scanclk            ;
reg             host_scanin             ;
reg             host_scanen             ;
wire            host_scanout            ;
reg             host_dppulldown         ;
reg             host_dnpulldown         ;
wire            host_disconnect         ;
reg             host_stuffenable        ;
reg             host_stuffenableh       ;
reg             host_fslsserialmode     ;
reg             host_txenablez          ;
reg             host_txdata             ;
reg             host_txsezero           ;
wire            host_rxdp               ;
wire            host_rxdm               ;
wire            host_rxrcv              ;
reg             host_conf1              ;
reg             host_conf3              ;
reg             host_conf4              ;
reg             host_onbist             ;
reg             host_onclock            ;
wire            host_clockout           ;
wire            host_gpanaio            ;

wire            host_vbus               ;
reg             host_id                 ;
reg             host_chargevbus         ;
reg             host_dischargevbus      ;
wire            host_vbusvalid          ;
wire            host_avalid             ;
wire            host_bvalid             ;
wire            host_endsession         ;
reg             host_idpullup           ;
wire            host_iddig              ;
reg             host_conf2              ;

wire            host_vbusovercurrent    ;
reg             host_drvvbus            ;

wire            host_id_int             ;
assign          host_id_int = host_id   ;

//-- USB 2.0 UPSTREAM PHY PORTS -----------------------------------------------
//--
reg             device_sysclock         ;
wire            device_sieclock         ;
reg             device_databus16_8      ;
reg     [15:0]  device_datain           ;
reg             device_txvalid          ;
reg             device_txvalidh         ;
wire            device_txready          ;
wire    [15:0]  device_dataout          ;
wire            device_rxvalid          ;
wire            device_rxvalidh         ;
wire            device_rxactive         ;
wire            device_rxerror          ;
reg             device_reset            ;
reg             device_suspend          ;
reg     [1:0]   device_xcvrsel          ;
reg             device_termsel          ;
reg     [1:0]   device_opmode           ;
wire    [1:0]   device_linestate        ;
wire            device_rrefext          ;
reg             device_vload            ;
reg     [3:0]   device_vcontrol         ;
wire    [7:0]   device_vstatus          ;
reg             device_scanmode         ;
reg             device_scanclk          ;
reg             device_scanin           ;
reg             device_scanen           ;
wire            device_scanout          ;
reg             device_dppulldown       ;
reg             device_dnpulldown       ;
wire            device_disconnect       ;
reg             device_stuffenable      ;
reg             device_stuffenableh     ;
reg             device_fslsserialmode   ;
reg             device_txenablez        ;
reg             device_txdata           ;
reg             device_txsezero         ;
wire            device_rxdp             ;
wire            device_rxdm             ;
wire            device_rxrcv            ;
reg             device_conf1            ;
reg             device_conf3            ;
reg             device_conf4            ;
reg             device_onbist           ;
reg             device_onclock          ;
wire            device_clockout         ;
wire            device_gpanaio          ;

wire            device_vbus             ;
reg             device_id               ;
reg             device_chargevbus       ;
reg             device_dischargevbus    ;
wire            device_vbusvalid        ;
wire            device_avalid           ;
wire            device_bvalid           ;
wire            device_endsession       ;
reg             device_idpullup         ;
wire            device_iddig            ;
reg             device_conf2            ;

wire            device_vbusovercurrent  ;
reg             device_drvvbus          ;

wire            device_id_int               ;
assign          device_id_int = device_id   ;

//-----------------------------------------------------------------------------
//--                           CLOCK GENERATION
//-----------------------------------------------------------------------------

//-- Host Sysclock
    always
    begin
        #(HOST_SYSCLOCK_PERIOD/2);
        host_sysclock <= 1;
        #(HOST_SYSCLOCK_PERIOD/2);
        host_sysclock <= 0;
    end

//-- Device Sysclock
    always
    begin
        #(DEVICE_SYSCLOCK_PERIOD/2);
        device_sysclock <= 1;
        #(DEVICE_SYSCLOCK_PERIOD/2);
        device_sysclock <= 0;
    end

always@(HOST_SYSCLOCK_PERIOD)
    HOST_SYSCLOCK_FREQUENCY   = 1.0/HOST_SYSCLOCK_PERIOD*1e3;   // System Clock Frequency in MHz

always@(DEVICE_SYSCLOCK_PERIOD)
    DEVICE_SYSCLOCK_FREQUENCY = 1.0/DEVICE_SYSCLOCK_PERIOD*1e3; // System Clock Frequency in MHz


wire           common_vdda          ;
assign         common_vdda = 1'b1   ;
wire           common_vssa          ;
assign         common_vssa = 1'b0   ;
wire           common_vddp          ;
assign         common_vddp = 1'b1   ;
wire           common_vssp          ;
assign         common_vssp = 1'b0   ;
wire           common_vdds          ;
assign         common_vdds = 1'b1   ;
wire           common_vsss          ;
assign         common_vsss = 1'b0   ;
wire           common_vddd          ;
assign         common_vddd = 1'b1   ;
wire           common_vssd          ;
assign         common_vssd = 1'b0   ;

`ifdef PHY
`elsif OTG
`else
initial
begin
   $display("\nERROR! PHY or OTG must be defined - Valid Options are : `define PHY or `define OTG");
   $display("If Using NCVERILOG Add one of the following lines in your script");
   $display("             +define+PHY \\");
   $display("             +define+OTG \\ \n\n");
   $finish;
end
`endif

`ifdef WITH_CHARGEPUMP
`elsif WITHOUT_CHARGEPUMP
`else
initial
begin
   $display("\nERROR! WITH_CHARGEPUMP or WITHOUT_CHARGEPUMP must be defined - Valid Options are : `define WITH_CHARGEPUMP or `define WITHOUT_CHARGEPUMP");
   $display("If Using NCVERILOG Add one of the following lines in your script");
   $display("             +define+WITH_CHARGEPUMP \\");
   $display("             +define+WITHOUT_CHARGEPUMP \\ \n\n");
   $finish;
end
`endif

//-- USB 2.0 DOWNSTREAM-FACING PHY INSTANTIATION ------------------------------
//--
`ifdef OTG
usb2otgf
`elsif PHY
CI12338tl
`endif
        UUT_HOST    (
                    .vdda               ( common_vdda           ),
                    .vssa               ( common_vssa           ),
                    .vddp               ( common_vddp           ),
                    .vssp               ( common_vssp           ),
                    .vdds               ( common_vdds           ),
                    .vsss               ( common_vsss           ),
                    .dp                 ( common_dp             ),
                    .dn                 ( common_dn             ),
                    .sysclock           ( host_sysclock         ),
                    .sieclock           ( host_sieclock         ),
                    .databus16_8        ( host_databus16_8      ),
                    .datain             ( host_datain           ),
                    .txvalid            ( host_txvalid          ),
                    .txvalidh           ( host_txvalidh         ),
                    .txready            ( host_txready          ),
                    .dataout            ( host_dataout          ),
                    .rxvalid            ( host_rxvalid          ),
                    .rxvalidh           ( host_rxvalidh         ),
                    .rxactive           ( host_rxactive         ),
                    .rxerror            ( host_rxerror          ),
                    .reset              ( host_reset            ),
                    .suspend            ( host_suspend          ),
                    .xcvrsel            ( host_xcvrsel          ),
                    .termsel            ( host_termsel          ),
                    .opmode             ( host_opmode           ),
                    .linestate          ( host_linestate        ),
                    .rrefext            ( host_rrefext          ),
                    .vload              ( host_vload            ),
                    .vcontrol           ( host_vcontrol         ),
                    .vstatus            ( host_vstatus          ),
                    .scanmode           ( host_scanmode         ),
                    .scanclk            ( host_scanclk          ),
                    .scanina            ( host_scanin           ),
                    .scaninb            ( host_scanin           ),
                    .scanen             ( host_scanen           ),
                    .scanouta           ( host_scanout          ),
                    .scanoutb           ( /* NC */              ),
                    .dppulldown         ( host_dppulldown       ),
                    .dnpulldown         ( host_dnpulldown       ),
                    .hostdisconnect     ( host_disconnect       ),
                    .txbitstuffenable   ( host_stuffenable      ),
                    .txbitstuffenableH  ( host_stuffenableh     ),
                    .fslsserialmode     ( host_fslsserialmode   ),
                    .txenablez          ( host_txenablez        ),
                    .txdata             ( host_txdata           ),
                    .txsezero           ( host_txsezero         ),
                    .rxdp               ( host_rxdp             ),
                    .rxdm               ( host_rxdm             ),
                    .rxrcv              ( host_rxrcv            ),
                    .conf1              ( host_conf1            ),
                    .setin12            ( ~host_conf4           ),
                    .onbist             ( host_onbist           ),
                    .gpanaio            ( /* NC */              ),
                    .vbg                ( /* NC */              ),
                    .ibiascp            ( /* NC */              )

                    //OTG-specific pins
                    `ifdef OTG
                    ,
                    .vbus               ( host_vbus             ),
                    .id                 ( host_id_int           ),
                    .chargevbus         ( host_chargevbus       ),
                    .dischargevbus      ( host_dischargevbus    ),
                    .vbusvalid          ( host_vbusvalid        ),
                    .avalid             ( host_avalid           ),
                    .bvalid             ( host_bvalid           ),
                    .endsession         ( host_endsession       ),
                    .idpullup           ( host_idpullup         ),
                    .iddig              ( host_iddig            ),
                    .conf2              ( host_conf2            )
                    `endif

                    `ifdef WITH_CHARGEPUMP
                    ,
                    .vbusovercurrent    ( host_vbusovercurrent  ),
                    .drvvbus            ( host_drvvbus          )
                    `endif

                    );
//defparam UUT_HOST.U0.UCORE1.U2.BGAPRSPTIME = 0;
//defparam UUT_HOST.U0.UCORE1.U3.TSTART      = 0;

//-- USB 2.0 UPSTREAM-FACING PHY INSTANTIATION --------------------------------
//--
`ifdef OTG
usb2otgf
`elsif PHY
CI12338tl
`endif
        UUT_DEVICE  (
                    .vdda               ( common_vdda           ),
                    .vssa               ( common_vssa           ),
                    .vddp               ( common_vddp           ),
                    .vssp               ( common_vssp           ),
                    .vdds               ( common_vdds           ),
                    .vsss               ( common_vsss           ),
                    .dp                 ( common_dp             ),
                    .dn                 ( common_dn             ),
                    .sysclock           ( device_sysclock       ),
                    .sieclock           ( device_sieclock       ),
                    .databus16_8        ( device_databus16_8    ),
                    .datain             ( device_datain         ),
                    .txvalid            ( device_txvalid        ),
                    .txvalidh           ( device_txvalidh       ),
                    .txready            ( device_txready        ),
                    .dataout            ( device_dataout        ),
                    .rxvalid            ( device_rxvalid        ),
                    .rxvalidh           ( device_rxvalidh       ),
                    .rxactive           ( device_rxactive       ),
                    .rxerror            ( device_rxerror        ),
                    .reset              ( device_reset          ),
                    .suspend            ( device_suspend        ),
                    .xcvrsel            ( device_xcvrsel        ),
                    .termsel            ( device_termsel        ),
                    .opmode             ( device_opmode         ),
                    .linestate          ( device_linestate      ),
                    .rrefext            ( device_rrefext        ),
                    .vload              ( device_vload          ),
                    .vcontrol           ( device_vcontrol       ),
                    .vstatus            ( device_vstatus        ),
                    .scanmode           ( device_scanmode       ),
                    .scanclk            ( device_scanclk        ),
                    .scanina            ( device_scanin         ),
                    .scaninb            ( device_scanin         ),
                    .scanen             ( device_scanen         ),
                    .scanouta           ( device_scanout        ),
                    .scanoutb           ( /* NC */              ),
                    .dppulldown         ( device_dppulldown     ),
                    .dnpulldown         ( device_dnpulldown     ),
                    .hostdisconnect     ( device_disconnect     ),
                    .txbitstuffenable   ( device_stuffenable    ),
                    .txbitstuffenableH  ( device_stuffenableh   ),
                    .fslsserialmode     ( device_fslsserialmode ),
                    .txenablez          ( device_txenablez      ),
                    .txdata             ( device_txdata         ),
                    .txsezero           ( device_txsezero       ),
                    .rxdp               ( device_rxdp           ),
                    .rxdm               ( device_rxdm           ),
                    .rxrcv              ( device_rxrcv          ),
                    .conf1              ( device_conf1          ),
                    .setin12            ( ~device_conf4         ),
                    .onbist             ( device_onbist         ),
                    .gpanaio            ( /* NC */              ),
                    .vbg                ( /* NC */              ),
                    .ibiascp            ( /* NC */              )

                    //OTG-specific pins
                    `ifdef OTG
                    ,
                    .vbus               ( device_vbus           ),
                    .id                 ( device_id_int         ),
                    .chargevbus         ( device_chargevbus     ),
                    .dischargevbus      ( device_dischargevbus  ),
                    .vbusvalid          ( device_vbusvalid      ),
                    .avalid             ( device_avalid         ),
                    .bvalid             ( device_bvalid         ),
                    .endsession         ( device_endsession     ),
                    .idpullup           ( device_idpullup       ),
                    .iddig              ( device_iddig          ),
                    .conf2              ( device_conf2          )
                    `endif

                    `ifdef WITH_CHARGEPUMP
                    ,
                    .vbusovercurrent    ( device_vbusovercurrent),
                    .drvvbus            ( device_drvvbus        )
                    `endif

                    );
//defparam UUT_DEVICE.U0.UCORE1.U2.BGAPRSPTIME = 0;
//defparam UUT_DEVICE.U0.UCORE1.U3.TSTART      = 0;

//------------------------------------------------------------------------------------------------
//--------------------------------- SEQUENCE OF TESTS --------------------------------------------
//------------------------------------------------------------------------------------------------
initial
begin
    $display("");
    $display("-------------------------------------------------------------");
    `ifdef PHY
    $display("                     VERIFYING PHY");
    `elsif OTG
    $display("                   VERIFYING OTG PHY");
    `endif
    $display("-------------------------------------------------------------");
    $display("");
    $display("************** Starting Normal Operation Tests **************");
    $display("");
    $display("-------------------------------------------------------------");
    $display("");
    $display(" SIMULATION CONDITIONS:");
    $display("");

    spec   <= 0;
    errors <= 0;

    //-- Change Here the HOST and DEVICE SYSCLOCKs for the Entire Testbench
    TESTBENCH_HOST_SYSCLOCK_PERIOD   = MAX_SYSCLOCK_PERIOD;
    TESTBENCH_DEVICE_SYSCLOCK_PERIOD = MIN_SYSCLOCK_PERIOD;

    HOST_SYSCLOCK_PERIOD             = TESTBENCH_HOST_SYSCLOCK_PERIOD;
    DEVICE_SYSCLOCK_PERIOD           = TESTBENCH_DEVICE_SYSCLOCK_PERIOD;

    //-- SETUP HOST SIGNALS -----------------------------------------------
    host_sysclock           <= 1'b0     ;
    host_databus16_8        <= 1'b1     ;
    host_datain             <= 16'dx    ;
    host_txvalid            <= 1'b0     ;
    host_txvalidh           <= 1'b0     ;
    host_reset              <= 1'b0     ;
    host_suspend            <= 1'b1     ;
    host_xcvrsel            <= 2'b00    ;
    host_termsel            <= 1'b0     ;
    host_opmode             <= 2'b00    ;
    host_vload              <= 1'b1     ;
    host_vcontrol           <= 4'd0     ;
    host_scanmode           <= 1'b0     ;
    host_scanclk            <= 1'b0     ;
    host_scanin             <= 1'b1     ;
    host_scanen             <= 1'b0     ;
    host_dppulldown         <= 1'b1     ;
    host_dnpulldown         <= 1'b1     ;
    host_stuffenable        <= 1'b0     ;
    host_stuffenableh       <= 1'b0     ;
    host_fslsserialmode     <= 1'b0     ;
    host_txenablez          <= 1'b1     ;
    host_txdata             <= 1'b0     ;
    host_txsezero           <= 1'b0     ;
    host_conf1              <= 1'b0     ;
    host_conf3              <= 1'b0     ;
    host_onbist             <= 1'b0     ;
    host_onclock            <= 1'b0     ;
`ifdef SYSCLOCK_12MHZ
    host_conf4              <= 1'b0     ;           //cross-check this value with datasheet
`elsif SYSCLOCK_24MHZ
    host_conf4              <= 1'b1     ;           //cross-check this value with datasheet
`endif
    host_id                 <= 1'bz     ;
    host_chargevbus         <= 1'b0     ;
    host_dischargevbus      <= 1'b0     ;
    host_idpullup           <= 1'b0     ;
    host_conf2              <= 1'b0     ;
    host_drvvbus            <= 1'b0     ;

    //-- SETUP DEVICE SIGNALS ---------------------------------------------
    device_sysclock         <= 1'b0     ;
    device_databus16_8      <= 1'b1     ;
    device_datain           <= 16'dx    ;
    device_txvalid          <= 1'b0     ;
    device_txvalidh         <= 1'b0     ;
    device_reset            <= 1'b0     ;
    device_suspend          <= 1'b1     ;
    device_xcvrsel          <= 2'b00    ;
    device_termsel          <= 1'b0     ;
    device_opmode           <= 2'b00    ;
    device_vload            <= 1'b1     ;
    device_vcontrol         <= 4'd0     ;
    device_scanmode         <= 1'b0     ;
    device_scanclk          <= 1'b0     ;
    device_scanin           <= 1'b1     ;
    device_scanen           <= 1'b0     ;
    device_dppulldown       <= 1'b0     ;
    device_dnpulldown       <= 1'b0     ;
    device_stuffenable      <= 1'b0     ;
    device_stuffenableh     <= 1'b0     ;
    device_fslsserialmode   <= 1'b0     ;
    device_txenablez        <= 1'b1     ;
    device_txdata           <= 1'b0     ;
    device_txsezero         <= 1'b0     ;
    device_conf1            <= 1'b0     ;
    device_conf3            <= 1'b0     ;
    device_onbist           <= 1'b0     ;
    device_onclock          <= 1'b0     ;
`ifdef SYSCLOCK_12MHZ
    device_conf4            <= 1'b0     ;           //cross-check this value with datasheet
`elsif SYSCLOCK_24MHZ
    device_conf4            <= 1'b1     ;           //cross-check this value with datasheet
`endif
    device_id               <= 1'bz     ;
    device_chargevbus       <= 1'b0     ;
    device_dischargevbus    <= 1'b0     ;
    device_idpullup         <= 1'b0     ;
    device_conf2            <= 1'b0     ;
    device_drvvbus          <= 1'b0     ;

    errors                  <= 201'd0   ;
    warnings                <= 201'd0   ;
    production_test         = "None - Normal Operation Tests...";

    // Apply Host and Device Reset
    host_apply_reset;
    device_apply_reset;

    print_host_status;
    print_device_status;

    // Set of Tests

    $display("-------------------------------------------------------------");
    $display("");
    $display(" Waiting for USB PHY to power-up...");
    repeat(2) @(posedge device_sieclock);
    repeat(2) @(posedge host_sieclock);
    $display($time," Power is up.");

    //
    //
    spec <= 1;
    $display("");
    $display("-----------------------------------------------------------------");
    $display("Low-Speed operation in 16-bit mode with USB standard test packet");
    $display("-----------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b1);
    host_apply_xcvrsel(2'b10);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b1);
    device_apply_xcvrsel(2'b10);
    host_apply_databus(1);
    device_apply_databus(1);

    repeat(200) @(posedge host_sieclock);

    fork
        host_16bits_send_data_from_file("stimuli1.txt",56);
        device_receive;
    join

    verify_transmission("DEVICE","");

    //
    //
    spec <= 2;
    $display("");
    $display("-----------------------------------------------------------------");
    $display("Low-Speed operation in 8-bit mode with USB standard test packet");
    $display("-----------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b1);
    host_apply_xcvrsel(2'b10);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b1);
    device_apply_xcvrsel(2'b10);
    host_apply_databus(0);
    device_apply_databus(0);

    repeat(200) @(posedge host_sieclock);

    fork
        host_8bits_send_data_from_file("stimuli1.txt",56);
        device_receive;
    join

    verify_transmission("DEVICE","");

    //
    //
    spec <= 3;
    $display("");
    $display("-----------------------------------------------------------------");
    $display("Full-Speed operation in 16-bit mode with USB standard test packet");
    $display("-----------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b1);
    host_apply_xcvrsel(2'b01);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b1);
    device_apply_xcvrsel(2'b01);
    host_apply_databus(1);
    device_apply_databus(1);

    repeat(200) @(posedge host_sieclock);

    fork
        host_16bits_send_data_from_file("stimuli1.txt",56);
        device_receive;
    join

    verify_transmission("DEVICE","");

    //
    //
    spec <= 4;
    $display("");
    $display("-----------------------------------------------------------------");
    $display("Full-Speed operation in 8-bit mode with USB standard test packet");
    $display("-----------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b1);
    host_apply_xcvrsel(2'b01);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b1);
    device_apply_xcvrsel(2'b01);
    host_apply_databus(0);
    device_apply_databus(0);

    repeat(200) @(posedge host_sieclock);

    fork
        host_8bits_send_data_from_file("stimuli1.txt",56);
        device_receive;
    join

    verify_transmission("DEVICE","");

    //
    //
    spec <= 5;
    $display("");
    $display("-----------------------------------------------------------------");
    $display("High-Speed operation in 16-bit mode with USB standard test packet");
    $display("-----------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b0);
    host_apply_xcvrsel(2'b00);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b0);
    device_apply_xcvrsel(2'b00);
    host_apply_databus(1);
    device_apply_databus(1);

    repeat(200) @(posedge host_sieclock);

    fork
        host_16bits_send_data_from_file("stimuli1.txt",56);
        device_receive;
    join

    verify_transmission("DEVICE","");

    //
    //
    spec <= 6;
    $display("");
    $display("-----------------------------------------------------------------");
    $display("High-Speed operation in 8-bit mode with USB standard test packet");
    $display("-----------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b0);
    host_apply_xcvrsel(2'b00);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b0);
    device_apply_xcvrsel(2'b00);
    host_apply_databus(0);
    device_apply_databus(0);

    repeat(200) @(posedge host_sieclock);

    fork
        host_8bits_send_data_from_file("stimuli1.txt",56);
        device_receive;
    join

    verify_transmission("DEVICE","");

    //
    //
    spec <= 7;
    $display("");
    $display("------------------------------------------------------------");
    $display("Checking High-Speed SOF (without Host Disconnect generation ");
    $display("------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b0);
    host_apply_xcvrsel(2'b00);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b0);
    device_apply_xcvrsel(2'b00);
    host_apply_databus(0);
    device_apply_databus(0);

    repeat(200) @(posedge host_sieclock);

    fork
        host_8bits_send_data_from_file("stimuli2.txt",3);
        device_receive;
    join

    verify_transmission("SOF","WITHOUT");

    //
    //
    spec <= 8;
    $display("");
    $display("---------------------------------------------------------");
    $display("Checking High-Speed SOF (with Host Disconnect generation ");
    $display("---------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b0);
    host_apply_xcvrsel(2'b00);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b0);
    device_apply_xcvrsel(2'b00);
    host_apply_databus(0);
    device_apply_databus(0);

    repeat(200) @(posedge host_sieclock);

    force UUT_HOST.U0.UCORE1.U1.vouthsded = 1;

    fork
        host_8bits_send_data_from_file("stimuli2.txt",3);
        device_receive;
    join

    verify_transmission("SOF","WITH");

    release UUT_HOST.U0.UCORE1.U1.vouthsded;

    //
    //
    spec <= 9;
    $display("");
    $display("-------------------------------------------------------------------------------");
    $display("High-Speed operation in 16-bit Loopback Test mode with USB standard test packet");
    $display("-------------------------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b0);
    host_apply_xcvrsel(2'b00);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b0);
    device_apply_xcvrsel(2'b00);
    host_apply_databus(1);
    device_apply_databus(1);

    repeat(200) @(posedge host_sieclock);

    apply_testmode("LOOPBACK");

    fork
        host_16bits_send_data_from_file("stimuli1.txt",56);
        host_receive;
    join

    verify_transmission("HOST","");

    spec <= 10;
    $display("");
    $display("-------------------------------------------------------------------------------");
    $display("High-Speed operation in 8-bit Loopback Test mode with USB standard test packet");
    $display("-------------------------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b0);
    host_apply_xcvrsel(2'b00);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b0);
    device_apply_xcvrsel(2'b00);
    host_apply_databus(0);
    device_apply_databus(0);

    repeat(200) @(posedge host_sieclock);

    apply_testmode("LOOPBACK");

    fork
        host_8bits_send_data_from_file("stimuli1.txt",56);
        host_receive;
    join

    verify_transmission("HOST","");

    spec <= 11;
    $display("");
    $display("-------------------------------------------------------------------------------");
    $display("Full-Speed operation in 16-bit Loopback Test mode with USB standard test packet");
    $display("-------------------------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b1);
    host_apply_xcvrsel(2'b01);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b1);
    device_apply_xcvrsel(2'b01);
    host_apply_databus(1);
    device_apply_databus(1);

    repeat(200) @(posedge host_sieclock);

    apply_testmode("LOOPBACK");

    fork
        host_16bits_send_data_from_file("stimuli1.txt",56);
        host_receive;
    join

    verify_transmission("HOST","");

    spec <= 12;
    $display("");
    $display("-------------------------------------------------------------------------------");
    $display("Full-Speed operation in 8-bit Loopback Test mode with USB standard test packet");
    $display("-------------------------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b1);
    host_apply_xcvrsel(2'b01);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b1);
    device_apply_xcvrsel(2'b01);
    host_apply_databus(0);
    device_apply_databus(0);

    repeat(200) @(posedge host_sieclock);

    apply_testmode("LOOPBACK");

    fork
        host_8bits_send_data_from_file("stimuli1.txt",56);
        host_receive;
    join

    verify_transmission("HOST","");

    spec <= 13;
    $display("");
    $display("------------------------------------------------------------------------------");
    $display("Low-Speed operation in 16-bit Loopback Test mode with USB standard test packet");
    $display("------------------------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b1);
    host_apply_xcvrsel(2'b10);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b1);
    device_apply_xcvrsel(2'b10);
    host_apply_databus(1);
    device_apply_databus(1);

    repeat(200) @(posedge host_sieclock);

    apply_testmode("LOOPBACK");

    fork
        host_16bits_send_data_from_file("stimuli1.txt",56);
        host_receive;
    join

    verify_transmission("HOST","");

    spec <= 14;
    $display("");
    $display("------------------------------------------------------------------------------");
    $display("Low-Speed operation in 8-bit Loopback Test mode with USB standard test packet");
    $display("------------------------------------------------------------------------------");
    host_apply_opmode(2'b00);
    host_apply_termsel(1'b1);
    host_apply_xcvrsel(2'b10);
    device_apply_opmode(2'b00);
    device_apply_termsel(1'b1);
    device_apply_xcvrsel(2'b10);
    host_apply_databus(0);
    device_apply_databus(0);

    repeat(200) @(posedge host_sieclock);

    apply_testmode("LOOPBACK");

    fork
        host_8bits_send_data_from_file("stimuli1.txt",56);
        host_receive;
    join

    verify_transmission("HOST","");

    repeat(200) @(posedge host_sieclock);


    $display("");
    $display("");
    $display("");
    $display("-------------------------------------------------------------");
    $display("");
    $display("***************** Starting Production Tests *****************");
    $display("");
    $display("-------------------------------------------------------------");
    $display("");

    //Disconnecting the Device PHY, because only Host PHY will be tested...
    device_apply_opmode(2'b01);     //Tri-state drivers
    device_reset    <= 1'b1;
    device_suspend  <= 1'b0;

    //Changing the HOST SYSCLOCK frequency to nominal, for the Production Testbench
    host_suspend  <= 1'b0;
    #(HOST_SYSCLOCK_PERIOD*5);
    TESTBENCH_HOST_SYSCLOCK_PERIOD   = TYP_SYSCLOCK_PERIOD;
    HOST_SYSCLOCK_PERIOD             = TESTBENCH_HOST_SYSCLOCK_PERIOD;
    #(HOST_SYSCLOCK_PERIOD*5);
    @( negedge host_sysclock )
    host_suspend  <= 1'b1;
    host_apply_databus(0);

    $display("");
    $display(" Waiting for USB PHY to power-up...");
    $display("");
    repeat(2) @(posedge host_sieclock);
    $display($time," Power is up.");

    //===  BIST LOOPBACK SEQUENCES TESTS
    test_bist_modes;
    //===  FULL SPEED OUTPUT TESTS
    test_fs_output;
    //===  HIGH SPEED OUTPUT TESTS
    test_hs_output;
    //===  LINESTATE TESTS
    test_linestate;
    //===  LOW / FULL SPEED IDLE TESTS
    test_ls_fs_idle;
`ifdef OTG
    //===  OTG TESTS
    test_otg;
`endif


    print_errors;

    $finish;
end


`protect


task host_apply_reset;
reg in_use;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    @(negedge host_sysclock);
    host_reset   <= 1;
    repeat (2) @(negedge host_sysclock);
    host_reset   <= 0;
    repeat (30) @(negedge host_sysclock);

    in_use = 0;
end
endtask


task device_apply_reset;
reg in_use;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    @(negedge device_sysclock);
    device_reset <= 1;
    repeat (2) @(negedge device_sysclock);
    device_reset <= 0;
    repeat (30) @(negedge device_sysclock);

    in_use = 0;
end
endtask


task print_host_status;
begin
    @(posedge host_sysclock );
    @(posedge host_sysclock );
    $display("");
    $display("  * PHY 1 CONFIGURATION (HOST):");
    $display("    ---------------------------");

    $display("    Master Clock Frequency = %f MHz", HOST_SYSCLOCK_FREQUENCY);

    if( host_databus16_8 )
        $display("    databus16_8 = 1 (16 BITS UTMI INTERFACE)");
    else
        $display("    databus16_8 = 0 (8 BITS UTMI INTERFACE)");

    if( host_termsel )
        $display("    host_termsel = 1 (2'b01-SPEED TERMINATION)");
    else
        $display("    host_termsel = 0 (2'b00-SPEED TERMINATION)");

    case( host_xcvrsel )
    2'b00:  $display("    host_xcvrsel = 00 (2'b00-SPEED TRANSCEIVER ENABLED)");
    2'b01:  $display("    host_xcvrsel = 01 (2'b01-SPEED TRANSCEIVER ENABLED)");
    2'b10:  $display("    host_xcvrsel = 10 (2'b10-SPEED TRANSCEIVER ENABLED)");
    2'b11:  $display("    host_xcvrsel = 11 (RESERVED MODE)");
    endcase

    case( host_opmode )
    2'b00:  $display("    host_opmode = 00 (NORMAL OPERATION)");
    2'b01:  $display("    host_opmode = 01 (NON-DRIVING)");
    2'b10:  $display("    host_opmode = 10 (DISABLE BIT-STUFFING AND NRZI ENCODING");
    2'b11:  $display("    host_opmode = 11 (RESERVED MODE)");
    endcase

    $display("    -------------------");
end
endtask


task print_device_status;
begin
    @(posedge device_sysclock );
    @(posedge device_sysclock );
    $display("");
    $display("  * PHY 2 CONFIGURATION (DEVICE):");
    $display("    -----------------------------");

    $display("    Master Clock Frequency = %f MHz", DEVICE_SYSCLOCK_FREQUENCY);

    if( device_databus16_8 )
        $display("    databus16_8 = 1 (16 BITS UTMI INTERFACE)");
    else
        $display("    databus16_8 = 0 (8 BITS UTMI INTERFACE)");

    if( device_termsel )
        $display("    host_termsel = 1 (2'b01-SPEED TERMINATION)");
    else
        $display("    host_termsel = 0 (2'b00-SPEED TERMINATION)");

    case( device_xcvrsel )
    2'b00:  $display("    host_xcvrsel = 00 (2'b00-SPEED TRANSCEIVER ENABLED)");
    2'b01:  $display("    host_xcvrsel = 01 (2'b01-SPEED TRANSCEIVER ENABLED)");
    2'b10:  $display("    host_xcvrsel = 10 (2'b10-SPEED TRANSCEIVER ENABLED)");
    2'b11:  $display("    host_xcvrsel = 11 (RESERVED MODE)");
    endcase

    case( device_opmode )
    2'b00:  $display("    host_opmode = 00 (NORMAL OPERATION)");
    2'b01:  $display("    host_opmode = 01 (NON-DRIVING)");
    2'b10:  $display("    host_opmode = 10 (DISABLE BIT-STUFFING AND NRZI ENCODING");
    2'b11:  $display("    host_opmode = 11 (RESERVED MODE)");
    endcase

    $display("    -------------------");
end
endtask


task host_apply_opmode;
input [1:0] new_opmode;
reg in_use;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    if(host_opmode !== new_opmode)
    begin
        @(posedge host_sieclock);
        #SIECLOCK_TO_DATA_DELAY;
        host_opmode <= new_opmode;
    end
    in_use = 0;
end
endtask


task device_apply_opmode;
input [1:0] new_opmode;
reg in_use;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    if(device_opmode !== new_opmode)
    begin
        @(posedge device_sieclock);
        #SIECLOCK_TO_DATA_DELAY;
        device_opmode <= new_opmode;
    end

    in_use = 0;
end
endtask


task host_apply_termsel;
input [1:0] new_termsel;
reg in_use;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    if(host_termsel !== new_termsel)
    begin
        @(posedge host_sieclock);
        #SIECLOCK_TO_DATA_DELAY;
        host_termsel <= new_termsel;
    end

    in_use = 0;
end
endtask


task device_apply_termsel;
input [1:0] new_termsel;
reg in_use;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    if(device_termsel !== new_termsel)
    begin
        @(posedge device_sieclock);
        #SIECLOCK_TO_DATA_DELAY;
        device_termsel <= new_termsel;
    end

    in_use = 0;
end
endtask


task host_apply_xcvrsel;
input [1:0] new_xcvrsel;
reg in_use;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    if(host_xcvrsel !== new_xcvrsel)
    begin
        @(posedge host_sieclock);
        #SIECLOCK_TO_DATA_DELAY;
        host_xcvrsel <= new_xcvrsel;
    end
    in_use = 0;
end
endtask


task device_apply_xcvrsel;
input [1:0] new_xcvrsel;
reg in_use;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    if(device_xcvrsel !== new_xcvrsel)
    begin
        @(posedge device_sieclock);
        #SIECLOCK_TO_DATA_DELAY;
        device_xcvrsel <= new_xcvrsel;
    end
    in_use = 0;
end
endtask


task host_apply_databus;
input new_databus;
reg in_use;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    if(host_databus16_8 !== new_databus)
    begin
        host_databus16_8 <= new_databus;
        host_apply_reset;
    end
      
    in_use = 0;
end
endtask


task device_apply_databus;
input new_databus;
reg in_use;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    if(device_databus16_8 !== new_databus)
    begin
        device_databus16_8 <= new_databus;
        device_apply_reset;
    end

    in_use = 0;
end
endtask


task host_16bits_send_data_from_file;
input            filename;
input            data_bytes;
reg     [1023:0] filename;
integer          data_bytes;
reg              in_use;
integer          n;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    $readmemh( {STIMULI_DIR,filename}, aData);
    host_16bits_send_data_common(data_bytes);

    in_use = 0;
end
endtask


task host_16bits_send_data_common;
input   data_bytes;
integer data_bytes;
reg     in_use;
integer n;
begin
    if (in_use === 1)  $stop;
    in_use = 1;

    bytes_transmitted = data_bytes;

    //-- WAIT -------------------------------------------------------------
    //--
    @(posedge host_sieclock);
    while(host_txready) @(posedge host_sieclock);

    //-- SEND DATA ---------------------------------------------------
    //--
    #(SIECLOCK_TO_DATA_DELAY);
    host_datain[7:0]  <= aData[1];
    host_txvalid      <= 1;
    if( data_bytes>1 )
    begin
        host_datain[15:8] <= aData[2];
        host_txvalidh     <= 1;
    end
    else
    begin
        host_datain[15:8] <= 8'dx;
        host_txvalidh     <= 0;
    end
    @(posedge host_sieclock);
    while(!host_txready) @(posedge host_sieclock);

    for(n=3;n<=data_bytes;n=n+2)
    begin
        #(SIECLOCK_TO_DATA_DELAY);
        host_datain[7:0]  <= aData[n];
        if( n+1<=data_bytes )
        begin
            host_datain[15:8] <= aData[n+1];
        end
        else
        begin
            host_datain[15:8] <= 8'dx;
            host_txvalidh     <= 0;
        end
        @(posedge host_sieclock);
        while(!host_txready) @(posedge host_sieclock);
    end

    //-- IDLE -------------------------------------------------------------
    //--
    #(SIECLOCK_TO_DATA_DELAY);
    host_txvalid  <= 0;
    host_txvalidh <= 0;
    host_datain   <= 16'dx;
    @(posedge host_sieclock);
    while(host_txready) @(posedge host_sieclock);

    in_use = 0;
end
endtask


task device_receive;
reg         in_use;
reg         error;
integer     n;
begin
    if (in_use === 1) $stop;
    in_use = 1;
    
    error = 0;

    @(posedge device_sieclock);
    while(!device_rxactive) @(posedge device_sieclock);
    begin
        n=0;
        while(device_rxactive)
        begin
            if(device_rxerror)
            begin
                $display("* * * *   WARNING * * * *");
                $display("Device receive error signal was generated in DEVICE! at ",$realtime);
                warnings = warnings + 1;
            end
            else
                if(device_rxvalid)
                begin
                    n = n+1;
                    bData[n] = device_dataout[7:0];
                    if(device_rxvalidh)
                    begin
                        n = n+1;
                        bData[n] = device_dataout[15:8];
                    end
                end
            @(posedge device_sieclock);
        end
        bytes_received = n;
    end

    in_use = 0;
end
endtask


task host_receive;
reg         in_use;
reg         error;
integer     n;
begin
    if (in_use === 1) $stop;
    in_use = 1;
    
    error = 0;

    @(posedge host_sieclock);
    while(!host_rxactive) @(posedge host_sieclock);
    begin
        n=0;
        while(host_rxactive)
        begin
            if(host_rxerror)
            begin
                $display("* * * *   WARNING * * * *");
                $display("Device receive error signal was generated in HOST! at ",$realtime);
                warnings = warnings + 1;
            end
            else
                if(host_rxvalid)
                begin
                    n = n+1;
                    cData[n] = host_dataout[7:0];

                    if(host_rxvalidh)
                    begin
                        n = n+1;
                        cData[n] = host_dataout[15:8];
                    end
                end
            @(posedge host_sieclock);
        end
        host_bytes_received = n;
    end

    in_use = 0;
end
endtask


task host_8bits_send_data_from_file;
input            filename;
input            data_bytes;
reg     [1023:0] filename;
integer          data_bytes;
reg              in_use;
integer          n;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    $readmemh( {STIMULI_DIR,filename}, aData);
    host_8bits_send_data_common(data_bytes);

    in_use = 0;
end
endtask


task host_8bits_send_data_common;
input   data_bytes;
integer data_bytes;
reg     in_use;
integer n;
begin
    if (in_use === 1) $stop;
    in_use = 1;

    bytes_transmitted = data_bytes;

    //-- WAIT -------------------------------------------------------------
    //--
    @(posedge host_sieclock);
    while(host_txready) @(posedge host_sieclock);

    //-- SEND DATA ---------------------------------------------------
    //--
    #(SIECLOCK_TO_DATA_DELAY);
    host_datain[7:0]  <= aData[1];
    host_txvalid      <= 1;
    //if( VERBOSE_MODE ) $display("  HOST: Data(%d)= %h",1,aData[1]);
    @(posedge host_sieclock);
    while(!host_txready) @(posedge host_sieclock);

    for(n=2;n!=data_bytes+1;n=n+1)
    begin
        #(SIECLOCK_TO_DATA_DELAY);
        host_datain[7:0] <= aData[n];
        //if( VERBOSE_MODE ) $display("  HOST: Data(%d)= %h",n,aData[n]);
        @(posedge host_sieclock);
        while(!host_txready) @(posedge host_sieclock);
    end

    //-- IDLE -------------------------------------------------------------
    //--
    #(SIECLOCK_TO_DATA_DELAY);
    host_txvalid  <= 0;
    host_datain   <= 16'dx;
    @(posedge host_sieclock);
    while(host_txready) @(posedge host_sieclock);

    in_use = 0;
end
endtask


task verify_transmission;
input        test;
input        option;
reg  [100:0] test;
reg  [100:0] option;
integer      n;
reg          error;
begin
    error = 0;
    
    #(1000)
         
    if(test === "HOST")
    begin
        if( host_bytes_received !== bytes_transmitted )
        begin
            $display("* * * *   E R R O R in HOST   * * * *");
            $display("(HOST)Transmission test failed (nr of bytes)! at ",$realtime);
            $display("(HOST)bytes_received = %d ",host_bytes_received);
            $display("(HOST)bytes_transmitted = %d",bytes_transmitted);
            error = 1;
        end

        for(n=1;n!=host_bytes_received+1;n=n+1)
            if( aData[n]!==cData[n] )
            begin
                $display("* * * *   E R R O R in HOST   * * * *");
                $display("(HOST)Transmission test failed! at ",$realtime);
                error = 1;
            end

        if(!error)
            $display(".............. Passed in HOST");
        else
        begin
            $display(".............. Failed in HOST");
            errors = errors + 1;
        end

        repeat(20) @(posedge host_sieclock);

        host_bytes_received = 0;
        bytes_transmitted = 1;
    end

    if(test === "DEVICE")
    begin
        if( bytes_received !== bytes_transmitted )
        begin
            $display("* * * *   E R R O R in DEVICE   * * * *");
            $display("(DEVICE)Transmission test failed (nr of bytes)! at ",$realtime);
            $display("(DEVICE)bytes_received = %d ",bytes_received);
            $display("(DEVICE)bytes_transmitted = %d",bytes_transmitted);
            error = 1;
        end

        for(n=1;n!=bytes_received+1;n=n+1)
            if( aData[n]!==bData[n] )
            begin
                $display("* * * *   E R R O R in DEVICE * * * *");
                $display("(DEVICE)Transmission test failed! at ",$realtime);
                error = 1;
            end

        if(!error)
            $display(".............. Passed in DEVICE");
        else
        begin
            $display(".............. Failed in DEVICE");
            errors = errors + 1;
        end

        repeat(20) @(posedge host_sieclock);

        bytes_received = 0;
        bytes_transmitted = 1;
    end

    if(test === "SOF")
    begin
        if(option === "WITH")
        begin
            repeat(3) @(posedge host_sysclock);
            if(host_disconnect !== 1'b1)
            begin
                $display("........!ERROR - Host_Disconnect Signal not Asserted at ",$realtime);
                error = 1;
            end
        end

        else if (option === "WITHOUT")
        begin
            repeat(3) @(posedge host_sysclock);
            if(host_disconnect !== 1'b0)
            begin
                $display("........!ERROR - Host_Disconnect Signal Asserted at ",$realtime);
                error = 1;
            end
        end

        #(1);

        if(!error)
            $display(".............. Passed");
        else
        begin
            $display(".............. Failed");
            errors = errors + 1;
        end
    end

end
endtask


task apply_testmode;
input         testmode;
reg   [300:0] testmode;
begin
    @(negedge host_sysclock);

    if(testmode === "LOOPBACK")
        host_vcontrol <= 4'b0001;
    host_vload   <= 1'b0;

    if(TESTER_TESTMODE_CHARGING === "SUSPEND_NEEDED")
        host_suspend <= 1'b0;

    @(negedge host_sysclock);

    host_vload   <= 1'b1;
    host_suspend <= 1'b1;

    if(testmode === "LOOPBACK")
        repeat(10) @(posedge host_sieclock);

    #(1000);
end
endtask


task test_bist_modes;
reg in_use;
reg error;
reg error_int;
begin
    if (in_use === 1) $stop;
    in_use      = 1;
    error       = 0;
    error_int   = 0;

    $display("\n====== Loopback BIST Tests  ===================================");

    ////////////////////LOOPBACK BIST 2'b01 SPEED//////////////////////////////
    $display("..............Full Speed");
    production_test = "LOOPBACK BIST / FS";

    // Apply and release host_suspend
    @( negedge host_sysclock )
    host_suspend    = 0;
    repeat(2) @(negedge host_sysclock);
    host_suspend    = 1;

    // Wait for bandgap and pll lock
`ifdef SYSCLOCK_12MHZ
    repeat (2500)   @( negedge host_sysclock );
`elsif SYSCLOCK_24MHZ
    repeat (5000)   @( negedge host_sysclock );
`elsif SYSCLOCK_96MHZ
    repeat (20000)  @( negedge host_sysclock );
`else
    repeat (20100)  @( negedge host_sysclock );
`endif

    //
    // Full Speed - 8 Bits
    //
    @(negedge host_sieclock);
    host_xcvrsel    = 2'b01;
    host_termsel    = 1'b1;

    host_vcontrol[3:0]  <= 4'b0010;

    host_apply_databus(0);

    host_onbist = 1;
    repeat (3)      @( negedge host_sysclock );
    host_onbist = 0;

`ifdef SYSCLOCK_12MHZ
    repeat (800)    @( negedge host_sysclock );
`elsif SYSCLOCK_24MHZ
    repeat (1600)   @( negedge host_sysclock );
`elsif SYSCLOCK_96MHZ
    repeat (6400)   @( negedge host_sysclock );
`else
    repeat (6700)   @( negedge host_sysclock );
`endif

    if ( host_vstatus[7:0] !== 8'h10 )
        error   = 1'b1;

    if(error === 1'b1) error_int = 1'b1;
    if(error)
    begin
        $display("........................Failed");
        errors = errors + 1'd1;
    end
    else
        $display("........................Passed");
    error   = 1'b0;

    ////////////////////LOOPBACK BIST 2'b00 SPEED//////////////////////////////
    $display("..............High Speed");
    production_test = "LOOPBACK BIST / HS";

    //
    // High Speed - 8 Bits
    //
    @(negedge host_sieclock);
    host_xcvrsel    = 2'b00;
    host_termsel    = 1'b0;

    host_vcontrol[3:0]  <= 4'b0001;

    host_apply_reset;

    host_onbist = 1;
    repeat (3)      @( negedge host_sysclock );
    host_onbist = 0;

`ifdef SYSCLOCK_12MHZ
    repeat (200)    @( negedge host_sysclock );
`elsif SYSCLOCK_24MHZ
    repeat (400)    @( negedge host_sysclock );
`elsif SYSCLOCK_96MHZ
    repeat (800)    @( negedge host_sysclock );
`else
    repeat (1000)   @( negedge host_sysclock );
`endif

    if ( host_vstatus[7:0] !== 8'h10 )
        error   = 1'b1;

    if(error === 1'b1) error_int = 1'b1;
    if(error)
    begin
        $display("........................Failed");
        errors = errors + 1'd1;
    end
    else
        $display("........................Passed");
    error   = 1'b0;

    host_vcontrol[3:0]  <= 4'b0000;

    host_apply_reset;


    if(error_int || error)
        $display("......Loopback BIST Failed");
    else
        $display("......Loopback BIST Passed");

    error     = 0;
    error_int = 0;
    in_use    = 0;
end
endtask


task test_fs_output;
reg in_use;
reg error;
begin
    if (in_use === 1) $stop;
    in_use      = 1;
    error       = 0;

    $display("\n====== Full Speed Output Tests  ===============================");

    ////////////////////2'b01 SPEED OUTPUT//////////////////////////////
    production_test = "FS OUTPUT";

    @(negedge host_sieclock);
    host_xcvrsel        = 2'b01;
    host_termsel        = 1'b1;
    host_opmode         = 2'b10;
    host_datain[7:0]    = 8'hFF;
    host_txvalid        = 1;

    repeat (20)     @( negedge host_sysclock );

    if ( ( common_dp !== 1 ) || ( common_dn !== 0 ) )
    begin
        $display("....................Error! DP/DN differs from J at ",$realtime);
        error   = 1;
        errors = errors + 1'd1;
    end

    @(negedge host_sieclock);
    host_datain[7:0]    = 8'h00;

    repeat (20)     @( negedge host_sysclock );

    if ( ( common_dp !== 0 ) || ( common_dn !== 1 ) )
    begin
        $display("....................Error! DP/DN differs from K at ",$realtime);
        error   = 1;
        errors = errors + 1'd1;
    end

    host_txvalid        = 0;


    if( error )
        $display("......Full Speed Output Failed");
    else
        $display("......Full Speed Output Passed");

    error     = 0;
    in_use    = 0;
end
endtask


task test_hs_output;
reg in_use;
reg error;
begin
    if (in_use === 1) $stop;
    in_use      = 1;
    error       = 0;

    $display("\n====== High Speed Output Tests  ===============================");

    ////////////////////2'b00 SPEED OUTPUT//////////////////////////////
    production_test = "HS OUTPUT";

    @(negedge host_sieclock);
    host_xcvrsel        = 2'b00;
    host_termsel        = 1'b0;

    repeat (100)    @( negedge host_sysclock );

    if ( ( common_dp !== 0 ) || ( common_dn !== 0 ) )
    begin
        $display("....................Error! DP/DN differs from SE0 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    host_opmode         = 2'b10;
    host_datain[7:0]    = 8'hFF;
    host_txvalid        = 1;

    repeat (20)     @( negedge host_sysclock );

    if ( ( common_dp !== 1 ) || ( common_dn !== 0 ) )
    begin
        $display("....................Error! DP/DN differs from J at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    @(negedge host_sieclock);
    host_datain[7:0]    = 8'h00;

    repeat (20)     @( negedge host_sysclock );

    if ( ( common_dp !== 0 ) || ( common_dn !== 1 ) )
    begin
        $display("....................Error! DP/DN differs from K at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    host_txvalid     = 0;


    if( error )
        $display("......High Speed Output Failed");
    else
        $display("......High Speed Output Passed");

    error     = 0;
    in_use    = 0;
end
endtask


task test_linestate;
reg in_use;
reg error;
reg error_int;
begin
    if (in_use === 1) $stop;
    in_use      = 1;
    error       = 0;
    error_int   = 0;

    $display("\n====== Linestate Tests  =======================================");

    ////////////////////LINESTATE 2'b00 SPEED//////////////////////////////
    production_test = "LINESTATE HS";
    $display("..............High Speed");

    host_apply_databus(0);

    @(negedge host_sieclock);
    host_xcvrsel    = 2'b00;
    host_termsel    = 1'b0;
    host_opmode     = 2'b00;

    repeat (20)     @( negedge host_sysclock );

    //SE0
    force   common_dp   = 0;
    force   common_dn   = 0;
    repeat (20)     @( negedge host_sysclock );
    if ( host_linestate[1:0] !== 2'b00 )  error_int = 1;

    //J
    force   common_dp   = 1;
    force   common_dn   = 0;
    repeat (20)     @( negedge host_sysclock );
    if ( host_linestate[1:0] !== 2'b01 )  error_int = 1;

    //K
    force   common_dp   = 0;
    force   common_dn   = 1;
    repeat (20)     @( negedge host_sysclock );
    if ( host_linestate[1:0] !== 2'b01 )  error_int = 1;

    release common_dp;
    release common_dn;

    if ( error_int )
    begin
        error   = 1;
        errors  = errors + 1'd1;
        $display("....................Error! One or more Linestate values not correct at ",$realtime);
        $display("........................Failed");
    end
    else
        $display("........................Passed");

    ////////////////////LINESTATE 2'b01 SPEED//////////////////////////////
    production_test = "LINESTATE FS";
    $display("..............Full Speed");

    @(negedge host_sieclock);
    host_xcvrsel    = 2'b01;
    host_termsel    = 1'b1;
    error_int   = 0;

    repeat (100)    @( negedge host_sysclock );

    //SE0
    force   common_dp   = 0;
    force   common_dn   = 0;
    repeat (20)     @( negedge host_sysclock );
    if ( host_linestate[1:0] !== 2'b00 )  error_int = 1;

    //J
    force   common_dp   = 1;
    force   common_dn   = 0;
    repeat (20)     @( negedge host_sysclock );
    if ( host_linestate[1:0] !== 2'b01 )  error_int = 1;

    //K
    force   common_dp   = 0;
    force   common_dn   = 1;
    repeat (20)     @( negedge host_sysclock );
    if ( host_linestate[1:0] !== 2'b10 )  error_int = 1;

    release common_dp;
    release common_dn;

    if ( error_int )
    begin
        error   = 1;
        errors = errors + 1'd1;
        $display("....................Error! One or more Linestate values not correct at ",$realtime);
        $display("........................Failed");
    end
    else
        $display("........................Passed");


    if( error )
        $display("......Linestate Failed");
    else
        $display("......Linestate Passed");

    error       = 0;
    in_use      = 0;
end
endtask


task test_ls_fs_idle;
reg in_use;
reg error;
begin
    if (in_use === 1) $stop;
    in_use      = 1;
    error       = 0;

    $display("\n====== Low / Full Speed Idle Tests  ===========================");

    ////////////////////2'b01 SPEED IDLE//////////////////////////////
    production_test = "FS IDLE";
    $display("..............Full Speed");

    @(negedge host_sieclock);
    host_xcvrsel    = 2'b01;
    host_termsel    = 1'b1;
    host_opmode     = 2'b00;
    host_dppulldown = 1'b0;
    host_dnpulldown = 1'b0;
    host_txvalid    = 1'b0;

    repeat (20)     @( negedge host_sysclock );

    if ( common_dp !== 1 )
    begin
        $display("....................Error! DP differs from 1'b1 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( error )
        $display("........................Failed");
    else
        $display("........................Passed");

    ////////////////////2'b10 SPEED IDLE//////////////////////////////
    production_test   = "LS IDLE";
    $display("..............Low Speed");

    @(negedge host_sieclock);
    host_xcvrsel    = 2'b10;

    repeat (20)     @( negedge host_sysclock );

    if ( common_dn !== 1 )
    begin
        $display("....................Error! DN differs from 1'b1 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( error )
        $display("........................Failed");
    else
        $display("........................Passed");


    if( error )
        $display("......Low / Full Speed Idle Failed");
    else
        $display("......Low / Full Speed Idle Passed");

    host_dppulldown = 1'b1;
    host_dnpulldown = 1'b1;
    error       = 0;
    in_use      = 0;
end
endtask


task test_otg;
reg in_use;
reg error;
begin
    if (in_use === 1) $stop;
    in_use      = 1;
    error       = 0;

    $display("\n====== OTG Tests  =============================================");

    ////////////////////OTG//////////////////////////////
    production_test = "OTG";

`ifdef SYSCLOCK_12MHZ
    repeat (12)     @( negedge host_sysclock );
`elsif SYSCLOCK_24MHZ
    repeat (24)     @( negedge host_sysclock );
`elsif SYSCLOCK_96MHZ
    repeat (96)     @( negedge host_sysclock );
`else
    repeat (100)    @( negedge host_sysclock );
`endif

    host_idpullup       = 1'b1;
    host_chargevbus     = 1'b0;
    host_dischargevbus  = 1'b1;

`ifdef SYSCLOCK_12MHZ
    repeat (12)     @( negedge host_sysclock );
`elsif SYSCLOCK_24MHZ
    repeat (24)     @( negedge host_sysclock );
`elsif SYSCLOCK_96MHZ
    repeat (96)     @( negedge host_sysclock );
`else
    repeat (100)    @( negedge host_sysclock );
`endif

    if ( host_vbus !== 0 )
    begin
        $display("....................Error! VBUS differs from 1'b0 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_id_int !== 1 )
    begin
        $display("....................Error! ID differs from 1'b1 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_iddig !== 1 )
    begin
        $display("....................Error! IDdig differs from 1'b1 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_vbusvalid !== 0 )
    begin
        $display("....................Error! VBUSvalid differs from 1'b0 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_avalid !== 0 )
    begin
        $display("....................Error! Avalid differs from 1'b0 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_bvalid !== 0 )
    begin
        $display("....................Error! Bvalid differs from 1'b0 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_endsession !== 1 )
    begin
        $display("....................Error! EndSession differs from 1'b1 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

`ifdef SYSCLOCK_12MHZ
    repeat (12)     @( negedge host_sysclock );
`elsif SYSCLOCK_24MHZ
    repeat (24)     @( negedge host_sysclock );
`elsif SYSCLOCK_96MHZ
    repeat (96)     @( negedge host_sysclock );
`else
    repeat (100)    @( negedge host_sysclock );
`endif

    host_chargevbus     = 1'b1;
    host_dischargevbus  = 1'b0;

`ifdef SYSCLOCK_12MHZ
    repeat (12)     @( negedge host_sysclock );
`elsif SYSCLOCK_24MHZ
    repeat (24)     @( negedge host_sysclock );
`elsif SYSCLOCK_96MHZ
    repeat (96)     @( negedge host_sysclock );
`else
    repeat (100)    @( negedge host_sysclock );
`endif

    if ( host_vbus !== 1 )
    begin
        $display("....................Error! VBUS differs from 1'b1 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_vbusvalid !== 0 )
    begin
        $display("....................Warning! VBUSvalid differs from 1'b0 at ",$realtime);
        $display("............................ (this is not an error, because VBUS is modeled as a digital signal in the Verilog Behavioral Model;");
        $display("............................  so, as VBUS > 0, in the model it is interpreted as 1'b1, and so VBUSvalid rises - but in silicon it shouldn't!)");
        warnings = warnings + 1'd1;
    end

    if ( host_avalid !== 1 )
    begin
        $display("....................Error! Avalid differs from 1'b1 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_bvalid !== 1 )
    begin
        $display("....................Error! Bvalid differs from 1'b1 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_endsession !== 0 )
    begin
        $display("....................Error! EndSession differs from 1'b0 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

`ifdef SYSCLOCK_12MHZ
    repeat (12)     @( negedge host_sysclock );
`elsif SYSCLOCK_24MHZ
    repeat (24)     @( negedge host_sysclock );
`elsif SYSCLOCK_96MHZ
    repeat (96)     @( negedge host_sysclock );
`else
    repeat (100)    @( negedge host_sysclock );
`endif

    host_chargevbus     = 1'b0;
    host_dischargevbus  = 1'b0;
    force   host_vbus   = 1'b1;
    host_id             = 1'b0;

`ifdef SYSCLOCK_12MHZ
    repeat (12)     @( negedge host_sysclock );
`elsif SYSCLOCK_24MHZ
    repeat (24)     @( negedge host_sysclock );
`elsif SYSCLOCK_96MHZ
    repeat (96)     @( negedge host_sysclock );
`else
    repeat (100)    @( negedge host_sysclock );
`endif

    if ( host_iddig !== 0 )
    begin
        $display("....................Error! IDdig differs from 1'b0 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_vbusvalid !== 1 )
    begin
        $display("....................Error! VBUSvalid differs from 1'b1 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_avalid !== 1 )
    begin
        $display("....................Error! Avalid differs from 1'b1 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_bvalid !== 1 )
    begin
        $display("....................Error! Bvalid differs from 1'b1 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

    if ( host_endsession !== 0 )
    begin
        $display("....................Error! EndSession differs from 1'b0 at ",$realtime);
        error   = 1;
        errors  = errors + 1'd1;
    end

`ifdef SYSCLOCK_12MHZ
    repeat (12)     @( negedge host_sysclock );
`elsif SYSCLOCK_24MHZ
    repeat (24)     @( negedge host_sysclock );
`elsif SYSCLOCK_96MHZ
    repeat (96)     @( negedge host_sysclock );
`else
    repeat (100)    @( negedge host_sysclock );
`endif

    release host_vbus;


    if( error )
        $display("......OTG Failed");
    else
        $display("......OTG Passed");

    error     = 0;
    in_use    = 0;
end
endtask


task print_errors;
begin
    repeat(50) @(posedge host_sysclock);

    $display("");
    $display("");
    if (errors > 0)
    begin
        if(warnings > 0)
            $display("\n!!!!!!!!!! Testbench Finished with %g Errors and %g Warnings !!!!!!!!!!",errors,warnings);
        else
            $display("\n!!!!!!!!!! Testbench Finished with %g Errors !!!!!!!!!!",errors);
    end
    else if(warnings > 0)
        $display("\n/!\\ /!\\ /!\\ /!\\ Testbench Finished with %g Warnings /!\\ /!\\ /!\\ /!\\",warnings);
    else
        $display("\n<<<<<<<<<< Testbench Finished Without Errors or Warnings >>>>>>>>>>");

    $display("");
end
endtask


`endprotect

endmodule
