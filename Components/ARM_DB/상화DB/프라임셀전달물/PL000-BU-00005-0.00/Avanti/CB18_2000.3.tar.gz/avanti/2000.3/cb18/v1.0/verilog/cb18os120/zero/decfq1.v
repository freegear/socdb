// ****** (C) Copyright 1998 Avant! Inc. ********
//  --    AVANT! Verilog Models
// **********************************************


`celldefine
`suppress_faults
`enable_portfaults

`ifdef functional
 `timescale 1ns / 1ns
 `delay_mode_distributed
 `delay_mode_unit
`else
 `timescale 1ns / 10ps
 `delay_mode_path
`endif 


// Model type   	: zero timing
// Filename     	: decfq1.v
// Description  	:  Buffered Enabled D Flip-Flop with Clear and Q only, 1X Drive
// Library      	: cb18os120
// Programmer   	: bgazel
// Date                 : 06-Aug-1999
// Product version	: Rev. main.1 
// Master version	: Rev. main.3
//
//


module decfq1 (CPN,CDN,D,ENN,Q);

output  Q;
input   CPN,CDN,D,ENN;

buf (CPN_buf,CPN);
buf (CDN_buf,CDN);
buf (D_buf,D);
buf (ENN_buf,ENN);

wire BOOL_OUT = (((!ENN_buf && D_buf)) && ((!ENN_buf))) || !(!Q || ((!ENN_buf)));

`ifdef functional
U_FD_N_RB_NO #1 (Q,BOOL_OUT,CPN,CDN,1'b1);
`else
reg notifier;
U_FD_N_RB_NO #0.01 (Q,BOOL_OUT,CPN,CDN,notifier);
`endif

`ifdef functional
`else
wire vcond1 = ((CDN_buf==1'b1) && (ENN_buf==1'b0));
specify
// Parameter declarations
 specparam tsu_enn_h_cpn=0.25,tsu_enn_l_cpn=0.46,tsu_d_h_cpn=0.24,tsu_d_l_cpn=0.39,
 tsu_cdn_h_cpn=0.00,th_cpn_enn_h=0.00,th_cpn_enn_l=0.00,th_cpn_d_h=0.00,th_cpn_d_l=0.00,
 th_cpn_cdn_l=0.37,tpw_cpn_l=0.32,tpw_cpn_h=0.34,tpw_cdn_l=0.20,cpn_hl_q_lh=0,
 cpn_hl_q_hl=0,cdn_hl_q_hl_1=0;
// Violation constraints
 $setup (posedge ENN &&& (CDN==1'b1),negedge CPN &&& (CDN==1'b1),tsu_enn_h_cpn,notifier);
 $setup (negedge ENN &&& (CDN==1'b1),negedge CPN &&& (CDN==1'b1),tsu_enn_l_cpn,notifier);
 $setup (posedge D &&& (vcond1==1'b1),negedge CPN &&& (vcond1==1'b1),tsu_d_h_cpn,notifier);
 $setup (negedge D &&& (vcond1==1'b1),negedge CPN &&& (vcond1==1'b1),tsu_d_l_cpn,notifier);
 $recovery (posedge CDN &&& (ENN==1'b0),negedge CPN &&& (ENN==1'b0),tsu_cdn_h_cpn,notifier);
 $hold  (negedge CPN &&& (CDN==1'b1),negedge ENN &&& (CDN==1'b1),th_cpn_enn_h,notifier);
 $hold  (negedge CPN &&& (CDN==1'b1),posedge ENN &&& (CDN==1'b1),th_cpn_enn_l,notifier);
 $hold  (negedge CPN &&& (vcond1==1'b1),negedge D &&& (vcond1==1'b1),th_cpn_d_h,notifier);
 $hold  (negedge CPN &&& (vcond1==1'b1),posedge D &&& (vcond1==1'b1),th_cpn_d_l,notifier);
 $hold  (negedge CPN &&& (ENN==1'b0),posedge CDN &&& (ENN==1'b0),th_cpn_cdn_l,notifier);
 $width (negedge CPN &&& (vcond1==1'b1),tpw_cpn_l,0,notifier);
 $width (posedge CPN &&& (vcond1==1'b1),tpw_cpn_h,0,notifier);
 $width (negedge CDN,tpw_cdn_l,0,notifier);
// Delays
 if ((CDN==1'b1) && (ENN==1'b0))
 (negedge CPN  => (Q +: BOOL_OUT)) = (cpn_hl_q_lh,cpn_hl_q_hl);
 (negedge CDN  => (Q -: 1'b1)) = (0,cdn_hl_q_hl_1);
endspecify
`endif

endmodule
`endcelldefine
`disable_portfaults
`nosuppress_faults
