// ****** (C) Copyright 1998 Avant! Inc. ********
//  --    AVANT! Verilog Models
// **********************************************


`celldefine
`suppress_faults
`enable_portfaults

`ifdef functional
 `timescale 1ns / 1ns
 `delay_mode_distributed
 `delay_mode_unit
`else
 `timescale 1ns / 10ps
 `delay_mode_path
`endif 


// Model type   	: zero timing
// Filename     	: decrq2.v
// Description  	:  Buffered Enabled D Flip-Flop with Clear and Q only, 2X Drive
// Library      	: cb18os120
// Programmer   	: bgazel
// Date                 : 06-Aug-1999
// Product version	: Rev. main.1 
// Master version	: Rev. main.3
//
//


module decrq2 (CP,CDN,D,ENN,Q);

output  Q;
input   CP,CDN,D,ENN;

buf (CP_buf,CP);
buf (CDN_buf,CDN);
buf (D_buf,D);
buf (ENN_buf,ENN);

wire BOOL_OUT = (((!ENN_buf && D_buf)) && ((!ENN_buf))) || !(!Q || ((!ENN_buf)));

`ifdef functional
U_FD_P_RB_NO #1 (Q,BOOL_OUT,CP,CDN,1'b1);
`else
reg notifier;
U_FD_P_RB_NO #0.01 (Q,BOOL_OUT,CP,CDN,notifier);
`endif

`ifdef functional
`else
wire vcond1 = ((CDN_buf==1'b1) && (ENN_buf==1'b0));
specify
// Parameter declarations
 specparam tsu_enn_h_cp=0.39,tsu_enn_l_cp=0.47,tsu_d_h_cp=0.30,tsu_d_l_cp=0.34,
 tsu_cdn_h_cp=0.00,th_cp_enn_h=0.00,th_cp_enn_l=0.00,th_cp_d_h=0.00,th_cp_d_l=0.00,
 th_cp_cdn_l=0.30,tpw_cp_h=0.24,tpw_cp_l=0.42,tpw_cdn_l=0.22,cp_lh_q_lh=0,
 cp_lh_q_hl=0,cdn_hl_q_hl_1=0;
// Violation constraints
 $setup (posedge ENN &&& (CDN==1'b1),posedge CP &&& (CDN==1'b1),tsu_enn_h_cp,notifier);
 $setup (negedge ENN &&& (CDN==1'b1),posedge CP &&& (CDN==1'b1),tsu_enn_l_cp,notifier);
 $setup (posedge D &&& (vcond1==1'b1),posedge CP &&& (vcond1==1'b1),tsu_d_h_cp,notifier);
 $setup (negedge D &&& (vcond1==1'b1),posedge CP &&& (vcond1==1'b1),tsu_d_l_cp,notifier);
 $recovery (posedge CDN &&& (ENN==1'b0),posedge CP &&& (ENN==1'b0),tsu_cdn_h_cp,notifier);
 $hold  (posedge CP &&& (CDN==1'b1),negedge ENN &&& (CDN==1'b1),th_cp_enn_h,notifier);
 $hold  (posedge CP &&& (CDN==1'b1),posedge ENN &&& (CDN==1'b1),th_cp_enn_l,notifier);
 $hold  (posedge CP &&& (vcond1==1'b1),negedge D &&& (vcond1==1'b1),th_cp_d_h,notifier);
 $hold  (posedge CP &&& (vcond1==1'b1),posedge D &&& (vcond1==1'b1),th_cp_d_l,notifier);
 $hold  (posedge CP &&& (ENN==1'b0),posedge CDN &&& (ENN==1'b0),th_cp_cdn_l,notifier);
 $width (posedge CP &&& (vcond1==1'b1),tpw_cp_h,0,notifier);
 $width (negedge CP &&& (vcond1==1'b1),tpw_cp_l,0,notifier);
 $width (negedge CDN,tpw_cdn_l,0,notifier);
// Delays
 if ((CDN==1'b1) && (ENN==1'b0))
 (posedge CP   => (Q +: BOOL_OUT)) = (cp_lh_q_lh,cp_lh_q_hl);
 (negedge CDN  => (Q -: 1'b1)) = (0,cdn_hl_q_hl_1);
endspecify
`endif

endmodule
`endcelldefine
`disable_portfaults
`nosuppress_faults
