// ****** (C) Copyright 1998 Avant! Inc. ********
//  --    AVANT! Verilog Models
// **********************************************


`celldefine
`suppress_faults
`enable_portfaults

`ifdef functional
 `timescale 1ns / 1ns
 `delay_mode_distributed
 `delay_mode_unit
`else
 `timescale 1ns / 10ps
 `delay_mode_path
`endif 


// Model type   	: zero timing
// Filename     	: lanhn2.v
// Description  	:  Buffered Latch with QN only, 2X Drive
// Library      	: cb18os120
// Programmer   	: xavier
// Date                 : 20-Jul-2000
// Product version	: Rev. main.3 
// Master version	: Rev. main.4
//
//


module lanhn2 (E,D,QN);

output  QN;
input   E,D;

`ifdef functional
buf b_E (E_buf,E);
buf b_D (D_buf,D);
s_lanhn2 #0.01 (QN,E_buf,D_buf,1'b0);
`else
reg notifier;
buf b_E (E_buf,E);
buf b_D (D_buf,D);
s_lanhn2 #0.01 (QN,E_buf,D_buf,notifier);
`endif


`ifdef functional
`else
specify
// Parameter declarations
 specparam tsu_d_h_e=0.31,tsu_d_l_e=0.21,th_e_d_h=0.00,th_e_d_l=0.00,
 tpw_e_h=0.24,d_lh_qn_hl=0,d_hl_qn_lh=0,e_lh_qn_hl=0,e_lh_qn_lh=0;
// Violation constraints
 $setup (posedge D,negedge E,tsu_d_h_e,notifier);
 $setup (negedge D,negedge E,tsu_d_l_e,notifier);
 $hold  (negedge E,negedge D,th_e_d_h,notifier);
 $hold  (negedge E,posedge D,th_e_d_l,notifier);
 $width (posedge E,tpw_e_h,0,notifier);
// Delays
 if (E==1'b1)
 (        D -=> QN) = (d_hl_qn_lh,d_lh_qn_hl);
 (posedge E  => (QN -: D )) = (e_lh_qn_lh,e_lh_qn_hl);
endspecify
`endif

endmodule
`endcelldefine
`disable_portfaults
`nosuppress_faults
`timescale 1ns / 10ps

primitive s_lanhn2(QN,E,D,notifier);

output QN;
reg    QN;
input  E,D,notifier;

table
// E	D	notifier : - : QN;
   1	(?0)	   ?     : ? :  1;
   1	(?1)	   ?     : ? :  0;
   0     *         ?	 : ? :  -;
   r	 0	   ? 	 : ? :  1;
   r     1	   ? 	 : ? :  0;    
   (0x)  0         ?  	 : 1 :  x;
   (0x)  1	   ?	 : 0 :  x;     
   (x1)  0	   ?     : ? :  1;
   (x1)  1         ?     : ? :  0;      
   (1x)  ?	   ? 	 : ? :  x;
    f    0         ?     : ? :  -;
    f    1         ?     : ? :  -;
    ?    ?         *     : ? :  x;  
endtable
endprimitive


