// ****** (C) Copyright 1998 Avant! Inc. ********
//  --    AVANT! Verilog Models
// **********************************************


`celldefine
`suppress_faults
`enable_portfaults

`ifdef functional
 `timescale 1ns / 1ns
 `delay_mode_distributed
 `delay_mode_unit
`else
 `timescale 1ns / 10ps
 `delay_mode_path
`endif 


// Model type   	: zero timing
// Filename     	: ora31d4.v
// Description  	:  3/1 OR-AND, 4X Drive
// Library      	: cb18os120
// Programmer   	: bgazel
// Date                 : 06-Aug-1999
// Product version	: Rev. main.1 
// Master version	: Rev. main.2
//
//


module ora31d4 (B3,B2,B1,A,Z);

output  Z;
input   B3,B2,B1,A;

or (g_2_out,B2,B1,B3);
and #0.01 (Z,A,g_2_out);

`ifdef functional
`else
specify
// Parameter declarations
 specparam b1_hl_z_hl=0,b1_lh_z_lh=0,b2_lh_z_lh=0,b2_hl_z_hl=0,
 b3_lh_z_lh=0,a_hl_z_hl_4=0,a_lh_z_lh_4=0,b3_hl_z_hl=0;
// Delays
 (        B1 +=> Z) = (b1_lh_z_lh,b1_hl_z_hl);
 (        B2 +=> Z) = (b2_lh_z_lh,b2_hl_z_hl);
 (        B3 +=> Z) = (b3_lh_z_lh,b3_hl_z_hl);
 (        A  +=> Z) = (a_lh_z_lh_4,a_hl_z_hl_4);
endspecify
`endif

endmodule
`endcelldefine
`disable_portfaults
`nosuppress_faults
