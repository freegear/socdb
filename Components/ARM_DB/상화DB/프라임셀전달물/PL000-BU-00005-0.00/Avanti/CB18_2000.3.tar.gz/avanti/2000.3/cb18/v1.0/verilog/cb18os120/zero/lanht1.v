// ****** (C) Copyright 1998 Avant! Inc. ********
//  --    AVANT! Verilog Models
// **********************************************


`celldefine
`suppress_faults
`enable_portfaults

`ifdef functional
 `timescale 1ns / 1ns
 `delay_mode_distributed
 `delay_mode_unit
`else
 `timescale 1ns / 10ps
 `delay_mode_path
`endif 


// Model type   	: zero timing
// Filename     	: lanht1.v
// Description  	:  Minimum Tristate Latch with Z-output only and Active Higher Enable, 1X Drive
// Library      	: cb18os120
// Programmer   	: xavier
// Date                 : 20-Jul-2000
// Product version	: Rev. main.3 
// Master version	: Rev. main.4
//
//


module lanht1 (D,E,OE,Z);

output  Z;
input   D,E,OE;

`ifdef functional
buf b_D (D_buf,D);
buf b_E (E_buf,E);
buf b_OE (OE_buf,OE);
U_LD_P #0.01 (Q,D_buf,E_buf);
bufif1 b1(Z,Q,OE_buf);
`else
reg notifier;
buf b_D (D_buf,D);
buf b_E (E_buf,E);
buf b_OE (OE_buf,OE);
U_LD_P_NO #0.01 (Q,D_buf,E_buf,notifier);
bufif1 b1(Z,Q,OE_buf);
`endif

`ifdef functional
`else
specify
// Parameter declarations
 specparam tsu_d_h_e=0.04,tsu_d_l_e=0.18,th_e_d_h=0.00,th_e_d_l=0.01,
 tpw_e_h=0.25,d_lh_z_lh=0,oe_hl_z_hz_1=0,oe_lh_z_zl_1=0,d_hl_z_hl=0,
 e_lh_z_lh=0,e_lh_z_hl=0,oe_hl_z_lz_1=0,oe_lh_z_zh_2=0;
// Violation constraints
 $setup (posedge D,negedge E,tsu_d_h_e,notifier);
 $setup (negedge D,negedge E,tsu_d_l_e,notifier);
 $hold  (negedge E,negedge D,th_e_d_h,notifier);
 $hold  (negedge E,posedge D,th_e_d_l,notifier);
 $width (posedge E,tpw_e_h,0,notifier);
// Delays
 (        OE  => Z) = (oe_hl_z_lz_1,oe_hl_z_hz_1,oe_hl_z_lz_1,oe_lh_z_zh_2,oe_hl_z_hz_1,oe_lh_z_zl_1);
 (D   *> Z) = (d_lh_z_lh,d_hl_z_hl);
 (E   *> Z) = (e_lh_z_lh,e_lh_z_hl);
endspecify
`endif



endmodule
`endcelldefine
`disable_portfaults
`nosuppress_faults
`timescale 1ns / 10ps
