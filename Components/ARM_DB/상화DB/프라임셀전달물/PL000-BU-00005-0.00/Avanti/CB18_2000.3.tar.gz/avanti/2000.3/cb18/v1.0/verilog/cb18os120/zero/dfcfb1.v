// ****** (C) Copyright 1998 Avant! Inc. ********
//  --    AVANT! Verilog Models
// **********************************************


`celldefine
`suppress_faults
`enable_portfaults

`ifdef functional
 `timescale 1ns / 1ns
 `delay_mode_distributed
 `delay_mode_unit
`else
 `timescale 1ns / 10ps
 `delay_mode_path
`endif 


// Model type   	: zero timing
// Filename     	: dfcfb1.v
// Description  	:  Buffered D Flip-Flop with Clear, 1X Drive
// Library      	: cb18os120
// Programmer   	: bgazel
// Date                 : 06-Aug-1999
// Product version	: Rev. main.1 
// Master version	: Rev. main.2
//
//


module dfcfb1 (D,CPN,CDN,Q,QN);

output  Q,QN;
input   D,CPN,CDN;

`ifdef functional
U_FD_N_RB_NO #1 (buf_Q,D,CPN,CDN,1'b1);
`else
reg notifier;
U_FD_N_RB_NO #0.01 (buf_Q,D,CPN,CDN,notifier);
`endif

buf (Q,buf_Q);
not (QN,buf_Q);

`ifdef functional
`else
specify
// Parameter declarations
 specparam tsu_d_h_cpn=0.10,tsu_d_l_cpn=0.22,tsu_cdn_h_cpn=0.00,th_cpn_d_h=0.00,
 th_cpn_d_l=0.09,th_cpn_cdn_l=0.32,tpw_cpn_l=0.32,tpw_cpn_h=0.34,tpw_cdn_l=0.26,
 cpn_hl_qn_hl=0,cpn_hl_q_lh=0,cpn_hl_qn_lh=0,cpn_hl_q_hl=0,cdn_hl_q_hl_1=0,cdn_hl_qn_lh_1=0;
// Violation constraints
 $setup (posedge D &&& (CDN==1'b1),negedge CPN &&& (CDN==1'b1),tsu_d_h_cpn,notifier);
 $setup (negedge D &&& (CDN==1'b1),negedge CPN &&& (CDN==1'b1),tsu_d_l_cpn,notifier);
 $recovery (posedge CDN,negedge CPN,tsu_cdn_h_cpn,notifier);
 $hold  (negedge CPN &&& (CDN==1'b1),negedge D &&& (CDN==1'b1),th_cpn_d_h,notifier);
 $hold  (negedge CPN &&& (CDN==1'b1),posedge D &&& (CDN==1'b1),th_cpn_d_l,notifier);
 $hold  (negedge CPN,posedge CDN,th_cpn_cdn_l,notifier);
 $width (negedge CPN &&& (CDN==1'b1),tpw_cpn_l,0,notifier);
 $width (posedge CPN &&& (CDN==1'b1),tpw_cpn_h,0,notifier);
 $width (negedge CDN,tpw_cdn_l,0,notifier);
// Delays
 if (CDN==1'b1)
 (negedge CPN  => (QN -: D   )) = (cpn_hl_qn_lh,cpn_hl_qn_hl);
 if (CDN==1'b1)
 (negedge CPN  => (Q  +: D   )) = (cpn_hl_q_lh,cpn_hl_q_hl);
 (negedge CDN  => (Q  -: 1'b1)) = (0,cdn_hl_q_hl_1);
 (negedge CDN  => (QN +: 1'b1)) = (cdn_hl_qn_lh_1,0);
endspecify
`endif

endmodule
`endcelldefine
`disable_portfaults
`nosuppress_faults
