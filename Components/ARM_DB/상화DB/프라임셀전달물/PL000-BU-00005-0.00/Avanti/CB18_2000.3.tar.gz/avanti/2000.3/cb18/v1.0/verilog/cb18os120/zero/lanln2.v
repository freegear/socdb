// ****** (C) Copyright 1998 Avant! Inc. ********
//  --    AVANT! Verilog Models
// **********************************************


`celldefine
`suppress_faults
`enable_portfaults

`ifdef functional
 `timescale 1ns / 1ns
 `delay_mode_distributed
 `delay_mode_unit
`else
 `timescale 1ns / 10ps
 `delay_mode_path
`endif 


// Model type   	: zero timing
// Filename     	: lanln2.v
// Description  	:  Buffered Latch with Low Enable and QN only, 2X Drive
// Library      	: cb18os120
// Programmer   	: xavier
// Date                 : 20-Jul-2000
// Product version	: Rev. main.3 
// Master version	: Rev. main.4
//
//


module lanln2 (EN,D,QN);

output  QN;
input   EN,D;

`ifdef functional
buf b_EN (EN_buf,EN);
buf b_D (D_buf,D);
s_lanln2 #0.01 (QN,EN_buf,D_buf,1'b0);
`else
reg notifier;
buf b_EN (EN_buf,EN);
buf b_D (D_buf,D);
s_lanln2 #0.01 (QN,EN_buf,D_buf,notifier);
`endif


`ifdef functional
`else
specify
// Parameter declarations
 specparam tsu_d_h_en=0.26,tsu_d_l_en=0.31,th_en_d_h=0.00,th_en_d_l=0.00,
 tpw_en_l=0.30,d_lh_qn_hl=0,d_hl_qn_lh=0,en_hl_qn_lh=0,en_hl_qn_hl=0;
// Violation constraints
 $setup (posedge D,posedge EN,tsu_d_h_en,notifier);
 $setup (negedge D,posedge EN,tsu_d_l_en,notifier);
 $hold  (posedge EN,negedge D,th_en_d_h,notifier);
 $hold  (posedge EN,posedge D,th_en_d_l,notifier);
 $width (negedge EN,tpw_en_l,0,notifier);
// Delays
 if (EN==1'b0)
 (        D  -=> QN) = (d_hl_qn_lh,d_lh_qn_hl);
 (negedge EN  => (QN -: D  )) = (en_hl_qn_lh,en_hl_qn_hl);
endspecify
`endif

endmodule
`endcelldefine
`disable_portfaults
`nosuppress_faults
`timescale 1ns / 10ps


primitive s_lanln2 (QN,EN,D,notifier);

output	QN;
input	EN,D,notifier;
reg	QN;

table
// EN     D    notifier : - : QN ;
    0    (?0)	 ?	: ? :  1 ;
    0    (?1)    ?	: ? :  0 ;
    1     * 	 ?	: ? :  - ;
    f     0	 ?	: ? :  1 ;
    f 	  1	 ? 	: ? :  0 ;
   (1x)   0  	 ?	: 1 :  x ;
   (1x)   1      ?      : 0 :  x ;
   (x0)   0      ? 	: ? :  1 ;
   (x0)   1      ?      : ? :  0 ;
   (0x)   ?	 ? 	: ? :  x ;
   r      0	 ? 	: ? :  - ;
   r      1	 ? 	: ? :  - ;
   ?	  ? 	 *	: ? :  x ;
endtable
endprimitive 
