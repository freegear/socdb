// ****** (C) Copyright 1998 Avant! Inc. ********
//  --    AVANT! Verilog Models
// **********************************************


`celldefine
`suppress_faults
`enable_portfaults

`ifdef functional
 `timescale 1ns / 1ns
 `delay_mode_distributed
 `delay_mode_unit
`else
 `timescale 1ns / 10ps
 `delay_mode_path
`endif 


// Model type   	: zero timing
// Filename     	: sdcrn1.v
// Description  	:  Buffered Muxed Scan D Flip-Flop with Clear and QN only, 1X Drive
// Library      	: LIBNAME
// Programmer   	: LOGIN
// Date                 : DATE
// Product version	: PRODUCT_VERSION 
// Master version	: MASTER_VERSION
// Master note		: 03-Jun-1999 - fix UDP related to DH 7587
// Master note		: 16-Aug-1999 UDP modified to remove redundancies related to DH 9988
// Master note		: Bugfix
//
//


module sdcrn1 (CP,CDN,D,SC,SD,QN);

output  QN;
input   CP,CDN,D,SC,SD;

`ifdef functional
s_sdcrn1 #0.01 (QN,CP,SC,CDN,SD,D,1'b0);
`else
reg notifier;
s_sdcrn1 #0.01 (QN,CP,SC,CDN,SD,D,notifier);
`endif

`ifdef functional
`else
buf (CDN_buf,CDN);
buf (SC_buf,SC);


wire vcond1 = ((CDN_buf==1'b1) && (SC_buf==1'b1));
wire vcond2 = ((CDN_buf==1'b1) && (SC_buf==1'b0));
specify
// Parameter declarations
 specparam tsu_sd_h_cp=0.49,tsu_sd_l_cp=0.59,tsu_sc_h_cp=0.48,tsu_sc_l_cp=0.49,
 tsu_d_h_cp=0.30,tsu_d_l_cp=0.41,tsu_cdn_h_cp=0.00,th_cp_sd_h=0.00,th_cp_sd_l=0.00,
 th_cp_sc_h=0.00,th_cp_sc_l=0.00,th_cp_d_h=0.00,th_cp_d_l=0.00,th_cp_cdn_l=0.30,
 tpw_cp_h=0.27,tpw_cp_l=0.42,tpw_cdn_l=0.28,cp_lh_qn_hl_1=0,cp_lh_qn_lh_1=0,cdn_hl_qn_lh_3=0;
// Violation constraints

 $setup (posedge SD &&& (vcond1==1'b1),posedge CP &&& (vcond1==1'b1),tsu_sd_h_cp,notifier);
 $setup (negedge SD &&& (vcond1==1'b1),posedge CP &&& (vcond1==1'b1),tsu_sd_l_cp,notifier);
 $setup (posedge SC &&& (CDN==1'b1),posedge CP &&& (CDN==1'b1),tsu_sc_h_cp,notifier);
 $setup (negedge SC &&& (CDN==1'b1),posedge CP &&& (CDN==1'b1),tsu_sc_l_cp,notifier);
 $setup (posedge D &&& (vcond2==1'b1),posedge CP &&& (vcond2==1'b1),tsu_d_h_cp,notifier);
 $setup (negedge D &&& (vcond2==1'b1),posedge CP &&& (vcond2==1'b1),tsu_d_l_cp,notifier);
 $recovery (posedge CDN,posedge CP,tsu_cdn_h_cp,notifier);
 $hold  (posedge CP &&& (vcond1==1'b1),negedge SD &&& (vcond1==1'b1),th_cp_sd_h,notifier);
 $hold  (posedge CP &&& (vcond1==1'b1),posedge SD &&& (vcond1==1'b1),th_cp_sd_l,notifier);
 $hold  (posedge CP &&& (CDN==1'b1),negedge SC &&& (CDN==1'b1),th_cp_sc_h,notifier);
 $hold  (posedge CP &&& (CDN==1'b1),posedge SC &&& (CDN==1'b1),th_cp_sc_l,notifier);
 $hold  (posedge CP &&& (vcond2==1'b1),negedge D &&& (vcond2==1'b1),th_cp_d_h,notifier);
 $hold  (posedge CP &&& (vcond2==1'b1),posedge D &&& (vcond2==1'b1),th_cp_d_l,notifier);
 $hold  (posedge CP,posedge CDN,th_cp_cdn_l,notifier);

 $width (posedge CP &&& (CDN==1'b1),tpw_cp_h,0,notifier);
 $width (negedge CP &&& (CDN==1'b1),tpw_cp_l,0,notifier);
 $width (negedge CDN,tpw_cdn_l,0,notifier);
// Delays
 if (CDN==1'b1)
 (posedge CP   => (QN -: ((SD && SC) || (D && ~SC)))) = (cp_lh_qn_lh_1,cp_lh_qn_hl_1);
 (negedge CDN  => (QN +: 1'b1)) = (cdn_hl_qn_lh_3,0);
endspecify
`endif

endmodule
`endcelldefine
`disable_portfaults
`nosuppress_faults
`timescale 1ns / 10ps


primitive s_sdcrn1(QN,CP,SC,CDN,SD,D,notifier);

output QN;
reg    QN;
input  CP,SC,CDN,SD,D,notifier;

table
// CP   SC   CDN  SD   D    nfr : - : QN;

   r    1    1    0    ?    ?   : ? : 1;
   r    0    1    ?    0    ?   : ? : 1;
   ?    ?    0    ?    ?    ?   : ? : 1;
   r    0    1    ?    1    ?   : ? : 0;
   r    1    1    1    ?    ?   : ? : 0;
   n    ?    1    ?    ?    ?   : ? : -;
//   ?    *    ?    ?    ?    ?   : ? : -;
   ?    ?    (?1) ?    ?    ?   : ? : -;
//   ?    ?    ?    *    ?    ?   : ? : -;
//   ?    ?    ?    ?    *    ?   : ? : -;
   r    x    1    0    0    ?   : ? : 1;
   r    x    1    1    1    ?   : ? : 0;
   r    1    x    0    ?    ?   : ? : 1;
   r    0    x    ?    0    ?   : ? : 1;
   0    ?    x    ?    ?    ?   : 1 : 1;
   ?    ?    ?    ?    ?    *   : ? : x;
// new entry
   r    ?    ?    0    0    ?   : ? : 1;
   ?    p    1    ?    ?    ?   : ? : -;
   ?    ?    1    ?    n    ?   : ? : -;
endtable
endprimitive

