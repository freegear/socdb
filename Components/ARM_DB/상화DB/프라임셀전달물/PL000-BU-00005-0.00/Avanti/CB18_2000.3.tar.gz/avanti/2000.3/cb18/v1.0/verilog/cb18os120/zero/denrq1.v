// ****** (C) Copyright 1998 Avant! Inc. ********
//  --    AVANT! Verilog Models
// **********************************************


`celldefine
`suppress_faults
`enable_portfaults

`ifdef functional
 `timescale 1ns / 1ns
 `delay_mode_distributed
 `delay_mode_unit
`else
 `timescale 1ns / 10ps
 `delay_mode_path
`endif 


// Model type   	: zero timing
// Filename     	: denrq1.v
// Description  	:  Buffered Enabled D Flip-Flop with Q only, 1X Drive
// Library      	: cb18os120
// Programmer   	: bgazel
// Date                 : 06-Aug-1999
// Product version	: Rev. main.1 
// Master version	: Rev. main.2
//
//


module denrq1 (CP,D,ENN,Q);

output  Q;
input   CP,D,ENN;

buf (CP_buf,CP);
buf (D_buf,D);
buf (ENN_buf,ENN);

wire BOOL_OUT = (((!ENN_buf && D_buf)) && ((!ENN_buf))) || !(!Q || ((!ENN_buf)));

`ifdef functional
U_FD_P #1 (Q,BOOL_OUT,CP);
`else
reg notifier;
U_FD_P_NO #0.01 (Q,BOOL_OUT,CP,notifier);
`endif

`ifdef functional
`else
specify
// Parameter declarations
 specparam tsu_enn_h_cp=0.36,tsu_enn_l_cp=0.45,tsu_d_h_cp=0.27,tsu_d_l_cp=0.37,
 th_cp_enn_h=0.00,th_cp_enn_l=0.00,th_cp_d_h=0.00,th_cp_d_l=0.00,tpw_cp_h=0.23,
 tpw_cp_l=0.41,cp_lh_q_hl=0,cp_lh_q_lh=0;
// Violation constraints
 $setup (posedge ENN,posedge CP,tsu_enn_h_cp,notifier);
 $setup (negedge ENN,posedge CP,tsu_enn_l_cp,notifier);
 $setup (posedge D &&& (ENN==1'b0),posedge CP &&& (ENN==1'b0),tsu_d_h_cp,notifier);
 $setup (negedge D &&& (ENN==1'b0),posedge CP &&& (ENN==1'b0),tsu_d_l_cp,notifier);
 $hold  (posedge CP,negedge ENN,th_cp_enn_h,notifier);
 $hold  (posedge CP,posedge ENN,th_cp_enn_l,notifier);
 $hold  (posedge CP &&& (ENN==1'b0),negedge D &&& (ENN==1'b0),th_cp_d_h,notifier);
 $hold  (posedge CP &&& (ENN==1'b0),posedge D &&& (ENN==1'b0),th_cp_d_l,notifier);
 $width (posedge CP &&& (ENN==1'b0),tpw_cp_h,0,notifier);
 $width (negedge CP &&& (ENN==1'b0),tpw_cp_l,0,notifier);
// Delays
 if (ENN==1'b0)
 (posedge CP  => (Q +: BOOL_OUT)) = (cp_lh_q_lh,cp_lh_q_hl);
endspecify
`endif

endmodule
`endcelldefine
`disable_portfaults
`nosuppress_faults
