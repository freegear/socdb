// ****** (C) Copyright 1998 Avant! Inc. ********
//  --    AVANT! Verilog Models
// **********************************************


`celldefine
`delay_mode_path
`suppress_faults
`enable_portfaults
`timescale 1 ns / 10 ps

// Model type   	: zero timing
// Filename     	: cload1.v
// Description  	:  CLOCK LOAD
// Library      	: cb18os120
// Programmer   	: bgazel
// Date                 : 06-Aug-1999
// Product version	: Rev. main.1 
// Master version	: Rev. main.2
//
//


module cload1 (I);

   input I;
   buf    E0(DeadEnd, I);

`ifdef NOTIMING
`else
   specify
      specparam InCap$I       = 0.000,
                cell_count    = 0.000,
                Transistors   = 2,
                Power         = 0.000;
      
   endspecify
`endif

endmodule

`nosuppress_faults
`disable_portfaults
`endcelldefine
