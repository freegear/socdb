// ****** (C) Copyright 1998 Avant! Inc. ********
//  --    AVANT! Verilog Models
// **********************************************


`celldefine
`suppress_faults
`enable_portfaults

`ifdef functional
 `timescale 1ns / 1ns
 `delay_mode_distributed
 `delay_mode_unit
`else
 `timescale 1ns / 10ps
 `delay_mode_path
`endif 


// Model type   	: zero timing
// Filename     	: ora21d2.v
// Description  	:  2/1 OR-AND, 2X Drive
// Library      	: cb18os120
// Programmer   	: bgazel
// Date                 : 06-Aug-1999
// Product version	: Rev. main.1 
// Master version	: Rev. main.2
//
//


module ora21d2 (B2,B1,A,Z);

output  Z;
input   B2,B1,A;

or (g_2_out,B1,B2);
and #0.01 (Z,A,g_2_out);

`ifdef functional
`else
specify
// Parameter declarations
 specparam b1_hl_z_hl=0,b1_lh_z_lh=0,b2_lh_z_lh=0,a_hl_z_hl_2=0,
 a_lh_z_lh_2=0,b2_hl_z_hl=0;
// Delays
 (        B1 +=> Z) = (b1_lh_z_lh,b1_hl_z_hl);
 (        B2 +=> Z) = (b2_lh_z_lh,b2_hl_z_hl);
 (        A  +=> Z) = (a_lh_z_lh_2,a_hl_z_hl_2);
endspecify
`endif

endmodule
`endcelldefine
`disable_portfaults
`nosuppress_faults
