--=============================================================
--
-- Title: 		V2dev_top_level
-- Program: 	Virtex-II Development Board, Kokerboom
-- Filename:	V2dev_top_level
-- PCB P/N:		H294-APPS-KKB-2101
-- PCB ASSY:	H294-APPS-KKB-3101
--
-- FPGA: 		XC2V4000-4FG1152C
-- Author(s):	Martin A. Mavis
-- Date:		12/2001
--
-- Purpose:
--	This module performs the top level connectivity and hierarchy for the Virtex-II
--	Development board FPGA.  The main functionality of the FPGA is discussed within the UART
--	module.
--
-- Naming convention:
--	Active low signals are indicated by _L.
--
--
-- Disclaimer:
--	Avnet, Inc. makes no warranty for the use of this code or design.  
--	This code is provided  "As Is". Avnet, Inc assumes no responsibility for 
--	any errors, which may appear in this code, nor does it make a commitment 
--	to update the information contained herein. Avnet, Inc specifically 
--	disclaims any implied warranties of fitness for a particular purpose.
--       			 Copyright (c) 2000 Avnet, Inc.
--               			 All rights reserved.
--
--=============================================================
-- Revision List
-- Version		Date		Changes
-- 1.0
--
--=============================================================

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity virtex2_top is
    Port (
--CLOCKS
		   CLK_40MHZ		:  in std_logic;  -- This is the Main FPGA clock
           SWITCH		: in std_logic_vector(7 downto 0);
           LED			: out std_logic_vector(7 downto 0)
		);
end virtex2_top;

architecture rtl of virtex2_top is

--  Define signals
--signal	RESET_L				:   	std_logic;
--signal count_10		: integer range 0 to 1;
--signal CLK_10MHZ 	: std_logic;

COMPONENT DIP_LED_test
PORT (			
		CLK_40MHZ			:  IN	std_logic;
		LED					:  OUT std_logic_vector(7 downto 0);
		SWITCH				:  IN std_logic_vector(7 downto 0)
		);			
END COMPONENT ;			

------------------------------------------------------------------------------
--
BEGIN

--RESET_L <= not SWITCH(0);

--  10MHz CLOCK
--
--CLK_10_PROC :PROCESS (CLK_40MHZ)
--variable count_10 : integer range 0 to 1;
--begin
--if RESET_L = '0' then
--count_10 := 0;
--elsif CLK_40MHZ'event and CLK_40MHZ= '1' then
--	if count_10 = 1 then
--		CLK_10MHZ <= not CLK_10MHZ;
--		count_10 := 0;
--	else
--		count_10 := count_10 + 1;
--	end if;
--end if;
--end process;


DIP_LED : DIP_LED_test			
PORT MAP (			
	CLK_40MHZ		=>	CLK_40MHZ,
	LED				=>	LED,
	SWITCH			=>	SWITCH
	);

end rtl;
