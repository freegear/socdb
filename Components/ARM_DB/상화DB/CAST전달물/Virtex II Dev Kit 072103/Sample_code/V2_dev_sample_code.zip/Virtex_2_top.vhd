--=============================================================
--
-- Title: 	Virtex-II_top
-- Program: 	Virtex-II, Hawaii Development Board
-- Filename:	Hawaii_top
--
-- FPGA:       XC2V1500-5FF896C
-- Author(s):	Marvin Stoltman, Matt Schultz, Martin Mavis
-- Date:       12/2000
--
-- Purpose:	This module performs the top level connectivity and hierarchy for the Hawaii FPGA.
--		The main functionality of the FPGA is discussed within the UART module.
--
-- Naming convention:	Active low signals are indicated by _L.
--
--=============================================================
-- Revision List
-- Version		Date		Changes
-- 1.0
--
--=============================================================

library IEEE;
use IEEE.std_lOGIC_1164.ALL;
use IEEE.std_lOGIC_ARITH.ALL;
use IEEE.std_lOGIC_UNSIGNED.ALL;

ENTITY UART_TOP is			
PORT (			
CLK_40MHZ          : IN  std_logic;
SWITCH             : IN  std_logic_vector(4 downto 0);
RS232_IN           : IN  std_logic;
RS232_OUT          : OUT std_logic;
LED                : OUT std_logic_vector(5 downto 0);
FLASH_RST_L        : OUT std_logic;
FLASH_WE_L         : OUT std_logic;
FLASH_CE_L         : OUT std_logic;
FLASH_OE_L         : OUT std_logic;
ADDRESS            : OUT std_logic_vector(31 downto 0);
DATA               : inout std_logic_vector(15 downto 0)
);			
END UART_TOP;			
--
--
ARCHITECTURE struct OF UART_TOP is

signal	RESET_L             : std_logic;
signal	FLASH_START_TEST    : std_logic;
signal	FLASH_FAIL_TEST	    : std_logic;
signal	FLASH_PASS_TEST     : std_logic;
--signal  FLASH_ADDRESS       : std_logic_vector(31 downto 0);



COMPONENT FLASH_ID			
PORT (			
CLK_10MHZ         : IN  std_logic;
RESET_L           : IN  std_logic;
FLASH_CE_L        : OUT std_logic;
FLASH_RST_L       : OUT std_logic;
FLASH_WE_L        : OUT std_logic;
FLASH_OE_L        : OUT std_logic;
ADDRESS           : OUT std_logic_vector(31 downto 0);
DATA              : INOUT std_logic_vector(15 downto 0);
FLASH_START_TEST  : IN  std_logic;
FLASH_FAIL_TEST	  : OUT std_logic;
FLASH_PASS_TEST	  : OUT std_logic	
);			
END COMPONENT ;			
--			
			
			
COMPONENT UART			
PORT (			
CLK_40MHZ          : IN  std_logic;
RESET_L            : IN  std_logic;
LED                : OUT std_logic_vector(5 downto 0);
SWITCH             : IN  std_logic_vector(4 downto 0);
RS232_IN           : IN	 std_logic;
RS232_OUT          : OUT std_logic;

FLASH_START_TEST   : OUT std_logic;
FLASH_FAIL_TEST	   : IN  std_logic;
FLASH_PASS_TEST    : IN  std_logic			
);			
END COMPONENT ;			
--			
--			
--
----=====================================================================
----
---- Begin Architecture
----
----=====================================================================
--
signal count_10       : integer range 0 to 1;
signal CLK_10MHZ      : std_logic;
signal FLASH_DATA     : std_logic_vector(15 downto 0);
signal DELETE_DATA    : std_logic_vector(15 downto 0);

-- DUMMY SIGNALS
signal DUM_1          : std_logic;
signal DUM_2          : std_logic;

signal int_FLASH_WE_L : std_logic;

BEGIN

FLASH_WE_L <= int_FLASH_WE_L;

RESET_L <= not(SWITCH(0));

CLK_10_PROC :PROCESS (CLK_40MHZ,RESET_L)
variable count_10 : integer range 0 to 1;
begin
if RESET_L = '0' then
count_10 := 0;
elsif CLK_40MHZ'event and CLK_40MHZ= '1' then
   if count_10 = 1 then
      CLK_10MHZ <= not CLK_10MHZ;
      count_10 := 0;
   else
      count_10 := count_10 + 1;
   end if;
end if;
end process;


FLASH_CORE : FLASH_ID			
PORT MAP (			
CLK_10MHZ               => CLK_10MHZ,
RESET_L                 => RESET_L,
FLASH_CE_L              => FLASH_CE_L,
FLASH_RST_L             => FLASH_RST_L,
FLASH_WE_L              => int_FLASH_WE_L,
FLASH_OE_L              => FLASH_OE_L,
ADDRESS	                => ADDRESS,
DATA                    => data,
FLASH_START_TEST        => FLASH_START_TEST,
FLASH_FAIL_TEST	        => FLASH_FAIL_TEST,
FLASH_PASS_TEST         => FLASH_PASS_TEST	
);			
				
UART_CORE : UART			
PORT MAP (			
CLK_40MHZ               => CLK_40MHZ,
RESET_L                 => RESET_L,
LED                     => LED,
SWITCH                  => SWITCH,
RS232_IN                => RS232_IN,	
RS232_OUT               => RS232_OUT,
FLASH_START_TEST        => FLASH_START_TEST,
FLASH_FAIL_TEST         => FLASH_FAIL_TEST,
FLASH_PASS_TEST         => FLASH_PASS_TEST

);			

end struct;

