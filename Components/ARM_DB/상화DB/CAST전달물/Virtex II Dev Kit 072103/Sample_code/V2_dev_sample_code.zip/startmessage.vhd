--======================================================================================
-- Design Units	        : message
--
-- Filename             : startmessage.vhd
--
-- Purpose              : This module displays a message to the RS-232 port.
--
-- Notes                : This module currently echos the input bytes to the output port.
--
-- Limitations          :
--
-- Errors               :
--
-- Naming               : Active low signals are indicated by _N.
-- convention
--
-- Library              :
--
-- Dependencies         : IEEE.Std_Logic_1164, IEEE.STD_LOGIC_UNSIGNED
--
-- Sub Modules          : UART_TX, UART_RX

-- Author               : Rob Owens
--                        Avnet Design Services
--
-- Simulator            :
--
-- Disclaimer           :Avnet, Inc. makes no warranty for the use of this code or design.  
--			This code is provided  "As Is". Avnet, Inc assumes no responsibility for 
--			any errors, which may appear in this code, nor does it make a commitment 
--			to update the information contained herein. Avnet, Inc specifically 
--			disclaims any implied warranties of fitness for a particular purpose.
--              	Copyright (c) 2000 Avnet, Inc.
--               	All rights reserved.
--
--
------------------------------------------------------------------------------------------
-- Revision list
-- Version		Author		Date		Changes
--
-- 1.0			RCO           10-02-99          Initial Release
------------------------------------------------------------------------------------------		


library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity message is
port (
	RESET_L:          in    std_logic;
	LED		: out std_logic_vector(4 downto 0);
	CLK_40MHZ:            in    std_logic;
	MESS_ENABLE:     in    std_logic;	-- Signal to start the message out sequence.
	MESS_DONE:       out   std_logic;	-- Signals the completation of the output message.
						-- The current state machine will not get set this output.

						-- RS-232 driver signals.
	SER_IN: in STD_LOGIC;			-- Serial input signal.
	SER_OUT: out STD_LOGIC;			-- Serial output signal.

	FLASH_START_TEST			: out std_logic;
	FLASH_PASS_TEST			: in std_logic;
	FLASH_FAIL_TEST			: in std_logic

	);

end message;

architecture message_arch of message is

-- Transmit Byte
component UART_TX 
   port ( 
	RESET_L: in std_logic;				-- RESET
	BAUDCLK: in std_logic;				-- This clock is the BUAD rate clock
	DATA: in std_logic_vector(7 downto 0);		-- DATA to be sent
	SER_OUT: out std_logic;				-- Serial output line
	SEND_DATA: in std_logic;			-- Trigger serial out
	BUSY: out std_logic				-- Transmitting Flag
   );
end component;

-- Recieve Byte
component UART_RX
   port ( 
	RESET_L: in std_logic;				-- RESET
	X16CLK: in std_logic;				-- This clock is 16 time as fast as baud rate clock
	DATA: out std_logic_vector(7 downto 0);		-- The output on these signals is valid on the rising DATA_READY signal
	SER_IN: in std_logic;				-- Serial input line
	DATA_READY: out std_logic			-- This signal goes high one clock after DATA is valid. Signal is active for one clock.
   );

end component;

type data_capt is (a, b, c );
signal data_capt_state : data_capt;

type STATES is (StartTX,WaitTX,WaitTXDone,NextTX,Done,ECHO1,ECHO2,ECHO3);

type state is (idle, testing);
signal test_state : state ;


signal  mode :       STATES;
signal	DATA_OUT,DATA_IN: std_logic_vector(7 downto 0);		-- DATA to be sent
signal	W0, W1, W2, W3 : std_logic_vector(7 downto 0);
signal	SEND_DATA,DATA_READY: std_logic;					-- Trigger serial out
signal	BUSY: std_logic;							-- Transmitting Flag

signal BAUDcount: std_logic_vector(3 downto 0);
signal counter:  std_logic_vector(31 downto 0);
signal BAUD9600 : std_logic;

signal X16count: std_logic_vector(15 downto 0);
signal X16CLK : std_logic;

---------------------------
-- Output message
-- AVNET DESIGN SERVICES
-- design@ads.avnet.com
-- 1.800.585.1602
-- www.ads.avnet.com
-- Virtex-II Development Board

    subtype ROM_WORD is STD_LOGIC_VECTOR (7 downto 0);
    type ROM_TABLE is array (0 to 112) of ROM_WORD;
    constant ROM: ROM_TABLE := ROM_TABLE'(
        ROM_WORD'("00001010"),	-- 0x0A
        ROM_WORD'("00001101"),	-- 0x0D
        ROM_WORD'("01000001"),  	-- A
        ROM_WORD'("01010110"),	-- V
        ROM_WORD'("01001110"),	-- N
        ROM_WORD'("01000101"),	-- E
        ROM_WORD'("01010100"),	-- T
        ROM_WORD'("00100000"),	-- 
        ROM_WORD'("01000100"),	-- D
        ROM_WORD'("01000101"),	-- E
        ROM_WORD'("01010011"),	-- S
        ROM_WORD'("01001001"),	-- I
        ROM_WORD'("01000111"),	-- G
        ROM_WORD'("01001110"),	-- N
        ROM_WORD'("00100000"),	-- 
        ROM_WORD'("01010011"),	-- S
        ROM_WORD'("01000101"),	-- E
        ROM_WORD'("01010010"),	-- R
        ROM_WORD'("01010110"),	-- V
        ROM_WORD'("01001001"),	-- I
        ROM_WORD'("01000011"),	-- C
        ROM_WORD'("01000101"),	-- E
        ROM_WORD'("01010011"),	-- S
        ROM_WORD'("00001010"),	-- 0x0A
        ROM_WORD'("00001101"),	-- 0x0D
        ROM_WORD'("01100100"),	-- d
        ROM_WORD'("01100101"),	-- e
        ROM_WORD'("01110011"),	-- s
        ROM_WORD'("01101001"),	-- i
        ROM_WORD'("01100111"),	-- g
        ROM_WORD'("01101110"),	-- n
        ROM_WORD'("01000000"),	-- @
        ROM_WORD'("01100001"),	-- a
        ROM_WORD'("01100100"),	-- d
        ROM_WORD'("01110011"),	-- s
        ROM_WORD'("00101110"),	-- .
        ROM_WORD'("01100001"),	-- a
        ROM_WORD'("01110110"),	-- v
        ROM_WORD'("01101110"),	-- n
        ROM_WORD'("01100101"),	-- e
        ROM_WORD'("01110100"),	-- t
        ROM_WORD'("00101110"),	-- .
        ROM_WORD'("01100011"),	-- c
        ROM_WORD'("01101111"),	-- o
        ROM_WORD'("01101101"),	-- m
        ROM_WORD'("00001010"),	-- 0x0A
        ROM_WORD'("00001101"),	-- 0x0D
        ROM_WORD'("00110001"),	-- 1
        ROM_WORD'("00101110"),	-- .
        ROM_WORD'("00111000"),	-- 8
        ROM_WORD'("00110000"),	-- 0
        ROM_WORD'("00110000"),	-- 0
        ROM_WORD'("00101110"),	-- .
        ROM_WORD'("00110101"),	-- 5
        ROM_WORD'("00111000"),	-- 8
        ROM_WORD'("00110101"),	-- 5
        ROM_WORD'("00101110"),	-- .
        ROM_WORD'("00110001"),	-- 1
        ROM_WORD'("00110110"),	-- 6
        ROM_WORD'("00110000"),	-- 0
        ROM_WORD'("00110010"),	-- 2
        ROM_WORD'("00001010"),	-- 0x0A
        ROM_WORD'("00001101"),	-- 0x0D
        ROM_WORD'("01110111"),	-- w
        ROM_WORD'("01110111"),	-- w
        ROM_WORD'("01110111"),	-- w
        ROM_WORD'("00101110"),	-- .
        ROM_WORD'("01100001"),	-- a
        ROM_WORD'("01100100"),	-- d
        ROM_WORD'("01110011"),	-- s
        ROM_WORD'("00101110"),	-- .
        ROM_WORD'("01100001"),	-- a
        ROM_WORD'("01110110"),	-- v
        ROM_WORD'("01101110"),	-- n
        ROM_WORD'("01100101"),	-- e
        ROM_WORD'("01110100"),	-- t
        ROM_WORD'("00101110"),	-- .
        ROM_WORD'("01100011"),	-- c
        ROM_WORD'("01101111"),	-- o
        ROM_WORD'("01101101"),	-- m
        ROM_WORD'("00001010"),	-- 0x0A
        ROM_WORD'("00001101"),	-- 0x0D
        ROM_WORD'("01010110"),	-- V
        ROM_WORD'("01101001"),	-- i
        ROM_WORD'("01110010"),	-- r
        ROM_WORD'("01110100"),	-- t
        ROM_WORD'("01100101"),	-- e
        ROM_WORD'("01111000"),   -- x
        ROM_WORD'("00101101"),	-- -
        ROM_WORD'("01001001"),	-- I
        ROM_WORD'("01001001"),	-- I
        ROM_WORD'("00100000"),	-- 
        ROM_WORD'("01000100"),	-- D
		  ROM_WORD'("01100101"),	-- e
        ROM_WORD'("01110110"),	-- v
        ROM_WORD'("01100101"),	-- e
        ROM_WORD'("01101100"),	-- l
        ROM_WORD'("01101111"),	-- o
        ROM_WORD'("01110000"),	-- p
        ROM_WORD'("01101101"),	-- m
        ROM_WORD'("01100101"),	-- e
        ROM_WORD'("01101110"),	-- n
        ROM_WORD'("01110100"),	-- t
        ROM_WORD'("00100000"),	-- 
        ROM_WORD'("01000010"),	-- B
        ROM_WORD'("01101111"),	-- o
        ROM_WORD'("01100001"),	-- a
        ROM_WORD'("01110010"),	-- r
        ROM_WORD'("01100100"),	-- d

        ROM_WORD'("00001010"),	-- 0x0A
        ROM_WORD'("00001101"),	-- 0x0D
        ROM_WORD'("00101101"),	-- -
        ROM_WORD'("00111110")); -- >	

signal count: integer;

begin
LED(2) <= '1';
LED(3) <= '1';
LED(4) <= not(RESET_L);
--LED(5) <= switch(1);
-- Set the RS-232 driver/receiver  enabled and active. 
--ENABLE_N <= '0';
--DEACTIVATE_N <= '1';

process(CLK_40MHZ,RESET_L)    
begin

if RESET_L = '0' then 
	mode         <= StartTX;
	count <= 0; 
	MESS_DONE     <= '0';
	DATA_OUT <= "00000000";
elsif CLK_40MHZ'event and CLK_40MHZ = '1' then
	if MESS_ENABLE     = '0' then
        	MESS_DONE     <= '0';  -- wait.
	else	-- Send the message.
		case mode is
		when StartTX => 				-- Transmit the current byte. 
				MESS_DONE     <= '0';
				DATA_OUT <= ROM(count);
				SEND_DATA <= '1';
				mode <= WaitTX;
				
		when WaitTX =>
				MESS_DONE     <= '0';
				SEND_DATA <= '1';
				if  Busy = '0' then
					mode <= WaitTX;
				else 
					mode <= WaitTXDone;
				end if;
		when WaitTXDone =>
				MESS_DONE     <= '0';
				SEND_DATA <= '0'; 
				if Busy = '1' then
					mode <= WaitTXDone;
				else
					mode <= NextTX; 
				end if; 						
		when NextTX =>					-- Loop through the message.
				MESS_DONE     <= '0';
				SEND_DATA <= '0';
				if count = 112 then   -- 15
					mode <= ECHO1;
					count <= 0;
				else
					count <= count +1;
					mode <= StartTX;
				end if;
				
		when ECHO1 =>					-- Get byte				
				MESS_DONE     <= '0';
				if DATA_READY = '1' then				
					DATA_OUT <= DATA_IN;
					SEND_DATA <= '1';
					mode <= ECHO2;
				else
					mode <= ECHO1;
				end if;
		when ECHO2 =>					-- Sent Byte
				MESS_DONE     <= '0';
				SEND_DATA <= '1';
				if Busy = '0' then
					mode <= ECHO2;
				else
					mode <= ECHO3;
				end if;
		when ECHO3 =>
				MESS_DONE     <= '0';
				SEND_DATA <= '0';
				if Busy = '1' then
					mode <= ECHO3;
				else
					mode <= ECHO1;
				end if;
			
		when Done =>					-- Can't get here.
			SEND_DATA <= '0';
			MESS_DONE <= '1';
			mode     <= StartTX;
		when others => 
			SEND_DATA <= '0';
			MESS_DONE <= '1';
			mode     <= StartTX;
						
		end case;
	end if;
end if;
end process;

--Data checking of incoming data
process(CLK_40MHZ,RESET_L, test_state)
begin

if RESET_L = '0' or test_state = testing then		--reset buffer when valid pattern found, only two
	W0 <=  "00000000";										--states so OK to decode this way
	W1 <=  "00000000";
	W2 <=  "00000000";
	W3 <=  "00000000";
	data_capt_state <= a;
--	LED(3) <= '1';
--	LED(4) <= '1';
--	LED(5) <= '0';
--	LED(6) <= '0';
--	LED(7) <= '1';
	elsif CLK_40MHZ'event and CLK_40MHZ = '1' then
		case data_capt_state is
		when a =>
			if DATA_READY = '1' then				
				W0 <= DATA_IN ;
				W1 <= W0 ;
				W2 <= W1 ;
				W3 <= W2 ;
				data_capt_state <= b;
			else
				W0 <= W0 ;
				W1 <= W1 ;
				W2 <= W2 ;
				W3 <= W3 ;
				data_capt_state <= a;	
 			end if;
--			LED(7) <= '1';
		when b =>
			if Busy = '0' then 
				data_capt_state <= b;
			else
				data_capt_state <= c;
			end if;
--			LED(6) <= '1';
		when c =>
			if Busy = '1' then 
				data_capt_state <= c;
			else
				data_capt_state <= a;
			end if;
--			LED(5) <= '1';
		end case;
end if;
end process;

process(CLK_40MHZ,RESET_L)
begin

if RESET_L = '0' then
	test_state <= idle;
	counter <= "00000000000000000000000000000000";
	LED(0) <= '0';
	LED(1) <= '0';
--	LED(6) <= '0';
--	LED(7) <= '1';
	FLASH_START_TEST <= '0';

	elsif CLK_40MHZ'event and CLK_40MHZ = '1' then

	case test_state is

	when idle =>
	counter <= "00000000000000000000000000000000";
			LED(0) <= '0';
			LED(1) <= '0';
--			led(7) <= '0';
		if	 	W0 = x"4c" and W1 = x"46" and W2 = x"20" and W3 = x"54" then -- LF T = T FL
			FLASH_START_TEST <= '1';
			test_state <= testing;
		else
			test_state <= idle;
		end if;
--		LED(6) <= '1';
	when testing =>
--LED(6) <= '0';

--	 	if FLASH_PASS_TEST = '1' then
--			LED(6) <= '1';
--		elsif FLASH_FAIL_TEST = '1' then
--			LED(6) <= '1';
--		else 
--			LED(6) <= '0';
--		end if;

	 	if FLASH_PASS_TEST = '1' then
			LED(0) <= '1';
			LED(1) <= '0';
		elsif FLASH_FAIL_TEST = '1' then
			LED(0) <= '0';
			LED(1) <= '1';
		else 
			LED(0) <= '0';
			LED(1) <= '0';
		end if;
		
		if counter = x"0fffffff"	then		--3 second delay
			test_state <= idle;
				FLASH_START_TEST <= '0';
		else
			counter <= counter + 1;
			test_state <= testing;
		end if;

when others => null;
end case;
end if ;
end process;


-- Generate a communication clock and a sampling clock - 9600 baud
process(CLK_40MHZ,RESET_L)
begin

if RESET_L = '0' then
	X16count <= "0000000000000000";
	BAUD9600 <= '0';
	BAUDcount <= "0000";
	X16CLK <= '0';
elsif CLK_40MHZ'event and CLK_40MHZ = '1' then
	if X16count =  130 then
		X16CLK <= not X16CLK;
		X16count <= "0000000000000000";
		if BAUDcount = 15 then
			BAUD9600 <= not BAUD9600;
			BAUDcount <= "0000";
		else
			BAUDcount <= BAUDcount + 1;
		end if;
	else
		X16count <= X16count +1;
	end if;
end if;
 

end process;

UART1: UART_TX port map(RESET_L,BAUD9600,DATA_OUT,SER_OUT,SEND_DATA,BUSY);
UART2: UART_RX port map(RESET_L,X16CLK,DATA_IN,SER_IN,DATA_READY); 


end message_arch;
