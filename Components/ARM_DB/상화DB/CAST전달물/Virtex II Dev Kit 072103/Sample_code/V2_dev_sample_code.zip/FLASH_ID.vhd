library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity FLASH_ID is
    Port ( RESET_L 				: in std_logic;
           CLK_10MHZ 			: in std_logic;
	  		  DATA 					: inout std_logic_vector(15 downto 0);
           ADDRESS 				: out std_logic_vector(31 downto 0);
           FLASH_RST_L			: out std_logic;
           FLASH_CE_L 		: out std_logic;
           FLASH_WE_L 			: out std_logic;
           FLASH_OE_L 			: out std_logic;
           FLASH_START_TEST 	: in std_logic;
           FLASH_PASS_TEST	 		: out std_logic;
           FLASH_FAIL_TEST 			: out std_logic);
			  
end FLASH_ID;

architecture logic of FLASH_ID is

type FLASH_STATE is (wait_for_test, wr_1_set, wr_1_cs, wr_1_hld,
												wr_2_set, wr_2_cs, wr_2_hld,
--												wr_3_set, wr_3_cs, wr_3_hld, 
  											   rd_1_set, rd_1_cs, rd_1_done,rd_1_hld);

signal FLASH_COMPARE : std_logic;
signal FLASH_DATA : STD_LOGIC_VECTOR (15 downto 0);
signal next_state : FLASH_STATE;
signal test_in_prog	: std_logic;


begin

process(RESET_L,CLK_10MHZ)
	begin
	if RESET_L = '0'  then --and switch(2) = '0'
		next_state 	<= wait_for_test;
		FLASH_RST_L 	<= '0';
		FLASH_OE_L  	<= '1';
		FLASH_WE_L  	<= 'Z';
		DATA				<= (others => 'Z'); 
		ADDRESS			<= (others => 'Z');  
		FLASH_CE_L	<= 'Z';
		test_in_prog	<= '0';
		FLASH_COMPARE	<= '0';
		FLASH_PASS_TEST <= '0' ;
		FLASH_FAIL_TEST <= '0' ;
		FLASH_DATA <= x"4321"; 

	elsif CLK_10MHZ'event AND CLK_10MHZ= '1' then

	case next_state is
		when wait_for_test =>
			if FLASH_START_TEST = '1' then
				next_state <= wr_1_set;
			else
				next_state <= wait_for_test;
			end if;
			FLASH_OE_L  	<= '1';
			FLASH_RST_L <= '0';
			FLASH_PASS_TEST <= '0' ;
			FLASH_FAIL_TEST <= '0' ;
			DATA				<= (others => 'Z'); 
			ADDRESS			<= (others => 'Z');
			FLASH_CE_L	<= '1';
			FLASH_WE_L  	<= '1';
			FLASH_DATA <= x"4321"; 

		when wr_1_set =>
				address 			<= x"00002AA8";
				DATA    			<= x"00FF";  --DATA_1;
				FLASH_RST_L 	<= '1';
				FLASH_OE_L  	<= '1';
				FLASH_WE_L  	<= '0';
				FLASH_CE_L	<= '1';
				test_in_prog	<= '1';
	 		next_state <= wr_1_cs ;
		when wr_1_cs =>
				address 			<= x"00002AA8";
				DATA    			<= x"00FF";
				FLASH_RST_L 	<= '1';
				FLASH_OE_L  	<= '1';
				FLASH_WE_L  	<= '0';
				FLASH_CE_L	<= '0';
			next_state <= wr_1_hld ;
		when wr_1_hld =>
				address 			<= x"00002AA8";
				DATA    			<= x"00FF";
				FLASH_RST_L 	<= '1';
				FLASH_OE_L  	<= '1';
				FLASH_WE_L  	<= '0';
				FLASH_CE_L	<= '1';
			next_state <= wr_2_set ;
--
--		when wr_2_set =>
--				address 			<= x"00001550";
--				DATA    			<= x"0055";
--				FLASH_RST_L 	<= '1';
--				FLASH_OE_L  	<= '1';
--				FLASH_WE_L  	<= '0';
--				FLASH_CE_L	<= '1';
--	 		next_state <= wr_2_cs ;
--		when wr_2_cs =>
--				address 			<= x"00001550";
--				DATA    			<= x"0055";
--				FLASH_RST_L 	<= '1';
--				FLASH_OE_L  	<= '1';
--				FLASH_WE_L  	<= '0';
--				FLASH_CE_L	<= '0';
--			next_state <= wr_2_hld ;
--		when wr_2_hld =>
--				address 			<= x"00001550";
--				DATA    			<= x"0055";
--				FLASH_RST_L 	<= '1';
--				FLASH_OE_L  	<= '1';
--				FLASH_WE_L  	<= '0';
--				FLASH_CE_L	<= '1';
--			next_state <= wr_3_set ;

		when wr_2_set =>
				address 			<= x"00002AA8";
				DATA    			<= x"0090";
				FLASH_RST_L 	<= '1';
				FLASH_OE_L  	<= '1';
				FLASH_WE_L  	<= '0';
				FLASH_CE_L	<= '1';
	 		next_state <= wr_2_cs ;
		when wr_2_cs =>
				address 			<= x"00002AA8";
				DATA    			<= x"0090";
				FLASH_RST_L 	<= '1';
				FLASH_OE_L  	<= '1';
				FLASH_WE_L  	<= '0';
				FLASH_CE_L	<= '0';
			next_state <= wr_2_hld ;
		when wr_2_hld =>
				address 			<= x"00002AA8";
				DATA    			<= x"0090";
				FLASH_RST_L 	<= '1';
				FLASH_OE_L  	<= '1';
				FLASH_WE_L  	<= '0';
				FLASH_CE_L	<= '1';
			next_state <= rd_1_set ;
		when  rd_1_set =>
				address 			<= x"00000001";
				DATA    			<= (others => 'Z');
				FLASH_RST_L 	<= '1';
				FLASH_OE_L  	<= '0';
				FLASH_WE_L  	<= '1';
				FLASH_CE_L	<= '0';
					next_state <= rd_1_cs ;
		when rd_1_cs =>
				address 			<= x"00000001";
				DATA    			<= (others => 'Z');
				FLASH_RST_L 	<= '1';
				FLASH_OE_L  	<= '0';
				FLASH_WE_L  	<= '1';
				FLASH_CE_L	<= '0';
			next_state <= rd_1_hld ;
		when rd_1_hld =>
				address 			<= x"00000001";
				DATA    			<= (others => 'Z');
				FLASH_RST_L 	<= '1';
				FLASH_OE_L  	<= '0';
				FLASH_WE_L  	<= '1';
				FLASH_CE_L	<= '0';
				FLASH_DATA 		<= DATA;
					next_state <= rd_1_done ;
		when rd_1_done =>
			if FLASH_START_TEST = '0' then
				next_state <= wait_for_test;
			else
				next_state <= rd_1_done;
			end if;
				FLASH_COMPARE 	<= '1';
				address 			<= x"00000001";
				DATA    			<= (others => 'Z');
				FLASH_RST_L 	<= '1';
				FLASH_OE_L  	<= '0';
				FLASH_WE_L  	<= '1';
				FLASH_CE_L	<= '1';

			if FLASH_DATA = x"0017"  then
				FLASH_PASS_TEST <= '1' ;
				FLASH_FAIL_TEST <= '0' ;
			else
				FLASH_PASS_TEST <= '0' ;
				FLASH_FAIL_TEST <= '1' ;
			end if;
		end case;
	end if;
end process;

end logic;


