--======================================================================================
-- Design Units	      : Virtex-II Dev Board DIP/LED test
--
-- Filename             : DIP_LED_test.vhd
--
-- Purpose              : This module tests the DIP switch S1 and the LEDs D(1-8) 
--			  
-- Notes                : 
--
-- Limitations          :
--
-- Errors               :
--
-- Naming               : 
-- convention
--
-- Library              :
--
-- Dependencies         : IEEE.Std_Logic_1164,  IEEE.STD_LOGIC_ARITH, IEEE.STD_LOGIC_UNSIGNED
--
-- Sub Modules          : None
--
-- Author               : Matt Schultz
--                        Avnet Design Services
--
-- Simulator            :
--
-- Disclaimer           :Avnet, Inc. makes no warranty for the use of this code or design.  
--								 This code is provided  "As Is". Avnet, Inc assumes no responsibility for 
--								 any errors, which may appear in this code, nor does it make a commitment 
--								 to update the information contained herein. Avnet, Inc specifically 
--								 disclaims any implied warranties of fitness for a particular purpose.
--              			 Copyright (c) 2000 Avnet, Inc.
--               			 All rights reserved.
--
--
------------------------------------------------------------------------------------------
-- Revision list
-- Version		Author		Date			Changes
--
-- 1.0			MRS         11/17/00    Initial Release
-- 2.0			MAM			06/25/01	Modified for sample source code release and to
--										execute under "LED scan" mode
-- 3.0			MAM			12/19/01	Modified for use on the Virtex-II Development Brd
------------------------------------------------------------------------------------------
-----------------------------------------------------------------
--                     Test Modes                              --
--                                                             --
--    DIP Switch (S1)- 1 2     Mode                            --
--                     0 0     IDLE                            --
--                     1 0     LED scan                        --
--                     1 1     DIP switches                    --
-----------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity DIP_LED_test is
    Port ( 
	 	CLK_40MHZ					: in STD_LOGIC;
	 	LED					: out STD_LOGIC_VECTOR (7 downto 0); 
    	SWITCH				: in STD_LOGIC_VECTOR (7 downto 0)
	 );
end DIP_LED_test;

architecture DIP_LED_arch of DIP_LED_test is

signal SCAN_LED	: STD_LOGIC_VECTOR (7 downto 0);
signal CLR_LED		: STD_LOGIC_VECTOR (7 downto 0);
signal COUNTER		: STD_LOGIC_VECTOR (21 downto 0);
signal RIGHT		:std_logic;

begin

CLR_LED <= "10101010";

process (CLK_40MHZ)
begin

-----------------------------------------------------------------
--                    LED Test                                 --
--        When S1, switch 1 on: start scanning.                --
----------------------------------------------------------------- 

   if CLK_40MHZ'event and CLK_40MHZ='1' then  --CLK rising edge
		if SWITCH(0) = '1' then
			if (SWITCH(0) = '1' and SWITCH(1) = '0') then --and SWITCH(2) = '0') then
					LED <= SCAN_LED;
-----------------------------------------------------------------
--                      DIP Switch Test                        --
--                   When S1, switch 3 on:                     --
--                    S1-3 lights LED-D3                       --
--                    S1-4 lights LED-D4                       --
--                    S1-5 lights LED-D5                       --
--                    S1-6 lights LED-D6                       --
--                    S1-7 lights LED-D7                       --
--                    S1-8 lights LED-D8                       --
-----------------------------------------------------------------

			elsif (SWITCH(0) = '1' and SWITCH(1) = '1') then --and SWITCH(2) = '0') then
					if SWITCH(1) = '1' then
--						LED <= CLR_LED;
						LED <= "00000011";
						if SWITCH(2) = '1' then
							LED(2) <= '1';
							if SWITCH(3) = '1' then
								LED(3) <= '1';
								if SWITCH(4) = '1' then
									LED(4) <= '1';
									if SWITCH(5) = '1' then
										LED(5) <= '1';
										if SWITCH(6) = '1' then
											LED(6) <= '1';
											if SWITCH(7) = '1' then
												LED(7) <= '1';
											end if;
										end if;
									end if;
								end if;
							end if;
						end if;
					else
					LED <= CLR_LED;
					end if;
			end if;
		else
			LED <= "11110000";
  		end if;
	end if;
end process;

-- Is the LED currently going left to right or right to left?
process (CLK_40MHZ)
begin

if CLK_40MHZ'event and CLK_40MHZ='1' then  --CLK rising edge
  	if counter = "111111111111111111110" then
		if SCAN_LED(0) = '1' then
				RIGHT <= '1';
		elsif SCAN_LED(7) = '1' then
				RIGHT <= '0';
		end if;
	end if;
end if;
end process;

--  Rotate the LED display according to the direction.
process (CLK_40MHZ,SWITCH)
begin
if SWITCH(0) = '0' then
	SCAN_LED <= "00000001";
elsif CLK_40MHZ'event and CLK_40MHZ='1' then  --CLK rising edge
			counter <= counter + "0000000000000000000001";
	if counter = "111111111111111111111" then
		if RIGHT = '1' then
				SCAN_LED <= SCAN_LED(6 downto 0) & SCAN_LED(7); 
		else
				SCAN_LED <= SCAN_LED(0) & SCAN_LED(7 downto 1);
		end if; 
	end if;
end if;
end process;

end DIP_LED_arch;



