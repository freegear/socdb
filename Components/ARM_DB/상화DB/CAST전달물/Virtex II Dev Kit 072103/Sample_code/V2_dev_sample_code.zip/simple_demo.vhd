--======================================================================================
-- Design Units	        : SP_II_DEMO
--
-- Filename             : simple_demo.vhd
--
-- Purpose              : This module controls simple demos to demostrate the Spartan-II 
--			  Evaluation Board.
--
-- Notes                : 
--
-- Limitations          :
--
-- Errors               :
--
-- Naming               : Active low signals are indicated by _N.
-- convention
--
-- Library              :
--
-- Dependencies         : IEEE.Std_Logic_1164, IEEE.STD_LOGIC_UNSIGNED
--
-- Sub Modules          : message, 

-- Author               : Rob Owens
--                        Avnet Design Services
--
-- Simulator            :
--
-- Disclaimer           :Avnet, Inc. makes no warranty for the use of this code or design.  
--			This code is provided  "As Is". Avnet, Inc assumes no responsibility for 
--			any errors, which may appear in this code, nor does it make a commitment 
--			to update the information contained herein. Avnet, Inc specifically 
--			disclaims any implied warranties of fitness for a particular purpose.
--              	Copyright (c) 2000 Avnet, Inc.
--               	All rights reserved.
--
--
------------------------------------------------------------------------------------------
-- Revision list
-- Version		Author		Date		Changes
--
-- 1.0			RCO           10-02-99          Initial Release
------------------------------------------------------------------------------------------		

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;


entity UART is
port (RESET_L :in STD_LOGIC;
    	CLK_40MHZ		: in STD_LOGIC;
    	LED		: out STD_LOGIC_VECTOR (5 downto 0);
    	SWITCH		: in STD_LOGIC_VECTOR (4 downto 0);
--	DATA_OUT	: out STD_LOGIC_VECTOR(7 downto 0);
	RS232_IN		: in STD_LOGIC;
	RS232_OUT		: out STD_LOGIC;
--	ENABLE_N	: out STD_LOGIC;
--	DEACTIVATE_N	: out STD_LOGIC;
	FLASH_START_TEST	: out std_logic;
	FLASH_PASS_TEST	: in std_logic;
	FLASH_FAIL_TEST	: in std_logic
);
end UART;

architecture UART_arch of UART is

--signal TEMP_CLK		: std_logic;
signal LED_INT		: std_logic_vector(4 downto 0);
signal BUTTON		: std_logic;
signal MESS_ENABLE	: std_logic;
signal MESS_DONE	: std_logic;
--signal SCAN_LED		: STD_LOGIC_VECTOR (7 downto 0);
signal COUNTER		: STD_LOGIC_VECTOR (21 downto 0);
signal RIGHT		:std_logic;

type states is (IDLE,SEND_MESSAGE);
signal current_state: states;

type TEMPERATURE_STATES is (TEMP_IDLE,TEMP_SETUP,TEMP_SETUP_COMPLETE,TEMP_GET_DATA,TEMP_GET_DATA_COMPLETE);
signal TEMP_state	: TEMPERATURE_STATES;

--  Display message
component message
port (
	RESET_L		: in	std_logic;
	CLK_40MHZ	: in    std_logic;

	MESS_ENABLE	: in    std_logic;
	MESS_DONE	: out   std_logic;

	SER_IN		: in 	STD_LOGIC;
	SER_OUT		: out 	STD_LOGIC;
	LED			: out STD_LOGIC_VECTOR(5 downto 0);
--	ENABLE_N	: out 	STD_LOGIC;
--	DEACTIVATE_N	: out 	STD_LOGIC;
	
	FLASH_START_TEST	: out std_logic;
	FLASH_PASS_TEST	: in std_logic;
	FLASH_FAIL_TEST	: in std_logic
	);
end component;

begin

LED(5) <= SWITCH(1);
LED(4) <= LED_INT(4);
LED(3) <= LED_INT(3);
LED(2) <= LED_INT(2);
LED(1) <= LED_INT(1);
LED(0) <= LED_INT(0);


--DATA_OUT <= SWITCH (7 downto 0);

--BUTTON <= SWITCH(1);
--RESET_L <= SWITCH(0);
--LED(2) <= '1';
--LED(3) <= '1';
-- Start display message when button is pressed.
process (RESET_L,CLK_40MHZ)
begin
   if RESET_L = '0' then
	current_state <= IDLE;
	MESS_ENABLE <= '0';
   elsif CLK_40MHZ'event and CLK_40MHZ='1' then  --CLK_40MHZ rising edge
BUTTON <= SWITCH(1);
--RESET_L <= SWITCH(0);
	   case current_state is
	      when IDLE =>
	         MESS_ENABLE <= '0';
	         if BUTTON = '1' then
	         	current_state <= SEND_MESSAGE;
	         else
	         	current_state <= IDLE;
	         end if;
	      when SEND_MESSAGE =>
	         if MESS_DONE = '1' then
			current_state <= IDLE;	
			MESS_ENABLE <= '0';
		else
			current_state <= SEND_MESSAGE;
			MESS_ENABLE <= '1';
		end if;
	   end case;
   end if;
end process;



START_BOY: message
port map(
	RESET_L 		=> RESET_L,
	CLK_40MHZ 		=> CLK_40MHZ,
	MESS_ENABLE 	=> MESS_ENABLE,
	MESS_DONE 	=> MESS_DONE,
	LED			=>	LED_INT,
	SER_IN 		=> RS232_IN,
	SER_OUT 		=> RS232_OUT,
	FLASH_START_TEST	=>	FLASH_START_TEST,
	FLASH_PASS_TEST	=>	FLASH_PASS_TEST,
	FLASH_FAIL_TEST	=> FLASH_FAIL_TEST
	);

   end UART_arch;
