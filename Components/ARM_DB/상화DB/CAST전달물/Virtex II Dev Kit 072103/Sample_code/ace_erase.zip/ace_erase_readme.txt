Ace Erase Utility:
 
(for the Virtex-II Development Board from Avnet Design Services)

Running the Ace Erase batch file (ace_erase.bat) will erase the flash inside the System ACE MPM device.  Ace Erase is meant as a temporary solution for System ACE MPM erasure until the Xilinx ISE 5.1i tools are available.  Ace Erase makes use of two parallel port drivers.  The giveio driver (included in this zip file) is required if using Windows NT or 2000.  The giveio driver is not necessary if using Windows '95 or '98.  Installation instructions for the giveio driver are included below.  The second driver used is for the Xilinx iMPACT software and is automatically installed during the installation of the Xilinx ISE software.  System ACE MPM requires the Xilinx ISE 4.2i software tools.  Ace Erase requires a Xilinx parallel download cable be connected to the parallel port of the PC and JTAG header on the Virtex-II Development Board (TDI, TDO, TMS, TCK, VCC & GND).  Set the parallel port mode to EPP when using Ace Erase (Ace Erase will not run in ECP mode).

To run Ace Erase, extract all of the files to a folder on the PC that will be used for System ACE MPM programming/erasing.  Open a DOS window and change the directory to the folder containing the extracted files.  Type ace_erase.bat at the prompt and press Enter.  Alternatively you could double-click on the ace_erase.bat file in the folder containing the extracted files.


Giveio driver installation:

Create a new folder and unzip the ace_erase.zip file into it.  You 
can also optionally add the path to your Autoexec.bat file (requires 
reboot for path to take affect).  No other action is required for
operation on Windows 95* and Windows 98*.

For Windows 2000* login to an account with Administrator privileges 
copy the giveio.sys file to: %systemroot%\system32\drivers.  Click 
Start, point to Settings, click to Control Panel, click Add/Remove 
Hardware, click next, select Add/Troubleshoot a device and click 
next, select 'Add a new device' and click next, select 'No, I want 
to select the hardware from a list' and click next, select Other 
devices and click next, click 'Have Disk...', click 'Browse...', 
locate the folder where ace_erase.zip was unpacked to, open giveio.inf, 
click 'OK', click next, click next again, finally click Finish.  
This completes the installation for Windows2000.

For Windows NT* login to an account with Administrator privileges, 
open a DOS* window and change directory to the same folder as 
the ace_erase.ZIP file was unpacked to.  Copy giveio.sys to 
%systemroot%\system32\drivers, then run install the driver 
using the instdrv utility specifying the driver name and the 
FULL PATH NAME to the giveio.sys file.  Example: 

  C:\ace_erase>copy giveio.sys %systemroot%\system32\drivers\giveio.sys
        1 file(s) copied.
  C:\ace_erase>dir %systemroot%\system32\drivers\giveio.sys
   Volume in drive C has no label.
   Volume Serial Number is 364B-0C45

   Directory of C:\WINNT\system32\drivers

  05/13/00  08:55p                 2,200 giveio.sys
                 1 File(s)          2,200 bytes
                            1,279,771,648 bytes free

  C:\ace_erase>instdrv giveio c:\winnt\system32\drivers\giveio.sys
  CreateService SUCCESS
  StartService SUCCESS
  CreateFile SUCCESS

To enable the driver to start automatically each time you boot, 
click Start, point to Settings, click Control Panel, click Devices, 
select giveio from the list, click Startup..., select Startup Type 
Automatic.


Disclaimer:

Avnet, Inc. makes no warranty for the use of this code or design.  This code is provided  "As Is". Avnet, Inc assumes no responsibility for any errors, which may appear in this code, nor does it make a commitment to update the information contained herein. Avnet, Inc specifically disclaims any implied warranties of fitness for a particular purpose.


