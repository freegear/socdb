echo off
info_print.exe && readmpmheader.exe -tir 8 -hir 6 -tdr 1 -hdr 1 -erase