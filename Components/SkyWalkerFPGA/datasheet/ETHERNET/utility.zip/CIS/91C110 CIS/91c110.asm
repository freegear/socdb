;******************************************************************************
; Card Name: SMSC/Rockwell LAN91C110 Ethernet/Modem PCCard
; Code Name: 
; File Contents: Multifunction CIS
;
;
; $Log: /Software/CIS/SMSC/Source/91C110.ASM $
; 
; 9     2/04/99 1:43p Fwbent
; - Added comment about CIS lenght needed to be less than 512 bytes.
; 
; 7     11/14/98 1:00p Fwbent
;
;
; Update V5:
;   1 - Changed the base for the CCR's in the global CIS to 8000 from 8020, this 
;       was needed for DOS card services
;   **Known problems:
;   1 - The buffer sizes in Func1_tuple 7, 6, and 5 need to be verified
;   2 - The global CIS contains no device type, so DOS CS will not enable the card
;       as a modem only device.  This is GOOD, if this tuple is put in then it will
;       cause trouble on other OS's like the Mac OS.
; Update V4:
;   1 - changed the order of the network and modem and simplified the network cis
;       now works in OSR2
;   **Known problems:
;   1 - The buffer sizes in Func1_tuple 7, 6, and 5 need to be verified
;   2 - The global CIS contains no device type, so DOS CS will not enable the card
;       as a modem only device.  This is OK, if this tuple is put in then it will
;       cause trouble on other OS's like the Mac OS.
; Update V3:
;   1 - Added a LongLink tuple and a new MF CIS segment.  The theory is that the
;       NON-MF Card Services will only parse the Global CIS and the MF Capable
;       Card Services will skip the rest of the global CIS at the LongLink tuple
;       and jump to the MF CIS area.
;   **Known problems:
;   1 - The buffer sizes in Func1_tuple 7, 6, and 5 need to be verified
;   2 - The global CIS contains no device type, so DOS CS will not enable the card
;       as a modem only device.  This is OK, if this tuple is put in then it will
;       cause trouble on other OS's like the Mac OS.
; Update V2:
;   1 - Removed the CISTPL_FUNCID tuple from the global CIS so both functions
;       didn't look like serial devices.
;       This should work correctly under Win95, Win95 OSR2, WinNT4.0
;       MacOS with CM2 or CM3
;   **Known problems:
;   1 - The buffer sizes in Func1_tuple 7, 6, and 5 need to be verified
; Update V1:
;   1 - Created CIS
;   **Known problems:
;   1 - The buffer sizes in Func1_tuple 7, 6, and 5 need to be verified
;
;

;
; Include files
;
.INCLUDE PCCTPL.INC

;
; CIS Version
;
CIS_VERSION EQU 5

;
; The CISTPL_FUNCE LAN function Extension TPLFE_TYPE constants
;

LAN_TECH  EQU  01h
LAN_SPEED EQU  02h
LAN_MEDIA EQU  03h
LAN_NID   EQU  04h
LAN_CONN  EQU  05h

	PUBLIC CIS_ROM_TABLE

CIS_ROM_TABLE:
start_global_tuple1:
	.DB CISTPL_DEVICE
	.DB (start_global_tuple2 - $ - 1)
	.DB 00h
	.DB 0ffh ; End of Tuple

SPECIAL_global_CISTPL_VERS_1:
start_global_tuple2:
	.DB CISTPL_VERS_1
	.DB (start_global_tuple3 - $ - 1)
	.DB 05h         ; TPLLV1_MAJOR     5h, 0h  February 1995
	.DB 00h         ; TPLLV1_MINOR
        .DB "SMSC"
	.DB 00h         ; NULL Terminator
        .DB "LAN91C110 Ethernet+Modem"
;        .DB "56k + 10Mb Ethernet"
	.DB 00h         ; NULL Terminator
        .DB "400071-xxx"
;        .DB "400019-16C"
	.DB 00h         ; NULL Terminator
        .DB "SerialNumber"
;        .DB "123456789abc"
	.DB 00h         ; NULL Terminator
	.DB CIS_VERSION ; CIS Version number
	.DB 0ffh        ; End of Tuple

start_global_tuple3:
	.DB CISTPL_MANFID
	.DB (start_global_tuple4 - $ - 1)
        .DW 0108h       ; SMSC 0108H/Ositech 0140H
        .DW 0133h       ;

;CIS_ROM_3V_HEADER_END:

start_global_tuple4:
	.DB CISTPL_LONGLINK_A
	.DB (start_global_tuple5 - $ - 1)
        .DW (start_MF_tuple1 - CIS_ROM_TABLE) ; The address of the first function
	.DW 00h         ; the high order word of the first function address

; Only none multi-function card and socket services will get here.

start_global_tuple5:
	.DB CISTPL_CONFIG
	.DB (start_global_tuple6 - $ - 1)
	.DB 005h  ; TPCC_SZ   Size Fields - Reserved  : TPCC_RMSZ : TPCC_RASZ
                  ;                            00     :   0001    :    01
        .DB 007h  ; TPCC_LAST - Last Config Table Index 7
        .DB 000h  ; TPCC_RADR - Config register base address, 2Bytes
        .DB 004h  ;    400h
        .DB 077h  ; TPCC_RMSK - Config register Presence Mask, 2Byte
        .DB 000h  ;    0000 0000 0111 0111
                  ;    Offset 0  : MCOR
                  ;    Offset 2  : MCSR
                  ;    Offset 4  : MPRR 
                  ;    Offset 6  : NOT USED
                  ;    Offset 8  : MESR
                  ;    Offset a  : MIO-0
                  ;    Offset c  : MIO-1
                  ;    Offset e  : NOT USED
                  ;    Offset 10 : NOT USED 
                  ;    Offset 12 : NOT USED 

start_global_tuple6:
	.DB CISTPL_CFTABLE_ENTRY
        .DB (SPECIAL_global_LAN_NID - $ - 1)
	.DB 087h  ; TPCE_INDX       Configuration Table Index
                  ;                 Configuration Entry Number :7
                  ;                 NOT Default Configuration
                  ;                 Interface(TPCE_IF) byte follows
	.DB 041h  ; TPCE_IF        I/O Interface,Ready/Busy Active
	.DB 09Dh  ; TPCE_FS        Feature Selection
                  ;                 VCC power description follows
                  ;                 Timing Description follows
                  ;                 IRQ Structure present
                  ;                 A miscellaneous field struct is present
	.DB 07Fh  ; TPCE_PD        Power Description
	.DB 055h  ;                 Nominal supply voltage :5 V
	.DB 0C5h  ;                 Minimum supply voltage
	.DB 04Bh  ;                 (Extension) :4.75 V
	.DB 0D5h  ;                 Maximum supply voltage
	.DB 019h  ;                 (Extension) :5.25 V
	.DB 026h  ;                 Continuous current required :200 mA
	.DB 04Eh  ;                 Max current required averaged over 1 second :450 mA
	.DB 0E6h  ;                 Max current required averaged over 10 milliseconds
	.DB 032h  ;                 (Extension) :650 mA
	.DB 053h  ;                 Power-down current required :0 mA
	.DB 0E7h  ; TPCE_TD         Timing Description
	.DB 05Fh  ;                  Ready/Busy Scale
	.DB 023h  ; TPCE_IO         I/O Description
                  ;                  8-bit,I/O Address Line: 3
	.DB 0B0h  ; TPCE_IR         Interrupt Request, Shared, Level
	.DB 0FFh  ;                  IRQs Allowed
	.DB 0FFh  ;                  IRQs Allowed
	.DB 028h  ; TPCE_MI         Miscellaneous

; We put this here so that the drivers will find
; it without having to know about the CISTPL_LONGLINK_A
; and CISTPL_LONGLINK_MFC tuples.

; BUGBUGBUG
; If we leave this as a CISTPL_FUNCE then will things break,
; since there is no CISTPL_FUNCID tuple before it?

SPECIAL_global_LAN_NID:
;        .DB CISTPL_FUNCE
        .DB 090h       ; OSITECH_TUPLE
        .DB (start_global_end - $ - 1)
        .DB LAN_NID
        .DB 006h  ; Length
        .DB 000h  
        .DB 080h  ; SMSC OUI 00-80-0F-XX-XX-XX
        .DB 00Fh
        .DB 0F0h
        .DB 027h
        .DB 00Dh

start_global_end:
	.DB CISTPL_END
        .DB (start_global_ends - $ - 1)
        .DB 0ffh  ; CISTPL_END for non PC Card 5.0
start_global_ends:
;        .DB 0ffh  ; CISTPL_END for non PC Card 5.0

;******************************************************************************
; MultiFunction Section
;******************************************************************************
start_MF_tuple1:
	.DB CISTPL_LINKTARGET
	.DB (start_MF_tuple2 - $ - 1)
	.DB "CIS" 

start_MF_tuple2:
	.DB CISTPL_LONGLINK_MFC
	.DB (start_MF_end - $ - 1)
	.DB 02h         ; Two functions
	.DB 00h         ; Attributes - NONE
  .DW (start_func2_tuple1 - CIS_ROM_TABLE) ; The address of the "first" function
	.DW 00h         ; the high order word of the first function address

	.DB 00h         ; Attributes - NONE
  .DW (start_func1_tuple1 - CIS_ROM_TABLE) ; The address of the "second" function
	.DW 00h         ; the high order word of the second function address

start_MF_end:
	.DB CISTPL_END
        .DB (start_MF_ends - $ - 1)

start_MF_ends:

;******************************************************************************
; Ethernet CIS
;******************************************************************************

start_func2_tuple1:
	.DB CISTPL_LINKTARGET
	.DB (start_func2_tuple2 - $ - 1)
	.DB "CIS" 

start_func2_tuple2:
	.DB CISTPL_FUNCID
	.DB (start_func2_tuple9 - $ - 1)
	.DB 006h ; TPLFID_FUNCTION Network Adapter
	.DB 000h ; TPLFID_SYSINIT  

start_func2_tuple9:
	.DB CISTPL_CONFIG
	.DB (start_func2_tuple10 - $ - 1)
	.DB 005h  ; TPCC_SZ   Size Fields - Reserved  : TPCC_RMSZ : TPCC_RASZ
                  ;                            00     :   0001    :    01
	.DB 007h  ; TPCC_LAST - Last Config Table Index 1
        .DB 000h  ; TPCC_RADR - Config register base address, 2Byte
        .DB 004h  ;    400h
        .DB 0ffh  ; TPCC_RMSK - Config register Presence Mask, 2Byte
        .DB 003h  ;    0000 0000 0011 0011
                  ;    Offset 0  : ECOR
                  ;    Offset 2  : ECSR
                  ;    Offset 4  : NOT USED
                  ;    Offset 6  : NOT USED
                  ;    Offset 8  : NOT USED
                  ;    Offset a  : EIO-0
                  ;    Offset c  : EIO-1
                  ;    Offset e  : NOT USED 
                  ;    Offset 10 : NOT USED 
                  ;    Offset 12 : NOT USED

start_func2_tuple10:
	.DB CISTPL_CFTABLE_ENTRY
        .DB (start_func2_end - $ - 1)
        .DB 0C7h       ; TPCE_INDX - Value written to COR, Default
        .DB 041h       ; TPCE_IF   - I/O Interface,Ready/Busy Active
	.DB 019h       ; TPCE_FS   - IRQ, IO and Vcc-Power descriptions follow.
	.DB 04fh       ; TPCE_PD   - P.DWnI, StaticI, MaxV, MinV, NomV bytes follow
	.DB 055h       ; TPCE_PD   - Nom V: 5V 
	.DB 0c5h, 04bh ; TPCE_PD   - Min V: 4.75V 
	.DB 0d5h, 019h ; TPCE_PD   - Max V: 5.25V 
	.DB 01eh       ; TPCE_PD   - Static I: 150mA
	.DB 043h       ; TPCE_PD   - P.DWn I: 400uA
        .DB 044h       ; TPCE_IO   - 16bit IO, decoding four address lines
	.DB 0b0h       ; TPCE_IR   - Interrupt: Share, level, Mask
	.DB 0ffh       ; TPCE_IR   - IRQ 0-7 valid
	.DB 0ffh       ; TPCE_IR   - IRQ 8-15 valid

start_func2_end:
	.DB CISTPL_END
        .DB (start_func2_ends - $ - 1)

start_func2_ends:

;******************************************************************************
; Modem CIS
;******************************************************************************
start_func1_tuple1:
	.DB CISTPL_LINKTARGET
	.DB (start_func1_tuple2 - $ - 1)
	.DB "CIS" 

start_func1_tuple2:
	.DB CISTPL_FUNCID
	.DB (start_func1_tuple3 - $ - 1)
	.DB TPLFID_SerialPort   ; TPLFID_FUNCTION
	.DB 000h                ; TPLFID_SYSINIT

start_func1_tuple3:
	.DB CISTPL_FUNCE
	.DB (start_func1_tuple4 - $ - 1)
	.DB 000h ; TPLFE_TYPE Serial Port Description Follows
	.DB 002h ; TPLFE_UA   16550 UART
	.DB 00fh ; TPLFE_UC   All parity supported
	.DB 07fh ; TPLFE_UC   8,7,6,5 bit characters and 1,1.5,2 stop bits supported

start_func1_tuple4:
	.DB CISTPL_FUNCE
	.DB (start_func1_tuple5 - $ - 1)
	.DB 005h ; TPLFE_TYPE Data modem Interface Capabilities Extension
	.DB 01fh ; TPLFE_FC   All - transparent, tx/rx-hw, tx/rx-xon/xoff
	.DB 00fh ; TPLFE_CB   64 byte DCE command buffer
	.DB 000h, 002h, 000h ; TPLFE_EB   DCE-DTE buffer 0x000200 = 512 bytes
	.DB 000h, 002h, 000h ; TPLFE_TB   DTE-DCE buffer 0x000200 = 512 bytes

start_func1_tuple5:
	.DB CISTPL_FUNCE
	.DB (start_func1_tuple6 - $ - 1)
	.DB 006h ; TPLFE_TYPE Fax modem Interface Capabilities Extension
	.DB 01fh ; TPLFE_FC   All - transparent, tx/rx-hw, tx/rx-xon/xoff
	.DB 00fh ; TPLFE_CB   64 byte DCE command buffer
	.DB 000h, 030h, 000h ; TPLFE_EB   DCE-DTE buffer 0x003000 = 12288 bytes
	.DB 000h, 030h, 000h ; TPLFE_TB   DTE-DCE buffer 0x003000 = 12288 bytes

start_func1_tuple6:
	.DB CISTPL_FUNCE
	.DB (start_func1_tuple7 - $ - 1)
	.DB 007h ; TPLFE_TYPE Voice modem Interface Capabilities Extension
	.DB 01fh ; TPLFE_FC   All - transparent, tx/rx-hw, tx/rx-xon/xoff
	.DB 00fh ; TPLFE_CB   64 byte DCE command buffer
	.DB 000h, 030h, 000h ; TPLFE_EB   DCE-DTE buffer 0x003000 = 12288 bytes
	.DB 000h, 030h, 000h ; TPLFE_TB   DTE-DCE buffer 0x003000 = 12288 bytes

start_func1_tuple7:
	.DB CISTPL_FUNCE
	.DB (start_func1_tuple8 - $ - 1)
	.DB 002h ; TPLFE_TYPE Data modem services.
	.DB 00ch, 000h ; TPLFE_UD - Max DTE to UART 230400bps
	.DB 03fh, 01ch ; TPLFE_MS - support:
	   ; |____7____|___6__|____5____|____4_____|____3____|__2___|___1___|____0_____|
	   ; | V.26bis | V.26 | V.22bis | Bell212A | V.22A&B | V.23 | V.21  | Bell 103 |
	   ; |    0    |   0  |    1    |    1     |    1    |  1   |   1   |     1    |
	   ; ===========================================================================
	   ; |   RFU   |  RFU |   RFU   |   V.34   | V.32bis | V.32 |  V.29 |   V.27   |
	   ; |    0    |   0  |    0    |    1     |    1    |  1   |   0   |    0     |
	   ; ===========================================================================
	.DB 003h ; TPLFE_EM - Error Correction: V.42/LAPM and MNP2-4
	.DB 003h ; TPLFE_DC - Data Compression: MNP5 and V.42bis
	.DB 00fh ; TPLFE_CM - Command Sets: AT1, AT2, AT3, MNP AT 
	.DB 007h ; TPLFE_EX - Escapes: BREAK, +++, User defined character
	.DB 000h ; TPLFE_DY - Data encryption: none
	.DB 001h ; TPLFE_EF - End user feature selection: Caller ID 
	.DB 0b5h ; TPLFE_CD - CCITT Country Code: USA
	.DB 0ffh ; TPLFE_CD - CCITT Country Code: end of list

start_func1_tuple8:
	.DB CISTPL_FUNCE
	.DB (start_func1_tuple9 - $ - 1)
	.DB 013h ; TPLFE_TYPE Fax modem services - Class 1.
	.DB 006h, 000h ; TPLFE_UF Max UART rate = 115,200 
	.DB 01fh ; TPLFE_FM Modulation: V.33, V.17, V.29, V.27ter, V.21-C2
	.DB 000h ; TPLFE_FY Encryption: not used
	.DB 07ah, 000h ; TPLFE_FS Feature Selection:
	              ;    File Xfer, polling, voice, error correct, T.6, T.4, T.3
	.DB 0b5h ; TPLFE_CF Country: USA
	.DB 0ffh ; TPLFE_CF Country: End of country list

start_func1_tuple9:
	.DB CISTPL_FUNCE
	.DB (start_func1_tuple10 - $ - 1)
	.DB 023h ; TPLFE_TYPE Fax modem services - Class 2.
	.DB 006h, 000h ; TPLFE_UF Max UART rate = 115,200 
	.DB 01fh ; TPLFE_FM Modulation: V.33, V.17, V.29, V.27ter, V.21-C2
	.DB 000h ; TPLFE_FY Encryption: not used
	.DB 032h, 000h ; TPLFE_FS Feature Selection:
                       ;    polling, voice, T.4     
	.DB 0b5h ; TPLFE_CF Country: USA
	.DB 0ffh ; TPLFE_CF Country: End of country list

start_func1_tuple10:
	.DB CISTPL_FUNCE
	.DB (start_func1_tuple11 - $ - 1)
	.DB 084h ; TPLFE_TYPE Voice modem service - EIA/TIA Class 8
	.DB 006h,000h ; TPLFE_UV Max DTE to UART speed - 115200bps
	.DB 00bh,002h ; TPLFE_SR Sample rate 11.025KHz
	.DB 007h,014h ; TPLFE_SR Sample rate 7.2KHz
	.DB 000h ; TPLFE_SR End of sample rate list
	.DB 010h,000h ; TPLFE_SS Sample Size 16
	.DB 008h,000h ; TPLFE_SS Sample Size 8
	.DB 004h,000h ; TPLFE_SS Sample Size 4
	.DB 002h,000h ; TPLFE_SS Sample Size 2
	.DB 000h ; TPLFE_SS End of Sample Size List
	.DB 000h ; TPLFE_SC Voice Compression Method - none

start_func1_tuple11:
	.DB CISTPL_CONFIG
	.DB (start_func1_tuple12 - $ - 1)
	.DB 005h  ; TPCC_SZ   Size Fields - Reserved  : TPCC_RMSZ : TPCC_RASZ
	         ;                            00     :   0001    :    01
	.DB 007h  ; TPCC_LAST - Last Config Table Index 7
	.DB 020h  ; TPCC_RADR - Config register base address, 2Byte
	.DB 004h  ;    420h
	.DB 077h  ; TPCC_RMSK - Config register Presence Mask, 2Byte
	.DB 000h  ;    0000 0000 0111 0111 
	         ;    Offset 0  : MCOR
	         ;    Offset 2  : MCSR
	         ;    Offset 4  : MPRR 
                 ;    Offset 6  : NOT USED
	         ;    Offset 8  : MESR
	         ;    Offset a  : MIO-0
	         ;    Offset c	: MIO-1
	         ;    Offset e	: NOT USED
	         ;    Offset 10	: NOT USED
                 ;    Offset 12 : NOT USED

start_func1_tuple12:
	.DB CISTPL_CFTABLE_ENTRY
	.DB (start_func1_tuple13 - $ - 1)
        .DB 0C7h  ; TPCE_INDX      Configuration Table Index
	         ;                 Configuration Entry Number :7
	         ;                 Default Configuration
	         ;                 Interface(TPCE_IF) byte follows
	.DB 041h  ; TPCE_IF        I/O Interface,Ready/Busy Active
	.DB 09Dh  ; TPCE_FS        Feature Selection
	         ;                 VCC power description follows
			 ;                 Timing Description follows
			 ;                 IRQ Structure present
			 ;                 A miscellaneous field struct is present
	.DB 07Fh  ; TPCE_PD        Power Description
	.DB 055h  ;                 Nominal supply voltage :5 V
	.DB 0C5h  ;                 Minimum supply voltage
	.DB 04Bh  ;                 (Extension) :4.75 V
	.DB 0D5h  ;                 Maximum supply voltage
	.DB 019h  ;                 (Extension) :5.25 V
	.DB 026h  ;                 Continuous current required :200 mA
	.DB 04Eh  ;                 Max current required averaged over 1 second :450 mA
	.DB 0E6h  ;                 Max current required averaged over 10 milliseconds
	.DB 032h  ;                 (Extension) :650 mA
	.DB 053h  ;                 Power-down current required :0 mA
	.DB 0E7h  ; TPCE_TD         Timing Description
	.DB 05Fh  ;                  Ready/Busy Scale
  .DB 0A3h, 060h, 0e8h, 003h, 007h
;  .DB 023h  ; TPCE_IO         I/O Description
;           ;                  8-bit,I/O Address Line: 3
	.DB 0B0h  ; TPCE_IR         Interrupt Request,Level
	.DB 0FFh  ;                  IRQs Allowed
	.DB 0FFh  ;                  IRQs Allowed
	.DB 028h  ; TPCE_MI         Miscellaneous

start_func1_tuple13:
	.DB CISTPL_CFTABLE_ENTRY
	.DB (start_func1_tuple14 - $ - 1)
  .DB 007h  ; TPCE_INDX      Configuration Table Index
	         ;                 Configuration Entry Number :7
	         ;                 Default Configuration
	         ;                 Interface(TPCE_IF) byte follows
  .DB 008h  ; TPCE_FS        Feature Selection
       ;                 IO field struct is present
  .DB 0A3h, 060h, 0f8h, 003h, 007h
;  .DB 023h  ; TPCE_IO         I/O Description
;           ;                  8-bit,I/O Address Line: 3

start_func1_tuple14:
	.DB CISTPL_CFTABLE_ENTRY
	.DB (start_func1_tuple15 - $ - 1)
  .DB 007h  ; TPCE_INDX      Configuration Table Index
	         ;                 Configuration Entry Number :7
	         ;                 Default Configuration
	         ;                 Interface(TPCE_IF) byte follows
  .DB 008h  ; TPCE_FS        Feature Selection
       ;                 IO field struct is present
  .DB 0A3h, 060h, 0e8h, 002h, 007h

start_func1_tuple15:
	.DB CISTPL_CFTABLE_ENTRY
	.DB (start_func1_tuple16 - $ - 1)
  .DB 007h  ; TPCE_INDX      Configuration Table Index
	         ;                 Configuration Entry Number :7
	         ;                 Default Configuration
	         ;                 Interface(TPCE_IF) byte follows
  .DB 008h  ; TPCE_FS        Feature Selection
       ;                 IO field struct is present
  .DB 0A3h, 060h, 0f8h, 002h, 007h

start_func1_tuple16:
	.DB CISTPL_CFTABLE_ENTRY
	.DB (start_func1_end - $ - 1)
  .DB 007h  ; TPCE_INDX      Configuration Table Index
	         ;                 Configuration Entry Number :7
	         ;                 Default Configuration
	         ;                 Interface(TPCE_IF) byte follows
  .DB 008h  ; TPCE_FS        Feature Selection
       ;                 IO field struct is present
  .DB 023h  ; TPCE_IO         I/O Description
           ;                  8-bit,I/O Address Line: 3


start_func1_end:
	.DB CISTPL_END
        .DB (start_func1_ends - $ - 1)
        .DB 0ffh

start_func1_ends:

        .DB 0ffh        ; pad some 0ffh CISTPL_END at the end
        .DB 0ffh
        .DB 0ffh

CIS_CFG_END:

CIS_LENGTH:		.EQU	CIS_CFG_END-CIS_ROM_TABLE

; NOTE: CIS_LENGTH *MUST* be less than 200H since there is only a
;       instal CIS RAM of 512 bytes in size!

; NOTE: CIS_LENGTH *MUST* be less than 400H otherwise things will
;       break since the CCR registers are located at 400H


