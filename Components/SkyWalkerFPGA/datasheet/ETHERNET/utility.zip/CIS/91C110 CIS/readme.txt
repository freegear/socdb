SMSC LAN91C110 Ethernet + V90 Modem
README.TXT
23/06/1999


How to Flash the Modem
----------------------
1. Compile the 91C110.ASM using MAKECIS.BAT batch file.
2. This will generate an 91C110.S37 file.
3. Enable the modem and use a communications package that can send
   ASCII text files to remote machine.
4. Flash the updated CIS into the modem using AT**5, followed by
   an ASCII upload of the 91C110.S37 file.
5. Power cycle the modem and it should use the newly flashed CIS.


What To Change the in CIS
-------------------------
If you make changes to the CIS, then the Plug and Play signature of
the card might change.  You should refer to the PC99 design guidelines
as to which tuples are used for the calculation.  Microsoft provides
a DTPL program that will calculate the tuple signature.

However, there appear to be discrepencies between what the operating
system calulates and what the DTPL program generates.  The DPLT needs
real mode Card and Socket Service to generate a signature.

So, the best way is to use the HKLM\Enum\PCMCIA registry tree instead
to obtain the correct PnP signature of the PC Card.

Starting with Windows 95 OSR2.0, you can use a new format that uses to
CISTPL_MANFID instead of the calculated checksum.  But both should be
present if the PC Card is to work under Windows 95 Golden and later
versions of Windows.

The PC99 Design Guide, section 12.11 indicates the needed tuples,
and they are the CISTPL_DEVICE, CISTPL_VERS_1, CISTPL_CONFIG,
CISTPL_CFGTABLE_ENTRY, CISTPL_MANFID, and CISTPL_FUNCID tuples.


Tuple that Should Change
------------------------

CISTPL_MANFID
        0108H    Pcmcia Vendor ID (assigned by PCMCIA org)
        0201H    Pcmcia Vendor Information (Vendor Specific)

Most programs will use the CISTPL_MANFID to identify the PC Card as
being a supported card or not.


CISTPL_VERS_1
        "SMSC"                          Manufacturer Name
        "LAN91110 Ethernet/Modem"       Marketing Product Name
        "400071-xxx"                    (Optional) Vendor Specific Part. No.
        "SerialNumber"                  (Optional) Vendor Specific S/N

This is a human readable description of the PC Card.  Must be composed of
ASCII characters greater than ASCII 20h and less than ASCII 7Fh.


OSITECH_TUPLE (90H)
        00-80-0F-xx-xx-xx               Network Node Address
                                        NOTE: Must be guaranteed unique!
                                        00-80-0F SMSC OUI (IEEE assigned)

To find the node address from the CIS, we use the OSITECH_TUPLE (90H)
which is a legacy solution.  Really, it should be using the
CISTPL_FUNCE tuple to find the LAN_NID.  But, we have seen issues with
this approach, and so are using a vendor specific tuple for the network
address.  The layout of this tuple is identical to that of the
CISTPL_FUNCE tuple.

You could have both the OSITECH_TUPLE as well as the CISTPL_FUNCE tuple
if you want, but there is a finite size to the CIS of 200H bytes.


If you have issues or want any help on these drivers ,please contact

Field Application Engineers
Standard Microsystems Corp.

