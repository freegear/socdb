/****************************************************************************************
*
*   Disclaimer   This software code and all associated documentation, comments or other 
*  of Warranty:  information (collectively "Software") is provided "AS IS" without 
*                warranty of any kind. MICRON TECHNOLOGY, INC. ("MTI") EXPRESSLY 
*                DISCLAIMS ALL WARRANTIES EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
*                TO, NONINFRINGEMENT OF THIRD PARTY RIGHTS, AND ANY IMIED WARRANTIES 
*                OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE. MTI DOES NOT 
*                WARRANT THAT THE SOFTWARE WILL MEET YOUR REQUIREMENTS, OR THAT THE 
*                OPERATION OF THE SOFTWARE WILL BE UNINTERRUPTED OR ERROR-FREE. 
*                FURTHERMORE, MTI DOES NOT MAKE ANY REPRESENTATIONS REGARDING THE USE OR 
*                THE RESULTS OF THE USE OF THE SOFTWARE IN TERMS OF ITS CORRECTNESS, 
*                ACCURACY, RELIABILITY, OR OTHERWISE. THE ENTIRE RISK ARISING OUT OF USE 
*                OR PERFORMANCE OF THE SOFTWARE REMAINS WITH YOU. IN NO EVENT SHALL MTI, 
*                ITS AFFILIATED COMPANIES OR THEIR SUPPLIERS BE LIABLE FOR ANY DIRECT, 
*                INDIRECT, CONSEQUENTIAL, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, 
*                WITHOUT LIMITATION, DAMAGES FOR LOSS OF PROFITS, BUSINESS INTERRUPTION, 
*                OR LOSS OF INFORMATION) ARISING OUT OF YOUR USE OF OR INABILITY TO USE 
*                THE SOFTWARE, EVEN IF MTI HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
*                DAMAGES. Because some jurisdictions prohibit the exclusion or 
*                limitation of liability for consequential or incidental damages, the 
*                above limitation may not apply to you.
*
*                Copyright 2003 Micron Technology, Inc. All rights reserved.
*
****************************************************************************************/
 

    parameter tRC_min      =      25;
    parameter tRP_min      =      12;
    parameter tRR_min      =      20;
    parameter tWC_min      =      25;
    parameter tWP_min      =      12;
    parameter tCEA_max     =      25;
    parameter tCLS_min     =      10;
    parameter tCLH_min     =       5;
    parameter tCS_min      =      15;
    parameter tCH_min      =       5;
    parameter tDS_min      =      10;
    parameter tDH_min      =       5;
    parameter tALS_min     =      10;
    parameter tALH_min     =       5;
    parameter tAR_min      =      10;
    parameter tDCBSYR1_min =       0;
    parameter tDCBSYR1_max =    3000;
    parameter tDCBSYR2_min =    3000;
    parameter tDCBSYR2_max =   25000;
    parameter tOH_min      =      15;
	parameter tCOH_min     = tOH_min; //different name for same param
    parameter tREA_max     =      20;
    parameter tREH_min     =      10;
    parameter tRHW_min	   =	 100;
    parameter tRHZ_max     =     100;
    parameter tR_max       =   25000;
    parameter tRST_read    =    5000;
    parameter tRST_prog    =   10000;
    parameter tRST_erase   =  500000;
    parameter tRST_powerup = 1000000;
	parameter tRST_ready   =    5000;
	parameter tRPRE_max    =       0;//not used
    parameter tWB_max      =     100;  
    parameter tWH_min      =      10;  
    parameter tWHR_min     =      60;  

// cache mode ops have special timing
    parameter tWC_cache_min      =      45;
    parameter tWP_cache_min      =      25;
    parameter tWH_cache_min      =      15;  
    parameter tCLS_cache_min     =      25;
    parameter tCLH_cache_min     =      10;
    parameter tCS_cache_min      =      35;
    parameter tCH_cache_min      =      10;
    parameter tDS_cache_min      =      20;
    parameter tDH_cache_min      =      10;
    parameter tALS_cache_min     =      25;
    parameter tALH_cache_min     =      10;
    parameter tCEA_cache_max     =      45;
	parameter tIR_cache_min      =       0;
    parameter tRC_cache_min      =      50;
    parameter tREA_cache_max     =      30;
    parameter tREH_cache_min     =      15;
    parameter tRP_cache_min      =      25;


    parameter PAGE_BITS    =       6;  // 2^6=64
    parameter tBERS_min    = 1500000;
    parameter tBERS_max    = 2000000;
    parameter tDBSY_min    =     500;
    parameter tDBSY_max    =    1000;
    parameter tCBSY_min    =    3000;
    parameter tCBSY_max    =  500000;
    parameter tLBSY_min    =    2000;
    parameter tLBSY_max    =    3000;
    parameter tPROG_typ    =  220000;
    parameter tPROG_max    =  500000;
	parameter tOBSY_max    =   25000;
	parameter NPP		   =	   4;
	parameter tCLR_min     =      10;
	parameter tIR_min      =       0;
	parameter tWW_min      =      30;
	parameter tRHOH_min    =      22;
	parameter tRLOH_min    =       5;
	parameter tADL_min     =      70;
	parameter tCHZ_max     =      30;

	//unused timing parameters for this device
	parameter tFEAT		   =       0;
	//programmable drivestrength timing parameters
	parameter tCLHIO_min   =	   0;
	parameter tCLSIO_min   =       0;
	parameter tDHIO_min    =       0;
	parameter tDSIO_min    =       0;
	parameter tREAIO_max   =       0;
	parameter tRPIO_min    =       0;
	parameter tWCIO_min    =       0;
	parameter tWHIO_min    =       0;
	parameter tWHRIO_min   =       0;
	parameter tWPIO_min    =       0;


    parameter COL_BITS  =     12;
    parameter DQ_BITS =      8;

 parameter NUM_OTP_ROW   =   10;  // Number of OTP pages (valid OTP address between 2h and Bh)

`ifdef G4
    parameter ROW_BITS  =          18;
    parameter BLCK_BITS =          12;  // 
`else `ifdef G8
    parameter ROW_BITS  =          18;
    parameter BLCK_BITS =          12;  //
`else `ifdef G16
    parameter ROW_BITS  =          19;
    parameter BLCK_BITS =          13;  //
`else
	`define G4
	// make G4 default
    parameter ROW_BITS  =          18;
    parameter BLCK_BITS =          12;  // 
`endif `endif `endif

`ifdef FullMem   // Only do this if you require the full memory size.
    parameter NUM_PAGE  =     64;
    parameter NUM_COL   =   2112;
	`ifdef G4
    	parameter NUM_ROW   = 262144;  // PagesXBlocks = 64x4096  for 4G
	`else `ifdef G8
    	parameter NUM_ROW   = 262144;  // PagesXBlocks = 64x4096 per CE  for 8G
	`else `ifdef G16
    	parameter NUM_ROW   = 524288;  // PagesXBlocks = 64x8192 per CE  for 16G
	`endif `endif `endif
`else
    parameter NUM_ROW   =   64;  // smaller value for fast sim load
    parameter NUM_PAGE  =     32;
    parameter NUM_COL   =   128;
`endif

parameter NUM_ID_BYTES = 5;
    parameter READ_ID_BYTE0     =  8'h2c;   // Micron Manufacturer ID
`ifdef G4
	parameter READ_ID_BYTE2     =  8'h90;
	parameter READ_ID_BYTE4	    =  8'h54;
    parameter READ_ID_BYTE1     =  8'hdc; 
`else `ifdef G8
	 parameter READ_ID_BYTE2     =  8'h90;
	 parameter READ_ID_BYTE4	 =  8'h54;
     parameter READ_ID_BYTE1     =  8'hdc;
`else `ifdef G16
	 parameter READ_ID_BYTE2     =  8'hd1;
	 parameter READ_ID_BYTE4	 =  8'h58;
     parameter READ_ID_BYTE1     =  8'hd3;
`endif `endif `endif
     parameter READ_ID_BYTE3     =  8'h95;


parameter FEATURE_SET = 12'b000000111111;
// FEATURE_SET      unused--\\\\\\\\\\\\--basic NAND commands
//                   unused--\\\\\\\\\\--new commands (page rd cache commands)
//                    unused--\\\\\\\\--read ID2
//			   drive strength--\\\\\\--read unique
//			        block lock--\\\\--OTP commands
//						   ONFI--\\--2plane commands


// Preload Pin
//define PRE = 1'b1;

`ifdef G4
	parameter NUM_DIE 	=			1;
	parameter NUM_CE 	=			1;
`else `ifdef G8
	parameter NUM_DIE 	=			2;
	parameter NUM_CE 	=			2;
`else `ifdef G16
	parameter NUM_DIE 	=			4;
	parameter NUM_CE 	=			2;
`endif `endif `endif
