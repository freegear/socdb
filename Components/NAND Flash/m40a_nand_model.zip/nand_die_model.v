/*******************************************************************************
*
*    File Name:  nand_die_model.V
*        Model:  BUS Functional
*    Simulator:  ModelSim
* Dependencies:  parameters.v
*
*        Email:  modelsupport@micron.com
*      Company:  Micron Technology, Inc.
*  Part Number:  MT29F
*
*  Description:  Micron NAND Verilog Model
*
*   Limitation:
*
*         Note:  This model does not model bit errors on read or write
*                Psuedo Pass commands are identical to normal status commands.
*
*   Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY
*                WHATSOEVER AND MICRON SPECIFICALLY DISCLAIMS ANY
*                IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
*                A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
*
*                Copyright � 2006 Micron Semiconductor Products, Inc.
*                All rights researved
*
* Rev  Author          Date        Changes
* ---  --------------- ----------  -------------------------------
* 3.0  smk              10/13/2006  - Update of all previous NAND models. (2.x and below)
*                                     First release of new model capable of 
*                                     supporting all NAND products
*
*******************************************************************************/
`timescale 1ns / 1ps

module nand_die_model (Io, Cle, Ale, Ce_n, We_n, Re_n, Wp_n, Rb_n
`ifdef PRE
   ,Pre
`endif
`ifdef LOCK
   ,Lock
`endif
);

   `include "parameters.v"

    // Device Parameters
	parameter mds = 3'b000;
    parameter PAGESIZE  =NUM_COL;
	//max number of planes that could be supported by this model
	parameter NUM_PLANES = 2;
	//EDO cycle time upper bound
	parameter tEDO_RC = 30;
	parameter MAX_BLOCKS = (1 << BLCK_BITS) -1;

	parameter CMD_BASIC = 4'h0;
	parameter CMD_NEW   = 4'h1;
	parameter CMD_ID2   = 4'h2;
	parameter CMD_UNIQUE= 4'h3;
	parameter CMD_OTP   = 4'h4;
	parameter CMD_2PLANE= 4'h5;
	parameter CMD_ONFI  = 4'h6;
	parameter CMD_LOCK  = 4'h7;
	parameter CMD_DRVSTR= 4'h8;

    // Ports Declaration
    inout  [DQ_BITS - 1 : 0] Io;
    input                      Cle;
    input                      Ale;
    input                      Ce_n;
    input                      We_n;
    input                      Re_n;
    input                      Wp_n;
   `ifdef PRE
	input						Pre;
   `else
	reg   						Pre;
	initial Pre = 1'b0;
   `endif
   `ifdef LOCK
	input						Lock;
   `else
	reg   						Lock;
	initial Lock = 1'b0;
   `endif

    output                     Rb_n;

    reg                        Rb_n;

    reg    [DQ_BITS - 1 : 0] Io_buf;
    assign                     Io = Io_buf;

			 
    reg 			  [1:0] thisDieNumber;
	reg 				    mdsel1, mdsel2;
    reg                     PowerUp_Complete;
    reg                     ResetComplete;
    reg                     die_select;

    // Memory Array
    reg [DQ_BITS - 1 : 0] data_reg[0:NUM_PLANES -1]  [0 : NUM_COL - 1];
    reg [DQ_BITS - 1 : 0] cache_reg[0:NUM_PLANES -1] [0 : NUM_COL - 1];
//    reg [DQ_BITS - 1 : 0] cache_reg [0 : NUM_COL - 1];
    reg [DQ_BITS - 1 : 0] special_array [0 : (1 << COL_BITS) - 1];   //Special array for Read_ID_2 and Read_Unique
    reg [DQ_BITS - 1 : 0] OTP_array [0 : ((1 << COL_BITS) * (NUM_OTP_ROW +2)) - 1];  // OTP array
    reg [DQ_BITS - 1 : 0] mem_array [0 : (NUM_COL * NUM_ROW) - 1];
	reg [(ROW_BITS + COL_BITS) -1 : 0] memory_addr [0 : (NUM_COL * NUM_ROW) - 1];
	reg [(NUM_COL * NUM_ROW)-1 :0] memory_index;
	reg [(NUM_COL * NUM_ROW)-1 :0] memory_used;

	// device parameter limits
	reg [3 : 0] pp_counter [0 : NUM_ROW -1];  // pp_counter[row_addr] = support for # of partial page programming checks
	reg [(ROW_BITS)-1:0] pp_addr [0 : NUM_ROW -1];
	reg [ROW_BITS -1 : 0] pp_index;
	reg [ROW_BITS -1 : 0] pp_used;

	reg [2 : 0] otp_counter [0 : 3];  // otp_counter[row_addr] = support for # of OTP partial page programming checks
	// seq_page[blck_addr] = place holder for last page address programmed in block, used to check for prohibited random page programming
	reg [(PAGE_BITS -1) : 0] seq_page [0 : (1 << BLCK_BITS) -1]; 

    // Command Decode
    reg cmnd_00h, cmnd_05h, cmnd_06h, cmnd_10h, cmnd_11h, cmnd_15h;
    reg cmnd_30h, cmnd_31h, cmnd_35h, cmnd_3Fh, cmnd_60h, cmnd_65h;
    reg cmnd_70h, cmnd_78h, cmnd_7Ah;
    reg cmnd_80h, cmnd_85h, cmnd_90h;
    reg cmnd_A0h, cmnd_A5h, cmnd_AFh; 
    reg cmnd_B8h, cmnd_D0h, cmnd_E0h, cmnd_FFh;
	reg cmnd_23h, cmnd_24h, cmnd_2Ah, cmnd_2Ch;
    reg twoplane_op;             // flag
	reg cache_op;
    reg saw_cmnd_65h;            // flag
    reg saw_cmnd_00h;            // flag
    reg do_read_id_2;            // flag
    reg do_read_unique;          // flag
    reg OTP_write;
    reg OTP_read;
    reg OTP_locked;
	reg disable_md_stat;
    reg LOCKCOMMAND;
    reg LOCKTIGHT;
	reg LOCK_DEVICE;
	reg[BLCK_BITS -1:0] UnlockAddrLower;
	reg[BLCK_BITS -1:0] UnlockAddrUpper;
	reg LockInvert;
    time UnlockTightTimeLow; 
    time UnlockTightTimeHigh; 
	reg disable_multidie_status;
	reg edo_mode;

    // DEBUG
    reg debug;
    reg debug2;   //Io_buf
    reg mcp_debug;
    reg data_debug;
    reg command_debug;
    reg command_debug2;

    // Address Decode
    reg [COL_BITS - 1 : 0] col_addr;
    reg [ROW_BITS - 1 : 0] row_addr;
    reg [COL_BITS - 1 : 0] twoplane_col_addr;
    reg [ROW_BITS - 1 : 0] twoplane_row_addr;
	reg [ROW_BITS - 1 : 0] array_prog_addr [0:NUM_PLANES-1];
	reg [BLCK_BITS - 1: 0] erase_block_addr[0:NUM_PLANES-1];
	reg [ROW_BITS - 1 : 0] otp_prog_addr;
	reg array_prog_2plane;
	reg erase_block_2plane;
	reg [7:0] id_reg_addr;
	reg [ROW_BITS - 1 : 0] cmnd_35h_row_addr;


	// timing checks
	realtime	tm_we_n_r;
	realtime	tm_we_n_f;
	realtime	tm_re_n_r;
	realtime	tm_re_n_f;
	realtime	tm_ce_n_r;
	realtime	tm_ce_n_f;
	realtime	tm_ale_r;
	realtime	tm_ale_f;
	realtime	tm_cle_r;
	realtime	tm_cle_f;
	realtime	tm_io_ztodata;
	realtime	tm_io_datatoz;
	realtime	tm_rb_n_r;
	realtime 	tm_rb_n_f;
	realtime	tm_wp_n;
	realtime	tm_we_ale_r;
	realtime	tm_we_data_r;
	reg			we_adl_active;

	realtime 	tprog_done;
	realtime 	tload_done;
	realtime 	t_readtox;
	realtime	t_readtoz;

    // Read Status (70h || 71h || 78h || 79h)
    reg [DQ_BITS - 1 : 0] status_register;
    // Drive Strength (B8h)
    reg [7 : 0] DriveStrength;

	reg active_plane;
	reg array_prog_done;
	reg otp_prog_done;
	reg array_load_done;
	reg cache_prog_last;

    // Valid Status
    reg col_valid, row_valid, data_valid, cache_valid;

    // Counter
    reg [COL_BITS -1 : 0] col_counter, cache_counter;
    integer addr_start, addr_stop;
    integer delay;
    reg timestep;
    reg [ROW_BITS -1 : 0] j;
    reg [COL_BITS -1 : 0] k;

	reg [3:0] row_rows, col_rows, ADDR_ROWS;

    // Initialization
    initial begin
        PowerUp_Complete = 1'b0;
		ResetComplete = 1'b0;
		cache_prog_last = 1'b0;
		array_load_done = 1'b1;
		array_prog_done = 1'b1;
		active_plane = 1'b0;
		tprog_done = 0;
		tload_done = 0;
		t_readtox = 0;
		t_readtoz = 0;
		timestep = 0;
		edo_mode = 0;
        cmnd_00h = 1'b0;
        cmnd_05h = 1'b0;
        cmnd_06h = 1'b0;
        cmnd_10h = 1'b0;
        cmnd_11h = 1'b0;
        cmnd_15h = 1'b0;
		cmnd_23h = 1'b0;
		cmnd_24h = 1'b0;
		cmnd_2Ah = 1'b0;
		cmnd_2Ch = 1'b0;
        cmnd_30h = 1'b0;
        cmnd_31h = 1'b0;
        cmnd_35h = 1'b0;
        cmnd_3Fh = 1'b0;
        cmnd_60h = 1'b0;
        cmnd_65h = 1'b0;
        cmnd_70h = 1'b0;
        cmnd_78h = 1'b0;
		cmnd_7Ah = 1'b0;
        cmnd_80h = 1'b0;
        cmnd_85h = 1'b0;
        cmnd_90h = 1'b0;
        cmnd_A0h = 1'b0;
        cmnd_A5h = 1'b0;
        cmnd_AFh = 1'b0;
        cmnd_D0h = 1'b0;
        cmnd_E0h = 1'b0;
        cmnd_FFh = 1'b0;

        col_valid = 1'b0;
        col_addr = 0;
        row_valid = 1'b0;
        row_addr = 0;
        data_valid = 1'b0;
        cache_valid = 1'b0;
        twoplane_op  = 1'b0;
		cache_op = 1'b0;
        saw_cmnd_00h = 1'b0;
        saw_cmnd_65h = 1'b0;
        do_read_id_2 = 1'b0;
        do_read_unique = 1'b0;
        addr_start = 0;
        addr_stop = 0;
		active_plane = 1'b0;
		disable_multidie_status = 1'b0;

        Io_buf <= {DQ_BITS{1'bz}};
        
		if (ROW_BITS > 16) row_rows = 3;
		else if (ROW_BITS > 8) row_rows = 2;
		else row_rows = 1;
		
		if (COL_BITS > 16) col_rows = 3;
		else if (COL_BITS > 8) col_rows = 2;
		else col_rows = 1;
		
		ADDR_ROWS = row_rows + col_rows;

        $timeformat (-9, 3, " ns", 1);
		$display("Device is Powering Up ...");
        // Initialize memory array to all FFs
		// also initialize partial page counters to all 00s
		`ifdef MAX_MEM
	        for (j = 0; j <= NUM_ROW - 1; j = j + 1) begin
				pp_counter[j]={4{1'b0}};
        		for (k = 0; k <= NUM_COL - 1; k = k + 1) begin
            			mem_array [{j,k}] = {DQ_BITS{1'b1}};
	        	end
		    end
		`else
	        for (j = 0; j <= NUM_ROW - 1; j = j + 1) begin
				pp_counter[j]={4{1'b0}};
			end
			for(memory_index=0; memory_index < (NUM_ROW * NUM_COL) -1 ; memory_index = memory_index +1) begin
            		mem_array [memory_index] = {DQ_BITS{1'b1}};
			end
		`endif

		for (j=0; j< (NUM_OTP_ROW +2); j=j+1) begin
			otp_counter[j] = 3'b000;
		end
	   	for (j=0; j< MAX_BLOCKS ; j=j+1) begin
	   		seq_page[j] = {PAGE_BITS{1'b0}};
	   	end
		`ifdef MAX_MEM
		`else
    	    memory_used = 0;
			pp_used = 0;
		`endif

        LockInvert = 1;
        UnlockAddrLower = {ROW_BITS{1'b0}};
        UnlockAddrUpper = {ROW_BITS{1'b1}};

		
        OTP_locked    = 0;
        OTP_write     = 0;
        OTP_read      = 0;

        debug = 0;
        debug2 = 0;
        mcp_debug = 0;
        data_debug = 0;
        command_debug = 0;
        command_debug2 = 0;

		mdsel1 = 1'b0;
		mdsel2 = 1'b0;


		case (mds) 
        3'b111 : begin
         			 thisDieNumber = 2'b11;
					 die_select = 1'b0;
				 end
        3'b110 : begin
         		  	 thisDieNumber = 2'b10;
					 die_select = 1'b0;
			 	 end
        3'b101 : begin
           			 thisDieNumber = 2'b01;
					 die_select = 1'b0;
				 end
        3'b100 : begin
           			 thisDieNumber = 2'b00;
					 die_select = 1'b1;
				 end
        3'b011 : begin
           			 thisDieNumber = 2'b01;
					 die_select = 1'b0;
				 end
        3'b010 : begin
           			 thisDieNumber = 2'b00;
					 die_select = 1'b1;
				 end
		3'b000 : begin
           			 thisDieNumber = 2'b00;
					 die_select = 1'b1;
        		 end
		endcase

		`ifdef INIT_MEM
           `ifdef x8
             $readmemh ("data.8.init", mem_array);
             $readmemh ("read_unq.8.init", special_array);
             $readmemh ("otp.8.init", OTP_array);
           `else 
             $readmemh ("data.16.init", mem_array);
             $readmemh ("read_unq.16.init", special_array);
             $readmemh ("otp.16.init", OTP_array);
           `endif
		`else
		   for (j=2; j < (NUM_OTP_ROW+2); j=j+1) begin
        	  for (k = 0; k < NUM_COL; k = k + 1) begin
            		OTP_array [{j,k}] = {DQ_BITS{1'b1}};
        	  end
		   end
       	  for (k = 0; k < 2048; k = k + 1) begin
           		special_array [k] = {DQ_BITS{1'b1}};
       	  end
		`endif
        `ifdef x16
        status_register [15:8] = 8'h00;  // DEFAULT
	`endif
        status_register [6:0] = 7'b1100000;  // DEFAULT:  ready, ready, 0 0 0, success, success
        if (Wp_n == 1'b1) begin
            status_register [7] = 1'b1;
        end else begin
            status_register [7] = 1'b0;
        end
        Io_buf = {DQ_BITS{1'bz}}; 
		clear_cache_register(0);
		clear_cache_register(1);
		clear_data_register(0);
		clear_data_register(1);
        if (debug2) $display("Io_buf Trigger 1"); 
		//Need this 1 step delay so Pre defined in initial block in tb gets set
		#1;
        // this preloads the 1st page into the data register
		if (Pre) begin
			$display ("At time %0t : Starting Power-On Preload ...", $time);
			Rb_n = 1'b0;
			status_register [6:5] = 2'b00;
    	    for (col_counter = 0; col_counter <= NUM_COL - 1; col_counter = col_counter + 1) begin
			`ifdef MAX_MEM
            	data_reg[active_plane] [col_counter] = mem_array [{{ROW_BITS{1'b0}}, col_counter}];
			`else
                if (memory_addr_exists({{ROW_BITS{1'b0}}, col_counter})) begin
                    data_reg[active_plane] [col_counter] = mem_array[memory_index];
                end else begin
                    data_reg[active_plane] [col_counter] = {DQ_BITS{1'b1}};
                end
			`endif
	        end
			go_busy(tRPRE_max-1);
			status_register [6:5] = 2'b11;
	        $display("At time %0t : PO_read complete", $time);
		end

		col_counter = 0;
		Rb_n = 1'bz;

		LOCKTIGHT = 1'b0;
        if (Lock === 1) begin
           LOCKCOMMAND   = 1;   // Lock commands valid if Lock active on power-up
        end else begin
           LOCKCOMMAND   = 0;   // Lock commands valid if Lock active on power-up
        end
		LOCK_DEVICE = 1'b0;
		DriveStrength = 8'h00;
        PowerUp_Complete = 1'b1;
		$display("At time %0t : PowerUp Complete.", $time);
    end   

	//called during reset of a program or erase op
	task corrupt_page;
		input [ROW_BITS -1: 0] tsk_row_addr;
		reg [COL_BITS -1: 0] i;
	begin
	    if (debug) $display("Corrupting addr=%0h due to reset", tsk_row_addr);
		for (i = 0; i<=NUM_COL-1; i=i+1) begin
			`ifdef MAX_MEM
	           	mem_array [{tsk_row_addr, i}] = {DQ_BITS{1'bx}};
			`else
	   		   	if (memory_used == (NUM_ROW*NUM_COL)) begin
     		   		$display ("%t ERROR: Memory overflow.  Write to Address %h with Data %h will be lost.\nYou must increase the NUM_ROWS parameter or define MAX_MEM.", $realtime, {twoplane_row_addr,i}, data_reg[~active_plane][i]);
    	   			$stop(0);
    		    end else begin
            		if (!memory_addr_exists({tsk_row_addr, i})) begin
            			memory_used = memory_used + 1;
                	end
                	memory_addr[memory_index] = {tsk_row_addr, i};
                	mem_array[memory_index] =  {DQ_BITS{1'bx}};
            	end
			`endif
		end
	end
	endtask

	task corrupt_otp_page;
		input [ROW_BITS -1: 0] tsk_row_addr;
		reg [COL_BITS -1: 0] i;
	begin
	    if (debug) $display("Corrupting OTP addr=%0h due to reset", tsk_row_addr);
		for (i = 0; i<=NUM_COL-1; i=i+1) begin
           	OTP_array [{tsk_row_addr, i}] = {DQ_BITS{1'bx}};
		end
	end
	endtask

    // Clear Data Register
    task clear_data_register;
		input plane;
        reg [COL_BITS -1:0] i;
    begin
        for (i = 0; i <= NUM_COL - 1; i = i + 1) begin
           data_reg[active_plane] [i] = {DQ_BITS {1'b1}};  //clear == F's in flash
        end
    end
    endtask

    // Clear Cache Register
    task clear_cache_register;
		input plane;
        reg [COL_BITS -1:0] i;
    begin
        for (i = 0; i <= NUM_COL - 1; i = i + 1) begin
           cache_reg[plane] [i] = {DQ_BITS {1'b1}};
        end
    end
    endtask

	task load_cache_register;
        input twoplanes;
		input assert_busy;
        reg [COL_BITS -1 : 0] i;
	begin
		if (assert_busy) begin
			#tWB_max;
			Rb_n = 1'b0;
		end
        status_register [6:5] = 2'b00;
		if (twoplanes) begin
			//not currently supported in any current design
	        for (i = 0; i <= NUM_COL - 1; i = i + 1) begin
				cache_reg[~active_plane][i] = data_reg[~active_plane][i];
			end
		end
        for (i = 0; i <= NUM_COL - 1; i = i + 1) begin
				cache_reg[active_plane][i] = data_reg[active_plane][i];
		end
		if (assert_busy) begin
			delay = (tDCBSYR1_max);
			go_busy(delay);
		end
		// have to wait if previous data reg load is not done
		if (~array_load_done) begin
			while (~array_load_done) begin
				#1;
			end
		end else begin
			if (assert_busy) begin
				Rb_n = 1'bz; // Device Ready
				status_register[6] = 1'b1;
			end
		end

		//if page read cache mode, need to load next page to data_reg
		if (cmnd_31h && ~cmnd_3Fh) begin
			//will load page from mem, but not drive Rb_n busy (since cache mode)
			if (debug) $display("Loading next page for cache read addr=%0h", row_addr);
			load_data_register(0,1);
		end

	end
	endtask

    // Load Register
    task load_data_register;
        input twoplanes;
        input cache_mode;
        reg [COL_BITS -1 : 0] i;
    begin
        // Random Delay For RB# (tWB)
        if (~cache_mode) begin
           #tWB_max
           Rb_n = 1'b0;
		   status_register[6] = 1'b0;
        end
        data_valid = 1'b0;
        status_register [5] = 1'b0;
		array_load_done = 1'b0;
        if (twoplanes) begin
           if (twoplane_row_addr[PAGE_BITS] == row_addr[PAGE_BITS]) begin
              $display($time, "  ERROR:  TWOPLANE OP A -> LSB's of block addr must be even/odd for dual plane op B1=%h B2=%h LSB1=%h LSB2=%h", twoplane_row_addr, row_addr, twoplane_row_addr[PAGE_BITS], row_addr[PAGE_BITS]);
           end 
           if (twoplane_row_addr[PAGE_BITS-1:0] != row_addr[PAGE_BITS-1:0]) begin
              $display($time, "  ERROR:  TWOPLANE OP A -> page addr must be identical for dual plane op B1=%h B2=%h", twoplane_row_addr, row_addr);
           end 
		   if (twoplane_row_addr[ROW_BITS -1] != row_addr[ROW_BITS -1]) begin
			  $display($time, "  ERROR:  TWOPLANE OP -> MSB's of block addr must be identical for dual plane op  B1=%h  B2=%h  MSB1=%h  MSB2=%h", twoplane_row_addr, row_addr, twoplane_row_addr[ROW_BITS -1], row_addr[ROW_BITS -1]); 
		   end
        end else begin
			//internal data move only allowed within the same plane
			if (cmnd_35h) cmnd_35h_row_addr = row_addr;
		end

        // Read From Memory Array
        for (i = 0; i <= NUM_COL - 1; i = i + 1) begin : col_loop
            if (OTP_read) begin : otp_read
                data_reg[active_plane][i] = OTP_array[{row_addr, i}];

            end else begin
				// cant do any loading if already in special read_id_2 or read_unique states
				// only way out is reset or power down/up
                if (~do_read_id_2 && ~do_read_unique) begin : no_id_2
					if (twoplanes) begin
						`ifdef MAX_MEM
    						data_reg[~active_plane][i] = mem_array [{twoplane_row_addr, i}];
						`else
        					if (memory_addr_exists({twoplane_row_addr,i})) begin
           						data_reg[~active_plane][i] = mem_array[memory_index];
							end else begin
						        data_reg[~active_plane][i] = {DQ_BITS{1'b1}};
						    end
						`endif

					end
					`ifdef MAX_MEM
						data_reg[active_plane] [i] = mem_array [{row_addr, i}];
					`else
    					  if (memory_addr_exists({row_addr,i})) begin
           			         data_reg[active_plane] [i] = mem_array[memory_index];
						  end else begin
				             data_reg[active_plane] [i] = {DQ_BITS{1'b1}};
				          end
						  if (data_debug) begin
						  	$display("At time %t, Read from address=%0h, data=%0h", $time, {row_addr,i}, data_reg[active_plane][i]);
						  end
					`endif
                end else begin
				//else we are in do_read_id_2 or do_read_unique and will be reading out of the special array
				// need to go busy like normal page read
				end // no_id_2
            end // otp_read
        end // col_loop

        OTP_read = 0;

        delay = tR_max;
		if (~cache_mode) begin
			delay = delay - tWB_max;
		end
		tload_done = ($realtime + delay);

        if (cmnd_FFh) begin
            cmnd_reset(1);
        end
    end
    endtask

 	task output_status;
	begin
	if (~Re_n && ~Ce_n && We_n && die_select && ((cmnd_70h === 1'b1) || (cmnd_78h === 1'b1))) begin
		if (debug2) $display ("%0t output status Re_n %0d  Ce_n %0d  We_n %0d  cmnd_70h %0d  Cmnd_78h %0d", $time, Re_n, Ce_n, We_n, cmnd_70h, cmnd_78h);
		if (cmnd_78h && disable_md_stat) begin
			$display("MULTI-DIE STATUS READ IS PROHIBITED DURING AND AFTER POWER-UP RESET AND OTP OPERATIONS.");
		end else begin
		// determine whether CE access time or RE access time dominates
			if (tCEA_max - tREA_max < $realtime - tm_ce_n_f) begin
				if (data_debug) $display("AA negedge RE %t CE %t", $realtime, tm_ce_n_f);
        	    Io_buf <= #tREA_max status_register;
			end else begin
				if (data_debug) $display("BB negedge RE %t CE %t", $realtime, tm_ce_n_f);
        	    Io_buf <= #(tm_ce_n_f + tCEA_max - $realtime) status_register;
			end
		end
	end
	end
    endtask

    // Erase Block
    task erase_block;
        input twoplanes;  // 1=two plane opperation 
        input [BLCK_BITS -1 : 0] block_one;
        input [PAGE_BITS - 1 : 0] page_one;
        input [BLCK_BITS -1 : 0] block_two;
        input [PAGE_BITS - 1 : 0] page_two;
        reg   [COL_BITS - 1: 0]   col;
        reg   [PAGE_BITS - 1 : 0] page;
    begin
        // Random Delay For RB# (tWB)
        #tWB_max;
        Rb_n = 1'b0;   // Go busy
        status_register [6 : 5] = 2'b00;
		erase_block_2plane = 1'b0;
		erase_block_addr[0] = block_one;
		erase_block_addr[1] = block_two;
        if (twoplanes) begin
		   erase_block_2plane = 1'b1;
           if (block_one[0] == block_two[0]) begin
              $display($time, "  ERROR:  TWOPLANE OP B -> LSB's of block addr must be even/odd for dual plane op B1=%h B2=%h LSB1=%h LSB2=%h", block_one, block_two, block_one[0], block_two[0]);
           end 
           if (page_one != page_two) begin
              $display($time, "  ERROR:  TWOPLANE OP B -> page addr must be identical for dual plane op B1=%h P1=%h B2=%h P2=%h", block_one, page_one, block_two, page_two);
           end 
		   if (block_one[BLCK_BITS -1] != block_two[BLCK_BITS -1]) begin
			  $display($time, "  ERROR:  TWOPLANE OP -> MSB's of block addr must be identical for dual plane op  B1=%h  B2=%h  MSB1=%h  MSB2=%h", block_one, block_two, block_one[BLCK_BITS -1], block_two[BLCK_BITS -1]); 
		   end
        end


        if (twoplanes) begin
           if (1) $display("ERASE: DIE=%h Block1=%h Block2=%h 2pOP=%h", thisDieNumber, block_one, block_two, twoplanes);
        end else begin
           if (1) $display("ERASE: DIE=%h Block=%h", thisDieNumber, block_one);
        end

        if (

           ~LOCKCOMMAND 

           || (
                 (LOCKCOMMAND && ~twoplanes &&  LockInvert && ((block_one <  UnlockAddrLower) || (block_one >  UnlockAddrUpper)))
                 || 
                 (LOCKCOMMAND && ~twoplanes && ~LockInvert && ((block_one >= UnlockAddrLower) && (block_one <= UnlockAddrUpper)))
              ) 

           || (
                 (
                    (LOCKCOMMAND && twoplanes &&  LockInvert && ((block_one <  UnlockAddrLower) || (block_one >  UnlockAddrUpper)))
                    || 
                    (LOCKCOMMAND && twoplanes && ~LockInvert && ((block_one >= UnlockAddrLower) && (block_one <= UnlockAddrUpper)))
                 )
                 && 
                 (
                    (LOCKCOMMAND && twoplanes &&  LockInvert && ((block_two <  UnlockAddrLower) || (block_two >  UnlockAddrUpper)))
                    || 
                    (LOCKCOMMAND && twoplanes && ~LockInvert && ((block_two >= UnlockAddrLower) && (block_two <= UnlockAddrUpper)))
                 )
              )


           ) begin

           col = 0;
           page = 0;

           if (twoplanes && debug) $display(" -Erase plane2 (Blk %0d : Page %0d : Col %0d) and plane1:", block_two, page, col);
           if (debug) $display(" -Erase Block (Blk %0d : Page %0d : Col %0d)", block_one, page, col);

           // Erase Memory Array
           repeat (NUM_PAGE) begin
              repeat (NUM_COL) begin
                 if (twoplanes) begin
				 `ifdef MAX_MEM
                 	mem_array [{block_two, page, col}] = {DQ_BITS{1'b1}};
				`else
            		if (memory_used == (NUM_ROW*NUM_COL)) begin
                		$display ("%t ERROR: Memory overflow.  Erase at Address %h will be lost.\nYou must increase the NUM_ROW parameter or define MAX_MEM.", $realtime, {block_two,page,col});
                		$stop(0);
            		end else begin
                		if (!memory_addr_exists({block_two,page,col})) begin
							//memory address not used, so must still be FF, no need to erase
                		end else begin
							//address already exists, clear data
                			memory_addr[memory_index] = {block_two, page, col};
                			mem_array[memory_index] = {DQ_BITS{1'b1}};
						end
            		end
				`endif
					pp_counter[{block_two,page}] = 4'b000;
					seq_page[block_two] = {PAGE_BITS{1'b0}};

                 end
				 `ifdef MAX_MEM
                    mem_array [{block_one, page, col}] = {DQ_BITS{1'b1}};
				`else
            		if (memory_used == (NUM_ROW*NUM_COL)) begin
                		$display ("%t ERROR: Memory overflow.  Erase at Address %h will be lost.\nYou must increase the NUM_ROW parameter or define MAX_MEM.", $realtime, {block_one,page,col});
                		$stop(0);
            		end else begin
                		if (!memory_addr_exists({block_one,page,col})) begin
							//memory address not used, so must still be FF, no need to erase
                    		//memory_used = memory_used + 1;
                		end	else begin
							//address already exists, clear data
	                		memory_addr[memory_index] = {block_one, page, col};
    	            		mem_array[memory_index] = {DQ_BITS{1'b1}};
						end
            		end
				`endif
					//reset partial page counter
					pp_counter[{block_one,page}] = 4'b000;
					//reset sequential page in block counter
					seq_page[block_one] = {PAGE_BITS{1'b0}};

                 col = col + 1'b1;
              end
              col = 0;
              page = page + 1'b1;
           end

           // Delay for RB# (tBERS) that grabs 70, 78, and FF commands while busy
           delay = (tBERS_min);
		   go_busy(delay);

        Rb_n = 1'bz;   // not busy anymore
        status_register [6 : 5] = 2'b11;
		output_status;

       end else begin
		// block was locked and cannot be erase
           if (twoplanes) begin
           		$display("At time %0t : twoplane Not Erasing Block %0h UnlockAddrLowr=%0h UnlockAddrUpr=%0h", $time, block_two, UnlockAddrLower, UnlockAddrUpper);
		   end else begin
           		$display("At time %0t : Not Erasing Block %0h UnlockAddrLowr=%0h UnlockAddrUpr=%0h", $time, block_one, UnlockAddrLower, UnlockAddrUpper);
		   end
           // Random Delay for RB# (tBERS)
           status_register [7] = 1'b0;
           delay = (tLBSY_max - tWB_max);
		   go_busy(delay);
           Rb_n = 1'bz;   // not busy anymore
           status_register [6:5] = 2'b11;
		   if (LOCK_DEVICE) begin
    	       status_register [7] = 1'b0;
		   end else begin
	           status_register [7] = 1'b1;
		   end
       end
	   cmnd_D0h = 1'b0;
    end
    endtask

	//Increment partial page counter
	//input row address
	task inc_otpc;
        input [ROW_BITS - 1 : 0] row_addr_tsk;
		begin
			if (otp_counter[row_addr_tsk] < 4) begin
				otp_counter[row_addr_tsk] = otp_counter[row_addr_tsk] + 1;
				if (data_debug) $display($time, "  OTP  partial page programming : Page=%0h  Count=%d  Limit=%1d", row_addr_tsk, otp_counter[row_addr_tsk], NPP);
			end
			else
				$display($time, "  ERROR : OTP partial page programming limit reached.  Page=%0h  Limit=%1d", row_addr, 4);
		end
	endtask

	//Increment partial page counter
	//input row address
	task inc_pp;
		input [ROW_BITS -1: 0] row_addr_tsk;
		reg [ROW_BITS -1: 0] index;
		begin
			`ifdef MAX_MEM
				index = row_addr_tsk;
			`else
          		if (!pp_addr_exists(row_addr_tsk)) begin
                	pp_used = pp_used + 1;
                end
                pp_addr[pp_index] = row_addr_tsk;
				index = pp_index;
			`endif			
				if (data_debug) $display($time, "  Page=%0h  Count=%d  Limit=%1d", row_addr_tsk, pp_counter[index], NPP);
			if (pp_counter[index] < NPP) begin
				pp_counter[index] = pp_counter[index] + 1;
			end
			else
				$display($time, "  ERROR : partial page programming limit reached.  Block=%0h Page=%0h Limit=%1d", row_addr_tsk[ROW_BITS-1:PAGE_BITS], row_addr_tsk[PAGE_BITS-1:0], NPP);
		end
	endtask
	
	//check block for illegal random page programming
	task check_block;
		input [ROW_BITS -1: 0] row_addr_tsk;
		reg [BLCK_BITS -1: 0] blck_addr_tsk;
		reg [PAGE_BITS -1: 0] page_tsk;
		begin
			blck_addr_tsk = row_addr_tsk[ROW_BITS -1 : PAGE_BITS];
			page_tsk = row_addr_tsk[PAGE_BITS -1 : 0];
			if (page_tsk == seq_page[blck_addr_tsk]) begin 
				// don't need to do anything here, programming to same page already in seq_page block checker
 			end
			else if (page_tsk == (seq_page[blck_addr_tsk] +1)) begin
				// increment page in sequential page checker for this block
				seq_page[blck_addr_tsk] = seq_page[blck_addr_tsk] +1;
				if (data_debug) $display ("At time %t , programming to  Block=%0h  Page=%0h", $time, blck_addr_tsk, page_tsk);
			end else begin
				$display($time, "  ERROR : random page programming within a block is prohibited! Block=%0h  Page=%0h seq_page[blck_addr]", blck_addr_tsk, page_tsk, seq_page[blck_addr_tsk]);
			end
 		end
	endtask


    // Program Page
    task program_page;
        input twoplanes;
		input cache_op;
        reg [COL_BITS - 1: 0] i;
    begin
		if (debug) $display($time, "START CACHE ARRAY PROGRAMMING, twoplanes=%d, cache_op=%d", twoplanes, cache_op);
        // Delay For RB# (tWB)
           #tWB_max;
           Rb_n = 1'b0;
           status_register [6 : 5] = 2'b00;

        for (i = 0; i <= NUM_COL - 1; i = i + 1) begin
			if (twoplanes) begin
				data_reg[~active_plane][i] =  cache_reg[~active_plane] [i];
			end
			data_reg[active_plane][i] = cache_reg[active_plane][i];
		end
		row_valid = 1'b0;
		if (cache_op) begin
		// this is for cache mode program ops
			go_busy(tCBSY_min);	
			while (~array_prog_done) begin
				#1;
			end
            Rb_n = 1'bz;
			//only cache bit in status register changes here
   	        status_register [6] = 1'b1;
		end
		// if cache prog, last program may still be active
		// need to wait for it to finish
		while (~array_prog_done) begin
			#1;
		end
		program_page_from_datareg(twoplanes,cache_op);       
	end
	endtask

    // Program Page
    task program_page_from_datareg;
        input twoplanes;
		input cache_mode;
        reg [COL_BITS - 1: 0] i;
		integer page_count, otp_count;
    begin
		if (debug) $display ($time, "PROGRAM PAGE FROM DATAREG, twoplanes=%d, cache_mode=%d", twoplanes, cache_mode);

		array_prog_done = 1'b0;
		array_prog_2plane = 1'b0;
		array_prog_addr[0] = row_addr;
		array_prog_addr[1] = twoplane_row_addr;

		status_register[5] = 1'b0;
        if (twoplanes) begin
			array_prog_2plane = 1'b1;
           if (twoplane_row_addr[PAGE_BITS] == row_addr[PAGE_BITS]) begin
              $display($time, "  ERROR:  TWOPLANE OP C -> LSB's of block addr must be even/odd for dual plane op B1=%h B2=%h LSB1=%h LSB2=%h", twoplane_row_addr, row_addr, twoplane_row_addr[PAGE_BITS], row_addr[PAGE_BITS]);
           end 
           if (twoplane_row_addr[PAGE_BITS-1:0] != row_addr[PAGE_BITS-1:0]) begin
              $display($time, "  ERROR:  TWOPLANE OP C -> page addr must be identical for dual plane op B1=%b B2=%b", twoplane_row_addr[PAGE_BITS-1:0], row_addr[PAGE_BITS-1:0]);
           end 
		   if (twoplane_row_addr[ROW_BITS -1] != row_addr[ROW_BITS -1]) begin
			  $display($time, "  ERROR:  TWOPLANE OP -> MSB's of block addr must be identical for dual plane op  B1=%h  B2=%h  MSB1=%h  MSB2=%h", twoplane_row_addr, row_addr, twoplane_row_addr[ROW_BITS -1], row_addr[ROW_BITS -1]); 
		   end
        end	else begin
			if (FEATURE_SET[CMD_2PLANE]) begin
				if (row_addr[PAGE_BITS] != cmnd_35h_row_addr[PAGE_BITS]) begin
					$display($time, "  ERROR:  Invalid operation.  Internal Data Move is only allowed within the same plane.  Addr from=%0h  Addr to=%0h", cmnd_35h_row_addr, row_addr);
				end
			end
		end

        if (

           ~LOCKCOMMAND 

           || (
                 (LOCKCOMMAND && ~twoplanes &&  LockInvert && ((row_addr <  UnlockAddrLower) || (row_addr >  UnlockAddrUpper)))
                 || 
                 (LOCKCOMMAND && ~twoplanes && ~LockInvert && ((row_addr >= UnlockAddrLower) && (row_addr <= UnlockAddrUpper)))
              ) 

           || (
                 (
                    (LOCKCOMMAND && twoplanes &&  LockInvert && ((twoplane_row_addr <  UnlockAddrLower) || (twoplane_row_addr >  UnlockAddrUpper)))
                    || 
                    (LOCKCOMMAND && twoplanes && ~LockInvert && ((twoplane_row_addr >= UnlockAddrLower) && (twoplane_row_addr <= UnlockAddrUpper)))
                 )
                 && 
                 (
                    (LOCKCOMMAND && twoplanes &&  LockInvert && ((row_addr <  UnlockAddrLower) || (row_addr >  UnlockAddrUpper)))
                    || 
                    (LOCKCOMMAND && twoplanes && ~LockInvert && ((row_addr >= UnlockAddrLower) && (row_addr <= UnlockAddrUpper)))
                 )
              )


           ) begin

		   page_count = 1'b0;
		   otp_count = 1'b0;
           // Write to Memory Array
           for (i = 0; i <= NUM_COL - 1; i = i + 1) begin
               if (OTP_write) begin
                   if (OTP_locked) begin
                       $display("At time %0t: Error: OTP Program FAILED - OTP Protected! Data Register1 %0h = %0h", $time, i, data_reg[active_plane] [i]);
                       status_register [7 : 5] = 3'b011;
				   end else if ((8'h02 > row_addr[(PAGE_BITS -1):0]) || (8'h0B < row_addr[(PAGE_BITS -1):0])) begin
					   $display("At time %0t: Error: OTP Prorgram FAILED - OTP page address out of bound! Page address = %0h", $time, row_addr[(PAGE_BITS-1):0]);
                     end else begin
					 // only program if OTP data is still FF's
					 if (&OTP_array[{row_addr,i}]) begin
					   otp_prog_addr = row_addr;
					   otp_prog_done = 1'b0;
                       OTP_array [{row_addr, i}] = data_reg[active_plane] [i];
					   if (otp_count == 0) inc_otpc(row_addr);
					   otp_count = 1'b1;
                       if (data_debug) $display("At time %0t : OTP Program from Data Register %0h = %0h", $time, i, data_reg[active_plane] [i]);
				     end else begin
						// if OTP data is not FF's, report error if data reg is trying to program new values
						if (~(&data_reg[active_plane][i])) begin
					   		$display($time, "  ERROR : OTP program attempted to write to previously programmed address = %0h.  Cannot overwrite.", row_addr);
						end
				     end
                   end
               end else begin
	               if (data_debug) $display("At time %0t : Program 1st Plane from cache_reg (%0h : %0h : %0h) = %0h", $time, twoplane_row_addr [(ROW_BITS -1) : (PAGE_BITS)], twoplane_row_addr [(PAGE_BITS -1) : 0], i, data_reg[~active_plane][i]);
                   if (data_debug) $display("At time %0t : Program 2nd Plane from Data Reg (%0h) = %0h", $time, i, data_reg[active_plane] [i]);
				   if (twoplanes) begin
						//first do twoplane program if needed
		    		   `ifdef MAX_MEM
    		               	mem_array [{twoplane_row_addr, i}] = data_reg[~active_plane][i] & mem_array [{twoplane_row_addr, i}];
					   `else
	            		   	if (memory_used == (NUM_ROW*NUM_COL)) begin
    	            	   		$display ("%t ERROR: Memory overflow.  Write to Address %h with Data %h will be lost.\nYou must increase the NUM_ROWS parameter or define MAX_MEM.", $realtime, {twoplane_row_addr,i}, data_reg[~active_plane][i]);
        	        			$stop(0);
            			    end else begin
                				if (!memory_addr_exists({twoplane_row_addr, i})) begin
                    				memory_used = memory_used + 1;
                				end
                				memory_addr[memory_index] = {twoplane_row_addr, i};
                				mem_array[memory_index] =  data_reg[~active_plane][i] & mem_array [memory_index];
            				end
						`endif

					   if (page_count == 0) begin
					          inc_pp(twoplane_row_addr);
							  check_block(twoplane_row_addr);
							  page_count = 1;
					   end
           		   end
				   //now do the regular page program
				   if (data_debug) $display("At time %t, programmed %0h to memory location (%0h, %0h, %0h)", $time, data_reg[active_plane][i],  row_addr [(ROW_BITS -1) : (PAGE_BITS)], row_addr [(PAGE_BITS -1) : 0], i);
	    		   `ifdef MAX_MEM
       		        	mem_array [{row_addr, i}] = data_reg[active_plane] [i] & mem_array [{row_addr, i}];
				   `else
           				if (memory_used == (NUM_ROW*NUM_COL)) begin
               				$display ("%t ERROR: Memory overflow.  Write to Address %h with Data %h will be lost.\nYou must increase the MEM_BITS parameter or define MAX_MEM.", $realtime, {row_addr,i}, data_reg[active_plane][i]);
               				$stop(0);
           				end else begin
               				if (!memory_addr_exists({row_addr, i})) begin
                   				memory_used = memory_used + 1;
               				end
               				memory_addr[memory_index] = {row_addr, i};
               				mem_array[memory_index] =  data_reg[active_plane] [i] & mem_array [memory_index];
           				end
				   `endif
				   if (page_count == 0) begin
				          inc_pp(row_addr);
						  check_block(row_addr);
						  page_count = 1;
				   end
			   end
           end
           
			if (debug2) $display("memory_used is %0d", memory_used);

           OTP_write = 0;
           // Set Delay for RB# (tPROG)
           if (cmnd_10h || cmnd_11h || cmnd_15h || cmnd_A0h) begin
                   if  (cmnd_10h) begin
                       delay = tPROG_typ;
                   end else if (cmnd_15h) begin
                       delay = tCBSY_max;
                   end else if (cmnd_11h) begin
                       delay = tDBSY_max;
				   end else if (cmnd_A0h) begin
					   delay = tOBSY_max;
                   end
				   tprog_done = ($realtime + delay);
                   if (cmnd_10h) begin 
                   		cmnd_10h = 1'b0;
                   end else if (cmnd_15h) begin
                        cmnd_15h = 1'b0;
                   end

               end 
        end else begin
		// else if block is locked
           if (twoplanes) begin
              $display("At time %0t : twoplane Not Programing Block %0h UnlockAddrLowr=%0h UnlockAddrUpr=%0h", $time, twoplane_row_addr, UnlockAddrLower, UnlockAddrUpper);
              $display("At time %0t : twoplane Not Programing Block %0h UnlockAddrLowr=%0h UnlockAddrUpr=%0h", $time, row_addr, UnlockAddrLower, UnlockAddrUpper);
           end else begin
           	  $display("At time %0t : LOCKED: Not Programing Block 0x%0h UnlockAddrLowr=%0h UnlockAddrUpr=%0h, invert=%0d", $time, row_addr[BLCK_BITS-1:PAGE_BITS], UnlockAddrLower, UnlockAddrUpper, LockInvert);
		   end
		   status_register [7] = 1'b0;
		   array_prog_done = 1'b1;
		   delay = tLBSY_max;
		   go_busy(delay);
           Rb_n = 1'bz;   // not busy anymore
           status_register [6:5] = 2'b11;
		   if (LOCK_DEVICE) begin
    	       status_register [7] = 1'b0;
		   end else begin
	           status_register [7] = 1'b1;
		   end

        end
     end
     endtask


	task finish_array_prog;
	begin
		if (debug) $display($time, "PROGRAM DATA REG DONE.");
		if (~cache_prog_last) begin
	    	Rb_n = 1'bz; // Device Ready
			status_register [6 : 5] = 2'b11;		   
		  	output_status;
		end else begin
			cache_prog_last = 1'b0;
		end
	end
	endtask

	task finish_array_load;
	begin
		if (debug) $display($time, "ARRAY LOAD COMPLETE.");
		Rb_n = 1'bz;
		status_register[6:5] = 2'b11;
		output_status;
	end
	endtask

//reg last_we_n;
//wire #1 last_we_n = We_n;

	task go_busy;
	input delay;
	integer delay;
	reg saw_edge_we_n;
	reg last_we_n;
	begin
		if (debug) $display("busy delay of %d ns ", delay);
		last_we_n = We_n;
    	while (delay) begin  : delay_loop
	    	delay = delay - 1;
			if (last_we_n !== We_n) begin
				saw_edge_we_n = 1'b1;
			end else begin
				saw_edge_we_n = 1'b0;
			end
			last_we_n = We_n;
	        if (Cle && We_n && ~Ale && Re_n && ~Ce_n && saw_edge_we_n) begin
    	    	if ((Io [7 : 0] === 8'h70) || (Io [7 : 0] === 8'h71) && die_select && (cmnd_70h === 1'b0)) begin
        	    	if (debug) $display ("STATUS READ WHILE BUSY : MODE = STATUS");
            	    cmnd_70h = 1'b1;
	            end else if (((Io [7 : 0] === 8'h78) || (Io [7 : 0] === 8'h79)) && ~disable_multidie_status) begin
    	            if (mcp_debug) $display (" die %d : MULTI DIE READ STATUS READ WHILE BUSY : MODE = STATUS", thisDieNumber);
        	        cmnd_78h = 1'b1;
            	    addr_start = col_rows +1;
                	addr_stop  =  ADDR_ROWS;
					row_valid = 1'b0;
    	        end else if (Io [7 : 0] === 8'hFF) begin
        	        $display ("RESET WHILE BUSY - ABORT");
					cmnd_reset(1);
					disable delay_loop;
        	    end
	        end
    	    #1;
	    end
	end
	endtask   


`ifdef MAX_MEM
`else
    function memory_addr_exists;
        input [(ROW_BITS+COL_BITS) -1:0] addr;
        begin : index
			memory_addr_exists = 0;
            for (memory_index=0; memory_index<memory_used; memory_index=memory_index+1) begin
                if (memory_addr[memory_index] == addr) begin
                    memory_addr_exists = 1;
                    disable index;
                end
            end
        end
    endfunction

// this task for partial page hash table
    function pp_addr_exists;
        input [(ROW_BITS) -1:0] addr;
        begin : pp_func
			pp_addr_exists = 0;
            for (pp_index=0; pp_index<pp_used; pp_index=pp_index+1) begin
                if (pp_addr[pp_index] == addr) begin
                    pp_addr_exists = 1;
                    disable pp_func;
                end
            end
        end
    endfunction
`endif

    // Command Reset
    // 0 = power on reset
    // 1 = soft reset 
    task cmnd_reset;
        input reset;
		reg dev_was_busy;
		reg [(ROW_BITS-BLCK_BITS)-1:0] i;
    begin
		cmnd_FFh = 1'b1;
        ResetComplete = 1'b0;
		if (Rb_n === 1'b0) begin
			dev_was_busy = 1'b1;
		end else begin
			dev_was_busy = 1'b0;
		end

        // Delay For RB# (tWB)
			#tWB_max;
			Rb_n = 1'b0;

        if (reset) begin
		// reset during regular op
            // Delay for RB# (tRST)
            if (dev_was_busy) begin
	            if (~array_load_done) begin
    	            delay = tRST_read;
        	    end else if (~array_prog_done) begin
            	    delay = tRST_prog;
					if (array_prog_2plane) begin
						corrupt_page(array_prog_addr[1]);
					end
					if (~otp_prog_done) begin
						corrupt_otp_page(otp_prog_addr);
					end else begin
						corrupt_page(array_prog_addr[0]);
					end
	            end else if (cmnd_D0h) begin
					//when interrupting go_busy task, model is already #1 ahead
    	            delay = (tRST_erase-1);
					for (i=0;i<=NUM_PAGE-1;i=i+1) begin
						if (erase_block_2plane) begin
							corrupt_page({erase_block_addr[1],i});
						end
						corrupt_page({erase_block_addr[0],i});
					end
				end
            end else begin
                delay = tRST_ready;
            end
        end 

        // Read Status
        status_register [6 : 5] = 2'b00;

        // Reset Command
        cmnd_00h = 1'b0;
        cmnd_05h = 1'b0;
        cmnd_06h = 1'b0;
        cmnd_10h = 1'b0;
        cmnd_11h = 1'b0;
        cmnd_15h = 1'b0;
		cmnd_23h = 1'b0;
		cmnd_24h = 1'b0;
		cmnd_2Ah = 1'b0;
		cmnd_2Ch = 1'b0;
        cmnd_30h = 1'b0;
        cmnd_31h = 1'b0;
        cmnd_35h = 1'b0;
        cmnd_3Fh = 1'b0;
        cmnd_60h = 1'b0;
        cmnd_65h = 1'b0;
        cmnd_70h = 1'b0;
        cmnd_78h = 1'b0;
		cmnd_7Ah = 1'b0;
        cmnd_80h = 1'b0;
        cmnd_85h = 1'b0;
        cmnd_90h = 1'b0;
        cmnd_A0h = 1'b0;
        cmnd_A5h = 1'b0;
        cmnd_AFh = 1'b0;
        cmnd_D0h = 1'b0;
        cmnd_E0h = 1'b0;
        cmnd_FFh = 1'b0;

        // Reset Flags
		//die_select = 1'b1;
        col_valid = 1'b0;
        col_addr = 0;
        row_valid = 1'b0;
        row_addr = 0;
        data_valid = 1'b0;
        cache_valid = 1'b0;
        twoplane_op  = 1'b0;
		cache_op = 1'b0;
		disable_md_stat = 1'b0;
        saw_cmnd_00h = 1'b0;
        saw_cmnd_65h = 1'b0;
        do_read_id_2 = 1'b0;
        do_read_unique = 1'b0;
        addr_start = 0;
        addr_stop = 0;
		active_plane = 1'b0;
		otp_prog_done = 1'b1;
		edo_mode = 0;

        Io_buf <= {DQ_BITS{1'bz}};
        if (debug2) $display("Io_buf Trigger 33"); 

        if (reset) begin
			go_busy(delay);
        end else begin
		//else this is a power-on reset
			//multi-die status read disabled after initial reset
			disable_md_stat = 1'b1;
			go_busy(tRST_powerup);
		end

        // Ready
        Rb_n = 1'bz;

        // Read Status
		tprog_done = 0;
		tload_done = 0;
		t_readtox = 0;
		t_readtoz = 0;
		array_prog_done = 1'b1;
		array_load_done = 1'b1;
		timestep = ~timestep; 
        status_register [6 : 5] = 2'b11;

        $display("At time %0t : Reset Complete, die=%0d", $time, thisDieNumber);
     cmnd_FFh = 1'b0;
     ResetComplete = 1'b1;
    end
    endtask

//#############################################################################
// end of tasks, start always blocks
//#############################################################################

	always @ (timestep) begin
		timestep <= #(0.5) ~timestep;
	end

	//instead of non-blocking assignments, the array program and load operations
	//need start and stop times because they can be interrupted by a reset
	//command.  Since we also need interleaved die support, the go_busy delay 
	//loop is also not recommended for these operations.

	always @ (timestep) begin
		if (tprog_done == $realtime) begin
			array_prog_done = 1'b1;
			otp_prog_done = 1'b1;
			finish_array_prog;
		end
		if (tload_done == $realtime) begin
			array_load_done = 1'b1;
			finish_array_load;
		end
		if (t_readtox == $realtime) begin
			Io_buf <= {DQ_BITS{1'bx}};
		end
		if (t_readtoz == $realtime) begin
			Io_buf <= {DQ_BITS{1'bz}};
		end
	end


	// output status register
	always @ (negedge Re_n) begin
		if(~Ce_n && We_n && ((cmnd_70h === 1'b1) || (cmnd_78h === 1'b1)) && die_select) begin
			output_status;
		end
	end


    // Latch Wp_n
    always @ (Wp_n) begin
        status_register [7] = Wp_n;
		tm_wp_n = $realtime;
 		// holding Wp_low locks all block
        UnlockAddrLower = {ROW_BITS{1'b0}};
        UnlockAddrUpper = {ROW_BITS{1'b1}};
        LockInvert = 1;
        if (Wp_n === 1'b0) begin
           UnlockTightTimeLow = $time; 
        end else begin
           UnlockTightTimeHigh = $time; 
           if ((UnlockTightTimeHigh-UnlockTightTimeLow > 100) && FEATURE_SET[CMD_LOCK]) begin
    	       $display ("INFO: LOCK TIGHT disabled - Wp_n low > 100ns");
	           LOCKTIGHT = 1'b0;
           end
        end
    end

    // Address Latch
    always @ (negedge Ale) begin
       if (addr_start >= 6) begin
                             if (die_select) begin
                                if (mcp_debug) $display ("*** Die %d is aware of this address latch sequence", thisDieNumber);
                             end else begin
                                cmnd_00h = 1'b0;
                                cmnd_05h = 1'b0;
                                cmnd_30h = 1'b0;
                                cmnd_90h = 1'b0;
                                cmnd_70h = 1'b0;
                                cmnd_78h = 1'b0;
								cmnd_7Ah = 1'b0;
                                cmnd_80h = 1'b0;
                                cmnd_85h = 1'b0;
                                cmnd_60h = 1'b0;
                                cmnd_A0h = 1'b0;
                                cmnd_A5h = 1'b0;
                                cmnd_AFh = 1'b0;
                                cmnd_B8h = 1'b0;
                             end
       end
    end

    // Address Latch
    always @ (posedge row_valid) begin
	if (FEATURE_SET[CMD_2PLANE]) begin
		active_plane = row_addr[PAGE_BITS];
	end else begin
		active_plane = 1'b0;
	end
    if (cmnd_23h) begin
       UnlockAddrLower = {row_addr[ROW_BITS-1:PAGE_BITS],{PAGE_BITS{1'b0}}}; // remove page bits
	   if (data_debug) $display("UnlockAddrLower = %0h", UnlockAddrLower);
       cmnd_23h = 1'b0;
       end
    if (cmnd_24h) begin
       UnlockAddrUpper = {row_addr[ROW_BITS-1:PAGE_BITS],{PAGE_BITS{1'b0}}}; // remove page bits
       LockInvert = row_addr[0];
	   if (data_debug) $display("UnlockAddrUpper=%0h  LockInvert=%0h", UnlockAddrUpper, LockInvert);
       cmnd_24h = 1'b0;
       end
    end


    // Address Latch
    always @ (posedge We_n) begin
        //if (command_debug) $display ("At time %0t : We_n posedge Address Latch", $time);
        if (~Cle && Ale && ~Ce_n && We_n && Re_n) begin
            if (saw_cmnd_00h) begin
                saw_cmnd_00h = 1'b0;
                col_valid = 1'b0;
                row_valid = 1'b0;
                data_valid = 1'b0;
                addr_start = 1;
                addr_stop = ADDR_ROWS;
            end
			we_adl_active = 1'b0;
			tm_we_ale_r = $realtime;
        end 
        if (~Cle && Ale && ~Ce_n && We_n && Re_n) begin
		    // latch special read_id address (for devices that support ONFI
			if ((addr_start === 1'b1) && (addr_stop === 1'b0)) begin
				id_reg_addr [7:0] = Io [7 : 0];
			end
            // Latch Column
            if (addr_start <= col_rows && addr_start <= addr_stop && ~col_valid) begin
                case (addr_start)
                    1 : col_addr [7 : 0] = Io [7 : 0];
                    2 : col_addr [COL_BITS - 1 : 8] = Io [16 - COL_BITS - 1 : 0];
                endcase

                if (addr_start >= 2) begin
                    col_valid = 1'b1;
                end
            end

            // Latch Row
            if (addr_start >= (col_rows +1) && addr_start <= addr_stop) begin
                case (addr_start)
                    3 : begin
                           row_addr [ 7 : 0] = Io [7 : 0];
                        end
                    4 : begin
                           row_addr [15 : 8] = Io [7 : 0];
						   if (ROW_BITS == 17) begin
									mdsel1 = Io [7];
						   end
                        end
					`ifdef TWO_ROW
					`else
                    5 : begin
                            // G8
                               row_addr [(ROW_BITS -1):16] = Io [(ROW_BITS -1 -16):0];
                               if (~row_valid) begin
                                  mdsel2 = Io [(ROW_BITS -1) -16];
								  if (ROW_BITS > 17) begin
                                  	mdsel1 = Io [(ROW_BITS -2) -16];
								  end
								  if (mcp_debug) $display ("mdsel1 %d  : msdsel2 %d", mdsel1, mdsel2);
                               end
							   if ((NUM_DIE / NUM_CE) == 4) begin
                                  if ( {mdsel2, mdsel1} == thisDieNumber) begin
                                  	die_select = 1'b1;
                                  	if (mcp_debug) $display ("At time %0t : DIE %d ACTIVE", $time, thisDieNumber);
                               	  end else begin
                                  	die_select = 1'b0;
                                  	if (mcp_debug) $display ("At time %0t : DIE %d INACTIVE", $time, thisDieNumber);
                                  end
							   end
							   else if ((NUM_DIE / NUM_CE) == 2) begin
                                  if ( mdsel2 == thisDieNumber[0]) begin
                                  	die_select = 1'b1;
                                  	if (mcp_debug) $display ("At time %0t : DIE %d ACTIVE", $time, thisDieNumber);
                               	  end else begin
                                  	die_select = 1'b0;
                                  	if (mcp_debug) $display ("At time %0t : DIE %d INACTIVE", $time, thisDieNumber);
                                  end
							   end
							   else	begin
                                  die_select = 1'b1;
                                  if (mcp_debug) $display ("At time %0t : DIE %d ACTIVE", $time, thisDieNumber);
							   end
                        end
				    `endif
                endcase
                
                if (debug) $display ("At time %0t : Die %d Latch Address (%0h) = %0h", $time, thisDieNumber, addr_start, Io [7 : 0]);

                if (addr_start >= ADDR_ROWS) begin
                    row_valid = 1'b1;
                end
            end

            // Increase Address Counter
            addr_start = addr_start + 1;
        end
    end


    // Command Latch
    always @ (posedge We_n) begin : cLatch
    	if (Cle && ~Ale && ~Ce_n && We_n && Re_n) begin : latch_Cle
	        if (Rb_n === 1'bz) begin : cLatch_unbusy
                if (command_debug2) $display ("At time %0t : Command Latch Unlock 2, die=%0d", $time, thisDieNumber);

                // Command (00h)
                if (Io [7 : 0] === 8'h00) begin
                    if (command_debug) $display ("At time %0t : die %d Latch Command = 00h", $time, thisDieNumber);

                    // Command (00h -> [00h] -> 30h)
                    //                         -or- 
                    // Command (00h -> [00h] -> 35h)
                    if (~(cmnd_70h || cmnd_78h) && (Rb_n === 1'bz)) begin
						if (cmnd_00h && FEATURE_SET[CMD_2PLANE]) begin
	                        if (mcp_debug) $display ("At time %0t : TWO PLANE Latch Second 00h A Command", $time);
    	    				twoplane_row_addr = row_addr;
							twoplane_op = 1'b1;
						end
	                    // Command ( [00h] -> 30h)
    	                //                         -or- 
        	            // Command ( [00h] -> 35h)
						cmnd_00h = 1'b1;
                        col_valid = 1'b0;
                        row_valid = 1'b0;
                        data_valid = 1'b0;
                        addr_start = 1;
                        addr_stop = ADDR_ROWS;
					end

                    if (~cmnd_00h && (cmnd_70h || cmnd_78h) && (Rb_n === 1'bz)) begin
                        if (command_debug2) $display ("At time %0t : Latch Command 00h B", $time);
                        cmnd_00h = 1'b1;
                        saw_cmnd_00h = 1'b1;
                    end


                    // Terminate Commands
					cmnd_15h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_70h = 1'b0;
                    cmnd_78h = 1'b0;
					cmnd_7Ah = 1'b0;
                    cmnd_B8h = 1'b0;
                    cmnd_80h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_90h = 1'b0;
					active_plane = 1'b0;
					cache_op = 1'b0;
					disable_md_stat = 1'b0;
                end
    
                // Command (05h)
                else if (Io [7 : 0] === 8'h05) begin

                    if (command_debug) $display ("At time %0t : Latch Command = 05h", $time);
    
                    // Command (00h -> 30h -> [05h] -> E0h)
                    if ((cmnd_30h || cmnd_E0h) && row_valid && (Rb_n === 1'bz)) begin
                        cmnd_05h = 1'b1;
                        col_valid = 1'b0;
                        data_valid = 1'b0;
                        addr_start = 1;
                        addr_stop = col_rows;
                    end 

                    cmnd_B8h = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_E0h = 1'b0;
                end

                // Command (06h)
                else if ((Io [7 : 0] === 8'h06) && FEATURE_SET[CMD_2PLANE]) begin

                    if (command_debug) $display ("At time %0t : Latch Command = 06h", $time);


                    // Command ([06h] -> E0h)
                    cmnd_06h = 1'b1;
                    if (command_debug2) $display ("At time %0t : 06h Command", $time);
                    col_valid = 1'b0;
                    row_valid = 1'b0;
                    data_valid = 1'b0;
                    addr_start = 1;
                    addr_stop = ADDR_ROWS;

                    cmnd_30h = 1'b0;
                    cmnd_B8h = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_E0h = 1'b0;
                end
    
    
                // Command (10h)
                else if ((Io [7 : 0] === 8'h10) && die_select) begin

                    if (command_debug) $display ("At time %0t : Latch Command = 10h", $time);
    
					if (cache_op) begin
						cache_prog_last = 1'b1;
					end
                    // Command (A0h -> [10h])
                    if (row_valid && (Rb_n === 1'bz)) begin
                        if (command_debug2) $display ("At time %0t : Latch Command = 10h A", $time);
                        cmnd_10h = 1'b1;
						//program_page
						cache_op = 1'b0;
						if (cmnd_A5h) begin
	                        OTP_locked = 1'b1;
							#tWB_max;
							Rb_n = 1'b0;
					        status_register [6 : 5] = 2'b00;
							go_busy(tPROG_typ);
					        Rb_n = 1'bz;   // not busy anymore
					        status_register [6 : 5] = 2'b11;
						end else begin
							program_page(twoplane_op,cache_op);
						end
					end

                    cmnd_A0h = 1'b0;
                    cmnd_A5h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_80h = 1'b0;
					twoplane_op = 1'b0;
					cache_op = 1'b0;
	            end
    
                // Command (11h)
                else if ((Io [7 : 0] === 8'h11) && FEATURE_SET[CMD_2PLANE]) begin 

                    if (command_debug) $display ("At time %0t : Latch Command = 11h", $time);
    
                    // Command (80h -> [11h])
                    if ((cmnd_80h || cmnd_85h) && row_valid && (Rb_n === 1'bz)) begin
                        twoplane_op = 1'b1;
                        cmnd_11h = 1'b1;
   	                    twoplane_row_addr = row_addr;
						//save twoplane address and data for future write
						//can't actually write to mem_array yet because final program command not seen
						if (cmnd_80h) begin
	                        if (command_debug2) $display ("At time %0t : Latch Command = 11h A", $time);
							cmnd_80h = 1'b0;
						end else begin
							//data already in both cache regs
	                        if (command_debug2) $display ("At time %0t : Latch Command = 11h B", $time);
							cmnd_85h = 1'b0;
						end
						//busy time required to switch planes
						#tWB_max;
						Rb_n = 1'b0;
						status_register[6:5] = 2'b00;
						go_busy(tDBSY_max);
						status_register[6:5] = 2'b11;
						Rb_n = 1'bz;

					end else begin
						// latched 8'h11, but row invalid, device busy, or wrong command sequence
							cmnd_80h = 1'b0;
							cmnd_85h = 1'b0;
					end 

                end
    
                // Command (15h)
                else if ((Io [7 : 0] === 8'h15) && die_select) begin
					 // Command (80h -> (85h) -> [15h]
                    if (cmnd_80h && row_valid && (Rb_n === 1'bz)) begin
    	                if (command_debug2) $display ("At time %0t : Latch Command = 15h A", $time);
                        cmnd_80h = 1'b0;
						cmnd_85h = 1'b0;
                        cmnd_15h = 1'b1;
						cache_op = 1'b1;
                        program_page (twoplane_op, cache_op);
                    end

                    // Terminate Command (80h)
                    else if (cmnd_80h && ~row_valid) begin
	                    if (command_debug2) $display ("At time %0t : Latch Command = 15h B", $time);
                        cmnd_80h = 1'b0;
						cmnd_85h = 1'b0;
                    end
                end

                // Command (23h)
                else if ((Io [7 : 0] === 8'h23) && Wp_n && FEATURE_SET[CMD_LOCK]) begin
                    if (LOCKCOMMAND && ~LOCKTIGHT) begin
                       if (command_debug) $display ("At time %0t Die %d Latch Command = 23h", $time, thisDieNumber);
    
                          cmnd_23h = 1'b1;
                          data_valid = 1'b0;
                          row_valid = 1'b0;
                          col_valid = 1'b0;
                          addr_start = col_rows +1;
                          addr_stop = ADDR_ROWS;
                         
                          cmnd_24h = 1'b0;
                          cmnd_2Ah = 1'b0;
                          cmnd_2Ch = 1'b0;
						  cmnd_15h = 1'b0;
						  cmnd_31h = 1'b0;
				          cmnd_3Fh = 1'b0;
                          cmnd_70h = 1'b0;
                          cmnd_7Ah = 1'b0;
                          cmnd_90h = 1'b0;
                          cmnd_B8h = 1'b0;
						  cache_op = 1'b0;
						  disable_md_stat = 1'b0;
                       end else begin
                       $display ("Warning:  Command 23h - IGNORED - Lock commands are disabled");
                       end
                    end
    
                // Command (24h)
                else if ((Io [7 : 0] === 8'h24) && FEATURE_SET[CMD_LOCK]) begin
                    if (LOCKCOMMAND && ~LOCKTIGHT) begin
                       if (command_debug) $display ("At time %0t Die %d Latch Command = 24h", $time, thisDieNumber);
    				   if (row_valid && (Rb_n === 1'bz)) begin
                          cmnd_24h = 1'b1;
                          data_valid = 1'b0;
                          row_valid = 1'b0;
                          col_valid = 1'b0;
                          addr_start = col_rows +1;
                          addr_stop = ADDR_ROWS;
						  LOCK_DEVICE = 1'b0;
						  status_register[7] = 1'b1;
      
                          cmnd_23h = 1'b0;
                          cmnd_2Ah = 1'b0;
                          cmnd_2Ch = 1'b0;
                          cmnd_70h = 1'b0;
                          cmnd_7Ah = 1'b0;
                          cmnd_90h = 1'b0;
                          cmnd_B8h = 1'b0;
					   end
                    end else begin
                       $display ("Warning:  Command 24h - IGNORED - Lock commands are disabled");
                    end
                end
       
                // Command (2Ah)
                else if ((Io [7 : 0] === 8'h2A) && FEATURE_SET[CMD_LOCK]) begin
                    if (LOCKCOMMAND && ~LOCKTIGHT) begin
                       if (command_debug) $display ("At time %0t : Latch Command1 = 2Ah", $time);

                          cmnd_2Ah = 1'b1;
                          UnlockAddrLower = {ROW_BITS{1'b0}};
                          UnlockAddrUpper = {ROW_BITS{1'b1}};
						  LockInvert = 1'b1;
						  status_register[7] = 1'b0;
						  LOCK_DEVICE = 1'b1;
        
                          cmnd_23h = 1'b0;
                          cmnd_24h = 1'b0;
                          cmnd_2Ch = 1'b0;
						  cmnd_15h = 1'b0;
						  cmnd_31h = 1'b0;
						  cmnd_3Fh = 1'b0;
                          cmnd_70h = 1'b0;
                          cmnd_7Ah = 1'b0;
                          cmnd_90h = 1'b0;
                          cmnd_B8h = 1'b0;
						  cache_op = 1'b0;
						  disable_md_stat = 1'b0;

                       end else begin
                          $display ("Warning:  Command 2Ah - IGNORED - Lock commands are disabled");
                       end
                    end
       
                // Command (2Ch)
                else if ((Io [7 : 0] === 8'h2C) && FEATURE_SET[CMD_LOCK]) begin
                    if (LOCKCOMMAND && ~LOCKTIGHT) begin
                       if (command_debug) $display ("At time %0t : Latch Command1 = 2Ch", $time);
    
                          cmnd_2Ch = 1'b1;
                          LOCKTIGHT = 1'b1;
						  LOCK_DEVICE = 1'b0;
						  status_register[7] = 1'b1;
          
                          cmnd_23h = 1'b0;
                          cmnd_24h = 1'b0;
                          cmnd_2Ah = 1'b0;
						  cmnd_15h = 1'b0;
						  cmnd_31h = 1'b0;
						  cmnd_3Fh = 1'b0;
                          cmnd_70h = 1'b0;
                          cmnd_7Ah = 1'b0;
                          cmnd_90h = 1'b0;
                          cmnd_B8h = 1'b0;
						  cache_op = 1'b0;
						  disable_md_stat = 1'b0;
                       end else begin
                          $display ("Warning:  Command 2Ch - IGNORED - Lock commands are disabled");
                       end
                    end
        
                // Command (30h)
                else if (Io [7 : 0] === 8'h30 && die_select) begin

                    if (command_debug) $display ("At time %0t : Latch Command = 30h", $time);

                    cmnd_30h = 1'b1;

                    // Command (00h -> [30h] -> 05h -> E0h)
                    if (cmnd_00h && row_valid && (Rb_n === 1'bz) && ~saw_cmnd_65h) begin
                        if (command_debug2) $display ("Command = 30h A0");
                        cmnd_00h = 1'b0;
                        cmnd_30h = 1'b1;
                        col_counter = 0;
                        load_data_register (twoplane_op, 0);
						//for 2plane ops, pulsing Re_n after 2plane page read should
						// output from Plane 0 first
						if (twoplane_op) begin
							active_plane = 1'b0;
						end
						twoplane_op = 1'b0;
                        data_valid = 1'b1;
                        cache_valid = 1'b0;
                    end 

                    // Command (AFh -> [30h])
                    if (cmnd_AFh && row_valid && (Rb_n === 1'bz)) begin
                        if (command_debug2) $display ("Command = 30h A2");
                        cmnd_AFh = 1'b0;
                        cmnd_30h = 1'b1;
                        col_counter = 0;
                        load_data_register (0, 0);
                        data_valid = 1'b1;
                        cache_valid = 1'b0;
                    end 

                    // Command (30h -> 65h -> 00 -> [30h]) 
                    if (cmnd_00h && row_valid && (Rb_n === 1'bz) && saw_cmnd_65h) begin
                        if (command_debug2) $display ("Command = 30h B");
                        cmnd_30h = 1'b1;
                        cmnd_00h = 1'b0; 
                        if (col_addr == 512) begin  // hex 200 (LSB of second Column Address = 02h
							if (FEATURE_SET[CMD_ID2]) begin
                            	do_read_id_2 = 1'b1;
                            	`ifdef x8
                                	col_counter = 512;  // Byte 512 for x8
                      	        `else
                        	        col_counter = 256;  // Byte 512 for x16
                            	`endif
								load_data_register(0,0); 
							end else begin
								$display("ERROR : READ ID2 Command is not supported by this device.");
							end
                            if (command_debug2) $display ("At time %0t : Latch last 30h command for do_read_id_2", $time);
                        end else if (col_addr == 0) begin
							if (FEATURE_SET[CMD_UNIQUE]) begin
	                            do_read_unique = 1'b1;
    	                        col_counter = 0;
								load_data_register(0,0); 
        	                    if (command_debug2) $display ("At time %0t : Latch last 30h command for do_read_unique", $time);
							end else begin
								$display("ERROR : READ UNIQUE Command is not supported by this device.");
							end
                        end else begin
                            $display ("At time %0t : ERROR invalid col_addr when attemping read_id_2 or read_unique", $time);
                            $display ("At time %0t : ERROR col_addr = %hh", $time, col_addr);
                        end
                        saw_cmnd_65h = 1'b0; 
                    end

                    // Terminate Command (00h)
                    if (cmnd_00h && ~row_valid) begin
                        if (command_debug2) $display ("Command = 30h C");
                        cmnd_00h = 1'b0;
                    end
					twoplane_op = 1'b0;
					cache_op = 1'b0;
					cmnd_65h = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
                end
    
                // Command (31h)
                else if ((Io [7 : 0] === 8'h31) && FEATURE_SET[CMD_NEW] && die_select) begin
  		            if (command_debug2) $display ("At time %0t : Latch Command = 31h", $time);

                    // Command (00h -> 30h -> 31h -> 3Fh)
                    if (cmnd_30h && row_valid && (Rb_n === 1'bz)) begin
       		            if (command_debug2) $display ("At time %0t : Latch Command = 31h valid", $time);
                        // Reset Column Address
                        col_addr = 0;
                        col_counter = 0;
						cache_op = 1'b1;
                        row_addr = {row_addr [(ROW_BITS -1) : (PAGE_BITS)], (row_addr [(PAGE_BITS -1) : 0] + 1'b1)};
						if (row_addr[PAGE_BITS-1:0] === {(PAGE_BITS){1'b0}}) begin
							$display ($time, "  ERROR : CACHED PAGE READ cannot cross block boundaries. Block=%0h   Page=%0h ", row_addr[ROW_BITS-1:PAGE_BITS], (row_addr[PAGE_BITS-1:0] -1'b1));
						end
    
                        // Command (00h -> 30h -> [31h] -> 3Fh)
 						// 	 -- or --
                        // Command (00h -> 30h -> 31h -> [31h] -> 3Fh)
                        cmnd_31h = 1'b1;
                        load_cache_register (0, cache_op);  // Load cache
    
                        cache_valid = 1'b1;
                        data_valid = 1'b1;
                    end
                    // Terminate Command
                    if (cmnd_30h  && ~row_valid) begin
                        cmnd_30h = 1'b0;
                    end
					twoplane_op = 1'b0;
					cache_op = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
                end
    
                // Command (35h)
                else if ((Io [7 : 0] === 8'h35) && die_select) begin

                    if (command_debug) $display ("At time %0t : Latch Command = 35h", $time);
    
                    // Command (00h -> 35h -> 85h -> 10h)
                    if (row_valid && (Rb_n === 1'bz)) begin
                        if (command_debug2) $display ("At time %0t : Latch Command = 35h A", $time);
						if (cmnd_00h && twoplane_op) begin
	                        if (mcp_debug) $display ("At time %0t : TWO PLANE Latch Second 35h B Command", $time);
							
						end
                        cmnd_00h = 1'b0;
                        cmnd_35h = 1'b1;
						//col_counter must be set to 0 so designs supporting Re# pulses after h35 work correctly
						col_counter = 0;
                        col_valid = 1'b0;
                        row_valid = 1'b0;
						load_data_register (twoplane_op, cache_op);
                        load_cache_register (twoplane_op, cache_op);
                    end

                    // Terminate Command (00h)
                    if (cmnd_00h && ~row_valid) begin
                        cmnd_00h = 1'b0;
                    end

					twoplane_op = 1'b0;
					cache_op = 1'b0;

                end
    
                // Command (3Fh)
                else if ((Io [7 : 0] === 8'h3F) && FEATURE_SET[CMD_NEW]) begin

                    if (command_debug) $display ("At time %0t : Latch Command = 3Fh", $time);
    
                    // Command (00h -> 30h -> 31h -> 3Fh)
                    if (cmnd_30h && cmnd_31h && row_valid && (Rb_n === 1'bz)) begin
                        cmnd_3Fh = 1'b1;
                        col_addr = 0;
                        col_counter = 0;
                        row_addr = {row_addr [(ROW_BITS -1) : (PAGE_BITS)], (row_addr [(PAGE_BITS -1) : 0] + 1'b1)};
						if (row_addr[PAGE_BITS-1:0] === {(PAGE_BITS){1'b0}}) begin
							$display ($time, "  ERROR : CACHED PAGE READ cannot cross block boundaries. Block=%0h   Page=%0h ", row_addr[ROW_BITS-1:PAGE_BITS], (row_addr[PAGE_BITS-1:0] -1'b1));
						end
                        load_cache_register (0, 1); 
                        cmnd_30h = 1'b0;
                        cmnd_31h = 1'b0;
                        cache_valid = 1'b1;
                        data_valid = 1'b1;
                    end

					twoplane_op = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
                end
    
                // Command (60h)
                else if (Io [7 : 0] === 8'h60) begin

                    if (command_debug) $display ("At time %0t : die %d Latch Command = 60h", $time, thisDieNumber);

					if (~Wp_n) begin
						$display("Wp_n = 0,  ERASE operation disabled.");
					end
     
                    if (Wp_n && (Rb_n === 1'bz)) begin 
						if (cmnd_60h && FEATURE_SET[CMD_2PLANE]) begin
							// Command (60h -> [60h] -> D0h)
							twoplane_op = 1'b1;
							twoplane_row_addr = row_addr;
						end
						// Otherwise just a regular Command ([60h] -> D0h)
                        cmnd_60h = 1'b1;
                        row_valid = 1'b0;
                        addr_start = col_rows +1;
                        addr_stop = ADDR_ROWS;
                    end
       
                    // Terminate Command (00h -> 30h -> [05h] - [E0h])
                    if (cmnd_30h || cmnd_05h) begin
                        cmnd_30h = 1'b0;
                        cmnd_05h = 1'b0;
                        data_valid = 1'b0;
                    end
    
					cmnd_15h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_70h = 1'b0;
                    cmnd_78h = 1'b0;
					cmnd_7Ah = 1'b0;
                    cmnd_80h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
					cache_op = 1'b0;
					disable_md_stat = 1'b0;
                end
    
                // Command (65h)
                else if ((Io [7 : 0] === 8'h65) && (FEATURE_SET[CMD_ID2] || FEATURE_SET[CMD_UNIQUE])) begin

                    if (command_debug) $display ("At time %0t : Latch Command = 65h", $time);
    
                    // Terminate Command (30h -> 65h -> [00h])
                    if (cmnd_30h) begin
                        if (command_debug2) $display ("Command = 65h A");
                        cmnd_30h = 1'b0;
                        cmnd_65h = 1'b1;
                        saw_cmnd_65h = 1'b1;
                    end
    
					cmnd_15h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_80h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_B8h = 1'b0;
                end

                // Command (70h)
                else if (((Io [7 : 0] === 8'h70) || (Io [7 : 0] === 8'h71)) && (die_select)) begin

                    if (command_debug2) $display ("At time %0t : Latch Command1 = 70h or 71h", $time);
    
                    // Status
                    cmnd_70h = 1'b1;
    
                    // Terminate Command (00h -> 30h -> [05h] - [E0h])
                    if (cmnd_30h || cmnd_05h) begin
                        cmnd_30h = 1'b0;
                        cmnd_05h = 1'b0;
                        data_valid = 1'b0;
                    end
    
                    cmnd_60h = 1'b0;
                    cmnd_78h = 1'b0;
                    cmnd_7Ah = 1'b0;
                    cmnd_80h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
                end
    
                // Command (78h)
                else if ((Io [7 : 0] === 8'h78) || (Io [7 : 0] === 8'h79)) begin

                    if (command_debug) $display ("At time %0t : Latch Command1 = 78h or 79h, die=%0d", $time, thisDieNumber);
    
                    // Status
                    cmnd_78h = 1'b1;
                    addr_start = col_rows +1;
                    addr_stop = ADDR_ROWS;
    
                    data_valid = 1'b0;
					row_valid = 1'b0;

                    cmnd_30h = 1'b0;
                    cmnd_05h = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_70h = 1'b0;
					cmnd_7Ah = 1'b0;
                    cmnd_80h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
                end
    
				// block lock status read
                else if ((Io [7 : 0] === 8'h7A) && (die_select) && FEATURE_SET[CMD_LOCK]) begin

                    if (command_debug) $display ("At time %0t : Latch Command1 = 7Ah", $time);
    
                    // Status
                    cmnd_7Ah = 1'b1;
                    addr_start = col_rows +1;
                    addr_stop = ADDR_ROWS;
    
                    data_valid = 1'b0;
					row_valid = 1'b0;

					cmnd_23h = 1'b0;
					cmnd_24h = 1'b0;
					cmnd_2Ah = 1'b0;
					cmnd_2Ch = 1'b0;
                    cmnd_30h = 1'b0;
					cmnd_15h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_05h = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_70h = 1'b0;
                    cmnd_78h = 1'b0;
                    cmnd_80h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
                end

                // Command (80h)
                else if (Io [7 : 0] === 8'h80) begin

                    if (command_debug) $display ("At time %0t : Latch Command = 80h, die=%0d", $time, thisDieNumber);
    
                    // Command [80h] -> 10h
					// or Command [80h] -> 15h
					// or Command [80h] -> 11h
					if (~Wp_n) begin
						$display("Wp_n = 0,  PROGRAM operation disabled.");
					end else begin
                      if (Rb_n === 1'bz) begin
                        if (command_debug2) $display ("At time %0t : 80h AA", $time);
                        cmnd_80h = 1'b1;

                        col_valid = 1'b0;
                        row_valid = 1'b0;

                        addr_start = 1'b1;
                        addr_stop = ADDR_ROWS;
                        col_counter = 0;
						//if this is 2nd half of twoplane op, don't want to clear registers
						if (~twoplane_op) begin
	                        clear_cache_register(~active_plane);
							clear_data_register(~active_plane);
	                        clear_cache_register(active_plane);
							clear_data_register(active_plane);
						end
                      end 
					end

                    // Terminate Command (00h -> 30h -> 05h -> E0h)
                    if (cmnd_00h || cmnd_30h || cmnd_05h) begin
                        if (command_debug2) $display ("At time %0t : 80h B", $time);
                        cmnd_00h = 1'b0;
                        cmnd_30h = 1'b0;
                        cmnd_05h = 1'b0;
                        data_valid = 1'b0;
                    end

                    cmnd_11h = 1'b0;
					cmnd_15h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_35h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_70h = 1'b0;
                    cmnd_78h = 1'b0;
					cmnd_7Ah = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
					disable_md_stat = 1'b0;
                end
        
                // Command (85h)
                else if (Io [7 : 0] === 8'h85) begin

                    if (command_debug) $display ("At time %0t : Latch Command = 85h", $time);
     
					// For all random column data write
					// Command ( 80h -> [85h] -> ??)
					//  	- or -
					// Command (85h -> [85h] -> ??)
					if (row_valid && (Rb_n === 1'bz)) begin
	                    if (cmnd_85h | cmnd_80h | cmnd_A0h) begin  
    	                    if (command_debug2) $display ("At time %0t : Latch Command = 85h A", $time);
        	                col_valid = 1'b0;
            	            col_counter = 0;
							cmnd_85h = 1'b1;
                	        addr_start = 1;
                    	    addr_stop = col_rows;
						end
	                end	else if (Rb_n === 1'bz) begin
    	                    if (command_debug2) $display ("At time %0t : Latch Command = 85h B", $time);
							//else this is the first 85h for internal data move (not random data input)
							if (~Wp_n) begin
								$display("Wp_n = 0,  PROGRAM operation disabled.");
							end else begin
	                            col_valid = 1'b0;
                        	    row_valid = 1'b0;
								cmnd_85h = 1'b1;
                	            addr_start = 1;
            	                addr_stop = ADDR_ROWS;
        	                    col_counter = 0;
								disable_md_stat = 1'b0;
							end
					end
						
                       // Terminate Command (80h -> 85h -> 10h)
                    if (cmnd_80h && ~row_valid) begin
                        cmnd_80h = 1'b0;
                    end

                    // Terminate Command (00h -> 30h -> 05h -> E0h)
                    if (cmnd_00h || cmnd_30h || cmnd_05h) begin
                        if (command_debug2) $display ("At time %0t : 80h B", $time);
                        cmnd_00h = 1'b0;
                        cmnd_30h = 1'b0;
                        cmnd_05h = 1'b0;
                        data_valid = 1'b0;
                    end

                    cmnd_11h = 1'b0;
					cmnd_15h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_35h = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_70h = 1'b0;
                    cmnd_78h = 1'b0;
					cmnd_7Ah = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
                    end
    
                // Command (90h)
                else if ((Io [7 : 0] === 8'h90) && die_select) begin

                    if (command_debug) $display ("At time %0t : Latch Command = 90h", $time);
    
                    // Command (90h)
                    //if (~cmnd_90h) begin
                        cmnd_90h = 1'b1;
                        col_valid = 1'b0;
                        row_valid = 1'b0;
                        addr_start = 1;
                        addr_stop = 0;
                        col_counter = 0;
                    //end
    
                    // Terminate Command (00h -> 30h -> 05h -> E0h)
                    if (cmnd_00h || cmnd_30h || cmnd_05h) begin
                        cmnd_00h = 1'b0;
                        cmnd_30h = 1'b0;
                        cmnd_05h = 1'b0;
                        data_valid = 1'b0;
                    end
    
					cmnd_15h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_35h = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_70h = 1'b0;
                    cmnd_78h = 1'b0;
					cmnd_7Ah = 1'b0;
                    cmnd_80h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_B8h = 1'b0;
					cache_op = 1'b0;
					disable_md_stat = 1'b0;
                end
    
                // Command (A0)
                else if ((Io [7 : 0] === 8'hA0) && FEATURE_SET[CMD_OTP]) begin

                    if (command_debug) $display ("At time %0t : Latch Command = A0h", $time);
    
                    // Command (A0)
                    if (~cmnd_A0h && (Rb_n === 1'bz)) begin
                        if (command_debug2) $display ("At time %0t : A0h A", $time);
                        OTP_write = 1;
						disable_md_stat = 1'b1;
                        cmnd_A0h = 1'b1;
                        col_valid = 1'b0;
                        row_valid = 1'b0;
                        addr_start = 1'b1;
                        addr_stop = ADDR_ROWS;
                        col_counter = 0;
                    end
    
                    // Terminate Command (00h -> 30h -> 05h -> E0h)
                    if (cmnd_00h || cmnd_30h || cmnd_05h) begin
                        if (command_debug2) $display ("At time %0t : A0h B", $time);
                        cmnd_00h = 1'b0;
                        cmnd_30h = 1'b0;
                        cmnd_05h = 1'b0;
                        data_valid = 1'b0;
                    end
    
					cmnd_15h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_35h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_70h = 1'b0;
                    cmnd_78h = 1'b0;
					cmnd_7Ah = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
                end
     
                // Command (A5)
                else if ((Io [7 : 0] === 8'hA5) && FEATURE_SET[CMD_OTP]) begin

                    if (command_debug) $display ("At time %0t : Latch Command = A5h", $time);
    
                    // Command (A5)
                    if (~cmnd_A5h && (Rb_n === 1'bz)) begin
                        if (command_debug2) $display ("At time %0t : A5h A", $time);
                        cmnd_A5h = 1'b1;
                        col_valid = 1'b0;
                        row_valid = 1'b0;
                        addr_start = 1'b1;
                        addr_stop = ADDR_ROWS;
                        col_counter = 0;
                        if (command_debug2) $display("At time %0t : OTP Protect", $time);
                    end
    
                    // Terminate Command (00h -> 30h -> 05h -> E0h)
                    if (cmnd_00h || cmnd_30h || cmnd_05h) begin
                        if (command_debug2) $display ("At time %0t : A5h B", $time);
                        cmnd_00h = 1'b0;
                        cmnd_30h = 1'b0;
                        cmnd_05h = 1'b0;
                        data_valid = 1'b0;
                    end
    
					cmnd_15h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_35h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_70h = 1'b0;
                    cmnd_78h = 1'b0;
					cmnd_7Ah = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
                end

                // Command (AFh)
                else if ((Io [7 : 0] === 8'hAF) && FEATURE_SET[CMD_OTP]) begin
                    if (command_debug) $display ("At time %0t : Latch Command = AFh", $time);

                    if (~cmnd_AFh && (Rb_n === 1'bz)) begin
                        if (command_debug2) $display ("At time %0t : Latch Command AFh B", $time);
                        OTP_read = 1;
						disable_md_stat = 1'b1;
                        cmnd_AFh = 1'b1;
                        col_valid = 1'b0;
                        row_valid = 1'b0;
                        data_valid = 1'b0;
                        addr_start = 1;
                        addr_stop = ADDR_ROWS;
                    end

					cmnd_15h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_70h = 1'b0;
                    cmnd_78h = 1'b0;
					cmnd_7Ah = 1'b0;
                    cmnd_80h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
                end
 
                // Command (B8h)
                else if ((Io [7 : 0] === 8'hB8) && (FEATURE_SET[CMD_DRVSTR])) begin

                    if (command_debug) $display ("At time %0t : Latch Command1 = B8h", $time);
    
                    // Status
                    cmnd_B8h = 1'b1;
    
					cmnd_05h = 1'b0;    
					cmnd_15h = 1'b0;
					cmnd_30h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_70h = 1'b0;
                    cmnd_78h = 1'b0;
					cmnd_7Ah = 1'b0;
                    cmnd_80h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_90h = 1'b0;
					cache_op = 1'b0;
					disable_md_stat = 1'b0;
               end
    

                // Command (D0h)
                else if (Io [7 : 0] === 8'hD0) begin

                    if (command_debug) $display ("At time %0t : Latch Command = D0h", $time);
    
                    // Command (60h -> D0h)
                    if (cmnd_60h && row_valid && Wp_n && (Rb_n === 1'bz)) begin
                        cmnd_60h = 1'b0;
                        cmnd_D0h = 1'b1;
						if (twoplane_op) begin 
	                        erase_block (1, {twoplane_row_addr [ROW_BITS - 1 : ROW_BITS - BLCK_BITS]}, twoplane_row_addr[PAGE_BITS-1 : 0], {row_addr [ROW_BITS - 1 : ROW_BITS - BLCK_BITS]}, row_addr[PAGE_BITS-1 : 0]);   //twoplane, blk1, page1, blk2, page2 
						end else begin
	                        erase_block (0, {row_addr [ROW_BITS - 1 : ROW_BITS - BLCK_BITS]}, row_addr[PAGE_BITS -1 : 0], 0, 0); //twoplane, blk1, page1, blk2, page2
						end
                    end
                    // Terminate Command (60h -> D0h)
                    if (cmnd_60h && ~row_valid) begin
                        cmnd_60h = 1'b0;
                    end
					twoplane_op = 1'b0;
					cache_op = 1'b0;
                end
    
                // Command (E0h)
                else if (Io [7 : 0] === 8'hE0) begin

                    if (command_debug) $display ("At time %0t : Latch Command = E0h", $time);
    
                    cmnd_E0h = 1'b1;

                    // Command (06h -> [E0h])
                    if (cmnd_06h && row_valid && (Rb_n === 1'bz)) begin
                        if (command_debug2) $display ("Command = E0h A0");
                        cmnd_06h = 1'b0;
                        col_counter = 0;
                        data_valid = 1'b1;
                        cache_valid = 1'b0;
                    end 

                    // Command (00h -> 30h -> 05h -> E0h)
                    if (cmnd_05h && col_valid) begin
                        data_valid = 1'b1;
                        col_counter = 0;
                    end
    
                    // Terminate Command (00h -> 30h -> 05h -> E0h)
                    if (cmnd_05h && ~col_valid) begin
                        cmnd_30h = 1'b0;
                        cmnd_05h = 1'b0;
                        data_valid = 1'b0;
                    end
                    
                    cmnd_06h = 1'b0;
                end

				// Command (ECh) ONFI READ PARAMETER PAGE Command
				else if ((Io [7 : 0] === 8'hEC) && FEATURE_SET[CMD_ONFI]) begin
					$display("WARNING : This model does not yet support the ECh command.");
					cmnd_15h = 1'b0;
					cmnd_31h = 1'b0;
					cmnd_3Fh = 1'b0;
                    cmnd_35h = 1'b0;
                    cmnd_85h = 1'b0;
                    cmnd_60h = 1'b0;
                    cmnd_70h = 1'b0;
                    cmnd_78h = 1'b0;
					cmnd_7Ah = 1'b0;
                    cmnd_90h = 1'b0;
                    cmnd_B8h = 1'b0;
				end
								    
                // Command (FFh) Reset Command
                else if (Io [7 : 0] === 8'hFF) begin

                    if (command_debug) $display ("At time Reset Command %0t : Latch Command = FFh", $time);
					if (~ResetComplete) begin
						cmnd_reset (1'b0);
					end else begin
	                    cmnd_reset (1'b1);
					end
                end
   				else if (die_select) begin
					$display ("ERROR: At time %0t : die %0h  : Unsupported command = %00h", $time, thisDieNumber, Io[7:0]);
				end
            end // : cLatch_unbusy
	        if (Rb_n == 1'b0) begin : busy_command
    	    // even when buzy we need to do status and reset
        	    // Command (70h)
	            if (((Io [7 : 0] === 8'h70) || (Io [7 : 0] === 8'h71)) && (die_select)) begin
    	            if (command_debug) $display ("At time %0t : Latch Command2 = 70h or 71h", $time);
        	        // Status
            	    cmnd_70h = 1'b1;
	            end
		        // Command (78h)
    		    if ((Io [7 : 0] === 8'h78) || (Io [7 : 0] === 8'h79)) begin
        		    if (command_debug) $display ("At time %0t : Latch Command2 = 78h or 79h", $time);
		            // Status
    		        cmnd_78h = 1'b1;
					addr_start = col_rows +1;
					addr_stop = ADDR_ROWS;
					row_valid = 1'b0;
		         end
        	    // Command (FFh) Reset Command
	        	else if (Io [7 : 0] === 8'hFF) begin

    	            if (command_debug) $display ("At time Reset Command %0t : Latch Command = FFh", $time);
            	    cmnd_reset (1'b1);
	        	end
			end // : busy_command
        end // : latch_Cle
    end	// : cLatch

    // Data Input
    always @ (posedge We_n && die_select) begin
        //if (command_debug2) $display ("At time %0t : We_n posedge Data Input", $time);
        if (~Cle && ~Ale && ~Ce_n && We_n && Re_n && Wp_n) begin
			we_adl_active = 1'b1;
			tm_we_data_r = $realtime;
            if (col_valid && row_valid && (col_addr + col_counter <= NUM_COL - 1)) begin

                if (data_debug) $display ("At time %0t : Latch Data (%0h : %0h : %0h + %0h) = %0h",
                    $time, row_addr [(ROW_BITS -1) : (PAGE_BITS)], row_addr [(PAGE_BITS -1) : 0], col_addr, col_counter, Io);

                // Data Register
					cache_reg[active_plane] [col_addr + col_counter] = Io;
				//end

                // Increase Column Counter
                col_counter = col_counter + 1;
            end else if (cmnd_B8h === 1'b1) begin
                DriveStrength = (Io & 8'b00001100);
            end
        end
    end

    // Data Output
    //always @ (negedge Re_n && die_select) begin
    always @ (negedge Re_n) begin
        if (PowerUp_Complete === 1'b1) begin
            if (cmnd_00h) begin
                cmnd_00h = 1'b0;
            end
		end
		if (die_select) begin : rd_die_select
            if (~Cle && ~Ale && ~Ce_n && We_n && ~Re_n && (Rb_n === 1'bz)) begin : not_busy
				//Read ID2 and Read Unique take precedence.  Only way out is reset or power up/down
                // Read ID 2 
                if (do_read_id_2) begin

                    if (debug) $display ("At time %0t : ReadID2 (%0d)", $time, col_counter);
                    Io_buf <= #tREA_max special_array[col_counter];
                    if (debug2) $display("Io_buf Trigger 7id2"); 

                    // Advance counter
                    col_counter = col_counter + 1;

                // Read Unique 
                end else if (do_read_unique) begin

                    if (debug) $display ("At time %0t : ReadUnique (%0h)=%h", $time, col_counter, special_array[col_counter]);
                    Io_buf <= #tREA_max special_array[col_counter];
                    if (debug2) $display("Io_buf Trigger 7uniq"); 

                    // Advance counter
                    col_counter = col_counter + 1;

                // Status Read
				end else if (cmnd_70h || cmnd_78h) begin
					//nothing to do here, output_status task will catch this case    			
					//output_status;
                // Normal Page Read
                end else if (~cmnd_7Ah && col_valid && row_valid && (col_addr + col_counter <= NUM_COL - 1)) begin
                    // Data Buffer
					// determine whether CE access time or RE access time dominates
		 	    	if (cmnd_15h || cmnd_31h || cmnd_3Fh) begin
					// use cache mode timing
						if (tCEA_cache_max - tREA_cache_max < $realtime - tm_ce_n_f) begin
							//negedge is far enough away from negedge Ce_n, use tREA
							if (data_debug) $display("AA negedge RE %t  %t", $realtime, tm_ce_n_f);
        	    	        Io_buf <= #(tREA_cache_max) cache_reg[active_plane] [col_addr + col_counter];
						end else begin
							//negedge Re_n close to negedge Ce_n, use tCEA
							if (data_debug) $display("BB negedge RE %t  %t", $realtime, tm_ce_n_f);
	                    	Io_buf <= #(tm_ce_n_f + tCEA_cache_max - $realtime) cache_reg[active_plane] [col_addr + col_counter];
						end
					end else begin
						//regular read, no cache mode
						if (tCEA_max - tREA_max < $realtime - tm_ce_n_f) begin
							//negedge is far enough away from negedge Ce_n, use tREA
							if (data_debug) $display("CC negedge RE %t  %t", $realtime, tm_ce_n_f);
        		            Io_buf <= #(tREA_max) data_reg[active_plane] [col_addr + col_counter];
						end else begin
							//negedge Re_n close to negedge Ce_n, use tCEA
							if (data_debug) $display("DD negedge RE %t  %t", $realtime, tm_ce_n_f);
	                    	Io_buf <= #(tm_ce_n_f + tCEA_max - $realtime) data_reg[active_plane] [col_addr + col_counter];
						end
					end
                    if (debug2) $display("Io_buf Trigger 4"); 
    
                    if (data_debug) begin
            	        $display ("At time %0t : Data Read (%0h : %0h : %0h + %0h) = %0h",
  	            	        $time, row_addr [(ROW_BITS -1) : (PAGE_BITS)], row_addr [(PAGE_BITS -1) : 0], col_addr, col_counter, data_reg[active_plane] [col_addr + col_counter]);
					end
    
                    // Increase Column Counter
                    col_counter = col_counter + 1;

			//some designs support reading out of cache register right after read for internal data move
                end else if (~col_valid && ~row_valid && cmnd_35h) begin
					// use cache mode timing
						if (tCEA_cache_max - tREA_cache_max < $realtime - tm_ce_n_f) begin
							//negedge is far enough away from negedge Ce_n, use tREA
							if (data_debug) $display("AA negedge RE %t  %t", $realtime, tm_ce_n_f);
        	    	        Io_buf <= #(tREA_cache_max) cache_reg[active_plane] [col_addr + col_counter];
						end else begin
							//negedge Re_n close to negedge Ce_n, use tCEA
							if (data_debug) $display("BB negedge RE %t  %t", $realtime, tm_ce_n_f);
	                    	Io_buf <= #(tm_ce_n_f + tCEA_cache_max - $realtime) cache_reg[active_plane] [col_addr + col_counter];
						end
                    	col_counter = col_counter + 1;

                // extra case to drive data bus high z after column boundary is reached
                end else if (~cmnd_70h && ~cmnd_78h && col_valid && row_valid && data_valid && (col_addr + col_counter > NUM_COL - 1)) begin
                    Io_buf <= #(tREA_max) {DQ_BITS{1'bz}};
                    if (debug2) $display("Io_buf Trigger 5 - col_addr=%h, col_counter=%h, NUM_COL=%h", col_addr, col_counter, NUM_COL); 
    
				// lock status read
				end else if (cmnd_7Ah) begin
					if (debug) $display("BLOCK LOCK READ STATUS\n");
					if (~LOCKCOMMAND) begin
						// device was not locked on startup, cannot be locked later
						Io_buf <= #(tREA_max) 8'h06;
        		       		if (debug) $display ("At time %0t : Lock Status Read=%0hh at address  %0h", $time, 8'h06, row_addr[ROW_BITS-1:PAGE_BITS] );
					end else begin
						//if ((UnlockAddrLower <= row_addr[ROW_BITS-1:PAGE_BITS]) && (row_addr[ROW_BITS-1:PAGE_BITS] <= UnlockAddrUpper)) begin
						if ((UnlockAddrLower <= row_addr) && (row_addr <= UnlockAddrUpper)) begin
							Io_buf <= #(tREA_max) {{(DQ_BITS-3){1'b0}}, ~LockInvert, ~LOCKTIGHT, LOCKTIGHT};
        		       		if (debug) $display ("At time %0t : Lock Status Read=%0hh at address  %0h", $time, {{(DQ_BITS-3){1'b0}}, ~LockInvert, ~LOCKTIGHT, LOCKTIGHT}, row_addr );
						end else begin
							Io_buf <= #(tREA_max) {{(DQ_BITS-3){1'b0}}, LockInvert, ~LOCKTIGHT, LOCKTIGHT};
		               		if (debug) $display ("At time %0t : Lock Status Read=%0hh at address  %0h", $time, {{(DQ_BITS-3){1'b0}}, LockInvert, ~LOCKTIGHT, LOCKTIGHT}, row_addr );
						end
				    end

                // DriveStrength
                end else if (cmnd_B8h) begin
                    Io_buf <= #tREAIO_max DriveStrength;
					if (debug) $display("DriveStrength=%0h", DriveStrength);
                    if (debug2) $display("Io_buf Trigger 7DS"); 

                // Read ID
                end else if (cmnd_90h) begin
    
					if (id_reg_addr === 8'h00) begin
						//Regular ID read

    	                // Reset Counter
	                    if (col_counter > (NUM_ID_BYTES - 1)) begin
        	                col_counter = 0;
            	        end
			
    	                case (col_counter)
	                          0 : begin
                            	      Io_buf <= #(tREA_max) READ_ID_BYTE0;
                        	          if (debug2) $display("Io_buf Trigger 71"); 
                    	          end
                	          1 : begin
        	                          Io_buf <= #(tREA_max) READ_ID_BYTE1;
    	                              if (debug2) $display("Io_buf Trigger 72"); 
	                              end
                        	  2 : begin
                	                  Io_buf <= #(tREA_max) READ_ID_BYTE2;
            	                      if (debug2) $display("Io_buf Trigger 73"); 
        	                      end
    	                      3 : begin
                                	  Io_buf <= #(tREA_max) READ_ID_BYTE3;
                            	      if (debug2) $display("Io_buf Trigger 74"); 
                        	      end
                    	      4 : begin
            	                      Io_buf <= #(tREA_max) READ_ID_BYTE4;
        	                          if (debug2) $display("Io_buf Trigger 74"); 
    	                          end
	                    endcase
    
                    	if (debug) $display ("At time %0t : Read ID (%0h)", $time, col_counter);
    
                    	// Advance counter
                    	col_counter = col_counter + 1;

    				end else if ((id_reg_addr === 8'h20) && (FEATURE_SET[CMD_ONFI])) begin
						//special ONFI read ID
    	                // Reset Counter
	                    if (col_counter > 3) begin
							if (data_debug) $display("ERROR : ONFI read beyond 4 bytes is indeterminate.");
        	                Io_buf <= #(tREA_max) {DQ_BITS{1'bx}};
            	        end
			
    	                case (col_counter)
	                          0 : begin
                            	      Io_buf <= #(tREA_max) 8'h4F;
                    	          end
                	          1 : begin
        	                          Io_buf <= #(tREA_max) 8'h4E;
	                              end
                        	  2 : begin
                	                  Io_buf <= #(tREA_max) 8'h46;
        	                      end
    	                      3 : begin
                                	  Io_buf <= #(tREA_max) 8'h49;
                        	      end
	                    endcase
    
                    	if (debug) $display ("At time %0t : ONFI Read ID (%0h)", $time, col_counter);
    
                    	// Advance counter
                    	col_counter = col_counter + 1;

					end
                end else if (Pre) begin
        		            Io_buf <= #(tREA_max) data_reg[active_plane] [col_addr + col_counter];
							col_counter = col_counter +1;
                // Out of bounds or unknown
                end else begin
                    Io_buf <= #(tREA_max) {DQ_BITS{1'bz}};
                    if (debug2) $display("Io_buf Trigger 99"); 
                    $display("Error: DATA NOT Transfered on Re_n Trigger 8"); 
                end
            end else begin
				if (~(cmnd_70h || cmnd_78h)) begin
	                Io_buf <= #(tREA_max) {DQ_BITS{1'bz}};
				end
				if (data_debug) $display("%t  Rb_n %h   ", $time, Rb_n);
                if (debug2) $display("Io_buf Trigger 9"); 
            end // : not_busy
        end // : rd_die_select
    end

// output with delay
    always @ (posedge Re_n) begin
        if (~Cle && ~Ale && ~Ce_n && We_n && Re_n && die_select) begin
			t_readtox = ($realtime + tRHOH_min);
			t_readtoz = ($realtime + tRHZ_max);
            if (debug2) $display("Io_buf Trigger 10"); 
        end
    end
//	always @ (posedge Ce_n && (Io_buf !== {DQ_BITS{1'bz}})) begin
	// if IO has already changed from 
	always @ (posedge Ce_n && (t_readtox > $realtime)) begin
			if (($realtime + tOH_min) < t_readtox) begin
				t_readtox = $realtime + tOH_min;
			end
			if (($realtime + tCHZ_max) < t_readtox) begin
				t_readtoz = $realtime + tCHZ_max;
			end
	end

// timing checks
	always @ (We_n) begin
		if (~We_n) begin
	  	   if (~Ce_n) begin
			if (cmnd_15h || cmnd_31h || cmnd_3Fh) begin
    	    	// special cache mode timing checks
	  			if ($realtime - tm_we_n_f < tWC_cache_min) $display("%t ERROR:   Cache Mode tWC violation on We_n by %t ", $realtime, tm_we_n_f + tWC_cache_min - $realtime);
				if ($realtime - tm_we_n_r < tWH_cache_min) $display("%t ERROR:   Cache Mode tWH violation on We_n by %t ", $realtime, tm_we_n_r + tWH_cache_min - $realtime);
		  	end else if (cmnd_B8h) begin
	  			if ($realtime - tm_we_n_f < tWCIO_min) $display("%t ERROR:   tWCIO violation on We_n by %t ", $realtime, tm_we_n_f + tWCIO_min - $realtime);
				if ($realtime - tm_we_n_r < tWHIO_min) $display("%t ERROR:   tWHIO violation on We_n by %t ", $realtime, tm_we_n_r + tWHIO_min - $realtime);
		  	end else begin
	  			if ($realtime - tm_we_n_f < tWC_min) $display("%t ERROR:   tWC violation on We_n by %t ", $realtime, tm_we_n_f + tWC_min - $realtime);
				if ($realtime - tm_we_n_r < tWH_min) $display("%t ERROR:   tWH violation on We_n by %t ", $realtime, tm_we_n_r + tWH_min - $realtime);
				if ($realtime - tm_re_n_r < tRHW_min) $display("%t ERROR:   tRHW violation on We_n by %t ", $realtime, tm_re_n_r + tRHW_min - $realtime);
		    end
		  tm_we_n_f = $realtime;
		  end
		end else begin
		   if (~Ce_n) begin
			if (cmnd_15h || cmnd_31h || cmnd_3Fh) begin
    		    // special cache mode timing checks
		  		if ($realtime - tm_we_n_f < tWP_cache_min) $display("%t ERROR:   Cache Mode tWP violation on We_n by %t ", $realtime, tm_we_n_f + tWP_cache_min - $realtime);
				if ($realtime - tm_cle_r < tCLS_cache_min) $display("%t ERROR:   Cache Mode tCLS violation on We_n by %t ", $realtime, tm_cle_r + tCLS_cache_min - $realtime);
				if ($realtime - tm_cle_f < tCLS_cache_min) $display("%t ERROR:   Cache Mode tCLS violation on We_n by %t ", $realtime, tm_cle_f + tCLS_cache_min - $realtime);
				if ($realtime - tm_ce_n_f < tCS_cache_min) $display("%t ERROR:   Cache Mode tCS violation on We_n by %t ", $realtime, tm_ce_n_f + tCS_cache_min - $realtime);
				if ($realtime - tm_io_ztodata < tDS_cache_min) $display("%t ERROR:   Cache Mode tDS violation on We_n by %t ", $realtime, tm_io_ztodata + tDS_cache_min - $realtime);
				if ($realtime - tm_ale_r < tALS_cache_min) $display("%t ERROR:   Cache Mode tALS violation on We_n by %t ", $realtime, tm_ale_r + tALS_cache_min - $realtime);
				if ($realtime - tm_ale_f < tALS_cache_min) $display("%t ERROR:   Cache Mode tALS violation on We_n by %t ", $realtime, tm_ale_f + tALS_cache_min - $realtime);
			end else if (cmnd_B8h) begin
				if ($realtime - tm_we_n_f < tWPIO_min) $display("%t ERROR:   tWPIO violation on We_n by %t ", $realtime, tm_we_n_f + tWPIO_min - $realtime);
				if ($realtime - tm_cle_r < tCLSIO_min) $display("%t ERROR:   tCLSIO violation on We_n by %t ", $realtime, tm_cle_r + tCLSIO_min - $realtime);
				if ($realtime - tm_cle_f < tCLSIO_min) $display("%t ERROR:   tCLSIO violation on We_n by %t ", $realtime, tm_cle_f + tCLSIO_min - $realtime);
				if ($realtime - tm_io_ztodata < tDSIO_min) $display("%t ERROR:   tDSIO violation on We_n by %t ", $realtime, tm_io_ztodata + tDSIO_min - $realtime);
			end else begin
				if ($realtime - tm_we_n_f < tWP_min) $display("%t ERROR:   tWP violation on We_n by %t ", $realtime, tm_we_n_f + tWP_min - $realtime);
				if ($realtime - tm_ale_r < tALS_min) $display("%t ERROR:   tALS violation on We_n by %t ", $realtime, tm_ale_r + tALS_min - $realtime);
				if ($realtime - tm_ale_f < tALS_min) $display("%t ERROR:   tALS violation on We_n by %t ", $realtime, tm_ale_f + tALS_min - $realtime);
				if ($realtime - tm_cle_r < tCLS_min) $display("%t ERROR:   tCLS violation on We_n by %t ", $realtime, tm_cle_r + tCLS_min - $realtime);
				if ($realtime - tm_cle_f < tCLS_min) $display("%t ERROR:   tCLS violation on We_n by %t ", $realtime, tm_cle_f + tCLS_min - $realtime);
				if ($realtime - tm_ce_n_f < tCS_min) $display("%t ERROR:   tCS violation on We_n by %t ", $realtime, tm_ce_n_f + tCS_min - $realtime);
				if ($realtime - tm_wp_n < tWW_min) $display("%t ERROR:   tWW violation on We_n by %t ", $realtime, tm_wp_n + tWW_min - $realtime);
				if ($realtime - tm_io_ztodata < tDS_min) $display("%t ERROR:   tDS violation on We_n by %t ", $realtime, tm_io_ztodata + tDS_min - $realtime);
				if ((we_adl_active) && (tm_we_data_r - tm_we_ale_r < tADL_min)) $display("%t ERROR:   tADL violation on We_n by %t ", $realtime, tm_we_ale_r + tADL_min - tm_we_data_r);
			end
		   end
		  tm_we_n_r = $realtime;
		end
	end

	always @ (Re_n) begin
		if (~Re_n) begin
			if (~Ce_n) begin
    	    	if (cmnd_15h || cmnd_31h || cmnd_3Fh) begin
		    	    // special cache mode timing checks
					if ($realtime - tm_io_datatoz < tIR_cache_min) $display("%t ERROR:   Cache Mode tIR violation on Re_n by %t ", $realtime, tm_io_datatoz + tIR_cache_min - $realtime);
					if ($realtime - tm_re_n_f < tRC_cache_min) $display("%t ERROR:   Cache Mode tRC violation on Re_n by %t ", $realtime, tm_re_n_f + tRC_cache_min - $realtime);
					if ($realtime - tm_re_n_f < tRC_cache_min) $display("%t ERROR:   Cache Mode tRC violation on Re_n by %t ", $realtime, tm_re_n_f + tRC_cache_min - $realtime);
					if ($realtime - tm_re_n_r < tREH_cache_min) $display("%t ERROR:   Cache Mode tREH violation on Re_n by %t ", $realtime, tm_re_n_r + tREH_min - $realtime);
				end else if (cmnd_B8h) begin
					if ($realtime - tm_we_n_r < tWHRIO_min) $display("%t ERROR:   tWHRIO violation on Re_n by %t ", $realtime, tm_we_n_r + tWHRIO_min - $realtime);
				end else begin
					if ($realtime - tm_ale_f < tAR_min) $display("%t ERROR:   tAR violation on Re_n by %t ", $realtime, tm_ale_f + tAR_min - $realtime);
					if ($realtime - tm_cle_f < tCLR_min) $display("%t ERROR:   tCLR violation on Re_n by %t ", $realtime, tm_cle_f + tCLR_min - $realtime);
					if ($realtime - tm_re_n_f < tRC_min) $display("%t ERROR:   tRC violation on Re_n by %t ", $realtime, tm_re_n_f + tRC_min - $realtime);
					if ($realtime - tm_re_n_f < tRC_min) $display("%t ERROR:   tRC violation on Re_n by %t ", $realtime, tm_re_n_f + tRC_min - $realtime);
					if ($realtime - tm_re_n_r < tREH_min) $display("%t ERROR:   tREH violation on Re_n by %t ", $realtime, tm_re_n_r + tREH_min - $realtime);
					if ($realtime - tm_we_n_r < tWHR_min) $display("%t ERROR:   tWHR violation on Re_n by %t ", $realtime, tm_we_n_r + tWHR_min - $realtime);
					if ($realtime - tm_io_datatoz < tIR_min) $display("%t ERROR:   tIR violation on Re_n by %t ", $realtime, tm_io_datatoz + tIR_min - $realtime);
					if ($realtime - tm_rb_n_r < tRR_min) $display("%t ERROR:   tRR violation on Re_n by %t ", $realtime, tm_rb_n_r + tRR_min - $realtime);
				end
				//read EDO mode
				if (($realtime - tm_re_n_r) < tEDO_RC) begin
					edo_mode = 1'b1;
					if (debug) $display("edo=1, %0t %0t", $realtime, tm_re_n_r);
				end else begin
					edo_mode = 1'b0;
					if (debug) $display("edo=0, %0t %0t", $realtime, tm_re_n_r);
				end
				//negedge Re_n in devices that support EDO read mode utilizes tRLOH_min
		        if (~Cle && ~Ale && ~Ce_n && We_n && die_select && edo_mode) begin
					if (($realtime + tRLOH_min) > (tm_re_n_r + tRHOH_min)) begin
						t_readtox = ($realtime + tRLOH_min);
						t_readtoz = ($realtime + tRHZ_max);
					end
        		end
			end
			tm_re_n_f <= $realtime;
		end else begin
			//posedge Re_n
			if (~Ce_n) begin
    	    	if (cmnd_15h || cmnd_31h || cmnd_3Fh) begin
		    	    // special cache mode timing checks
					if ($realtime - tm_re_n_f < tRP_cache_min) $display("%t ERROR:   Cache Mode tRP violation on Re_n by %0t", $realtime, tm_re_n_f + tRP_cache_min - $realtime);
				end else if (cmnd_B8h) begin
					if ($realtime - tm_re_n_f < tRPIO_min) $display("%t ERROR:   tRPIO violation on Re_n by %0t", $realtime, tm_re_n_f + tRPIO_min - $realtime);
				end else begin
					if ($realtime - tm_re_n_f < tRP_min) $display("%t ERROR:   tRP violation on Re_n by %0t", $realtime, tm_re_n_f + tRP_min - $realtime);
				end
			end
			tm_re_n_r <= $realtime;
		end
	end

	always @ (Ce_n) begin
		if (~Ce_n) begin
			tm_ce_n_f <= $realtime;
		end else begin
    	    if (PowerUp_Complete == 1'b1) begin
    	    	if (cmnd_15h || cmnd_31h || cmnd_3Fh) begin
		    	    // special cache mode timing checks
					if ($realtime - tm_we_n_r < tCH_cache_min) $display("%t ERROR:   Cache Mode tCH violation on Re_n by %0t", $realtime, tm_we_n_r + tCH_cache_min - $realtime); 
				end	else begin
					if ($realtime - tm_we_n_r < tCH_min) $display("%t ERROR:   tCH violation on Re_n by %0t", $realtime, tm_we_n_r + tCH_min - $realtime); 
				end
			tm_ce_n_r <= $realtime;
			end
		end
	end

	always @ (Rb_n) begin
		if (~Rb_n) begin
			tm_rb_n_f = $realtime;
		end else begin
			tm_rb_n_r = $realtime;
		end
	end

	always @ (Cle) begin
		if (~Cle) begin
			tm_cle_f = $realtime;
		end else begin
			tm_cle_r = $realtime;
		end
		if (PowerUp_Complete) begin
 	    	if (cmnd_15h || cmnd_31h || cmnd_3Fh) begin
	    	    // special cache mode timing checks
				if ($realtime - tm_we_n_r < tCLH_cache_min) $display("%t ERROR:   Cache Mode tCLH violation on Cle by %0t", $realtime, tm_we_n_r + tCLH_cache_min - $realtime);
			end else if (cmnd_B8h) begin
				if ($realtime - tm_we_n_r < tCLHIO_min) $display("%t ERROR:   tCLHIO violation on Cle by %0t", $realtime, tm_we_n_r + tCLHIO_min - $realtime);
			end else begin
				if ($realtime - tm_we_n_r < tCLH_min) $display("%t ERROR:   tCLH violation on Cle by %0t", $realtime, tm_we_n_r + tCLH_min - $realtime);
			end
		end
	end

	always @ (Ale) begin
		if (~Ale) begin
			tm_ale_f = $realtime;
		end else begin
			tm_ale_r = $realtime;
		end
		if (PowerUp_Complete) begin
 	    	if (cmnd_15h || cmnd_31h || cmnd_3Fh) begin
	    	    // special cache mode timing checks
				if ($realtime - tm_we_n_r < tALH_cache_min) $display("%t ERROR:   Cache Mode tALH violation on Ale by %0t", $realtime, tm_we_n_r + tALH_cache_min - $realtime);
			end else begin
				if ($realtime - tm_we_n_r < tALH_min) $display("%t ERROR:   tALH violation on Ale by %0t", $realtime, tm_we_n_r + tALH_min - $realtime);
			end
		end
	end

	always @ (Io_buf) begin
		if ((Io_buf === {DQ_BITS{1'bx}}) && ($realtime == t_readtox)) begin
			if (PowerUp_Complete) begin
	 	    	if (cmnd_15h || cmnd_31h || cmnd_3Fh) begin
	    	    // special cache mode timing checks
					if ($realtime - tm_we_n_r < tDH_cache_min) $display("%t ERROR:   Cache Mode tDH violation on IO by %0t", $realtime, tm_we_n_r + tDH_cache_min - $realtime);
				end else if (cmnd_B8h) begin
					if ($realtime - tm_we_n_r < tDHIO_min) $display("%t ERROR:   tDHIO violation on IO by %0t", $realtime, tm_we_n_r + tDHIO_min - $realtime);
				end else begin
					if ($realtime - tm_we_n_r < tDH_min) $display("%t ERROR:   tDH violation on IO by %0t", $realtime, tm_we_n_r + tDH_min - $realtime);
					if ($realtime - tm_ce_n_r < tOH_min) $display("%t ERROR:   tOH violation on IO by %0t", $realtime, tm_ce_n_r + tOH_min - $realtime);
					if ($realtime - tm_re_n_r < tRHOH_min) $display("%t ERROR:   tRHOH violation on IO by %0t", $realtime, tm_re_n_r + tRHOH_min - $realtime);
					if (edo_mode) begin
						if ((0 < ($realtime - tm_re_n_f)) && (($realtime - tm_re_n_f)  < tRLOH_min)) $display("%t ERROR:   tRLOH violation on IO by %0t", $realtime, tm_re_n_f + tRLOH_min - $realtime);
					end
				end
			end
			tm_io_datatoz = $realtime;
		end else begin
			// to do 
			tm_io_ztodata = $realtime;
		end
	end

endmodule

