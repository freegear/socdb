/*******************************************************************************
*
*    File Name:  nand_model.V
*        Model:  BUS Functional
*    Simulator:  ModelSim
* Dependencies:  parameters.v
*
*        Email:  modelsupport@micron.com
*      Company:  Micron Technology, Inc.
*  Part Number:  MT29F
*
*  Description:  Micron NAND Verilog Model
*
*   Limitation:
*
*         Note:  This model does not model bit errors on read or write
*                Psuedo Pass commands are identical to normal status commands.
*
*   Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY
*                WHATSOEVER AND MICRON SPECIFICALLY DISCLAIMS ANY
*                IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
*                A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
*
*                Copyright � 2006 Micron Semiconductor Products, Inc.
*                All rights researved
*
********************************************************************************/

`timescale 1ns / 1ns

module nand_model (Io, Cle, Ale, Ce_n, Ce2_n, We_n, Re_n, Wp_n, Rb_n, Rb2_n);

`include "parameters.v"

    // Ports Declaration
    inout  [DQ_BITS - 1 : 0] Io;
    input                      Cle;
    input                      Ale;
    input                      Ce_n;
    input                      Ce2_n;
    input                      We_n;
    input                      Re_n;
    input                      Wp_n;
    output                     Rb_n;
    output                     Rb2_n;

    //wire [DQ_BITS - 1 : 0] IO = Io;

    // Instantiate Device
 `ifdef G4
    defparam uut_0.mds = 3'b100;
    nand_die_model uut_0  (Io, Cle, Ale, Ce_n, We_n, Re_n, Wp_n, Rb_n );

 `else `ifdef G8
    defparam uut_0.mds = 3'b100;
	defparam uut_1.mds = 3'b101;
    nand_die_model uut_0  (Io, Cle, Ale, Ce_n,  We_n, Re_n, Wp_n, Rb_n );
    nand_die_model uut_1  (Io, Cle, Ale, Ce2_n,  We_n, Re_n, Wp_n, Rb2_n );

 `else `ifdef G16
    defparam uut_0.mds = 3'b010;
	defparam uut_1.mds = 3'b011;
    defparam uut_2.mds = 3'b110;
	defparam uut_3.mds = 3'b111;

    nand_die_model uut_0  (Io, Cle, Ale, Ce_n,  We_n, Re_n, Wp_n, Rb_n );
    nand_die_model uut_1  (Io, Cle, Ale, Ce_n,  We_n, Re_n, Wp_n, Rb_n );
    nand_die_model uut_2  (Io, Cle, Ale, Ce2_n,  We_n, Re_n, Wp_n, Rb2_n );
    nand_die_model uut_3  (Io, Cle, Ale, Ce2_n,  We_n, Re_n, Wp_n, Rb2_n );

`endif `endif `endif
endmodule
