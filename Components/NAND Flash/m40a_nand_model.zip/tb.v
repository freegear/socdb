////////////////////////////////////////////////
//[Disclaimer]    
//This software code and all associated documentation, comments
//or other information (collectively "Software") is provided 
//"AS IS" without warranty of any kind. MICRON TECHNOLOGY, INC. 
//("MTI") EXPRESSLY DISCLAIMS ALL WARRANTIES EXPRESS OR IMPLIED,
//INCLUDING BUT NOT LIMITED TO, NONINFRINGEMENT OF THIRD PARTY
//RIGHTS, AND ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS
//FOR ANY PARTICULAR PURPOSE. MTI DOES NOT WARRANT THAT THE
//SOFTWARE WILL MEET YOUR REQUIREMENTS, OR THAT THE OPERATION OF
//THE SOFTWARE WILL BE UNINTERRUPTED OR ERROR-FREE. FURTHERMORE,
//MTI DOES NOT MAKE ANY REPRESENTATIONS REGARDING THE USE OR THE
//RESULTS OF THE USE OF THE SOFTWARE IN TERMS OF ITS CORRECTNESS,
//ACCURACY, RELIABILITY, OR OTHERWISE. THE ENTIRE RISK ARISING OUT
//OF USE OR PERFORMANCE OF THE SOFTWARE REMAINS WITH YOU. IN NO
//EVENT SHALL MTI, ITS AFFILIATED COMPANIES OR THEIR SUPPLIERS BE
//LIABLE FOR ANY DIRECT, INDIRECT, CONSEQUENTIAL, INCIDENTAL, OR
//SPECIAL DAMAGES (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS
//OF PROFITS, BUSINESS INTERRUPTION, OR LOSS OF INFORMATION)
//ARISING OUT OF YOUR USE OF OR INABILITY TO USE THE SOFTWARE,
//EVEN IF MTI HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//Because some jurisdictions prohibit the exclusion or limitation
//of liability for consequential or incidental damages, the above
//limitation may not apply to you.
//
//Copyright 2006 Micron Technology, Inc. All rights reserved.
////////////////////////////////////////////////
`timescale 1ns / 100ps

module tb;

`include "parameters.v"

    // Ports Declaration
    reg  [DQ_BITS - 1 : 0] Io;
    reg                      Cle;
    reg                      Ale;
    reg                      Ce_n;
    reg                      Re_n;
    reg                      We_n;
    reg                      Wp_n;
	reg						 Ce2_n;
	reg						 Pre;
	reg						 Lock;
	tri1 					 Rb2_n;	//pullup
    tri1                     Rb_n;  // pullup

	parameter				 tRP = tCEA_max +5; // Re_n low pulse width, adjust as needed
	parameter				 tREH = tRHZ_max + 5; // Re_n high width, adjust as needed
	parameter				 tRC = tRP + tREH;

    wire [DQ_BITS - 1 : 0] IO = Io;
	reg rd_verify;
	reg device;
	reg [DQ_BITS -1 : 0] rd_dq;
	initial begin
		rd_verify = 0;
		device = 0;
	end

    // Instantiate Device
	`ifdef LOCK
	   `ifdef PRE
           nand_model uut  (IO, Cle, Ale, Ce_n, Ce2_n, We_n, Re_n, Wp_n, Rb_n, Rb2_n, Pre, Lock);
	   `else
    	   nand_model uut  (IO, Cle, Ale, Ce_n, Ce2_n, We_n, Re_n, Wp_n, Rb_n, Rb2_n, Lock);
	   `endif
	`else
	   `ifdef PRE
           nand_model uut  (IO, Cle, Ale, Ce_n, Ce2_n, We_n, Re_n, Wp_n, Rb_n, Rb2_n, Pre);
	   `else
    	   nand_model uut  (IO, Cle, Ale, Ce_n, Ce2_n, We_n, Re_n, Wp_n, Rb_n, Rb2_n);
	   `endif
	`endif

	// 0 = dies controlled by Ce_n, 1 = dies controlled by Ce2_n
	task activate_device;
	input dev;
	begin
		device = dev;
		if (dev==1) begin
	        Ce_n = 1;
			Ce2_n = 0;
		end else begin
    	    Ce_n = 0;
			Ce2_n = 1;
		end
	end
	endtask

    // Wait Ready : wait for ready->busy->ready
    task wait_ready;
    begin
		if (device == 1) begin
	        if (Rb2_n === 1) begin
    	        wait (Rb2_n === 0);
        	    wait (Rb2_n === 1);
	        end else if (Rb2_n === 0) begin
	   	        wait (Rb2_n === 1);
        	end
    	    #tRR_min;
		end else begin
	        if (Rb_n === 1) begin
    	        wait (Rb_n === 0);
        	    wait (Rb_n === 1);
	        end else if (Rb_n === 0) begin
	   	        wait (Rb_n === 1);
        	end
    	    #tRR_min;
		end
    end
    endtask

	//pulse Re_n to latch read data
	task latch_read;
	parameter trl=tRP;
	parameter trh=(tRC - tRP);
    begin
        Cle = 0;
        Ale = 0;
      	Re_n <= 0;
        #(trl);
      	Re_n <= 1;
        #(trh);
    end
    endtask
/*
	//pulse Re_n to latch read data, EDO mode
	task latch_read;
	parameter trl=tRP;
	parameter trh=(tRC - tRP);
    begin
        Cle = 0;
        Ale = 0;
      	Re_n <= 0;
        #(tRP_min+1);
      	Re_n <= 1;
        #(tRC_min - tRP_min);
    end
    endtask
*/
	//pulse Re_n to latch read data
	//special timing for Programmable DriveStrength
	task latch_read_pio;
	parameter trl=tRPIO_min;
	parameter trh=tRPIO_min;
    begin
        Cle = 0;
        Ale = 0;
      	Re_n <= 0;
        #(trl);
      	Re_n <= 1;
        #(trh);
    end
    endtask

    task latch_address;
    input [DQ_BITS - 1 : 0] addr_in;
    begin
		#tALS_min;
        We_n = 0;
        Re_n = 1;  // 0 active
        //Wp_n = 1; 
        Cle = 0;
      Ale = 1;
        Io[7:0] = addr_in;
        `ifdef x16
            Io[15:8] = 8'b0;
        `endif
        #tWP_cache_min; 
		We_n = 1;
        #(tWC_cache_min - tWP_cache_min);  
        Io = {DQ_BITS{1'bz}};
      Ale = 0;
    end
    endtask

    task latch_command;
    input [DQ_BITS - 1 : 0] data_in;
    begin
        #(tRHW_min + tCLS_cache_min);  
     	We_n = 0;
        Ale = 0;
        Cle = 1;
        Io = data_in;
        #tWP_cache_min;     
        We_n = 1;
        #(tWH_cache_min + tCLH_cache_min); 
        Cle = 0;
        Io = {DQ_BITS{1'bz}};
    end
    endtask


    task latch_command_pio;
    input [DQ_BITS - 1 : 0] data_in;
    begin
        #(tRHW_min + tCLSIO_min);  
     	We_n = 0;
        Ale = 0;
        Cle = 1;
        Io = data_in;
        #tWPIO_min;     
        We_n = 1;
        #(tWHIO_min + tCLHIO_min); 
        Cle = 0;
        Io = {DQ_BITS{1'bz}};
    end
    endtask

	//pulse we to latch write data
    task latch_data;
        input [DQ_BITS - 1 : 0] data_in;
    begin
		#(tWP_cache_min - (tWH_cache_min - tDH_cache_min));
      We_n = 0;
        Ale = 0;
        #(tWP_cache_min-tDS_cache_min);  
        Ale = 0;
        Io = data_in;
        #tWP_cache_min;       // 10 ns
      We_n = 1;
		#(tWC_cache_min - tWP_cache_min);
        //#tDH_min;
        Io = {DQ_BITS{1'bz}};
        #(tWH_cache_min-tDH_cache_min);
    end
    endtask

    task latch_data_pio;
        input [DQ_BITS - 1 : 0] data_in;
    begin
		#(tWPIO_min - (tWHIO_min - tDHIO_min));
      We_n = 0;
        Ale = 0;
        #(tWPIO_min-tDSIO_min);  
        Ale = 0;
        Io = data_in;
        #tWPIO_min;       // 10 ns
      We_n = 1;
		#(tWCIO_min - tWPIO_min);
        //#tDH_min;
        Io = {DQ_BITS{1'bz}};
        #(tWHIO_min-tDHIO_min);
    end
    endtask

    // Status Read (70h)
    task status_read;
    begin
    	$display ("tb.status_read at time %t", $time);
      	latch_command (8'h70);
		#tWHR_min;
	end
	endtask

	//No Op
	task nop;
	input trc;
	real trc;
	begin
		#trc;
	end
	endtask

	// 0 = regular lock, 1 = locktight
	task lock_block;
	input locktight;
	begin
		if (locktight === 1'b1) begin
			latch_command(8'h2C);
		end else begin
			latch_command(8'h2A);
		end
	end
	endtask

    task get_drivestrength;
    begin
        // Decode Command
        latch_command_pio (8'hB8);
        #tWHRIO_min;
    end
    endtask

    task set_drivestrength;
        input [7 : 0] drivestrength;
    begin
        // Decode Command
        latch_command_pio (8'hB8);
        latch_data_pio (drivestrength);
        #tWHRIO_min;
    end
    endtask

    // multi die status read
    task multi_die_status_read;
        input [BLCK_BITS - 1 : 0] blck_addr;

        reg   [DQ_BITS - 1 : 0] row_addr_1;
        reg   [DQ_BITS - 1 : 0] row_addr_2;
        reg   [DQ_BITS - 1 : 0] row_addr_3;
    begin
        // Decode Address
        row_addr_1 [7 : 0] = {blck_addr [(7 - PAGE_BITS):0],{PAGE_BITS {1'b0}}};
        row_addr_2 [7 : 0] = blck_addr [(15 - PAGE_BITS) : (8 - PAGE_BITS)];
		`ifdef TWO_ROW
		`else 
        	row_addr_3 [7 : 0] = {{(24 - (BLCK_BITS + PAGE_BITS)){1'b0}}, blck_addr [(BLCK_BITS -1) : (16 - PAGE_BITS)]};
		`endif

        // Decode Command
        latch_command (8'h78);
        latch_address (row_addr_1);
        latch_address (row_addr_2);
		`ifdef TWO_ROW
		`else 
	        latch_address (row_addr_3);
		`endif
        #(tWHR_min);
    end
    endtask

    // locked block status read
    task block_lock_status_read;
        input [BLCK_BITS - 1 : 0] blck_addr;

        reg   [DQ_BITS - 1 : 0] row_addr_1;
        reg   [DQ_BITS - 1 : 0] row_addr_2;
        reg   [DQ_BITS - 1 : 0] row_addr_3;
    begin
        // Decode Address
        row_addr_1 [7 : 0] = {blck_addr [(7 - PAGE_BITS):0],{PAGE_BITS {1'b0}}};
        row_addr_2 [7 : 0] = blck_addr [(15 - PAGE_BITS) : (8 - PAGE_BITS)];
		`ifdef TWO_ROW
		`else
        row_addr_3 [7 : 0] = {{(24 - (BLCK_BITS + PAGE_BITS)){1'b0}}, blck_addr [(BLCK_BITS -1) : (16 - PAGE_BITS)]};
		`endif

        // Decode Command
        latch_command (8'h7A);
        latch_address (row_addr_1);
        latch_address (row_addr_2);
		`ifdef TWO_ROW
		`else
        latch_address (row_addr_3);
		`endif
		#tWHR_min;
    end
    endtask

	task unlock_block;
        input [BLCK_BITS - 1 : 0] blck_addr_one;
        input [BLCK_BITS - 1 : 0] blck_addr_two;
		input invert;

        reg   [DQ_BITS - 1 : 0] row_addr_1_one;
        reg   [DQ_BITS - 1 : 0] row_addr_2_one;
        reg   [DQ_BITS - 1 : 0] row_addr_3_one;
        reg   [DQ_BITS - 1 : 0] row_addr_1_two;
        reg   [DQ_BITS - 1 : 0] row_addr_2_two;
        reg   [DQ_BITS - 1 : 0] row_addr_3_two;

    begin
        row_addr_1_one [7 : 0] = {blck_addr_one [(7 - PAGE_BITS):0], {(PAGE_BITS-1){1'b0}}, invert};
        row_addr_2_one [7 : 0] = blck_addr_one [(15 - PAGE_BITS) : (8 - PAGE_BITS)];
        row_addr_1_two [7 : 0] = {blck_addr_two [(7 - PAGE_BITS):0], {(PAGE_BITS -1){1'b0}}, invert};
        row_addr_2_two [7 : 0] = blck_addr_two [(15 - PAGE_BITS) : (8 - PAGE_BITS)];
		`ifdef TWO_ROW
		`else
	        row_addr_3_one [7 : 0] = {{(24 - (BLCK_BITS + PAGE_BITS)){1'b0}}, blck_addr_one [(BLCK_BITS -1) : (16 - PAGE_BITS)]};
    	    row_addr_3_two [7 : 0] = {{(24 - (BLCK_BITS + PAGE_BITS)){1'b0}}, blck_addr_two [(BLCK_BITS -1) : (16 - PAGE_BITS)]};
		`endif
        // Decode Command
        latch_command (8'h23);
        latch_address (row_addr_1_one);
        latch_address (row_addr_2_one);
		`ifdef TWO_ROW
		`else
	        latch_address (row_addr_3_one);
		`endif
        latch_command (8'h24);
        latch_address (row_addr_1_two);
        latch_address (row_addr_2_two);
		`ifdef TWO_ROW
		`else
	        latch_address (row_addr_3_two);
		`endif
		#tWHR_min;

	end
	endtask

    // Erase Block (60h -> D0h)
    //      tp	 = address is 1st of two planes
    task erase_block;
        input [BLCK_BITS - 1 : 0] blck_addr;
		input tp;

        reg   [DQ_BITS - 1 : 0] row_addr_1;
        reg   [DQ_BITS - 1 : 0] row_addr_2;
        reg   [DQ_BITS - 1 : 0] row_addr_3;
    begin
        // Decode Address
        row_addr_1 [7 : 0] = {blck_addr [(7 - PAGE_BITS):0],{PAGE_BITS {1'b0}}};
        row_addr_2 [7 : 0] = blck_addr [(15 - PAGE_BITS) : (8 - PAGE_BITS)];
		`ifdef TWO_ROW
		`else
	        row_addr_3 [7 : 0] = {{(24 - (BLCK_BITS + PAGE_BITS)){1'b0}}, blck_addr [(BLCK_BITS -1) : (16 - PAGE_BITS)]};
		`endif
        // Decode Command
        latch_command (8'h60);
        latch_address (row_addr_1);
        latch_address (row_addr_2);
		`ifdef TWO_ROW
		`else
       		 latch_address (row_addr_3);
		`endif
		if (~tp) begin
	        latch_command (8'hD0);
		end
        #tRR_min;
    end
    endtask

    // Two plane Page Read (00h -> 00h -> 30h)
    // blck_addr = block address
    // page_addr = page address
    //  col_addr = column address
    //      tp	 = address is 1st of two planes
	//    idm    = read for internal data move
	//    otp    = OTP page read
    task read_page;
        input [BLCK_BITS - 1 : 0] blck_addr;
        input [PAGE_BITS - 1 : 0] page_addr;
        input [COL_BITS - 1 : 0]  col_addr;
		input tp;
		input idm;
		input otp;

        reg   [DQ_BITS - 1 : 0] col_addr_1;
        reg   [DQ_BITS - 1 : 0] col_addr_2;
        reg   [DQ_BITS - 1 : 0] row_addr_1;
        reg   [DQ_BITS - 1 : 0] row_addr_2;
        reg   [DQ_BITS - 1 : 0] row_addr_3;

    begin
		if (otp && (tp || idm)) $display("ERROR: Illegal task option.  Can't read OTP page with twoplane or internal data move");
        // Decode Address
        col_addr_1 [7 : 0] = col_addr [7 : 0];
        col_addr_2 [7 : 0] = {{(16 - COL_BITS){1'b0}}, col_addr [(COL_BITS -1) : 8]};
        row_addr_1 [7 : 0] = {blck_addr [(7 - PAGE_BITS):0], page_addr [(PAGE_BITS -1) : 0]};
        row_addr_2 [7 : 0] = blck_addr [(15 - PAGE_BITS) : (8 - PAGE_BITS)];
		`ifdef TWO_ROW
		`else
	        row_addr_3 [7 : 0] = {{(24 - (BLCK_BITS + PAGE_BITS)){1'b0}}, blck_addr [(BLCK_BITS -1) : (16 - PAGE_BITS)]};
		`endif
        // Decode Command
		if (otp) begin
	        latch_command (8'hAF);
		end else begin
	        latch_command (8'h00);
		end
        latch_address (col_addr_1);
        latch_address (col_addr_2);
        latch_address (row_addr_1);
		if (otp) begin
			latch_address (8'h00);
			`ifdef TWO_ROW
			`else
				latch_address (8'h00);
			`endif
		end else begin
	        latch_address (row_addr_2);
			`ifdef TWO_ROW
			`else
    	    	latch_address (row_addr_3);
			`endif
		end

		if (~tp) begin
			if (idm) begin
	    	    latch_command (8'h35);
			end else begin
		        latch_command (8'h30);
			end
		end
    end
    endtask
	
	task cache_read;
	input last;
	begin
		if (last) begin
			latch_command(8'h3F);
		end else begin
			latch_command(8'h31);
		end
	end
	endtask

	//tp =  0 = page random data (2 address cycles)
	//  	1 = two-plane random data (5 address cycles)
	task random_data_read;
        input [BLCK_BITS - 1 : 0] blck_addr;
        input [PAGE_BITS - 1 : 0] page_addr;
        input [COL_BITS - 1 : 0]  col_addr;
		input tp;

        reg   [DQ_BITS - 1 : 0] col_addr_1;
        reg   [DQ_BITS - 1 : 0] col_addr_2;
        reg   [DQ_BITS - 1 : 0] row_addr_1;
        reg   [DQ_BITS - 1 : 0] row_addr_2;
        reg   [DQ_BITS - 1 : 0] row_addr_3;
	begin
        col_addr_1 [7 : 0] = col_addr [7 : 0];
        col_addr_2 [7 : 0] = {{(16 - COL_BITS){1'b0}}, col_addr [(COL_BITS -1) : 8]};
        row_addr_1 [7 : 0] = {blck_addr [(7 - PAGE_BITS):0], page_addr [(PAGE_BITS -1) : 0]};
        row_addr_2 [7 : 0] = blck_addr [(15 - PAGE_BITS) : (8 - PAGE_BITS)];
		`ifdef TWO_ROW
		`else
	        row_addr_3 [7 : 0] = {{(24 - (BLCK_BITS + PAGE_BITS)){1'b0}}, blck_addr [(BLCK_BITS -1) : (16 - PAGE_BITS)]};
		`endif

		if (tp) begin
	        latch_command (8'h06);
    	    latch_address (col_addr_1);
	        latch_address (col_addr_2);
        	latch_address (row_addr_1);
    	    latch_address (row_addr_2);
			`ifdef TWO_ROW
			`else
		        latch_address (row_addr_3);
			`endif
		end else begin
	        latch_command (8'h05);
    	    latch_address (col_addr_1);
	        latch_address (col_addr_2);
		end
        latch_command (8'hE0);
		#tWHR_min;
	end
	endtask

    // Program Page (80h -> 10h)
    // blck_addr = block address
    // page_addr = page address
    //  col_addr = column address
    //      data = your first data value
    //      size = number of serial data to be written
    //   pattern = modify data pattern
	//             00 = no change
    //             01 = inc
   	//             10 = dec
  	//             11 = random

    //    tp	 = address is 1st of two planes
	//    idm    = program for internal data move
	//	  		   0 = no idm
	//			   1 = program for internal data move (for 2plane, 1st half of idm program)
	//    otp    = OTP page read
	//	 cache   = cache mode program (not last page)
	//   final  = if low, will not finalize write -- indicates that a random data write will follow
    task program_page;
        input [BLCK_BITS - 1 : 0] blck_addr;
        input [PAGE_BITS - 1 : 0] page_addr;
        input [COL_BITS  - 1 : 0] col_addr;
        input [DQ_BITS - 1 : 0] data;
        input [COL_BITS  - 1 : 0] size;
        input             [1 : 0] pattern;
		input tp;
		input idm;
		input otp;
		input cache;
		input final;

        reg   [DQ_BITS - 1 : 0] col_addr_1;
        reg   [DQ_BITS - 1 : 0] col_addr_2;
        reg   [DQ_BITS - 1 : 0] row_addr_1;
        reg   [DQ_BITS - 1 : 0] row_addr_2;
        reg   [DQ_BITS - 1 : 0] row_addr_3;
        reg   [COL_BITS  - 1 : 0] i;
    begin

		if (otp && (tp || idm || cache)) $display("ERROR: Illegal task option.  Can't write OTP page with cache, twoplane, or internal data move commands");

        // Decode Address
        col_addr_1 [7 : 0] = col_addr [7 : 0];
        col_addr_2 [7 : 0] = {{(16 - COL_BITS){1'b0}}, col_addr [(COL_BITS -1) : 8]};
        row_addr_1 [7 : 0] = {blck_addr [(7 - PAGE_BITS):0], page_addr [(PAGE_BITS -1) : 0]};
        row_addr_2 [7 : 0] = blck_addr [(15 - PAGE_BITS) : (8 - PAGE_BITS)];
		`ifdef TWO_ROW
		`else
	        row_addr_3 [7 : 0] = {{(24 - (BLCK_BITS + PAGE_BITS)){1'b0}}, blck_addr [(BLCK_BITS -1) : (16 - PAGE_BITS)]};
		`endif

        // Decode Command
		if (otp) begin
	        latch_command (8'hA0);
		end else begin
			if (idm) begin
		        latch_command (8'h85);
			end else begin
		        latch_command (8'h80);
			end
		end
        latch_address (col_addr_1);
        latch_address (col_addr_2);
        latch_address (row_addr_1);
		if (otp) begin
			latch_address (8'h00);
			`ifdef TWO_ROW
			`else
				latch_address (8'h00);
			`endif
		end else begin
	        latch_address (row_addr_2);
			`ifdef TWO_ROW
			`else
		        latch_address (row_addr_3);
			`endif
		end

		#tADL_min;
				
		if (~idm && (size != 0)) begin
		//only input data if not an internal data move
		//random data writes are in a separate task

        	// Decode Pattern
	        for (i = 0; i <= size - 1; i = i + 1) begin
    	        case (pattern)
        	        2'b00 : latch_data (data);
            	    2'b01 : latch_data (data + i);
	                2'b10 : latch_data (data - i);
    	            2'b11 : latch_data ({$random} % {DQ_BITS{1'b1}});
        	    endcase
	        end
		end

        // Done Program
	    if (final) begin
			if (tp) begin
				latch_command (8'h11);
			end else begin
				if (cache) begin
			        latch_command (8'h15);
				end else begin
					//if (~idm[0]) begin
				        latch_command (8'h10);
					//end
				end
			end
		end
    end
    endtask

	//used to write data to a random col address on current page
    //    tp	 = address is 1st of two planes
	//	 cache   = cache mode program (not last page)
	//   final  = if low, will not finalize write -- indicates that a random data write will follow
	task random_data_write;
        input [COL_BITS - 1 : 0]  col_addr;
        input [DQ_BITS - 1 : 0] data;
        input [COL_BITS  - 1 : 0] size;
        input             [1 : 0] pattern;
		input tp;
		input cache;
		input final;

        reg   [DQ_BITS - 1 : 0] col_addr_1;
        reg   [DQ_BITS - 1 : 0] col_addr_2;
        reg   [COL_BITS  - 1 : 0] i;
	begin
        col_addr_1 [7 : 0] = col_addr [7 : 0];
        col_addr_2 [7 : 0] = {{(16 - COL_BITS){1'b0}}, col_addr [(COL_BITS -1) : 8]};

        latch_command (8'h85);
   	    latch_address (col_addr_1);
        latch_address (col_addr_2);

		#tADL_min;

	    // Decode Pattern
    	for (i = 0; i <= size - 1; i = i + 1) begin
        case (pattern)
            2'b00 : latch_data (data);
            2'b01 : latch_data (data + i);
            2'b10 : latch_data (data - i);
            2'b11 : latch_data ({$random} % {DQ_BITS{1'b1}});
        endcase
	    end
		if (final) begin
			if (tp) begin
				latch_command (8'h11);
			end else begin
				if (cache) begin
					latch_command (8'h15);
				end else begin
					latch_command (8'h10);
				end
			end
		end
	end
	endtask


    task OTP_protect;
    begin

        // Decode Command
        latch_command (8'hA5);
        latch_address (8'h00);
        latch_address (8'h00);
        latch_address (8'h01);
        latch_address (8'h00);
        latch_address (8'h00);
        latch_command (8'h10);
        wait_ready;
    end
    endtask

    // reset (FFh) - 
    task reset;
    begin
        latch_command (8'hFF);
        //wait_ready;
    end
    endtask

    // Read ID (90h) - 
    task read_id;
	integer i;
    begin
        latch_command (8'h90);
        latch_address (0);
        #tWHR_min
		for (i = 0; i < NUM_ID_BYTES; i = i + 1)
        	begin 
        		latch_read;   // Byte i
			end
    end
    endtask

	//reads static ONFI regs
	task read_onfi;
	integer i;
	begin
		latch_command (8'h90);
		latch_address (8'h20);
        #tWHR_min
		for (i = 0; i < 4; i = i + 1)
        	begin 
        		latch_read;   // Byte i
			end
	end
	endtask

    // Read speacial
	// special = special page read data
	//			 0 = read ID2 
	//			 1 = read unique
    task read_special;  // Not inherited from read_id, rather from page_read
	input sel;
    reg [12:0] i;
    begin
        latch_command (8'h30);
        latch_command (8'h65);
        latch_command (8'h00);
        latch_address (0);
		if (sel) begin
			//read_unique
	        latch_address (0);
		end else begin
			//read_id2
    	    latch_address (2);
		end
        latch_address (2);
        latch_address (0);
        latch_address (0);
        latch_command (8'h30);
        wait_ready;
        #tRR_min;
        // Serial Read
        for (i = 0; i <= 255; i = i + 1) 
           begin
              latch_read;   // Byte 0
           end
        #tRR_min;
    end
    endtask

	//pulse Re_n and compares output data to expected value
	task serial_read;
		input [DQ_BITS -1: 0] data;
		input [1:0] pattern;
		input [ROW_BITS -1: 0] size;
		integer i;
		begin
        	// Serial Read
		    $display ("LATCH READ size=%0d,\t data=%0h,\t pattern=%0d", size, data, pattern);
    		for (i = 0; i <= size - 1; i = i + 1) begin
				latch_and_check_data(data);
            	case (pattern)
	                2'b00 : ;
    	            2'b01 : data = data + 1;
        	        2'b10 : data = data - 1;
            	    2'b11 : data = 0;
	            endcase
    	    end
	    	#tRR_min;	
		end
	endtask

	task serial_read_pio;
		input [DQ_BITS -1: 0] data;
		begin
				latch_and_check_data_pio(data);
				#tRR_min;
		end
	endtask

	task latch_and_check_data;
	input [DQ_BITS -1: 0] exp_data;
	begin
		rd_dq = exp_data;
		rd_verify <= #(tREA_max -1) 1'b1;
		//rd_verify <= 1'b1;
		latch_read;
	end
	endtask

	task latch_and_check_data_pio;
	input [DQ_BITS -1: 0] exp_data;
	begin
		rd_dq = exp_data;
		rd_verify <= 1;
		latch_read_pio;
	end
	endtask

    always @(IO) begin : data_verify
        integer i;
	   if (rd_verify ) begin
        // Verify the data word after output delay
        //if ((IO ^ rd_dq) !== {DQ_BITS{1'b0}}) begin
        if (IO !== rd_dq) begin
                $display ("%m at time %t: ERROR: Read data miscompare: Expected = %h, Actual = %h", $time, rd_dq, IO);
        end
        rd_verify <= 1'b0;
	   end
    end


    reg test_done;
	initial test_done = 0;

    // End-of-test triggered in 'subtest.vh'
    always @(test_done) begin : all_done
		if (test_done == 1) begin
      #5000
      $display ("Simulation is Complete");
			$stop(0);
			$finish;
		end
	end

	
	`include "subtest.vh"

endmodule
