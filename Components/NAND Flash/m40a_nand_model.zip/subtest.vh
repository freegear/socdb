initial begin : test

Pre   <= 1'b0; 
Lock  <= 1'b0; 
Cle   <= 1'b0; 
Ce_n  <= 1'b1; 
Ce2_n <= 1'b1; 
We_n  <= 1'b1; 
Ale   <= 1'b0; 
Re_n  <= 1'b1; 
Wp_n  <= 1'b1; 
Io   = {DQ_BITS{1'bz}};
nop(tWHR_min);
nop(tRHW_min);
if (Pre===1'b1) begin
     wait_ready;
end
Ce_n = 1'b0;
Ce2_n = 1'b0;
reset;
activate_device(0);
wait_ready;
$display("Powerup complete");
//program_page(block,page,column,data,size,pat,tp,idm,otp,cache,final)
program_page(0, 0, 0, 8'h0, 10, 2, 1, 0, 0, 0, 1);
wait_ready;
//program_page(block,page,column,data,size,pat,tp,idm,otp,cache,final)
program_page(1, 0, 0, 8'h11, 10, 2, 0, 0, 0, 0, 1);
wait_ready;
//read_page(block,page,column,tp,idm,otp)
read_page(0, 0, 0, 1, 1, 0);
//read_page(block,page,column,tp,idm,otp)
read_page(1, 0, 0, 0, 1, 0);
wait_ready;
//program_page(block,page,column,data,size,pat,tp,idm,otp,cache,final)
program_page(2, 0, 0, 8'hFF, 0, 0, 1, 1, 0, 0, 1);
wait_ready;
//program_page(block,page,column,data,size,pat,tp,idm,otp,cache,final)
program_page(3, 0, 0, 8'hFF, 0, 0, 0, 0, 0, 0, 1);
wait_ready;
//program_page(block,page,column,data,size,pat,tp,idm,otp,cache,final)
program_page(4, 0, 0, 8'hFF, 0, 0, 1, 1, 0, 0, 0);
random_data_write(0,8'h12, 10,1,1,0,0);
random_data_write(10,8'h13, 10,1,1,0,0);
random_data_write(20,8'h14, 10,1,1,0,1);
wait_ready;
//program_page(block,page,column,data,size,pat,tp,idm,otp,cache,final)
program_page(5, 0, 0, 8'hFF, 0, 0, 0, 0, 0, 0, 0);
random_data_write(0,8'h21, 10,1,1,0,0);
random_data_write(10,8'h31, 10,1,1,0,0);
random_data_write(20,8'h41, 10,1,0,0,1);
wait_ready;
//read_page(block,page,column,tp,idm,otp)
read_page(0, 0, 0, 1, 0, 0);
//read_page(block,page,column,tp,idm,otp)
read_page(1, 0, 0, 0, 0, 0);
wait_ready;
random_data_read(0,0,0,1);
serial_read(8'h0, 2'h2, 10);
random_data_read(1,0,0,1);
serial_read(8'h11, 2'h2, 10);
//read_page(block,page,column,tp,idm,otp)
read_page(2, 0, 0, 1, 0, 0);
//read_page(block,page,column,tp,idm,otp)
read_page(3, 0, 0, 0, 0, 0);
wait_ready;
serial_read(8'h0, 2'h2, 10);
random_data_read(3,0,0,1);
serial_read(8'h11, 2'h2, 10);
//read_page(block,page,column,tp,idm,otp)
read_page(4, 0, 0, 1, 0, 0);
//read_page(block,page,column,tp,idm,otp)
read_page(5, 0, 0, 0, 0, 0);
wait_ready;
serial_read(8'h12, 2'h1, 10);
serial_read(8'h13, 2'h1, 10);
serial_read(8'h14, 2'h1, 10);
random_data_read(5,0,0,1);
serial_read(8'h21, 2'h1, 10);
serial_read(8'h31, 2'h1, 10);
serial_read(8'h41, 2'h1, 10);
$display("SIMULATION ENDING NORMALLY");
test_done = 1;
end

