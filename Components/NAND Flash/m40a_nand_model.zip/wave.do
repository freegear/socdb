onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -format Logic /tb/Wp_n
add wave -noupdate -format Logic /tb/Lock
add wave -noupdate -format Logic /tb/Ce_n
add wave -noupdate -format Logic /tb/Ce2_n
add wave -noupdate -format Logic /tb/Cle
add wave -noupdate -format Logic /tb/Ale
add wave -noupdate -format Logic /tb/We_n
add wave -noupdate -format Logic /tb/Re_n
add wave -noupdate -format Logic /tb/Rb_n
add wave -noupdate -format Logic /tb/Rb2_n
add wave -noupdate -format Literal -radix hexadecimal /tb/IO
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {1120957 ns}
WaveRestoreZoom {496340 ns} {496838 ns}
configure wave -namecolwidth 192
configure wave -valuecolwidth 40
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
