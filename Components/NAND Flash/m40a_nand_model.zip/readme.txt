Disclaimer of Warranty:
-----------------------
This software code and all associated documentation, comments
or other information (collectively "Software") is provided 
"AS IS" without warranty of any kind. MICRON TECHNOLOGY, INC. 
("MTI") EXPRESSLY DISCLAIMS ALL WARRANTIES EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO, NONINFRINGEMENT OF THIRD PARTY
RIGHTS, AND ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS
FOR ANY PARTICULAR PURPOSE. MTI DOES NOT WARRANT THAT THE
SOFTWARE WILL MEET YOUR REQUIREMENTS, OR THAT THE OPERATION OF
THE SOFTWARE WILL BE UNINTERRUPTED OR ERROR-FREE. FURTHERMORE,
MTI DOES NOT MAKE ANY REPRESENTATIONS REGARDING THE USE OR THE
RESULTS OF THE USE OF THE SOFTWARE IN TERMS OF ITS CORRECTNESS,
ACCURACY, RELIABILITY, OR OTHERWISE. THE ENTIRE RISK ARISING OUT
OF USE OR PERFORMANCE OF THE SOFTWARE REMAINS WITH YOU. IN NO
EVENT SHALL MTI, ITS AFFILIATED COMPANIES OR THEIR SUPPLIERS BE
LIABLE FOR ANY DIRECT, INDIRECT, CONSEQUENTIAL, INCIDENTAL, OR
SPECIAL DAMAGES (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS
OF PROFITS, BUSINESS INTERRUPTION, OR LOSS OF INFORMATION)
ARISING OUT OF YOUR USE OF OR INABILITY TO USE THE SOFTWARE,
EVEN IF MTI HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
Because some jurisdictions prohibit the exclusion or limitation
of liability for consequential or incidental damages, the above
limitation may not apply to you.

Copyright 2006 Micron Technology, Inc. All rights reserved.
Getting Started:
----------------
Unzip nand_model.zip to a folder.
Point your simulator to the folder where you located the files.
At the ModelSim command prompt, type "do tb.do"  

File Descriptions:
------------------
nand_model.v        --Full nand model for device
nand_die_model.v    --Model of a single die
parameters.v        --File that contains all parameters used by the model
readme.txt          --This file
tb.v                --Test bench
tb.do               --File that compiles and runs the above files

Defining Die Number
--------------------------
This model is capable of multiple instantiations in multiple die package configurations.  
The nand_model.v will instantiate multiple dies based on the size parameter.

Defining the Organization:
--------------------------
The Verilog compiler directive "`define" may be used to choose between 
multiple organizations supported by the model.  Valid 
organizations include "x16" and "x8", and are listed in the 
parameters.v file.  The organization is used to select the port sizes 
of the model.  The following is an example of defining the organization 
using the ModelSim simulator.

    vlog +define+x8 nand_model.v nand_die_model.v

Allocating Memory:
------------------
The memory size define is mandatory.  The following is an example of 
defining memory size using the ModelSim simulator.

vlog +define+G4 nand_model.v nand_die_model.v

In addition, a set associative array has been implemented to reduce 
the amount of static memory allocated by the model.  The number of 
entries in the array is controlled by the num_row 
parameter, and is equal to (num_row*num_col), it helps to think of rows
as pages.  Directly edit this parameter in the parameters.v file.

It is possible to allocate memory for every address supported by the 
model by using the Verilog compiler directive "`define FullMem".
This procedure will improve simulation performance at the expense of 
system memory.  The following is an example of allocating memory for
every address using the ModelSim simulator.

	vlog +define+FullMem nand_model.v nand_die_model.v
