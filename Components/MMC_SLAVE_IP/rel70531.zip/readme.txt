
//****************************************************************************
//
// DESIGN RELEASE EP560-K1 SD/SDIO/MMC SLAVE CONTROLLER REV 1.0
//
// EUREKA TECHNOLOGY INC.
//
// Copyright (c) by Eureka Technology Inc.
// All rights reserved
//
//****************************************************************************
//
// Rev 1.0 release notes.
//
// Source Code
//
// Per license agreement, the RTL source code are encrypted.
// However, the top level source code (ep560k1.v) and the design
// template, top560.v, are clear source code for easy reference.
// The lower level modules, if they are encrpted, are fully
// synthesizable and can be simulated with any Verilog simulator.
// They are encrypted only to the extended to prevent reverse
// engineering. Other than that, the RTL source code are fully
// usable by ASIC design software.
//
//****************************************************************************
//
// This release of the EP560-K1 OpenCore contains the following files:
//
// 1. src/ep560k1.v : Verilog source file of ep560k1
// 2. src/sd_slave.v : module used by ep560k1
// 3. src/ahdlprim.v : library file
// 4. src/eu_dpramx2.v : Ram module used by ep560k1
// 5. src/top560.v : Top level design template, showing ep560k1 instantiated
//                    inside a chip.
// 6. vector_test/tb560.v: vector based top level testbench
// 7. vector_test/comp_all.do: script for compiling vector test in
//                              ModelSim simulator.
// 8. readme.txt : This file
//
//****************************************************************************
//
// Instruction for vector-based simulation.
//
// 1. Unzip all the files in this release file and preserve the directory
//    structure.
// 3. Compile files 1 to 6 using the Verilog simulator. File 7 can be used
//    as a script for Modelsim or as a guideline for other simulators.
// 4. After all the files are compile, simulate the testbench tb560.
// 5. The testbench is self-checking. It provide input stimulus
//    every clock cycle and compares output with the expected data every
//    clock cycle. If mismatch is found, it prints error message and stops
//    simulation. If no mismatch is found, simulation continues. When
//    finishes, it prints test completion message and stops simulation.
//
//****************************************************************************
//
// Further questions should be directed to:
// Eureka Technology Inc. Tel: 650 960 3800, Fax: 650 960 3805
// email: info@eurekatech.com
//
//****************************************************************************
