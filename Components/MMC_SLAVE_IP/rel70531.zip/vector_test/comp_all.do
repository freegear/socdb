vlib work
vlog ../src/ahdlprim.v
vlog ../src/eu_dpramx2.v
vlog ../src/sd_slave.v
vlog ../src/ep560k1.v
vlog ../src/top560.v
vlog +define+mmc tb560.v
