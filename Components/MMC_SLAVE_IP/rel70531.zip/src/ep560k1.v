//
// ##########################################################################
//
// Copyright (C) by Eureka Technology Inc.
//
// Confidential & Proprietary Information
//
// All Rights Reserved
//
// The use, modification, or duplication of this product is protected
// according to FAR 12.212 and by Eureka's licensing agreement.
// This design contains confidential and proprietary information which
// are the properties of Eureka Technology Inc.
// Unauthorized use, disclosure, duplication, or reproduction are prohibited.
//
// ep560k1 SD Slave controller
//
// Rev 1.0
//
// ##########################################################################
//
// Signal Description:
//
// SD interface:
//		clk			clock input from SD interface
//		cmdin			CMD input pin
//		cmdout			CMD output pin
//		dtin			DAT in pin
//		dtout			DAT out pin
//		oe_cmd			output enable for CMD pin
//		oe_dt			output enable for DAT pin
//
// Memory Card User interface:
//		abort_b			abort current user transaction
//		addr			memory address to user logic
//		ads_b			address strobe, signals to start an access
//		be_b			byte enable, indicating which bytes are transferred
//		blast_b			burst last, signals last word of burst
//		cs_b			chip select for the type of operation requested by user
//		drd			data read line
//		dwr			data write line
//		error			user request caused error
//		rdy_b			data ready or command acknowledgement
//		size			transfer size
//		wr			indicates write or read access
//
// SDIO Function 0 User interface:
//		i0_abort_b		abort curent user transaction
//		i0_addr			function 0 address to user logic
//		i0_ads_b		address strobe, signals to start an access
//		i0_be_b			byte enable, indicating which bytes are transferred
//		i0_blast_b		burst last, signals last word of burst
//		i0_cs_b			chip select
//		i0_drd			data read line
//		i0_dwr			data write line
//		i0_rdy_b		data ready
//		i0_size			number of words being transferred
//		i0_wr			indicates write or read access
//
// SDIO Function 1 User interface:
//		i1_abort_b		abort curent user transaction
//		i1_addr			function 1 address to user logic
//		i1_ads_b		address strobe, signals to start an access
//		i1_be_b			byte enable, indicating which bytes are transferred
//		i1_blast_b		burst last, signals last word of burst
//		i1_cs_b			chip select
//		i1_drd			data read line
//		i1_dwr			data write line
//		i1_rdy_b		data ready
//		i1_size			number of words being transferred
//		i1_wr			indicates write or read access
//
// System and Status Signals:
//		card_ecc_disabled	Card ECC is disabled
//		card_ecc_failed		ECC applied to data, but failed
//		cccr_out		CCCR contents output to user
//		dsr			DSR contents
//		hreset_b		hardware reset
//		pwdin			Password Input
//		pwd_len			Password Length Input
//		rd_thd			read threshold for stream data read
//		sdio_crd_rdy		SDIO card initialization
//		sel_mmc			select MMC
//		sd_dev			indicates if SD Memory and/or SDIO is implemented
//		sreseti_b		soft reset signal to user for SDIO
//		sresetm_b		soft reset signal to user for memory
//
// Static input from user logic:
//		cccr			Card Common Control Registers (SDIO)
//		cccr_upper		Upper most 128 bits of CCCR
//		cid			Card Identification Register (SD Memory)
//		csd			Card Specific Data Register (SD Memory)
//		ecsd			17 input buses for Extended CSD labeled from ecsd_a to ecsdq
//		eps1			Output from FBR register for function 1 relecting EPS value
//		fbr1			Function Basic Register for Function 1 (SDIO)
//		ocr_sdio		Operation Conditions Register for SDIO
//		ocr_mem			Operation Conditions Register for SD Memory/MMC
//		oe_card_detect		Connect the weak pull-up resistor on DT[3]
//		scr			SD Configuration Register (SD Memory)
//
// ###########################################################################
//
`timescale 1ns / 100ps

module ep560k1(
cmdin,
cmdout,
dtin,
dtout,
oe_cmd,
oe_dt,
sdclk,

abort_b,
addr,
ads_b,
be_b,
blast_b,
cs_b,
drd,
dwr,
error,
rdy_b,
size,
wr,

i0_abort_b,
i0_addr,
i0_ads_b,
i0_be_b,
i0_blast_b,
i0_cs_b,
i0_drd,
i0_dwr,
i0_rdy_b,
i0_size,
i0_wr,

i1_abort_b,
i1_addr,
i1_ads_b,
i1_be_b,
i1_blast_b,
i1_cs_b,
i1_drd,
i1_dwr,
i1_rdy_b,
i1_size,
i1_wr,

hreset_b,
oe_card_detect,
pwdin,
pwd_len,
rd_thd,
sdio_crd_rdy,
sel_mmc,
sd_dev,
sreseti_b,
sresetm_b,

card_ecc_disabled,
card_ecc_failed,
cccr,
cccr_out,
cccr_upper,
cid,
csd,
dsr,
ecsd_a,
ecsd_b,
ecsd_c,
ecsd_d,
ecsd_e,
ecsd_f,
ecsd_g,
ecsd_h,
ecsd_i,
ecsd_j,
ecsd_k,
ecsd_l,
ecsd_m,
ecsd_n,
ecsd_o,
ecsd_p,
ecsd_q,
eps1,
fbr1,
ocr_mem,
ocr_sdio,
scr
);

input		cmdin;
output		cmdout;
output		oe_cmd;
input[7:0]	dtin;
output[7:0]	dtout;
output[7:0]	oe_dt;
input		sdclk;

output		abort_b;
output[31:0] 	addr;
output		ads_b;
output[3:0]	be_b;
output		blast_b;
output[1:0]	cs_b;
input[31:0]	drd;
output[31:0]	dwr;
input		error;
input		rdy_b;
output[9:0]	size;
output		wr;

output		i0_abort_b;
output[31:0]	i0_addr;
output		i0_ads_b;
output[3:0]	i0_be_b;
output		i0_blast_b;
output[1:0]	i0_cs_b;
input[31:0]	i0_drd;
output[31:0]	i0_dwr;
input		i0_rdy_b;
output[9:0]	i0_size;
output		i0_wr;

output		i1_abort_b;
output[31:0]	i1_addr;
output		i1_ads_b;
output[3:0]	i1_be_b;
output		i1_blast_b;
output[1:0]	i1_cs_b;
input[31:0]	i1_drd;
output[31:0]	i1_dwr;
input		i1_rdy_b;
output[9:0]	i1_size;
output		i1_wr;

input		card_ecc_disabled;
input		card_ecc_failed;
output[153:17]	cccr_out;
output[15:0]	dsr;
input		hreset_b;
output		oe_card_detect;
input[127:0]	pwdin;
input[7:0]	pwd_len;
input[2:0]	rd_thd;
input		sdio_crd_rdy;
input		sel_mmc;
input[1:0]	sd_dev;
output		sreseti_b;
output		sresetm_b;

input[152:0]	cccr;
input[127:0]	cccr_upper;
input[127:0]	cid;
input[127:0]	csd;
input[7:0]	ecsd_a;
input[31:0]	ecsd_b;
input[7:0]	ecsd_c;
input[7:0]	ecsd_d;
input[7:0]	ecsd_e;
input[7:0]	ecsd_f;
input[7:0]	ecsd_g;
input[7:0]	ecsd_h;
input[7:0]	ecsd_i;
input[7:0]	ecsd_j;
input[7:0]	ecsd_k;
input[7:0]	ecsd_l;
input[7:0]	ecsd_m;
input[7:0]	ecsd_n;
input[7:0]	ecsd_o;
input[7:0]	ecsd_p;
input[7:0]	ecsd_q;
output		eps1;
input[143:0]	fbr1;
input[31:0]	ocr_mem;
input[23:0]	ocr_sdio;
input[63:0]	scr;

wire[9:0]	dtbuf_raddr;
wire[31:0]	dtbuf_rdata;
wire[9:0]	dtbuf_waddr;
wire[31:0]	dtbuf_wdata;
wire		dtbuf_wren;

wire[9:0]	i0_dtbuf_raddr;
wire[31:0]	i0_dtbuf_rdata;
wire[9:0]	i0_dtbuf_waddr;
wire[31:0]	i0_dtbuf_wdata;
wire		i0_dtbuf_wren;

wire[9:0]	i1_dtbuf_raddr;
wire[31:0]	i1_dtbuf_rdata;
wire[9:0]	i1_dtbuf_waddr;
wire[31:0]	i1_dtbuf_wdata;
wire		i1_dtbuf_wren;

//
// ##########################################################################
//
// Instantiate low level modules
//
// ##########################################################################
//
sd_slave sd_slave(
.clk			(sdclk),
.cmdin			(cmdin),
.cmdout			(cmdout),
.dtin			(dtin),
.dtout			(dtout),
.oe_cmd			(oe_cmd),
.oe_dt			(oe_dt),

.abort_b		(abort_b),
.addr			(addr),
.ads_b			(ads_b),
.be_b			(be_b),
.blast_b		(blast_b),
.cs_b			(cs_b),
.drd			(drd),
.dwr			(dwr),
.error			(error),
.rdy_b			(rdy_b),
.size			(size),
.wr			(wr),

.i0_abort_b		(i0_abort_b),
.i0_addr		(i0_addr),
.i0_ads_b		(i0_ads_b),
.i0_be_b		(i0_be_b),
.i0_blast_b		(i0_blast_b),
.i0_cs_b		(i0_cs_b),
.i0_drd			(i0_drd),
.i0_dwr			(i0_dwr),
.i0_rdy_b		(i0_rdy_b),
.i0_size		(i0_size),
.i0_wr			(i0_wr),

.i1_abort_b		(i1_abort_b),
.i1_addr		(i1_addr),
.i1_ads_b		(i1_ads_b),
.i1_be_b		(i1_be_b),
.i1_blast_b		(i1_blast_b),
.i1_cs_b		(i1_cs_b),
.i1_drd			(i1_drd),
.i1_dwr			(i1_dwr),
.i1_rdy_b		(i1_rdy_b),
.i1_size		(i1_size),
.i1_wr			(i1_wr),

.cccr_out		(cccr_out),
.dsr			(dsr),
.hreset_b		(hreset_b),
.oe_card_detect		(oe_card_detect),
.pwdin			(pwdin),
.pwd_len		(pwd_len),
.rd_thd			(rd_thd),
.sdio_crd_rdy		(sdio_crd_rdy),
.sel_mmc		(sel_mmc),
.sd_dev			(sd_dev),
.sreseti_b		(sreseti_b),
.sresetm_b		(sresetm_b),

.card_ecc_disabled	(card_ecc_disabled),
.card_ecc_failed	(card_ecc_failed),
.cccr			(cccr),
.cccr_upper		(cccr_upper),
.cid			(cid),
.csd			(csd),
.ecsd_a			(ecsd_a),
.ecsd_b			(ecsd_b),
.ecsd_c			(ecsd_c),
.ecsd_d			(ecsd_d),
.ecsd_e			(ecsd_e),
.ecsd_f			(ecsd_f),
.ecsd_g			(ecsd_g),
.ecsd_h			(ecsd_h),
.ecsd_i			(ecsd_i),
.ecsd_j			(ecsd_j),
.ecsd_k			(ecsd_k),
.ecsd_l			(ecsd_l),
.ecsd_m			(ecsd_m),
.ecsd_n			(ecsd_n),
.ecsd_o			(ecsd_o),
.ecsd_p			(ecsd_p),
.ecsd_q			(ecsd_q),
.eps1			(eps1),
.fbr1			(fbr1),
.ocr_mem		(ocr_mem),
.ocr_sdio		(ocr_sdio),
.scr			(scr),

.dtbuf_raddr		(dtbuf_raddr),
.dtbuf_rdata		(dtbuf_rdata),
.dtbuf_waddr		(dtbuf_waddr),
.dtbuf_wdata		(dtbuf_wdata),
.dtbuf_wren		(dtbuf_wren),

.i0_dtbuf_raddr		(i0_dtbuf_raddr),
.i0_dtbuf_rdata		(i0_dtbuf_rdata),
.i0_dtbuf_waddr		(i0_dtbuf_waddr),
.i0_dtbuf_wdata		(i0_dtbuf_wdata),
.i0_dtbuf_wren		(i0_dtbuf_wren),

.i1_dtbuf_raddr		(i1_dtbuf_raddr),
.i1_dtbuf_rdata		(i1_dtbuf_rdata),
.i1_dtbuf_waddr		(i1_dtbuf_waddr),
.i1_dtbuf_wdata		(i1_dtbuf_wdata),
.i1_dtbuf_wren		(i1_dtbuf_wren)
);

eu_dpramx2 #(10, 32) dtbuf(
.raddr			(dtbuf_raddr),
.rclk			(sdclk),
.rdata			(dtbuf_rdata),
.waddr			(dtbuf_waddr),
.wclk			(sdclk),
.wdata			(dtbuf_wdata),
.we			(dtbuf_wren)
);

eu_dpramx2 #(10, 32) i0_dtbuf(
.raddr			(i0_dtbuf_raddr),
.rclk			(sdclk),
.rdata			(i0_dtbuf_rdata),
.waddr			(i0_dtbuf_waddr),
.wclk			(sdclk),
.wdata			(i0_dtbuf_wdata),
.we			(i0_dtbuf_wren)
);

eu_dpramx2 #(10, 32) i1_dtbuf(
.raddr			(i1_dtbuf_raddr),
.rclk			(sdclk),
.rdata			(i1_dtbuf_rdata),
.waddr			(i1_dtbuf_waddr),
.wclk			(sdclk),
.wdata			(i1_dtbuf_wdata),
.we			(i1_dtbuf_wren)
);

endmodule
//
// This code is filtered with these parameters defined
// sdm
// sdio
// mmc
