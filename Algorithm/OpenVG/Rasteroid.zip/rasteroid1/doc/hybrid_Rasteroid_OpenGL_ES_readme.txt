
           Hybrid Rasteroid OpenGL ES API Implementation
            -------------------------------------------
               \-----------------------------------/
                          Version 1.0

Copyright Notice
----------------

(C) 2001-2005 Hybrid Graphics Ltd.
All Rights Reserved.

This file is part of the documentation of Hybrid Rasteroid(TM) and is 
subject to licensing conditions between the user and Hybrid Graphics. 
The user must possess a valid license prior to installing, inspecting, 
reviewing or otherwise using any part of Hybrid Rasteroid. Use and/or 
disclosure outside these terms may result in irrepairable harm to 
Hybrid Graphics and legal action against the party in breach.


Introduction
------------
Hybrid Rasteroid allows you to implement real-time graphics 
applications on mobile platforms.

It contains implementations of the OpenGL ES and JSR 184 (M3G) 
APIs. Rasteroid is meant as a tool for mobile content developers, with 
the goal of bringing desktop-quality graphics to mobile devices. The 
Rasteroid OpenGL ES API implementation is based on Hybrid's Gerbera 
OpenGL ES implementation.

Hybrid Rasteroid OpenGL ES implementation conforms to the OpenGL ES 
1.0 API. Hybrid also expects the Implementation to successfully pass 
the Khronos OpenGL ES 1.1 Conformance Process when it is completed.
Hybrid Rasteroid OpenGL ES is based on the published OpenGL(r) ES 1.1 
API specification, but only successfully passing products are licensed 
by Silicon Graphics, Inc. to use the OpenGL ES API trademark. Current 
conformance status can be found at http://www.khornos.org.

The up-to-date version of the OpenGL ES 1.1 specification can be
found at http://www.khronos.org/opengles/spec.html

For more information about Hybrid Rasteroid(TM)
and Hybrid Graphics see http://www.hybrid.fi/

Document last updated: 14 December 2004


API
---

Hybrid Rasteroid OpenGL ES is interfaced through the
OpenGL ES 1.1 and EGL 1.1 APIs. The specifications and manual
pages are available on the Khronos web site
http://www.khronos.org/opengles/

Hybrid's implementation supports multiple extensions, grouped
below:

Supported OpenGL ES 1.0 extensions:
OES_byte_coordinates
OES_compressed_paletted_texture
OES_fixed_point
OES_query_matrix
OES_read_format
OES_single_precision

Supported OpenGL ES 1.1 extensions:
OES_matrix_palette
OES_point_sprite
OES_point_size_array
OES_draw_texture
OES_matrix_get

Supported EGL(tm) 1.1 extensions:
OES_swap_control
OES_render_texture



Thread-Safety
-------------

Hybrid Rasteroid OpenGL ES API implementation is not thread-safe.
This means that you should not mix OpenGL ES calls from
different threads. Hybrid's implementation can be used in a
multi-threaded application, if a global mutex is maintained
to ensure that simultaneous calls to the implementation are
not performed.


Testing
-------

Hybrid Rasteroid OpenGL ES API implementation has been thoroughly
tested using Hybrid's in-house OpenGL ES testing tools. The
implementation also passes all of SGI's OpenGL ES conformance
tests, with zero failures.


Bug Reporting and Technical Support
-----------------------------------

See included release_notes.html file for known issues.

Please direct your comments, suggestions and questions regarding 
Rasteroid to Hybrid's discussion forum at http://forum.hybrid.fi. 

Contact
-------

Hybrid Graphics Ltd.
Et. Makasiinikatu 4
FI-00130 Helsinki
FINLAND
EUROPE
www.hybrid.fi

info@hybrid.fi
Tel. +358 9 6866 380
Fax +358 9 6852 030



Gerbera is a trademark of Hybrid Graphics Ltd.
Rasteroid is a trademark of Hybrid Graphics Ltd.
OpenGL is a registered trademark of Silicon Graphics, Inc
OpenGL ES and the OpenGL ES logo are trademarks of Silicon Graphics, Inc
ARM is a registered trademark of ARM Holdings Plc.
Pocket PC is a registered trademark of Microsoft Corporation
Symbian and all Symbian-based marks and logos are trademarks of Symbian Limited
Windows CE is a trademark of Microsoft Corporation
