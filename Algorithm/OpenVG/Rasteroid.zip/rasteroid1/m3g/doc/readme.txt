
                 Hybrid Graphics M3G implementation
            --------------------------------------------
               \------------------------------------/
                           Version 1.2.0

Copyright Notice
----------------

This file consists of documentation related to Hybrid Graphics's
M3G Implementation and is subject to licensing conditions between 
the user and Hybrid Graphics. The user must possess a valid license 
prior to installing, inspecting, reviewing or otherwise using the 
Hybrid M3G Implementation. Use and/or disclosure outside these terms 
may result in irreparable harm to Hybrid Graphics and legal action 
against the party in breach.


Installing Windows Examples
-----------------------------------------------

To run the examples, Java 2 SDK 1.3 or newer is needed.

The example applications can be run simply by executing their 
corresponding batch files while in the bin directory. The directory
of the Java virtual machine executable (java.exe) must be in the path
environment variable.

There is also a jar/jad pair for the examples located in the bin
directory for running the applications in a MIDP2.0 environment.
Refer to the platform documentation for instructions of installing
Midlets from a jad file.


Building the accompanying applications
--------------------------------------

The package includes source for Hybrid M3G examples for both Java
Standard Edition and MIDP 2.0. An ANT build file is provided for
convenient building of the applications in the build folder.

Prerequisites:
- Java 2 SDK 1.3 or newer
- Apache ANT version 1.6.2 or newer (http://ant.apache.org)
- For building the MIDP applications, the SUN Wireless Toolkit version
2.0 or newer is required (http://java.sun.com/products/j2mewtoolkit)

Building:
- If you are planning to build the MIDP versions of the applications,
set the property "wtk.home" point to the location of your Wireless
Toolkit installation in the file "build/apps.properties".
- The build process takes as arguments the application name (app) and
the target profile (profile). For example (from hybrid/products/m3g):
$ ant -f build/apps.xml -Dapp=examples -Dprofile=jse
- For building the Hybrid M3G examples, "app" must be set to
"examples", "profile" can be either "jse" or "midp".
- The result of the build is placed in the bin directory.

Package Structure
-----------------

Below is listed the directories of the full source distribution. 
Binary and evaluation distributions contain some subset of these.


Directory                       Description
---------                       -----------

** Under hybrid/products/m3g:

bin				Binaries of the example applications
				for both jse and midp.

build                           ANT build file for building the
				examples.

data                            External data files needed to
                                run the examples

doc                             Documentation

tools				Third party build tools

Other Resources
---------------

Mobile 3D Graphics (JSR 184) specification / API documentation  
is available at:
http://jcp.org/aboutJava/communityprocess/final/jsr184/

Some content for testing purposes is available at:
http://www.forum.nokia.com/main/1,6566,040,00.html?fsrParam=2-3-/main.html&fileID=4892

Contact
------

Hybrid Graphics, Ltd.
Et. Makasiinikatu 4 
FI-00130 Helsinki 
Finland
www.hybrid.fi

info@hybrid.fi
Tel. +358 9 6866 380 
Fax +358 9 6852 030

Support e-mail:
m3g-support@hybrid.fi
