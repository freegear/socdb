/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003-2004 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). Please do not use this program/source code 
 * before you have read the EULA and have agreed to be bound by 
 * its terms.
 * 
 * Use and/or disclosure outside these terms may result in 
 * irrepairable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * Description:     Example1
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/Example1.java#1 $
 * $Date: 2004/12/14 $
 * $Author: otso $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.m3g.*;
import java.util.*;

/**
 * Scene graph fractal test.
 * 
 * This example should draw a whirling cloud of white cubes
 * transformed with hierarchial transforms. One of the cubes is bigger
 * than the rest. The camera should follow that cube.
 * 
 */
public class Example1 extends ExampleBase
{

    private World iWorld;
    private Vector iNodes;
    private Vector iAxis;

    public Example1()
    {
        super(SHOW_RENDER_TIME);
    }

    protected void render(int time)
    {
        float angle = time * 0.1f;
        for (int i = 0; i < iNodes.size(); i++)
        {
            Node node = (Node)iNodes.elementAt(i);
            float[] axis = (float[])iAxis.elementAt(i);

            node.setOrientation(angle * axis[3], axis[0], axis[1], axis[2]);
        }

        iWorld.align(null); // throws IllegalStateException on WTK22b
        Graphics3D.getInstance().render(iWorld);
    }

    protected void initialize()
    {
        iWorld = new World();
        iNodes = new Vector();
        iAxis = new Vector();
        Mesh box = createBox();

        Background bg = new Background();
        bg.setColor(0xff204080);
        iWorld.setBackground(bg);

        Camera camera = new Camera();
        camera.setPerspective(90.0f, 1.0f, 1.0f, 100.0f);
        camera.setTranslation(0.0f, 0.0f, 30.0f);
        iWorld.addChild(camera);
        iWorld.setActiveCamera(camera);

        Light light = new Light();
        light.setTranslation(0.0f, 0.0f, 30.0f);
        iWorld.addChild(light);

        Node ground = (Node)box.duplicate();
        ground.setTranslation(0.0f, -20.0f, 0.0f);
        ground.setScale(2.0f, 0.1f, 2.0f);
        iWorld.addChild(ground);

        Node fractal = createRecursive(box, 6);
        iWorld.addChild(fractal);

        Node target = fractal;
        while (target instanceof Group)
        {
            target = ((Group)target).getChild((int)(random() * 2.0f));
        }
        target.scale(3.0f, 3.0f, 3.0f);

        camera.setScale(-1.0f, 1.0f, -1.0f);
        camera.setAlignment(target, Node.ORIGIN, iWorld, Node.Y_AXIS);
    }

    private Node createRecursive(Mesh aBox, int aCounter)
    {
        float scale = 0.7f;
        float offset = 8.0f;

        Node result;
        if (aCounter == 0)
        {
            result = (Node)aBox.duplicate();
        } else
        {
            Node left = createRecursive(aBox, aCounter - 1);
            Node right = createRecursive(aBox, aCounter - 1);
            left.translate(-offset, 0.0f, 0.0f);
            left.scale(scale, scale, scale);
            right.translate(offset, 0.0f, 0.0f);
            right.scale(scale, scale, scale);

            Group group = new Group();
            group.addChild(left);
            group.addChild(right);
            result = group;
        }

        iNodes.addElement(result);
        float[] axis = new float[4];
        axis[0] = (float)random() - 0.5f;
        axis[1] = (float)random() - 0.5f;
        axis[2] = (float)random() - 0.5f;
        axis[3] = (float)random();
        iAxis.addElement(axis);

        return result;
    }
}
