/*------------------------------------------------------------------------
*
* M3G 1.2.0
* -----------------------------------------
*
* (C) 2003 Hybrid Graphics, Ltd.
* All Rights Reserved.
*
* This file consists of unpublished, proprietary source code of
* Hybrid Graphics, and is considered Confidential Information for
* purposes of non-disclosure agreement. Disclosure outside the terms
* outlined in signed agreement may result in irrepairable harm to
* Hybrid Graphics and legal action against the party in breach.
*
* Description:      PlatformServices interface
*
*
* $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/PlatformServices.java#1 $
* $Date: 2004/12/14 $
* $Author: otso $
*
*----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

/**
 * @author antti
 */
public interface PlatformServices
{
    public Object loadImage(String name);
    public String getResourceDir();
}
