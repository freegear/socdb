/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * Description:     Example8
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/Example8.java#1 $
 * $Date: 2004/12/14 $
 * $Author: otso $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.m3g.*;

/**
 * Morphing test.
 */
public class Example8 extends ExampleBase
{

    private MorphingMesh iMorphingMesh;
    private Light iLight;
    private Camera iCamera;
    private int iCurrentFrame;
    private Transform trans;
    private Transform iLightTrans;
    private float[] iWeights;

    public Example8()
    {
        super(SHOW_RENDER_TIME);
        iCurrentFrame = 0;
        trans = new Transform();
        iWeights = new float[2];
    }

    protected void render(int time)
    {
        Background back = new Background();
        back.setColor(0xff404045);
        back.setDepthClearEnable(true);
        Graphics3D.getInstance().clear(back);

        Graphics3D.getInstance().resetLights();
        Graphics3D.getInstance().addLight(iLight, iLightTrans);

        for (int i = 0; i < iWeights.length; i++)
        {
            iWeights[i] = (float) Math.sin(((float) (iCurrentFrame % (60*(i+1)))) / ((float) (60*(i+1))) * Math.PI);
        }
        iCurrentFrame++;
        iMorphingMesh.setWeights(iWeights);

        Graphics3D.getInstance().render(iMorphingMesh, trans);
    }

    protected void initialize()
    {
        VertexArray normals = new VertexArray(6, 3, 1);
        normals.set(0,6,new byte[] {0,0,-127,
                                    0,0,-127,
                                    0,0,-127,
                                    0,0,-127,
                                    0,0,-127,
                                    0,0,-127});

        VertexArray basePositions = new VertexArray(6, 3, 2);
        basePositions.set(0,6,new short[] {-100, -100, 0,
                                          100,  -100, 0,
                                          100,   0, 0,
                                          100,   100, 0,
                                          -100,  100, 0,
                                          -100,  0, 0});

        VertexArray[] targetPos = new VertexArray[2];
        for (int i = 0; i < targetPos.length; i++)
        {
            targetPos[i] = new VertexArray(6,3,2);
            targetPos[i].set(0,6,new short[] {-100,              -100, 0,
                                             100,               -100, 0,
                                             (short)(50*(1-i)+100),   0, 0,
                                             100,                100, 0,
                                             -100,               100, 0,
                                             (short)(-50*i-100), 0, 0});
        }

        TriangleStripArray strip = new TriangleStripArray(new int[] {1, 0, 2, 5, 3, 4},
                                                          new int[] {6});

        VertexBuffer base = new VertexBuffer();
        base.setPositions(basePositions, .1f, null);
        base.setNormals(normals);
        base.setDefaultColor(0xFF0B7FCC);

        VertexBuffer[] targets = new VertexBuffer[2];
        for (int i = 0; i < targets.length; i++)
        {
            targets[i] = new VertexBuffer();
            targets[i].setPositions(targetPos[i], 1.0f, null);
            if (i == 0)
            {
                targets[i].setDefaultColor(0xFFFF0000);
            }
            else
            {
                targets[i].setDefaultColor(0xFF0B7FCC);
            }
        }

        Material material = new Material();
        material.setVertexColorTrackingEnable(true);
        //material.setColor(Material.AMBIENT, 0x124797); // Hybrid darkest blue.
        //material.setColor(Material.DIFFUSE, 0x0B7FCC); // Hybrid dark blue.

        PolygonMode polyMode = new PolygonMode();
        polyMode.setCulling(PolygonMode.CULL_NONE);
        polyMode.setTwoSidedLightingEnable(true);

        Appearance appearance = new Appearance();
        appearance.setMaterial(material);
        appearance.setPolygonMode(polyMode);

        iMorphingMesh = new MorphingMesh(base, targets, strip, appearance);

        iLight = new Light();
        iLight.setMode(Light.DIRECTIONAL);
        iLight.setIntensity(0.7f);
        iLight.setColor(0xFFFFFF);
        iLightTrans = new Transform();
        iLightTrans.postTranslate(-10.f, -10.f, 6.f);

        iCamera = new Camera();
        iCamera.setPerspective(90.f, 1.f, 1.f, 150.f);
        Transform cameraTrans = new Transform();
        cameraTrans.postTranslate(0.f, 0.f, 26.f);
        Graphics3D.getInstance().setCamera(iCamera, cameraTrans);
    }

}

