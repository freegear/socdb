/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * Description:     Example5
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/Example5.java#3 $
 * $Date: 2004/12/21 $
 * $Author: antti $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.m3g.*;

/**
 * Picking test.
 *
 * The scene contains three balls and a sprite rotating around
 * them. On Java Standard Edition platform, the mouse can be used to
 * move the picking point. When picker hits something, normal at the
 * impact point is shown with an elongated box. If the picker hits a
 * ball, the ball turns red.
 *
 */
public class Example5 extends ExampleBase
{

    private static final String FILE_NAME = "pallot";
    private static final String TEXTURE_NAME = "textures/pukki_small.png";
    
    private static final int IMAGE_BASE_SIZE = 128;

    private Fog iFog;
    private World iWorld;
    private Appearance iPickedAppearance;
    private Mesh iPointer;
    private Group iAligner;
    private Image2D iImage;
    private Sprite3D iSprite;
    private Group iGroup;
    private Group boxGroup;
    private float[] boxSpeed = { 1.f, 1.2f, 2.1f };
    private Mesh[] box = new Mesh[3];

    public Example5()
    {
        super(SHOW_RENDER_TIME | USES_CURSOR);
    }

    protected void render(int time)
    {
        Node picked = null;
        Appearance oldAppearance = null;
        RayIntersection ray = new RayIntersection();
        iWorld.pick(-1, getMouseX(), getMouseY(), iWorld.getActiveCamera(), ray);

        if (ray.getIntersected() != null)
        {
            picked = ray.getIntersected();

            if (picked instanceof Mesh)
            {
                oldAppearance = ((Mesh)picked).getAppearance(0);
                ((Mesh)picked).setAppearance(0, iPickedAppearance);
            }
            else if (picked == iSprite)
            {
                boxGroup.setRenderingEnable(true);
            }
            
            float[] f = new float[6];
            float dist = ray.getDistance();
            ray.getRay(f);
            iPointer.setTranslation(
                f[0] + f[3] * dist,
                f[1] + f[4] * dist,
                f[2] + f[5] * dist);

            Transform xform = new Transform();
            ray.getIntersected().getTransformTo(iWorld, xform);
            float[] dir = new float[]{ray.getNormalX(), ray.getNormalY(), ray.getNormalZ(), 0.0f};
            xform.transform(dir);
            iAligner.setTranslation(
                f[0] + f[3] * dist + dir[0],
                f[1] + f[4] * dist + dir[1],
                f[2] + f[5] * dist + dir[2]);
            iPointer.setRenderingEnable(true);

            Material mat = iPointer.getAppearance(0).getMaterial();
            int s = (int)(ray.getTextureS(0) * 256.0f) & 0xff;
            int t = (int)(ray.getTextureT(0) * 256.0f) & 0xff;
            mat.setColor(Material.AMBIENT, 0xff555555);
            mat.setColor(Material.DIFFUSE, 0xff000077 + (s << 16) + (t << 8));
        }
        else
        {
            iPointer.setRenderingEnable(false);
        }
        
        float angle = time * 0.0005f;
        float radius = 100.0f;
        iGroup.setTranslation((float)Math.sin(angle) * radius, 0.0f, (float)Math.cos(angle) * radius);
        
        float boxAngle = time * 0.003f;
        float boxRadius = 30.f;
        box[0].setTranslation((float)Math.sin(boxSpeed[0]*boxAngle) * boxRadius, (float)Math.cos(boxSpeed[0]*boxAngle) * boxRadius,  0.f);
        box[1].setTranslation((float)Math.sin(boxSpeed[1]*boxAngle) * boxRadius, 0.f, (float)Math.cos(boxSpeed[1]*boxAngle) * boxRadius);
        box[2].setTranslation(0.f, (float)Math.sin(boxSpeed[2]*boxAngle) * boxRadius, (float)Math.cos(boxSpeed[2]*boxAngle) * boxRadius);
        
        iWorld.align(null); // throws IllegalStateException on WTK22b

        Graphics3D.getInstance().render(iWorld);

        if (picked != null)
        {
            if (picked instanceof Mesh)
            {
                ((Mesh)picked).setAppearance(0, oldAppearance);
            }
            else if (picked == iSprite)
            {
                boxGroup.setRenderingEnable(false);
            }
        }

    }

    private void traverse(Node aNode)
    {
        if (aNode instanceof Mesh)
        {
            Mesh mesh = (Mesh)aNode;
            for (int i = 0; i < mesh.getSubmeshCount(); i++)
            {
                Appearance app = mesh.getAppearance(i);
                app.setFog(iFog);
            }
        }
        if (aNode instanceof Group)
        {
            Group group = (Group)aNode;
            for (int i = 0; i < group.getChildCount(); i++)
            {
                traverse(group.getChild(i));
            }
        }
    }

    
    protected void initialize()
    {
        iFog = new Fog();
        iFog.setColor(0xFF204080);
        iFog.setMode(Fog.LINEAR);
        iFog.setLinear(170.0f, 320.0f);

        iWorld = (World)load(FILE_NAME)[0];
        traverse(iWorld);
        
        Material mat = new Material();
        mat.setColor(Material.AMBIENT, 0xff000000);
        mat.setColor(Material.DIFFUSE, 0xffff0000);
        iPickedAppearance = new Appearance();
        iPickedAppearance.setMaterial(mat);
        iPickedAppearance.setFog(iFog);

        iAligner = new Group();
        iWorld.addChild(iAligner);

        iPointer = createBox();
        Transform xform = new Transform();
//      xform.postScale(0.03f, 0.03f, 0.15f);
        xform.postScale(0.3f, 0.3f, 1.5f);
//      xform.postScale(2.0f, 2.0f, 10.0f);
        xform.postTranslate(0.0f, 0.0f, 10.0f);
        iPointer.setTransform(xform);
        iPointer.setRenderingEnable(false);
        iPointer.setPickingEnable(false);
        iPointer.setAlignment(iAligner, Node.ORIGIN, iAligner, Node.Y_AXIS);
        iWorld.addChild(iPointer);

        // Texture options (choose one):
        
        // 1. load image TEXTURE_IMAGE
        iImage = new Image2D(Image2D.RGBA, platformServices.loadImage(TEXTURE_NAME));
        
        // 2. create perlin noise image
        //iImage = ProceduralTexture.createPerlinNoiseImage(0, 0, IMAGE_BASE_SIZE, IMAGE_BASE_SIZE, 0, IMAGE_BASE_SIZE, 0, true);

        // 3. create plasma image
        //iImage = ProceduralTexture.createPlasmaImage(IMAGE_BASE_SIZE, IMAGE_BASE_SIZE, true);

        Appearance sapp = new Appearance();
        sapp.setCompositingMode(new CompositingMode());
        sapp.getCompositingMode().setAlphaThreshold(0.5f);
        sapp.setFog(iFog);
        iSprite = new Sprite3D(true, iImage, sapp);
        iSprite.setScale(50.0f, 50.0f, 50.0f);

        iGroup = new Group();
        boxGroup = new Group();
        boxGroup.setRenderingEnable(false);
        iGroup.addChild(iSprite);

        for (int i = 0; i < box.length; i++)
        {
            box[i] = createBox();
            box[i].setScale(0.3f, 0.3f, 0.3f);
            box[i].getAppearance(0).setFog(iFog);
            box[i].setPickingEnable(false);
            boxGroup.addChild(box[i]);
        }
        
        iGroup.addChild(boxGroup);
        iWorld.addChild(iGroup);
    }

}
