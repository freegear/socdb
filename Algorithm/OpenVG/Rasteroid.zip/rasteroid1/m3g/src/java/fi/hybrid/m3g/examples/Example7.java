/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * Description:     Example7
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/Example7.java#1 $
 * $Date: 2004/12/14 $
 * $Author: otso $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.m3g.*;

/**
 * Light test.
 *
 * Scene consists of three balls and two lights. One of the lights
 * rotates around the balls. Highlights etc. should be visible.
 *
 */

public class Example7 extends ExampleBase
{
    private static final String FILE_NAME = "pallot";

    private Light iLight0;
    private World iWorld;

    public Example7()
    {
        super(SHOW_RENDER_TIME);
        iWorld = null;
    }

    protected void render(int time)
    {
        Transform transform = new Transform();
        transform.postRotate(((float)time)/10.f,
                            0.0f, 1.0f, 0.0f);   // rotate around this axis
        iLight0.setTransform(transform);

        Graphics3D.getInstance().render(iWorld);
    }

    protected void initialize()
    {
        iWorld = (World)load(FILE_NAME)[0];
        iLight0 = new Light();
        iLight0.setMode(Light.DIRECTIONAL);
        iWorld.addChild(iLight0);
        iWorld.align(null);
    }
}
