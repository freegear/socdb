/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003-2004 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). Please do not use this program/source code 
 * before you have read the EULA and have agreed to be bound by 
 * its terms.
 * 
 * Use and/or disclosure outside these terms may result in 
 * irrepairable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * Description:     Stub for running examples on Java Standard Edition VM
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/JseStub.java#1 $
 * $Date: 2004/12/14 $
 * $Author: otso $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import java.awt.*;
import java.awt.event.*;
import java.util.Hashtable;

public class JseStub extends Canvas implements KeyListener, WindowListener, MouseMotionListener
{

    private ExampleBase iExample;
    private Frame       iFrame;

    private Graphics    iBackGraphics;
    private Image       iBackImage;

    private int         iCounter;
    private long        intervalStart;
    private float       fps;
    
    private boolean     iStarted;
    private long        elapsed;

    private static final int NUM_FRAMES = 10;
    
    private static Hashtable keymap = new Hashtable();
    static {
        keymap.put(new Integer(KeyEvent.VK_0), new Integer(ExampleBase.KEY_0));
        keymap.put(new Integer(KeyEvent.VK_1), new Integer(ExampleBase.KEY_1));
        keymap.put(new Integer(KeyEvent.VK_2), new Integer(ExampleBase.KEY_2));
        keymap.put(new Integer(KeyEvent.VK_3), new Integer(ExampleBase.KEY_3));
        keymap.put(new Integer(KeyEvent.VK_4), new Integer(ExampleBase.KEY_4));
        keymap.put(new Integer(KeyEvent.VK_5), new Integer(ExampleBase.KEY_5));
        keymap.put(new Integer(KeyEvent.VK_6), new Integer(ExampleBase.KEY_6));
        keymap.put(new Integer(KeyEvent.VK_7), new Integer(ExampleBase.KEY_7));
        keymap.put(new Integer(KeyEvent.VK_8), new Integer(ExampleBase.KEY_8));
        keymap.put(new Integer(KeyEvent.VK_9), new Integer(ExampleBase.KEY_9));
        keymap.put(new Integer(KeyEvent.VK_UP), new Integer(ExampleBase.KEY_UP));
        keymap.put(new Integer(KeyEvent.VK_RIGHT), new Integer(ExampleBase.KEY_RIGHT));
        keymap.put(new Integer(KeyEvent.VK_DOWN), new Integer(ExampleBase.KEY_DOWN));
        keymap.put(new Integer(KeyEvent.VK_LEFT), new Integer(ExampleBase.KEY_LEFT));
        keymap.put(new Integer(KeyEvent.VK_ESCAPE), new Integer(ExampleBase.KEY_EXIT));
        keymap.put(new Integer(KeyEvent.VK_F), new Integer(ExampleBase.KEY_FPS_TOGGLE));
    }
    
    public JseStub(ExampleBase aExample)
    {
        iStarted = false;
        iExample = aExample;

        String title = iExample.getClass().getName();
        System.out.println("Initializing " + title + "...");
        iExample.initialize();
        Frame iFrame = new Frame(title);
        iFrame.addWindowListener(this);
        this.addKeyListener(this);
        this.addMouseMotionListener(this);
        iFrame.add(this);
        iFrame.setSize(400, 400);
        iFrame.setVisible(true);
        setFont(new Font(null, Font.BOLD, 12));
    }

    public void start()
    {
        System.out.println("Starting...");
        iExample.setStartTime((int)System.currentTimeMillis());
        iStarted = true;
        elapsed = -1;
        repaint();
    }
    

    public static void main(String[] args) throws InstantiationException, IllegalAccessException
    {
        if (args.length != 1)
        {
            System.out.println("Usage:\n\tjava -cp<...> JseStub <example number>");
            System.exit(0);
        }
//      System.runFinalizersOnExit(true);
        try 
        {           
            Class exampleClass = Class.forName("fi.hybrid.m3g.examples.Example" + args[0]);
            ExampleBase example = (ExampleBase)exampleClass.newInstance();
            example.setPlatformServices(new JsePlatformServices());
            JseStub stub = new JseStub(example);
            stub.start();
        }   
        catch (ClassNotFoundException notFound)
        {
            System.out.println("Class fi.hybrid.m3g.examples.Example" + args[0] + " not found.");
            System.exit(0);
        }
    }

    public void paint(Graphics g)
    {
        if (iStarted == false)
            return;
        
        long now = System.currentTimeMillis();
        
        int w = getWidth();
        int h = getHeight();
        if ((iExample.getFeatures() & ExampleBase.DOUBLE_BUFFERING) != 0 &&
            (iBackImage == null || iBackImage.getWidth(null) != w || iBackImage.getHeight(null) != h))
        {
            if (iBackGraphics != null)
            {
                iBackGraphics.dispose();
            }
            iBackImage = createImage(w, h);
            iBackGraphics = iBackImage.getGraphics();
            iBackGraphics.setClip(new Rectangle(0, 0, w, h));
        }

        iExample.render((iBackImage == null) ? g : iBackGraphics, getWidth(), getHeight());

        if (iBackImage != null)
        {
            g.drawImage(iBackImage, 0, 0, null);
        }

//       FPS display
        if ((iExample.getFeatures() & ExampleBase.SHOW_RENDER_TIME) != 0)
        {
            // for every NUM_FRAMES frame, count new fps
            if (iCounter % NUM_FRAMES == 0)
            {
                if (iCounter > 0)
                {
                    long elapsed =  now - intervalStart;
                    fps = ((float)NUM_FRAMES / (float)elapsed) * 1000.f;                    
                }
                
                intervalStart = now;
            }
            
            // display fps
            if (iCounter >= NUM_FRAMES)
            {
                FontMetrics m = g.getFontMetrics();
                g.setColor(Color.white);
                String f = String.valueOf(fps);
                int lenMin = Math.min(f.length(), 5);
                g.drawString(f.substring(0, lenMin), 4, 4 + m.getAscent());
            }

        }    
        iCounter++;

        if ((iCounter++ & 0x7f) == 0)
        {
            System.gc();
        }
        repaint();
    }

    public void update(Graphics g)
    {
        paint(g);
    }

    public void keyPressed(KeyEvent e)
    {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_ESCAPE)
        {
            System.exit(0);
        }
        else if (code == KeyEvent.VK_SPACE)
        {
            System.out.println(Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory());
        }
        
        Integer exampleKey = (Integer)keymap.get(new Integer(code));
        if (exampleKey != null)
            iExample.keyPressed(exampleKey.intValue());
    }

    public void windowClosing(WindowEvent e)
    {
        System.exit(0);
    }

    public void mouseMoved(MouseEvent e)
    {
        float mouseX = (e.getX() + 0.5f) / getWidth();
        float mouseY = (e.getY() + 0.5f) / getHeight();
        iExample.setMousePos(mouseX, mouseY);
    }

    public void mouseDragged(MouseEvent e)
    {
        mouseMoved(e);
    }

    public void keyReleased(KeyEvent e) {}
    public void keyTyped(KeyEvent e) {}
    public void windowOpened(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
    public void windowActivated(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}

    public static class JsePlatformServices implements PlatformServices {
        public Object loadImage(String name) {
            try
            {
                Toolkit toolkit = Toolkit.getDefaultToolkit();
                return toolkit.getImage(getResourceDir() + name);
            }
            catch (Exception e)
            {
                e.printStackTrace();
                return null;
            }
        }
        public String getResourceDir() {
            return "../data/";
        }
    }

}
