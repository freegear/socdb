/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * Description:     Example4
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/Example4.java#2 $
 * $Date: 2004/12/21 $
 * $Author: antti $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.m3g.*;

/**
 * M3G import and show test.
 *
 * The example loads the FILE_NAME file and takes the first object
 * contained in the file. The object is assumed to be of type World.
 * The world is first animated and then rendered. The actions of the
 * camera depend on the contents of the file.
 */
public class Example4 extends ExampleBase
{

//  private static final String FILE_NAME = "q3dm1_plain";
//  private static final String FILE_NAME = "village2";
    private static final String FILE_NAME = "cartrack";
//  private static final String FILE_NAME = "cube";
//  private static final String FILE_NAME = "nokia/tunnel";
//  private static final String FILE_NAME = "nokia/nokia_on_ice";
//  private static final String FILE_NAME = "nokia/pond_vilkutus2";
//  private static final String FILE_NAME = "swerve/skaterboy";
//  private static final String FILE_NAME = "swerve/pogoroo";
//  private static final String FILE_NAME = "swerve/swerve";
    private World iWorld;

    public Example4()
    {
        super(SHOW_RENDER_TIME);
    }

    protected void render(int time)
    {
        iWorld.animate(time);
        iWorld.align(null);
//      iWorld.setAlphaFactor((float)Math.cos(time * 0.001f) * 0.45f + 0.5f);
        Graphics3D.getInstance().render(iWorld);
    }

    protected void initialize()
    {
        iWorld = (World)load(FILE_NAME)[0];
//      traverse(iWorld);
    }

    private void traverse(Node aNode)
    {
        if (aNode instanceof Mesh)
        {
            Mesh mesh = (Mesh)aNode;
            for (int i = 0; i < mesh.getSubmeshCount(); i++)
            {
                Appearance app = mesh.getAppearance(i);
                CompositingMode cm = new CompositingMode();
                cm.setBlending(CompositingMode.ALPHA_ADD);
                app.setCompositingMode(cm);
                app.setTexture(0, null);
                Material mat = new Material();
                mat.setColor(Material.AMBIENT | Material.DIFFUSE | Material.SPECULAR, 0xff000000);
                mat.setColor(Material.EMISSIVE, 0xff444444);
                app.setMaterial(mat);
            }
        }
        if (aNode instanceof Group)
        {
            Group group = (Group)aNode;
            for (int i = 0; i < group.getChildCount(); i++)
            {
                traverse(group.getChild(i));
            }
        }
    }

}
