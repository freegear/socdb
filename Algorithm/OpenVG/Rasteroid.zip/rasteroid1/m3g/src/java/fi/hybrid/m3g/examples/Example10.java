/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * Description:     Example10
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/Example10.java#1 $
 * $Date: 2004/12/14 $
 * $Author: otso $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.m3g.*;
//import java.awt.*;
//import java.awt.event.KeyEvent;
/*
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import javax.microedition.m3g.*;*/
import java.util.*;

public class Example10 extends ExampleBase
{
    // Debug output flag
    private static final boolean DEBUG = false;

    // Graphics3d context
    private Graphics3D      g3d;

    // Random generator
    private Random          m_random = new Random();

    // Some flags
    private boolean         m_tunnelFadeOut = false;
    private boolean         m_nokiaFadeOut = false; 
    private boolean         m_fogOn = false;
    private float           m_lightIntensity = 1.0f;
    /*private GameMIDlet        m_midlet;*/

    // Nokia scene params
    private static final int SCENE_NOKIA_LENGTH = 33000;
    private static final int SCENE_NOKIA_HIDEBUG = 22000;

    // Snowflake count
    private static final int NUM_SNOWFLAKES = 20;
    private static final float SNOWFLAKE_SCALE = 6f;
    private static final float GROUND_LEVEL = 0f;

    // Bug scene length in ms
    private static final int SCENE_BUG_LENGTH = 6700;

    // The tunnel scene length
    private static final int SCENE_TUNNEL_LENGTH = 3000;

    // Current scene index
    private int             m_currentScene;

    // Number of scenes
    private static final int SCENE_COUNT = 5;

    // Scene indices
    private static final int SCENE_NOKIA = 0;
    private static final int SCENE_BUG = 1;
    private static final int SCENE_TUNNEL = 2;
    private static final int SCENE_POND = 3;
    private static final int SCENE_LOWPOLY = 4;

    // User IDs for the ant polygon image
    private static final int UID_NOKIA_ANTIMAGE = 47364324;

    // Items in the tunnel scene..
    private static final int UID_TUNNEL_MESH = 116237701;
    private static final int UID_TUNNEL_CAMERA = 457572229;
    private static final int UID_TUNNEL_LIGHT = 131143914;

    // For the pond scene
    private static final int UID_POND_CAMERA1 = 653251478;
    private static final int UID_POND_CAMERA2 = 124296655;
    private static final int UID_POND_CAMERA3 = 901844788;
    private static final int UID_POND_CAMERA4 = 468090727;
    private static final int UID_POND_ANTHEAD = 296699498;

    // Fov value for pond scenes
    private float[]     m_cameraFOVs = {35, 25, 30, 30};
    private int         m_currentCamera = 0;

    // Switches for the tunnel
    private static final int NO_TEXTURE = 0;
    private static final int ONE_TEXTURE = 1;
    private static final int DUAL_TEXTURE = 2;
    private static final int TOGGLE_FOG = 3;

    // We load .m3g scenes here
    private World[]     m_scenes;

    // Time counter
    private int         m_currentTime;

    // Time in millisecs
    private long        m_lastFrame;
    private int         m_deltaTime;

    //
    public Example10()
    {
        super(SHOW_RENDER_TIME);
        /*m_midlet = m;*/
    }

    //
    public void initialize()
    {
        // Create a new 3D graphics context
        g3d = Graphics3D.getInstance();

        try
        {
            // Allocate some scenes
            m_scenes = new World[SCENE_COUNT];

            // Load the nokia scene
            m_scenes[SCENE_NOKIA] = loadScene("nokia/nokia_on_ice");
            preInitNokiaScene();

            // Start from the first scene
            m_currentScene = SCENE_NOKIA;
            m_currentTime = 0;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        //
        if (DEBUG)
            System.out.println("Loaded");
    }

    // Loads a scene with given name
    private World loadScene(String name)
    {
        long mem = Runtime.getRuntime().freeMemory();
        Object3D[] o = null;
        try
        {
            o = load(name);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        long memNow = mem - Runtime.getRuntime().freeMemory();

        if (DEBUG)
        {
            System.out.println("Scene took " + memNow + " bytes..");
            // Show free mem
            showMemory();
        }

        return (World) o[0];
    }

    public void render(Object g)
    {
        /*Display display = Display.getDisplay( m_midlet );
        if ( display.getCurrent() == this )*/
        {
            long frm = System.currentTimeMillis();

            // make sure we don't do a huge skip on the first frame
            if (m_lastFrame == 0)
            {
                m_deltaTime = 0;
            }
            else
            {
                m_deltaTime = (int) (frm - m_lastFrame);
            }

            m_lastFrame = frm;
            doFrame(g);
            /*serviceRepaints();*/
        }
    }

    //
    public void keyPressed( int keyCode )
    {
        super.keyPressed(keyCode);
//      int gameAction = getGameAction( keyCode );

        if (m_currentScene == SCENE_NOKIA)
        {
            if (keyCode == KEY_5)
            {
                m_nokiaFadeOut = true;
            }           
        }
        
        if (m_currentScene == SCENE_TUNNEL)
        {
            if (keyCode == KEY_1)
            {
                switchTunnelMode(NO_TEXTURE);
            }
            else
            if (keyCode == KEY_2)
            {
                switchTunnelMode(ONE_TEXTURE);
            }
            else
            if (keyCode == KEY_3)
            {
                switchTunnelMode(DUAL_TEXTURE);
            }
            else
            if (keyCode == KEY_4)
            {
                switchTunnelMode(TOGGLE_FOG);
            }
            else
            if (keyCode == KEY_5)
            {
                m_tunnelFadeOut = true;
            }
        }

        if (m_currentScene == SCENE_POND)
        {
            // Find the pond scene..
            World pond = m_scenes[SCENE_POND];
    
            // Switch active cameras        
            if (keyCode == KEY_1)
            {
                Camera c = (Camera) pond.find(UID_POND_CAMERA1);
                pond.setActiveCamera(c);
                m_currentCamera = 0;
            }
            else
            if (keyCode == KEY_2)
            {
                Camera c = (Camera) pond.find(UID_POND_CAMERA2);
                pond.setActiveCamera(c);
                m_currentCamera = 1;
            }
            else
            if (keyCode == KEY_3)
            {
                Camera c = (Camera) pond.find(UID_POND_CAMERA3);
                pond.setActiveCamera(c);
                m_currentCamera = 2;
            }
            else
            if (keyCode == KEY_4)
            {
                Camera c = (Camera) pond.find(UID_POND_CAMERA4);
                pond.setActiveCamera(c);
                m_currentCamera = 3;
            }
            else
            // Adjust current FOV factor
            if (keyCode == KEY_UP)
            {
                float fo = m_cameraFOVs[m_currentCamera];
                if (fo > 15)
                    fo-=5;
                m_cameraFOVs[m_currentCamera] = fo;
                // Set the field-of-view
                Camera c = pond.getActiveCamera();
                c.setPerspective(fo, 1.0f, 0.1f,5);
            }
            else
            if (keyCode == KEY_DOWN)
            {
                float fo = m_cameraFOVs[m_currentCamera];
                if (fo < 45)
                    fo+=5;
                m_cameraFOVs[m_currentCamera] = fo;
                // Set the field-of-view
                Camera c = pond.getActiveCamera();
                c.setPerspective(fo, 1.0f, 0.1f,5);
            }
        }
/*
        if (keyCode == KEY_0)
        {
            m_midlet.destroyApp( true );
        }
*/  }

    // Do something..
    public void doFrame( Object g )
    {
//        int w = getWidth();
 //       int h = getHeight();

        // if we don't have a g3d context, fill screen with red color
        if (g3d == null)
        {
//          g.setClip(0,0, w,h);
//          g.setColor(100,10,15);
//          g.fillRect(0,0, w,h);
            return;
        }

        //
        int delta = m_deltaTime * 3/4;

        // update demo
        updateDemo(m_currentTime, delta);

        // bind to graphics
        g3d.bindTarget(g);

        // get currently displayed scene
        World scn = m_scenes[m_currentScene];
        scn.animate(m_currentTime);

        // do something after animation
        postAnimate();

        g3d.render(scn);
        scn = null;

        // release g3d
        g3d.releaseTarget();

        // update timer by delta value
        m_currentTime+=delta;
    }

    // updates the demo
    private void updateDemo(int time, int delta)
    {
        if (m_currentScene == SCENE_NOKIA)
        {
            updateNokiaScene(time);
        }
        else
        if (m_currentScene == SCENE_BUG)
        {
            updateBugScene(time);
        }       
        else
        if (m_currentScene == SCENE_TUNNEL)
        {
            updateTunnelScene(time, delta);
        }       
    }

    // does some post-animate() tasks
    private void postAnimate()
    {
        /** target the camera to ant's head */
        if (m_currentScene == SCENE_POND)
        {
            World scn = m_scenes[m_currentScene];
            Camera c = scn.getActiveCamera();
            c.align(null);
        }
    }

    // Frees the old scene (destroys it's references) and frees up mem
    private void freeOldScene()
    {
        // Get mem
        long mem = Runtime.getRuntime().freeMemory();

        // get the current scene
        World w = m_scenes[m_currentScene];

        // clear background
        w.setBackground(null);

        // remove all animation tracks
        removeAnimTracks(w);

        // remove all groups & nodes from the scene
        removeAllNodes(w);

        // null the scene
        m_scenes[m_currentScene] = null;

        // try to free some memory...
        System.gc();

        // Show how much we actually freed
        if (DEBUG)
        {
            long memNow = Runtime.getRuntime().freeMemory() - mem;
            System.out.println("Freed " + memNow + " bytes ...");
            // Show free mem
            showMemory();
        }
    }

    private void removeAllNodes(Group g)
    {
        // Do while we have something to remove..
        while (g.getChildCount() > 0)
        {
            // get the first child
            Node n = g.getChild(0);

            // if child is a group, clear it first..
            if (n instanceof Group)
            {
                Group g2 = (Group) n;
                if (g2.getChildCount() > 0)
                {
                    removeAllNodes(g2);
                }
            }

            //
            g.removeChild(n);
            if (DEBUG)
                System.out.println("Node removed");
        }
    }

    // Let's try to free up as much mem as possible...
    private void removeAnimTracks(Object3D obj)
    {
        int numReferences = obj.getReferences(null);
        if (numReferences > 0)
        {
            Object3D[] objArray = new Object3D[numReferences];
            obj.getReferences(objArray);

            //
            for (int i = 0; i < numReferences; i++)
            {
                //
                Object3D o = objArray[i];

                // remove possible animation tracks
                while (o.getAnimationTrackCount() > 0)
                {
                    AnimationTrack an = o.getAnimationTrack(0);
                    o.removeAnimationTrack(an);
                    if (DEBUG)
                        System.out.println("removed animation track");
                }

                //
                if (o instanceof Mesh || o instanceof SkinnedMesh)
                {
                    // remove appearances etc
                    removeAppearance((Mesh) o);
                }

                // trace next obj
                removeAnimTracks(o);
            }
        }
    }

    // Clear texture references to free up more mem
    private void removeAppearance(Mesh m)
    {
        // loop through all submeshes
        for (int a = 0; a < m.getSubmeshCount(); a++)
        {
            Appearance p = m.getAppearance(a);
            if (p != null)
            {
                // clear everything we can..
                p.setTexture(0, null);
                p.setMaterial(null);
                p.setPolygonMode(null);
                p.setFog(null);
                p.setCompositingMode(null);
            }
            // finally, remove the appearance...
            m.setAppearance(a, null);
        }
    }

    //
    private void showMemory()
    {
        if (DEBUG)
            System.out.println("Memory available : " + Runtime.getRuntime().freeMemory() + " / " + Runtime.getRuntime().totalMemory());
    }

    //
    private void preInitNokiaScene()
    {
        // Search the node with the 2d bug image and hide it for now..
        World nokia = m_scenes[SCENE_NOKIA];
        Mesh m = (Mesh) nokia.find(UID_NOKIA_ANTIMAGE);
        m.setRenderingEnable(false);

        // Add some snowflakes to the scene
        initSnowFlakes();
    }

    //
    private boolean showBug = false;
    private void updateNokiaScene(int time)
    {
        // Do not show the bug node before certain time has been reached..
        if (time > SCENE_NOKIA_HIDEBUG && !showBug)
        {
            // Search the image node & display it
            World nokia = m_scenes[SCENE_NOKIA];
            Mesh m = (Mesh) nokia.find(UID_NOKIA_ANTIMAGE);
            m.setRenderingEnable(true);

            // Show the lil' fellah :)
            showBug = true;
        }

        // Animate the snowflakes..
        animateSnowFlakes(time);

        // Switch to bug scene when
        // todo: fade out nokia scene properly
        if (time > SCENE_NOKIA_LENGTH || m_nokiaFadeOut)
        {
            //
            freeOldScene();

            // Load the bug scene
            m_scenes[SCENE_BUG] = loadScene("nokia/otokka_jump2");

            //
            m_currentScene = SCENE_BUG;
            m_currentTime = 0;
        }
    }

    //
    private void updateBugScene(int time)
    {
        // Switch to bug scene when
        if (time > SCENE_BUG_LENGTH)
        {
            //
            freeOldScene();

            // Load the pond scene
            m_scenes[SCENE_TUNNEL] = loadScene("nokia/tunnel");
            preInitTunnelScene();

            //
            m_currentScene = SCENE_TUNNEL;
            m_currentTime = 0;
        }
    }

    //
    private void preInitTunnelScene()
    {
        /** Select the world... */
        World w = m_scenes[SCENE_TUNNEL];

        // Find the tunnel mesh
        Mesh tnl = (Mesh) w.find(UID_TUNNEL_MESH);

        // Get the appearance from the mesh
        Appearance ap = tnl.getAppearance(0);

        // Get the vertex buffer for the tunnel mesh
        VertexBuffer vb = tnl.getVertexBuffer();

        // Get vertex count
        int count = vb.getVertexCount();

        // Create a new array for texture coordinates (for texture #2, as the object has only one texture layer defined in swerve)
        tunnelTexCoords = new short[count * 2];

        // Init the array with some random values
        for (int a = 0 ; a < count*2; a++)
        {
            int i = (m_random.nextInt() & 0xFF);
            tunnelTexCoords[a] = (short) i;
        }

        // Create a new vertex array..
        tunnelTextureArray = new VertexArray(count, 2, 2);

        // Copy texture coordinate values to array
        tunnelTextureArray.set(0, count, tunnelTexCoords);

        // Assign texture coordinates to second texture unit.
        vb.setTexCoords(1, tunnelTextureArray, 0.0004f, null);

        // Load texture image ...
        tunnelTextureImage2 = new Image2D(Image2D.RGB, platformServices.loadImage("nokia/ttex2.png"));

        // Create texmap
        tunnelTexture2 = new Texture2D(tunnelTextureImage2);

        // Choose blending mode for the texture layer, additive by default
        tunnelTexture2.setBlending(Texture2D.FUNC_ADD);

        // Backup first texture reference...
        tunnelTexture1 = ap.getTexture(0);

        // Update the textures...
        switchTunnelMode(1);

        // Create linear fog for the tunnel
        tunnelFog = new Fog();
        tunnelFog.setMode(Fog.LINEAR);
        tunnelFog.setColor(0x006080a0);
        tunnelFog.setLinear(10.0f, 25.0f);
    }

    //
    private void updateTunnelScene(int time, int delta)
    {
        // 
        World scn = m_scenes[SCENE_TUNNEL];

        // Find the omni light
        Light l = (Light) scn.find(UID_TUNNEL_LIGHT);

        // Set the light's intensity
        l.setIntensity(m_lightIntensity);

        /** Fade out mode */
        if (m_tunnelFadeOut)
        {
            if (DEBUG)
                System.out.println(delta);

            // Drop intensity
            m_lightIntensity-=(delta * 0.001f);

            // Fade below zero.. Looks like we have ambient light somewhere?
            if (m_lightIntensity <= -2.0f)
            {
                //
                freeOldScene();
    
                //
                m_scenes[SCENE_POND] = loadScene("nokia/pond_vilkutus2");
                preInitPondScene();
    
                //
                m_currentScene = SCENE_POND;
                m_currentTime = 0;
            }
        }
    }

    // Switches between different texture depths
    private void switchTunnelMode(int tnlMode)
    {
        // Select the world...
        World w = m_scenes[SCENE_TUNNEL];

        // Find the tunnel mesh
        Mesh tnl = (Mesh) w.find(UID_TUNNEL_MESH);

        // Get the appearance from the mesh
        Appearance ap = tnl.getAppearance(0);

        // remove textures?
        if (tnlMode == NO_TEXTURE)
        {
            ap.setTexture(0, null);
            ap.setTexture(1, null);
        }
        else
        if (tnlMode == ONE_TEXTURE)
        {
            ap.setTexture(0, tunnelTexture1);
            ap.setTexture(1, null);
        }
        else
        if (tnlMode == DUAL_TEXTURE)
        {
            ap.setTexture(0, tunnelTexture1);
            ap.setTexture(1, tunnelTexture2);
        }
        else
        // Switch fog on/off
        if (tnlMode == TOGGLE_FOG)
        {
            if (!m_fogOn)
            {
                ap.setFog(tunnelFog);
                m_fogOn = true;
            }
            else
            {
                ap.setFog(null);
                m_fogOn = false;
            }
        }
    }

    // Picks some cameras etc
    private void preInitPondScene()
    {
        //
        World pond = m_scenes[SCENE_POND];

        // Default to first camera
        Camera c = (Camera) pond.find(UID_POND_CAMERA1);
        c.setPerspective(m_cameraFOVs[0], 1.0f, 0.1f,5);

        //
        m_currentCamera = 0;
        pond.setActiveCamera(c);

        // Target camera to the ant. Note that the y target axis is scene's z-axis because 
        // the scene is exported from 3dsmax, in which z points up on world space
        
        Node n = (Node) pond.find(UID_POND_ANTHEAD);
        c.setAlignment(n, Node.ORIGIN, pond, Node.Z_AXIS);
        c.scale(-1, 1, -1);

        // Set field-of-view and clip params by hand
        c = (Camera) pond.find(UID_POND_CAMERA2);
        c.setPerspective(m_cameraFOVs[1], 1.0f, 0.1f,5);

        c.setAlignment(n, Node.ORIGIN, pond, Node.Z_AXIS);
        c.scale(-1, 1, -1);

        c = (Camera) pond.find(UID_POND_CAMERA3);
        c.setPerspective(m_cameraFOVs[2], 1.0f, 0.1f,5);

        c.setAlignment(n, Node.ORIGIN, pond, Node.Z_AXIS);
        c.scale(-1, 1, -1);

        c = (Camera) pond.find(UID_POND_CAMERA4);
        c.setPerspective(m_cameraFOVs[3], 1.0f, 0.1f,5);

        c.setAlignment(n, Node.ORIGIN, pond, Node.Z_AXIS);
        c.scale(-1, 1, -1);
    }

    // Inits some snowflakes for the Nokia scene
    private void initSnowFlakes()
    {
        // First we init a vertex array with 3 components (X,Y,Z), size of each component is byte
        flakeVertexArray = new VertexArray(flakeVertices.length / 3, 3, 2);

        // Now, we copy the actual XYZ coordinates to the array
        flakeVertexArray.set(0, flakeVertices.length / 3, flakeVertices);

        // Init a texture coordinate array with same size as the coordinate array, but only two coords for each vertex (u,v)
        flakeTextureArray = new VertexArray(flakeTexCoords.length / 2, 2, 2);

        // Copy actual values again
        flakeTextureArray.set(0, flakeTexCoords.length / 2, flakeTexCoords);

        // Next we need to create a vertex buffer, to which we'll assign the texture coordinates and XYZ coordinates
        flakeVertexBuffer = new VertexBuffer();

        // No scale, no bias in XYZ coordinates
        flakeVertexBuffer.setPositions(flakeVertexArray, 0.01f, null);

        // Assign texture coordinates to first texture unit. Again, no scale & no bias is needed
        flakeVertexBuffer.setTexCoords(0, flakeTextureArray, 0.1f, null);

        // Next we need to create a triangle strip array which holds the polygon definitions for the flakes
        flakeTriangles = new TriangleStripArray(flakeStrip, flakeStripLengths);

        /** 
        *
        * We could also create the triangle strip implicitly, by defining the first vertex index as zero..
        * This saves some space when simple, continuous triangle strips are created.
        *
        * flakeTriangles = new TriangleStripArray(0, flakeStripLengths);
        *
        */



        // First we need to create new appearance
        flakeAppearance = new Appearance();

        // Then we load a texture image ... We need to use alpha due to transparent pixels
        flakeTextureImage = new Image2D(Image2D.RGBA, platformServices.loadImage("nokia/snowflake.png"));

        // Then we create a texture map from the image
        flakeTexture = new Texture2D(flakeTextureImage);

        // Choose worst possible filtering type to gain more speed (actually it's already selected by default)
        flakeTexture.setFiltering(Texture2D.FILTER_BASE_LEVEL, Texture2D.FILTER_NEAREST);

        // Just replace the texel directly with the source for more speed
        flakeTexture.setBlending(Texture2D.FUNC_REPLACE);




        // Next, create a polygon mode definition
        flakePolyMode = new PolygonMode();

        // No, we don't need perspective correction for such small polygons
        flakePolyMode.setPerspectiveCorrectionEnable(false);

        // Shading should apply to whole polygon
        flakePolyMode.setShading(PolygonMode.SHADE_FLAT);

        // Disable visible side culling (both sides of flakes are seen)
        flakePolyMode.setCulling(PolygonMode.CULL_NONE);

        // Define winding as clockwise (actually it doesn't matter here since no culling is used...)
        flakePolyMode.setWinding(PolygonMode.WINDING_CW);

        // No, we don't want the flakes to be lit by camera light
        flakePolyMode.setLocalCameraLightingEnable(false);

        // Sincle no culling is used, we need to light both sides of the polygon
        flakePolyMode.setTwoSidedLightingEnable(true);




        // Let's define how the polygon is blended with the background
        flakeCompositing = new CompositingMode();

        // We want to use the alpha to blend the pixels to background
        flakeCompositing.setBlending(CompositingMode.ALPHA);

        // Don't write anything to alpha buffer
        flakeCompositing.setAlphaWriteEnable(false);




        // Set the texture map to the appearance's first texture unit
        flakeAppearance.setTexture(0, flakeTexture);

        // Assign the polygon mode to the appearance
        flakeAppearance.setPolygonMode(flakePolyMode);

        // Assign the compositing mode to the appearance
        flakeAppearance.setCompositingMode(flakeCompositing);



        // Get the world..
        World nokia = m_scenes[SCENE_NOKIA];

        // Finally, let's do some meshes from these definitions and add them to the scene
        m_snowFlakes = new Mesh[NUM_SNOWFLAKES];

        //
        for (int a = 0; a < NUM_SNOWFLAKES; a++)
        {
            m_snowFlakes[a] = new Mesh(flakeVertexBuffer, flakeTriangles, flakeAppearance);
            m_snowFlakes[a].translate(
                rnd(-SNOWFLAKE_SCALE, SNOWFLAKE_SCALE),
                rnd(-SNOWFLAKE_SCALE, SNOWFLAKE_SCALE),
                rnd(GROUND_LEVEL, GROUND_LEVEL + (SNOWFLAKE_SCALE/2.0f))
            );
            nokia.addChild(m_snowFlakes[a]);
        }
    }

    //
    private float rnd(float min, float max)
    {
        float p = (float) (m_random.nextInt() & 0xFFF) / 4095.0f;
        float q = 1.0f - p;
        return p * max + q * min;
    }

    // Animates the snowflakes...
    private void animateSnowFlakes(int time)
    {
        float[] xyz = new float[3];
        for (int a = 0; a < NUM_SNOWFLAKES; a++)
        {
            // push the new position to the flake. Note that the scene is exported from 3dsmax, thus z points up.
            m_snowFlakes[a].translate(0,0, -0.1f);

            // get current snowflake position
            m_snowFlakes[a].getTranslation(xyz);

            // move the flakes a bit
            if (xyz[2] < GROUND_LEVEL)
            {
                // push the new position to the flake
                m_snowFlakes[a].translate(0,0, SNOWFLAKE_SCALE/2.0f);
            }
        }
    }


    // Definitions for a snowflake
    private Appearance          flakeAppearance;
    private Material            flakeMaterial;
    private PolygonMode         flakePolyMode;
    private CompositingMode     flakeCompositing;
    private Image2D             flakeTextureImage;
    private Texture2D           flakeTexture;

    // Arrays & buffers for snowflake
    private VertexArray         flakeVertexArray;
    private VertexArray         flakeTextureArray;
    private VertexBuffer        flakeVertexBuffer;
    private TriangleStripArray  flakeTriangles;

    // Meshes
    private Mesh[]              m_snowFlakes;

    // Vertex coordinates for a snowflake (a simple flat quad actually)
    private static final short flakeVertices[] =
    {
        (short) -10, (short) 0, (short)  10,
        (short) -10, (short) 0, (short) -10,
        (short)  10, (short) 0, (short)  10,
        (short)  10, (short) 0, (short) -10
    };

    // Texture coordinates for the snowflake
    private static final short flakeTexCoords[] =
    {
        (short) 0,  (short) 10,
        (short) 0, (short) 0,
        (short) 10, (short) 10,
        (short) 10,  (short) 0,
    };

    // Strip lengths for a simple snowflake
    private static final int flakeStripLengths[] = { 4 };

    // Triangle strip for the snowflake
    private static final int flakeStrip[] =
    {
        0, 1, 2, 3
    };

    //
    private Appearance          tunnelAppearance;
    //private Image2D           tunnelTextureImage1;
    private Image2D             tunnelTextureImage2;

    //
    private Fog                 tunnelFog;

    //
    private Texture2D           tunnelTexture1;
    private Texture2D           tunnelTexture2;

    // Arrays & buffers for the tunnel
    private VertexArray         tunnelTextureArray;

    // Texture coordinates for the tunnel
    private short[] tunnelTexCoords;
}
