/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * Description:     Example3
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/Example3.java#1 $
 * $Date: 2004/12/14 $
 * $Author: otso $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.m3g.*;

/**
 * Animation and interpolation test.
 *
 * The result should be a smoothly rotating white cube over a black
 * "floor".
 *
 */
public class Example3 extends ExampleBase
{

    private World iWorld;

    public Example3()
    {
        super(SHOW_RENDER_TIME);
    }

    protected void render(int time)
    {
        iWorld.animate(time);
        iWorld.align(null);
        Graphics3D.getInstance().render(iWorld);
    }

    protected void initialize()
    {
        iWorld = new World();
        Mesh box = createBox();

        Background bg = new Background();
        bg.setColor(0xff204080);
        iWorld.setBackground(bg);

        Camera camera = new Camera();
        camera.setPerspective(90.0f, 1.0f, 1.0f, 100.0f);
        camera.setTranslation(0.0f, 0.0f, 30.0f);
        iWorld.addChild(camera);
        iWorld.setActiveCamera(camera);

        Light light = new Light();
        light.setTranslation(0.0f, 0.0f, 30.0f);
        iWorld.addChild(light);

        Node ground = (Node)box.duplicate();
        ground.setTranslation(0.0f, -15.0f, 0.0f);
        ground.setScale(2.0f, 0.1f, 2.0f);
        iWorld.addChild(ground);

        for (int i = 0; i < 1; i++)
        {
            int num = 5;
            int duration = 3000;
            int comps = 4;

            Node node = (Node)box.duplicate();
            node.setScale(0.2f, 0.2f, 0.2f);
            iWorld.addChild(node);

//          KeyframeSequence seq = new KeyframeSequence(num, comps, KeyframeSequence.LINEAR);
//          KeyframeSequence seq = new KeyframeSequence(num, comps, KeyframeSequence.SLERP);
//          KeyframeSequence seq = new KeyframeSequence(num, comps, KeyframeSequence.SPLINE);
            KeyframeSequence seq = new KeyframeSequence(num, comps, KeyframeSequence.SQUAD);
//          KeyframeSequence seq = new KeyframeSequence(num, comps, KeyframeSequence.STEP);
//          seq.setRepeatMode(KeyframeSequence.CONSTANT);
            seq.setRepeatMode(KeyframeSequence.LOOP);
            seq.setDuration(duration);
            for (int j = 0; j < num; j++)
            {
                float[] value = new float[comps];
                for (int k = 0; k < comps; k++)
                {
                    value[k] = ((float)random() - 0.5f) * 30.0f;
                }
                seq.setKeyframe(j, (j * 2 + 1) * duration / (num * 2), value);
            }

            AnimationController ctrl = new AnimationController();

//          AnimationTrack track = new AnimationTrack(seq, AnimationTrack.TRANSLATION);
            AnimationTrack track = new AnimationTrack(seq, AnimationTrack.ORIENTATION);
            track.setController(ctrl);

            node.addAnimationTrack(track);
        }
    }
}
