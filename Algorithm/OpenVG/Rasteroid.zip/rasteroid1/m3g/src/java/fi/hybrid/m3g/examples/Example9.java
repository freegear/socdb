/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * Description:     Example9
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/Example9.java#1 $
 * $Date: 2004/12/14 $
 * $Author: otso $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.m3g.*;

/**
 * Morphing test.
 */
public class Example9 extends ExampleBase
{

    private SkinnedMesh iSkinnedMesh;
    private Light iLight;
    private Camera iCamera;
    private int iCurrentFrame;
    private Transform trans;
    private Transform iLightTrans;
    private Transform bone1Trans;
    private Transform bone2Trans;
    private Group skeleton;
    private Group bone1;
    private Group bone2;

    public Example9()
    {
        super(SHOW_RENDER_TIME);
        iCurrentFrame = 0;
        trans = new Transform();
        bone2Trans = new Transform();
        bone1Trans = new Transform();
    }

    protected void render(int time)
    {
        Background back = new Background();
        back.setColor(0xff404045);
        back.setDepthClearEnable(true);
        Graphics3D.getInstance().clear(back);

        bone1Trans.setIdentity();
        bone1Trans.postTranslate(0.0f, (float) (4*3*25)*0.03f, 0.0f);
        bone1Trans.postRotate((float)Math.sin(((double)iCurrentFrame/30)*Math.PI*2)*40, 0.0f, 0.0f, 1.0f);
        bone1Trans.postTranslate(0.0f, (float) (-4*3*25)*0.03f, 0.0f);
        //bone1Trans.postTranslate(10.0f, 0.0f, 0.0f);
        bone1.setTransform(bone1Trans);

        bone2Trans.setIdentity();
        bone2Trans.postTranslate(0.0f, (float) (-4*3*25)*0.03f, 0.0f);
        bone2Trans.postRotate((float)Math.sin(((double)iCurrentFrame/60)*Math.PI*2)*40, 0.0f, 0.0f, 1.0f);
        bone2Trans.postTranslate(0.0f, (float) (4*3*25)*0.03f, 0.0f);
        //bone2Trans.postTranslate(-10.0f, 0.0f, 0.0f);
        bone2.setTransform(bone2Trans);

        trans.postRotate(2.0f, 0.0f, 1.0f, 0.0f);

        Graphics3D.getInstance().render(iSkinnedMesh, trans);

        if ((iCurrentFrame + 15) % 30 == 0)
        {
            iSkinnedMesh = (SkinnedMesh) iSkinnedMesh.duplicate();
            bone1 = (Group) iSkinnedMesh.getSkeleton().getChild(0);
            bone2 = (Group) bone1.getChild(0);
        }

        iCurrentFrame++;
    }

    protected void initialize()
    {
        int sides = 8;

        short[] positions = new short[sides*8*3 * 3];
        short[] normals = new short[sides*8*3 * 3];

        for (int i = 0; i < 8*3; i++)
        {
            for (int j = 0; j < sides; j++)
            {
                positions[3*(i*sides + j)] = (short) (100*Math.sin(2*Math.PI*((float)j / (float)sides)));
                positions[3*(i*sides + j) + 1] = (short) (-50*i + 4*3*50); // Normalize to origin.
                positions[3*(i*sides + j) + 2] = (short) (100*Math.cos(2*Math.PI*((float)j / (float)sides)));

                normals[3*(i*sides + j)] = (short) (-100*Math.sin(2*Math.PI*((float)j / (float)sides)));
                normals[3*(i*sides + j) + 1] = (short) 0;
                normals[3*(i*sides + j) + 2] = (short) (-100*Math.cos(2*Math.PI*((float)j / (float)sides)));
            }
        }

        VertexArray normalsArray = new VertexArray(3*8*sides, 3, 2);
        normalsArray.set(0,3*8*sides, normals);

        VertexArray basePositions = new VertexArray(3*8*sides, 3, 2);
        basePositions.set(0,3*8*sides, positions);

        int[] stripIndices = new int[(8*3-1)*(2*sides+2)];
        int[] stripLengths = new int[8*3-1];
        for (int i = 0; i < 8*3-1; i++)
        {
            stripIndices[i*(2*sides+2)] = i*sides;
            for (int j = 1; j < sides+1; j++)
            {
                stripIndices[i*(2*sides+2)+j*2-1] = (j%sides) + i*sides;
                stripIndices[i*(2*sides+2)+j*2] = (j%sides) + (i+1)*sides;
            }
            stripIndices[i*(2*sides+2)+sides*2+1] = (i+1)*sides + 1;
            stripLengths[i] = 2*sides+2;
        }

        TriangleStripArray strip = new TriangleStripArray(stripIndices, stripLengths);

        VertexBuffer base = new VertexBuffer();
        base.setPositions(basePositions, .03f, null);
        base.setNormals(normalsArray);
        base.setDefaultColor(0xFF0B7FCC);


        Material material = new Material();
        material.setColor(Material.AMBIENT, 0x124797); // Hybrid darkest blue.
        material.setColor(Material.DIFFUSE, 0xff0B7FCC); // Hybrid dark blue.

        PolygonMode polyMode = new PolygonMode();
        polyMode.setCulling(PolygonMode.CULL_NONE);
        polyMode.setTwoSidedLightingEnable(true);

        Appearance appearance = new Appearance();
        appearance.setMaterial(material);
        appearance.setPolygonMode(polyMode);

        skeleton = new Group();
        bone1 = new Group();
        bone2 = new Group();
        skeleton.addChild(bone1);
        bone1.addChild(bone2);

        iSkinnedMesh = new SkinnedMesh(base, strip, appearance, skeleton);

        iSkinnedMesh.addTransform(bone1, 200, 8*sides, 10*sides);
        iSkinnedMesh.addTransform(bone2, 1, 2*8*sides, 8*sides);

        iLight = new Light();
        iLight.setMode(Light.OMNI);
        iLight.setAttenuation(0.001f, 0.1f, 0.0f);
        iLight.setIntensity(1.0f);
        iLight.setColor(0xFFFFFF);
        iLightTrans = new Transform();
        iLightTrans.postTranslate(-5.f, -5.f, 16.f);
        Graphics3D.getInstance().addLight(iLight, iLightTrans);

        iCamera = new Camera();
        iCamera.setPerspective(90.f, 1.f, 1.f, 150.f);
        Transform cameraTrans = new Transform();
        cameraTrans.postTranslate(0.f, 0.f, 26.f);
        Graphics3D.getInstance().setCamera(iCamera, cameraTrans);
    }

}
