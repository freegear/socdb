/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003-2004 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). Please do not use this program/source code 
 * before you have read the EULA and have agreed to be bound by 
 * its terms.
 * 
 * Use and/or disclosure outside these terms may result in 
 * irrepairable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * Description:     Example base class
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/ExampleBase.java#1 $
 * $Date: 2004/12/14 $
 * $Author: otso $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.m3g.*;

import java.io.*;

/**
 * Base class for all the examples.
 */
public abstract class ExampleBase
{

    public static final int SHOW_RENDER_TIME = 1 << 0;
    public static final int DOUBLE_BUFFERING = 1 << 1;
    public static final int USES_CURSOR      = 1 << 2;

    // Key codes used in examples
    public static final int KEY_1 = 0;
    public static final int KEY_2 = 1;
    public static final int KEY_3 = 2;
    public static final int KEY_4 = 3;
    public static final int KEY_5 = 4;
    public static final int KEY_6 = 5;
    public static final int KEY_7 = 6;
    public static final int KEY_8 = 7;
    public static final int KEY_9 = 8;
    public static final int KEY_0 = 9;
    public static final int KEY_UP = 10;
    public static final int KEY_RIGHT = 11;
    public static final int KEY_DOWN = 12;
    public static final int KEY_LEFT = 13;
    public static final int KEY_EXIT = 14;
    public static final int KEY_FPS_TOGGLE = 15;
      
    private static long sSeed = 5555555;
    private int iFeatures;
    private int iCounter;
    private int iStartTime;
    private float iMouseX;
    private float iMouseY;
    protected int width;
    protected int height;
    protected PlatformServices platformServices; 
    
    public ExampleBase(int aFeatures)
    {
        iFeatures = aFeatures;
        iCounter = 0;
        iStartTime = 0;
        iMouseX = 0.5f;
        iMouseY = 0.5f;
        
        // \todo is there some other state that we should reset?
        Graphics3D.getInstance().resetLights();
    }

    public float getMouseX()
    {
        return iMouseX;
    }

    public float getMouseY()
    {
        return iMouseY;
    }

    public void setMousePos(float aX, float aY)
    {
        iMouseX = aX;
        iMouseY = aY;
    }

    public void setStartTime(int aTime)
    {
        iStartTime = aTime;
    }

    public void keyPressed(int aKeyCode)
    {
        if (aKeyCode == KEY_FPS_TOGGLE)
            iFeatures ^= SHOW_RENDER_TIME;
    }    
 
    public void keyReleased(int aKeyCode)
    {
    }    
    
    protected abstract void initialize();

    public void render(Object aGraphics, int width, int height)
    {
        this.width = width;
        this.height = height;
        render(aGraphics);
    }

    protected void render(Object aGraphics)
    {
        Graphics3D.getInstance().bindTarget(aGraphics);
        render((int) System.currentTimeMillis() - iStartTime);
        Graphics3D.getInstance().releaseTarget();
    }
    
    protected void render(int aTime)
    {
    }

    public int getFeatures()
    {
        return iFeatures;
    }

    public static Mesh createBox()
    {
        byte[] vert = { 10, 10, 10, -10, 10, 10, 10, -10, 10, -10, -10, 10,
                -10, 10, -10, 10, 10, -10, -10, -10, -10, 10, -10, -10, -10,
                10, 10, -10, 10, -10, -10, -10, 10, -10, -10, -10, 10, 10, -10,
                10, 10, 10, 10, -10, -10, 10, -10, 10, 10, 10, -10, -10, 10,
                -10, 10, 10, 10, -10, 10, 10, 10, -10, 10, -10, -10, 10, 10,
                -10, -10, -10, -10, -10, };

        VertexArray vertArray = new VertexArray(vert.length / 3, 3, 1);
        vertArray.set(0, vert.length / 3, vert);

        byte[] norm = { 0, 0, 127, 0, 0, 127, 0, 0, 127, 0, 0, 127, 0, 0, -127,
                0, 0, -127, 0, 0, -127, 0, 0, -127, -127, 0, 0, -127, 0, 0,
                -127, 0, 0, -127, 0, 0, 127, 0, 0, 127, 0, 0, 127, 0, 0, 127,
                0, 0, 0, 127, 0, 0, 127, 0, 0, 127, 0, 0, 127, 0, 0, -127, 0,
                0, -127, 0, 0, -127, 0, 0, -127, 0, };

        VertexArray normArray = new VertexArray(norm.length / 3, 3, 1);
        normArray.set(0, norm.length / 3, norm);

        int[] stripLen = { 4, 4, 4, 4, 4, 4 };
        
        VertexBuffer vertexBuf = new VertexBuffer();
        vertexBuf.setPositions(vertArray, 1.0f, null);
        vertexBuf.setNormals(normArray);
        
        IndexBuffer indexBuf = new TriangleStripArray(0, stripLen);
        
        Appearance app = new Appearance();
        app.setMaterial(new Material());
        
        return new Mesh(vertexBuf, indexBuf, app);
    }
    
    public Object3D[] load(String aSceneName)
    {
        
        Object3D[] objs;
        
        try
        {
            objs = Loader.load(platformServices.getResourceDir() + aSceneName + ".m3g");
        } catch (IOException e)
        {
            System.out.println("Load failed (" + e.getMessage() + ")");
            e.printStackTrace();
            return null;
        }
        return objs;
        
    }
    
    public Object3D[] loadGeneric(String aSceneName)
    {
        
        Object3D[] objs;
        
        try
        {
            objs = Loader.load(platformServices.getResourceDir() + aSceneName);
        } catch (IOException e)
        {
            System.out.println("Load failed (" + e.getMessage() + ")");
            e.printStackTrace();
            return null;
        }
        return objs;
        
    }
    
    /**
     * CLDC 1.1 does not have Math.random(), so we have here a simple pseudo
     * random number generator.
     */
    static double random()
    {
        sSeed = (16807 * sSeed + 3) % 0xFFFFFFF;
        return (double) sSeed / (double) 0xFFFFFFF;
    }
    
    /**
     * @param platformServices  The platform specific services.
     */
    public void setPlatformServices(PlatformServices platformServices)
    {
        this.platformServices = platformServices;
    }
}