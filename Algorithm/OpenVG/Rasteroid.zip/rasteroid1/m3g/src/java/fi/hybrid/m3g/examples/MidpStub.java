/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * Description:     Stub for running examples on MIDP
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/MidpStub.java#2 $
 * $Date: 2004/12/21 $
 * $Author: antti $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.*;

public class MidpStub extends MIDlet implements CommandListener
{
    private ExampleCanvas iCanvas;
    private final static Command iOkCommand = new Command("Ok", Command.OK, 1);
    private final static Command iExitCommand = new Command ("Exit", Command.EXIT, 1);
    private List        iSelList;
    private Display     iDisplay;
    private Alert       iError;
    private boolean firstTime;
    
    public MidpStub()
    {    
        String[] EXAMPLE_STRINGS = {"1", "2", "3", "4", "5", "6", "7", "8", "9"};
        iSelList = new List("Select Example", ChoiceGroup.IMPLICIT, EXAMPLE_STRINGS, (Image[])null);
        iSelList.addCommand(iOkCommand);
        iSelList.addCommand(iExitCommand);
        
        iDisplay = Display.getDisplay(this);
        iError = new Alert("Hybrid M3G Examples", 
                           "",
                           null,
                           AlertType.ERROR);
        iError.setTimeout(Alert.FOREVER);
        firstTime = true;
    }

    protected void startApp()
    {
        if (firstTime)
        {
            
            iSelList.setCommandListener(this);
            iDisplay.setCurrent(iSelList);
            firstTime = false;
        }
    }

    public void commandAction(Command aCommand, Displayable aDisp)
    {
        
        if (aCommand == iOkCommand && aDisp == iSelList)
        {
            int selIndex = iSelList.getSelectedIndex();
            
            try 
            {
                Class exampleClass = Class.forName("fi.hybrid.m3g.examples.Example" + iSelList.getString(selIndex));
                ExampleBase example = (ExampleBase)exampleClass.newInstance();
                example.setPlatformServices(new MidpPlatformServices());
                if (iCanvas != null) iCanvas.stopAndWait();
                iCanvas = new ExampleCanvas(example);               
                iCanvas.setCommandListener(this);
                iCanvas.addCommand(iExitCommand);
                iDisplay.setCurrent(iCanvas);
            }
            catch (ClassNotFoundException notFound)
            {
                Displayable temp = iDisplay.getCurrent();
                iError.setString("Class fi.hybrid.m3g.examples.Example" + (selIndex+1) + " not found");
                if (iCanvas != null) iCanvas.stopAndWait();
                iDisplay.setCurrent(iError, temp);
            }
            catch (Exception e)
            {
                Displayable temp = iDisplay.getCurrent();
                iError.setString("Unknown error (" + e.getMessage() +")");
                if (iCanvas != null) iCanvas.stopAndWait();
                iDisplay.setCurrent(iError, temp);              
            }

        }
        else if (aCommand == iExitCommand && aDisp == iCanvas)
        {   
            iDisplay.setCurrent(iSelList);
        }
        else if (aCommand == iExitCommand && aDisp == iSelList)
        {
            if (iCanvas != null) iCanvas.stopAndWait();
            notifyDestroyed();
        }   
    }

    protected void pauseApp()
    {
        // Here we should stop the constant redrawing, but why bother =)
    }

    protected void destroyApp(boolean aUnconditional)
    {
        if (iCanvas != null) iCanvas.stopAndWait();
    }

    public static class MidpPlatformServices implements PlatformServices {
        public Object loadImage(String name) {
            try
            {
                return Image.createImage(getResourceDir() + name);
            }
            catch (Exception e)
            {
                e.printStackTrace();
                return null;
            }
        }
        public String getResourceDir() {
            return "/";
        }
    }
    
}

