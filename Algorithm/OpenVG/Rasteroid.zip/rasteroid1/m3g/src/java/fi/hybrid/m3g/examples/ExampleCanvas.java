/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * Description:     ExampleCanvas for MIDP
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/ExampleCanvas.java#1 $
 * $Date: 2004/12/14 $
 * $Author: otso $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import java.util.Hashtable;

import javax.microedition.lcdui.*;

public class ExampleCanvas extends Canvas
{
    
    private ExampleBase iExample;
    private boolean     iStop = false;
    private boolean     iIsRendering = false;
    
    private int         iCounter;
    private long        intervalStart;
    private long        lastCursorUpdate;
    private float       fps;
    
    /* Cursor speed in pixels / second */
    private static final float CURSOR_SPEED = 20.0f;
    private float       cursorX;
    private float       cursorY;

    private static final int UP_PRESSED = 1 << 0;
    private static final int DOWN_PRESSED = 1 << 1;
    private static final int RIGHT_PRESSED = 1 << 2;
    private static final int LEFT_PRESSED = 1 << 3;
    
    private int keysPressed = 0;

    private static final int NUM_FRAMES = 10;

    private static Hashtable keymap = new Hashtable();
    static {
        keymap.put(new Integer(KEY_NUM1), new Integer(ExampleBase.KEY_1));
        keymap.put(new Integer(KEY_NUM2), new Integer(ExampleBase.KEY_2));
        keymap.put(new Integer(KEY_NUM3), new Integer(ExampleBase.KEY_3));
        keymap.put(new Integer(KEY_NUM4), new Integer(ExampleBase.KEY_4));
        keymap.put(new Integer(KEY_NUM5), new Integer(ExampleBase.KEY_5));
        keymap.put(new Integer(KEY_NUM6), new Integer(ExampleBase.KEY_6));
        keymap.put(new Integer(KEY_NUM7), new Integer(ExampleBase.KEY_7));
        keymap.put(new Integer(KEY_NUM8), new Integer(ExampleBase.KEY_8));
        keymap.put(new Integer(KEY_NUM9), new Integer(ExampleBase.KEY_9));
        keymap.put(new Integer(KEY_NUM0), new Integer(ExampleBase.KEY_FPS_TOGGLE));
    }
    
    public ExampleCanvas(ExampleBase aExample)
    {           
        iExample = aExample;
        iExample.initialize();
        iExample.setStartTime((int)System.currentTimeMillis());
        lastCursorUpdate = System.currentTimeMillis();
        //setFullScreenMode(true);
        iCounter = 0;
        cursorX = getWidth() / 2;
        cursorY = getHeight() / 2;
    }

    protected void paint(Graphics aGraphics)
    {
        
        iIsRendering = true;
        if (!iStop)
        { 
            // do the rendering
            iExample.render(aGraphics, getWidth(), getHeight());
            
            long now = System.currentTimeMillis();
            
            // Cursor display
            if ((iExample.getFeatures() & ExampleBase.USES_CURSOR) != 0)
            {
                long delta = now - lastCursorUpdate;
                lastCursorUpdate = now;
                updateCursor(delta);

                // display cursor
                aGraphics.setColor(0xFFFFFFFF);
                aGraphics.setStrokeStyle(Graphics.SOLID);
                aGraphics.drawLine((int)cursorX - 4, (int)cursorY, (int)cursorX + 4, (int)cursorY);
                aGraphics.drawLine((int)cursorX, (int)cursorY - 4, (int)cursorX, (int)cursorY + 4);
            }               
            
            // FPS display
            if ((iExample.getFeatures() & ExampleBase.SHOW_RENDER_TIME) != 0)
            {
                // for every NUM_FRAMES frame, count new fps
                if (iCounter % NUM_FRAMES == 0)
                {
                    if (iCounter > 0)
                    {
                        long elapsed =  now - intervalStart;
                        fps = ((float)NUM_FRAMES / (float)elapsed) * 1000.f;                    
                    }
                    
                    intervalStart = now;
                }
                
                // display fps
                if (iCounter >= NUM_FRAMES)
                {
                    aGraphics.setColor(0xFFFFFFFF);
                    String f = String.valueOf(fps);
                    int lenMin = Math.min(f.length(), 5);
                    aGraphics.drawString(String.valueOf(fps).substring(0, lenMin), 4, 4 + aGraphics.getFont().getHeight(), Graphics.TOP|Graphics.LEFT);
                }
            }    
            iCounter++;
            repaint();
        }
        iIsRendering = false;
    }
    
    public void stopAndWait()
    {
        iStop = true;
        while(iIsRendering)
        {
            try {
                Thread.sleep(1);    
            } catch(InterruptedException ie) {}
        }
    }

   private void updateCursor(long delta)
   {
    int ydir = 0, xdir = 0;
    
    if  ((keysPressed & UP_PRESSED) != 0)
        ydir = -1;
    else if ((keysPressed & DOWN_PRESSED) != 0)
        ydir = 1;
    
    if  ((keysPressed & LEFT_PRESSED) != 0)
        xdir = -1;
    else if ((keysPressed & RIGHT_PRESSED) != 0)
        xdir = 1;
    
    if (ydir != 0)
    {
        cursorY += (float)ydir * CURSOR_SPEED * ((float)delta / 1000.f);
        cursorY = (cursorY > getHeight() ? getHeight() : (cursorY < 0 ? 0 : cursorY));      
    }
    if (xdir != 0)
    {
        cursorX += (float)xdir * CURSOR_SPEED * ((float)delta / 1000.f); 
        cursorX = (cursorX > getWidth() ? getWidth() : (cursorX < 0 ? 0 : cursorX));
    }
    
    if (ydir != 0 || xdir != 0)
    {
        iExample.setMousePos((cursorX + 0.5f) / getWidth(), (cursorY + 0.5f) / getHeight());
    }
   }
    
    protected void keyReleased(int key)
    {
        if ((iExample.getFeatures() & ExampleBase.USES_CURSOR) != 0)
        {
            boolean changed = false;
            switch(getGameAction(key))
            {
                case UP:
                    keysPressed &= ~UP_PRESSED;
                    changed = true;
                    break;
                case DOWN:
                    keysPressed &= ~DOWN_PRESSED;
                    changed = true;
                    break;
                case RIGHT:
                    keysPressed &= ~RIGHT_PRESSED;
                    changed = true;
                    break;
                case LEFT:
                    keysPressed &= ~LEFT_PRESSED;
                    changed = true;
                    break;
            }
            if (changed)
            {
                long now = System.currentTimeMillis();
                long delta = now - lastCursorUpdate;
                lastCursorUpdate = now;
                updateCursor(delta);                       
            }
        }
    }
    
    protected void keyPressed(int key)
    {
        Integer exampleKey = (Integer)keymap.get(new Integer(key));
        if (exampleKey != null)
            iExample.keyPressed(exampleKey.intValue());
        else if ((iExample.getFeatures() & ExampleBase.USES_CURSOR) != 0)
        {
            boolean changed = false;
            switch(getGameAction(key))
            {
                case UP:
                    keysPressed |= UP_PRESSED;
                    changed = true;
                    break;
                case DOWN:
                    keysPressed |= DOWN_PRESSED;
                    changed = true;
                    break;
                case RIGHT:
                    keysPressed |= RIGHT_PRESSED;
                    changed = true;
                    break;
                case LEFT:
                    keysPressed |= LEFT_PRESSED;
                    changed = true;
                    break;
            }
            if (changed)
            {
                long now = System.currentTimeMillis();
                long delta = now - lastCursorUpdate;
                lastCursorUpdate = now;
                updateCursor(delta);                       
            }
        }
        else
        {
            switch (getGameAction(key))
            {
            case UP:
                iExample.keyPressed(ExampleBase.KEY_UP);
                break;
            case DOWN:
                iExample.keyPressed(ExampleBase.KEY_DOWN);
                break;
            case LEFT:
                iExample.keyPressed(ExampleBase.KEY_LEFT);
                break;
            case RIGHT:
                iExample.keyPressed(ExampleBase.KEY_RIGHT);
                break;
            }           
         }            
    }
}
