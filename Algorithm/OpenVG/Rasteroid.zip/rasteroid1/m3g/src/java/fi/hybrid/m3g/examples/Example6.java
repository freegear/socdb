/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * Description:     Example6
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/Example6.java#1 $
 * $Date: 2004/12/14 $
 * $Author: otso $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.m3g.*;

/**
 * Image, sprite and background test.
 *
 * The test moves a sprite back and forth in front of the camera. The
 * transition between different mipmap levels should be visible.
 *
 */
public class Example6 extends ExampleBase
{

    private static final int IMAGE_BASE_SIZE = 128;
//  private static final int IMAGE_BASE_SIZE = 256 - 13;

    private static final String TEXTURE_NAME = "textures/pukki_small_cg2.png";
    
    private World iWorld;
    private Background iBackground;
    private Mesh iMesh;
    private Sprite3D iSprite;
    private Image2D iImage;
    
    public Example6()
    {
        super(SHOW_RENDER_TIME);
    }

    protected void render(int time)
    {
        iMesh.setOrientation(time * 0.15f, 0.0f, 1.0f, 0.0f);
        iMesh.preRotate(time * 0.01f, 1.0f, 0.0f, 0.0f);

        double temp = Math.tan((1.0f - (float)Math.cos(time * 0.0005f))*0.5f);
        iSprite.setTranslation(0.0f, 0.0f, (float)(temp*temp*temp) * -100.0f + 30.0f);

        Graphics3D.getInstance().render(iWorld);
    }

    protected void initialize()
    {
        iWorld = new World();
        Mesh box = createBox();

        Camera camera = new Camera();
        camera.setPerspective(70.0f, 1.0f, 1.0f, 10000.0f);
        camera.setTranslation(0.0f, 0.0f, 40.0f);
        iWorld.addChild(camera);
        iWorld.setActiveCamera(camera);

        Light light = new Light();
        light.setTranslation(0.0f, 0.0f, 40.0f);
        iWorld.addChild(light);

        // Texture options (choose one):
        
        // 1. load image TEXTURE_IMAGE
        iImage = new Image2D(Image2D.RGBA, platformServices.loadImage(TEXTURE_NAME));
        
        // 2. create perlin noise image
        //iImage = ProceduralTexture.createPerlinNoiseImage(0, 0, IMAGE_BASE_SIZE, IMAGE_BASE_SIZE, 0, IMAGE_BASE_SIZE, 0, false);

        // 3. create plasma image
        //iImage = ProceduralTexture.createPlasmaImage(IMAGE_BASE_SIZE, IMAGE_BASE_SIZE, false);

        iMesh = (Mesh)box.duplicate();
        Appearance app = new Appearance();

        app.setMaterial(new Material());

        CompositingMode cmode = new CompositingMode();
//      cmode.setAlphaThreshold(0.5f);
//      cmode.setBlending(CompositingMode.ALPHA_ADD);
//      cmode.setDepthWriteEnable(false);
        app.setCompositingMode(cmode);

        PolygonMode pmode = new PolygonMode();
        pmode.setPerspectiveCorrectionEnable(true);
//      pmode.setCulling(PolygonMode.CULL_NONE);
        app.setPolygonMode(pmode);

        iMesh.setAppearance(0, app);
        iMesh.setScale(0.3f, 0.3f, 0.3f);
//      iMesh.setRenderingEnable(false);
//      iWorld.addChild(iMesh);

        iBackground = new Background();
        iBackground.setColor(0xff204080);
//      iBackground.setImage(iImage);
//      iBackground.setImageMode(Background.REPEAT, Background.REPEAT);
        iWorld.setBackground(iBackground);

        iSprite = new Sprite3D(true, iImage, new Appearance());
//      iSprite = new Sprite3D(false, iImage, null);
        iSprite.setScale(20.0f, 20.0f, 20.0f);
//      iSprite.setRenderingEnable(false);
        iWorld.addChild(iSprite);
    }
    
}
