/*------------------------------------------------------------------------
 *
 * M3G 1.2.0
 * -----------------------------------------
 *
 * (C) 2003 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * Description:     Example2
 *
 *
 * $Id: //depot/branches/jsr-184/1.2.0/src/java/fi/hybrid/m3g/examples/Example2.java#1 $
 * $Date: 2004/12/14 $
 * $Author: otso $
 *
 *----------------------------------------------------------------------*/

package fi.hybrid.m3g.examples;

import javax.microedition.m3g.*;
import java.util.*;

/**
 * Scene graph fractal test.
 * 
 * This example should draw a whirling cloud of white cubes
 * transformed with hierarchial transforms. One of the cubes is bigger
 * than the rest. The camera should follow that cube.
 * 
 */
public class Example2 extends ExampleBase
{
    private static final String BACKGROUND_TEXTURE = "textures/pukki_small_cg2.png";

    public void test1()
    {
        int a = 4;
        int b = a & 0xf;
    }

    private World iWorld;
    private Vector iNodes;
    private Vector iAxis;

    public Example2()
    {
        super(SHOW_RENDER_TIME);
    }

    protected void render(int time)
    {
        iWorld.animate(time);

        float angle = time * 0.1f;
        for (int i = 0; i < iNodes.size(); i++)
        {
            Node node = (Node)iNodes.elementAt(i);
            float[] axis = (float[])iAxis.elementAt(i);

            node.setOrientation(angle * axis[3], axis[0], axis[1], axis[2]);
        }

        iWorld.align(null); // throws IllegalStateException on WTK22b
        Graphics3D.getInstance().render(iWorld);
    }

    protected void initialize()
    {
        iWorld = new World();
        iNodes = new Vector();
        iAxis = new Vector();
        Mesh box = createBox();

        Background bg = new Background();
        Image2D image = new Image2D(Image2D.RGB, platformServices.loadImage(BACKGROUND_TEXTURE));
        bg.setColor(0xff204080);
        bg.setImage(image);
        int b = 16;
        bg.setCrop(-b, -b, 64+2*b, 64+2*b);
        iWorld.setBackground(bg);

        Camera camera = new Camera();
        camera.setPerspective(90.0f, 1.0f, 1.0f, 100.0f);
        camera.setTranslation(0.0f, 0.0f, 30.0f);
        iWorld.addChild(camera);
        iWorld.setActiveCamera(camera);

        Light light = new Light();
        light.setTranslation(0.0f, 0.0f, 30.0f);
        iWorld.addChild(light);

        Node ground = (Node)box.duplicate();
        ground.setTranslation(0.0f, -20.0f, 0.0f);
        ground.setScale(2.0f, 0.1f, 2.0f);
        iWorld.addChild(ground);

        Node fractal = createRecursive(box, 5);
        iWorld.addChild(fractal);

        Node target = fractal;
        while (target instanceof Group)
        {
            target = ((Group)target).getChild((int)(random() * 2.0f));
        }
        target.scale(3.0f, 3.0f, 3.0f);

        camera.setScale(-1.0f, 1.0f, -1.0f);
        camera.setAlignment(target, Node.ORIGIN, iWorld, Node.Y_AXIS);

        for (int i = 0; i < 1; i++)
        {
            int num = 25;
            int duration = 3000;
            int comps = 4;

//          KeyframeSequence seq = new KeyframeSequence(num, comps, KeyframeSequence.LINEAR);
//          KeyframeSequence seq = new KeyframeSequence(num, comps, KeyframeSequence.SLERP);
            KeyframeSequence seq = new KeyframeSequence(num, comps, KeyframeSequence.SPLINE);
//          KeyframeSequence seq = new KeyframeSequence(num, comps, KeyframeSequence.SQUAD);
//          KeyframeSequence seq = new KeyframeSequence(num, comps, KeyframeSequence.STEP);
//          seq.setRepeatMode(KeyframeSequence.CONSTANT);
            seq.setRepeatMode(KeyframeSequence.LOOP);
            seq.setDuration(duration);

            for (int j = 0; j < num; j++)
            {
                float[] value = new float[comps];
                for (int k = 0; k < comps; k++)
                {
                    if (k <= 1)
                        value[k] = ((float)random() - 0.5f) * 32.0f;
                    else
                        value[k] = ((float)random() + 1.0f) * 48.0f;
                }

                seq.setKeyframe(j, (j * 2 + 1) * duration / (num * 2), value);
            }

            AnimationController ctrl = new AnimationController();

            AnimationTrack track = new AnimationTrack(seq, AnimationTrack.CROP);
            track.setController(ctrl);

            bg.addAnimationTrack(track);
        }
    }

    private Node createRecursive(Mesh aBox, int aCounter)
    {
        float scale = 0.7f;
        float offset = 8.0f;

        Node result;
        if (aCounter == 0)
        {
            result = (Node)aBox.duplicate();
        } else
        {
            Node left = createRecursive(aBox, aCounter - 1);
            Node right = createRecursive(aBox, aCounter - 1);
            left.translate(-offset, 0.0f, 0.0f);
            left.scale(scale, scale, scale);
            right.translate(offset, 0.0f, 0.0f);
            right.scale(scale, scale, scale);

            Group group = new Group();
            group.addChild(left);
            group.addChild(right);
            result = group;
        }

        iNodes.addElement(result);
        float[] axis = new float[4];
        axis[0] = (float)random() - 0.5f;
        axis[1] = (float)random() - 0.5f;
        axis[2] = (float)random() - 0.5f;
        axis[3] = (float)random();
        iAxis.addElement(axis);

        return result;
    }
}
