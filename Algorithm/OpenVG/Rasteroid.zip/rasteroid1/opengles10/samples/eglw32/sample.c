/*************************************************************************
 *
 * Gerbera/EGL sample app
 * ----------------------
 *
 * (C) 2001-2004 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * The most up-to-date version of the OpenGL ES 1.1 specification
 * can be found from http://www.khronos.org/opengles/spec.html
 *
 * Description: Sample application that renders a red spinning
 *              cube on a blue background.
 *
 * $Archive: /gerbera/samples/eglw32/sample.c $
 * $Author: jasinb $
 * $Revision: #1 $
 *
 ************************************************************************/

#define SAMPLE_SURFACE_TYPE EGL_WINDOW_BIT
//#define SAMPLE_SURFACE_TYPE EGL_PIXMAP_BIT
//#define SAMPLE_SURFACE_TYPE EGL_PBUFFER_BIT

#define SAMPLE_COLOR_DEPTH 32   /* 16/32 */

#if !defined(SAMPLE_SURFACE_TYPE) || ((SAMPLE_SURFACE_TYPE != EGL_WINDOW_BIT) && (SAMPLE_SURFACE_TYPE != EGL_PIXMAP_BIT) && (SAMPLE_SURFACE_TYPE != EGL_PBUFFER_BIT))
#   error Define SAMPLE_SURFACE_TYPE properly.
#endif

#if defined (_MSC_VER)
#   pragma warning(disable : 4115) /* named type definition in parentheses */
#endif

#include <windows.h>
#include <math.h>
#include "GLES/gl.h"
#include "GLES/egl.h"

#include <stdio.h>

/* EGL resources and Windows globals, defines, and prototypes */
static LONG WINAPI  MainWndProc (HWND, UINT, WPARAM, LPARAM);

#define             SAMPLE_WINDOW_WIDTH     300
#define             SAMPLE_WINDOW_HEIGHT    300

static const char   szAppName[] = "Gerbera OpenGL ES sample app";
static HWND         ghWnd;

static EGLDisplay   eglDisplay;
static EGLConfig    eglConfig;
static EGLContext   eglContext;
static EGLSurface   eglWindowSurface;

/*-------------------------------------------------------------------------
 * OpenGL ES code
 *-----------------------------------------------------------------------*/

/* Vertices */
static const GLbyte s_cubeVertices[] =
{
    -10,  10,  10,
     10, -10,  10,
     10,  10,  10,
    -10, -10,  10,

    -10,  10, -10,
     10, -10, -10,
     10,  10, -10,
    -10, -10, -10,

    -10, -10,  10,
     10, -10, -10,
     10, -10,  10,
    -10, -10, -10,

    -10,  10,  10,
     10,  10, -10,
     10,  10,  10,
    -10,  10, -10,

     10, -10,  10,
     10,  10, -10,
     10,  10,  10,
     10, -10, -10,

    -10, -10,  10,
    -10,  10, -10,
    -10,  10,  10,
    -10, -10, -10
};

static const GLubyte s_cubeColors[] =
{
     40,  80, 160, 255,
     40,  80, 160, 255,
     40,  80, 160, 255,
     40,  80, 160, 255,

     40,  80, 160, 255,
     40,  80, 160, 255,
     40,  80, 160, 255,
     40,  80, 160, 255,

    128, 128, 128, 255,
    128, 128, 128, 255,
    128, 128, 128, 255,
    128, 128, 128, 255,

    128, 128, 128, 255,
    128, 128, 128, 255,
    128, 128, 128, 255,
    128, 128, 128, 255,

    255, 110,  10, 255,
    255, 110,  10, 255,
    255, 110,  10, 255,
    255, 110,  10, 255,

    255,  70,  60, 255,
    255,  70,  60, 255,
    255,  70,  60, 255,
    255,  70,  60, 255
};

/* Vertex indices */
static const GLubyte s_cubeIndices[] =
{
     0, 3, 1, 2, 0, 1,  /* front    */
     6, 5, 4, 5, 7, 4,  /* back     */
     8,11, 9,10, 8, 9,  /* top      */
    15,12,13,12,14,13,  /* bottom   */
    16,19,17,18,16,17,  /* right    */
    23,20,21,20,22,21   /* left     */
};

/* Normals */
static const GLbyte s_cubeNormals[] =
{
    0, 0, 127,
    0, 0, 127,
    0, 0, 127,
    0, 0, 127,

    0, 0, -128,
    0, 0, -128,
    0, 0, -128,
    0, 0, -128,

    0, -128, 0,
    0, -128, 0,
    0, -128, 0,
    0, -128, 0,

    0, 127, 0,
    0, 127, 0,
    0, 127, 0,
    0, 127, 0,

    127, 0, 0,
    127, 0, 0,
    127, 0, 0,
    127, 0, 0,

    -128, 0, 0,
    -128, 0, 0,
    -128, 0, 0,
    -128, 0, 0
};

#if defined(GL_OES_VERSION_1_1)
static const GLuint s_vertexBufferID    = 1;
static const GLuint s_normalBufferID    = 2;
static const GLuint s_indexBufferID     = 3;
#endif

/*-------------------------------------------------------------------*//*!
 * \brief   Sets the perspective matrix to OpenGL.
 * \param   fovy    Vertical field-of-view.
 * \param   aspect  Aspect ratio.
 * \param   zNear   Distance to near plane.
 * \param   zFar    Distance to far plane.
 *//*-------------------------------------------------------------------*/

static void perspective (
    GLfloat fovy,
    GLfloat aspect,
    GLfloat zNear,
    GLfloat zFar)
{
    GLfloat xmin, xmax, ymin, ymax;

    ymax = zNear * (GLfloat)tan(fovy * 3.1415962f / 360.0);
    ymin = -ymax;
    xmin = ymin * aspect;
    xmax = ymax * aspect;

    glFrustumf(xmin, xmax, ymin, ymax, zNear, zFar);
}

/*-------------------------------------------------------------------*//*!
 * \internal
 * \brief   Update state.
 * \param   width   Rendering width.
 * \param   height  Rendering height.
 *//*-------------------------------------------------------------------*/

static void updateState (
    int width,
    int height)
{
    static const GLfloat light_position[]   = { -50.f, 50.f, 50.f, 0.f };
    static const GLfloat light_ambient[]    = { 0.125f, 0.125f, 0.125f, 1.f };
    static const GLfloat light_diffuse[]    = { 0.7f, 0.7f, 0.7f, 1.f };
    static const GLfloat material_spec[]    = { 0.7f, 0.7f, 0.7f, 0.f };
    static const GLfloat zero_vec4[]        = { 0.0f, 0.0f, 0.0f, 0.f };

    float aspect = height ? (float)width/(float)height : 1.0f;

    glViewport          (0, 0, width, height);
    glScissor           (0, 0, width, height);

    glMatrixMode        (GL_MODELVIEW);
    glLoadIdentity      ();

    glLightfv           (GL_LIGHT0, GL_POSITION, light_position);
    glLightfv           (GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv           (GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv           (GL_LIGHT0, GL_SPECULAR, zero_vec4);
    glMaterialfv        (GL_FRONT_AND_BACK, GL_SPECULAR, material_spec);

    glDisable           (GL_NORMALIZE);
    glEnable            (GL_LIGHTING);
    glEnable            (GL_LIGHT0);
    glEnable            (GL_COLOR_MATERIAL);
    glEnable            (GL_CULL_FACE);

    glHint              (GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);

    glShadeModel        (GL_FLAT);
    glDisable           (GL_DITHER);
    glClearColor        (0.1f, 0.2f, 0.4f, 0.f );

    glColor4x           (0x10000, 0, 0, 0);
    glEnableClientState (GL_VERTEX_ARRAY);
    glEnableClientState (GL_NORMAL_ARRAY);

    glMatrixMode        (GL_PROJECTION);
    glLoadIdentity      ();
    perspective         (60.f, aspect, 0.1f, 100.f);
}

/*-------------------------------------------------------------------*//*!
 * \brief   Initialize graphics.
 *//*-------------------------------------------------------------------*/

static void init (void)
{
#if defined(GL_OES_VERSION_1_1)
    glBindBuffer(GL_ARRAY_BUFFER, s_vertexBufferID);
    glBufferData(GL_ARRAY_BUFFER, sizeof(s_cubeVertices), s_cubeVertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, s_normalBufferID);
    glBufferData(GL_ARRAY_BUFFER, sizeof(s_cubeNormals), s_cubeNormals, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, s_indexBufferID);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(s_cubeIndices), s_cubeIndices, GL_STATIC_DRAW);
#endif
}

/*-------------------------------------------------------------------*//*!
 * \brief   Draw the scene.
 * \param   width   Rendering width in pixels
 * \param   height  Rendering height in pixels
 *//*-------------------------------------------------------------------*/

static void drawScene (
    int width,
    int height)
{
    const double time = fmod(GetTickCount() / 1000.0, 360.0);

    updateState     (width, height);
    glClear         (GL_COLOR_BUFFER_BIT);

    glMatrixMode    (GL_MODELVIEW);
    glLoadIdentity  ();

    glTranslatef    (0.f, 0.f, -30.f);
    glRotatef       ((float)(time*29.77f), 1.0f, 2.0f, 0.0f);
    glRotatef       ((float)(time*22.311f), -0.1f, 0.0f, -5.0f);

#if defined(GL_OES_VERSION_1_1)
/*  glEnableClientState(GL_COLOR_ARRAY);
    glBindBuffer    (GL_ARRAY_BUFFER, 0);
    glColorPointer  (4, GL_UNSIGNED_BYTE, 0, s_cubeColors);*/

    glBindBuffer    (GL_ARRAY_BUFFER, s_vertexBufferID);
    glVertexPointer (3, GL_BYTE, 0, 0);

    glBindBuffer    (GL_ARRAY_BUFFER, s_normalBufferID);
    glNormalPointer (GL_BYTE, 0, 0);

    glBindBuffer    (GL_ELEMENT_ARRAY_BUFFER, s_indexBufferID);
    glDrawElements  (GL_TRIANGLES, 6*6, GL_UNSIGNED_BYTE, 0);
#else
    glVertexPointer (3, GL_BYTE, 0, s_cubeVertices);
    glNormalPointer (GL_BYTE, 0, s_cubeNormals);
    glDrawElements  (GL_TRIANGLES, 6*6, GL_UNSIGNED_BYTE, s_cubeIndices);
#endif

#if (SAMPLE_SURFACE_TYPE == EGL_WINDOW_BIT)
    eglSwapBuffers  (eglDisplay, eglWindowSurface);
#endif
}

#if (SAMPLE_SURFACE_TYPE == EGL_PIXMAP_BIT)

/*-------------------------------------------------------------------*//*!
 * \brief   Create a DIB section bitmap.
 * \param   hDC DC handle.
 * \return  Returns the handle to the created bitmap.
 *//*-------------------------------------------------------------------*/

static HBITMAP createPixmap (HDC hDC)
{
    const size_t    bmiSize = sizeof(BITMAPINFO) + 256U*sizeof(RGBQUAD);
    BITMAPINFO*     bmi;
    DWORD*          bits;

    bmi = (BITMAPINFO*)malloc(bmiSize);
    memset(bmi, 0, bmiSize);

    bmi->bmiHeader.biSize           = sizeof(BITMAPINFOHEADER);
    bmi->bmiHeader.biWidth          = SAMPLE_WINDOW_WIDTH;
    bmi->bmiHeader.biHeight         = -SAMPLE_WINDOW_HEIGHT;
    bmi->bmiHeader.biPlanes         = (short)1;
    bmi->bmiHeader.biBitCount       = (unsigned short)SAMPLE_COLOR_DEPTH;
    bmi->bmiHeader.biCompression    = BI_RGB;
    bmi->bmiHeader.biSizeImage      = 0;
    bmi->bmiHeader.biXPelsPerMeter  = 0;
    bmi->bmiHeader.biYPelsPerMeter  = 0;
    bmi->bmiHeader.biClrUsed        = 3;
    bmi->bmiHeader.biClrImportant   = 0;

#if (SAMPLE_COLOR_DEPTH != 16) && (SAMPLE_COLOR_DEPTH != 32)
#   error SAMPLE_COLOR_DEPTH must be either 16 or 32
#endif

    return CreateDIBSection(hDC, bmi, DIB_RGB_COLORS, &bits, NULL, 0);
}

/*-------------------------------------------------------------------*//*!
 * \brief   Destroy the given bitmap.
 * \param   bitmap  Bitmap handle.
 *//*-------------------------------------------------------------------*/

static void deletePixmap (
    HBITMAP bitmap)
{
    DeleteObject(bitmap);
}

#endif /* SAMPLE_SURFACE_TYPE == EGL_PIXMAP_BIT */

/*-------------------------------------------------------------------*//*!
 * \brief   Main procedure.
 * \param   hInstance       Instance handle.
 * \param   hPrevInstance   Previous instance handle.
 * \param   lpCmdLine       Command line.
 * \param   nCmdShow        Show command.
 * \return  Returns exit status.
 *//*-------------------------------------------------------------------*/

int WINAPI WinMain (
    HINSTANCE   hInstance,
    HINSTANCE   hPrevInstance,
    LPSTR       lpCmdLine,
    int         nCmdShow)
{
    MSG             msg;
    WNDCLASS        wndclass;

    hPrevInstance;
    lpCmdLine;

    /* Register the frame class */
    wndclass.style         = 0;
    wndclass.lpfnWndProc   = (WNDPROC)MainWndProc;
    wndclass.cbClsExtra    = 0;
    wndclass.cbWndExtra    = 0;
    wndclass.hInstance     = hInstance;
    wndclass.hIcon         = LoadIcon (hInstance, szAppName);
    wndclass.hCursor       = LoadCursor (NULL,IDC_ARROW);
    wndclass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wndclass.lpszMenuName  = szAppName;
    wndclass.lpszClassName = szAppName;

    if (!RegisterClass (&wndclass) )
        return FALSE;

    /* Create the frame */
    ghWnd = CreateWindow (szAppName,
                          szAppName,
                          WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
                          CW_USEDEFAULT,
                          CW_USEDEFAULT,
                          SAMPLE_WINDOW_WIDTH,
                          SAMPLE_WINDOW_HEIGHT,
                          NULL,
                          NULL,
                          hInstance,
                          NULL);

    /* make sure window was created */
    if (!ghWnd)
        return FALSE;

    /* adjust client rectangle size */
    {
        RECT    rc;
        DWORD   dwStyle;
        int     xp;
        int     yp;
        int     menuFlag;

        /* change window style to popup */
        dwStyle = GetWindowLong(ghWnd, GWL_STYLE);

        GetWindowRect(ghWnd, &rc);
        xp = rc.left;
        yp = rc.top;

        menuFlag    = GetMenu(ghWnd) != NULL;
        rc.top      = rc.left = 0;
        rc.right    = SAMPLE_WINDOW_WIDTH;
        rc.bottom   = SAMPLE_WINDOW_HEIGHT;
        AdjustWindowRect(&rc, dwStyle, menuFlag);

        SetWindowPos(ghWnd, HWND_NOTOPMOST, xp, yp, rc.right - rc.left, rc.bottom - rc.top,
                     SWP_NOZORDER | SWP_NOACTIVATE);
    }

    /* show and update main window */
    ShowWindow (ghWnd, nCmdShow);
    UpdateWindow (ghWnd);

    /* message loop */
    for (;;)
    {
        RECT rc;
        while (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE) == TRUE)
        {
            if (GetMessage(&msg, NULL, 0, 0) )
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
            else
                return 0;
        }

        GetClientRect(ghWnd, &rc);
        drawScene(rc.right, rc.bottom);
        InvalidateRect(ghWnd, NULL, FALSE);
    }
}

/*-------------------------------------------------------------------*//*!
 * \brief   Main window procedure.
 * \param   hWnd    Window handle.
 * \param   uMsg    Message.
 * \param   wParam  Parameter.
 * \param   lParam  Parameter.
 * \return  Returns the return status.
 *//*-------------------------------------------------------------------*/

static LONG WINAPI MainWndProc (
    HWND    hWnd,
    UINT    uMsg,
    WPARAM  wParam,
    LPARAM  lParam)
{
    static HBITMAP  pixmap;
    PAINTSTRUCT     ps;
    LONG            lRet = 1;

    switch (uMsg)
    {
    case WM_CREATE:
        {
            /* EGL Setup */
            static const EGLint s_configAttribs[] =
            {
#if (SAMPLE_COLOR_DEPTH == 16)
                EGL_RED_SIZE,       5,
                EGL_GREEN_SIZE,     5,
                EGL_BLUE_SIZE,      5,
#elif (SAMPLE_COLOR_DEPTH == 32)
                EGL_RED_SIZE,       8,
                EGL_GREEN_SIZE,     8,
                EGL_BLUE_SIZE,      8,
#endif
                EGL_ALPHA_SIZE,     EGL_DONT_CARE,
                EGL_DEPTH_SIZE,     EGL_DONT_CARE,
                EGL_STENCIL_SIZE,   EGL_DONT_CARE,
                EGL_SURFACE_TYPE,   SAMPLE_SURFACE_TYPE,
                EGL_NONE
            };

#if (SAMPLE_SURFACE_TYPE == EGL_PBUFFER_BIT)
            static const EGLint s_pbufferAttribs[] =
            {
                EGL_WIDTH,  SAMPLE_WINDOW_WIDTH,
                EGL_HEIGHT, SAMPLE_WINDOW_HEIGHT,
                EGL_NONE
            };
#endif

            EGLint numConfigs;
            EGLint majorVersion;
            EGLint minorVersion;

#if (SAMPLE_SURFACE_TYPE == EGL_PIXMAP_BIT)
            HDC dc = GetDC(hWnd);
            pixmap = createPixmap(dc);
            ReleaseDC(hWnd, dc);
#endif

            eglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
            eglInitialize(eglDisplay, &majorVersion, &minorVersion);
            eglGetConfigs(eglDisplay, NULL, 0, &numConfigs);
            eglChooseConfig(eglDisplay, s_configAttribs, &eglConfig, 1, &numConfigs);
            eglContext = eglCreateContext(eglDisplay, eglConfig, NULL, NULL);

#if (SAMPLE_SURFACE_TYPE == EGL_WINDOW_BIT)
            eglWindowSurface = eglCreateWindowSurface(eglDisplay, eglConfig, hWnd, NULL);
#elif (SAMPLE_SURFACE_TYPE == EGL_PIXMAP_BIT)
            eglWindowSurface = eglCreatePixmapSurface(eglDisplay, eglConfig, pixmap, NULL);
#elif (SAMPLE_SURFACE_TYPE == EGL_PBUFFER_BIT)
            eglWindowSurface = eglCreatePbufferSurface(eglDisplay, eglConfig, s_pbufferAttribs);
#endif
            eglMakeCurrent(eglDisplay, eglWindowSurface, eglWindowSurface, eglContext);

            init();
        }
        break;

    case WM_PAINT:
        {
            HDC dc = BeginPaint(hWnd, &ps);
#if (SAMPLE_SURFACE_TYPE == EGL_PIXMAP_BIT)
            HDC hdcBitmap = CreateCompatibleDC((HDC)dc);
            HDC old = SelectObject(hdcBitmap, pixmap);

            int dx0 = 0;
            int dy0 = 0;
            int dx1 = SAMPLE_WINDOW_WIDTH;
            int dy1 = SAMPLE_WINDOW_HEIGHT;

            StretchBlt((HDC)dc, dx0, dy0, dx1, dy1, hdcBitmap, dx0, dy0, dx1, dy1, SRCCOPY);

            SelectObject(hdcBitmap, old);
#else
            (void)dc; /* unreferenced */
#endif
            EndPaint(hWnd, &ps);
        }
        break;

    case WM_SIZE:
        /* resizing is handled each frame */
        break;

    case WM_CLOSE:
        DestroyWindow (hWnd);
        break;

    case WM_DESTROY:
        /* Destroy all EGL resources */
        eglMakeCurrent(eglDisplay, NULL, NULL, NULL);
        eglDestroyContext(eglDisplay, eglContext);
        eglDestroySurface(eglDisplay, eglWindowSurface);
        eglTerminate(eglDisplay);
#if (SAMPLE_SURFACE_TYPE == EGL_PIXMAP_BIT)
        deletePixmap(pixmap);
#endif
        PostQuitMessage (0);
        break;

    case WM_KEYDOWN:
        if (wParam == VK_ESCAPE)
            SendMessage(hWnd, WM_CLOSE, 0, 0);
        /* FALLTHROUGH */

    default:
        lRet = DefWindowProc (hWnd, uMsg, wParam, lParam);
        break;
    }

    return lRet;
}

/*----------------------------------------------------------------------*/

