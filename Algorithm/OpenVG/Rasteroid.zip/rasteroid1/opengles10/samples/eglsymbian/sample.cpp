/*************************************************************************
 *
 * Gerbera/EGL sample app
 * ----------------------
 *
 * (C) 2001-2005 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * The most up-to-date version of the OpenGL ES 1.1 specification
 * can be found from http://www.khronos.org/opengles/spec.html
 *
 * Description: Sample application that renders a red spinning
 *              cube on a blue background.
 *
 * $Author: jasinb $
 * $Revision: #2 $
 *
 ************************************************************************/
#include <e32std.h>     // User
#include <coecntrl.h>   // CCoeControl
#include <aknappui.h>   // CAknAppUi
#include <eikdoc.h>     // CEikDocument
#include <aknapp.h>     // CAknApplication

#include <math.h>

#include "GLES/egl.h"
#include "GLES/gl.h"

//------------------------------------------------------------------------

#include <stdio.h>
#include <stdarg.h>

extern "C" void myPrintf (const char* format, ...)
{
#if defined(__SYMBIAN32__)
    FILE* f = fopen("c:\\g_log.txt", "a");
    if (f)
    {
        va_list args;
        va_start(args, format);
        vfprintf(f, format, args);
        va_end(args);
        fclose(f);
    }
#else
    char str[512];

    va_list args;
    va_start(args, format);

    vsprintf(str, format, args);
    va_end(args);

#   if defined (_WIN32) || defined (WIN32)
        OutputDebugString(str);
#   endif

    printf("%s", str);
#endif
}

//------------------------------------------------------------------------
/* OpenGL code */

static void perspective(GLfloat fovy, GLfloat aspect,
                        GLfloat zNear, GLfloat zFar)
{
    GLfloat xmin, xmax, ymin, ymax;

    ymax = zNear * (GLfloat)tan(fovy * 3.1415962f / 360.0);
    ymin = -ymax;
    xmin = ymin * aspect;
    xmax = ymax * aspect;

    glFrustumf(xmin, xmax, ymin, ymax, zNear, zFar);
}

//------------------------------------------------------------------------

// DemoTimer

class DemoTimer : public CTimer
{
public:
    class Callback
    {
    public:
                        Callback        (void) {}
        virtual         ~Callback       (void) {}
        virtual void    timerEvent      (void) = 0;
    };

                    DemoTimer   (Callback& callback);
                    ~DemoTimer  (void);

    void            ConstructL  (void);

    void            start       (void);
    void            stop        (void);

private:
    virtual void    RunL        (void);

    Callback&       m_callback;
};

DemoTimer::DemoTimer (Callback& callback) :
    CTimer      (CActive::EPriorityLow),
    m_callback  (callback)
{
}

void DemoTimer::ConstructL (void)
{
    CTimer::ConstructL();
    CActiveScheduler::Add(this);
}

DemoTimer::~DemoTimer (void)
{
    CTimer::Cancel();
}

void DemoTimer::RunL (void)
{
    m_callback.timerEvent();
    After(TTimeIntervalMicroSeconds32(1));
}

void DemoTimer::start (void)
{
    After(TTimeIntervalMicroSeconds32(1));
}

void DemoTimer::stop (void)
{
    CTimer::Cancel();
}

/* Vertices */
static const GLbyte s_cubeVertices[] =
{
    -10,  10,  10,
     10, -10,  10,
     10,  10,  10,
    -10, -10,  10,

    -10,  10, -10,
     10, -10, -10,
     10,  10, -10,
    -10, -10, -10,

    -10, -10,  10,
     10, -10, -10,
     10, -10,  10,
    -10, -10, -10,

    -10,  10,  10,
     10,  10, -10,
     10,  10,  10,
    -10,  10, -10,

     10, -10,  10,
     10,  10, -10,
     10,  10,  10,
     10, -10, -10,

    -10, -10,  10,
    -10,  10, -10,
    -10,  10,  10,
    -10, -10, -10
};

/* Vertex indices */
static const GLubyte s_cubeIndices[] =
{
     0, 3, 1, 2, 0, 1,  /* front    */
     6, 5, 4, 5, 7, 4,  /* back     */
     8,11, 9,10, 8, 9,  /* top      */
    15,12,13,12,14,13,  /* bottom   */
    16,19,17,18,16,17,  /* right    */
    23,20,21,20,22,21   /* left     */
};

/* Normals */
static const GLbyte s_cubeNormals[] =
{
    0, 0, 127,
    0, 0, 127,
    0, 0, 127,
    0, 0, 127,

    0, 0, -128,
    0, 0, -128,
    0, 0, -128,
    0, 0, -128,

    0, -128, 0,
    0, -128, 0,
    0, -128, 0,
    0, -128, 0,

    0, 127, 0,
    0, 127, 0,
    0, 127, 0,
    0, 127, 0,

    127, 0, 0,
    127, 0, 0,
    127, 0, 0,
    127, 0, 0,

    -128, 0, 0,
    -128, 0, 0,
    -128, 0, 0,
    -128, 0, 0
};

#if defined(GL_OES_VERSION_1_1)
static const GLuint s_vertexBufferID    = 1;
static const GLuint s_normalBufferID    = 2;
static const GLuint s_indexBufferID     = 3;
#endif

// Demo

class Demo : public DemoTimer::Callback
{
public:
                    Demo        (RWsSession& wsSession, RWindow* window);
    virtual         ~Demo       (void);

    void            ConstructL  (void);

    void            start       (void);
    void            stop        (void);

    virtual void    timerEvent  (void);
    void            render      (float time);
    void            init        (void);

private:
    enum
    {

#if defined (_MSC_VER) || defined (__VC32__) /* WINS */
        NUM_TIMERS = 10
#else /* Symbian */
        NUM_TIMERS = 2
#endif
    };

    TTime           m_startTime;

    RWsSession&     m_wsSession;
    RWindow*        m_window;

    DemoTimer*      m_timers[NUM_TIMERS];

    EGLDisplay      m_display;
    EGLConfig       m_config;
    EGLContext      m_context;
    EGLSurface      m_surface;
};

Demo::Demo (RWsSession& wsSession, RWindow* window) :
    m_wsSession(wsSession),
    m_window(window)
{
    m_startTime.UniversalTime();

    for (int i = 0; i < NUM_TIMERS; i++)
        m_timers[i] = new DemoTimer(*this);

    // Initialize EGL

    static const EGLint attribList[] =
    {
        EGL_RED_SIZE,       8,
        EGL_GREEN_SIZE,     8,
        EGL_BLUE_SIZE,      8,
        EGL_ALPHA_SIZE,     EGL_DONT_CARE,
        EGL_DEPTH_SIZE,     32,
        EGL_STENCIL_SIZE,   EGL_DONT_CARE,
        EGL_NONE
    };

    EGLint numConfigs;
    EGLint majorVersion;
    EGLint minorVersion;

    m_display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(m_display, &majorVersion, &minorVersion);
    eglGetConfigs(m_display, NULL, 0, &numConfigs);
    eglChooseConfig(m_display, attribList, &m_config, 1, &numConfigs);
    m_context = eglCreateContext(m_display, m_config, NULL, NULL);
    m_surface = eglCreateWindowSurface(m_display, m_config, m_window, NULL);
    eglMakeCurrent(m_display, m_surface, m_surface, m_context);

    init();
}

void Demo::ConstructL (void)
{
    for (int i = 0; i < NUM_TIMERS; i++)
        if (m_timers[i]) m_timers[i]->ConstructL();
}

Demo::~Demo (void)
{
    for (int i = 0; i < NUM_TIMERS; i++)
        delete m_timers[i];

    eglDestroyContext(m_display, m_context);
    eglDestroySurface(m_display, m_surface);
    eglTerminate(m_display);
}

void Demo::start (void)
{
    for (int i = 0; i < NUM_TIMERS; i++)
        if (m_timers[i]) m_timers[i]->start();
}

void Demo::stop (void)
{
    for (int i = 0; i < NUM_TIMERS; i++)
        if (m_timers[i]) m_timers[i]->stop();
}

void Demo::timerEvent (void)
{
    User::ResetInactivityTime();

    TTime currentTime;
    currentTime.UniversalTime();
    TInt64 elapsedTime = currentTime.MicroSecondsFrom(m_startTime).Int64();
    elapsedTime.Lsr(14);
    float time = elapsedTime.Low() / (1000000.0f / 16384.0f);

    render(time);
}

void Demo::init (void)
{
#if defined(GL_OES_VERSION_1_1)
    glBindBuffer(GL_ARRAY_BUFFER, s_vertexBufferID);
    glBufferData(GL_ARRAY_BUFFER, sizeof(s_cubeVertices), s_cubeVertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, s_normalBufferID);
    glBufferData(GL_ARRAY_BUFFER, sizeof(s_cubeNormals), s_cubeNormals, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, s_indexBufferID);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(s_cubeIndices), s_cubeIndices, GL_STATIC_DRAW);
#endif
}

static void updateState (int width, int height)
{
    static const GLfloat light_position[]   = { -50.f, 50.f, 50.f, 0.f };
    static const GLfloat light_ambient[]    = { 0.125f, 0.125f, 0.125f, 1.f };
    static const GLfloat light_diffuse[]    = { 0.7f, 0.7f, 0.7f, 1.f };
    static const GLfloat material_spec[]    = { 0.7f, 0.7f, 0.7f, 0.f };
    static const GLfloat zero_vec4[]        = { 0.0f, 0.0f, 0.0f, 0.f };

    float aspect = height ? (float)width/(float)height : 1.0f;

    glViewport          (0, 0, width, height);
    glScissor           (0, 0, width, height);

    glMatrixMode        (GL_MODELVIEW);
    glLoadIdentity      ();

    glLightfv           (GL_LIGHT0, GL_POSITION, light_position);
    glLightfv           (GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv           (GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv           (GL_LIGHT0, GL_SPECULAR, zero_vec4);
    glMaterialfv        (GL_FRONT_AND_BACK, GL_SPECULAR, material_spec);

    glDisable           (GL_NORMALIZE);
    glEnable            (GL_LIGHTING);
    glEnable            (GL_LIGHT0);
    glEnable            (GL_COLOR_MATERIAL);
    glEnable            (GL_CULL_FACE);

    glHint              (GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);

    glShadeModel        (GL_FLAT);
    glDisable           (GL_DITHER);
    glClearColor        (0.1f, 0.2f, 0.4f, 0.f );

    glColor4x           (0x10000, 0, 0, 0);
    glEnableClientState (GL_VERTEX_ARRAY);
    glEnableClientState (GL_NORMAL_ARRAY);

    glMatrixMode        (GL_PROJECTION);
    glLoadIdentity      ();
    perspective         (60.f, aspect, 0.1f, 100.f);
}

void Demo::render (float time)
{
    int width   = 176;
    int height  = 208;

    updateState     (width, height);
    glClear         (GL_COLOR_BUFFER_BIT);

    glMatrixMode    (GL_MODELVIEW);
    glLoadIdentity  ();

    glTranslatef    (0.f, 0.f, -30.f);
    glRotatef       ((float)(time*29.77f), 1.0f, 2.0f, 0.0f);
    glRotatef       ((float)(time*22.311f), -0.1f, 0.0f, -5.0f);

#if defined(GL_OES_VERSION_1_1)
/*  glEnableClientState(GL_COLOR_ARRAY);
    glBindBuffer    (GL_ARRAY_BUFFER, 0);
    glColorPointer  (4, GL_UNSIGNED_BYTE, 0, s_cubeColors);*/

    glBindBuffer    (GL_ARRAY_BUFFER, s_vertexBufferID);
    glVertexPointer (3, GL_BYTE, 0, 0);

    glBindBuffer    (GL_ARRAY_BUFFER, s_normalBufferID);
    glNormalPointer (GL_BYTE, 0, 0);

    glBindBuffer    (GL_ELEMENT_ARRAY_BUFFER, s_indexBufferID);
    glDrawElements  (GL_TRIANGLES, 6*6, GL_UNSIGNED_BYTE, 0);
#else
    glVertexPointer (3, GL_BYTE, 0, s_cubeVertices);
    glNormalPointer (GL_BYTE, 0, s_cubeNormals);
    glDrawElements  (GL_TRIANGLES, 6*6, GL_UNSIGNED_BYTE, s_cubeIndices);
#endif

    /* swap */
    eglSwapBuffers  (m_display, m_surface);
}

// CAppView

class CAppView : public CCoeControl
{
public:
    static CAppView*    NewL            (const TRect& aRect);
    static CAppView*    NewLC           (const TRect& aRect);
                        ~CAppView       (void);

    /*-------------------------------------------------------------------*/

//  void            Draw                ()
    void            StartDemo           (void);
    void            StopDemo            (void);

    TKeyResponse    OfferKeyEventL      (const TKeyEvent& event, TEventCode type);

private:
                    CAppView            (void);
    void            ConstructL          (const TRect& aRect);

    /*-------------------------------------------------------------------*/

    Demo*               m_demo;

    RWsSession          m_iSession;
    RWindowGroup        m_iWindowGroup;
    RWindow             m_iWindow;
    CWsScreenDevice*    m_iScreen;
};

CAppView* CAppView::NewL(const TRect& aRect)
{
    CAppView* self = CAppView::NewLC(aRect);
    CleanupStack::Pop();
    return self;
}

CAppView* CAppView::NewLC(const TRect& aRect)
{
    CAppView* self = new (ELeave) CAppView;
    CleanupStack::PushL(self);
    self->ConstructL(aRect);
    return self;
}

void CAppView::ConstructL(const TRect& aRect)
{
    // create window and set its size
    CreateWindowL();
    SetRect(aRect);

    // reset the keyboard status
    //  for (int i=0;i<KEY_MAX;i++)
    //      m_keyboardBuffer[i] = false;

    m_demo = new (ELeave) Demo(iEikonEnv->WsSession(), &Window());
    m_demo->ConstructL();

    // activate window
    ActivateL();

    // start demo
    StartDemo();
}

CAppView::CAppView() :
    m_demo(NULL)
{
}

CAppView::~CAppView()
{
    StopDemo();
    delete m_demo;
    m_iSession.Close();
}

void CAppView::StartDemo()
{
    if (m_demo)
        m_demo->start();
}

void CAppView::StopDemo()
{
    if (m_demo)
        m_demo->stop();
}

TKeyResponse CAppView::OfferKeyEventL(const TKeyEvent &aKeyEvent, TEventCode aType)
{
    if (aType == EEventKeyDown)
    {
        switch (aKeyEvent.iScanCode)
        {
            case EStdKeyDevice1:    // Exit/Cancel key
                User::Exit(0);
                return EKeyWasConsumed;

            default:
                break;
        }
    }

    return EKeyWasNotConsumed;
}

// CAppUi

class CAppUi : public CAknAppUi
{
public:
                CAppUi          (void);
    virtual     ~CAppUi         (void);
    void        ConstructL      (void);

    void        HandleCommandL  (TInt command);

private:
    CAppView*   m_appView;
};

void CAppUi::ConstructL (void)
{
    BaseConstructL(ENoAppResourceFile);
    SetKeyBlockMode(ENoKeyBlock);
    m_appView = CAppView::NewL(ApplicationRect());
    AddToStackL(m_appView);
}

CAppUi::CAppUi (void)
{
}

CAppUi::~CAppUi (void)
{
    if (m_appView)
    {
        RemoveFromStack(m_appView);
        delete m_appView;
        m_appView = NULL;
    }
}

// handle any menu commands
void CAppUi::HandleCommandL (TInt command)
{
    switch(command)
    {
        case EAknSoftkeyExit:
            Exit();
            break;

/*
        case EGraphicsNoOffScreenDemo:
        case EGraphicsOffScreenDemo:
        case EGraphicsStopDemo:
        default:
            break;
*/
    }
}

// CDocument

class CDocument : public CEikDocument
{
public:
    virtual             ~CDocument      (void);

    static CDocument*   NewL            (CEikApplication& app);
    static CDocument*   NewLC           (CEikApplication& app);

private:
                        CDocument       (CEikApplication& app);
    void                ConstructL      (void);
    CEikAppUi*          CreateAppUiL    (void);
};

CDocument* CDocument::NewL (CEikApplication& app)
{
    CDocument* self = NewLC(app);
    CleanupStack::Pop();
    return self;
}

CDocument* CDocument::NewLC(CEikApplication& app)
{
    CDocument* self = new (ELeave) CDocument(app);
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
}

void CDocument::ConstructL()
{
}

CDocument::CDocument(CEikApplication& app) : CEikDocument(app)
{
}

CDocument::~CDocument()
{
}

CEikAppUi* CDocument::CreateAppUiL()
{
    // Create the application user interface, and return a pointer to it
    return new (ELeave) CAppUi;
}

// CApplication

class CApplication : public CAknApplication
{
public:
    TUid            AppDllUid           (void) const;
    TFileName       ResourceFileName    (void) const;

protected:
    CApaDocument*   CreateDocumentL     (void);
};

TFileName CApplication::ResourceFileName (void) const
{
    return TFileName();
}

CApaDocument* CApplication::CreateDocumentL (void)
{
    return CDocument::NewL(*this);
}

// DLL init.
GLDEF_C TInt E32Dll(TDllReason)
{
    return KErrNone;
}

// Create the application instance.
EXPORT_C CApaApplication* NewApplication(void)
{
    return new CApplication;
}

// Return application UID
TUid CApplication::AppDllUid (void) const
{
    static const TUid KUidGraphicsApp = {0x10005B81};
    return KUidGraphicsApp;
}
