#include "AEEModGen.h"          // Module interface definitions
#include "AEEAppGen.h"          // Applet interface definitions
#include "AEEShell.h"           // Shell interface definitions
#include "AEEStdLib.h"

#include <AEEGL.h>
#include <IGL.h>

#include "sample.bid"

#include "HYBRID_GLES.BID"
#include "HYBRID_GLES_CL.BID"
#include "HYBRID_EGL.BID"


/*-------------------------------------------------------------------------
 * APPLICATION STRUCTURE.
 *-----------------------------------------------------------------------*/

typedef struct _eglBrew
{
    AEEApplet       a;          /* First element of this structure must be AEEApplet     */
    AEEDeviceInfo   DeviceInfo; /* always have access to the hardware device information */
    IDisplay*       pIDisplay;  /* give a standard way to access the Display interface   */
    IShell*         pIShell;    /* give a standard way to access the Shell interface     */

    EGLDisplay      m_eglDisplay;   /* EGL display */
    EGLContext      m_eglContext;   /* EGL context */
    EGLConfig       m_eglConfig;    /* EGL config  */
    EGLSurface      m_eglSurface;   /* EGL surface */

    IDIB*           m_pixmap;       /* Pixmap pointer */

    IGL*            m_gl;           /* GL interface pointer  */
    IEGL*           m_egl;          /* EGL interface pointer */

} eglBrew;



/*-------------------------------------------------------------------------
 * OPENGL ES CODE.
 *-----------------------------------------------------------------------*/


/*-------------------------------------------------------------------------
 * Vertices.
 *-----------------------------------------------------------------------*/

static const GLbyte s_cubeVertices[] =
{
    -10,  10,  10,
     10, -10,  10,
     10,  10,  10,
    -10, -10,  10,

    -10,  10, -10,
     10, -10, -10,
     10,  10, -10,
    -10, -10, -10,

    -10, -10,  10,
     10, -10, -10,
     10, -10,  10,
    -10, -10, -10,

    -10,  10,  10,
     10,  10, -10,
     10,  10,  10,
    -10,  10, -10,

     10, -10,  10,
     10,  10, -10,
     10,  10,  10,
     10, -10, -10,

    -10, -10,  10,
    -10,  10, -10,
    -10,  10,  10,
    -10, -10, -10
};


/*-------------------------------------------------------------------------
 * Vertex indices.
 *-----------------------------------------------------------------------*/

static const GLubyte s_cubeIndices[] =
{
     0, 3, 1, 2, 0, 1,  /* front    */
     6, 5, 4, 5, 7, 4,  /* back     */
     8,11, 9,10, 8, 9,  /* top      */
    15,12,13,12,14,13,  /* bottom   */
    16,19,17,18,16,17,  /* right    */
    23,20,21,20,22,21   /* left     */
};

/*-------------------------------------------------------------------------
 * Normals.
 *-----------------------------------------------------------------------*/

static const GLbyte s_cubeNormals[] =
{
    0, 0, 127,
    0, 0, 127,
    0, 0, 127,
    0, 0, 127,

    0, 0, -128,
    0, 0, -128,
    0, 0, -128,
    0, 0, -128,

    0, -128, 0,
    0, -128, 0,
    0, -128, 0,
    0, -128, 0,

    0, 127, 0,
    0, 127, 0,
    0, 127, 0,
    0, 127, 0,

    127, 0, 0,
    127, 0, 0,
    127, 0, 0,
    127, 0, 0,

    -128, 0, 0,
    -128, 0, 0,
    -128, 0, 0,
    -128, 0, 0
};

#define FTOX(x) (int)((x) * 65536.f)
extern double tan (double);

/*-------------------------------------------------------------------*//*!
 * \brief   Sets the perspective matrix to OpenGL.
 * \param   fovy    Vertical field-of-view.
 * \param   aspect  Aspect ratio.
 * \param   zNear   Distance to near plane.
 * \param   zFar    Distance to far plane.
 *//*-------------------------------------------------------------------*/

static void perspective (
    GLfloat fovy,
    GLfloat aspect,
    GLfloat zNear,
    GLfloat zFar)
{
    GLfloat xmin, xmax, ymin, ymax;

    ymax = zNear * (GLfloat)tan(fovy * 3.1415962f / 360.0);
    ymin = -ymax;
    xmin = ymin * aspect;
    xmax = ymax * aspect;

    glFrustumx(FTOX(xmin), FTOX(xmax), FTOX(ymin), FTOX(ymax), FTOX(zNear), FTOX(zFar));
}

/*-------------------------------------------------------------------*//*!
 * \internal
 * \brief   Update the OpenGL ES state.
 * \param   width   Width of the viewport.
 * \param   height  Height of the viewport.
 *//*-------------------------------------------------------------------*/

static void updateState (int width, int height)
{
    static const GLfixed light_position[]   = { FTOX(-50.f), FTOX(50.f), FTOX(50.f), FTOX(0.f) };
    static const GLfixed light_ambient[]    = { FTOX(0.125f), FTOX(0.125f), FTOX(0.125f), FTOX(1.f) };
    static const GLfixed light_diffuse[]    = { FTOX(0.7f), FTOX(0.7f), FTOX(0.7f), FTOX(1.f) };
    static const GLfixed material_spec[]    = { FTOX(0.7f), FTOX(0.7f), FTOX(0.7f), FTOX(0.f) };
    static const GLfixed zero_vec4[]        = { FTOX(0.0f), FTOX(0.0f), FTOX(0.0f), FTOX(0.f) };

    float aspect = height ? (float)width/(float)height : 1.0f;

    glViewport          (0, 0, width, height);
    glScissor           (0, 0, width, height);

    glMatrixMode        (GL_MODELVIEW);
    glLoadIdentity      ();

    glLightxv           (GL_LIGHT0, GL_POSITION, light_position);
    glLightxv           (GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightxv           (GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightxv           (GL_LIGHT0, GL_SPECULAR, zero_vec4);
    glMaterialxv        (GL_FRONT_AND_BACK, GL_SPECULAR, material_spec);

    glDisable           (GL_NORMALIZE);
    glEnable            (GL_LIGHTING);
    glEnable            (GL_LIGHT0);
    glEnable            (GL_COLOR_MATERIAL);
    glEnable            (GL_CULL_FACE);

    glHint              (GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);

    glShadeModel        (GL_FLAT);
    glDisable           (GL_DITHER);
    glClearColorx       (FTOX(0.1f), FTOX(0.2f), FTOX(0.4f), FTOX(0.f) );

    glColor4x           (0x10000, 0, 0, 0);
    glEnableClientState (GL_VERTEX_ARRAY);
    glEnableClientState (GL_NORMAL_ARRAY);

    glMatrixMode        (GL_PROJECTION);
    glLoadIdentity      ();
    perspective         (60.f, aspect, 0.1f, 100.f);
}



/*-------------------------------------------------------------------*//*!
 * \brief   Draw the scene.
 * \param   width   Rendering width in pixels
 * \param   height  Rendering height in pixels
 *//*-------------------------------------------------------------------*/

static void drawScene (eglBrew* pMe)
{
    float time = GETUPTIMEMS() / 1000.f;
    IDIB* dib;
    IBitmap* bitmap;

    IDISPLAY_GetDeviceBitmap(pMe->pIDisplay, &bitmap);
    IBITMAP_QueryInterface  (bitmap, AEECLSID_DIB, (void**)&dib);


    IBITMAP_Release (bitmap);
    updateState     (dib->cx, dib->cy);
    IDIB_Release    (dib);

    glClear         (GL_COLOR_BUFFER_BIT);

    glMatrixMode    (GL_MODELVIEW);
    glLoadIdentity  ();

    glTranslatex    (FTOX(0.f), FTOX(0.f), FTOX(-30.f));
    glRotatex       (FTOX(time*29.77f), FTOX(1.0f), FTOX(2.0f), FTOX(0.0f));
    glRotatex       (FTOX(time*22.311f), FTOX(-0.1f), FTOX(0.0f), FTOX(-5.0f));

    glVertexPointer (3, GL_BYTE, 0, s_cubeVertices);
    glNormalPointer (GL_BYTE, 0, s_cubeNormals);
    glDrawElements  (GL_TRIANGLES, 6*6, GL_UNSIGNED_BYTE, s_cubeIndices);

    eglSwapBuffers(pMe->m_eglDisplay, pMe->m_eglSurface);
    IDISPLAY_Backlight(pMe->pIDisplay, TRUE);
    ISHELL_SetTimer(pMe->pIShell, 1, (PFNNOTIFY)drawScene, pMe);
}

/*-------------------------------------------------------------------------
 * BREW APPLICATION CODE.
 *-----------------------------------------------------------------------*/

boolean         eglBrew_InitAppData (eglBrew* pMe);
void            eglBrew_FreeAppData (eglBrew* pMe);
static  boolean eglBrew_HandleEvent (eglBrew* pMe,
                                     AEEEvent eCode,
                                     uint16 wParam,
                                     uint32 dwParam);

/*-------------------------------------------------------------------*//*!
 * \brief   Create class instance.
 * \param   ClsId       Class ID.
 * \param   pIShell     Shell pointer.
 * \param   *po         Module pointer.
 * \param   **ppObj     Output pointer.
 * \return  Returns AEE_SUCCESS upon success, EFAILED otherwise.
 *//*-------------------------------------------------------------------*/

int AEEClsCreateInstance (AEECLSID ClsId, IShell *pIShell, IModule *po, void **ppObj)
{
    *ppObj = NULL;

    if (ClsId == AEECLSID_HYBRID_SAMPLE)
    {

        /*-----------------------------------------------------------------
         * Create the applet.
         *---------------------------------------------------------------*/

        if (!AEEApplet_New(sizeof(eglBrew),
                          ClsId,
                          pIShell,
                          po,
                          (IApplet**)ppObj,
                          (AEEHANDLER)eglBrew_HandleEvent,
                          (PFNFREEAPPDATA)eglBrew_FreeAppData))
            return EFAILED;


        /*-----------------------------------------------------------------
         * Initialize applet data, this is called before sending
         * EVT_APP_START to the HandleEvent function
         *---------------------------------------------------------------*/

        if (!eglBrew_InitAppData((eglBrew*)*ppObj))
        {

            /*-------------------------------------------------------------
             * Release the applet. This will free the memory allocated for
             * the applet when AEEApplet_New was called.
             *-----------------------------------------------------------*/

            IAPPLET_Release((IApplet*)*ppObj);
            return EFAILED;
        }

        return AEE_SUCCESS;
    }

    return EFAILED;
}


/*-------------------------------------------------------------------*//*!
 * \brief   Initialize application data.
 * \param   pMe Application pointer.
 * \return  Returns TRUE upon success, FALSE otherwise.
 *//*-------------------------------------------------------------------*/

boolean eglBrew_InitAppData (eglBrew* pMe)
{
    pMe->DeviceInfo.wStructSize = sizeof(pMe->DeviceInfo);
    ISHELL_GetDeviceInfo(pMe->a.m_pIShell,&pMe->DeviceInfo);

    pMe->pIDisplay = pMe->a.m_pIDisplay;
    pMe->pIShell   = pMe->a.m_pIShell;

    return TRUE;
}


/*-------------------------------------------------------------------*//*!
 * \brief   Deinitialize the application.
 * \param   pMe Application pointer.
 *//*-------------------------------------------------------------------*/

void eglBrew_FreeAppData (eglBrew* pMe)
{
}

/*-------------------------------------------------------------------*//*!
 * \brief   Event handler.
 * \param   pMe     Application pointer.
 * \param   eCode   Event code.
 * \param   wParam  First parameter.
 * \param   dwParam Second parameter.
 * \return  Returns TRUE if the application processes the event.
 *//*-------------------------------------------------------------------*/

static boolean eglBrew_HandleEvent (eglBrew* pMe, AEEEvent eCode, uint16 wParam, uint32 dwParam)
{
    switch (eCode)
    {
        case EVT_APP_START:
            {

                /*---------------------------------------------------------
                 * EGL INITIALIZATION.
                 *-------------------------------------------------------*/

                static const EGLint s_configAttribs[] =
                {
                    EGL_RED_SIZE,       5,
                    EGL_GREEN_SIZE,     6,
                    EGL_BLUE_SIZE,      5,
                    EGL_ALPHA_SIZE,     EGL_DONT_CARE,
                    EGL_DEPTH_SIZE,     EGL_DONT_CARE,
                    EGL_STENCIL_SIZE,   EGL_DONT_CARE,
                    EGL_SURFACE_TYPE,   EGL_PIXMAP_BIT,
                    EGL_NONE
                };

                EGLint major, minor;
                EGLint numConfigs;
                IBitmap* bitmap;
                IDIB*       dib;

                ISHELL_CreateInstance(pMe->pIShell, AEECLSID_HYBRID_GLES, (void**)&pMe->m_gl);

                ISHELL_CreateInstance(pMe->pIShell, AEECLSID_HYBRID_EGL, (void**)&pMe->m_egl);

                IGL_Init    (pMe->m_gl);
                IEGL_Init   (pMe->m_egl);

                IDISPLAY_GetDeviceBitmap(pMe->pIDisplay, &bitmap);
                IBITMAP_QueryInterface  (bitmap, AEECLSID_DIB, (void**)&dib);

                IBITMAP_Release(bitmap);

                pMe->m_eglDisplay = eglGetDisplay(pMe->pIDisplay);

                eglInitialize(pMe->m_eglDisplay, &major, &minor);
                eglGetConfigs(pMe->m_eglDisplay, NULL, 0, &numConfigs);
                eglChooseConfig(pMe->m_eglDisplay, s_configAttribs, &pMe->m_eglConfig, 1, &numConfigs);
                pMe->m_eglContext = eglCreateContext(pMe->m_eglDisplay, pMe->m_eglConfig, NULL, NULL);
                pMe->m_eglSurface = eglCreateWindowSurface(pMe->m_eglDisplay, pMe->m_eglConfig, dib, NULL);

                IDIB_Release(dib);

                eglMakeCurrent(pMe->m_eglDisplay, pMe->m_eglSurface, pMe->m_eglSurface, pMe->m_eglContext);

                ISHELL_SetTimer(pMe->pIShell, 1, (PFNNOTIFY)drawScene, pMe);

            }
            return TRUE;

        case EVT_APP_STOP:
            ISHELL_CancelTimer(pMe->pIShell, (PFNNOTIFY)drawScene, NULL);


            /*-------------------------------------------------------------
             * EGL UNINITIALIZATION.
             *-----------------------------------------------------------*/

            eglMakeCurrent(pMe->m_eglDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
            eglDestroyContext(pMe->m_eglDisplay, pMe->m_eglContext);
            eglDestroySurface(pMe->m_eglDisplay, pMe->m_eglSurface);
            eglTerminate(pMe->m_eglDisplay);

            IGL_Release(pMe->m_gl);
            IEGL_Release(pMe->m_egl);
            return TRUE;

        case EVT_APP_SUSPEND:
            return TRUE;

        case EVT_APP_NO_SLEEP:
            return TRUE;

        case EVT_APP_RESUME:
            return TRUE;

        case EVT_APP_MESSAGE:
            return TRUE;

        case EVT_KEY:
            return TRUE;
   }

   return FALSE;
}

/*-----------------------------------------------------------------------*/
