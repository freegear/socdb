/*------------------------------------------------------------------------
 *
 * OpenGL ES 1.1 example
 * ----------------------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/gerbera/3.0/samples/cube/src/cube.c#1 $
 * $Date: 2006/03/06 $
 * $Author: sampo $
 *
 *//**
 * \file
 * \brief	Platform independent code for EGL and OpenGL ES
 *//*-------------------------------------------------------------------*/

#include "EGL/egl.h"
#include "GLES/gl.h"

#include "akAppKit.h"
#include "akUtils.h"

#include <stdlib.h>
#include <math.h>

#define COLOR_SPACE EGL_COLORSPACE_sRGB
#define ALPHA_FORMAT EGL_ALPHA_FORMAT_NONPRE
#define SURFACE_TYPE EGL_WINDOW_BIT | EGL_PBUFFER_BIT
#define WINDOW_WIDTH	400
#define WINDOW_HEIGHT	400

/*-------------------------------------------------------------------*//*!
 * \brief	Application's data.
 *//*-------------------------------------------------------------------*/

typedef struct AppData_s
{
	/* Data for EGL */
	EGLDisplay	eglDisplay;
	EGLConfig	eglConfig;
	EGLContext	eglContextOpenGLES;
	EGLSurface	eglWindowSurface;

} AppData;

/*-------------------------------------------------------------------------
 * OpenGL ES code
 *-----------------------------------------------------------------------*/

/* Vertices */
static const GLbyte s_cubeVertices[] =
{

	/* FRONT */
	-10, -10,  10,
	 10, -10,  10,
	-10,  10,  10,
	 10,  10,  10,

	 /* BACK */
	-10, -10, -10,
	-10,  10, -10,
	 10, -10, -10,
	 10,  10, -10,

	 /* LEFT */
	-10, -10,  10,
	-10,  10,  10,
	-10, -10, -10,
	-10,  10, -10,
	
	/* RIGHT */
	 10, -10, -10,
	 10,  10, -10,
	 10, -10,  10,
	 10,  10,  10,
	
	 /* TOP */
	-10,  10,  10,
	 10,  10,  10,
	-10,  10, -10,
	 10,  10, -10,
	
	 /* BOTTOM */
	-10, -10,  10,
	-10, -10, -10,
	 10, -10,  10,
	 10, -10, -10,

};

/* Normals */
static const GLbyte s_cubeNormals[] =
{
	0, 0, 127,
	0, 0, 127,
	0, 0, 127,
	0, 0, 127,

	0, 0, -128,
	0, 0, -128,
	0, 0, -128,
	0, 0, -128,

	-128, 0, 0,
	-128, 0, 0,
	-128, 0, 0,
	-128, 0, 0,

	127, 0, 0,
	127, 0, 0,
	127, 0, 0,
	127, 0, 0,

	0, 127, 0,
	0, 127, 0,
	0, 127, 0,
	0, 127, 0,

	0, -128, 0,
	0, -128, 0,
	0, -128, 0,
	0, -128, 0,

};

/* Texture coordinates */
static const GLbyte s_cubeTexCoords[] =
{

	/* FRONT */
	0, 1,
	1, 1,
	0, 0,
	1, 0,

	/* BACK */
	1, 1,
	1, 0,
	0, 1,
	0, 0,

	/* LEFT */
	1, 1,
	1, 0,
	0, 1,
	0, 0,
	
	/* RIGHT */
	1, 1,
	1, 0,
	0, 1,
	0, 0,
	
	/* TOP */
	0, 1,
	1, 1,
	0, 0,
	1, 0,
	
	/* BOTTOM */
	0, 0,
	0, 1,
	1, 0,
	1, 1,

};

/*-------------------------------------------------------------------*//*!
 * \brief	Sets the perspective matrix to OpenGL ES.
 * \param	fovy	Vertical field-of-view.
 * \param	aspect	Aspect ratio.
 * \param	zNear	Distance to near plane.
 * \param	zFar	Distance to far plane.
 *//*-------------------------------------------------------------------*/
static void setGLESperspective(GLfloat fovy, GLfloat aspect, GLfloat zNear, GLfloat zFar)
{
	GLfloat xmin, xmax, ymin, ymax;

	ymax = zNear * (GLfloat)tan(fovy * 3.1415962f / 360.0);
	ymin = -ymax;
	xmin = ymin * aspect;
	xmax = ymax * aspect;

	glFrustumf(xmin, xmax, ymin, ymax, zNear, zFar);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Updates the OpenGL ES state
 * \param	width	Rendering width.
 * \param	height	Rendering height.
 *//*-------------------------------------------------------------------*/
static void updateOpenGLESState(int width, int height)
{
	/* Define lights and materials for the OpenGL ES scene */
	static const GLfloat light_position[]	= { -50.f, 50.f, 50.f, 0.0f };
	static const GLfloat light_ambient[]	= { 0.125f, 0.125f, 0.125f, 1.0f };
	static const GLfloat light_diffuse[]	= { 0.7f, 0.7f, 0.7f, 1.0f };
	static const GLfloat material_spec[]	= { 0.7f, 0.7f, 0.7f, 0.0f };
	static const GLfloat zero_vec4[]		= { 0.0f, 0.0f, 0.0f, 0.0f };

	/* Define the aspect ratio for the perpective calculations so that 
	   no distortion happens when the screen is resized */
	float aspect		= height ? (float)width/(float)height : 1.0f;

	glViewport			(0, 0, width, height);
	glScissor			(0, 0, width, height);

	/* Set the matrix mode to world coordinates */
	glMatrixMode		(GL_MODELVIEW);
	glLoadIdentity		();

	/* Setup lights and materials with the values given above */
	glLightfv			(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv			(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv			(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv			(GL_LIGHT0, GL_SPECULAR, zero_vec4);
	glMaterialfv		(GL_FRONT_AND_BACK, GL_SPECULAR, material_spec);

	/* Enable ligting, materials, backface culling and textures */
	glDisable			(GL_NORMALIZE);
	glEnable			(GL_LIGHTING);
	glEnable			(GL_LIGHT0);
	glEnable			(GL_COLOR_MATERIAL);
	glEnable			(GL_CULL_FACE);
	glEnable			(GL_TEXTURE_2D);

	/* Tell OpenGL to use nicest perspective correction */
	glHint				(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	/* Use flat shading and disable dithering */
	glShadeModel		(GL_FLAT);
	glDisable			(GL_DITHER);

	/* Setup the clear color and the current color for the OpenGL context */
	glClearColor		(0.1f, 0.2f, 0.4f, 1.f);
	glColor4x			(0x10000, 0x00000, 0x00000, 0x10000);

	/* Enable the use of vertex, normal and texture coordinate arrays */
	glEnableClientState	(GL_VERTEX_ARRAY);
	glEnableClientState	(GL_NORMAL_ARRAY);
	glEnableClientState	(GL_TEXTURE_COORD_ARRAY);

	/* Update the projection matrix */
	glMatrixMode		(GL_PROJECTION);
	glLoadIdentity		();
	setGLESperspective	(60.f, aspect, 0.1f, 100.f);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Render the OpenGL ES scene.
 * \param	width	Rendering width in pixels
 * \param	height	Rendering height in pixels
 * \note	Renders the OpenGL ES scene
 *//*-------------------------------------------------------------------*/
static void renderGLESScene(int width, int height, AppData* context, unsigned int time)
{

	/* Time needed for the rotation */
	const double effectTime	= fmod(time / 1000.0, 360.0);

	updateOpenGLESState		(width, height);
	glClear 				(GL_COLOR_BUFFER_BIT);

	/* Rotate the world matrix and translate it on the z-axis */
	glMatrixMode			(GL_MODELVIEW);
	glLoadIdentity			();
	glTranslatef			(0.f, 0.f, -30.f);
	glRotatef				((float)(effectTime*29.77f), 1.0f, 2.0f, 0.0f);
	glRotatef				((float)(effectTime*22.311f), -0.1f, 0.0f, -5.0f);

	/* Set the pointer to the arrays containing the cube vertices, normals 
	   and texture coordinates */
	glVertexPointer			(3, GL_BYTE, 0, s_cubeVertices);
	glNormalPointer			(GL_BYTE, 0, s_cubeNormals);
	glTexCoordPointer		(2, GL_BYTE, 0, s_cubeTexCoords);

	/* Draw the cube one face at a time in the same order thay have been defined 
	   in the s_cubeVertices array */
	glDrawArrays			(GL_TRIANGLE_STRIP, 0, 4);
	glDrawArrays			(GL_TRIANGLE_STRIP, 4, 4);
	glDrawArrays			(GL_TRIANGLE_STRIP, 8, 4);
	glDrawArrays			(GL_TRIANGLE_STRIP, 12, 4);
	glDrawArrays			(GL_TRIANGLE_STRIP, 16, 4);
	glDrawArrays			(GL_TRIANGLE_STRIP, 20, 4);

}

/*-------------------------------------------------------------------------
 * EGL code
 *-----------------------------------------------------------------------*/
/*-------------------------------------------------------------------*//*!
 * \brief	Static function used to select the "better" config
 * \param	oldC,newC		Configs to compare
 * \param	dpy		Egldisplay for which to check the configs for
 * \return	The better config - in an egl failure or equal situation, oldC is returned.
 *----------------------------------------------------------------------*/
static EGLConfig pickConfig(EGLConfig oldC, EGLConfig newC, EGLDisplay dpy)
{

	/* Check for better colorbuffer type */
	EGLint oldBufType;
	EGLint newBufType;

	if (!eglGetConfigAttrib(dpy, newC, EGL_COLOR_BUFFER_TYPE, &newBufType))
		return oldC;

	if (!eglGetConfigAttrib(dpy, oldC, EGL_COLOR_BUFFER_TYPE, &oldBufType))
		return newC;

	if (oldBufType == EGL_RGB_BUFFER && newBufType != oldBufType)
		return oldC;

	else if (newBufType == EGL_RGB_BUFFER && newBufType != oldBufType)
		return newC;


	/* Check for less colorBits (including alpha) */
	{
		EGLint oldColorBits = 0;
		EGLint newColorBits = 0;
		EGLint temp			= 0;
		EGLint newRGB		= 0;
		EGLint oldRGB		= 0;
		
		if (!eglGetConfigAttrib(dpy, newC, EGL_RED_SIZE, &temp))
			return oldC;
		
		newColorBits += temp;
		
		if (!eglGetConfigAttrib(dpy, newC, EGL_GREEN_SIZE, &temp))
			return oldC;
		
		newColorBits += temp;
		
		if (!eglGetConfigAttrib(dpy, newC, EGL_BLUE_SIZE, &temp))
			return oldC;
		
		newColorBits += temp;
		
		if (!eglGetConfigAttrib(dpy, newC, EGL_LUMINANCE_SIZE, &temp))
			return oldC;
		
		newColorBits += temp;
		newRGB = newColorBits;

		if (!eglGetConfigAttrib(dpy, newC, EGL_ALPHA_SIZE, &temp))
			return oldC;
		newColorBits += temp;

		if (!eglGetConfigAttrib(dpy, oldC, EGL_RED_SIZE, &temp))
			return newC;

		oldColorBits += temp;

		if (!eglGetConfigAttrib(dpy, oldC, EGL_GREEN_SIZE, &temp))
			return newC;
		
		oldColorBits += temp;
		
		if (!eglGetConfigAttrib(dpy, oldC, EGL_BLUE_SIZE, &temp))
			return newC;
		
		oldColorBits += temp;
		
		if (!eglGetConfigAttrib(dpy, oldC, EGL_LUMINANCE_SIZE, &temp))
			return newC;
		
		oldColorBits += temp;
		oldRGB = oldColorBits;
		
		if (!eglGetConfigAttrib(dpy, oldC, EGL_ALPHA_SIZE, &temp))
			return newC;
		
		oldColorBits += temp;
		
		/* First check total rgbal-bits then just rgb - favor infimum */
		if (newColorBits < oldColorBits || newRGB < oldRGB)
			return newC;
	}

	/* Rest of the eglChooseConfig sorting is ok, returning the old config */
	return oldC;
}

/*-------------------------------------------------------------------*//*!
 * \brief	Static function used to choose eglconfig
 * \param	configAttribs	Parameters of the desired configurations
 * \param	result			pointer to an EGLConfig variable to receive 
 *							the result
 * \return	Boolean variable indicating success or failure of config 
 *			selection.
 * \note	This function can easily be converted to return a sorted
 *			list by just plugging in your favourite sorting algorithm
 *			and using exPickConfig as the comparator.
 *//*-------------------------------------------------------------------*/
static EGLBoolean chooseEGLConfig(const EGLint* configAttribs, EGLConfig* result, EGLDisplay dpy)
{
	if (!configAttribs || !result)
		return EGL_FALSE;

	{
		EGLint		numConfigs;
		EGLint		i;
		EGLConfig*	allConfigs;

		eglGetConfigs(dpy, NULL, 0, &numConfigs);

		if (eglGetError() != EGL_SUCCESS || numConfigs <= 0)
			return EGL_FALSE;

		allConfigs = (EGLConfig*)malloc(sizeof(EGLConfig)*numConfigs);

		if (!allConfigs)
			return EGL_FALSE;

		i = numConfigs;

		eglChooseConfig(dpy, configAttribs, allConfigs, i, &numConfigs);

		if (eglGetError() != EGL_SUCCESS || numConfigs <= 0)
		{
			free(allConfigs);
			return EGL_FALSE;
		}

		*result = allConfigs[0];

		for (i=1;i< numConfigs;i++)
		{
			*result = pickConfig(*result,allConfigs[i],dpy);
		}

		free(allConfigs);

	}

	return EGL_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief	EGL initialisation
 * \param	wnd	Native window pointer
*//*-------------------------------------------------------------------*/
static void initEGL(NativeWindowType wnd, AppData* context)
{
	EGLint		majorVersion;
	EGLint		minorVersion;

	/* Set the attributes for the window surface */
	static const EGLint s_surfaceAttribs[] =
	{
		EGL_COLORSPACE,		COLOR_SPACE,
		EGL_ALPHA_FORMAT,	ALPHA_FORMAT,
		EGL_NONE
	};

	/* Set the attributes for EGLConfig. */
	static const EGLint s_configAttribs[] =
	{
		EGL_RED_SIZE,				8,
		EGL_GREEN_SIZE, 			8,
		EGL_BLUE_SIZE,				8,
		EGL_ALPHA_SIZE, 			8,
		EGL_LUMINANCE_SIZE,			EGL_DONT_CARE,

		EGL_SURFACE_TYPE,			SURFACE_TYPE,
		EGL_RENDERABLE_TYPE,		EGL_OPENGL_ES_BIT,
		EGL_BIND_TO_TEXTURE_RGBA,	EGL_TRUE,
		EGL_NONE
	};

	context->eglDisplay			= eglGetDisplay(EGL_DEFAULT_DISPLAY);
							
	eglInitialize				(context->eglDisplay, &majorVersion, &minorVersion);
	chooseEGLConfig				(s_configAttribs, &context->eglConfig, context->eglDisplay);
	
	/* Create a window surface for OpenGL ES */
	context->eglWindowSurface	= eglCreateWindowSurface(context->eglDisplay, context->eglConfig, wnd, s_surfaceAttribs);
	
	/* Create a context for OpenGL ES */
	eglBindAPI					(EGL_OPENGL_ES_API);
	context->eglContextOpenGLES	= eglCreateContext(context->eglDisplay, context->eglConfig, NULL, NULL);
	
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF HGbool init(AKAppKit* ak, AppData* appData)
{

	AKSurfaceDesc		desc;
	NativeWindowType	window;
	AppData*			context;

	HG_ASSERT(ak && appData);
	
	desc	= AKAppKit_getSurface(ak);
	window	= (NativeWindowType)desc.nativePtr;
	context	= appData;

	initEGL(window, context);
	eglMakeCurrent	(context->eglDisplay, 
					 context->eglWindowSurface, 
					 context->eglWindowSurface, 
					 context->eglContextOpenGLES);

	return HG_TRUE;

}

/*-------------------------------------------------------------------*//*!
 * \brief	This is called on program shutdown.
 *//*-------------------------------------------------------------------*/

HG_STATICF void deinit(AKAppKit* ak)
{
	HG_ASSERT(ak);
	{
		AppData* context	= (AppData*)AKAppKit_getUserPtr(ak);

		/* Destroy all EGL resources */
		eglMakeCurrent		(context->eglDisplay, NULL, NULL, NULL);
		eglDestroyContext	(context->eglDisplay, context->eglContextOpenGLES);
		eglDestroySurface	(context->eglDisplay, context->eglWindowSurface);
		eglTerminate		(context->eglDisplay);

		free				(context);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	This function is called once in the program startup and
 *			and whenever surface's size has been altered.
 *//*-------------------------------------------------------------------*/

HG_STATICF void surfaceChanged (AKAppKit* ak, AKSurfaceDesc desc)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(desc);

	/* Do something with desc.width and desc.height? */
}

/*-------------------------------------------------------------------*//*!
 * \brief	All key events (keyboard, mouse buttons and mouse wheel)
 *			are passed to this function.
 *
 * \input	data is in DOM3 format.
 *//*-------------------------------------------------------------------*/

HG_STATICF void keyEvent (AKAppKit* ak, HGbool down, const char* data)
{

	/* Exit on esc, phone exit key or red phone key */
	if (down &&
		(akCompareStrings(data, "U+001B") ||
		 akCompareStrings(data, "RightSoftKey") ||
		 akCompareStrings(data, "U+0018")))
		AKAppKit_requestExit(ak);

}

/*-------------------------------------------------------------------*//*!
 * \brief	This handles the keyboard character events.
 *
 * \input	c is the typed character in Unicode format.
 *//*-------------------------------------------------------------------*/

HG_STATICF void charEvent (AKAppKit* ak, HGuint32 c)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(c);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Pointer movement callback.
 *
 * \input	known is true if pointer is inside the client area. When it
 *			is false the pointer has left the area.
 *
 * \input	x and y are the pointer coordinates on the window client
 *			area in pixels. 0, 0 represent the top-left corner of the area.
 *//*-------------------------------------------------------------------*/

HG_STATICF void ptrEvent (AKAppKit* ak, HGbool known, HGint32 x, HGint32 y)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(known);
	HG_UNREF(x);
	HG_UNREF(y);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Main update callback.
 *			This is where any drawing should be done.
 *
 * \input	timeDelta is the time difference between current frame and the
 *			last frame in milliseconds.
 *
 * \note	If you need to know how much time has passed after program
 *			startup, use AKAppKit_getTime().
 *//*-------------------------------------------------------------------*/

HG_STATICF void update (AKAppKit* ak, HGint32 timeDelta)
{
	HG_ASSERT(ak);
	HG_UNREF(timeDelta);
	{

		/* Has to be done with an intermediate variable to avoid a compiler bug */
		unsigned int time		= (unsigned int)AKAppKit_getTime(ak);
		AppData* context		= (AppData*)AKAppKit_getUserPtr(ak);
		renderGLESScene			(AKAppKit_getSurface(ak).width, AKAppKit_getSurface(ak).height, context, time);
		eglSwapBuffers			(context->eglDisplay, context->eglWindowSurface);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	This will be called first in the AppKit startup.
 *
 *			There are few things you should do here:
 *
 *				Crucial
 *					- create window
 *
 *				Recommended
 *					- assign callbacks you need to AppKit parameters
 *					- associate application data with AppKit
 *
 *			You may also want to initialize your own stuff here.
 *//*-------------------------------------------------------------------*/

HGbool appInit (AKAppKit* ak)
{
	AppData*		appData;
	AKAppKitParams	params;

	HG_ASSERT(ak);

	/* Init your stuff. */

	appData = (AppData*)malloc(sizeof(AppData));
	if (!appData)
		return HG_FALSE;	/* This will cause AppKit to exit immediately. */

	/* Fill params structure with callbacks and data pointer,
	then pass it to AppKit. */

	AKAppKitParams_clear(&params);

	params.deinit			= deinit;
	params.surfaceChanged	= surfaceChanged;
	params.keyEvent			= keyEvent;
	params.charEvent		= charEvent;
	params.ptrEvent			= ptrEvent;
	params.update			= update;

	params.userPtr			= appData;

	AKAppKit_initParams(ak, &params);

	/* Create window. */
	AKAppKit_createWindow(ak, 
						  WINDOW_WIDTH, 
						  WINDOW_HEIGHT, 
						  "Hybrid Graphics OpenGL ES sample", 
						  AK_COLORFORMAT_NONE);

	return init(ak, appData);
}

/*----------------------------------------------------------------------*/
