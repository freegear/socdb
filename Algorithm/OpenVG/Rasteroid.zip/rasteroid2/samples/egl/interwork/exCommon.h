#ifndef __COMMON_H
#define __COMMON_H

/*------------------------------------------------------------------------
 *
 * OpenGL ES / OpenVG interworking example
 * ----------------------------------------
 *
 * (C) 2002-2005 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/egl/1.1/samples/interwork_sample/src/exCommon.h#3 $
 * $Date: 2006/03/09 $
 * $Author: teppo $ *
 *
 *//**
 * \file
 * \brief	Platform independent code
 *//*-------------------------------------------------------------------*/

#ifndef __egl_h
#	include "EGL/egl.h"
#endif

#ifndef _OPENVG_H
#	include "vg/openvg.h"
#endif

typedef struct
{
	/* Data for EGL */
	EGLDisplay	eglDisplay;
	EGLConfig	eglConfig;
	EGLContext	eglContextOpenGLES;
	EGLContext	eglContextTexture;
	EGLContext	eglContextRenderer;
	EGLSurface	eglWindowSurface;
	EGLSurface	eglPBufferSurface;

	/* Data for the animated OpenVG texture */
	VGPath		circle;
	VGImage		text;
	VGfloat		angles[7];
	VGfloat		radius;
	VGfloat		startTime;


	/* Data for the HUD */
	VGubyte*	patternData;
	int			imageHeight;
	int			imageWidth;
	VGImage		pattern;
	VGfloat		meterDiameter;
	VGfloat		meterX;
	VGfloat		meterY;
	VGfloat		handAngle;
	int			prevFrameTime;
	VGPaint		fillPaint;
	VGPaint		strokePaint;
	VGPath		dial;
	VGPath		extras;

} EXCommonCtx;

#if defined(__cplusplus)
extern "C" {
#endif

EXCommonCtx*	EXCommon_create();
void			EXCommon_init(EXCommonCtx* context, int width, int height, NativeWindowType window);
void			EXCommon_render(EXCommonCtx* context, int width, int height, unsigned int time);
void			EXCommon_destroy(EXCommonCtx* context);

#if defined(__cplusplus)
}
#endif

#endif /* __COMMON_H */
