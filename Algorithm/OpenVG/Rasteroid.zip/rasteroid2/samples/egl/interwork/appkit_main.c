/*------------------------------------------------------------------------
 *
 * AppKit main
 * ------------
 *
 * (C) 2005-YYYY Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/egl/1.1/samples/interwork_sample/src/appkit/appkit_main.c#2 $
 * $Date: 2006/03/09 $
 * $Author: teppo $
 *
 *//**
 * \file
 * \brief	Platform independent
 *//*-------------------------------------------------------------------*/

#include "EGL/egl.h"
#include "vg/openvg.h"
#include "vg/vgu.h"

#include "akAppKit.h"
#include "akUtils.h"

#include "exCommon.h"

#include <stdlib.h>

#define WINDOW_WIDTH 208
#define WINDOW_HEIGHT 176

/*-------------------------------------------------------------------*//*!
 * \brief	Application's data.
 *//*-------------------------------------------------------------------*/

typedef struct AppData_s
{

	EXCommonCtx*		sampleCtx;

} AppData;

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF HGbool init(AKAppKit* ak, AppData* appData)
{

	AKSurfaceDesc desc;

	HG_ASSERT(ak && appData);
	
	desc = AKAppKit_getSurface(ak);

	appData->sampleCtx	= EXCommon_create();
	EXCommon_init		(appData->sampleCtx,
						 AKAppKit_getSurface(ak).width, 
						 AKAppKit_getSurface(ak).height,
						 (NativeWindowType)desc.nativePtr);

	return HG_TRUE;

}

/*-------------------------------------------------------------------*//*!
 * \brief	This is called on program shutdown.
 *//*-------------------------------------------------------------------*/

HG_STATICF void deinit(AKAppKit* ak)
{
	HG_ASSERT(ak);
	{
		AppData* appData	= (AppData*)AKAppKit_getUserPtr(ak);
		EXCommon_destroy	(appData->sampleCtx);
		free				(appData);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	This function is called once in the program startup and
 *			and whenever surface's size has been altered.
 *//*-------------------------------------------------------------------*/

HG_STATICF void surfaceChanged (AKAppKit* ak, AKSurfaceDesc desc)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(desc);

	/* Do something with desc.width and desc.height? */
}

/*-------------------------------------------------------------------*//*!
 * \brief	All key events (keyboard, mouse buttons and mouse wheel)
 *			are passed to this function.
 *
 * \input	data is in DOM3 format.
 *//*-------------------------------------------------------------------*/

HG_STATICF void keyEvent (AKAppKit* ak, HGbool down, const char* data)
{
	/* Exit on esc, phone exit key or red phone key */
	if (down &&
		(akCompareStrings(data, "U+001B") ||
		 akCompareStrings(data, "RightSoftKey") ||
		 akCompareStrings(data, "U+0018")))
		AKAppKit_requestExit(ak);

}

/*-------------------------------------------------------------------*//*!
 * \brief	This handles the keyboard character events.
 *
 * \input	c is the typed character in Unicode format.
 *//*-------------------------------------------------------------------*/

HG_STATICF void charEvent (AKAppKit* ak, HGuint32 c)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(c);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Pointer movement callback.
 *
 * \input	known is true if pointer is inside the client area. When it
 *			is false the pointer has left the area.
 *
 * \input	x and y are the pointer coordinates on the window client
 *			area in pixels. 0, 0 represent the top-left corner of the area.
 *//*-------------------------------------------------------------------*/

HG_STATICF void ptrEvent (AKAppKit* ak, HGbool known, HGint32 x, HGint32 y)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(known);
	HG_UNREF(x);
	HG_UNREF(y);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Main update callback.
 *			This is where any drawing should be done.
 *
 * \input	timeDelta is the time difference between current frame and the
 *			last frame in milliseconds.
 *
 * \note	If you need to know how much time has passed after program
 *			startup, use AKAppKit_getTime().
 *//*-------------------------------------------------------------------*/

HG_STATICF void update (AKAppKit* ak, HGint32 timeDelta)
{
	HG_ASSERT(ak);
	HG_UNREF(timeDelta);
	{

		/* Has to be done with an intermediate variable to avoid a compiler bug */
		int time				= (int)AKAppKit_getTime(ak);

		AppData* appData		= (AppData*)AKAppKit_getUserPtr(ak);
		EXCommon_render			(appData->sampleCtx, 
								 AKAppKit_getSurface(ak).width, 
								 AKAppKit_getSurface(ak).height, 
								 time);

	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	This will be called first in the AppKit startup.
 *
 *			There are few things you should do here:
 *
 *				Crucial
 *					- create window
 *
 *				Recommended
 *					- assign callbacks you need to AppKit parameters
 *					- associate application data with AppKit
 *
 *			You may also want to initialize your own stuff here.
 *//*-------------------------------------------------------------------*/

HGbool appInit (AKAppKit* ak)
{
	AppData*		appData;
	AKAppKitParams	params;

	HG_ASSERT(ak);

	/* Init your stuff. */

	appData = (AppData*)malloc(sizeof(AppData));
	if (!appData)
		return HG_FALSE;	/* This will cause AppKit to exit immediately. */

	/* Fill params structure with callbacks and data pointer,
	then pass it to AppKit. */

	AKAppKitParams_clear(&params);

	params.deinit			= deinit;
	params.surfaceChanged	= surfaceChanged;
	params.keyEvent			= keyEvent;
	params.charEvent		= charEvent;
	params.ptrEvent			= ptrEvent;
	params.update			= update;

	params.userPtr			= appData;

	AKAppKit_initParams(ak, &params);

	/* Create window. */
	AKAppKit_createWindow(ak, 
						  WINDOW_HEIGHT, 
						  WINDOW_WIDTH, 
						  "Hybrid Graphics OpenVG/OpenGL ES intework sample", 
						  AK_COLORFORMAT_NONE);

	return init(ak, appData);
}

/*----------------------------------------------------------------------*/
