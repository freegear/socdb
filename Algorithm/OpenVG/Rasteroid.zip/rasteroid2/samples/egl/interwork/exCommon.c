/*------------------------------------------------------------------------
 *
 * OpenGL ES / OpenVG interworking example
 * ----------------------------------------
 *
 * (C) 2002-2005 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/egl/1.1/samples/interwork_sample/src/exCommon.c#3 $
 * $Date: 2006/03/09 $
 * $Author: teppo $ *
 *
 *//**
 * \file
 * \brief	Platform independent code
 *//*-------------------------------------------------------------------*/

#include "EGL/egl.h"
#include "vg/openvg.h"
#include "vg/vgu.h"
#include "GLES/gl.h"
#include "exCommon.h"
#include "textImage.h"
#include <stdlib.h>
#include <math.h>
#include <stdio.h>

#define TEXTURE_ID		1

#define COLOR_SPACE EGL_COLORSPACE_sRGB
#define ALPHA_FORMAT EGL_ALPHA_FORMAT_NONPRE
#define SURFACE_TYPE EGL_WINDOW_BIT | EGL_PBUFFER_BIT

#define PBUFFER_WIDTH	256
#define PBUFFER_HEIGHT	256
#define MAX_ANGLE		1.5f*3.141f
#define UPDATE_TIME		2000;

#define TEXT_FADE_OUT_TIME	300.0f
#define TEXT_FADE_IN_TIME	500.0f
#define LOGO_FADE_OUT_TIME	300.0f
#define LOGO_FADE_IN_TIME	1000.0f

/*-------------------------------------------------------------------------
 * OpenGL ES code
 *-----------------------------------------------------------------------*/

/* Vertices */
static const GLbyte s_cubeVertices[] =
{

	/* FRONT */
	-10, -10,  10,
	 10, -10,  10,
	-10,  10,  10,
	 10,  10,  10,

	 /* BACK */
	-10, -10, -10,
	-10,  10, -10,
	 10, -10, -10,
	 10,  10, -10,

	 /* LEFT */
	-10, -10,  10,
	-10,  10,  10,
	-10, -10, -10,
	-10,  10, -10,
	
	/* RIGHT */
	 10, -10, -10,
	 10,  10, -10,
	 10, -10,  10,
	 10,  10,  10,
	
	 /* TOP */
	-10,  10,  10,
	 10,  10,  10,
	-10,  10, -10,
	 10,  10, -10,
	
	 /* BOTTOM */
	-10, -10,  10,
	-10, -10, -10,
	 10, -10,  10,
	 10, -10, -10,

};

/* Normals */
static const GLbyte s_cubeNormals[] =
{
	0, 0, 127,
	0, 0, 127,
	0, 0, 127,
	0, 0, 127,

	0, 0, -128,
	0, 0, -128,
	0, 0, -128,
	0, 0, -128,

	-128, 0, 0,
	-128, 0, 0,
	-128, 0, 0,
	-128, 0, 0,

	127, 0, 0,
	127, 0, 0,
	127, 0, 0,
	127, 0, 0,

	0, 127, 0,
	0, 127, 0,
	0, 127, 0,
	0, 127, 0,

	0, -128, 0,
	0, -128, 0,
	0, -128, 0,
	0, -128, 0,

};

/* Texture coordinates */
static const GLbyte s_cubeTexCoords[] =
{

	/* FRONT */
	0, 1,
	1, 1,
	0, 0,
	1, 0,

	/* BACK */
	1, 1,
	1, 0,
	0, 1,
	0, 0,

	/* LEFT */
	1, 1,
	1, 0,
	0, 1,
	0, 0,
	
	/* RIGHT */
	1, 1,
	1, 0,
	0, 1,
	0, 0,
	
	/* TOP */
	0, 1,
	1, 1,
	0, 0,
	1, 0,
	
	/* BOTTOM */
	0, 0,
	0, 1,
	1, 0,
	1, 1,

};

/*-------------------------------------------------------------------*//*!
 * \brief	Sets the perspective matrix to OpenGL ES.
 * \param	fovy	Vertical field-of-view.
 * \param	aspect	Aspect ratio.
 * \param	zNear	Distance to near plane.
 * \param	zFar	Distance to far plane.
 *//*-------------------------------------------------------------------*/
static void setGLESperspective(GLfloat fovy, GLfloat aspect, GLfloat zNear, GLfloat zFar)
{
	GLfloat xmin, xmax, ymin, ymax;

	ymax = zNear * (GLfloat)tan(fovy * 3.1415962f / 360.0);
	ymin = -ymax;
	xmin = ymin * aspect;
	xmax = ymax * aspect;

	glFrustumf(xmin, xmax, ymin, ymax, zNear, zFar);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Updates the OpenGL ES state
 * \param	width	Rendering width.
 * \param	height	Rendering height.
 *//*-------------------------------------------------------------------*/
static void updateOpenGLESState(int width, int height)
{
	/* Define lights and materials for the OpenGL ES scene */
	static const GLfloat light_position[]	= { -50.f, 50.f, 50.f, 0.0f };
	static const GLfloat light_ambient[]	= { 0.125f, 0.125f, 0.125f, 1.0f };
	static const GLfloat light_diffuse[]	= { 0.7f, 0.7f, 0.7f, 1.0f };
	static const GLfloat material_spec[]	= { 0.7f, 0.7f, 0.7f, 0.0f };
	static const GLfloat zero_vec4[]		= { 0.0f, 0.0f, 0.0f, 0.0f };

	/* Define the aspect ratio for the perpective calculations so that 
	   no distortion happens when the screen is resized */
	float aspect		= height ? (float)width/(float)height : 1.0f;

	glViewport			(0, 0, width, height);
	glScissor			(0, 0, width, height);

	/* Set the matrix mode to world coordinates */
	glMatrixMode		(GL_MODELVIEW);
	glLoadIdentity		();

	/* Setup lights and materials with the values given above */
	glLightfv			(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv			(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv			(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv			(GL_LIGHT0, GL_SPECULAR, zero_vec4);
	glMaterialfv		(GL_FRONT_AND_BACK, GL_SPECULAR, material_spec);

	/* Enable ligting, materials, backface culling and textures */
	glDisable			(GL_NORMALIZE);
	glEnable			(GL_LIGHTING);
	glEnable			(GL_LIGHT0);
	glEnable			(GL_COLOR_MATERIAL);
	glEnable			(GL_CULL_FACE);
	glEnable			(GL_TEXTURE_2D);

	/* Tell OpenGL to use nicest perspective correction */
	glHint				(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	/* Use flat shading and disable dithering */
	glShadeModel		(GL_FLAT);
	glDisable			(GL_DITHER);

	/* Setup the clear color and the current color for the OpenGL context */
	glClearColor		(0.1f, 0.2f, 0.4f, 1.f);
	glColor4x			(0x10000, 0x10000, 0x10000, 0x10000);

	/* Enable the use of vertex, normal and texture coordinate arrays */
	glEnableClientState	(GL_VERTEX_ARRAY);
	glEnableClientState	(GL_NORMAL_ARRAY);
	glEnableClientState	(GL_TEXTURE_COORD_ARRAY);

	/* Update the projection matrix */
	glMatrixMode		(GL_PROJECTION);
	glLoadIdentity		();
	setGLESperspective	(60.f, aspect, 0.1f, 100.f);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Render the OpenGL ES scene.
 * \param	width	Rendering width in pixels
 * \param	height	Rendering height in pixels
 * \note	Renders the OpenGL ES scene with a texture generated with
 *			OpenVG.
 *//*-------------------------------------------------------------------*/
static void renderGLESScene(int width, int height, EXCommonCtx* context, unsigned int time)
{

	/* Time needed for the rotation */
	const double effectTime	= fmod(time / 1000.0, 360.0);

	/* Texture environment color */
	GLfixed texColor[4]		= {(GLfixed) 1.f, (GLfixed) 1.f,
							   (GLfixed) 1.f, (GLfixed) 1.f};

	updateOpenGLESState		(width, height);
	glClear 				(GL_COLOR_BUFFER_BIT);

	/* Rotate the world matrix and translate it on the z-axis */
	glMatrixMode			(GL_MODELVIEW);
	glLoadIdentity			();
	glTranslatef			(0.f, 0.f, -30.f);
	glRotatef				((float)(effectTime*29.77f), 1.0f, 2.0f, 0.0f);
	glRotatef				((float)(effectTime*22.311f), -0.1f, 0.0f, -5.0f);

	/* Set the pointer to the arrays containing the cube vertices, normals 
	   and texture coordinates */
	glVertexPointer			(3, GL_BYTE, 0, s_cubeVertices);
	glNormalPointer			(GL_BYTE, 0, s_cubeNormals);
	glTexCoordPointer		(2, GL_BYTE, 0, s_cubeTexCoords);

	/* Bind the texture to a predefined ID and bind the texture to the pBuffer */
	glBindTexture			(GL_TEXTURE_2D, TEXTURE_ID);
	eglBindTexImage			(context->eglDisplay, context->eglPBufferSurface, EGL_BACK_BUFFER);

	/* Set the texture parameters */
	glTexParameterx			(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameterx			(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameterx			(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S,	  GL_REPEAT);
	glTexParameterx			(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T,	  GL_REPEAT);

	/* Set the texture environment */
	glTexEnvx				(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,	GL_MODULATE);
	glTexEnvxv				(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR,	texColor);

	/* Reset the texture matrix */
	glMatrixMode			(GL_TEXTURE);
	glLoadIdentity			();

	/* Draw the cube one face at a time in the same order thay have been defined 
	   in the s_cubeVertices array */
	glDrawArrays			(GL_TRIANGLE_STRIP, 0, 4);
	glDrawArrays			(GL_TRIANGLE_STRIP, 4, 4);
	glDrawArrays			(GL_TRIANGLE_STRIP, 8, 4);
	glDrawArrays			(GL_TRIANGLE_STRIP, 12, 4);
	glDrawArrays			(GL_TRIANGLE_STRIP, 16, 4);
	glDrawArrays			(GL_TRIANGLE_STRIP, 20, 4);

	/* Release the pbuffer so that it can be drawn to on the next iteration */
	eglReleaseTexImage		(context->eglDisplay, context->eglPBufferSurface, EGL_BACK_BUFFER);

}

/*-------------------------------------------------------------------------
 * OpenVG code
 *-----------------------------------------------------------------------*/
/*-------------------------------------------------------------------------
 * OpenVG texture generation code
 *-----------------------------------------------------------------------*/
/*-------------------------------------------------------------------*//*!
 * \brief	Initialise the OpenVG texture
 * \param	context	The common context to store data in
 *//*-------------------------------------------------------------------*/
static void initOVGTexture(EXCommonCtx* context)
{

	/* Create a circle for the logo */
	context->circle		= vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, (unsigned int)VG_PATH_CAPABILITY_APPEND_TO);
	vguEllipse			(context->circle, 0.0f, 0.0f, 0.28f, 0.28f);
	
	vgSeti				(VG_IMAGE_QUALITY, VG_IMAGE_QUALITY_BETTER);
	context->text		= vgCreateImage(VG_sRGBA_8888, 283, 123, VG_IMAGE_QUALITY_BETTER);
	vgImageSubData		(context->text, imgData, 1132, VG_sRGBA_8888, 0, 0, 283, 123);
	
	{
		int i;
		for (i = 0; i < 7; i++)
		{
			context->angles[i] = 2 * 3.14159f * (float)(rand() & RAND_MAX);
		}
	}

	context->radius		= 1.0f;
	context->startTime	= -1.f;

}

/*-------------------------------------------------------------------*//*!
 * \brief	Render the OpenVG texture to the pBuffer
 * \param	context	The common context contains the data for the 
 *					OpenVG texture
 * \param	width	pBuffer width
 * \param	height	pBuffer height
 * \param	time	time since the start of the application
 * \note	The texture for OpenGL ES is generated here with OpenVG.
 *			OpenVG uses a pBuffer surface on which it render the tecture
 *			image and EGL makes the pBuffer available for OpenGL ES
 *			to use as a texture.
 *//*-------------------------------------------------------------------*/
static void renderOVGTexture(EXCommonCtx* context, int width, int height, unsigned int time)
{

	VGPaint fillPaint;
	VGPaint	strokePaint;
	VGfloat strokeColor[4]	= {0.f, 0.36f, 0.60f, 1.f};
	VGfloat fillColor[4]	= {0.89f, 0.95f, 0.99f, 1.f};
	VGfloat clearColor[4]	= {1.0f, 1.0f, 1.0f, 1.0f};

	/* Time variables control the animation */
	VGfloat	effectTime		= 0.f;
	VGfloat	elapsedTime;

	/* Initialise the paints */
	fillPaint				= vgCreatePaint();
	strokePaint				= vgCreatePaint();
	vgSetParameteri			(fillPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
	vgSetParameterfv		(fillPaint, VG_PAINT_COLOR, 4, fillColor);
	vgSetParameteri			(strokePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
	vgSetParameterfv		(strokePaint, VG_PAINT_COLOR, 4, strokeColor);
	vgSetf					(VG_STROKE_LINE_WIDTH, 0.02f);
	vgSetPaint				(fillPaint, VG_FILL_PATH);
	vgSetPaint				(strokePaint, VG_STROKE_PATH);

	/* Set fill rules and blend mode to OVG context */ 
	vgSeti					(VG_FILL_RULE, VG_NON_ZERO);
	vgSeti					(VG_BLEND_MODE, VG_BLEND_SRC_OVER);

	/* Start time is initialised to -1.0f to mark the start of the application */
	if (context->startTime < 0.f)
		context->startTime = (float)time;
	
	/* Elapsed time changes from 0 to x and back */
	elapsedTime				= time - context->startTime;
	elapsedTime				= 3000.f * (float)sin(3.141*(fmod(elapsedTime,15000)/15000));
	effectTime				= elapsedTime - 2000.f;

	/* The radius of the animated path of the circles */
	context->radius			= 1.f - (elapsedTime / 2700.f); 

	/* Fade the circles in and out when the elapsedTime is close to 0 */
	if (elapsedTime < LOGO_FADE_IN_TIME && elapsedTime >= LOGO_FADE_OUT_TIME)
	{
		/* The closer elapsedTime is to zero the smaller the circle color alpha is */
		fillColor[3]		= 1.f * (elapsedTime-LOGO_FADE_OUT_TIME)/(LOGO_FADE_IN_TIME-LOGO_FADE_OUT_TIME);
		vgSetParameterfv	(fillPaint, VG_PAINT_COLOR, 4, fillColor);
		strokeColor[3]		= 1.f * (elapsedTime-LOGO_FADE_OUT_TIME)/(LOGO_FADE_IN_TIME-LOGO_FADE_OUT_TIME);
		vgSetParameterfv	(strokePaint, VG_PAINT_COLOR, 4, strokeColor);

	}
	else if (elapsedTime < LOGO_FADE_OUT_TIME)
	{
		/* Set the circle color alpha to zero if elapsedTime really close to 0 */ 
		fillColor[3]		= 0.f;
		vgSetParameterfv	(fillPaint, VG_PAINT_COLOR, 4, fillColor);
		strokeColor[3]		= 0.f;
		vgSetParameterfv	(strokePaint, VG_PAINT_COLOR, 4, strokeColor);
	}

	/* Animated path radius can't be nagative */
	if (context->radius < 0.f)
		context->radius = 0.0f;

	{
		float rotInc = 2 * 3.14159f * (elapsedTime / 1500.0f);
		int i;
		for (i = 0; i < 7; i++)
		{
			context->angles[i] += rotInc;
		}
	}

	/* Translate the circles to correct positions */
	vgLoadIdentity();
	vgTranslate((float)(width/2), (float)(height/2));
	vgScale((float)(width/2), (float)(width/2));

	/* Clear the screen */
	vgSetfv(VG_CLEAR_COLOR, 4, clearColor);
	vgClear(0, 0, width, height);

	/* Draw the circles with different parameters to get a random looking pattern */
	/* Draw the first 4 circles on the screen */
	vgTranslate(-0.29f, 0.79f);
	{
		int i;
		for (i = 0; i < 4; i++)
		{
			vgRotate(context->angles[i]);
			vgTranslate(context->radius, 0.f);
			vgDrawPath(context->circle, VG_FILL_PATH | VG_STROKE_PATH);
			vgTranslate(-context->radius, 0.f);
			vgRotate(-context->angles[i]);
			vgTranslate(0.f, -0.31f);
		}
	}

	/* Draw the next 2 circles */
	vgTranslate(0.56f, 0.31f);
	{
		int i;
		for (i = 0; i < 2; i++)
		{
			vgRotate(context->angles[i+4]);
			vgTranslate(context->radius, 0.f);
			vgDrawPath(context->circle, VG_FILL_PATH | VG_STROKE_PATH);
			vgTranslate(-context->radius, 0.f);
			vgRotate(-context->angles[i+4]);
			vgTranslate(0.f, 0.31f);
		}
	}

	/* And the final circle */
	vgTranslate(-0.28f, -0.145f);
	vgRotate(context->angles[6]);
	vgTranslate(context->radius, 0.f);
	vgDrawPath(context->circle, VG_FILL_PATH | VG_STROKE_PATH);
	
	/* Draw the "hybrid graphics" text image when the time is right */
	if (elapsedTime > 2000.f + TEXT_FADE_OUT_TIME)
	{
		VGfloat blendCol[4] = {1.f, 1.f, 1.f, 1.f};
		
		blendCol[3] = (elapsedTime - 2000.f - TEXT_FADE_OUT_TIME) / TEXT_FADE_IN_TIME;
		
		vgSeti(VG_MATRIX_MODE, VG_MATRIX_IMAGE_USER_TO_SURFACE);
		vgSeti(VG_IMAGE_MODE, VG_DRAW_IMAGE_MULTIPLY);
		vgSetParameterfv(fillPaint, VG_PAINT_COLOR, 4, blendCol);

		vgLoadIdentity();
		{
			
			VGfloat imgScale = (float)width / 400.f;		
			vgTranslate(((float)(width/2) - (vgGetParameterf(context->text, VG_IMAGE_WIDTH)/2.f)*imgScale), imgScale*5.f);
			vgScale(imgScale, imgScale);
			
			vgDrawImage(context->text);
		}

		vgSeti(VG_MATRIX_MODE, VG_MATRIX_PATH_USER_TO_SURFACE);
	}

	/* Destroy allocated resources */
	/* A waste of resources to allocate and deallocate every time the screen is rendered */
	vgDestroyPaint(fillPaint);
	vgDestroyPaint(strokePaint);

}

/*-------------------------------------------------------------------------
 * OpenVG HUD generation code
 *-----------------------------------------------------------------------*/
 /*-------------------------------------------------------------------*//*!
 * \brief	Initialises the data needed to render the HUD
 * \note	
 *//*-------------------------------------------------------------------*/
 static void initOVGHUD(EXCommonCtx* context, int width, int height)
 {
	context->imageWidth		= 100;
	context->imageHeight	= 100;
	context->patternData	= malloc(sizeof(VGubyte)*4*context->imageWidth*context->imageWidth);
	context->pattern		= vgCreateImage(VG_sRGBA_8888, 
											context->imageWidth, 
											context->imageHeight, 
											VG_IMAGE_QUALITY_BETTER);

	context->fillPaint		= vgCreatePaint();
	context->strokePaint	= vgCreatePaint();
	vgSetParameteri			(context->fillPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
	vgSetParameteri			(context->strokePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);

	context->dial			= vgCreatePath(VG_PATH_FORMAT_STANDARD, 
										   VG_PATH_DATATYPE_F, 
										   1.0f, 
										   1.0f, 
										   0, 
										   0, 
										   VG_PATH_CAPABILITY_ALL);

	context->extras			= vgCreatePath(VG_PATH_FORMAT_STANDARD, 
										   VG_PATH_DATATYPE_F, 
										   1.0f, 
										   1.0f, 
										   0, 
										   0, 
										   VG_PATH_CAPABILITY_ALL);

	context->meterDiameter	= ((VGfloat)height)/5.f;
	context->meterX			= (VGfloat)width-context->meterDiameter+20.f;
	context->meterY			= (VGfloat)height-context->meterDiameter+20.f;
	context->handAngle		= 0.f;

 }

/*-------------------------------------------------------------------*//*!
 * \brief	Render the OpenVG heads-up-display.
 * \note	Renders the HUD on top of the OpenGL ES scene
 *//*-------------------------------------------------------------------*/
static void renderOVGHUD(EXCommonCtx* context, int width, int height, unsigned int time)
{

	/* Define the colors used in the HUD */
	VGfloat yellow[4]		= {1.f, 1.f, 0.f, 0.5f};
	VGfloat	black[4]		= {0.f, 0.f, 0.f, 1.f};
	VGfloat red[4]			= {1.0f, 0.f, 0.f, 1.f};

	/* Local variables used to calculate the fps meter */
	VGfloat	zeroAngle;
	VGfloat targetAngle;
	VGfloat deltaTime;

	/* Update the meter parameters */ 
	context->meterDiameter	= ((VGfloat)height)/5.f;
	context->meterX			= (context->meterDiameter/2.f) + 10.f;
	context->meterY			= (context->meterDiameter/2.f) + 10.f;
	zeroAngle				= 1.25f * 3.141f;
	deltaTime				= (VGfloat)(time - context->prevFrameTime);

	/* The hand is rotated towards the targetAngle to get smooth movement */
	targetAngle				= MAX_ANGLE/(0.2f*deltaTime);
	context->handAngle		+= 0.1f*(targetAngle - context->handAngle);

	/* Clamp the hands movement */
	if (context->handAngle > MAX_ANGLE)
		context->handAngle = MAX_ANGLE;

	vgSeti					(VG_BLEND_MODE, VG_BLEND_SRC_OVER);

	/* Claer both paths before darwing to them */
	vgClearPath				(context->dial, VG_PATH_CAPABILITY_ALL);
	vgClearPath				(context->extras, VG_PATH_CAPABILITY_ALL);

	/* Set paints for the dial background */
	vgSetParameterfv		(context->fillPaint, VG_PAINT_COLOR, 4, yellow);
	vgSetPaint				(context->fillPaint, VG_FILL_PATH);
	vgSetParameterfv		(context->strokePaint, VG_PAINT_COLOR, 4, black);
	vgSetPaint				(context->strokePaint, VG_STROKE_PATH);

	/* Create path data with vgu */
	vguEllipse				(context->dial, context->meterX, context->meterY, context->meterDiameter, context->meterDiameter);
	vguLine					(context->dial, 
							 context->meterX, 
							 context->meterY,
							 context->meterX+(context->meterDiameter/2)*(VGfloat)cos(-1 * context->handAngle+zeroAngle),
							 context->meterY+(context->meterDiameter/2)*(VGfloat)sin(-1 * context->handAngle+zeroAngle));
	vguLine					(context->extras, 
							 context->meterX, 
							 context->meterY,
							 context->meterX+(context->meterDiameter/2)*(VGfloat)cos(zeroAngle),
							 context->meterY+(context->meterDiameter/2)*(VGfloat)sin(zeroAngle));
	vgDrawPath				(context->dial, VG_STROKE_PATH|VG_FILL_PATH);

	/* Set paints for the second path and draw it (this is the marker for the zero point) */
	vgSetParameterfv		(context->fillPaint, VG_PAINT_COLOR, 4, red);
	vgSetPaint				(context->fillPaint, VG_FILL_PATH);
	vgSetParameterfv		(context->strokePaint, VG_PAINT_COLOR, 4, red);
	vgSetPaint				(context->strokePaint, VG_STROKE_PATH);
	vgDrawPath				(context->extras, VG_STROKE_PATH|VG_FILL_PATH);
	
	context->prevFrameTime	= time;

}


/*-------------------------------------------------------------------------
 * EGL code
 *-----------------------------------------------------------------------*/
/*-------------------------------------------------------------------*//*!
 * \brief	Static function used to select the "better" config
 * \param	oldC,newC		Configs to compare
 * \param	dpy		Egldisplay for which to check the configs for
 * \return	The better config - in an egl failure or equal situation, oldC is returned.
 *----------------------------------------------------------------------*/
static EGLConfig pickConfig(EGLConfig oldC, EGLConfig newC, EGLDisplay dpy)
{

	/* Check for better colorbuffer type */
	EGLint oldBufType;
	EGLint newBufType;

	if (!eglGetConfigAttrib(dpy, newC, EGL_COLOR_BUFFER_TYPE, &newBufType))
		return oldC;

	if (!eglGetConfigAttrib(dpy, oldC, EGL_COLOR_BUFFER_TYPE, &oldBufType))
		return newC;

	if (oldBufType == EGL_RGB_BUFFER && newBufType != oldBufType)
		return oldC;

	else if (newBufType == EGL_RGB_BUFFER && newBufType != oldBufType)
		return newC;


	/* Check for less colorBits (including alpha) */
	{
		EGLint oldColorBits = 0;
		EGLint newColorBits = 0;
		EGLint temp			= 0;
		EGLint newRGB		= 0;
		EGLint oldRGB		= 0;
		
		if (!eglGetConfigAttrib(dpy, newC, EGL_RED_SIZE, &temp))
			return oldC;
		
		newColorBits += temp;
		
		if (!eglGetConfigAttrib(dpy, newC, EGL_GREEN_SIZE, &temp))
			return oldC;
		
		newColorBits += temp;
		
		if (!eglGetConfigAttrib(dpy, newC, EGL_BLUE_SIZE, &temp))
			return oldC;
		
		newColorBits += temp;
		
		if (!eglGetConfigAttrib(dpy, newC, EGL_LUMINANCE_SIZE, &temp))
			return oldC;
		
		newColorBits += temp;
		newRGB = newColorBits;

		if (!eglGetConfigAttrib(dpy, newC, EGL_ALPHA_SIZE, &temp))
			return oldC;
		newColorBits += temp;

		if (!eglGetConfigAttrib(dpy, oldC, EGL_RED_SIZE, &temp))
			return newC;

		oldColorBits += temp;

		if (!eglGetConfigAttrib(dpy, oldC, EGL_GREEN_SIZE, &temp))
			return newC;
		
		oldColorBits += temp;
		
		if (!eglGetConfigAttrib(dpy, oldC, EGL_BLUE_SIZE, &temp))
			return newC;
		
		oldColorBits += temp;
		
		if (!eglGetConfigAttrib(dpy, oldC, EGL_LUMINANCE_SIZE, &temp))
			return newC;
		
		oldColorBits += temp;
		oldRGB = oldColorBits;
		
		if (!eglGetConfigAttrib(dpy, oldC, EGL_ALPHA_SIZE, &temp))
			return newC;
		
		oldColorBits += temp;
		
		/* First check total rgbal-bits then just rgb - favor infimum */
		if (newColorBits < oldColorBits || newRGB < oldRGB)
			return newC;
	}

	/* Rest of the eglChooseConfig sorting is ok, returning the old config */
	return oldC;
}

/*-------------------------------------------------------------------*//*!
 * \brief	Static function used to choose eglconfig
 * \param	configAttribs	Parameters of the desired configurations
 * \param	result			pointer to an EGLConfig variable to receive 
 *							the result
 * \return	Boolean variable indicating success or failure of config 
 *			selection.
 * \note	This function can easily be converted to return a sorted
 *			list by just plugging in your favourite sorting algorithm
 *			and using exPickConfig as the comparator.
 *//*-------------------------------------------------------------------*/
static EGLBoolean chooseEGLConfig(const EGLint* configAttribs, EGLConfig* result, EGLDisplay dpy)
{
	if (!configAttribs || !result)
		return EGL_FALSE;

	{
		EGLint		numConfigs;
		EGLint		i;
		EGLConfig*	allConfigs;

		eglGetConfigs(dpy, NULL, 0, &numConfigs);

		if (eglGetError() != EGL_SUCCESS || numConfigs <= 0)
			return EGL_FALSE;

		allConfigs = (EGLConfig*)malloc(sizeof(EGLConfig)*numConfigs);

		if (!allConfigs)
			return EGL_FALSE;

		i = numConfigs;

		eglChooseConfig(dpy, configAttribs, allConfigs, i, &numConfigs);

		if (eglGetError() != EGL_SUCCESS || numConfigs <= 0)
		{
			free(allConfigs);
			return EGL_FALSE;
		}

		*result = allConfigs[0];

		for (i=1;i< numConfigs;i++)
		{
			*result = pickConfig(*result,allConfigs[i],dpy);
		}

		free(allConfigs);

	}

	return EGL_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief	EGL initialisation
 * \param	wnd	Native window pointer
 * \note	Initialises three EGL contexts
 *			1) OpenGL ES	- rendering 3D graphics
 *			2) OpenVG 		- rendering 2D graphics on top of the scene
 *			3) OpenVG		- rendering 2D texture for OpenGL ES to use
 * \note	Initialises two EGL surfaces
 *			1) window		- OpenGL ES and OpenVG render on the same window surface
 *			2) pBuffer		- OpenVG renders the texture on a pBuffer surface							
*//*-------------------------------------------------------------------*/
static void initEGL(NativeWindowType wnd, EXCommonCtx* context)
{
	EGLint		majorVersion;
	EGLint		minorVersion;

	/* Set the attributes for the window surface used by 
	   both OpenGL ES and OpenVG for rendering on screen. */
	static const EGLint s_surfaceAttribs[] =
	{
		EGL_COLORSPACE,		COLOR_SPACE,
		EGL_ALPHA_FORMAT,	ALPHA_FORMAT,
		EGL_NONE
	};

	/* Set the attributes for EGLConfig. Both the EGL_OPENVG_BIT and
	   EGL_OPENGL_ES_BIT must be on for EGL to be able to render to the same
	   surface. */
	static const EGLint s_configAttribs[] =
	{
		EGL_RED_SIZE,				8,
		EGL_GREEN_SIZE, 			8,
		EGL_BLUE_SIZE,				8,
		EGL_ALPHA_SIZE, 			8,
		EGL_LUMINANCE_SIZE,			EGL_DONT_CARE,

		EGL_SURFACE_TYPE,			SURFACE_TYPE,
		EGL_RENDERABLE_TYPE,		EGL_OPENVG_BIT & EGL_OPENGL_ES_BIT,
		EGL_BIND_TO_TEXTURE_RGBA,	EGL_TRUE,
		EGL_NONE
	};

	/* Set the pbuffer attributes. OpenVG renders a texture to the 
	   pbuffer for OpenGL ES to use. */
	static const EGLint s_pbufferAttribs[] =
	{
		EGL_WIDTH,			PBUFFER_WIDTH,
		EGL_HEIGHT,			PBUFFER_HEIGHT,
		EGL_COLORSPACE,		COLOR_SPACE,
		EGL_ALPHA_FORMAT,	ALPHA_FORMAT,
		EGL_TEXTURE_FORMAT, EGL_TEXTURE_RGBA,
		EGL_TEXTURE_TARGET,	EGL_TEXTURE_2D,
		EGL_NONE
	};

	/* Initialise EGL with three contexts, one pbuffer, one window surface, 
	   one display and one context. */
	context->eglDisplay			= eglGetDisplay(EGL_DEFAULT_DISPLAY);
							
	eglInitialize				(context->eglDisplay, &majorVersion, &minorVersion);
	chooseEGLConfig				(s_configAttribs, &context->eglConfig, context->eglDisplay);
	
	/* Create a window surface for OpenGL ES and OpenVG to render to and a pBuffer surface 
	   for OpenVG to generate texture to. */
	context->eglWindowSurface	= eglCreateWindowSurface(context->eglDisplay, context->eglConfig, wnd, s_surfaceAttribs);
	context->eglPBufferSurface	= eglCreatePbufferSurface(context->eglDisplay, context->eglConfig, s_pbufferAttribs);
	
	/* Create a context for OpenVG (HUD) */
	eglBindAPI					(EGL_OPENVG_API);
	context->eglContextRenderer	= eglCreateContext(context->eglDisplay, context->eglConfig, NULL, NULL);

	/* Create a context for OpenGL ES */
	eglBindAPI					(EGL_OPENGL_ES_API);
	context->eglContextOpenGLES	= eglCreateContext(context->eglDisplay, context->eglConfig, NULL, NULL);
	
	/* Create a context for OpenVG (texture) */
	eglBindAPI					(EGL_OPENVG_API);
	context->eglContextTexture	= eglCreateContext(context->eglDisplay, context->eglConfig, NULL, NULL);
	
}

/*-------------------------------------------------------------------------
 * Public interface
 *-----------------------------------------------------------------------*/
/*-------------------------------------------------------------------*//*!
 * \brief	Allocates memory for the common context
 * \return	Pointer to the common context	
 *//*-------------------------------------------------------------------*/
EXCommonCtx* EXCommon_create()
{

	EXCommonCtx* context	= malloc(sizeof(EXCommonCtx));
	return context;

}

/*-------------------------------------------------------------------*//*!
 * \brief	Initialises the sample
 * \param	context	The common context containing EGL contexts etc.	
 * \param	width	Window size
 * \param	height	Window size
 *//*-------------------------------------------------------------------*/
void EXCommon_init(EXCommonCtx* context, int width, int height, NativeWindowType window)
{

	initEGL(window, context);
	eglMakeCurrent	(context->eglDisplay, 
					 NULL, 
					 NULL, 
					 NULL);
	eglMakeCurrent	(context->eglDisplay, 
					 context->eglPBufferSurface, 
					 context->eglPBufferSurface, 
					 context->eglContextTexture);
	initOVGTexture(context);
	eglMakeCurrent	(context->eglDisplay, 
					 NULL, 
					 NULL, 
					 NULL);
	eglMakeCurrent	(context->eglDisplay, 
					 context->eglWindowSurface, 
					 context->eglWindowSurface, 
					 context->eglContextRenderer);
	initOVGHUD(context, width, height);

}

/*-------------------------------------------------------------------*//*!
 * \brief	Renders the scene
 * \param	context	The common context containing EGL contexts etc.	
 * \param	width	Window size
 * \param	height	Window size
 * \param	time	Time since the start of the application
 *//*-------------------------------------------------------------------*/
void EXCommon_render(EXCommonCtx* context, int width, int height, unsigned int time)
{
	/* Render OpenVG texture */
	eglMakeCurrent	(context->eglDisplay, 
					 NULL, 
					 NULL, 
					 NULL);
	eglMakeCurrent	(context->eglDisplay, 
					 context->eglPBufferSurface, 
					 context->eglPBufferSurface, 
					 context->eglContextTexture);
	renderOVGTexture(context, PBUFFER_WIDTH, PBUFFER_HEIGHT, time);

	/* Render spinning cube with VG texture */
	eglMakeCurrent	(context->eglDisplay, 
					 NULL, 
					 NULL, 
					 NULL);
	eglMakeCurrent	(context->eglDisplay, 
					 context->eglWindowSurface, 
					 context->eglWindowSurface, 
					 context->eglContextOpenGLES);
	renderGLESScene	(width, height, context, time);

	/* Render "HUD" */
	eglMakeCurrent	(context->eglDisplay, 
					 NULL, 
					 NULL, 
					 NULL);
	eglMakeCurrent	(context->eglDisplay, 
					 context->eglWindowSurface, 
					 context->eglWindowSurface, 
					 context->eglContextRenderer);
	renderOVGHUD	(context, width, height, time);

	eglSwapBuffers	(context->eglDisplay, 
					 context->eglWindowSurface);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Deinitialisation
 * \param	context	The common context containing EGL contexts etc.	
 *//*-------------------------------------------------------------------*/
void EXCommon_destroy(EXCommonCtx* context)
{

	/* Destroy all EGL resources */
	eglMakeCurrent		(context->eglDisplay, NULL, NULL, NULL);
	eglDestroyContext	(context->eglDisplay, context->eglContextOpenGLES);
	eglDestroyContext	(context->eglDisplay, context->eglContextTexture);
	eglDestroyContext	(context->eglDisplay, context->eglContextRenderer);
	eglDestroySurface	(context->eglDisplay, context->eglWindowSurface);
	eglTerminate		(context->eglDisplay);
	eglReleaseThread	();

	free(context->patternData);
	free(context);

}
