/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akWinCEMain.c#2 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include "akMain.h"
#include "akAppKitPrivate.h"
#include "akUtils.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <stdio.h>
#include <stdlib.h>

#if (HG_COMPILER == HG_COMPILER_MSC)
#	include <crtdbg.h>
#endif

/*-------------------------------------------------------------------------
 * AppKit WinCE context.
 *-----------------------------------------------------------------------*/

typedef struct AKWinCEContext_s
{
	AKAppKit*				ak;
	HWND					window;
	
	LARGE_INTEGER			perfCtrFreq;
	LARGE_INTEGER			perfCtrStart;
	
	HGint32					dragCount;
	HGint32					wheelAcc;
} AKWinCEContext;

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF const char* translateKey (DWORD code)
{
	switch (code)
	{
	case VK_MENU:		return "Alt";			// Menu
	case VK_APPS:		return "Apps";			// Application
	case VK_ATTN:		return "Attn";
	case VK_CAPITAL:	return "CapsLock";		// Capital
	case VK_CLEAR:
	case VK_OEM_CLEAR:	return "Clear";
	case VK_CONTROL:	return "Control";		// Ctrl
	case VK_CRSEL:		return "Crsel";
	case VK_CONVERT:	return "Convert";
	case VK_DOWN:		return "Down";			// Arrow
	case VK_END:		return "End";
	case VK_RETURN:		return "Enter";			// Return
	case VK_EREOF:		return "EraseEof";
	case VK_EXECUTE:	return "Execute";
	case VK_EXSEL:		return "Exsel";
	case VK_F1:			return "F1";
	case VK_F2:			return "F2";
	case VK_F3:			return "F3";
	case VK_F4:			return "F4";
	case VK_F5:			return "F5";
	case VK_F6:			return "F6";
	case VK_F7:			return "F7";
	case VK_F8:			return "F8";
	case VK_F9:			return "F9";
	case VK_F10:		return "F10";
	case VK_F11:		return "F11";
	case VK_F12:		return "F12";
	case VK_F13:		return "F13";
	case VK_F14:		return "F14";
	case VK_F15:		return "F15";
	case VK_F16:		return "F16";
	case VK_F17:		return "F17";
	case VK_F18:		return "F18";
	case VK_F19:		return "F19";
	case VK_F20:		return "F20";
	case VK_F21:		return "F21";
	case VK_F22:		return "F22";
	case VK_F23:		return "F23";
	case VK_F24:		return "F24";
	case VK_FINAL:		return "FinalMode";		// (Asian)
	case VK_HELP:		return "Help";
	case VK_HOME:		return "Home";
	case VK_INSERT:		return "Insert";		// Ins
	case VK_JUNJA:		return "JunjaMode";
	case VK_KANA:		return "KanaMode";		// Kana lock
	case VK_KANJI:		return "KanjiMode";		// (Japanese)
	case VK_LEFT:		return "Left";			// Arrow
	case VK_NUMLOCK:	return "NumLock";
	case VK_NEXT:		return "PageDown";		// Next
	case VK_PRIOR:		return "PageUp";		// Prior
	case VK_PAUSE:		return "Pause";
	case VK_PLAY:		return "Play";
	case VK_PRINT:
	case VK_SNAPSHOT:	return "PrintScreen";	// SnapShot
	case VK_PROCESSKEY:	return "Process";
	case VK_RIGHT:		return "Right";			// Arrow
	case VK_SCROLL:		return "Scroll";		// Scroll lock
	case VK_SELECT:		return "Select";
	case VK_SHIFT:		return "Shift";
	case VK_UP:			return "Up";			// Arrow
	case VK_LWIN:
	case VK_RWIN:		return "Win";			// Windows logo
	case VK_ZOOM:		return "Zoom";
	case VK_BACK:		return "U+0008";		// Backspace
	case VK_TAB:		return "U+0009";		// Tab
	case VK_CANCEL:		return "U+0018";		// Cancel
	case VK_ESCAPE:		return "U+001B";		// Esc
	case VK_SPACE:		return "U+0020";		// Space
	case 0xDE:			return "U+0027";		// '
	case VK_MULTIPLY:	return "U+002A";		// *
	case VK_ADD:		return "U+002B";		// +
	case VK_SEPARATOR:
	case 0xBC:			return "U+002C";		// ,
	case VK_SUBTRACT:
	case 0xBD:			return "U+002D";		// -
	case VK_DECIMAL:
	case 0xBE:			return "U+002E";		// .
	case VK_DIVIDE:
	case 0xBF:			return "U+002F";		// /
	case '0':
	case VK_NUMPAD0:	return "U+0030";		// 0
	case '1':
	case VK_NUMPAD1:	return "U+0031";		// 1
	case '2':
	case VK_NUMPAD2:	return "U+0032";		// 2
	case '3':
	case VK_NUMPAD3:	return "U+0033";		// 3
	case '4':
	case VK_NUMPAD4:	return "U+0034";		// 4
	case '5':
	case VK_NUMPAD5:	return "U+0035";		// 5
	case '6':
	case VK_NUMPAD6:	return "U+0036";		// 6
	case '7':
	case VK_NUMPAD7:	return "U+0037";		// 7
	case '8':
	case VK_NUMPAD8:	return "U+0038";		// 8
	case '9':
	case VK_NUMPAD9:	return "U+0039";		// 9
	case 0xBA:			return "U+003B";		// ;
	case 0xBB:			return "U+003D";		// =
	case 'A':			return "U+0041";		// A
	case 'B':			return "U+0042";		// B
	case 'C':			return "U+0043";		// C
	case 'D':			return "U+0044";		// D
	case 'E':			return "U+0045";		// E
	case 'F':			return "U+0046";		// F
	case 'G':			return "U+0047";		// G
	case 'H':			return "U+0048";		// H
	case 'I':			return "U+0049";		// I
	case 'J':			return "U+004A";		// J
	case 'K':			return "U+004B";		// K
	case 'L':			return "U+004C";		// L
	case 'M':			return "U+004D";		// M
	case 'N':			return "U+004E";		// N
	case 'O':			return "U+004F";		// O
	case 'P':			return "U+0050";		// P
	case 'Q':			return "U+0051";		// Q
	case 'R':			return "U+0052";		// R
	case 'S':			return "U+0053";		// S
	case 'T':			return "U+0054";		// T
	case 'U':			return "U+0055";		// U
	case 'V':			return "U+0056";		// V
	case 'W':			return "U+0057";		// W
	case 'X':			return "U+0058";		// X
	case 'Y':			return "U+0059";		// Y
	case 'Z':			return "U+005A";		// Z
	case 0xDB:			return "U+005B";		// [
	case 0xDC:			return "U+005C";		// Backslash
	case 0xDD:			return "U+005D";		// ]
	case 0xC0:
	case 0xDF:			return "U+0060";		// Grave
	case VK_DELETE:		return "U+007F";		// Del
	default:			return NULL;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF void handleMouseButton (AKWinCEContext* ctx, HGbool down, const char* button)
{
	AK_ASSERT(ctx);

	if (down)
	{
		if (!ctx->dragCount)
			SetCapture(ctx->window);
		ctx->dragCount++;
	} else
	{
		ctx->dragCount--;
		if (!ctx->dragCount)
			ReleaseCapture();
	}

	AKAppKit_callKeyEvent(ctx->ak, down, (const char*)button);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF HGbool passPointerPosition (AKWinCEContext* ctx, LPARAM lParam)
{
	AKAppKit_callPtrEvent(ctx->ak, HG_TRUE, (short)LOWORD(lParam), (short)HIWORD(lParam));
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF LONG WINAPI windowProc (
	HWND	hWnd,
	UINT	uMsg,
	WPARAM	wParam,
	LPARAM	lParam)
{
	AKWinCEContext* ctx = (AKWinCEContext*)GetWindowLong(hWnd, GWL_USERDATA);
	if (!ctx)
		return DefWindowProc(hWnd, uMsg, wParam, lParam);

	switch (uMsg)
	{
	case WM_CLOSE:
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;

	case WM_KEYDOWN:
	case WM_KEYUP:
	case WM_SYSKEYDOWN:
	case WM_SYSKEYUP:
		{
			HGbool down = (uMsg == WM_KEYDOWN || uMsg == WM_SYSKEYDOWN);
			const char* keyId = translateKey(wParam);
			if (keyId)
			{
				AKAppKit_callKeyEvent(ctx->ak, down, keyId);
				return 0;
			}
		}
		break;

	case WM_CHAR:
	case WM_SYSCHAR:
		AKAppKit_callCharEvent(ctx->ak, wParam);
		return 0;

	case WM_MOUSEMOVE:
		if (passPointerPosition(ctx, lParam))
			return 0;
		break;

	case WM_LBUTTONDOWN:
		passPointerPosition(ctx, lParam);
		handleMouseButton(ctx, HG_TRUE,		"!PtrLeft");
		return 0;

	case WM_RBUTTONDOWN:
		passPointerPosition(ctx, lParam);
		handleMouseButton(ctx, HG_TRUE,		"!PtrRight");
		return 0;

	case WM_MBUTTONDOWN:
		passPointerPosition(ctx, lParam);
		handleMouseButton(ctx, HG_TRUE,		"!PtrMiddle");
		return 0;

	case WM_LBUTTONUP:		handleMouseButton(ctx, HG_FALSE,	"!PtrLeft");	return 0;
	case WM_RBUTTONUP:		handleMouseButton(ctx, HG_FALSE,	"!PtrRight");	return 0;
	case WM_MBUTTONUP:		handleMouseButton(ctx, HG_FALSE,	"!PtrMiddle");	return 0;

	case WM_MOUSEWHEEL:
		ctx->wheelAcc += (short)HIWORD(wParam);
		while (ctx->wheelAcc >= 120)
		{
			AKAppKit_callKeyEvent(ctx->ak, HG_TRUE, (const char*)"!WheelUp");
			AKAppKit_callKeyEvent(ctx->ak, HG_FALSE, (const char*)"!WheelUp");
			ctx->wheelAcc -= 120;
		}
		while (ctx->wheelAcc <= -120)
		{
			AKAppKit_callKeyEvent(ctx->ak, HG_TRUE, (const char*)"!WheelDown");
			AKAppKit_callKeyEvent(ctx->ak, HG_FALSE, (const char*)"!WheelDown");
			ctx->wheelAcc += 120;
		}
		return 0;

	default:
		break;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF void run (AKWinCEContext* ctx)
{
	AK_ASSERT(ctx && ctx->ak);

	if (!ctx->window) /* Window is not created or creation has failed. */
		return;

	ShowWindow(ctx->window, SW_SHOW);

	/* Message loop. */

	for(;;)		/* No warnings. */
	{
		MSG msg;
		if (PeekMessage(&msg, NULL, 0, 0, TRUE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
			if (msg.message == WM_QUIT)
				break;
		} else
			AKAppKit_callUpdate(ctx->ak);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateWindow (AKAppKit* ak, HGuint32 width, HGuint32 height, const char* title, AKColorFormat bufFormatHint)
{
	AK_ASSERT(ak);
	HG_UNREF(width);
	HG_UNREF(height);
	HG_UNREF(bufFormatHint);

	{
		AKWinCEContext* ctx = AKAppKit_getContext(ak);
		AK_ASSERT(ctx);

		/* Register window class. */
		{
			WNDCLASS wndclass;

			wndclass.style		   = 0;
			wndclass.lpfnWndProc   = windowProc;
			wndclass.cbClsExtra    = 0;
			wndclass.cbWndExtra    = 0;
			wndclass.hInstance	   = (HINSTANCE)GetModuleHandle(NULL);
			wndclass.hIcon		   = NULL;
			wndclass.hCursor	   = LoadCursor(NULL, IDC_ARROW);
			wndclass.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
			wndclass.lpszMenuName  = NULL;
			wndclass.lpszClassName = L"MainWndClass";

			RegisterClass(&wndclass);
		}

		/* Create window. */
		{
			HGuint16* title16 = akConvertString8To16(title);
			if (title16)
			{
				ctx->window = CreateWindow(
					L"MainWndClass",
					title16,
					WS_VISIBLE,
					CW_USEDEFAULT, CW_USEDEFAULT,
					GetSystemMetrics(SM_CXSCREEN),
					GetSystemMetrics(SM_CYSCREEN),
					NULL,
					NULL,
					(HINSTANCE)GetModuleHandle(NULL),
					NULL);
	
				free(title16);
			}
		}

		if (ctx->window)
		{
			/* Associate context with the window. */
			SetWindowLong(ctx->window, GWL_USERDATA, (LONG)ctx);
			return HG_TRUE;
		}
		else
			return HG_FALSE;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akAdjustWindow(AKAppKit* ak, HGuint32 width, HGuint32 height)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(width);
	HG_UNREF(height);
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akSetWindowTitle (AKAppKit* ak, const char* title)
{
	AK_ASSERT(ak);
	{
		AKWinCEContext* ctx = AKAppKit_getContext(ak);
		AK_ASSERT(ctx);

		if (ctx->window)
		{
			HGuint16* buf16 = akConvertString8To16(title);
			if (buf16)
			{
				SetWindowText(ctx->window, buf16);
				free(buf16);
			}
			return HG_TRUE;
		}
		else
			return HG_FALSE;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* akLockWindowBuffer (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	/* \todo [tero 12/Jan/06] implement */
	return NULL;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseWindowBuffer (AKAppKit* ak, AKImage* bufImage)
{
	AK_ASSERT(ak && bufImage);
	HG_UNREF(ak);
	HG_UNREF(bufImage);
	/* \todo [tero 12/Jan/06] implement */
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akErrorMessage (AKAppKit* ak, const char* msg)
{
	AKWinCEContext* ctx = (AKWinCEContext*)AKAppKit_getContext(ak);
	HGuint16* buf16 = akConvertString8To16(msg);
	AK_ASSERT(ak);
	
	if (buf16)
	{
		MessageBox((HWND)ctx->window, buf16, NULL, 0);
		free(buf16);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAbort (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	exit(1);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akRequestExit (AKAppKit* ak)
{
	AK_ASSERT(ak);
	{
		AKWinCEContext* ctx = (AKWinCEContext*)AKAppKit_getContext(ak);
		SendMessage(ctx->window, WM_CLOSE, 0, 0);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akGetTime (AKAppKit* ak, HGuint32* hiMillis, HGuint32* loMillis)
{
	AKWin32Context*	ctx		= (AKWin32Context*)AKAppKit_getContext(ak);
	LARGE_INTEGER	perfCtr;
	__int64			millis;
	AK_ASSERT(ak && ctx);

	QueryPerformanceCounter(&perfCtr);
	millis = (__int64)((perfCtr.QuadPart - ctx->perfCtrStart.QuadPart) * 1000.0 / ctx->perfCtrFreq.QuadPart);
	*hiMillis = (HGuint32)(millis >> 32);
	*loMillis = (HGuint32)millis;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKSurfaceDesc akGetSurface (AKAppKit* ak)
{
	AKSurfaceDesc desc;
	AK_ASSERT(ak);

	{
		AKWinCEContext* ctx = AKAppKit_getContext(ak);

		RECT rect;
		GetClientRect(ctx->window, &rect);

		desc.width = rect.right;
		desc.height = rect.bottom;
		desc.nativePtr = ctx->window;
	}

	return desc;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF void pushEntry (AKDirListing* dir, WIN32_FIND_DATA* fd)
{
	char* filename;
	AK_ASSERT(dir && fd);

	filename = akConvertString16To8(fd->cFileName);
	if (!filename)
		return;

	if (akCompareStrings(filename, ".") || akCompareStrings(filename, ".."))
	{
		free(filename);
		return;
	}

	{
		AKDirEntry* entry = AKDirEntry_create();
		if (!entry)
		{
			free(filename);
			return;
		}

		if (fd->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			entry->flags |= AK_DIRENTRY_FLAGS_DIR;

		akCopyString(entry->filename, filename);

		AKDirListing_pushBack(dir, entry);
	}

	free(filename);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKDirListing* akGetDirectoryListing (AKAppKit* ak, const char* path)
{
	AK_ASSERT(ak && path);
	HG_UNREF(ak);

	{
		AKDirListing* dir;
		WIN32_FIND_DATA fd;
		HANDLE h;
		char* fixedPath;
		HGuint16* fixedPath16;

		fixedPath = akFixPath(path);
		if (!fixedPath)
			return NULL;

		/* Append wildcard to fixedPath. */
		akAppendString(&fixedPath, "*");
		if (!fixedPath)
			return NULL;

		fixedPath16 = akConvertString8To16(fixedPath);
		free(fixedPath);
		if (!fixedPath16)
			return NULL;

		dir = AKDirListing_create();
		if (!dir)
		{
			free(fixedPath16);
			return NULL;
		}

		h = FindFirstFile(fixedPath16, &fd);
		free(fixedPath16);

		if (h == INVALID_HANDLE_VALUE)
		{
			AKDirListing_destroy(dir);
			return NULL;
		}

		pushEntry(dir, &fd);

		while (FindNextFile(h, &fd) != 0)
			pushEntry(dir, &fd);

		FindClose(h);

		return dir;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

static DWORD WINAPI akThreadProc (LPVOID lpParameter)
{
	AK_ASSERT(lpParameter);
	AKAppKit_threadStarted((AKThreadParams*)lpParameter);
	return 0;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateThread (AKAppKit* ak, AKThreadParams* params)
{
	HANDLE	thread;
	DWORD	threadID;
	AK_ASSERT(ak && params);
	HG_UNREF(ak);

	thread = CreateThread(NULL, 0, akThreadProc, params, 0, &threadID);
	if (!thread)
		return HG_FALSE;
	CloseHandle(thread);
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akGetThreadID (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	return (HGuint32)GetCurrentThreadId();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void* akCreateSemaphore (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	return CreateSemaphore(NULL, 1, 1, NULL);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akDestroySemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	CloseHandle((HANDLE)semaphore);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAcquireSemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	WaitForSingleObject((HANDLE)semaphore, INFINITE);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseSemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	ReleaseSemaphore((HANDLE)semaphore, 1, NULL);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

int WINAPI WinMain (
	HINSTANCE	hInstance, 
	HINSTANCE	hPrevInstance, 
	LPWSTR		lpCmdLine, 
	int			nCmdShow)
{
	AKWinCEContext	ctx;

	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_IDLE);

#if defined(HG_DEBUG) && (HG_COMPILER == HG_COMPILER_MSC)
	{
		int flag = 0;
		flag |= _CRTDBG_ALLOC_MEM_DF;			/* use allocation guards */
/*		flag |= _CRTDBG_CHECK_ALWAYS_DF;*/		/* check whole memory on each alloc */
/*		flag |= _CRTDBG_DELAY_FREE_MEM_DF;*/	/* keep freed memory and check that it isn't written */
		flag |= _CRTDBG_LEAK_CHECK_DF;			/* check memory leaks at program exit */
		_CrtSetDbgFlag(flag);
/*		_CrtSetBreakAlloc(8086);*/
		_CrtSetReportMode(_CRT_WARN, _CRTDBG_MODE_FILE);
		_CrtSetReportFile(_CRT_WARN, _CRTDBG_FILE_STDERR);
	}
#endif

	/* Create AppKit and set up context. */

	ctx.ak = AKAppKit_create(&ctx, NULL, 0);
	if (!ctx.ak)
		return 1;

	ctx.window		= NULL;
	
	QueryPerformanceFrequency(&ctx.perfCtrFreq);
	QueryPerformanceCounter(&ctx.perfCtrStart);
	
	ctx.dragCount	= 0;
	ctx.wheelAcc	= 0;

	if (appInit(ctx.ak))	/* Init application. */
		run(&ctx);			/* Run if init succeeded. */

	AKAppKit_destroy(ctx.ak);	/* Destroy AppKit (calls application's deinit). */

	if (ctx.window)
		DestroyWindow(ctx.window);

	return 0;
}

/*-----------------------------------------------------------------------*/
