#ifndef __AKDIRLISTING_H
#define __AKDIRLISTING_H
/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/include/akDirListing.h#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#if !defined(__AKDEFS_H)
#	include "akDefs.h"
#endif

/*-------------------------------------------------------------------------
 * Constants.
 *-----------------------------------------------------------------------*/

#define AK_DIRENTRY_FILENAME_LENGTH		260

#define AK_DIRENTRY_FLAGS_DIR			1

/*-------------------------------------------------------------------------
 * Forward declarations.
 *-----------------------------------------------------------------------*/

typedef struct AKDirListing_s	AKDirListing;
typedef struct AKDirEntry_s		AKDirEntry;

/*-------------------------------------------------------------------------
 * AKDirEntry class.
 *-----------------------------------------------------------------------*/

struct AKDirEntry_s
{
	char			filename[AK_DIRENTRY_FILENAME_LENGTH];
	HGuint32		flags;
	AKDirEntry*		next;
};

HG_HEADER_CT_ASSERT(AKDIRLISTING_H, sizeof(AKDirEntry) == AK_DIRENTRY_FILENAME_LENGTH
														+ 2 * 4);

HG_EXTERN_C_BLOCK_BEGIN

AKDirEntry*			AKDirEntry_create				(void);
void				AKDirEntry_destroy				(AKDirEntry* entry);

/*-------------------------------------------------------------------------
 * AKDirListing methods.
 *-----------------------------------------------------------------------*/

AKDirListing*		AKDirListing_create				(void);
void				AKDirListing_destroy			(AKDirListing* dir);

void				AKDirListing_pushBack			(AKDirListing* dir, AKDirEntry* entry);

AKDirEntry*			AKDirListing_getFirst			(AKDirListing* dir);

HGuint32			AKDirListing_getCount			(AKDirListing* dir);
AKDirEntry*			AKDirListing_getByIndex			(AKDirListing* dir, HGuint32 index);

void				AKDirListing_filterByType		(AKDirListing* dir, const char* type, HGbool keepDirectories);
void				AKDirListing_moveDirectoriesTop	(AKDirListing* dir);

HG_EXTERN_C_BLOCK_END

/*----------------------------------------------------------------------*/
#endif /* __AKDIRLISTING_H */
