/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akUtils.c#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include "akUtils.h"

#include <stdlib.h>

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

char* akCreateString (HGuint32 length)
{
	char* str = malloc(length + 1);
	if (str)
		*str = 0;
	return str;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

char* akDuplicateString (const char* str)
{
	HGuint32 len = akStringLength(str);
	char* d = akCreateString(len);
	if (d)
		akCopyString(d, str);
	return d;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akStringLength (const char* str)
{
	HGuint32 i = 0;
	AK_ASSERT(str);
	while (str[i] != 0)
		i++;
	return i;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akStringLength16 (const HGuint16* str)
{
	HGuint32 i = 0;
	AK_ASSERT(str);
	while (str[i] != 0)
		i++;
	return i;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akStringCountChars (const char* str, const char* chars)
{
	AK_ASSERT(str && chars);
	{
		HGuint32 count = 0;
		HGuint32 i = 0;
		HGuint32 c = 0;
		HGuint32 strLen = akStringLength(str);
		HGuint32 charCount = akStringLength(chars);

		for (i = 0; i < strLen; i++)
			for (c = 0; c < charCount; c++)
				if (str[i] == chars[c])
				{
					count++;
					break;
				}

		return count;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akCopyString (char* tgt, const char* src)
{
	HGuint32 i = 0;
	AK_ASSERT(tgt && src);
	while (src[i] != 0)
	{
		*tgt++ = src[i];
		i++;
	}
	*tgt = 0;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akAppendString (char** tgt, const char* src)
{
	AK_ASSERT(tgt && *tgt && src);
	{
		HGuint32 tl = akStringLength(*tgt);
		HGuint32 sl = akStringLength(src);

		if (!sl)
			return HG_TRUE; /* Nothing to do. */

		{
			char* n = akCreateString(tl + sl);
			if (!n)
				return HG_FALSE;

			akCopyString(n, *tgt);
			akCopyString(n + tl, src);

			free(*tgt);
			*tgt = n;
		}
	}
	return HG_TRUE;
} 

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

char* akCatenateStrings (const char* first, const char* second)
{
	AK_ASSERT(first && second);
	{
		HGuint32 fl = akStringLength(first);
		HGuint32 sl = akStringLength(second);
		char* r = akCreateString(fl + sl);
		if (r)
		{
			akCopyString(r, first);
			akCopyString(r + fl, second);
		}
		return r;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCompareStrings (const char* a, const char* b)
{
	AK_ASSERT(a && b);
	{
		HGuint32 i = 0;
		HGuint32 al = akStringLength(a);
		HGuint32 bl = akStringLength(b);

		if (al != bl)
			return HG_FALSE;

		for (i = 0; i < al; i++)
			if (a[i] != b[i])
				return HG_FALSE;
	}
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAdvanceString (char** str, char stopChar)
{
	AK_ASSERT(str);
	while (**str != stopChar && **str != 0)
		(*str)++;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akRemoveChars (char** str, const char* chars)
{
	AK_ASSERT(str && *str && chars);
	{
		char* t = akCreateString(akStringLength(*str));
		if (!t)
			return;

		{
			char* tp = t;
			char* s = *str;

			while (*s != 0)
			{
				HGbool add = HG_TRUE;
				char c = *s++;
				HGuint32 i = 0;

				while (chars[i] != 0)
				{
					if (c == chars[i])
					{
						add = HG_FALSE;
						break;
					}
					i++;
				}

				if (add)
					*tp++ = c;
			}
			*tp = 0;
		}
		{
			char* r = akDuplicateString(t);
			free(t);

			if (!r)
				return;

			free(*str);
			*str = r;
		}
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReplaceSingleChars (char* str, const char* from, const char* to)
{
	AK_ASSERT(str && from && to);

	while (*str != 0)
	{
		char c = *str;
		HGuint32 i = 0;
		while (from[i] != 0 && to[i] != 0)
		{
			if (c == from[i])
			{
				c = to[i];
				break;
			}
			i++;
		}
		*str++ = c;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	Only difference from the akReplaceSingleChars() func is that
 *			this one can replace from-to '\0' characters.
 *
 *			Input strings "from" and "to" must have "length" amount
 *			of bytes allocated.
 *//*-------------------------------------------------------------------*/

void akReplaceSingleCharsN (char* str, const char* from, const char* to, HGuint32 count)
{
	AK_ASSERT(str && from && to);

	while (*str != 0)
	{
		char c = *str;
		HGuint32 i = 0;
		while (i < count)
		{
			if (c == from[i])
			{
				c = to[i];
				break;
			}
			i++;
		}
		*str++ = c;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

char* akFixPath (const char* path)
{
	AK_ASSERT(path);
	{
		char* f = akDuplicateString(path);
		if (!f)
			return NULL;

		akRemoveChars(&f, "*?");			/* Remove wildcards '*' and '?' */
		if (!f)
			return NULL;

		akReplaceSingleChars(f, "\\", "/");	/* Convert slashes */

		/* Make sure that fixed path ends with '/' */
		{
			HGuint32 l = akStringLength(f);
			if (l > 0 && f[l - 1] != '/')
				akAppendString(&f, "/");
		}

		return f;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

#define PATH_MAX_DEPTH 256

char* akReconstructPath (const char* path)
{
	AK_ASSERT(path);
	{
		HGuint32 pos;
		char* sliced[PATH_MAX_DEPTH];
		char* modPath = akDuplicateString(path);
		char* modPathPos = modPath;
		char* modPathEnd = modPath + akStringLength(path) + 1;
		HGbool beginningSlashes = HG_TRUE;
		char* r = NULL;

		if (!modPath)
			return NULL;

		for (pos = 0; pos < PATH_MAX_DEPTH; pos++)
			sliced[pos] = NULL;

		pos = 0;

		akReplaceSingleCharsN(modPath, "/\\", "\0\0", 2);

		while (modPathPos < modPathEnd)
		{
			HGbool add = HG_FALSE;
			if (akCompareStrings(modPathPos, ".."))
			{
				if (!beginningSlashes)
				{
					pos--;
					free(sliced[pos]);
					sliced[pos] = NULL;
				}
				else
				{
					add = HG_TRUE;
				}
			}
			else
			{
				add = HG_TRUE;
				if (!akCompareStrings(modPathPos, "."))
					beginningSlashes = HG_FALSE;
			}

			if (add)
			{
				sliced[pos] = akDuplicateString(modPathPos);
				if (!sliced[pos])
					break;
				pos++;
			}

			akAdvanceString(&modPathPos, '\0');
			modPathPos++;
		}

		if (pos > 0)
		{
			r = akDuplicateString(sliced[0]);
			if (r && pos > 1)
			{
				HGuint32 i;
				akAppendString(&r, "/");

				for (i = 1; i < pos; i++)
					if (sliced[i] && r)
					{
						akAppendString(&r, sliced[i]);
						if (r && i < pos - 1)
							akAppendString(&r, "/");
					}
			}
		}
		else
		{
			r = akDuplicateString(".");
		}

		while (pos--)
			free(sliced[pos]);

		free(modPath);

		return r;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint16* akConvertString8To16 (const char* str)
{
	AK_ASSERT(str);
	{
		HGuint32 l = akStringLength(str);
		HGuint16* r = malloc((l + 1) * sizeof(HGuint16));
		if (r)
		{
			HGuint32 i;
			for (i = 0; i < l; i++)
				r[i] = (HGuint16)str[i];
			r[l] = 0;
		}
		return r;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

char* akConvertString16To8 (const HGuint16* str)
{
	AK_ASSERT(str);
	{
		HGuint32 l = akStringLength16(str);
		char* r = malloc(l + 1);
		if (r)
		{
			HGuint32 i;
			for (i = 0; i < l; i++)
				r[i] = (char)str[i];
			r[l] = 0;
		}
		return r;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint16 akChangeOrderUInt16 (HGuint16 v)
{
	return (HGuint16)(((v & 0xff) << 8) | (v >> 8));
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akChangeOrderUInt32 (HGuint32 v)
{
	return ((v & 0xff) << 24) | ((v & 0xff00) << 8) | ((v & 0xff0000) >> 8) | (v >> 24);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint16 akGetLittleEndianUInt16 (HGuint16 v)
{
	return (HGuint16)(hgGetEndianess() == HG_ENDIAN_BIG ? akChangeOrderUInt16(v) : v);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akGetLittleEndianUInt32 (HGuint32 v)
{
	return hgGetEndianess() == HG_ENDIAN_BIG ? akChangeOrderUInt32(v) : v;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint16 akGetBigEndianUInt16 (HGuint16 v)
{
	return (HGuint16)(hgGetEndianess() == HG_ENDIAN_LITTLE ? akChangeOrderUInt16(v) : v);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akGetBigEndianUInt32 (HGuint32 v)
{
	return hgGetEndianess() == HG_ENDIAN_LITTLE ? akChangeOrderUInt32(v) : v;
}

/*----------------------------------------------------------------------*/
