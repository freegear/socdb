/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akMacOSX/akMacOSXWindow.c#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *
 *//**
 * \file
 * \brief    ???
 * \author    lauri@hybrid.fi
 *//*-------------------------------------------------------------------*/

#include "akMacOSXMain.h"
#include "akMacOSXWindow.h"
#include "akMacOSXKeyTranslation.h"
#include "akMacOSXKeyUtils.h"

#include "akMain.h"

#include <Carbon/Carbon.h>
#include <OpenGL/gl.h>
#include <AGL/agl.h>

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

#define AK_WINDOW_TOP 100
#define AK_WINDOW_LEFT 50

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

HG_STATICF OSStatus    akMac_BuildGL                    (AKMacOSXContext* ctx);
HG_STATICF OSStatus    akMac_DisposeGL                  (AKMacOSXContext* ctx);
HG_STATICF void        akMac_DrawGL                     (AKMacOSXContext* ctx);
HG_STATICF OSStatus    akMac_ResizeGL                   (AGLContext aglContext, int width, int height);

HG_STATICF OSStatus    akMac_AglReportError             (void);
    
HG_STATICF OSStatus    akMac_InstallWindowEventHandlers (AKAppKit* ak);
            
HG_STATICF pascal      OSStatus akMac_KeyEvent          (EventHandlerCallRef nextHandler,
                                                         EventRef theEvent,
                                                         void* userData);
                  
HG_STATICF pascal      OSStatus akMac_ModEvent          (EventHandlerCallRef nextHandler,
                                                         EventRef theEvent,
                                                         void* userData);
            
HG_STATICF pascal      OSStatus akMac_WindowEvtHndlr    (EventHandlerCallRef myHandler,
                                                         EventRef event,
                                                         void* userData);
        
/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateWindow (AKAppKit* ak,
                       HGuint32 width,
                       HGuint32 height,
                       const char* title,
                       AKColorFormat bufFormatHint)
{
    OSStatus            result = 0;
    AKMacOSXContext*    context;

    AK_ASSERT(ak);
    HG_UNREF(bufFormatHint);

    context = AKAppKit_getContext(ak);

    {
        Rect contentRect;

        WindowAttributes windowAttrs = kWindowStandardDocumentAttributes
            | kWindowStandardHandlerAttribute 
            | kWindowInWindowMenuAttribute; 
    
        SetRect (&contentRect, AK_WINDOW_LEFT,  AK_WINDOW_TOP, AK_WINDOW_LEFT + width, AK_WINDOW_TOP + height);
    
        result = CreateNewWindow (kDocumentWindowClass, windowAttrs, &contentRect, &context->window);
        if(result)
        {
            akMac_ErrorCode(ak, result);
            return HG_FALSE;
        }
    }

    {
        CFStringRef cfTitle;
    
        cfTitle = CFStringCreateWithCString(kCFAllocatorDefault, title, kCFStringEncodingMacRoman);
        result = SetWindowTitleWithCFString(context->window, cfTitle);
        
        CFRelease (cfTitle); 
    
        if(result)
        {
            akMac_ErrorCode(ak, result);
        }
    }

    akMac_BuildGL(context);

    result = akMac_InstallWindowEventHandlers(ak);
    if(result) {
        akMac_ErrorCode(ak, result);
    }

    /* Add application-specific window initialization here */
    RepositionWindow (context->window, NULL, kWindowCascadeOnMainScreen);
    context->bufFormatHint = bufFormatHint;
    
    return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akAdjustWindow(AKAppKit* ak, HGuint32 width, HGuint32 height)
{
    AK_ASSERT(ak);
    {
        AKMacOSXContext* ctx = (AKMacOSXContext*)AKAppKit_getContext(ak);
        /* \todo [tero 24/Feb/06] make sure that this changes the size of the content
         * region, not including the titlebar or borders */
        if(ctx->window)
            SizeWindow(ctx->window, (short)width, (short)height, true);
    }
    return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akSetWindowTitle (AKAppKit* ak, const char* title)
{
    OSStatus result = 0;
    AKMacOSXContext* context = AKAppKit_getContext(ak);
    
    CFStringRef cfTitle;

    AK_ASSERT(ak);
    HG_UNREF(ak);

    cfTitle = CFStringCreateWithCString(kCFAllocatorDefault, title, kCFStringEncodingMacRoman);
    result = SetWindowTitleWithCFString(context->window, cfTitle);

    CFRelease (cfTitle); 

    if(result)
    {
        akMac_ErrorCode(ak, result);
        return HG_FALSE;
    }
    
    return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* akLockWindowBuffer (AKAppKit* ak)
{
    AKMacOSXContext*    ctx         = AKAppKit_getContext(ak);
    AKSurfaceDesc       surfDesc    = akGetSurface(ak);
    AK_ASSERT(ak);

    /* Destroy image if it's of wrong dimension. */

    if (ctx->bufImage && (ctx->bufImage->width != surfDesc.width || ctx->bufImage->height != surfDesc.height))
    {
        AKImage_destroy(ctx->bufImage);
        ctx->bufImage = NULL;
    }

    /* Create image if we don't have one. */

    if (!ctx->bufImage)
    {
        AKColorFormat fmt = akCanonizeColorFormat(ctx->bufFormatHint);
        if (fmt != AK_COLORFORMAT_BYTE_RGB &&
            fmt != AK_COLORFORMAT_BYTE_RGBA)
        {
            fmt = AK_COLORFORMAT_BYTE_RGB;
        }

        ctx->bufImage = AKImage_createBlankDownUp(surfDesc.width, surfDesc.height, fmt);
        if (!ctx->bufImage)
            return NULL;
    }
    
    return ctx->bufImage;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseWindowBuffer (AKAppKit* ak, AKImage* bufImage)
{
    AKMacOSXContext* ctx = (AKMacOSXContext*)AKAppKit_getContext(ak);
    int format;
    int type;
    AK_ASSERT(ak && bufImage && ctx);
    HG_UNREF(ak);

    aglSetDrawable(ctx->aglContext, GetWindowPort(ctx->window));

    switch (bufImage->format)
    {
    case AK_COLORFORMAT_BYTE_RGB:
        format  = GL_RGB;
        type    = GL_UNSIGNED_BYTE;
        break;

    case AK_COLORFORMAT_BYTE_RGBA:
        format  = GL_RGBA;
        type    = GL_UNSIGNED_BYTE;
        break;

    default:
        AK_ASSERT(HG_FALSE);
        return;
    }

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glDrawPixels(bufImage->width, bufImage->height, format, type,
        bufImage->data + bufImage->stride * (bufImage->height - 1));
    aglSwapBuffers(ctx->aglContext);    /*show the OpenGL frame buffer*/
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKSurfaceDesc akGetSurface (AKAppKit* ak)
{
    AKSurfaceDesc desc;
    AK_ASSERT(ak);
    
    {
        AKMacOSXContext* ctx = AKAppKit_getContext(ak);
        Rect rect;
        memset(&rect, 0, sizeof(rect));

        if(ctx->window)
            GetWindowBounds(ctx->window, kWindowContentRgn, &rect);
            
        desc.width     = (int)(rect.right - rect.left);
        desc.height    = (int)(rect.bottom - rect.top);
        desc.nativePtr = ctx->window;
    }
        
    return desc;
}

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

HG_STATICF OSStatus akMac_BuildGL(AKMacOSXContext* ctx)
{
    OSStatus err = noErr;
    Rect rectPort;
    GLint attrib[] = { AGL_RGBA, AGL_DOUBLEBUFFER, AGL_DEPTH_SIZE, 32, AGL_NONE };

    HG_ASSERT(ctx && ctx->window);
    HG_ASSERT(!ctx->aglContext);

    /* build context */
    ctx->aglPixFmt = aglChoosePixelFormat(NULL, 0, attrib);
    err = akMac_AglReportError();

    if (ctx->aglPixFmt)
    {
        ctx->aglContext = aglCreateContext(ctx->aglPixFmt, NULL);
        err = akMac_AglReportError ();
    }

    if (ctx->aglContext)
    {
        long opaque = 1;
        GLint sync = 1;

        /* It sucks, but to use AGL with Carbon, some legacy QuickDraw stuff is required.
         * More about that almost dead graphics library can be found from here:
         * http://developer.apple.com/documentation/mac/QuickDraw/QuickDraw-2.html
         */
        GrafPtr portSave = NULL;
        GetPort(&portSave);
        SetPort((GrafPtr) GetWindowPort (ctx->window));

        if(!aglSetDrawable(ctx->aglContext, GetWindowPort (ctx->window)))
            err = akMac_AglReportError ();
        if (!aglSetCurrentContext(ctx->aglContext))
            err = akMac_AglReportError ();
        aglSetInteger(ctx->aglContext, AGL_SURFACE_OPACITY, &opaque);
        aglSetInteger(ctx->aglContext, AGL_SWAP_INTERVAL, &sync);

        /* init GL stuff here */
        /* \todo [tero 24/Feb/06] move glViewport() to akReleaseWindowBuffer() */
        /* \todo [tero 24/Feb/06] other stuff is probably not needed? */
        glDisable(GL_DEPTH_TEST);
        glClearColor(1.0, 1.0, 1.0, 1.0);
        glClear (GL_COLOR_BUFFER_BIT);
        GetWindowPortBounds(ctx->window, &rectPort);
        glViewport(0, 0, rectPort.right - rectPort.left, rectPort.bottom - rectPort.top);

        SetPort(portSave);
    }
    
    return err;    
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF OSStatus akMac_DisposeGL(AKMacOSXContext* ctx)
{
    if(ctx)
    {
        if (ctx->aglContext)
        {
            aglSetDrawable (ctx->aglContext, NULL);
            aglSetCurrentContext (NULL);
            aglDestroyContext (ctx->aglContext);
            ctx->aglContext = NULL;
        }
        if (ctx->aglPixFmt)
        {
            aglDestroyPixelFormat (ctx->aglPixFmt);
            ctx->aglPixFmt = NULL;
        }
    }
    
    return noErr;
}

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

HG_STATICF void akMac_DrawGL(AKMacOSXContext* ctx)
{
    HG_ASSERT(ctx && ctx->aglContext);

    /* ensure the context is current */
    /* \todo [tero 24/Feb/06] move this to akReleaseWindowBuffer() */
    if (!aglSetCurrentContext(ctx->aglContext))
        akMac_AglReportError ();

    AKAppKit_callUpdate(ctx->appKit);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

OSStatus akMac_ResizeGL(AGLContext aglContext, int width, int height)
{
    OSStatus err = noErr;

    if (!aglContext)
        return paramErr;

    /* Re-attach drawable to ensure context is updated. */
    if (!aglSetCurrentContext (aglContext))
        err = akMac_AglReportError ();
        
    if ((noErr == err) && !aglUpdateContext (aglContext))
        err = akMac_AglReportError ();
        
    if (noErr == err)
    {
        /* \todo [tero 24/Feb/06] move glViewport() to akReleaseWindowBuffer() */
        /* \todo [tero 24/Feb/06] glClear() not probably needed? */
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);
    }
    
    return err;
}

/*-------------------------------------------------------------------*//*!
 * \brief update application at regular intervals
 *//*-------------------------------------------------------------------*/

HG_STATICF pascal void akMac_TimerCallBack(EventLoopTimerRef inTimer, void* userData)
{        
    AKMacOSXContext* ctx = (AKMacOSXContext*)userData;
    HG_UNREF(inTimer);
    HG_ASSERT(ctx);
    akMac_DrawGL(ctx);
}

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

HG_STATICF OSStatus akMac_AglReportError (void)
{
    GLenum err = aglGetError();
    if (AGL_NO_ERROR != err)
        printf("AGL: %s",(const char *) aglErrorString(err));

    /* ensure we are returning an OSStatus noErr if no error condition */
    if (err == AGL_NO_ERROR)
        return noErr;
    else
        return (OSStatus) err;
}

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

HG_STATICF OSStatus akMac_InstallWindowEventHandlers(AKAppKit* ak)
{
    OSStatus result = noErr;
    AKMacOSXContext* context = AKAppKit_getContext(ak);

    {
        EventHandlerUPP keyHandlerUPP;
        EventTypeSpec keySpec[] = {{kEventClassKeyboard, kEventRawKeyDown},
                                   {kEventClassKeyboard, kEventRawKeyUp}};
    
        EventHandlerUPP modHandlerUPP;
        EventTypeSpec modSpec;
    
        modSpec.eventClass = kEventClassKeyboard;
        modSpec.eventKind  = kEventRawKeyModifiersChanged;
    
        keyHandlerUPP = NewEventHandlerUPP(akMac_KeyEvent);
        result = InstallWindowEventHandler(context->window,
                                           keyHandlerUPP,
                                           2,
                                           keySpec,
                                           (void*) context,
                                           NULL);
                                           
        if(result) akMac_ErrorCode(ak, result);
    
        modHandlerUPP = NewEventHandlerUPP(akMac_ModEvent);
        result = InstallWindowEventHandler(context->window,
                                           modHandlerUPP,
                                           1,
                                           &modSpec,
                                           (void*) context,
                                           NULL);
                                           
        if(result) akMac_ErrorCode(ak, result);
    }

    {
        EventTypeSpec list[] = { { kEventClassWindow, kEventWindowCollapsing },
                                 { kEventClassWindow, kEventWindowActivated },
                                 { kEventClassWindow, kEventWindowHiding },
                                 { kEventClassWindow, kEventWindowShown },
                                 { kEventClassWindow, kEventWindowClose },
                                 { kEventClassWindow, kEventWindowDrawContent },
                                 { kEventClassWindow, kEventWindowResizeCompleted },
                                 { kEventClassKeyboard, kEventRawKeyDown },
                                 { kEventClassKeyboard, kEventRawKeyUp },
                                 { kEventClassKeyboard, kEventRawKeyModifiersChanged } };
                                     
        context->timerUPP = NewEventLoopTimerUPP(akMac_TimerCallBack);    
        context->winEventHandlerUPP = NewEventHandlerUPP(akMac_WindowEvtHndlr); 
        result = InstallWindowEventHandler(context->window,
                                        context->winEventHandlerUPP,
                                        GetEventTypeCount(list),
                                        list,
                                        (void*)context,
                                        &context->winEventHandlerRef);
        HG_ASSERT(result == noErr);
    }

    return result;
}

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

HG_STATICF pascal OSStatus akMac_KeyEvent(EventHandlerCallRef nextHandler,
                                          EventRef keyEvent,
                                          void* userData)
{
	/* \todo [tero 24/Feb/06] prefer to align the variable declarations */
    OSStatus result = noErr;
    AKMacOSXContext* context = (AKMacOSXContext *) userData;

    UInt32 kind = GetEventKind(keyEvent);
    HGbool down = (kind == kEventRawKeyDown ? HG_TRUE : HG_FALSE);

    unsigned int keyPressed;
    char charPressed;
    UniChar ucPressed;
    UniChar akPressed;
    
    const char* nonUnicode;
    char unicode[8];
                      
    GetEventParameter(keyEvent, kEventParamKeyCode, typeUInt32, NULL,
                      sizeof(UInt32), NULL, &keyPressed);

    GetEventParameter(keyEvent, kEventParamKeyMacCharCodes, typeChar, NULL,
                      sizeof(char), NULL, &charPressed);

    GetEventParameter(keyEvent, kEventParamKeyUnicodes, typeUnicodeText, NULL,
                      sizeof(UniChar), NULL, &ucPressed);

    akPressed = akMac_ConvertToAppkitKeyEventCode(context->appKit, keyEvent);
    
    if((nonUnicode = akMac_TranslateNonUnicodeKey(keyPressed)))
    {
        AKAppKit_callKeyEvent(context->appKit, down, nonUnicode);

    } else if (ucPressed)
    {
        akMac_TranslateUnicodeKey(akPressed, unicode, sizeof(unicode));        
        AKAppKit_callKeyEvent(context->appKit, down, unicode);
    }
    
    if (down && ucPressed)
        AKAppKit_callCharEvent(context->appKit, ucPressed);
        
    result = CallNextEventHandler(nextHandler, keyEvent);

    return result;
}

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

HG_STATICF pascal OSStatus akMac_ModEvent(EventHandlerCallRef nextHandler,
                                          EventRef keyEvent,
                                          void* userData)
{
    OSStatus result             = noErr;
    AKMacOSXContext* context    = (AKMacOSXContext *) userData;    

    HGbool down;    
    unsigned int modsDown;
    
    const char* unicode;
    GetEventParameter(keyEvent, kEventParamKeyModifiers, typeUInt32, NULL,
                      sizeof(UInt32), NULL, &modsDown);

    unicode = akMac_TranslateModifierKey(modsDown ^ context->prevModifiers);
    down = (modsDown ^ context->prevModifiers) & modsDown ? HG_TRUE : HG_FALSE;

    if(unicode)
    {
        AKAppKit_callKeyEvent(context->appKit, down, unicode);
    }

    context->prevModifiers = modsDown;

    result = CallNextEventHandler(nextHandler, keyEvent);

    return result;
}

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

HG_STATICF pascal OSStatus akMac_WindowEvtHndlr(EventHandlerCallRef nextHandler,
                                                EventRef event,
                                                void* userData)
{
    AKMacOSXContext*    ctx         = (AKMacOSXContext*)userData;
    UInt32              class       = GetEventClass(event);
    UInt32              kind        = GetEventKind(event);

    HG_ASSERT(ctx && ctx->window);

    switch(class)
    {
    case kEventClassWindow:
        switch(kind)
        {
        case kEventWindowHiding:
        	/* \todo [tero 24/Feb/06] avoid //-comments in C files, even when debugging */
        	/* \todo [tero 24/Feb/06] use a macro to enable/disable all the prints at once */
            //printf("windowEvtHndlr::kEventWindowHiding\n");
            if(ctx->timerRef) {
                
                /* remove timer to avoid wasting time for rendering while hidden */
                RemoveEventLoopTimer(ctx->timerRef);
                ctx->timerRef = HG_NULL;
            }
            break;
        
        case kEventWindowCollapsing:
            //printf("windowEvtHndlr::kEventWindowCollapsing\n");
            if(ctx->timerRef) {
                
                /* remove timer to avoid wasting time for rendering while collapsed */
                RemoveEventLoopTimer(ctx->timerRef);
                ctx->timerRef = HG_NULL;
            }
            break;
        
        case kEventWindowActivated: /* called on click activation and initially */
            //printf("windowEvtHndlr::kEventWindowActivated\n");
            
            /* install timer to render a frame every 0.01 seconds */
            if(!ctx->timerRef) {        
                //printf("windowEvtHndlr::kEventWindowActivated: !ctx->timerRef\n");
                InstallEventLoopTimer(GetCurrentEventLoop(), 0, 0.01, ctx->timerUPP, (void *)ctx, &ctx->timerRef);
            }
            
            break;

        case kEventWindowDrawContent: /* will receive one prior to being shown */
            //printf("windowEvtHndlr::kEventWindowDrawContent\n");
            akMac_DrawGL(ctx);
            break;

        case kEventWindowClose: /* called when window is being closed (close box) */
            {
                //printf("windowEvtHndlr::kEventWindowClose\n");
                if(ctx->timerRef) {
                    
                    /* remove timer so that idle update is not called anymore */
                    RemoveEventLoopTimer(ctx->timerRef);
                    ctx->timerRef = HG_NULL;
                }
                
                AKAppKit_requestExit(ctx->appKit);
                akMac_DisposeGL(ctx);
            }
            break;

        case kEventWindowShown: /* called on initial show (not on un-minimize) */
        
            /* draw content is received prior to this so if you handle that then not drawing required here */
            //printf("windowEvtHndlr::kEventWindowShown\n");
            if (ctx->window == FrontWindow())
                SetUserFocusWindow(ctx->window);
                
            /* install timer to render a frame every 0.01 seconds */
            if(!ctx->timerRef) {
                //printf("windowEvtHndlr::kEventWindowShown: !ctx->timerRef\n");            
                InstallEventLoopTimer(GetCurrentEventLoop(), 0, 0.01, ctx->timerUPP, (void *)ctx, &ctx->timerRef);
            }
    
            break;

        case kEventWindowResizeCompleted:
            {
                AKSurfaceDesc d = AKAppKit_getSurface(ctx->appKit);
                //printf("windowEvtHndlr::kEventWindowBoundsChanged: size %dx%d\n",d.width, d.height);
                akMac_ResizeGL(ctx->aglContext, d.width, d.height);
                akMac_DrawGL(ctx);
            }
            break;
        }
        break;
    }
    
    return CallNextEventHandler(nextHandler, event);
}

/*----------------------------------------------------------------------*/
