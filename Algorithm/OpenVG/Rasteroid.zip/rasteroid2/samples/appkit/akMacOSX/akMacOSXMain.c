/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akMacOSX/akMacOSXMain.c#2 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *
 *//**
 * \file
 * \brief    ???
 * \author    lauri@hybrid.fi
 *//*-------------------------------------------------------------------*/
 
#include "akMacOSXMain.h"
#include "akMacOSXWindow.h"

#include "akUtils.h"
#include "akMain.h"

#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

/* Define if the executable is going to be wrapped inside an app bundle. */
#undef USE_APP_BUNDLE

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

#if !defined(USE_APP_BUNDLE)
extern OSErr CPSEnableForegroundOperation(ProcessSerialNumber* psn);
#endif

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF void             pushEntry            (AKDirListing* dir, struct dirent* f, const char* path);
HG_STATICF void*            threadProc           (void* arg);
HG_STATICF pascal OSStatus  akMac_AppEvtHndlr    (EventHandlerCallRef myHandler,
                                                  EventRef event,
                                                  void* userData);

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

int main(int argc, char** argv)
{
    AKMacOSXContext context;
    UnsignedWide startTime;

    memset(&context, 0, sizeof(AKMacOSXContext));

    context.appKit = AKAppKit_create(&context, argv, argc);

    if(!context.appKit)
        return EXIT_FAILURE;

    Microseconds(&startTime);
    context.startTime = UnsignedWideToUInt64(startTime);

    context.bufFormatHint = AK_COLORFORMAT_NONE;

#if !defined(USE_APP_BUNDLE)
    {
        ProcessSerialNumber psn;
    
        /* CPSEnableForegroundOperation is an undocumented SPI function in Mac OS X.
         * It registers the unbundled executable with the window server.
         */
        if(!GetCurrentProcess(&psn))
            if(!CPSEnableForegroundOperation(&psn))
                SetFrontProcess(&psn);
    }
#endif

    {
        OSStatus err;
        EventTypeSpec list[] = { { kEventClassCommand, kEventProcessCommand },
                                 { kEventClassApplication, kEventAppActivated },
                                 { kEventClassMouse, kEventMouseDown },    /* TODO handle these per window? */
                                 { kEventClassMouse, kEventMouseUp }, 
                                 { kEventClassMouse, kEventMouseMoved },
                                 { kEventClassMouse, kEventMouseDragged },
                                 { kEventClassMouse, kEventMouseExited },
                                 { kEventClassMouse, kEventMouseWheelMoved } };

        context.appEventHandlerUPP = NewEventHandlerUPP(akMac_AppEvtHndlr);
        
        err = InstallApplicationEventHandler(context.appEventHandlerUPP,
                                             GetEventTypeCount(list),
                                             list,
                                             (void*)&context,
                                             &context.appEventHandlerRef);
                                             
        if(err != noErr) return EXIT_FAILURE;
    }
        
    if(!appInit(context.appKit))
        return EXIT_FAILURE;    

    ShowWindow (context.window);
    RunApplicationEventLoop();

    if (context.window)
    {
        RemoveEventHandler(context.appEventHandlerRef);
        RemoveEventHandler(context.winEventHandlerRef);
        DisposeEventLoopTimerUPP(context.timerUPP);
        DisposeEventHandlerUPP(context.appEventHandlerUPP);
        DisposeEventHandlerUPP(context.winEventHandlerUPP);
        HideWindow(context.window);
        DisposeWindow(context.window);
        AKAppKit_destroy(context.appKit);
    }
    
    return EXIT_SUCCESS;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akMac_ErrorCode (AKAppKit* ak, int code)
{
    AKAppKit_printf(ak, "ERROR: %d\n", code);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akErrorMessage (AKAppKit* ak, const char* msg)
{
    AK_ASSERT(ak);
    AKAppKit_outputString(ak, msg);
    AKAppKit_outputString(ak, "\n");
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAbort (AKAppKit* ak)
{
    AK_ASSERT(ak);
    HG_UNREF(ak);
    exit(1);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akRequestExit(AKAppKit* ak)
{
    AK_ASSERT(ak);
    HG_UNREF(ak);
    QuitApplicationEventLoop();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akGetTime(AKAppKit* ak, HGuint32* hiMillis, HGuint32* loMillis)
{
    AK_ASSERT(ak && hiMillis && loMillis);
    {
        AKMacOSXContext*  ctx  = AKAppKit_getContext(ak);
        UnsignedWide      time = {0, 0};
    
        Microseconds(&time);
        time = UInt64ToUnsignedWide(U64Div(U64Subtract(UnsignedWideToUInt64(time), ctx->startTime), U64Set(1000)));
        *hiMillis = time.hi;
        *loMillis = time.lo;
    }
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF void pushEntry (AKDirListing* dir, struct dirent* f, const char* path)
{
    AK_ASSERT(dir && f);

    if (akCompareStrings(f->d_name, ".") || akCompareStrings(f->d_name, ".."))
        return;

    {
        AKDirEntry* entry = AKDirEntry_create();
        if (!entry)
            return;

        {
            struct stat    buf;
            char*        name = akCatenateStrings(path, f->d_name);
            if (name && !lstat(name, &buf))
            {
                if (S_ISDIR(buf.st_mode))
                    entry->flags |= AK_DIRENTRY_FLAGS_DIR;
            }

            free(name);
        }

        akCopyString(entry->filename, f->d_name);

        AKDirListing_pushBack(dir, entry);
    }
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKDirListing* akGetDirectoryListing (AKAppKit* ak, const char* path)
{
    AK_ASSERT(ak && path);
    HG_UNREF(ak);

    {
        char*            fixedPath;
        char*            dirPath;
        AKDirListing*    dir;
        DIR*             d;
        struct dirent*   f;

        fixedPath = akFixPath(path);
        if (!fixedPath)
            return NULL;

        dirPath = akDuplicateString(fixedPath);
        akAppendString(&dirPath, ".");
        if (!dirPath)
            return NULL;

        dir = AKDirListing_create();
        if (!dir)
        {
            free(fixedPath);
            free(dirPath);
            return NULL;
        }

        d = opendir(dirPath);
        free(dirPath);

        if (!d)
        {
            AKDirListing_destroy(dir);
            free(fixedPath);
            return NULL;
        }

        while ((f = readdir(d)) != NULL)
            pushEntry(dir, f, fixedPath);

        closedir(d);

        free(fixedPath);

        return dir;
    }
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/
 
 HG_STATICF void* threadProc (void* arg)
 {
     AK_ASSERT(arg);
     AKAppKit_threadStarted((AKThreadParams*)arg);
     return NULL;
 }

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateThread (AKAppKit* ak, AKThreadParams* params)
{
    pthread_t id;
    AK_ASSERT(ak && params);
    HG_UNREF(ak);
    return (pthread_create(&id, NULL, threadProc, params) == 0);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akGetThreadID (AKAppKit* ak)
{
    AK_ASSERT(ak);
    HG_UNREF(ak);
    return (HGuint32)pthread_self();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void* akCreateSemaphore (AKAppKit* ak)
{
    MPSemaphoreID semaphore;
    
    AK_ASSERT(ak);
    HG_UNREF(ak);

    MPCreateSemaphore(1, 1, &semaphore);

    if (!semaphore)
    {
        MPDeleteSemaphore(semaphore);
        return NULL;
    }
    
    return semaphore;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akDestroySemaphore (AKAppKit* ak, void* semaphore)
{
    AK_ASSERT(ak && semaphore);
    HG_UNREF(ak);
    MPDeleteSemaphore((MPSemaphoreID)semaphore);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAcquireSemaphore (AKAppKit* ak, void* semaphore)
{
    AK_ASSERT(ak && semaphore);
    HG_UNREF(ak);
    MPWaitOnSemaphore((MPSemaphoreID)semaphore, kDurationForever);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseSemaphore (AKAppKit* ak, void* semaphore)
{
    AK_ASSERT(ak && semaphore);
    HG_UNREF(ak);
    MPSignalSemaphore((MPSemaphoreID)semaphore);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF pascal OSStatus akMac_AppEvtHndlr (EventHandlerCallRef nextHandler,
                                              EventRef event,
                                              void* userData)
{
    OSStatus            err;    
    OSStatus            result      = noErr;
    
    UInt32              eventClass  = GetEventClass(event);
    UInt32              kind        = GetEventKind(event);
    
    AKMacOSXContext*    ctx         = (AKMacOSXContext*)userData;
    
    HG_ASSERT(ctx);
    
    switch(eventClass)
    {
    case kEventClassApplication:
        break;
    case kEventClassMouse:

        switch(kind)
        {
        case kEventMouseDown:
        case kEventMouseUp:
            {
                EventMouseButton button = 0;
    
                err = GetEventParameter(event, kEventParamMouseButton,
                                        typeMouseButton, NULL, 
                                        sizeof(EventMouseButton), NULL,
                                        &button);
                                        
                HG_ASSERT(err == noErr);
    
                if (button == kEventMouseButtonPrimary)
                    AKAppKit_callKeyEvent(ctx->appKit, kind == kEventMouseDown, (const char*)"!PtrLeft");
                if (button == kEventMouseButtonSecondary)
                    AKAppKit_callKeyEvent(ctx->appKit, kind == kEventMouseDown, (const char*)"!PtrRight");
                if (button == kEventMouseButtonTertiary)
                    AKAppKit_callKeyEvent(ctx->appKit, kind == kEventMouseDown, (const char*)"!PtrMiddle");
                break;
            }
        case kEventMouseDragged:
        case kEventMouseMoved:
            {
                HIPoint  location = {0.0f, 0.0f};           
                Rect     rect;
 
                GetWindowBounds(ctx->window, kWindowContentRgn, &rect);
                GetEventParameter(event, kEventParamMouseLocation, typeHIPoint, NULL, sizeof(HIPoint), NULL, &location);
                AKAppKit_callPtrEvent(ctx->appKit, HG_TRUE,
                                     (short)location.x - rect.left,
                                     (short)location.y - rect.top);
            }
            break;

        case kEventMouseExited:
            /* TODO this doesn't work. Probably because exit messages work with tracking regions or something */
            AKAppKit_callPtrEvent(ctx->appKit, HG_FALSE, 0, 0);
            break;

        case kEventMouseWheelMoved:
            {
                long wheelDelta  = 0;
            
                GetEventParameter(event, kEventParamMouseWheelDelta,
                                  typeLongInteger, NULL,
                                  sizeof(long), NULL,
                                  &wheelDelta);
                {         
                    const char* keyData = wheelDelta > 0 ? "!WheelUp" : "!WheelDown";
    
                    int i;               
                    for(i = 0; i < abs(wheelDelta); i++)
                    {
                        AKAppKit_callKeyEvent(ctx->appKit, HG_TRUE, keyData);
                        AKAppKit_callKeyEvent(ctx->appKit, HG_FALSE, keyData);
                    }
                }
                break;
            }
        }
        
        result = noErr;
        break;

    case kEventClassCommand:

        switch(kind)
        {
        case kEventProcessCommand:
            {
                HICommand command;
    
                GetEventParameter(event,
                                  kEventParamDirectObject,
                                  kEventParamHICommand, NULL,
                                  sizeof(command), NULL,
                                  &command); /* get command */
                                   
                switch(command.commandID)
                {
                case kHICommandQuit:
                    /* just exits the event loop and return to main. Deinitialization will be done there. */
                    break;
                }
            }
            break;
        }
        break;
    }

    if(result != noErr) return result;
        
    return CallNextEventHandler(nextHandler, event);
}

/*----------------------------------------------------------------------*/
