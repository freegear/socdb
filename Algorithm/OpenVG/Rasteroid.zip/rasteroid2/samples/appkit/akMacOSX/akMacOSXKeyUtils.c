/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akMacOSX/akMacOSXKeyUtils.c#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *
 *//**
 * \file
 * \brief	???
 * \author	lauri@hybrid.fi
 *//*-------------------------------------------------------------------*/
 
#include "akMacOSXKeyUtils.h"
#include <CoreFoundation/CoreFoundation.h>

/*-------------------------------------------------------------------*//*!
 *
 * \brief Upgrade a WorldScript code to a TEC encoding based on the keyboard
 *        layout id.
 *
 * Results:
 *      The TEC code that corresponds best to the combination of WorldScript
 *      code and 'KCHR' id.
 *
 * Side effects:
 *      None.
 *
 * Rationale and Notes:
 *      WorldScript codes are sometimes not unique encodings.  E.g. Icelandic
 *      uses script smRoman (0), but the actual encoding is
 *      kTextEncodingMacIcelandic (37).  ftp://ftp.unicode.org/Public
 *      /MAPPINGS/VENDORS/APPLE/README.TXT has a good summary of these
 *      variants.  So we need to upgrade the script to an encoding with
 *      GetTextEncodingFromScriptInfo().
 *
 *      'KCHR' ids are usually region codes (see the comments in Script.h).
 *      Where they are not, we get a paramErr from the OS function and have
 *      appropriate fallbacks.
 *
*//*-------------------------------------------------------------------*/

TextEncoding akMac_GetKCHREncoding(ScriptCode script, SInt32 layoutid)
{
    RegionCode    region     = layoutid;
    TextEncoding  encoding   = script;

    if (GetTextEncodingFromScriptInfo(script,
                                      kTextLanguageDontCare,
                                      region,
                                      &encoding) == noErr)
    {
        return encoding;
    }
        
    /*
     * The valid script codes are also the valid default encoding codes, so
     * if nothing else helps, fall back on those.
     */

    return script;
}

/*-------------------------------------------------------------------*//*!
 *
 * \brief Given MacOS key event data this function generates the Unicode
 *        characters.  It does this using a 'uchr' and the UCKeyTranslate
 *        API.
 *
 *        The parameter deadKeyStatePtr can be NULL, if no deadkey handling
 *        is needed.
 *
 *        Tested and known to work with US, Hebrew, Greek and Russian layouts
 *        as well as "Unicode Hex Input".
 *
 * Results:
 *        The number of characters generated if any, 0 if we are waiting for
 *        another byte of a dead-key sequence. Fills in the uniChars array
 *        with a Unicode string.
 *
 * Side Effects:
 *        None
 *
*//*-------------------------------------------------------------------*/

int akMac_KeycodeToUnicodeViaUnicodeResource(UniChar * uniChars,
                                             int maxChars,
                                             Ptr uchr,
                                             EventKind eKind,
                                             UInt32 keycode, UInt32 modifiers,
                                             UInt32 * deadKeyStatePtr)
{
    int             action;
    unsigned long   keyboardType;
    OptionBits      options = 0;
    UInt32          dummy_state;
    UniCharCount    actuallength; 
    OSStatus        status;

    keycode         &= 0xFF;
    modifiers       = (modifiers >> 8) & 0xFF;
    keyboardType    = LMGetKbdType();

    if (!deadKeyStatePtr)
    {
        options         = kUCKeyTranslateNoDeadKeysMask;
        dummy_state     = 0;
        deadKeyStatePtr = &dummy_state;
    }

    switch(eKind) {     
    case kEventRawKeyDown:
        action = kUCKeyActionDown;
        break;
    case kEventRawKeyUp:
        action = kUCKeyActionUp;
        break;
    case kEventRawKeyRepeat:
        action = kUCKeyActionAutoKey;
        break;
    default:
#ifdef HG_DEBUG
        fprintf (stderr,
                 "KeycodeToUnicodeViaUnicodeResource(): Invalid parameter eKind %d\n",
                 (int) eKind);
#endif
        return 0;
    }

    status = UCKeyTranslate(
                            (const UCKeyboardLayout *) uchr,
                            keycode, action, modifiers, keyboardType,
                            options, deadKeyStatePtr,
                            maxChars, &actuallength, uniChars);

    if (!actuallength && *deadKeyStatePtr)
    {
        /*
         * More data later
         */
        
        return 0; 
    }
    
    /*
     * some IMEs leave residue :-(
     */
    
    *deadKeyStatePtr = 0; 

    if (noErr != status)
    {
#ifdef HG_DEBUG
        fprintf(stderr, "UCKeyTranslate failed: %d", (int) status);
#endif
        actuallength = 0;
    }

    return actuallength;
}

/*-------------------------------------------------------------------*//*!
 *
 * \brief Given MacOS key event data this function generates the Unicode
 *        characters.  It does this using a 'KCHR' and the KeyTranslate API.
 *
 *        The parameter deadKeyStatePtr can be NULL, if no deadkey handling
 *        is needed.
 *
 * Results:
 *        The number of characters generated if any, 0 if we are waiting for
 *        another byte of a dead-key sequence. Fills in the uniChars array
 *        with a Unicode string.
 *
 * Side Effects:
 *        None
 *
*//*-------------------------------------------------------------------*/

int akMac_KeycodeToUnicodeViaKCHRResource(UniChar* uniChars,
                                          int maxChars,
                                          SInt32* kchr,
                                          TextEncoding encoding,
                                          UInt32 keycode,
                                          UInt32 modifiers,
                                          UInt32* deadKeyStatePtr)
{
    UInt32  result;
    char    macBuff[3];
    char*   macStr;
    int     macStrLen;
    UInt32  dummy_state = 0;


    if (!deadKeyStatePtr)
    {
        deadKeyStatePtr = &dummy_state;
    }

    keycode |= modifiers;
    result   = KeyTranslate(kchr, keycode, deadKeyStatePtr);

    if (!result && dummy_state)
    {
        /*
         * 'dummy_state' gets only filled if the caller did not want deadkey
         * processing (deadKeyStatePtr was NULL originally), but we still
         * have a deadkey.  We just push the keycode for the space bar to get
         * the real key value.
         */

        result = KeyTranslate(kchr, 0x31, deadKeyStatePtr);
        *deadKeyStatePtr = 0;
    }

    if (!result && *deadKeyStatePtr)
    {
        /*
         * More data later
         */
        
        return 0; 
    }

    macBuff[0] = (char) (result >> 16);
    macBuff[1] = (char)  result;
    macBuff[2] = 0;

    if (macBuff[0])
    {
        /*
         * If the first byte is valid, the second is too
         */
        
        macStr = macBuff;
        macStrLen = 2;
    } else if (macBuff[1])
    {
        /*
         * Only the second is valid
         */
        
        macStr = macBuff+1;
        macStrLen = 1;
    } else {
        /*
         * No valid bytes at all -- shouldn't happen
         */
        
        macStr = NULL;
        macStrLen = 0;
    }

    if (macStrLen <= 0)
    {
        return 0;
    } else {

        /*
         * Use the CFString conversion routines.  This is the easiest and
         * most compatible way to get from an 8-bit string and a MacOS script
         * code to a Unicode string.
         */
        
        CFStringRef cfString;
        int uniStrLen;

        cfString = CFStringCreateWithCStringNoCopy(NULL, macStr, encoding, kCFAllocatorNull);
        if (!cfString)
        {
#ifdef HG_DEBUG
            fprintf(stderr, "CFString: Can't convert with encoding %d\n",
                    (int) encoding);
#endif
            return 0;
        }

        uniStrLen = CFStringGetLength(cfString);
        if (uniStrLen > maxChars)
        {
            uniStrLen = maxChars;
        }
        CFStringGetCharacters(cfString, CFRangeMake(0,uniStrLen), uniChars);
        CFRelease(cfString);

        return uniStrLen;
    }
}

/*----------------------------------------------------------------------*/
