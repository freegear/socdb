/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akMacOSX/akMacOSXKeyTranslation.c#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *
 *//**
 * \file
 * \brief	???
 * \author	lauri@hybrid.fi
 *//*-------------------------------------------------------------------*/

#include "akMacOSXKeyTranslation.h"
#include "akMacOSXKeyUtils.h"
#include "akMacOSXMain.h"

#include <Carbon/Carbon.h>
#include <CoreFoundation/CoreFoundation.h>

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

typedef enum
{
    kAKey            = 0x00,
    kSKey            = 0x01,
    kDKey            = 0x02,
    kFKey            = 0x03,
    kHKey            = 0x04,
    kGKey            = 0x05,
    kZKey            = 0x06,
    kXKey            = 0x07,
    kCKey            = 0x08,
    kVKey            = 0x09,
    kBKey            = 0x0B,
    kQKey            = 0x0C,
    kWKey            = 0x0D,
    kEKey            = 0x0E,
    kRKey            = 0x0F,
    kYKey            = 0x10,
    kTKey            = 0x11,
    k1Key            = 0x12,
    k2Key            = 0x13,
    k3Key            = 0x14,
    k4Key            = 0x15,
    k5Key            = 0x17,
    k6Key            = 0x16,
    k7Key            = 0x1A,
    k8Key            = 0x1C,
    k9Key            = 0x19,
    k0Key            = 0x1D,
    kMinusKey        = 0x1B,
    kEqualsKey       = 0x18,
    kRightBraceKey   = 0x1E,
    kOKey            = 0x1F,
    kUKey            = 0x20,
    kLeftBraceKey    = 0x21,
    kIKey            = 0x22,
    kPKey            = 0x23,
    kReturnKey       = 0x24,
    kLKey            = 0x25,
    kJKey            = 0x26,
    kQuoteKey        = 0x27,
    kKKey            = 0x28,
    kColonKey        = 0x29,
    kBackSlashKey    = 0x2A,
    kLessThanKey     = 0x2B,
    kSlashKey        = 0x2C,
    kNKey            = 0x2D,
    kMKey            = 0x2E,
    kGreaterThanKey  = 0x2F,
    kPeriodKey       = 0x2F,
    kTabKey          = 0x30,
    kSpaceKey        = 0x31,
    kTildeKey        = 0x32,
    kBackSpaceKey    = 0x33,
    kEscapeKey       = 0x35,
    kCapsLockKey     = 0x39,
    kOptionKey       = 0x3A,
    kControlKey      = 0x3B,
    kCmdKey          = 0x37,
    kShiftKey        = 0x38,
    kClearKey        = 0x47,
    kEnterKey        = 0x4C,
    kHomeKey         = 0x73,
    kEndKey          = 0x77,
    kLeftArrowKey    = 0x7B,
    kRightArrowKey   = 0x7C,
    kDownArrowKey    = 0x7D,
    kUpArrowKey      = 0x7E,
    kHelpKey         = 0x72,
    kPageUpKey       = 0x74,
    kDelKey          = 0x75,
    kPageDownKey     = 0x79,
    kF1Key           = 0x7A,
    kF2Key           = 0x78,
    kF3Key           = 0x63,
    kF4Key           = 0x76,
    kF5Key           = 0x60,
    kF6Key           = 0x61,
    kF7Key           = 0x62,
    kF8Key           = 0x64,
    kF9Key           = 0x65,
    kF10Key          = 0x6D,
    kF11Key          = 0x67,
    kF12Key          = 0x6F,
    kF13Key          = 0x69,
    kF14Key          = 0x6B,
    kF15Key          = 0x71
} akMac_VirtualKeyCode;

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

typedef enum
{
    mCapsLockKey    = 0x400,
    mShiftKey       = 0x200,    
    mControlKey     = 0x1000,
    mAltKey         = 0x800,
    mCommandKey     = 0x100
} akMac_ModifierKeyFlag;

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

UniChar akMac_ConvertToAppkitKeyEventCode(AKAppKit* ak, EventRef keyEvent)
{
    EventRecord         eventRec;
    KeyboardLayoutRef   keyboardLayout;

    ScriptCode          currentKeyScript;
    SInt32*             currentLayoutId;

    TextEncoding        currentEncoding;

    UniChar             uniChars[5];

    HG_UNREF(ak);
    
    ConvertEventRefToEventRecord(keyEvent, &eventRec);

    KLGetCurrentKeyboardLayout(&keyboardLayout);
    
    KLGetKeyboardLayoutProperty(
        keyboardLayout,
        kKLKCHRData,
        (void*) &currentLayoutId
    );

    currentKeyScript    = GetScriptManagerVariable(smKeyScript);
    currentEncoding     = akMac_GetKCHREncoding(currentKeyScript, *currentLayoutId);

    akMac_KeycodeToUnicodeViaKCHRResource(uniChars,
                                          sizeof(uniChars),
                                          currentLayoutId,
                                          currentEncoding,
                                          eventRec.message >> 8,
                                          0,
                                          NULL);
    
    return uniChars[0];
}

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

void akMac_TranslateUnicodeKey (UInt32 code, char* unicode, unsigned int ucSize)
{
    snprintf(unicode, ucSize, "U+%04X", (unsigned int) code);
}

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

const char* akMac_TranslateNonUnicodeKey (UInt32 code)
{
    switch (code)
    {                        
        case kF1Key:           return "F1";
        case kF2Key:           return "F2";
        case kF3Key:           return "F3";
        case kF4Key:           return "F4";
        case kF5Key:           return "F5";
        case kF6Key:           return "F6";
        case kF7Key:           return "F7";
        case kF8Key:           return "F8";
                          
        case kEnterKey:        return "Enter";
              
        case kHelpKey:         return "Help";
        case kHomeKey:         return "Home";
        case kEndKey:          return "End";
        case kPageUpKey:       return "PageUp";
        case kPageDownKey:     return "PageDown";
                        
        case kUpArrowKey:      return "Up";
        case kLeftArrowKey:    return "Left";
        case kDownArrowKey:    return "Down";
        case kRightArrowKey:   return "Right";

        default: return NULL;
    }    
}

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

const char* akMac_TranslateModifierKey (UInt32 code)
{
    switch (code)
    {                    
        case mCapsLockKey:  return "CapsLock";
        case mShiftKey:     return "Shift";
        case mControlKey:   return "Control";
        case mAltKey:       return "Alt";
        case mCommandKey:   return "Win";

        default: return NULL;
    }
}

/*----------------------------------------------------------------------*/
