#ifndef __AKMACOSXWINDOW_H
#define __AKMACOSXWINDOW_H

/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akMacOSX/akMacOSXWindow.h#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *
 *//**
 * \file
 * \brief    ???
 * \author    lauri@hybrid.fi
 *//*-------------------------------------------------------------------*/

#if !defined(__AKAPPKIT_H)
#   include "akAppKit.h"
#endif

#if !defined(__AKDEFS_H)
#   include "akDefs.h"
#endif

/*----------------------------------------------------------------------*/
#endif /* __AKMACOSXWINDOW_H */
