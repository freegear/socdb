#ifndef __AKMACOSXMAIN_H
#define __AKMACOSXMAIN_H

/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akMacOSX/akMacOSXMain.h#2 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *
 *//**
 * \file
 * \brief    ???
 * \author    lauri@hybrid.fi
 *//*-------------------------------------------------------------------*/

#if !defined(__AKAPPKIT_H)
#   include "akAppKit.h"
#endif

#if !defined(__AKAPPKITPRIVATE_H)
#include "akAppKitPrivate.h"
#endif

#if !defined(__AKDEFS_H)
#   include "akDefs.h"
#endif

#include <Carbon/Carbon.h>
#include <CoreServices/CoreServices.h>
#include <OpenGL/gl.h>
#include <AGL/agl.h>

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

typedef struct
{

    AKAppKit*                appKit;
    WindowRef                window;

    UInt64                   startTime;

    EventLoopTimerRef        timerRef;
    EventLoopTimerUPP        timerUPP;
    EventHandlerRef          winEventHandlerRef;
    EventHandlerUPP          winEventHandlerUPP;
    EventHandlerRef          appEventHandlerRef;
    EventHandlerUPP          appEventHandlerUPP;
    
    UInt32                   prevModifiers;
    
    AGLPixelFormat           aglPixFmt;
    AGLContext               aglContext;

    HGint32                  bufFormatHint;    /* AKColorFormat */
    AKImage*                 bufImage;

} AKMacOSXContext;

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

void             akMac_ErrorCode         (AKAppKit* ak, int code);

/*----------------------------------------------------------------------*/
#endif /* __AKMACOSXMAIN_H */
