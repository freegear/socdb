#ifndef __AKMACOSXKEYEVENT_H
#define __AKMACOSXKEYEVENT_H

/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akMacOSX/akMacOSXKeyTranslation.h#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *
 *//**
 * \file
 * \brief	???
 * \author	lauri@hybrid.fi
 *//*-------------------------------------------------------------------*/

#if !defined(__AKAPPKIT_H)
#   include "akAppKit.h"
#endif

#include <Carbon/Carbon.h>

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

UniChar akMac_ConvertToAppkitKeyEventCode(AKAppKit* ak, EventRef keyEvent);

void            akMac_TranslateUnicodeKey       (UInt32, char unicode[], unsigned int ucSize);
const char*     akMac_TranslateNonUnicodeKey    (UInt32 key);
const char*     akMac_TranslateModifierKey      (UInt32 key);

/*----------------------------------------------------------------------*/
#endif /* __AKMACOSXKEYEVENT_H */
