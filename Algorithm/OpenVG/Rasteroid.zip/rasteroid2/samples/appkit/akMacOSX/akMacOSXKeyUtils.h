#ifndef __AKMACOSXKEYUTILS_H
#define __AKMACOSXKEYUTILS_H

/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akMacOSX/akMacOSXKeyUtils.h#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *
 *//**
 * \file
 * \brief	???
 * \author	lauri@hybrid.fi
 *//*-------------------------------------------------------------------*/

#if !defined(__AKDEFS_H)
#   include "akDefs.h"
#endif

#include <Carbon/Carbon.h>

/*-------------------------------------------------------------------*//*!
* \brief
*//*-------------------------------------------------------------------*/

TextEncoding akMac_GetKCHREncoding(ScriptCode script, SInt32 layoutid);

int akMac_KeycodeToUnicodeViaUnicodeResource(UniChar* uniChars,
                                             int maxChars,
                                             Ptr kchr,
                                             EventKind eKind,
                                             UInt32 keycode, UInt32 modifiers,
                                             UInt32* deadKeyStatePtr);

int akMac_KeycodeToUnicodeViaKCHRResource(UniChar* uniChars, 
                                          int maxChars,
                                          SInt32* kchr,
                                          TextEncoding encoding,
                                          UInt32 keycode,
                                          UInt32 modifiers,
                                          UInt32* deadKeyStatePtr);
                                    
/*----------------------------------------------------------------------*/
#endif /* __AKMACOSXKEYUTILS_H */
