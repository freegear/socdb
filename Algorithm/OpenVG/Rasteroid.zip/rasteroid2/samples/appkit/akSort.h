#ifndef __AKSORT_H
#define __AKSORT_H
/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/include/akSort.h#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *
 *//**
 * \file
 * \brief	Abstract quick sort implementation
 * \author	tero@hybrid.fi
 *//*-------------------------------------------------------------------*/

#if !defined(__AKDEFS_H)
#	include "akDefs.h"
#endif

/*-------------------------------------------------------------------*//*!
 * \brief	Abstract function for comparing two elements in an array.
 *
 * \param	data	User data.
 * \param	idxA	Index of the first element.
 * \param	idxB	Index of the second element.
 * \return	Negative if a < b, zero if a = b, and positive if a > b.
 *//*-------------------------------------------------------------------*/

typedef int (*akSortCompareFunc)(void* data, int idxA, int idxB);

/*-------------------------------------------------------------------*//*!
 * \brief	Abstract function for swapping two elements in an array.
 *
 * \param	data	User context.
 * \param	idxA	Index of the first element.
 * \param	idxB	Index of the second element.
 *//*-------------------------------------------------------------------*/

typedef void (*akSortSwapFunc)(void* data, int idxA, int idxB);

/*-------------------------------------------------------------------------
 * Function prototypes
 *-----------------------------------------------------------------------*/

HG_EXTERN_C_BLOCK_BEGIN

void akSort(int start, int size, void* data, akSortCompareFunc compareFunc, akSortSwapFunc swapFunc);

HG_EXTERN_C_BLOCK_END

/*----------------------------------------------------------------------*/
#endif /* __AKSORT_H */
