#ifndef __AKARG_H
#define __AKARG_H
/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/include/akArg.h#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#if !defined(__AKDEFS_H)
#	include "akDefs.h"
#endif

/*-------------------------------------------------------------------------
 * AKArg class.
 *-----------------------------------------------------------------------*/

typedef struct AKArg_s AKArg;

struct AKArg_s
{
	char*		name;
	HGuint32	valueCount;
	char**		values;
	AKArg*		next;
};

HG_HEADER_CT_ASSERT(AKARG_H, sizeof(AKArg) == 4 * 4);

/*-------------------------------------------------------------------------
 * AKArg methods.
 *-----------------------------------------------------------------------*/

HG_EXTERN_C_BLOCK_BEGIN

AKArg*		AKArg_create		(char** data, HGuint32 count);
void		AKArg_destroy		(AKArg* arg);
void		AKArg_destroyList	(AKArg* firstArg);

void		AKArg_addToList		(AKArg** firstArg, AKArg* nArg);

HG_EXTERN_C_BLOCK_END

/*----------------------------------------------------------------------*/
#endif /* __AKARG_H */
