#ifndef __AKIMAGE_H
#define __AKIMAGE_H
/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/include/akImage.h#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#if !defined(__AKDEFS_H)
#	include "akDefs.h"
#endif

/*-------------------------------------------------------------------------
 * Color format enumeration.
 *-----------------------------------------------------------------------*/

typedef enum
{
	AK_COLORFORMAT_NONE = 0,

	AK_COLORFORMAT_INT_RGBA,
	AK_COLORFORMAT_INT_BGRA,
	AK_COLORFORMAT_INT_ARGB,
	AK_COLORFORMAT_INT_ABGR,

	AK_COLORFORMAT_BYTE_RGBA,
	AK_COLORFORMAT_BYTE_BGRA,
	AK_COLORFORMAT_BYTE_ARGB,
	AK_COLORFORMAT_BYTE_ABGR,
	AK_COLORFORMAT_BYTE_RGB,
	AK_COLORFORMAT_BYTE_BGR,

	AK_COLORFORMAT_SHORT_ARGB_4444,
	AK_COLORFORMAT_SHORT_RGB_565,

	AK_COLORFORMAT_MAX
} AKColorFormat;

/*-------------------------------------------------------------------------
 * Image class.
 *-----------------------------------------------------------------------*/

typedef struct AKImage_s
{
	HGint32			width;
	HGint32			height;
	HGint32			format; /*!< AKColorFormat */
	HGint32			stride;
	HGuint8*		data;	/*!< Points to the pixel at (0, 0). This might not be the start of the memory block. */
} AKImage;

HG_HEADER_CT_ASSERT(AKIMAGE_H, sizeof(AKImage) == 5 * 4);

/*-------------------------------------------------------------------------
 * Image methods.
 *-----------------------------------------------------------------------*/

HG_EXTERN_C_BLOCK_BEGIN

int					akGetColorFormatPixelBytes	(AKColorFormat format);
AKColorFormat		akCanonizeColorFormat		(AKColorFormat format);
HGuint32			akGetColorARGB				(AKColorFormat format, const HGuint8* p);
void				akSetColorARGB				(AKColorFormat format, HGuint8* p, HGuint32 argb);

/* Creates image with its own buffer and stride = width * bpp. AKImage.data points to the start of the memory block. */
AKImage*			AKImage_createBlank			(int width, int height, AKColorFormat format);

/* Creates image with its own buffer and stride = -width * bpp. AKImage.data does NOT point to the start of the memory block. */
AKImage*			AKImage_createBlankDownUp	(int width, int height, AKColorFormat format);

/* Creates image that refers to the given external buffer. */
AKImage*			AKImage_createForBuffer		(int width, int height, AKColorFormat format, int stride, void* data);

/* Same as createBlank(), but copies the data from the given external buffer. */
AKImage*			AKImage_createFromBuffer	(int width, int height, AKColorFormat format, int stride, const void* data);

/* Creates image as a copy from another image. */
AKImage* 			AKImage_createCopy			(AKColorFormat format, const AKImage* src);

void				AKImage_destroy				(AKImage* image);

HG_INLINE HGuint8*	AKImage_getRowPtr			(const AKImage* image, int y)					{ AK_ASSERT(image); return image->data + y * image->stride; }
HG_INLINE HGuint8*	AKImage_getPixelPtr			(const AKImage* image, int x, int y)			{ AK_ASSERT(image); return image->data + x * akGetColorFormatPixelBytes((AKColorFormat)image->format) + y * image->stride; }
HG_INLINE HGuint32	AKImage_getPixelARGB		(const AKImage* image, int x, int y)			{ AK_ASSERT(image); return akGetColorARGB((AKColorFormat)image->format, AKImage_getPixelPtr(image, x, y)); }
HG_INLINE void		AKImage_setPixelARGB		(AKImage* image, int x, int y, HGuint32 argb)	{ AK_ASSERT(image); akSetColorARGB((AKColorFormat)image->format, AKImage_getPixelPtr(image, x, y), argb); }
void				AKImage_copyConvert			(AKImage* dst, const AKImage* src, int dx, int dy, int sx, int sy, int w, int h);
HG_INLINE void		AKImage_copyConvertFull		(AKImage* dst, const AKImage* src)				{ AK_ASSERT(dst && src && dst->width == src->width && dst->height == src->height); AKImage_copyConvert(dst, src, 0, 0, 0, 0, src->width, src->height); }



HG_EXTERN_C_BLOCK_END

/*----------------------------------------------------------------------*/
#endif /* __AKIMAGE_H */
