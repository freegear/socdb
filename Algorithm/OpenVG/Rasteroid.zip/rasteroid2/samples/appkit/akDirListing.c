/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akDirListing.c#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include "akDirListing.h"
#include "akUtils.h"

#include <stdlib.h>

 /*-------------------------------------------------------------------------
 * AKDirListing private methods.
 *-----------------------------------------------------------------------*/

HG_STATICF void	AKDirListing_validateLast	(AKDirListing* dir);

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKDirEntry* AKDirEntry_create (void)
{
	AKDirEntry* entry = malloc(sizeof(AKDirEntry));
	if (!entry)
		return 0;

	akCopyString(entry->filename, "");
	entry->flags = 0;
	entry->next = NULL;

	return entry;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKDirEntry_destroy (AKDirEntry* entry)
{
	AK_ASSERT(entry);
	free(entry);
}

/*-------------------------------------------------------------------------
 * AKDirListing class.
 *-----------------------------------------------------------------------*/

struct AKDirListing_s
{
	AKDirEntry* first;
	AKDirEntry* last;
};

HG_CT_ASSERT(sizeof(AKDirListing) == 2 * 4);

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKDirListing* AKDirListing_create (void)
{
	AKDirListing* dir = malloc(sizeof(AKDirListing));
	if (!dir)
		return NULL;

	dir->first = NULL;
	dir->last = NULL;

	return dir;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKDirListing_destroy (AKDirListing* dir)
{
	AK_ASSERT(dir);

	{
		AKDirEntry* entry = dir->first;
		while (entry)
		{
			AKDirEntry* next = entry->next;
			AKDirEntry_destroy(entry);
			entry = next;
		}
	}

	free(dir);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKDirListing_pushBack (AKDirListing* dir, AKDirEntry* entry)
{
	AK_ASSERT(dir && entry);

	if (!dir->first)
	{
		AK_ASSERT(!dir->last);
		dir->first = entry;
		dir->last = entry;
	}
	else
	{
		AK_ASSERT(dir->last);
		dir->last->next = entry;
		dir->last = entry;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKDirEntry* AKDirListing_getFirst (AKDirListing* dir)
{
	AK_ASSERT(dir);
	return dir->first;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 AKDirListing_getCount (AKDirListing* dir)
{
	AK_ASSERT(dir);
	{
		AKDirEntry* entry	= dir->first;
		HGuint32 count		= 0;
		while (entry)
		{
			count++;
			entry = entry->next;
		}
		return count;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKDirEntry* AKDirListing_getByIndex (AKDirListing* dir, HGuint32 index)
{
	AK_ASSERT(dir);
	{
		AKDirEntry* entry = dir->first;
		while (entry && index)
		{
			index--;
			entry = entry->next;
		}
		return entry;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	This method removes files which do not apply to the type listing.
 * \note [aarni 01/12/05] It sure would be easier to create a new dir
 *						listing and push those remaining entries into it,
 *						but I made it by the hard way already and it's working.
 *//*-------------------------------------------------------------------*/

void AKDirListing_filterByType (AKDirListing* dir, const char* type, HGbool keepDirectories)
{
	AK_ASSERT(dir && type);
	{
		AKDirEntry* last	= NULL;
		AKDirEntry* entry	= dir->first;

		char* modType		= akDuplicateString(type);
		if (!modType)
			return;

		{
			HGint32 i			= 0;
			HGint32 typeCount	= akStringCountChars(type, ",") + 1;
			char** typeList		= malloc(sizeof(char*) * typeCount);

			if (typeList)
			{
				for (i = 0; i < typeCount; i++)
					typeList[i] = NULL;

				akReplaceSingleCharsN(modType, ",", "\0", 1);

				{
					char* modTypePos = modType;
					for (i = 0; i < typeCount; i++)
					{
						typeList[i] = akDuplicateString(modTypePos);
						if (!typeList[i])
							break;
						akAdvanceString(&modTypePos, '\0');
						modTypePos++;								/* Skip \0 */
					}
				}

				while (entry)
				{
					char* entryType = entry->filename;
					HGbool found	= HG_FALSE;

					if (!(entry->flags & AK_DIRENTRY_FLAGS_DIR))	/* Filter files only. */
					{
						akAdvanceString(&entryType, '.');
						entryType++;								/* Skip character: '.' */

						for (i = 0; i < typeCount; i++)
							if (akCompareStrings(entryType, typeList[i]))
							{
								found = HG_TRUE;
								break;
							}
					}
					else
					{
						found = keepDirectories;
					}

					if (!found)
					{				/* After this deletion, dir->last might not be valid anymore. */
						if (last)
						{
							last->next = entry->next;
							AKDirEntry_destroy(entry);
							entry = last->next;
						}
						else
						{
							dir->first = entry->next;
							AKDirEntry_destroy(entry);
							entry = dir->first;
						}
					}
					else
					{
						last = entry;
						entry = entry->next;
					}
				}

				while (typeCount-- > 0)
					free(typeList[typeCount]);
				free(typeList);
			}
		}

		free(modType);
	}
	AKDirListing_validateLast(dir);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKDirListing_moveDirectoriesTop (AKDirListing* dir)
{
	AK_ASSERT(dir);
	{
		AKDirEntry* firstDir = NULL;
		AKDirEntry* lastDir = NULL;
		AKDirEntry* entry = dir->first;
		AKDirEntry* last = NULL;

		while (entry)
		{
			AKDirEntry* nextEntry = entry->next;

			if (entry->flags & AK_DIRENTRY_FLAGS_DIR)
			{
				/* Remove entry from the list. */
				if (last)
					last->next = nextEntry;
				else
					dir->first = nextEntry;

				entry->next = NULL;

				/* Add entry to the dir list. */
				if (lastDir)
				{
					lastDir->next = entry;
					lastDir = lastDir->next;
				}
				else
				{
					firstDir = entry;
					lastDir = firstDir;
				}
			}
			else
			{
				last = entry;
			}

			entry = nextEntry;
		}

		if (lastDir)
		{
			lastDir->next = dir->first;
			dir->first = firstDir;
		}
	}
	AKDirListing_validateLast(dir);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Makes sure that dirlisting's last entry is valid.
 *//*-------------------------------------------------------------------*/

void AKDirListing_validateLast (AKDirListing* dir)
{
	AK_ASSERT(dir);
	{
		AKDirEntry* entry = dir->first;
		AKDirEntry* last = NULL;
		while (entry)
		{
			last = entry;
			entry = entry->next;
		}
		if (last)
			dir->last = last;
		else
			dir->last = dir->first; /* List has one entry or none. */
	}
}

/*----------------------------------------------------------------------*/
