/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akBmp.c#2 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include "akBmp.h"
#include "akUtils.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*-------------------------------------------------------------------------
 * Windows RGB Quad struct
 *-----------------------------------------------------------------------*/

typedef struct akRGBQuad_s {
    HGuint8    rgbBlue; 
    HGuint8    rgbGreen; 
    HGuint8    rgbRed; 
    HGuint8    rgbReserved; 
} akRGBQuad; 

HG_CT_ASSERT(sizeof(akRGBQuad) == 4);

/*-------------------------------------------------------------------------
 * BMP Header.
 *-----------------------------------------------------------------------*/

typedef struct AKBmpHeader_s
{
	HGuint16	pad;				/* ignored */
	HGuint8		type[2];			/* BM */
 	HGuint32	size;				/* bmp file's size */
	HGuint32	reserved;			/* 0 */
	HGuint32	offset;				/* offset to bitmap data. header 14 + info 40 = 54 */
} AKBmpHeader;

HG_CT_ASSERT(sizeof(AKBmpHeader) == 16);

HG_STATICF void		AKBmpHeader_clear		(AKBmpHeader* header);

/*-------------------------------------------------------------------------
 * BMP Info.
 *-----------------------------------------------------------------------*/

typedef struct AKBmpInfo_s
{
	HGuint32	infoSize;			/* 40 */
	HGuint32	width;
	HGint32		height;					/* Can be negative */
	HGuint16	planes;				/* 1 */
	HGuint16	bitDepth;			/* 24 */
	HGuint32	compression;		/* 0 = no compression. */
	HGuint32	imageSize;			/* If there is no compression, it is valid to set this member to zero. */
	HGuint32	pixelsPerMeterX;	/* 0 */
	HGuint32	pixelsPerMeterY;	/* 0 */
	HGuint32	colorsUsed;			/* 0 */
	HGuint32	importantColor;		/* 0 */
} AKBmpInfo;

HG_CT_ASSERT(sizeof(AKBmpInfo) == 40);

HG_STATICF void		AKBmpInfo_clear			(AKBmpInfo* info);

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKBmpHeader_clear (AKBmpHeader* header)
{
	header->pad			= 0;
	header->type[0]		= 'B';
	header->type[1]		= 'M';
	header->size		= 0;
	header->reserved	= 0;
	header->offset		= 0;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKBmpInfo_clear (AKBmpInfo* info)
{
	info->infoSize			= sizeof(AKBmpInfo);
	info->width				= 0;
	info->height			= 0;
	info->planes			= akGetLittleEndianUInt16(1);
	info->bitDepth			= akGetLittleEndianUInt16(24);
	info->compression		= 0;
	info->imageSize			= 0;
	info->pixelsPerMeterX	= 0;
	info->pixelsPerMeterY	= 0;
	info->colorsUsed		= 0;
	info->importantColor	= 0;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akExportBmpImage (AKAppKit* ak, const char* filename, AKImage* image)
{
	FILE*		f;
	HGuint32	rowSize	= ((image->width * 3 + 3) & -4);
	HGuint32	offset	= sizeof(AKBmpHeader) - 2 /* remove padding bytes */ + sizeof(AKBmpInfo);
	AKBmpHeader	header;
	AKBmpInfo	info;
	HGuint8*	rowBuf;
	int			y;

	AK_ASSERT(ak && filename && image);
	HG_UNREF(ak);

	f = fopen(filename, "wb");
	if (!f)
		return HG_FALSE;	/* File open failed. */

	AKBmpHeader_clear(&header);
	AKBmpInfo_clear(&info);

	header.offset = akGetLittleEndianUInt32(offset);
	header.size = akGetLittleEndianUInt32(rowSize * image->height + offset);

	fwrite(((HGuint8*)&header) + 2 /* padding */, sizeof(AKBmpHeader) - 2 /* padding */, 1, f);

	info.width = akGetLittleEndianUInt32(image->width);
	info.height = akGetLittleEndianUInt32(image->height);

	fwrite(&info, sizeof(AKBmpInfo), 1, f);

	rowBuf = malloc(rowSize);
	if (!rowBuf)
	{
		fclose(f);
		return HG_FALSE;
	}

	for (y = image->height - 1; y >= 0; y--)
	{
		HGuint8*	p = rowBuf;
		int			x;

		for (x = 0; x < image->width; x++)
		{
			HGuint32 argb = AKImage_getPixelARGB(image, x, y);
			*p++ = (HGuint8)(argb >> 0);
			*p++ = (HGuint8)(argb >> 8);
			*p++ = (HGuint8)(argb >> 16);
		}

		fwrite(rowBuf, 1, rowSize, f);
	}

	fclose(f);
	free(rowBuf);
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akExportBmpBuffer (AKAppKit* ak, const char* filename, int width, int height, AKColorFormat format, int stride, const void* data)
{
	AKImage*	image;
	HGbool		ok = HG_FALSE;
	AK_ASSERT(ak && data && filename);

	image = AKImage_createFromBuffer(width, height, format, stride, data);
	if (image)
	{
		ok = akExportBmpImage(ak, filename, image);
		AKImage_destroy(image);
	}
	return ok;
}



/*-------------------------------------------------------------------*//*!
 * \brief
 *		loads a BMP file
 *		supports non-RLE-compressed files of 
 *			1, 2, 4, 8 & 24 bits-per-pixel
 * \param	ak			appkit context
 * \param	filename	fullpath to bmp to be loaded
 * \return	pointer to a new AKImage
 * \TODO:	Support for RLE compressed bmps
 *//*-------------------------------------------------------------------*/


AKImage* akImportBmpImage (AKAppKit* ak, const char* filename)
{
	AKBmpHeader bmfh;
	AKBmpInfo bmih;
	FILE* f;
	HGuint8* buf;
	HGuint16 bpp;
	HGint32 width;
	HGint32 height;
	HGint32 bytesPerRow;
	akRGBQuad*	palette =HG_NULL;
	AKImage*	result = HG_NULL;
	AKBmpInfo* pbmi;

	AK_ASSERT(ak && filename);
	HG_UNREF(ak);

	f = fopen(filename, "rb");
	if (!f)
		return HG_NULL;
	buf = (HGuint8*)malloc(sizeof(AKBmpHeader)-2);
	if (!buf)
	{
		fclose(f);
		return HG_NULL;
	}
	/* Load bitmap fileheader */
	if (fread((void*)buf,sizeof(AKBmpHeader)-2,1,f) != 1)
	{	
		fclose(f);
		free(buf);
		return HG_NULL;
	}

	/* Load bitmap infoheader */
	if (fread((void*)&bmih,1,sizeof(AKBmpInfo),f) != sizeof(AKBmpInfo))
	{
		fclose(f);
		free(buf);
		return HG_NULL;
	}
	memset(&bmfh,0,sizeof(AKBmpHeader));
	memcpy(((HGuint8*)&bmfh)+2,buf,sizeof(AKBmpHeader)-2);
	free(buf);
	buf = HG_NULL;
	/* Convert to machine endianess */
	bmfh.size = akGetLittleEndianUInt32(bmfh.size);
	bmfh.offset = akGetLittleEndianUInt32(bmfh.offset);
	/* Check filetype signature */
	if (bmfh.type[0] != 'B' || bmfh.type[1] != 'M')
	{
		fclose(f);
		return HG_NULL;		/* not BMP */
	}

	/* Convert to machine endianess */
	bmih.infoSize = akGetLittleEndianUInt32(bmih.infoSize);			/* 40 */
	bmih.width = akGetLittleEndianUInt32(bmih.width);
	bmih.height = akGetLittleEndianUInt32(bmih.height);					/* Can be negative */
	bmih.planes = akGetLittleEndianUInt16(bmih.planes);				/* 1 */
	bmih.bitDepth = akGetLittleEndianUInt16(bmih.bitDepth);			/* 24 */
	bmih.compression = akGetLittleEndianUInt32(bmih.compression);		/* 0 = no compression. */
	bmih.imageSize = akGetLittleEndianUInt32(bmih.imageSize);			/* If there is no compression, it is valid to set this member to zero. */
	bmih.pixelsPerMeterX = akGetLittleEndianUInt32(bmih.pixelsPerMeterX);	/* 0 */
	bmih.pixelsPerMeterY = akGetLittleEndianUInt32(bmih.pixelsPerMeterY);	/* 0 */
	bmih.colorsUsed = akGetLittleEndianUInt32(bmih.colorsUsed);			/* 0 */
	bmih.importantColor = akGetLittleEndianUInt32(bmih.importantColor);		/* 0 */
	
	bpp=bmih.bitDepth;
	width=bmih.width;
	height= (bmih.height>0) ? bmih.height : -(HGint32)(bmih.height);
	bytesPerRow = width * bpp / 8;
	bytesPerRow += (4-bytesPerRow%4) % 4;	/* 4-byte alignment */

	/* If bits per pixel isn't 24, load Palette: */
	if (bpp==24) 
		pbmi=(AKBmpInfo*)malloc(sizeof(AKBmpInfo));
	else
	{
		pbmi=(AKBmpInfo*) malloc(sizeof(AKBmpInfo)+(1<<bpp)*sizeof(akRGBQuad));
		palette=(akRGBQuad*)((char*)pbmi+sizeof(AKBmpInfo));
		/* Read palette to palette variable (inside pbmi struct) */
		if (!pbmi || fread(palette,sizeof(HGuint8),sizeof (akRGBQuad) * (1<<bpp),f) != sizeof (akRGBQuad) * (1<<bpp))
		{
			if (pbmi)
				free(pbmi);
			fclose(f);
			return HG_NULL;
		}
	}
	if (!pbmi)
	{
		fclose(f);
		return HG_NULL;
	}
	/* Seek to data */
	fseek(f, bmfh.offset, SEEK_SET);

	/* Create Image */
	result = AKImage_createBlank(width,height,AK_COLORFORMAT_BYTE_RGBA);
	if (!result)
	{
		free(pbmi);
		fclose(f);
		return HG_NULL;
	}

	buf = (HGuint8*) malloc(bytesPerRow);
	if (!buf)
	{
		AKImage_destroy(result);
		free(pbmi);
		fclose(f);
		return HG_NULL;
	}
	/* if height is positive the bmp is bottom-up, read it reversed */
	{
		HGint32 i;
		HGint32 j;
		HGuint32 argb;
		for (i=0;i<height;i++)
		{

			HGuint8* src = buf;
			/* Set y pixel coordinate according to mirroring */
			HGint32 y = bmih.height > 0 ? height - i - 1 : i;
			/* Read one row of pixels to buf */
			if (fread(buf,sizeof(HGuint8),bytesPerRow,f) != (HGuint32)bytesPerRow)
			{
				if(ferror(f)) 
					y += 1;
				if (feof(f))
					y -= 1;
				AKImage_destroy(result);
				free(pbmi);
				fclose(f);
				free(buf);
				return HG_NULL;
			}
			/* Loop through pixels */
			for (j=0;j<width;j++)
			{
				argb = (HGuint32)(0xff << 24);
				if (bpp == 24)
				{
					/* Read pixel data straight from 24bpp buf */
					argb |= (HGuint32)(*src++) << 0;
					argb |= (HGuint32)(*src++) << 8;
					argb |= (HGuint32)(*src++) << 16;
				}
				else
				{
					/* Fetch RGB-values from palette */
					akRGBQuad rgb = palette[buf[j]];
					AK_ASSERT(palette);
					argb |= rgb.rgbBlue  << 0;
					argb |= rgb.rgbGreen << 8;
					argb |= rgb.rgbRed   << 16;
				}
				AKImage_setPixelARGB(result,j,y, argb);
			}
		}
	}
	/* Done - free buffers and close bmp-file and return result */
	free(pbmi);
	fclose(f);
	free(buf);
	return result;
}


/*-------------------------------------------------------------------*//*!
 * \brief
 *		loads a BMP file to an existing AKImage
 *		supports non-RLE-compressed files of 
 *			1, 2, 4, 8 & 24 bits-per-pixel
 * \param	image		Image where to import the bmp
 * \param	ak			appkit context
 * \param	filename	fullpath to bmp to be loaded
 * \param	image		image to write the pixels to
 * \return	Boolean indicating successful import
 *
 * \TODO:	Support for RLE compressed bmps
 * \TODO:	Rename function
 *//*-------------------------------------------------------------------*/

HGbool akImportBmpImageB (AKAppKit* ak, const char* filename, AKImage* image)
{
	AKBmpHeader bmfh;
	AKBmpInfo bmih;
	FILE* f;
	HGuint8* buf;
	HGuint16 bpp;
	HGint32 width;
	HGint32 height;
	HGint32 bytesPerRow;
	akRGBQuad*	palette =HG_NULL;
	AKBmpInfo* pbmi;

	AK_ASSERT(ak && filename && image);
	HG_UNREF(ak);

	f = fopen(filename, "rb");
	if (!f)
		return HG_FALSE;
	buf = (HGuint8*)malloc(sizeof(AKBmpHeader)-2);
	if (!buf)
	{
		fclose(f);
		return HG_FALSE;
	}
	/* Load bitmap fileheader */
	if (fread((void*)buf,sizeof(AKBmpHeader)-2,1,f) != 1)
	{	
		fclose(f);
		free(buf);
		return HG_FALSE;
	}

	/* Load bitmap infoheader */
	if (fread((void*)&bmih,1,sizeof(AKBmpInfo),f) != sizeof(AKBmpInfo))
	{
		fclose(f);
		free(buf);
		return HG_FALSE;
	}
	memset(&bmfh,0,sizeof(AKBmpHeader));
	memcpy(((HGuint8*)&bmfh)+2,buf,sizeof(AKBmpHeader)-2);
	free(buf);
	buf = HG_NULL;
	/* Check filetype signature */
	if (bmfh.type[0] != 'B' || bmfh.type[1] != 'M')
	{
		fclose(f);
		return HG_FALSE;		/* File is not BMP */
	}
	bpp=bmih.bitDepth;
	width=bmih.width;
	height= (bmih.height>0) ? bmih.height : -(HGint32)(bmih.height); 
	bytesPerRow = width * bpp / 8;
	bytesPerRow += (4-bytesPerRow%4) % 4;	/* 4-byte alignment */

	/* If bits per pixel isn't 24, load Palette: */
	if (bpp==24) 
		pbmi=(AKBmpInfo*)malloc(sizeof(AKBmpInfo));
	else
	{
		pbmi=(AKBmpInfo*) malloc(sizeof(AKBmpInfo)+(1<<bpp)*sizeof(akRGBQuad));
		palette=(akRGBQuad*)((char*)pbmi+sizeof(AKBmpInfo));
		/* Read palette to palette variable (inside pbmi struct) */
		if (!pbmi || fread(palette,sizeof(HGuint8),sizeof (akRGBQuad) * (1<<bpp),f) != sizeof (akRGBQuad) * (1<<bpp))
		{
			if (pbmi)
				free(pbmi);
			fclose(f);
			return HG_FALSE;
		}
	}
	if (!pbmi)
	{
		fclose(f);
		return HG_FALSE;
	}

	buf = (HGuint8*) malloc(bytesPerRow);
	if (!buf)
	{
		free(pbmi);
		fclose(f);
		return HG_FALSE;
	}

	fseek(f, bmfh.offset, SEEK_SET);

	/* if height is positive the bmp is bottom-up, read it reversed */
	{
		HGint32 i;
		HGint32 j;
		HGuint32 argb;
		for (i=0;i<height;i++)
		{

			HGuint8* src = buf;
			/* Set y pixel coordinate according to mirroring */
			HGint32 y = bmih.height > 0 ? height - i - 1 : i;
			/* Read one row of pixels to buf */
			if (fread(buf,sizeof(HGuint8),bytesPerRow,f) != (HGuint32)bytesPerRow)
			{
				if(ferror(f)) 
					y += 1;
				if (feof(f))
					y -= 1;
				free(pbmi);
				fclose(f);
				free(buf);
				return HG_FALSE;
			}
			/* Loop through pixels */
			for (j=0;j<width;j++)
			{
				argb = (HGuint32)(0xff << 24);
				if (bpp == 24)
				{
					/* Read pixel data straight from 24bpp buf */
					argb |= (HGuint32)(*src++) << 0;
					argb |= (HGuint32)(*src++) << 8;
					argb |= (HGuint32)(*src++) << 16;
				}
				else
				{
					/* Fetch RGB-values from palette */
					akRGBQuad rgb = palette[buf[j]];
					AK_ASSERT(palette);
					argb |= rgb.rgbBlue  << 0;
					argb |= rgb.rgbGreen << 8;
					argb |= rgb.rgbRed   << 16;
				}
				if (image->height > y && image->width > j)
					AKImage_setPixelARGB(image,j,y, argb);
			}
		}
	}
	/* Done - free buffers and close bmp-file and return result */
	free(pbmi);
	fclose(f);
	free(buf);
	return HG_TRUE;

}



/*----------------------------------------------------------------------*/
