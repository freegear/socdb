/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akWin32Main.c#2 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include "akMain.h"
#include "akUtils.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#define _WIN32_WINNT 0x0400
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#if defined(HG_DEVEL) && (HG_COMPILER == HG_COMPILER_MSC)
#	define AK_SHOW_MEMORY_SIZE
#endif

#if (HG_COMPILER == HG_COMPILER_MSC)
#	include <crtdbg.h>
#endif

/*-------------------------------------------------------------------------
 * AppKit Win32 context.
 *-----------------------------------------------------------------------*/

typedef struct AKWin32Context_s
{
	AKAppKit*				ak;
	HWND					window;

	LARGE_INTEGER			perfCtrFreq;
	LARGE_INTEGER			perfCtrStart;

	HGint32					dragCount;
	HGint32					wheelAcc;
	HGbool					altDown;

	HGint32					bufFormatHint;	/* AKColorFormat */
	HDC						bufDC;
	AKImage*				bufImage;
	HBITMAP					bufDIB;
} AKWin32Context;

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF HGint32 translateUnicodeKey (DWORD vkey)
{
	HGint32 code = MapVirtualKeyW(vkey, 2);

	/* Translate dead keys to combining marks. */

	switch (code)
	{
	case 0x80000060: code = 0x0300; break;
	case 0x800000B4: code = 0x0301; break;
	case 0x8000005E: code = 0x0302; break;
	case 0x8000007E: code = 0x0303; break;
	case 0x800000AF: code = 0x0304; break;
	case 0x800002D8: code = 0x0306; break;
	case 0x800002D9: code = 0x0307; break;
	case 0x800000A8: code = 0x0308; break;
	case 0x800002DA: code = 0x030A; break;
	case 0x800002DD: code = 0x030B; break;
	case 0x800002C7: code = 0x030C; break;
	case 0x800000B8: code = 0x0327; break;
	case 0x800002DB: code = 0x0328; break;
	case 0x8000037A: code = 0x0345; break;
	case 0x8000309B: code = 0x3099; break;
	case 0x8000309C: code = 0x309A; break;
	default: break;
	}

	return code;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF const char* translateSpecialKey (DWORD vkey)
{
	switch (vkey)
	{
	case VK_ACCEPT:		return "Accept";		/* Commit */
	case VK_MENU:		return "Alt";			/* Menu */
	case VK_APPS:		return "Apps";			/* Application */
	case VK_ATTN:		return "Attn";
	case VK_CAPITAL:	return "CapsLock";		/* Capital */
	case VK_CLEAR:
	case VK_OEM_CLEAR:	return "Clear";
	case VK_CONTROL:	return "Control";		/* Ctrl */
	case VK_CRSEL:		return "Crsel";
	case VK_CONVERT:	return "Convert";
	case VK_DOWN:		return "Down";			/* Arrow */
	case VK_END:		return "End";
	case VK_RETURN:		return "Enter";			/* Return */
	case VK_EREOF:		return "EraseEof";
	case VK_EXECUTE:	return "Execute";
	case VK_EXSEL:		return "Exsel";
	case VK_F1:			return "F1";
	case VK_F2:			return "F2";
	case VK_F3:			return "F3";
	case VK_F4:			return "F4";
	case VK_F5:			return "F5";
	case VK_F6:			return "F6";
	case VK_F7:			return "F7";
	case VK_F8:			return "F8";
	case VK_F9:			return "F9";
	case VK_F10:		return "F10";
	case VK_F11:		return "F11";
	case VK_F12:		return "F12";
	case VK_F13:		return "F13";
	case VK_F14:		return "F14";
	case VK_F15:		return "F15";
	case VK_F16:		return "F16";
	case VK_F17:		return "F17";
	case VK_F18:		return "F18";
	case VK_F19:		return "F19";
	case VK_F20:		return "F20";
	case VK_F21:		return "F21";
	case VK_F22:		return "F22";
	case VK_F23:		return "F23";
	case VK_F24:		return "F24";
	case VK_FINAL:		return "FinalMode";		/* (Asian) */
	case VK_HELP:		return "Help";
	case VK_HOME:		return "Home";
	case VK_INSERT:		return "Insert";		/* Ins */
	case VK_JUNJA:		return "JunjaMode";
	case VK_KANA:		return "KanaMode";		/* Kana lock */
	case VK_KANJI:		return "KanjiMode";		/* (Japanese) */
	case VK_LEFT:		return "Left";			/* Arrow */
	case VK_MODECHANGE:	return "ModeChange";
	case VK_NONCONVERT:	return "Nonconvert";	/* Don't convert */
	case VK_NUMLOCK:	return "NumLock";
	case VK_NEXT:		return "PageDown";		/* Next */
	case VK_PRIOR:		return "PageUp";		/* Prior */
	case VK_PAUSE:		return "Pause";
	case VK_PLAY:		return "Play";
	case VK_PRINT:
	case VK_SNAPSHOT:	return "PrintScreen";	/* SnapShot */
	case VK_PROCESSKEY:	return "Process";
	case VK_RIGHT:		return "Right";			/* Arrow */
	case VK_SCROLL:		return "Scroll";		/* Scroll lock */
	case VK_SELECT:		return "Select";
	case VK_SHIFT:		return "Shift";
	case VK_UP:			return "Up";			/* Arrow */
	case VK_LWIN:
	case VK_RWIN:		return "Win";			/* Windows logo */
	case VK_ZOOM:		return "Zoom";
	default:			return NULL;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF void handleMouseButton (AKWin32Context* ctx, HGbool down, const char* button)
{
	AK_ASSERT(ctx);

	if (down)
	{
		if (!ctx->dragCount)
			SetCapture(ctx->window);
		ctx->dragCount++;
	} else
	{
		ctx->dragCount--;
		if (!ctx->dragCount)
			ReleaseCapture();
	}

	AKAppKit_callKeyEvent(ctx->ak, down, button);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF LONG WINAPI windowProc (
	HWND	hWnd,
	UINT	uMsg,
	WPARAM	wParam,
	LPARAM	lParam)
{
	AKWin32Context* ctx = (AKWin32Context*)GetWindowLong(hWnd, GWL_USERDATA);
	if (!ctx)
		return DefWindowProc(hWnd, uMsg, wParam, lParam);

	switch (uMsg)
	{
	case WM_CLOSE:
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;

	case WM_KEYDOWN:
	case WM_KEYUP:
	case WM_SYSKEYDOWN:
	case WM_SYSKEYUP:
		{
			HGbool down = (uMsg == WM_KEYDOWN || uMsg == WM_SYSKEYDOWN);

			/* Quit on Alt-F4. */

			if (wParam == VK_MENU)
				ctx->altDown = down;
			if (wParam == VK_F4 && ctx->altDown)
				PostQuitMessage(0);

			/* Generate key event. */
			{
				const char* id = translateSpecialKey(wParam);
				if (id)
					AKAppKit_callKeyEvent(ctx->ak, down, id);
				else
				{
					HGint32 code = translateUnicodeKey(wParam);
					if (code)
					{
						char buf[11];
						sprintf(buf, "U+%04X", code);
						AKAppKit_callKeyEvent(ctx->ak, down, buf);
					}
				}
			}

			/* Generate character events. */
			{
				BYTE	keyState[256];
				WCHAR	buf[256];
				int		num;
				int		i;

				GetKeyboardState(keyState);
				num = ToUnicode(
					wParam,
					((lParam >> 16) & 0xff) | ((down) ? 0 : 0x8000),
					keyState,
					buf,
					HG_LENGTH_OF_ARRAY(buf),
					0);

				for (i = 0; i < num; i++)
					AKAppKit_callCharEvent(ctx->ak, buf[i]);
			}
		}
		return 0;

	case WM_MOUSEMOVE:
		AKAppKit_callPtrEvent(ctx->ak, HG_TRUE, (short)LOWORD(lParam), (short)HIWORD(lParam));
		{
			TRACKMOUSEEVENT track;
			track.cbSize = sizeof(TRACKMOUSEEVENT);
			track.dwFlags = TME_LEAVE;
			track.hwndTrack = ctx->window;
			track.dwHoverTime = HOVER_DEFAULT;
			TrackMouseEvent(&track);
		}
		return 0;

	case WM_MOUSELEAVE:
		AKAppKit_callPtrEvent(ctx->ak, HG_FALSE, 0, 0);
		return 0;

	case WM_LBUTTONDOWN:	handleMouseButton(ctx, HG_TRUE,		"!PtrLeft");	return 0;
	case WM_LBUTTONUP:		handleMouseButton(ctx, HG_FALSE,	"!PtrLeft");	return 0;
	case WM_RBUTTONDOWN:	handleMouseButton(ctx, HG_TRUE,		"!PtrRight");	return 0;
	case WM_RBUTTONUP:		handleMouseButton(ctx, HG_FALSE,	"!PtrRight");	return 0;
	case WM_MBUTTONDOWN:	handleMouseButton(ctx, HG_TRUE,		"!PtrMiddle");	return 0;
	case WM_MBUTTONUP:		handleMouseButton(ctx, HG_FALSE,	"!PtrMiddle");	return 0;

	case WM_MOUSEWHEEL:
		ctx->wheelAcc += (short)HIWORD(wParam);
		while (ctx->wheelAcc >= 120)
		{
			AKAppKit_callKeyEvent(ctx->ak, HG_TRUE, (const char*)"!WheelUp");
			AKAppKit_callKeyEvent(ctx->ak, HG_FALSE, (const char*)"!WheelUp");
			ctx->wheelAcc -= 120;
		}
		while (ctx->wheelAcc <= -120)
		{
			AKAppKit_callKeyEvent(ctx->ak, HG_TRUE, (const char*)"!WheelDown");
			AKAppKit_callKeyEvent(ctx->ak, HG_FALSE, (const char*)"!WheelDown");
			ctx->wheelAcc += 120;
		}
		return 0;

	default:
		break;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateWindow (AKAppKit* ak, HGuint32 width, HGuint32 height, const char* title, AKColorFormat bufFormatHint)
{
	AKWin32Context* ctx = AKAppKit_getContext(ak);
	AK_ASSERT(ak);
	AK_ASSERT(ctx);

	/* Register window class. */
	{
		WNDCLASS wndclass;

		wndclass.style		   = 0;
		wndclass.lpfnWndProc   = windowProc;
		wndclass.cbClsExtra    = 0;
		wndclass.cbWndExtra    = 0;
		wndclass.hInstance	   = (HINSTANCE)GetModuleHandle(NULL);
		wndclass.hIcon		   = LoadIcon(wndclass.hInstance, MAKEINTRESOURCE(101));
		wndclass.hCursor	   = LoadCursor(NULL, IDC_ARROW);
		wndclass.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
		wndclass.lpszMenuName  = NULL;
		wndclass.lpszClassName = "MainWndClass";

		if (!wndclass.hIcon)
			wndclass.hIcon = LoadIcon(NULL, IDI_EXCLAMATION);

		RegisterClass(&wndclass);
	}

	/* Create window. */

	ctx->window = CreateWindow(
		"MainWndClass",
		title,
		WS_OVERLAPPEDWINDOW,
		200, 200, 0, 0,
		NULL,
		NULL,
		(HINSTANCE)GetModuleHandle(NULL),
		NULL);

	akAdjustWindow(ctx->ak, width, height);

	if (!ctx->window)
		return HG_FALSE;

	/* Associate context with the window. */
	SetWindowLong(ctx->window, GWL_USERDATA, (LONG)ctx);
	ctx->bufFormatHint = bufFormatHint;
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akAdjustWindow (AKAppKit* ak, HGuint32 width, HGuint32 height)
{
	AK_ASSERT(ak);

	{
		AKWin32Context* ctx = (AKWin32Context*)AKAppKit_getContext(ak);
		AK_ASSERT(ctx);

		if (!ctx->window)
			return HG_FALSE;

		/* Resize window. */
		{
			RECT rc;

			rc.left		= 0;
			rc.top		= 0;
			rc.right	= width;
			rc.bottom	= height;

			AdjustWindowRect(&rc, GetWindowLong(ctx->window, GWL_STYLE), (GetMenu(ctx->window) != NULL));

			SetWindowPos(ctx->window, NULL, 0, 0, rc.right - rc.left, rc.bottom - rc.top,
				SWP_NOACTIVATE | SWP_NOCOPYBITS | SWP_NOMOVE | SWP_NOZORDER);
		}
	}
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akSetWindowTitle (AKAppKit* ak, const char* title)
{
	AK_ASSERT(ak);
	{
		AKWin32Context* ctx = AKAppKit_getContext(ak);
		AK_ASSERT(ctx);

		if (!ctx->window)
			return HG_FALSE;

		SetWindowText(ctx->window, title);
	}
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* akLockWindowBuffer (AKAppKit* ak)
{
	AKWin32Context*	ctx			= (AKWin32Context*)AKAppKit_getContext(ak);
	AKSurfaceDesc	surfDesc	= akGetSurface(ak);
	AK_ASSERT(ak && ctx);

	/* Destroy image if it's of wrong dimension. */

	if (ctx->bufImage && (ctx->bufImage->width != surfDesc.width || ctx->bufImage->height != surfDesc.height))
	{
		AKImage_destroy(ctx->bufImage);
		DeleteObject(ctx->bufDIB);
		ctx->bufImage = NULL;
		ctx->bufDIB = NULL;
	}

	/* Create device context if we don't have one. */

	if (!ctx->bufDC)
	{
		HDC winDC = GetDC(ctx->window);
		ctx->bufDC = CreateCompatibleDC(winDC);
		ReleaseDC(ctx->window, winDC);
		if (!ctx->bufDC)
			return NULL;
	}

	/* Create image if we don't have one. */

	if (!ctx->bufImage)
	{
		AKColorFormat	fmt		= akCanonizeColorFormat(ctx->bufFormatHint);
		void*			dataPtr	 = NULL;

		struct
		{
			BITMAPINFOHEADER	header;
			DWORD				rMask;
			DWORD				gMask;
			DWORD				bMask;
		} bmi;

		bmi.header.biSize			= sizeof(BITMAPINFOHEADER);
		bmi.header.biWidth			= surfDesc.width;
		bmi.header.biHeight			= -surfDesc.height;
		bmi.header.biPlanes			= 1;
		bmi.header.biBitCount		= (WORD)(akGetColorFormatPixelBytes(fmt) * 8);
		bmi.header.biCompression	= BI_BITFIELDS;

		switch (fmt)
		{
		case AK_COLORFORMAT_BYTE_RGBA:
			bmi.rMask = 0x000000ff;
			bmi.gMask = 0x0000ff00;
			bmi.bMask = 0x00ff0000;
			break;

		case AK_COLORFORMAT_BYTE_BGRA:
			bmi.rMask = 0x00ff0000;
			bmi.gMask = 0x0000ff00;
			bmi.bMask = 0x000000ff;
			break;

		case AK_COLORFORMAT_BYTE_ARGB:
			bmi.rMask = 0x0000ff00;
			bmi.gMask = 0x00ff0000;
			bmi.bMask = 0xff000000;
			break;

		case AK_COLORFORMAT_BYTE_ABGR:
			bmi.rMask = 0xff000000;
			bmi.gMask = 0x00ff0000;
			bmi.bMask = 0x0000ff00;
			break;

		default:
			fmt = AK_COLORFORMAT_BYTE_BGR;
			bmi.header.biBitCount = 24;
			bmi.header.biCompression = BI_RGB;
			break;
		}

		ctx->bufDIB = CreateDIBSection(ctx->bufDC, (BITMAPINFO*)&bmi, DIB_RGB_COLORS, &dataPtr, NULL, 0);
		if (!ctx->bufDIB)
			return NULL;

		ctx->bufImage = AKImage_createForBuffer(surfDesc.width, surfDesc.height, fmt,
			(surfDesc.width * bmi.header.biBitCount / 8 + 3) & -4, dataPtr);
		if (!ctx->bufImage)
		{
			DeleteObject(ctx->bufDIB);
			ctx->bufDIB = NULL;
			return NULL;
		}
	}
	return ctx->bufImage;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseWindowBuffer (AKAppKit* ak, AKImage* bufImage)
{
	AKWin32Context*	ctx		= (AKWin32Context*)AKAppKit_getContext(ak);
	HDC				winDC;

	AK_ASSERT(ak && bufImage && ctx);
	AK_ASSERT(bufImage == ctx->bufImage);

	HG_UNREF(bufImage);

	SelectObject(ctx->bufDC, ctx->bufDIB);
	winDC = GetDC(ctx->window);
	BitBlt(winDC, 0, 0, ctx->bufImage->width, ctx->bufImage->height, ctx->bufDC, 0, 0, SRCCOPY);
	ReleaseDC(ctx->window, winDC);
	SelectObject(ctx->bufDC, NULL);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akErrorMessage (AKAppKit* ak, const char* msg)
{
	AKWin32Context* ctx = (AKWin32Context*)AKAppKit_getContext(ak);
	AK_ASSERT(ak);
	MessageBox((HWND)ctx->window, msg, NULL, 0);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAbort (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	exit(1);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akRequestExit (AKAppKit* ak)
{
	AKWin32Context* ctx = (AKWin32Context*)AKAppKit_getContext(ak);
	AK_ASSERT(ak && ctx);
	SendMessage(ctx->window, WM_CLOSE, 0, 0);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akGetTime (AKAppKit* ak, HGuint32* hiMillis, HGuint32* loMillis)
{
	AKWin32Context*	ctx		= (AKWin32Context*)AKAppKit_getContext(ak);
	LARGE_INTEGER	perfCtr;
	__int64			millis;
	AK_ASSERT(ak && ctx);

	QueryPerformanceCounter(&perfCtr);
	millis = (__int64)((perfCtr.QuadPart - ctx->perfCtrStart.QuadPart) * 1000.0 / ctx->perfCtrFreq.QuadPart);
	*hiMillis = (HGuint32)(millis >> 32);
	*loMillis = (HGuint32)millis;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKSurfaceDesc akGetSurface (AKAppKit* ak)
{
	AKSurfaceDesc desc;
	AK_ASSERT(ak);

	{
		AKWin32Context* ctx = AKAppKit_getContext(ak);

		RECT rect;
		GetClientRect(ctx->window, &rect);

		desc.width = rect.right;
		desc.height = rect.bottom;
		desc.nativePtr = ctx->window;
	}

	return desc;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF void pushEntry (AKDirListing* dir, WIN32_FIND_DATA* fd)
{
	AK_ASSERT(dir && fd);

	if (akCompareStrings(fd->cFileName, ".") || akCompareStrings(fd->cFileName, ".."))
		return;

	{
		AKDirEntry* entry = AKDirEntry_create();
		if (!entry)
			return;

		if (fd->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			entry->flags |= AK_DIRENTRY_FLAGS_DIR;

		akCopyString(entry->filename, fd->cFileName);

		AKDirListing_pushBack(dir, entry);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKDirListing* akGetDirectoryListing (AKAppKit* ak, const char* path)
{
	AK_ASSERT(ak && path);
	HG_UNREF(ak);

	{
		AKDirListing* dir;
		WIN32_FIND_DATA fd;
		HANDLE h;
		char* fixedPath;

		fixedPath = akFixPath(path);
		if (!fixedPath)
			return NULL;

		/* Append wildcard to fixedPath. */
		akAppendString(&fixedPath, "*");
		if (!fixedPath)
			return NULL;

		dir = AKDirListing_create();
		if (!dir)
		{
			free(fixedPath);
			return NULL;
		}

		h = FindFirstFile(fixedPath, &fd);
		free(fixedPath);

		if (h == INVALID_HANDLE_VALUE)
		{
			AKDirListing_destroy(dir);
			return NULL;
		}

		pushEntry(dir, &fd);

		while (FindNextFile(h, &fd) != 0)
			pushEntry(dir, &fd);

		FindClose(h);

		return dir;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF DWORD WINAPI akThreadProc (LPVOID lpParameter)
{
	AK_ASSERT(lpParameter);
	AKAppKit_threadStarted((AKThreadParams*)lpParameter);
	return 0;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateThread (AKAppKit* ak, AKThreadParams* params)
{
	HANDLE	thread;
	DWORD	threadID;
	AK_ASSERT(ak && params);
	HG_UNREF(ak);

	thread = CreateThread(NULL, 0, akThreadProc, params, 0, &threadID);
	if (!thread)
		return HG_FALSE;
	CloseHandle(thread);
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akGetThreadID (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	return (HGuint32)GetCurrentThreadId();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void* akCreateSemaphore (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	return CreateSemaphore(NULL, 1, 1, NULL);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akDestroySemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	CloseHandle((HANDLE)semaphore);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAcquireSemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	WaitForSingleObject((HANDLE)semaphore, INFINITE);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseSemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	ReleaseSemaphore((HANDLE)semaphore, 1, NULL);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

#ifdef AK_SHOW_MEMORY_SIZE
HG_STATICF int numBytesAllocated (void)
{
#ifdef HG_DEBUG
	_CrtMemState state;
	_CrtMemCheckpoint(&state);
	return state.lSizes[_NORMAL_BLOCK] + state.lSizes[_CLIENT_BLOCK];
#else
	int num = 0;
	_HEAPINFO hinfo;
	hinfo._pentry = NULL;
	while (_heapwalk(&hinfo) == _HEAPOK)
		if (hinfo._useflag == _USEDENTRY)
			num += hinfo._size;
	return num;
#endif
}
#endif

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

int main (int argc, char** argv)
{
	AKWin32Context	ctx;

	SetPriorityClass(GetCurrentProcess(), IDLE_PRIORITY_CLASS);
	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_IDLE);

#if defined(HG_DEBUG) && (HG_COMPILER == HG_COMPILER_MSC)
	{
		int flag = 0;
		flag |= _CRTDBG_ALLOC_MEM_DF;			/* use allocation guards */
/*		flag |= _CRTDBG_CHECK_ALWAYS_DF;*/		/* check whole memory on each alloc */
/*		flag |= _CRTDBG_DELAY_FREE_MEM_DF;*/	/* keep freed memory and check that it isn't written */
		flag |= _CRTDBG_LEAK_CHECK_DF;			/* check memory leaks at program exit */
		_CrtSetDbgFlag(flag);
/*		_CrtSetBreakAlloc(3553);*/
		_CrtSetReportMode(_CRT_WARN, _CRTDBG_MODE_FILE);
		_CrtSetReportFile(_CRT_WARN, _CRTDBG_FILE_STDERR);
	}
#endif

	/* Create AppKit and set up context. */

	ctx.ak = AKAppKit_create(&ctx, argv, argc);
	if (!ctx.ak)
		return 1;

	ctx.window			= NULL;

	QueryPerformanceFrequency(&ctx.perfCtrFreq);
	QueryPerformanceCounter(&ctx.perfCtrStart);

	ctx.dragCount		= 0;
	ctx.wheelAcc		= 0;
	ctx.altDown			= HG_FALSE;

	ctx.bufFormatHint	= AK_COLORFORMAT_NONE;
	ctx.bufDC			= NULL;
	ctx.bufImage		= NULL;
	ctx.bufDIB			= NULL;

	/* Init application and run the message loop. */

	if (appInit(ctx.ak) && ctx.window)
	{
		ShowWindow(ctx.window, SW_SHOW);
		for (;;)
		{
			MSG msg;
			if (PeekMessage(&msg, NULL, 0, 0, TRUE))
			{
				DispatchMessage(&msg);
				if (msg.message == WM_QUIT)
					break;
			} else
				AKAppKit_callUpdate(ctx.ak);
		}
	}

#ifdef AK_SHOW_MEMORY_SIZE
	AKAppKit_printf(ctx.ak, "Bytes allocated: %d\n", numBytesAllocated());
#endif

	AKAppKit_destroy(ctx.ak);	/* Destroy AppKit (calls application's deinit). */

	if (ctx.bufDC)
		DeleteDC(ctx.bufDC);
	if (ctx.bufImage)
		AKImage_destroy(ctx.bufImage);
	if (ctx.window)
		DestroyWindow(ctx.window);
	return 0;
}

/*-----------------------------------------------------------------------*/
