/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akArg.c#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include "akArg.h"
#include "akUtils.h"

#include <stdlib.h>

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKArg* AKArg_create (char** data, HGuint32 count)
{
	AK_ASSERT(data && data[0]);
	{
		AKArg* arg = malloc(sizeof(AKArg));
		if (!arg)
			return NULL;

		arg->next = NULL;
		arg->valueCount = 0;
		arg->values = NULL;

		arg->name = akDuplicateString(data[0] + 1); /* Skip first character. */
		if (!arg->name)
		{
			AKArg_destroy(arg);
			return NULL;
		}

		if (count)
		{
			HGuint32 i;

			arg->values = malloc(sizeof(char*) * count);
			if (arg->values)
			{
				arg->valueCount = count;

				for (i = 0; i < count; i++)
					arg->values[i] = NULL;

				for (i = 0; i < count; i++)
				{
					arg->values[i] = akDuplicateString(data[i + 1]);
					if (!arg->values[i])
					{
						AKArg_destroy(arg);
						return NULL;
					}
				}
			}
			else
			{
				AKArg_destroy(arg);
				return NULL;
			}
		}

		return arg;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKArg_destroy (AKArg* arg)
{
	HGuint32 i;
	AK_ASSERT(arg);

	free(arg->name);

	for (i = 0; i < arg->valueCount; i++)
		free(arg->values[i]);
	free(arg->values);

	free(arg);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKArg_destroyList (AKArg* firstArg)
{
	AKArg* current = firstArg;
	while (current)
	{
		AKArg* next = current->next;
		AKArg_destroy(current);
		current = next;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKArg_addToList (AKArg** firstArg, AKArg* nArg)
{
	nArg->next = *firstArg;
	*firstArg = nArg;
}

/*----------------------------------------------------------------------*/
