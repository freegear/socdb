/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akAppKit.c#2 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include "akAppKitPrivate.h"
#include "akMain.h"
#include "akUtils.h"
#include "akImage.h"
#include "akBmp.h"
#include "akTga.h"

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

/*-------------------------------------------------------------------*//*!
 * AKAppKit class.
 *//*-------------------------------------------------------------------*/

struct AKAppKit_s
{
	AKAppKitParams				params;		/* Parameters provided by the application. */
	AKArg*						args;		/* Command line arguments. */
	void*						ctx;

	HGbool						updateCalled;
	HGint32						currTime;
	HGint32						currWidth;
	HGint32						currHeight;
	
	char						msgBuffer[1024];
								
	HGint32						userBufFormat; /* AKColorFormat */
	AKImage*					userBufImage;
	AKImage*					nativeBufImage;

	HGuint32					mainThread;
	AKMonitor*					monitor;
};

HG_CT_ASSERT(sizeof(AKAppKit) == 1 * sizeof(AKAppKitParams)
							   + 1024
							   + 11 * 4);

/*-------------------------------------------------------------------*//*!
 * AKMonitor class.
 *//*-------------------------------------------------------------------*/

struct AKMonitor_s
{
	AKAppKit*					appkit;
	void*						enterSem;
	void*						ownerSem;
	void*						waitSem;
	void*						notifySem;
	volatile HGuint32			ownerThread;
	volatile HGint32			enterCount;
	volatile HGint32			waitCount;
};

HG_CT_ASSERT(sizeof(AKMonitor) == 8 * 4);

/*-------------------------------------------------------------------*//*!
 * AKThreadParams class.
 *//*-------------------------------------------------------------------*/

struct AKThreadParams_s
{
	AKAppKit*					appkit;
	AKAppKit_threadFunc			userFunc;
	void*						userParam;
	void*						waitSem;
};

HG_CT_ASSERT(sizeof(AKThreadParams) == 4 * 4);

/*-------------------------------------------------------------------*//*!
 * AKAppKit private methods.
 *//*-------------------------------------------------------------------*/

HG_INLINE void		AKAppKit_enter			(AKAppKit* ak);
HG_INLINE void		AKAppKit_leave			(AKAppKit* ak);
HG_STATICF void		AKAppKit_formatMessage	(AKAppKit* ak, const char* format, va_list args);
HG_STATICF HGbool	AKAppKit_initArgs		(AKAppKit* ak, char** argv, HGuint32 argc);

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKitParams_clear (AKAppKitParams* params)
{
	params->deinit			= NULL;

	params->surfaceChanged	= NULL;

	params->keyEvent		= NULL;
	params->charEvent		= NULL;
	params->ptrEvent		= NULL;

	params->update			= NULL;

	params->userPtr			= NULL;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKAppKit* AKAppKit_create (void* ctx, char** argv, HGuint32 argc)
{
	AKAppKit* ak = malloc(sizeof(AKAppKit));
	if (!ak)
		return NULL;

	AKAppKitParams_clear(&ak->params);

	ak->updateCalled	= HG_FALSE;
	ak->currTime		= 0;
	ak->currWidth		= 0;
	ak->currHeight		= 0;

	ak->args			= NULL;
	ak->ctx				= ctx;

	ak->msgBuffer[sizeof(ak->msgBuffer) - 1] = '\0';

	ak->userBufFormat	= AK_COLORFORMAT_NONE;
	ak->userBufImage	= NULL;
	ak->nativeBufImage	= NULL;

	ak->mainThread		= akGetThreadID(ak);
	ak->monitor			= AKAppKit_createMonitor(ak);

	if (!AKAppKit_initArgs(ak, argv, argc))
	{
		AKAppKit_destroy(ak);
		return NULL;
	}
	return ak;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_destroy (AKAppKit* ak)
{
	AK_ASSERT(ak);
	AK_ASSERT(ak->mainThread == akGetThreadID(ak));

	if (ak->params.deinit)
		ak->params.deinit(ak);

	if (ak->nativeBufImage)
		akReleaseWindowBuffer(ak, ak->nativeBufImage);

	if (ak->monitor)
		AKMonitor_destroy(ak->monitor);

	AKArg_destroyList(ak->args);

	if (ak->userBufImage)
		AKImage_destroy(ak->userBufImage);

	free(ak);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_enter (AKAppKit* ak)
{
	AK_ASSERT(ak);
	if (ak->monitor)
		AKMonitor_enter(ak->monitor);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_leave (AKAppKit* ak)
{
	AK_ASSERT(ak);
	if (ak->monitor)
		AKMonitor_leave(ak->monitor);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void* AKAppKit_getContext (AKAppKit* ak)
{
	AK_ASSERT(ak);
	return ak->ctx;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_formatMessage (AKAppKit* ak, const char* format, va_list args)
{
	AK_ASSERT(ak);
#if (HG_COMPILER == HG_COMPILER_MSC) && (HG_OS != HG_OS_SYMBIAN)
	_vsnprintf(ak->msgBuffer, sizeof(ak->msgBuffer) - 1, format, args);
#else
	vsprintf(ak->msgBuffer, format, args); /* \todo [tero 12/Jan/06] unsafe */
#endif
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_outputString (AKAppKit* ak, const char* msg)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);

	AKAppKit_enter(ak);

#if (HG_OS == HG_OS_SYMBIAN) || (HG_OS == HG_OS_WINCE)
	{
		FILE* f = fopen("C:\\hg_appkit_log.txt", "a");
		if (f)
		{
			fprintf(f, "%s", msg);
			fclose(f);
		}
	}
#else
	fprintf(stderr, "%s", msg);
	fflush(stderr);
#endif

	AKAppKit_leave(ak);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_initParams (AKAppKit* ak, const AKAppKitParams* params)
{
	AK_ASSERT(ak && params);
	ak->params = *params;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool AKAppKit_createWindow (AKAppKit* ak, HGuint32 width, HGuint32 height, const char* title, AKColorFormat bufferFormat)
{
	HGbool ok;
	AK_ASSERT(ak);
	AK_ASSERT(bufferFormat >= 0 && bufferFormat < AK_COLORFORMAT_MAX);
	AK_ASSERT(ak->mainThread == akGetThreadID(ak));

	AKAppKit_enter(ak);
	ak->userBufFormat = bufferFormat;
	ok = akCreateWindow(ak, width, height, title, bufferFormat);
	AKAppKit_leave(ak);
	return ok;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool AKAppKit_adjustWindow (AKAppKit* ak, HGuint32 width, HGuint32 height)
{
	HGbool ok;
	AK_ASSERT(ak);
	AK_ASSERT(ak->mainThread == akGetThreadID(ak));

	AKAppKit_enter(ak);
	ok = akAdjustWindow(ak, width, height);
	AKAppKit_leave(ak);
	return ok;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool AKAppKit_setWindowTitle (AKAppKit* ak, const char* title)
{
	HGbool ok;
	AK_ASSERT(ak);
	AK_ASSERT(ak->mainThread == akGetThreadID(ak));

	AKAppKit_enter(ak);
	ok = akSetWindowTitle(ak, title);
	AKAppKit_leave(ak);
	return ok;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* AKAppKit_lockWindowBuffer (AKAppKit* ak)
{
	AKSurfaceDesc surfDesc = akGetSurface(ak);
	AK_ASSERT(ak);
	AK_ASSERT(ak->userBufFormat != AK_COLORFORMAT_NONE);
	AK_ASSERT(!ak->nativeBufImage);
	AK_ASSERT(ak->mainThread == akGetThreadID(ak));

	AKAppKit_enter(ak);

	/* Destroy user image if it's of wrong size. */

	if (ak->userBufImage && (ak->userBufImage->width != surfDesc.width || ak->userBufImage->height != surfDesc.height))
	{
		AKImage_destroy(ak->userBufImage);
		ak->userBufImage = NULL;
	}

	/* Get native image and return it if it's of correct format. */

	ak->nativeBufImage = akLockWindowBuffer(ak);
	if (!ak->nativeBufImage)
	{
		AKAppKit_leave(ak);
		return NULL;
	}
	if (ak->nativeBufImage->format == ak->userBufFormat)
	{
		AKAppKit_leave(ak);
		return ak->nativeBufImage;
	}

	/* Create user image if we don't have one. */

	if (!ak->userBufImage)
	{
		ak->userBufImage = AKImage_createBlank(surfDesc.width, surfDesc.height, ak->userBufFormat);
		if (!ak->userBufImage)
		{
			akReleaseWindowBuffer(ak, ak->nativeBufImage);
			ak->nativeBufImage = NULL;
		}
	}
	AKAppKit_leave(ak);
	return ak->userBufImage;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_releaseWindowBuffer (AKAppKit* ak)
{
	AK_ASSERT(ak);
	AK_ASSERT(ak->nativeBufImage);
	AK_ASSERT(ak->mainThread == akGetThreadID(ak));

	AKAppKit_enter(ak);

	/* Update the native image if we are using an user image. */

	if (ak->nativeBufImage->format != ak->userBufFormat)
		AKImage_copyConvertFull(ak->nativeBufImage, ak->userBufImage);

	/* Release the native image. */

	akReleaseWindowBuffer(ak, ak->nativeBufImage);
	ak->nativeBufImage = NULL;

	AKAppKit_leave(ak);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_printf (AKAppKit* ak, const char* format, ...)
{
	va_list args;
	AK_ASSERT(ak);

	AKAppKit_enter(ak);
	va_start(args, format);
	AKAppKit_formatMessage(ak, format, args);
	va_end(args);
	AKAppKit_outputString(ak, ak->msgBuffer);
	AKAppKit_leave(ak);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_errorPrintf (AKAppKit* ak, const char* format, ...)
{
	va_list args;
	AK_ASSERT(ak);

	AKAppKit_enter(ak);
	va_start(args, format);
	AKAppKit_formatMessage(ak, format, args);
	va_end(args);
	akErrorMessage(ak, ak->msgBuffer);
	AKAppKit_leave(ak);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_abort (AKAppKit* ak, const char* format, ...)
{
	va_list args;
	AK_ASSERT(ak);

	AKAppKit_enter(ak);
	va_start(args, format);
	AKAppKit_formatMessage(ak, format, args);
	va_end(args);
	akErrorMessage(ak, ak->msgBuffer);
	akAbort(ak);
	AKAppKit_leave(ak);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_requestExit (AKAppKit* ak)
{
	AK_ASSERT(ak);

	AKAppKit_enter(ak);
	akRequestExit(ak);
	AKAppKit_leave(ak);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKArg* AKAppKit_getArg (AKAppKit* ak, const char* name)
{
	AKArg* current = ak->args;
	AK_ASSERT(ak && name);

	while (current)
	{
		if (akCompareStrings(current->name, name))
			return current;
		current = current->next;
	}
	return 0;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 AKAppKit_getArgCount (AKAppKit* ak)
{
	AKArg*		arg		= ak->args;
	HGuint32	count	= 0;
	AK_ASSERT(ak);

	while (arg)
	{
		count++;
		arg = arg->next;
	}
	return count;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKArg* AKAppKit_getArgByIndex (AKAppKit* ak, HGuint32 index)
{
	AKArg* arg = ak->args;
	AK_ASSERT(ak);

	while (arg && index)
	{
		index--;
		arg = arg->next;
	}
	return arg;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void* AKAppKit_getUserPtr (AKAppKit* ak)
{
	AK_ASSERT(ak);
	return ak->params.userPtr;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 AKAppKit_getTime (AKAppKit* ak)
{
	HGuint32 hiMillis;
	HGuint32 loMillis;
	AK_ASSERT(ak);

	AKAppKit_enter(ak);
	akGetTime(ak, &hiMillis, &loMillis);
	AKAppKit_leave(ak);
	return loMillis;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_getTimeWide (AKAppKit* ak, HGuint32* hiMillis, HGuint32* loMillis)
{
	AK_ASSERT(ak && loMillis && hiMillis);

	AKAppKit_enter(ak);
	akGetTime(ak, hiMillis, loMillis);
	AKAppKit_leave(ak);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKSurfaceDesc AKAppKit_getSurface (AKAppKit* ak)
{
	AKSurfaceDesc desc;
	AK_ASSERT(ak);

	AKAppKit_enter(ak);
	desc = akGetSurface(ak);
	AKAppKit_leave(ak);
	return desc;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKDirListing* AKAppKit_getDirectoryListing (AKAppKit* ak, const char* path)
{
	AKDirListing* listing;
	AK_ASSERT(ak);

	AKAppKit_enter(ak);
	listing = akGetDirectoryListing(ak, path);
	AKAppKit_leave(ak);
	return listing;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool AKAppKit_createThread (AKAppKit* ak, AKAppKit_threadFunc func, void* param)
{
	AKThreadParams	params;
	HGbool			ok;
	AK_ASSERT(ak && func);

	params.appkit		= ak;
	params.userFunc		= func;
	params.userParam	= param;
	params.waitSem		= akCreateSemaphore(ak);

	if (!params.waitSem)
		return HG_FALSE;

	akAcquireSemaphore(ak, params.waitSem);
	ok = akCreateThread(ak, &params);
	if (ok)
		akAcquireSemaphore(ak, params.waitSem);
	akDestroySemaphore(ak, params.waitSem);
	return ok;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 AKAppKit_getThreadID (AKAppKit* ak)
{
	AK_ASSERT(ak);
	return akGetThreadID(ak);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_threadStarted (AKThreadParams* params)
{
	AKThreadParams pcopy = *params;
	AK_ASSERT(params);

	akReleaseSemaphore(pcopy.appkit, pcopy.waitSem);
	pcopy.userFunc(pcopy.appkit, pcopy.userParam);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKMonitor* AKAppKit_createMonitor (AKAppKit* ak)
{
	AKMonitor* monitor = malloc(sizeof(AKMonitor));
	AK_ASSERT(ak);

	if (!monitor)
		return NULL;

	monitor->appkit			= ak;
	monitor->enterSem		= akCreateSemaphore(ak);
	monitor->ownerSem		= akCreateSemaphore(ak);
	monitor->waitSem		= akCreateSemaphore(ak);
	monitor->notifySem		= akCreateSemaphore(ak);
	monitor->ownerThread	= 0;
	monitor->enterCount		= 0;
	monitor->waitCount		= 0;

	if (!monitor->enterSem || !monitor->ownerSem || !monitor->waitSem || !monitor->notifySem)
	{
		AKMonitor_destroy(monitor);
		return NULL;
	}

	akAcquireSemaphore(ak, monitor->waitSem);
	akAcquireSemaphore(ak, monitor->notifySem);
	return monitor;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_INLINE HGbool isArg(const char* arg)
{
	return (arg[0] == '-' || arg[0] == '/');
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool AKAppKit_initArgs (AKAppKit* ak, char** argv, HGuint32 argc)
{
	HGuint32 i = 1;
	AK_ASSERT(ak);

	while (i < argc)
	{
		if (isArg(argv[i]))
		{
			HGuint32 c = i + 1;
			while (c < argc && !isArg(argv[c]))
				c++;

			{
				AKArg* nArg = AKArg_create(argv + i, c - (i + 1));
				if (!nArg)
					return HG_FALSE;

				AKArg_addToList(&ak->args, nArg);
			}
		}
		i++;
	}
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_callKeyEvent (AKAppKit* ak, HGbool down, const char* data)
{
	AKAppKit_keyEventFunc func = ak->params.keyEvent;
	AK_ASSERT(ak);
	AK_ASSERT(ak->mainThread == akGetThreadID(ak));

	if (func)
		func(ak, down, data);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_callCharEvent (AKAppKit* ak, HGuint32 c)
{
	AKAppKit_charEventFunc func = ak->params.charEvent;
	AK_ASSERT(ak);
	AK_ASSERT(ak->mainThread == akGetThreadID(ak));

	if (func)
		func(ak, c);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_callPtrEvent (AKAppKit* ak, HGbool known, HGint32 x, HGint32 y)
{
	AKAppKit_ptrEventFunc func = ak->params.ptrEvent;
	AK_ASSERT(ak);
	AK_ASSERT(ak->mainThread == akGetThreadID(ak));

	if (func)
		func(ak, known, x, y);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKAppKit_callUpdate (AKAppKit* ak)
{
	AKSurfaceDesc				surfDesc;
	AKAppKit_surfaceChangedFunc	surfChg		= NULL;
	AKAppKit_updateFunc			update		= NULL;
	HGint32						timeDelta;

	AK_ASSERT(ak);
	AK_ASSERT(ak->mainThread == akGetThreadID(ak));

	AKAppKit_enter(ak);

	/* Check for surface resize. */

	surfDesc = akGetSurface(ak);
	if (!ak->updateCalled || ak->currWidth != surfDesc.width || ak->currHeight != surfDesc.height)
	{
		ak->currWidth = surfDesc.width;
		ak->currHeight = surfDesc.height;
		surfChg = ak->params.surfaceChanged;
	}

	/* Update time. */
	{
		HGuint32 hiMillis;
		HGuint32 loMillis;
		akGetTime(ak, &hiMillis, &loMillis);
		timeDelta = (ak->updateCalled) ? loMillis - ak->currTime : 0;
		ak->currTime = loMillis;
		update = ak->params.update;
	}

	ak->updateCalled = HG_TRUE;
	AKAppKit_leave(ak);

	/* Do callbacks. */

	if (surfChg)
		surfChg(ak, surfDesc);
	if (update)
		update(ak, timeDelta);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

#if defined(HG_LINT) || defined(HG_NO_ASSERT_H)
void hgAssertFail(const char* expr, const char* file, int line, const char* message)
{
	HG_UNREF(expr);
	HG_UNREF(file);
	HG_UNREF(line);
	HG_UNREF(message);
}
#endif

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKMonitor_destroy (AKMonitor* monitor)
{
	AK_ASSERT(monitor);

	if (monitor->enterSem)
		akDestroySemaphore(monitor->appkit, monitor->enterSem);
	if (monitor->ownerSem)
		akDestroySemaphore(monitor->appkit, monitor->ownerSem);
	if (monitor->waitSem)
		akDestroySemaphore(monitor->appkit, monitor->waitSem);
	if (monitor->notifySem)
		akDestroySemaphore(monitor->appkit, monitor->notifySem);
	free(monitor);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKMonitor_enter (AKMonitor* monitor)
{
	HGuint32 currThread = akGetThreadID(monitor->appkit);
	AK_ASSERT(monitor);

	akAcquireSemaphore(monitor->appkit, monitor->enterSem);
	if (!monitor->enterCount || monitor->ownerThread != currThread)
	{
		akReleaseSemaphore(monitor->appkit, monitor->enterSem);
		akAcquireSemaphore(monitor->appkit, monitor->ownerSem);
		akAcquireSemaphore(monitor->appkit, monitor->enterSem);
	}

	monitor->ownerThread = currThread;
	monitor->enterCount++;
	akReleaseSemaphore(monitor->appkit, monitor->enterSem);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKMonitor_leave (AKMonitor* monitor)
{
	AK_ASSERT(monitor);
	AK_ASSERT(monitor->enterCount && monitor->ownerThread == akGetThreadID(monitor->appkit));

	monitor->enterCount--;
	if (!monitor->enterCount)
		akReleaseSemaphore(monitor->appkit, monitor->ownerSem);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKMonitor_wait (AKMonitor* monitor)
{
	int			enterCount	= monitor->enterCount;
	HGuint32	currThread	= monitor->ownerThread;

	AK_ASSERT(monitor);
	AK_ASSERT(enterCount && currThread == akGetThreadID(monitor->appkit));

	monitor->waitCount++;
	monitor->enterCount = 0;
	akReleaseSemaphore(monitor->appkit, monitor->ownerSem);

	akAcquireSemaphore(monitor->appkit, monitor->waitSem);
	monitor->waitCount--;
	akReleaseSemaphore(monitor->appkit, monitor->notifySem);

	akAcquireSemaphore(monitor->appkit, monitor->ownerSem);
	akAcquireSemaphore(monitor->appkit, monitor->enterSem);
	monitor->ownerThread = currThread;
	monitor->enterCount = enterCount;
	akReleaseSemaphore(monitor->appkit, monitor->enterSem);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKMonitor_notify (AKMonitor* monitor)
{
	AK_ASSERT(monitor);
	AK_ASSERT(monitor->enterCount && monitor->ownerThread == akGetThreadID(monitor->appkit));

	if (monitor->waitCount)
	{
		akReleaseSemaphore(monitor->appkit, monitor->waitSem);
		akAcquireSemaphore(monitor->appkit, monitor->notifySem);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKMonitor_notifyAll (AKMonitor* monitor)
{
	AK_ASSERT(monitor);
	AK_ASSERT(monitor->enterCount && monitor->ownerThread == akGetThreadID(monitor->appkit));

	while (monitor->waitCount)
	{
		akReleaseSemaphore(monitor->appkit, monitor->waitSem);
		akAcquireSemaphore(monitor->appkit, monitor->notifySem);
	}
}

/*----------------------------------------------------------------------*/
