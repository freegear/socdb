/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akSort.c#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *
 *//**
 * \file
 * \brief	Abstract quick sort implementation
 * \author	tero@hybrid.fi
 *//*-------------------------------------------------------------------*/

#include "akSort.h"

/*-------------------------------------------------------------------*//*!
 * \brief	Performs insertion sort (bubble sort with early exit) on
 *			the given abstract subarray.
 *
 * \param	start		Index of the first element of the subarray.
 * \param	size		Number of elements in the subarray.
 * \param	data		Data given as a parameter for the comparison
 *						and swap functions.
 * \param	compareFunc	Function pointer for comparing elements.
 * \param	swapFunc	Function pointer for swapping elements.
 *//*-------------------------------------------------------------------*/

HG_INLINE void akInsertionSort(
	int					start,
	int					size,
	void*				data,
	akSortCompareFunc	compareFunc,
	akSortSwapFunc		swapFunc)
{
	int i, j;

	AK_ASSERT(compareFunc);
	AK_ASSERT(swapFunc);
	AK_ASSERT(size >= 0);

	for (i = 1; i < size; i++)
		for (j = start + i - 1; j >= start && compareFunc(data, j, j + 1) > 0; j--)
			swapFunc(data, j, j + 1);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Finds the approximate median element of the given abstract
 *			subarray.
 *
 * \param	low			Index of the first element of the subarray.
 * \param	high		Index of the first element after the subarray.
 *						high - low is the number of elements in the
 *						subarray.
 * \param	data		Data given as a parameter for the comparison
 *						and swap functions.
 * \param	compareFunc	Function pointer for comparing elements.
 * \return	Index of the approximate median element.
 *//*-------------------------------------------------------------------*/

HG_INLINE int akMedian3(
	int					low,
	int					high,
	void*				data,
	akSortCompareFunc	compareFunc)
{
	int l = low;
	int c = (low + high) >> 1;
	int h = high - 2;
	int t;

	AK_ASSERT(compareFunc);
	AK_ASSERT(low >= 0 && high >= 2);

	if (compareFunc(data, l, h) > 0) { t = l; l = h; h = t; }
	if (compareFunc(data, l, c) > 0) { t = l; l = c; c = t; }
	if (compareFunc(data, c, h) > 0) { t = c; c = h; h = t; }
	return c;
}

/*-------------------------------------------------------------------*//*!
 * \brief	Performs quick sort on the given abstract subarray.
 *
 * \param	low			Index of the first element of the subarray.
 * \param	high		Index of the first element after the subarray.
 *						high - low is the number of elements in the
 *						subarray.
 * \param	data		Data given as a parameter for the comparison
 *						and swap functions.
 * \param	compareFunc	Function pointer for comparing elements.
 * \param	swapFunc	Function pointer for swapping elements.
 *//*-------------------------------------------------------------------*/

HG_STATICF void akQuickSort(
	int					low,
	int					high,
	void*				data,
	akSortCompareFunc	compareFunc,
	akSortSwapFunc		swapFunc)
{
	int i;
	int j;

	AK_ASSERT(compareFunc);
	AK_ASSERT(swapFunc);
	AK_ASSERT(low <= high);

	/* Use insertion sort for small values */

	if ((high - low) <= 15)
	{
		akInsertionSort(low, high - low, data, compareFunc, swapFunc);
		return;
	}

	/* Select pivot using median-3, and hide it in the highest entry */

	swapFunc(data, akMedian3(low, high, data, compareFunc), high - 1);

	/* Partition data */

	i = low - 1;
	j = high - 1;
	for (;;)
	{
		do
			i++;
		while (compareFunc(data, i, high - 1) < 0);
		do 
			j--;
		while (compareFunc(data, j, high - 1) > 0);

		AK_ASSERT(i >= low && j >= low && i < high && j < high);
		if (i >= j)
			break;
		swapFunc(data, i, j);
	}

	/* Restore pivot */

	swapFunc(data, i, high - 1);

	/* Sort sub-partitions */

	if (i - low > 1)
		akQuickSort(low, i, data, compareFunc, swapFunc);
	if (high - i > 2)
		akQuickSort(i + 1, high, data, compareFunc, swapFunc);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Sorts the given abstract subarray. Calls akQuickSort().
 *
 * \param	start		Index of the first element of the subarray.
 * \param	size		Number of elements in the subarray.
 * \param	data		Data given as a parameter for the comparison
 *						and swap functions.
 * \param	compareFunc	Function pointer for comparing elements.
 * \param	swapFunc	Function pointer for swapping elements.
 *//*-------------------------------------------------------------------*/

void akSort(
	int					start,
	int					size,
	void*				data,
	akSortCompareFunc	compareFunc,
	akSortSwapFunc		swapFunc)
{
	AK_ASSERT(compareFunc);
	AK_ASSERT(swapFunc);
	akQuickSort(start, start + size, data, compareFunc, swapFunc);

#ifdef HG_DEBUG
	/* Check that the array is sorted */
	{
		int i;
		for (i = 0; i < size - 1; i++)
			AK_ASSERT(compareFunc(data, start + i, start + i + 1) <= 0);
	}
#endif
}

/*----------------------------------------------------------------------*/
