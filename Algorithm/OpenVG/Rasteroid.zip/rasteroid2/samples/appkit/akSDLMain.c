/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akSDLMain.c#2 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include "akMain.h"
#include "akAppKitPrivate.h"
#include "akUtils.h"

#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#include "SDL/SDL.h"

/*-------------------------------------------------------------------------
 * AppKit SDL context.
 *-----------------------------------------------------------------------*/

typedef struct AKSDLContext_s
{
	AKAppKit*		ak;
	SDL_Surface*	screen;
	HGbool			running;
} AKSDLContext;

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF const char* translateKey (SDLKey key)
{
	switch (key)
	{
	case SDLK_RALT:
	case SDLK_LALT:			return "Alt";			/* Menu */
	case SDLK_MENU:			return "Apps";			/* Application */
	case SDLK_CAPSLOCK:		return "CapsLock";		/* Capital */
	case SDLK_CLEAR:		return "Clear";
	case SDLK_COMPOSE:		return "Compose";
	case SDLK_RCTRL:
	case SDLK_LCTRL:		return "Control";		/* Ctrl */
	case SDLK_DOWN:			return "Down";			/* Arrow */
	case SDLK_END:			return "End";
	case SDLK_RETURN:
	case SDLK_KP_ENTER:		return "Enter";			/* Return */
	case SDLK_F1:			return "F1";
	case SDLK_F2:			return "F2";
	case SDLK_F3:			return "F3";
	case SDLK_F4:			return "F4";
	case SDLK_F5:			return "F5";
	case SDLK_F6:			return "F6";
	case SDLK_F7:			return "F7";
	case SDLK_F8:			return "F8";
	case SDLK_F9:			return "F9";
	case SDLK_F10:			return "F10";
	case SDLK_F11:			return "F11";
	case SDLK_F12:			return "F12";
	case SDLK_F13:			return "F13";
	case SDLK_F14:			return "F14";
	case SDLK_F15:			return "F15";
	case SDLK_HELP:			return "Help";
	case SDLK_HOME:			return "Home";
	case SDLK_INSERT:		return "Insert";		/* Ins */
	case SDLK_LEFT:			return "Left";			/* Arrow */
	case SDLK_RMETA:
	case SDLK_LMETA:		return "Meta";
	case SDLK_MODE:			return "ModeChange";
	case SDLK_NUMLOCK:		return "NumLock";
	case SDLK_PAGEDOWN:		return "PageDown";		/* Next */
	case SDLK_PAGEUP:		return "PageUp";		/* Prior */
	case SDLK_PAUSE:		return "Pause";
	case SDLK_PRINT:		return "PrintScreen";	/* SnapShot */
	case SDLK_RIGHT:		return "Right";			/* Arrow */
	case SDLK_SCROLLOCK:	return "Scroll";		/* Scroll lock */
	case SDLK_RSHIFT:
	case SDLK_LSHIFT:		return "Shift";
	case SDLK_UP:			return "Up";			/* Arrow */
	case SDLK_UNDO:			return "Undo";
	case SDLK_LSUPER:
	case SDLK_RSUPER:		return "Win";			/* Windows logo */
	case SDLK_BACKSPACE:	return "U+0008";		/* Backspace */
	case SDLK_TAB:			return "U+0009";		/* Tab */
	case SDLK_BREAK:		return "U+0018";		/* Cancel */
	case SDLK_ESCAPE:		return "U+001B";		/* Esc */
	case SDLK_SPACE:		return "U+0020";		/* Space */
	case SDLK_EXCLAIM:		return "U+0021";		/* ! */
	case SDLK_QUOTEDBL:		return "U+0022";		/* " */
	case SDLK_HASH:			return "U+0023";		/* # */
	case SDLK_DOLLAR:		return "U+0024";		/* $ */
	case SDLK_AMPERSAND:	return "U+0026";		/* & */
	case SDLK_QUOTE:		return "U+0027";		/* ' */
	case SDLK_LEFTPAREN:	return "U+0028";		/* ( */
	case SDLK_RIGHTPAREN:	return "U+0029";		/* ) */
	case SDLK_ASTERISK:
	case SDLK_KP_MULTIPLY:	return "U+002A";		/* * */
	case SDLK_PLUS:
	case SDLK_KP_PLUS:		return "U+002B";		/* + */
	case SDLK_COMMA:		return "U+002C";		/* , */
	case SDLK_MINUS:
	case SDLK_KP_MINUS:		return "U+002D";		/* - */
	case SDLK_PERIOD:
	case SDLK_KP_PERIOD:	return "U+002E";		/* . */
	case SDLK_SLASH:
	case SDLK_KP_DIVIDE:	return "U+002F";		/* / */
	case SDLK_0:
	case SDLK_KP0:			return "U+0030";		/* 0 */
	case SDLK_1:
	case SDLK_KP1:			return "U+0031";		/* 1 */
	case SDLK_2:
	case SDLK_KP2:			return "U+0032";		/* 2 */
	case SDLK_3:
	case SDLK_KP3:			return "U+0033";		/* 3 */
	case SDLK_4:
	case SDLK_KP4:			return "U+0034";		/* 4 */
	case SDLK_5:
	case SDLK_KP5:			return "U+0035";		/* 5 */
	case SDLK_6:
	case SDLK_KP6:			return "U+0036";		/* 6 */
	case SDLK_7:
	case SDLK_KP7:			return "U+0037";		/* 7 */
	case SDLK_8:
	case SDLK_KP8:			return "U+0038";		/* 8 */
	case SDLK_9:
	case SDLK_KP9:			return "U+0039";		/* 9 */
	case SDLK_COLON:		return "U+003A";		/* : */
	case SDLK_SEMICOLON:	return "U+003B";		/* ; */
	case SDLK_LESS:			return "U+003C";		/* < */
	case SDLK_EQUALS:
	case SDLK_KP_EQUALS:	return "U+003D";		/* = */
	case SDLK_GREATER:		return "U+003E";		/* > */
	case SDLK_QUESTION:		return "U+003F";		/* ? */
	case SDLK_AT:			return "U+0040";		/* @ */
	case SDLK_a:			return "U+0041";		/* A */
	case SDLK_b:			return "U+0042";		/* B */
	case SDLK_c:			return "U+0043";		/* C */
	case SDLK_d:			return "U+0044";		/* D */
	case SDLK_e:			return "U+0045";		/* E */
	case SDLK_f:			return "U+0046";		/* F */
	case SDLK_g:			return "U+0047";		/* G */
	case SDLK_h:			return "U+0048";		/* H */
	case SDLK_i:			return "U+0049";		/* I */
	case SDLK_j:			return "U+004A";		/* J */
	case SDLK_k:			return "U+004B";		/* K */
	case SDLK_l:			return "U+004C";		/* L */
	case SDLK_m:			return "U+004D";		/* M */
	case SDLK_n:			return "U+004E";		/* N */
	case SDLK_o:			return "U+004F";		/* O */
	case SDLK_p:			return "U+0050";		/* P */
	case SDLK_q:			return "U+0051";		/* Q */
	case SDLK_r:			return "U+0052";		/* R */
	case SDLK_s:			return "U+0053";		/* S */
	case SDLK_t:			return "U+0054";		/* T */
	case SDLK_u:			return "U+0055";		/* U */
	case SDLK_v:			return "U+0056";		/* V */
	case SDLK_w:			return "U+0057";		/* W */
	case SDLK_x:			return "U+0058";		/* X */
	case SDLK_y:			return "U+0059";		/* Y */
	case SDLK_z:			return "U+005A";		/* Z */
	case SDLK_LEFTBRACKET:	return "U+005B";		/* [ */
	case SDLK_BACKSLASH:	return "U+005C";		/* Backslash */
	case SDLK_RIGHTBRACKET:	return "U+005D";		/* ] */
	case SDLK_CARET:		return "U+005E";		/* ^ */
	case SDLK_UNDERSCORE:	return "U+005F";		/* _ */
	case SDLK_BACKQUOTE:	return "U+0060";		/* Grave */
	case SDLK_DELETE:		return "U+007F";		/* Del */
	case SDLK_EURO:			return "U+20AC";		/* Euro sign */
	default:				return NULL;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF void run (AKSDLContext* ctx)
{
	AK_ASSERT(ctx && ctx->ak);

	if (!ctx->screen) /* Window is not created or creation has failed. */
		return;

	/* Event loop. */

	while (ctx->running)
	{
		SDL_Event event;

		AKAppKit_callUpdate(ctx->ak);

		while (SDL_PollEvent(&event))
		{
			switch (event.type)
			{
			case SDL_QUIT:
				ctx->running = HG_FALSE;
				break;

			case SDL_KEYDOWN:
			case SDL_KEYUP:
				{
					HGbool down = (event.type == SDL_KEYDOWN);
					const char* keyId = translateKey(event.key.keysym.sym);
					if (keyId)
						AKAppKit_callKeyEvent(ctx->ak, down, keyId);
					if (down && event.key.keysym.unicode)
						AKAppKit_callCharEvent(ctx->ak, event.key.keysym.unicode);
				}
				break;

			case SDL_MOUSEMOTION:
				AKAppKit_callPtrEvent(ctx->ak, HG_TRUE, event.motion.x, event.motion.y);
				break;

			case SDL_MOUSEBUTTONDOWN:
			case SDL_MOUSEBUTTONUP:
				{
					const char* keyId;

					switch (event.button.button)
					{
					case SDL_BUTTON_LEFT:		keyId = "!PtrLeft"; break;
					case SDL_BUTTON_RIGHT:		keyId = "!PtrRight"; break;
					case SDL_BUTTON_MIDDLE:		keyId = "!PtrMiddle"; break;
					case SDL_BUTTON_WHEELUP:	keyId = "!WheelUp"; break;
					case SDL_BUTTON_WHEELDOWN:	keyId = "!WheelDown"; break;
					default:					keyId = NULL; break;
					}

					if (keyId)
						AKAppKit_callKeyEvent(ctx->ak, event.type == SDL_MOUSEBUTTONDOWN, keyId);
				}
				break;

			case SDL_VIDEORESIZE:
				{
					HGuint32 width = event.resize.w;
					HGuint32 height = event.resize.h;

					ctx->screen = SDL_SetVideoMode(width, height, 32, SDL_SWSURFACE | SDL_RESIZABLE);
					if (!ctx->screen)
						exit(1);
				}
				break;
			}
		}
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateWindow (AKAppKit* ak, HGuint32 width, HGuint32 height, const char* title, AKColorFormat bufFormatHint)
{
	AKSDLContext* ctx = (AKSDLContext*)AKAppKit_getContext(ak);
	AK_ASSERT(ak && ctx);
	HG_UNREF(bufFormatHint);

	if (SDL_Init(SDL_INIT_VIDEO) == -1)
		return HG_FALSE;

	ctx->screen = SDL_SetVideoMode(width, height, 32, SDL_SWSURFACE | SDL_RESIZABLE);
	if (!ctx->screen)
		return HG_FALSE;

	SDL_WM_SetCaption(title, NULL);
	SDL_EnableUNICODE(1);
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akAdjustWindow(AKAppKit* ak, HGuint32 width, HGuint32 height)
{
	AK_ASSERT(ak);

	{
		AKSDLContext* ctx = (AKSDLContext*)AKAppKit_getContext(ak);

		ctx->screen = SDL_SetVideoMode(width, height, 32, SDL_SWSURFACE | SDL_RESIZABLE);
		if (!ctx->screen)
			exit(1);
	}

	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akSetWindowTitle (AKAppKit* ak, const char* title)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);

	SDL_WM_SetCaption(title, NULL);

	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* akLockWindowBuffer (AKAppKit* ak)
{
	AKSDLContext*	ctx			= (AKSDLContext*)AKAppKit_getContext(ak);
	AKImage*		bufImage;
	AK_ASSERT(ak && ctx);
	
	SDL_LockSurface(ctx->screen);
	bufImage = AKImage_createForBuffer(
		ctx->screen->w, ctx->screen->h, AK_COLORFORMAT_INT_ARGB,
		ctx->screen->pitch, ctx->screen->pixels);
	if (!bufImage)
	{
		SDL_UnlockSurface(ctx->screen);
		return NULL;
	}
	return bufImage;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseWindowBuffer (AKAppKit* ak, AKImage* bufImage)
{
	AKSDLContext*			ctx	= (AKSDLContext*)AKAppKit_getContext(ak);
	const SDL_PixelFormat*	fmt	= ctx->screen->format;
	int						y;
	int						ash	= 24 + fmt->Aloss;
	int						rsh	= 16 + fmt->Rloss;
	int						gsh	= 8 + fmt->Gloss;
	int						bsh	= 0 + fmt->Bloss;
	
	AK_ASSERT(ak && bufImage);

	for (y = 0; y < bufImage->height; y++)
	{
		HGuint32* p = (HGuint32*)AKImage_getRowPtr(bufImage, y);
		int x;
		for (x = 0; x < bufImage->width; x++)
		{
			HGuint32 v = p[x];
			p[x] =
				((v >> ash << fmt->Ashift) & fmt->Amask) |
				((v >> rsh << fmt->Rshift) & fmt->Rmask) |
				((v >> gsh << fmt->Gshift) & fmt->Gmask) |
				((v >> bsh << fmt->Bshift) & fmt->Bmask);
		}
	}
	SDL_UnlockSurface(ctx->screen);
	SDL_Flip(ctx->screen);
	AKImage_destroy(bufImage);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akErrorMessage (AKAppKit* ak, const char* msg)
{
	AK_ASSERT(ak);
	AKAppKit_outputString(ak, msg);
	AKAppKit_outputString(ak, "\n");
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAbort (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	exit(1);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akRequestExit(AKAppKit* ak)
{
	AK_ASSERT(ak);
	{
		AKSDLContext* ctx = (AKSDLContext*)AKAppKit_getContext(ak);
		ctx->running = HG_FALSE;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akGetTime(AKAppKit* ak, HGuint32* hiMillis, HGuint32* loMillis)
{
	AK_ASSERT(ak && hiMillis && loMillis);
	HG_UNREF(ak);
	*hiMillis = 0;
	*loMillis = SDL_GetTicks();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKSurfaceDesc akGetSurface (AKAppKit* ak)
{
	AKSurfaceDesc desc;
	AK_ASSERT(ak);

	{
		AKSDLContext* ctx = AKAppKit_getContext(ak);
		desc.width = ctx->screen->w;
		desc.height = ctx->screen->h;
		desc.nativePtr = ctx->screen;
	}

	return desc;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF void pushEntry (AKDirListing* dir, struct dirent* f, const char* path)
{
	AK_ASSERT(dir && f);

	if (akCompareStrings(f->d_name, ".") || akCompareStrings(f->d_name, ".."))
		return;

	{
		AKDirEntry* entry = AKDirEntry_create();
		if (!entry)
			return;

		{
			struct stat	buf;
			char*		name = akCatenateStrings(path, f->d_name);
			if (name && !lstat(name, &buf))
			{
				if (S_ISDIR(buf.st_mode))
					entry->flags |= AK_DIRENTRY_FLAGS_DIR;
			}

			free(name);
		}

		akCopyString(entry->filename, f->d_name);

		AKDirListing_pushBack(dir, entry);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKDirListing* akGetDirectoryListing (AKAppKit* ak, const char* path)
{
	AK_ASSERT(ak && path);
	HG_UNREF(ak);

	{
		char*			fixedPath;
		char*			dirPath;
		AKDirListing*	dir;
		DIR*			d;
		struct dirent*	f;

		fixedPath = akFixPath(path);
		if (!fixedPath)
			return NULL;

		dirPath = akDuplicateString(fixedPath);
		akAppendString(&dirPath, ".");
		if (!dirPath)
			return NULL;

		dir = AKDirListing_create();
		if (!dir)
		{
			free(fixedPath);
			free(dirPath);
			return NULL;
		}

		d = opendir(dirPath);
		free(dirPath);

		if (!d)
		{
			AKDirListing_destroy(dir);
			free(fixedPath);
			return NULL;
		}

		while ((f = readdir(d)) != NULL)
			pushEntry(dir, f, fixedPath);

		closedir(d);

		free(fixedPath);

		return dir;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/
 
 HG_STATICF void* threadProc (void* arg)
 {
	 AK_ASSERT(arg);
	 AKAppKit_threadStarted((AKThreadParams*)arg);
	 return NULL;
 }

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateThread (AKAppKit* ak, AKThreadParams* params)
{
	pthread_t id;
	AK_ASSERT(ak && params);
	HG_UNREF(ak);
	return (pthread_create(&id, NULL, threadProc, params) == 0);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akGetThreadID (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	return (HGuint32)pthread_self();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void* akCreateSemaphore (AKAppKit* ak)
{
	sem_t* semaphore = malloc(sizeof(sem_t));
	AK_ASSERT(ak);
	HG_UNREF(ak);
	
	if (!semaphore)
		return NULL;
	if (sem_init(semaphore, HG_FALSE, 1) != 0)
	{
		free(semaphore);
		return NULL;
	}
	return semaphore;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akDestroySemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	sem_destroy((sem_t*)semaphore);
	free(semaphore);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAcquireSemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	sem_wait((sem_t*)semaphore);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseSemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	sem_post((sem_t*)semaphore);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

int main (int argc, char** argv)
{
	AKSDLContext	ctx;

	/* Be nice. */

	nice(5);

	/* Create AppKit and set up context. */

	ctx.ak = AKAppKit_create(&ctx, argv, argc);
	if (!ctx.ak)
		return 1;

	ctx.screen	= NULL;
	ctx.running	= HG_TRUE;

	if (appInit(ctx.ak))	/* Init application. */
		run(&ctx);			/* Run if init succeeded. */

	AKAppKit_destroy(ctx.ak);	/* Destroy AppKit (calls application's deinit). */

	if (ctx.screen)
		SDL_FreeSurface(ctx.screen);

	SDL_Quit();

	return 0;
}

/*-----------------------------------------------------------------------*/
