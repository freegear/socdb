/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akGLUTMain.c#2 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include "akMain.h"
#include "akAppKitPrivate.h"
#include "akUtils.h"
#include "hgPublicDefs.h"

#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#if (HG_OS == HG_OS_WIN32) || (HG_OS == HG_OS_CYGWIN)
#	include <windows.h>
#	include <GL/gl.h>
#	define GLUT_DISABLE_ATEXIT_HACK
#	include <GL/glut.h>
#elif (HG_OS == HG_OS_MACOSX)
#	include <OpenGL/gl.h>
#	include <GLUT/glut.h>
#elif (HG_OS == HG_OS_LINUX)
#	include <GL/gl.h>
#	include <GL/glut.h>
#else
#	error "Unsupported AppKit GLUT platform"
#endif

/*-------------------------------------------------------------------------
 * AppKit GLUT context.
 *-----------------------------------------------------------------------*/

typedef struct AKGLUTContext_s
{
	AKAppKit*		ak;
	int				window;
	HGint32			bufFormatHint;	/* AKColorFormat */
	AKImage*		bufImage;
} AKGLUTContext;

/*-------------------------------------------------------------------------
 * Function prototypes.
 *-----------------------------------------------------------------------*/

HG_STATICF const char*		translateKey	(int key, HGbool special);
HG_STATICF HGbool			initGLUT		(AKGLUTContext* ctx);
void						pushEntry		(AKDirListing* dir, struct dirent* f, const char* path);

static AKGLUTContext* gCtx = HG_NULL;

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF const char* translateKey (int key, HGbool special)
{
	if(special)
	{
		switch(key)
		{
		case GLUT_KEY_LEFT:			return "Left";			/* Arrow */
		case GLUT_KEY_RIGHT:		return "Right";			/* Arrow */
		case GLUT_KEY_UP:			return "Up";			/* Arrow */
		case GLUT_KEY_DOWN:			return "Down";			/* Arrow */
		case GLUT_KEY_PAGE_UP:		return "PageUp";		/* Prior */
		case GLUT_KEY_PAGE_DOWN:	return "PageDown";		/* Next */
		case GLUT_KEY_HOME:			return "Home";
		case GLUT_KEY_END:			return "End";
		case GLUT_KEY_INSERT:		return "Insert";		/* Ins */
		case GLUT_KEY_F1:			return "F1";
		case GLUT_KEY_F2:			return "F2";
		case GLUT_KEY_F3:			return "F3";
		case GLUT_KEY_F4:			return "F4";
		case GLUT_KEY_F5:			return "F5";
		case GLUT_KEY_F6:			return "F6";
		case GLUT_KEY_F7:			return "F7";
		case GLUT_KEY_F8:			return "F8";
		case GLUT_KEY_F9:			return "F9";
		case GLUT_KEY_F10:			return "F10";
		case GLUT_KEY_F11:			return "F11";
		case GLUT_KEY_F12:			return "F12";
		default:					return HG_NULL;
		}
	}
	else
	{
		switch(key)
		{
		case 13:				return "Enter";		/* Return */
		case 127:				return "U+0008";	/* Backspace */
		case 9:					return "U+0009";	/* Tab */
		case 27:				return "U+001B";	/* Esc */

		case (int)' ':			return "U+0020";		/* Space */

		case (int)'!':			return "U+0021";
		case (int)'"':			return "U+0022";
		case (int)'#':			return "U+0023";
		case (int)'$':			return "U+0024";
		case (int)'&':			return "U+0026";
		case (int)'\'':			return "U+0027";
		case (int)'(':			return "U+0028";
		case (int)')':			return "U+0029";
		case (int)'*':			return "U+002A";
		case (int)'+':			return "U+002B";
		case (int)'-':			return "U+002D";
		case (int)',':			return "U+002C";
		case (int)'.':			return "U+002E";
		case (int)'/':			return "U+002F";

		case (int)'0':			return "U+0030";
		case (int)'1':			return "U+0031";
		case (int)'2':			return "U+0032";
		case (int)'3':			return "U+0033";
		case (int)'4':			return "U+0034";
		case (int)'5':			return "U+0035";
		case (int)'6':			return "U+0036";
		case (int)'7':			return "U+0037";
		case (int)'8':			return "U+0038";
		case (int)'9':			return "U+0039";

		case (int)':':			return "U+003A";
		case (int)';':			return "U+003B";
		case (int)'<':			return "U+003C";
		case (int)'=':			return "U+003D";
		case (int)'>':			return "U+003E";
		case (int)'?':			return "U+003F";
		case (int)'@':			return "U+0040";

		case (int)'A':
		case (int)'a':			return "U+0041";
		case (int)'B':
		case (int)'b':			return "U+0042";
		case (int)'C':
		case (int)'c':			return "U+0043";
		case (int)'D':
		case (int)'d':			return "U+0044";
		case (int)'E':
		case (int)'e':			return "U+0045";
		case (int)'F':
		case (int)'f':			return "U+0046";
		case (int)'G':
		case (int)'g':			return "U+0047";
		case (int)'H':
		case (int)'h':			return "U+0048";
		case (int)'I':
		case (int)'i':			return "U+0049";
		case (int)'J':
		case (int)'j':			return "U+004A";
		case (int)'K':
		case (int)'k':			return "U+004B";
		case (int)'L':
		case (int)'l':			return "U+004C";
		case (int)'M':
		case (int)'m':			return "U+004D";
		case (int)'N':
		case (int)'n':			return "U+004E";
		case (int)'O':
		case (int)'o':			return "U+004F";
		case (int)'P':
		case (int)'p':			return "U+0050";
		case (int)'Q':
		case (int)'q':			return "U+0051";
		case (int)'R':
		case (int)'r':			return "U+0052";
		case (int)'S':
		case (int)'s':			return "U+0053";
		case (int)'T':
		case (int)'t':			return "U+0054";
		case (int)'U':
		case (int)'u':			return "U+0055";
		case (int)'V':
		case (int)'v':			return "U+0056";
		case (int)'W':
		case (int)'w':			return "U+0057";
		case (int)'X':
		case (int)'x':			return "U+0058";
		case (int)'Y':
		case (int)'y':			return "U+0059";
		case (int)'Z':
		case (int)'z':			return "U+005A";

		case (int)'[':			return "U+005B";
		case (int)'\\':			return "U+005C";
		case (int)']':			return "U+005D";
		case (int)'^':			return "U+005E";
		case (int)'_':			return "U+005F";

		case 8:					return "U+007F";		/* Delete */

		default:				return HG_NULL;
		}
	}

#if 0
	switch (key)
	{
		/* this function can be used for finding out if alt, ctrl or shift is pressed.
			Unfortunately they don't generate keyboard events */
extern int APIENTRY glutGetModifiers(void);
#define GLUT_ACTIVE_SHIFT               1
#define GLUT_ACTIVE_CTRL                2
#define GLUT_ACTIVE_ALT                 4

		/* TODO these are currently not handled since there doesn't seem to be a way to query these from GLUT */
	case GLUTK_ALT:			return "Alt";			/* Menu */
	case GLUTK_MENU:		return "Apps";			/* Application */
	case GLUTK_CAPSLOCK:	return "CapsLock";		/* Capital */
	case GLUTK_CLEAR:		return "Clear";
	case GLUTK_COMPOSE:		return "Compose";
	case GLUTK_CTRL:		return "Control";		/* Ctrl */
	case GLUTK_HELP:		return "Help";
	case GLUTK_META:		return "Meta";
	case GLUTK_MODE:		return "ModeChange";
	case GLUTK_NUMLOCK:		return "NumLock";
	case GLUTK_PAUSE:		return "Pause";
	case GLUTK_PRINT:		return "PrintScreen";	/* SnapShot */
	case GLUTK_SCROLLOCK:	return "Scroll";		/* Scroll lock */
	case GLUTK_SHIFT:		return "Shift";
	case GLUTK_UNDO:		return "Undo";
	case GLUTK_SUPER:		return "Win";			/* Windows logo */
	case GLUTK_BREAK:		return "U+0018";		/* Cancel */
	case GLUTK_BACKQUOTE:	return "U+0060";		/* Grave */
	case GLUTK_EURO:		return "U+20AC";		/* Euro sign */
	default:				return NULL;
	}
#endif
	return NULL;
}

/*-------------------------------------------------------------------*//*!
 * \brief	Main window procedure.
 * \param	hWnd	Window handle.
 * \param	uMsg	Message.
 * \param	wParam	Parameter.
 * \param	lParam	Parameter.
 * \return	Returns the return status.
 *//*-------------------------------------------------------------------*/

HG_STATICF void kbdfunc(unsigned char key, int x, int y)
{
	AKGLUTContext* ctx = gCtx;
	HG_UNREF(x);
	HG_UNREF(y);
	{
		const char* keyId = translateKey((int)key, HG_FALSE);
		if (keyId)
			AKAppKit_callKeyEvent(ctx->ak, HG_TRUE, keyId);
		AKAppKit_callCharEvent(ctx->ak, key);
	}
}
HG_STATICF void kbdupfunc(unsigned char key, int x, int y)
{
	AKGLUTContext* ctx = gCtx;
	HG_UNREF(x);
	HG_UNREF(y);
	{
		const char* keyId = translateKey((int)key, HG_FALSE);
		if (keyId)
			AKAppKit_callKeyEvent(ctx->ak, HG_FALSE, keyId);
	}
}
HG_STATICF void specialfunc(int key, int x, int y)
{
	AKGLUTContext* ctx = gCtx;
	HG_UNREF(x);
	HG_UNREF(y);
	{
		const char* keyId = translateKey((int)key, HG_TRUE);
		if (keyId)
			AKAppKit_callKeyEvent(ctx->ak, HG_TRUE, keyId);
	}
}
HG_STATICF void specialupfunc(int key, int x, int y)
{
	AKGLUTContext* ctx = gCtx;
	HG_UNREF(x);
	HG_UNREF(y);
	{
		const char* keyId = translateKey((int)key, HG_TRUE);
		if (keyId)
			AKAppKit_callKeyEvent(ctx->ak, HG_FALSE, keyId);
	}
}
HG_STATICF void mousefunc(int x, int y)
{
	AKGLUTContext* ctx = gCtx;
	AKAppKit_callPtrEvent(ctx->ak, HG_TRUE, x, y);

	/* if we need to invert mouse y for some reason... */
	/*mousey = (float)(glutGet(GLUT_WINDOW_HEIGHT) - y);*/
}
HG_STATICF void mouseButtonFunc(int button, int state, int x, int y)
{
	AKGLUTContext* ctx = gCtx;
	HG_UNREF(x);
	HG_UNREF(y);
	{
		const char* keyId;

		switch (button)
		{
		case GLUT_LEFT_BUTTON:		keyId = "!PtrLeft"; break;
		case GLUT_RIGHT_BUTTON:		keyId = "!PtrRight"; break;
		case GLUT_MIDDLE_BUTTON:	keyId = "!PtrMiddle"; break;
		/* TODO GLUT doesn't support mouse wheel? */
/*		case GLUT_BUTTON_WHEELUP:	keyId = "!WheelUp"; break;
		case GLUT_BUTTON_WHEELDOWN:	keyId = "!WheelDown"; break;
*/		default:					keyId = NULL; break;
		}

		if (keyId)
			AKAppKit_callKeyEvent(ctx->ak, state == GLUT_DOWN, keyId);
	}
}
HG_STATICF void idlefunc(void)
{
	glutPostRedisplay();
}

HG_STATICF void exitfunc(void)
{
	AKGLUTContext* ctx = gCtx;
	if (ctx->bufImage)
		AKImage_destroy(ctx->bufImage);
	AKAppKit_destroy(ctx->ak);	/* Destroy AppKit (calls application's deinit). */
}

HG_STATICF void displayfunc(void)
{
	AKGLUTContext* ctx = gCtx;
	AK_ASSERT(ctx && ctx->ak);

	if (!ctx->window)	/* Window is not created or creation has failed. */
		exit(1);
	AKAppKit_callUpdate(ctx->ak);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateWindow (AKAppKit* ak, HGuint32 width, HGuint32 height, const char* title, AKColorFormat bufFormatHint)
{
	AK_ASSERT(ak);
	HG_UNREF(bufFormatHint);
	{
		AKGLUTContext* ctx = (AKGLUTContext*)AKAppKit_getContext(ak);
		AK_ASSERT(ctx);
	
		glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
		glutInitWindowSize(width, height);
		ctx->window = glutCreateWindow(title);
		if (ctx->window)
			return HG_TRUE;
		else
			return HG_FALSE;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akAdjustWindow (AKAppKit* ak, HGuint32 width, HGuint32 height)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	glutReshapeWindow(width, height);
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akSetWindowTitle (AKAppKit* ak, const char* title)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	glutSetWindowTitle(title);
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* akLockWindowBuffer (AKAppKit* ak)
{
	AKGLUTContext*	ctx			= AKAppKit_getContext(ak);
	AKSurfaceDesc	surfDesc	= akGetSurface(ak);
	AK_ASSERT(ak);

	/* Destroy image if it's of wrong dimension. */

	if (ctx->bufImage && (ctx->bufImage->width != surfDesc.width || ctx->bufImage->height != surfDesc.height))
	{
		AKImage_destroy(ctx->bufImage);
		ctx->bufImage = NULL;
	}

	/* Create image if we don't have one. */

	if (!ctx->bufImage)
	{
		AKColorFormat fmt = akCanonizeColorFormat(ctx->bufFormatHint);
		if (fmt != AK_COLORFORMAT_BYTE_RGB &&
			fmt != AK_COLORFORMAT_BYTE_RGBA)
		{
			fmt = AK_COLORFORMAT_BYTE_RGB;
		}

		ctx->bufImage = AKImage_createBlankDownUp(surfDesc.width, surfDesc.height, fmt);
		if (!ctx->bufImage)
			return NULL;
	}
	return ctx->bufImage;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseWindowBuffer (AKAppKit* ak, AKImage* bufImage)
{
	int format;
	int type;
	AK_ASSERT(ak && bufImage);
	HG_UNREF(ak);

	switch (bufImage->format)
	{
	case AK_COLORFORMAT_BYTE_RGB:
		format	= GL_RGB;
		type	= GL_UNSIGNED_BYTE;
		break;

	case AK_COLORFORMAT_BYTE_RGBA:
		format	= GL_RGBA;
		type	= GL_UNSIGNED_BYTE;
		break;

	default:
		AK_ASSERT(HG_FALSE);
		return;
	}

	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glDrawPixels(bufImage->width, bufImage->height, format, type,
		bufImage->data + bufImage->stride * (bufImage->height - 1));
	glutSwapBuffers();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akErrorMessage (AKAppKit* ak, const char* msg)
{
	AK_ASSERT(ak);
	AKAppKit_outputString(ak, msg);
	AKAppKit_outputString(ak, "\n");
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAbort (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	exit(1);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akRequestExit(AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	exit(0);	/* this will cause a call to exitfunc */
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akGetTime(AKAppKit* ak, HGuint32* hiMillis, HGuint32* loMillis)
{
	AK_ASSERT(ak && hiMillis && loMillis);
	HG_UNREF(ak);
	*hiMillis = 0;
	*loMillis = glutGet(GLUT_ELAPSED_TIME);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKSurfaceDesc akGetSurface (AKAppKit* ak)
{
	AKSurfaceDesc desc;
	AK_ASSERT(ak);

	{
		AKGLUTContext* ctx = AKAppKit_getContext(ak);
		/* this code restores the current window. Not really needed until we have support for multiple windows. */
		int currWin = glutGetWindow();
		glutSetWindow(ctx->window);
		desc.width = glutGet(GLUT_WINDOW_WIDTH);
		desc.height = glutGet(GLUT_WINDOW_HEIGHT);
		glutSetWindow(currWin);
		desc.nativePtr = (void*)ctx->window;
	}

	return desc;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void pushEntry (AKDirListing* dir, struct dirent* f, const char* path)
{
	AK_ASSERT(dir && f);

	if (akCompareStrings(f->d_name, ".") || akCompareStrings(f->d_name, ".."))
		return;

	{
		AKDirEntry* entry = AKDirEntry_create();
		if (!entry)
			return;

		{
			struct stat	buf;
			char*		name = akCatenateStrings(path, f->d_name);
			if (name && !lstat(name, &buf))
			{
				if (S_ISDIR(buf.st_mode))
					entry->flags |= AK_DIRENTRY_FLAGS_DIR;
			}

			free(name);
		}

		akCopyString(entry->filename, f->d_name);

		AKDirListing_pushBack(dir, entry);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKDirListing* akGetDirectoryListing (AKAppKit* ak, const char* path)
{
	AK_ASSERT(ak && path);
	HG_UNREF(ak);

	{
		char*			fixedPath;
		char*			dirPath;
		AKDirListing*	dir;
		DIR*			d;
		struct dirent*	f;

		fixedPath = akFixPath(path);
		if (!fixedPath)
			return NULL;

		dirPath = akDuplicateString(fixedPath);
		akAppendString(&dirPath, ".");
		if (!dirPath)
			return NULL;

		dir = AKDirListing_create();
		if (!dir)
		{
			free(fixedPath);
			free(dirPath);
			return NULL;
		}

		d = opendir(dirPath);
		free(dirPath);

		if (!d)
		{
			AKDirListing_destroy(dir);
			free(fixedPath);
			return NULL;
		}

		while ((f = readdir(d)) != NULL)
			pushEntry(dir, f, fixedPath);

		closedir(d);

		free(fixedPath);

		return dir;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/
 
 HG_STATICF void* threadProc (void* arg)
 {
	 AK_ASSERT(arg);
	 AKAppKit_threadStarted((AKThreadParams*)arg);
	 return NULL;
 }

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateThread (AKAppKit* ak, AKThreadParams* params)
{
	pthread_t id;
	AK_ASSERT(ak && params);
	HG_UNREF(ak);
	return (pthread_create(&id, NULL, threadProc, params) == 0);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akGetThreadID (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	return (HGuint32)pthread_self();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void* akCreateSemaphore (AKAppKit* ak)
{
	sem_t* semaphore = malloc(sizeof(sem_t));
	AK_ASSERT(ak);
	HG_UNREF(ak);
	
	if (!semaphore)
		return NULL;
	if (sem_init(semaphore, HG_FALSE, 1) != 0)
	{
		free(semaphore);
		return NULL;
	}
	return semaphore;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akDestroySemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	sem_destroy((sem_t*)semaphore);
	free(semaphore);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAcquireSemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	sem_wait((sem_t*)semaphore);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseSemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	sem_post((sem_t*)semaphore);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF HGbool initGLUT (AKGLUTContext* ctx)
{
	AK_ASSERT(ctx && ctx->ak);
	HG_UNREF(ctx);

	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

int main (int argc, char** argv)
{
	AKGLUTContext	ctx;

	/* Be nice. */

	nice(5);

	/* Create AppKit and set up context. */
	ctx.ak = AKAppKit_create(&ctx, argv, argc);
	if (!ctx.ak)
		return 1;

	ctx.window			= 0;
	ctx.bufFormatHint	= AK_COLORFORMAT_NONE;
	ctx.bufImage		= NULL;
	gCtx				= &ctx;		/* TODO is there really no way to pass the context pointer to callbacks? */

	{
		int c = 1;
		char empty[] = "test.exe";
		char* param = (char*)empty;
		glutInit( &c, &param );
	}

	if (appInit(ctx.ak))	/* Init application. */
	{
		if (initGLUT(&ctx))
		{
			glutDisplayFunc(displayfunc);
			glutKeyboardFunc(kbdfunc);
			glutSpecialFunc(specialfunc);
			glutKeyboardUpFunc(kbdupfunc);
			glutSpecialUpFunc(specialupfunc);
			glutPassiveMotionFunc(mousefunc);
			glutMotionFunc(mousefunc);
			glutMouseFunc(mouseButtonFunc);
			glutIdleFunc(idlefunc);
			atexit(exitfunc);
			glutMainLoop();
		}
	}
	return 0;
}

/*-----------------------------------------------------------------------*/
