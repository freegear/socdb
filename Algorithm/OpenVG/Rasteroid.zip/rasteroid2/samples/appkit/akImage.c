/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akImage.c#2 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include "akImage.h"

#include <stdlib.h>
#include <string.h>

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

int akGetColorFormatPixelBytes (AKColorFormat format)
{
	static const HGuint32 s_bpp[AK_COLORFORMAT_MAX] = {
		0,				/* AK_COLORFORMAT_NONE */
		4, 4, 4, 4,		/* AK_COLORFORMAT_INT_RGBA */
		4, 4, 4, 4,		/* AK_COLORFORMAT_BYTE_RGBA */
		3, 3,			/* AK_COLORFORMAT_BYTE_RGB */
		2, 2			/* AK_COLORFORMAT_SHORT_ARGB_4444 */
	};

	AK_ASSERT(format >= 0 && format < AK_COLORFORMAT_MAX);
	return s_bpp[format];
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKColorFormat akCanonizeColorFormat (AKColorFormat format)
{
	switch (format)
	{
	case AK_COLORFORMAT_INT_RGBA:
		return (hgGetEndianess() == HG_ENDIAN_BIG) ? AK_COLORFORMAT_BYTE_RGBA : AK_COLORFORMAT_BYTE_ABGR;

	case AK_COLORFORMAT_INT_BGRA:
		return (hgGetEndianess() == HG_ENDIAN_BIG) ? AK_COLORFORMAT_BYTE_BGRA : AK_COLORFORMAT_BYTE_ARGB;

	case AK_COLORFORMAT_INT_ARGB:
		return (hgGetEndianess() == HG_ENDIAN_BIG) ? AK_COLORFORMAT_BYTE_ARGB : AK_COLORFORMAT_BYTE_BGRA;

	case AK_COLORFORMAT_INT_ABGR:
		return (hgGetEndianess() == HG_ENDIAN_BIG) ? AK_COLORFORMAT_BYTE_ABGR : AK_COLORFORMAT_BYTE_RGBA;

	default:
		return format;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akGetColorARGB (AKColorFormat format, const HGuint8* p)
{
	AK_ASSERT(p);
	switch (akCanonizeColorFormat(format))
	{
	case AK_COLORFORMAT_BYTE_RGBA:
		return ((HGuint32)p[0] << 16) | ((HGuint32)p[1] << 8) | ((HGuint32)p[2] << 0) | ((HGuint32)p[3] << 24);

	case AK_COLORFORMAT_BYTE_BGRA:
		return ((HGuint32)p[0] << 0) | ((HGuint32)p[1] << 8) | ((HGuint32)p[2] << 16) | ((HGuint32)p[3] << 24);

	case AK_COLORFORMAT_BYTE_ARGB:
		return ((HGuint32)p[0] << 24) | ((HGuint32)p[1] << 16) | ((HGuint32)p[2] << 8) | ((HGuint32)p[3] << 0);

	case AK_COLORFORMAT_BYTE_ABGR:
		return ((HGuint32)p[0] << 24) | ((HGuint32)p[1] << 0) | ((HGuint32)p[2] << 8) | ((HGuint32)p[3] << 16);

	case AK_COLORFORMAT_BYTE_RGB:
		return 0xff000000 | ((HGuint32)p[0] << 16) | ((HGuint32)p[1] << 8) | ((HGuint32)p[2] << 0);

	case AK_COLORFORMAT_BYTE_BGR:
		return 0xff000000 | ((HGuint32)p[0] << 0) | ((HGuint32)p[1] << 8) | ((HGuint32)p[2] << 16);

	case AK_COLORFORMAT_SHORT_ARGB_4444:
		{
			HGuint32 v = *(const HGuint16*)p;
			return
				((v << 16) & 0xf0000000) |
				((v << 12) & 0x0ff00000) |
				((v << 8) & 0x000ff000) |
				((v << 4) & 0x00000ff0) |
				(v & 0x0000000f);
		}

	case AK_COLORFORMAT_SHORT_RGB_565:
		{
			HGuint32 v = *(const HGuint16*)p;
			return
				0xff000000 |
				((v << 8) & 0x00f80000) |
				((v << 3) & 0x000700f8) |
				((v << 5) & 0x0000fc00) |
				((v >> 1) & 0x00000300) |
				((v >> 2) & 0x00000007);
		}

	default:
		AK_ASSERT(HG_FALSE);
		return 0;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akSetColorARGB (AKColorFormat format, HGuint8* p, HGuint32 argb)
{
	AK_ASSERT(p);
	switch (akCanonizeColorFormat(format))
	{
	case AK_COLORFORMAT_BYTE_RGBA:
		p[0] = (HGuint8)(argb >> 16);
		p[1] = (HGuint8)(argb >> 8);
		p[2] = (HGuint8)(argb >> 0);
		p[3] = (HGuint8)(argb >> 24);
		break;

	case AK_COLORFORMAT_BYTE_BGRA:
		p[0] = (HGuint8)(argb >> 0);
		p[1] = (HGuint8)(argb >> 8);
		p[2] = (HGuint8)(argb >> 16);
		p[3] = (HGuint8)(argb >> 24);
		break;

	case AK_COLORFORMAT_BYTE_ARGB:
		p[0] = (HGuint8)(argb >> 24);
		p[1] = (HGuint8)(argb >> 16);
		p[2] = (HGuint8)(argb >> 8);
		p[3] = (HGuint8)(argb >> 0);
		break;

	case AK_COLORFORMAT_BYTE_ABGR:
		p[0] = (HGuint8)(argb >> 24);
		p[1] = (HGuint8)(argb >> 0);
		p[2] = (HGuint8)(argb >> 8);
		p[3] = (HGuint8)(argb >> 16);
		break;

	case AK_COLORFORMAT_BYTE_RGB:
		p[0] = (HGuint8)(argb >> 16);
		p[1] = (HGuint8)(argb >> 8);
		p[2] = (HGuint8)(argb >> 0);
		break;

	case AK_COLORFORMAT_BYTE_BGR:
		p[0] = (HGuint8)(argb >> 0);
		p[1] = (HGuint8)(argb >> 8);
		p[2] = (HGuint8)(argb >> 16);
		break;

	case AK_COLORFORMAT_SHORT_ARGB_4444:
		*(HGuint16*)p = (HGuint16)(
			((argb >> 16) & 0xf000) |
			((argb >> 12) & 0x0f00) |
			((argb >> 8) & 0x00f0) |
			((argb >> 4) & 0x000f));
		break;

	case AK_COLORFORMAT_SHORT_RGB_565:
		*(HGuint16*)p = (HGuint16)(
			((argb >> 8) & 0xf800) |
			((argb >> 5) & 0x07e0) |
			((argb >> 3) & 0x001f));
		break;

	default:
		AK_ASSERT(HG_FALSE);
		break;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* AKImage_createBlank (int width, int height, AKColorFormat format)
{
	HGint32		rowSize		= akGetColorFormatPixelBytes(format) * width;
	HGint32		dataSize	= rowSize * height;
	AKImage*	image		= malloc(sizeof(AKImage) + dataSize);

	AK_ASSERT(width >= 0 && height >= 0);
	AK_ASSERT(format >= 0 && format < AK_COLORFORMAT_MAX && format != AK_COLORFORMAT_NONE);

	if (!image)
		return NULL;

	image->width	= width;
	image->height	= height;
	image->format	= format;
	image->stride	= rowSize;
	image->data		= (HGuint8*)(image + 1);
	memset(image + 1, 0, dataSize);
	return image;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* AKImage_createBlankDownUp (int width, int height, AKColorFormat format)
{
	HGint32		rowSize		= akGetColorFormatPixelBytes(format) * width;
	HGint32		dataSize	= rowSize * height;
	AKImage*	image		= malloc(sizeof(AKImage) + dataSize);

	AK_ASSERT(width >= 0 && height >= 0);
	AK_ASSERT(format >= 0 && format < AK_COLORFORMAT_MAX && format != AK_COLORFORMAT_NONE);

	if (!image)
		return NULL;

	image->width	= width;
	image->height	= height;
	image->format	= format;
	image->stride	= -rowSize;
	image->data		= (HGuint8*)(image + 1) + rowSize * (height - 1);
	memset(image + 1, 0, dataSize);
	return image;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* AKImage_createForBuffer (int width, int height, AKColorFormat format, int stride, void* data)
{
	AKImage* image = malloc(sizeof(AKImage));

	AK_ASSERT(width >= 0 && height >= 0);
	AK_ASSERT(format >= 0 && format < AK_COLORFORMAT_MAX && format != AK_COLORFORMAT_NONE);

	if (!image)
		return NULL;

	image->width	= width;
	image->height	= height;
	image->format	= format;
	image->stride	= stride;
	image->data		= (HGuint8*)data;
	return image;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* AKImage_createFromBuffer (int width, int height, AKColorFormat format, int stride, const void* data)
{
	AKImage*	image;
	int			y;

	/* Create image. */
	
	image = AKImage_createBlank(width, height, format);
	if (!image)
		return NULL;

	/* Copy data. */

	for (y = 0; y < height; y++)
		memcpy(image->data + y * image->stride, (const HGuint8*)data + y * stride, image->stride);
	return image;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKImage_destroy (AKImage* image)
{
	AK_ASSERT(image);
	free(image);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void AKImage_copyConvert (AKImage* dst, const AKImage* src, int dx, int dy, int sx, int sy, int w, int h)
{
	int				dstFmt	= akCanonizeColorFormat(dst->format);
	int				srcFmt	= akCanonizeColorFormat(src->format);
	int				dstBPP	= akGetColorFormatPixelBytes(dstFmt);
	int				srcBPP	= akGetColorFormatPixelBytes(srcFmt);
	HGuint8*		dstRow	= AKImage_getPixelPtr(dst, dx, dy);
	const HGuint8*	srcRow	= AKImage_getPixelPtr(src, sx, sy);
	int				y;

	AK_ASSERT(dst && src);
	AK_ASSERT(dst != src);
	AK_ASSERT(dx >= 0 && dx + w <= dst->width);
	AK_ASSERT(dy >= 0 && dy + h <= dst->height);
	AK_ASSERT(sx >= 0 && sx + w <= src->width);
	AK_ASSERT(sy >= 0 && sy + h <= src->height);

	for (y = 0; y < h; y++)
	{
		if (srcFmt == dstFmt)
			memcpy(dstRow, srcRow, srcBPP * w);
		else
		{
			HGuint8*		dp	= dstRow;
			const HGuint8*	sp	= srcRow;
			int				x;

			switch ((srcFmt << 16) | (dstFmt))
			{
			/* RGB <-> BGR. */

			case (AK_COLORFORMAT_BYTE_RGBA << 16) | (AK_COLORFORMAT_BYTE_BGRA):
			case (AK_COLORFORMAT_BYTE_BGRA << 16) | (AK_COLORFORMAT_BYTE_RGBA):
				for (x = 0; x < w; x++)
				{
					*dp++ = sp[2];
					*dp++ = sp[1];
					*dp++ = sp[0];
					*dp++ = sp[3];
					sp += 4;
				}
				break;

			case (AK_COLORFORMAT_BYTE_ARGB << 16) | (AK_COLORFORMAT_BYTE_ABGR):
			case (AK_COLORFORMAT_BYTE_ABGR << 16) | (AK_COLORFORMAT_BYTE_ARGB):
				for (x = 0; x < w; x++)
				{
					*dp++ = sp[0];
					*dp++ = sp[3];
					*dp++ = sp[2];
					*dp++ = sp[1];
					sp += 4;
				}
				break;

			case (AK_COLORFORMAT_BYTE_RGB << 16) | (AK_COLORFORMAT_BYTE_BGR):
			case (AK_COLORFORMAT_BYTE_BGR << 16) | (AK_COLORFORMAT_BYTE_RGB):
				for (x = 0; x < w; x++)
				{
					*dp++ = sp[2];
					*dp++ = sp[1];
					*dp++ = sp[0];
					sp += 3;
				}
				break;

			/* Alpha moving. */

			case (AK_COLORFORMAT_BYTE_RGBA << 16) | (AK_COLORFORMAT_BYTE_ARGB):
			case (AK_COLORFORMAT_BYTE_BGRA << 16) | (AK_COLORFORMAT_BYTE_ABGR):
				for (x = 0; x < w; x++)
				{
					*dp++ = sp[3];
					*dp++ = sp[0];
					*dp++ = sp[1];
					*dp++ = sp[2];
					sp += 4;
				}
				break;

			case (AK_COLORFORMAT_BYTE_ARGB << 16) | (AK_COLORFORMAT_BYTE_RGBA):
			case (AK_COLORFORMAT_BYTE_ABGR << 16) | (AK_COLORFORMAT_BYTE_BGRA):
				for (x = 0; x < w; x++)
				{
					*dp++ = sp[1];
					*dp++ = sp[2];
					*dp++ = sp[3];
					*dp++ = sp[0];
					sp += 4;
				}
				break;

			case (AK_COLORFORMAT_BYTE_RGBA << 16) | (AK_COLORFORMAT_BYTE_RGB):
			case (AK_COLORFORMAT_BYTE_BGRA << 16) | (AK_COLORFORMAT_BYTE_BGR):
				for (x = 0; x < w; x++)
				{
					*dp++ = *sp++;
					*dp++ = *sp++;
					*dp++ = *sp++;
					sp++;
				}
				break;

			case (AK_COLORFORMAT_BYTE_ARGB << 16) | (AK_COLORFORMAT_BYTE_RGB):
			case (AK_COLORFORMAT_BYTE_ABGR << 16) | (AK_COLORFORMAT_BYTE_BGR):
				for (x = 0; x < w; x++)
				{
					sp++;
					*dp++ = *sp++;
					*dp++ = *sp++;
					*dp++ = *sp++;
				}
				break;

			case (AK_COLORFORMAT_BYTE_RGB << 16) | (AK_COLORFORMAT_BYTE_RGBA):
			case (AK_COLORFORMAT_BYTE_BGR << 16) | (AK_COLORFORMAT_BYTE_BGRA):
				for (x = 0; x < w; x++)
				{
					*dp++ = *sp++;
					*dp++ = *sp++;
					*dp++ = *sp++;
					*dp++ = 0xff;
				}
				break;

			case (AK_COLORFORMAT_BYTE_RGB << 16) | (AK_COLORFORMAT_BYTE_ARGB):
			case (AK_COLORFORMAT_BYTE_BGR << 16) | (AK_COLORFORMAT_BYTE_ABGR):
				for (x = 0; x < w; x++)
				{
					*dp++ = 0xff;
					*dp++ = *sp++;
					*dp++ = *sp++;
					*dp++ = *sp++;
				}
				break;

			/* Alpha moving, RGB <-> BGR. */

			case (AK_COLORFORMAT_BYTE_RGBA << 16) | (AK_COLORFORMAT_BYTE_ABGR):
			case (AK_COLORFORMAT_BYTE_BGRA << 16) | (AK_COLORFORMAT_BYTE_ARGB):
				for (x = 0; x < w; x++)
				{
					*dp++ = sp[3];
					*dp++ = sp[2];
					*dp++ = sp[1];
					*dp++ = sp[0];
					sp += 4;
				}
				break;

			case (AK_COLORFORMAT_BYTE_ARGB << 16) | (AK_COLORFORMAT_BYTE_BGRA):
			case (AK_COLORFORMAT_BYTE_ABGR << 16) | (AK_COLORFORMAT_BYTE_RGBA):
				for (x = 0; x < w; x++)
				{
					*dp++ = sp[3];
					*dp++ = sp[2];
					*dp++ = sp[1];
					*dp++ = sp[0];
					sp += 4;
				}
				break;

			case (AK_COLORFORMAT_BYTE_RGBA << 16) | (AK_COLORFORMAT_BYTE_BGR):
			case (AK_COLORFORMAT_BYTE_BGRA << 16) | (AK_COLORFORMAT_BYTE_RGB):
				for (x = 0; x < w; x++)
				{
					*dp++ = sp[2];
					*dp++ = sp[1];
					*dp++ = sp[0];
					sp += 4;
				}
				break;

			case (AK_COLORFORMAT_BYTE_ARGB << 16) | (AK_COLORFORMAT_BYTE_BGR):
			case (AK_COLORFORMAT_BYTE_ABGR << 16) | (AK_COLORFORMAT_BYTE_RGB):
				for (x = 0; x < w; x++)
				{
					*dp++ = sp[3];
					*dp++ = sp[2];
					*dp++ = sp[1];
					sp += 4;
				}
				break;

			case (AK_COLORFORMAT_BYTE_RGB << 16) | (AK_COLORFORMAT_BYTE_BGRA):
			case (AK_COLORFORMAT_BYTE_BGR << 16) | (AK_COLORFORMAT_BYTE_RGBA):
				for (x = 0; x < w; x++)
				{
					*dp++ = sp[2];
					*dp++ = sp[1];
					*dp++ = sp[0];
					*dp++ = 0xff;
					sp += 3;
				}
				break;

			case (AK_COLORFORMAT_BYTE_RGB << 16) | (AK_COLORFORMAT_BYTE_ABGR):
			case (AK_COLORFORMAT_BYTE_BGR << 16) | (AK_COLORFORMAT_BYTE_ARGB):
				for (x = 0; x < w; x++)
				{
					*dp++ = 0xff;
					*dp++ = sp[2];
					*dp++ = sp[1];
					*dp++ = sp[0];
					sp += 3;
				}
				break;

			case (AK_COLORFORMAT_INT_ARGB << 16) | (AK_COLORFORMAT_SHORT_ARGB_4444):
				{
					HGuint16* dps = (HGuint16*)dp;
					const HGuint32* spi = (const HGuint32*)sp;
					for (x = 0; x < w; x++)
					{
						HGuint32 v = *spi++;
						*dps++ = (HGuint16)(
							((v >> 16) & 0xf000) |
							((v >> 12) & 0x0f00) |
							((v >> 8) & 0x00f0) |
							((v >> 4) & 0x000f));
					}
				}
				break;

			/* Generic conversion. */

			default:
				if (dstFmt == AK_COLORFORMAT_SHORT_ARGB_4444)
				{
					HGuint16* dps = (HGuint16*)dp;
					for (x = 0; x < w; x++)
					{
						HGuint32 v = akGetColorARGB(srcFmt, sp);
						sp += srcBPP;
						*dps++ = (HGuint16)(
							((v >> 16) & 0xf000) |
							((v >> 12) & 0x0f00) |
							((v >> 8) & 0x00f0) |
							((v >> 4) & 0x000f));
					}
				} else if (dstFmt == AK_COLORFORMAT_SHORT_RGB_565)
				{
					HGuint16* dps = (HGuint16*)dp;
					for (x = 0; x < w; x++)
					{
						HGuint32 v = akGetColorARGB(srcFmt, sp);
						sp += srcBPP;
						*dps++ = (HGuint16)(
							((v >> 8) & 0xf800) |
							((v >> 5) & 0x07e0) |
							((v >> 3) & 0x001f));
					}
				} else
				{
					for (x = 0; x < w; x++)
					{
						akSetColorARGB(dstFmt, dp, akGetColorARGB(srcFmt, sp));
						dp += dstBPP;
						sp += srcBPP;
					}
				}
				break;
			}
		}
		dstRow += dst->stride;
		srcRow += src->stride;
	}
}


/*-------------------------------------------------------------------*//*!
 * \brief 	Creates a copy of the image with the given format.																	
 * \return	If the image cannot be allocated, HG_NULL is returned.
 *//*-------------------------------------------------------------------*/

AKImage* AKImage_createCopy(AKColorFormat format, const AKImage* src)
{
	AKImage* copy = AKImage_createBlank(src->width, src->height, format);
	
	HG_ASSERT(src);

	if (!copy)
		return HG_NULL;

	AKImage_copyConvertFull(copy, src);

	return copy;
}


/*----------------------------------------------------------------------*/
