#ifndef __AKDEFS_H
#define __AKDEFS_H
/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/include/akDefs.h#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#if !defined(__HGDEFS_H)
#	include "hgDefs.h"
#endif

#define AK_ASSERT(c)	HG_ASSERT(c)

/*----------------------------------------------------------------------*/
#endif /* __AKDEFS_H */
