/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akSymbianMain.cpp#3 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include <e32std.h>
#include <coecntrl.h>
#include <eikdoc.h>
#include <aknnotewrappers.h>
#include <aknlists.h>

#if defined HG_SYMBIAN_9
#   include <eikappui.h>
#   include <eikapp.h>
#   include <eikstart.h>
#   include <eikenv.h>
#else
#	include <aknappui.h>
#	include <aknapp.h>
#endif

#ifdef EKA2
#	include <palette.h>
#	define	EColor16MU_HG EColor16MU
#else
#	define EColor16MU_HG 11
#endif

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

#include "akMain.h"
#include "akAppKitPrivate.h"
#include "akUtils.h"

/*#define AK_ENABLE_PROFILER*/

#ifdef AK_ENABLE_PROFILER
#	include "akSymbianProfiler.hpp"
#endif

/*-------------------------------------------------------------------*//*!
 * \brief	CAppView
 *//*-------------------------------------------------------------------*/

class CAppView : public CCoeControl
{
public:
								CAppView				(CApaApplication* app);
								~CAppView				(void);

	void						ConstructL				(const TRect& rect);
	virtual TKeyResponse		OfferKeyEventL			(const TKeyEvent& event, TEventCode type);

	void						createAppWindow			(void);
	void						getTime					(HGuint32* hiMillis, HGuint32* loMillis) const;
	void						exitApp					(void);
	
	AKImage*					lockWindowBuffer		(void);
	void						releaseWindowBuffer		(void);
	
	int							getUniqueID				(void);

private:
	static const char*			translateKey			(TInt code);
	virtual void				Draw					(const TRect& rect) const;
	static TInt					idleCallback			(TAny* self);
	TInt						idle					(void);

	CApaApplication*			m_app;
	CIdle*						m_idleNotify;

	AKAppKit*					m_appkit;
	HGbool						m_appInited;
	HGbool						m_windowCreated;
	TInt64						m_startTime;

	AKImage*					m_bufImage;
	CFbsBitmap*					m_bufBitmap;

#ifdef AK_ENABLE_PROFILER
	SymbianProfiler				m_profiler;
#endif	
	HGint32						m_uniqueID;
};

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

CAppView::CAppView (CApaApplication* app)
:	m_app			(app),
	m_idleNotify	(NULL),
	m_appkit		(NULL),
	m_bufImage		(NULL),
	m_bufBitmap		(NULL),
	m_uniqueID		(0)
{
	m_appInited = HG_FALSE;
	m_windowCreated = HG_FALSE;

	TTime curr;
	curr.UniversalTime();
	m_startTime = curr.Int64() / 1000;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

CAppView::~CAppView (void)
{
	delete m_idleNotify;

	if (m_bufImage)
		AKImage_destroy(m_bufImage);
		
	delete m_bufBitmap;
	
	if (m_appkit)
		AKAppKit_destroy(m_appkit);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void CAppView::getTime (HGuint32* hiMillis, HGuint32* loMillis) const
{
	AK_ASSERT(hiMillis && loMillis);
	TTime curr;
	TInt64 millis;
	curr.UniversalTime();
	millis = curr.Int64() / 1000 - m_startTime;
	*hiMillis = millis.High();
	*loMillis = millis.Low();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

const char* CAppView::translateKey (TInt code)
{
	switch (code)
	{
	case EStdKeyYes:				return "Accept";				/* Commit */
	case EStdKeyLeftAlt:
	case EStdKeyRightAlt:			return "Alt";					/* Menu */
	case EStdKeyMenu:				return "Apps";					/* Application */
	case EStdKeyCapsLock:			return "CapsLock";				/* Capital */
	case EStdKeyLeftCtrl:
	case EStdKeyRightCtrl:			return "Control";				/* Ctrl */
	case EStdKeyDownArrow:			return "Down";					/* Arrow */
	case EStdKeyEnd:				return "End";
	case EStdKeyEnter:
	case EStdKeyNkpEnter:			return "Enter";					/* Return */
	case EStdKeyF1:					return "F1";
	case EStdKeyF2:					return "F2";
	case EStdKeyF3:					return "F3";
	case EStdKeyF4:					return "F4";
	case EStdKeyF5:					return "F5";
	case EStdKeyF6:					return "F6";
	case EStdKeyF7:					return "F7";
	case EStdKeyF8:					return "F8";
	case EStdKeyF9:					return "F9";
	case EStdKeyF10:				return "F10";
	case EStdKeyF11:				return "F11";
	case EStdKeyF12:				return "F12";
	case EStdKeyF13:				return "F13";
	case EStdKeyF14:				return "F14";
	case EStdKeyF15:				return "F15";
	case EStdKeyF16:				return "F16";
	case EStdKeyF17:				return "F17";
	case EStdKeyF18:				return "F18";
	case EStdKeyF19:				return "F19";
	case EStdKeyF20:				return "F20";
	case EStdKeyF21:				return "F21";
	case EStdKeyF22:				return "F22";
	case EStdKeyF23:				return "F23";
	case EStdKeyF24:				return "F24";
	case EStdKeyHelp:				return "Help";
	case EStdKeyHome:				return "Home";
	case EStdKeyInsert:				return "Insert";				/* Ins */
	case EStdKeyApplication0:		return "LaunchApplication1";
	case EStdKeyApplication1:		return "LaunchApplication2";
	case EStdKeyLeftArrow:			return "Left";					/* Arrow */
	case EStdKeyNumLock:			return "NumLock";
	case EStdKeyPageDown:			return "PageDown";				/* Next */
	case EStdKeyPageUp:				return "PageUp";				/* Prior */
	case EStdKeyPause:				return "Pause";
	case EStdKeyDictaphonePlay:		return "Play";
	case EStdKeyPrintScreen:		return "PrintScreen";			/* SnapShot */
	case EStdKeyRightArrow:			return "Right";					/* Arrow */
	case EStdKeyScrollLock:			return "Scroll";				/* Scroll lock */
	case EStdKeyDevice3:			return "Select";
	case EStdKeyLeftShift:
	case EStdKeyRightShift:			return "Shift";
	case EStdKeyDictaphoneStop:		return "Stop";
	case EStdKeyUpArrow:			return "Up";					/* Arrow */
	case EStdKeyDecVolume:			return "VolumeDown";
	case EStdKeyIncVolume:			return "VolumeUp";
	case EStdKeyBackspace:			return "U+0008";				/* Backspace */
	case EStdKeyTab:				return "U+0009";				/* Tab */
	case EStdKeyNo:					return "U+0018";				/* Cancel */
	case EStdKeyEscape:				return "U+001B";				/* Esc */
	case EStdKeySpace:				return "U+0020";				/* Space */
	case EStdKeyHash:				return "U+0023";				/* # */
	case EStdKeySingleQuote:		return "U+0027";				/* ' */
	case EStdKeyNkpAsterisk:		return "U+002A";				/* * */
	case EStdKeyNkpPlus:			return "U+002B";				/* + */
	case EStdKeyComma:				return "U+002C";				/* , */
	case EStdKeyMinus:
	case EStdKeyNkpMinus:			return "U+002D";				/* - */
	case EStdKeyFullStop:
	case EStdKeyNkpFullStop:		return "U+002E";				/* . */
	case EStdKeyForwardSlash:
	case EStdKeyNkpForwardSlash:	return "U+002F";				/* / */
	case '0':
	case EStdKeyNkp0:				return "U+0030";				/* 0 */
	case '1':
	case EStdKeyNkp1:				return "U+0031";				/* 1 */
	case '2':
	case EStdKeyNkp2:				return "U+0032";				/* 2 */
	case '3':
	case EStdKeyNkp3:				return "U+0033";				/* 3 */
	case '4':
	case EStdKeyNkp4:				return "U+0034";				/* 4 */
	case '5':
	case EStdKeyNkp5:				return "U+0035";				/* 5 */
	case '6':
	case EStdKeyNkp6:				return "U+0036";				/* 6 */
	case '7':
	case EStdKeyNkp7:				return "U+0037";				/* 7 */
	case '8':
	case EStdKeyNkp8:				return "U+0038";				/* 8 */
	case '9':
	case EStdKeyNkp9:				return "U+0039";				/* 9 */
	case EStdKeySemiColon:			return "U+003B";				/* ; */
	case EStdKeyEquals:				return "U+003D";				/* = */
	case 'A':						return "U+0041";				/* A */
	case 'B':						return "U+0042";				/* B */
	case 'C':						return "U+0043";				/* C */
	case 'D':						return "U+0044";				/* D */
	case 'E':						return "U+0045";				/* E */
	case 'F':						return "U+0046";				/* F */
	case 'G':						return "U+0047";				/* G */
	case 'H':						return "U+0048";				/* H */
	case 'I':						return "U+0049";				/* I */
	case 'J':						return "U+004A";				/* J */
	case 'K':						return "U+004B";				/* K */
	case 'L':						return "U+004C";				/* L */
	case 'M':						return "U+004D";				/* M */
	case 'N':						return "U+004E";				/* N */
	case 'O':						return "U+004F";				/* O */
	case 'P':						return "U+0050";				/* P */
	case 'Q':						return "U+0051";				/* Q */
	case 'R':						return "U+0052";				/* R */
	case 'S':						return "U+0053";				/* S */
	case 'T':						return "U+0054";				/* T */
	case 'U':						return "U+0055";				/* U */
	case 'V':						return "U+0056";				/* V */
	case 'W':						return "U+0057";				/* W */
	case 'X':						return "U+0058";				/* X */
	case 'Y':						return "U+0059";				/* Y */
	case 'Z':						return "U+005A";				/* Z */
	case EStdKeySquareBracketLeft:	return "U+005B";				/* [ */
	case EStdKeyBackSlash:			return "U+005C";				/* Backslash */
	case EStdKeySquareBracketRight:	return "U+005D";				/* ] */
	case EStdKeyXXX:				return "U+0060";				/* Grave */
	case EStdKeyDelete:				return "U+007F";				/* Del */
	case EStdKeySliderUp:			return "!WheelUp";				/* Custom */
	case EStdKeySliderDown:			return "!WheelDown";			/* Custom */
	case EStdKeyDevice0:			return "LeftSoftKey";
	case EStdKeyDevice1:			return "RightSoftKey";
	default:						return NULL;
	}
}
 
/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void CAppView::ConstructL (const TRect& rect)
{
	CreateWindowL();
	SetRect(rect);

	/* Create AppKit. */

	m_appkit = AKAppKit_create(this, 0, 0);

	/* Create idle notify. */

	m_idleNotify = CIdle::NewL(CActive::EPriorityLow);
	m_idleNotify->Start(TCallBack(idleCallback, this));

	ActivateL();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void CAppView::Draw (const TRect& rect) const
{
	HG_UNREF(rect);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

TInt CAppView::idleCallback (TAny* self)
{
	return ((CAppView*)self)->idle();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

TInt CAppView::idle (void)
{
	if (!m_appInited)
	{
		m_appInited = HG_TRUE;
#ifdef AK_ENABLE_PROFILER
		m_profiler.start(500);
#endif
		if (!appInit(m_appkit) || !m_windowCreated)
			exitApp();
	}

	User::ResetInactivityTime();
	AKAppKit_callUpdate(m_appkit);
	return 1;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

TKeyResponse CAppView::OfferKeyEventL (const TKeyEvent& event, TEventCode type)
{
	if (type == EEventKey)
	{
		if (event.iCode >= ENonCharacterKeyBase)
			return EKeyWasNotConsumed;

		AKAppKit_callCharEvent(m_appkit, event.iScanCode);
		return EKeyWasConsumed;
	}

	const char* keyId = translateKey(event.iScanCode);
	if (!keyId)
		return EKeyWasNotConsumed;

	AKAppKit_callKeyEvent(m_appkit, type == EEventKeyDown, keyId);
	return EKeyWasConsumed;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void CAppView::createAppWindow (void)
{
	m_windowCreated = HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void CAppView::exitApp (void)
{
#ifdef AK_ENABLE_PROFILER
	m_profiler.stop();
	TFileName mapName = m_app->DllName();
	mapName.Append(_L(".map"));
	char buf[KMaxFileName + 1];
	for (int i = 0; i < mapName.Length(); i++)
		buf[i] = (char)mapName[i];
	buf[mapName.Length()] = '\0';
	m_profiler.dump(buf, "c:\\hgtune.txt");
#endif
	
	AKAppKit_destroy(m_appkit);
	User::Exit(0);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* CAppView::lockWindowBuffer (void)
{
	/* Use existing image if we have one. */

	if (m_bufImage)
		return m_bufImage;
	
	/* Get screen info. */
	
	TDisplayMode displayMode = CEikonEnv::Static()->ScreenDevice()->DisplayMode();
	TScreenInfoV01 info;
	TPckg<TScreenInfoV01> infoPkg(info);
	UserSvr::ScreenInfo(infoPkg);

	/* Handle direct screen access. */
	
	if (info.iScreenAddressValid)
	{
		AKColorFormat fmt;

		if (displayMode == EColor4K)
			fmt = AK_COLORFORMAT_SHORT_ARGB_4444;
		if (displayMode == EColor64K)
			fmt = AK_COLORFORMAT_SHORT_RGB_565;
		else if (displayMode == EColor16MU_HG)
			fmt = AK_COLORFORMAT_INT_ARGB;
		else
			fmt = AK_COLORFORMAT_NONE;
		
		if (fmt)
		{
			m_bufImage = AKImage_createForBuffer(
				info.iScreenSize.iWidth, info.iScreenSize.iHeight, fmt,
				info.iScreenSize.iWidth * akGetColorFormatPixelBytes(fmt),
				(HGuint8*)info.iScreenAddress + 32);
			return m_bufImage;
		}
	}
	
	/* Create bitmap if we don't have one. */

	if (!m_bufBitmap)
	{
		m_bufBitmap = new CFbsBitmap;
		if (!m_bufBitmap)
			return NULL;
		if (m_bufBitmap->Create(TSize(Size().iWidth, Size().iHeight), EColor64K) != KErrNone)
		{
			delete m_bufBitmap;
			m_bufBitmap = NULL;
			return NULL;
		}
	}

	/* Create image. */
	
	m_bufImage = AKImage_createForBuffer(
		m_bufBitmap->SizeInPixels().iWidth,
		m_bufBitmap->SizeInPixels().iHeight,
		AK_COLORFORMAT_SHORT_RGB_565,
		m_bufBitmap->ScanLineLength(m_bufBitmap->SizeInPixels().iWidth, m_bufBitmap->DisplayMode()),
		m_bufBitmap->DataAddress());
	return m_bufImage;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void CAppView::releaseWindowBuffer (void)
{
	AK_ASSERT(m_bufImage);
	
	if (m_bufBitmap)
	{
		ActivateGc();
		SystemGc().BitBlt(TPoint(0, 0), m_bufBitmap);
		DeactivateGc();
	} else
	{
		TRawEvent redraw;
		redraw.Set(TRawEvent::ERedraw);
		UserSvr::AddEvent(redraw);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

int CAppView::getUniqueID (void)
{
	return m_uniqueID++;
}

/*-------------------------------------------------------------------*//*!
 * \brief	CAppUi
 *//*-------------------------------------------------------------------*/
#if defined SYMBIAN9
class CAppUi : public CEikAppUi
#else
class CAppUi : public CAknAppUi
#endif
{
public:
							CAppUi			(CApaApplication* app);
	virtual					~CAppUi			(void);
	
	virtual void			ConstructL		(void);
	virtual void			HandleCommandL	(TInt command);

private:
	CApaApplication*		m_app;
	CAppView*				m_appView;
};

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

CAppUi::CAppUi (CApaApplication* app)
:	m_app (app)
{
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

CAppUi::~CAppUi (void)
{
	if (m_appView)
		RemoveFromStack(m_appView);
	delete m_appView;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void CAppUi::ConstructL (void)
{
	BaseConstructL(ENoAppResourceFile);
	SetKeyBlockMode(ENoKeyBlock);

	CAppView* appView = new(ELeave) CAppView(m_app);
	CleanupStack::PushL(appView);
	appView->ConstructL(ApplicationRect());
	appView->SetMopParent(this);
	AddToStackL(appView);
	CleanupStack::Pop();
	m_appView = appView;
}

/*-------------------------------------------------------------------*//*!
 * \brief	Handle menu commands.
 *//*-------------------------------------------------------------------*/

void CAppUi::HandleCommandL (TInt command)
{
	if (command == EEikCmdExit || command == EAknSoftkeyExit)
		Exit();
}

/*-------------------------------------------------------------------*//*!
 * \brief	CDocument
 *//*-------------------------------------------------------------------*/

class CDocument : public CEikDocument
{
public:
							CDocument		(CEikApplication& app);
	virtual					~CDocument		(void);

	virtual CEikAppUi*		CreateAppUiL	(void);
};

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

CDocument::CDocument (CEikApplication& app)
:	CEikDocument (app)
{
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

CDocument::~CDocument (void)
{
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

CEikAppUi* CDocument::CreateAppUiL (void)
{
	return new(ELeave) CAppUi(Application());
}

/*-------------------------------------------------------------------*//*!
 * \brief	CApplication
 *//*-------------------------------------------------------------------*/
#if defined(HG_SYMBIAN_9)
class CApplication : public CEikApplication
#else
class CApplication : public CAknApplication
#endif
{
public:
	virtual TUid			AppDllUid 	 		(void) const;
	virtual TFileName		ResourceFileName	(void) const;

protected:
	virtual CApaDocument*	CreateDocumentL		(void);
};

#if defined HG_SYMBIAN_9
/*-------------------------------------------------------------------*//*!
 * \brief	Create the application instance.
 *//*-------------------------------------------------------------------*/

LOCAL_C CApaApplication* NewApplication()
{
    return new CApplication;
}

GLDEF_C TInt E32Main()
{
    return EikStart::RunApplication(NewApplication);
}

// Return application UID
TUid CApplication::AppDllUid (void) const
{
    static const TUid KUidGraphicsApp = {0x0FB230CE};
    static const TUid KUidGraphicsApp = {0x10281ABA};
    return KUidGraphicsApp;
}

#else

/*-------------------------------------------------------------------*//*!
 * \brief	DLL init.
 *//*-------------------------------------------------------------------*/

GLDEF_C TInt E32Dll (TDllReason)
{
	return KErrNone;
}

/*-------------------------------------------------------------------*//*!
 * \brief	Create the application instance.
 *//*-------------------------------------------------------------------*/

EXPORT_C CApaApplication* NewApplication (void)
{
	return new CApplication;
}


/*-------------------------------------------------------------------*//*!
 * \brief	Return application UID.
 *//*-------------------------------------------------------------------*/

TUid CApplication::AppDllUid (void) const
{
	RFs fs;
	fs.Connect();
	TEntry entry;
	fs.Entry(DllName(), entry);
	fs.Close();
	return entry[2];
}

#endif
/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

TFileName CApplication::ResourceFileName (void) const
{
	return TFileName();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

CApaDocument* CApplication::CreateDocumentL (void)
{
	return new(ELeave) CDocument(*this);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateWindow (AKAppKit* ak, HGuint32 width, HGuint32 height, const char* title, AKColorFormat bufFormatHint)
{
	AK_ASSERT(ak);
	HG_UNREF(width);
	HG_UNREF(height);
	HG_UNREF(title);
	HG_UNREF(bufFormatHint);

	CAppView* ctx = (CAppView*)AKAppKit_getContext(ak);
	AK_ASSERT(ctx);
	ctx->createAppWindow();
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akAdjustWindow (AKAppKit* ak, HGuint32 width, HGuint32 height)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(width);
	HG_UNREF(height);
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akSetWindowTitle (AKAppKit* ak, const char* title)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(title);
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKImage* akLockWindowBuffer (AKAppKit* ak)
{
	AK_ASSERT(ak);
	return ((CAppView*)AKAppKit_getContext(ak))->lockWindowBuffer();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseWindowBuffer (AKAppKit* ak, AKImage* bufImage)
{
	AK_ASSERT(ak && bufImage);
	HG_UNREF(bufImage);
	((CAppView*)AKAppKit_getContext(ak))->releaseWindowBuffer();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akErrorMessage (AKAppKit* ak, const char* msg)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);

	TBuf<1024> buf;
	for (const char* ptr = msg; *ptr; ptr++)
		buf.Append((TChar)*ptr);
	(new(ELeave) CAknErrorNote(ETrue))->ExecuteLD(buf);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAbort (AKAppKit* ak)
{
	HG_ASSERT(ak);
	((CAppView*)AKAppKit_getContext(ak))->exitApp(); /* Is deinit() safe to do here? I doubt */
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akRequestExit (AKAppKit* ak)
{
	HG_ASSERT(ak);
	((CAppView*)AKAppKit_getContext(ak))->exitApp(); /* Is deinit() safe to do here? I doubt */
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akGetTime (AKAppKit* ak, HGuint32* hiMillis, HGuint32* loMillis)
{
	HG_ASSERT(ak && hiMillis && loMillis);
	((CAppView*)AKAppKit_getContext(ak))->getTime(hiMillis, loMillis);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKSurfaceDesc akGetSurface (AKAppKit* ak)
{
	HG_ASSERT(ak);
	CAppView* ctx = (CAppView*)AKAppKit_getContext(ak);

	RDrawableWindow* wnd = ctx->DrawableWindow();
	TSize wndSize = wnd->Size();

	AKSurfaceDesc desc;
	desc.width = wndSize.iWidth;
	desc.height = wndSize.iHeight;
	desc.nativePtr = wnd;

	return desc;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

char* convertTFileName (const TFileName& filename)
{
	HGuint32 l = filename.Length();
	char* str = (char*)malloc(l + 1);
	if (!str)
		return NULL;

	HGuint32 i;
	for (i = 0; i < l; i++)
		str[i] = (char)filename[i];
	str[l] = 0;
	return str;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void pushEntry (AKDirListing* dir, const TEntry& e)
{
	AK_ASSERT(dir);

	char* name = convertTFileName(e.iName);
	if (!name)
		return;

	if (akCompareStrings(name, ".") || akCompareStrings(name, ".."))
	{
		free(name);
		return;
	}

	{
		AKDirEntry* entry = AKDirEntry_create();
		if (!entry)
		{
			free(name);
			return;
		}

		if (e.IsDir())
			entry->flags |= AK_DIRENTRY_FLAGS_DIR;

		akCopyString(entry->filename, name);

		AKDirListing_pushBack(dir, entry);
	}

	free(name);
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

AKDirListing* akGetDirectoryListing (AKAppKit* ak, const char* path)
{
	AK_ASSERT(ak && path);
	HG_UNREF(ak);

	{
		char* fixedPath = akFixPath(path);
		if (!fixedPath)
			return NULL;

		/* Convert slashes and append wildcard. */

		akReplaceSingleChars(fixedPath, "/", "\\");
		akAppendString(&fixedPath, "*");
		if (!fixedPath)
			return NULL;

		TFileName name;
		name.Copy(TPtrC8((TUint8*)fixedPath));

		free(fixedPath);

		AKDirListing* dir = AKDirListing_create();
		if (!dir)
			return NULL;

		CDir* dirList;
		CCoeEnv::Static()->FsSession().GetDir(name, KEntryAttMaskSupported, ESortByName, dirList);
		if (!dirList)
		{
			AKDirListing_destroy(dir);
			return NULL;
		}

		int i;
		for (i = 0; i < dirList->Count(); i++)
			pushEntry(dir, (*dirList)[i]);

		delete dirList;

		return dir;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF TInt threadFunc (TAny* aPtr)
{
	AK_ASSERT(aPtr);
	AKAppKit_threadStarted((AKThreadParams*)aPtr);
	return 0;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akCreateThread (AKAppKit* ak, AKThreadParams* params)
{
	AK_ASSERT(ak && params);
	TBuf<1024> name;
	name.Format(_L("userThread_%d"), ((CAppView*)AKAppKit_getContext(ak))->getUniqueID());
	RThread thread;
	if (thread.Create(name, threadFunc, 8 << 10, 8 << 10, 8 << 20, params) != KErrNone)
		return HG_FALSE;
	thread.Resume();
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGuint32 akGetThreadID (AKAppKit* ak)
{
	AK_ASSERT(ak);
	HG_UNREF(ak);
	return (HGuint32)(TUint)RThread().Id();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void* akCreateSemaphore (AKAppKit* ak)
{
	RSemaphore* semaphore = new RSemaphore;
	AK_ASSERT(ak);
	HG_UNREF(ak);
	if (!semaphore)
		return NULL;
	if (semaphore->CreateLocal(1) != KErrNone)
	{
		delete semaphore;
		return NULL;
	}
	return semaphore;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akDestroySemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	delete (RSemaphore*)semaphore;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akAcquireSemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	((RSemaphore*)semaphore)->Wait();
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

void akReleaseSemaphore (AKAppKit* ak, void* semaphore)
{
	AK_ASSERT(ak && semaphore);
	HG_UNREF(ak);
	((RSemaphore*)semaphore)->Signal();
}

/*----------------------------------------------------------------------*/
