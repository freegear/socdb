#ifndef __AKMAIN_H
#define __AKMAIN_H
/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akMain.h#2 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#if !defined(__AKAPPKITPRIVATE_H)
#	include "akAppKitPrivate.h"
#endif

/*-------------------------------------------------------------------------
 * Backend functions.
 *-----------------------------------------------------------------------*/

HG_EXTERN_C_BLOCK_BEGIN

/* Will be called from the main thread. Not called concurrently. */

HGbool			akCreateWindow			(AKAppKit* ak, HGuint32 width, HGuint32 height, const char* title, AKColorFormat formatHint);
HGbool			akAdjustWindow			(AKAppKit* ak, HGuint32 width, HGuint32 height);
HGbool			akSetWindowTitle		(AKAppKit* ak, const char* title);
AKImage*		akLockWindowBuffer		(AKAppKit* ak);	/* Format need not be the same as formatHint in akCreateWindow(). */
void			akReleaseWindowBuffer	(AKAppKit* ak, AKImage* bufImage);

/* May be called from any thread. Not called concurrently. */

void			akErrorMessage			(AKAppKit* ak, const char* msg);
void			akAbort					(AKAppKit* ak);
void			akRequestExit			(AKAppKit* ak);

void			akGetTime				(AKAppKit* ak, HGuint32* hiMillis, HGuint32* loMillis);
AKSurfaceDesc	akGetSurface			(AKAppKit* ak);

AKDirListing*	akGetDirectoryListing	(AKAppKit* ak, const char* path);

/* May be called from any thread. May be called concurrently. */

HGbool			akCreateThread			(AKAppKit* ak, AKThreadParams* params);
HGuint32		akGetThreadID			(AKAppKit* ak);

void*			akCreateSemaphore		(AKAppKit* ak);	/* Binary semaphore: initial = 1, maximum = 1. */
void			akDestroySemaphore		(AKAppKit* ak, void* semaphore);
void			akAcquireSemaphore		(AKAppKit* ak, void* semaphore);
void			akReleaseSemaphore		(AKAppKit* ak, void* semaphore);

HG_EXTERN_C_BLOCK_END

/*----------------------------------------------------------------------*/
#endif /* __AKMAIN_H */
