#ifndef __AKBMP_H
#define __AKBMP_H
/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/include/akBmp.h#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#if !defined(__AKIMAGE_H)
#	include "akImage.h"
#endif
#if !defined(__AKAPPKIT_H)
#	include "akAppKit.h"
#endif

/*-------------------------------------------------------------------------
 * Bmp functions.
 *-----------------------------------------------------------------------*/

HG_EXTERN_C_BLOCK_BEGIN

HGbool		akExportBmpImage		(AKAppKit* ak, const char* filename, AKImage* image);
HGbool		akExportBmpBuffer		(AKAppKit* ak, const char* filename, int width, int height, AKColorFormat format, int stride, const void* data);
AKImage*	akImportBmpImage		(AKAppKit* ak, const char* filename);
HGbool		akImportBmpImageB		(AKAppKit* ak, const char* filename, AKImage* image);


HG_EXTERN_C_BLOCK_END

/*----------------------------------------------------------------------*/
#endif /* __AKBMP_H */
