#ifndef __AKUTILS_H
#define __AKUTILS_H
/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/include/akUtils.h#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#if !defined(__AKDEFS_H)
#	include "akDefs.h"
#endif

/*-------------------------------------------------------------------------
 *
 *-----------------------------------------------------------------------*/

HG_EXTERN_C_BLOCK_BEGIN

/* String functions. */

char*			akCreateString			(HGuint32 length);

char*			akDuplicateString		(const char* str);

HGuint32		akStringLength			(const char* str);
HGuint32		akStringLength16		(const HGuint16* str);
HGuint32		akStringCountChars		(const char* str, const char* chars);

void			akCopyString			(char* tgt, const char* src);
HGbool			akAppendString			(char** tgt, const char* src); /* Returns false if fails. */
char*			akCatenateStrings		(const char* first, const char* second);

HGbool			akCompareStrings		(const char* a, const char* b);

void			akAdvanceString			(char** str, char stopChar);
void			akRemoveChars			(char** str, const char* chars);
void			akReplaceSingleChars	(char* str, const char* from, const char* to);
void			akReplaceSingleCharsN	(char* str, const char* from, const char* to, HGuint32 count);

char*			akFixPath				(const char* path);
char*			akReconstructPath		(const char* path);

HGuint16*		akConvertString8To16	(const char* str);
char*			akConvertString16To8	(const HGuint16* str);

/* Endianess */

HGuint16	akChangeOrderUInt16			(HGuint16 v);
HGuint32	akChangeOrderUInt32			(HGuint32 v);

HGuint16	akGetLittleEndianUInt16		(HGuint16 v);
HGuint32	akGetLittleEndianUInt32		(HGuint32 v);
HGuint16	akGetBigEndianUInt16		(HGuint16 v);
HGuint32	akGetBigEndianUInt32		(HGuint32 v);

HG_EXTERN_C_BLOCK_END

/*----------------------------------------------------------------------*/
#endif /* __AKUTILS_H */
