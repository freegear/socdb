#ifndef __AKAPPKIT_H
#define __AKAPPKIT_H
/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/include/akAppKit.h#2 $
 * $Date: 2006/03/10 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#if !defined(__AKDEFS_H)
#	include "akDefs.h"
#endif
#if !defined(__AKARG_H)
#	include "akArg.h"
#endif
#if !defined(__AKDIRLISTING_H)
#	include "akDirListing.h"
#endif
#if !defined(__AKIMAGE_H)
#	include "akImage.h"
#endif

/*-------------------------------------------------------------------------
 * Constants.
 *-----------------------------------------------------------------------*/

#define AK_DEFAULT_WINDOW_WIDTH		320
#define AK_DEFAULT_WINDOW_HEIGHT	240

/*-------------------------------------------------------------------------
 * Forward declarations.
 *-----------------------------------------------------------------------*/

typedef struct AKAppKit_s	AKAppKit;
typedef struct AKMonitor_s	AKMonitor;

/*-------------------------------------------------------------------------
 * AKSurfaceDesc.
 *-----------------------------------------------------------------------*/

typedef struct AKSurfaceDesc_s
{
	HGint32		width;
	HGint32		height;
	void*		nativePtr;
} AKSurfaceDesc;

HG_HEADER_CT_ASSERT(AKAPPKIT_H, sizeof(AKSurfaceDesc) == 3 * 4);

/*-------------------------------------------------------------------------
 * Application callback functions. Called by AppKit from the main thread.
 * DOM3 key identifier strings are used in keyEventFunc().
 * http://www.w3.org/TR/DOM-Level-3-Events/keyset.html
 *-----------------------------------------------------------------------*/

typedef void	(*AKAppKit_deinitFunc)			(AKAppKit* ak);

typedef void	(*AKAppKit_surfaceChangedFunc)	(AKAppKit* ak, AKSurfaceDesc desc);

typedef void	(*AKAppKit_keyEventFunc)		(AKAppKit* ak, HGbool down, const char* data);
typedef void	(*AKAppKit_charEventFunc)		(AKAppKit* ak, HGuint32 c);
typedef void	(*AKAppKit_ptrEventFunc)		(AKAppKit* ak, HGbool known, HGint32 x, HGint32 y);

typedef void	(*AKAppKit_updateFunc)			(AKAppKit* ak, HGint32 timeDelta);

typedef void	(*AKAppKit_threadFunc)			(AKAppKit* ak, void* param);

/*-------------------------------------------------------------------------
 * AKAppKitParams.
 *-----------------------------------------------------------------------*/

typedef struct AKAppKitParams_s
{
	AKAppKit_deinitFunc			deinit;

	AKAppKit_surfaceChangedFunc	surfaceChanged;

	AKAppKit_keyEventFunc		keyEvent;
	AKAppKit_charEventFunc		charEvent;
	AKAppKit_ptrEventFunc		ptrEvent;

	AKAppKit_updateFunc			update;

	void*						userPtr;
} AKAppKitParams;

HG_HEADER_CT_ASSERT(AKAPPKIT_H, sizeof(AKAppKitParams) == 7 * 4);

HG_EXTERN_C_BLOCK_BEGIN

void			AKAppKitParams_clear			(AKAppKitParams* params);

/*-------------------------------------------------------------------------
 * Application main program. Called by AppKit from the main thread.
 *-----------------------------------------------------------------------*/

HGbool			appInit							(AKAppKit* app);	/* AppKit will exit if false is returned. */

/*-------------------------------------------------------------------------
 * AKAppKit public methods. These are all thread safe.
 *-----------------------------------------------------------------------*/

void			AKAppKit_initParams				(AKAppKit* ak, const AKAppKitParams* params);

/* Window management. Must be called from the main thread. */

HGbool			AKAppKit_createWindow			(AKAppKit* ak, HGuint32 width, HGuint32 height, const char* title, AKColorFormat bufferFormat);
HGbool			AKAppKit_adjustWindow			(AKAppKit* ak, HGuint32 width, HGuint32 height);
HGbool			AKAppKit_setWindowTitle			(AKAppKit* ak, const char* title);
AKImage*		AKAppKit_lockWindowBuffer		(AKAppKit* ak);	/* Image is always of the requested format. */
void			AKAppKit_releaseWindowBuffer	(AKAppKit* ak);

/* Printing and error reporting. */

void			AKAppKit_printf					(AKAppKit* ak, const char* format, ...);
void			AKAppKit_errorPrintf			(AKAppKit* ak, const char* format, ...);
void			AKAppKit_abort					(AKAppKit* ak, const char* format, ...);
void			AKAppKit_requestExit			(AKAppKit* ak);

/* Command line arguments. */

AKArg*			AKAppKit_getArg					(AKAppKit* ak, const char* name);
HGuint32		AKAppKit_getArgCount			(AKAppKit* ak);
AKArg*			AKAppKit_getArgByIndex			(AKAppKit* ak, HGuint32 index);

/* Miscellaneous getters. */

void*			AKAppKit_getUserPtr				(AKAppKit* ak);
HGuint32		AKAppKit_getTime				(AKAppKit* ak);
void			AKAppKit_getTimeWide			(AKAppKit* ak, HGuint32* hiMillis, HGuint32* loMillis);
AKSurfaceDesc	AKAppKit_getSurface				(AKAppKit* ak);

/* Directory listing. */

AKDirListing*	AKAppKit_getDirectoryListing	(AKAppKit* ak, const char* path);

/* Multithreading. */

HGbool			AKAppKit_createThread			(AKAppKit* ak, AKAppKit_threadFunc func, void* param);
HGuint32		AKAppKit_getThreadID			(AKAppKit* ak);
AKMonitor*		AKAppKit_createMonitor			(AKAppKit* ak);

/*-------------------------------------------------------------------------
 * AKMonitor methods. The behavior is the same as in Java.
 *-----------------------------------------------------------------------*/

void			AKMonitor_destroy				(AKMonitor* monitor);	/* The monitor must not be currently used. */
void			AKMonitor_enter					(AKMonitor* monitor);	/* Will not cause a deadlock if called multiple times. */
void			AKMonitor_leave					(AKMonitor* monitor);
void			AKMonitor_wait					(AKMonitor* monitor);	/* Waits for a notify. The monitor must have been entered. */
void			AKMonitor_notify				(AKMonitor* monitor);	/* Wakes up a single waiting thread. The monitor must have been entered. */
void			AKMonitor_notifyAll				(AKMonitor* monitor);	/* Wakes up all waiting threads. The monitor must have been entered. */

HG_EXTERN_C_BLOCK_END

/*----------------------------------------------------------------------*/
#endif /* __AKAPPKIT_H */
