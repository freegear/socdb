/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akTga.c#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#include "akTga.h"
#include "akUtils.h"

#include <stdio.h>
#include <stdlib.h>

/*-------------------------------------------------------------------------
 * TGA Header.
 * \todo [tero 14/Nov/05] This is getting a bit hard to follow.
 *						  Because of the alignment, we basically lose
 *						  the benefit of using a struct.
 *-----------------------------------------------------------------------*/

static const HGuint32 AK_TGA_HEADER_FIRST_PART_OFFSET = 0;
static const HGuint32 AK_TGA_HEADER_FIRST_PART_LENGTH = 3;
static const HGuint32 AK_TGA_HEADER_SECOND_PART_OFFSET = 4;
static const HGuint32 AK_TGA_HEADER_SECOND_PART_LENGTH = 5;
static const HGuint32 AK_TGA_HEADER_THIRD_PART_OFFSET = 12;
static const HGuint32 AK_TGA_HEADER_THIRD_PART_LENGTH = 10;

typedef struct AKTgaHeader_s
{
	HGuint8		idLength;		/* 0 */
	HGuint8		colorMapType;
	HGuint8		imageType;

	HGuint8		padA;			/* ignored */

	HGuint16	cmapStart;		/* 4 */
	HGuint16	cmapLength;
	HGuint8		cmapDepth;

	HGuint8		padB[3];		/* ignored */
	
	HGuint16	xOffset;		/* 12 */
	HGuint16	yOffset;
	HGuint16	width;
	HGuint16	height;
	HGuint8		pixelDepth;
	HGuint8		imageDescriptor;

	HGuint16	padC;			/* ignored */
} AKTgaHeader;

HG_CT_ASSERT(sizeof(AKTgaHeader) == 24);

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF void AKTgaHeader_clear (AKTgaHeader* header)
{
	header->idLength		= 0;
	header->colorMapType	= 0;
	header->imageType		= 2;
	header->cmapStart		= 0;
	header->cmapLength		= 0;
	header->cmapDepth		= 0;
	header->xOffset			= 0;
	header->yOffset			= 0;
	header->width			= 0;
	header->height			= 0;
	header->pixelDepth		= 32;
	header->imageDescriptor	= 8;	/* 8 bits of alpha */
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akExportTgaImage (AKAppKit* ak, const char* filename, AKImage* image)
{
	FILE*		f;
	AKTgaHeader	header;
	HGuint8*	rowBuf;
	int			y;

	AK_ASSERT(ak && filename && image);
	HG_UNREF(ak);

	f = fopen(filename, "wb");
	if (!f)
		return HG_FALSE; /* File open failed. */

	AKTgaHeader_clear(&header);

	header.width = akGetLittleEndianUInt16((HGuint16)image->width);
	header.height = akGetLittleEndianUInt16((HGuint16)image->height);

	fwrite(((HGuint8*)&header) + AK_TGA_HEADER_FIRST_PART_OFFSET, 1, AK_TGA_HEADER_FIRST_PART_LENGTH, f);
	fwrite(((HGuint8*)&header) + AK_TGA_HEADER_SECOND_PART_OFFSET, 1, AK_TGA_HEADER_SECOND_PART_LENGTH, f);
	fwrite(((HGuint8*)&header) + AK_TGA_HEADER_THIRD_PART_OFFSET, 1, AK_TGA_HEADER_THIRD_PART_LENGTH, f);

	rowBuf = malloc(image->width * 4);
	if (!rowBuf)
	{
		fclose(f);
		return HG_FALSE;
	}

	for (y = image->height - 1; y >= 0; y--)
	{
		HGuint8*	p = rowBuf;
		int			x;

		for (x = 0; x < image->width; x++)
		{
			HGuint32 argb = AKImage_getPixelARGB(image, x, y);
			*p++ = (HGuint8)(argb >> 0);
			*p++ = (HGuint8)(argb >> 8);
			*p++ = (HGuint8)(argb >> 16);
			*p++ = (HGuint8)(argb >> 24);
		}

		fwrite(rowBuf, 1, image->width * 4, f);
	}

	fclose(f);
	free(rowBuf);
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HGbool akExportTgaBuffer (AKAppKit* ak, const char* filename, int width, int height, AKColorFormat format, int stride, const void* data)
{
	AKImage*	image;
	HGbool		ok = HG_FALSE;
	AK_ASSERT(ak && data && filename);

	image = AKImage_createFromBuffer(width, height, format, stride, data);
	if (image)
	{
		ok = akExportTgaImage(ak, filename, image);
		AKImage_destroy(image);
	}
	return ok;
}

/*-------------------------------------------------------------------*//*!
 * \brief Loads a TGA file. Supports uncompressed 24 and 32-bit files.
 *			This is a bit hacky, should be cleaned up.
 * \param	ak			appkit context
 * \param	filename	fullpath to bmp to be loaded
 * \return	pointer to a new AKImage
 * \TODO:	Support for RLE compressed and paletted files, etc.
 *//*-------------------------------------------------------------------*/

enum TgaFormats
{
	TGA_NOIMAGE					= 0,
	TGA_UNCOMPRESSEDCOLORMAP	= 1,
	TGA_UNCOMPRESSEDRGB			= 2,			/* supported */
	TGA_UNCOMPRESSEDBW			= 3,
	TGA_RLECOLORMAP				= 9,
	TGA_RLERGB					= 10,
	TGA_COMPRESSEDBW			= 11,
	TGA_COMPRESSEDCOLORMAP		= 32,
	TGA_COMPRESSEDCOLORMAP2		= 33
};

#define AK_TARGA_HEADER_SIZE		18

static HGuint32 pack(HGuint32 a, HGuint32 r, HGuint32 g, HGuint32 b)
{
	return (a << 24) | (r << 16) | (g << 8) | b;
}

AKImage* akImportTgaImage (AKAppKit* ak, const char* filename)
{
	FILE* f;
	HGuint8* buf;
	HGuint8* input;
	int	id_lgt,cmap_esize,pix_size,flip,cmap_lgt,datatype;
	int	depth,w,h,c;
	unsigned char r,e;
	int	i,j;
	AKImage*	result = HG_NULL;

	AK_ASSERT(ak && filename);
	HG_UNREF(ak);

	f = fopen(filename, "rb");
	if (!f)
		return HG_NULL;
	buf = (HGuint8*)malloc(AK_TARGA_HEADER_SIZE);
	if (!buf)
	{
		fclose(f);
		return HG_NULL;
	}

	/* Load targa header */
	if (fread((void*)buf,AK_TARGA_HEADER_SIZE,1,f) != 1)
	{	
		fclose(f);
		free(buf);
		return HG_NULL;
	}

	input = buf;
	r = *input++;
	id_lgt = r;					/*identification field length (1)*/

	input++;					/*color map type (1)*/

	r = *input++;
	datatype = r; 				/*image type code (1)*/
	if(datatype != TGA_UNCOMPRESSEDRGB && datatype != TGA_RLERGB)
	{	
		fclose(f);
		free(buf);
		return HG_NULL;			/*unsupported format*/
	}

	/*cmap specification (5 bytes)*/
	input += 2;					/*index of first cmap entry (2)*/

	r = *input++;
	e = *input++;
	cmap_lgt = e*256+r;			/*number of cmap entries (2)*/

	r = *input++;
	cmap_esize = r;				/*cmap entry size in bits (1)*/

	/*image specification (10 bytes)*/
	input += 2;					/*lower left x (2)*/
	input += 2;					/*lower left y (2)*/

	r = *input++;
	e = *input++;
	w = e*256+r;				/*width of the picture (2)*/

	r = *input++;
	e = *input++;
	h = e*256+r;				/*height of the picture (2)*/

	r = *input++;
	pix_size = r;				/*size of a pixel in bits (1)*/
	depth = r / 8;
	if(depth < 3 || depth > 4)
	{	
		fclose(f);
		free(buf);
		return HG_NULL;			/*unsupported color depth*/
	}

	r = *input++;
	flip = (r & 32) ? 0 : 1;				/*image descriptor: bit 5 = flip y (1)*/

	free(buf);

	/*image identification field (id_lgt bytes)*/
	if(fseek(f, id_lgt, SEEK_CUR))
	{	
		fclose(f);
		return HG_NULL;
	}

	/*color map data (entries * entrybits / 8)*/
	if(fseek(f, cmap_lgt*cmap_esize/8, SEEK_CUR))
	{	
		fclose(f);
		return HG_NULL;
	}

	/* Create Image */
	result = AKImage_createBlank(w,h,AK_COLORFORMAT_BYTE_RGBA);
	if (!result)
	{
		fclose(f);
		return HG_NULL;
	}

	switch (datatype)
	{
	case TGA_NOIMAGE:
		break;

	case TGA_UNCOMPRESSEDRGB:
		for (i=0;i<h;i++)
		{
			int y = flip ? h-1-i : i;
			for (j=0;j<w;j++)
			{
				HGuint8 color[4];
				if (fread((void*)color,depth,1,f) != 1)
				{	
					AKImage_destroy(result);
					fclose(f);
					return HG_NULL;
				}
				if(depth == 3)
					AKImage_setPixelARGB(result,j,y, pack(255, color[2], color[1], color[0]));
				else
					AKImage_setPixelARGB(result,j,y, pack(color[3], color[2], color[1], color[0]));
				/* TODO handle depth == 2 */
			}
		}
		break;

	case TGA_RLERGB:
		for(c=0;c<w*h;)
		{
			HGuint8 packet;
			int repeat;
			if (fread((void*)&packet,1,1,f) != 1)
			{	
				AKImage_destroy(result);
				fclose(f);
				return HG_NULL;
			}
			repeat = (packet & 0x7f) + 1;
			if(packet & 0x80)
			{	/* RLE packet */
				HGuint8 color[4];
				HGuint32 argb;
				if (fread((void*)color,depth,1,f) != 1)
				{	
					AKImage_destroy(result);
					fclose(f);
					return HG_NULL;
				}
				if(depth == 3)
					argb = pack(255, color[2], color[1], color[0]);
				else
					argb = pack(color[3], color[2], color[1], color[0]);
				/* else TODO handle depth == 2 */
				for(i=0;i<repeat;i++,c++)
				{
					int x = c % w;
					int y = c / w;
					if(flip)
						y = h-1-y;
					AKImage_setPixelARGB(result,x,y,argb);
				}
			}
			else
			{	/* raw packet */
				for(i=0;i<repeat;i++,c++)
				{
					HGuint8 color[4];
					HGuint32 argb;
					int x = c % w;
					int y = c / w;
					if(flip)
						y = h-1-y;
					if (fread((void*)color,depth,1,f) != 1)
					{	
						AKImage_destroy(result);
						fclose(f);
						return HG_NULL;
					}
					if(depth == 3)
						argb = pack(255, color[2], color[1], color[0]);
					else
						argb = pack(color[3], color[2], color[1], color[0]);
					/* else TODO handle depth == 2 */
					AKImage_setPixelARGB(result,x,y,argb);
				}
			}
		}
		break;
	}
	fclose(f);
	return result;
}
