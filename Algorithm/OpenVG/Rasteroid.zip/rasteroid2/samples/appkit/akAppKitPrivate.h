#ifndef __AKAPPKITPRIVATE_H
#define __AKAPPKITPRIVATE_H
/*------------------------------------------------------------------------
 *
 * AppKit
 * ------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Graphics, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irreparable harm to
 * Hybrid Graphics and legal action against the party in breach.
 *
 * $Id: //hybrid/libs/appkit/1.0/src/akAppKitPrivate.h#1 $
 * $Date: 2006/03/08 $
 * $Author: tero $
 *//*-------------------------------------------------------------------*/

#if !defined(__AKAPPKIT_H)
#	include "akAppKit.h"
#endif

/*-------------------------------------------------------------------------
 * Forward declarations.
 *-----------------------------------------------------------------------*/

typedef struct AKThreadParams_s		AKThreadParams;
typedef struct AKMutex_s			AKMutex;

/*-------------------------------------------------------------------------
 * AKAppKit methods which shouldn't be used outside this library.
 *-----------------------------------------------------------------------*/

HG_EXTERN_C_BLOCK_BEGIN

AKAppKit*				AKAppKit_create				(void* ctx, char** argv, HGuint32 argc);
void					AKAppKit_destroy			(AKAppKit* ak);

void*					AKAppKit_getContext			(AKAppKit* ak);
void					AKAppKit_outputString		(AKAppKit* ak, const char* msg);
void					AKAppKit_threadStarted		(AKThreadParams* params);

/* Events. Must be called from the main thread. */

void					AKAppKit_callKeyEvent		(AKAppKit* ak, HGbool down, const char* data);
void					AKAppKit_callCharEvent		(AKAppKit* ak, HGuint32 c);
void					AKAppKit_callPtrEvent		(AKAppKit* ak, HGbool known, HGint32 x, HGint32 y);
void					AKAppKit_callUpdate			(AKAppKit* ak);

HG_EXTERN_C_BLOCK_END

/*----------------------------------------------------------------------*/
#endif /* __AKAPPKITPRIVATE_H */
