/*------------------------------------------------------------------------
 *
 * OpenVG Example 1
 * -------------------------------
 *
 * (C) 2002-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example1/ex1.c#1 $
 * $Date: 2006/03/06 $
 * $Author: sampo $ *
 *
 *//*-------------------------------------------------------------------*/

#include "ex1.h"
#include "dude.h"
#include <vg/openvg.h>
#include <vg/vgu.h>
#include <stdlib.h>

typedef struct
{
	VGFillRule		m_fillRule;
	VGPaintMode		m_paintMode;
	VGCapStyle		m_capStyle;
	VGJoinStyle		m_joinStyle;
	float			m_miterLimit;
	float			m_strokeWidth;
	VGPaint			m_fillPaint;
	VGPaint			m_strokePaint;
	VGPath			m_path;
} PathData;

typedef struct
{
	PathData*		m_paths;
	int				m_numPaths;
	float			m_zoom;
	float			m_x;
	float			m_y;
	float			m_shear;
	float			m_rotation;

	int				m_isZoomingIn;
	int				m_isZoomingOut;
	int				m_isMovingLeft;
	int				m_isMovingRight;
	int				m_isMovingUp;
	int				m_isMovingDown;
	int				m_isShearingRight;
	int				m_isShearingLeft;
	int				m_isRotatingCW;
	int				m_isRotatingCCW;
} PS;

/*-------------------------------------------------------------------*//*!
 * \brief	construct the data structure containing all the data of
 *			the this example
 * \param	commands		The path commands of the example
 * \param	commandCount	The number of commands
 * \param	points			The controls point
 * \param	pointCount		The number of points
 * \return	The created structure
 *//*-------------------------------------------------------------------*/

PS* PS_construct(const char* commands, int commandCount, const float* points, int pointCount)
{
	PS* ps = (PS*)malloc(sizeof(PS));
	int p = 0;
	int c = 0;
	int i = 0;
	int paths = 0;
	int maxElements = 0;
	unsigned char* cmd;
	(void)(pointCount);

	ps->m_zoom		= 1.f;
	/* Little tweaking so that the dude is initially in the middle */
	ps->m_x			= -dudeMinX - (dudeMaxX - dudeMinX)*0.5f;
	ps->m_y			= -dudeMinY - (dudeMaxY - dudeMinY)*0.5f;
	ps->m_shear		= 0.f;
	ps->m_rotation	= 0.f;
	ps->m_isZoomingIn		= 0;
	ps->m_isZoomingOut		= 0;
	ps->m_isMovingLeft		= 0;
	ps->m_isMovingRight		= 0;
	ps->m_isMovingUp		= 0;
	ps->m_isMovingDown		= 0;
	ps->m_isShearingRight	= 0;
	ps->m_isShearingLeft	= 0;
	ps->m_isRotatingCW		= 0;
	ps->m_isRotatingCCW		= 0;

	while(c < commandCount)
	{
		int elements, e;
		c += 4;
		p += 8;
		elements = (int)points[p++];
		EX_ASSERT(elements > 0);
		if(elements > maxElements)
			maxElements = elements;
		for(e=0;e<elements;e++)
		{
			switch(commands[c])
			{
			case 'M': p += 2; break;
			case 'L': p += 2; break;
			case 'C': p += 6; break;
			case 'E': break;
			default:
				EX_ASSERT(0);		/* unknown command */
			}
			c++;
		}
		paths++;
	}

	ps->m_numPaths = paths;
	ps->m_paths = (PathData*)malloc(paths * sizeof(PathData));
	cmd = (unsigned char*)malloc(maxElements);

	i = 0;
	p = 0;
	c = 0;
	while(c < commandCount)
	{
		int elements, startp, e;
		float color[4];

		/* fill type */
		int paintMode = 0;
		ps->m_paths[i].m_fillRule = VG_NON_ZERO;
		switch( commands[c] )
		{
		case 'N':
			paintMode |= VG_FILL_PATH;
			break;
		case 'F':
			ps->m_paths[i].m_fillRule = VG_NON_ZERO;
			paintMode |= VG_FILL_PATH;
			break;
		case 'E':
			ps->m_paths[i].m_fillRule = VG_EVEN_ODD;
			paintMode |= VG_FILL_PATH;
			break;
		default:
			EX_ASSERT(0);		/* unknown command */
		}
		c++;

		/* stroke */
		switch( commands[c] )
		{
		case 'N':
			break;
		case 'S':
			paintMode |= VG_STROKE_PATH;
			break;
		default:
			EX_ASSERT(0);		/* unknown command */
		}
		ps->m_paths[i].m_paintMode = (VGPaintMode)paintMode;
		c++;

		/* line cap */
		switch( commands[c] )
		{
		case 'B':
			ps->m_paths[i].m_capStyle = VG_CAP_BUTT;
			break;
		case 'R':
			ps->m_paths[i].m_capStyle = VG_CAP_ROUND;
			break;
		case 'S':
			ps->m_paths[i].m_capStyle = VG_CAP_SQUARE;
			break;
		default:
			EX_ASSERT(0);		/* unknown command */
		}
		c++;

		/* line join */
		switch( commands[c] )
		{
		case 'M':
			ps->m_paths[i].m_joinStyle = VG_JOIN_MITER;
			break;
		case 'R':
			ps->m_paths[i].m_joinStyle = VG_JOIN_ROUND;
			break;
		case 'B':
			ps->m_paths[i].m_joinStyle = VG_JOIN_BEVEL;
			break;
		default:
			EX_ASSERT(0);		/* unknown command */
		}
		c++;

		/* the rest of stroke attributes */
		ps->m_paths[i].m_miterLimit = points[p++];
		ps->m_paths[i].m_strokeWidth = points[p++];

		/* paints */
		color[0] = points[p++];
		color[1] = points[p++];
		color[2] = points[p++];
		color[3] = 1.0f;
		ps->m_paths[i].m_strokePaint = vgCreatePaint();
		vgSetParameteri(ps->m_paths[i].m_strokePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
		vgSetParameterfv(ps->m_paths[i].m_strokePaint, VG_PAINT_COLOR, 4, color);

		color[0] = points[p++];
		color[1] = points[p++];
		color[2] = points[p++];
		color[3] = 1.0f;
		ps->m_paths[i].m_fillPaint = vgCreatePaint();
		vgSetParameteri(ps->m_paths[i].m_fillPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
		vgSetParameterfv(ps->m_paths[i].m_fillPaint, VG_PAINT_COLOR, 4, color);

		/* read number of elements */

		elements = (int)points[p++];
		EX_ASSERT(elements > 0);
		startp = p;
		for(e=0;e<elements;e++)
		{
			switch( commands[c] )
			{
			case 'M':
				cmd[e] = VG_MOVE_TO | VG_ABSOLUTE;
				p += 2;
				break;
			case 'L':
				cmd[e] = VG_LINE_TO | VG_ABSOLUTE;
				p += 2;
				break;
			case 'C':
				cmd[e] = VG_CUBIC_TO | VG_ABSOLUTE;
				p += 6;
				break;
			case 'E':
				cmd[e] = VG_CLOSE_PATH;
				break;
			default:
				EX_ASSERT(0);		/* unknown command */
			}
			c++;
		}

		ps->m_paths[i].m_path = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, (unsigned int)VG_PATH_CAPABILITY_ALL);
		vgAppendPathData(ps->m_paths[i].m_path, elements, cmd, points + startp);
		i++;
	}
	free(cmd);
	return ps;
}

/*-------------------------------------------------------------------*//*!
 * \brief	free all the data of the this example
 * \param	ps	The example data structure
 * \return	
 *//*-------------------------------------------------------------------*/

void PS_destruct(PS* ps)
{
	int i;
	EX_ASSERT(ps);
	for(i=0;i<ps->m_numPaths;i++)
	{
		vgDestroyPaint(ps->m_paths[i].m_fillPaint);
		vgDestroyPaint(ps->m_paths[i].m_strokePaint);
		vgDestroyPath(ps->m_paths[i].m_path);
	}
	free(ps->m_paths);
	free(ps);
}

/*-------------------------------------------------------------------*//*!
 * \brief	render the example
 * \param	ps	The example data structure
 * \return	
 *//*-------------------------------------------------------------------*/

void PS_render(PS* ps)
{
	int i;
	EX_ASSERT(ps);
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);

	for(i=0;i<ps->m_numPaths;i++)
	{
		vgSeti(VG_FILL_RULE, ps->m_paths[i].m_fillRule);
		vgSetPaint(ps->m_paths[i].m_fillPaint, VG_FILL_PATH);

		if(ps->m_paths[i].m_paintMode & VG_STROKE_PATH)
		{
			vgSetf(VG_STROKE_LINE_WIDTH, ps->m_paths[i].m_strokeWidth);
			vgSeti(VG_STROKE_CAP_STYLE, ps->m_paths[i].m_capStyle);
			vgSeti(VG_STROKE_JOIN_STYLE, ps->m_paths[i].m_joinStyle);
			vgSetf(VG_STROKE_MITER_LIMIT, ps->m_paths[i].m_miterLimit);
			vgSetPaint(ps->m_paths[i].m_strokePaint, VG_STROKE_PATH);
		}
		vgDrawPath(ps->m_paths[i].m_path, ps->m_paths[i].m_paintMode);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	init the example
 * \param	
 * \return	A pointer to the data structure allocated by the example
 *//*-------------------------------------------------------------------*/

void* ex1_init()
{
	vgSeti(VG_MATRIX_MODE, VG_MATRIX_PATH_USER_TO_SURFACE);
	return (void*) PS_construct(dudeCommands, dudeCommandCount, dudePoints, dudePointCount);
}

/*-------------------------------------------------------------------*//*!
 * \brief	deinit the example
 * \param	example		The example data structure
 * \return	
 *//*-------------------------------------------------------------------*/

void ex1_deinit(void* example)
{
	EX_ASSERT(example);
	PS_destruct((PS*) example);
}

/*-------------------------------------------------------------------*//*!
 * \brief	render the example
 * \param	example		The example data structure
 * \param	width		The width of the rendering surface
 * \param	height		The height of the rendering surface
 * \return	
 *//*-------------------------------------------------------------------*/

void ex1_render (void* example, int width, int height, float timeElapsed)
{
	float clearColor[4] = {1,1,1,1};

	EX_ASSERT(example);
	EX_UNREF(timeElapsed);

	{
		PS* dude = (PS*) example;

		float midx = (float) width  / 2.f;
		float midy = (float) height / 2.f;

		float scale = (float) width / (dudeMaxX - dudeMinX);

		if (dude->m_isZoomingIn)
			dude->m_zoom *= 1.1f;

		if (dude->m_isZoomingOut)
			dude->m_zoom *= 0.9f;

		if (dude->m_isMovingLeft)
			dude->m_x += 25.0f/dude->m_zoom;

		if (dude->m_isMovingRight)
			dude->m_x -= 25.0f/dude->m_zoom;

		if (dude->m_isMovingUp)
			dude->m_y -= 25.0f/dude->m_zoom;

		if (dude->m_isMovingDown)
			dude->m_y += 25.0f/dude->m_zoom;

		if (dude->m_isShearingRight)
			dude->m_shear += 0.1f;

		if (dude->m_isShearingLeft)
			dude->m_shear -= 0.1f;

		if (dude->m_isRotatingCW)
			dude->m_rotation -= 2.f;

		if (dude->m_isRotatingCCW)
			dude->m_rotation += 2.f;

		vgMask(VG_INVALID_HANDLE, VG_CLEAR_MASK, 0, 0, width + 1, height + 1);
		vgSetfv(VG_CLEAR_COLOR, 4, clearColor);
		vgClear(0, 0, width, height);

		vgLoadIdentity();


		vgTranslate(scale*dude->m_x*dude->m_zoom, scale*dude->m_y*dude->m_zoom);
		vgTranslate(midx, midy);
		vgScale(dude->m_zoom * scale, dude->m_zoom * scale);
		vgShear(dude->m_shear, 0.0f);
		vgRotate(dude->m_rotation);

		PS_render(dude);
		EX_ASSERT(vgGetError() == VG_NO_ERROR);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	handle events
 * \param	example		The example data structure
 * \param	event		The event to be handled
 * \return	
 *//*-------------------------------------------------------------------*/

void ex1_handleEvent(void* example, KeyEvent event)
{
	EX_ASSERT(example);
	{
		PS* dude = (PS*) example;
		switch (event)
		{
		case EVENT_BEGIN_ZOOM_IN:
			dude->m_isZoomingIn = 1;
			break;
		case EVENT_BEGIN_ZOOM_OUT:
			dude->m_isZoomingOut = 1;
			break;
		case EVENT_BEGIN_LEFT:
			dude->m_isMovingLeft = 1;
			break;
		case EVENT_BEGIN_RIGHT:
			dude->m_isMovingRight = 1;
			break;
		case EVENT_BEGIN_UP:
			dude->m_isMovingUp = 1;
			break;
		case EVENT_BEGIN_DOWN:
			dude->m_isMovingDown = 1;
			break;
		case EVENT_BEGIN_SHEAR_RIGHT:
			dude->m_isShearingRight = 1;
			break;
		case EVENT_BEGIN_SHEAR_LEFT:
			dude->m_isShearingLeft = 1;
			break;
		case EVENT_BEGIN_ROTATE_CW:
			dude->m_isRotatingCW = 1;
			break;
		case EVENT_BEGIN_ROTATE_CCW:
			dude->m_isRotatingCCW = 1;
			break;
		case EVENT_END_ZOOM_IN:
			dude->m_isZoomingIn = 0;
			break;
		case EVENT_END_ZOOM_OUT:
			dude->m_isZoomingOut = 0;
			break;
		case EVENT_END_LEFT:
			dude->m_isMovingLeft = 0;
			break;
		case EVENT_END_RIGHT:
			dude->m_isMovingRight = 0;
			break;
		case EVENT_END_UP:
			dude->m_isMovingUp = 0;
			break;
		case EVENT_END_DOWN:
			dude->m_isMovingDown = 0;
			break;
		case EVENT_END_SHEAR_RIGHT:
			dude->m_isShearingRight = 0;
			break;
		case EVENT_END_SHEAR_LEFT:
			dude->m_isShearingLeft = 0;
			break;
		case EVENT_END_ROTATE_CW:
			dude->m_isRotatingCW = 0;
			break;
		case EVENT_END_ROTATE_CCW:
			dude->m_isRotatingCCW = 0;
			break;
		default:
			break;
		}
	}
}
