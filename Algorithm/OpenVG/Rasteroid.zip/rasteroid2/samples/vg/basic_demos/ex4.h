#ifndef __EX4_H
#	define __EX4_H

/*------------------------------------------------------------------------
 *
 * OpenVG Example 4
 * -------------------------------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example4/ex4.h#2 $
 * $Date: 2006/03/09 $
 * $Author: teppo $ *
 *
 *//*-------------------------------------------------------------------*/

#ifndef __COMMON_H
#	include "common.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

void*	ex4_init		(void);
void	ex4_deinit		(void* example);
void	ex4_render		(void* example, int width, int height, float elapsedTime);
void	ex4_handleEvent	(void* example, KeyEvent event);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* __EX4_H */
