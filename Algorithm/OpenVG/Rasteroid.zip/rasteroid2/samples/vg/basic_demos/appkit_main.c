/*------------------------------------------------------------------------
 *
 * AppKit main
 * ------------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example_fw/appkit_main.c#1 $
 * $Date: 2006/03/06 $
 * $Author: sampo $
 *
 *//**
 * \file
 * \brief	Platform independent entrypoint for samples
 *//*-------------------------------------------------------------------*/

#include "EGL/egl.h"
#include "vg/openvg.h"
#include "vg/vgu.h"

#include "akAppKit.h"
#include "akUtils.h"

#include "common.h"

#include <stdlib.h>

/*-------------------------------------------------------------------*//*!
 * \brief	Application's data.
 *//*-------------------------------------------------------------------*/

typedef struct AppData_s
{
	Example			currentExample;
	void*			currentData;
	float			startTime;
	float			elapsedTime;
	HGbool			changeSample;
	
	EGLDisplay		eglDisplay;
	EGLContext		eglContext;
	EGLSurface		eglSurface;

} AppData;

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF HGbool checkEGLError(void)
{
	return (eglGetError() != EGL_SUCCESS);
}

/*-------------------------------------------------------------------*//*!
 * \brief Chooses the best EGL config
 *//*-------------------------------------------------------------------*/

HG_STATICF EGLConfig chooseEGLConfig(EGLDisplay eglDisplay, HGbool exactChannels, int redBits, int greenBits, int blueBits, int alphaBits, int maskBits, int surfaceBit)
{
	EGLint		numConfigs;
	EGLConfig*	configs;
	EGLConfig	bestConfig;
	HGint32		bestScore;
	int			i;

	/* Get all configurations. */

	eglGetConfigs(eglDisplay, NULL, 0, &numConfigs);
	if (checkEGLError())
		return (EGLConfig)0;

	configs = malloc(numConfigs * sizeof(EGLConfig));
	if (!configs)
		return (EGLConfig)0;

	eglGetConfigs(eglDisplay, configs, numConfigs, &numConfigs);
	if (checkEGLError() || numConfigs <= 0)
	{
		free(configs);
		return (EGLConfig)0;
	}

	/* Select the best configuration. */

#define ATTRIB(NAME)				if (!eglGetConfigAttrib(eglDisplay, configs[i], (NAME), &value)) continue;
#define HAS_BIT(BIT)				if ((value & (BIT)) == 0) continue;
#define PREFER(PREF, WEIGHT)		score -= ((value < (PREF)) ? (PREF) - value : value - (PREF)) << (WEIGHT);
#define PREFER_EQ(PREF, WEIGHT)		if (value == (PREF)) score += 1 << (WEIGHT);
#define PREFER_BITS(PREF, WEIGHT)	if ((PREF) != 0 && value == 0) continue; PREFER(PREF, WEIGHT);
#define CHANNEL(PREF, WEIGHT)		if (!exactChannels) { PREFER_BITS(PREF, WEIGHT); } else if (value != (PREF)) continue;

	bestConfig = (EGLConfig)0;
	bestScore = HG_INT32_MIN;
	for (i = 0; i < numConfigs; i++)
	{
		HGint32	score = 0;
		EGLint	value = 0;

		ATTRIB(EGL_RED_SIZE);			CHANNEL(redBits, 0);
		ATTRIB(EGL_GREEN_SIZE);			CHANNEL(greenBits, 0);
		ATTRIB(EGL_BLUE_SIZE);			CHANNEL(blueBits, 0);
		ATTRIB(EGL_ALPHA_SIZE);			CHANNEL(alphaBits, 0);
		ATTRIB(EGL_ALPHA_MASK_SIZE);	PREFER_BITS(maskBits, 0);
		ATTRIB(EGL_CONFIG_CAVEAT);		PREFER_EQ(EGL_NONE, 8);
		ATTRIB(EGL_RENDERABLE_TYPE);	HAS_BIT(EGL_OPENVG_BIT);
		ATTRIB(EGL_SURFACE_TYPE);		HAS_BIT(surfaceBit);

		if (score > bestScore)
		{
			bestConfig = configs[i];
			bestScore = score;
		}
	}

#undef ATTRIB
#undef HASBIT
#undef PREFER
#undef PREFER_EQ
#undef PREFER_BITS
#undef CHANNEL

	free(configs);

	if (bestScore == HG_INT32_MIN)
		return (EGLConfig)0;
	else
		return bestConfig;
}

/*-------------------------------------------------------------------*//*!
 * \brief
 *//*-------------------------------------------------------------------*/

HG_STATICF HGbool init(AKAppKit* ak, AppData* appData)
{

	AKSurfaceDesc desc;
	/*AppData* appData = (AppData*)AKAppKit_getUserPtr(ak);*/

	HG_ASSERT(ak && appData);

	desc = AKAppKit_getSurface(ak);

	/* Init EGL */
	appData->eglDisplay		= EGL_NO_DISPLAY;
	appData->eglContext		= EGL_NO_CONTEXT;
	appData->eglSurface		= EGL_NO_SURFACE;

	/* Initialize EGL display. */
	{
		EGLDisplay	display;
		EGLint		majorVersion;
		EGLint		minorVersion;

		eglBindAPI(EGL_OPENVG_API);
		display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
		if (checkEGLError() || display == EGL_NO_DISPLAY)
			return HG_FALSE;

		eglInitialize(display, &majorVersion, &minorVersion);
		if (checkEGLError())
		{
			AKAppKit_errorPrintf(ak, "init: EGL Initialize");
			return HG_FALSE;
		}

		appData->eglDisplay = display;
	}

	/* Create EGL surface and context. */
	{
		static const EGLint surfAttribs[] =
		{
			EGL_COLORSPACE,		EGL_COLORSPACE_sRGB,
			EGL_ALPHA_FORMAT,	EGL_ALPHA_FORMAT_PRE,
			EGL_NONE
		};

		EGLConfig config = chooseEGLConfig(appData->eglDisplay, HG_FALSE, 8, 8, 8, 0, 8, EGL_WINDOW_BIT);
		if (!config)
		{
			AKAppKit_errorPrintf(ak, "init: EGL Choose config");
			return HG_FALSE;
		}

		appData->eglSurface = eglCreateWindowSurface(appData->eglDisplay, config, (NativeWindowType)desc.nativePtr, surfAttribs);
		if (checkEGLError() || !appData->eglSurface)
		{
			AKAppKit_errorPrintf(ak, "init: EGL Create surface");
			return HG_FALSE;
		}

		appData->eglContext = eglCreateContext(appData->eglDisplay, config, appData->eglContext, NULL);
		if (checkEGLError() || !appData->eglContext)
		{
			AKAppKit_errorPrintf(ak, "init: EGL Create context");
			return HG_FALSE;
		}
	}

	eglMakeCurrent(appData->eglDisplay, appData->eglSurface, appData->eglSurface, appData->eglContext);

	/* Initialise application data */
	appData->currentExample = EXAMPLE_1;
	appData->currentData	= 0;
	appData->startTime		= 0.f;
	appData->elapsedTime	= 0.f;
	appData->currentData	= common_init(appData->currentExample);

	return HG_TRUE;

}

/*-------------------------------------------------------------------*//*!
 * \brief	This is called on program shutdown.
 *//*-------------------------------------------------------------------*/

HG_STATICF void deinit(AKAppKit* ak)
{
	HG_ASSERT(ak);
	{
		AppData* appData = (AppData*)AKAppKit_getUserPtr(ak);

		common_deinit(appData->currentExample, appData->currentData);

		if (appData->eglDisplay != EGL_NO_DISPLAY)
		{
			eglMakeCurrent(appData->eglDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);

			if (appData->eglContext != EGL_NO_CONTEXT)
				eglDestroyContext(appData->eglDisplay, appData->eglContext);
			if (appData->eglSurface != EGL_NO_SURFACE)
				eglDestroySurface(appData->eglDisplay, appData->eglSurface);

			eglTerminate(appData->eglDisplay);
		}
		
		free(appData);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	This function is called once in the program startup and
 *			and whenever surface's size has been altered.
 *//*-------------------------------------------------------------------*/

HG_STATICF void surfaceChanged (AKAppKit* ak, AKSurfaceDesc desc)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(desc);

	/* Do something with desc.width and desc.height? */
}

/*-------------------------------------------------------------------*//*!
 * \brief	All key events (keyboard, mouse buttons and mouse wheel)
 *			are passed to this function.
 *
 * \input	data is in DOM3 format.
 *//*-------------------------------------------------------------------*/

HG_STATICF void keyEvent (AKAppKit* ak, HGbool down, const char* data)
{

	AppData* appData = (AppData*)AKAppKit_getUserPtr(ak);

	/* Exit on esc, phone exit key or red phone key */
	if (down &&
		(akCompareStrings(data, "U+001B") ||
		 akCompareStrings(data, "RightSoftKey") ||
		 akCompareStrings(data, "U+0018")))
		AKAppKit_requestExit(ak);


	/* Skip to the next example with 3 */
	if (down && akCompareStrings(data, "U+0033") && appData->changeSample)
	{
		Example ex				= ((appData->currentExample)+1)%EXAMPLE_LAST;
		appData->changeSample	= HG_FALSE;

		/* Initialise the selected sample and deinit the previous one */
		if (appData->currentExample != ex)
		{
			void* data = common_init(ex);
			if (data)
			{
				common_deinit			(appData->currentExample, 
										 appData->currentData);
				appData->currentExample = ex;
				appData->currentData    = data;
			}
		}

	}

	/* Skip to the previous example with 1 */
	if (down && akCompareStrings(data, "U+0031") && appData->changeSample)
	{

		/* Select the previous example */
		int ex;

		if (appData->currentExample == 0)
			ex = EXAMPLE_LAST-1;
		else
			ex = ((appData->currentExample)-1)%EXAMPLE_LAST;

		appData->changeSample	= HG_FALSE;

		/* Initialise the selected sample and deinit the previous one */
		if (appData->currentExample != ex)
		{
			void* data = common_init(ex);
			if (data)
			{
				common_deinit			(appData->currentExample, 
										 appData->currentData);
				appData->currentExample = ex;
				appData->currentData    = data;
			}
		}

	}

	/* When the "1" key comes up */
	if (!down && akCompareStrings(data, "U+0033") && !appData->changeSample)
	{
		appData->changeSample = HG_TRUE;
	}

	/* When the "3" key comes up */
	if (!down && akCompareStrings(data, "U+0031") && !appData->changeSample)
	{
		appData->changeSample = HG_TRUE;
	}

	/* Key events for actions in examples */
	if (down && akCompareStrings(data, "Left"))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_BEGIN_LEFT);

	if (!down && akCompareStrings(data, "Left"))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_END_LEFT);

	if (down && akCompareStrings(data, "Right"))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_BEGIN_RIGHT);

	if (!down && akCompareStrings(data, "Right"))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_END_RIGHT);

	if (down && akCompareStrings(data, "Up"))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_BEGIN_UP);

	if (!down && akCompareStrings(data, "Up"))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_END_UP);

	if (down && akCompareStrings(data, "Down"))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_BEGIN_DOWN);

	if (!down && akCompareStrings(data, "Down"))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_END_DOWN);
	
	if (down && (akCompareStrings(data, "U+0051") || akCompareStrings(data, "U+0034")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_BEGIN_ZOOM_IN); 

	if (!down && (akCompareStrings(data, "U+0051") || akCompareStrings(data, "U+0034")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_END_ZOOM_IN); 

	if (down && (akCompareStrings(data, "U+0045") || akCompareStrings(data, "U+0036")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_BEGIN_ZOOM_OUT); 

	if (!down && (akCompareStrings(data, "U+0045") || akCompareStrings(data, "U+0036")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_END_ZOOM_OUT); 

	if (down && (akCompareStrings(data, "U+0041") || akCompareStrings(data, "U+0037")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_BEGIN_SHEAR_LEFT);

	if (!down && (akCompareStrings(data, "U+0041") || akCompareStrings(data, "U+0037")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_END_SHEAR_LEFT);

	if (down && (akCompareStrings(data, "U+0044") || akCompareStrings(data, "U+0039")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_BEGIN_SHEAR_RIGHT);

	if (!down && (akCompareStrings(data, "U+0044") || akCompareStrings(data, "U+0039")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_END_SHEAR_RIGHT);

	if (down && (akCompareStrings(data, "U+005A") || akCompareStrings(data, "U+002A")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_BEGIN_ROTATE_CCW);

	if (!down && (akCompareStrings(data, "U+005A") || akCompareStrings(data, "U+002A")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_END_ROTATE_CCW);

	if (down && (akCompareStrings(data, "U+0043") || akCompareStrings(data, "U+0023")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_BEGIN_ROTATE_CW);

	if (!down && (akCompareStrings(data, "U+0043") || akCompareStrings(data, "U+0023")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_END_ROTATE_CW);

	if (down && (akCompareStrings(data, "U+0057") || akCompareStrings(data, "U+0035")))
		common_handleEvent(appData->currentExample, appData->currentData, EVENT_BEGIN_ANIMATION);

}

/*-------------------------------------------------------------------*//*!
 * \brief	This handles the keyboard character events.
 *
 * \input	c is the typed character in Unicode format.
 *//*-------------------------------------------------------------------*/

HG_STATICF void charEvent (AKAppKit* ak, HGuint32 c)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(c);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Pointer movement callback.
 *
 * \input	known is true if pointer is inside the client area. When it
 *			is false the pointer has left the area.
 *
 * \input	x and y are the pointer coordinates on the window client
 *			area in pixels. 0, 0 represent the top-left corner of the area.
 *//*-------------------------------------------------------------------*/

HG_STATICF void ptrEvent (AKAppKit* ak, HGbool known, HGint32 x, HGint32 y)
{
	HG_ASSERT(ak);
	HG_UNREF(ak);
	HG_UNREF(known);
	HG_UNREF(x);
	HG_UNREF(y);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Main update callback.
 *			This is where any drawing should be done.
 *
 * \input	timeDelta is the time difference between current frame and the
 *			last frame in milliseconds.
 *
 * \note	If you need to know how much time has passed after program
 *			startup, use AKAppKit_getTime().
 *//*-------------------------------------------------------------------*/

HG_STATICF void update (AKAppKit* ak, HGint32 timeDelta)
{
	HG_ASSERT(ak);
	HG_UNREF(timeDelta);
	{

		/* Has to be done with an intermediate variable to avoid a compiler bug */
		int time				= (int)AKAppKit_getTime(ak);

		AppData* appData		= (AppData*)AKAppKit_getUserPtr(ak);
		appData->elapsedTime	= (float)time;
		common_render			(appData->currentExample,
								 appData->currentData,
								 AKAppKit_getSurface(ak).width,
								 AKAppKit_getSurface(ak).height,
								 appData->elapsedTime);
		eglSwapBuffers			(appData->eglDisplay, appData->eglSurface);

	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	This will be called first in the AppKit startup.
 *
 *			There are few things you should do here:
 *
 *				Crucial
 *					- create window
 *
 *				Recommended
 *					- assign callbacks you need to AppKit parameters
 *					- associate application data with AppKit
 *
 *			You may also want to initialize your own stuff here.
 *//*-------------------------------------------------------------------*/

HGbool appInit (AKAppKit* ak)
{
	AppData*		appData;
	AKAppKitParams	params;

	HG_ASSERT(ak);

	/* Init your stuff. */

	appData = (AppData*)malloc(sizeof(AppData));
	if (!appData)
		return HG_FALSE;	/* This will cause AppKit to exit immediately. */

	/* Fill params structure with callbacks and data pointer,
	then pass it to AppKit. */

	AKAppKitParams_clear(&params);

	params.deinit			= deinit;
	params.surfaceChanged	= surfaceChanged;
	params.keyEvent			= keyEvent;
	params.charEvent		= charEvent;
	params.ptrEvent			= ptrEvent;
	params.update			= update;

	params.userPtr			= appData;

	AKAppKit_initParams(ak, &params);

	/* Create window. */
	AKAppKit_createWindow(ak, 
						  400, 
						  400, 
						  "Hybrid Graphics OpenVG examples", 
						  AK_COLORFORMAT_NONE);

	return init(ak, appData);
}

/*----------------------------------------------------------------------*/
