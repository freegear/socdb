/*------------------------------------------------------------------------
 *
 * OpenVG Example 3
 * -------------------------------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example3/ex3.c#1 $
 * $Date: 2006/03/06 $
 * $Author: sampo $ *
 *
 *//*-------------------------------------------------------------------*/

#include "ex3.h"
#include "textImage.h"
#include <vg/openvg.h>
#include <vg/vgu.h>
#include <stdlib.h>

#define FADE_OUT_TIME 300.0f
#define FADE_IN_TIME 4000.0f

typedef struct
{
	VGPath	circle;
	VGPaint	fillPaint;
	VGPaint strokePaint;
	VGImage text;
	VGfloat angles[7];
	VGfloat radius;
	VGfloat startTime;
} Example3;

/*-------------------------------------------------------------------*//*!
 * \brief	init the example
 * \param	
 * \return	A pointer to the data structure allocated by the example
 *//*-------------------------------------------------------------------*/

void* ex3_init ()
{
	VGfloat strokeColor[4]	= {0.f, 0.36f, 0.60f, 1.f};
	VGfloat fillColor[4]	= {0.89f, 0.95f, 0.99f, 1.f};
	VGUErrorCode err;

	Example3* data = (Example3*) malloc(sizeof(Example3));

	vgSeti(VG_MATRIX_MODE, VG_MATRIX_PATH_USER_TO_SURFACE);

	data->fillPaint = vgCreatePaint();
	data->strokePaint   = vgCreatePaint();

	vgSetParameteri(data->fillPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
	vgSetParameterfv(data->fillPaint, VG_PAINT_COLOR, 4, fillColor);

	vgSetParameteri(data->strokePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
	vgSetParameterfv(data->strokePaint, VG_PAINT_COLOR, 4, strokeColor);

	data->circle = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, (unsigned int)VG_PATH_CAPABILITY_APPEND_TO);

	err = vguEllipse(data->circle, 0.0f, 0.0f, 0.28f, 0.28f);
	EX_UNREF(err);
	
	vgSetf(VG_STROKE_LINE_WIDTH, 0.02f);
	vgSetPaint(data->fillPaint, VG_FILL_PATH);
	vgSetPaint(data->strokePaint, VG_STROKE_PATH);

	vgSeti(VG_FILL_RULE, VG_NON_ZERO);
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);

	vgSeti(VG_IMAGE_QUALITY, VG_IMAGE_QUALITY_BETTER);
	data->text = vgCreateImage(VG_sRGBA_8888, 283, 123, VG_IMAGE_QUALITY_BETTER);
	vgImageSubData(data->text, imgData, 1132, VG_sRGBA_8888, 0, 0, 283, 123);
	
	{
		int i;
		for (i = 0; i < 7; i++)
		{
			data->angles[i] = 2 * 3.14159f * (float)(rand() & RAND_MAX);
		}
	}
	data->radius = 1.0f;
	data->startTime = -1.f;

	EX_ASSERT(vgGetError() == VG_NO_ERROR);
	
	return (void*) data;
}

/*-------------------------------------------------------------------*//*!
 * \brief	deinit the example
 * \param	example		The example data structure
 * \return	
 *//*-------------------------------------------------------------------*/

void ex3_deinit (void* example)
{
	Example3* data = (Example3*)example;
	vgDestroyPath(data->circle);
	vgDestroyPaint(data->fillPaint);
	vgDestroyPaint(data->strokePaint);
	vgDestroyImage(data->text);
	free(example);
}

/*-------------------------------------------------------------------*//*!
 * \brief	render the example
 * \param	example		The example data structure
 * \param	width		The width of the rendering surface
 * \param	height		The height of the rendering surface
 * \return	
 *//*-------------------------------------------------------------------*/

void ex3_render (void* example, int width, int height, float elapsedTime)
{
	VGfloat strokeColor[4]	= {0.f, 0.36f, 0.60f, 1.f};
	VGfloat fillColor[4]	= {0.89f, 0.95f, 0.99f, 1.f};
	Example3* data = (Example3*) example;
	VGfloat clearColor[4] = {1.0f, 1.0f, 1.0f, 1.0f};

	if (data->startTime < 0.f)
		data->startTime = elapsedTime;
	
	elapsedTime = elapsedTime - data->startTime;

	data->radius = 1.f - (elapsedTime / 2000.f); 

	if (data->radius < 0.f)
	{
		float effectTime = elapsedTime - 2000.f;
		data->radius = 0.0f;
		if (effectTime < FADE_OUT_TIME)
		{
			fillColor[3] = 1.0f - (effectTime / FADE_OUT_TIME);
			vgSetParameterfv(data->fillPaint, VG_PAINT_COLOR, 4, fillColor);
			strokeColor[3] = 1.0f - (effectTime / FADE_OUT_TIME);
			vgSetParameterfv(data->strokePaint, VG_PAINT_COLOR, 4, strokeColor);
		}
		else
		{
			fillColor[3] = (effectTime / FADE_IN_TIME - FADE_OUT_TIME/FADE_IN_TIME);
			vgSetParameterfv(data->fillPaint, VG_PAINT_COLOR, 4, fillColor);
			strokeColor[3] = (effectTime / FADE_IN_TIME - FADE_OUT_TIME/FADE_IN_TIME);
			vgSetParameterfv(data->strokePaint, VG_PAINT_COLOR, 4, strokeColor);
		}
	}
	
	{
		float rotInc = 2*3.14159f * (elapsedTime / 750.0f);
		int i;
		for (i = 0; i < 7; i++)
		{
			data->angles[i] += rotInc;
		}
	}

	vgLoadIdentity();
	vgTranslate((float)(width/2), (float)(height/2));
	vgScale((float)(width/2), (float)(width/2));

	vgSetfv(VG_CLEAR_COLOR, 4, clearColor);
	vgClear(0, 0, width, height);

	vgTranslate(-0.29f, 0.79f);
	{
		int i;
		for (i = 0; i < 4; i++)
		{
			vgRotate(data->angles[i]);
			vgTranslate(data->radius, 0.f);
			vgDrawPath(data->circle, VG_FILL_PATH | VG_STROKE_PATH);
			vgTranslate(-data->radius, 0.f);
			vgRotate(-data->angles[i]);
			vgTranslate(0.f, -0.31f);
		}
	}
	vgTranslate(0.56f, 0.31f);
	{
		int i;
		for (i = 0; i < 2; i++)
		{
			vgRotate(data->angles[i+4]);
			vgTranslate(data->radius, 0.f);
			vgDrawPath(data->circle, VG_FILL_PATH | VG_STROKE_PATH);
			vgTranslate(-data->radius, 0.f);
			vgRotate(-data->angles[i+4]);
			vgTranslate(0.f, 0.31f);
		}
	}
	vgTranslate(-0.28f, -0.145f);
	vgRotate(data->angles[6]);
	vgTranslate(data->radius, 0.f);
	vgDrawPath(data->circle, VG_FILL_PATH | VG_STROKE_PATH);
	
	if (elapsedTime > 2000.f + FADE_OUT_TIME)
	{
		VGfloat blendCol[4] = {1.f, 1.f, 1.f, 1.f};
		
		blendCol[3] = (elapsedTime - 2000.f - FADE_OUT_TIME) / FADE_IN_TIME;
		
		vgSeti(VG_MATRIX_MODE, VG_MATRIX_IMAGE_USER_TO_SURFACE);
		vgSeti(VG_IMAGE_MODE, VG_DRAW_IMAGE_MULTIPLY);
		vgSetParameterfv(data->fillPaint, VG_PAINT_COLOR, 4, blendCol);

		vgLoadIdentity();
		{
			VGfloat imgScale = (float)width / 400.0f;		
			vgTranslate(0, (float)height / 2);
			vgScale(imgScale, imgScale);
			vgTranslate(61.f, -212.f);
			vgDrawImage(data->text);
		}

		vgSeti(VG_MATRIX_MODE, VG_MATRIX_PATH_USER_TO_SURFACE);
	}

}

/*-------------------------------------------------------------------*//*!
 * \brief	handle events
 * \param	example		The example data structure
 * \param	event		The event to be handled
 * \return	
 *//*-------------------------------------------------------------------*/

void ex3_handleEvent (void* example, KeyEvent event)
{
	EX_UNREF(example);
	EX_UNREF(event);
}
