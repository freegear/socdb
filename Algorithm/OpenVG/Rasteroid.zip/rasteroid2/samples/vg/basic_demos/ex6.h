#ifndef __EX6_H
#	define __EX6_H

/*------------------------------------------------------------------------
 *
 * OpenVG Example 6
 * -------------------------------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example6/ex6.h#1 $
 * $Date: 2006/03/06 $
 * $Author: sampo $ *
 *
 *//*-------------------------------------------------------------------*/

#ifndef __COMMON_H
#	include "common.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

void*	ex6_init		(void);
void	ex6_deinit		(void* example);
void	ex6_render		(void* example, int width, int height, float elapsedTime);
void	ex6_handleEvent	(void* example, KeyEvent event);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* __EX6_H */
