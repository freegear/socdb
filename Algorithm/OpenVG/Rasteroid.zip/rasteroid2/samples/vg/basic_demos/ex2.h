#ifndef __EX2_H
#	define __EX2_H

/*------------------------------------------------------------------------
 *
 * OpenVG Example 2
 * -------------------------------
 *
 * (C) 2002-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * SAMPLE LEGALESE
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example2/ex2.h#1 $
 * $Date: 2006/03/06 $
 * $Author: sampo $ *
 *
 *//*-------------------------------------------------------------------*/

#ifndef __COMMON_H
#	include "common.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

void*	ex2_init		(void);
void	ex2_deinit		(void* example);
void	ex2_render		(void* example, int width, int height, float elapsedTime);
void	ex2_handleEvent	(void* example, KeyEvent event);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* __EX2_H */
