/*------------------------------------------------------------------------
 *
 * OpenVG Example 2
 * -------------------------------
 *
 * (C) 2002-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example2/ex2.c#1 $
 * $Date: 2006/03/06 $
 * $Author: sampo $ *
 *
 * Hybrid Rotating Cube Example
 *
 *//*-------------------------------------------------------------------*/

#include "ex2.h"
#include <vg/openvg.h>
#include <stdlib.h>

typedef struct
{
	VGfloat currentRotation;
	VGPaint	strokePaint;
	VGPaint	fillPaint;
	VGPath	path;
} Example2;

/*-------------------------------------------------------------------*//*!
 * \brief	init the example
 * \param	
 * \return	A pointer to the data structure allocated by the example
 *//*-------------------------------------------------------------------*/

void* ex2_init ()
{
	VGfloat strokeColor[4]	= {1.f, 0.f, 0.f, 1.f};
	VGfloat fillColor[4]	= {0.f, 0.f, 1.f, 1.f};

	VGubyte pathSegments[6]	=
	{
		VG_LINE_TO | VG_ABSOLUTE,
		VG_LINE_TO | VG_ABSOLUTE,
		VG_LINE_TO | VG_ABSOLUTE,
		VG_LINE_TO | VG_ABSOLUTE,
		VG_CLOSE_PATH
	};

	VGfloat pathData[10] =
	{
		  0.f, 100.f,
		100.f, 100.f,
		100.f,   0.f,
		  0.f,   0.f
	};

	Example2* data = (Example2*) malloc(sizeof(Example2));

	vgSeti(VG_MATRIX_MODE, VG_MATRIX_PATH_USER_TO_SURFACE);

	data->currentRotation = 0.f;
	data->strokePaint = vgCreatePaint();
	data->fillPaint   = vgCreatePaint();

	vgSetParameteri(data->strokePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
	vgSetParameterfv(data->strokePaint, VG_PAINT_COLOR, 4, strokeColor);

	vgSetParameteri(data->fillPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
	vgSetParameterfv(data->fillPaint, VG_PAINT_COLOR, 4, fillColor);

	data->path = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 4, 4, (unsigned int)VG_PATH_CAPABILITY_ALL);

	vgAppendPathData(data->path, 4, pathSegments, pathData);

	return (void*) data;
}

/*-------------------------------------------------------------------*//*!
 * \brief	deinit the example
 * \param	example		The example data structure
 * \return	
 *//*-------------------------------------------------------------------*/

void ex2_deinit (void* example)
{
	Example2* data = (Example2*)example;
	vgDestroyPaint(data->fillPaint);
	vgDestroyPaint(data->strokePaint);
	vgDestroyPath(data->path);
	free(example);
}

/*-------------------------------------------------------------------*//*!
 * \brief	render the example
 * \param	example		The example data structure
 * \param	width		The width of the rendering surface
 * \param	height		The height of the rendering surface
 * \return	
 *//*-------------------------------------------------------------------*/

void ex2_render (void* example, int width, int height, float elapsedTime)
{
	Example2* data = (Example2*) example;
	VGfloat clearColor[4] = {0.1f, 0.2f, 0.4f, 1.f};

	VGfloat scaleFactor = width/200.f;
	if (height/200.f < scaleFactor)
		scaleFactor = height/200.f;

	data->currentRotation = elapsedTime*0.1f;

	if (data->currentRotation >= 360.f)
		data->currentRotation -= 360.f;

	vgSetfv(VG_CLEAR_COLOR, 4, clearColor);
	vgClear(0, 0, width, height);

	vgLoadIdentity();
	vgScale(scaleFactor, scaleFactor);
	vgTranslate(100.f, 100.f);
	vgRotate(data->currentRotation);
	vgTranslate(-50.f, -50.f);

	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);
	vgSeti(VG_FILL_RULE, VG_EVEN_ODD);

	vgSetPaint(data->fillPaint, VG_FILL_PATH);

	vgSetf(VG_STROKE_LINE_WIDTH, 10.f);
	vgSeti(VG_STROKE_CAP_STYLE, VG_CAP_ROUND);
	vgSeti(VG_STROKE_JOIN_STYLE, VG_JOIN_ROUND);
	vgSetf(VG_STROKE_MITER_LIMIT, 0.f);
	vgSetPaint(data->strokePaint, VG_STROKE_PATH);

	vgDrawPath(data->path, VG_FILL_PATH | VG_STROKE_PATH);
}

/*-------------------------------------------------------------------*//*!
 * \brief	handle events
 * \param	example		The example data structure
 * \param	event		The event to be handled
 * \return	
 *//*-------------------------------------------------------------------*/

void ex2_handleEvent (void* example, KeyEvent event)
{
	EX_UNREF(example);
	EX_UNREF(event);
}
