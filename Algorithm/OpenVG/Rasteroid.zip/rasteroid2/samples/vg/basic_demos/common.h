#ifndef __COMMON_H
#	define __COMMON_H

/*------------------------------------------------------------------------
 *
 * OpenVG Examples
 * -------------------------------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example_fw/common.h#1 $
 * $Date: 2006/03/06 $
 * $Author: sampo $ *
 *
 *//**
 * \file
 * \brief	Wrapper functions for all the examples
 *//*-------------------------------------------------------------------*/

#ifdef _DEBUG
#	include <assert.h>
#	define EX_ASSERT(X) assert(X)
#else
#	define EX_ASSERT(X)
#endif

#define EX_UNREF(X) ((void)(X))

#include <stdio.h>

typedef enum 
{
	EXAMPLE_1	 = 0, /* Dude demo -- static content*/
	EXAMPLE_2	 = 1, /* Classic rotating cube */
	EXAMPLE_3	 = 2, /* Animated Hybrid logo */
	EXAMPLE_4	 = 3, /* Animated path tranform test */
	EXAMPLE_5    = 4, /* Buttons */
	EXAMPLE_6	 = 5, /* Apollonian marble packing */
	EXAMPLE_LAST = 6
} Example;

typedef enum 
{
	EVENT_BEGIN_ZOOM_IN,
	EVENT_BEGIN_ZOOM_OUT,
	EVENT_BEGIN_LEFT,
	EVENT_BEGIN_RIGHT,
	EVENT_BEGIN_UP,
	EVENT_BEGIN_DOWN,
	EVENT_BEGIN_SHEAR_RIGHT,
	EVENT_BEGIN_SHEAR_LEFT,
	EVENT_BEGIN_ROTATE_CW,
	EVENT_BEGIN_ROTATE_CCW,
	EVENT_BEGIN_ANIMATION,
	EVENT_END_ZOOM_IN,
	EVENT_END_ZOOM_OUT,
	EVENT_END_LEFT,
	EVENT_END_RIGHT,
	EVENT_END_UP,
	EVENT_END_DOWN,
	EVENT_END_SHEAR_RIGHT,
	EVENT_END_SHEAR_LEFT,
	EVENT_END_ROTATE_CW,
	EVENT_END_ROTATE_CCW
} KeyEvent;

#ifdef __cplusplus
extern "C" {
#endif

void*	common_init			(Example ex);
void	common_deinit		(Example ex, void* data);
void	common_render		(Example ex, void* data, int width, int height, float elapsedTime);
void	common_handleEvent	(Example ex, void* data, KeyEvent event);


void*	exMalloc			(size_t size);
void	exFree				(void* ptr);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* __COMMON_H */
