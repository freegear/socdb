/*------------------------------------------------------------------------
 *
 * OpenVG Example 6
 * -------------------------------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example6/ex6.c#2 $
 * $Date: 2006/03/24 $
 * $Author: jussir $ *
 *
 *//*-------------------------------------------------------------------*/

#include "ex6.h"
#include <vg/openvg.h>
#include <vg/vgu.h>
#include <stdlib.h>
#include <math.h>

typedef struct
{
	VGPath	circle;
	VGPaint	basePaint;
	VGPaint	highlightPaint;
	VGPaint borderPaint;
	VGPaint chromePaint;
	VGPaint chromeBorderPaint;
	VGfloat startTime;
	VGfloat lastTime;
	VGfloat radiusLimit;
	int		recursionLimit;
	VGfloat	angle;
	VGfloat	zoom;
	VGfloat	posx;
	VGfloat	posy;
	VGfloat	width;
	VGfloat	height;

	int				m_isZoomingIn;
	int				m_isZoomingOut;
	int				m_isMovingLeft;
	int				m_isMovingRight;
	int				m_isMovingUp;
	int				m_isMovingDown;
} Example6;

/*-------------------------------------------------------------------*//*!
 * \brief	Vector2 type and helper functions
 * \param	
 *//*-------------------------------------------------------------------*/

typedef struct
{
	float	x,y;
} Vector2;

static float length(const Vector2* v)
{
	return (float)sqrt(v->x*v->x + v->y*v->y);
}
static float MAX(float a, float b)
{
	return (a > b) ? a : b;
}

/*-------------------------------------------------------------------*//*!
 * \brief	Test if a disk is inside the viewport
 * \param	
 * \return	Bitmask indicating which border the disk was outside
 *//*-------------------------------------------------------------------*/

static unsigned int isInside(Example6* data, const Vector2* p, float r)
{
	float midx = data->width * 0.5f;
	float midy = data->height * 0.5f;

	float px = (p->x*midx + data->posx)*data->zoom + midx;
	float py = (p->y*midx + data->posy)*data->zoom + midy;
	int l = 0;
	unsigned int flags = 0;
	r *= data->zoom * midx * 2.0f;

	if(px+r < l)
		flags |= 1;
	if(px-r > data->width - l)
		flags |= 2;
	if(py+r < l)
		flags |= 4;
	if(py-r > data->height - l)
		flags |= 8;
	return flags;
}

/*-------------------------------------------------------------------*//*!
 * \brief	Draw a disk
 * \param	
 * \return	
 *//*-------------------------------------------------------------------*/

static void drawMarble(Example6* data, const Vector2* p, float r, int level)
{
	float midx = data->width * 0.5f;
	float midy = data->height * 0.5f;

	if(r < data->radiusLimit)
		return;		/* too small to be drawn */

	if(0xf & isInside(data, p, r))
		return;		/* outside the viewport */

	/* transform and scale */
	vgSeti(VG_MATRIX_MODE, VG_MATRIX_PATH_USER_TO_SURFACE);
	vgLoadIdentity();
	vgTranslate(data->posx*data->zoom + midx, data->posy*data->zoom + midy);
	vgScale(data->zoom * midx, data->zoom * midx);
	vgTranslate(p->x, p->y);
	vgScale(r*2.0f,r*2.0f);
	vgTranslate(-0.5f, -0.5f);

	/* draw red glass marble */
	vgSeti(VG_MATRIX_MODE, VG_MATRIX_FILL_PAINT_TO_USER);
	vgLoadIdentity();
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC);
	vgSetPaint(data->basePaint, VG_FILL_PATH);
	vgDrawPath(data->circle, VG_FILL_PATH);
/*	vgTranslate(0.25f, 0.75f);
	vgRotate(-45.0f);
	vgScale(0.65f, 1.0f);
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);
	vgSetPaint(data->highlightPaint, VG_FILL_PATH);
	vgDrawPath(data->circle, VG_FILL_PATH);
	vgLoadIdentity();
	vgSetPaint(data->borderPaint, VG_FILL_PATH);
	vgDrawPath(data->circle, VG_FILL_PATH);
*/
	/* draw chrome marble */
/*	vgSeti(VG_MATRIX_MODE, VG_MATRIX_FILL_PAINT_TO_USER);
	vgLoadIdentity();
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC);
	vgSetPaint(data->chromePaint, VG_FILL_PATH);
	vgDrawPath(data->circle, VG_FILL_PATH);
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);
	vgSetPaint(data->chromeBorderPaint, VG_FILL_PATH);
	vgDrawPath(data->circle, VG_FILL_PATH);
*/
}

/*-------------------------------------------------------------------*//*!
 * \brief	
 * \param	
 * \return	
 *//*-------------------------------------------------------------------*/

static float innerApollonian(Example6* data, Vector2* p, const Vector2* A, float r1, const Vector2* B, float r2, const Vector2* C, float r3)
{
	/*circle between three external triangles*/
	Vector2 CB, AC, BA;
	CB.x = C->x - B->x;
	CB.y = C->y - B->y;
	AC.x = A->x - C->x;
	AC.y = A->y - C->y;
	BA.x = B->x - A->x;
	BA.y = B->y - A->y;
	{
		float a = length(&CB);
		float b = length(&AC);
		float c = length(&BA);
		float s = 0.5f * (a + b + c);
		float R = a*b*c / (4.0f * (float)sqrt(MAX(0.0f, s * (a+b-s) * (a+c-s) * (b+c-s))));
		float alpha = 1.0f + b*c / (2.0f * R * (-a+b+c));
		float beta  = 1.0f + c*a / (2.0f * R * (-b+c+a));
		float gamma = 1.0f + a*b / (2.0f * R * (-c+a+b));
		float aa = a * alpha;
		float bb = b * beta;
		float cc = c * gamma;
		float sum = aa + bb + cc;
		aa /= sum;
		bb /= sum;
		cc /= sum;
		p->x = A->x*aa + B->x*bb + C->x*cc;
		p->y = A->y*aa + B->y*bb + C->y*cc;

		return r1*r2*r3 / (r1*r2 + r1*r3 + r2*r3 + 2.0f * (float)sqrt(MAX(0.0f, r1*r2*r3*(r1+r2+r3))));
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	
 * \param	
 * \return	
 *//*-------------------------------------------------------------------*/

static void edgeApollonianFindD(Example6* data, Vector2* p, Vector2* pd, float r, const Vector2* B, float r2, const Vector2* C, float r3)
{
	float a = r2 + r3;									/*distance from B to C*/
	float b = r2 + r;									/*distance from B to D*/
	float c = r3 + r;									/*distance from C to D*/
	float s = 0.5f * (a + b + c);						/*semiperimeter of the triangle BCD*/
	float area = (float)sqrt(MAX(0.0f, s * (s - a) * (s - b) * (s - c)));	/*triangle area using heron's formula*/
	float h = 2 * area / a;								/*height of the triangle*/
	float d = (float)sqrt(MAX(0.0f, b*b - h*h));		/*projected distance from B to D along BC*/
	Vector2 BC;
	if( a*a + b*b < c*c )								/*is angle (BC, BD) > 90*/
		d = -d;											/*D is behind B, negate the distance*/
	BC.x = C->x - B->x;
	BC.y = C->y - B->y;
	a = 1.0f / a;
	BC.x *= a;
	BC.y *= a;
	p->x = B->x + BC.x * d;
	p->y = B->y + BC.y * d;								/*base point*/
	pd->x = -BC.y * h;
	pd->y = BC.x * h;									/*perpendicular vector to the right side*/
}

/*-------------------------------------------------------------------*//*!
 * \brief	
 * \param	
 * \return	
 *//*-------------------------------------------------------------------*/

static void edgeApollonian(Example6* data, int right, Vector2* p, float* r, const Vector2* A, float r1, const Vector2* B, float r2, const Vector2* C, float r3)
{
	Vector2 pd;
	Vector2 p1,p2;
	float a = -r1*r2*r3;
	float b = -r1*r2 + -r1*r3 + r2*r3;
	float c = 2*((float)sqrt( MAX(0.0f, -r1*r2*r3*(-r1 + r2 + r3) )));

	*r = a / (b - c);	/*smaller circle between two external and one internal triangle*/

	edgeApollonianFindD(data, p, &pd, *r, B, r2, C, r3);
	if( !right )
	{
		pd.x = -pd.x;
		pd.y = -pd.y;
	}

	p1.x = p->x - pd.x - A->x;
	p1.y = p->y - pd.y - A->y;
	p2.x = p->x + pd.x - A->x;
	p2.y = p->y + pd.y - A->y;
	if( p1.x*p1.x+p1.y*p1.y > p2.x*p2.x+p2.y*p2.y )
	{	/*the circle that was found was on the wrong side, try again with the other side*/
		*r = a / (b + c);	/*larger circle between two external and one internal triangle*/
		edgeApollonianFindD(data, p, &pd, *r, B, r2, C, r3);
		if( !right )
		{
			pd.x = -pd.x;
			pd.y = -pd.y;
		}
	}
	p->x += pd.x;
	p->y += pd.y;
}

/*-------------------------------------------------------------------*//*!
 * \brief	
 * \param	
 * \return	
 *//*-------------------------------------------------------------------*/

static void innerApollonianRecurse(Example6* data, const Vector2* A, float r1, const Vector2* B, float r2, const Vector2* C, float r3, int level)
{
	Vector2 pi;
	float ri;

	if( level >= data->recursionLimit )
		return;		/* recursion limit reached */

	if(0xf & isInside(data, A, 0.0f) & isInside(data, B, 0.0f) & isInside(data, C, 0.0f))
		return;		/* the stuff would be outside the viewport, so don't bother drawing it */

	ri = innerApollonian(data, &pi, A, r1, B, r2, C, r3);
	drawMarble(data, &pi, ri, level);
	if( ri < data->radiusLimit )
		return;

	innerApollonianRecurse(data, &pi, ri, B, r2, C, r3, level+1);
	innerApollonianRecurse(data, A, r1, &pi, ri, C, r3, level+1);
	innerApollonianRecurse(data, A, r1, B, r2, &pi, ri, level+1);
}

/*-------------------------------------------------------------------*//*!
 * \brief	
 * \param	
 * \return	
 *//*-------------------------------------------------------------------*/

static void edgeApollonianRecurse(Example6* data, int right, const Vector2* A, float r1, const Vector2* B, float r2, const Vector2* C, float r3, int level)
{
	Vector2 p;
	float r;

	if(level >= data->recursionLimit)
		return;		/* recursion limit reached */

	{	/* viewport culling */
		Vector2 a,b,c,d,e;
		float l;
		a.x = B->x - A->x;
		a.y = B->y - A->y;
		l = r1 / (float)sqrt(a.x*a.x+a.y*a.y);
		a.x *= l;
		a.y *= l;

		b.x = C->x - A->x;
		b.y = C->y - A->y;
		l = r1 / (float)sqrt(b.x*b.x+b.y*b.y);
		b.x *= l;
		b.y *= l;

		c.x = a.y;
		c.y = -a.x;
		d.x = b.y;
		d.y = -b.x;

		a.x += A->x;
		a.y += A->y;
		b.x += A->x;
		b.y += A->y;

		{
			float x1 = a.x, y1 = a.y, x2 = a.x + c.x, y2 = a.y + c.y;
			float x3 = b.x, y3 = b.y, x4 = b.x + d.x, y4 = b.y + d.y;
			float d1 = x1*y2 - y1*x2;
			float d2 = x3*y4 - y3*x4;
			float d3 = 1.0f / ((x1-x2)*(y3-y4) - (y1-y2)*(x3-x4));
			e.x = (d1*(x3-x4) - d2*(x1-x2)) * d3;
			e.y = (d1*(y3-y4) - d2*(y1-y2)) * d3;
		}

		if(0xf & isInside(data, &a, 0.0f) & isInside(data, &b, 0.0f) & isInside(data, &c, 0.0f) & isInside(data, &d, 0.0f) & isInside(data, &e, 0.0f))
			return;		/* the stuff would be outside the viewport, so don't bother drawing it */
	}

	edgeApollonian(data, right, &p, &r, A,r1, B,r2, C,r3);

	/*left recursion*/
	drawMarble(data, &p, r, level);
	if( r < data->radiusLimit )
		return;

	edgeApollonianRecurse(data, right, A, r1, B, r2, &p, r, level+1);
	edgeApollonianRecurse(data, right, A, r1, &p, r, C, r3, level+1);
	innerApollonianRecurse(data, B, r2, &p, r, C, r3, level+1);
}

/*-------------------------------------------------------------------*//*!
 * \brief	init the example
 * \param	
 * \return	A pointer to the data structure allocated by the example
 *//*-------------------------------------------------------------------*/

void* ex6_init ()
{
	VGUErrorCode err;
	float stops1[15] = {0, 1,0.5f,0.25f,1, 0.5f, 0.75f,0,0,1, 1.0f, 0.25f,0,0,1};
	float grad1[5] = {0.7f, 0.3f, 0.7f, 0.3f, 1.0f};
	float stops2[15] = {0, 1,1,1,1, 0.5f, 1,1,1,1, 1.0f, 0,0,0,0};
	float grad2[5] = {0,0,0,0, 0.20f};
	float stops3[15] = {0, 0,0,0,0, 0.6f, 0,0,0,0, 1.0f, 0,0,0,0.5f};
	float grad3[5] = {0.4f, 0.6f, 0.4f, 0.6f, 0.8f};
	float stops4[30] = {0, 1,1,1,1, 0.40f, 1,1,1,1, 0.5f, 0.85f,0.85f,0.85f,1, 0.65f, 0.05f,0.05f,0.05f,1, 0.75f, 0.75f,0.75f,0.75f,1, 1.0f, 0.9f,0.9f,0.9f,1};
	float grad4[5] = {0.5f, 0.9f, 0.5f, 0.9f, 0.9f};
	float stops5[20] = {0, 0.5f,0.5f,0.5f,0, 0.6f, 0.25f,0.25f,0.25f,0, 0.75f, 0.25f,0.25f,0.25f,0.4f, 1.0f, 0.0f,0.0f,0.0f,0.7f};
	float grad5[5] = {0.5f, 0.57f, 0.5f, 0.57f, 0.57f};

	Example6* data = (Example6*) exMalloc(sizeof(Example6));

	/* create and set up paints */
	data->basePaint = vgCreatePaint();
	data->highlightPaint = vgCreatePaint();
	data->borderPaint = vgCreatePaint();
	data->chromePaint = vgCreatePaint();
	data->chromeBorderPaint = vgCreatePaint();

	vgSetParameteri(data->basePaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(data->basePaint, VG_PAINT_COLOR_RAMP_STOPS, 15, stops1);
	vgSetParameteri(data->basePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	vgSetParameterfv(data->basePaint, VG_PAINT_RADIAL_GRADIENT, 5, grad1);

	vgSetParameteri(data->highlightPaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(data->highlightPaint, VG_PAINT_COLOR_RAMP_STOPS, 15, stops2);
	vgSetParameteri(data->highlightPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	vgSetParameterfv(data->highlightPaint, VG_PAINT_RADIAL_GRADIENT, 5, grad2);

	vgSetParameteri(data->borderPaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(data->borderPaint, VG_PAINT_COLOR_RAMP_STOPS, 15, stops3);
	vgSetParameteri(data->borderPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	vgSetParameterfv(data->borderPaint, VG_PAINT_RADIAL_GRADIENT, 5, grad3);

	vgSetParameteri(data->chromePaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(data->chromePaint, VG_PAINT_COLOR_RAMP_STOPS, 30, stops4);
	vgSetParameteri(data->chromePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	vgSetParameterfv(data->chromePaint, VG_PAINT_RADIAL_GRADIENT, 5, grad4);

	vgSetParameteri(data->chromeBorderPaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(data->chromeBorderPaint, VG_PAINT_COLOR_RAMP_STOPS, 20, stops5);
	vgSetParameteri(data->chromeBorderPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	vgSetParameterfv(data->chromeBorderPaint, VG_PAINT_RADIAL_GRADIENT, 5, grad5);

	/* create circle path */
	data->circle = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, (unsigned int)VG_PATH_CAPABILITY_APPEND_TO);
	err = vguEllipse(data->circle, 0.5f, 0.5f, 1.0f, 1.0f);
	EX_UNREF(err);
	
	vgSeti(VG_FILL_RULE, VG_NON_ZERO);
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC);

	data->startTime = -1.f;
	data->lastTime = 0.0f;
	data->radiusLimit = 0.005f;
	data->recursionLimit = 16;
	data->zoom = 1.0f;
	data->posx = 0.0f;
	data->posy = 0.0f;
	data->angle = 0.0f;

	data->m_isZoomingIn = 0;
	data->m_isZoomingOut = 0;
	data->m_isMovingLeft = 0;
	data->m_isMovingRight = 0;
	data->m_isMovingUp = 0;
	data->m_isMovingDown = 0;

	EX_ASSERT(vgGetError() == VG_NO_ERROR);
	
	return (void*) data;
}

/*-------------------------------------------------------------------*//*!
 * \brief	deinit the example
 * \param	example		The example data structure
 * \return	
 *//*-------------------------------------------------------------------*/

void ex6_deinit (void* example)
{
	Example6* data	= (Example6*)example;
	vgDestroyPath	(data->circle);
	vgDestroyPaint	(data->basePaint);
	vgDestroyPaint	(data->highlightPaint);
	vgDestroyPaint	(data->borderPaint);
	vgDestroyPaint	(data->chromePaint);
	vgDestroyPaint	(data->chromeBorderPaint);
	exFree			(example);
}

/*-------------------------------------------------------------------*//*!
 * \brief	render the example
 * \param	example		The example data structure
 * \param	width		The width of the rendering surface
 * \param	height		The height of the rendering surface
 * \return	
 *//*-------------------------------------------------------------------*/

void ex6_render (void* example, int width, int height, float elapsedTime)
{
	Example6* data = (Example6*) example;
	VGfloat clearColor[4] = {0.5f, 0.0f, 0.0f, 1.0f};

	/* compute how much time has passed since the last frame */
	float dt;
	if (data->startTime < 0.f)
	{
		data->startTime = elapsedTime;
		data->lastTime = elapsedTime;
	}
	elapsedTime = elapsedTime - data->startTime;
	dt = elapsedTime - data->lastTime;
	data->lastTime = elapsedTime;

	data->width = (float)width;
	data->height = (float)height;

	/* handle movement events */
	if(data->m_isZoomingIn)
		data->zoom = data->zoom * (float)pow(1.001f, dt);
	if(data->m_isZoomingOut)
		data->zoom = data->zoom * (float)pow(0.999f, dt);
	if(data->m_isMovingLeft)
		data->posx += 0.2f / data->zoom * dt;
	if(data->m_isMovingRight)
		data->posx -= 0.2f / data->zoom * dt;
	if(data->m_isMovingUp)
		data->posy -= 0.2f / data->zoom * dt;
	if(data->m_isMovingDown)
		data->posy += 0.2f / data->zoom * dt;

	data->radiusLimit = 0.002f / data->zoom;
	data->angle += 0.0002f * dt / data->zoom;

	/* clear the background */
	vgSetfv(VG_CLEAR_COLOR, 4, clearColor);
	vgClear(0, 0, width, height);

	{	/*apollonian marble packing*/
		/*radii given a fixed circle at the origin, center of another circle and direction to the third circle*/
		float r1 = 0.8f;

		float angle = 3.1415f + 2.8f * (float)sin(data->angle);
		Vector2 A, B, C, AB;
		float l;
		A.x = 0.0f;		/* position of the outer circle */
		A.y = 0.0f;
		B.x = 0.5f;		/* position of the first inner circle */
		B.y = 0.0f;
		C.x = (float)cos(angle);	/* direction of the second inner circle (position will be computed below) */
		C.y = (float)sin(angle);


		AB.x = B.x - A.x;
		AB.y = B.y - A.y;
		/*limit the distance of B from A*/
		l = length(&AB);
		if(l > r1 - 0.1f)
		{
			l = (r1 - 0.1f) / l;	/* normalize & scale */
			AB.x *= l;
			AB.y *= l;
			B.x = A.x + AB.x;
			B.y = A.y + AB.y;
			AB.x = B.x - A.x;
			AB.y = B.y - A.y;
		}

		{
			float cosa, r3, l;
			float r2 = r1 - length(&AB);
			r2 = MAX(0.0f, r2);
			l = 1.0f / length(&C);
			C.x *= l;
			C.y *= l;
			cosa = C.x*AB.x+C.y*AB.y;
			r3 = ((AB.x*AB.x+AB.y*AB.y) + r1*r1 - r2*r2 - 2.0f * r1 * cosa) / (2.0f * (r1 + r2 - cosa));
			r3 = MAX(0.0f, r3);
			C.x = A.x + (r1 - r3) * C.x;	/*find the center point*/
			C.y = A.y + (r1 - r3) * C.y;

			drawMarble(data, &B, r2, 1);
			drawMarble(data, &C, r3, 1);
			edgeApollonianRecurse(data, 0, &A,r1, &B,r2, &C,r3, 2);
			edgeApollonianRecurse(data, 1, &A,r1, &B,r2, &C,r3, 2);
		}
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	handle events
 * \param	example		The example data structure
 * \param	event		The event to be handled
 * \return	
 *//*-------------------------------------------------------------------*/

void ex6_handleEvent (void* example, KeyEvent event)
{
	Example6* data = (Example6*) example;
	switch (event)
	{
	case EVENT_BEGIN_ZOOM_IN:
		data->m_isZoomingIn = 1;
		break;
	case EVENT_BEGIN_ZOOM_OUT:
		data->m_isZoomingOut = 1;
		break;
	case EVENT_BEGIN_LEFT:
		data->m_isMovingLeft = 1;
		break;
	case EVENT_BEGIN_RIGHT:
		data->m_isMovingRight = 1;
		break;
	case EVENT_BEGIN_UP:
		data->m_isMovingUp = 1;
		break;
	case EVENT_BEGIN_DOWN:
		data->m_isMovingDown = 1;
		break;
	case EVENT_END_ZOOM_IN:
		data->m_isZoomingIn = 0;
		break;
	case EVENT_END_ZOOM_OUT:
		data->m_isZoomingOut = 0;
		break;
	case EVENT_END_LEFT:
		data->m_isMovingLeft = 0;
		break;
	case EVENT_END_RIGHT:
		data->m_isMovingRight = 0;
		break;
	case EVENT_END_UP:
		data->m_isMovingUp = 0;
		break;
	case EVENT_END_DOWN:
		data->m_isMovingDown = 0;
		break;
	default:
		break;
	}
}
