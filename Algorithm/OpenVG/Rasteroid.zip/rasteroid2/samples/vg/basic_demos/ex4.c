/*------------------------------------------------------------------------
 *
 * OpenVG Example 4
 * -------------------------------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example4/ex4.c#2 $
 * $Date: 2006/03/09 $
 * $Author: teppo $ *
 *
 * Path transformation sample
 *
 *//*-------------------------------------------------------------------*/

#include "ex4.h"
#include <vg/openvg.h>
#include <math.h>

typedef struct
{

	VGshort		phase;		
	VGPath		refPath;
	VGPaint		refStrokePaint;
	VGPath		dstPath;
	VGPaint		dstStrokePaint;
	VGfloat		startTime;
	VGfloat		elapsedTime;
	VGfloat		lastRenderTime;
	VGfloat		scale;

	float		distance;
	float		zoom;
	float		x;
	float		y;
	int			isZoomingIn;
	int			isZoomingOut;
	int			isMovingLeft;
	int			isMovingRight;
	int			isMovingUp;
	int			isMovingDown;

} Example4;

/*-------------------------------------------------------------------*//*!
 * \brief	calculate the appropriate matrices for the animation
 * \param   elapsedTime The time since start of application (in milliseconds)
 * \return	
 *//*-------------------------------------------------------------------*/

static void ex4_animate(void* example, int width, int height)
{

	Example4*	data = (Example4*) example;
	VGint		numSegments;
	VGfloat		pathLength,tX,tY;
	VGfloat		deltaTime = data->elapsedTime - data->lastRenderTime;

	EX_UNREF(width);
	EX_UNREF(height);

	switch (data->phase)
	{
	case 0:
		numSegments		= vgGetParameteri(data->refPath, VG_PATH_NUM_SEGMENTS);
		vgPointAlongPath(data->refPath, 0, numSegments, data->distance, &tX, &tY, NULL, NULL);		

		if (data->x < tX)
			data->x += (deltaTime * 0.5f)/data->scale;

		if (data->x > tX)
			data->x -= (deltaTime * 0.5f)/data->scale;

		if (data->y < tY)
			data->y += (deltaTime * 0.5f)/data->scale;

		if (data->y > tY)
			data->y -= (deltaTime * 0.5f)/data->scale;

		if (fabs(data->y - tY) < (30/data->scale) && fabs(data->x - tX) < (30/data->scale))
			data->phase = 1;
		break;
	case 1:
		numSegments		= vgGetParameteri(data->refPath, VG_PATH_NUM_SEGMENTS);
		pathLength		= vgPathLength(data->refPath, 0, numSegments);
		tX				= 1.f;
		tY				= 1.f;
		data->distance	+= (deltaTime * 0.04f);

		vgPointAlongPath(data->refPath, 0, numSegments, data->distance, &data->x, &data->y, &tX, &tY);

		/* The angle of the current path point can be found with
		   the tangent values tX and tY */
		/*angle = (VGfloat)atan(tY/tX);*/

		if (data->distance > pathLength) 
		{
			data->phase		= -1;
			data->startTime = data->elapsedTime;
			data->distance	= 0.0f;
		}

		break;
	default:
		break;
	};

	vgScale(data->scale, data->scale);
	vgTranslate(-data->x, -data->y);

}

/*-------------------------------------------------------------------*//*!
 * \brief	calculate the appropriate matrices for moving the path
 * \param	example		The example data structure
 * \return	
 *//*-------------------------------------------------------------------*/

static void ex4_move(void* example)
{

	Example4* data = (Example4*) example;
	float deltaTime = data->elapsedTime - data->lastRenderTime;

	if (data->isMovingUp)
		data->y += (deltaTime * 0.3f)/data->scale;
	if (data->isMovingDown)
		data->y -= (deltaTime * 0.3f)/data->scale;
	if (data->isMovingLeft)
		data->x -= (deltaTime * 0.3f)/data->scale;
	if (data->isMovingRight)
		data->x += (deltaTime * 0.3f)/data->scale;

	vgScale(data->scale, data->scale);	
	vgTranslate(-data->x, -data->y);

}

/*-------------------------------------------------------------------*//*!
 * \brief	calculate the appropriate matrices for scaling the path
 * \param	example		The example data structure
 * \return	
 *//*-------------------------------------------------------------------*/

static void ex4_zoom(void* example)
{
	Example4* data = (Example4*) example;
	float deltaTime = data->elapsedTime - data->lastRenderTime;
	
	if (data->isZoomingIn)
		data->scale *= (1 + (deltaTime * 0.001f));
	if (data->isZoomingOut)
		data->scale *= (1 - (deltaTime * 0.001f));

	/* Clamp scale */
	if (data->scale > 1000.0f)
		data->scale = 1000.0f;
	else if (data->scale < 0.01f)
		data->scale = 0.01f;
}

/*-------------------------------------------------------------------*//*!
 * \brief	init the example
 * \param	
 * \return	A pointer to the data structure allocated by the example
 *//*-------------------------------------------------------------------*/

void* ex4_init ()
{

	VGfloat refStrokeColor[4]	= {1.f, 0.f, 0.f, 1.f};
	VGfloat dstStrokeColor[4]	= {0.f, 1.f, 0.f, 1.f};
	/*VGfloat fillColor[4]		= {0.f, 0.f, 1.f, 0.5f};*/
	VGPaint fillPaint;
	VGfloat rampStops[15]		= {0.0f, 1.0f, 0.0f, 0.0f, 1.0f,
								   0.5f, 0.0f, 1.0f, 0.0f, 1.0f,
								   1.0f, 0.0f, 0.0f, 1.0f, 1.0f};
	VGfloat gradient[4]			= {50.0f, 50.0f, 150.0f, 150.0f};

	VGubyte pathSegments[13]	=
	{
		VG_MOVE_TO		| VG_ABSOLUTE,
		VG_LINE_TO		| VG_ABSOLUTE,
		VG_HLINE_TO		| VG_ABSOLUTE,
		VG_VLINE_TO		| VG_ABSOLUTE,
		VG_QUAD_TO		| VG_ABSOLUTE,
		VG_CUBIC_TO		| VG_ABSOLUTE,
		VG_SQUAD_TO		| VG_ABSOLUTE,
		VG_SCUBIC_TO	| VG_ABSOLUTE,
		VG_SCCWARC_TO	| VG_ABSOLUTE,
		VG_SCWARC_TO	| VG_ABSOLUTE,
		VG_LCCWARC_TO	| VG_ABSOLUTE,
		VG_LCWARC_TO	| VG_ABSOLUTE,
		VG_CLOSE_PATH
	};

	VGfloat pathData[42] =
	{
		0.f,   0.f,
		50.f,  50.f,
		20.f,
		70.f,
		35.f,  150.f, 50.f,  70.f,
		100.f, 100.f, 150.f, 100.f, 100.f, 150.f,
		70.f,  20.f,
		50.f,  20.f, 30.f,   -20.f,
		10.f,  5.f,  20.f,   30.f,  -70.f,
		25.f,  20.f, 300.f,  -50.f, 0.f,
		20.f,  20.f, 0.f,    -40.f, 70.f,
		10.f,  70.f, 50.f,   0.f,   50.f
	};

	Example4* data			= (Example4*) exMalloc(sizeof(Example4));


	vgSeti(VG_MATRIX_MODE, VG_MATRIX_PATH_USER_TO_SURFACE);

	data->refStrokePaint	= vgCreatePaint();
	data->dstStrokePaint	= vgCreatePaint();
	fillPaint				= vgCreatePaint();

	vgSetParameteri(data->refStrokePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
	vgSetParameterfv(data->refStrokePaint, VG_PAINT_COLOR, 4, refStrokeColor);
	vgSetParameteri(data->dstStrokePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
	vgSetParameterfv(data->dstStrokePaint, VG_PAINT_COLOR, 4, dstStrokeColor);

	vgSetParameteri(fillPaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_REFLECT);
	vgSetParameteri(fillPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_LINEAR_GRADIENT);
	vgSetParameterfv(fillPaint, VG_PAINT_COLOR_RAMP_STOPS, 15, rampStops);
	vgSetParameterfv(fillPaint, VG_PAINT_LINEAR_GRADIENT, 4, gradient);
	vgSetPaint(fillPaint, VG_FILL_PATH);

	/*
	vgSetParameteri(fillPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
	vgSetParameterfv(fillPaint, VG_PAINT_COLOR, 4, fillColor);
	*/

	data->refPath = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 4, 4, (unsigned int)VG_PATH_CAPABILITY_ALL);
	data->dstPath = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 4, 4, (unsigned int)VG_PATH_CAPABILITY_ALL);
	vgAppendPathData(data->refPath, 13, pathSegments, pathData);
	vgSetPaint(fillPaint, VG_FILL_PATH);

	data->scale				= 1.0f;
	data->startTime			= -1.0f;
	data->elapsedTime		= -1.0f;
	data->lastRenderTime	= -1.0f;
	data->phase				= -1;
	data->isZoomingIn		= 0;
	data->isZoomingOut		= 0;
	data->isMovingLeft		= 0;
	data->isMovingRight		= 0;
	data->isMovingUp		= 0;
	data->isMovingDown		= 0;
	data->zoom				= 1.0f;
	data->x					= 0.0f;
	data->y					= 0.0f;
	data->distance			= 0.0f;

	return (void*) data;
}

/*-------------------------------------------------------------------*//*!
 * \brief	deinit the example
 * \param	example		The example data structure
 * \return	
 *//*-------------------------------------------------------------------*/

void ex4_deinit (void* example)
{
	Example4* data = (Example4*)example;
	vgDestroyPath(data->dstPath);
	vgDestroyPaint(data->dstStrokePaint);
	vgDestroyPath(data->refPath);
	vgDestroyPaint(data->refStrokePaint);
	exFree(example);
}

/*-------------------------------------------------------------------*//*!
 * \brief	render the example
 * \param	example		The example data structure
 * \param	width		The width of the rendering surface
 * \param	height		The height of the rendering surface
 * \param   elapsedTime The time since start of application (in milliseconds)
 * \return	
 *//*-------------------------------------------------------------------*/

void ex4_render (void* example, int width, int height, float elapsedTime)
{

	Example4* data = (Example4*) example;
	VGfloat clearColor[4] = {1.0f, 1.0f, 1.0f, 1.f};

	/* If example has just been started */
	if (data->startTime < 0.0f )
	{
		data->startTime			= elapsedTime;
		data->lastRenderTime	= elapsedTime;
	}

	data->elapsedTime = elapsedTime;

	vgSetfv(VG_CLEAR_COLOR, 4, clearColor);
	vgClear(0, 0, width, height);

	/* Center the image on the screen */
	vgLoadIdentity();
	vgTranslate((float)width/2, (float)height/2);

	/* Calculate the scale of the matrix */
	ex4_zoom(data);

	/* Calculate the matrices for the animation 
	   or move the path according to user input */
	if (data->phase >= 0)
		ex4_animate(data, width, height);

	/* If animation is not running, check for moving */
	if (data->phase < 0)
		ex4_move(data);

	vgClearPath(data->dstPath, VG_PATH_CAPABILITY_TRANSFORM_TO);
	vgTransformPath(data->dstPath, data->refPath);

	/* Set attributes for the reference path  and draw it*/
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);
	vgSeti(VG_FILL_RULE, VG_EVEN_ODD);

	vgSetf(VG_STROKE_LINE_WIDTH, 5.f);
	vgSeti(VG_STROKE_CAP_STYLE, VG_CAP_ROUND);
	vgSeti(VG_STROKE_JOIN_STYLE, VG_JOIN_ROUND);
	vgSetf(VG_STROKE_MITER_LIMIT, 0.f);

	vgSetPaint(data->refStrokePaint, VG_STROKE_PATH);
	vgDrawPath(data->refPath, VG_FILL_PATH | VG_STROKE_PATH);

	/* Reset the path matrix, set attributes to 
	   the transformed path and draw it */
	vgLoadIdentity();
	vgSetf(VG_STROKE_LINE_WIDTH, 3.f);
	vgSetPaint(data->dstStrokePaint, VG_STROKE_PATH);
	vgDrawPath(data->dstPath, VG_FILL_PATH | VG_STROKE_PATH);

	data->lastRenderTime = elapsedTime;

}

/*-------------------------------------------------------------------*//*!
 * \brief	handle events
 * \param	example		The example data structure
 * \param	event		The event to be handled
 * \return	
 *//*-------------------------------------------------------------------*/

void ex4_handleEvent (void* example, KeyEvent event)
{

	EX_ASSERT(example);
	{
		Example4* data = (Example4*) example;
		switch (event)
		{
		case EVENT_BEGIN_ANIMATION:
			if (data->phase >= 0)
			{
				data->phase = -1;
			}
			else
			{
				data->startTime = data->elapsedTime;
				data->phase		= 0;
			}
			break;
		case EVENT_BEGIN_ZOOM_IN:
			data->isZoomingIn = 1;
			break;
		case EVENT_BEGIN_ZOOM_OUT:
			data->isZoomingOut = 1;
			break;
		case EVENT_BEGIN_LEFT:
			data->isMovingLeft = 1;
			data->phase = -1;
			break;
		case EVENT_BEGIN_RIGHT:
			data->isMovingRight = 1;
			data->phase = -1;
			break;
		case EVENT_BEGIN_UP:
			data->isMovingUp = 1;
			data->phase = -1;
			break;
		case EVENT_BEGIN_DOWN:
			data->isMovingDown = 1;
			data->phase = -1;
			break;
		case EVENT_END_ZOOM_IN:
			data->isZoomingIn = 0;
			break;
		case EVENT_END_ZOOM_OUT:
			data->isZoomingOut = 0;
			break;
		case EVENT_END_LEFT:
			data->isMovingLeft = 0;
			break;
		case EVENT_END_RIGHT:
			data->isMovingRight = 0;
			break;
		case EVENT_END_UP:
			data->isMovingUp = 0;
			break;
		case EVENT_END_DOWN:
			data->isMovingDown = 0;
			break;
		default:
			break;
		}
	}
}
