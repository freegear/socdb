/*------------------------------------------------------------------------
 *
 * OpenVG Example 5
 * -------------------------------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example5/ex5.c#2 $
 * $Date: 2006/03/24 $
 * $Author: jussir $ *
 *
 *//*-------------------------------------------------------------------*/

#include "ex5.h"
#include <vg/openvg.h>
#include <vg/vgu.h>
#include <stdlib.h>

typedef struct
{
	VGPath	circle;
	VGPaint	basePaint;
	VGPaint	highlightPaint;
	VGPaint borderPaint;
	VGPaint chromePaint;
	VGPaint chromeBorderPaint;
} Example5;

/*-------------------------------------------------------------------*//*!
 * \brief	Draw a glass marble with three radial gradients: first a
 *			backlight, then the highlight, and finally a shadow to the
 *			lower right corner.
 * \param	
 * \return	
 *//*-------------------------------------------------------------------*/

static void drawGlassMarble(Example5* data)
{
	vgSeti(VG_MATRIX_MODE, VG_MATRIX_FILL_PAINT_TO_USER);
	vgLoadIdentity();
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC);
	vgSetPaint(data->basePaint, VG_FILL_PATH);
	vgDrawPath(data->circle, VG_FILL_PATH);
	vgTranslate(0.25f, 0.75f);
	vgRotate(-45.0f);
	vgScale(0.65f, 1.0f);
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);
	vgSetPaint(data->highlightPaint, VG_FILL_PATH);
	vgDrawPath(data->circle, VG_FILL_PATH);
	vgLoadIdentity();
	vgSetPaint(data->borderPaint, VG_FILL_PATH);
	vgDrawPath(data->circle, VG_FILL_PATH);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Draw a chrome marble with two gradients: one for the
 *			reflections, and one for a shadow around the boundary
 * \param	
 * \return	
 *//*-------------------------------------------------------------------*/

static void drawChromeMarble(Example5* data)
{
	vgSeti(VG_MATRIX_MODE, VG_MATRIX_FILL_PAINT_TO_USER);
	vgLoadIdentity();
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC);
	vgSetPaint(data->chromePaint, VG_FILL_PATH);
	vgDrawPath(data->circle, VG_FILL_PATH);
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);
	vgSetPaint(data->chromeBorderPaint, VG_FILL_PATH);
	vgDrawPath(data->circle, VG_FILL_PATH);
}

/*-------------------------------------------------------------------*//*!
 * \brief	init the example
 * \param	
 * \return	A pointer to the data structure allocated by the example
 *//*-------------------------------------------------------------------*/

void* ex5_init ()
{
	VGUErrorCode err;
	float stops1[15] = {0, 1,0.5f,0.25f,1, 0.5f, 0.75f,0,0,1, 1.0f, 0.25f,0,0,1};
	float grad1[5] = {0.7f, 0.3f, 0.7f, 0.3f, 1.0f};
	float stops2[15] = {0, 1,1,1,1, 0.5f, 1,1,1,1, 1.0f, 0,0,0,0};
	float grad2[5] = {0,0,0,0, 0.20f};
	float stops3[15] = {0, 0,0,0,0, 0.6f, 0,0,0,0, 1.0f, 0,0,0,0.5f};
	float grad3[5] = {0.4f, 0.6f, 0.4f, 0.6f, 0.8f};
	float stops4[30] = {0, 1,1,1,1, 0.40f, 1,1,1,1, 0.5f, 0.85f,0.85f,0.85f,1, 0.65f, 0.05f,0.05f,0.05f,1, 0.75f, 0.75f,0.75f,0.75f,1, 1.0f, 0.9f,0.9f,0.9f,1};
	float grad4[5] = {0.5f, 0.9f, 0.5f, 0.9f, 0.9f};
	float stops5[20] = {0, 0.5f,0.5f,0.5f,0, 0.6f, 0.25f,0.25f,0.25f,0, 0.75f, 0.0f,0.0f,0.0f,0.5f, 1.0f, 0.0f,0.0f,0.0f,1.0f};
	float grad5[5] = {0.5f, 0.57f, 0.5f, 0.57f, 0.57f};

	Example5* data = (Example5*) exMalloc(sizeof(Example5));

	data->basePaint = vgCreatePaint();
	data->highlightPaint = vgCreatePaint();
	data->borderPaint = vgCreatePaint();
	data->chromePaint = vgCreatePaint();
	data->chromeBorderPaint = vgCreatePaint();

	vgSetParameteri(data->basePaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(data->basePaint, VG_PAINT_COLOR_RAMP_STOPS, 15, stops1);
	vgSetParameteri(data->basePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	vgSetParameterfv(data->basePaint, VG_PAINT_RADIAL_GRADIENT, 5, grad1);

	vgSetParameteri(data->highlightPaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(data->highlightPaint, VG_PAINT_COLOR_RAMP_STOPS, 15, stops2);
	vgSetParameteri(data->highlightPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	vgSetParameterfv(data->highlightPaint, VG_PAINT_RADIAL_GRADIENT, 5, grad2);

	vgSetParameteri(data->borderPaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(data->borderPaint, VG_PAINT_COLOR_RAMP_STOPS, 15, stops3);
	vgSetParameteri(data->borderPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	vgSetParameterfv(data->borderPaint, VG_PAINT_RADIAL_GRADIENT, 5, grad3);

	vgSetParameteri(data->chromePaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(data->chromePaint, VG_PAINT_COLOR_RAMP_STOPS, 30, stops4);
	vgSetParameteri(data->chromePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	vgSetParameterfv(data->chromePaint, VG_PAINT_RADIAL_GRADIENT, 5, grad4);

	vgSetParameteri(data->chromeBorderPaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(data->chromeBorderPaint, VG_PAINT_COLOR_RAMP_STOPS, 20, stops5);
	vgSetParameteri(data->chromeBorderPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	vgSetParameterfv(data->chromeBorderPaint, VG_PAINT_RADIAL_GRADIENT, 5, grad5);

	data->circle = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, (unsigned int)VG_PATH_CAPABILITY_APPEND_TO);

	err = vguEllipse(data->circle, 0.5f, 0.5f, 1.0f, 1.0f);
	EX_UNREF(err);
	
	vgSeti(VG_FILL_RULE, VG_NON_ZERO);
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC);

	EX_ASSERT(vgGetError() == VG_NO_ERROR);
	
	return (void*) data;
}

/*-------------------------------------------------------------------*//*!
 * \brief	deinit the example
 * \param	example		The example data structure
 * \return	
 *//*-------------------------------------------------------------------*/

void ex5_deinit (void* example)
{
	Example5* data	= (Example5*)example;
	vgDestroyPath	(data->circle);
	vgDestroyPaint	(data->basePaint);
	vgDestroyPaint	(data->highlightPaint);
	vgDestroyPaint	(data->borderPaint);
	vgDestroyPaint	(data->chromePaint);
	vgDestroyPaint	(data->chromeBorderPaint);
	exFree			(example);
}

/*-------------------------------------------------------------------*//*!
 * \brief	render the example
 * \param	example		The example data structure
 * \param	width		The width of the rendering surface
 * \param	height		The height of the rendering surface
 * \return	
 *//*-------------------------------------------------------------------*/

void ex5_render (void* example, int width, int height, float elapsedTime)
{
	Example5* data = (Example5*) example;
	VGfloat clearColor[4] = {0.5f, 0.0f, 0.0f, 1.0f};
	float midx = (float)width * 0.5f;
	float midy = (float)height * 0.5f;
	EX_UNREF(elapsedTime);

	vgSetfv(VG_CLEAR_COLOR, 4, clearColor);
	vgClear(0, 0, width, height);

	/* transform, scale, and render */
	vgSeti(VG_MATRIX_MODE, VG_MATRIX_PATH_USER_TO_SURFACE);
	vgLoadIdentity();
	vgTranslate(midx,midy);
	vgScale(midx,midx);
	drawGlassMarble(data);

	vgSeti(VG_MATRIX_MODE, VG_MATRIX_PATH_USER_TO_SURFACE);
	vgLoadIdentity();
	vgTranslate(0,0);
	vgScale(midx,midx);
	drawChromeMarble(data);
}

/*-------------------------------------------------------------------*//*!
 * \brief	handle events
 * \param	example		The example data structure
 * \param	event		The event to be handled
 * \return	
 *//*-------------------------------------------------------------------*/

void ex5_handleEvent (void* example, KeyEvent event)
{
	EX_UNREF(example);
	EX_UNREF(event);
}
