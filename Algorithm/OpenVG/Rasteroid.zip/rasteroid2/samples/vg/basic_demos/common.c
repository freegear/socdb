/*------------------------------------------------------------------------
 *
 * OpenVG Examples
 * -------------------------------
 *
 * (C) 2005-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example_fw/common.c#1 $
 * $Date: 2006/03/06 $
 * $Author: sampo $ *
 *
 *//**
 * \file
 * \brief	Wrapper functions for all the examples
 *//*-------------------------------------------------------------------*/

#include "common.h"

#if !defined(__EX1_H) && (defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_1))
#	include "ex1.h"
#endif

#if !defined(__EX2_H) && (defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_2))
#	include "ex2.h"
#endif

#if !defined(__EX3_H) && (defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_3))
#	include "ex3.h"
#endif

#if !defined(__EX4_H) && (defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_4))
#	include "ex4.h"
#endif

#if !defined(__EX5_H) && (defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_5))
#	include "ex5.h"
#endif

#if !defined(__EX6_H) && (defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_6))
#	include "ex6.h"
#endif

#include <stdlib.h>

typedef void* (*exInitFunc)(void);
typedef void (*exDeinitFunc)(void*);
typedef void (*exRenderFunc)(void*, int, int, float);
typedef void (*exEventFunc)(void*, KeyEvent);

typedef struct
{
	const exInitFunc	init;
	const exDeinitFunc	deinit;
	const exRenderFunc	render;
	const exEventFunc	event;
} EXFunctions;

static const EXFunctions exFunctions[EXAMPLE_LAST] =
{
#if defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_1)
	{ex1_init, ex1_deinit, ex1_render, ex1_handleEvent},
#else
	{NULL, NULL, NULL, NULL},
#endif 

#if defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_2)
	{ex2_init, ex2_deinit, ex2_render, ex2_handleEvent},
#else
	{NULL, NULL, NULL, NULL},
#endif 

#if defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_3)
	{ex3_init, ex3_deinit, ex3_render, ex3_handleEvent},
#else
	{NULL, NULL, NULL, NULL},
#endif
	
#if defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_4)
	{ex4_init, ex4_deinit, ex4_render, ex4_handleEvent},
#else
	{NULL, NULL, NULL, NULL},
#endif

#if defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_5)
	{ex5_init, ex5_deinit, ex5_render, ex5_handleEvent},
#else
	{NULL, NULL, NULL, NULL},
#endif

#if defined(USE_EXAMPLE_ALL) || defined(USE_EXAMPLE_6)
	{ex6_init, ex6_deinit, ex6_render, ex6_handleEvent}
#else
	{NULL, NULL, NULL, NULL}
#endif

};

/*-------------------------------------------------------------------*//*!
 * \brief	A wrapper function to pass the initialisation call to the
 *			given example
 * \param	ex		The exmaple to be deinited
 * \return	The data allocated by the given example
 *//*-------------------------------------------------------------------*/

void* common_init(Example ex)
{
	EX_ASSERT(ex >= 0 && ex <= EXAMPLE_LAST);
	
	if (exFunctions[ex].init == NULL)
		return NULL;
	else
		return exFunctions[ex].init();
}

/*-------------------------------------------------------------------*//*!
 * \brief	a wrapper function to pass the deinit call to the exmaple
 * \param	ex		The exmaple to be deinited
 * \param	data	The data allocated by the given example
 * \return	
 *//*-------------------------------------------------------------------*/

void common_deinit(Example ex, void* data)
{

	EX_ASSERT(ex >= 0 && ex <= EXAMPLE_LAST);
	
	if (exFunctions[ex].deinit != NULL)
		exFunctions[ex].deinit(data);

}

/*-------------------------------------------------------------------*//*!
 * \brief	a wrapper function to pass the render call to the examples
 * \param	ex			The example to be rendered
 * \param	data		The data allocated by the given example
 * \param	width		The width of the surface
 * \param	height		The height of the surface
 * \param	elapsedTime	The time elapsed since the last call to render
 * \return	
 *//*-------------------------------------------------------------------*/

void common_render(Example ex, void* data, int width, int height, float elapsedTime)
{
	EX_ASSERT(ex >= 0 && ex <= EXAMPLE_LAST);
	
	if (exFunctions[ex].render != NULL)
		exFunctions[ex].render(data, width, height, elapsedTime);

}

/*-------------------------------------------------------------------*//*!
 * \brief	a wrapper function to pass the events to the examples
 * \param	ex		The example to be rendered
 * \param	data	The data allocated by the given example
 * \param	event	The event to be processed
 * \return	
 *//*-------------------------------------------------------------------*/

void common_handleEvent(Example ex, void* data, KeyEvent event)
{
	EX_ASSERT(ex >= 0 && ex <= EXAMPLE_LAST);
	
	if (exFunctions[ex].event != NULL)
		exFunctions[ex].event(data, event);
}

/*-------------------------------------------------------------------*//*!
 * \brief	a wrapper function for malloc
 * \param	size	size of memory to be allocated
 * \return	
 *//*-------------------------------------------------------------------*/

void* exMalloc (size_t size)
{
	return malloc(size);
}

/*-------------------------------------------------------------------*//*!
 * \brief	a wrapper function for free
 * \param	ptr		a pointer to the memory area to be freed
 * \return	
 *//*-------------------------------------------------------------------*/

void exFree (void* ptr)
{
	free(ptr);
}
