#ifndef __EX1_H
#	define __EX1_H

/*------------------------------------------------------------------------
 *
 * OpenVG Example 1
 * -------------------------------
 *
 * (C) 2002-2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 * $Id: //hybrid/products/openvg/1.3/samples/example1/ex1.h#1 $
 * $Date: 2006/03/06 $
 * $Author: sampo $ *
 *
 *//*-------------------------------------------------------------------*/

#ifndef __COMMON_H
#	include "common.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

void*	ex1_init		(void);
void	ex1_deinit		(void* example);
void	ex1_render		(void* example, int width, int height, float timeElapsed);
void	ex1_handleEvent	(void* example, KeyEvent event);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* __EX1_H */
