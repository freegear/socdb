/*------------------------------------------------------------------------
 *
 * OpenVG Tetris Sample
 * ---------------------------------
 *
 * (C) 2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 *//**
 *
 * \file
 * \brief 	Class for rendering fonts
 *
 *//*
 *
 * $Id: //hybrid/products/openvg/1.3/samples/tetris/src/renderFont.h#2 $
 * $Date: 2006/03/10 $
 *//*-------------------------------------------------------------------*/

#ifndef RENDERFONT_H
#define RENDERFONT_H

#include "vg/openvg.h"

class Font
{
public:
	Font(int pointSize);
	~Font();

	void		renderString(const char* text, float x, float y, VGbitfield renderFlags) const;
private:
	Font(const Font&);
	Font& operator=(const Font&);

	int			m_pointSize;
	VGPath		m_glyphs[256];
};

#endif