/*------------------------------------------------------------------------
 *
 * OpenVG Tetris Sample
 * ---------------------------------
 *
 * (C) 2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 *//**
 *
 * \file
 * \brief 	Tetris sample
 *
 *			The keys are as follows:
 *			Up		   - Start game / turn piece
 *			Left/Right - Select difficulty / move piece
 *			Down	   - Drop piece
 *			4 		   - Pause
 *			esc / 0	   - Exit 
 *
 *//*
 *
 * $Id: //hybrid/products/openvg/1.3/samples/tetris/src/main.cpp#5 $
 * $Date: 2006/03/10 $
 *//*-------------------------------------------------------------------*/

#include "akAppkit.h"
#include "akUtils.h"
#include "akImage.h"
#include "akBmp.h"

#include "egl.h"
#include "openvg.h"
#include "vgu.h"

#include "renderFont.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/* structure and data for graphics */
typedef struct
{
    const float*   floats;
    const HGuint8* cmds;
    HGint32        nCommands;
    HGuint32       color;
} PathData;

#include "chili.inl"
#define NUM_CHILI_PATHS		(sizeof(chili_paths)/sizeof(PathData))
#include "skull.inl"
#define NUM_SKULL_PATHS		(sizeof(skull_paths)/sizeof(PathData))

/* The dimensions of the actual AppKit window */
#define SAMPLE_WIN_WIDTH 176
#define SAMPLE_WIN_HEIGHT 208
/* Scale factor for the window size (2 or 3 for desktop, 1 for Series 60) */

#if (HG_OS == HG_OS_SYMBIAN)
#	define SAMPLE_WIN_SCALE 1
#else
#	define SAMPLE_WIN_SCALE 2
#endif

#define PLAYFIELD_WIDTH		8
#define PLAYFIELD_HEIGHT	32
#define NUM_NEXT_PIECES		8

#define BLOCK_SIZE			6.0f

/*-------------------------------------------------------------------*//*!
 * \brief  	Data of the AppKit application. Mostly used for interaction
 *			with the user.
 *//*-------------------------------------------------------------------*/

typedef enum
{
	GAME_OVER		= 0,
	PAUSED			= 1,
	PLAYING			= 2
} State;

typedef struct
{
	/* game data */
	State			state;
	int				difficulty;
	float			speed;
	int				level;
	int				score;
	int				highscore;
	int				lines;
	int				highlines;
	double			time;
	double			apptime;
	int				currentPiece;
	int				nextPiece[NUM_NEXT_PIECES];
	int				rotation;
	int				x;
	int				y;
	HGbool			D;
	int				playfield[PLAYFIELD_WIDTH*PLAYFIELD_HEIGHT];
	char			message[256];
	unsigned int	colors[8];
	int				xs[7*4*4];		//each piece has 4 blocks, each piece is in all 4 rotations
	int				ys[7*4*4];

	/* VG stuff */
	VGPaint			textFillPaint;
	VGPaint			textStrokePaint;
	VGPaint			piecePaint;
	VGPaint			shadowPaint[6];
	VGPath			piecePath;
	VGPath			framePath;
	VGPath			shadowPath[7];
	Font*			font;
	VGPath			chiliPath[NUM_CHILI_PATHS];
	float			chiliX, chiliY, chiliW, chiliH;
	VGPath			skullPath[NUM_SKULL_PATHS];
	float			skullX, skullY, skullW, skullH;

	/* EGL stuff */
	EGLDisplay		eglDisplay;
	EGLConfig		eglConfig;
	EGLContext		eglContext;
	EGLSurface		eglPBufferSurface;
	EGLSurface		eglWindowSurface;
	AKAppKit* ak;
} AppData;

static void			initGame(AppData* appData);
static void			deinitGame(AppData* appData);
static void			gameFrame(AppData* appData, double dt);

static void			newGame(AppData* appData);
static void			gameOver(AppData* appData);
static void			addPiece(AppData* appData, int x, int y, int piece, int rot);
static void			newPiece(AppData* appData);
static void			updateGame(AppData* appData, double dt);
static HGbool		collides(AppData* appData, int x, int y, int piece, int rot);

static HGbool		init (AKAppKit* ak, AppData* appData);

/*-------------------------------------------------------------------*//*!
 * \brief	AppKit application initialization.
 *//*-------------------------------------------------------------------*/

HG_STATICF HGbool init(AKAppKit* ak, AppData* appData)
{
	AKSurfaceDesc desc;
	HGbool sRGB = HG_TRUE;
	HGbool premultiplied = HG_FALSE;
	int redBits = 8;
	int greenBits = 8;
	int blueBits = 8;
	int alphaBits = 0;
	int luminanceBits = 0;
	int width, height;

#define SAMPLE_SURFACE_TYPE EGL_WINDOW_BIT
	EGLint		numConfigs;
	EGLint		majorVersion;
	EGLint		minorVersion;

	EGLint surfaceAttribs[] =
	{
		EGL_COLORSPACE,		EGL_COLORSPACE_sRGB,
		EGL_ALPHA_FORMAT,	EGL_ALPHA_FORMAT_NONPRE,
		EGL_NONE
	};

	EGLint configAttribs[] =
	{
		EGL_RED_SIZE,			EGL_DONT_CARE,
		EGL_GREEN_SIZE,			EGL_DONT_CARE,
		EGL_BLUE_SIZE,			EGL_DONT_CARE,
		EGL_ALPHA_SIZE,			EGL_DONT_CARE,
		EGL_LUMINANCE_SIZE,		EGL_DONT_CARE,
		EGL_COLOR_BUFFER_TYPE,	EGL_RGB_BUFFER,
		EGL_SURFACE_TYPE,		EGL_WINDOW_BIT,
		EGL_RENDERABLE_TYPE,	EGL_OPENVG_BIT,
		EGL_NONE
	};

#if (SAMPLE_SURFACE_TYPE == EGL_PBUFFER_BIT)
	EGLint pbufferAttribs[] =
	{
		EGL_WIDTH,	SAMPLE_WINDOW_WIDTH,
		EGL_HEIGHT, SAMPLE_WINDOW_HEIGHT,
		EGL_COLORSPACE,		SAMPLE_COLOR_SPACE,
		EGL_ALPHA_FORMAT,	SAMPLE_ALPHA_FORMAT,
		EGL_NONE
	};
#endif

	AK_ASSERT(ak && appData);

	if(!sRGB)
		surfaceAttribs[1] = EGL_COLORSPACE_LINEAR;
	if(premultiplied)
		surfaceAttribs[3] = EGL_ALPHA_FORMAT_PRE;

	if(redBits)
		configAttribs[1] = redBits;
	if(greenBits)
		configAttribs[3] = greenBits;
	if(blueBits)
		configAttribs[5] = blueBits;
	if(alphaBits)
		configAttribs[7] = alphaBits;
	if(luminanceBits)
	{
		configAttribs[9] = luminanceBits;
		configAttribs[11] = EGL_LUMINANCE_BUFFER;
	}

	AK_ASSERT(ak && appData);

	desc = AKAppKit_getSurface(ak);

	appData->eglDisplay = EGL_NO_DISPLAY;
	appData->eglContext = EGL_NO_CONTEXT;
	appData->eglWindowSurface = EGL_NO_SURFACE;

	/*eglSetConfigPreferenceHG(1);*/
	appData->eglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
	AK_ASSERT(eglGetError() == EGL_SUCCESS);

	eglInitialize(appData->eglDisplay, &majorVersion, &minorVersion);
	AK_ASSERT(eglGetError() == EGL_SUCCESS);

	eglGetConfigs(appData->eglDisplay, NULL, 0, &numConfigs);
	AK_ASSERT(eglGetError() == EGL_SUCCESS);

	eglChooseConfig(appData->eglDisplay, configAttribs, &appData->eglConfig, 1, &numConfigs);
	AK_ASSERT(eglGetError() == EGL_SUCCESS);

#if (SAMPLE_SURFACE_TYPE == EGL_WINDOW_BIT)
	appData->eglWindowSurface = eglCreateWindowSurface(appData->eglDisplay, appData->eglConfig, (NativeWindowType)desc.nativePtr, surfaceAttribs);
#elif (SAMPLE_SURFACE_TYPE == EGL_PIXMAP_BIT)
	appData->eglWindowSurface = eglCreatePixmapSurface(appData->eglDisplay, appData->eglConfig, pixmap, surfaceAttribs);
#elif (SAMPLE_SURFACE_TYPE == EGL_PBUFFER_BIT)
	appData->eglWindowSurface = eglCreatePixmapSurface(appData->eglDisplay, appData->eglConfig, pixmap, surfaceAttribs);
	AK_ASSERT(eglGetError() == EGL_SUCCESS);
	appData->eglPBufferSurface = eglCreatePbufferSurface(appData->eglDisplay, appData->eglConfig, pbufferAttribs);
#endif
	AK_ASSERT(eglGetError() == EGL_SUCCESS);

	eglBindAPI(EGL_OPENVG_API);
	AK_ASSERT(eglGetError() == EGL_SUCCESS);

	appData->eglContext = eglCreateContext(appData->eglDisplay, appData->eglConfig, NULL, NULL);
	AK_ASSERT(eglGetError() == EGL_SUCCESS);

	eglMakeCurrent(appData->eglDisplay, appData->eglWindowSurface, appData->eglWindowSurface, appData->eglContext);
	AK_ASSERT(eglGetError() == EGL_SUCCESS);


	/* print feedback on the buffer format actually initialized */
	{
		EGLint ret;
		eglGetConfigAttrib(appData->eglDisplay, appData->eglConfig, EGL_RED_SIZE, &redBits);
		eglGetConfigAttrib(appData->eglDisplay, appData->eglConfig, EGL_GREEN_SIZE, &greenBits);
		eglGetConfigAttrib(appData->eglDisplay, appData->eglConfig, EGL_BLUE_SIZE, &blueBits);
		eglGetConfigAttrib(appData->eglDisplay, appData->eglConfig, EGL_ALPHA_SIZE, &alphaBits);
		eglGetConfigAttrib(appData->eglDisplay, appData->eglConfig, EGL_LUMINANCE_SIZE, &luminanceBits);

		eglQuerySurface(appData->eglDisplay, appData->eglWindowSurface, EGL_COLORSPACE, &ret);
		sRGB = HG_TRUE;
		if(ret == EGL_COLORSPACE_LINEAR)
			sRGB = HG_FALSE;

		eglQuerySurface(appData->eglDisplay, appData->eglWindowSurface, EGL_ALPHA_FORMAT, &ret);
		premultiplied = HG_FALSE;
		if(ret == EGL_ALPHA_FORMAT_PRE)
			premultiplied = HG_TRUE;

		eglQuerySurface(appData->eglDisplay, appData->eglWindowSurface, EGL_WIDTH, &width);
		eglQuerySurface(appData->eglDisplay, appData->eglWindowSurface, EGL_HEIGHT, &height);
	}

	appData->ak = ak;
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief	Application clean up.
 *//*-------------------------------------------------------------------*/

HG_STATICF void deinit(AKAppKit* ak)
{
	AppData* appData = (AppData*)AKAppKit_getUserPtr(ak);
	if (appData)
	{
		deinitGame(appData);

		if (appData->eglDisplay != EGL_NO_DISPLAY)
		{
			eglMakeCurrent(appData->eglDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);

			if (appData->eglContext != EGL_NO_CONTEXT)
				eglDestroyContext(appData->eglDisplay, appData->eglContext);
			if (appData->eglWindowSurface != EGL_NO_SURFACE)
				eglDestroySurface(appData->eglDisplay, appData->eglWindowSurface);

			eglTerminate(appData->eglDisplay);
			eglReleaseThread();
		}
		free(appData);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	Draw the next frame. Update the window properties based
 *			on the time between the frames and request the window server 
 *			to produce a new frame.
 *//*-------------------------------------------------------------------*/

HG_STATICF void update (AKAppKit* ak, HGint32 timeDelta)
{
	AK_ASSERT(ak);
	{
		AppData* appData = (AppData*)AKAppKit_getUserPtr(ak);
		AK_ASSERT(appData->eglDisplay && appData->eglWindowSurface && appData->eglContext);

		/* Set current EGL surface and context. */
		eglMakeCurrent(appData->eglDisplay, appData->eglWindowSurface, appData->eglWindowSurface, appData->eglContext);

		gameFrame(appData, (float)timeDelta * 0.001f);

		eglSwapBuffers(appData->eglDisplay, appData->eglWindowSurface);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	Process the key events.
 *//*-------------------------------------------------------------------*/

HG_STATICF void keyEvent (AKAppKit* ak, HGbool down, const char* data)
{
	AK_ASSERT(ak);
	AppData* appData = (AppData*) AKAppKit_getUserPtr(ak);

	if (down && (akCompareStrings(data, "U+001B") || akCompareStrings(data, "U+0030")))
		AKAppKit_requestExit(ak);

	switch( appData->state )
	{
	case GAME_OVER:
		if(akCompareStrings(data,  "Up"))
		{
			newGame(appData);
		}

		if(down && akCompareStrings(data,  "Left"))
		{
			if( appData->difficulty > 0 ) appData->difficulty--;
		}

		if(down && akCompareStrings(data,  "Right"))
		{
			if( appData->difficulty < 2 ) appData->difficulty++;
		}

		switch( appData->difficulty )
		{
		case 0:
			appData->speed = 1.5f;
			break;
		case 1:
			appData->speed = 1.7f;
			break;
		case 2:
			appData->speed = 1.9f;
			break;
		}
		break;
	case PAUSED:
		if(down && akCompareStrings(data,  "U+0034"))
		{
			appData->state = PLAYING;
			sprintf(appData->message, " ");
		}
		break;
	default:
		AK_ASSERT(appData->state == PLAYING);
		//read keyboard
		if(down && akCompareStrings(data,  "U+0034"))
		{
			sprintf(appData->message, "paused");
			appData->state = PAUSED;
			break;
		}

		if(down && akCompareStrings(data,  "Left"))
		{
			if( !collides(appData, appData->x-1,appData->y,appData->currentPiece,appData->rotation) )
				--appData->x;
		}

		if(down && akCompareStrings(data,  "Right"))
		{
			if( !collides(appData, appData->x+1,appData->y,appData->currentPiece,appData->rotation) )
				++appData->x;
		}

		if(akCompareStrings(data,  "Down"))
		{
			appData->D = down;
		}

		if(down && akCompareStrings(data,  "Up"))
		{
			if( !collides(appData, appData->x,appData->y,appData->currentPiece,(appData->rotation+1)&3) )
				appData->rotation = (appData->rotation+1)&3;
		}
		break;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	Main function.
 *//*-------------------------------------------------------------------*/

HGbool appInit (AKAppKit* ak)
{
	AppData* appData = HG_NULL;
	AK_ASSERT(ak);

	appData = (AppData*)malloc(sizeof(AppData));
	if (!appData)
		return HG_FALSE;

	memset(appData, 0, sizeof(AppData));
	AKAppKit_createWindow(ak, 
						  SAMPLE_WIN_WIDTH*SAMPLE_WIN_SCALE, 
						  SAMPLE_WIN_HEIGHT*SAMPLE_WIN_SCALE, 
						  "OpenVG Tetris Sample", 
						  AK_COLORFORMAT_INT_RGBA);

	{
		AKAppKitParams ap;
		AKAppKitParams_clear(&ap);

		ap.deinit			= deinit;
		ap.keyEvent			= keyEvent;
		ap.update			= update;

		ap.userPtr			= appData;

		AKAppKit_initParams(ak, &ap);
	}

	if (!init(ak, appData))
	{
		AKAppKit_printf(ak, "appInit! - Init FAULIERRR\n");		
		deinit(ak);
		return HG_FALSE;
	}

	initGame(appData);
	return HG_TRUE;
}

/*-------------------------------------------------------------------*//*!
 * \brief	Game data initialization
 *//*-------------------------------------------------------------------*/

static unsigned int rgb(unsigned int r, unsigned int g, unsigned int b)
{
	return (r << 24) | (g << 16) | (b << 8) | 255;
}

static void initGame(AppData* appData)
{
	/* set colors for pieces */
	appData->colors[0] = rgb(64,64,48);
	appData->colors[1] = rgb(255,224,0);
	appData->colors[2] = rgb(0,224,255);
	appData->colors[3] = rgb(255,128,0);
	appData->colors[4] = rgb(0,64,255);
	appData->colors[5] = rgb(64,224,192);
	appData->colors[6] = rgb(255,64,255);
	appData->colors[7] = rgb(255,255,224);

	/* describe the shapes of the pieces */
	//piece 0
	// xx
	// x
	// x
	appData->xs[0*16 + 0*4 + 0] = 0;
	appData->xs[0*16 + 0*4 + 1] = 1;
	appData->xs[0*16 + 0*4 + 2] = 0;
	appData->xs[0*16 + 0*4 + 3] = 0;
	appData->ys[0*16 + 0*4 + 0] = -1;
	appData->ys[0*16 + 0*4 + 1] = -1;
	appData->ys[0*16 + 0*4 + 2] = 0;
	appData->ys[0*16 + 0*4 + 3] = 1;

	appData->xs[0*16 + 1*4 + 0] = -1;
	appData->xs[0*16 + 1*4 + 1] = -1;
	appData->xs[0*16 + 1*4 + 2] = 0;
	appData->xs[0*16 + 1*4 + 3] = 1;
	appData->ys[0*16 + 1*4 + 0] = 0;
	appData->ys[0*16 + 1*4 + 1] = -1;
	appData->ys[0*16 + 1*4 + 2] = 0;
	appData->ys[0*16 + 1*4 + 3] = 0;

	appData->xs[0*16 + 2*4 + 0] = 0;
	appData->xs[0*16 + 2*4 + 1] = 0;
	appData->xs[0*16 + 2*4 + 2] = 0;
	appData->xs[0*16 + 2*4 + 3] = -1;
	appData->ys[0*16 + 2*4 + 0] = -1;
	appData->ys[0*16 + 2*4 + 1] = 0;
	appData->ys[0*16 + 2*4 + 2] = 1;
	appData->ys[0*16 + 2*4 + 3] = 1;

	appData->xs[0*16 + 3*4 + 0] = -1;
	appData->xs[0*16 + 3*4 + 1] = 0;
	appData->xs[0*16 + 3*4 + 2] = 1;
	appData->xs[0*16 + 3*4 + 3] = 1;
	appData->ys[0*16 + 3*4 + 0] = 0;
	appData->ys[0*16 + 3*4 + 1] = 0;
	appData->ys[0*16 + 3*4 + 2] = 0;
	appData->ys[0*16 + 3*4 + 3] = 1;

	//piece 1
	// xx
	//  x
	//  x
	appData->xs[1*16 + 0*4 + 0] = 0;
	appData->xs[1*16 + 0*4 + 1] = 1;
	appData->xs[1*16 + 0*4 + 2] = 1;
	appData->xs[1*16 + 0*4 + 3] = 1;
	appData->ys[1*16 + 0*4 + 0] = -1;
	appData->ys[1*16 + 0*4 + 1] = -1;
	appData->ys[1*16 + 0*4 + 2] = 0;
	appData->ys[1*16 + 0*4 + 3] = 1;

	appData->xs[1*16 + 1*4 + 0] = -1;
	appData->xs[1*16 + 1*4 + 1] = -1;
	appData->xs[1*16 + 1*4 + 2] = 0;
	appData->xs[1*16 + 1*4 + 3] = 1;
	appData->ys[1*16 + 1*4 + 0] = 0;
	appData->ys[1*16 + 1*4 + 1] = 1;
	appData->ys[1*16 + 1*4 + 2] = 0;
	appData->ys[1*16 + 1*4 + 3] = 0;

	appData->xs[1*16 + 2*4 + 0] = 0;
	appData->xs[1*16 + 2*4 + 1] = 0;
	appData->xs[1*16 + 2*4 + 2] = 0;
	appData->xs[1*16 + 2*4 + 3] = 1;
	appData->ys[1*16 + 2*4 + 0] = -1;
	appData->ys[1*16 + 2*4 + 1] = 0;
	appData->ys[1*16 + 2*4 + 2] = 1;
	appData->ys[1*16 + 2*4 + 3] = 1;

	appData->xs[1*16 + 3*4 + 0] = -1;
	appData->xs[1*16 + 3*4 + 1] = 0;
	appData->xs[1*16 + 3*4 + 2] = 1;
	appData->xs[1*16 + 3*4 + 3] = 1;
	appData->ys[1*16 + 3*4 + 0] = 0;
	appData->ys[1*16 + 3*4 + 1] = 0;
	appData->ys[1*16 + 3*4 + 2] = 0;
	appData->ys[1*16 + 3*4 + 3] = -1;

	//piece 2
	// xxxx
	appData->xs[2*16 + 0*4 + 0] = -1;
	appData->xs[2*16 + 0*4 + 1] = 0;
	appData->xs[2*16 + 0*4 + 2] = 1;
	appData->xs[2*16 + 0*4 + 3] = 2;
	appData->ys[2*16 + 0*4 + 0] = 0;
	appData->ys[2*16 + 0*4 + 1] = 0;
	appData->ys[2*16 + 0*4 + 2] = 0;
	appData->ys[2*16 + 0*4 + 3] = 0;

	appData->xs[2*16 + 1*4 + 0] = 0;
	appData->xs[2*16 + 1*4 + 1] = 0;
	appData->xs[2*16 + 1*4 + 2] = 0;
	appData->xs[2*16 + 1*4 + 3] = 0;
	appData->ys[2*16 + 1*4 + 0] = -1;
	appData->ys[2*16 + 1*4 + 1] = 0;
	appData->ys[2*16 + 1*4 + 2] = 1;
	appData->ys[2*16 + 1*4 + 3] = 2;

	appData->xs[2*16 + 2*4 + 0] = -1;
	appData->xs[2*16 + 2*4 + 1] = 0;
	appData->xs[2*16 + 2*4 + 2] = 1;
	appData->xs[2*16 + 2*4 + 3] = 2;
	appData->ys[2*16 + 2*4 + 0] = 0;
	appData->ys[2*16 + 2*4 + 1] = 0;
	appData->ys[2*16 + 2*4 + 2] = 0;
	appData->ys[2*16 + 2*4 + 3] = 0;

	appData->xs[2*16 + 3*4 + 0] = 0;
	appData->xs[2*16 + 3*4 + 1] = 0;
	appData->xs[2*16 + 3*4 + 2] = 0;
	appData->xs[2*16 + 3*4 + 3] = 0;
	appData->ys[2*16 + 3*4 + 0] = -1;
	appData->ys[2*16 + 3*4 + 1] = 0;
	appData->ys[2*16 + 3*4 + 2] = 1;
	appData->ys[2*16 + 3*4 + 3] = 2;

	//piece 3
	// xx
	// xx
	appData->xs[3*16 + 0*4 + 0] = 0;
	appData->xs[3*16 + 0*4 + 1] = 1;
	appData->xs[3*16 + 0*4 + 2] = 1;
	appData->xs[3*16 + 0*4 + 3] = 0;
	appData->ys[3*16 + 0*4 + 0] = 0;
	appData->ys[3*16 + 0*4 + 1] = 0;
	appData->ys[3*16 + 0*4 + 2] = 1;
	appData->ys[3*16 + 0*4 + 3] = 1;

	appData->xs[3*16 + 1*4 + 0] = 0;
	appData->xs[3*16 + 1*4 + 1] = 1;
	appData->xs[3*16 + 1*4 + 2] = 1;
	appData->xs[3*16 + 1*4 + 3] = 0;
	appData->ys[3*16 + 1*4 + 0] = 0;
	appData->ys[3*16 + 1*4 + 1] = 0;
	appData->ys[3*16 + 1*4 + 2] = 1;
	appData->ys[3*16 + 1*4 + 3] = 1;

	appData->xs[3*16 + 2*4 + 0] = 0;
	appData->xs[3*16 + 2*4 + 1] = 1;
	appData->xs[3*16 + 2*4 + 2] = 1;
	appData->xs[3*16 + 2*4 + 3] = 0;
	appData->ys[3*16 + 2*4 + 0] = 0;
	appData->ys[3*16 + 2*4 + 1] = 0;
	appData->ys[3*16 + 2*4 + 2] = 1;
	appData->ys[3*16 + 2*4 + 3] = 1;

	appData->xs[3*16 + 3*4 + 0] = 0;
	appData->xs[3*16 + 3*4 + 1] = 1;
	appData->xs[3*16 + 3*4 + 2] = 1;
	appData->xs[3*16 + 3*4 + 3] = 0;
	appData->ys[3*16 + 3*4 + 0] = 0;
	appData->ys[3*16 + 3*4 + 1] = 0;
	appData->ys[3*16 + 3*4 + 2] = 1;
	appData->ys[3*16 + 3*4 + 3] = 1;

	//piece 4
	// xxx
	//  x
	appData->xs[4*16 + 0*4 + 0] = -1;
	appData->xs[4*16 + 0*4 + 1] = 0;
	appData->xs[4*16 + 0*4 + 2] = 1;
	appData->xs[4*16 + 0*4 + 3] = 0;
	appData->ys[4*16 + 0*4 + 0] = 0;
	appData->ys[4*16 + 0*4 + 1] = 0;
	appData->ys[4*16 + 0*4 + 2] = 0;
	appData->ys[4*16 + 0*4 + 3] = 1;

	appData->xs[4*16 + 1*4 + 0] = 0;
	appData->xs[4*16 + 1*4 + 1] = 0;
	appData->xs[4*16 + 1*4 + 2] = 0;
	appData->xs[4*16 + 1*4 + 3] = 1;
	appData->ys[4*16 + 1*4 + 0] = -1;
	appData->ys[4*16 + 1*4 + 1] = 0;
	appData->ys[4*16 + 1*4 + 2] = 1;
	appData->ys[4*16 + 1*4 + 3] = 0;

	appData->xs[4*16 + 2*4 + 0] = 0;
	appData->xs[4*16 + 2*4 + 1] = -1;
	appData->xs[4*16 + 2*4 + 2] = 0;
	appData->xs[4*16 + 2*4 + 3] = 1;
	appData->ys[4*16 + 2*4 + 0] = -1;
	appData->ys[4*16 + 2*4 + 1] = 0;
	appData->ys[4*16 + 2*4 + 2] = 0;
	appData->ys[4*16 + 2*4 + 3] = 0;

	appData->xs[4*16 + 3*4 + 0] = 0;
	appData->xs[4*16 + 3*4 + 1] = 0;
	appData->xs[4*16 + 3*4 + 2] = 0;
	appData->xs[4*16 + 3*4 + 3] = -1;
	appData->ys[4*16 + 3*4 + 0] = -1;
	appData->ys[4*16 + 3*4 + 1] = 0;
	appData->ys[4*16 + 3*4 + 2] = 1;
	appData->ys[4*16 + 3*4 + 3] = 0;

	//piece 5
	//  xx
	// xx
	appData->xs[5*16 + 0*4 + 0] = 0;
	appData->xs[5*16 + 0*4 + 1] = 1;
	appData->xs[5*16 + 0*4 + 2] = -1;
	appData->xs[5*16 + 0*4 + 3] = 0;
	appData->ys[5*16 + 0*4 + 0] = 0;
	appData->ys[5*16 + 0*4 + 1] = 0;
	appData->ys[5*16 + 0*4 + 2] = 1;
	appData->ys[5*16 + 0*4 + 3] = 1;

	appData->xs[5*16 + 1*4 + 0] = 0;
	appData->xs[5*16 + 1*4 + 1] = 0;
	appData->xs[5*16 + 1*4 + 2] = 1;
	appData->xs[5*16 + 1*4 + 3] = 1;
	appData->ys[5*16 + 1*4 + 0] = -1;
	appData->ys[5*16 + 1*4 + 1] = 0;
	appData->ys[5*16 + 1*4 + 2] = 0;
	appData->ys[5*16 + 1*4 + 3] = 1;

	appData->xs[5*16 + 2*4 + 0] = 0;
	appData->xs[5*16 + 2*4 + 1] = 1;
	appData->xs[5*16 + 2*4 + 2] = -1;
	appData->xs[5*16 + 2*4 + 3] = 0;
	appData->ys[5*16 + 2*4 + 0] = -1;
	appData->ys[5*16 + 2*4 + 1] = -1;
	appData->ys[5*16 + 2*4 + 2] = 0;
	appData->ys[5*16 + 2*4 + 3] = 0;

	appData->xs[5*16 + 3*4 + 0] = -1;
	appData->xs[5*16 + 3*4 + 1] = -1;
	appData->xs[5*16 + 3*4 + 2] = 0;
	appData->xs[5*16 + 3*4 + 3] = 0;
	appData->ys[5*16 + 3*4 + 0] = -1;
	appData->ys[5*16 + 3*4 + 1] = 0;
	appData->ys[5*16 + 3*4 + 2] = 0;
	appData->ys[5*16 + 3*4 + 3] = 1;

	//piece 6
	// xx
	//  xx
	appData->xs[6*16 + 0*4 + 0] = -1;
	appData->xs[6*16 + 0*4 + 1] = 0;
	appData->xs[6*16 + 0*4 + 2] = 0;
	appData->xs[6*16 + 0*4 + 3] = 1;
	appData->ys[6*16 + 0*4 + 0] = 0;
	appData->ys[6*16 + 0*4 + 1] = 0;
	appData->ys[6*16 + 0*4 + 2] = 1;
	appData->ys[6*16 + 0*4 + 3] = 1;

	appData->xs[6*16 + 1*4 + 0] = 0;
	appData->xs[6*16 + 1*4 + 1] = 0;
	appData->xs[6*16 + 1*4 + 2] = 1;
	appData->xs[6*16 + 1*4 + 3] = 1;
	appData->ys[6*16 + 1*4 + 0] = 0;
	appData->ys[6*16 + 1*4 + 1] = 1;
	appData->ys[6*16 + 1*4 + 2] = -1;
	appData->ys[6*16 + 1*4 + 3] = 0;

	appData->xs[6*16 + 2*4 + 0] = -1;
	appData->xs[6*16 + 2*4 + 1] = 0;
	appData->xs[6*16 + 2*4 + 2] = 0;
	appData->xs[6*16 + 2*4 + 3] = 1;
	appData->ys[6*16 + 2*4 + 0] = -1;
	appData->ys[6*16 + 2*4 + 1] = -1;
	appData->ys[6*16 + 2*4 + 2] = 0;
	appData->ys[6*16 + 2*4 + 3] = 0;

	appData->xs[6*16 + 3*4 + 0] = -1;
	appData->xs[6*16 + 3*4 + 1] = -1;
	appData->xs[6*16 + 3*4 + 2] = 0;
	appData->xs[6*16 + 3*4 + 3] = 0;
	appData->ys[6*16 + 3*4 + 0] = 0;
	appData->ys[6*16 + 3*4 + 1] = 1;
	appData->ys[6*16 + 3*4 + 2] = -1;
	appData->ys[6*16 + 3*4 + 3] = 0;

	/* initialize game data */
	newGame(appData);
	appData->state = GAME_OVER;
	appData->currentPiece = 0;
	appData->rotation = 0;
	appData->x = -4;
	appData->y = 0;
	sprintf(appData->message, "press up");
	appData->difficulty = 1;
	appData->highscore = 0;
	appData->highlines = 0;
	appData->apptime = 0.0;

	/* create paints and path objects */
	appData->piecePaint = vgCreatePaint();
	vgSetPaint(appData->piecePaint, VG_FILL_PATH | VG_STROKE_PATH);

	appData->textFillPaint = vgCreatePaint();
	vgSetColor(appData->textFillPaint, 0xffffffff);
	appData->textStrokePaint = vgCreatePaint();
	vgSetColor(appData->textStrokePaint, 0x000000ff);

	appData->piecePath = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
	vguRect(appData->piecePath, 0.0f, 0.0f, BLOCK_SIZE, BLOCK_SIZE);

	appData->framePath = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
	vguRect(appData->framePath, -0.5f, -0.5f, PLAYFIELD_WIDTH*BLOCK_SIZE+1.0f, PLAYFIELD_HEIGHT*BLOCK_SIZE+1.0f);

	/* create font */
	appData->font = new Font(10);

	/* create shadow paints */
	float stops[10] = {0, 0,0,0,1, 1, 0,0,0,0};
	float invstops[10] = {0, 0,0,0,0, 1, 0,0,0,1};

	appData->shadowPaint[0] = vgCreatePaint();
	vgSetParameteri(appData->shadowPaint[0], VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(appData->shadowPaint[0], VG_PAINT_COLOR_RAMP_STOPS, 10, stops);
	vgSetParameteri(appData->shadowPaint[0], VG_PAINT_TYPE, VG_PAINT_TYPE_LINEAR_GRADIENT);
	float grad0[4] = {0.0f, 0.0f, 0.0f, -BLOCK_SIZE/2.0f};
	vgSetParameterfv(appData->shadowPaint[0], VG_PAINT_LINEAR_GRADIENT, 4, grad0);

	appData->shadowPaint[1] = vgCreatePaint();
	vgSetParameteri(appData->shadowPaint[1], VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(appData->shadowPaint[1], VG_PAINT_COLOR_RAMP_STOPS, 10, stops);
	vgSetParameteri(appData->shadowPaint[1], VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	float grad1[5] = {BLOCK_SIZE/2.0f, 0.0f, BLOCK_SIZE/2.0f, 0.0f, BLOCK_SIZE/2.0f};
	vgSetParameterfv(appData->shadowPaint[1], VG_PAINT_RADIAL_GRADIENT, 5, grad1);

	appData->shadowPaint[2] = vgCreatePaint();
	vgSetParameteri(appData->shadowPaint[2], VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(appData->shadowPaint[2], VG_PAINT_COLOR_RAMP_STOPS, 10, stops);
	vgSetParameteri(appData->shadowPaint[2], VG_PAINT_TYPE, VG_PAINT_TYPE_LINEAR_GRADIENT);
	float grad2[4] = {BLOCK_SIZE, 0.0f, 3.0f*BLOCK_SIZE/2.0f, 0.0f};
	vgSetParameterfv(appData->shadowPaint[2], VG_PAINT_LINEAR_GRADIENT, 4, grad2);

	appData->shadowPaint[3] = vgCreatePaint();
	vgSetParameteri(appData->shadowPaint[3], VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(appData->shadowPaint[3], VG_PAINT_COLOR_RAMP_STOPS, 10, stops);
	vgSetParameteri(appData->shadowPaint[3], VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	float grad3[5] = {BLOCK_SIZE, BLOCK_SIZE/2.0f, BLOCK_SIZE, BLOCK_SIZE/2.0f, BLOCK_SIZE/2.0f};
	vgSetParameterfv(appData->shadowPaint[3], VG_PAINT_RADIAL_GRADIENT, 5, grad3);

	appData->shadowPaint[4] = vgCreatePaint();
	vgSetParameteri(appData->shadowPaint[4], VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(appData->shadowPaint[4], VG_PAINT_COLOR_RAMP_STOPS, 10, stops);
	vgSetParameteri(appData->shadowPaint[4], VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	float grad4[5] = {BLOCK_SIZE, 0.0f, BLOCK_SIZE, 0.0f, BLOCK_SIZE/2.0f};
	vgSetParameterfv(appData->shadowPaint[4], VG_PAINT_RADIAL_GRADIENT, 5, grad4);

	appData->shadowPaint[5] = vgCreatePaint();
	vgSetParameteri(appData->shadowPaint[5], VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
	vgSetParameterfv(appData->shadowPaint[5], VG_PAINT_COLOR_RAMP_STOPS, 10, invstops);
	vgSetParameteri(appData->shadowPaint[5], VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
	float grad5[5] = {BLOCK_SIZE+BLOCK_SIZE/2.0f, -BLOCK_SIZE/2.0f, BLOCK_SIZE+BLOCK_SIZE/2.0f, -BLOCK_SIZE/2.0f, BLOCK_SIZE/2.0f};
	vgSetParameterfv(appData->shadowPaint[5], VG_PAINT_RADIAL_GRADIENT, 5, grad5);


	/* create shadow paths */
	appData->shadowPath[0] = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
	vguRect(appData->shadowPath[0], 0.0f, -BLOCK_SIZE/2.0f, BLOCK_SIZE, BLOCK_SIZE/2.0f);
	appData->shadowPath[1] = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
	vguRect(appData->shadowPath[1], BLOCK_SIZE/2.0f, -BLOCK_SIZE/2.0f, BLOCK_SIZE/2.0f, BLOCK_SIZE/2.0f);
	appData->shadowPath[2] = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
	vguRect(appData->shadowPath[2], 0.0f, -BLOCK_SIZE/2.0f, BLOCK_SIZE/2.0f, BLOCK_SIZE/2.0f);
	appData->shadowPath[3] = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
	vguRect(appData->shadowPath[3], BLOCK_SIZE, 0.0f, BLOCK_SIZE/2.0f, BLOCK_SIZE);
	appData->shadowPath[4] = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
	vguRect(appData->shadowPath[4], BLOCK_SIZE, 0.0f, BLOCK_SIZE/2.0f, BLOCK_SIZE/2.0f);
	appData->shadowPath[5] = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
	vguRect(appData->shadowPath[5], BLOCK_SIZE, BLOCK_SIZE/2.0f, BLOCK_SIZE/2.0f, BLOCK_SIZE/2.0f);
	appData->shadowPath[6] = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
	vguRect(appData->shadowPath[6], BLOCK_SIZE, -BLOCK_SIZE/2.0f, BLOCK_SIZE/2.0f, BLOCK_SIZE/2.0f);

	/* create paths for the background image */
	appData->chiliX = 1000000.0f;
	appData->chiliY = 1000000.0f;
	appData->chiliW = 0.0f;
	appData->chiliH = 0.0f;
	for(unsigned int i=0;i<NUM_CHILI_PATHS;i++)
	{
		float x,y,w,h;
		appData->chiliPath[i] = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
		vgAppendPathData(appData->chiliPath[i], chili_paths[i].nCommands,
						(VGubyte*)chili_paths[i].cmds, chili_paths[i].floats);
		vgPathBounds(appData->chiliPath[i], &x, &y, &w, &h);
		if(x < appData->chiliX) appData->chiliX = x;
		if(y < appData->chiliY) appData->chiliY = y;
		if(w > appData->chiliW) appData->chiliW = w;
		if(h > appData->chiliH) appData->chiliH = h;
	}

	/* create paths for the intro screen */
	appData->skullX = 1000000.0f;
	appData->skullY = 1000000.0f;
	appData->skullW = 0.0f;
	appData->skullH = 0.0f;
	for(unsigned int i=0;i<NUM_SKULL_PATHS;i++)
	{
		float x,y,w,h;
		appData->skullPath[i] = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
		vgAppendPathData(appData->skullPath[i], skull_paths[i].nCommands,
						(VGubyte*)skull_paths[i].cmds, skull_paths[i].floats);
		vgPathBounds(appData->skullPath[i], &x, &y, &w, &h);
		if(x < appData->skullX) appData->skullX = x;
		if(y < appData->skullY) appData->skullY = y;
		if(w > appData->skullW) appData->skullW = w;
		if(h > appData->skullH) appData->skullH = h;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	Game data deinitialization
 *//*-------------------------------------------------------------------*/

static void deinitGame(AppData* appData)
{
	AK_ASSERT(appData);
	vgDestroyPaint(appData->textFillPaint);
	vgDestroyPaint(appData->textStrokePaint);
	vgDestroyPaint(appData->piecePaint);
	for(unsigned int i=0;i<6;i++)
		vgDestroyPaint(appData->shadowPaint[i]);
	vgDestroyPath(appData->piecePath);
	vgDestroyPath(appData->framePath);
	for(unsigned int i=0;i<7;i++)
		vgDestroyPath(appData->shadowPath[i]);
	delete appData->font;
	for(unsigned int i=0;i<NUM_CHILI_PATHS;i++)
		vgDestroyPath(appData->chiliPath[i]);
	for(unsigned int i=0;i<NUM_SKULL_PATHS;i++)
		vgDestroyPath(appData->skullPath[i]);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Handle one frame of the game: update playfield and render
 *//*-------------------------------------------------------------------*/

static void gameFrame(AppData* appData, double dt)
{
	int i, x, y;

	/* update the game */
	appData->apptime += dt;
	if(appData->state == PLAYING)
	{
		updateGame(appData, dt);
	}

	/* clear background */
	{
		float clearColor[4] = {0.8f,0.4f,0.0f,1};
		if(appData->state == GAME_OVER)
		{
			clearColor[0] *= 0.5f;
			clearColor[1] *= 0.5f;
			clearColor[2] *= 0.5f;
		}
		vgSetfv(VG_CLEAR_COLOR, 4, clearColor);
		vgClear(0, 0, SAMPLE_WIN_WIDTH*SAMPLE_WIN_SCALE, SAMPLE_WIN_HEIGHT*SAMPLE_WIN_SCALE);
	}

	vgSetPaint(appData->piecePaint, VG_FILL_PATH | VG_STROKE_PATH);

	{	//draw background image
		float scale = 1.5f * SAMPLE_WIN_WIDTH/appData->chiliW;
		vgLoadIdentity();
		vgScale(SAMPLE_WIN_SCALE, SAMPLE_WIN_SCALE);
		vgTranslate(SAMPLE_WIN_WIDTH/2.0f, SAMPLE_WIN_HEIGHT/2.0f);
		vgScale(scale, -scale);
		vgRotate((float)sin(appData->apptime)*2.0f);
		vgTranslate(-appData->chiliX - appData->chiliW * 0.5f, -appData->chiliY - appData->chiliH * 0.5f);
		for(unsigned int i=0;i<NUM_CHILI_PATHS;i++)
		{
			unsigned int c = (chili_paths[i].color<<8);
			if(appData->state == GAME_OVER)
			{
				c &= 0xfefe00fe;
				c >>= 1;
			}
			vgSetColor(appData->piecePaint, c | 255);
			vgDrawPath(appData->chiliPath[i], VG_FILL_PATH);
		}
	}

	float sx = SAMPLE_WIN_WIDTH/2.0f - PLAYFIELD_WIDTH*BLOCK_SIZE/2.0f;
	float sy = -(SAMPLE_WIN_HEIGHT/2.0f - PLAYFIELD_HEIGHT*BLOCK_SIZE/2.0f);

	//draw playfield border
	vgLoadIdentity();
	vgSetf(VG_STROKE_LINE_WIDTH, 1.0f);
	vgScale(SAMPLE_WIN_SCALE, SAMPLE_WIN_SCALE);
	vgTranslate(sx, sy + SAMPLE_WIN_HEIGHT-PLAYFIELD_HEIGHT*BLOCK_SIZE);
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);
	vgTranslate(BLOCK_SIZE/3.0f, -BLOCK_SIZE/3.0f);
	vgSetColor(appData->piecePaint, 0x0000003f);
	vgDrawPath(appData->framePath, VG_STROKE_PATH);
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC);
	vgTranslate(-BLOCK_SIZE/3.0f, BLOCK_SIZE/3.0f);
	vgSetColor(appData->piecePaint, 0x000000ff);
	vgDrawPath(appData->framePath, VG_STROKE_PATH);

	if(appData->state == PLAYING)
	{
		//add piece to playfield (for drawing and drop shadow generation)
		for(i=0;i<4;i++)
		{
			int xx = appData->x + appData->xs[appData->currentPiece * 16 + appData->rotation * 4 + i];
			int yy = appData->y + appData->ys[appData->currentPiece * 16 + appData->rotation * 4 + i];
			if( xx >= 0 && xx < PLAYFIELD_WIDTH && yy >= 0 && yy < PLAYFIELD_HEIGHT )
				appData->playfield[yy*PLAYFIELD_WIDTH+xx] = appData->currentPiece+1;
		}
	}

	//draw pieces
	int *src = appData->playfield;
	for(y=0;y<PLAYFIELD_HEIGHT;y++)
	{
		for(x=0;x<PLAYFIELD_WIDTH;x++)
		{
			int p = *src++;
			if(p)
			{
				unsigned int c = appData->colors[p];
				if(appData->state == GAME_OVER)
				{
					c &= 0xfefe00fe;
					c >>= 1;
					c |= 255;
				}
				vgLoadIdentity();
				vgScale(SAMPLE_WIN_SCALE, SAMPLE_WIN_SCALE);
				vgTranslate(sx + x*BLOCK_SIZE, sy + SAMPLE_WIN_HEIGHT-BLOCK_SIZE-y*BLOCK_SIZE);
				vgSetColor(appData->piecePaint, c);
				vgDrawPath(appData->piecePath, VG_FILL_PATH);
			}
		}
	}

	//draw drop shadows
	vgSetColor(appData->piecePaint, 0x0000007f);
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);
	for(y=0;y<PLAYFIELD_HEIGHT;y++)
	{
		for(x=0;x<PLAYFIELD_WIDTH;x++)
		{
			int pcc = appData->playfield[y*PLAYFIELD_WIDTH+x];
			int pul = 0, puc = 0, pur = 0, pcl = 0, pcr = 0, pdl = 0, pdc = 0, pdr = 0;
			if(y > 0)
			{
				if(x > 0) pul = appData->playfield[(y-1)*PLAYFIELD_WIDTH+x-1];
				puc = appData->playfield[(y-1)*PLAYFIELD_WIDTH+x];
				if(x < PLAYFIELD_WIDTH-1) pur = appData->playfield[(y-1)*PLAYFIELD_WIDTH+x+1];
			}
			if(x > 0) pcl = appData->playfield[y*PLAYFIELD_WIDTH+x-1];
			if(x < PLAYFIELD_WIDTH-1) pcr = appData->playfield[y*PLAYFIELD_WIDTH+x+1];
			if(y < PLAYFIELD_HEIGHT-1)
			{
				if(x > 0) pdl = appData->playfield[(y+1)*PLAYFIELD_WIDTH+x-1];
				pdc = appData->playfield[(y+1)*PLAYFIELD_WIDTH+x];
				if(x < PLAYFIELD_WIDTH-1) pdr = appData->playfield[(y+1)*PLAYFIELD_WIDTH+x+1];
			}

			if(pcc)
			{
				if(!pdc)
				{	/* bottom */
					vgLoadIdentity();
					vgScale(SAMPLE_WIN_SCALE, SAMPLE_WIN_SCALE);
					vgTranslate(sx + x*BLOCK_SIZE, sy + SAMPLE_WIN_HEIGHT-BLOCK_SIZE-y*BLOCK_SIZE);
					if(pcl && !pdl)
					{	/* straight */
						vgSetPaint(appData->shadowPaint[0], VG_FILL_PATH);
						vgDrawPath(appData->shadowPath[0], VG_FILL_PATH);
					}
					else
					{	/* corner */
						vgSetPaint(appData->shadowPaint[0], VG_FILL_PATH);
						vgDrawPath(appData->shadowPath[1], VG_FILL_PATH);

						if(!pdl)
						{
							vgSetPaint(appData->shadowPaint[1], VG_FILL_PATH);
							vgDrawPath(appData->shadowPath[2], VG_FILL_PATH);
						}
					}
				}
				if(!pcr)
				{	/* right */
					vgLoadIdentity();
					vgScale(SAMPLE_WIN_SCALE, SAMPLE_WIN_SCALE);
					vgTranslate(sx + x*BLOCK_SIZE, sy + SAMPLE_WIN_HEIGHT-BLOCK_SIZE-y*BLOCK_SIZE);
					if(puc && !pur)
					{	/* straight */
						vgSetPaint(appData->shadowPaint[2], VG_FILL_PATH);
						vgDrawPath(appData->shadowPath[3], VG_FILL_PATH);
					}
					else
					{	/* corner */
						vgSetPaint(appData->shadowPaint[2], VG_FILL_PATH);
						vgDrawPath(appData->shadowPath[4], VG_FILL_PATH);

						if(!pur)
						{
							vgSetPaint(appData->shadowPaint[3], VG_FILL_PATH);
							vgDrawPath(appData->shadowPath[5], VG_FILL_PATH);
						}
					}
				}
				if(!pdr && !pcr && !pdc)
				{	/* outer corner */
					vgLoadIdentity();
					vgScale(SAMPLE_WIN_SCALE, SAMPLE_WIN_SCALE);
					vgTranslate(sx + x*BLOCK_SIZE, sy + SAMPLE_WIN_HEIGHT-BLOCK_SIZE-y*BLOCK_SIZE);
					vgSetPaint(appData->shadowPaint[4], VG_FILL_PATH);
					vgDrawPath(appData->shadowPath[6], VG_FILL_PATH);
				}
			}
			if(!pdr && pcr && pdc)
			{	/* inner corner */
				vgLoadIdentity();
				vgScale(SAMPLE_WIN_SCALE, SAMPLE_WIN_SCALE);
				vgTranslate(sx + x*BLOCK_SIZE, sy + SAMPLE_WIN_HEIGHT-BLOCK_SIZE-y*BLOCK_SIZE);
				vgSetPaint(appData->shadowPaint[5], VG_FILL_PATH);
				vgDrawPath(appData->shadowPath[6], VG_FILL_PATH);
			}
		}
	}
	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC);
	vgSetPaint(appData->piecePaint, VG_FILL_PATH | VG_STROKE_PATH);

	if(appData->state == PLAYING)
	{
		//remove piece from playfield
		for(i=0;i<4;i++)
		{
			int xx = appData->x + appData->xs[appData->currentPiece * 16 + appData->rotation * 4 + i];
			int yy = appData->y + appData->ys[appData->currentPiece * 16 + appData->rotation * 4 + i];
			if( xx >= 0 && xx < PLAYFIELD_WIDTH && yy >= 0 && yy < PLAYFIELD_HEIGHT )
				appData->playfield[yy*PLAYFIELD_WIDTH+xx] = 0;
		}
	}

	if(appData->state == PLAYING)
	{
		//draw next pieces
		for(int j=0;j<NUM_NEXT_PIECES;j++)
		{
			for(i=0;i<4;i++)
			{
				int xx = 3 + appData->xs[appData->nextPiece[j] * 16 + i];
				int yy = 1 + appData->ys[appData->nextPiece[j] * 16 + i] + j*4;
				{
					vgLoadIdentity();
					vgScale(SAMPLE_WIN_SCALE, SAMPLE_WIN_SCALE);
					vgTranslate(xx*BLOCK_SIZE, sy + SAMPLE_WIN_HEIGHT-BLOCK_SIZE-yy*BLOCK_SIZE);
					vgSetColor(appData->piecePaint, appData->colors[appData->nextPiece[j]+1]);
					vgDrawPath(appData->piecePath, VG_FILL_PATH);
				}
			}
		}
	}

	if(appData->state == GAME_OVER)
	{	/* draw intro image */
		float scale = 1.5f * SAMPLE_WIN_WIDTH/appData->skullW;
		vgLoadIdentity();
		vgScale(SAMPLE_WIN_SCALE, SAMPLE_WIN_SCALE);
		vgTranslate(SAMPLE_WIN_WIDTH/2.0f, SAMPLE_WIN_HEIGHT/2.0f-20.0f);
		vgScale(scale, -scale);
		vgRotate((float)sin(appData->apptime)*2.0f+1.0f);
		float s = 1.0f + (float)sin(appData->apptime*2.0f)*0.5f;
		vgScale(s, s);
		vgTranslate(-appData->skullX - appData->skullW * 0.5f, -appData->skullY - appData->skullH * 0.5f);
		for(unsigned int i=0;i<NUM_SKULL_PATHS;i++)
		{
			vgSetColor(appData->piecePaint, (unsigned int)(246<<24) | (unsigned int)(213<<16) | (unsigned int)255);
			vgDrawPath(appData->skullPath[i], VG_FILL_PATH);
		}
		vgSetPaint(appData->textStrokePaint, VG_STROKE_PATH);
		vgSetf(VG_STROKE_LINE_WIDTH, 10.0f);
		for(unsigned int i=0;i<NUM_SKULL_PATHS;i++)
		{
			vgDrawPath(appData->skullPath[i], VG_STROKE_PATH);
		}
	}

	{	/* draw score etc. */
		char msg[100];
		vgLoadIdentity();
		vgSetPaint(appData->textFillPaint, VG_FILL_PATH);
		vgScale(SAMPLE_WIN_SCALE, SAMPLE_WIN_SCALE);
		vgSeti(VG_BLEND_MODE, VG_BLEND_SRC);
		vgSeti(VG_RENDERING_QUALITY, VG_RENDERING_QUALITY_FASTER);
		appData->font->renderString(appData->message, 10.0f, 10.0f, VG_FILL_PATH);
		float mx = sx + PLAYFIELD_WIDTH*BLOCK_SIZE + 5.0f;
		float my = SAMPLE_WIN_HEIGHT-10.0f;
		sprintf(msg, "%d", appData->score);
		appData->font->renderString(msg, mx, my-10.0f, VG_FILL_PATH);
		appData->font->renderString("score", mx, my-20.0f, VG_FILL_PATH);
		sprintf(msg, "%d", appData->lines);
		appData->font->renderString(msg, mx, my-35.0f, VG_FILL_PATH);
		appData->font->renderString("lines", mx, my-45.0f, VG_FILL_PATH);
		sprintf(msg, "%d", appData->level);
		appData->font->renderString(msg, mx, my-60.0f, VG_FILL_PATH);
		appData->font->renderString("level", mx, my-70.0f, VG_FILL_PATH);
		sprintf(msg, "%d", appData->highscore);
		appData->font->renderString(msg, mx, my-85.0f, VG_FILL_PATH);
		appData->font->renderString("highscore", mx, my-95.0f, VG_FILL_PATH);
		sprintf(msg, "%d", appData->highlines);
		appData->font->renderString(msg, mx, my-110.0f, VG_FILL_PATH);
		appData->font->renderString("highlines", mx, my-120.0f, VG_FILL_PATH);
		sprintf(msg, "%d", appData->difficulty);
		appData->font->renderString(msg, mx, my-135.0f, VG_FILL_PATH);
		appData->font->renderString("difficulty", mx, my-145.0f, VG_FILL_PATH);
	}

	if(appData->state == GAME_OVER)
	{	/* draw intro text */
		vgLoadIdentity();
		vgSetPaint(appData->textFillPaint, VG_FILL_PATH);
		vgSetPaint(appData->textStrokePaint, VG_STROKE_PATH);
		vgSetf(VG_STROKE_LINE_WIDTH, 0.035f);
		vgScale(SAMPLE_WIN_SCALE, SAMPLE_WIN_SCALE);
		vgTranslate(88, 170);
		vgRotate(-(float)sin(appData->apptime)*2.0f);
		float s = 1.0f + (float)sin(appData->apptime*2.0f)*0.5f;
		vgScale(s*0.4f, s*0.4f);
		vgScale(10.0f, 10.0f);
		appData->font->renderString("tetris", -16.0f, -4.0f, VG_FILL_PATH | VG_STROKE_PATH);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	Start a new game
 *//*-------------------------------------------------------------------*/

static void newGame(AppData* appData)
{
	/* clear playfield */
	memset(appData->playfield,0,sizeof(int)*PLAYFIELD_WIDTH*PLAYFIELD_HEIGHT);

	srand((int)(appData->apptime*1000.0));	//initialize random number generator
	appData->state = PLAYING;
	appData->score = 0;
	appData->level = 1;
	appData->lines = 0;
	for(int i=0;i<NUM_NEXT_PIECES;i++)
		appData->nextPiece[i] = rand() % 7;
	appData->D = HG_FALSE;
	sprintf(appData->message, " ");

	newPiece(appData);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Add a new piece to the game
 *//*-------------------------------------------------------------------*/

static void newPiece(AppData* appData)
{
	appData->currentPiece = appData->nextPiece[0];
	appData->time = 0.0;
	appData->x = PLAYFIELD_WIDTH / 2 - 1;
	appData->y = 0;
	for(int i=0;i<NUM_NEXT_PIECES-1;i++)
		appData->nextPiece[i] = appData->nextPiece[i+1];
	appData->nextPiece[NUM_NEXT_PIECES-1] = rand() % 7;
	appData->rotation = 0;

	if( collides(appData, appData->x, appData->y, appData->currentPiece, 0 ) )
		gameOver(appData);	//new piece doesn't fit to the playground => game over
}

/*-------------------------------------------------------------------*//*!
 * \brief	Game over
 *//*-------------------------------------------------------------------*/

static void gameOver(AppData* appData)
{
	appData->state = GAME_OVER;
	sprintf(appData->message, "game over");

	if( appData->score > appData->highscore )
	{
		appData->highscore = appData->score;
		appData->highlines = appData->lines;
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	Update playfield
 *//*-------------------------------------------------------------------*/

static void updateGame(AppData* appData, double dt)
{
	dt *= appData->speed;
	if( appData->D )
		dt *= 30.0f;
	else
		dt *= (float)(appData->level+32)/16.0f;
	appData->time += dt;

	while( appData->time - float(appData->y) > 1.0f )
	{	//it's time to move down
		if( collides(appData, appData->x,appData->y+1,appData->currentPiece,appData->rotation) )
		{	//collides on the way down => place the piece on the playfield and drop a new one
			addPiece(appData, appData->x,appData->y,appData->currentPiece,appData->rotation);
			newPiece(appData);
		}
		else
		{	//doesn't collide, move down
			++appData->y;
			if( appData->D )
				appData->score += (int)(appData->level * appData->speed);
		}
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	Add a piece to the playfield and check for full lines
 *//*-------------------------------------------------------------------*/

static void addPiece(AppData* appData, int x, int y, int piece, int rot)
{
	//add piece
	int xx,yy,miny = 0x7fffffff,maxy = 0;
	for(int i=0;i<4;++i)
	{
		xx = x + appData->xs[piece * 16 + rot * 4 + i];
		yy = y + appData->ys[piece * 16 + rot * 4 + i];
		if( xx >= 0 && xx < PLAYFIELD_WIDTH && yy >= 0 && yy < PLAYFIELD_HEIGHT )
		{
			if( yy > maxy ) maxy = yy;
			if( yy < miny ) miny = yy;
			appData->playfield[yy * PLAYFIELD_WIDTH + xx] = piece + 1;
		}
	}
	appData->score += (int)(100 * appData->level * appData->speed);

	//check for full lines
	int fullLines = 0;
	yy = maxy;
	for(int i = miny;i <= maxy;i++)
	{
		HGbool hole = false;
		for(int x=0;x<PLAYFIELD_WIDTH;++x)
		{
			if( !appData->playfield[yy*PLAYFIELD_WIDTH+x] )
			{
				hole = HG_TRUE;
				break;
			}
		}
		if( hole ) --yy;	//not full, go one line up
		else
		{	//drop lines
			++fullLines;
			//drop all lines above
			for(int y=yy;y>0;--y)
			{
				AK_ASSERT(y > 0);
				AK_ASSERT(y < PLAYFIELD_HEIGHT);
				memcpy(appData->playfield+y*PLAYFIELD_WIDTH,appData->playfield+(y-1)*PLAYFIELD_WIDTH,PLAYFIELD_WIDTH * sizeof(int));
			}
			//clear uppermost line
			memset(appData->playfield,0,PLAYFIELD_WIDTH * sizeof(int));
		}
	}

	appData->score += (int)(100 * fullLines * fullLines * appData->level * appData->speed);
	appData->lines += fullLines;
	appData->level++;
	if( appData->level > 128 )
		appData->level = 128;
}

/*-------------------------------------------------------------------*//*!
 * \brief	Test for collisions
 *//*-------------------------------------------------------------------*/

static HGbool collides(AppData* appData, int x, int y, int piece, int rot)
{
	int xx,yy;
	for(int i=0;i<4;++i)
	{
		xx = x + appData->xs[piece * 16 + rot * 4 + i];
		yy = y + appData->ys[piece * 16 + rot * 4 + i];
		if( xx < 0 || xx >= PLAYFIELD_WIDTH || yy >= PLAYFIELD_HEIGHT || (yy >= 0 && appData->playfield[yy * PLAYFIELD_WIDTH + xx]) )
			return HG_TRUE;
	}

	return HG_FALSE;
}
