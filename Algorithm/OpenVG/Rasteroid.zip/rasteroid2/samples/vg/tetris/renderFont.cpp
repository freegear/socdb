/*------------------------------------------------------------------------
 *
 * OpenVG Tetris Sample
 * ---------------------------------
 *
 * (C) 2006 Hybrid Graphics, Ltd.
 * All Rights Reserved.
 *
 * This file consists of source code released by Hybrid 
 * Graphics under the terms of the accompanying End User License 
 * Agreement (EULA). By using this source code you agree to be 
 * bound by the terms of the EULA. 
 *
 * Use and/or disclosure outside these terms may result in 
 * irreparable harm to Hybrid Graphics and legal action against 
 * the party in breach.
 *
 * This source code is distributed on an "as is" basis, with 
 * all express and implied warranties and conditions disclaimed, 
 * including, without limitation, any implied warranties and
 * conditions of merchantability, satisfactory quality, fitness 
 * for a particular purpose, and non-infringement.
 *
 *//**
 *
 * \file
 * \brief 	Class for rendering fonts
 *
 *//*
 *
 * $Id: //hybrid/products/openvg/1.3/samples/tetris/src/renderFont.cpp#3 $
 * $Date: 2006/03/17 $
 *//*-------------------------------------------------------------------*/

#include "akAppkit.h"
#include "renderFont.h"
#include "font.inl"

#include <string.h>
#include <math.h>

/*-------------------------------------------------------------------*//*!
 * \brief	Font constructor
 *//*-------------------------------------------------------------------*/

Font::Font(int pointSize) :
	m_pointSize(pointSize)
{
	memset(m_glyphs, 0, 256*sizeof(VGPath));

	VGPaint fontpaint = vgCreatePaint();
	VGfloat drawColor[4] = {1,1,1,1};
	vgSetParameterfv(fontpaint, VG_PAINT_COLOR, 4, drawColor);
	vgSetParameteri(fontpaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);

	for(int glyph=0;glyph<g_glyphCount;glyph++)
	{
		const int* points = &g_glyphPoints[g_glyphPointIndices[glyph]*2];
		const unsigned char* instructions = &g_glyphInstructions[g_glyphInstructionIndices[glyph]];
		int instructionCount = g_glyphInstructionCounts[glyph];

		VGPath path = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_S_32, 1.0f/65536.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
		m_glyphs[glyph] = path;
		if(instructionCount)
			vgAppendPathData(path, instructionCount, instructions, points);
	}
	vgDestroyPaint(fontpaint);
}

/*-------------------------------------------------------------------*//*!
 * \brief	Font destructor
 *//*-------------------------------------------------------------------*/

Font::~Font()
{
	for(int i=0;i<g_glyphCount;i++)
	{
		vgDestroyPath(m_glyphs[i]);
	}
}

/*-------------------------------------------------------------------*//*!
 * \brief	Function for rendering a string of text
 *//*-------------------------------------------------------------------*/

void Font::renderString(const char* text, float x, float y, VGbitfield renderFlags) const
{
	float s = (float)m_pointSize;
	float xx = x;
	float mm[9];
	vgGetMatrix(mm);
	for(int l=0;l<(int)strlen(text);l++)
	{
		unsigned int character = (unsigned int)text[l];
		int glyph = g_characterMap[character];
		if( glyph == -1 )
			continue;	//glyph is undefined

		VGfloat mat[9] = {s,    0.0f, 0.0f,
						  0.0f, s,    0.0f,
						  xx,   y,    1.0f};
		vgLoadMatrix(mm);
		vgMultMatrix(mat);

		vgDrawPath(m_glyphs[glyph], renderFlags);

		xx += s * g_glyphAdvances[glyph] / 65536.0f;
	}
	vgLoadMatrix(mm);
}
