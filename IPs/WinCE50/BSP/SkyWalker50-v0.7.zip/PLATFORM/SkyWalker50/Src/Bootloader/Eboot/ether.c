//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//

#include <windows.h>
#include <halether.h>
#define __OAL_ETHDRV_H	// Temporary: clean up build warning until EDBG prototypes are moved.
#include <bsp.h>
#include "loader.h"

#define FROM_BCD(n)    ((((n) >> 4) * 10) + ((n) & 0xf))
#define TO_BCD(n)      ((((n) / 10) << 4) | ((n) % 10))

// Function pointers to the support library functions of the currently installed debug ethernet controller.
//
PFN_EDBG_INIT             pfnEDbgInit;
PFN_EDBG_ENABLE_INTS      pfnEDbgEnableInts;
PFN_EDBG_DISABLE_INTS     pfnEDbgDisableInts;
PFN_EDBG_GET_PENDING_INTS pfnEDbgGetPendingInts;
PFN_EDBG_GET_FRAME        pfnEDbgGetFrame;
PFN_EDBG_SEND_FRAME       pfnEDbgSendFrame;
PFN_EDBG_READ_EEPROM      pfnEDbgReadEEPROM;
PFN_EDBG_WRITE_EEPROM     pfnEDbgWriteEEPROM;
PFN_EDBG_SET_OPTIONS      pfnEDbgSetOptions;

// Function prototypes.
//
//BOOL    CS8900DBG_Init(PBYTE iobase, DWORD membase, USHORT MacAddr[3]);
//UINT16  CS8900DBG_GetFrame(PBYTE pbData, UINT16 *pwLength);
//UINT16  CS8900DBG_SendFrame(PBYTE pbData, DWORD dwLength);
#if 0 //shkim 2006/10/12
// Modified by DJKIM 2006/09/29
// Refer to PUBLIC\COMMON\OAK\DRIVERS\ETHDBG\SMSC100\smsc100.c
BOOL	Smsc100FdInit (BYTE *pbBaseAddress, DWORD dwMultiplier,USHORT MacAddr[3]);
UINT16  Smsc100FdGetFrame (BYTE *pbData, UINT16 *pusLength);
UINT16  Smsc100FdSendFrame (BYTE *pbData, DWORD dwLength);
#else
//BOOL   Smsc91CInit(BYTE *pAddress, DWORD offset, USHORT mac[3]);
//UINT16 Smsc91CSendFrame(BYTE *pBuffer, DWORD length);
//UINT16 Smsc91CGetFrame(BYTE *pBuffer, UINT16 *pLength);
#endif

/*
    @func   BOOL | InitEthDevice | Initializes the Ethernet device to be used for download.
    @rdesc  TRUE = Success, FALSE = Failure.
    @comm    
    @xref   
*/
BOOL InitEthDevice(PBOOT_CFG pBootCfg)
{
    PBYTE  pBaseIOAddress = NULL;
    UINT32 MemoryBase = 0;
    UINT32 multiplier = 0;
    BOOL bResult = FALSE;

    OALMSG(OAL_FUNC, (TEXT("+InitEthDevice.\r\n")));

    // Use the MAC address programmed into flash by the user.
    //
    memcpy(pBSPArgs->kitl.mac, pBootCfg->EdbgAddr.wMAC, 6);
#if 0 //shkim 2006/10/12
    // Use the LAN91C111 Ethernet controller for download.
    //
    pfnEDbgInit      = Smsc100FdInit;
    pfnEDbgGetFrame  = Smsc100FdGetFrame;
    pfnEDbgSendFrame = Smsc100FdSendFrame;
#else
    pfnEDbgInit      = Smsc91CInit;
    pfnEDbgGetFrame  = Smsc91CGetFrame;
    pfnEDbgSendFrame = Smsc91CSendFrame;
#endif

#if 0   // For CS8900
    // OALPAtoVA() : Returns the cached or uncached virtual addr of physical addr
    // DEVICE_LOCATION devLoc : PCI bus driver structure
    pBaseIOAddress   = (PBYTE)OALPAtoVA(pBSPArgs->kitl.devLoc.LogicalLoc, FALSE);
    MemoryBase       = (UINT32)OALPAtoVA(BSP_BASE_REG_PA_LAN91C111_MEMBASE, FALSE);
    
    // Initialize the Ethernet controller.
    //
    if (!pfnEDbgInit((PBYTE)pBaseIOAddress, MemoryBase, pBSPArgs->kitl.mac))
    {
        OALMSG(OAL_ERROR, (TEXT("ERROR: InitEthDevice: Failed to initialize Ethernet controller.\r\n")));
        goto CleanUp;
    }
#else   // For LAN91C111 by DJKIM 2006/09/30
    MemoryBase       = (UINT32)OALPAtoVA(BSP_BASE_REG_PA_LAN91C111_MEMBASE, FALSE);

    // Initialize the Ethernet controller.
    //
    if (!pfnEDbgInit((PBYTE)MemoryBase, (DWORD)multiplier, pBSPArgs->kitl.mac)) // What is dwMultiplier??? by DJKIM 2006/09/30
    {
        OALMSG(OAL_ERROR, (TEXT("ERROR: InitEthDevice: Failed to initialize Ethernet controller.\r\n")));
        goto CleanUp;
    }
#endif


    // Make sure MAC address has been programmed.
    //
    if (!pBSPArgs->kitl.mac[0] && !pBSPArgs->kitl.mac[1] && !pBSPArgs->kitl.mac[2])
    {
        OALMSG(OAL_ERROR, (TEXT("ERROR: InitEthDevice: Invalid MAC address.\r\n")));
        goto CleanUp;
    }

    bResult = TRUE;

CleanUp:

    OALMSG(OAL_FUNC, (TEXT("-InitEthDevice.\r\n")));
    return(bResult);
}


/*
    @func   BOOL | OEMGetRealTime | Returns the current wall-clock time from the RTC.
    @rdesc  TRUE = Success, FALSE = Failure.
    @comm    
    @xref   
*/
static BOOL OEMGetRealTime(LPSYSTEMTIME lpst) 
{
    volatile SMT926A_RTC_REG *smtRTC = (SMT926A_RTC_REG *)OALPAtoVA(SMT926A_BASE_REG_PA_RTC, FALSE);

    // RTC register mapping �� �Ʒ� �ڵ� ���� �ʿ� by DJKIM 2006/09/28
    do
    {
        lpst->wYear         = FROM_BCD(smtRTC->BCDYEAR) + 2000 ;
        lpst->wMonth        = FROM_BCD(smtRTC->BCDMON   & 0x1f);
        lpst->wDay          = FROM_BCD(smtRTC->BCDDAY   & 0x3f);

        lpst->wDayOfWeek    = (smtRTC->BCDDATE - 1);

        lpst->wHour         = FROM_BCD(smtRTC->BCDHOUR  & 0x3f);
        lpst->wMinute       = FROM_BCD(smtRTC->BCDMIN   & 0x7f);
        lpst->wSecond       = FROM_BCD(smtRTC->BCDSEC   & 0x7f);
        lpst->wMilliseconds = 0;
    }
    while (!(lpst->wSecond));

    return(TRUE);
}


/*
    @func   DWORD | OEMEthGetSecs | Returns a free-running seconds count.
    @rdesc  Number of elapsed seconds since last roll-over.
    @comm    
    @xref   
*/
DWORD OEMEthGetSecs(void)
{
    SYSTEMTIME sTime;

    OEMGetRealTime(&sTime);
    return((60UL * (60UL * (24UL * (31UL * sTime.wMonth + sTime.wDay) + sTime.wHour) + sTime.wMinute)) + sTime.wSecond);
}


/*
    @func   BOOL | OEMEthGetFrame | Reads data from the Ethernet device.
    @rdesc  TRUE = Success, FALSE = Failure.
    @comm    
    @xref   
*/
BOOL OEMEthGetFrame(PUCHAR pData, PUSHORT pwLength)
{
    return(pfnEDbgGetFrame(pData, pwLength));
}


/*
    @func   BOOL | OEMEthSendFrame | Writes data to an Ethernet device.
    @rdesc  TRUE = Success, FALSE = Failure.
    @comm    
    @xref   
*/
BOOL OEMEthSendFrame(PUCHAR pData, DWORD dwLength)
{
    BYTE Retries = 0;

    while (Retries++ < 4)
    {
        if (!pfnEDbgSendFrame(pData, dwLength))
            return(TRUE);

        EdbgOutputDebugString("INFO: OEMEthSendFrame: retrying send (%u)\r\n", Retries);
    }

    return(FALSE);
}

