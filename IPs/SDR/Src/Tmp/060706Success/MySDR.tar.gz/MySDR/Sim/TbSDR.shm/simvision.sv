# SimVision Command Script (Tue Jul 04 17:52:14 KST 2006)

#
# databases
#
if {[database find -match exact -name "TbSDR"] == {}} {
    database open /home/eastbrt2/Project/MySDR/Sim/TbSDR.shm/TbSDR.trn -name "TbSDR"
}

#
# conditions
#
set expression {(TbSDR::TbSDR.sdram16bit.Dq === 'hE37C)}
if {[condition find -match exact -name x] == {}} {
    condition new -name  x -expr $expression
} else {
    condition set -using x -expr $expression
}

#
# mmaps
#
mmap new -reuse -name "Example Map" -contents {
{%b=11???? -bgcolor orange -label REG:%x -linecolor yellow -shape bus}
{%x=1F -bgcolor red -label ERROR -linecolor white -shape EVENT}
{%x=2C -bgcolor red -label ERROR -linecolor white -shape EVENT}
{%x=* -label %x -linecolor gray -shape bus}
}

#
# Design Browser windows
#
if {[window find -match exact -name "Design Browser 1"] == {}} {
    window new DesignBrowser -name "Design Browser 1" -geometry 943x716+175+194
} else {
    window geometry "Design Browser 1" 943x716+175+194
}
window target "Design Browser 1" on
browser using "Design Browser 1"
browser set \
    -scope {TbSDR::TbSDR.SDRTop.SDRAi}
browser yview see {TbSDR::TbSDR.SDRTop.SDRAi}

#
# Waveform windows
#
if {[window find -match exact -name "Waveform 1"] == {}} {
    window new WaveWindow -name "Waveform 1" -geometry 1165x707+33+161
} else {
    window geometry "Waveform 1" 1165x707+33+161
}
window target "Waveform 1" on
waveform using "Waveform 1"
waveform sidebar visibility partial
waveform set \
    -primarycursor "TimeA" \
    -signalnames name \
    -signalwidth 165 \
    -units ns \
    -valuewidth 83
cursor set -using "TimeA" -time 272841.731ns
waveform baseline set -time 175472.041ns

set id [waveform add -signals {TbSDR::TbSDR.SDRTop.ARESETB}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.AWAddr[21:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.AWBurst[1:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.AWLen[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.AWId[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.AWValid}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.AWReady}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.WId[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.WReady}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.WValid}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.WLast}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.WStrb[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.WData[31:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.WBLQRead}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.DiValid}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.WQFull}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.WQEmpty}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.WQRead}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{bus(TbSDR::TbSDR.SDRTop.SDRAi.WBurstCnt[3], TbSDR::TbSDR.SDRTop.SDRAi.WBurstCnt[2], TbSDR::TbSDR.SDRTop.SDRAi.WBurstCnt[1], TbSDR::TbSDR.SDRTop.SDRAi.WBurstCnt[0])}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.WrWrapEn}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.WrAddrHold}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.WBurstCnt[3:0]}}]
waveform format $id -radix %d -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.LatchedWBL[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.WrWrapAddrSt[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.WQIncAddr[5:0]}}]
waveform format $id -radix %d -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.WrWrapCnt[5:0]}}]
waveform format $id -radix %d -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RQFull}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RQRead}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RBurstCnt[3:0]}}]
waveform format $id -radix %d -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RdWrapEn}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RQIncAddr[7:0]}}]
waveform format $id -radix %d -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RdWrapCnt[7:0]}}]
waveform format $id -radix %d -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.BId[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.BValid}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.BReady}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.BResp[1:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.tWIdle}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.tWWDat}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.tWWAck}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.tWWReq}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.tWWSpi}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.ARReady}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.ARValid}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.ARId[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.ARBurst[1:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.ARLen[3:0]}}]
waveform format $id -radix %d -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.ARAddr[31:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.ARAddr[25:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RdWrapAALow[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.tRRReq}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.tRRSpi}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RQHFull}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RQFull}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RQRead}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.RReady}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.RValid}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.SD_DQI[31:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.FCLK}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.ReadLatchEnFd}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RdDataMemFd[31:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.In16BitSel}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.ACLK}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RdDataMem[31:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RdIdMem[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RdLastMem}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RdDataRdy}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RdAddrHold}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RQWrite}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RQWrData[35:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RdLastCnt[3:0]}}]
waveform format $id -radix %d -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.tRDIdle}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.tRDReq}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.LatchedRBL[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RBurstCnt[3:0]}}]
waveform format $id -radix %d -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RdWrapAddrSt[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RdWrapCnt[7:0]}}]
waveform format $id -radix %d -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RdWrapEn}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.RQRead}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.RQRdData[35:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.RId[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.RData[31:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.RLast}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.RResp[1:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRCtl.ras_empty}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRCtl.cas_empty}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRCtl.ras_full}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRCtl.cas_full}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.BA_PM}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.BA_REQ}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.BA_ID[3:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.BA_RW}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.BA_AA[21:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.BA_TT[4:0]}}]
waveform format $id -radix %d -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRCtl.rw_bstop0}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRCtl.rw_bstop1}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRCtl.cas_0_ba[1:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRCtl.cas_0_rw}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRCtl.AddrSiz[1:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRCtl.AddrSwapEn}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRCtl.Port16BitSel}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.BA_AA[8]}}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.BA_AA[7]}}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRCtl.BA_BA[1:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRCtl.BA_RA[12:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRCtl.BA_CA[7:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDclk}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDba[1:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDadr[12:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDrasb}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDcasb}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDweb}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.WrAddrHold}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.SDRTop.SDRAi.Out16BitSel}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.SDRTop.SDRAi.WQRdData[35:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {x}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {{TbSDR::TbSDR.sdram16bit.Dq[15:0]}}]
waveform format $id -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.sdram16bit.Data_in_enable}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.sdram16bit.Data_out_enable}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.sdram16bit.Active_enable}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.sdram16bit.Aref_enable}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.sdram16bit.Mode_reg_enable}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.sdram16bit.Read_enable}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.sdram16bit.Write_enable}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}
set id [waveform add -signals {TbSDR::TbSDR.sdram16bit.Prech_enable}]
waveform format $id -radix %b -trace digital -color #00ff00 -symbol {}

waveform xview limits 272830.214ns 272926.077ns

#
# preferences
#
preferences set ams-show-flow {1}
preferences set ams-show-potential {1}
preferences set analog-height {5}
preferences set color-verilog-by-value {1}
preferences set create-cursor-for-new-window {0}
preferences set cv-num-lines {25}
preferences set cv-show-only {1}
preferences set db-scope-gen-compnames {0}
preferences set db-scope-gen-icons {1}
preferences set db-scope-gen-sort {name}
preferences set db-scope-gen-tracksb {0}
preferences set db-scope-systemc-processes {1}
preferences set db-scope-verilog-cells {1}
preferences set db-scope-verilog-functions {1}
preferences set db-scope-verilog-namedbegins {1}
preferences set db-scope-verilog-namedforks {1}
preferences set db-scope-verilog-tasks {1}
preferences set db-scope-vhdl-assertions {1}
preferences set db-scope-vhdl-assignments {1}
preferences set db-scope-vhdl-blocks {1}
preferences set db-scope-vhdl-breakstatements {1}
preferences set db-scope-vhdl-calls {1}
preferences set db-scope-vhdl-generates {1}
preferences set db-scope-vhdl-processstatements {1}
preferences set db-scope-vhdl-unnamedprocesses {1}
preferences set db-show-editbuf {0}
preferences set db-show-modnames {0}
preferences set db-show-values {simulator}
preferences set db-signal-filter-constants {1}
preferences set db-signal-filter-generics {1}
preferences set db-signal-filter-other {1}
preferences set db-signal-filter-quantities {1}
preferences set db-signal-filter-signals {1}
preferences set db-signal-filter-terminals {1}
preferences set db-signal-filter-variables {1}
preferences set db-signal-gen-radix {default}
preferences set db-signal-gen-showdetail {0}
preferences set db-signal-gen-showstrength {0}
preferences set db-signal-gen-sort {name}
preferences set db-signal-show-assertions {1}
preferences set db-signal-show-errorsignals {1}
preferences set db-signal-show-fibers {1}
preferences set db-signal-show-inouts {1}
preferences set db-signal-show-inputs {1}
preferences set db-signal-show-internal {1}
preferences set db-signal-show-live {1}
preferences set db-signal-show-mutexes {1}
preferences set db-signal-show-outputs {1}
preferences set db-signal-show-semaphores {1}
preferences set db-signal-vlogfilter-branches {1}
preferences set db-signal-vlogfilter-memories {1}
preferences set db-signal-vlogfilter-parameters {1}
preferences set db-signal-vlogfilter-registers {1}
preferences set db-signal-vlogfilter-variables {1}
preferences set db-signal-vlogfilter-wires {1}
preferences set default-ams-formatting {potential}
preferences set default-time-units {ar}
preferences set delete-unused-cursors-on-exit {1}
preferences set delete-unused-groups-on-exit {1}
preferences set enable-toolnet {0}
preferences set initial-zoom-out-full {0}
preferences set key-bindings {
	Edit>Undo "Ctrl+Z"
	Edit>Redo "Ctrl+Y"
	Edit>Copy "Ctrl+C"
	Edit>Cut "Ctrl+X"
	Edit>Paste "Ctrl+V"
	Edit>Delete "Del"
        Select>All "Ctrl+A"
        Edit>Select>All "Ctrl+A"
        Edit>SelectAll "Ctrl+A"
      	openDB "Ctrl+O"
        Simulation>Run "F2"
        Simulation>Next "F6"
        Simulation>Step "F5"
        #Schematic window
        View>Zoom>Fit "Alt+="
        View>Zoom>In "Alt+I"
        View>Zoom>Out "Alt+O"
        #Waveform Window
	View>Zoom>InX "Alt+I"
	View>Zoom>OutX "Alt+O"
	View>Zoom>FullX "Alt+="
	View>Zoom>InX_widget "I"
	View>Zoom>OutX_widget "O"
	View>Zoom>FullX_widget "="
	View>Zoom>FullY_widget "Y"
	View>Zoom>Cursor-Baseline "Alt+Z"
	View>Center "Alt+C"
	View>ExpandSequenceTime>AtCursor "Alt+X"
	View>CollapseSequenceTime>AtCursor "Alt+S"
	Edit>Create>Group "Ctrl+G"
	Edit>Ungroup "Ctrl+Shift+G"
	Edit>Create>Marker "Ctrl+M"
	Edit>Create>Condition "Ctrl+E"
	Edit>Create>Bus "Ctrl+W"
	Explore>NextEdge "Ctrl+]"
	Explore>PreviousEdge "Ctrl+["
	ScrollRight "Right arrow"
	ScrollLeft "Left arrow"
	ScrollUp "Up arrow"
	ScrollDown "Down arrow"
	PageUp "PageUp"
	PageDown "PageDown"
	TopOfPage "Home"
	BottomOfPage "End"
}
preferences set marching-waveform {1}
preferences set prompt-exit {1}
preferences set prompt-on-reinvoke {1}
preferences set respond-to-simvision-command {1}
preferences set restore-state-on-startup {0}
preferences set save-state-on-startup {0}
preferences set sb-double-click-command {@goto-definition}
preferences set sb-editor-command {xterm -e vi +%L %F}
preferences set sb-history-size {10}
preferences set sb-radix {default}
preferences set sb-show-strength {1}
preferences set sb-syntax-highlight {1}
preferences set sb-syntax-types {
    {-name "VHDL/VHDL-AMS" -cleanname "vhdl" -extensions {.vhd .vhdl}}
    {-name "Verilog/Verilog-AMS" -cleanname "verilog" -extensions {.v .vams .vms .va}}
    {-name "C" -cleanname "c" -extensions {.c}}
    {-name "C++" -cleanname "c++" -extensions {.h .hpp .cc .cpp .CC}}
    {-name "SystemC" -cleanname "systemc" -extensions {.h .hpp .cc .cpp .CC}}
}
preferences set sb-tab-size {8}
preferences set schematic-show-values {simulator}
preferences set search-toolbar {1}
preferences set seq-time-width {30}
preferences set sfb-colors {
    register #beded1
    variable #beded1
    assignStmt gray85
    force #faa385
}
preferences set sfb-default-tree {0}
preferences set sfb-max-cell-width {40}
preferences set show-database-names {0}
preferences set show-full-signal-names {0}
preferences set show-strength {0}
preferences set show-times-on-cursors {1}
preferences set show-times-on-markers {1}
preferences set signal-type-colors {
	group #0000FF
	overlay #0000FF
	input #FFFF00
	output #FFA500
	inout #00FFFF
	internal #00FF00
	fiber #FF99FF
	errorsignal #FF0000
	assertion #FF0000
	unknown #FFFFFF
}
preferences set snap-to-edge {1}
preferences set toolbars-style {icon}
preferences set transaction-height {3}
preferences set txe-locate-add-fibers {yes}
preferences set txe-locate-create-waveform {sometimes}
preferences set txe-locate-pop-waveform {yes}
preferences set txe-locate-scroll-x {yes}
preferences set txe-locate-scroll-y {yes}
preferences set txe-man-doubleclick-search {edit}
preferences set txe-navigate-search-locate {no}
preferences set txe-navigate-waveform-locate {yes}
preferences set txe-navigate-waveform-next-child {no}
preferences set txe-search-default-form {built_in.basic}
preferences set txe-search-result-limit {200}
preferences set txe-search-reuse-window {never}
preferences set txe-search-show-linenumbers {yes}
preferences set txe-search-style {form}
preferences set txe-view-hold {off}
preferences set use-signal-type-colors {0}
preferences set use-signal-type-icons {1}
preferences set verilog-colors {
	HiZ #ff9900
	StrX #ff0000
	Sm #00ff99
	Me #0000ff
	We #00ffff
	La #ff00ff
	Pu #9900ff
	St ""
	Su #ff0099
	0 ""
	1 ""
	X #ff0000
	Z #ff9900
	other #ffff00
}
preferences set vhdl-colors {
	U #9900ff 
	X #ff0000 
	0 ""
	1 ""
	Z #ff9900 
	W #ff0000
	L #00ffff 
	H #00ffff
	- ""
}
preferences set waveform-banding {1}
preferences set waveform-height {10}
preferences set waveform-space {2}
