vlog ./TbSDR.v
vlog ./TM/TestMaster.v
vlog ./model/mt48lc4m16a2.v

vlog ../Rtl/SDRTop.v
vlog ../Rtl/SDRAi.v
vlog ../Rtl/SDRWQ.v
vlog ../Rtl/SDRRQ.v
vlog ../Rtl/SDRCtl.v
vlog ../Rtl/SDRBsm.v
vlog ../Rtl/SDRRas.v
vlog ../Rtl/SDRCas.v

vsim -L work work.TbSDR &
