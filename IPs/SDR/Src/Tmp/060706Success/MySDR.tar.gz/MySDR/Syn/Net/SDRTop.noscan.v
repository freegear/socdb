
module SDRTop ( ARESETB, PORESETB, ACLK, nACLK, FCLK, AWAddr, AWId, AWLen, 
        AWValid, AWReady, AWBurst, WLast, WStrb, WData, WValid, WReady, WId, 
        BResp, BValid, BReady, BId, ARAddr, ARId, ARLen, ARValid, ARReady, 
        ARBurst, RData, RValid, RReady, RLast, RId, RResp, SD_CKE, SD_CSB, 
        SD_RASB, SD_CASB, SD_WEB, SD_BADDR, SD_ADDR, SD_DQE, SD_DQI, SD_DQO, 
        SD_DQM, PCLK, PRESETB, PSEL, PENABLE, PADDR, PWRITE, PWDATA, PRDATA );
  input [25:0] AWAddr;
  input [3:0] AWId;
  input [3:0] AWLen;
  input [1:0] AWBurst;
  input [3:0] WStrb;
  input [31:0] WData;
  input [3:0] WId;
  output [1:0] BResp;
  output [3:0] BId;
  input [25:0] ARAddr;
  input [3:0] ARId;
  input [3:0] ARLen;
  input [1:0] ARBurst;
  output [31:0] RData;
  output [3:0] RId;
  output [1:0] RResp;
  output [1:0] SD_BADDR;
  output [12:0] SD_ADDR;
  input [31:0] SD_DQI;
  output [31:0] SD_DQO;
  output [3:0] SD_DQM;
  input [7:2] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  input ARESETB, PORESETB, ACLK, nACLK, FCLK, AWValid, WLast, WValid, BReady,
         ARValid, RReady, PCLK, PRESETB, PSEL, PENABLE, PWRITE;
  output AWReady, WReady, BValid, ARReady, RValid, RLast, SD_CKE, SD_CSB,
         SD_RASB, SD_CASB, SD_WEB, SD_DQE;
  wire   RLastS, RValidS, RReadyS, RQFull, WQFull, BA_REQ, BA_RW, BA_PM, n_2;
  wire   [1:0] RRespS;
  wire   [31:0] RDataS;
  wire   [3:0] RIdS;
  wire   [16:0] BA_STS;
  wire   [25:0] BA_AA;
  wire   [4:0] BA_TT;
  wire   [3:0] BA_ID;
  assign BResp[1] = 1'b0;
  assign BResp[0] = 1'b0;

  SDRRDS SDRRDS ( .ACLK(ACLK), .ARESETn(ARESETB), .INFORMATION_S({1'b0, 1'b0, 
        RLastS, RDataS, RIdS}), .VALID_S(RValidS), .READY_S(RReadyS), 
        .INFORMATION_R({RResp, RLast, RData, RId}), .VALID_R(RValid), 
        .READY_R(RReady) );
  SDRAi SDRAi ( .ARESETB(ARESETB), .PORESETB(PORESETB), .ACLK(ACLK), .nACLK(
        nACLK), .FCLK(FCLK), .AWAddr(AWAddr), .AWId(AWId), .AWLen(AWLen), 
        .AWValid(AWValid), .AWReady(AWReady), .AWBurst(AWBurst), .WLast(WLast), 
        .WStrb(WStrb), .WData(WData), .WValid(WValid), .WReady(WReady), .WId(
        WId), .BValid(BValid), .BReady(BReady), .BId(BId), .ARAddr(ARAddr), 
        .ARId(ARId), .ARLen(ARLen), .ARValid(ARValid), .ARReady(ARReady), 
        .ARBurst(ARBurst), .RData(RDataS), .RValid(RValidS), .RReady(RReadyS), 
        .RLast(RLastS), .RId(RIdS), .RQFull(RQFull), .WQFull(WQFull), .BA_STS(
        BA_STS), .BA_AA(BA_AA), .BA_REQ(BA_REQ), .BA_TT(BA_TT), .BA_RW(BA_RW), 
        .BA_ID(BA_ID), .BA_PM(BA_PM), .SD_DQE(SD_DQE), .SD_DQI(SD_DQI), 
        .SD_DQO(SD_DQO), .SD_DQM(SD_DQM) );
  SDRCtl SDRCtl ( .PORESETB(PORESETB), .ARESETB(ARESETB), .ACLK(ACLK), .BA_AA(
        BA_AA), .BA_TT(BA_TT), .BA_RW(BA_RW), .BA_REQ(BA_REQ), .BA_ID(BA_ID), 
        .BA_PM(BA_PM), .BA_STS(BA_STS), .RQFull(RQFull), .WQFull(n_2), 
        .SD_CKE(SD_CKE), .SD_CSB(SD_CSB), .SD_RASB(SD_RASB), .SD_CASB(SD_CASB), 
        .SD_WEB(SD_WEB), .SD_BADDR(SD_BADDR), .SD_ADDR(SD_ADDR), .PCLK(PCLK), 
        .PRESETB(PRESETB), .PSEL(PSEL), .PENABLE(PENABLE), .PADDR(PADDR), 
        .PWRITE(PWRITE), .PWDATA(PWDATA), .PRDATA(PRDATA) );
  AND2X2 U13 ( .A(WReady), .B(WQFull), .Y(n_2) );
endmodule


module SDRCtl ( PORESETB, ARESETB, ACLK, BA_AA, BA_TT, BA_RW, BA_REQ, BA_ID, 
        BA_PM, BA_STS, RQFull, WQFull, SD_CKE, SD_CSB, SD_RASB, SD_CASB, 
        SD_WEB, SD_BADDR, SD_ADDR, PCLK, PRESETB, PSEL, PENABLE, PADDR, PWRITE, 
        PWDATA, PRDATA );
  input [25:0] BA_AA;
  input [4:0] BA_TT;
  input [3:0] BA_ID;
  output [16:0] BA_STS;
  output [1:0] SD_BADDR;
  output [12:0] SD_ADDR;
  input [7:2] PADDR;
  input [31:0] PWDATA;
  output [31:0] PRDATA;
  input PORESETB, ARESETB, ACLK, BA_RW, BA_REQ, BA_PM, RQFull, WQFull, PCLK,
         PRESETB, PSEL, PENABLE, PWRITE;
  output SD_CKE, SD_CSB, SD_RASB, SD_CASB, SD_WEB;
  wire   cmd_mask, tcl_2_, tcl_1_, AddrSwapEn, SDREnStatus, rs_state_2_,
         rs_state_1_, PwDnEn, SelfRefEn, pSD_CKE, refresh_cnt_15_,
         refresh_cnt_14_, refresh_cnt_13_, refresh_cnt_12_, refresh_cnt_11_,
         refresh_cnt_10_, refresh_cnt_9_, refresh_cnt_8_, refresh_cnt_7_,
         refresh_cnt_6_, refresh_cnt_5_, refresh_cnt_4_, refresh_cnt_3_,
         refresh_cnt_1_, cmd_full_d, i_ba_req, cas_0_final, cas_0_newrow,
         cas_empty, ras_empty, bf_0casbusy, bf_0rasbusy, bf_trasbusy,
         bf_0ready, bf_tready, bf_0idle, bf_0last, ecmd_6_, ecmd_4_, ecmd_3_,
         ecmd_2_, ecmd_1_, ecmd_0_, bf_1casbusy, bf_1rasbusy, bf_1ready,
         bf_1idle, bf_1last, bf_2casbusy, bf_2rasbusy, bf_2ready, bf_2idle,
         bf_2last, bf_3casbusy, bf_3rasbusy, bf_3ready, bf_3idle, bf_3last,
         cas_0_rw, rw_bstop0, rw_bstop1, do_valid_3, do_valid_2, do_valid_1,
         do_valid_0, bf_last_3, bf_last_2, bf_last_1, cas_pm_0, cas_0_pm,
         read_bstop, pttn5084_3_, pttn5084_2_, pttn5084_1_, pttn5084_0_,
         iSD_CSB, iSD_RASB, iSD_CASB, iSD_WEB, iSD_CKE, cas_full, closing,
         ras_full, SDREn, PRDATA502_31_, PRDATA502_30_, PRDATA502_29_,
         PRDATA502_28_, PRDATA502_27_, PRDATA502_26_, PRDATA502_25_,
         PRDATA502_24_, PRDATA502_23_, PRDATA502_22_, PRDATA502_21_,
         PRDATA502_20_, PRDATA502_19_, PRDATA502_18_, PRDATA502_17_,
         PRDATA502_16_, PRDATA502_15_, PRDATA502_14_, PRDATA502_13_,
         PRDATA502_12_, PRDATA502_11_, PRDATA502_10_, PRDATA502_9_,
         PRDATA502_8_, PRDATA502_7_, PRDATA502_6_, PRDATA502_5_, PRDATA502_4_,
         PRDATA502_3_, PRDATA502_2_, PRDATA502_1_, PRDATA502_0_,
         PwDnCnt564_15_, PwDnCnt564_14_, PwDnCnt564_13_, PwDnCnt564_12_,
         PwDnCnt564_11_, PwDnCnt564_10_, PwDnCnt564_9_, PwDnCnt564_8_,
         PwDnCnt564_7_, PwDnCnt564_6_, PwDnCnt564_5_, PwDnCnt564_4_,
         PwDnCnt564_3_, PwDnCnt564_2_, PwDnCnt564_1_, selfref_cnt2109_4_,
         selfref_cnt2109_3_, selfref_cnt2109_2_, selfref_cnt2109_1_,
         refresh_cnt2423_15_, refresh_cnt2423_14_, refresh_cnt2423_13_,
         refresh_cnt2423_12_, refresh_cnt2423_11_, refresh_cnt2423_10_,
         refresh_cnt2423_9_, refresh_cnt2423_8_, refresh_cnt2423_7_,
         refresh_cnt2423_6_, refresh_cnt2423_5_, refresh_cnt2423_4_,
         refresh_cnt2423_3_, refresh_cnt2423_2_, refresh_cnt2423_1_,
         refresh_cnt2486_14_, refresh_cnt2486_13_, refresh_cnt2486_12_,
         refresh_cnt2486_11_, refresh_cnt2486_10_, refresh_cnt2486_9_,
         refresh_cnt2486_0_, n2828_3_, do_valid_04685, do_valid4691,
         do_id4820_3_, do_id4820_2_, do_id4820_1_, do_id4820_0_, bf_last_14961,
         bf_last_04967, bf_last4973, n7445, n8053, n8054, n8055, n8056, n8057,
         n8058, n8059, n8060, n8061, n8062, n8063, n8064, n8065, n8066, n8067,
         n8068, n8069, n8070, n8071, n8072, n8073, n8074, n8075, n8076, n8077,
         n8078, n8079, n8080, n8081, n8082, n8083, n8084, n8085, n8086, n8087,
         n8088, n8089, n8090, n8091, n8092, n8093, n8094, n8095, n8096, n8097,
         n8098, n8099, n8100, n8101, n8102, n8103, n8104, n8105, n8106, n8107,
         n8108, n8109, n8110, n8111, n8112, n8113, n8114, n8115, n8116, n8117,
         n8118, n8119, n8120, n8121, n8122, n8123, n8124, n8125, n8126, n8127,
         n8128, n8129, n8130, n8131, n8132, n8133, n8134, n8135, n8136, n8137,
         n8138, n8139, n8140, n8141, n8142, n8143, n8144, n8145, n8146, n8147,
         n8148, n8149, n8150, n8151, n8152, n8153, n8154, n8155, n8156, n8157,
         n8158, n8159, n8160, n8161, n8162, n8163, n8164, n8165, n8166, n8167,
         n8168, n8169, n8170, n8171, n8172, n8173, n8174, n8175, n8176, n8177,
         n8178, n8179, n8180, n8181, n8182, n8183, n8184, n8185, n8186, n8187,
         n8188, n8189, n8190, n8191, n8192, n8193, n8194, n8195, n8196, n8197,
         n8198, n8204, n8601, n8603, n8501, n8502, n8503, n8504, n8505, n8605,
         n8508, n8510, carry, carry0, carry1, carry2, carry3, carry4, carry5,
         carry6, carry7, carry8, carry9, carry10, carry11, carry12, carry13,
         carry14, carry15, carry16, carry17, carry18, carry19, carry20,
         carry21, carry22, carry23, carry24, carry25, carry26, carry27,
         carry28, carry29, carry_9_, n6, n8606, n8608, n8609, n8611, n8612,
         n8613, n8614, n8615, n8616, n8617, n8618, n8619, n8620, n8623, n8624,
         n8627, n8628, n8629, n8630, n8631, n8632, n8633, n8634, n8635, n8636,
         n8637, n8638, n8639, n8641, n8642, n8643, n8644, n8645, n8646, n8648,
         n8649, n8650, n8651, n8652, n8653, n8654, n8655, n8656, n8657, n8658,
         n8659, n8660, n8661, n8662, n8664, n8665, n8666, n8668, n8669, n8670,
         n8671, n8672, n8673, n8674, n8675, n8676, n8678, n8679, n8680, n8681,
         n8682, n8684, n8685, n8686, n8687, n8689, n8690, n8692, n8693, n8694,
         n8695, n8696, n8697, n8698, n8699, n8700, n8701, n8702, n8705, n8706,
         n8709, n8712, n8715, n8718, n8721, n8724, n8725, n8726, n8727, n8728,
         n8729, n8730, n8731, n8732, n8733, n8734, n8735, n8736, n8737, n8738,
         n8739, n8740, n8741, n8742, n8743, n8744, n8745, n8746, n8749, n8750,
         n8751, n8754, n8756, n8757, n8759, n8761, n8763, n8765, n8766, n8767,
         n8769, n8770, n8771, n8772, n8773, n8774, n8775, n8776, n8778, n8779,
         n8781, n8782, n8783, n8784, n8785, n8787, n8788, n8789, n8790, n8791,
         n8792, n8794, n8795, n8796, n8797, n8798, n8799, n8800, n8802, n8803,
         n8804, n8805, n8806, n8808, n8809, n8810, n8811, n8812, n8813, n8814,
         n8815, n8816, n8817, n8818, n8819, n8820, n8821, n8822, n8823, n8824,
         n8826, n8827, n8828, n8829, n8830, n8831, n8832, n8833, n8834, n8835,
         n8836, n8837, n8838, n8839, n8841, n8842, n8843, n8844, n8845, n8846,
         n8847, n8848, n8849, n8851, n8852, n8853, n8854, n8855, n8856, n8858,
         n8859, n8860, n8861, n8862, n8865, n8868, n8869, n8870, n8871, n8872,
         n8873, n8874, n8875, n8876, n8877, n8878, n8879, n8880, n8881, n8882,
         n8883, n8884, n8885, n8886, n8887, n8888, n8889, n8890, n8891, n8892,
         n8893, n8894, n8895, n8896, n8897, n8898, n8899, n8900, n8901, n8902,
         n8903, n8904, n8905, n8906, n8907, n8908, n8909, n8910, n8911, n8912,
         n8913, n8914, n8915, n8916, n8917, n8918, n8919, n8920, n8922, n8924,
         n8925, n8926, n8929, n8930, n8931, n8932, n8933, n8934, n8935, n8936,
         n8937, n8938, n8939, n8941, n8942, n8944, n8945, n8947, n8949, n8951,
         n8953, n8954, n8955, n8956, n8958, n8959, n8960, n8961, n8962, n8963,
         n8965, n8967, n8968, n8969, n8973, n8974, n8976, n8978, n8980, n8981,
         n8982, n8984, n8985, n8987, n8989, n8990, n8991, n8992, n8993, n8995,
         n8996, n8997, n8998, n9002, n9009, n9010, n9011, n9012, n9013, n9014,
         n9016, n9019, n9021, n9023, n9024, n9025, n9026, n9027, n9028, n9029,
         n9030, n9031, n9032, n9033, n9034, n9035, n9036, n9037, n9038, n9039,
         n9040, n9041, n9042, n9046, n9049, n9050, n9051, n9052, n9053, n9054,
         n9055, n9057, n9058, n9059, n9060, n9061, n9062, n9063, n9064, n9065,
         n9069, n9071, n9072, n9074, n9077, n9078, n9079, n9080, n9081, n9082,
         n9083, n9084, n9085, n9086, n9087, n9088, n9089, n9090, n9091, n9092,
         n9093, n9094, n9095, n9096, n9097, n9098, n9099, n9100, n9102, n9103,
         n9104, n9106, n9108, n9109, n9114, n9120, n9124, n9130, n9135, n9137,
         n9142, n9143, n9144, n9145, n9156, n9158, n9160, n9161, n9163, n9164,
         n9165, n9166, n9167, n9168, n9169, n9171, n9172, n9175, n9176, n9177,
         n9178, n9179, n9180, n9181, n9182, n9183, n9185, n9186, n9187, n9188,
         n9189, n9191, n9194, n9195, n9196, n9197, n9198, n9199, n9200, n9201,
         n9202, n9203, n9204, n9205, n9206, n9207, n9208, n9209, n9210, n9211,
         n9212, n9213, n9214, n9215, n9216, n9217, n9218, n9219, n9220, n9221,
         n9222, n9223, n9224, n9225, n9226, n9227, n9228, n9229, n9230, n9231,
         n9232, n9233, n9234, n9235, n9236, n9237, n9238, n9239, n9240, n9241,
         n9242, n9244, n9245, n9246, n9247, n9248, n9249, n9250, n9251, n9252,
         n9253, n9254, n9255, n9256, n9257, n9258, n9259, n9261, n9262, n9263,
         n9264, n9265, n9267, n9268, n9270, n9271, n9272, n9273, n9274, n9275,
         n9276, n9277, n9278, n9280, n9281, n9282, n9283, n9284, n9285, n9286,
         n9288, n9289, n9290, n9291, n9292, n9293, n9294, n9295, n9296, n9297,
         n9298, n9299, n9300, n9301, n9302, n9303, n9304, n9305, n9306, n9307,
         n9308, n9309, n9310, n9311, n9312, n9313, n9314, n9315, n9316, n9317,
         n9318, n9319, n9320, n9321, n9322, n9323, n9324, n9325, n9326, n9327,
         n9328, n9329, n9330, n9331, n9332, n9333, n9334, n9335, n9336, n9337,
         n9338, n9339, n9340, n9341, n9342, n9343, n9344, n9345, n9346, n9347,
         n9348, n9349, n9350, n9351, n9352, n9353, n9354, n9355, n9356, n9357,
         n9358, n9359, n9360, n9361, n9362, n9363, n9364, n9365, n9366, n9367,
         n9368, n9369, n9370, n9371, n9372, n9373, n9374, n9375, n9376, n9377,
         n9378, n9379, n9380, n9381, n9382, n9383, n9384, n9385, n9386, n9387,
         n9388, n9389, n9390, n9391, n9392, n9393, n9394, n9395, n9396, n9397,
         n9398, n9399, n9400, n9401, n9402, n9403, n9404, n9405, n9406, n9407,
         n9408, n9409, n9410, n9411, n9412, n9413, n9414, n9415, n9416, n9417,
         n9418, n9419, n9420, n9421, n9422, n9423, n9424, n9425, n9426, n9427,
         n9428, n9429, n9430, n9431, n9432, n9433, n9434, n9435, n9436, n9437,
         n9438, n9439, n9440, n9441, n9442, n9443, n9447, n9448;
  wire   [3:0] trc;
  wire   [3:0] trasmin;
  wire   [1:0] trcd;
  wire   [1:0] trp;
  wire   [15:0] PwDnCnt;
  wire   [2:0] stable_cnt;
  wire   [3:0] refreshno;
  wire   [15:0] trefresh;
  wire   [15:0] PwDnRef;
  wire   [5:0] ercmd;
  wire   [3:0] ar_cnt;
  wire   [1:0] trp_cnt;
  wire   [3:0] trc_cnt;
  wire   [1:0] tmrs_cnt;
  wire   [1:0] cas_0_ba;
  wire   [12:0] cas_0_ra;
  wire   [4:0] cas_0_tt;
  wire   [13:0] b0_last_ra;
  wire   [1:0] ras_0_ba;
  wire   [12:0] ras_0_ra;
  wire   [4:0] ras_0_tt;
  wire   [5:0] bf_0reqcmd;
  wire   [5:0] bf_0cmd;
  wire   [13:0] b1_last_ra;
  wire   [5:0] bf_1reqcmd;
  wire   [5:0] bf_1cmd;
  wire   [13:0] b2_last_ra;
  wire   [5:0] bf_2reqcmd;
  wire   [5:0] bf_2cmd;
  wire   [13:0] b3_last_ra;
  wire   [5:0] bf_3reqcmd;
  wire   [5:0] bf_3cmd;
  wire   [1:0] last_ba;
  wire   [3:0] do_id_3;
  wire   [3:0] do_id_2;
  wire   [3:0] do_id_1;
  wire   [3:0] do_id_0;
  wire   [10:0] cas_0_ca;
  wire   [12:0] iSD_ADDR;
  wire   [1:0] iSD_BADDR;
  wire   [3:0] cas_0_id;
  wire   [1:0] BA_BA;
  wire   [12:0] BA_RA;
  wire   [10:0] BA_CA;

  SDRBsm_3 B0SM ( .ARESETB(ARESETB), .ACLK(ACLK), .TRP(trp), .TRRD({1'b0, 1'b1}), .TRCD(trcd), .TRASMIN(trasmin), .BA_BA(BA_BA), .BA_RA(BA_RA), .BA_TT(BA_TT), 
        .BA_REQ(i_ba_req), .CAS_0_BA(cas_0_ba), .CAS_0_RA(cas_0_ra), 
        .CAS_0_TT(cas_0_tt), .CAS_0_FINAL(cas_0_final), .CAS_0_NEWROW(
        cas_0_newrow), .CAS_EMPTY(cas_empty), .LAST_RA(b0_last_ra), .RAS_0_BA(
        ras_0_ba), .RAS_0_RA(ras_0_ra), .RAS_0_TT(ras_0_tt), .RAS_EMPTY(
        ras_empty), .BF_NO({1'b0, 1'b0}), .BF_CASBUSY(bf_0casbusy), 
        .BF_TCASBUSY(n8510), .BF_RASBUSY(bf_0rasbusy), .BF_TRASBUSY(
        bf_trasbusy), .BF_READY(bf_0ready), .BF_TREADY(bf_tready), .BF_IDLE(
        bf_0idle), .BF_LAST(bf_0last), .BF_REQCMD(bf_0reqcmd), .BF_CMD(bf_0cmd), .ERCMD({ercmd[5:3], n9447, ercmd[1:0]}), .ECMD({ecmd_6_, n8204, ecmd_4_, 
        ecmd_3_, ecmd_2_, ecmd_1_, ecmd_0_}) );
  SDRBsm_2 B1SM ( .ARESETB(ARESETB), .ACLK(ACLK), .TRP(trp), .TRRD({1'b0, 1'b1}), .TRCD(trcd), .TRASMIN(trasmin), .BA_BA(BA_BA), .BA_RA(BA_RA), .BA_TT(BA_TT), 
        .BA_REQ(i_ba_req), .CAS_0_BA(cas_0_ba), .CAS_0_RA(cas_0_ra), 
        .CAS_0_TT(cas_0_tt), .CAS_0_FINAL(cas_0_final), .CAS_0_NEWROW(
        cas_0_newrow), .CAS_EMPTY(cas_empty), .LAST_RA(b1_last_ra), .RAS_0_BA(
        ras_0_ba), .RAS_0_RA(ras_0_ra), .RAS_0_TT(ras_0_tt), .RAS_EMPTY(
        ras_empty), .BF_NO({1'b0, 1'b1}), .BF_CASBUSY(bf_1casbusy), 
        .BF_TCASBUSY(n8510), .BF_RASBUSY(bf_1rasbusy), .BF_TRASBUSY(
        bf_trasbusy), .BF_READY(bf_1ready), .BF_TREADY(bf_tready), .BF_IDLE(
        bf_1idle), .BF_LAST(bf_1last), .BF_REQCMD(bf_1reqcmd), .BF_CMD(bf_1cmd), .ERCMD({ercmd[5:3], n9447, ercmd[1:0]}), .ECMD({ecmd_6_, n8204, ecmd_4_, 
        ecmd_3_, ecmd_2_, ecmd_1_, ecmd_0_}) );
  SDRBsm_1 B2SM ( .ARESETB(ARESETB), .ACLK(ACLK), .TRP(trp), .TRRD({1'b0, 1'b1}), .TRCD(trcd), .TRASMIN(trasmin), .BA_BA(BA_BA), .BA_RA(BA_RA), .BA_TT(BA_TT), 
        .BA_REQ(i_ba_req), .CAS_0_BA(cas_0_ba), .CAS_0_RA(cas_0_ra), 
        .CAS_0_TT(cas_0_tt), .CAS_0_FINAL(cas_0_final), .CAS_0_NEWROW(
        cas_0_newrow), .CAS_EMPTY(cas_empty), .LAST_RA(b2_last_ra), .RAS_0_BA(
        ras_0_ba), .RAS_0_RA(ras_0_ra), .RAS_0_TT(ras_0_tt), .RAS_EMPTY(
        ras_empty), .BF_NO({1'b1, 1'b0}), .BF_CASBUSY(bf_2casbusy), 
        .BF_TCASBUSY(n8510), .BF_RASBUSY(bf_2rasbusy), .BF_TRASBUSY(
        bf_trasbusy), .BF_READY(bf_2ready), .BF_TREADY(bf_tready), .BF_IDLE(
        bf_2idle), .BF_LAST(bf_2last), .BF_REQCMD(bf_2reqcmd), .BF_CMD(bf_2cmd), .ERCMD({ercmd[5:3], n9447, ercmd[1:0]}), .ECMD({ecmd_6_, n8204, ecmd_4_, 
        ecmd_3_, ecmd_2_, ecmd_1_, ecmd_0_}) );
  SDRBsm_0 B3SM ( .ARESETB(ARESETB), .ACLK(ACLK), .TRP(trp), .TRRD({1'b0, 1'b1}), .TRCD(trcd), .TRASMIN(trasmin), .BA_BA(BA_BA), .BA_RA(BA_RA), .BA_TT(BA_TT), 
        .BA_REQ(i_ba_req), .CAS_0_BA(cas_0_ba), .CAS_0_RA(cas_0_ra), 
        .CAS_0_TT(cas_0_tt), .CAS_0_FINAL(cas_0_final), .CAS_0_NEWROW(
        cas_0_newrow), .CAS_EMPTY(cas_empty), .LAST_RA(b3_last_ra), .RAS_0_BA(
        ras_0_ba), .RAS_0_RA(ras_0_ra), .RAS_0_TT(ras_0_tt), .RAS_EMPTY(
        ras_empty), .BF_NO({1'b1, 1'b1}), .BF_CASBUSY(bf_3casbusy), 
        .BF_TCASBUSY(n8510), .BF_RASBUSY(bf_3rasbusy), .BF_TRASBUSY(
        bf_trasbusy), .BF_READY(bf_3ready), .BF_TREADY(bf_tready), .BF_IDLE(
        bf_3idle), .BF_LAST(bf_3last), .BF_REQCMD(bf_3reqcmd), .BF_CMD(bf_3cmd), .ERCMD({ercmd[5:3], n9447, ercmd[1:0]}), .ECMD({ecmd_6_, n8204, ecmd_4_, 
        ecmd_3_, ecmd_2_, ecmd_1_, ecmd_0_}) );
  SDRCas CasQ ( .ARESETB(ARESETB), .ACLK(ACLK), .BA_BA(BA_BA), .BA_RA(BA_RA), 
        .BA_CA(BA_CA), .BA_TT(BA_TT), .BA_ID(BA_ID), .BA_RW(BA_RW), .BA_REQ(
        i_ba_req), .BA_PM(BA_PM), .CMD({n8204, ecmd_4_, ecmd_3_, ecmd_2_, 
        ecmd_1_, ecmd_0_}), .B0_LAST_RA(b0_last_ra), .B1_LAST_RA(b1_last_ra), 
        .B2_LAST_RA(b2_last_ra), .B3_LAST_RA(b3_last_ra), .CAS_0_BA(cas_0_ba), 
        .CAS_0_RA(cas_0_ra), .CAS_0_CA(cas_0_ca), .CAS_0_TT(cas_0_tt), 
        .CAS_0_ID(cas_0_id), .CAS_0_RW(cas_0_rw), .CAS_0_PM(cas_0_pm), 
        .CAS_0_FINAL(cas_0_final), .CAS_0_NEWROW(cas_0_newrow), .CAS_EMPTY(
        cas_empty), .CAS_FULL(cas_full) );
  SDRRas RasQ ( .ARESETB(ARESETB), .ACLK(ACLK), .BA_BA(BA_BA), .BA_RA(BA_RA), 
        .BA_TT(BA_TT), .BA_REQ(i_ba_req), .CMD({n8204, ecmd_4_, ecmd_3_, 
        ecmd_2_, ecmd_1_, ecmd_0_}), .CLOSING(closing), .B0_LAST_RA(b0_last_ra), .B1_LAST_RA(b1_last_ra), .B2_LAST_RA(b2_last_ra), .B3_LAST_RA(b3_last_ra), 
        .RAS_0_BA(ras_0_ba), .RAS_0_RA(ras_0_ra), .RAS_0_TT(ras_0_tt), 
        .RAS_EMPTY(ras_empty), .RAS_FULL(ras_full) );
  NOR2BX4 U4421 ( .AN(n9064), .B(n9065), .Y(ecmd_0_) );
  NAND4BX4 U4706 ( .AN(bf_3reqcmd[0]), .B(n9089), .C(n9102), .D(n9088), .Y(
        n8675) );
  AO21X4 U4803 ( .A0(BA_STS[14]), .A1(n9275), .B0(n9276), .Y(BA_BA[1]) );
  OA21X4 U4814 ( .A0(n9285), .A1(n9286), .B0(BA_STS[14]), .Y(n9284) );
  AO22X2 U4849 ( .A0(BA_STS[14]), .A1(n9239), .B0(n9240), .B1(n9309), .Y(
        BA_RA[12]) );
  INVX3 U4850 ( .A(n9061), .Y(ecmd_1_) );
  OAI31X1 U4851 ( .A0(n9057), .A1(n8660), .A2(n8914), .B0(n9167), .Y(n9295) );
  OAI31X2 U4852 ( .A0(n9057), .A1(n8660), .A2(n8914), .B0(n9167), .Y(n9296) );
  OAI31X1 U4853 ( .A0(n9057), .A1(n8660), .A2(n8914), .B0(n9167), .Y(n9060) );
  AOI221X4 U4854 ( .A0(ras_0_ra[10]), .A1(n9441), .B0(cas_0_ca[10]), .B1(n8606), .C0(closing), .Y(n8655) );
  AOI221X4 U4855 ( .A0(ras_0_ra[2]), .A1(n9441), .B0(cas_0_ca[2]), .B1(n8606), 
        .C0(n8635), .Y(n8637) );
  AOI221X4 U4856 ( .A0(ras_0_ra[6]), .A1(n9441), .B0(cas_0_ca[6]), .B1(n8606), 
        .C0(n8644), .Y(n8643) );
  AOI221X4 U4857 ( .A0(ras_0_ra[0]), .A1(n9441), .B0(cas_0_ca[0]), .B1(n8606), 
        .C0(n8635), .Y(n8633) );
  AOI221X4 U4858 ( .A0(ras_0_ra[1]), .A1(n9441), .B0(cas_0_ca[1]), .B1(n8606), 
        .C0(n8635), .Y(n8636) );
  AOI32X4 U4859 ( .A0(n8885), .A1(n8883), .A2(ecmd_2_), .B0(cas_0_ba[1]), .B1(
        n8606), .Y(n8890) );
  AOI222X4 U4860 ( .A0(ras_0_ra[4]), .A1(n9441), .B0(n8635), .B1(n9323), .C0(
        cas_0_ca[4]), .C1(n8606), .Y(n8639) );
  AOI222X4 U4861 ( .A0(ras_0_ra[5]), .A1(n9441), .B0(n8635), .B1(n8642), .C0(
        cas_0_ca[5]), .C1(n8606), .Y(n8641) );
  AO22X2 U4862 ( .A0(n9054), .A1(n8510), .B0(n8606), .B1(cas_0_rw), .Y(
        BA_STS[0]) );
  INVX1 U4863 ( .A(bf_0reqcmd[5]), .Y(n9187) );
  INVX1 U4864 ( .A(n8659), .Y(n8934) );
  NAND3BX2 U4865 ( .AN(n9289), .B(n9290), .C(n9291), .Y(n9275) );
  INVX3 U4866 ( .A(n8675), .Y(n9065) );
  INVX3 U4867 ( .A(n9103), .Y(n9064) );
  NAND2BX1 U4868 ( .AN(n9104), .B(n9295), .Y(n9103) );
  INVX3 U4869 ( .A(bf_0reqcmd[2]), .Y(n9095) );
  INVX1 U4870 ( .A(bf_2reqcmd[2]), .Y(n9082) );
  NAND2BX2 U4871 ( .AN(n8675), .B(n9064), .Y(n9062) );
  NAND4BX2 U4872 ( .AN(bf_3reqcmd[1]), .B(n9085), .C(n9097), .D(n9084), .Y(
        n9063) );
  INVX3 U4873 ( .A(bf_2reqcmd[0]), .Y(n9089) );
  INVX3 U4874 ( .A(bf_1reqcmd[0]), .Y(n9088) );
  INVX3 U4875 ( .A(bf_0reqcmd[0]), .Y(n9102) );
  NAND4X1 U4876 ( .A(n9187), .B(n9188), .C(n8887), .D(n9189), .Y(n9401) );
  INVX3 U4877 ( .A(n9099), .Y(n9185) );
  NOR3BX1 U4878 ( .AN(bf_2reqcmd[2]), .B(n9093), .C(bf_1reqcmd[2]), .Y(
        bf_2cmd[2]) );
  NAND2BX1 U4879 ( .AN(n9058), .B(n9059), .Y(n8896) );
  NAND2BX1 U4880 ( .AN(n9062), .B(n9063), .Y(n9061) );
  OAI31X1 U4881 ( .A0(n9049), .A1(n8914), .A2(n8660), .B0(n9050), .Y(ecmd_6_)
         );
  AO22X1 U4882 ( .A0(n9197), .A1(n9309), .B0(BA_STS[14]), .B1(n9198), .Y(
        BA_RA[9]) );
  AO22X1 U4883 ( .A0(BA_STS[14]), .A1(n9199), .B0(n9198), .B1(n9309), .Y(
        BA_RA[8]) );
  AO22X1 U4884 ( .A0(BA_STS[14]), .A1(n9211), .B0(n9199), .B1(n9309), .Y(
        BA_RA[7]) );
  AO22X1 U4885 ( .A0(BA_STS[14]), .A1(n9227), .B0(n9223), .B1(n9309), .Y(
        BA_RA[3]) );
  AO22X1 U4886 ( .A0(n9235), .A1(n9309), .B0(BA_STS[14]), .B1(n9257), .Y(
        BA_RA[0]) );
  AND4X1 U4887 ( .A(bf_3ready), .B(bf_2ready), .C(bf_1ready), .D(bf_0ready), 
        .Y(bf_tready) );
  OA21X2 U4888 ( .A0(n9277), .A1(n9278), .B0(n9309), .Y(n9276) );
  INVX1 U4889 ( .A(n9072), .Y(ecmd_4_) );
  INVX1 U4890 ( .A(n8684), .Y(ecmd_2_) );
  INVX1 U4891 ( .A(n9281), .Y(n9297) );
  DFFSX1 ercmd_reg_0_ ( .D(n8156), .CK(ACLK), .SN(ARESETB), .Q(ercmd[0]), .QN(
        n9321) );
  DFFRX1 ercmd_reg_3_ ( .D(n8153), .CK(ACLK), .RN(ARESETB), .Q(ercmd[3]), .QN(
        n9322) );
  DFFRX1 ercmd_reg_1_ ( .D(n8155), .CK(ACLK), .RN(ARESETB), .Q(ercmd[1]), .QN(
        n9352) );
  NOR4X1 U4892 ( .A(PENABLE), .B(PADDR[7]), .C(PADDR[6]), .D(n9160), .Y(n9355)
         );
  AOI22X1 U4893 ( .A0(stable_cnt[1]), .A1(n8789), .B0(n9016), .B1(n9356), .Y(
        n9366) );
  DFFRX1 ercmd_reg_4_ ( .D(n8152), .CK(ACLK), .RN(ARESETB), .Q(ercmd[4]), .QN(
        n9369) );
  DFFRX1 SD_CKE_reg ( .D(iSD_CKE), .CK(ACLK), .RN(PORESETB), .Q(SD_CKE) );
  DFFSX1 SD_WEB_reg ( .D(iSD_WEB), .CK(ACLK), .SN(PORESETB), .Q(SD_WEB) );
  DFFSX1 SD_CASB_reg ( .D(iSD_CASB), .CK(ACLK), .SN(PORESETB), .Q(SD_CASB) );
  DFFSX1 SD_RASB_reg ( .D(iSD_RASB), .CK(ACLK), .SN(PORESETB), .Q(SD_RASB) );
  DFFSX1 SD_CSB_reg ( .D(iSD_CSB), .CK(ACLK), .SN(PORESETB), .Q(SD_CSB) );
  DFFRX1 do_valid_1_reg ( .D(do_valid_0), .CK(ACLK), .RN(ARESETB), .Q(
        do_valid_1) );
  DFFRX1 SD_BADDR_reg_0_ ( .D(iSD_BADDR[0]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_BADDR[0]) );
  DFFRX1 SD_BADDR_reg_1_ ( .D(iSD_BADDR[1]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_BADDR[1]) );
  DFFRX1 SD_ADDR_reg_0_ ( .D(iSD_ADDR[0]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[0]) );
  DFFRX1 SD_ADDR_reg_1_ ( .D(iSD_ADDR[1]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[1]) );
  DFFRX1 SD_ADDR_reg_2_ ( .D(iSD_ADDR[2]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[2]) );
  DFFRX1 SD_ADDR_reg_3_ ( .D(iSD_ADDR[3]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[3]) );
  DFFRX1 SD_ADDR_reg_4_ ( .D(iSD_ADDR[4]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[4]) );
  DFFRX1 SD_ADDR_reg_5_ ( .D(iSD_ADDR[5]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[5]) );
  DFFRX1 SD_ADDR_reg_6_ ( .D(iSD_ADDR[6]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[6]) );
  DFFRX1 SD_ADDR_reg_7_ ( .D(iSD_ADDR[7]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[7]) );
  DFFRX1 SD_ADDR_reg_8_ ( .D(iSD_ADDR[8]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[8]) );
  DFFRX1 SD_ADDR_reg_9_ ( .D(iSD_ADDR[9]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[9]) );
  DFFRX1 SD_ADDR_reg_10_ ( .D(iSD_ADDR[10]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[10]) );
  DFFRX1 SD_ADDR_reg_11_ ( .D(iSD_ADDR[11]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[11]) );
  DFFRX1 SD_ADDR_reg_12_ ( .D(iSD_ADDR[12]), .CK(ACLK), .RN(PORESETB), .Q(
        SD_ADDR[12]) );
  DFFRX1 do_id_1_reg_0_ ( .D(do_id_0[0]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_1[0]) );
  DFFRX1 do_id_1_reg_1_ ( .D(do_id_0[1]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_1[1]) );
  DFFRX1 do_id_1_reg_2_ ( .D(do_id_0[2]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_1[2]) );
  DFFRX1 do_id_1_reg_3_ ( .D(do_id_0[3]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_1[3]) );
  INVX3 U4894 ( .A(BA_AA[24]), .Y(n9242) );
  NAND3X1 U4895 ( .A(n9397), .B(n9398), .C(n9293), .Y(n9289) );
  OR2X1 U4896 ( .A(n9265), .B(n9270), .Y(n9398) );
  OR2X1 U4897 ( .A(n9281), .B(n9268), .Y(n9397) );
  INVX2 U4898 ( .A(BA_AA[23]), .Y(n9281) );
  INVX1 U4899 ( .A(BA_AA[9]), .Y(n9265) );
  OA22X1 U4900 ( .A0(n9241), .A1(n9238), .B0(n9242), .B1(n9271), .Y(n9293) );
  NAND3BX1 U4901 ( .AN(BA_STS[16]), .B(AddrSwapEn), .C(BA_STS[15]), .Y(n9270)
         );
  INVX1 U4902 ( .A(bf_2reqcmd[4]), .Y(n8888) );
  INVX1 U4903 ( .A(n8915), .Y(n9055) );
  OA22X4 U4904 ( .A0(n9241), .A1(n9265), .B0(n9281), .B1(n9271), .Y(n9288) );
  OR4X2 U4905 ( .A(bf_1rasbusy), .B(bf_0rasbusy), .C(bf_3rasbusy), .D(
        bf_2rasbusy), .Y(bf_trasbusy) );
  AOI211X2 U4906 ( .A0(n8674), .A1(n9063), .B0(n8935), .C0(n9181), .Y(n9180)
         );
  OAI221X2 U4907 ( .A0(n9259), .A1(n9267), .B0(n9280), .B1(n9238), .C0(n9288), 
        .Y(n9285) );
  OA22X4 U4908 ( .A0(n9258), .A1(n9248), .B0(n9283), .B1(n9271), .Y(n9282) );
  AO22X1 U4909 ( .A0(BA_STS[14]), .A1(n9247), .B0(n9239), .B1(n9309), .Y(
        BA_RA[11]) );
  INVX3 U4910 ( .A(n9169), .Y(n8918) );
  INVX1 U4911 ( .A(n8656), .Y(n8606) );
  OAI2BB1X1 U4912 ( .A0N(n8674), .A1N(n8675), .B0(n8672), .Y(n9169) );
  INVX1 U4913 ( .A(n9186), .Y(n9094) );
  AOI222X1 U4914 ( .A0(BA_AA[23]), .A1(n9204), .B0(n9205), .B1(BA_AA[18]), 
        .C0(BA_AA[22]), .C1(n9206), .Y(n9256) );
  INVX1 U4915 ( .A(BA_AA[22]), .Y(n9248) );
  OAI221X1 U4916 ( .A0(n9248), .A1(n9268), .B0(n9272), .B1(n9270), .C0(n9403), 
        .Y(n9286) );
  INVX3 U4917 ( .A(n9092), .Y(n9059) );
  INVX3 U4918 ( .A(n8681), .Y(n8204) );
  INVX3 U4919 ( .A(bf_1reqcmd[2]), .Y(n9081) );
  AND4X1 U4920 ( .A(n9081), .B(n9082), .C(bf_3reqcmd[2]), .D(n9083), .Y(
        bf_3cmd[2]) );
  NOR2X2 U4921 ( .A(n9063), .B(n9400), .Y(n9399) );
  NAND4X2 U4922 ( .A(n9095), .B(n9081), .C(n9082), .D(n9194), .Y(n9400) );
  AO22X1 U4923 ( .A0(BA_STS[14]), .A1(n9215), .B0(n9211), .B1(n9309), .Y(
        BA_RA[6]) );
  INVX2 U4924 ( .A(n8922), .Y(n9181) );
  OAI211X2 U4925 ( .A0(n9058), .A1(n9104), .B0(n8918), .C0(n9180), .Y(n8916)
         );
  AO22X1 U4926 ( .A0(BA_STS[14]), .A1(n9235), .B0(n9231), .B1(n9309), .Y(
        BA_RA[1]) );
  AO22X1 U4927 ( .A0(BA_STS[14]), .A1(n9223), .B0(n9219), .B1(n9309), .Y(
        BA_RA[4]) );
  AO22X1 U4928 ( .A0(BA_STS[14]), .A1(n9219), .B0(n9215), .B1(n9309), .Y(
        BA_RA[5]) );
  AO21X4 U4929 ( .A0(n9275), .A1(n9309), .B0(n9284), .Y(BA_BA[0]) );
  AO22X1 U4930 ( .A0(BA_STS[14]), .A1(n9231), .B0(n9227), .B1(n9309), .Y(
        BA_RA[2]) );
  AND2X2 U4931 ( .A(n8756), .B(n8802), .Y(n8800) );
  OR3X1 U4932 ( .A(n8926), .B(n8930), .C(n8929), .Y(n8901) );
  BUFX2 U4933 ( .A(n8605), .Y(BA_STS[14]) );
  NOR2BX1 U4934 ( .AN(BA_REQ), .B(cmd_full_d), .Y(i_ba_req) );
  AND3X1 U4935 ( .A(n9425), .B(bf_2idle), .C(bf_3idle), .Y(n9424) );
  AND2X1 U4936 ( .A(bf_1idle), .B(bf_0idle), .Y(n9425) );
  INVX3 U4937 ( .A(n8896), .Y(ecmd_3_) );
  INVX1 U4938 ( .A(n8617), .Y(n8654) );
  NOR2BX1 U4939 ( .AN(n9083), .B(n9081), .Y(bf_1cmd[2]) );
  INVX4 U4940 ( .A(n8912), .Y(n8935) );
  NAND2BX1 U4941 ( .AN(ecmd_2_), .B(n8650), .Y(n8617) );
  INVX1 U4942 ( .A(n8834), .Y(n8814) );
  INVX1 U4943 ( .A(n9441), .Y(n8609) );
  INVX1 U4944 ( .A(n8885), .Y(n8884) );
  NOR3BX1 U4945 ( .AN(bf_2reqcmd[0]), .B(n9091), .C(bf_1reqcmd[0]), .Y(
        bf_2cmd[0]) );
  NOR3BX1 U4946 ( .AN(n9078), .B(bf_2reqcmd[4]), .C(n9079), .Y(bf_3cmd[4]) );
  NOR2BX1 U4947 ( .AN(bf_1reqcmd[0]), .B(n9091), .Y(bf_1cmd[0]) );
  NOR2BX1 U4948 ( .AN(n9078), .B(n8888), .Y(bf_2cmd[4]) );
  NAND3BX1 U4949 ( .AN(bf_3reqcmd[4]), .B(n8888), .C(n9078), .Y(n9077) );
  NOR2BX1 U4950 ( .AN(bf_3reqcmd[5]), .B(n9077), .Y(bf_3cmd[5]) );
  NOR2BX1 U4951 ( .AN(bf_2reqcmd[5]), .B(n9077), .Y(bf_2cmd[5]) );
  NOR2BX1 U4952 ( .AN(bf_1reqcmd[5]), .B(n9077), .Y(bf_1cmd[5]) );
  NOR2BX1 U4953 ( .AN(bf_0reqcmd[5]), .B(n9077), .Y(bf_0cmd[5]) );
  NAND2BX1 U4954 ( .AN(n8830), .B(n8826), .Y(n8834) );
  INVX1 U4955 ( .A(n9093), .Y(n9083) );
  OAI31X1 U4956 ( .A0(n9191), .A1(bf_1reqcmd[4]), .A2(bf_0reqcmd[4]), .B0(
        n9094), .Y(n8672) );
  NAND2BX1 U4957 ( .AN(bf_3reqcmd[4]), .B(n8888), .Y(n9191) );
  NAND4X4 U4958 ( .A(n9401), .B(n9079), .C(n8888), .D(n9185), .Y(n8912) );
  INVX1 U4959 ( .A(n9100), .Y(n9058) );
  INVX1 U4960 ( .A(bf_3reqcmd[4]), .Y(n9079) );
  INVX1 U4961 ( .A(bf_0reqcmd[4]), .Y(n8893) );
  INVX1 U4962 ( .A(bf_1reqcmd[4]), .Y(n8891) );
  AND4X1 U4963 ( .A(n9088), .B(n9089), .C(bf_3reqcmd[0]), .D(n9090), .Y(
        bf_3cmd[0]) );
  INVX1 U4964 ( .A(n9091), .Y(n9090) );
  INVX1 U4965 ( .A(bf_2reqcmd[5]), .Y(n8887) );
  INVX1 U4966 ( .A(bf_1reqcmd[5]), .Y(n9188) );
  INVX1 U4967 ( .A(bf_3reqcmd[5]), .Y(n9189) );
  INVX1 U4968 ( .A(n8895), .Y(n8650) );
  NAND2BX1 U4969 ( .AN(n9441), .B(n8656), .Y(n8895) );
  BUFX2 U4970 ( .A(n8634), .Y(n9441) );
  INVX1 U4971 ( .A(n8687), .Y(n8694) );
  INVX1 U4972 ( .A(n9246), .Y(n9207) );
  NAND4BX1 U4973 ( .AN(bf_0reqcmd[5]), .B(n8893), .C(bf_0reqcmd[2]), .D(n8894), 
        .Y(n8885) );
  NAND2BX1 U4974 ( .AN(n8830), .B(n8941), .Y(n8942) );
  NAND4BX1 U4975 ( .AN(bf_1reqcmd[5]), .B(n8891), .C(bf_1reqcmd[2]), .D(n8892), 
        .Y(n8883) );
  AND4X1 U4976 ( .A(n8886), .B(n8887), .C(bf_2reqcmd[2]), .D(n8888), .Y(n8882)
         );
  DFFRX1 do_valid_0_reg ( .D(do_valid_04685), .CK(ACLK), .RN(ARESETB), .Q(
        do_valid_0) );
  DFFSX1 iSD_CASB_reg ( .D(pttn5084_1_), .CK(ACLK), .SN(ARESETB), .Q(iSD_CASB)
         );
  DFFSX1 iSD_RASB_reg ( .D(pttn5084_2_), .CK(ACLK), .SN(ARESETB), .Q(iSD_RASB)
         );
  INVX1 U4977 ( .A(n9063), .Y(n9096) );
  NOR3BX1 U4978 ( .AN(bf_3reqcmd[3]), .B(n9080), .C(bf_2reqcmd[3]), .Y(
        bf_3cmd[3]) );
  NOR2BX1 U4979 ( .AN(bf_2reqcmd[3]), .B(n9080), .Y(bf_2cmd[3]) );
  NOR2BX1 U4980 ( .AN(n9064), .B(n9102), .Y(bf_0cmd[0]) );
  NAND2BX1 U4981 ( .AN(bf_0reqcmd[0]), .B(n9064), .Y(n9091) );
  NAND4BX1 U4982 ( .AN(bf_3reqcmd[3]), .B(n8886), .C(n8894), .D(n8892), .Y(
        n9100) );
  NAND3BX1 U4983 ( .AN(n8675), .B(n9182), .C(n8674), .Y(n8922) );
  AOI31X1 U4984 ( .A0(n9095), .A1(n9081), .A2(n9183), .B0(n9063), .Y(n9182) );
  NOR2BX1 U4985 ( .AN(n9082), .B(bf_3reqcmd[2]), .Y(n9183) );
  NAND2BX2 U4986 ( .AN(n8510), .B(n9053), .Y(n8659) );
  NAND3BX1 U4987 ( .AN(bf_1reqcmd[3]), .B(n8894), .C(n9059), .Y(n9080) );
  INVX1 U4988 ( .A(n9098), .Y(n9078) );
  INVX1 U4989 ( .A(bf_3reqcmd[2]), .Y(n9194) );
  INVX1 U4990 ( .A(n8809), .Y(n8826) );
  INVX1 U4991 ( .A(n8806), .Y(n8808) );
  INVX1 U4992 ( .A(bf_0reqcmd[3]), .Y(n8894) );
  INVX1 U4993 ( .A(bf_1reqcmd[3]), .Y(n8892) );
  INVX1 U4994 ( .A(bf_2reqcmd[3]), .Y(n8886) );
  NAND2BX1 U4995 ( .AN(n8932), .B(n8937), .Y(n8914) );
  OAI31X1 U4996 ( .A0(n8737), .A1(n8725), .A2(n8735), .B0(n9443), .Y(n8687) );
  INVX1 U4997 ( .A(n8733), .Y(n8706) );
  NAND3BX1 U4998 ( .AN(n8735), .B(n9440), .C(n8736), .Y(n8734) );
  INVX1 U4999 ( .A(n8689), .Y(n8695) );
  NAND4BX1 U5000 ( .AN(ecmd_2_), .B(n8608), .C(n8609), .D(n9404), .Y(
        pttn5084_1_) );
  INVX1 U5001 ( .A(closing), .Y(n8608) );
  NAND2BX1 U5002 ( .AN(n8606), .B(n9404), .Y(pttn5084_2_) );
  INVX1 U5003 ( .A(n8649), .Y(n8632) );
  NAND2BX1 U5004 ( .AN(n8635), .B(n8650), .Y(n8649) );
  INVX1 U5005 ( .A(n9443), .Y(n8692) );
  INVX1 U5006 ( .A(n8740), .Y(n8799) );
  DFFRX1 PRDATA_reg_12_ ( .D(PRDATA502_12_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[12]) );
  DFFRX1 PRDATA_reg_13_ ( .D(PRDATA502_13_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[13]) );
  DFFRX1 PRDATA_reg_23_ ( .D(PRDATA502_23_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[23]) );
  DFFRX1 PRDATA_reg_29_ ( .D(PRDATA502_29_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[29]) );
  DFFRX1 PRDATA_reg_30_ ( .D(PRDATA502_30_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[30]) );
  DFFRX1 PRDATA_reg_31_ ( .D(PRDATA502_31_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[31]) );
  INVX1 U5007 ( .A(n9280), .Y(n9204) );
  INVX1 U5008 ( .A(n8901), .Y(n8899) );
  INVX1 U5009 ( .A(n9245), .Y(n9200) );
  NAND2X1 U5010 ( .A(n9268), .B(n9267), .Y(n9246) );
  AO21X1 U5011 ( .A0(n8676), .A1(n8510), .B0(n8658), .Y(do_valid_04685) );
  INVX1 U5012 ( .A(n9432), .Y(n9262) );
  NAND2BX1 U5013 ( .AN(n8805), .B(n8735), .Y(n8802) );
  INVX1 U5014 ( .A(n8851), .Y(n8729) );
  OR2X1 U5015 ( .A(n8845), .B(n8847), .Y(n8830) );
  INVX1 U5016 ( .A(n9442), .Y(n8875) );
  INVX1 U5017 ( .A(n8945), .Y(n8941) );
  INVX1 U5018 ( .A(n8980), .Y(n8984) );
  INVX1 U5019 ( .A(n8790), .Y(n8804) );
  INVX1 U5020 ( .A(n8796), .Y(n8738) );
  INVX1 U5021 ( .A(n9023), .Y(n9024) );
  INVX1 U5022 ( .A(n8741), .Y(n8732) );
  INVX1 U5023 ( .A(n8745), .Y(n8737) );
  INVX1 U5024 ( .A(n8759), .Y(n8770) );
  INVX1 U5025 ( .A(n8976), .Y(n8985) );
  INVX1 U5026 ( .A(n9440), .Y(n8725) );
  INVX1 U5027 ( .A(n9439), .Y(n9021) );
  INVX1 U5028 ( .A(n9012), .Y(n9011) );
  INVX1 U5029 ( .A(n8731), .Y(n8856) );
  DFFRX1 iSD_CKE_reg ( .D(pSD_CKE), .CK(ACLK), .RN(ARESETB), .Q(iSD_CKE) );
  OAI211X1 U5030 ( .A0(n9241), .A1(n9242), .B0(n9403), .C0(n9244), .Y(n9240)
         );
  AOI222X1 U5031 ( .A0(n9297), .A1(n9245), .B0(BA_AA[22]), .B1(n9246), .C0(
        BA_AA[25]), .C1(n9204), .Y(n9244) );
  AO22X2 U5032 ( .A0(n9247), .A1(n9309), .B0(BA_STS[14]), .B1(n9197), .Y(
        BA_RA[10]) );
  NOR3BX1 U5033 ( .AN(bf_2reqcmd[1]), .B(n9087), .C(bf_1reqcmd[1]), .Y(
        bf_2cmd[1]) );
  AOI211X1 U5034 ( .A0(n9055), .A1(n8510), .B0(n9168), .C0(n8930), .Y(n9167)
         );
  AO21X1 U5035 ( .A0(n9051), .A1(n9171), .B0(n8932), .Y(n9168) );
  INVX1 U5036 ( .A(n8914), .Y(n9171) );
  NOR2BX1 U5037 ( .AN(bf_1reqcmd[1]), .B(n9087), .Y(bf_1cmd[1]) );
  OAI221X1 U5038 ( .A0(n9242), .A1(n9268), .B0(n9238), .B1(n9270), .C0(n9405), 
        .Y(n9278) );
  OAI221X1 U5039 ( .A0(n9265), .A1(n9267), .B0(n9432), .B1(n9281), .C0(n9282), 
        .Y(n9277) );
  NAND3BX1 U5040 ( .AN(n8806), .B(n9310), .C(n8841), .Y(n8809) );
  AO22X1 U5041 ( .A0(n8842), .A1(n8805), .B0(n8843), .B1(n8844), .Y(n8806) );
  AOI211X1 U5042 ( .A0(n8845), .A1(n8846), .B0(n8847), .C0(n8848), .Y(n8844)
         );
  OAI31X1 U5043 ( .A0(n8849), .A1(n9413), .A2(n8851), .B0(n8738), .Y(n8843) );
  INVX1 U5044 ( .A(n8842), .Y(n8848) );
  NOR4X1 U5045 ( .A(bf_1casbusy), .B(bf_0casbusy), .C(bf_3casbusy), .D(
        bf_2casbusy), .Y(n9402) );
  INVX1 U5046 ( .A(n9402), .Y(n8510) );
  NAND4BX2 U5047 ( .AN(n9104), .B(n9058), .C(n9065), .D(n9399), .Y(n9186) );
  AND4X1 U5048 ( .A(n9084), .B(n9085), .C(bf_3reqcmd[1]), .D(n9086), .Y(
        bf_3cmd[1]) );
  INVX1 U5049 ( .A(n9087), .Y(n9086) );
  OA22X1 U5050 ( .A0(n9258), .A1(n9251), .B0(n9280), .B1(n9234), .Y(n9291) );
  OA22X1 U5051 ( .A0(n9272), .A1(n9267), .B0(n9432), .B1(n9248), .Y(n9290) );
  AND4X1 U5052 ( .A(n9424), .B(BA_STS[2]), .C(n8736), .D(n8681), .Y(n8849) );
  INVX1 U5053 ( .A(BA_AA[25]), .Y(n9283) );
  OAI211X1 U5054 ( .A0(n9200), .A1(n9251), .B0(n9255), .C0(n9256), .Y(n9247)
         );
  OA22X1 U5055 ( .A0(n9207), .A1(n9252), .B0(n9201), .B1(n9432), .Y(n9255) );
  OAI211X1 U5056 ( .A0(n9200), .A1(n9248), .B0(n9249), .C0(n9250), .Y(n9239)
         );
  OA22X1 U5057 ( .A0(n9207), .A1(n9251), .B0(n9432), .B1(n9252), .Y(n9249) );
  OAI211X1 U5058 ( .A0(n9200), .A1(n9208), .B0(n9212), .C0(n9213), .Y(n9199)
         );
  OA22X1 U5059 ( .A0(n9207), .A1(n9210), .B0(n9432), .B1(n9214), .Y(n9212) );
  AOI222X1 U5060 ( .A0(BA_AA[20]), .A1(n9204), .B0(BA_AA[15]), .B1(n9205), 
        .C0(n9206), .C1(BA_AA[19]), .Y(n9213) );
  OAI211X1 U5061 ( .A0(n9200), .A1(n9210), .B0(n9216), .C0(n9217), .Y(n9211)
         );
  OA22X1 U5062 ( .A0(n9207), .A1(n9214), .B0(n9432), .B1(n9218), .Y(n9216) );
  AOI222X1 U5063 ( .A0(n9204), .A1(BA_AA[19]), .B0(BA_AA[14]), .B1(n9205), 
        .C0(n9206), .C1(BA_AA[18]), .Y(n9217) );
  OAI211X1 U5064 ( .A0(n9200), .A1(n9214), .B0(n9220), .C0(n9221), .Y(n9215)
         );
  OA22X1 U5065 ( .A0(n9207), .A1(n9218), .B0(n9432), .B1(n9222), .Y(n9220) );
  AOI222X1 U5066 ( .A0(n9204), .A1(BA_AA[18]), .B0(BA_AA[13]), .B1(n9205), 
        .C0(n9206), .C1(BA_AA[17]), .Y(n9221) );
  OAI211X1 U5067 ( .A0(n9200), .A1(n9218), .B0(n9224), .C0(n9225), .Y(n9219)
         );
  OA22X1 U5068 ( .A0(n9207), .A1(n9222), .B0(n9432), .B1(n9226), .Y(n9224) );
  AOI222X1 U5069 ( .A0(n9204), .A1(BA_AA[17]), .B0(BA_AA[12]), .B1(n9205), 
        .C0(n9206), .C1(BA_AA[16]), .Y(n9225) );
  OAI211X1 U5070 ( .A0(n9200), .A1(n9222), .B0(n9228), .C0(n9229), .Y(n9223)
         );
  OA22X1 U5071 ( .A0(n9207), .A1(n9226), .B0(n9432), .B1(n9230), .Y(n9228) );
  AOI222X1 U5072 ( .A0(n9204), .A1(BA_AA[16]), .B0(BA_AA[11]), .B1(n9205), 
        .C0(BA_AA[15]), .C1(n9206), .Y(n9229) );
  OAI211X1 U5073 ( .A0(n9200), .A1(n9226), .B0(n9232), .C0(n9233), .Y(n9227)
         );
  OA22X1 U5074 ( .A0(n9207), .A1(n9230), .B0(n9432), .B1(n9234), .Y(n9232) );
  AOI222X1 U5075 ( .A0(BA_AA[15]), .A1(n9204), .B0(BA_AA[10]), .B1(n9205), 
        .C0(BA_AA[14]), .C1(n9206), .Y(n9233) );
  OAI211X1 U5076 ( .A0(n9200), .A1(n9201), .B0(n9202), .C0(n9203), .Y(n9198)
         );
  OA22X1 U5077 ( .A0(n9207), .A1(n9208), .B0(n9432), .B1(n9210), .Y(n9202) );
  AOI222X1 U5078 ( .A0(BA_AA[21]), .A1(n9204), .B0(BA_AA[16]), .B1(n9205), 
        .C0(BA_AA[20]), .C1(n9206), .Y(n9203) );
  DFFRX1 do_valid_reg ( .D(do_valid4691), .CK(ACLK), .RN(ARESETB), .Q(
        BA_STS[1]) );
  OAI211X1 U5079 ( .A0(n9200), .A1(n9252), .B0(n9253), .C0(n9254), .Y(n9197)
         );
  OA22X1 U5080 ( .A0(n9207), .A1(n9201), .B0(n9208), .B1(n9432), .Y(n9253) );
  AOI222X1 U5081 ( .A0(BA_AA[22]), .A1(n9204), .B0(n9205), .B1(BA_AA[17]), 
        .C0(n9206), .C1(BA_AA[21]), .Y(n9254) );
  OAI31X1 U5082 ( .A0(n8811), .A1(n8812), .A2(n8773), .B0(n8813), .Y(n8154) );
  AOI31X1 U5083 ( .A0(n9448), .A1(n8729), .A2(n8814), .B0(n8815), .Y(n8813) );
  OAI31X1 U5084 ( .A0(n8809), .A1(n8816), .A2(n8742), .B0(n8817), .Y(n8815) );
  INVX1 U5085 ( .A(n8819), .Y(n8816) );
  AOI32X1 U5086 ( .A0(n8818), .A1(n8789), .A2(n8808), .B0(n9447), .B1(n8806), 
        .Y(n8817) );
  INVX1 U5087 ( .A(n8803), .Y(n8818) );
  INVX1 U5088 ( .A(BA_AA[20]), .Y(n9252) );
  INVX1 U5089 ( .A(BA_AA[21]), .Y(n9251) );
  INVX1 U5090 ( .A(BA_AA[15]), .Y(n9218) );
  AOI22X1 U5091 ( .A0(BA_AA[20]), .A1(n9205), .B0(BA_AA[21]), .B1(n9262), .Y(
        n9403) );
  INVX1 U5092 ( .A(BA_AA[19]), .Y(n9201) );
  INVX1 U5093 ( .A(BA_AA[16]), .Y(n9214) );
  INVX1 U5094 ( .A(BA_AA[18]), .Y(n9208) );
  INVX1 U5095 ( .A(BA_AA[17]), .Y(n9210) );
  INVX1 U5096 ( .A(bf_1reqcmd[1]), .Y(n9084) );
  INVX1 U5097 ( .A(bf_2reqcmd[1]), .Y(n9085) );
  INVX1 U5098 ( .A(bf_0reqcmd[1]), .Y(n9097) );
  OAI211X1 U5099 ( .A0(n9258), .A1(n9259), .B0(n9405), .C0(n9261), .Y(n9257)
         );
  AOI222X1 U5100 ( .A0(BA_AA[10]), .A1(n9245), .B0(BA_AA[9]), .B1(n9246), .C0(
        BA_AA[8]), .C1(n9262), .Y(n9261) );
  NAND4BX1 U5101 ( .AN(n8725), .B(n8726), .C(n8727), .D(n9443), .Y(n8689) );
  OAI211X1 U5102 ( .A0(n8728), .A1(n8681), .B0(n8729), .C0(n8730), .Y(n8727)
         );
  NOR2BX1 U5103 ( .AN(n8731), .B(n8732), .Y(n8730) );
  NAND2BX1 U5104 ( .AN(n9447), .B(n9322), .Y(n8614) );
  OAI31X1 U5105 ( .A0(n8627), .A1(n8614), .A2(n9352), .B0(n8681), .Y(closing)
         );
  INVX1 U5106 ( .A(n9172), .Y(n8937) );
  NAND2BX1 U5107 ( .AN(n9406), .B(n8911), .Y(n9172) );
  OAI31X1 U5108 ( .A0(n8681), .A1(n8728), .A2(n8796), .B0(n8800), .Y(n8740) );
  OAI33X1 U5109 ( .A0(n8678), .A1(n8510), .A2(n8660), .B0(n8679), .B1(n8204), 
        .B2(n8680), .Y(n8182) );
  AO21X1 U5110 ( .A0(ecmd_2_), .A1(n8682), .B0(n9383), .Y(n8679) );
  NAND2BX1 U5111 ( .AN(ecmd_6_), .B(n8656), .Y(n8680) );
  NOR2BX1 U5112 ( .AN(n8806), .B(n9321), .Y(n8156) );
  INVX1 U5113 ( .A(n9104), .Y(n8674) );
  INVX1 U5114 ( .A(BA_REQ), .Y(n9046) );
  BUFX2 U5115 ( .A(n8690), .Y(n9443) );
  AO21X1 U5116 ( .A0(n8738), .A1(n8739), .B0(n8740), .Y(n8690) );
  OAI211X1 U5117 ( .A0(n8741), .A1(n8742), .B0(n8743), .C0(n8744), .Y(n8739)
         );
  OA21X2 U5118 ( .A0(n8745), .A1(n8746), .B0(n9417), .Y(n8744) );
  OAI211X1 U5119 ( .A0(n9200), .A1(n9234), .B0(n9263), .C0(n9264), .Y(n9235)
         );
  OA22X1 U5120 ( .A0(n9207), .A1(n9238), .B0(n9432), .B1(n9265), .Y(n9263) );
  AOI222X1 U5121 ( .A0(BA_AA[13]), .A1(n9204), .B0(BA_AA[8]), .B1(n9205), .C0(
        BA_AA[12]), .C1(n9206), .Y(n9264) );
  OAI211X1 U5122 ( .A0(n9200), .A1(n9230), .B0(n9236), .C0(n9237), .Y(n9231)
         );
  OA22X1 U5123 ( .A0(n9207), .A1(n9234), .B0(n9432), .B1(n9238), .Y(n9236) );
  AOI222X1 U5124 ( .A0(BA_AA[14]), .A1(n9204), .B0(BA_AA[9]), .B1(n9205), .C0(
        BA_AA[13]), .C1(n9206), .Y(n9237) );
  INVX1 U5125 ( .A(BA_AA[10]), .Y(n9238) );
  INVX1 U5126 ( .A(BA_AA[11]), .Y(n9234) );
  OAI222X1 U5127 ( .A0(n9310), .A1(n8806), .B0(n8808), .B1(n9352), .C0(n8809), 
        .C1(n8810), .Y(n8155) );
  INVX1 U5128 ( .A(ecmd_6_), .Y(n8620) );
  INVX1 U5129 ( .A(n8909), .Y(n9179) );
  INVX1 U5130 ( .A(n8936), .Y(n9051) );
  INVX1 U5131 ( .A(n9178), .Y(n9074) );
  AOI21X1 U5132 ( .A0(n8611), .A1(ecmd_6_), .B0(pttn5084_3_), .Y(n9404) );
  INVX1 U5133 ( .A(n8642), .Y(n8906) );
  INVX1 U5134 ( .A(n8795), .Y(n8778) );
  OAI211X1 U5135 ( .A0(n8796), .A1(n8797), .B0(n8798), .C0(n8799), .Y(n8795)
         );
  OA22X1 U5136 ( .A0(n8754), .A1(n8803), .B0(n8804), .B1(n8805), .Y(n8798) );
  NAND2BX1 U5137 ( .AN(n9448), .B(n8732), .Y(n8797) );
  INVX1 U5138 ( .A(BA_AA[12]), .Y(n9230) );
  INVX1 U5139 ( .A(BA_AA[8]), .Y(n9272) );
  INVX1 U5140 ( .A(BA_AA[7]), .Y(n9259) );
  INVX1 U5141 ( .A(BA_AA[14]), .Y(n9222) );
  INVX1 U5142 ( .A(BA_AA[13]), .Y(n9226) );
  AOI22X1 U5143 ( .A0(BA_AA[11]), .A1(n9206), .B0(BA_AA[12]), .B1(n9204), .Y(
        n9405) );
  OAI222X1 U5144 ( .A0(n8918), .A1(n8931), .B0(n8918), .B1(n8670), .C0(n8932), 
        .C1(n8933), .Y(n8926) );
  NAND3BX1 U5145 ( .AN(n9325), .B(BA_STS[15]), .C(BA_STS[16]), .Y(n9280) );
  NAND3BX1 U5146 ( .AN(BA_STS[15]), .B(n9325), .C(BA_STS[16]), .Y(n9268) );
  NAND2X1 U5147 ( .A(n9271), .B(n9270), .Y(n9245) );
  OAI221X1 U5148 ( .A0(n8918), .A1(n8936), .B0(n8918), .B1(n8937), .C0(n8931), 
        .Y(n8907) );
  NAND2BX1 U5149 ( .AN(n9325), .B(n9273), .Y(n9267) );
  NAND3BX1 U5150 ( .AN(n8953), .B(n8726), .C(n8804), .Y(n8847) );
  NAND3BX1 U5151 ( .AN(n8828), .B(n8954), .C(n8810), .Y(n8953) );
  DFFRX1 PRDATA_reg_0_ ( .D(PRDATA502_0_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[0]) );
  DFFRX1 PRDATA_reg_1_ ( .D(PRDATA502_1_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[1]) );
  DFFRX1 PRDATA_reg_2_ ( .D(PRDATA502_2_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[2]) );
  DFFRX1 PRDATA_reg_3_ ( .D(PRDATA502_3_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[3]) );
  DFFRX1 PRDATA_reg_4_ ( .D(PRDATA502_4_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[4]) );
  DFFRX1 PRDATA_reg_5_ ( .D(PRDATA502_5_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[5]) );
  DFFRX1 PRDATA_reg_6_ ( .D(PRDATA502_6_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[6]) );
  DFFRX1 PRDATA_reg_7_ ( .D(PRDATA502_7_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[7]) );
  DFFRX1 PRDATA_reg_8_ ( .D(PRDATA502_8_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[8]) );
  DFFRX1 PRDATA_reg_9_ ( .D(PRDATA502_9_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[9]) );
  DFFRX1 PRDATA_reg_10_ ( .D(PRDATA502_10_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[10]) );
  DFFRX1 PRDATA_reg_11_ ( .D(PRDATA502_11_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[11]) );
  DFFRX1 PRDATA_reg_14_ ( .D(PRDATA502_14_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[14]) );
  DFFRX1 PRDATA_reg_15_ ( .D(PRDATA502_15_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[15]) );
  DFFRX1 PRDATA_reg_16_ ( .D(PRDATA502_16_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[16]) );
  DFFRX1 PRDATA_reg_17_ ( .D(PRDATA502_17_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[17]) );
  DFFRX1 PRDATA_reg_18_ ( .D(PRDATA502_18_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[18]) );
  DFFRX1 PRDATA_reg_19_ ( .D(PRDATA502_19_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[19]) );
  DFFRX1 PRDATA_reg_20_ ( .D(PRDATA502_20_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[20]) );
  DFFRX1 PRDATA_reg_21_ ( .D(PRDATA502_21_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[21]) );
  DFFRX1 PRDATA_reg_22_ ( .D(PRDATA502_22_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[22]) );
  DFFRX1 PRDATA_reg_24_ ( .D(PRDATA502_24_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[24]) );
  DFFRX1 PRDATA_reg_25_ ( .D(PRDATA502_25_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[25]) );
  DFFRX1 PRDATA_reg_26_ ( .D(PRDATA502_26_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[26]) );
  DFFRX1 PRDATA_reg_27_ ( .D(PRDATA502_27_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[27]) );
  DFFRX1 PRDATA_reg_28_ ( .D(PRDATA502_28_), .CK(PCLK), .RN(PRESETB), .Q(
        PRDATA[28]) );
  BUFX2 U5152 ( .A(n9209), .Y(n9432) );
  NAND3BX1 U5153 ( .AN(BA_STS[16]), .B(n9325), .C(BA_STS[15]), .Y(n9209) );
  INVX1 U5154 ( .A(n9241), .Y(n9206) );
  INVX1 U5155 ( .A(n8931), .Y(n8932) );
  INVX1 U5156 ( .A(n8629), .Y(n8658) );
  INVX1 U5157 ( .A(n9258), .Y(n9205) );
  INVX1 U5158 ( .A(n8911), .Y(n9054) );
  AO22X1 U5159 ( .A0(ecmd_4_), .A1(n8670), .B0(n8676), .B1(n9071), .Y(
        bf_last_04967) );
  OR4X1 U5160 ( .A(bf_1last), .B(bf_0last), .C(bf_3last), .D(bf_2last), .Y(
        n9071) );
  OAI222X1 U5161 ( .A0(n8676), .A1(n9365), .B0(n8676), .B1(n9326), .C0(n8918), 
        .C1(n8660), .Y(n8920) );
  INVX1 U5162 ( .A(n9292), .Y(n9273) );
  NAND2BX1 U5163 ( .AN(BA_STS[16]), .B(n9327), .Y(n9292) );
  AOI211X1 U5164 ( .A0(n8660), .A1(n8911), .B0(n8934), .C0(n8935), .Y(n8933)
         );
  INVX1 U5165 ( .A(n8908), .Y(n8900) );
  DFFSX1 selfref_cnt_reg_2_ ( .D(n8100), .CK(ACLK), .SN(ARESETB), .Q(n8503), 
        .QN(n9357) );
  NOR3BX1 U5166 ( .AN(BA_STS[15]), .B(n9274), .C(n9339), .Y(BA_CA[10]) );
  OA22X1 U5167 ( .A0(BA_STS[14]), .A1(n9238), .B0(n9309), .B1(n9265), .Y(n9274) );
  NAND3BX1 U5168 ( .AN(n8991), .B(n9440), .C(n8746), .Y(n8980) );
  NAND2BX1 U5169 ( .AN(n8754), .B(n8841), .Y(n8805) );
  NAND3BX1 U5170 ( .AN(n8996), .B(n8997), .C(n8998), .Y(n8851) );
  AND4X1 U5171 ( .A(n9303), .B(n9313), .C(n9298), .D(n9360), .Y(n8997) );
  AND4X1 U5172 ( .A(n9363), .B(n9332), .C(n9314), .D(n9002), .Y(n8998) );
  OAI211X1 U5173 ( .A0(n9415), .A1(n9418), .B0(n9302), .C0(n9312), .Y(n8996)
         );
  NAND2BX1 U5174 ( .AN(n8862), .B(n8729), .Y(n8745) );
  OR2X1 U5175 ( .A(n8865), .B(n8805), .Y(n8796) );
  AO21X1 U5176 ( .A0(n8955), .A1(n8956), .B0(n8805), .Y(n8945) );
  AOI211X1 U5177 ( .A0(n8789), .A1(n8790), .B0(n8965), .C0(n8735), .Y(n8955)
         );
  INVX1 U5178 ( .A(n8829), .Y(n8956) );
  NAND3BX1 U5179 ( .AN(n8828), .B(n8865), .C(n8810), .Y(n8965) );
  NAND3BX1 U5180 ( .AN(n9158), .B(n8877), .C(n8878), .Y(n9106) );
  NAND2X1 U5181 ( .A(n8832), .B(n8831), .Y(n8790) );
  NAND2BX1 U5182 ( .AN(n9416), .B(n8729), .Y(n8741) );
  AO21X1 U5183 ( .A0(n8746), .A1(n9440), .B0(n8991), .Y(n8976) );
  OAI33X1 U5184 ( .A0(n9339), .A1(BA_STS[14]), .A2(n9265), .B0(n9309), .B1(
        n9272), .B2(n9339), .Y(BA_CA[9]) );
  OAI33X1 U5185 ( .A0(n9273), .A1(BA_STS[14]), .A2(n9272), .B0(n9309), .B1(
        n9273), .B2(n9259), .Y(BA_CA[8]) );
  OAI211X1 U5186 ( .A0(n8741), .A1(n8830), .B0(n8831), .C0(n8832), .Y(n8819)
         );
  INVX1 U5187 ( .A(n8868), .Y(n8869) );
  NAND2BX1 U5188 ( .AN(n9422), .B(n8968), .Y(n8810) );
  NOR2BX1 U5189 ( .AN(WQFull), .B(n9109), .Y(PRDATA502_29_) );
  BUFX2 U5190 ( .A(n8874), .Y(n9442) );
  NAND3BX1 U5191 ( .AN(n8876), .B(n8877), .C(n8878), .Y(n8874) );
  INVX1 U5192 ( .A(n9109), .Y(n9135) );
  INVX1 U5193 ( .A(n8872), .Y(n8873) );
  INVX1 U5194 ( .A(n8726), .Y(n8735) );
  BUFX2 U5195 ( .A(n8686), .Y(n9440) );
  NAND2BX1 U5196 ( .AN(n9310), .B(n8852), .Y(n8686) );
  INVX1 U5197 ( .A(n8660), .Y(n8676) );
  INVX1 U5198 ( .A(n9436), .Y(n8871) );
  NOR2BX1 U5199 ( .AN(RQFull), .B(n9431), .Y(PRDATA502_30_) );
  NOR2BX1 U5200 ( .AN(n8631), .B(n9433), .Y(PRDATA502_31_) );
  AND4X1 U5201 ( .A(n9362), .B(n9315), .C(n9304), .D(n9331), .Y(n9002) );
  INVX1 U5202 ( .A(n8728), .Y(n8736) );
  INVX1 U5203 ( .A(n8852), .Y(n8841) );
  OAI222X1 U5204 ( .A0(n9374), .A1(n9106), .B0(n9299), .B1(n9433), .C0(n9341), 
        .C1(n9434), .Y(PRDATA502_12_) );
  OAI222X1 U5205 ( .A0(n9373), .A1(n9106), .B0(n9307), .B1(n9433), .C0(n9340), 
        .C1(n9434), .Y(PRDATA502_13_) );
  AO22X1 U5206 ( .A0(n9135), .A1(BA_STS[3]), .B0(n9135), .B1(n8958), .Y(
        PRDATA502_23_) );
  INVX1 U5207 ( .A(n8958), .Y(BA_STS[2]) );
  OAI32X1 U5208 ( .A0(n8659), .A1(n8660), .A2(n8661), .B0(n8662), .B1(n9365), 
        .Y(n8184) );
  INVX1 U5209 ( .A(n8664), .Y(n8662) );
  OAI31X1 U5210 ( .A0(n8665), .A1(n8666), .A2(n9364), .B0(n8668), .Y(n8661) );
  INVX1 U5211 ( .A(n8669), .Y(n8665) );
  OAI2BB1X1 U5212 ( .A0N(n8845), .A1N(n8804), .B0(n8954), .Y(n8829) );
  INVX1 U5213 ( .A(n9130), .Y(n8974) );
  NAND2BX1 U5214 ( .AN(n9328), .B(n9419), .Y(n9130) );
  INVX1 U5215 ( .A(n8962), .Y(n8845) );
  NAND2BX1 U5216 ( .AN(n8963), .B(n9414), .Y(n8962) );
  INVX1 U5217 ( .A(n8978), .Y(n8991) );
  NOR2BX1 U5218 ( .AN(BA_AA[0]), .B(BA_STS[14]), .Y(BA_CA[0]) );
  INVX1 U5219 ( .A(n8775), .Y(n8771) );
  NAND3BX1 U5220 ( .AN(n8725), .B(n8773), .C(n8757), .Y(n8775) );
  NAND2BX1 U5221 ( .AN(n9418), .B(n8729), .Y(n8731) );
  NAND2BX1 U5222 ( .AN(n9439), .B(n9019), .Y(n9023) );
  AO22X1 U5223 ( .A0(BA_AA[7]), .A1(n9309), .B0(BA_AA[6]), .B1(BA_STS[14]), 
        .Y(BA_CA[7]) );
  AO22X1 U5224 ( .A0(BA_AA[6]), .A1(n9309), .B0(BA_AA[5]), .B1(BA_STS[14]), 
        .Y(BA_CA[6]) );
  AO22X1 U5225 ( .A0(BA_AA[5]), .A1(n9309), .B0(BA_AA[4]), .B1(BA_STS[14]), 
        .Y(BA_CA[5]) );
  AO22X1 U5226 ( .A0(BA_AA[4]), .A1(n9309), .B0(BA_AA[3]), .B1(BA_STS[14]), 
        .Y(BA_CA[4]) );
  AO22X1 U5227 ( .A0(BA_AA[3]), .A1(n9309), .B0(BA_AA[2]), .B1(BA_STS[14]), 
        .Y(BA_CA[3]) );
  AO22X1 U5228 ( .A0(BA_AA[2]), .A1(n9309), .B0(BA_AA[1]), .B1(BA_STS[14]), 
        .Y(BA_CA[2]) );
  AO22X1 U5229 ( .A0(BA_AA[1]), .A1(n9309), .B0(BA_AA[0]), .B1(BA_STS[14]), 
        .Y(BA_CA[1]) );
  AO21X1 U5230 ( .A0(n9013), .A1(n8821), .B0(n9368), .Y(n9012) );
  OA21X2 U5231 ( .A0(n9366), .A1(n9334), .B0(n9310), .Y(n9013) );
  AO21X1 U5232 ( .A0(n8773), .A1(n9440), .B0(n8774), .Y(n8759) );
  BUFX2 U5233 ( .A(n9027), .Y(n9439) );
  NAND4BX1 U5234 ( .AN(n8852), .B(n9310), .C(BA_STS[2]), .D(n9046), .Y(n9027)
         );
  NAND2BX1 U5235 ( .AN(n9368), .B(n8725), .Y(n8756) );
  INVX1 U5236 ( .A(n9019), .Y(n9026) );
  AND4X1 U5237 ( .A(n9307), .B(n9317), .C(n9300), .D(n9336), .Y(n9145) );
  INVX1 U5238 ( .A(n8773), .Y(n8822) );
  INVX1 U5239 ( .A(n8746), .Y(n8812) );
  NAND2BX1 U5240 ( .AN(n8938), .B(n8939), .Y(n8102) );
  XOR2X1 U5241 ( .A(n9422), .B(n8941), .Y(n8939) );
  INVX1 U5242 ( .A(n8942), .Y(n8938) );
  INVX1 U5243 ( .A(n8627), .Y(n8624) );
  OAI221X1 U5244 ( .A0(n9011), .A1(n9356), .B0(n8852), .B1(n9012), .C0(n8803), 
        .Y(n8092) );
  OAI221X1 U5245 ( .A0(n8757), .A1(n9311), .B0(n8759), .B1(n9374), .C0(n8761), 
        .Y(n8162) );
  INVX1 U5246 ( .A(n8742), .Y(n8789) );
  INVX1 U5247 ( .A(n8862), .Y(n8838) );
  INVX1 U5248 ( .A(n8757), .Y(n8774) );
  AOI31X1 U5249 ( .A0(n8666), .A1(n9364), .A2(n8669), .B0(n8670), .Y(n8668) );
  INVX1 U5250 ( .A(n8611), .Y(n8619) );
  NOR2BX1 U5251 ( .AN(n9356), .B(n8839), .Y(n8837) );
  NOR2BX1 U5252 ( .AN(n8630), .B(n8631), .Y(pSD_CKE) );
  INVX1 U5253 ( .A(n8645), .Y(n8635) );
  INVX1 U5254 ( .A(n8846), .Y(n8631) );
  INVX1 U5255 ( .A(n8685), .Y(n8682) );
  INVX1 U5256 ( .A(n8751), .Y(n8749) );
  DFFRX1 bf_last_reg ( .D(bf_last4973), .CK(ACLK), .RN(ARESETB), .Q(BA_STS[5])
         );
  DFFRX1 bf_last_1_reg ( .D(bf_last_14961), .CK(ACLK), .RN(ARESETB), .Q(
        bf_last_1) );
  DFFRX1 do_id_reg_0_ ( .D(do_id4820_0_), .CK(ACLK), .RN(ARESETB), .Q(
        BA_STS[6]) );
  DFFRX1 do_id_reg_1_ ( .D(do_id4820_1_), .CK(ACLK), .RN(ARESETB), .Q(
        BA_STS[7]) );
  DFFRX1 do_id_reg_2_ ( .D(do_id4820_2_), .CK(ACLK), .RN(ARESETB), .Q(
        BA_STS[8]) );
  DFFRX1 do_id_reg_3_ ( .D(do_id4820_3_), .CK(ACLK), .RN(ARESETB), .Q(
        BA_STS[9]) );
  DFFSX1 iSD_WEB_reg ( .D(pttn5084_0_), .CK(ACLK), .SN(ARESETB), .Q(iSD_WEB)
         );
  DFFSX1 iSD_CSB_reg ( .D(pttn5084_3_), .CK(ACLK), .SN(ARESETB), .Q(iSD_CSB)
         );
  NOR2BX1 U5257 ( .AN(BA_STS[0]), .B(n9166), .Y(BA_STS[10]) );
  NOR2BX1 U5258 ( .AN(BA_STS[0]), .B(n9165), .Y(BA_STS[11]) );
  NOR2BX1 U5259 ( .AN(BA_STS[0]), .B(n9164), .Y(BA_STS[12]) );
  NOR2BX1 U5260 ( .AN(BA_STS[0]), .B(n9163), .Y(BA_STS[13]) );
  BUFX2 U5261 ( .A(n8603), .Y(BA_STS[15]) );
  BUFX2 U5262 ( .A(n8601), .Y(BA_STS[16]) );
  AO21X2 U5263 ( .A0(cas_0_rw), .A1(n9169), .B0(n8934), .Y(n9057) );
  OAI211X1 U5264 ( .A0(n8822), .A1(n8811), .B0(n8823), .C0(n8824), .Y(n8152)
         );
  AOI32X1 U5265 ( .A0(n9366), .A1(stable_cnt[0]), .A2(n8808), .B0(ercmd[4]), 
        .B1(n8806), .Y(n8824) );
  AOI31X1 U5266 ( .A0(n8819), .A1(n8742), .A2(n8826), .B0(n8827), .Y(n8823) );
  OA21X2 U5267 ( .A0(n8828), .A1(n8829), .B0(n8826), .Y(n8827) );
  INVX1 U5268 ( .A(n9057), .Y(n9049) );
  AOI31X1 U5269 ( .A0(n9051), .A1(n9052), .A2(n9053), .B0(n8929), .Y(n9050) );
  NOR2BX1 U5270 ( .AN(read_bstop), .B(n8914), .Y(n9052) );
  INVX1 U5271 ( .A(n8833), .Y(n8811) );
  OAI32X1 U5272 ( .A0(n8806), .A1(stable_cnt[0]), .A2(n9356), .B0(n8745), .B1(
        n8834), .Y(n8833) );
  NAND3BX1 U5273 ( .AN(n9175), .B(n9176), .C(n9177), .Y(n8660) );
  XOR2X1 U5274 ( .A(n9323), .B(n7445), .Y(n9175) );
  XOR2X1 U5275 ( .A(rs_state_1_), .B(n8906), .Y(n9177) );
  XOR2X1 U5276 ( .A(rs_state_2_), .B(n9179), .Y(n9176) );
  NOR2BX1 U5277 ( .AN(cmd_full_d), .B(n9046), .Y(BA_STS[4]) );
  NAND3BX1 U5278 ( .AN(rs_state_2_), .B(n9324), .C(rs_state_1_), .Y(n8911) );
  NAND2BX1 U5279 ( .AN(cas_0_rw), .B(n8606), .Y(n8629) );
  NAND3BX1 U5280 ( .AN(rw_bstop1), .B(n9326), .C(n8660), .Y(n8936) );
  NAND2BX1 U5281 ( .AN(n2828_3_), .B(tcl_1_), .Y(n9178) );
  XOR3X1 U5282 ( .A(tcl_2_), .B(tcl_1_), .C(n9178), .Y(n8909) );
  OAI33X1 U5283 ( .A0(n8614), .A1(n8615), .A2(n8616), .B0(n8617), .B1(n8204), 
        .B2(n8618), .Y(pttn5084_3_) );
  NAND2BX1 U5284 ( .AN(ercmd[5]), .B(n9352), .Y(n8616) );
  XOR2X1 U5285 ( .A(n9321), .B(ercmd[4]), .Y(n8615) );
  NAND2BX1 U5286 ( .AN(n8619), .B(n8620), .Y(n8618) );
  AO21X1 U5287 ( .A0(n2828_3_), .A1(n9353), .B0(n9074), .Y(n8642) );
  BUFX2 U5288 ( .A(ercmd[2]), .Y(n9447) );
  NAND3BX1 U5289 ( .AN(n9195), .B(n9196), .C(ercmd[5]), .Y(n9104) );
  INVX1 U5290 ( .A(n8614), .Y(n9196) );
  NAND3BX1 U5291 ( .AN(ercmd[4]), .B(n9321), .C(n9352), .Y(n9195) );
  AO22X1 U5292 ( .A0(ercmd[3]), .A1(n8806), .B0(n8820), .B1(n8808), .Y(n8153)
         );
  INVX1 U5293 ( .A(n8821), .Y(n8820) );
  AO21X1 U5294 ( .A0(trefresh[7]), .A1(n8694), .B0(n8701), .Y(n8173) );
  AO22X1 U5295 ( .A0(refresh_cnt2423_7_), .A1(n8695), .B0(refresh_cnt_7_), 
        .B1(n8692), .Y(n8701) );
  XNOR2X1 U1_A_71 ( .A(refresh_cnt_7_), .B(carry7), .Y(refresh_cnt2423_7_) );
  AO21X1 U5296 ( .A0(trefresh[6]), .A1(n8694), .B0(n8700), .Y(n8174) );
  AO22X1 U5297 ( .A0(refresh_cnt2423_6_), .A1(n8695), .B0(refresh_cnt_6_), 
        .B1(n8692), .Y(n8700) );
  XNOR2X1 U1_A_61 ( .A(refresh_cnt_6_), .B(carry8), .Y(refresh_cnt2423_6_) );
  AO21X1 U5298 ( .A0(trefresh[5]), .A1(n8694), .B0(n8699), .Y(n8175) );
  AO22X1 U5299 ( .A0(refresh_cnt2423_5_), .A1(n8695), .B0(refresh_cnt_5_), 
        .B1(n8692), .Y(n8699) );
  XNOR2X1 U1_A_51 ( .A(refresh_cnt_5_), .B(carry9), .Y(refresh_cnt2423_5_) );
  AO21X1 U5300 ( .A0(trefresh[4]), .A1(n8694), .B0(n8698), .Y(n8176) );
  AO22X1 U5301 ( .A0(refresh_cnt2423_4_), .A1(n8695), .B0(refresh_cnt_4_), 
        .B1(n8692), .Y(n8698) );
  XNOR2X1 U1_A_42 ( .A(refresh_cnt_4_), .B(carry10), .Y(refresh_cnt2423_4_) );
  AO21X1 U5302 ( .A0(trefresh[3]), .A1(n8694), .B0(n8697), .Y(n8177) );
  AO22X1 U5303 ( .A0(refresh_cnt2423_3_), .A1(n8695), .B0(refresh_cnt_3_), 
        .B1(n8692), .Y(n8697) );
  XNOR2X1 U1_A_32 ( .A(refresh_cnt_3_), .B(carry11), .Y(refresh_cnt2423_3_) );
  NAND2BX1 U5304 ( .AN(n8612), .B(n8613), .Y(pttn5084_0_) );
  OAI211X1 U5305 ( .A0(n8627), .A1(n8628), .B0(n8629), .C0(n8609), .Y(n8612)
         );
  INVX1 U5306 ( .A(pttn5084_3_), .Y(n8613) );
  NAND3BX1 U5307 ( .AN(ercmd[3]), .B(n9352), .C(n9447), .Y(n8628) );
  OAI222X1 U5308 ( .A0(n8687), .A1(n9346), .B0(refresh_cnt2486_0_), .B1(n8689), 
        .C0(n9443), .C1(n9416), .Y(n8180) );
  OAI2BB1X1 U5309 ( .A0N(iSD_ADDR[6]), .A1N(n8632), .B0(n8643), .Y(n8192) );
  OAI33X1 U5310 ( .A0(n8645), .A1(n8646), .A2(n9428), .B0(n8645), .B1(tcl_2_), 
        .B2(n8648), .Y(n8644) );
  INVX1 U5311 ( .A(n8648), .Y(n8646) );
  OAI2BB1X1 U5312 ( .A0N(iSD_ADDR[5]), .A1N(n8632), .B0(n8641), .Y(n8193) );
  OAI2BB1X1 U5313 ( .A0N(iSD_ADDR[4]), .A1N(n8632), .B0(n8639), .Y(n8194) );
  OAI2BB1X1 U5314 ( .A0N(iSD_ADDR[2]), .A1N(n8632), .B0(n8637), .Y(n8196) );
  OAI2BB1X1 U5315 ( .A0N(iSD_ADDR[1]), .A1N(n8632), .B0(n8636), .Y(n8197) );
  OAI2BB1X1 U5316 ( .A0N(iSD_ADDR[0]), .A1N(n8632), .B0(n8633), .Y(n8198) );
  OAI2BB1X1 U5317 ( .A0N(iSD_ADDR[10]), .A1N(n8654), .B0(n8655), .Y(n8188) );
  OAI221X1 U5318 ( .A0(n8687), .A1(n9345), .B0(n9443), .B1(n9312), .C0(n8712), 
        .Y(n8169) );
  AOI22X1 U5319 ( .A0(refresh_cnt2423_11_), .A1(n8695), .B0(
        refresh_cnt2486_11_), .B1(n8706), .Y(n8712) );
  XNOR2X1 U1_A_111 ( .A(refresh_cnt_11_), .B(carry3), .Y(refresh_cnt2423_11_)
         );
  OAI221X1 U5320 ( .A0(n8609), .A1(n8889), .B0(n8617), .B1(n9294), .C0(n8890), 
        .Y(n8112) );
  INVX1 U5321 ( .A(ras_0_ba[1]), .Y(n8889) );
  OAI221X1 U5322 ( .A0(n8687), .A1(n9343), .B0(n9443), .B1(n9298), .C0(n8721), 
        .Y(n8166) );
  AOI22X1 U5323 ( .A0(refresh_cnt2423_14_), .A1(n8695), .B0(
        refresh_cnt2486_14_), .B1(n8706), .Y(n8721) );
  XNOR2X1 U1_A_141 ( .A(refresh_cnt_14_), .B(carry0), .Y(refresh_cnt2423_14_)
         );
  OAI221X1 U5324 ( .A0(n8687), .A1(n9340), .B0(n9443), .B1(n9313), .C0(n8718), 
        .Y(n8167) );
  AOI22X1 U5325 ( .A0(refresh_cnt2423_13_), .A1(n8695), .B0(
        refresh_cnt2486_13_), .B1(n8706), .Y(n8718) );
  XNOR2X1 U1_A_131 ( .A(refresh_cnt_13_), .B(carry1), .Y(refresh_cnt2423_13_)
         );
  OAI221X1 U5326 ( .A0(n8687), .A1(n9341), .B0(n9443), .B1(n9303), .C0(n8715), 
        .Y(n8168) );
  AOI22X1 U5327 ( .A0(refresh_cnt2423_12_), .A1(n8695), .B0(
        refresh_cnt2486_12_), .B1(n8706), .Y(n8715) );
  XNOR2X1 U1_A_121 ( .A(refresh_cnt_12_), .B(carry2), .Y(refresh_cnt2423_12_)
         );
  OAI221X1 U5328 ( .A0(n8687), .A1(n9320), .B0(n9443), .B1(n9331), .C0(n8705), 
        .Y(n8171) );
  AOI22X1 U5329 ( .A0(refresh_cnt2423_9_), .A1(n8695), .B0(refresh_cnt2486_9_), 
        .B1(n8706), .Y(n8705) );
  XNOR2X1 U1_A_91 ( .A(refresh_cnt_9_), .B(carry5), .Y(refresh_cnt2423_9_) );
  OAI221X1 U5330 ( .A0(n8687), .A1(n9342), .B0(n9443), .B1(n9302), .C0(n8709), 
        .Y(n8170) );
  AOI22X1 U5331 ( .A0(refresh_cnt2423_10_), .A1(n8695), .B0(
        refresh_cnt2486_10_), .B1(n8706), .Y(n8709) );
  XNOR2X1 U1_A_101 ( .A(refresh_cnt_10_), .B(carry4), .Y(refresh_cnt2423_10_)
         );
  OAI221X1 U5332 ( .A0(n8687), .A1(n9344), .B0(n9443), .B1(n9360), .C0(n8724), 
        .Y(n8165) );
  AOI22X1 U5333 ( .A0(n6), .A1(n8706), .B0(refresh_cnt2423_15_), .B1(n8695), 
        .Y(n8724) );
  XNOR2X1 U1_A_151 ( .A(refresh_cnt_15_), .B(carry), .Y(refresh_cnt2423_15_)
         );
  AO21X1 U5334 ( .A0(trp_cnt[1]), .A1(n8778), .B0(n8785), .Y(n8157) );
  OAI32X1 U5335 ( .A0(n8778), .A1(n9372), .A2(n8781), .B0(n8787), .B1(n8778), 
        .Y(n8785) );
  OAI211X1 U5336 ( .A0(n8788), .A1(n8789), .B0(n9440), .C0(n8784), .Y(n8787)
         );
  NOR2BX1 U5337 ( .AN(trp_cnt[1]), .B(n9381), .Y(n8788) );
  AO21X1 U5338 ( .A0(refresh_cnt_8_), .A1(n8692), .B0(n8702), .Y(n8172) );
  AO22X1 U5339 ( .A0(trefresh[8]), .A1(n8694), .B0(refresh_cnt2423_8_), .B1(
        n8695), .Y(n8702) );
  XNOR2X1 U1_A_81 ( .A(refresh_cnt_8_), .B(carry6), .Y(refresh_cnt2423_8_) );
  AO21X1 U5340 ( .A0(n9448), .A1(n8692), .B0(n8693), .Y(n8179) );
  AO22X1 U5341 ( .A0(trefresh[1]), .A1(n8694), .B0(refresh_cnt2423_1_), .B1(
        n8695), .Y(n8693) );
  XNOR2X1 U1_A_17 ( .A(n9448), .B(refresh_cnt2486_0_), .Y(refresh_cnt2423_1_)
         );
  AO21X1 U5342 ( .A0(iSD_BADDR[0]), .A1(n8654), .B0(n8879), .Y(n8113) );
  OAI222X1 U5343 ( .A0(n8656), .A1(n8671), .B0(n8684), .B1(n8880), .C0(n8609), 
        .C1(n8881), .Y(n8879) );
  INVX1 U5344 ( .A(ras_0_ba[0]), .Y(n8881) );
  AO21X1 U5345 ( .A0(n8882), .A1(n8883), .B0(n8884), .Y(n8880) );
  AO21X1 U5346 ( .A0(trp_cnt[0]), .A1(n8778), .B0(n8779), .Y(n8158) );
  OAI33X1 U5347 ( .A0(n8778), .A1(n9371), .A2(n8781), .B0(n8778), .B1(n8782), 
        .B2(n8783), .Y(n8779) );
  NAND2BX1 U5348 ( .AN(trp_cnt[0]), .B(n9440), .Y(n8782) );
  INVX1 U5349 ( .A(n8784), .Y(n8783) );
  AO21X1 U5350 ( .A0(iSD_ADDR[3]), .A1(n8632), .B0(n8638), .Y(n8195) );
  AO22X1 U5351 ( .A0(ras_0_ra[3]), .A1(n9441), .B0(cas_0_ca[3]), .B1(n8606), 
        .Y(n8638) );
  AO21X1 U5352 ( .A0(trefresh[2]), .A1(n8694), .B0(n8696), .Y(n8178) );
  AO22X1 U5353 ( .A0(refresh_cnt2423_2_), .A1(n8695), .B0(n8508), .B1(n8692), 
        .Y(n8696) );
  XNOR2X1 U1_A_22 ( .A(n8508), .B(carry12), .Y(refresh_cnt2423_2_) );
  AO21X1 U5354 ( .A0(iSD_ADDR[9]), .A1(n8650), .B0(n8653), .Y(n8189) );
  AO22X1 U5355 ( .A0(ras_0_ra[9]), .A1(n9441), .B0(cas_0_ca[9]), .B1(n8606), 
        .Y(n8653) );
  AO21X1 U5356 ( .A0(iSD_ADDR[8]), .A1(n8650), .B0(n8652), .Y(n8190) );
  AO21X1 U5357 ( .A0(iSD_ADDR[7]), .A1(n8650), .B0(n8651), .Y(n8191) );
  AND3X2 U5358 ( .A(n9407), .B(n9354), .C(n7445), .Y(n9406) );
  OAI211X1 U5359 ( .A0(n8729), .A1(n8834), .B0(n8835), .C0(n8836), .Y(n8151)
         );
  OA22X1 U5360 ( .A0(n8726), .A1(n8809), .B0(n8808), .B1(n9375), .Y(n8835) );
  AOI33X1 U5361 ( .A0(stable_cnt[0]), .A1(n8837), .A2(n8808), .B0(n8812), .B1(
        n8838), .B2(n8814), .Y(n8836) );
  OR2X1 U5362 ( .A(refresh_cnt_13_), .B(n9409), .Y(n9408) );
  OR2X1 U5363 ( .A(refresh_cnt_12_), .B(n9410), .Y(n9409) );
  OR2X1 U5364 ( .A(refresh_cnt_11_), .B(n9411), .Y(n9410) );
  OR2X1 U5365 ( .A(refresh_cnt_10_), .B(n9412), .Y(n9411) );
  OR2X1 U5366 ( .A(refresh_cnt_9_), .B(carry_9_), .Y(n9412) );
  NAND3BX1 U5367 ( .AN(BA_STS[15]), .B(AddrSwapEn), .C(BA_STS[16]), .Y(n9241)
         );
  NAND3BX1 U5368 ( .AN(AddrSwapEn), .B(BA_STS[15]), .C(BA_STS[16]), .Y(n9271)
         );
  NAND3BX1 U5369 ( .AN(n8958), .B(n8932), .C(n8959), .Y(n8954) );
  AOI211X1 U5370 ( .A0(n8960), .A1(n8961), .B0(n8510), .C0(n9358), .Y(n8959)
         );
  NOR2BX1 U5371 ( .AN(n8504), .B(n9420), .Y(n8961) );
  NOR2BX1 U5372 ( .AN(n8503), .B(n9422), .Y(n8960) );
  NAND3BX1 U5373 ( .AN(rs_state_2_), .B(n9354), .C(n9324), .Y(n8931) );
  INVX1 U5374 ( .A(n8925), .Y(n8897) );
  NAND3BX1 U5375 ( .AN(cas_0_rw), .B(n8907), .C(n8901), .Y(n8925) );
  NAND2BX1 U5376 ( .AN(AddrSwapEn), .B(n9273), .Y(n9258) );
  NAND4BX1 U5377 ( .AN(refresh_cnt_4_), .B(n9314), .C(n9413), .D(n9069), .Y(
        carry_9_) );
  AND4X1 U5378 ( .A(n9332), .B(n9362), .C(n9315), .D(n9304), .Y(n9069) );
  OAI221X1 U5379 ( .A0(n8911), .A1(n8912), .B0(n8913), .B1(n8914), .C0(n8915), 
        .Y(n8908) );
  AOI31X1 U5380 ( .A0(rs_state_2_), .A1(n8918), .A2(n8919), .B0(n8920), .Y(
        n8917) );
  BUFX2 U5381 ( .A(refresh_cnt_1_), .Y(n9448) );
  AO22X1 U5382 ( .A0(cas_pm_0), .A1(n8656), .B0(n8657), .B1(n8658), .Y(n8185)
         );
  NOR2BX1 U5383 ( .AN(cas_0_pm), .B(cas_empty), .Y(n8657) );
  AO22X1 U5384 ( .A0(cas_0_ba[1]), .A1(n8606), .B0(last_ba[1]), .B1(n8656), 
        .Y(n8106) );
  AO22X1 U5385 ( .A0(cas_0_ba[0]), .A1(n8606), .B0(last_ba[0]), .B1(n8656), 
        .Y(n8107) );
  AO21X1 U5386 ( .A0(n7445), .A1(n8908), .B0(n8899), .Y(n8902) );
  AO22X1 U5387 ( .A0(rs_state_1_), .A1(n8902), .B0(n8903), .B1(n8901), .Y(
        n8104) );
  OAI31X1 U5388 ( .A0(n8900), .A1(rs_state_1_), .A2(n7445), .B0(n8904), .Y(
        n8903) );
  OA22X1 U5389 ( .A0(n8905), .A1(n8670), .B0(n8906), .B1(n8905), .Y(n8904) );
  INVX1 U5390 ( .A(n8907), .Y(n8905) );
  OAI2BB1X1 U5391 ( .A0N(n8897), .A1N(n8909), .B0(n8910), .Y(n8103) );
  AOI32X1 U5392 ( .A0(rs_state_1_), .A1(rs_state_2_), .A2(n8908), .B0(
        rs_state_2_), .B1(n8902), .Y(n8910) );
  AO22X1 U5393 ( .A0(do_id_0[3]), .A1(n8629), .B0(cas_0_id[3]), .B1(n8658), 
        .Y(n8108) );
  AO22X1 U5394 ( .A0(do_id_0[2]), .A1(n8629), .B0(cas_0_id[2]), .B1(n8658), 
        .Y(n8109) );
  AO22X1 U5395 ( .A0(do_id_0[1]), .A1(n8629), .B0(cas_0_id[1]), .B1(n8658), 
        .Y(n8110) );
  AO22X1 U5396 ( .A0(do_id_0[0]), .A1(n8629), .B0(cas_0_id[0]), .B1(n8658), 
        .Y(n8111) );
  AO21X1 U5397 ( .A0(n8897), .A1(n9323), .B0(n8898), .Y(n8105) );
  OAI32X1 U5398 ( .A0(n8899), .A1(n7445), .A2(n8900), .B0(n9324), .B1(n8901), 
        .Y(n8898) );
  AND2X2 U5399 ( .A(n9418), .B(n9361), .Y(n9413) );
  NAND3BX1 U5400 ( .AN(n9158), .B(PADDR[2]), .C(PADDR[3]), .Y(n9109) );
  NAND3BX1 U5401 ( .AN(n9158), .B(PADDR[2]), .C(PADDR[3]), .Y(n9434) );
  NAND3BX1 U5402 ( .AN(n8876), .B(n8877), .C(PADDR[2]), .Y(n8872) );
  NAND3BX1 U5403 ( .AN(n8876), .B(PADDR[3]), .C(PADDR[2]), .Y(n8868) );
  NAND3BX1 U5404 ( .AN(n8876), .B(PADDR[3]), .C(PADDR[2]), .Y(n9438) );
  NAND3BX1 U5405 ( .AN(n8876), .B(PADDR[3]), .C(PADDR[2]), .Y(n9437) );
  OR3X2 U5406 ( .A(n8958), .B(n9414), .C(n8967), .Y(n8726) );
  NAND3BX1 U5407 ( .AN(n9158), .B(n8877), .C(PADDR[2]), .Y(n9114) );
  NAND2BX1 U5408 ( .AN(stable_cnt[0]), .B(n9356), .Y(n8852) );
  NAND4BX1 U5409 ( .AN(n8504), .B(n9414), .C(n9419), .D(n9421), .Y(n8832) );
  NAND3BX1 U5410 ( .AN(refresh_cnt2486_0_), .B(n9448), .C(n8729), .Y(n8728) );
  NAND2BX1 U5411 ( .AN(stable_cnt[2]), .B(SDREn), .Y(n8754) );
  NAND3BX1 U5412 ( .AN(n8503), .B(n9422), .C(n8974), .Y(n8846) );
  NAND3BX1 U5413 ( .AN(n9010), .B(n8505), .C(n8503), .Y(n8967) );
  NAND3BX1 U5414 ( .AN(n9420), .B(n8501), .C(n8504), .Y(n9010) );
  AND2X2 U5415 ( .A(n9416), .B(n9361), .Y(n9415) );
  AND2X2 U5416 ( .A(n9418), .B(n8729), .Y(n9417) );
  AO21X1 U5417 ( .A0(ar_cnt[1]), .A1(n8984), .B0(n8981), .Y(n8989) );
  OAI211X1 U5418 ( .A0(stable_cnt[2]), .A1(n8852), .B0(SDREn), .C0(n9440), .Y(
        n8842) );
  NAND2BX1 U5419 ( .AN(PWRITE), .B(n9355), .Y(n9158) );
  INVX1 U5420 ( .A(n8969), .Y(n8828) );
  OAI221X1 U5421 ( .A0(n8503), .A1(n8504), .B0(n9421), .B1(n9328), .C0(n9419), 
        .Y(n8969) );
  NAND2X1 U5422 ( .A(PWRITE), .B(n9355), .Y(n8876) );
  NAND2BX1 U5423 ( .AN(SelfRefEn), .B(n8963), .Y(n8865) );
  NOR2BX1 U5424 ( .AN(refreshno[3]), .B(n9109), .Y(PRDATA502_19_) );
  NOR2BX1 U5425 ( .AN(stable_cnt[2]), .B(n9109), .Y(PRDATA502_22_) );
  NOR2BX1 U5426 ( .AN(n8503), .B(n9109), .Y(PRDATA502_26_) );
  BUFX2 U5427 ( .A(n8870), .Y(n9436) );
  NAND3BX1 U5428 ( .AN(n8876), .B(n8878), .C(PADDR[3]), .Y(n8870) );
  NOR2BX1 U5429 ( .AN(refreshno[2]), .B(n9434), .Y(PRDATA502_18_) );
  NOR2BX1 U5430 ( .AN(stable_cnt[1]), .B(n9434), .Y(PRDATA502_21_) );
  NOR2BX1 U5431 ( .AN(n8504), .B(n9434), .Y(PRDATA502_25_) );
  NOR2BX1 U5432 ( .AN(n8501), .B(n9434), .Y(PRDATA502_28_) );
  NAND2X1 U5433 ( .A(cas_empty), .B(ras_empty), .Y(n8958) );
  NAND2BX1 U5434 ( .AN(n8505), .B(n8968), .Y(n8831) );
  OAI31X1 U5435 ( .A0(n9009), .A1(n8505), .A2(n8501), .B0(n8967), .Y(n8963) );
  NAND3BX1 U5436 ( .AN(n8502), .B(n9328), .C(n9357), .Y(n9009) );
  AO22X1 U5437 ( .A0(trefresh[11]), .A1(n9438), .B0(PWDATA[11]), .B1(n8869), 
        .Y(n8138) );
  AO22X1 U5438 ( .A0(trefresh[5]), .A1(n9438), .B0(PWDATA[5]), .B1(n8869), .Y(
        n8144) );
  BUFX2 U5439 ( .A(n9108), .Y(n9433) );
  NAND3BX1 U5440 ( .AN(n9158), .B(n8878), .C(PADDR[3]), .Y(n9108) );
  AO22X1 U5441 ( .A0(refreshno[3]), .A1(n9438), .B0(PWDATA[19]), .B1(n8869), 
        .Y(n8071) );
  AO22X1 U5442 ( .A0(refreshno[2]), .A1(n9437), .B0(PWDATA[18]), .B1(n8869), 
        .Y(n8072) );
  AO22X1 U5443 ( .A0(refreshno[1]), .A1(n8868), .B0(PWDATA[17]), .B1(n8869), 
        .Y(n8073) );
  AO22X1 U5444 ( .A0(refreshno[0]), .A1(n9438), .B0(PWDATA[16]), .B1(n8869), 
        .Y(n8074) );
  AO22X1 U5445 ( .A0(SelfRefEn), .A1(n9436), .B0(PWDATA[31]), .B1(n8871), .Y(
        n8132) );
  AO22X1 U5446 ( .A0(PwDnEn), .A1(n9436), .B0(PWDATA[16]), .B1(n8871), .Y(
        n8133) );
  AO22X1 U5447 ( .A0(trefresh[15]), .A1(n9437), .B0(PWDATA[15]), .B1(n8869), 
        .Y(n8134) );
  AO22X1 U5448 ( .A0(trefresh[14]), .A1(n8868), .B0(PWDATA[14]), .B1(n8869), 
        .Y(n8135) );
  AO22X1 U5449 ( .A0(trefresh[13]), .A1(n9438), .B0(PWDATA[13]), .B1(n8869), 
        .Y(n8136) );
  AO22X1 U5450 ( .A0(trefresh[12]), .A1(n9437), .B0(PWDATA[12]), .B1(n8869), 
        .Y(n8137) );
  AO22X1 U5451 ( .A0(trefresh[10]), .A1(n9438), .B0(PWDATA[10]), .B1(n8869), 
        .Y(n8139) );
  AO22X1 U5452 ( .A0(trefresh[9]), .A1(n9437), .B0(PWDATA[9]), .B1(n8869), .Y(
        n8140) );
  AO22X1 U5453 ( .A0(trefresh[8]), .A1(n9437), .B0(PWDATA[8]), .B1(n8869), .Y(
        n8141) );
  AO22X1 U5454 ( .A0(trefresh[7]), .A1(n9438), .B0(PWDATA[7]), .B1(n8869), .Y(
        n8142) );
  AO22X1 U5455 ( .A0(trefresh[6]), .A1(n9437), .B0(PWDATA[6]), .B1(n8869), .Y(
        n8143) );
  AO22X1 U5456 ( .A0(trefresh[4]), .A1(n9438), .B0(PWDATA[4]), .B1(n8869), .Y(
        n8145) );
  AO22X1 U5457 ( .A0(trefresh[3]), .A1(n9437), .B0(PWDATA[3]), .B1(n8869), .Y(
        n8146) );
  AO22X1 U5458 ( .A0(trefresh[2]), .A1(n9437), .B0(PWDATA[2]), .B1(n8869), .Y(
        n8147) );
  AO22X1 U5459 ( .A0(trefresh[1]), .A1(n9438), .B0(PWDATA[1]), .B1(n8869), .Y(
        n8148) );
  AO22X1 U5460 ( .A0(trefresh[0]), .A1(n9437), .B0(PWDATA[0]), .B1(n8869), .Y(
        n8149) );
  AO22X1 U5461 ( .A0(PwDnRef[15]), .A1(n9436), .B0(n8871), .B1(PWDATA[15]), 
        .Y(n8055) );
  AO22X1 U5462 ( .A0(PwDnRef[14]), .A1(n9436), .B0(n8871), .B1(PWDATA[14]), 
        .Y(n8056) );
  AO22X1 U5463 ( .A0(PwDnRef[13]), .A1(n9436), .B0(n8871), .B1(PWDATA[13]), 
        .Y(n8057) );
  AO22X1 U5464 ( .A0(PwDnRef[12]), .A1(n9436), .B0(n8871), .B1(PWDATA[12]), 
        .Y(n8058) );
  AO22X1 U5465 ( .A0(PwDnRef[11]), .A1(n9436), .B0(n8871), .B1(PWDATA[11]), 
        .Y(n8059) );
  AO22X1 U5466 ( .A0(PwDnRef[10]), .A1(n9436), .B0(n8871), .B1(PWDATA[10]), 
        .Y(n8060) );
  AO22X1 U5467 ( .A0(PwDnRef[9]), .A1(n9436), .B0(n8871), .B1(PWDATA[9]), .Y(
        n8061) );
  AO22X1 U5468 ( .A0(PwDnRef[8]), .A1(n9436), .B0(n8871), .B1(PWDATA[8]), .Y(
        n8062) );
  AO22X1 U5469 ( .A0(PwDnRef[7]), .A1(n9436), .B0(n8871), .B1(PWDATA[7]), .Y(
        n8063) );
  AO22X1 U5470 ( .A0(PwDnRef[6]), .A1(n9436), .B0(n8871), .B1(PWDATA[6]), .Y(
        n8064) );
  AO22X1 U5471 ( .A0(PwDnRef[5]), .A1(n9436), .B0(n8871), .B1(PWDATA[5]), .Y(
        n8065) );
  AO22X1 U5472 ( .A0(PwDnRef[4]), .A1(n9436), .B0(n8871), .B1(PWDATA[4]), .Y(
        n8066) );
  AO22X1 U5473 ( .A0(PwDnRef[3]), .A1(n9436), .B0(n8871), .B1(PWDATA[3]), .Y(
        n8067) );
  AO22X1 U5474 ( .A0(PwDnRef[2]), .A1(n9436), .B0(n8871), .B1(PWDATA[2]), .Y(
        n8068) );
  AO22X1 U5475 ( .A0(PwDnRef[1]), .A1(n9436), .B0(n8871), .B1(PWDATA[1]), .Y(
        n8069) );
  AO22X1 U5476 ( .A0(PwDnRef[0]), .A1(n9436), .B0(n8871), .B1(PWDATA[0]), .Y(
        n8070) );
  AO22X1 U5477 ( .A0(trp[1]), .A1(n9442), .B0(n8875), .B1(PWDATA[1]), .Y(n8114) );
  AO22X1 U5478 ( .A0(trcd[1]), .A1(n9442), .B0(n8875), .B1(PWDATA[3]), .Y(
        n8116) );
  AO22X1 U5479 ( .A0(n2828_3_), .A1(n9442), .B0(n8875), .B1(PWDATA[4]), .Y(
        n8120) );
  AO22X1 U5480 ( .A0(trasmin[2]), .A1(n9442), .B0(n8875), .B1(PWDATA[10]), .Y(
        n8122) );
  AO22X1 U5481 ( .A0(trasmin[1]), .A1(n9442), .B0(n8875), .B1(PWDATA[9]), .Y(
        n8123) );
  AO22X1 U5482 ( .A0(trasmin[0]), .A1(n9442), .B0(n8875), .B1(PWDATA[8]), .Y(
        n8124) );
  AO22X1 U5483 ( .A0(trc[3]), .A1(n9442), .B0(n8875), .B1(PWDATA[15]), .Y(
        n8125) );
  AO22X1 U5484 ( .A0(trc[1]), .A1(n9442), .B0(n8875), .B1(PWDATA[13]), .Y(
        n8127) );
  AO22X1 U5485 ( .A0(n8601), .A1(n8872), .B0(n8873), .B1(PWDATA[5]), .Y(n8053)
         );
  AO22X1 U5486 ( .A0(n8603), .A1(n8872), .B0(n8873), .B1(PWDATA[4]), .Y(n8054)
         );
  AO22X1 U5487 ( .A0(trp[0]), .A1(n9442), .B0(n8875), .B1(PWDATA[0]), .Y(n8115) );
  AO22X1 U5488 ( .A0(trcd[0]), .A1(n9442), .B0(n8875), .B1(PWDATA[2]), .Y(
        n8117) );
  AO22X1 U5489 ( .A0(tcl_2_), .A1(n9442), .B0(n8875), .B1(PWDATA[6]), .Y(n8118) );
  AO22X1 U5490 ( .A0(tcl_1_), .A1(n9442), .B0(n8875), .B1(PWDATA[5]), .Y(n8119) );
  AO22X1 U5491 ( .A0(trasmin[3]), .A1(n9442), .B0(n8875), .B1(PWDATA[11]), .Y(
        n8121) );
  AO22X1 U5492 ( .A0(trc[2]), .A1(n9442), .B0(n8875), .B1(PWDATA[14]), .Y(
        n8126) );
  AO22X1 U5493 ( .A0(trc[0]), .A1(n9442), .B0(n8875), .B1(PWDATA[12]), .Y(
        n8128) );
  AO22X1 U5494 ( .A0(n8605), .A1(n8872), .B0(n8873), .B1(PWDATA[7]), .Y(n8129)
         );
  AO22X1 U5495 ( .A0(AddrSwapEn), .A1(n8872), .B0(n8873), .B1(PWDATA[1]), .Y(
        n8130) );
  AO22X1 U5496 ( .A0(SDREn), .A1(n8872), .B0(n8873), .B1(PWDATA[0]), .Y(n8131)
         );
  BUFX2 U5497 ( .A(n9435), .Y(n9431) );
  NAND3BX1 U5498 ( .AN(n9158), .B(PADDR[2]), .C(PADDR[3]), .Y(n9435) );
  NOR2BX1 U5499 ( .AN(n8505), .B(n9431), .Y(PRDATA502_24_) );
  NOR2BX1 U5500 ( .AN(n8502), .B(n9431), .Y(PRDATA502_27_) );
  NOR2BX1 U5501 ( .AN(stable_cnt[0]), .B(n9431), .Y(PRDATA502_20_) );
  NOR2BX1 U5502 ( .AN(refreshno[1]), .B(n9431), .Y(PRDATA502_17_) );
  INVX1 U5503 ( .A(n8973), .Y(n8968) );
  NAND3BX1 U5504 ( .AN(n9414), .B(n8503), .C(n8974), .Y(n8973) );
  OR2X1 U1_B_9 ( .A(PwDnCnt[9]), .B(carry22), .Y(carry21) );
  OR2X1 U1_B_16 ( .A(n9448), .B(refresh_cnt2486_0_), .Y(carry12) );
  OR2X1 U1_B_22 ( .A(n8508), .B(carry12), .Y(carry11) );
  OR2X1 U1_B_1 ( .A(PwDnCnt[1]), .B(PwDnCnt[0]), .Y(carry29) );
  OR2X1 U1_B_111 ( .A(refresh_cnt_11_), .B(carry3), .Y(carry2) );
  OR2X1 U1_B_2 ( .A(PwDnCnt[2]), .B(carry29), .Y(carry28) );
  OR2X1 U1_B_3 ( .A(PwDnCnt[3]), .B(carry28), .Y(carry27) );
  OR2X1 U1_B_4 ( .A(PwDnCnt[4]), .B(carry27), .Y(carry26) );
  OR2X1 U1_B_5 ( .A(PwDnCnt[5]), .B(carry26), .Y(carry25) );
  OR2X1 U1_B_6 ( .A(PwDnCnt[6]), .B(carry25), .Y(carry24) );
  OR2X1 U1_B_7 ( .A(PwDnCnt[7]), .B(carry24), .Y(carry23) );
  OR2X1 U1_B_8 ( .A(PwDnCnt[8]), .B(carry23), .Y(carry22) );
  OR2X1 U1_B_10 ( .A(PwDnCnt[10]), .B(carry21), .Y(carry20) );
  OR2X1 U1_B_11 ( .A(PwDnCnt[11]), .B(carry20), .Y(carry19) );
  OR2X1 U1_B_12 ( .A(PwDnCnt[12]), .B(carry19), .Y(carry18) );
  OR2X1 U1_B_13 ( .A(PwDnCnt[13]), .B(carry18), .Y(carry17) );
  OR2X1 U1_B_51 ( .A(refresh_cnt_5_), .B(carry9), .Y(carry8) );
  OR2X1 U1_B_41 ( .A(refresh_cnt_4_), .B(carry10), .Y(carry9) );
  OR2X1 U1_B_131 ( .A(refresh_cnt_13_), .B(carry1), .Y(carry0) );
  OR2X1 U1_B_121 ( .A(refresh_cnt_12_), .B(carry2), .Y(carry1) );
  OR2X1 U1_B_101 ( .A(refresh_cnt_10_), .B(carry4), .Y(carry3) );
  OR2X1 U1_B_91 ( .A(refresh_cnt_9_), .B(carry5), .Y(carry4) );
  OR2X1 U1_B_32 ( .A(refresh_cnt_3_), .B(carry11), .Y(carry10) );
  OR2X1 U1_B_61 ( .A(refresh_cnt_6_), .B(carry8), .Y(carry7) );
  OR2X1 U1_B_71 ( .A(refresh_cnt_7_), .B(carry7), .Y(carry6) );
  OR2X1 U1_B_81 ( .A(refresh_cnt_8_), .B(carry6), .Y(carry5) );
  AO21X1 U5505 ( .A0(ar_cnt[0]), .A1(n8984), .B0(n8991), .Y(n8981) );
  OAI222X1 U5506 ( .A0(n9349), .A1(n9106), .B0(n9308), .B1(n9433), .C0(n9386), 
        .C1(n9434), .Y(PRDATA502_2_) );
  OAI222X1 U5507 ( .A0(n9350), .A1(n9106), .B0(n9319), .B1(n9433), .C0(n9387), 
        .C1(n9431), .Y(PRDATA502_3_) );
  OAI222X1 U5508 ( .A0(n9428), .A1(n9106), .B0(n9316), .B1(n9433), .C0(n9388), 
        .C1(n9434), .Y(PRDATA502_6_) );
  OAI222X1 U5509 ( .A0(n9309), .A1(n9114), .B0(n9335), .B1(n9433), .C0(n9389), 
        .C1(n9434), .Y(PRDATA502_7_) );
  OAI222X1 U5510 ( .A0(n9351), .A1(n9106), .B0(n9305), .B1(n9433), .C0(n9385), 
        .C1(n9431), .Y(PRDATA502_8_) );
  OAI222X1 U5511 ( .A0(n9390), .A1(n9106), .B0(n9347), .B1(n9433), .C0(n9320), 
        .C1(n9431), .Y(PRDATA502_9_) );
  OAI222X1 U5512 ( .A0(n9391), .A1(n9106), .B0(n9318), .B1(n9433), .C0(n9342), 
        .C1(n9431), .Y(PRDATA502_10_) );
  OAI222X1 U5513 ( .A0(n9384), .A1(n9106), .B0(n9306), .B1(n9433), .C0(n9345), 
        .C1(n9431), .Y(PRDATA502_11_) );
  OAI222X1 U5514 ( .A0(n9392), .A1(n9106), .B0(n9317), .B1(n9433), .C0(n9343), 
        .C1(n9431), .Y(PRDATA502_14_) );
  OAI222X1 U5515 ( .A0(n9393), .A1(n9106), .B0(n9300), .B1(n9433), .C0(n9344), 
        .C1(n9434), .Y(PRDATA502_15_) );
  OAI222X1 U5516 ( .A0(n8976), .A1(n9378), .B0(n8860), .B1(n8980), .C0(n8987), 
        .C1(n9348), .Y(n8095) );
  INVX1 U5517 ( .A(n8989), .Y(n8987) );
  OAI222X1 U5518 ( .A0(n8976), .A1(n9377), .B0(n8978), .B1(n9330), .C0(
        ar_cnt[0]), .C1(n8980), .Y(n8097) );
  OAI2BB2X1 U5519 ( .A0N(n9135), .A1N(refreshno[0]), .B0(n8630), .B1(n9433), 
        .Y(PRDATA502_16_) );
  OAI2BB1X1 U5520 ( .A0N(ar_cnt[3]), .A1N(n8989), .B0(n8990), .Y(n8094) );
  AOI32X1 U5521 ( .A0(ar_cnt[2]), .A1(ar_cnt[3]), .A2(n8984), .B0(refreshno[3]), .B1(n8985), .Y(n8990) );
  NOR2X1 U5522 ( .A(n8501), .B(n9420), .Y(n9419) );
  OAI221X1 U5523 ( .A0(n9371), .A1(n9106), .B0(n9333), .B1(n9433), .C0(n9156), 
        .Y(PRDATA502_0_) );
  OA22X1 U5524 ( .A0(n9346), .A1(n9434), .B0(n9114), .B1(n9382), .Y(n9156) );
  OAI221X1 U5525 ( .A0(n9372), .A1(n9106), .B0(n9336), .B1(n9433), .C0(n9137), 
        .Y(PRDATA502_1_) );
  OA22X1 U5526 ( .A0(n9394), .A1(n9434), .B0(n9325), .B1(n9114), .Y(n9137) );
  OAI221X1 U5527 ( .A0(n9323), .A1(n9106), .B0(n9367), .B1(n9433), .C0(n9124), 
        .Y(PRDATA502_4_) );
  OA22X1 U5528 ( .A0(n9395), .A1(n9431), .B0(n9327), .B1(n9114), .Y(n9124) );
  OAI221X1 U5529 ( .A0(n9353), .A1(n9106), .B0(n9337), .B1(n9433), .C0(n9120), 
        .Y(PRDATA502_5_) );
  OA22X1 U5530 ( .A0(n9396), .A1(n9434), .B0(n9339), .B1(n9114), .Y(n9120) );
  OAI31X1 U5531 ( .A0(n8992), .A1(n8993), .A2(n8773), .B0(n8756), .Y(n8978) );
  NAND2BX1 U5532 ( .AN(stable_cnt[0]), .B(n8995), .Y(n8993) );
  OA21X2 U5533 ( .A0(n8865), .A1(n8745), .B0(n9356), .Y(n8992) );
  INVX1 U5534 ( .A(n8754), .Y(n8995) );
  AO21X1 U5535 ( .A0(PwDnCnt564_15_), .A1(n9024), .B0(n9041), .Y(n8075) );
  AO22X1 U5536 ( .A0(PwDnCnt[15]), .A1(n9026), .B0(PwDnRef[15]), .B1(n9439), 
        .Y(n9041) );
  XNOR2X1 U1_A_15 ( .A(PwDnCnt[15]), .B(carry16), .Y(PwDnCnt564_15_) );
  OR2X1 U1_B_14 ( .A(PwDnCnt[14]), .B(carry17), .Y(carry16) );
  AO21X1 U5537 ( .A0(PwDnCnt564_14_), .A1(n9024), .B0(n9040), .Y(n8076) );
  AO22X1 U5538 ( .A0(PwDnCnt[14]), .A1(n9026), .B0(PwDnRef[14]), .B1(n9439), 
        .Y(n9040) );
  XNOR2X1 U1_A_14 ( .A(PwDnCnt[14]), .B(carry17), .Y(PwDnCnt564_14_) );
  OR2X1 U1_B_141 ( .A(refresh_cnt_14_), .B(carry0), .Y(carry) );
  NOR2X1 U5539 ( .A(n8503), .B(n9422), .Y(n9421) );
  NAND2BX1 U5540 ( .AN(n9161), .B(PSEL), .Y(n9160) );
  OR2X1 U5541 ( .A(PADDR[5]), .B(PADDR[4]), .Y(n9161) );
  OAI211X1 U5542 ( .A0(n8941), .A1(n9357), .B0(n8947), .C0(n8942), .Y(n8100)
         );
  NAND2BX1 U5543 ( .AN(n8945), .B(selfref_cnt2109_2_), .Y(n8947) );
  XNOR2X1 U1_A_21 ( .A(n8503), .B(carry15), .Y(selfref_cnt2109_2_) );
  OAI211X1 U5544 ( .A0(n8941), .A1(n9328), .B0(n8944), .C0(n8942), .Y(n8101)
         );
  NAND2BX1 U5545 ( .AN(n8945), .B(selfref_cnt2109_1_), .Y(n8944) );
  XNOR2X1 U1_A_16 ( .A(n8504), .B(n8505), .Y(selfref_cnt2109_1_) );
  OAI211X1 U5546 ( .A0(n8941), .A1(n9420), .B0(n8949), .C0(n8942), .Y(n8099)
         );
  NAND2BX1 U5547 ( .AN(n8945), .B(selfref_cnt2109_3_), .Y(n8949) );
  XNOR2X1 U1_A_31 ( .A(n8502), .B(carry14), .Y(selfref_cnt2109_3_) );
  OAI211X1 U5548 ( .A0(n8941), .A1(n9358), .B0(n8951), .C0(n8942), .Y(n8098)
         );
  NAND2BX1 U5549 ( .AN(n8945), .B(selfref_cnt2109_4_), .Y(n8951) );
  XNOR2X1 U1_A_41 ( .A(n8501), .B(carry13), .Y(selfref_cnt2109_4_) );
  OR2X1 U1_B_31 ( .A(n8502), .B(carry14), .Y(carry13) );
  OAI31X1 U5550 ( .A0(n8672), .A1(n8670), .A2(n8660), .B0(n8673), .Y(n8183) );
  AOI32X1 U5551 ( .A0(n8674), .A1(n8675), .A2(n8676), .B0(rw_bstop0), .B1(
        n8664), .Y(n8673) );
  AOI32X1 U5552 ( .A0(n9424), .A1(BA_STS[2]), .A2(n8736), .B0(
        refresh_cnt2486_0_), .B1(n9448), .Y(n8743) );
  XOR2X1 U5553 ( .A(n8671), .B(last_ba[0]), .Y(n8669) );
  NAND4BX1 U5554 ( .AN(trc_cnt[3]), .B(n9301), .C(n9311), .D(n9329), .Y(n8773)
         );
  NAND3BX1 U5555 ( .AN(ar_cnt[3]), .B(n9014), .C(n8822), .Y(n8746) );
  INVX1 U5556 ( .A(n8860), .Y(n9014) );
  NAND4BX1 U5557 ( .AN(n9142), .B(n9143), .C(n9144), .D(n9145), .Y(n8630) );
  NAND4BX1 U5558 ( .AN(PwDnCnt[9]), .B(n9305), .C(n9316), .D(n9335), .Y(n9142)
         );
  AND4X1 U5559 ( .A(n9308), .B(n9319), .C(n9367), .D(n9337), .Y(n9143) );
  AND4X1 U5560 ( .A(n9333), .B(n9318), .C(n9306), .D(n9299), .Y(n9144) );
  NAND4BX1 U5561 ( .AN(n9447), .B(n9352), .C(ercmd[3]), .D(n8624), .Y(n8645)
         );
  NAND3BX1 U5562 ( .AN(stable_cnt[0]), .B(stable_cnt[1]), .C(n8812), .Y(n8821)
         );
  NAND3BX1 U5563 ( .AN(ar_cnt[2]), .B(n9359), .C(n9330), .Y(n8860) );
  NAND3BX1 U5564 ( .AN(ercmd[5]), .B(n9369), .C(n9321), .Y(n8627) );
  OR2X1 U5565 ( .A(tmrs_cnt[0]), .B(tmrs_cnt[1]), .Y(n8839) );
  OR2X1 U5566 ( .A(trp_cnt[0]), .B(trp_cnt[1]), .Y(n8742) );
  NAND2BX1 U5567 ( .AN(n9334), .B(stable_cnt[1]), .Y(n8803) );
  AO21X1 U5568 ( .A0(n8737), .A1(n8738), .B0(n8776), .Y(n8757) );
  OAI31X1 U5569 ( .A0(n8754), .A1(stable_cnt[0]), .A2(n9356), .B0(n8756), .Y(
        n8776) );
  INVX1 U5570 ( .A(PADDR[2]), .Y(n8878) );
  INVX1 U5571 ( .A(PADDR[3]), .Y(n8877) );
  NAND2BX1 U5572 ( .AN(trc_cnt[0]), .B(n8771), .Y(n8761) );
  NAND2BX1 U5573 ( .AN(n8508), .B(n9415), .Y(n8862) );
  NAND2X1 U5574 ( .A(n9423), .B(n8924), .Y(n8685) );
  XNOR2X1 U5575 ( .A(ras_0_ba[0]), .B(last_ba[0]), .Y(n9423) );
  OAI31X1 U5576 ( .A0(n9042), .A1(n8931), .A2(n9376), .B0(n9021), .Y(n9019) );
  NAND3BX1 U5577 ( .AN(SelfRefEn), .B(n9424), .C(n8630), .Y(n9042) );
  AO21X1 U5578 ( .A0(trc_cnt[0]), .A1(n8771), .B0(n8774), .Y(n8765) );
  OAI211X1 U5579 ( .A0(n9379), .A1(n9322), .B0(n8623), .C0(n8624), .Y(n8611)
         );
  XOR2X1 U5580 ( .A(n8614), .B(ercmd[1]), .Y(n8623) );
  OAI31X1 U5581 ( .A0(n8790), .A1(n8735), .A2(n8791), .B0(n8792), .Y(n8784) );
  NAND2BX1 U5582 ( .AN(stable_cnt[1]), .B(n9448), .Y(n8791) );
  AO21X1 U5583 ( .A0(n8735), .A1(n9356), .B0(n8789), .Y(n8792) );
  OAI222X1 U5584 ( .A0(n9019), .A1(n9333), .B0(n9021), .B1(n9380), .C0(
        PwDnCnt[0]), .C1(n9023), .Y(n8090) );
  OAI222X1 U5585 ( .A0(n8759), .A1(n9373), .B0(trc_cnt[1]), .B1(n8761), .C0(
        n8763), .C1(n9329), .Y(n8161) );
  INVX1 U5586 ( .A(n8765), .Y(n8763) );
  AO22X1 U5587 ( .A0(cmd_mask), .A1(n8853), .B0(n8854), .B1(n8855), .Y(n8150)
         );
  OA21X2 U5588 ( .A0(n8856), .A1(n8735), .B0(n9356), .Y(n8854) );
  INVX1 U5589 ( .A(n8855), .Y(n8853) );
  OAI221X1 U5590 ( .A0(n9417), .A1(n8796), .B0(n8754), .B1(n8858), .C0(n8802), 
        .Y(n8855) );
  OAI2BB1X1 U5591 ( .A0N(trc_cnt[3]), .A1N(n8766), .B0(n8772), .Y(n8159) );
  AOI32X1 U5592 ( .A0(trc_cnt[2]), .A1(trc_cnt[3]), .A2(n8771), .B0(trc[3]), 
        .B1(n8770), .Y(n8772) );
  OAI2BB1X1 U5593 ( .A0N(ar_cnt[1]), .A1N(n8981), .B0(n8982), .Y(n8096) );
  AOI32X1 U5594 ( .A0(n9330), .A1(n9359), .A2(n8984), .B0(refreshno[1]), .B1(
        n8985), .Y(n8982) );
  OAI2BB1X1 U5595 ( .A0N(trc_cnt[2]), .A1N(n8766), .B0(n8767), .Y(n8160) );
  AOI32X1 U5596 ( .A0(n9329), .A1(n9301), .A2(n8769), .B0(trc[2]), .B1(n8770), 
        .Y(n8767) );
  INVX1 U5597 ( .A(n8761), .Y(n8769) );
  INVX1 U5598 ( .A(cas_0_ba[0]), .Y(n8671) );
  AO21X1 U5599 ( .A0(trc_cnt[1]), .A1(n8771), .B0(n8765), .Y(n8766) );
  AO21X1 U5600 ( .A0(PwDnCnt564_13_), .A1(n9024), .B0(n9039), .Y(n8077) );
  AO22X1 U5601 ( .A0(PwDnCnt[13]), .A1(n9026), .B0(PwDnRef[13]), .B1(n9439), 
        .Y(n9039) );
  XNOR2X1 U1_A_13 ( .A(PwDnCnt[13]), .B(carry18), .Y(PwDnCnt564_13_) );
  AO21X1 U5602 ( .A0(PwDnCnt564_12_), .A1(n9024), .B0(n9038), .Y(n8078) );
  AO22X1 U5603 ( .A0(PwDnCnt[12]), .A1(n9026), .B0(PwDnRef[12]), .B1(n9439), 
        .Y(n9038) );
  XNOR2X1 U1_A_12 ( .A(PwDnCnt[12]), .B(carry19), .Y(PwDnCnt564_12_) );
  AO21X1 U5604 ( .A0(PwDnCnt564_11_), .A1(n9024), .B0(n9037), .Y(n8079) );
  AO22X1 U5605 ( .A0(PwDnCnt[11]), .A1(n9026), .B0(PwDnRef[11]), .B1(n9439), 
        .Y(n9037) );
  XNOR2X1 U1_A_11 ( .A(PwDnCnt[11]), .B(carry20), .Y(PwDnCnt564_11_) );
  AO21X1 U5606 ( .A0(PwDnCnt564_10_), .A1(n9024), .B0(n9036), .Y(n8080) );
  AO22X1 U5607 ( .A0(PwDnCnt[10]), .A1(n9026), .B0(PwDnRef[10]), .B1(n9439), 
        .Y(n9036) );
  XNOR2X1 U1_A_10 ( .A(PwDnCnt[10]), .B(carry21), .Y(PwDnCnt564_10_) );
  AO21X1 U5608 ( .A0(PwDnCnt564_9_), .A1(n9024), .B0(n9035), .Y(n8081) );
  AO22X1 U5609 ( .A0(PwDnCnt[9]), .A1(n9026), .B0(PwDnRef[9]), .B1(n9439), .Y(
        n9035) );
  XNOR2X1 U1_A_9 ( .A(PwDnCnt[9]), .B(carry22), .Y(PwDnCnt564_9_) );
  AO21X1 U5610 ( .A0(PwDnCnt564_8_), .A1(n9024), .B0(n9034), .Y(n8082) );
  XNOR2X1 U1_A_8 ( .A(PwDnCnt[8]), .B(carry23), .Y(PwDnCnt564_8_) );
  AO22X1 U5611 ( .A0(PwDnCnt[8]), .A1(n9026), .B0(PwDnRef[8]), .B1(n9439), .Y(
        n9034) );
  AO21X1 U5612 ( .A0(PwDnCnt564_7_), .A1(n9024), .B0(n9033), .Y(n8083) );
  XNOR2X1 U1_A_7 ( .A(PwDnCnt[7]), .B(carry24), .Y(PwDnCnt564_7_) );
  AO22X1 U5613 ( .A0(PwDnCnt[7]), .A1(n9026), .B0(PwDnRef[7]), .B1(n9439), .Y(
        n9033) );
  AO21X1 U5614 ( .A0(PwDnCnt564_6_), .A1(n9024), .B0(n9032), .Y(n8084) );
  XNOR2X1 U1_A_6 ( .A(PwDnCnt[6]), .B(carry25), .Y(PwDnCnt564_6_) );
  AO22X1 U5615 ( .A0(PwDnCnt[6]), .A1(n9026), .B0(PwDnRef[6]), .B1(n9439), .Y(
        n9032) );
  AO21X1 U5616 ( .A0(PwDnCnt564_5_), .A1(n9024), .B0(n9031), .Y(n8085) );
  XNOR2X1 U1_A_5 ( .A(PwDnCnt[5]), .B(carry26), .Y(PwDnCnt564_5_) );
  AO22X1 U5617 ( .A0(PwDnCnt[5]), .A1(n9026), .B0(PwDnRef[5]), .B1(n9439), .Y(
        n9031) );
  AO21X1 U5618 ( .A0(PwDnCnt564_4_), .A1(n9024), .B0(n9030), .Y(n8086) );
  XNOR2X1 U1_A_4 ( .A(PwDnCnt[4]), .B(carry27), .Y(PwDnCnt564_4_) );
  AO22X1 U5619 ( .A0(PwDnCnt[4]), .A1(n9026), .B0(PwDnRef[4]), .B1(n9439), .Y(
        n9030) );
  AO21X1 U5620 ( .A0(PwDnCnt564_3_), .A1(n9024), .B0(n9029), .Y(n8087) );
  XNOR2X1 U1_A_3 ( .A(PwDnCnt[3]), .B(carry28), .Y(PwDnCnt564_3_) );
  AO22X1 U5621 ( .A0(PwDnCnt[3]), .A1(n9026), .B0(PwDnRef[3]), .B1(n9439), .Y(
        n9029) );
  AO21X1 U5622 ( .A0(PwDnCnt564_2_), .A1(n9024), .B0(n9028), .Y(n8088) );
  XNOR2X1 U1_A_2 ( .A(PwDnCnt[2]), .B(carry29), .Y(PwDnCnt564_2_) );
  AO22X1 U5623 ( .A0(PwDnCnt[2]), .A1(n9026), .B0(PwDnRef[2]), .B1(n9439), .Y(
        n9028) );
  AO21X1 U5624 ( .A0(PwDnCnt564_1_), .A1(n9024), .B0(n9025), .Y(n8089) );
  XNOR2X1 U1_A_1 ( .A(PwDnCnt[1]), .B(PwDnCnt[0]), .Y(PwDnCnt564_1_) );
  AO22X1 U5625 ( .A0(PwDnCnt[1]), .A1(n9026), .B0(PwDnRef[1]), .B1(n9439), .Y(
        n9025) );
  INVX1 U5626 ( .A(cas_0_rw), .Y(n8670) );
  OA21X2 U5627 ( .A0(n8796), .A1(n8859), .B0(n8821), .Y(n8858) );
  NAND4BX1 U5628 ( .AN(n8860), .B(trc_cnt[1]), .C(n8861), .D(n8838), .Y(n8859)
         );
  AND4X1 U5629 ( .A(n9338), .B(n9311), .C(n9301), .D(n9370), .Y(n8861) );
  INVX1 U5630 ( .A(n8839), .Y(n9016) );
  INVX1 U5631 ( .A(n8794), .Y(n8781) );
  OAI211X1 U5632 ( .A0(stable_cnt[1]), .A1(n8726), .B0(n8742), .C0(n9440), .Y(
        n8794) );
  NAND2X1 U5633 ( .A(tmrs_cnt[0]), .B(n9440), .Y(n8750) );
  XOR2X1 U5634 ( .A(stable_cnt[0]), .B(n9011), .Y(n8093) );
  NAND2BX1 U5635 ( .AN(n9323), .B(tcl_1_), .Y(n8648) );
  NAND2BX1 U5636 ( .AN(rs_state_1_), .B(n9324), .Y(n8664) );
  AND2X2 U5637 ( .A(n9428), .B(n9074), .Y(n9426) );
  OAI31X1 U5638 ( .A0(n8754), .A1(stable_cnt[1]), .A2(n9334), .B0(n8756), .Y(
        n8751) );
  OR3X2 U5639 ( .A(ras_full), .B(cas_full), .C(cmd_mask), .Y(BA_STS[3]) );
  AND3X2 U5640 ( .A(n9428), .B(n9353), .C(n2828_3_), .Y(n9427) );
  OR2X1 U1_B_21 ( .A(n8503), .B(carry15), .Y(carry14) );
  OR2X1 U1_B_15 ( .A(n8504), .B(n8505), .Y(carry15) );
  AO22X1 U5641 ( .A0(n8749), .A1(tmrs_cnt[0]), .B0(n8750), .B1(n8751), .Y(
        n8164) );
  AO22X1 U5642 ( .A0(bf_last_2), .A1(n9427), .B0(bf_last_3), .B1(n9426), .Y(
        bf_last4973) );
  AO22X1 U5643 ( .A0(do_valid_2), .A1(n9427), .B0(do_valid_3), .B1(n9426), .Y(
        do_valid4691) );
  AO22X1 U5644 ( .A0(do_id_2[0]), .A1(n9427), .B0(do_id_3[0]), .B1(n9426), .Y(
        do_id4820_0_) );
  AO22X1 U5645 ( .A0(do_id_2[1]), .A1(n9427), .B0(do_id_3[1]), .B1(n9426), .Y(
        do_id4820_1_) );
  AO22X1 U5646 ( .A0(do_id_2[2]), .A1(n9427), .B0(do_id_3[2]), .B1(n9426), .Y(
        do_id4820_2_) );
  AO22X1 U5647 ( .A0(do_id_2[3]), .A1(n9427), .B0(do_id_3[3]), .B1(n9426), .Y(
        do_id4820_3_) );
  OAI2BB2X1 U5648 ( .A0N(tmrs_cnt[1]), .A1N(n8749), .B0(n9429), .B1(n8750), 
        .Y(n8163) );
  INVX1 U5649 ( .A(cas_0_ba[1]), .Y(n8666) );
  AO21X1 U5650 ( .A0(stable_cnt[2]), .A1(n9012), .B0(n8725), .Y(n8091) );
  AO21X1 U5651 ( .A0(SDREn), .A1(n9440), .B0(SDREnStatus), .Y(n8181) );
  NOR2X1 U5652 ( .A(n9430), .B(cas_pm_0), .Y(bf_last_14961) );
  INVX1 U5653 ( .A(cas_0_id[0]), .Y(n9166) );
  INVX1 U5654 ( .A(cas_0_id[1]), .Y(n9165) );
  INVX1 U5655 ( .A(cas_0_id[2]), .Y(n9164) );
  INVX1 U5656 ( .A(cas_0_id[3]), .Y(n9163) );
  DFFRX1 AddrSiz_reg_1_ ( .D(n8053), .CK(PCLK), .RN(PRESETB), .Q(n8601), .QN(
        n9339) );
  DFFRX1 AddrSiz_reg_0_ ( .D(n8054), .CK(PCLK), .RN(PRESETB), .Q(n8603), .QN(
        n9327) );
  DFFRX1 ercmd_reg_5_ ( .D(n8151), .CK(ACLK), .RN(ARESETB), .Q(ercmd[5]), .QN(
        n9375) );
  DFFRX1 tcl_reg_1_ ( .D(n8119), .CK(PCLK), .RN(PRESETB), .Q(tcl_1_), .QN(
        n9353) );
  DFFRX1 rs_state_reg_1_ ( .D(n8104), .CK(ACLK), .RN(ARESETB), .Q(rs_state_1_), 
        .QN(n9354) );
  DFFSX1 tcl_reg_0_ ( .D(n8120), .CK(PCLK), .SN(PRESETB), .Q(n2828_3_), .QN(
        n9323) );
  DFFRX1 rs_state_reg_0_ ( .D(n8105), .CK(ACLK), .RN(ARESETB), .Q(n7445), .QN(
        n9324) );
  DFFRX1 tcl_reg_2_ ( .D(n8118), .CK(PCLK), .RN(PRESETB), .Q(tcl_2_), .QN(
        n9428) );
  DFFRX1 ercmd_reg_2_ ( .D(n8154), .CK(ACLK), .RN(ARESETB), .Q(ercmd[2]), .QN(
        n9379) );
  DFFRX1 AddrSwapEn_reg ( .D(n8130), .CK(PCLK), .RN(PRESETB), .Q(AddrSwapEn), 
        .QN(n9325) );
  DFFRX1 refresh_cnt_reg_2_ ( .D(n8178), .CK(ACLK), .RN(ARESETB), .Q(n8508), 
        .QN(n9418) );
  DFFSX1 refresh_cnt_reg_5_ ( .D(n8175), .CK(ACLK), .SN(ARESETB), .Q(
        refresh_cnt_5_), .QN(n9332) );
  DFFRX1 refresh_cnt_reg_4_ ( .D(n8176), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_4_), .QN(n9363) );
  DFFRX1 refresh_cnt_reg_7_ ( .D(n8173), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_7_), .QN(n9315) );
  DFFRX1 refresh_cnt_reg_6_ ( .D(n8174), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_6_), .QN(n9362) );
  DFFRX1 refresh_cnt_reg_3_ ( .D(n8177), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_3_), .QN(n9314) );
  DFFRX1 refresh_cnt_reg_8_ ( .D(n8172), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_8_), .QN(n9304) );
  DFFRX1 rw_bstop1_reg ( .D(n8184), .CK(ACLK), .RN(ARESETB), .Q(rw_bstop1), 
        .QN(n9365) );
  DFFRX1 rw_bstop0_reg ( .D(n8183), .CK(ACLK), .RN(ARESETB), .Q(rw_bstop0), 
        .QN(n9326) );
  DFFRX1 Port16BitSel_reg ( .D(n8129), .CK(PCLK), .RN(PRESETB), .Q(n8605), 
        .QN(n9309) );
  DFFRX1 rs_state_reg_2_ ( .D(n8103), .CK(ACLK), .RN(ARESETB), .Q(rs_state_2_), 
        .QN(n9407) );
  DFFRX1 refresh_cnt_reg_1_ ( .D(n8179), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_1_), .QN(n9361) );
  DFFSX1 cmd_full_d_reg ( .D(BA_STS[3]), .CK(ACLK), .SN(ARESETB), .Q(
        cmd_full_d) );
  DFFSX1 selfref_cnt_reg_0_ ( .D(n8102), .CK(ACLK), .SN(ARESETB), .Q(n8505), 
        .QN(n9422) );
  DFFSX1 selfref_cnt_reg_1_ ( .D(n8101), .CK(ACLK), .SN(ARESETB), .Q(n8504), 
        .QN(n9328) );
  DFFSX1 stable_cnt_reg_1_ ( .D(n8092), .CK(ACLK), .SN(ARESETB), .Q(
        stable_cnt[1]), .QN(n9356) );
  DFFSX1 selfref_cnt_reg_3_ ( .D(n8099), .CK(ACLK), .SN(ARESETB), .Q(n8502), 
        .QN(n9420) );
  DFFSX1 stable_cnt_reg_0_ ( .D(n8093), .CK(ACLK), .SN(ARESETB), .Q(
        stable_cnt[0]), .QN(n9334) );
  DFFSX1 selfref_cnt_reg_4_ ( .D(n8098), .CK(ACLK), .SN(ARESETB), .Q(n8501), 
        .QN(n9358) );
  DFFRX1 refresh_cnt_reg_0_ ( .D(n8180), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt2486_0_), .QN(n9416) );
  DFFSX1 refresh_cnt_reg_11_ ( .D(n8169), .CK(ACLK), .SN(ARESETB), .Q(
        refresh_cnt_11_), .QN(n9312) );
  DFFSX1 PwDnCnt_reg_0_ ( .D(n8090), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[0]), 
        .QN(n9333) );
  DFFSX1 PwDnCnt_reg_2_ ( .D(n8088), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[2]), 
        .QN(n9308) );
  DFFSX1 PwDnCnt_reg_1_ ( .D(n8089), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[1]), 
        .QN(n9336) );
  DFFRX1 SelfRefEn_reg ( .D(n8132), .CK(PCLK), .RN(PRESETB), .Q(SelfRefEn), 
        .QN(n9414) );
  DFFRX1 refresh_cnt_reg_14_ ( .D(n8166), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_14_), .QN(n9298) );
  DFFRX1 refresh_cnt_reg_13_ ( .D(n8167), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_13_), .QN(n9313) );
  DFFRX1 refresh_cnt_reg_12_ ( .D(n8168), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_12_), .QN(n9303) );
  DFFRX1 refresh_cnt_reg_10_ ( .D(n8170), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_10_), .QN(n9302) );
  DFFRX1 refresh_cnt_reg_9_ ( .D(n8171), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_9_), .QN(n9331) );
  DFFSX1 stable_cnt_reg_2_ ( .D(n8091), .CK(ACLK), .SN(ARESETB), .Q(
        stable_cnt[2]), .QN(n9310) );
  DFFRX1 refresh_cnt_reg_15_ ( .D(n8165), .CK(ACLK), .RN(ARESETB), .Q(
        refresh_cnt_15_), .QN(n9360) );
  DFFRX1 read_bstop_reg ( .D(n8182), .CK(ACLK), .RN(ARESETB), .Q(read_bstop), 
        .QN(n9383) );
  DFFSX1 PwDnCnt_reg_9_ ( .D(n8081), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[9]), 
        .QN(n9347) );
  DFFSX1 PwDnCnt_reg_14_ ( .D(n8076), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[14]), .QN(n9317) );
  DFFSX1 PwDnCnt_reg_13_ ( .D(n8077), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[13]), .QN(n9307) );
  DFFSX1 PwDnCnt_reg_12_ ( .D(n8078), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[12]), .QN(n9299) );
  DFFSX1 PwDnCnt_reg_11_ ( .D(n8079), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[11]), .QN(n9306) );
  DFFSX1 PwDnCnt_reg_10_ ( .D(n8080), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[10]), .QN(n9318) );
  DFFSX1 PwDnCnt_reg_8_ ( .D(n8082), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[8]), 
        .QN(n9305) );
  DFFSX1 PwDnCnt_reg_7_ ( .D(n8083), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[7]), 
        .QN(n9335) );
  DFFSX1 PwDnCnt_reg_6_ ( .D(n8084), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[6]), 
        .QN(n9316) );
  DFFSX1 PwDnCnt_reg_5_ ( .D(n8085), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[5]), 
        .QN(n9337) );
  DFFSX1 PwDnCnt_reg_4_ ( .D(n8086), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[4]), 
        .QN(n9367) );
  DFFSX1 PwDnCnt_reg_3_ ( .D(n8087), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[3]), 
        .QN(n9319) );
  DFFSX1 trc_cnt_reg_1_ ( .D(n8161), .CK(ACLK), .SN(ARESETB), .Q(trc_cnt[1]), 
        .QN(n9329) );
  DFFRX1 SDREn_reg ( .D(n8131), .CK(PCLK), .RN(PRESETB), .Q(SDREn), .QN(n9368)
         );
  DFFSX1 PwDnCnt_reg_15_ ( .D(n8075), .CK(ACLK), .SN(PORESETB), .Q(PwDnCnt[15]), .QN(n9300) );
  DFFSX1 trc_cnt_reg_3_ ( .D(n8159), .CK(ACLK), .SN(ARESETB), .Q(trc_cnt[3]), 
        .QN(n9370) );
  DFFSX1 tmrs_cnt_reg_0_ ( .D(n8164), .CK(ACLK), .SN(ARESETB), .Q(tmrs_cnt[0])
         );
  DFFSX1 trp_cnt_reg_1_ ( .D(n8157), .CK(ACLK), .SN(ARESETB), .Q(trp_cnt[1])
         );
  DFFRX1 trp_cnt_reg_0_ ( .D(n8158), .CK(ACLK), .RN(ARESETB), .Q(trp_cnt[0]), 
        .QN(n9381) );
  DFFRX1 ar_cnt_reg_3_ ( .D(n8094), .CK(ACLK), .RN(ARESETB), .Q(ar_cnt[3]), 
        .QN(n9338) );
  DFFRX1 tmrs_cnt_reg_1_ ( .D(n8163), .CK(ACLK), .RN(ARESETB), .Q(tmrs_cnt[1]), 
        .QN(n9429) );
  DFFRX1 trc_cnt_reg_0_ ( .D(n8162), .CK(ACLK), .RN(ARESETB), .Q(trc_cnt[0]), 
        .QN(n9311) );
  DFFRX1 ar_cnt_reg_1_ ( .D(n8096), .CK(ACLK), .RN(ARESETB), .Q(ar_cnt[1]), 
        .QN(n9359) );
  DFFRX1 ar_cnt_reg_0_ ( .D(n8097), .CK(ACLK), .RN(ARESETB), .Q(ar_cnt[0]), 
        .QN(n9330) );
  DFFRX1 ar_cnt_reg_2_ ( .D(n8095), .CK(ACLK), .RN(ARESETB), .Q(ar_cnt[2]), 
        .QN(n9348) );
  DFFRX1 trc_cnt_reg_2_ ( .D(n8160), .CK(ACLK), .RN(ARESETB), .Q(trc_cnt[2]), 
        .QN(n9301) );
  DFFRX1 last_ba_reg_1_ ( .D(n8106), .CK(ACLK), .RN(ARESETB), .Q(last_ba[1]), 
        .QN(n9364) );
  DFFRX1 last_ba_reg_0_ ( .D(n8107), .CK(ACLK), .RN(ARESETB), .Q(last_ba[0])
         );
  DFFSX1 trp_reg_1_ ( .D(n8114), .CK(PCLK), .SN(PRESETB), .Q(trp[1]), .QN(
        n9372) );
  DFFRX1 trp_reg_0_ ( .D(n8115), .CK(PCLK), .RN(PRESETB), .Q(trp[0]), .QN(
        n9371) );
  DFFSX1 trc_reg_3_ ( .D(n8125), .CK(PCLK), .SN(PRESETB), .Q(trc[3]), .QN(
        n9393) );
  DFFRX1 refreshno_reg_0_ ( .D(n8074), .CK(PCLK), .RN(PRESETB), .Q(
        refreshno[0]), .QN(n9377) );
  DFFRX1 trefresh_reg_8_ ( .D(n8141), .CK(PCLK), .RN(PRESETB), .Q(trefresh[8]), 
        .QN(n9385) );
  DFFRX1 trefresh_reg_1_ ( .D(n8148), .CK(PCLK), .RN(PRESETB), .Q(trefresh[1]), 
        .QN(n9394) );
  DFFSX1 PwDnRef_reg_0_ ( .D(n8070), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[0]), 
        .QN(n9380) );
  DFFSX1 trc_reg_1_ ( .D(n8127), .CK(PCLK), .SN(PRESETB), .Q(trc[1]), .QN(
        n9373) );
  DFFSX1 trefresh_reg_11_ ( .D(n8138), .CK(PCLK), .SN(PRESETB), .Q(
        trefresh[11]), .QN(n9345) );
  DFFRX1 refreshno_reg_2_ ( .D(n8072), .CK(PCLK), .RN(PRESETB), .Q(
        refreshno[2]), .QN(n9378) );
  DFFRX1 trc_reg_2_ ( .D(n8126), .CK(PCLK), .RN(PRESETB), .Q(trc[2]), .QN(
        n9392) );
  DFFRX1 trc_reg_0_ ( .D(n8128), .CK(PCLK), .RN(PRESETB), .Q(trc[0]), .QN(
        n9374) );
  DFFRX1 PwDnEn_reg ( .D(n8133), .CK(PCLK), .RN(PRESETB), .Q(PwDnEn), .QN(
        n9376) );
  DFFRX1 trefresh_reg_15_ ( .D(n8134), .CK(PCLK), .RN(PRESETB), .Q(
        trefresh[15]), .QN(n9344) );
  DFFRX1 trefresh_reg_14_ ( .D(n8135), .CK(PCLK), .RN(PRESETB), .Q(
        trefresh[14]), .QN(n9343) );
  DFFRX1 trefresh_reg_13_ ( .D(n8136), .CK(PCLK), .RN(PRESETB), .Q(
        trefresh[13]), .QN(n9340) );
  DFFRX1 trefresh_reg_12_ ( .D(n8137), .CK(PCLK), .RN(PRESETB), .Q(
        trefresh[12]), .QN(n9341) );
  DFFRX1 trefresh_reg_10_ ( .D(n8139), .CK(PCLK), .RN(PRESETB), .Q(
        trefresh[10]), .QN(n9342) );
  DFFRX1 trefresh_reg_9_ ( .D(n8140), .CK(PCLK), .RN(PRESETB), .Q(trefresh[9]), 
        .QN(n9320) );
  DFFRX1 trefresh_reg_0_ ( .D(n8149), .CK(PCLK), .RN(PRESETB), .Q(trefresh[0]), 
        .QN(n9346) );
  DFFRX1 SDREnStatus_reg ( .D(n8181), .CK(ACLK), .RN(ARESETB), .Q(SDREnStatus), 
        .QN(n9382) );
  DFFSX1 cmd_mask_reg ( .D(n8150), .CK(ACLK), .SN(ARESETB), .Q(cmd_mask) );
  DFFRX1 refreshno_reg_3_ ( .D(n8071), .CK(PCLK), .RN(PRESETB), .Q(
        refreshno[3]) );
  DFFRX1 refreshno_reg_1_ ( .D(n8073), .CK(PCLK), .RN(PRESETB), .Q(
        refreshno[1]) );
  DFFSX1 trcd_reg_1_ ( .D(n8116), .CK(PCLK), .SN(PRESETB), .Q(trcd[1]), .QN(
        n9350) );
  DFFSX1 trasmin_reg_0_ ( .D(n8124), .CK(PCLK), .SN(PRESETB), .Q(trasmin[0]), 
        .QN(n9351) );
  DFFSX1 trasmin_reg_2_ ( .D(n8122), .CK(PCLK), .SN(PRESETB), .Q(trasmin[2]), 
        .QN(n9391) );
  DFFSX1 trasmin_reg_1_ ( .D(n8123), .CK(PCLK), .SN(PRESETB), .Q(trasmin[1]), 
        .QN(n9390) );
  DFFRX1 trcd_reg_0_ ( .D(n8117), .CK(PCLK), .RN(PRESETB), .Q(trcd[0]), .QN(
        n9349) );
  DFFRX1 trasmin_reg_3_ ( .D(n8121), .CK(PCLK), .RN(PRESETB), .Q(trasmin[3]), 
        .QN(n9384) );
  DFFSX1 trefresh_reg_5_ ( .D(n8144), .CK(PCLK), .SN(PRESETB), .Q(trefresh[5]), 
        .QN(n9396) );
  DFFRX1 trefresh_reg_7_ ( .D(n8142), .CK(PCLK), .RN(PRESETB), .Q(trefresh[7]), 
        .QN(n9389) );
  DFFRX1 trefresh_reg_6_ ( .D(n8143), .CK(PCLK), .RN(PRESETB), .Q(trefresh[6]), 
        .QN(n9388) );
  DFFRX1 trefresh_reg_4_ ( .D(n8145), .CK(PCLK), .RN(PRESETB), .Q(trefresh[4]), 
        .QN(n9395) );
  DFFRX1 trefresh_reg_3_ ( .D(n8146), .CK(PCLK), .RN(PRESETB), .Q(trefresh[3]), 
        .QN(n9387) );
  DFFRX1 trefresh_reg_2_ ( .D(n8147), .CK(PCLK), .RN(PRESETB), .Q(trefresh[2]), 
        .QN(n9386) );
  DFFRX1 cas_pm_0_reg ( .D(n8185), .CK(ACLK), .RN(ARESETB), .Q(cas_pm_0) );
  DFFSX1 PwDnRef_reg_15_ ( .D(n8055), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[15])
         );
  DFFSX1 PwDnRef_reg_14_ ( .D(n8056), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[14])
         );
  DFFSX1 PwDnRef_reg_13_ ( .D(n8057), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[13])
         );
  DFFSX1 PwDnRef_reg_12_ ( .D(n8058), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[12])
         );
  DFFSX1 PwDnRef_reg_11_ ( .D(n8059), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[11])
         );
  DFFSX1 PwDnRef_reg_10_ ( .D(n8060), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[10])
         );
  DFFSX1 PwDnRef_reg_9_ ( .D(n8061), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[9])
         );
  DFFSX1 PwDnRef_reg_8_ ( .D(n8062), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[8])
         );
  DFFSX1 PwDnRef_reg_7_ ( .D(n8063), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[7])
         );
  DFFSX1 PwDnRef_reg_6_ ( .D(n8064), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[6])
         );
  DFFSX1 PwDnRef_reg_5_ ( .D(n8065), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[5])
         );
  DFFSX1 PwDnRef_reg_4_ ( .D(n8066), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[4])
         );
  DFFSX1 PwDnRef_reg_3_ ( .D(n8067), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[3])
         );
  DFFSX1 PwDnRef_reg_2_ ( .D(n8068), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[2])
         );
  DFFSX1 PwDnRef_reg_1_ ( .D(n8069), .CK(PCLK), .SN(PRESETB), .Q(PwDnRef[1])
         );
  DFFRX1 do_id_0_reg_3_ ( .D(n8108), .CK(ACLK), .RN(ARESETB), .Q(do_id_0[3])
         );
  DFFRX1 do_id_0_reg_2_ ( .D(n8109), .CK(ACLK), .RN(ARESETB), .Q(do_id_0[2])
         );
  DFFRX1 do_id_0_reg_1_ ( .D(n8110), .CK(ACLK), .RN(ARESETB), .Q(do_id_0[1])
         );
  DFFRX1 do_id_0_reg_0_ ( .D(n8111), .CK(ACLK), .RN(ARESETB), .Q(do_id_0[0])
         );
  DFFRX1 bf_last_2_reg ( .D(bf_last_1), .CK(ACLK), .RN(ARESETB), .Q(bf_last_2)
         );
  DFFRX1 do_valid_2_reg ( .D(do_valid_1), .CK(ACLK), .RN(ARESETB), .Q(
        do_valid_2) );
  DFFRX1 do_id_2_reg_0_ ( .D(do_id_1[0]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_2[0]) );
  DFFRX1 do_id_2_reg_1_ ( .D(do_id_1[1]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_2[1]) );
  DFFRX1 do_id_2_reg_2_ ( .D(do_id_1[2]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_2[2]) );
  DFFRX1 do_id_2_reg_3_ ( .D(do_id_1[3]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_2[3]) );
  DFFRX1 iSD_BADDR_reg_0_ ( .D(n8113), .CK(ACLK), .RN(ARESETB), .Q(
        iSD_BADDR[0]) );
  DFFRX1 iSD_ADDR_reg_9_ ( .D(n8189), .CK(ACLK), .RN(ARESETB), .Q(iSD_ADDR[9])
         );
  DFFRX1 iSD_ADDR_reg_8_ ( .D(n8190), .CK(ACLK), .RN(ARESETB), .Q(iSD_ADDR[8])
         );
  DFFRX1 iSD_ADDR_reg_7_ ( .D(n8191), .CK(ACLK), .RN(ARESETB), .Q(iSD_ADDR[7])
         );
  DFFRX1 iSD_ADDR_reg_3_ ( .D(n8195), .CK(ACLK), .RN(ARESETB), .Q(iSD_ADDR[3])
         );
  DFFRX1 iSD_ADDR_reg_10_ ( .D(n8188), .CK(ACLK), .RN(ARESETB), .Q(
        iSD_ADDR[10]) );
  DFFRX1 iSD_ADDR_reg_6_ ( .D(n8192), .CK(ACLK), .RN(ARESETB), .Q(iSD_ADDR[6])
         );
  DFFRX1 iSD_ADDR_reg_5_ ( .D(n8193), .CK(ACLK), .RN(ARESETB), .Q(iSD_ADDR[5])
         );
  DFFRX1 iSD_ADDR_reg_4_ ( .D(n8194), .CK(ACLK), .RN(ARESETB), .Q(iSD_ADDR[4])
         );
  DFFRX1 iSD_ADDR_reg_2_ ( .D(n8196), .CK(ACLK), .RN(ARESETB), .Q(iSD_ADDR[2])
         );
  DFFRX1 iSD_ADDR_reg_1_ ( .D(n8197), .CK(ACLK), .RN(ARESETB), .Q(iSD_ADDR[1])
         );
  DFFRX1 iSD_ADDR_reg_0_ ( .D(n8198), .CK(ACLK), .RN(ARESETB), .Q(iSD_ADDR[0])
         );
  DFFRX1 bf_last_3_reg ( .D(bf_last_2), .CK(ACLK), .RN(ARESETB), .Q(bf_last_3)
         );
  DFFRX1 do_valid_3_reg ( .D(do_valid_2), .CK(ACLK), .RN(ARESETB), .Q(
        do_valid_3) );
  DFFRX1 do_id_3_reg_0_ ( .D(do_id_2[0]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_3[0]) );
  DFFRX1 do_id_3_reg_1_ ( .D(do_id_2[1]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_3[1]) );
  DFFRX1 do_id_3_reg_2_ ( .D(do_id_2[2]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_3[2]) );
  DFFRX1 do_id_3_reg_3_ ( .D(do_id_2[3]), .CK(ACLK), .RN(ARESETB), .Q(
        do_id_3[3]) );
  DFFRX1 bf_last_0_reg ( .D(bf_last_04967), .CK(ACLK), .RN(ARESETB), .QN(n9430) );
  DFFRX1 iSD_ADDR_reg_12_ ( .D(n8186), .CK(ACLK), .RN(ARESETB), .Q(
        iSD_ADDR[12]) );
  DFFRX1 iSD_ADDR_reg_11_ ( .D(n8187), .CK(ACLK), .RN(ARESETB), .Q(
        iSD_ADDR[11]) );
  DFFRX1 iSD_BADDR_reg_1_ ( .D(n8112), .CK(ACLK), .RN(ARESETB), .Q(
        iSD_BADDR[1]), .QN(n9294) );
  NOR2X1 U5657 ( .A(refresh_cnt_14_), .B(n9408), .Y(n6) );
  XNOR2X1 U5658 ( .A(n9408), .B(refresh_cnt_14_), .Y(refresh_cnt2486_14_) );
  XNOR2X1 U5659 ( .A(n9409), .B(refresh_cnt_13_), .Y(refresh_cnt2486_13_) );
  XNOR2X1 U5660 ( .A(n9410), .B(refresh_cnt_12_), .Y(refresh_cnt2486_12_) );
  XNOR2X1 U5661 ( .A(n9411), .B(refresh_cnt_11_), .Y(refresh_cnt2486_11_) );
  XNOR2X1 U5662 ( .A(n9412), .B(refresh_cnt_10_), .Y(refresh_cnt2486_10_) );
  XNOR2X1 U5663 ( .A(carry_9_), .B(refresh_cnt_9_), .Y(refresh_cnt2486_9_) );
  XOR2X1 U5664 ( .A(n9364), .B(ras_0_ba[1]), .Y(n8924) );
  OA21X1 U5665 ( .A0(n8916), .A1(n8660), .B0(n8917), .Y(n8913) );
  AO22X1 U5666 ( .A0(ras_0_ra[7]), .A1(n9441), .B0(cas_0_ca[7]), .B1(n8606), 
        .Y(n8651) );
  OA21X1 U5667 ( .A0(n8682), .A1(n8684), .B0(n8609), .Y(n8678) );
  NAND3BX2 U5668 ( .AN(n9186), .B(n8891), .C(n8893), .Y(n9099) );
  AO22X1 U5669 ( .A0(ras_0_ra[8]), .A1(n9441), .B0(cas_0_ca[8]), .B1(n8606), 
        .Y(n8652) );
  AOI222X1 U5670 ( .A0(BA_AA[24]), .A1(n9204), .B0(n9205), .B1(BA_AA[19]), 
        .C0(BA_AA[23]), .C1(n9206), .Y(n9250) );
  INVX3 U5671 ( .A(n8916), .Y(n9053) );
  NAND2BX1 U5672 ( .AN(ecmd_1_), .B(n8896), .Y(n8634) );
  AND4X1 U5673 ( .A(bf_1reqcmd[4]), .B(n8893), .C(n9094), .D(n9060), .Y(
        bf_1cmd[4]) );
  AO22X1 U5674 ( .A0(ras_0_ra[12]), .A1(n9441), .B0(iSD_ADDR[12]), .B1(n8650), 
        .Y(n8186) );
  NOR2BX1 U5675 ( .AN(bf_0reqcmd[1]), .B(n9062), .Y(bf_0cmd[1]) );
  NOR3BX1 U5676 ( .AN(bf_0reqcmd[2]), .B(n9062), .C(n9063), .Y(bf_0cmd[2]) );
  NAND2BX1 U5677 ( .AN(n9062), .B(n9097), .Y(n9087) );
  NAND3BX1 U5678 ( .AN(n9062), .B(n9095), .C(n9096), .Y(n9093) );
  NAND2BX2 U5679 ( .AN(n9062), .B(n9399), .Y(n9092) );
  AO22X1 U5680 ( .A0(ras_0_ra[11]), .A1(n9441), .B0(iSD_ADDR[11]), .B1(n8650), 
        .Y(n8187) );
  NAND3BX1 U5681 ( .AN(n8734), .B(n8681), .C(n9443), .Y(n8733) );
  NAND2BX1 U5682 ( .AN(n8918), .B(n9296), .Y(n8656) );
  NAND2BX1 U5683 ( .AN(n9099), .B(n9296), .Y(n9098) );
  NAND2BX1 U5684 ( .AN(n8922), .B(n9060), .Y(n8684) );
  NAND2BX1 U5685 ( .AN(n8672), .B(n9296), .Y(n9072) );
  AO21X1 U5686 ( .A0(n9054), .A1(n9169), .B0(n9406), .Y(n8930) );
  OA21X1 U5687 ( .A0(n8922), .A1(n8685), .B0(n8912), .Y(n8919) );
  NOR2BX1 U5688 ( .AN(bf_0reqcmd[3]), .B(n9092), .Y(bf_0cmd[3]) );
  NOR3BX1 U5689 ( .AN(bf_0reqcmd[4]), .B(n9092), .C(n9100), .Y(bf_0cmd[4]) );
  NOR3BX1 U5690 ( .AN(bf_1reqcmd[3]), .B(n9092), .C(bf_0reqcmd[3]), .Y(
        bf_1cmd[3]) );
  AO22X1 U5691 ( .A0(n8935), .A1(n9054), .B0(n9055), .B1(n9402), .Y(n8929) );
  NAND2BX1 U5692 ( .AN(n8912), .B(n9060), .Y(n8681) );
  NAND3BX1 U5693 ( .AN(n8935), .B(n9054), .C(n8918), .Y(n8915) );
endmodule


module SDRBsm_3 ( ARESETB, ACLK, TRP, TRRD, TRCD, TRASMIN, BA_BA, BA_RA, BA_TT, 
        BA_REQ, CAS_0_BA, CAS_0_RA, CAS_0_TT, CAS_0_FINAL, CAS_0_NEWROW, 
        CAS_EMPTY, LAST_RA, RAS_0_BA, RAS_0_RA, RAS_0_TT, RAS_EMPTY, BF_NO, 
        BF_CASBUSY, BF_TCASBUSY, BF_RASBUSY, BF_TRASBUSY, BF_READY, BF_TREADY, 
        BF_IDLE, BF_LAST, BF_REQCMD, BF_CMD, ERCMD, ECMD );
  input [1:0] TRP;
  input [1:0] TRRD;
  input [1:0] TRCD;
  input [3:0] TRASMIN;
  input [1:0] BA_BA;
  input [12:0] BA_RA;
  input [4:0] BA_TT;
  input [1:0] CAS_0_BA;
  input [12:0] CAS_0_RA;
  input [4:0] CAS_0_TT;
  input [13:0] LAST_RA;
  input [1:0] RAS_0_BA;
  input [12:0] RAS_0_RA;
  input [4:0] RAS_0_TT;
  input [1:0] BF_NO;
  output [5:0] BF_REQCMD;
  input [5:0] BF_CMD;
  input [5:0] ERCMD;
  input [6:0] ECMD;
  input ARESETB, ACLK, BA_REQ, CAS_0_FINAL, CAS_0_NEWROW, CAS_EMPTY, RAS_EMPTY,
         BF_TCASBUSY, BF_TRASBUSY, BF_TREADY;
  output BF_CASBUSY, BF_RASBUSY, BF_READY, BF_IDLE, BF_LAST;
  wire   cbs_pcing, cbs_rowopen, cbs_rasing, cbs_casing, cas_0_final_l,
         cas_0_newrow_l, newrowenable, trrd_cnt_1_, trrd_cnt_0_, length749_4_,
         length749_3_, length749_2_, length749_1_, newrowexist, n2590, n2591,
         n2592, n2593, n2594, n2595, n2596, n2597, n2598, n2599, n2600, n2601,
         n2602, n2603, n2604, n2605, n2606, n2607, n2608, n2609, n2610, n2611,
         n2612, n2613, n2614, n2615, n2616, n2617, n2618, n2619, n2620, n2621,
         carry_4_, carry_3_, carry_2_, n2636, n2637, n2638, n2640, n2641,
         n2643, n2644, n2645, n2647, n2648, n2649, n2650, n2651, n2652, n2653,
         n2654, n2655, n2656, n2657, n2658, n2659, n2660, n2661, n2662, n2663,
         n2666, n2667, n2668, n2670, n2671, n2672, n2674, n2675, n2676, n2677,
         n2678, n2679, n2681, n2682, n2683, n2684, n2685, n2686, n2688, n2689,
         n2690, n2691, n2692, n2693, n2695, n2697, n2698, n2699, n2700, n2701,
         n2702, n2703, n2704, n2705, n2706, n2707, n2709, n2711, n2712, n2713,
         n2714, n2715, n2716, n2717, n2718, n2719, n2720, n2721, n2722, n2723,
         n2724, n2725, n2726, n2727, n2730, n2731, n2732, n2733, n2734, n2736,
         n2737, n2738, n2740, n2741, n2743, n2744, n2745, n2746, n2751, n2753,
         n2754, n2756, n2757, n2758, n2759, n2760, n2761, n2762, n2765, n2766,
         n2767, n2768, n2769, n2771, n2772, n2773, n2774, n2775, n2776, n2777,
         n2778, n2779, n2780, n2781, n2782, n2785, n2788, n2789, n2790, n2791,
         n2792, n2793, n2795, n2796, n2797, n2798, n2800, n2801, n2802, n2803,
         n2805, n2806, n2808, n2809, n2810, n2811, n2812, n2813, n2814, n2816,
         n2818, n2819, n2820, n2821, n2822, n2823, n2824, n2827, n2828, n2829,
         n2830, n2831, n2832, n2833, n2834, n2835, n2836, n2837, n2838, n2839,
         n2840, n2844, n2845, n2846, n2847, n2848, n2849, n2850, n2853, n2854,
         n2855, n2856, n2858, n2859, n2860, n2861, n2862, n2865, n2866, n2867,
         n2870, n2871, n2872, n2876, n2879, n2880, n2884, n2887, n2888, n2889,
         n2890, n2891, n2892, n2893, n2894, n2895, n2896, n2897, n2898, n2899,
         n2900, n2901, n2902, n2903, n2904, n2905, n2906, n2907, n2908, n2909,
         n2910, n2911, n2912, n2913, n2914, n2915, n2916, n2917, n2918, n2919,
         n2920, n2921, n2922, n2923, n2924, n2925;
  wire   [4:0] length;
  wire   [12:0] openedrow;
  wire   [3:0] trasmin_cnt;
  wire   [4:0] nextstate;
  wire   [1:0] trcd_cnt;
  wire   [1:0] trp_cnt;

  OAI32X4 U1261 ( .A0(n2910), .A1(n2919), .A2(n2835), .B0(n2836), .B1(n2837), 
        .Y(n2654) );
  NAND2BX4 U1313 ( .AN(n2659), .B(n2919), .Y(n2836) );
  NAND3BX2 U1346 ( .AN(n2860), .B(n2861), .C(n2862), .Y(n2845) );
  NAND3BX2 U1347 ( .AN(n2865), .B(n2866), .C(n2867), .Y(n2844) );
  XOR2X1 U1348 ( .A(n2872), .B(RAS_0_BA[0]), .Y(n2871) );
  NAND3BX1 U1349 ( .AN(n2655), .B(n2922), .C(n2672), .Y(n2688) );
  NAND3BX2 U1350 ( .AN(n2848), .B(n2849), .C(n2850), .Y(n2847) );
  NAND4BX1 U1351 ( .AN(n2853), .B(n2854), .C(n2855), .D(n2856), .Y(n2846) );
  INVX1 U1352 ( .A(n2691), .Y(BF_REQCMD[0]) );
  NAND3BX1 U1353 ( .AN(n2637), .B(n2666), .C(n2922), .Y(n2827) );
  OR2X1 U1354 ( .A(n2701), .B(n2827), .Y(n2691) );
  AO22X1 U1355 ( .A0(n2919), .A1(n2836), .B0(n2663), .B1(n2837), .Y(n2652) );
  OR2X1 U1356 ( .A(trasmin_cnt[0]), .B(trasmin_cnt[1]), .Y(n2798) );
  INVX1 U1357 ( .A(n2652), .Y(n2637) );
  INVX1 U1358 ( .A(n2654), .Y(n2834) );
  NAND4BX1 U1359 ( .AN(BF_TRASBUSY), .B(n2894), .C(n2887), .D(n2835), .Y(n2643) );
  INVX1 U1360 ( .A(n2659), .Y(n2835) );
  INVX3 U1361 ( .A(n2846), .Y(n2912) );
  INVX3 U1362 ( .A(n2847), .Y(n2913) );
  INVX3 U1363 ( .A(n2686), .Y(BF_REQCMD[5]) );
  NAND4BBX2 U1364 ( .AN(n2844), .BN(n2845), .C(n2912), .D(n2913), .Y(n2837) );
  AND2X1 U1365 ( .A(BF_CASBUSY), .B(n2704), .Y(n2914) );
  XOR2X1 U1366 ( .A(n2858), .B(CAS_0_RA[12]), .Y(n2855) );
  XOR2X1 U1367 ( .A(n2859), .B(CAS_0_RA[10]), .Y(n2854) );
  OR3X2 U1368 ( .A(n2876), .B(CAS_0_TT[1]), .C(CAS_0_TT[0]), .Y(n2667) );
  NAND4BX1 U1369 ( .AN(n2776), .B(n2777), .C(n2778), .D(n2779), .Y(n2773) );
  OAI2BB2X1 U1370 ( .A0N(n2697), .A1N(n2698), .B0(n2698), .B1(n2910), .Y(n2619) );
  AND4X1 U1371 ( .A(n2719), .B(n2720), .C(n2721), .D(n2722), .Y(n2718) );
  OAI2BB1X1 U1372 ( .A0N(n2816), .A1N(n2780), .B0(n2775), .Y(n2811) );
  AND2X1 U1373 ( .A(trrd_cnt_1_), .B(trrd_cnt_0_), .Y(n2806) );
  OR3X1 U1374 ( .A(ECMD[4]), .B(ECMD[6]), .C(ERCMD[1]), .Y(n2821) );
  INVX1 U1375 ( .A(BF_CMD[4]), .Y(n2684) );
  NAND3BX1 U1376 ( .AN(n2818), .B(n2809), .C(n2819), .Y(n2775) );
  XOR2X1 U1377 ( .A(BF_CMD[5]), .B(BF_CMD[2]), .Y(n2819) );
  NAND3BX1 U1378 ( .AN(n2788), .B(n2789), .C(n2790), .Y(n2704) );
  NAND3BX1 U1379 ( .AN(BF_CMD[5]), .B(n2791), .C(n2792), .Y(n2788) );
  INVX1 U1380 ( .A(BF_CMD[2]), .Y(n2791) );
  INVX1 U1381 ( .A(BF_CMD[3]), .Y(n2792) );
  INVX1 U1382 ( .A(n2925), .Y(n2782) );
  XOR2X1 U1383 ( .A(n2691), .B(BF_CMD[0]), .Y(n2690) );
  INVX1 U1384 ( .A(BF_CMD[0]), .Y(n2809) );
  NOR2BX1 U1385 ( .AN(n2701), .B(n2827), .Y(BF_REQCMD[4]) );
  INVX1 U1386 ( .A(BF_CMD[1]), .Y(n2789) );
  INVX1 U1387 ( .A(BA_RA[9]), .Y(n2769) );
  INVX1 U1388 ( .A(BA_RA[3]), .Y(n2736) );
  INVX1 U1389 ( .A(BA_RA[7]), .Y(n2744) );
  INVX1 U1390 ( .A(BA_RA[8]), .Y(n2772) );
  INVX3 U1391 ( .A(n2688), .Y(BF_REQCMD[2]) );
  INVX1 U1392 ( .A(BA_RA[11]), .Y(n2734) );
  BUFX2 U1393 ( .A(n2781), .Y(n2925) );
  NAND3BX1 U1394 ( .AN(n2808), .B(n2809), .C(n2810), .Y(n2781) );
  NAND3BX1 U1395 ( .AN(BF_CMD[5]), .B(n2791), .C(n2684), .Y(n2808) );
  XOR2X1 U1396 ( .A(BF_CMD[3]), .B(BF_CMD[1]), .Y(n2810) );
  XNOR2X1 U1397 ( .A(n2688), .B(BF_CMD[2]), .Y(n2911) );
  INVX1 U1398 ( .A(BA_RA[12]), .Y(n2733) );
  INVX1 U1399 ( .A(n2836), .Y(n2663) );
  INVX1 U1400 ( .A(n2692), .Y(n2693) );
  INVX1 U1401 ( .A(BF_TCASBUSY), .Y(n2666) );
  XOR2X1 U1402 ( .A(n2686), .B(BF_CMD[5]), .Y(n2685) );
  INVX1 U1403 ( .A(BA_RA[0]), .Y(n2723) );
  NAND4BX1 U1404 ( .AN(n2683), .B(n2684), .C(BF_CMD[3]), .D(n2685), .Y(n2682)
         );
  XOR2X1 U1405 ( .A(BF_CMD[1]), .B(BF_REQCMD[1]), .Y(n2689) );
  NAND2BX1 U1406 ( .AN(n2923), .B(n2695), .Y(n2692) );
  NAND3BX1 U1407 ( .AN(n2641), .B(n2666), .C(n2667), .Y(n2636) );
  INVX1 U1408 ( .A(n2785), .Y(n2695) );
  INVX1 U1409 ( .A(n2683), .Y(BF_REQCMD[3]) );
  INVX1 U1410 ( .A(n2667), .Y(n2701) );
  OAI33X1 U1411 ( .A0(n2641), .A1(n2891), .A2(n2643), .B0(n2644), .B1(n2645), 
        .B2(n2901), .Y(nextstate[3]) );
  INVX1 U1412 ( .A(n2647), .Y(n2645) );
  INVX1 U1413 ( .A(n2643), .Y(n2676) );
  OAI32X1 U1414 ( .A0(n2705), .A1(n2706), .A2(n2707), .B0(n2893), .B1(n2709), 
        .Y(n2618) );
  INVX1 U1415 ( .A(n2697), .Y(n2706) );
  INVX1 U1416 ( .A(n2709), .Y(n2705) );
  OAI221X1 U1417 ( .A0(n2651), .A1(n2906), .B0(n2711), .B1(n2923), .C0(n2712), 
        .Y(n2709) );
  NAND4X1 U1418 ( .A(BF_TREADY), .B(n2671), .C(n2922), .D(n2910), .Y(n2686) );
  INVX1 U1419 ( .A(n2655), .Y(n2662) );
  INVX1 U1420 ( .A(n2801), .Y(n2793) );
  NAND2BX1 U1421 ( .AN(n2782), .B(n2655), .Y(n2801) );
  INVX1 U1422 ( .A(n2798), .Y(n2796) );
  INVX1 U1423 ( .A(n2678), .Y(n2641) );
  OAI33X1 U1424 ( .A0(n2679), .A1(n2911), .A2(n2681), .B0(n2679), .B1(n2682), 
        .B2(n2911), .Y(n2678) );
  NAND4BX1 U1425 ( .AN(BF_CMD[3]), .B(n2684), .C(n2685), .D(n2683), .Y(n2681)
         );
  NAND2BX1 U1426 ( .AN(n2689), .B(n2690), .Y(n2679) );
  INVX1 U1427 ( .A(n2699), .Y(n2711) );
  INVX1 U1428 ( .A(n2657), .Y(n2671) );
  INVX1 U1429 ( .A(n2811), .Y(n2813) );
  INVX1 U1430 ( .A(n2884), .Y(BF_LAST) );
  NAND2BX1 U1431 ( .AN(n2907), .B(n2924), .Y(n2884) );
  INVX1 U1432 ( .A(ERCMD[2]), .Y(n2778) );
  INVX1 U1433 ( .A(n2651), .Y(n2703) );
  NAND4BX1 U1434 ( .AN(n2643), .B(n2828), .C(n2829), .D(BF_IDLE), .Y(n2683) );
  AND4X1 U1435 ( .A(n2830), .B(n2831), .C(n2832), .D(n2833), .Y(n2829) );
  INVX1 U1436 ( .A(RAS_0_TT[1]), .Y(n2830) );
  INVX1 U1437 ( .A(RAS_0_TT[4]), .Y(n2833) );
  NAND3BX1 U1438 ( .AN(CAS_0_TT[4]), .B(n2879), .C(n2880), .Y(n2876) );
  XNOR2X1 U1439 ( .A(RAS_0_RA[11]), .B(CAS_0_RA[11]), .Y(n2856) );
  NAND2BX1 U1440 ( .AN(trasmin_cnt[3]), .B(n2915), .Y(n2655) );
  INVX1 U1441 ( .A(n2714), .Y(n2707) );
  NAND4BX1 U1442 ( .AN(n2715), .B(n2716), .C(n2717), .D(n2718), .Y(n2714) );
  AOI221X1 U1443 ( .A0(LAST_RA[6]), .A1(n2889), .B0(LAST_RA[7]), .B1(n2904), 
        .C0(n2756), .Y(n2716) );
  AOI221X1 U1444 ( .A0(LAST_RA[8]), .A1(n2888), .B0(LAST_RA[9]), .B1(n2905), 
        .C0(n2751), .Y(n2717) );
  XNOR2X1 U1445 ( .A(RAS_0_RA[2]), .B(CAS_0_RA[2]), .Y(n2850) );
  XNOR2X1 U1446 ( .A(RAS_0_RA[8]), .B(CAS_0_RA[8]), .Y(n2862) );
  XNOR2X1 U1447 ( .A(RAS_0_RA[4]), .B(CAS_0_RA[4]), .Y(n2866) );
  XNOR2X1 U1448 ( .A(RAS_0_RA[1]), .B(CAS_0_RA[1]), .Y(n2849) );
  XNOR2X1 U1449 ( .A(RAS_0_RA[7]), .B(CAS_0_RA[7]), .Y(n2861) );
  NAND2BX1 U1450 ( .AN(length[0]), .B(n2924), .Y(BF_CASBUSY) );
  NAND3BX2 U1451 ( .AN(RAS_EMPTY), .B(n2870), .C(n2871), .Y(n2659) );
  XOR2X1 U1452 ( .A(RAS_0_RA[6]), .B(CAS_0_RA[6]), .Y(n2865) );
  XOR2X1 U1453 ( .A(RAS_0_RA[3]), .B(CAS_0_RA[3]), .Y(n2848) );
  XOR2X1 U1454 ( .A(RAS_0_RA[9]), .B(CAS_0_RA[9]), .Y(n2860) );
  AND2X2 U1455 ( .A(n2916), .B(n2796), .Y(n2915) );
  OAI32X1 U1456 ( .A0(n2820), .A1(n2821), .A2(n2822), .B0(ERCMD[5]), .B1(n2823), .Y(n2780) );
  INVX1 U1457 ( .A(ERCMD[1]), .Y(n2823) );
  OR2X1 U1458 ( .A(ECMD[3]), .B(ECMD[2]), .Y(n2822) );
  XOR2X1 U1459 ( .A(RAS_0_RA[0]), .B(CAS_0_RA[0]), .Y(n2853) );
  NAND3X1 U1460 ( .A(n2917), .B(n2753), .C(BA_REQ), .Y(n2751) );
  XNOR2X1 U1461 ( .A(BF_NO[0]), .B(BA_BA[0]), .Y(n2917) );
  NAND3BX1 U1462 ( .AN(n2760), .B(n2761), .C(n2762), .Y(n2715) );
  AOI221X1 U1463 ( .A0(LAST_RA[1]), .A1(n2892), .B0(LAST_RA[2]), .B1(n2918), 
        .C0(n2765), .Y(n2762) );
  OAI222X1 U1464 ( .A0(LAST_RA[8]), .A1(n2772), .B0(LAST_RA[7]), .B1(n2744), 
        .C0(BA_RA[8]), .C1(n2888), .Y(n2760) );
  AOI222X1 U1465 ( .A0(openedrow[9]), .A1(n2769), .B0(LAST_RA[0]), .B1(n2896), 
        .C0(BA_RA[9]), .C1(n2771), .Y(n2761) );
  NAND2BX1 U1466 ( .AN(trrd_cnt_0_), .B(n2895), .Y(BF_RASBUSY) );
  INVX1 U1467 ( .A(RAS_0_TT[0]), .Y(n2828) );
  INVX1 U1468 ( .A(RAS_0_TT[3]), .Y(n2832) );
  INVX1 U1469 ( .A(RAS_0_TT[2]), .Y(n2831) );
  INVX1 U1470 ( .A(CAS_0_TT[2]), .Y(n2880) );
  INVX1 U1471 ( .A(CAS_0_TT[3]), .Y(n2879) );
  XNOR2X1 U1472 ( .A(RAS_0_RA[5]), .B(CAS_0_RA[5]), .Y(n2867) );
  OAI22X1 U1473 ( .A0(n2740), .A1(LAST_RA[2]), .B0(n2918), .B1(BA_RA[2]), .Y(
        n2738) );
  INVX1 U1474 ( .A(BA_RA[2]), .Y(n2740) );
  AO21X1 U1475 ( .A0(n2662), .A1(cbs_rowopen), .B0(BF_IDLE), .Y(BF_READY) );
  AOI211X1 U1476 ( .A0(openedrow[3]), .A1(n2736), .B0(n2737), .C0(n2738), .Y(
        n2720) );
  AOI221X1 U1477 ( .A0(BA_RA[6]), .A1(n2743), .B0(openedrow[7]), .B1(n2744), 
        .C0(n2745), .Y(n2719) );
  AOI211X1 U1478 ( .A0(openedrow[0]), .A1(n2723), .B0(n2724), .C0(n2725), .Y(
        n2722) );
  AOI221X1 U1479 ( .A0(openedrow[1]), .A1(n2730), .B0(BA_RA[1]), .B1(n2731), 
        .C0(n2732), .Y(n2721) );
  INVX1 U1480 ( .A(LAST_RA[1]), .Y(n2731) );
  INVX1 U1481 ( .A(BA_RA[1]), .Y(n2730) );
  OAI222X1 U1482 ( .A0(LAST_RA[12]), .A1(n2733), .B0(LAST_RA[11]), .B1(n2734), 
        .C0(BA_RA[12]), .C1(n2897), .Y(n2732) );
  OAI2BB1X1 U1483 ( .A0N(cbs_rowopen), .A1N(n2699), .B0(n2700), .Y(n2698) );
  AOI32X1 U1484 ( .A0(n2701), .A1(CAS_0_NEWROW), .A2(n2702), .B0(
        cas_0_newrow_l), .B1(n2703), .Y(n2700) );
  NOR3X2 U1485 ( .A(CAS_EMPTY), .B(n2920), .C(n2921), .Y(n2919) );
  XNOR2X1 U1486 ( .A(n2754), .B(CAS_0_BA[1]), .Y(n2920) );
  XNOR2X1 U1487 ( .A(n2872), .B(CAS_0_BA[0]), .Y(n2921) );
  NOR2X1 U1488 ( .A(BF_IDLE), .B(n2923), .Y(n2922) );
  NOR4X1 U1489 ( .A(length[4]), .B(length[3]), .C(length[1]), .D(length[2]), 
        .Y(n2924) );
  AOI211X1 U1490 ( .A0(n2654), .A1(n2655), .B0(n2641), .C0(n2656), .Y(n2653)
         );
  OAI31X1 U1491 ( .A0(n2657), .A1(newrowexist), .A2(BF_TREADY), .B0(n2658), 
        .Y(n2656) );
  AOI31X1 U1492 ( .A0(n2657), .A1(n2659), .A2(n2660), .B0(n2661), .Y(n2658) );
  NOR2BX1 U1493 ( .AN(n2910), .B(n2919), .Y(n2660) );
  AO21X1 U1494 ( .A0(n2648), .A1(n2649), .B0(n2650), .Y(nextstate[2]) );
  INVX1 U1495 ( .A(n2638), .Y(n2648) );
  OAI33X1 U1496 ( .A0(n2647), .A1(n2644), .A2(n2901), .B0(n2651), .B1(
        cbs_rasing), .B2(n2644), .Y(n2650) );
  OAI2BB1X1 U1497 ( .A0N(n2636), .A1N(n2652), .B0(n2653), .Y(n2649) );
  INVX1 U1498 ( .A(n2838), .Y(BF_REQCMD[1]) );
  OAI211X1 U1499 ( .A0(n2839), .A1(n2840), .B0(BF_IDLE), .C0(n2676), .Y(n2838)
         );
  NAND2BX1 U1500 ( .AN(RAS_0_TT[1]), .B(n2828), .Y(n2840) );
  NAND3BX1 U1501 ( .AN(RAS_0_TT[4]), .B(n2832), .C(n2831), .Y(n2839) );
  INVX1 U1502 ( .A(RAS_0_RA[10]), .Y(n2859) );
  INVX1 U1503 ( .A(RAS_0_RA[12]), .Y(n2858) );
  OAI33X1 U1504 ( .A0(n2668), .A1(BF_IDLE), .A2(n2902), .B0(n2641), .B1(n2638), 
        .B2(n2670), .Y(nextstate[1]) );
  INVX1 U1505 ( .A(n2674), .Y(n2668) );
  AOI32X1 U1506 ( .A0(BF_TREADY), .A1(n2910), .A2(n2671), .B0(n2662), .B1(
        n2672), .Y(n2670) );
  OAI33X1 U1507 ( .A0(n2636), .A1(n2637), .A2(n2638), .B0(BF_LAST), .B1(n2903), 
        .B2(n2640), .Y(nextstate[4]) );
  OAI2BB1X1 U1508 ( .A0N(TRASMIN[2]), .A1N(n2782), .B0(n2797), .Y(n2597) );
  AOI32X1 U1509 ( .A0(trasmin_cnt[2]), .A1(n2798), .A2(n2793), .B0(n2793), 
        .B1(n2915), .Y(n2797) );
  OAI2BB1X1 U1510 ( .A0N(TRASMIN[1]), .A1N(n2782), .B0(n2795), .Y(n2598) );
  AOI32X1 U1511 ( .A0(trasmin_cnt[0]), .A1(trasmin_cnt[1]), .A2(n2793), .B0(
        n2793), .B1(n2796), .Y(n2795) );
  AO22X1 U1512 ( .A0(TRASMIN[0]), .A1(n2782), .B0(n2793), .B1(n2909), .Y(n2599) );
  AO22X1 U1513 ( .A0(TRASMIN[3]), .A1(n2782), .B0(n2800), .B1(n2793), .Y(n2596) );
  NOR2BX1 U1514 ( .AN(trasmin_cnt[3]), .B(n2915), .Y(n2800) );
  AO22X1 U1515 ( .A0(cas_0_final_l), .A1(n2692), .B0(CAS_0_FINAL), .B1(n2693), 
        .Y(n2620) );
  AO22X1 U1516 ( .A0(cas_0_newrow_l), .A1(n2692), .B0(CAS_0_NEWROW), .B1(n2693), .Y(n2621) );
  OAI222X1 U1517 ( .A0(LAST_RA[5]), .A1(n2746), .B0(BA_RA[5]), .B1(n2899), 
        .C0(BA_RA[6]), .C1(n2889), .Y(n2745) );
  INVX1 U1518 ( .A(BA_RA[5]), .Y(n2746) );
  OAI222X1 U1519 ( .A0(LAST_RA[10]), .A1(n2727), .B0(BA_RA[10]), .B1(n2900), 
        .C0(BA_RA[11]), .C1(n2890), .Y(n2724) );
  INVX1 U1520 ( .A(BA_RA[10]), .Y(n2727) );
  OAI222X1 U1521 ( .A0(LAST_RA[4]), .A1(n2741), .B0(LAST_RA[3]), .B1(n2736), 
        .C0(BA_RA[4]), .C1(n2898), .Y(n2737) );
  INVX1 U1522 ( .A(BA_RA[4]), .Y(n2741) );
  AO21X1 U1523 ( .A0(n2641), .A1(BF_IDLE), .B0(n2675), .Y(nextstate[0]) );
  OAI222X1 U1524 ( .A0(n2902), .A1(n2674), .B0(cbs_casing), .B1(n2640), .C0(
        n2676), .C1(n2891), .Y(n2675) );
  AOI31X1 U1525 ( .A0(n2701), .A1(CAS_0_FINAL), .A2(n2713), .B0(n2707), .Y(
        n2712) );
  OAI31X1 U1526 ( .A0(n2773), .A1(ERCMD[0]), .A2(n2774), .B0(n2775), .Y(n2699)
         );
  INVX1 U1527 ( .A(n2704), .Y(n2774) );
  INVX1 U1528 ( .A(n2780), .Y(n2776) );
  NAND2X1 U1529 ( .A(CAS_EMPTY), .B(RAS_EMPTY), .Y(n2657) );
  AND4X1 U1530 ( .A(n2824), .B(n2778), .C(n2779), .D(n2777), .Y(n2816) );
  INVX1 U1531 ( .A(ERCMD[0]), .Y(n2824) );
  AO22X1 U1532 ( .A0(length749_3_), .A1(n2914), .B0(CAS_0_TT[3]), .B1(n2695), 
        .Y(n2601) );
  XNOR2X1 U1_A_3 ( .A(length[3]), .B(carry_3_), .Y(length749_3_) );
  AO22X1 U1533 ( .A0(length749_2_), .A1(n2914), .B0(CAS_0_TT[2]), .B1(n2695), 
        .Y(n2602) );
  XNOR2X1 U1_A_2 ( .A(length[2]), .B(carry_2_), .Y(length749_2_) );
  AO22X1 U1534 ( .A0(length749_1_), .A1(n2914), .B0(CAS_0_TT[1]), .B1(n2695), 
        .Y(n2603) );
  XNOR2X1 U1_A_1 ( .A(length[1]), .B(length[0]), .Y(length749_1_) );
  AO22X1 U1535 ( .A0(n2914), .A1(n2907), .B0(CAS_0_TT[0]), .B1(n2695), .Y(
        n2604) );
  AO22X1 U1536 ( .A0(openedrow[5]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[5]), 
        .Y(n2612) );
  AO22X1 U1537 ( .A0(openedrow[4]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[4]), 
        .Y(n2613) );
  AO21X1 U1538 ( .A0(BA_RA[0]), .A1(n2726), .B0(LAST_RA[13]), .Y(n2725) );
  INVX1 U1539 ( .A(LAST_RA[0]), .Y(n2726) );
  AO22X1 U1540 ( .A0(openedrow[9]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[9]), 
        .Y(n2608) );
  AO22X1 U1541 ( .A0(openedrow[6]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[6]), 
        .Y(n2611) );
  AO22X1 U1542 ( .A0(openedrow[3]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[3]), 
        .Y(n2614) );
  AO22X1 U1543 ( .A0(openedrow[0]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[0]), 
        .Y(n2617) );
  AO22X1 U1544 ( .A0(TRCD[1]), .A1(n2782), .B0(n2803), .B1(n2925), .Y(n2594)
         );
  NOR2BX1 U1545 ( .AN(trcd_cnt[0]), .B(n2908), .Y(n2803) );
  AO22X1 U1546 ( .A0(TRP[1]), .A1(n2811), .B0(n2814), .B1(n2813), .Y(n2590) );
  NOR2BX1 U1547 ( .AN(trp_cnt[1]), .B(n2887), .Y(n2814) );
  AO22X1 U1548 ( .A0(TRRD[1]), .A1(n2782), .B0(n2806), .B1(n2925), .Y(n2592)
         );
  AO22X1 U1549 ( .A0(TRCD[0]), .A1(n2782), .B0(n2802), .B1(n2925), .Y(n2595)
         );
  NOR2BX1 U1550 ( .AN(trcd_cnt[1]), .B(trcd_cnt[0]), .Y(n2802) );
  AO22X1 U1551 ( .A0(TRP[0]), .A1(n2811), .B0(n2812), .B1(n2813), .Y(n2591) );
  NOR2BX1 U1552 ( .AN(trp_cnt[1]), .B(trp_cnt[0]), .Y(n2812) );
  AO22X1 U1553 ( .A0(TRRD[0]), .A1(n2782), .B0(n2805), .B1(n2925), .Y(n2593)
         );
  NOR2BX1 U1554 ( .AN(trrd_cnt_1_), .B(trrd_cnt_0_), .Y(n2805) );
  AO22X1 U1555 ( .A0(length749_4_), .A1(n2914), .B0(CAS_0_TT[4]), .B1(n2695), 
        .Y(n2600) );
  XNOR2X1 U1_A_4 ( .A(length[4]), .B(carry_4_), .Y(length749_4_) );
  OR2X1 U1_B_3 ( .A(length[3]), .B(carry_3_), .Y(carry_4_) );
  NAND3BX1 U1556 ( .AN(cbs_rowopen), .B(cbs_casing), .C(BF_LAST), .Y(n2651) );
  INVX1 U1557 ( .A(ERCMD[3]), .Y(n2779) );
  INVX1 U1558 ( .A(ERCMD[4]), .Y(n2777) );
  OAI222X1 U1559 ( .A0(openedrow[4]), .A1(n2757), .B0(openedrow[3]), .B1(n2758), .C0(openedrow[5]), .C1(n2759), .Y(n2756) );
  INVX1 U1560 ( .A(LAST_RA[5]), .Y(n2759) );
  INVX1 U1561 ( .A(LAST_RA[4]), .Y(n2757) );
  INVX1 U1562 ( .A(LAST_RA[3]), .Y(n2758) );
  OAI222X1 U1563 ( .A0(openedrow[11]), .A1(n2766), .B0(openedrow[10]), .B1(
        n2767), .C0(openedrow[12]), .C1(n2768), .Y(n2765) );
  INVX1 U1564 ( .A(LAST_RA[12]), .Y(n2768) );
  INVX1 U1565 ( .A(LAST_RA[10]), .Y(n2767) );
  INVX1 U1566 ( .A(LAST_RA[11]), .Y(n2766) );
  INVX1 U1567 ( .A(LAST_RA[6]), .Y(n2743) );
  INVX1 U1568 ( .A(LAST_RA[9]), .Y(n2771) );
  NAND3BX1 U1569 ( .AN(cbs_rasing), .B(n2902), .C(n2922), .Y(n2638) );
  NAND2BX1 U1570 ( .AN(cbs_pcing), .B(n2891), .Y(n2644) );
  NAND2BX1 U1571 ( .AN(trp_cnt[1]), .B(trp_cnt[0]), .Y(n2674) );
  NAND2BX1 U1572 ( .AN(trcd_cnt[1]), .B(trcd_cnt[0]), .Y(n2647) );
  NAND3BX1 U1573 ( .AN(cbs_rowopen), .B(n2901), .C(n2677), .Y(n2640) );
  INVX1 U1574 ( .A(n2644), .Y(n2677) );
  OR2X1 U1_B_1 ( .A(length[1]), .B(length[0]), .Y(carry_2_) );
  OR2X1 U1_B_2 ( .A(length[2]), .B(carry_2_), .Y(carry_3_) );
  INVX1 U1575 ( .A(BF_NO[0]), .Y(n2872) );
  INVX1 U1576 ( .A(BF_NO[1]), .Y(n2754) );
  DFFSX1 currstate_reg_0_ ( .D(nextstate[0]), .CK(ACLK), .SN(ARESETB), .Q(
        BF_IDLE), .QN(n2891) );
  DFFRX1 currstate_reg_2_ ( .D(nextstate[2]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_rowopen), .QN(n2923) );
  DFFRX1 length_reg_0_ ( .D(n2604), .CK(ACLK), .RN(ARESETB), .Q(length[0]), 
        .QN(n2907) );
  DFFRX1 trp_cnt_reg_0_ ( .D(n2591), .CK(ACLK), .RN(ARESETB), .Q(trp_cnt[0]), 
        .QN(n2887) );
  DFFRX1 trrd_cnt_reg_0_ ( .D(n2593), .CK(ACLK), .RN(ARESETB), .Q(trrd_cnt_0_)
         );
  DFFRX1 trp_cnt_reg_1_ ( .D(n2590), .CK(ACLK), .RN(ARESETB), .Q(trp_cnt[1]), 
        .QN(n2894) );
  DFFRX1 trrd_cnt_reg_1_ ( .D(n2592), .CK(ACLK), .RN(ARESETB), .Q(trrd_cnt_1_), 
        .QN(n2895) );
  DFFRX1 newrowexist_reg ( .D(n2619), .CK(ACLK), .RN(ARESETB), .Q(newrowexist), 
        .QN(n2910) );
  DFFRX1 trasmin_cnt_reg_0_ ( .D(n2599), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[0]), .QN(n2909) );
  DFFRX1 trasmin_cnt_reg_1_ ( .D(n2598), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[1]) );
  DFFRX1 length_reg_2_ ( .D(n2602), .CK(ACLK), .RN(ARESETB), .Q(length[2]) );
  DFFRX1 length_reg_1_ ( .D(n2603), .CK(ACLK), .RN(ARESETB), .Q(length[1]) );
  DFFRX1 length_reg_3_ ( .D(n2601), .CK(ACLK), .RN(ARESETB), .Q(length[3]) );
  DFFRX1 length_reg_4_ ( .D(n2600), .CK(ACLK), .RN(ARESETB), .Q(length[4]) );
  DFFRX1 trasmin_cnt_reg_3_ ( .D(n2596), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[3]) );
  DFFRX1 trasmin_cnt_reg_2_ ( .D(n2597), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[2]), .QN(n2916) );
  DFFRX1 newrowenable_reg ( .D(n2618), .CK(ACLK), .RN(ARESETB), .Q(
        newrowenable), .QN(n2893) );
  DFFRX1 openedrow_reg_5_ ( .D(n2612), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[5]), .QN(n2899) );
  DFFRX1 openedrow_reg_9_ ( .D(n2608), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[9]), .QN(n2905) );
  DFFRX1 openedrow_reg_0_ ( .D(n2617), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[0]), .QN(n2896) );
  DFFRX1 openedrow_reg_4_ ( .D(n2613), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[4]), .QN(n2898) );
  DFFRX1 openedrow_reg_2_ ( .D(n2615), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[2]), .QN(n2918) );
  DFFRX1 openedrow_reg_6_ ( .D(n2611), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[6]), .QN(n2889) );
  DFFRX1 openedrow_reg_12_ ( .D(n2605), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[12]), .QN(n2897) );
  DFFRX1 openedrow_reg_1_ ( .D(n2616), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[1]), .QN(n2892) );
  DFFRX1 openedrow_reg_7_ ( .D(n2610), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[7]), .QN(n2904) );
  DFFRX1 openedrow_reg_10_ ( .D(n2607), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[10]), .QN(n2900) );
  DFFRX1 openedrow_reg_11_ ( .D(n2606), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[11]), .QN(n2890) );
  DFFRX1 openedrow_reg_8_ ( .D(n2609), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[8]), .QN(n2888) );
  DFFRX1 openedrow_reg_3_ ( .D(n2614), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[3]) );
  DFFRX1 currstate_reg_4_ ( .D(nextstate[4]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_casing), .QN(n2903) );
  DFFRX1 trcd_cnt_reg_1_ ( .D(n2594), .CK(ACLK), .RN(ARESETB), .Q(trcd_cnt[1]), 
        .QN(n2908) );
  DFFRX1 currstate_reg_3_ ( .D(nextstate[3]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_rasing), .QN(n2901) );
  DFFRX1 cas_0_final_l_reg ( .D(n2620), .CK(ACLK), .RN(ARESETB), .Q(
        cas_0_final_l), .QN(n2906) );
  DFFRX1 currstate_reg_1_ ( .D(nextstate[1]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_pcing), .QN(n2902) );
  DFFRX1 trcd_cnt_reg_0_ ( .D(n2595), .CK(ACLK), .RN(ARESETB), .Q(trcd_cnt[0])
         );
  DFFRX1 cas_0_newrow_l_reg ( .D(n2621), .CK(ACLK), .RN(ARESETB), .Q(
        cas_0_newrow_l) );
  AOI211X1 U1577 ( .A0(n2662), .A1(newrowenable), .B0(n2663), .C0(n2659), .Y(
        n2661) );
  OAI31X1 U1578 ( .A0(n2663), .A1(n2893), .A2(n2659), .B0(n2834), .Y(n2672) );
  XOR2X1 U1579 ( .A(n2754), .B(RAS_0_BA[1]), .Y(n2870) );
  NAND2BX1 U1580 ( .AN(n2704), .B(n2667), .Y(n2785) );
  NAND2BX1 U1581 ( .AN(n2923), .B(n2704), .Y(n2697) );
  NOR2BX1 U1582 ( .AN(cbs_rowopen), .B(n2704), .Y(n2702) );
  NOR2BX1 U1583 ( .AN(cbs_rowopen), .B(n2704), .Y(n2713) );
  NAND3BX1 U1584 ( .AN(BF_CMD[4]), .B(n2792), .C(n2789), .Y(n2818) );
  XOR2X1 U1585 ( .A(BF_CMD[4]), .B(BF_CMD[0]), .Y(n2790) );
  AO22X1 U1586 ( .A0(openedrow[7]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[7]), 
        .Y(n2610) );
  AO22X1 U1587 ( .A0(openedrow[8]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[8]), 
        .Y(n2609) );
  AO22X1 U1588 ( .A0(openedrow[1]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[1]), 
        .Y(n2616) );
  AO22X1 U1589 ( .A0(openedrow[10]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[10]), 
        .Y(n2607) );
  AO22X1 U1590 ( .A0(openedrow[2]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[2]), 
        .Y(n2615) );
  NAND4BBX1 U1591 ( .AN(ECMD[1]), .BN(ECMD[0]), .C(ERCMD[5]), .D(ECMD[5]), .Y(
        n2820) );
  AO22X1 U1592 ( .A0(openedrow[12]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[12]), 
        .Y(n2605) );
  AO22X1 U1593 ( .A0(openedrow[11]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[11]), 
        .Y(n2606) );
  XOR2X1 U1594 ( .A(n2754), .B(BA_BA[1]), .Y(n2753) );
endmodule


module SDRBsm_2 ( ARESETB, ACLK, TRP, TRRD, TRCD, TRASMIN, BA_BA, BA_RA, BA_TT, 
        BA_REQ, CAS_0_BA, CAS_0_RA, CAS_0_TT, CAS_0_FINAL, CAS_0_NEWROW, 
        CAS_EMPTY, LAST_RA, RAS_0_BA, RAS_0_RA, RAS_0_TT, RAS_EMPTY, BF_NO, 
        BF_CASBUSY, BF_TCASBUSY, BF_RASBUSY, BF_TRASBUSY, BF_READY, BF_TREADY, 
        BF_IDLE, BF_LAST, BF_REQCMD, BF_CMD, ERCMD, ECMD );
  input [1:0] TRP;
  input [1:0] TRRD;
  input [1:0] TRCD;
  input [3:0] TRASMIN;
  input [1:0] BA_BA;
  input [12:0] BA_RA;
  input [4:0] BA_TT;
  input [1:0] CAS_0_BA;
  input [12:0] CAS_0_RA;
  input [4:0] CAS_0_TT;
  input [13:0] LAST_RA;
  input [1:0] RAS_0_BA;
  input [12:0] RAS_0_RA;
  input [4:0] RAS_0_TT;
  input [1:0] BF_NO;
  output [5:0] BF_REQCMD;
  input [5:0] BF_CMD;
  input [5:0] ERCMD;
  input [6:0] ECMD;
  input ARESETB, ACLK, BA_REQ, CAS_0_FINAL, CAS_0_NEWROW, CAS_EMPTY, RAS_EMPTY,
         BF_TCASBUSY, BF_TRASBUSY, BF_TREADY;
  output BF_CASBUSY, BF_RASBUSY, BF_READY, BF_IDLE, BF_LAST;
  wire   cbs_pcing, cbs_rowopen, cbs_rasing, cbs_casing, cas_0_final_l,
         cas_0_newrow_l, newrowenable, trrd_cnt_1_, trrd_cnt_0_, length749_4_,
         length749_3_, length749_2_, length749_1_, newrowexist, n2590, n2591,
         n2592, n2593, n2594, n2595, n2596, n2597, n2598, n2599, n2600, n2601,
         n2602, n2603, n2604, n2605, n2606, n2607, n2608, n2609, n2610, n2611,
         n2612, n2613, n2614, n2615, n2616, n2617, n2618, n2619, n2620, n2621,
         carry_4_, carry_3_, carry_2_, n2636, n2637, n2638, n2640, n2641,
         n2643, n2644, n2645, n2647, n2648, n2649, n2650, n2651, n2652, n2653,
         n2654, n2655, n2656, n2657, n2658, n2659, n2660, n2661, n2662, n2663,
         n2666, n2667, n2668, n2670, n2671, n2672, n2674, n2675, n2676, n2677,
         n2678, n2679, n2681, n2682, n2683, n2684, n2685, n2686, n2688, n2689,
         n2690, n2691, n2692, n2693, n2695, n2697, n2698, n2699, n2700, n2701,
         n2702, n2703, n2704, n2705, n2706, n2707, n2709, n2711, n2712, n2713,
         n2714, n2715, n2716, n2717, n2718, n2719, n2720, n2721, n2722, n2723,
         n2724, n2725, n2726, n2727, n2730, n2731, n2732, n2733, n2734, n2736,
         n2737, n2738, n2740, n2741, n2743, n2744, n2745, n2746, n2751, n2753,
         n2754, n2756, n2757, n2758, n2759, n2760, n2761, n2762, n2765, n2766,
         n2767, n2768, n2769, n2771, n2772, n2773, n2774, n2775, n2776, n2777,
         n2778, n2779, n2780, n2781, n2782, n2785, n2788, n2789, n2790, n2791,
         n2792, n2793, n2795, n2796, n2797, n2798, n2800, n2801, n2802, n2803,
         n2805, n2806, n2808, n2809, n2810, n2811, n2812, n2813, n2814, n2816,
         n2818, n2819, n2820, n2821, n2822, n2823, n2824, n2827, n2828, n2829,
         n2830, n2831, n2832, n2833, n2834, n2835, n2836, n2837, n2838, n2839,
         n2840, n2844, n2845, n2846, n2847, n2848, n2849, n2850, n2853, n2854,
         n2855, n2856, n2858, n2859, n2860, n2861, n2862, n2865, n2866, n2867,
         n2870, n2871, n2872, n2876, n2879, n2880, n2884, n2887, n2888, n2889,
         n2890, n2891, n2892, n2893, n2894, n2895, n2896, n2897, n2898, n2899,
         n2900, n2901, n2902, n2903, n2904, n2905, n2906, n2907, n2908, n2909,
         n2910, n2911, n2912, n2913, n2914, n2915, n2916, n2917, n2918, n2919,
         n2920, n2921, n2922, n2923, n2924, n2925;
  wire   [4:0] length;
  wire   [12:0] openedrow;
  wire   [3:0] trasmin_cnt;
  wire   [4:0] nextstate;
  wire   [1:0] trcd_cnt;
  wire   [1:0] trp_cnt;

  AO22X4 U1284 ( .A0(n2922), .A1(n2836), .B0(n2663), .B1(n2837), .Y(n2652) );
  NAND2BX4 U1313 ( .AN(n2659), .B(n2922), .Y(n2836) );
  INVX1 U1346 ( .A(n2691), .Y(BF_REQCMD[0]) );
  OR2X2 U1347 ( .A(n2701), .B(n2827), .Y(n2691) );
  NAND3BX1 U1348 ( .AN(n2655), .B(n2923), .C(n2672), .Y(n2688) );
  NAND3BX2 U1349 ( .AN(n2860), .B(n2861), .C(n2862), .Y(n2845) );
  NAND3BX1 U1350 ( .AN(n2848), .B(n2849), .C(n2850), .Y(n2847) );
  AND3X2 U1351 ( .A(n2910), .B(n2911), .C(n2912), .Y(n2922) );
  INVX1 U1352 ( .A(n2659), .Y(n2835) );
  OAI32X1 U1353 ( .A0(n2913), .A1(n2922), .A2(n2835), .B0(n2836), .B1(n2837), 
        .Y(n2654) );
  OR2X1 U1354 ( .A(trasmin_cnt[0]), .B(trasmin_cnt[1]), .Y(n2798) );
  NAND4BX2 U1355 ( .AN(n2853), .B(n2854), .C(n2855), .D(n2856), .Y(n2846) );
  INVX1 U1356 ( .A(CAS_EMPTY), .Y(n2910) );
  XOR2X1 U1357 ( .A(n2754), .B(CAS_0_BA[1]), .Y(n2911) );
  XOR2X1 U1358 ( .A(n2872), .B(CAS_0_BA[0]), .Y(n2912) );
  INVX3 U1359 ( .A(n2652), .Y(n2637) );
  INVX3 U1360 ( .A(n2688), .Y(BF_REQCMD[2]) );
  AND2X1 U1361 ( .A(BF_CASBUSY), .B(n2704), .Y(n2916) );
  OR3X2 U1362 ( .A(n2876), .B(CAS_0_TT[1]), .C(CAS_0_TT[0]), .Y(n2667) );
  OAI2BB2X1 U1363 ( .A0N(n2697), .A1N(n2698), .B0(n2698), .B1(n2913), .Y(n2619) );
  AND4X1 U1364 ( .A(n2719), .B(n2720), .C(n2721), .D(n2722), .Y(n2718) );
  OAI2BB1X1 U1365 ( .A0N(n2816), .A1N(n2780), .B0(n2775), .Y(n2811) );
  AND2X1 U1366 ( .A(trrd_cnt_1_), .B(trrd_cnt_0_), .Y(n2806) );
  NAND4BX1 U1367 ( .AN(BF_TRASBUSY), .B(n2894), .C(n2887), .D(n2835), .Y(n2914) );
  INVX1 U1368 ( .A(BF_CMD[2]), .Y(n2791) );
  INVX1 U1369 ( .A(BF_CMD[0]), .Y(n2809) );
  NAND3BX1 U1370 ( .AN(n2818), .B(n2809), .C(n2819), .Y(n2775) );
  NAND3BX1 U1371 ( .AN(BF_CMD[4]), .B(n2792), .C(n2789), .Y(n2818) );
  XOR2X1 U1372 ( .A(BF_CMD[5]), .B(BF_CMD[2]), .Y(n2819) );
  NAND3BX1 U1373 ( .AN(n2788), .B(n2789), .C(n2790), .Y(n2704) );
  XOR2X1 U1374 ( .A(BF_CMD[4]), .B(BF_CMD[0]), .Y(n2790) );
  NAND3BX1 U1375 ( .AN(BF_CMD[5]), .B(n2791), .C(n2792), .Y(n2788) );
  INVX1 U1376 ( .A(BF_CMD[3]), .Y(n2792) );
  INVX1 U1377 ( .A(n2925), .Y(n2782) );
  XOR2X1 U1378 ( .A(n2691), .B(BF_CMD[0]), .Y(n2690) );
  INVX1 U1379 ( .A(BF_CMD[4]), .Y(n2684) );
  NOR2BX1 U1380 ( .AN(n2701), .B(n2827), .Y(BF_REQCMD[4]) );
  INVX1 U1381 ( .A(BA_RA[9]), .Y(n2769) );
  XNOR2X1 U1382 ( .A(n2688), .B(BF_CMD[2]), .Y(n2915) );
  INVX1 U1383 ( .A(BA_RA[3]), .Y(n2736) );
  INVX1 U1384 ( .A(BA_RA[7]), .Y(n2744) );
  INVX1 U1385 ( .A(BA_RA[8]), .Y(n2772) );
  INVX1 U1386 ( .A(BA_RA[11]), .Y(n2734) );
  INVX1 U1387 ( .A(n2686), .Y(BF_REQCMD[5]) );
  BUFX2 U1388 ( .A(n2781), .Y(n2925) );
  NAND3BX1 U1389 ( .AN(n2808), .B(n2809), .C(n2810), .Y(n2781) );
  NAND3BX1 U1390 ( .AN(BF_CMD[5]), .B(n2791), .C(n2684), .Y(n2808) );
  XOR2X1 U1391 ( .A(BF_CMD[3]), .B(BF_CMD[1]), .Y(n2810) );
  INVX1 U1392 ( .A(BF_CMD[1]), .Y(n2789) );
  INVX1 U1393 ( .A(BA_RA[12]), .Y(n2733) );
  INVX1 U1394 ( .A(n2692), .Y(n2693) );
  INVX1 U1395 ( .A(n2836), .Y(n2663) );
  INVX1 U1396 ( .A(BF_TCASBUSY), .Y(n2666) );
  XOR2X1 U1397 ( .A(n2686), .B(BF_CMD[5]), .Y(n2685) );
  INVX1 U1398 ( .A(BA_RA[0]), .Y(n2723) );
  INVX1 U1399 ( .A(n2654), .Y(n2834) );
  NAND3BX2 U1400 ( .AN(n2637), .B(n2666), .C(n2923), .Y(n2827) );
  NAND4BX1 U1401 ( .AN(n2683), .B(n2684), .C(BF_CMD[3]), .D(n2685), .Y(n2682)
         );
  NAND2BX1 U1402 ( .AN(n2924), .B(n2695), .Y(n2692) );
  XOR2X1 U1403 ( .A(BF_CMD[1]), .B(BF_REQCMD[1]), .Y(n2689) );
  NAND3BX1 U1404 ( .AN(n2641), .B(n2666), .C(n2667), .Y(n2636) );
  INVX1 U1405 ( .A(n2785), .Y(n2695) );
  INVX1 U1406 ( .A(n2683), .Y(BF_REQCMD[3]) );
  OR4X4 U1407 ( .A(n2844), .B(n2845), .C(n2846), .D(n2847), .Y(n2837) );
  NAND3BX2 U1408 ( .AN(n2865), .B(n2866), .C(n2867), .Y(n2844) );
  INVX1 U1409 ( .A(n2667), .Y(n2701) );
  OAI33X1 U1410 ( .A0(n2641), .A1(n2891), .A2(n2914), .B0(n2644), .B1(n2645), 
        .B2(n2901), .Y(nextstate[3]) );
  INVX1 U1411 ( .A(n2647), .Y(n2645) );
  INVX1 U1412 ( .A(n2643), .Y(n2676) );
  OAI32X1 U1413 ( .A0(n2705), .A1(n2706), .A2(n2707), .B0(n2893), .B1(n2709), 
        .Y(n2618) );
  INVX1 U1414 ( .A(n2697), .Y(n2706) );
  INVX1 U1415 ( .A(n2709), .Y(n2705) );
  OAI221X1 U1416 ( .A0(n2651), .A1(n2906), .B0(n2711), .B1(n2924), .C0(n2712), 
        .Y(n2709) );
  NAND4X1 U1417 ( .A(BF_TREADY), .B(n2671), .C(n2923), .D(n2913), .Y(n2686) );
  INVX1 U1418 ( .A(n2655), .Y(n2662) );
  INVX1 U1419 ( .A(n2801), .Y(n2793) );
  NAND2BX1 U1420 ( .AN(n2782), .B(n2655), .Y(n2801) );
  INVX1 U1421 ( .A(n2798), .Y(n2796) );
  INVX1 U1422 ( .A(n2678), .Y(n2641) );
  OAI33X1 U1423 ( .A0(n2679), .A1(n2915), .A2(n2681), .B0(n2679), .B1(n2682), 
        .B2(n2915), .Y(n2678) );
  NAND4BX1 U1424 ( .AN(BF_CMD[3]), .B(n2684), .C(n2685), .D(n2683), .Y(n2681)
         );
  NAND2BX1 U1425 ( .AN(n2689), .B(n2690), .Y(n2679) );
  INVX1 U1426 ( .A(n2699), .Y(n2711) );
  INVX1 U1427 ( .A(n2657), .Y(n2671) );
  INVX1 U1428 ( .A(n2811), .Y(n2813) );
  INVX1 U1429 ( .A(n2884), .Y(BF_LAST) );
  NAND2BX1 U1430 ( .AN(n2907), .B(n2917), .Y(n2884) );
  INVX1 U1431 ( .A(ERCMD[2]), .Y(n2778) );
  INVX1 U1432 ( .A(n2651), .Y(n2703) );
  NAND4BX1 U1433 ( .AN(n2914), .B(n2828), .C(n2829), .D(BF_IDLE), .Y(n2683) );
  AND4X1 U1434 ( .A(n2830), .B(n2831), .C(n2832), .D(n2833), .Y(n2829) );
  INVX1 U1435 ( .A(RAS_0_TT[1]), .Y(n2830) );
  INVX1 U1436 ( .A(RAS_0_TT[4]), .Y(n2833) );
  AO21X1 U1437 ( .A0(n2662), .A1(cbs_rowopen), .B0(BF_IDLE), .Y(BF_READY) );
  NAND3BX1 U1438 ( .AN(CAS_0_TT[4]), .B(n2879), .C(n2880), .Y(n2876) );
  NAND4BX1 U1439 ( .AN(BF_TRASBUSY), .B(n2894), .C(n2887), .D(n2835), .Y(n2643) );
  XNOR2X1 U1440 ( .A(RAS_0_RA[11]), .B(CAS_0_RA[11]), .Y(n2856) );
  NAND2BX1 U1441 ( .AN(trasmin_cnt[3]), .B(n2918), .Y(n2655) );
  INVX1 U1442 ( .A(n2714), .Y(n2707) );
  NAND4BX1 U1443 ( .AN(n2715), .B(n2716), .C(n2717), .D(n2718), .Y(n2714) );
  AOI221X1 U1444 ( .A0(LAST_RA[6]), .A1(n2889), .B0(LAST_RA[7]), .B1(n2904), 
        .C0(n2756), .Y(n2716) );
  AOI221X1 U1445 ( .A0(LAST_RA[8]), .A1(n2888), .B0(LAST_RA[9]), .B1(n2905), 
        .C0(n2751), .Y(n2717) );
  NOR4X1 U1446 ( .A(length[4]), .B(length[3]), .C(length[1]), .D(length[2]), 
        .Y(n2917) );
  XNOR2X1 U1447 ( .A(RAS_0_RA[2]), .B(CAS_0_RA[2]), .Y(n2850) );
  XNOR2X1 U1448 ( .A(RAS_0_RA[8]), .B(CAS_0_RA[8]), .Y(n2862) );
  XNOR2X1 U1449 ( .A(RAS_0_RA[4]), .B(CAS_0_RA[4]), .Y(n2866) );
  XNOR2X1 U1450 ( .A(RAS_0_RA[1]), .B(CAS_0_RA[1]), .Y(n2849) );
  XNOR2X1 U1451 ( .A(RAS_0_RA[7]), .B(CAS_0_RA[7]), .Y(n2861) );
  NAND2BX1 U1452 ( .AN(length[0]), .B(n2917), .Y(BF_CASBUSY) );
  NAND3BX2 U1453 ( .AN(RAS_EMPTY), .B(n2870), .C(n2871), .Y(n2659) );
  XOR2X1 U1454 ( .A(RAS_0_RA[6]), .B(CAS_0_RA[6]), .Y(n2865) );
  XOR2X1 U1455 ( .A(RAS_0_RA[3]), .B(CAS_0_RA[3]), .Y(n2848) );
  XOR2X1 U1456 ( .A(RAS_0_RA[9]), .B(CAS_0_RA[9]), .Y(n2860) );
  AND2X2 U1457 ( .A(n2919), .B(n2796), .Y(n2918) );
  OAI32X1 U1458 ( .A0(n2820), .A1(n2821), .A2(n2822), .B0(ERCMD[5]), .B1(n2823), .Y(n2780) );
  INVX1 U1459 ( .A(ERCMD[1]), .Y(n2823) );
  OR2X1 U1460 ( .A(ECMD[3]), .B(ECMD[2]), .Y(n2822) );
  OAI31X1 U1461 ( .A0(n2773), .A1(ERCMD[0]), .A2(n2774), .B0(n2775), .Y(n2699)
         );
  NAND4BX1 U1462 ( .AN(n2776), .B(n2777), .C(n2778), .D(n2779), .Y(n2773) );
  INVX1 U1463 ( .A(n2704), .Y(n2774) );
  INVX1 U1464 ( .A(n2780), .Y(n2776) );
  XOR2X1 U1465 ( .A(RAS_0_RA[0]), .B(CAS_0_RA[0]), .Y(n2853) );
  XOR2X1 U1466 ( .A(n2859), .B(CAS_0_RA[10]), .Y(n2854) );
  XOR2X1 U1467 ( .A(n2858), .B(CAS_0_RA[12]), .Y(n2855) );
  NAND3X1 U1468 ( .A(n2920), .B(n2753), .C(BA_REQ), .Y(n2751) );
  XNOR2X1 U1469 ( .A(BF_NO[0]), .B(BA_BA[0]), .Y(n2920) );
  NAND3BX1 U1470 ( .AN(n2760), .B(n2761), .C(n2762), .Y(n2715) );
  AOI221X1 U1471 ( .A0(LAST_RA[1]), .A1(n2892), .B0(LAST_RA[2]), .B1(n2921), 
        .C0(n2765), .Y(n2762) );
  OAI222X1 U1472 ( .A0(LAST_RA[8]), .A1(n2772), .B0(LAST_RA[7]), .B1(n2744), 
        .C0(BA_RA[8]), .C1(n2888), .Y(n2760) );
  AOI222X1 U1473 ( .A0(openedrow[9]), .A1(n2769), .B0(LAST_RA[0]), .B1(n2896), 
        .C0(BA_RA[9]), .C1(n2771), .Y(n2761) );
  NAND2BX1 U1474 ( .AN(trrd_cnt_0_), .B(n2895), .Y(BF_RASBUSY) );
  INVX1 U1475 ( .A(RAS_0_TT[0]), .Y(n2828) );
  INVX1 U1476 ( .A(RAS_0_TT[3]), .Y(n2832) );
  INVX1 U1477 ( .A(RAS_0_TT[2]), .Y(n2831) );
  INVX1 U1478 ( .A(CAS_0_TT[2]), .Y(n2880) );
  INVX1 U1479 ( .A(CAS_0_TT[3]), .Y(n2879) );
  XNOR2X1 U1480 ( .A(RAS_0_RA[5]), .B(CAS_0_RA[5]), .Y(n2867) );
  OAI22X1 U1481 ( .A0(n2740), .A1(LAST_RA[2]), .B0(n2921), .B1(BA_RA[2]), .Y(
        n2738) );
  INVX1 U1482 ( .A(BA_RA[2]), .Y(n2740) );
  INVX1 U1483 ( .A(n2838), .Y(BF_REQCMD[1]) );
  OAI211X1 U1484 ( .A0(n2839), .A1(n2840), .B0(BF_IDLE), .C0(n2676), .Y(n2838)
         );
  NAND2BX1 U1485 ( .AN(RAS_0_TT[1]), .B(n2828), .Y(n2840) );
  NAND3BX1 U1486 ( .AN(RAS_0_TT[4]), .B(n2832), .C(n2831), .Y(n2839) );
  AOI211X1 U1487 ( .A0(openedrow[3]), .A1(n2736), .B0(n2737), .C0(n2738), .Y(
        n2720) );
  AOI221X1 U1488 ( .A0(BA_RA[6]), .A1(n2743), .B0(openedrow[7]), .B1(n2744), 
        .C0(n2745), .Y(n2719) );
  AOI211X1 U1489 ( .A0(openedrow[0]), .A1(n2723), .B0(n2724), .C0(n2725), .Y(
        n2722) );
  AOI221X1 U1490 ( .A0(openedrow[1]), .A1(n2730), .B0(BA_RA[1]), .B1(n2731), 
        .C0(n2732), .Y(n2721) );
  INVX1 U1491 ( .A(LAST_RA[1]), .Y(n2731) );
  INVX1 U1492 ( .A(BA_RA[1]), .Y(n2730) );
  OAI222X1 U1493 ( .A0(LAST_RA[12]), .A1(n2733), .B0(LAST_RA[11]), .B1(n2734), 
        .C0(BA_RA[12]), .C1(n2897), .Y(n2732) );
  OAI2BB1X1 U1494 ( .A0N(cbs_rowopen), .A1N(n2699), .B0(n2700), .Y(n2698) );
  AOI32X1 U1495 ( .A0(n2701), .A1(CAS_0_NEWROW), .A2(n2702), .B0(
        cas_0_newrow_l), .B1(n2703), .Y(n2700) );
  NOR2X1 U1496 ( .A(BF_IDLE), .B(n2924), .Y(n2923) );
  AOI211X1 U1497 ( .A0(n2654), .A1(n2655), .B0(n2641), .C0(n2656), .Y(n2653)
         );
  OAI31X1 U1498 ( .A0(n2657), .A1(newrowexist), .A2(BF_TREADY), .B0(n2658), 
        .Y(n2656) );
  AOI31X1 U1499 ( .A0(n2657), .A1(n2659), .A2(n2660), .B0(n2661), .Y(n2658) );
  NOR2BX1 U1500 ( .AN(n2913), .B(n2922), .Y(n2660) );
  AO22X1 U1501 ( .A0(length749_3_), .A1(n2916), .B0(CAS_0_TT[3]), .B1(n2695), 
        .Y(n2601) );
  XNOR2X1 U1_A_3 ( .A(length[3]), .B(carry_3_), .Y(length749_3_) );
  AO22X1 U1502 ( .A0(length749_2_), .A1(n2916), .B0(CAS_0_TT[2]), .B1(n2695), 
        .Y(n2602) );
  XNOR2X1 U1_A_2 ( .A(length[2]), .B(carry_2_), .Y(length749_2_) );
  AO22X1 U1503 ( .A0(length749_1_), .A1(n2916), .B0(CAS_0_TT[1]), .B1(n2695), 
        .Y(n2603) );
  XNOR2X1 U1_A_1 ( .A(length[1]), .B(length[0]), .Y(length749_1_) );
  AO22X1 U1504 ( .A0(n2916), .A1(n2907), .B0(CAS_0_TT[0]), .B1(n2695), .Y(
        n2604) );
  AO21X1 U1505 ( .A0(n2648), .A1(n2649), .B0(n2650), .Y(nextstate[2]) );
  INVX1 U1506 ( .A(n2638), .Y(n2648) );
  OAI33X1 U1507 ( .A0(n2647), .A1(n2644), .A2(n2901), .B0(n2651), .B1(
        cbs_rasing), .B2(n2644), .Y(n2650) );
  OAI2BB1X1 U1508 ( .A0N(n2636), .A1N(n2652), .B0(n2653), .Y(n2649) );
  INVX1 U1509 ( .A(RAS_0_RA[10]), .Y(n2859) );
  INVX1 U1510 ( .A(RAS_0_RA[12]), .Y(n2858) );
  OR3X2 U1511 ( .A(ECMD[4]), .B(ECMD[6]), .C(ERCMD[1]), .Y(n2821) );
  OAI33X1 U1512 ( .A0(n2668), .A1(BF_IDLE), .A2(n2902), .B0(n2641), .B1(n2638), 
        .B2(n2670), .Y(nextstate[1]) );
  INVX1 U1513 ( .A(n2674), .Y(n2668) );
  AOI32X1 U1514 ( .A0(BF_TREADY), .A1(n2913), .A2(n2671), .B0(n2662), .B1(
        n2672), .Y(n2670) );
  OAI33X1 U1515 ( .A0(n2636), .A1(n2637), .A2(n2638), .B0(BF_LAST), .B1(n2903), 
        .B2(n2640), .Y(nextstate[4]) );
  OAI2BB1X1 U1516 ( .A0N(TRASMIN[2]), .A1N(n2782), .B0(n2797), .Y(n2597) );
  AOI32X1 U1517 ( .A0(trasmin_cnt[2]), .A1(n2798), .A2(n2793), .B0(n2793), 
        .B1(n2918), .Y(n2797) );
  OAI2BB1X1 U1518 ( .A0N(TRASMIN[1]), .A1N(n2782), .B0(n2795), .Y(n2598) );
  AOI32X1 U1519 ( .A0(trasmin_cnt[0]), .A1(trasmin_cnt[1]), .A2(n2793), .B0(
        n2793), .B1(n2796), .Y(n2795) );
  AO22X1 U1520 ( .A0(TRASMIN[0]), .A1(n2782), .B0(n2793), .B1(n2909), .Y(n2599) );
  AO22X1 U1521 ( .A0(TRASMIN[3]), .A1(n2782), .B0(n2800), .B1(n2793), .Y(n2596) );
  NOR2BX1 U1522 ( .AN(trasmin_cnt[3]), .B(n2918), .Y(n2800) );
  AO22X1 U1523 ( .A0(cas_0_final_l), .A1(n2692), .B0(CAS_0_FINAL), .B1(n2693), 
        .Y(n2620) );
  AO22X1 U1524 ( .A0(cas_0_newrow_l), .A1(n2692), .B0(CAS_0_NEWROW), .B1(n2693), .Y(n2621) );
  AO22X1 U1525 ( .A0(length749_4_), .A1(n2916), .B0(CAS_0_TT[4]), .B1(n2695), 
        .Y(n2600) );
  XNOR2X1 U1_A_4 ( .A(length[4]), .B(carry_4_), .Y(length749_4_) );
  OR2X1 U1_B_3 ( .A(length[3]), .B(carry_3_), .Y(carry_4_) );
  OAI222X1 U1526 ( .A0(LAST_RA[5]), .A1(n2746), .B0(BA_RA[5]), .B1(n2899), 
        .C0(BA_RA[6]), .C1(n2889), .Y(n2745) );
  INVX1 U1527 ( .A(BA_RA[5]), .Y(n2746) );
  OAI222X1 U1528 ( .A0(LAST_RA[10]), .A1(n2727), .B0(BA_RA[10]), .B1(n2900), 
        .C0(BA_RA[11]), .C1(n2890), .Y(n2724) );
  INVX1 U1529 ( .A(BA_RA[10]), .Y(n2727) );
  OAI222X1 U1530 ( .A0(LAST_RA[4]), .A1(n2741), .B0(LAST_RA[3]), .B1(n2736), 
        .C0(BA_RA[4]), .C1(n2898), .Y(n2737) );
  INVX1 U1531 ( .A(BA_RA[4]), .Y(n2741) );
  AO21X1 U1532 ( .A0(n2641), .A1(BF_IDLE), .B0(n2675), .Y(nextstate[0]) );
  OAI222X1 U1533 ( .A0(n2902), .A1(n2674), .B0(cbs_casing), .B1(n2640), .C0(
        n2676), .C1(n2891), .Y(n2675) );
  AOI31X1 U1534 ( .A0(n2701), .A1(CAS_0_FINAL), .A2(n2713), .B0(n2707), .Y(
        n2712) );
  NAND2X1 U1535 ( .A(CAS_EMPTY), .B(RAS_EMPTY), .Y(n2657) );
  AND4X1 U1536 ( .A(n2824), .B(n2778), .C(n2779), .D(n2777), .Y(n2816) );
  INVX1 U1537 ( .A(ERCMD[0]), .Y(n2824) );
  AO22X1 U1538 ( .A0(openedrow[5]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[5]), 
        .Y(n2612) );
  AO22X1 U1539 ( .A0(openedrow[4]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[4]), 
        .Y(n2613) );
  AO21X1 U1540 ( .A0(BA_RA[0]), .A1(n2726), .B0(LAST_RA[13]), .Y(n2725) );
  INVX1 U1541 ( .A(LAST_RA[0]), .Y(n2726) );
  AO22X1 U1542 ( .A0(openedrow[9]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[9]), 
        .Y(n2608) );
  AO22X1 U1543 ( .A0(openedrow[6]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[6]), 
        .Y(n2611) );
  AO22X1 U1544 ( .A0(openedrow[3]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[3]), 
        .Y(n2614) );
  AO22X1 U1545 ( .A0(openedrow[0]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[0]), 
        .Y(n2617) );
  AO22X1 U1546 ( .A0(TRCD[1]), .A1(n2782), .B0(n2803), .B1(n2925), .Y(n2594)
         );
  NOR2BX1 U1547 ( .AN(trcd_cnt[0]), .B(n2908), .Y(n2803) );
  AO22X1 U1548 ( .A0(TRP[1]), .A1(n2811), .B0(n2814), .B1(n2813), .Y(n2590) );
  NOR2BX1 U1549 ( .AN(trp_cnt[1]), .B(n2887), .Y(n2814) );
  AO22X1 U1550 ( .A0(TRRD[1]), .A1(n2782), .B0(n2806), .B1(n2925), .Y(n2592)
         );
  AO22X1 U1551 ( .A0(TRCD[0]), .A1(n2782), .B0(n2802), .B1(n2925), .Y(n2595)
         );
  NOR2BX1 U1552 ( .AN(trcd_cnt[1]), .B(trcd_cnt[0]), .Y(n2802) );
  AO22X1 U1553 ( .A0(TRP[0]), .A1(n2811), .B0(n2812), .B1(n2813), .Y(n2591) );
  NOR2BX1 U1554 ( .AN(trp_cnt[1]), .B(trp_cnt[0]), .Y(n2812) );
  AO22X1 U1555 ( .A0(TRRD[0]), .A1(n2782), .B0(n2805), .B1(n2925), .Y(n2593)
         );
  NOR2BX1 U1556 ( .AN(trrd_cnt_1_), .B(trrd_cnt_0_), .Y(n2805) );
  NAND3BX1 U1557 ( .AN(cbs_rowopen), .B(cbs_casing), .C(BF_LAST), .Y(n2651) );
  INVX1 U1558 ( .A(ERCMD[3]), .Y(n2779) );
  INVX1 U1559 ( .A(ERCMD[4]), .Y(n2777) );
  OAI222X1 U1560 ( .A0(openedrow[4]), .A1(n2757), .B0(openedrow[3]), .B1(n2758), .C0(openedrow[5]), .C1(n2759), .Y(n2756) );
  INVX1 U1561 ( .A(LAST_RA[5]), .Y(n2759) );
  INVX1 U1562 ( .A(LAST_RA[4]), .Y(n2757) );
  INVX1 U1563 ( .A(LAST_RA[3]), .Y(n2758) );
  OAI222X1 U1564 ( .A0(openedrow[11]), .A1(n2766), .B0(openedrow[10]), .B1(
        n2767), .C0(openedrow[12]), .C1(n2768), .Y(n2765) );
  INVX1 U1565 ( .A(LAST_RA[12]), .Y(n2768) );
  INVX1 U1566 ( .A(LAST_RA[10]), .Y(n2767) );
  INVX1 U1567 ( .A(LAST_RA[11]), .Y(n2766) );
  AOI211X1 U1568 ( .A0(n2662), .A1(newrowenable), .B0(n2663), .C0(n2659), .Y(
        n2661) );
  INVX1 U1569 ( .A(LAST_RA[6]), .Y(n2743) );
  INVX1 U1570 ( .A(LAST_RA[9]), .Y(n2771) );
  NAND3BX1 U1571 ( .AN(cbs_rasing), .B(n2902), .C(n2923), .Y(n2638) );
  NAND2BX1 U1572 ( .AN(cbs_pcing), .B(n2891), .Y(n2644) );
  NAND2BX1 U1573 ( .AN(trp_cnt[1]), .B(trp_cnt[0]), .Y(n2674) );
  NAND2BX1 U1574 ( .AN(trcd_cnt[1]), .B(trcd_cnt[0]), .Y(n2647) );
  NAND3BX1 U1575 ( .AN(cbs_rowopen), .B(n2901), .C(n2677), .Y(n2640) );
  INVX1 U1576 ( .A(n2644), .Y(n2677) );
  OR2X1 U1_B_1 ( .A(length[1]), .B(length[0]), .Y(carry_2_) );
  OR2X1 U1_B_2 ( .A(length[2]), .B(carry_2_), .Y(carry_3_) );
  INVX1 U1577 ( .A(BF_NO[1]), .Y(n2754) );
  INVX1 U1578 ( .A(BF_NO[0]), .Y(n2872) );
  DFFSX1 currstate_reg_0_ ( .D(nextstate[0]), .CK(ACLK), .SN(ARESETB), .Q(
        BF_IDLE), .QN(n2891) );
  DFFRX1 currstate_reg_2_ ( .D(nextstate[2]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_rowopen), .QN(n2924) );
  DFFRX1 length_reg_0_ ( .D(n2604), .CK(ACLK), .RN(ARESETB), .Q(length[0]), 
        .QN(n2907) );
  DFFRX1 trp_cnt_reg_0_ ( .D(n2591), .CK(ACLK), .RN(ARESETB), .Q(trp_cnt[0]), 
        .QN(n2887) );
  DFFRX1 trrd_cnt_reg_0_ ( .D(n2593), .CK(ACLK), .RN(ARESETB), .Q(trrd_cnt_0_)
         );
  DFFRX1 trp_cnt_reg_1_ ( .D(n2590), .CK(ACLK), .RN(ARESETB), .Q(trp_cnt[1]), 
        .QN(n2894) );
  DFFRX1 trrd_cnt_reg_1_ ( .D(n2592), .CK(ACLK), .RN(ARESETB), .Q(trrd_cnt_1_), 
        .QN(n2895) );
  DFFRX1 newrowexist_reg ( .D(n2619), .CK(ACLK), .RN(ARESETB), .Q(newrowexist), 
        .QN(n2913) );
  DFFRX1 trasmin_cnt_reg_0_ ( .D(n2599), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[0]), .QN(n2909) );
  DFFRX1 trasmin_cnt_reg_1_ ( .D(n2598), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[1]) );
  DFFRX1 length_reg_2_ ( .D(n2602), .CK(ACLK), .RN(ARESETB), .Q(length[2]) );
  DFFRX1 length_reg_1_ ( .D(n2603), .CK(ACLK), .RN(ARESETB), .Q(length[1]) );
  DFFRX1 length_reg_3_ ( .D(n2601), .CK(ACLK), .RN(ARESETB), .Q(length[3]) );
  DFFRX1 length_reg_4_ ( .D(n2600), .CK(ACLK), .RN(ARESETB), .Q(length[4]) );
  DFFRX1 trasmin_cnt_reg_3_ ( .D(n2596), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[3]) );
  DFFRX1 trasmin_cnt_reg_2_ ( .D(n2597), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[2]), .QN(n2919) );
  DFFRX1 newrowenable_reg ( .D(n2618), .CK(ACLK), .RN(ARESETB), .Q(
        newrowenable), .QN(n2893) );
  DFFRX1 openedrow_reg_5_ ( .D(n2612), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[5]), .QN(n2899) );
  DFFRX1 openedrow_reg_9_ ( .D(n2608), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[9]), .QN(n2905) );
  DFFRX1 openedrow_reg_0_ ( .D(n2617), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[0]), .QN(n2896) );
  DFFRX1 openedrow_reg_4_ ( .D(n2613), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[4]), .QN(n2898) );
  DFFRX1 openedrow_reg_2_ ( .D(n2615), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[2]), .QN(n2921) );
  DFFRX1 openedrow_reg_6_ ( .D(n2611), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[6]), .QN(n2889) );
  DFFRX1 openedrow_reg_12_ ( .D(n2605), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[12]), .QN(n2897) );
  DFFRX1 openedrow_reg_1_ ( .D(n2616), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[1]), .QN(n2892) );
  DFFRX1 openedrow_reg_7_ ( .D(n2610), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[7]), .QN(n2904) );
  DFFRX1 openedrow_reg_10_ ( .D(n2607), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[10]), .QN(n2900) );
  DFFRX1 openedrow_reg_11_ ( .D(n2606), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[11]), .QN(n2890) );
  DFFRX1 openedrow_reg_8_ ( .D(n2609), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[8]), .QN(n2888) );
  DFFRX1 openedrow_reg_3_ ( .D(n2614), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[3]) );
  DFFRX1 currstate_reg_4_ ( .D(nextstate[4]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_casing), .QN(n2903) );
  DFFRX1 trcd_cnt_reg_1_ ( .D(n2594), .CK(ACLK), .RN(ARESETB), .Q(trcd_cnt[1]), 
        .QN(n2908) );
  DFFRX1 currstate_reg_3_ ( .D(nextstate[3]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_rasing), .QN(n2901) );
  DFFRX1 cas_0_final_l_reg ( .D(n2620), .CK(ACLK), .RN(ARESETB), .Q(
        cas_0_final_l), .QN(n2906) );
  DFFRX1 currstate_reg_1_ ( .D(nextstate[1]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_pcing), .QN(n2902) );
  DFFRX1 trcd_cnt_reg_0_ ( .D(n2595), .CK(ACLK), .RN(ARESETB), .Q(trcd_cnt[0])
         );
  DFFRX1 cas_0_newrow_l_reg ( .D(n2621), .CK(ACLK), .RN(ARESETB), .Q(
        cas_0_newrow_l) );
  XOR2X1 U1579 ( .A(n2754), .B(RAS_0_BA[1]), .Y(n2870) );
  OAI31X1 U1580 ( .A0(n2663), .A1(n2893), .A2(n2659), .B0(n2834), .Y(n2672) );
  XOR2X1 U1581 ( .A(n2872), .B(RAS_0_BA[0]), .Y(n2871) );
  AO22X1 U1582 ( .A0(openedrow[7]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[7]), 
        .Y(n2610) );
  AO22X1 U1583 ( .A0(openedrow[8]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[8]), 
        .Y(n2609) );
  AO22X1 U1584 ( .A0(openedrow[1]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[1]), 
        .Y(n2616) );
  NAND2BX1 U1585 ( .AN(n2704), .B(n2667), .Y(n2785) );
  NAND2BX1 U1586 ( .AN(n2924), .B(n2704), .Y(n2697) );
  NOR2BX1 U1587 ( .AN(cbs_rowopen), .B(n2704), .Y(n2702) );
  NOR2BX1 U1588 ( .AN(cbs_rowopen), .B(n2704), .Y(n2713) );
  AO22X1 U1589 ( .A0(openedrow[10]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[10]), 
        .Y(n2607) );
  AO22X1 U1590 ( .A0(openedrow[2]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[2]), 
        .Y(n2615) );
  NAND4BBX1 U1591 ( .AN(ECMD[1]), .BN(ECMD[0]), .C(ERCMD[5]), .D(ECMD[5]), .Y(
        n2820) );
  AO22X1 U1592 ( .A0(openedrow[12]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[12]), 
        .Y(n2605) );
  AO22X1 U1593 ( .A0(openedrow[11]), .A1(n2925), .B0(n2782), .B1(RAS_0_RA[11]), 
        .Y(n2606) );
  XOR2X1 U1594 ( .A(n2754), .B(BA_BA[1]), .Y(n2753) );
endmodule


module SDRBsm_1 ( ARESETB, ACLK, TRP, TRRD, TRCD, TRASMIN, BA_BA, BA_RA, BA_TT, 
        BA_REQ, CAS_0_BA, CAS_0_RA, CAS_0_TT, CAS_0_FINAL, CAS_0_NEWROW, 
        CAS_EMPTY, LAST_RA, RAS_0_BA, RAS_0_RA, RAS_0_TT, RAS_EMPTY, BF_NO, 
        BF_CASBUSY, BF_TCASBUSY, BF_RASBUSY, BF_TRASBUSY, BF_READY, BF_TREADY, 
        BF_IDLE, BF_LAST, BF_REQCMD, BF_CMD, ERCMD, ECMD );
  input [1:0] TRP;
  input [1:0] TRRD;
  input [1:0] TRCD;
  input [3:0] TRASMIN;
  input [1:0] BA_BA;
  input [12:0] BA_RA;
  input [4:0] BA_TT;
  input [1:0] CAS_0_BA;
  input [12:0] CAS_0_RA;
  input [4:0] CAS_0_TT;
  input [13:0] LAST_RA;
  input [1:0] RAS_0_BA;
  input [12:0] RAS_0_RA;
  input [4:0] RAS_0_TT;
  input [1:0] BF_NO;
  output [5:0] BF_REQCMD;
  input [5:0] BF_CMD;
  input [5:0] ERCMD;
  input [6:0] ECMD;
  input ARESETB, ACLK, BA_REQ, CAS_0_FINAL, CAS_0_NEWROW, CAS_EMPTY, RAS_EMPTY,
         BF_TCASBUSY, BF_TRASBUSY, BF_TREADY;
  output BF_CASBUSY, BF_RASBUSY, BF_READY, BF_IDLE, BF_LAST;
  wire   cbs_pcing, cbs_rowopen, cbs_rasing, cbs_casing, cas_0_final_l,
         cas_0_newrow_l, newrowenable, trrd_cnt_1_, trrd_cnt_0_, length749_4_,
         length749_3_, length749_2_, length749_1_, newrowexist, n2590, n2591,
         n2592, n2593, n2594, n2595, n2596, n2597, n2598, n2599, n2600, n2601,
         n2602, n2603, n2604, n2605, n2606, n2607, n2608, n2609, n2610, n2611,
         n2612, n2613, n2614, n2615, n2616, n2617, n2618, n2619, n2620, n2621,
         carry_4_, carry_3_, carry_2_, n2636, n2637, n2638, n2640, n2641,
         n2643, n2644, n2645, n2647, n2648, n2649, n2650, n2651, n2652, n2653,
         n2654, n2655, n2656, n2657, n2658, n2659, n2660, n2661, n2662, n2663,
         n2666, n2667, n2668, n2670, n2671, n2672, n2674, n2675, n2676, n2677,
         n2678, n2679, n2681, n2682, n2683, n2684, n2685, n2686, n2688, n2689,
         n2690, n2691, n2692, n2693, n2695, n2697, n2698, n2699, n2700, n2701,
         n2702, n2703, n2704, n2705, n2706, n2707, n2709, n2711, n2712, n2713,
         n2714, n2715, n2716, n2717, n2718, n2719, n2720, n2721, n2722, n2723,
         n2724, n2725, n2726, n2727, n2730, n2731, n2732, n2733, n2734, n2736,
         n2737, n2738, n2740, n2741, n2743, n2744, n2745, n2746, n2751, n2753,
         n2754, n2756, n2757, n2758, n2759, n2760, n2761, n2762, n2765, n2766,
         n2767, n2768, n2769, n2771, n2772, n2773, n2774, n2775, n2776, n2777,
         n2778, n2779, n2780, n2781, n2782, n2785, n2788, n2789, n2790, n2791,
         n2792, n2793, n2795, n2796, n2797, n2798, n2800, n2801, n2802, n2803,
         n2805, n2806, n2808, n2809, n2810, n2811, n2812, n2813, n2814, n2816,
         n2818, n2819, n2820, n2821, n2822, n2823, n2824, n2827, n2828, n2829,
         n2830, n2831, n2832, n2833, n2834, n2835, n2836, n2837, n2838, n2839,
         n2840, n2844, n2845, n2846, n2847, n2848, n2849, n2850, n2853, n2854,
         n2855, n2856, n2858, n2859, n2860, n2861, n2862, n2865, n2866, n2867,
         n2870, n2871, n2872, n2876, n2879, n2880, n2884, n2887, n2888, n2889,
         n2890, n2891, n2892, n2893, n2894, n2895, n2896, n2897, n2898, n2899,
         n2900, n2901, n2902, n2903, n2904, n2905, n2906, n2907, n2908, n2909,
         n2910, n2911, n2912, n2913, n2914, n2915, n2916, n2917, n2918, n2919,
         n2920, n2921, n2922;
  wire   [4:0] length;
  wire   [12:0] openedrow;
  wire   [3:0] trasmin_cnt;
  wire   [4:0] nextstate;
  wire   [1:0] trcd_cnt;
  wire   [1:0] trp_cnt;

  AO22X4 U1284 ( .A0(n2912), .A1(n2836), .B0(n2663), .B1(n2837), .Y(n2652) );
  NAND2BX2 U1346 ( .AN(n2659), .B(n2912), .Y(n2836) );
  NAND3BX2 U1347 ( .AN(n2860), .B(n2861), .C(n2862), .Y(n2845) );
  NAND3BX2 U1348 ( .AN(RAS_EMPTY), .B(n2870), .C(n2871), .Y(n2659) );
  INVX1 U1349 ( .A(n2691), .Y(BF_REQCMD[0]) );
  OR2X2 U1350 ( .A(n2701), .B(n2827), .Y(n2691) );
  OR2X1 U1351 ( .A(trasmin_cnt[0]), .B(trasmin_cnt[1]), .Y(n2798) );
  OAI31X1 U1352 ( .A0(n2663), .A1(n2893), .A2(n2659), .B0(n2834), .Y(n2672) );
  NAND4BX1 U1353 ( .AN(n2853), .B(n2854), .C(n2855), .D(n2856), .Y(n2846) );
  INVX4 U1354 ( .A(n2836), .Y(n2663) );
  INVX3 U1355 ( .A(n2652), .Y(n2637) );
  OAI32X1 U1356 ( .A0(n2909), .A1(n2912), .A2(n2835), .B0(n2836), .B1(n2837), 
        .Y(n2654) );
  AND2X1 U1357 ( .A(BF_CASBUSY), .B(n2704), .Y(n2911) );
  OR3X2 U1358 ( .A(n2876), .B(CAS_0_TT[1]), .C(CAS_0_TT[0]), .Y(n2667) );
  NAND4BX1 U1359 ( .AN(n2776), .B(n2777), .C(n2778), .D(n2779), .Y(n2773) );
  XOR2X1 U1360 ( .A(n2872), .B(RAS_0_BA[0]), .Y(n2871) );
  OAI2BB2X1 U1361 ( .A0N(n2697), .A1N(n2698), .B0(n2698), .B1(n2909), .Y(n2619) );
  AND4X1 U1362 ( .A(n2719), .B(n2720), .C(n2721), .D(n2722), .Y(n2718) );
  OAI2BB1X1 U1363 ( .A0N(n2816), .A1N(n2780), .B0(n2775), .Y(n2811) );
  AND2X1 U1364 ( .A(trrd_cnt_1_), .B(trrd_cnt_0_), .Y(n2806) );
  INVX1 U1365 ( .A(BF_CMD[2]), .Y(n2791) );
  INVX1 U1366 ( .A(BF_CMD[0]), .Y(n2809) );
  INVX1 U1367 ( .A(BF_CMD[4]), .Y(n2684) );
  NAND3BX1 U1368 ( .AN(n2788), .B(n2789), .C(n2790), .Y(n2704) );
  XOR2X1 U1369 ( .A(BF_CMD[4]), .B(BF_CMD[0]), .Y(n2790) );
  NAND3BX1 U1370 ( .AN(BF_CMD[5]), .B(n2791), .C(n2792), .Y(n2788) );
  NAND3BX1 U1371 ( .AN(n2818), .B(n2809), .C(n2819), .Y(n2775) );
  NAND3BX1 U1372 ( .AN(BF_CMD[4]), .B(n2792), .C(n2789), .Y(n2818) );
  XOR2X1 U1373 ( .A(BF_CMD[5]), .B(BF_CMD[2]), .Y(n2819) );
  INVX1 U1374 ( .A(BF_CMD[3]), .Y(n2792) );
  INVX1 U1375 ( .A(n2922), .Y(n2782) );
  NOR2BX1 U1376 ( .AN(n2701), .B(n2827), .Y(BF_REQCMD[4]) );
  INVX1 U1377 ( .A(BA_RA[9]), .Y(n2769) );
  XNOR2X1 U1378 ( .A(n2688), .B(BF_CMD[2]), .Y(n2910) );
  INVX1 U1379 ( .A(BA_RA[3]), .Y(n2736) );
  INVX1 U1380 ( .A(BA_RA[7]), .Y(n2744) );
  INVX1 U1381 ( .A(BA_RA[8]), .Y(n2772) );
  INVX3 U1382 ( .A(n2688), .Y(BF_REQCMD[2]) );
  INVX1 U1383 ( .A(BA_RA[11]), .Y(n2734) );
  BUFX2 U1384 ( .A(n2781), .Y(n2922) );
  NAND3BX1 U1385 ( .AN(n2808), .B(n2809), .C(n2810), .Y(n2781) );
  NAND3BX1 U1386 ( .AN(BF_CMD[5]), .B(n2791), .C(n2684), .Y(n2808) );
  XOR2X1 U1387 ( .A(BF_CMD[3]), .B(BF_CMD[1]), .Y(n2810) );
  INVX1 U1388 ( .A(n2686), .Y(BF_REQCMD[5]) );
  INVX1 U1389 ( .A(BF_CMD[1]), .Y(n2789) );
  INVX1 U1390 ( .A(BA_RA[12]), .Y(n2733) );
  INVX1 U1391 ( .A(BF_TCASBUSY), .Y(n2666) );
  XOR2X1 U1392 ( .A(n2686), .B(BF_CMD[5]), .Y(n2685) );
  INVX1 U1393 ( .A(BA_RA[0]), .Y(n2723) );
  INVX1 U1394 ( .A(n2692), .Y(n2693) );
  NAND3BX2 U1395 ( .AN(n2637), .B(n2666), .C(n2919), .Y(n2827) );
  NAND2BX1 U1396 ( .AN(n2920), .B(n2704), .Y(n2697) );
  NAND3BX2 U1397 ( .AN(n2655), .B(n2919), .C(n2672), .Y(n2688) );
  NAND3BX1 U1398 ( .AN(n2641), .B(n2666), .C(n2667), .Y(n2636) );
  INVX1 U1399 ( .A(n2683), .Y(BF_REQCMD[3]) );
  OR4X4 U1400 ( .A(n2844), .B(n2845), .C(n2846), .D(n2847), .Y(n2837) );
  NAND3BX2 U1401 ( .AN(n2848), .B(n2849), .C(n2850), .Y(n2847) );
  NAND3BX2 U1402 ( .AN(n2865), .B(n2866), .C(n2867), .Y(n2844) );
  INVX1 U1403 ( .A(n2654), .Y(n2834) );
  NAND2BX1 U1404 ( .AN(n2689), .B(n2690), .Y(n2679) );
  XOR2X1 U1405 ( .A(n2691), .B(BF_CMD[0]), .Y(n2690) );
  XOR2X1 U1406 ( .A(BF_CMD[1]), .B(BF_REQCMD[1]), .Y(n2689) );
  INVX1 U1407 ( .A(n2659), .Y(n2835) );
  INVX1 U1408 ( .A(n2667), .Y(n2701) );
  OAI33X1 U1409 ( .A0(n2641), .A1(n2891), .A2(n2643), .B0(n2644), .B1(n2645), 
        .B2(n2900), .Y(nextstate[3]) );
  INVX1 U1410 ( .A(n2647), .Y(n2645) );
  INVX1 U1411 ( .A(n2643), .Y(n2676) );
  OAI32X1 U1412 ( .A0(n2705), .A1(n2706), .A2(n2707), .B0(n2893), .B1(n2709), 
        .Y(n2618) );
  INVX1 U1413 ( .A(n2697), .Y(n2706) );
  INVX1 U1414 ( .A(n2709), .Y(n2705) );
  OAI221X1 U1415 ( .A0(n2651), .A1(n2905), .B0(n2711), .B1(n2920), .C0(n2712), 
        .Y(n2709) );
  NAND4X1 U1416 ( .A(BF_TREADY), .B(n2671), .C(n2919), .D(n2909), .Y(n2686) );
  INVX1 U1417 ( .A(n2655), .Y(n2662) );
  INVX1 U1418 ( .A(n2801), .Y(n2793) );
  NAND2BX1 U1419 ( .AN(n2782), .B(n2655), .Y(n2801) );
  INVX1 U1420 ( .A(n2798), .Y(n2796) );
  INVX1 U1421 ( .A(n2678), .Y(n2641) );
  OAI33X1 U1422 ( .A0(n2679), .A1(n2910), .A2(n2681), .B0(n2679), .B1(n2682), 
        .B2(n2910), .Y(n2678) );
  NAND4BX1 U1423 ( .AN(BF_CMD[3]), .B(n2684), .C(n2685), .D(n2683), .Y(n2681)
         );
  NAND4BX1 U1424 ( .AN(n2683), .B(n2684), .C(BF_CMD[3]), .D(n2685), .Y(n2682)
         );
  INVX1 U1425 ( .A(n2699), .Y(n2711) );
  NAND2BX1 U1426 ( .AN(n2920), .B(n2695), .Y(n2692) );
  INVX1 U1427 ( .A(n2785), .Y(n2695) );
  NAND2BX1 U1428 ( .AN(n2704), .B(n2667), .Y(n2785) );
  INVX1 U1429 ( .A(n2657), .Y(n2671) );
  INVX1 U1430 ( .A(n2811), .Y(n2813) );
  INVX1 U1431 ( .A(n2884), .Y(BF_LAST) );
  NAND2BX1 U1432 ( .AN(n2906), .B(n2921), .Y(n2884) );
  INVX1 U1433 ( .A(ERCMD[2]), .Y(n2778) );
  INVX1 U1434 ( .A(n2651), .Y(n2703) );
  NAND3BX1 U1435 ( .AN(CAS_0_TT[4]), .B(n2879), .C(n2880), .Y(n2876) );
  NAND4BX1 U1436 ( .AN(n2643), .B(n2828), .C(n2829), .D(BF_IDLE), .Y(n2683) );
  AND4X1 U1437 ( .A(n2830), .B(n2831), .C(n2832), .D(n2833), .Y(n2829) );
  INVX1 U1438 ( .A(RAS_0_TT[1]), .Y(n2830) );
  INVX1 U1439 ( .A(RAS_0_TT[4]), .Y(n2833) );
  AO21X1 U1440 ( .A0(n2662), .A1(cbs_rowopen), .B0(BF_IDLE), .Y(BF_READY) );
  NAND4BX1 U1441 ( .AN(BF_TRASBUSY), .B(n2894), .C(n2887), .D(n2835), .Y(n2643) );
  XNOR2X1 U1442 ( .A(RAS_0_RA[11]), .B(CAS_0_RA[11]), .Y(n2856) );
  NAND2BX1 U1443 ( .AN(trasmin_cnt[3]), .B(n2915), .Y(n2655) );
  INVX1 U1444 ( .A(n2714), .Y(n2707) );
  NAND4BX1 U1445 ( .AN(n2715), .B(n2716), .C(n2717), .D(n2718), .Y(n2714) );
  AOI221X1 U1446 ( .A0(LAST_RA[6]), .A1(n2889), .B0(LAST_RA[7]), .B1(n2903), 
        .C0(n2756), .Y(n2716) );
  AOI221X1 U1447 ( .A0(LAST_RA[8]), .A1(n2888), .B0(LAST_RA[9]), .B1(n2904), 
        .C0(n2751), .Y(n2717) );
  XNOR2X1 U1448 ( .A(RAS_0_RA[5]), .B(CAS_0_RA[5]), .Y(n2867) );
  XNOR2X1 U1449 ( .A(RAS_0_RA[2]), .B(CAS_0_RA[2]), .Y(n2850) );
  XNOR2X1 U1450 ( .A(RAS_0_RA[8]), .B(CAS_0_RA[8]), .Y(n2862) );
  XNOR2X1 U1451 ( .A(RAS_0_RA[1]), .B(CAS_0_RA[1]), .Y(n2849) );
  XNOR2X1 U1452 ( .A(RAS_0_RA[7]), .B(CAS_0_RA[7]), .Y(n2861) );
  NOR3X2 U1453 ( .A(CAS_EMPTY), .B(n2913), .C(n2914), .Y(n2912) );
  XNOR2X1 U1454 ( .A(n2754), .B(CAS_0_BA[1]), .Y(n2913) );
  XNOR2X1 U1455 ( .A(n2872), .B(CAS_0_BA[0]), .Y(n2914) );
  NAND2BX1 U1456 ( .AN(length[0]), .B(n2921), .Y(BF_CASBUSY) );
  XOR2X1 U1457 ( .A(RAS_0_RA[6]), .B(CAS_0_RA[6]), .Y(n2865) );
  XOR2X1 U1458 ( .A(RAS_0_RA[3]), .B(CAS_0_RA[3]), .Y(n2848) );
  XOR2X1 U1459 ( .A(RAS_0_RA[9]), .B(CAS_0_RA[9]), .Y(n2860) );
  AND2X2 U1460 ( .A(n2916), .B(n2796), .Y(n2915) );
  OAI32X1 U1461 ( .A0(n2820), .A1(n2821), .A2(n2822), .B0(ERCMD[5]), .B1(n2823), .Y(n2780) );
  INVX1 U1462 ( .A(ERCMD[1]), .Y(n2823) );
  OR2X1 U1463 ( .A(ECMD[3]), .B(ECMD[2]), .Y(n2822) );
  XOR2X1 U1464 ( .A(RAS_0_RA[0]), .B(CAS_0_RA[0]), .Y(n2853) );
  XOR2X1 U1465 ( .A(n2859), .B(CAS_0_RA[10]), .Y(n2854) );
  XOR2X1 U1466 ( .A(n2858), .B(CAS_0_RA[12]), .Y(n2855) );
  NAND3X1 U1467 ( .A(n2917), .B(n2753), .C(BA_REQ), .Y(n2751) );
  XNOR2X1 U1468 ( .A(BF_NO[0]), .B(BA_BA[0]), .Y(n2917) );
  NAND3BX1 U1469 ( .AN(n2760), .B(n2761), .C(n2762), .Y(n2715) );
  AOI221X1 U1470 ( .A0(LAST_RA[1]), .A1(n2892), .B0(LAST_RA[2]), .B1(n2918), 
        .C0(n2765), .Y(n2762) );
  OAI222X1 U1471 ( .A0(LAST_RA[8]), .A1(n2772), .B0(LAST_RA[7]), .B1(n2744), 
        .C0(BA_RA[8]), .C1(n2888), .Y(n2760) );
  AOI222X1 U1472 ( .A0(openedrow[9]), .A1(n2769), .B0(LAST_RA[0]), .B1(n2895), 
        .C0(BA_RA[9]), .C1(n2771), .Y(n2761) );
  NOR2BX1 U1473 ( .AN(cbs_rowopen), .B(n2704), .Y(n2702) );
  INVX1 U1474 ( .A(RAS_0_TT[0]), .Y(n2828) );
  OR2X1 U1475 ( .A(trrd_cnt_0_), .B(trrd_cnt_1_), .Y(BF_RASBUSY) );
  INVX1 U1476 ( .A(RAS_0_TT[3]), .Y(n2832) );
  INVX1 U1477 ( .A(RAS_0_TT[2]), .Y(n2831) );
  INVX1 U1478 ( .A(CAS_0_TT[2]), .Y(n2880) );
  INVX1 U1479 ( .A(CAS_0_TT[3]), .Y(n2879) );
  XNOR2X1 U1480 ( .A(RAS_0_RA[4]), .B(CAS_0_RA[4]), .Y(n2866) );
  OAI22X1 U1481 ( .A0(n2740), .A1(LAST_RA[2]), .B0(n2918), .B1(BA_RA[2]), .Y(
        n2738) );
  INVX1 U1482 ( .A(BA_RA[2]), .Y(n2740) );
  AOI211X1 U1483 ( .A0(openedrow[3]), .A1(n2736), .B0(n2737), .C0(n2738), .Y(
        n2720) );
  AOI221X1 U1484 ( .A0(BA_RA[6]), .A1(n2743), .B0(openedrow[7]), .B1(n2744), 
        .C0(n2745), .Y(n2719) );
  AOI211X1 U1485 ( .A0(openedrow[0]), .A1(n2723), .B0(n2724), .C0(n2725), .Y(
        n2722) );
  AOI221X1 U1486 ( .A0(openedrow[1]), .A1(n2730), .B0(BA_RA[1]), .B1(n2731), 
        .C0(n2732), .Y(n2721) );
  INVX1 U1487 ( .A(LAST_RA[1]), .Y(n2731) );
  INVX1 U1488 ( .A(BA_RA[1]), .Y(n2730) );
  OAI222X1 U1489 ( .A0(LAST_RA[12]), .A1(n2733), .B0(LAST_RA[11]), .B1(n2734), 
        .C0(BA_RA[12]), .C1(n2896), .Y(n2732) );
  NOR2X1 U1490 ( .A(BF_IDLE), .B(n2920), .Y(n2919) );
  NOR4X1 U1491 ( .A(length[4]), .B(length[3]), .C(length[1]), .D(length[2]), 
        .Y(n2921) );
  AOI211X1 U1492 ( .A0(n2654), .A1(n2655), .B0(n2641), .C0(n2656), .Y(n2653)
         );
  OAI31X1 U1493 ( .A0(n2657), .A1(newrowexist), .A2(BF_TREADY), .B0(n2658), 
        .Y(n2656) );
  AOI31X1 U1494 ( .A0(n2657), .A1(n2659), .A2(n2660), .B0(n2661), .Y(n2658) );
  NOR2BX1 U1495 ( .AN(n2909), .B(n2912), .Y(n2660) );
  INVX1 U1496 ( .A(n2838), .Y(BF_REQCMD[1]) );
  OAI211X1 U1497 ( .A0(n2839), .A1(n2840), .B0(BF_IDLE), .C0(n2676), .Y(n2838)
         );
  NAND2BX1 U1498 ( .AN(RAS_0_TT[1]), .B(n2828), .Y(n2840) );
  NAND3BX1 U1499 ( .AN(RAS_0_TT[4]), .B(n2832), .C(n2831), .Y(n2839) );
  INVX1 U1500 ( .A(RAS_0_RA[10]), .Y(n2859) );
  INVX1 U1501 ( .A(RAS_0_RA[12]), .Y(n2858) );
  OR3X2 U1502 ( .A(ECMD[4]), .B(ECMD[6]), .C(ERCMD[1]), .Y(n2821) );
  OAI33X1 U1503 ( .A0(n2668), .A1(BF_IDLE), .A2(n2901), .B0(n2641), .B1(n2638), 
        .B2(n2670), .Y(nextstate[1]) );
  INVX1 U1504 ( .A(n2674), .Y(n2668) );
  AOI32X1 U1505 ( .A0(BF_TREADY), .A1(n2909), .A2(n2671), .B0(n2662), .B1(
        n2672), .Y(n2670) );
  OAI33X1 U1506 ( .A0(n2636), .A1(n2637), .A2(n2638), .B0(BF_LAST), .B1(n2902), 
        .B2(n2640), .Y(nextstate[4]) );
  OAI2BB1X1 U1507 ( .A0N(TRASMIN[2]), .A1N(n2782), .B0(n2797), .Y(n2597) );
  AOI32X1 U1508 ( .A0(trasmin_cnt[2]), .A1(n2798), .A2(n2793), .B0(n2793), 
        .B1(n2915), .Y(n2797) );
  OAI2BB1X1 U1509 ( .A0N(TRASMIN[1]), .A1N(n2782), .B0(n2795), .Y(n2598) );
  AOI32X1 U1510 ( .A0(trasmin_cnt[0]), .A1(trasmin_cnt[1]), .A2(n2793), .B0(
        n2793), .B1(n2796), .Y(n2795) );
  OAI2BB1X1 U1511 ( .A0N(cbs_rowopen), .A1N(n2699), .B0(n2700), .Y(n2698) );
  AOI32X1 U1512 ( .A0(n2701), .A1(CAS_0_NEWROW), .A2(n2702), .B0(
        cas_0_newrow_l), .B1(n2703), .Y(n2700) );
  OAI222X1 U1513 ( .A0(LAST_RA[5]), .A1(n2746), .B0(BA_RA[5]), .B1(n2898), 
        .C0(BA_RA[6]), .C1(n2889), .Y(n2745) );
  INVX1 U1514 ( .A(BA_RA[5]), .Y(n2746) );
  OAI222X1 U1515 ( .A0(LAST_RA[10]), .A1(n2727), .B0(BA_RA[10]), .B1(n2899), 
        .C0(BA_RA[11]), .C1(n2890), .Y(n2724) );
  INVX1 U1516 ( .A(BA_RA[10]), .Y(n2727) );
  OAI222X1 U1517 ( .A0(LAST_RA[4]), .A1(n2741), .B0(LAST_RA[3]), .B1(n2736), 
        .C0(BA_RA[4]), .C1(n2897), .Y(n2737) );
  INVX1 U1518 ( .A(BA_RA[4]), .Y(n2741) );
  AO21X1 U1519 ( .A0(n2641), .A1(BF_IDLE), .B0(n2675), .Y(nextstate[0]) );
  OAI222X1 U1520 ( .A0(n2901), .A1(n2674), .B0(cbs_casing), .B1(n2640), .C0(
        n2676), .C1(n2891), .Y(n2675) );
  AO21X1 U1521 ( .A0(n2648), .A1(n2649), .B0(n2650), .Y(nextstate[2]) );
  INVX1 U1522 ( .A(n2638), .Y(n2648) );
  OAI33X1 U1523 ( .A0(n2647), .A1(n2644), .A2(n2900), .B0(n2651), .B1(
        cbs_rasing), .B2(n2644), .Y(n2650) );
  OAI2BB1X1 U1524 ( .A0N(n2636), .A1N(n2652), .B0(n2653), .Y(n2649) );
  AOI31X1 U1525 ( .A0(n2701), .A1(CAS_0_FINAL), .A2(n2713), .B0(n2707), .Y(
        n2712) );
  NOR2BX1 U1526 ( .AN(cbs_rowopen), .B(n2704), .Y(n2713) );
  OAI31X1 U1527 ( .A0(n2773), .A1(ERCMD[0]), .A2(n2774), .B0(n2775), .Y(n2699)
         );
  INVX1 U1528 ( .A(n2704), .Y(n2774) );
  INVX1 U1529 ( .A(n2780), .Y(n2776) );
  NAND2X1 U1530 ( .A(CAS_EMPTY), .B(RAS_EMPTY), .Y(n2657) );
  AND4X1 U1531 ( .A(n2824), .B(n2778), .C(n2779), .D(n2777), .Y(n2816) );
  INVX1 U1532 ( .A(ERCMD[0]), .Y(n2824) );
  AO22X1 U1533 ( .A0(length749_3_), .A1(n2911), .B0(CAS_0_TT[3]), .B1(n2695), 
        .Y(n2601) );
  XNOR2X1 U1_A_3 ( .A(length[3]), .B(carry_3_), .Y(length749_3_) );
  AO22X1 U1534 ( .A0(length749_2_), .A1(n2911), .B0(CAS_0_TT[2]), .B1(n2695), 
        .Y(n2602) );
  XNOR2X1 U1_A_2 ( .A(length[2]), .B(carry_2_), .Y(length749_2_) );
  AO22X1 U1535 ( .A0(length749_1_), .A1(n2911), .B0(CAS_0_TT[1]), .B1(n2695), 
        .Y(n2603) );
  XNOR2X1 U1_A_1 ( .A(length[1]), .B(length[0]), .Y(length749_1_) );
  AO22X1 U1536 ( .A0(n2911), .A1(n2906), .B0(CAS_0_TT[0]), .B1(n2695), .Y(
        n2604) );
  AO22X1 U1537 ( .A0(openedrow[5]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[5]), 
        .Y(n2612) );
  AO22X1 U1538 ( .A0(openedrow[4]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[4]), 
        .Y(n2613) );
  AO21X1 U1539 ( .A0(BA_RA[0]), .A1(n2726), .B0(LAST_RA[13]), .Y(n2725) );
  INVX1 U1540 ( .A(LAST_RA[0]), .Y(n2726) );
  AO22X1 U1541 ( .A0(TRASMIN[0]), .A1(n2782), .B0(n2793), .B1(n2908), .Y(n2599) );
  AO22X1 U1542 ( .A0(openedrow[9]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[9]), 
        .Y(n2608) );
  AO22X1 U1543 ( .A0(openedrow[6]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[6]), 
        .Y(n2611) );
  AO22X1 U1544 ( .A0(openedrow[3]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[3]), 
        .Y(n2614) );
  AO22X1 U1545 ( .A0(openedrow[0]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[0]), 
        .Y(n2617) );
  AO22X1 U1546 ( .A0(length749_4_), .A1(n2911), .B0(CAS_0_TT[4]), .B1(n2695), 
        .Y(n2600) );
  XNOR2X1 U1_A_4 ( .A(length[4]), .B(carry_4_), .Y(length749_4_) );
  OR2X1 U1_B_3 ( .A(length[3]), .B(carry_3_), .Y(carry_4_) );
  AO22X1 U1547 ( .A0(TRCD[1]), .A1(n2782), .B0(n2803), .B1(n2922), .Y(n2594)
         );
  NOR2BX1 U1548 ( .AN(trcd_cnt[0]), .B(n2907), .Y(n2803) );
  AO22X1 U1549 ( .A0(TRASMIN[3]), .A1(n2782), .B0(n2800), .B1(n2793), .Y(n2596) );
  NOR2BX1 U1550 ( .AN(trasmin_cnt[3]), .B(n2915), .Y(n2800) );
  AO22X1 U1551 ( .A0(TRP[1]), .A1(n2811), .B0(n2814), .B1(n2813), .Y(n2590) );
  NOR2BX1 U1552 ( .AN(trp_cnt[1]), .B(n2887), .Y(n2814) );
  AO22X1 U1553 ( .A0(TRRD[1]), .A1(n2782), .B0(n2806), .B1(n2922), .Y(n2592)
         );
  AO22X1 U1554 ( .A0(TRCD[0]), .A1(n2782), .B0(n2802), .B1(n2922), .Y(n2595)
         );
  NOR2BX1 U1555 ( .AN(trcd_cnt[1]), .B(trcd_cnt[0]), .Y(n2802) );
  AO22X1 U1556 ( .A0(cas_0_final_l), .A1(n2692), .B0(CAS_0_FINAL), .B1(n2693), 
        .Y(n2620) );
  AO22X1 U1557 ( .A0(cas_0_newrow_l), .A1(n2692), .B0(CAS_0_NEWROW), .B1(n2693), .Y(n2621) );
  AO22X1 U1558 ( .A0(TRP[0]), .A1(n2811), .B0(n2812), .B1(n2813), .Y(n2591) );
  NOR2BX1 U1559 ( .AN(trp_cnt[1]), .B(trp_cnt[0]), .Y(n2812) );
  AO22X1 U1560 ( .A0(TRRD[0]), .A1(n2782), .B0(n2805), .B1(n2922), .Y(n2593)
         );
  NOR2BX1 U1561 ( .AN(trrd_cnt_1_), .B(trrd_cnt_0_), .Y(n2805) );
  NAND3BX1 U1562 ( .AN(cbs_rowopen), .B(cbs_casing), .C(BF_LAST), .Y(n2651) );
  INVX1 U1563 ( .A(ERCMD[3]), .Y(n2779) );
  INVX1 U1564 ( .A(ERCMD[4]), .Y(n2777) );
  OAI222X1 U1565 ( .A0(openedrow[4]), .A1(n2757), .B0(openedrow[3]), .B1(n2758), .C0(openedrow[5]), .C1(n2759), .Y(n2756) );
  INVX1 U1566 ( .A(LAST_RA[5]), .Y(n2759) );
  INVX1 U1567 ( .A(LAST_RA[4]), .Y(n2757) );
  INVX1 U1568 ( .A(LAST_RA[3]), .Y(n2758) );
  OAI222X1 U1569 ( .A0(openedrow[11]), .A1(n2766), .B0(openedrow[10]), .B1(
        n2767), .C0(openedrow[12]), .C1(n2768), .Y(n2765) );
  INVX1 U1570 ( .A(LAST_RA[12]), .Y(n2768) );
  INVX1 U1571 ( .A(LAST_RA[10]), .Y(n2767) );
  INVX1 U1572 ( .A(LAST_RA[11]), .Y(n2766) );
  AOI211X1 U1573 ( .A0(n2662), .A1(newrowenable), .B0(n2663), .C0(n2659), .Y(
        n2661) );
  INVX1 U1574 ( .A(LAST_RA[6]), .Y(n2743) );
  INVX1 U1575 ( .A(LAST_RA[9]), .Y(n2771) );
  NAND3BX1 U1576 ( .AN(cbs_rasing), .B(n2901), .C(n2919), .Y(n2638) );
  NAND2BX1 U1577 ( .AN(cbs_pcing), .B(n2891), .Y(n2644) );
  NAND2BX1 U1578 ( .AN(trp_cnt[1]), .B(trp_cnt[0]), .Y(n2674) );
  NAND2BX1 U1579 ( .AN(trcd_cnt[1]), .B(trcd_cnt[0]), .Y(n2647) );
  NAND3BX1 U1580 ( .AN(cbs_rowopen), .B(n2900), .C(n2677), .Y(n2640) );
  INVX1 U1581 ( .A(n2644), .Y(n2677) );
  OR2X1 U1_B_1 ( .A(length[1]), .B(length[0]), .Y(carry_2_) );
  OR2X1 U1_B_2 ( .A(length[2]), .B(carry_2_), .Y(carry_3_) );
  INVX1 U1582 ( .A(BF_NO[0]), .Y(n2872) );
  INVX1 U1583 ( .A(BF_NO[1]), .Y(n2754) );
  DFFSX1 currstate_reg_0_ ( .D(nextstate[0]), .CK(ACLK), .SN(ARESETB), .Q(
        BF_IDLE), .QN(n2891) );
  DFFRX1 currstate_reg_2_ ( .D(nextstate[2]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_rowopen), .QN(n2920) );
  DFFRX1 length_reg_0_ ( .D(n2604), .CK(ACLK), .RN(ARESETB), .Q(length[0]), 
        .QN(n2906) );
  DFFRX1 trp_cnt_reg_0_ ( .D(n2591), .CK(ACLK), .RN(ARESETB), .Q(trp_cnt[0]), 
        .QN(n2887) );
  DFFRX1 trrd_cnt_reg_0_ ( .D(n2593), .CK(ACLK), .RN(ARESETB), .Q(trrd_cnt_0_)
         );
  DFFRX1 trp_cnt_reg_1_ ( .D(n2590), .CK(ACLK), .RN(ARESETB), .Q(trp_cnt[1]), 
        .QN(n2894) );
  DFFRX1 trrd_cnt_reg_1_ ( .D(n2592), .CK(ACLK), .RN(ARESETB), .Q(trrd_cnt_1_)
         );
  DFFRX1 newrowexist_reg ( .D(n2619), .CK(ACLK), .RN(ARESETB), .Q(newrowexist), 
        .QN(n2909) );
  DFFRX1 trasmin_cnt_reg_0_ ( .D(n2599), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[0]), .QN(n2908) );
  DFFRX1 trasmin_cnt_reg_1_ ( .D(n2598), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[1]) );
  DFFRX1 newrowenable_reg ( .D(n2618), .CK(ACLK), .RN(ARESETB), .Q(
        newrowenable), .QN(n2893) );
  DFFRX1 length_reg_2_ ( .D(n2602), .CK(ACLK), .RN(ARESETB), .Q(length[2]) );
  DFFRX1 length_reg_1_ ( .D(n2603), .CK(ACLK), .RN(ARESETB), .Q(length[1]) );
  DFFRX1 length_reg_3_ ( .D(n2601), .CK(ACLK), .RN(ARESETB), .Q(length[3]) );
  DFFRX1 length_reg_4_ ( .D(n2600), .CK(ACLK), .RN(ARESETB), .Q(length[4]) );
  DFFRX1 trasmin_cnt_reg_3_ ( .D(n2596), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[3]) );
  DFFRX1 trasmin_cnt_reg_2_ ( .D(n2597), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[2]), .QN(n2916) );
  DFFRX1 openedrow_reg_5_ ( .D(n2612), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[5]), .QN(n2898) );
  DFFRX1 openedrow_reg_9_ ( .D(n2608), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[9]), .QN(n2904) );
  DFFRX1 openedrow_reg_0_ ( .D(n2617), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[0]), .QN(n2895) );
  DFFRX1 openedrow_reg_4_ ( .D(n2613), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[4]), .QN(n2897) );
  DFFRX1 openedrow_reg_2_ ( .D(n2615), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[2]), .QN(n2918) );
  DFFRX1 openedrow_reg_6_ ( .D(n2611), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[6]), .QN(n2889) );
  DFFRX1 openedrow_reg_12_ ( .D(n2605), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[12]), .QN(n2896) );
  DFFRX1 openedrow_reg_1_ ( .D(n2616), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[1]), .QN(n2892) );
  DFFRX1 openedrow_reg_7_ ( .D(n2610), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[7]), .QN(n2903) );
  DFFRX1 openedrow_reg_10_ ( .D(n2607), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[10]), .QN(n2899) );
  DFFRX1 openedrow_reg_11_ ( .D(n2606), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[11]), .QN(n2890) );
  DFFRX1 openedrow_reg_8_ ( .D(n2609), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[8]), .QN(n2888) );
  DFFRX1 openedrow_reg_3_ ( .D(n2614), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[3]) );
  DFFRX1 currstate_reg_4_ ( .D(nextstate[4]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_casing), .QN(n2902) );
  DFFRX1 trcd_cnt_reg_1_ ( .D(n2594), .CK(ACLK), .RN(ARESETB), .Q(trcd_cnt[1]), 
        .QN(n2907) );
  DFFRX1 currstate_reg_3_ ( .D(nextstate[3]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_rasing), .QN(n2900) );
  DFFRX1 cas_0_final_l_reg ( .D(n2620), .CK(ACLK), .RN(ARESETB), .Q(
        cas_0_final_l), .QN(n2905) );
  DFFRX1 currstate_reg_1_ ( .D(nextstate[1]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_pcing), .QN(n2901) );
  DFFRX1 trcd_cnt_reg_0_ ( .D(n2595), .CK(ACLK), .RN(ARESETB), .Q(trcd_cnt[0])
         );
  DFFRX1 cas_0_newrow_l_reg ( .D(n2621), .CK(ACLK), .RN(ARESETB), .Q(
        cas_0_newrow_l) );
  XOR2X1 U1584 ( .A(n2754), .B(RAS_0_BA[1]), .Y(n2870) );
  AO22X1 U1585 ( .A0(openedrow[7]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[7]), 
        .Y(n2610) );
  AO22X1 U1586 ( .A0(openedrow[8]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[8]), 
        .Y(n2609) );
  AO22X1 U1587 ( .A0(openedrow[1]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[1]), 
        .Y(n2616) );
  AO22X1 U1588 ( .A0(openedrow[10]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[10]), 
        .Y(n2607) );
  AO22X1 U1589 ( .A0(openedrow[2]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[2]), 
        .Y(n2615) );
  NAND4BBX1 U1590 ( .AN(ECMD[1]), .BN(ECMD[0]), .C(ERCMD[5]), .D(ECMD[5]), .Y(
        n2820) );
  AO22X1 U1591 ( .A0(openedrow[12]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[12]), 
        .Y(n2605) );
  AO22X1 U1592 ( .A0(openedrow[11]), .A1(n2922), .B0(n2782), .B1(RAS_0_RA[11]), 
        .Y(n2606) );
  XOR2X1 U1593 ( .A(n2754), .B(BA_BA[1]), .Y(n2753) );
endmodule


module SDRBsm_0 ( ARESETB, ACLK, TRP, TRRD, TRCD, TRASMIN, BA_BA, BA_RA, BA_TT, 
        BA_REQ, CAS_0_BA, CAS_0_RA, CAS_0_TT, CAS_0_FINAL, CAS_0_NEWROW, 
        CAS_EMPTY, LAST_RA, RAS_0_BA, RAS_0_RA, RAS_0_TT, RAS_EMPTY, BF_NO, 
        BF_CASBUSY, BF_TCASBUSY, BF_RASBUSY, BF_TRASBUSY, BF_READY, BF_TREADY, 
        BF_IDLE, BF_LAST, BF_REQCMD, BF_CMD, ERCMD, ECMD );
  input [1:0] TRP;
  input [1:0] TRRD;
  input [1:0] TRCD;
  input [3:0] TRASMIN;
  input [1:0] BA_BA;
  input [12:0] BA_RA;
  input [4:0] BA_TT;
  input [1:0] CAS_0_BA;
  input [12:0] CAS_0_RA;
  input [4:0] CAS_0_TT;
  input [13:0] LAST_RA;
  input [1:0] RAS_0_BA;
  input [12:0] RAS_0_RA;
  input [4:0] RAS_0_TT;
  input [1:0] BF_NO;
  output [5:0] BF_REQCMD;
  input [5:0] BF_CMD;
  input [5:0] ERCMD;
  input [6:0] ECMD;
  input ARESETB, ACLK, BA_REQ, CAS_0_FINAL, CAS_0_NEWROW, CAS_EMPTY, RAS_EMPTY,
         BF_TCASBUSY, BF_TRASBUSY, BF_TREADY;
  output BF_CASBUSY, BF_RASBUSY, BF_READY, BF_IDLE, BF_LAST;
  wire   cbs_pcing, cbs_rowopen, cbs_rasing, cbs_casing, cas_0_final_l,
         cas_0_newrow_l, newrowenable, trrd_cnt_1_, trrd_cnt_0_, length749_4_,
         length749_3_, length749_2_, length749_1_, newrowexist, n2590, n2591,
         n2592, n2593, n2594, n2595, n2596, n2597, n2598, n2599, n2600, n2601,
         n2602, n2603, n2604, n2605, n2606, n2607, n2608, n2609, n2610, n2611,
         n2612, n2613, n2614, n2615, n2616, n2617, n2618, n2619, n2620, n2621,
         carry_4_, carry_3_, carry_2_, n2634, n2635, n2636, n2638, n2639,
         n2641, n2642, n2643, n2645, n2646, n2647, n2648, n2649, n2650, n2651,
         n2652, n2653, n2654, n2655, n2656, n2657, n2658, n2659, n2660, n2661,
         n2664, n2665, n2666, n2668, n2669, n2670, n2672, n2673, n2674, n2675,
         n2676, n2677, n2679, n2680, n2681, n2682, n2683, n2684, n2686, n2687,
         n2688, n2689, n2690, n2691, n2693, n2695, n2696, n2697, n2698, n2699,
         n2700, n2701, n2702, n2703, n2704, n2705, n2707, n2709, n2710, n2711,
         n2712, n2713, n2714, n2715, n2716, n2717, n2718, n2719, n2720, n2721,
         n2722, n2723, n2724, n2725, n2728, n2729, n2730, n2731, n2732, n2734,
         n2735, n2736, n2738, n2739, n2741, n2742, n2743, n2744, n2749, n2751,
         n2752, n2754, n2755, n2756, n2757, n2758, n2759, n2760, n2763, n2764,
         n2765, n2766, n2767, n2769, n2770, n2771, n2772, n2773, n2774, n2775,
         n2776, n2777, n2778, n2779, n2780, n2783, n2786, n2787, n2788, n2789,
         n2790, n2791, n2793, n2794, n2795, n2796, n2798, n2799, n2800, n2801,
         n2803, n2804, n2806, n2807, n2808, n2809, n2810, n2811, n2812, n2814,
         n2815, n2816, n2817, n2818, n2819, n2820, n2821, n2822, n2825, n2826,
         n2827, n2828, n2829, n2830, n2831, n2832, n2833, n2834, n2835, n2836,
         n2837, n2838, n2842, n2843, n2844, n2845, n2846, n2847, n2848, n2851,
         n2852, n2853, n2854, n2856, n2857, n2858, n2859, n2860, n2863, n2864,
         n2865, n2870, n2874, n2877, n2878, n2882, n2885, n2886, n2887, n2888,
         n2889, n2890, n2891, n2892, n2893, n2894, n2895, n2896, n2897, n2898,
         n2899, n2900, n2901, n2902, n2903, n2904, n2905, n2906, n2907, n2908,
         n2909, n2910, n2911, n2912, n2913, n2914, n2915, n2916, n2917, n2918,
         n2919, n2920, n2921, n2922, n2923;
  wire   [4:0] length;
  wire   [12:0] openedrow;
  wire   [3:0] trasmin_cnt;
  wire   [4:0] nextstate;
  wire   [1:0] trcd_cnt;
  wire   [1:0] trp_cnt;

  AO22X4 U1282 ( .A0(n2919), .A1(n2834), .B0(n2661), .B1(n2835), .Y(n2650) );
  NAND2BX4 U1311 ( .AN(n2657), .B(n2919), .Y(n2834) );
  INVX1 U1344 ( .A(n2657), .Y(n2833) );
  OAI32X1 U1345 ( .A0(n2908), .A1(n2919), .A2(n2833), .B0(n2834), .B1(n2835), 
        .Y(n2652) );
  OR2X1 U1346 ( .A(n2699), .B(n2825), .Y(n2689) );
  INVX1 U1347 ( .A(n2686), .Y(BF_REQCMD[2]) );
  OR4X2 U1348 ( .A(n2842), .B(n2843), .C(n2844), .D(n2845), .Y(n2835) );
  NAND3BX2 U1349 ( .AN(n2858), .B(n2859), .C(n2860), .Y(n2843) );
  INVX1 U1350 ( .A(n2689), .Y(BF_REQCMD[0]) );
  NAND3BX2 U1351 ( .AN(RAS_EMPTY), .B(n2909), .C(n2910), .Y(n2657) );
  OR2X1 U1352 ( .A(trasmin_cnt[0]), .B(trasmin_cnt[1]), .Y(n2796) );
  OAI31X1 U1353 ( .A0(n2661), .A1(n2891), .A2(n2657), .B0(n2832), .Y(n2670) );
  INVX1 U1354 ( .A(n2652), .Y(n2832) );
  XOR2X1 U1355 ( .A(n2752), .B(RAS_0_BA[1]), .Y(n2909) );
  XOR2X1 U1356 ( .A(n2870), .B(RAS_0_BA[0]), .Y(n2910) );
  NAND4BX1 U1357 ( .AN(n2851), .B(n2852), .C(n2853), .D(n2854), .Y(n2844) );
  INVX3 U1358 ( .A(n2650), .Y(n2635) );
  AND2X1 U1359 ( .A(BF_CASBUSY), .B(n2702), .Y(n2912) );
  OR3X2 U1360 ( .A(n2874), .B(CAS_0_TT[1]), .C(CAS_0_TT[0]), .Y(n2665) );
  OAI2BB2X1 U1361 ( .A0N(n2695), .A1N(n2696), .B0(n2696), .B1(n2908), .Y(n2619) );
  AND2X1 U1362 ( .A(trrd_cnt_1_), .B(trrd_cnt_0_), .Y(n2804) );
  OR3X1 U1363 ( .A(ECMD[4]), .B(ECMD[6]), .C(ERCMD[1]), .Y(n2819) );
  INVX1 U1364 ( .A(BF_CMD[2]), .Y(n2789) );
  INVX1 U1365 ( .A(BF_CMD[4]), .Y(n2682) );
  INVX1 U1366 ( .A(BF_CMD[0]), .Y(n2807) );
  NAND3BX1 U1367 ( .AN(n2786), .B(n2787), .C(n2788), .Y(n2702) );
  XOR2X1 U1368 ( .A(BF_CMD[4]), .B(BF_CMD[0]), .Y(n2788) );
  NAND3BX1 U1369 ( .AN(BF_CMD[5]), .B(n2789), .C(n2790), .Y(n2786) );
  NAND3BX1 U1370 ( .AN(n2816), .B(n2807), .C(n2817), .Y(n2773) );
  XOR2X1 U1371 ( .A(BF_CMD[5]), .B(BF_CMD[2]), .Y(n2817) );
  NAND3BX1 U1372 ( .AN(BF_CMD[4]), .B(n2790), .C(n2787), .Y(n2816) );
  INVX1 U1373 ( .A(BF_CMD[3]), .Y(n2790) );
  INVX1 U1374 ( .A(n2923), .Y(n2780) );
  NOR2BX1 U1375 ( .AN(n2699), .B(n2825), .Y(BF_REQCMD[4]) );
  INVX1 U1376 ( .A(BA_RA[9]), .Y(n2767) );
  XNOR2X1 U1377 ( .A(n2686), .B(BF_CMD[2]), .Y(n2911) );
  INVX1 U1378 ( .A(BA_RA[3]), .Y(n2734) );
  INVX1 U1379 ( .A(BA_RA[7]), .Y(n2742) );
  INVX1 U1380 ( .A(BA_RA[8]), .Y(n2770) );
  INVX1 U1381 ( .A(BA_RA[11]), .Y(n2732) );
  INVX1 U1382 ( .A(n2684), .Y(BF_REQCMD[5]) );
  INVX1 U1383 ( .A(BA_RA[12]), .Y(n2731) );
  INVX1 U1384 ( .A(n2834), .Y(n2661) );
  INVX1 U1385 ( .A(BF_TCASBUSY), .Y(n2664) );
  INVX1 U1386 ( .A(BF_CMD[1]), .Y(n2787) );
  XOR2X1 U1387 ( .A(n2684), .B(BF_CMD[5]), .Y(n2683) );
  INVX1 U1388 ( .A(BA_RA[0]), .Y(n2721) );
  BUFX2 U1389 ( .A(n2779), .Y(n2923) );
  NAND3BX1 U1390 ( .AN(n2806), .B(n2807), .C(n2808), .Y(n2779) );
  NAND3BX1 U1391 ( .AN(BF_CMD[5]), .B(n2789), .C(n2682), .Y(n2806) );
  XOR2X1 U1392 ( .A(BF_CMD[3]), .B(BF_CMD[1]), .Y(n2808) );
  INVX1 U1393 ( .A(n2690), .Y(n2691) );
  NAND3BX2 U1394 ( .AN(n2635), .B(n2664), .C(n2917), .Y(n2825) );
  NAND2BX1 U1395 ( .AN(n2918), .B(n2702), .Y(n2695) );
  NAND3BX2 U1396 ( .AN(n2653), .B(n2917), .C(n2670), .Y(n2686) );
  NAND3BX1 U1397 ( .AN(n2639), .B(n2664), .C(n2665), .Y(n2634) );
  NAND3BX1 U1398 ( .AN(n2846), .B(n2847), .C(n2848), .Y(n2845) );
  NAND3BX2 U1399 ( .AN(n2863), .B(n2864), .C(n2865), .Y(n2842) );
  NAND2BX1 U1400 ( .AN(n2687), .B(n2688), .Y(n2677) );
  XOR2X1 U1401 ( .A(n2689), .B(BF_CMD[0]), .Y(n2688) );
  XOR2X1 U1402 ( .A(BF_CMD[1]), .B(BF_REQCMD[1]), .Y(n2687) );
  INVX1 U1403 ( .A(n2665), .Y(n2699) );
  INVX1 U1404 ( .A(n2681), .Y(BF_REQCMD[3]) );
  OAI33X1 U1405 ( .A0(n2639), .A1(n2889), .A2(n2641), .B0(n2642), .B1(n2643), 
        .B2(n2899), .Y(nextstate[3]) );
  INVX1 U1406 ( .A(n2645), .Y(n2643) );
  INVX1 U1407 ( .A(n2641), .Y(n2674) );
  OAI32X1 U1408 ( .A0(n2703), .A1(n2704), .A2(n2705), .B0(n2891), .B1(n2707), 
        .Y(n2618) );
  INVX1 U1409 ( .A(n2695), .Y(n2704) );
  OAI221X1 U1410 ( .A0(n2649), .A1(n2904), .B0(n2709), .B1(n2918), .C0(n2710), 
        .Y(n2707) );
  NAND4X1 U1411 ( .A(BF_TREADY), .B(n2669), .C(n2917), .D(n2908), .Y(n2684) );
  INVX1 U1412 ( .A(n2653), .Y(n2660) );
  INVX1 U1413 ( .A(n2796), .Y(n2794) );
  INVX1 U1414 ( .A(n2676), .Y(n2639) );
  OAI33X1 U1415 ( .A0(n2677), .A1(n2911), .A2(n2679), .B0(n2677), .B1(n2680), 
        .B2(n2911), .Y(n2676) );
  NAND4BX1 U1416 ( .AN(BF_CMD[3]), .B(n2682), .C(n2683), .D(n2681), .Y(n2679)
         );
  NAND4BX1 U1417 ( .AN(n2681), .B(n2682), .C(BF_CMD[3]), .D(n2683), .Y(n2680)
         );
  INVX1 U1418 ( .A(n2697), .Y(n2709) );
  NAND2BX1 U1419 ( .AN(n2918), .B(n2693), .Y(n2690) );
  INVX1 U1420 ( .A(n2783), .Y(n2693) );
  NAND2BX1 U1421 ( .AN(n2702), .B(n2665), .Y(n2783) );
  INVX1 U1422 ( .A(n2655), .Y(n2669) );
  INVX1 U1423 ( .A(n2799), .Y(n2791) );
  NAND2BX1 U1424 ( .AN(n2780), .B(n2653), .Y(n2799) );
  INVX1 U1425 ( .A(n2809), .Y(n2811) );
  INVX1 U1426 ( .A(n2882), .Y(BF_LAST) );
  NAND2BX1 U1427 ( .AN(n2905), .B(n2922), .Y(n2882) );
  INVX1 U1428 ( .A(ERCMD[2]), .Y(n2776) );
  INVX1 U1429 ( .A(n2649), .Y(n2701) );
  NAND3BX1 U1430 ( .AN(CAS_0_TT[4]), .B(n2877), .C(n2878), .Y(n2874) );
  NAND4BX1 U1431 ( .AN(n2641), .B(n2826), .C(n2827), .D(BF_IDLE), .Y(n2681) );
  AND4X1 U1432 ( .A(n2828), .B(n2829), .C(n2830), .D(n2831), .Y(n2827) );
  INVX1 U1433 ( .A(RAS_0_TT[1]), .Y(n2828) );
  INVX1 U1434 ( .A(RAS_0_TT[4]), .Y(n2831) );
  AO21X1 U1435 ( .A0(n2660), .A1(cbs_rowopen), .B0(BF_IDLE), .Y(BF_READY) );
  NAND4BX1 U1436 ( .AN(BF_TRASBUSY), .B(n2892), .C(n2885), .D(n2833), .Y(n2641) );
  XNOR2X1 U1437 ( .A(RAS_0_RA[11]), .B(CAS_0_RA[11]), .Y(n2854) );
  NAND2BX1 U1438 ( .AN(trasmin_cnt[3]), .B(n2913), .Y(n2653) );
  XNOR2X1 U1439 ( .A(RAS_0_RA[5]), .B(CAS_0_RA[5]), .Y(n2865) );
  XNOR2X1 U1440 ( .A(RAS_0_RA[2]), .B(CAS_0_RA[2]), .Y(n2848) );
  XNOR2X1 U1441 ( .A(RAS_0_RA[8]), .B(CAS_0_RA[8]), .Y(n2860) );
  XNOR2X1 U1442 ( .A(RAS_0_RA[1]), .B(CAS_0_RA[1]), .Y(n2847) );
  XNOR2X1 U1443 ( .A(RAS_0_RA[7]), .B(CAS_0_RA[7]), .Y(n2859) );
  NAND2BX1 U1444 ( .AN(length[0]), .B(n2922), .Y(BF_CASBUSY) );
  XOR2X1 U1445 ( .A(RAS_0_RA[3]), .B(CAS_0_RA[3]), .Y(n2846) );
  XOR2X1 U1446 ( .A(RAS_0_RA[9]), .B(CAS_0_RA[9]), .Y(n2858) );
  XOR2X1 U1447 ( .A(RAS_0_RA[6]), .B(CAS_0_RA[6]), .Y(n2863) );
  AND2X2 U1448 ( .A(n2914), .B(n2794), .Y(n2913) );
  OAI32X1 U1449 ( .A0(n2818), .A1(n2819), .A2(n2820), .B0(ERCMD[5]), .B1(n2821), .Y(n2778) );
  INVX1 U1450 ( .A(ERCMD[1]), .Y(n2821) );
  OR2X1 U1451 ( .A(ECMD[3]), .B(ECMD[2]), .Y(n2820) );
  OAI31X1 U1452 ( .A0(n2771), .A1(ERCMD[0]), .A2(n2772), .B0(n2773), .Y(n2697)
         );
  INVX1 U1453 ( .A(n2702), .Y(n2772) );
  NAND4BX1 U1454 ( .AN(n2774), .B(n2775), .C(n2776), .D(n2777), .Y(n2771) );
  INVX1 U1455 ( .A(n2778), .Y(n2774) );
  XOR2X1 U1456 ( .A(RAS_0_RA[0]), .B(CAS_0_RA[0]), .Y(n2851) );
  XOR2X1 U1457 ( .A(n2857), .B(CAS_0_RA[10]), .Y(n2852) );
  XOR2X1 U1458 ( .A(n2856), .B(CAS_0_RA[12]), .Y(n2853) );
  NAND3X1 U1459 ( .A(n2915), .B(n2751), .C(BA_REQ), .Y(n2749) );
  XNOR2X1 U1460 ( .A(BF_NO[0]), .B(BA_BA[0]), .Y(n2915) );
  NAND3BX1 U1461 ( .AN(n2758), .B(n2759), .C(n2760), .Y(n2713) );
  AOI221X1 U1462 ( .A0(LAST_RA[1]), .A1(n2890), .B0(LAST_RA[2]), .B1(n2916), 
        .C0(n2763), .Y(n2760) );
  OAI222X1 U1463 ( .A0(LAST_RA[8]), .A1(n2770), .B0(LAST_RA[7]), .B1(n2742), 
        .C0(BA_RA[8]), .C1(n2886), .Y(n2758) );
  AOI222X1 U1464 ( .A0(openedrow[9]), .A1(n2767), .B0(LAST_RA[0]), .B1(n2894), 
        .C0(BA_RA[9]), .C1(n2769), .Y(n2759) );
  NOR2BX1 U1465 ( .AN(cbs_rowopen), .B(n2702), .Y(n2700) );
  NAND2BX1 U1466 ( .AN(trrd_cnt_0_), .B(n2893), .Y(BF_RASBUSY) );
  INVX1 U1467 ( .A(RAS_0_TT[0]), .Y(n2826) );
  INVX1 U1468 ( .A(RAS_0_TT[3]), .Y(n2830) );
  INVX1 U1469 ( .A(RAS_0_TT[2]), .Y(n2829) );
  INVX1 U1470 ( .A(CAS_0_TT[2]), .Y(n2878) );
  INVX1 U1471 ( .A(CAS_0_TT[3]), .Y(n2877) );
  XNOR2X1 U1472 ( .A(RAS_0_RA[4]), .B(CAS_0_RA[4]), .Y(n2864) );
  OAI22X1 U1473 ( .A0(n2738), .A1(LAST_RA[2]), .B0(n2916), .B1(BA_RA[2]), .Y(
        n2736) );
  INVX1 U1474 ( .A(BA_RA[2]), .Y(n2738) );
  AND4X1 U1475 ( .A(n2717), .B(n2718), .C(n2719), .D(n2720), .Y(n2716) );
  AOI211X1 U1476 ( .A0(openedrow[3]), .A1(n2734), .B0(n2735), .C0(n2736), .Y(
        n2718) );
  AOI221X1 U1477 ( .A0(BA_RA[6]), .A1(n2741), .B0(openedrow[7]), .B1(n2742), 
        .C0(n2743), .Y(n2717) );
  AOI211X1 U1478 ( .A0(openedrow[0]), .A1(n2721), .B0(n2722), .C0(n2723), .Y(
        n2720) );
  AOI221X1 U1479 ( .A0(openedrow[1]), .A1(n2728), .B0(BA_RA[1]), .B1(n2729), 
        .C0(n2730), .Y(n2719) );
  INVX1 U1480 ( .A(LAST_RA[1]), .Y(n2729) );
  INVX1 U1481 ( .A(BA_RA[1]), .Y(n2728) );
  OAI222X1 U1482 ( .A0(LAST_RA[12]), .A1(n2731), .B0(LAST_RA[11]), .B1(n2732), 
        .C0(BA_RA[12]), .C1(n2895), .Y(n2730) );
  NOR2X1 U1483 ( .A(BF_IDLE), .B(n2918), .Y(n2917) );
  NOR3X2 U1484 ( .A(CAS_EMPTY), .B(n2920), .C(n2921), .Y(n2919) );
  XNOR2X1 U1485 ( .A(n2752), .B(CAS_0_BA[1]), .Y(n2920) );
  XNOR2X1 U1486 ( .A(n2870), .B(CAS_0_BA[0]), .Y(n2921) );
  NOR4X1 U1487 ( .A(length[4]), .B(length[3]), .C(length[1]), .D(length[2]), 
        .Y(n2922) );
  AOI211X1 U1488 ( .A0(n2652), .A1(n2653), .B0(n2639), .C0(n2654), .Y(n2651)
         );
  OAI31X1 U1489 ( .A0(n2655), .A1(newrowexist), .A2(BF_TREADY), .B0(n2656), 
        .Y(n2654) );
  AOI31X1 U1490 ( .A0(n2655), .A1(n2657), .A2(n2658), .B0(n2659), .Y(n2656) );
  NOR2BX1 U1491 ( .AN(n2908), .B(n2919), .Y(n2658) );
  INVX1 U1492 ( .A(RAS_0_RA[10]), .Y(n2857) );
  INVX1 U1493 ( .A(RAS_0_RA[12]), .Y(n2856) );
  OAI33X1 U1494 ( .A0(n2666), .A1(BF_IDLE), .A2(n2900), .B0(n2639), .B1(n2636), 
        .B2(n2668), .Y(nextstate[1]) );
  INVX1 U1495 ( .A(n2672), .Y(n2666) );
  AOI32X1 U1496 ( .A0(BF_TREADY), .A1(n2908), .A2(n2669), .B0(n2660), .B1(
        n2670), .Y(n2668) );
  OAI33X1 U1497 ( .A0(n2634), .A1(n2635), .A2(n2636), .B0(BF_LAST), .B1(n2901), 
        .B2(n2638), .Y(nextstate[4]) );
  OAI2BB1X1 U1498 ( .A0N(cbs_rowopen), .A1N(n2697), .B0(n2698), .Y(n2696) );
  AOI32X1 U1499 ( .A0(n2699), .A1(CAS_0_NEWROW), .A2(n2700), .B0(
        cas_0_newrow_l), .B1(n2701), .Y(n2698) );
  OAI222X1 U1500 ( .A0(LAST_RA[5]), .A1(n2744), .B0(BA_RA[5]), .B1(n2897), 
        .C0(BA_RA[6]), .C1(n2887), .Y(n2743) );
  INVX1 U1501 ( .A(BA_RA[5]), .Y(n2744) );
  OAI222X1 U1502 ( .A0(LAST_RA[10]), .A1(n2725), .B0(BA_RA[10]), .B1(n2898), 
        .C0(BA_RA[11]), .C1(n2888), .Y(n2722) );
  INVX1 U1503 ( .A(BA_RA[10]), .Y(n2725) );
  OAI222X1 U1504 ( .A0(LAST_RA[4]), .A1(n2739), .B0(LAST_RA[3]), .B1(n2734), 
        .C0(BA_RA[4]), .C1(n2896), .Y(n2735) );
  INVX1 U1505 ( .A(BA_RA[4]), .Y(n2739) );
  AO21X1 U1506 ( .A0(n2639), .A1(BF_IDLE), .B0(n2673), .Y(nextstate[0]) );
  OAI222X1 U1507 ( .A0(n2900), .A1(n2672), .B0(cbs_casing), .B1(n2638), .C0(
        n2674), .C1(n2889), .Y(n2673) );
  AO21X1 U1508 ( .A0(n2646), .A1(n2647), .B0(n2648), .Y(nextstate[2]) );
  INVX1 U1509 ( .A(n2636), .Y(n2646) );
  OAI33X1 U1510 ( .A0(n2645), .A1(n2642), .A2(n2899), .B0(n2649), .B1(
        cbs_rasing), .B2(n2642), .Y(n2648) );
  OAI2BB1X1 U1511 ( .A0N(n2634), .A1N(n2650), .B0(n2651), .Y(n2647) );
  INVX1 U1512 ( .A(n2836), .Y(BF_REQCMD[1]) );
  OAI211X1 U1513 ( .A0(n2837), .A1(n2838), .B0(BF_IDLE), .C0(n2674), .Y(n2836)
         );
  NAND2BX1 U1514 ( .AN(RAS_0_TT[1]), .B(n2826), .Y(n2838) );
  NAND3BX1 U1515 ( .AN(RAS_0_TT[4]), .B(n2830), .C(n2829), .Y(n2837) );
  AOI31X1 U1516 ( .A0(n2699), .A1(CAS_0_FINAL), .A2(n2711), .B0(n2705), .Y(
        n2710) );
  NOR2BX1 U1517 ( .AN(cbs_rowopen), .B(n2702), .Y(n2711) );
  INVX1 U1518 ( .A(n2712), .Y(n2705) );
  NAND4BX1 U1519 ( .AN(n2713), .B(n2714), .C(n2715), .D(n2716), .Y(n2712) );
  AOI221X1 U1520 ( .A0(LAST_RA[6]), .A1(n2887), .B0(LAST_RA[7]), .B1(n2902), 
        .C0(n2754), .Y(n2714) );
  AOI221X1 U1521 ( .A0(LAST_RA[8]), .A1(n2886), .B0(LAST_RA[9]), .B1(n2903), 
        .C0(n2749), .Y(n2715) );
  NAND2X1 U1522 ( .A(CAS_EMPTY), .B(RAS_EMPTY), .Y(n2655) );
  AO21X1 U1523 ( .A0(n2814), .A1(n2778), .B0(n2815), .Y(n2809) );
  AND4X1 U1524 ( .A(n2822), .B(n2776), .C(n2777), .D(n2775), .Y(n2814) );
  INVX1 U1525 ( .A(n2773), .Y(n2815) );
  INVX1 U1526 ( .A(ERCMD[0]), .Y(n2822) );
  AO22X1 U1527 ( .A0(length749_3_), .A1(n2912), .B0(CAS_0_TT[3]), .B1(n2693), 
        .Y(n2601) );
  XNOR2X1 U1_A_3 ( .A(length[3]), .B(carry_3_), .Y(length749_3_) );
  AO22X1 U1528 ( .A0(length749_2_), .A1(n2912), .B0(CAS_0_TT[2]), .B1(n2693), 
        .Y(n2602) );
  XNOR2X1 U1_A_2 ( .A(length[2]), .B(carry_2_), .Y(length749_2_) );
  AO22X1 U1529 ( .A0(length749_1_), .A1(n2912), .B0(CAS_0_TT[1]), .B1(n2693), 
        .Y(n2603) );
  XNOR2X1 U1_A_1 ( .A(length[1]), .B(length[0]), .Y(length749_1_) );
  AO22X1 U1530 ( .A0(n2912), .A1(n2905), .B0(CAS_0_TT[0]), .B1(n2693), .Y(
        n2604) );
  AO22X1 U1531 ( .A0(openedrow[5]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[5]), 
        .Y(n2612) );
  AO22X1 U1532 ( .A0(openedrow[4]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[4]), 
        .Y(n2613) );
  AO21X1 U1533 ( .A0(BA_RA[0]), .A1(n2724), .B0(LAST_RA[13]), .Y(n2723) );
  INVX1 U1534 ( .A(LAST_RA[0]), .Y(n2724) );
  OAI2BB1X1 U1535 ( .A0N(TRASMIN[2]), .A1N(n2780), .B0(n2795), .Y(n2597) );
  AOI32X1 U1536 ( .A0(trasmin_cnt[2]), .A1(n2796), .A2(n2791), .B0(n2791), 
        .B1(n2913), .Y(n2795) );
  OAI2BB1X1 U1537 ( .A0N(TRASMIN[1]), .A1N(n2780), .B0(n2793), .Y(n2598) );
  AOI32X1 U1538 ( .A0(trasmin_cnt[0]), .A1(trasmin_cnt[1]), .A2(n2791), .B0(
        n2791), .B1(n2794), .Y(n2793) );
  AO22X1 U1539 ( .A0(TRASMIN[0]), .A1(n2780), .B0(n2791), .B1(n2907), .Y(n2599) );
  AO22X1 U1540 ( .A0(openedrow[9]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[9]), 
        .Y(n2608) );
  AO22X1 U1541 ( .A0(openedrow[6]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[6]), 
        .Y(n2611) );
  AO22X1 U1542 ( .A0(openedrow[3]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[3]), 
        .Y(n2614) );
  AO22X1 U1543 ( .A0(openedrow[0]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[0]), 
        .Y(n2617) );
  AO22X1 U1544 ( .A0(length749_4_), .A1(n2912), .B0(CAS_0_TT[4]), .B1(n2693), 
        .Y(n2600) );
  XNOR2X1 U1_A_4 ( .A(length[4]), .B(carry_4_), .Y(length749_4_) );
  OR2X1 U1_B_3 ( .A(length[3]), .B(carry_3_), .Y(carry_4_) );
  AO22X1 U1545 ( .A0(TRCD[1]), .A1(n2780), .B0(n2801), .B1(n2923), .Y(n2594)
         );
  NOR2BX1 U1546 ( .AN(trcd_cnt[0]), .B(n2906), .Y(n2801) );
  AO22X1 U1547 ( .A0(TRASMIN[3]), .A1(n2780), .B0(n2798), .B1(n2791), .Y(n2596) );
  NOR2BX1 U1548 ( .AN(trasmin_cnt[3]), .B(n2913), .Y(n2798) );
  AO22X1 U1549 ( .A0(TRP[1]), .A1(n2809), .B0(n2812), .B1(n2811), .Y(n2590) );
  NOR2BX1 U1550 ( .AN(trp_cnt[1]), .B(n2885), .Y(n2812) );
  AO22X1 U1551 ( .A0(TRRD[1]), .A1(n2780), .B0(n2804), .B1(n2923), .Y(n2592)
         );
  AO22X1 U1552 ( .A0(TRCD[0]), .A1(n2780), .B0(n2800), .B1(n2923), .Y(n2595)
         );
  NOR2BX1 U1553 ( .AN(trcd_cnt[1]), .B(trcd_cnt[0]), .Y(n2800) );
  AO22X1 U1554 ( .A0(cas_0_final_l), .A1(n2690), .B0(CAS_0_FINAL), .B1(n2691), 
        .Y(n2620) );
  AO22X1 U1555 ( .A0(cas_0_newrow_l), .A1(n2690), .B0(CAS_0_NEWROW), .B1(n2691), .Y(n2621) );
  AO22X1 U1556 ( .A0(TRP[0]), .A1(n2809), .B0(n2810), .B1(n2811), .Y(n2591) );
  NOR2BX1 U1557 ( .AN(trp_cnt[1]), .B(trp_cnt[0]), .Y(n2810) );
  AO22X1 U1558 ( .A0(TRRD[0]), .A1(n2780), .B0(n2803), .B1(n2923), .Y(n2593)
         );
  NOR2BX1 U1559 ( .AN(trrd_cnt_1_), .B(trrd_cnt_0_), .Y(n2803) );
  NAND3BX1 U1560 ( .AN(cbs_rowopen), .B(cbs_casing), .C(BF_LAST), .Y(n2649) );
  INVX1 U1561 ( .A(ERCMD[3]), .Y(n2777) );
  INVX1 U1562 ( .A(ERCMD[4]), .Y(n2775) );
  OAI222X1 U1563 ( .A0(openedrow[4]), .A1(n2755), .B0(openedrow[3]), .B1(n2756), .C0(openedrow[5]), .C1(n2757), .Y(n2754) );
  INVX1 U1564 ( .A(LAST_RA[5]), .Y(n2757) );
  INVX1 U1565 ( .A(LAST_RA[4]), .Y(n2755) );
  INVX1 U1566 ( .A(LAST_RA[3]), .Y(n2756) );
  OAI222X1 U1567 ( .A0(openedrow[11]), .A1(n2764), .B0(openedrow[10]), .B1(
        n2765), .C0(openedrow[12]), .C1(n2766), .Y(n2763) );
  INVX1 U1568 ( .A(LAST_RA[12]), .Y(n2766) );
  INVX1 U1569 ( .A(LAST_RA[11]), .Y(n2764) );
  INVX1 U1570 ( .A(LAST_RA[10]), .Y(n2765) );
  AOI211X1 U1571 ( .A0(n2660), .A1(newrowenable), .B0(n2661), .C0(n2657), .Y(
        n2659) );
  INVX1 U1572 ( .A(LAST_RA[6]), .Y(n2741) );
  INVX1 U1573 ( .A(LAST_RA[9]), .Y(n2769) );
  NAND3BX1 U1574 ( .AN(cbs_rasing), .B(n2900), .C(n2917), .Y(n2636) );
  NAND2BX1 U1575 ( .AN(cbs_pcing), .B(n2889), .Y(n2642) );
  NAND2BX1 U1576 ( .AN(trp_cnt[1]), .B(trp_cnt[0]), .Y(n2672) );
  NAND2BX1 U1577 ( .AN(trcd_cnt[1]), .B(trcd_cnt[0]), .Y(n2645) );
  NAND3BX1 U1578 ( .AN(cbs_rowopen), .B(n2899), .C(n2675), .Y(n2638) );
  INVX1 U1579 ( .A(n2642), .Y(n2675) );
  OR2X1 U1_B_1 ( .A(length[1]), .B(length[0]), .Y(carry_2_) );
  OR2X1 U1_B_2 ( .A(length[2]), .B(carry_2_), .Y(carry_3_) );
  INVX1 U1580 ( .A(BF_NO[1]), .Y(n2752) );
  INVX1 U1581 ( .A(BF_NO[0]), .Y(n2870) );
  DFFSX1 currstate_reg_0_ ( .D(nextstate[0]), .CK(ACLK), .SN(ARESETB), .Q(
        BF_IDLE), .QN(n2889) );
  DFFRX1 currstate_reg_2_ ( .D(nextstate[2]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_rowopen), .QN(n2918) );
  DFFRX1 length_reg_0_ ( .D(n2604), .CK(ACLK), .RN(ARESETB), .Q(length[0]), 
        .QN(n2905) );
  DFFRX1 trp_cnt_reg_0_ ( .D(n2591), .CK(ACLK), .RN(ARESETB), .Q(trp_cnt[0]), 
        .QN(n2885) );
  DFFRX1 trrd_cnt_reg_0_ ( .D(n2593), .CK(ACLK), .RN(ARESETB), .Q(trrd_cnt_0_)
         );
  DFFRX1 trp_cnt_reg_1_ ( .D(n2590), .CK(ACLK), .RN(ARESETB), .Q(trp_cnt[1]), 
        .QN(n2892) );
  DFFRX1 trrd_cnt_reg_1_ ( .D(n2592), .CK(ACLK), .RN(ARESETB), .Q(trrd_cnt_1_), 
        .QN(n2893) );
  DFFRX1 newrowexist_reg ( .D(n2619), .CK(ACLK), .RN(ARESETB), .Q(newrowexist), 
        .QN(n2908) );
  DFFRX1 trasmin_cnt_reg_0_ ( .D(n2599), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[0]), .QN(n2907) );
  DFFRX1 trasmin_cnt_reg_1_ ( .D(n2598), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[1]) );
  DFFRX1 length_reg_2_ ( .D(n2602), .CK(ACLK), .RN(ARESETB), .Q(length[2]) );
  DFFRX1 length_reg_1_ ( .D(n2603), .CK(ACLK), .RN(ARESETB), .Q(length[1]) );
  DFFRX1 length_reg_3_ ( .D(n2601), .CK(ACLK), .RN(ARESETB), .Q(length[3]) );
  DFFRX1 length_reg_4_ ( .D(n2600), .CK(ACLK), .RN(ARESETB), .Q(length[4]) );
  DFFRX1 trasmin_cnt_reg_3_ ( .D(n2596), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[3]) );
  DFFRX1 trasmin_cnt_reg_2_ ( .D(n2597), .CK(ACLK), .RN(ARESETB), .Q(
        trasmin_cnt[2]), .QN(n2914) );
  DFFRX1 newrowenable_reg ( .D(n2618), .CK(ACLK), .RN(ARESETB), .Q(
        newrowenable), .QN(n2891) );
  DFFRX1 openedrow_reg_5_ ( .D(n2612), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[5]), .QN(n2897) );
  DFFRX1 openedrow_reg_9_ ( .D(n2608), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[9]), .QN(n2903) );
  DFFRX1 openedrow_reg_0_ ( .D(n2617), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[0]), .QN(n2894) );
  DFFRX1 openedrow_reg_4_ ( .D(n2613), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[4]), .QN(n2896) );
  DFFRX1 openedrow_reg_2_ ( .D(n2615), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[2]), .QN(n2916) );
  DFFRX1 openedrow_reg_6_ ( .D(n2611), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[6]), .QN(n2887) );
  DFFRX1 openedrow_reg_12_ ( .D(n2605), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[12]), .QN(n2895) );
  DFFRX1 openedrow_reg_1_ ( .D(n2616), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[1]), .QN(n2890) );
  DFFRX1 openedrow_reg_7_ ( .D(n2610), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[7]), .QN(n2902) );
  DFFRX1 openedrow_reg_10_ ( .D(n2607), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[10]), .QN(n2898) );
  DFFRX1 openedrow_reg_11_ ( .D(n2606), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[11]), .QN(n2888) );
  DFFRX1 openedrow_reg_8_ ( .D(n2609), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[8]), .QN(n2886) );
  DFFRX1 openedrow_reg_3_ ( .D(n2614), .CK(ACLK), .RN(ARESETB), .Q(
        openedrow[3]) );
  DFFRX1 currstate_reg_4_ ( .D(nextstate[4]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_casing), .QN(n2901) );
  DFFRX1 trcd_cnt_reg_1_ ( .D(n2594), .CK(ACLK), .RN(ARESETB), .Q(trcd_cnt[1]), 
        .QN(n2906) );
  DFFRX1 currstate_reg_3_ ( .D(nextstate[3]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_rasing), .QN(n2899) );
  DFFRX1 cas_0_final_l_reg ( .D(n2620), .CK(ACLK), .RN(ARESETB), .Q(
        cas_0_final_l), .QN(n2904) );
  DFFRX1 currstate_reg_1_ ( .D(nextstate[1]), .CK(ACLK), .RN(ARESETB), .Q(
        cbs_pcing), .QN(n2900) );
  DFFRX1 trcd_cnt_reg_0_ ( .D(n2595), .CK(ACLK), .RN(ARESETB), .Q(trcd_cnt[0])
         );
  DFFRX1 cas_0_newrow_l_reg ( .D(n2621), .CK(ACLK), .RN(ARESETB), .Q(
        cas_0_newrow_l) );
  AO22X1 U1582 ( .A0(openedrow[7]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[7]), 
        .Y(n2610) );
  AO22X1 U1583 ( .A0(openedrow[8]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[8]), 
        .Y(n2609) );
  AO22X1 U1584 ( .A0(openedrow[1]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[1]), 
        .Y(n2616) );
  INVX1 U1585 ( .A(n2707), .Y(n2703) );
  AO22X1 U1586 ( .A0(openedrow[10]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[10]), 
        .Y(n2607) );
  AO22X1 U1587 ( .A0(openedrow[2]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[2]), 
        .Y(n2615) );
  NAND4BBX1 U1588 ( .AN(ECMD[1]), .BN(ECMD[0]), .C(ERCMD[5]), .D(ECMD[5]), .Y(
        n2818) );
  AO22X1 U1589 ( .A0(openedrow[12]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[12]), 
        .Y(n2605) );
  AO22X1 U1590 ( .A0(openedrow[11]), .A1(n2923), .B0(n2780), .B1(RAS_0_RA[11]), 
        .Y(n2606) );
  XOR2X1 U1591 ( .A(n2752), .B(BA_BA[1]), .Y(n2751) );
endmodule


module SDRRas ( ARESETB, ACLK, BA_BA, BA_RA, BA_TT, BA_REQ, CMD, CLOSING, 
        B0_LAST_RA, B1_LAST_RA, B2_LAST_RA, B3_LAST_RA, RAS_0_BA, RAS_0_RA, 
        RAS_0_TT, RAS_EMPTY, RAS_HEMPTY, RAS_FULL );
  input [1:0] BA_BA;
  input [12:0] BA_RA;
  input [4:0] BA_TT;
  input [5:0] CMD;
  output [13:0] B0_LAST_RA;
  output [13:0] B1_LAST_RA;
  output [13:0] B2_LAST_RA;
  output [13:0] B3_LAST_RA;
  output [1:0] RAS_0_BA;
  output [12:0] RAS_0_RA;
  output [4:0] RAS_0_TT;
  input ARESETB, ACLK, BA_REQ, CLOSING;
  output RAS_EMPTY, RAS_HEMPTY, RAS_FULL;
  wire   n206_4_, n206_3_, n206_2_, n206_1_, n206_0_, RAS_EMPTY471,
         RAS_HEMPTY479, RAS_FULL486, ras_cnt_4_, ras_cnt_3_, ras_cnt_2_,
         ras_cnt_1_, ras_cnt_0_, ras_cnt865_4_, n1469, n1470, n1471, n1472,
         n1473, n1474, n1475, n1476, n1477, n1478, n1479, n1480, n1481, n1482,
         n1483, n1484, n1485, n1486, n1487, n1488, n1489, n1490, n1491, n1492,
         n1493, n1494, n1495, n1496, n1497, n1498, n1499, n1500, n1501, n1502,
         n1503, n1504, n1505, n1506, n1507, n1508, n1509, n1510, n1511, n1512,
         n1513, n1514, n1515, n1516, n1517, n1518, n1519, n1520, n1521, n1522,
         n1523, n1524, n1525, n1526, n1527, n1528, n1529, n1530, n1531, n1532,
         n1533, n1534, n1535, n1536, n1537, n1538, n1539, n1540, n1541, n1542,
         n1543, n1544, n1545, n1546, n1547, n1548, n1549, n1550, n1551, n1552,
         n1553, n1554, n1555, n1556, n1557, n1558, n1559, n1560, n1561, n1562,
         n1563, n1564, n1565, n1566, n1567, n1568, n1569, n1570, n1571, n1572,
         n1573, n1574, n1575, n1576, n1577, n1578, n1579, n1580, n1581, n1582,
         n1583, n1584, n1585, n1586, n1587, n1588, n1589, n1590, n1591, n1592,
         n1593, n1594, n1595, n1596, n1597, n1598, n1599, n1600, n1601, n1602,
         n1603, n1604, n1605, n1606, n1607, n1608, n1609, n1610, n1611, n1612,
         n1613, n1614, n1615, n1616, n1617, n1618, n1619, n1620, n1621, n1622,
         n1623, n1624, n1625, n1626, n1627, n1628, n1629, n1630, n1631, n1632,
         n1633, n1634, n1635, n1636, n1637, n1638, n1639, n1640, n1641, n1642,
         n1643, n1644, n1645, n1646, n1647, n1648, n1649, n1650, n1651, n1652,
         n1653, n1654, n1655, n1656, n1657, n1658, n1659, n1660, n1661, n1662,
         n1663, n1664, n1665, n1666, n1667, n1668, n1669, n1670, n1671, n1672,
         n1673, n1674, n1675, n1676, n1677, n1678, n1679, n1680, n1681, n1682,
         n1683, n1684, n1685, n1686, n1687, n1688, n1689, n1690, n1691, n1692,
         n1693, n1694, n1695, n1696, n1697, n1698, n1699, n1700, n1701, n1702,
         n1703, n1704, carry_3_, carry_2_, n2458, n2459, n2460, n2461, n2462,
         n2463, n2464, n2465, n2467, n2468, n2470, n2472, n2475, n2478, n2481,
         n2484, n2487, n2490, n2493, n2496, n2499, n2502, n2505, n2508, n2511,
         n2514, n2517, n2520, n2523, n2526, n2528, n2529, n2530, n2531, n2533,
         n2534, n2554, n2555, n2557, n2558, n2578, n2579, n2580, n2581, n2582,
         n2583, n2585, n2586, n2606, n2608, n2610, n2611, n2631, n2632, n2634,
         n2635, n2655, n2656, n2657, n2658, n2662, n2663, n2664, n2665, n2666,
         n2667, n2668, n2669, n2670, n2671, n2672, n2673, n2674, n2675, n2676,
         n2677, n2678, n2679, n2680, n2681, n2682, n2683, n2684, n2685, n2686,
         n2688, n2689, n2690, n2692, n2693, n2695, n2696, n2700, n2704, n2705,
         n2708, n2710, n2711, n2712, n2713, n2714, n2715, n2716, n2717, n2718,
         n2719, n2720, n2721, n2722, n2723, n2724, n2725, n2726, n2727, n2728,
         n2729, n2730, n2731, n2732, n2733, n2734, n2735, n2736, n2737, n2738,
         n2739, n2740, n2741, n2742, n2743, n2744, n2745, n2746, n2747, n2748,
         n2749, n2750, n2751, n2752, n2753, n2754, n2755, n2756, n2757, n2758,
         n2759, n2760, n2761, n2762, n2763, n2764, n2765, n2766, n2767, n2768,
         n2769, n2770, n2771, n2772, n2773, n2774, n2775, n2776, n2777, n2778,
         n2779, n2780, n2781, n2782, n2783, n2784, n2785, n2786, n2787, n2788,
         n2789, n2790, n2791, n2792, n2793, n2794, n2795, n2796, n2797, n2798,
         n2799, n2800, n2801, n2802, n2803, n2804, n2805, n2806, n2807, n2808,
         n2809, n2810, n2811, n2812, n2813, n2814, n2815, n2816, n2817, n2818,
         n2819, n2820, n2821, n2822, n2823, n2824, n2825, n2826, n2827, n2828,
         n2829, n2830, n2831, n2832, n2833, n2834, n2835, n2836, n2837, n2838,
         n2839, n2840, n2841, n2842, n2843, n2844, n2845, n2846, n2847, n2848,
         n2849, n2850, n2851, n2852, n2853, n2854, n2855, n2856, n2857, n2858,
         n2859, n2860, n2861, n2862, n2863, n2864, n2865, n2866, n2867, n2868,
         n2869, n2870, n2871, n2872, n2873, n2874, n2875, n2876, n2877, n2878,
         n2879, n2880, n2881, n2882, n2883, n2884, n2885, n2886, n2887, n2888,
         n2889, n2890, n2891, n2892, n2893, n2894, n2895, n2896, n2897, n2898,
         n2899, n2900, n2901, n2902, n2903, n2904, n2905, n2906, n2907, n2908,
         n2909, n2910, n2911;
  wire   [19:0] ras_7_data;

  DFFRX4 RAS_0_RA_reg_0_ ( .D(n1559), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_RA[0]), 
        .QN(n1471) );
  AO22X4 U2468 ( .A0(n2461), .A1(n2874), .B0(n2700), .B1(n2723), .Y(n2581) );
  OAI33X1 U2502 ( .A0(n2710), .A1(CMD[3]), .A2(n2711), .B0(n2710), .B1(CMD[1]), 
        .B2(n2712), .Y(n2877) );
  OAI222X4 U2503 ( .A0(n2465), .A1(n2778), .B0(n2511), .B1(n2907), .C0(n2861), 
        .C1(n2911), .Y(n1670) );
  NAND2BX2 U2504 ( .AN(n2528), .B(n2465), .Y(n2911) );
  NAND2BX2 U2505 ( .AN(n2655), .B(n2632), .Y(n2887) );
  NAND2BX2 U2506 ( .AN(n2461), .B(n2884), .Y(n2632) );
  NAND3BX1 U2507 ( .AN(n2530), .B(n2579), .C(n2871), .Y(n2716) );
  INVX1 U2508 ( .A(n2878), .Y(n2717) );
  INVX1 U2509 ( .A(n2878), .Y(n2718) );
  NAND3BX1 U2510 ( .AN(n2530), .B(n2579), .C(n2871), .Y(n2878) );
  NAND3BX2 U2511 ( .AN(n2530), .B(n2529), .C(n2871), .Y(n2883) );
  AND2X8 U2512 ( .A(n2581), .B(n2582), .Y(n2871) );
  NAND3BX4 U2513 ( .AN(n2530), .B(n2579), .C(n2464), .Y(n2557) );
  NAND3BX2 U2514 ( .AN(n2530), .B(n2579), .C(n2464), .Y(n2898) );
  NAND2BX1 U2515 ( .AN(n2463), .B(n2871), .Y(n2719) );
  NAND2BX4 U2516 ( .AN(n2463), .B(n2871), .Y(n2585) );
  INVX8 U2517 ( .A(n2529), .Y(n2579) );
  NAND3BX2 U2518 ( .AN(n2529), .B(n2530), .C(n2871), .Y(n2889) );
  NAND3BX2 U2519 ( .AN(n2530), .B(n2529), .C(n2464), .Y(n2903) );
  NAND3BX4 U2520 ( .AN(n2529), .B(n2530), .C(n2871), .Y(n2888) );
  NAND3BX2 U2521 ( .AN(n2529), .B(n2530), .C(n2464), .Y(n2907) );
  NAND3BX4 U2522 ( .AN(n2530), .B(n2529), .C(n2464), .Y(n2902) );
  XOR2X4 U2523 ( .A(n2876), .B(ras_cnt_0_), .Y(n2529) );
  NAND2BX4 U2524 ( .AN(n2578), .B(n2555), .Y(n2901) );
  NAND2BX4 U2525 ( .AN(n2461), .B(n2898), .Y(n2555) );
  INVX1 U2526 ( .A(n2908), .Y(n2720) );
  INVX2 U2527 ( .A(n2720), .Y(n2721) );
  INVX1 U2528 ( .A(n2720), .Y(n2722) );
  INVX3 U2529 ( .A(n2580), .Y(n2464) );
  NAND2BX1 U2530 ( .AN(n2581), .B(n2582), .Y(n2580) );
  OAI33X1 U2531 ( .A0(n2710), .A1(CMD[3]), .A2(n2711), .B0(n2710), .B1(CMD[1]), 
        .B2(n2712), .Y(n2876) );
  NAND2BX2 U2532 ( .AN(n2631), .B(n2608), .Y(n2892) );
  NAND2BX2 U2533 ( .AN(n2554), .B(n2531), .Y(n2906) );
  NAND2BX1 U2534 ( .AN(n2876), .B(n2721), .Y(n2465) );
  NAND2BX1 U2535 ( .AN(n2876), .B(n2716), .Y(n2656) );
  OAI222X1 U2536 ( .A0(n2690), .A1(n2784), .B0(n2696), .B1(n2695), .C0(n2689), 
        .C1(n2873), .Y(n206_3_) );
  OAI222X1 U2537 ( .A0(n2690), .A1(n2723), .B0(n2692), .B1(n2693), .C0(n2689), 
        .C1(n2874), .Y(n206_2_) );
  DFFRX1 RAS_0_BA_reg_1_ ( .D(n1545), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_BA[1]), 
        .QN(n1470) );
  DFFRX2 RAS_0_BA_reg_0_ ( .D(n1546), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_BA[0]), 
        .QN(n1469) );
  DFFRX2 RAS_0_RA_reg_12_ ( .D(n1547), .CK(ACLK), .RN(ARESETB), .Q(
        RAS_0_RA[12]), .QN(n1474) );
  DFFRX1 RAS_0_RA_reg_11_ ( .D(n1548), .CK(ACLK), .RN(ARESETB), .Q(
        RAS_0_RA[11]), .QN(n1473) );
  DFFRX2 RAS_0_RA_reg_10_ ( .D(n1549), .CK(ACLK), .RN(ARESETB), .Q(
        RAS_0_RA[10]), .QN(n1472) );
  DFFRX1 RAS_0_RA_reg_8_ ( .D(n1551), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_RA[8]), 
        .QN(n1482) );
  DFFRX1 RAS_0_RA_reg_7_ ( .D(n1552), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_RA[7]), 
        .QN(n1481) );
  DFFRX1 RAS_0_RA_reg_5_ ( .D(n1554), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_RA[5]), 
        .QN(n1479) );
  DFFRX1 RAS_0_RA_reg_4_ ( .D(n1555), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_RA[4]), 
        .QN(n1478) );
  DFFRX2 RAS_0_RA_reg_3_ ( .D(n1556), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_RA[3]), 
        .QN(n1477) );
  DFFRX1 RAS_0_RA_reg_2_ ( .D(n1557), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_RA[2]), 
        .QN(n1476) );
  DFFRX1 RAS_0_RA_reg_1_ ( .D(n1558), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_RA[1]), 
        .QN(n1475) );
  DFFRX2 RAS_0_RA_reg_9_ ( .D(n1550), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_RA[9]), 
        .QN(n1483) );
  DFFRX1 RAS_0_RA_reg_6_ ( .D(n1553), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_RA[6]), 
        .QN(n1480) );
  AND3X1 U2538 ( .A(n2705), .B(n2529), .C(n2871), .Y(n2867) );
  INVX3 U2539 ( .A(n2867), .Y(n2884) );
  OAI33X4 U2540 ( .A0(n2710), .A1(CMD[3]), .A2(n2711), .B0(n2710), .B1(CMD[1]), 
        .B2(n2712), .Y(n2461) );
  NAND2BX1 U2541 ( .AN(n2717), .B(n2880), .Y(n2658) );
  NAND2BX1 U2542 ( .AN(n2578), .B(n2899), .Y(n2558) );
  NAND2BX1 U2543 ( .AN(n2528), .B(n2909), .Y(n2470) );
  NAND2BX1 U2544 ( .AN(n2655), .B(n2885), .Y(n2635) );
  NAND2BX1 U2545 ( .AN(n2554), .B(n2904), .Y(n2534) );
  NAND2BX1 U2546 ( .AN(n2606), .B(n2583), .Y(n2897) );
  NAND2BX1 U2547 ( .AN(n2631), .B(n2890), .Y(n2611) );
  NAND2BX1 U2548 ( .AN(n2606), .B(n2895), .Y(n2586) );
  NAND2BX1 U2549 ( .AN(n2461), .B(n2888), .Y(n2891) );
  NAND2BX1 U2550 ( .AN(n2876), .B(n2907), .Y(n2910) );
  NAND2BX1 U2551 ( .AN(n2876), .B(n2894), .Y(n2896) );
  NAND2BX1 U2552 ( .AN(n2461), .B(n2888), .Y(n2890) );
  NAND2BX1 U2553 ( .AN(n2876), .B(n2719), .Y(n2583) );
  NAND2BX1 U2554 ( .AN(n2876), .B(n2907), .Y(n2909) );
  NAND2BX1 U2555 ( .AN(n2876), .B(n2893), .Y(n2895) );
  INVX3 U2556 ( .A(n2705), .Y(n2530) );
  NAND2BX1 U2557 ( .AN(n206_2_), .B(n2685), .Y(n2680) );
  AND4X1 U2558 ( .A(n2683), .B(n2682), .C(n2679), .D(n2686), .Y(RAS_EMPTY471)
         );
  AO22X1 U2559 ( .A0(n2876), .A1(n2875), .B0(n2700), .B1(n2785), .Y(n2705) );
  NAND2BX2 U2560 ( .AN(n2718), .B(n2656), .Y(n2882) );
  INVX3 U2561 ( .A(n2877), .Y(n2700) );
  NAND2BX1 U2562 ( .AN(n2579), .B(n2530), .Y(n2463) );
  OR2X1 U2563 ( .A(n2581), .B(n2463), .Y(n2696) );
  AO21X1 U2564 ( .A0(n2463), .A1(n2581), .B0(n2695), .Y(n2693) );
  NAND2BX1 U2565 ( .AN(n2877), .B(n2695), .Y(n2690) );
  OAI2BB2X1 U2566 ( .A0N(ras_cnt865_4_), .A1N(n2688), .B0(n2868), .B1(n2690), 
        .Y(n206_4_) );
  NAND3BX2 U2567 ( .AN(n2666), .B(n2869), .C(n2870), .Y(n2695) );
  AO22X1 U2568 ( .A0(n2461), .A1(n2708), .B0(n2700), .B1(n2868), .Y(n2869) );
  AO22X1 U2569 ( .A0(n2877), .A1(n2873), .B0(n2700), .B1(n2784), .Y(n2870) );
  INVX1 U2570 ( .A(CMD[3]), .Y(n2712) );
  INVX1 U2571 ( .A(n2462), .Y(n2458) );
  INVX1 U2572 ( .A(n2585), .Y(n2606) );
  DFFSX1 RAS_HEMPTY_reg ( .D(RAS_HEMPTY479), .CK(ACLK), .SN(ARESETB), .Q(
        RAS_HEMPTY) );
  NAND2BX1 U2573 ( .AN(n2463), .B(n2871), .Y(n2894) );
  NAND2BX1 U2574 ( .AN(n2463), .B(n2871), .Y(n2893) );
  NOR2BX1 U2575 ( .AN(n2679), .B(n2680), .Y(RAS_HEMPTY479) );
  INVX1 U2576 ( .A(n2557), .Y(n2578) );
  INVX1 U2577 ( .A(CMD[1]), .Y(n2711) );
  INVX1 U2578 ( .A(n2664), .Y(n2662) );
  INVX1 U2579 ( .A(n2678), .Y(n2676) );
  INVX1 U2580 ( .A(n2674), .Y(n2672) );
  INVX1 U2581 ( .A(n2670), .Y(n2668) );
  INVX1 U2582 ( .A(n2665), .Y(n2663) );
  NAND3BX1 U2583 ( .AN(n2530), .B(n2579), .C(n2871), .Y(n2879) );
  NAND3BX1 U2584 ( .AN(n2530), .B(n2579), .C(n2871), .Y(n2657) );
  NAND2BX1 U2585 ( .AN(n2582), .B(n2690), .Y(n2689) );
  NAND2BX1 U2586 ( .AN(n2461), .B(n2902), .Y(n2904) );
  NAND2BX1 U2587 ( .AN(n2877), .B(n2903), .Y(n2531) );
  NAND2BX1 U2588 ( .AN(n2461), .B(n2883), .Y(n2886) );
  NAND2BX1 U2589 ( .AN(n2876), .B(n2883), .Y(n2885) );
  NAND2BX1 U2590 ( .AN(n2461), .B(n2902), .Y(n2905) );
  NAND2BX1 U2591 ( .AN(n2876), .B(n2878), .Y(n2881) );
  NAND2BX1 U2592 ( .AN(n2461), .B(n2557), .Y(n2900) );
  NAND2BX1 U2593 ( .AN(n2877), .B(n2889), .Y(n2608) );
  NAND2BX1 U2594 ( .AN(n2461), .B(n2716), .Y(n2880) );
  NAND2BX1 U2595 ( .AN(n2876), .B(n2557), .Y(n2899) );
  INVX1 U2596 ( .A(n2634), .Y(n2655) );
  INVX1 U2597 ( .A(n2610), .Y(n2631) );
  INVX1 U2598 ( .A(n2533), .Y(n2554) );
  INVX1 U2599 ( .A(n2460), .Y(n2459) );
  NAND2BX1 U2600 ( .AN(n2461), .B(n2462), .Y(n2460) );
  INVX1 U2601 ( .A(n2468), .Y(n2528) );
  OAI31X1 U2602 ( .A0(n2681), .A1(n2682), .A2(n2683), .B0(n2684), .Y(
        RAS_FULL486) );
  NOR2BX1 U2603 ( .AN(n2685), .B(n206_3_), .Y(n2684) );
  INVX1 U2604 ( .A(n206_2_), .Y(n2681) );
  INVX1 U2605 ( .A(n2680), .Y(n2686) );
  INVX1 U2606 ( .A(n206_3_), .Y(n2679) );
  INVX1 U2607 ( .A(n206_1_), .Y(n2683) );
  NAND2BX1 U2608 ( .AN(CLOSING), .B(n2677), .Y(n2678) );
  NAND2BX1 U2609 ( .AN(CLOSING), .B(n2673), .Y(n2674) );
  NAND2BX1 U2610 ( .AN(CLOSING), .B(n2669), .Y(n2670) );
  NAND2BX1 U2611 ( .AN(CLOSING), .B(n2664), .Y(n2665) );
  INVX1 U2612 ( .A(n2677), .Y(n2675) );
  INVX1 U2613 ( .A(n2673), .Y(n2671) );
  INVX1 U2614 ( .A(n2669), .Y(n2667) );
  INVX1 U2615 ( .A(BA_RA[9]), .Y(n2511) );
  INVX1 U2616 ( .A(BA_RA[8]), .Y(n2508) );
  INVX1 U2617 ( .A(BA_RA[7]), .Y(n2505) );
  INVX1 U2618 ( .A(BA_RA[12]), .Y(n2520) );
  INVX1 U2619 ( .A(BA_RA[10]), .Y(n2514) );
  INVX1 U2620 ( .A(BA_BA[1]), .Y(n2526) );
  INVX1 U2621 ( .A(BA_RA[11]), .Y(n2517) );
  INVX1 U2622 ( .A(BA_TT[4]), .Y(n2481) );
  INVX1 U2623 ( .A(BA_BA[0]), .Y(n2523) );
  INVX1 U2624 ( .A(BA_TT[3]), .Y(n2478) );
  INVX1 U2625 ( .A(BA_TT[2]), .Y(n2475) );
  INVX1 U2626 ( .A(BA_TT[1]), .Y(n2472) );
  INVX1 U2627 ( .A(BA_TT[0]), .Y(n2467) );
  INVX1 U2628 ( .A(BA_RA[0]), .Y(n2484) );
  INVX1 U2629 ( .A(BA_RA[2]), .Y(n2490) );
  INVX1 U2630 ( .A(BA_RA[4]), .Y(n2496) );
  INVX1 U2631 ( .A(BA_RA[1]), .Y(n2487) );
  INVX1 U2632 ( .A(BA_RA[5]), .Y(n2499) );
  INVX1 U2633 ( .A(BA_RA[3]), .Y(n2493) );
  INVX1 U2634 ( .A(BA_RA[6]), .Y(n2502) );
  DFFRX1 RAS_0_TT_reg_4_ ( .D(n1560), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_TT[4]), 
        .QN(n1488) );
  DFFRX1 RAS_0_TT_reg_1_ ( .D(n1563), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_TT[1]), 
        .QN(n1485) );
  DFFRX1 RAS_0_TT_reg_3_ ( .D(n1561), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_TT[3]), 
        .QN(n1487) );
  DFFRX1 RAS_0_TT_reg_2_ ( .D(n1562), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_TT[2]), 
        .QN(n1486) );
  DFFRX1 RAS_0_TT_reg_0_ ( .D(n1564), .CK(ACLK), .RN(ARESETB), .Q(RAS_0_TT[0]), 
        .QN(n1484) );
  NAND3BX1 U2635 ( .AN(n2529), .B(n2530), .C(n2464), .Y(n2908) );
  NAND3BX1 U2636 ( .AN(n2529), .B(n2530), .C(n2464), .Y(n2468) );
  OAI221X1 U2637 ( .A0(n2690), .A1(n2785), .B0(n2689), .B1(n2875), .C0(n2704), 
        .Y(n206_1_) );
  AOI32X1 U2638 ( .A0(n2529), .A1(n2705), .A2(n2582), .B0(n2530), .B1(n2579), 
        .Y(n2704) );
  INVX3 U2639 ( .A(n2695), .Y(n2582) );
  OAI222X1 U2640 ( .A0(n2904), .A1(n2798), .B0(n2523), .B1(n2902), .C0(n2776), 
        .C1(n2906), .Y(n1646) );
  OAI222X1 U2641 ( .A0(n2904), .A1(n2799), .B0(n2514), .B1(n2902), .C0(n2777), 
        .C1(n2534), .Y(n1649) );
  OAI222X1 U2642 ( .A0(n2531), .A1(n2800), .B0(n2511), .B1(n2902), .C0(n2778), 
        .C1(n2906), .Y(n1650) );
  OAI222X1 U2643 ( .A0(n2904), .A1(n2801), .B0(n2505), .B1(n2902), .C0(n2779), 
        .C1(n2906), .Y(n1652) );
  OAI222X1 U2644 ( .A0(n2904), .A1(n2802), .B0(n2496), .B1(n2902), .C0(n2780), 
        .C1(n2534), .Y(n1655) );
  OAI222X1 U2645 ( .A0(n2531), .A1(n2803), .B0(n2493), .B1(n2902), .C0(n2781), 
        .C1(n2906), .Y(n1656) );
  OAI222X1 U2646 ( .A0(n2905), .A1(n2804), .B0(n2475), .B1(n2902), .C0(n2783), 
        .C1(n2906), .Y(n1662) );
  OAI222X1 U2647 ( .A0(n2885), .A1(n2838), .B0(n2523), .B1(n2883), .C0(n2736), 
        .C1(n2887), .Y(n1566) );
  OAI222X1 U2648 ( .A0(n2885), .A1(n2839), .B0(n2514), .B1(n2883), .C0(n2737), 
        .C1(n2635), .Y(n1569) );
  OAI222X1 U2649 ( .A0(n2632), .A1(n2840), .B0(n2511), .B1(n2883), .C0(n2738), 
        .C1(n2887), .Y(n1570) );
  OAI222X1 U2650 ( .A0(n2885), .A1(n2841), .B0(n2505), .B1(n2883), .C0(n2739), 
        .C1(n2887), .Y(n1572) );
  OAI222X1 U2651 ( .A0(n2885), .A1(n2842), .B0(n2496), .B1(n2883), .C0(n2740), 
        .C1(n2635), .Y(n1575) );
  OAI222X1 U2652 ( .A0(n2632), .A1(n2843), .B0(n2493), .B1(n2883), .C0(n2741), 
        .C1(n2887), .Y(n1576) );
  OAI222X1 U2653 ( .A0(n2886), .A1(n2845), .B0(n2475), .B1(n2883), .C0(n2742), 
        .C1(n2887), .Y(n1582) );
  OAI222X1 U2654 ( .A0(n2886), .A1(n2826), .B0(n2526), .B1(n2884), .C0(n2724), 
        .C1(n2635), .Y(n1565) );
  OAI222X1 U2655 ( .A0(n2632), .A1(n2827), .B0(n2520), .B1(n2884), .C0(n2725), 
        .C1(n2635), .Y(n1567) );
  OAI222X1 U2656 ( .A0(n2886), .A1(n2828), .B0(n2517), .B1(n2884), .C0(n2726), 
        .C1(n2887), .Y(n1568) );
  OAI222X1 U2657 ( .A0(n2886), .A1(n2829), .B0(n2508), .B1(n2884), .C0(n2727), 
        .C1(n2635), .Y(n1571) );
  OAI222X1 U2658 ( .A0(n2632), .A1(n2830), .B0(n2502), .B1(n2884), .C0(n2728), 
        .C1(n2635), .Y(n1573) );
  OAI222X1 U2659 ( .A0(n2886), .A1(n2831), .B0(n2499), .B1(n2884), .C0(n2729), 
        .C1(n2887), .Y(n1574) );
  OAI222X1 U2660 ( .A0(n2886), .A1(n2832), .B0(n2490), .B1(n2884), .C0(n2730), 
        .C1(n2635), .Y(n1577) );
  OAI222X1 U2661 ( .A0(n2885), .A1(n2833), .B0(n2487), .B1(n2884), .C0(n2731), 
        .C1(n2887), .Y(n1578) );
  OAI222X1 U2662 ( .A0(n2632), .A1(n2834), .B0(n2484), .B1(n2884), .C0(n2732), 
        .C1(n2635), .Y(n1579) );
  OAI222X1 U2663 ( .A0(n2886), .A1(n2835), .B0(n2481), .B1(n2884), .C0(n2733), 
        .C1(n2887), .Y(n1580) );
  OAI222X1 U2664 ( .A0(n2886), .A1(n2836), .B0(n2472), .B1(n2884), .C0(n2734), 
        .C1(n2635), .Y(n1583) );
  OAI222X1 U2665 ( .A0(n2886), .A1(n2837), .B0(n2467), .B1(n2884), .C0(n2735), 
        .C1(n2887), .Y(n1584) );
  OAI222X1 U2666 ( .A0(n2891), .A1(n2724), .B0(n2526), .B1(n2889), .C0(n2805), 
        .C1(n2611), .Y(n1585) );
  OAI222X1 U2667 ( .A0(n2608), .A1(n2725), .B0(n2520), .B1(n2889), .C0(n2806), 
        .C1(n2611), .Y(n1587) );
  OAI222X1 U2668 ( .A0(n2891), .A1(n2726), .B0(n2517), .B1(n2889), .C0(n2807), 
        .C1(n2892), .Y(n1588) );
  OAI222X1 U2669 ( .A0(n2891), .A1(n2727), .B0(n2508), .B1(n2889), .C0(n2808), 
        .C1(n2611), .Y(n1591) );
  OAI222X1 U2670 ( .A0(n2608), .A1(n2728), .B0(n2502), .B1(n2889), .C0(n2809), 
        .C1(n2611), .Y(n1593) );
  OAI222X1 U2671 ( .A0(n2891), .A1(n2729), .B0(n2499), .B1(n2889), .C0(n2810), 
        .C1(n2892), .Y(n1594) );
  OAI222X1 U2672 ( .A0(n2891), .A1(n2730), .B0(n2490), .B1(n2889), .C0(n2811), 
        .C1(n2611), .Y(n1597) );
  OAI222X1 U2673 ( .A0(n2890), .A1(n2731), .B0(n2487), .B1(n2889), .C0(n2812), 
        .C1(n2892), .Y(n1598) );
  OAI222X1 U2674 ( .A0(n2608), .A1(n2732), .B0(n2484), .B1(n2889), .C0(n2813), 
        .C1(n2611), .Y(n1599) );
  OAI222X1 U2675 ( .A0(n2891), .A1(n2733), .B0(n2481), .B1(n2889), .C0(n2814), 
        .C1(n2892), .Y(n1600) );
  OAI222X1 U2676 ( .A0(n2891), .A1(n2734), .B0(n2472), .B1(n2889), .C0(n2815), 
        .C1(n2611), .Y(n1603) );
  OAI222X1 U2677 ( .A0(n2891), .A1(n2735), .B0(n2467), .B1(n2889), .C0(n2816), 
        .C1(n2892), .Y(n1604) );
  OAI222X1 U2678 ( .A0(n2905), .A1(n2786), .B0(n2526), .B1(n2903), .C0(n2764), 
        .C1(n2534), .Y(n1645) );
  OAI222X1 U2679 ( .A0(n2531), .A1(n2787), .B0(n2520), .B1(n2903), .C0(n2765), 
        .C1(n2534), .Y(n1647) );
  OAI222X1 U2680 ( .A0(n2905), .A1(n2788), .B0(n2517), .B1(n2903), .C0(n2766), 
        .C1(n2906), .Y(n1648) );
  OAI222X1 U2681 ( .A0(n2905), .A1(n2789), .B0(n2508), .B1(n2903), .C0(n2767), 
        .C1(n2534), .Y(n1651) );
  OAI222X1 U2682 ( .A0(n2531), .A1(n2790), .B0(n2502), .B1(n2903), .C0(n2768), 
        .C1(n2534), .Y(n1653) );
  OAI222X1 U2683 ( .A0(n2905), .A1(n2791), .B0(n2499), .B1(n2903), .C0(n2769), 
        .C1(n2906), .Y(n1654) );
  OAI222X1 U2684 ( .A0(n2905), .A1(n2792), .B0(n2490), .B1(n2903), .C0(n2770), 
        .C1(n2534), .Y(n1657) );
  OAI222X1 U2685 ( .A0(n2904), .A1(n2793), .B0(n2487), .B1(n2903), .C0(n2771), 
        .C1(n2906), .Y(n1658) );
  OAI222X1 U2686 ( .A0(n2531), .A1(n2794), .B0(n2484), .B1(n2903), .C0(n2772), 
        .C1(n2534), .Y(n1659) );
  OAI222X1 U2687 ( .A0(n2905), .A1(n2795), .B0(n2481), .B1(n2903), .C0(n2773), 
        .C1(n2906), .Y(n1660) );
  OAI222X1 U2688 ( .A0(n2905), .A1(n2796), .B0(n2472), .B1(n2903), .C0(n2774), 
        .C1(n2534), .Y(n1663) );
  OAI222X1 U2689 ( .A0(n2905), .A1(n2797), .B0(n2467), .B1(n2903), .C0(n2775), 
        .C1(n2906), .Y(n1664) );
  OAI222X1 U2690 ( .A0(n2900), .A1(n2743), .B0(n2526), .B1(n2898), .C0(n2786), 
        .C1(n2558), .Y(n1625) );
  OAI222X1 U2691 ( .A0(n2555), .A1(n2744), .B0(n2520), .B1(n2898), .C0(n2787), 
        .C1(n2558), .Y(n1627) );
  OAI222X1 U2692 ( .A0(n2900), .A1(n2745), .B0(n2517), .B1(n2898), .C0(n2788), 
        .C1(n2901), .Y(n1628) );
  OAI222X1 U2693 ( .A0(n2900), .A1(n2746), .B0(n2508), .B1(n2898), .C0(n2789), 
        .C1(n2558), .Y(n1631) );
  OAI222X1 U2694 ( .A0(n2555), .A1(n2747), .B0(n2502), .B1(n2898), .C0(n2790), 
        .C1(n2558), .Y(n1633) );
  OAI222X1 U2695 ( .A0(n2900), .A1(n2748), .B0(n2499), .B1(n2898), .C0(n2791), 
        .C1(n2901), .Y(n1634) );
  OAI222X1 U2696 ( .A0(n2900), .A1(n2749), .B0(n2490), .B1(n2898), .C0(n2792), 
        .C1(n2558), .Y(n1637) );
  OAI222X1 U2697 ( .A0(n2899), .A1(n2750), .B0(n2487), .B1(n2898), .C0(n2793), 
        .C1(n2901), .Y(n1638) );
  OAI222X1 U2698 ( .A0(n2555), .A1(n2751), .B0(n2484), .B1(n2898), .C0(n2794), 
        .C1(n2558), .Y(n1639) );
  OAI222X1 U2699 ( .A0(n2900), .A1(n2752), .B0(n2481), .B1(n2898), .C0(n2795), 
        .C1(n2901), .Y(n1640) );
  OAI222X1 U2700 ( .A0(n2900), .A1(n2753), .B0(n2472), .B1(n2898), .C0(n2796), 
        .C1(n2558), .Y(n1643) );
  OAI222X1 U2701 ( .A0(n2900), .A1(n2754), .B0(n2467), .B1(n2898), .C0(n2797), 
        .C1(n2901), .Y(n1644) );
  OAI222X1 U2702 ( .A0(n2890), .A1(n2736), .B0(n2523), .B1(n2888), .C0(n2817), 
        .C1(n2892), .Y(n1586) );
  OAI222X1 U2703 ( .A0(n2890), .A1(n2737), .B0(n2514), .B1(n2888), .C0(n2818), 
        .C1(n2611), .Y(n1589) );
  OAI222X1 U2704 ( .A0(n2608), .A1(n2738), .B0(n2511), .B1(n2888), .C0(n2819), 
        .C1(n2892), .Y(n1590) );
  OAI222X1 U2705 ( .A0(n2890), .A1(n2739), .B0(n2505), .B1(n2888), .C0(n2820), 
        .C1(n2892), .Y(n1592) );
  OAI222X1 U2706 ( .A0(n2890), .A1(n2740), .B0(n2496), .B1(n2888), .C0(n2821), 
        .C1(n2611), .Y(n1595) );
  OAI222X1 U2707 ( .A0(n2608), .A1(n2741), .B0(n2493), .B1(n2888), .C0(n2822), 
        .C1(n2892), .Y(n1596) );
  OAI222X1 U2708 ( .A0(n2891), .A1(n2742), .B0(n2475), .B1(n2888), .C0(n2823), 
        .C1(n2892), .Y(n1602) );
  OAI222X1 U2709 ( .A0(n2899), .A1(n2755), .B0(n2523), .B1(n2557), .C0(n2798), 
        .C1(n2901), .Y(n1626) );
  OAI222X1 U2710 ( .A0(n2899), .A1(n2756), .B0(n2514), .B1(n2557), .C0(n2799), 
        .C1(n2558), .Y(n1629) );
  OAI222X1 U2711 ( .A0(n2555), .A1(n2757), .B0(n2511), .B1(n2557), .C0(n2800), 
        .C1(n2901), .Y(n1630) );
  OAI222X1 U2712 ( .A0(n2899), .A1(n2758), .B0(n2505), .B1(n2898), .C0(n2801), 
        .C1(n2901), .Y(n1632) );
  OAI222X1 U2713 ( .A0(n2899), .A1(n2759), .B0(n2496), .B1(n2557), .C0(n2802), 
        .C1(n2558), .Y(n1635) );
  OAI222X1 U2714 ( .A0(n2555), .A1(n2760), .B0(n2493), .B1(n2557), .C0(n2803), 
        .C1(n2901), .Y(n1636) );
  OAI222X1 U2715 ( .A0(n2900), .A1(n2763), .B0(n2478), .B1(n2557), .C0(n2825), 
        .C1(n2558), .Y(n1641) );
  OAI222X1 U2716 ( .A0(n2900), .A1(n2761), .B0(n2475), .B1(n2898), .C0(n2804), 
        .C1(n2901), .Y(n1642) );
  OAI222X1 U2717 ( .A0(n2896), .A1(n2805), .B0(n2526), .B1(n2585), .C0(n2743), 
        .C1(n2586), .Y(n1605) );
  OAI222X1 U2718 ( .A0(n2583), .A1(n2806), .B0(n2520), .B1(n2585), .C0(n2744), 
        .C1(n2586), .Y(n1607) );
  OAI222X1 U2719 ( .A0(n2896), .A1(n2807), .B0(n2517), .B1(n2585), .C0(n2745), 
        .C1(n2897), .Y(n1608) );
  OAI222X1 U2720 ( .A0(n2896), .A1(n2808), .B0(n2508), .B1(n2585), .C0(n2746), 
        .C1(n2586), .Y(n1611) );
  OAI222X1 U2721 ( .A0(n2583), .A1(n2809), .B0(n2502), .B1(n2585), .C0(n2747), 
        .C1(n2586), .Y(n1613) );
  OAI222X1 U2722 ( .A0(n2896), .A1(n2810), .B0(n2499), .B1(n2585), .C0(n2748), 
        .C1(n2897), .Y(n1614) );
  OAI222X1 U2723 ( .A0(n2896), .A1(n2811), .B0(n2490), .B1(n2585), .C0(n2749), 
        .C1(n2586), .Y(n1617) );
  OAI222X1 U2724 ( .A0(n2895), .A1(n2812), .B0(n2487), .B1(n2585), .C0(n2750), 
        .C1(n2897), .Y(n1618) );
  OAI222X1 U2725 ( .A0(n2583), .A1(n2813), .B0(n2484), .B1(n2585), .C0(n2751), 
        .C1(n2586), .Y(n1619) );
  OAI222X1 U2726 ( .A0(n2896), .A1(n2814), .B0(n2481), .B1(n2585), .C0(n2752), 
        .C1(n2897), .Y(n1620) );
  OAI222X1 U2727 ( .A0(n2896), .A1(n2815), .B0(n2472), .B1(n2585), .C0(n2753), 
        .C1(n2586), .Y(n1623) );
  OAI222X1 U2728 ( .A0(n2896), .A1(n2816), .B0(n2467), .B1(n2585), .C0(n2754), 
        .C1(n2897), .Y(n1624) );
  OAI222X1 U2729 ( .A0(n2895), .A1(n2817), .B0(n2523), .B1(n2585), .C0(n2755), 
        .C1(n2897), .Y(n1606) );
  OAI222X1 U2730 ( .A0(n2895), .A1(n2818), .B0(n2514), .B1(n2585), .C0(n2756), 
        .C1(n2586), .Y(n1609) );
  OAI222X1 U2731 ( .A0(n2583), .A1(n2819), .B0(n2511), .B1(n2585), .C0(n2757), 
        .C1(n2897), .Y(n1610) );
  OAI222X1 U2732 ( .A0(n2895), .A1(n2820), .B0(n2505), .B1(n2894), .C0(n2758), 
        .C1(n2897), .Y(n1612) );
  OAI222X1 U2733 ( .A0(n2895), .A1(n2821), .B0(n2496), .B1(n2585), .C0(n2759), 
        .C1(n2586), .Y(n1615) );
  OAI222X1 U2734 ( .A0(n2583), .A1(n2822), .B0(n2493), .B1(n2894), .C0(n2760), 
        .C1(n2897), .Y(n1616) );
  OAI222X1 U2735 ( .A0(n2896), .A1(n2823), .B0(n2475), .B1(n2585), .C0(n2761), 
        .C1(n2897), .Y(n1622) );
  OAI222X1 U2736 ( .A0(n2886), .A1(n2844), .B0(n2478), .B1(n2634), .C0(n2762), 
        .C1(n2635), .Y(n1581) );
  OAI222X1 U2737 ( .A0(n2891), .A1(n2762), .B0(n2478), .B1(n2610), .C0(n2824), 
        .C1(n2611), .Y(n1601) );
  OAI222X1 U2738 ( .A0(n2896), .A1(n2824), .B0(n2478), .B1(n2894), .C0(n2763), 
        .C1(n2586), .Y(n1621) );
  OAI222X1 U2739 ( .A0(n2905), .A1(n2825), .B0(n2478), .B1(n2533), .C0(n2782), 
        .C1(n2534), .Y(n1661) );
  INVX1 U2740 ( .A(n206_4_), .Y(n2685) );
  INVX1 U2741 ( .A(n206_0_), .Y(n2682) );
  INVX1 U2742 ( .A(BA_REQ), .Y(n2666) );
  INVX1 U2743 ( .A(ras_cnt865_4_), .Y(n2708) );
  NAND3BX1 U2744 ( .AN(ras_cnt_4_), .B(n2784), .C(n2723), .Y(n2713) );
  NOR2X1 U2745 ( .A(CMD[5]), .B(CMD[4]), .Y(n2715) );
  INVX1 U2746 ( .A(n2689), .Y(n2688) );
  OAI222X1 U2747 ( .A0(n2690), .A1(n2846), .B0(n2529), .B1(n2695), .C0(
        ras_cnt_0_), .C1(n2689), .Y(n206_0_) );
  AO22X1 U2748 ( .A0(BA_RA[9]), .A1(n2458), .B0(ras_7_data[14]), .B1(n2459), 
        .Y(n1690) );
  AO22X1 U2749 ( .A0(BA_RA[0]), .A1(n2458), .B0(ras_7_data[5]), .B1(n2459), 
        .Y(n1699) );
  AO22X1 U2750 ( .A0(BA_RA[2]), .A1(n2458), .B0(ras_7_data[7]), .B1(n2459), 
        .Y(n1697) );
  AO22X1 U2751 ( .A0(BA_RA[8]), .A1(n2458), .B0(ras_7_data[13]), .B1(n2459), 
        .Y(n1691) );
  AO22X1 U2752 ( .A0(BA_RA[4]), .A1(n2458), .B0(ras_7_data[9]), .B1(n2459), 
        .Y(n1695) );
  AO22X1 U2753 ( .A0(BA_RA[1]), .A1(n2458), .B0(ras_7_data[6]), .B1(n2459), 
        .Y(n1698) );
  AO22X1 U2754 ( .A0(BA_RA[5]), .A1(n2458), .B0(ras_7_data[10]), .B1(n2459), 
        .Y(n1694) );
  AO22X1 U2755 ( .A0(BA_RA[3]), .A1(n2458), .B0(ras_7_data[8]), .B1(n2459), 
        .Y(n1696) );
  AO22X1 U2756 ( .A0(BA_RA[7]), .A1(n2458), .B0(ras_7_data[12]), .B1(n2459), 
        .Y(n1692) );
  AO22X1 U2757 ( .A0(BA_RA[6]), .A1(n2458), .B0(ras_7_data[11]), .B1(n2459), 
        .Y(n1693) );
  AO22X1 U2758 ( .A0(BA_RA[11]), .A1(n2458), .B0(ras_7_data[16]), .B1(n2459), 
        .Y(n1688) );
  AO22X1 U2759 ( .A0(BA_TT[4]), .A1(n2458), .B0(ras_7_data[4]), .B1(n2459), 
        .Y(n1700) );
  OAI222X1 U2760 ( .A0(n2881), .A1(n1470), .B0(n2526), .B1(n2879), .C0(n2826), 
        .C1(n2658), .Y(n1545) );
  OAI222X1 U2761 ( .A0(n2656), .A1(n1474), .B0(n2520), .B1(n2657), .C0(n2827), 
        .C1(n2658), .Y(n1547) );
  OAI222X1 U2762 ( .A0(n2881), .A1(n1473), .B0(n2517), .B1(n2879), .C0(n2828), 
        .C1(n2882), .Y(n1548) );
  OAI222X1 U2763 ( .A0(n2881), .A1(n1482), .B0(n2508), .B1(n2879), .C0(n2829), 
        .C1(n2658), .Y(n1551) );
  OAI222X1 U2764 ( .A0(n2656), .A1(n1480), .B0(n2502), .B1(n2879), .C0(n2830), 
        .C1(n2658), .Y(n1553) );
  OAI222X1 U2765 ( .A0(n2881), .A1(n1479), .B0(n2499), .B1(n2879), .C0(n2831), 
        .C1(n2882), .Y(n1554) );
  OAI222X1 U2766 ( .A0(n2881), .A1(n1476), .B0(n2490), .B1(n2657), .C0(n2832), 
        .C1(n2658), .Y(n1557) );
  OAI222X1 U2767 ( .A0(n2880), .A1(n1475), .B0(n2487), .B1(n2657), .C0(n2833), 
        .C1(n2882), .Y(n1558) );
  OAI222X1 U2768 ( .A0(n2656), .A1(n1471), .B0(n2484), .B1(n2879), .C0(n2834), 
        .C1(n2658), .Y(n1559) );
  OAI222X1 U2769 ( .A0(n2881), .A1(n1488), .B0(n2481), .B1(n2657), .C0(n2835), 
        .C1(n2882), .Y(n1560) );
  OAI222X1 U2770 ( .A0(n2881), .A1(n1485), .B0(n2472), .B1(n2657), .C0(n2836), 
        .C1(n2658), .Y(n1563) );
  OAI222X1 U2771 ( .A0(n2881), .A1(n1484), .B0(n2467), .B1(n2657), .C0(n2837), 
        .C1(n2882), .Y(n1564) );
  OAI222X1 U2772 ( .A0(n2910), .A1(n2764), .B0(n2526), .B1(n2722), .C0(n2847), 
        .C1(n2470), .Y(n1665) );
  OAI222X1 U2773 ( .A0(n2465), .A1(n2765), .B0(n2520), .B1(n2722), .C0(n2848), 
        .C1(n2470), .Y(n1667) );
  OAI222X1 U2774 ( .A0(n2910), .A1(n2766), .B0(n2517), .B1(n2722), .C0(n2849), 
        .C1(n2911), .Y(n1668) );
  OAI222X1 U2775 ( .A0(n2910), .A1(n2767), .B0(n2508), .B1(n2722), .C0(n2850), 
        .C1(n2470), .Y(n1671) );
  OAI222X1 U2776 ( .A0(n2465), .A1(n2768), .B0(n2502), .B1(n2722), .C0(n2851), 
        .C1(n2470), .Y(n1673) );
  OAI222X1 U2777 ( .A0(n2910), .A1(n2769), .B0(n2499), .B1(n2722), .C0(n2852), 
        .C1(n2911), .Y(n1674) );
  OAI222X1 U2778 ( .A0(n2910), .A1(n2770), .B0(n2490), .B1(n2722), .C0(n2853), 
        .C1(n2470), .Y(n1677) );
  OAI222X1 U2779 ( .A0(n2909), .A1(n2771), .B0(n2487), .B1(n2722), .C0(n2854), 
        .C1(n2911), .Y(n1678) );
  OAI222X1 U2780 ( .A0(n2465), .A1(n2772), .B0(n2484), .B1(n2722), .C0(n2855), 
        .C1(n2470), .Y(n1679) );
  OAI222X1 U2781 ( .A0(n2910), .A1(n2773), .B0(n2481), .B1(n2722), .C0(n2856), 
        .C1(n2911), .Y(n1680) );
  OAI222X1 U2782 ( .A0(n2910), .A1(n2774), .B0(n2472), .B1(n2722), .C0(n2857), 
        .C1(n2470), .Y(n1683) );
  OAI222X1 U2783 ( .A0(n2910), .A1(n2775), .B0(n2467), .B1(n2722), .C0(n2858), 
        .C1(n2911), .Y(n1684) );
  OAI222X1 U2784 ( .A0(n2880), .A1(n1469), .B0(n2523), .B1(n2657), .C0(n2838), 
        .C1(n2882), .Y(n1546) );
  OAI222X1 U2785 ( .A0(n2880), .A1(n1472), .B0(n2514), .B1(n2879), .C0(n2839), 
        .C1(n2658), .Y(n1549) );
  OAI222X1 U2786 ( .A0(n2656), .A1(n1483), .B0(n2511), .B1(n2879), .C0(n2840), 
        .C1(n2882), .Y(n1550) );
  OAI222X1 U2787 ( .A0(n2880), .A1(n1481), .B0(n2505), .B1(n2657), .C0(n2841), 
        .C1(n2882), .Y(n1552) );
  OAI222X1 U2788 ( .A0(n2880), .A1(n1478), .B0(n2496), .B1(n2879), .C0(n2842), 
        .C1(n2658), .Y(n1555) );
  OAI222X1 U2789 ( .A0(n2656), .A1(n1477), .B0(n2493), .B1(n2657), .C0(n2843), 
        .C1(n2882), .Y(n1556) );
  OAI222X1 U2790 ( .A0(n2881), .A1(n1487), .B0(n2478), .B1(n2657), .C0(n2844), 
        .C1(n2658), .Y(n1561) );
  OAI222X1 U2791 ( .A0(n2881), .A1(n1486), .B0(n2475), .B1(n2879), .C0(n2845), 
        .C1(n2882), .Y(n1562) );
  OAI222X1 U2792 ( .A0(n2909), .A1(n2776), .B0(n2523), .B1(n2907), .C0(n2859), 
        .C1(n2911), .Y(n1666) );
  OAI222X1 U2793 ( .A0(n2909), .A1(n2777), .B0(n2514), .B1(n2907), .C0(n2860), 
        .C1(n2470), .Y(n1669) );
  OAI222X1 U2794 ( .A0(n2909), .A1(n2779), .B0(n2505), .B1(n2907), .C0(n2862), 
        .C1(n2911), .Y(n1672) );
  OAI222X1 U2795 ( .A0(n2909), .A1(n2780), .B0(n2496), .B1(n2907), .C0(n2863), 
        .C1(n2470), .Y(n1675) );
  OAI222X1 U2796 ( .A0(n2465), .A1(n2781), .B0(n2493), .B1(n2907), .C0(n2864), 
        .C1(n2911), .Y(n1676) );
  OAI222X1 U2797 ( .A0(n2910), .A1(n2782), .B0(n2478), .B1(n2468), .C0(n2865), 
        .C1(n2470), .Y(n1681) );
  OAI222X1 U2798 ( .A0(n2910), .A1(n2783), .B0(n2475), .B1(n2907), .C0(n2866), 
        .C1(n2911), .Y(n1682) );
  AO22X1 U2799 ( .A0(BA_TT[3]), .A1(n2458), .B0(ras_7_data[3]), .B1(n2459), 
        .Y(n1701) );
  AO22X1 U2800 ( .A0(BA_TT[2]), .A1(n2458), .B0(ras_7_data[2]), .B1(n2459), 
        .Y(n1702) );
  AO22X1 U2801 ( .A0(BA_TT[1]), .A1(n2458), .B0(ras_7_data[1]), .B1(n2459), 
        .Y(n1703) );
  AO22X1 U2802 ( .A0(BA_TT[0]), .A1(n2458), .B0(ras_7_data[0]), .B1(n2459), 
        .Y(n1704) );
  AO22X1 U2803 ( .A0(n2678), .A1(n2677), .B0(B0_LAST_RA[13]), .B1(n2676), .Y(
        n1489) );
  AO22X1 U2804 ( .A0(n2674), .A1(n2673), .B0(B1_LAST_RA[13]), .B1(n2672), .Y(
        n1503) );
  AO22X1 U2805 ( .A0(n2670), .A1(n2669), .B0(B2_LAST_RA[13]), .B1(n2668), .Y(
        n1517) );
  AO22X1 U2806 ( .A0(n2665), .A1(n2664), .B0(B3_LAST_RA[13]), .B1(n2663), .Y(
        n1531) );
  AO22X1 U2807 ( .A0(n2675), .A1(BA_RA[9]), .B0(B0_LAST_RA[9]), .B1(n2676), 
        .Y(n1493) );
  AO22X1 U2808 ( .A0(n2671), .A1(BA_RA[9]), .B0(B1_LAST_RA[9]), .B1(n2672), 
        .Y(n1507) );
  AO22X1 U2809 ( .A0(n2667), .A1(BA_RA[9]), .B0(B2_LAST_RA[9]), .B1(n2668), 
        .Y(n1521) );
  AO22X1 U2810 ( .A0(n2662), .A1(BA_RA[9]), .B0(B3_LAST_RA[9]), .B1(n2663), 
        .Y(n1535) );
  AO22X1 U2811 ( .A0(n2675), .A1(BA_RA[0]), .B0(B0_LAST_RA[0]), .B1(n2676), 
        .Y(n1502) );
  AO22X1 U2812 ( .A0(n2671), .A1(BA_RA[0]), .B0(B1_LAST_RA[0]), .B1(n2672), 
        .Y(n1516) );
  AO22X1 U2813 ( .A0(n2667), .A1(BA_RA[0]), .B0(B2_LAST_RA[0]), .B1(n2668), 
        .Y(n1530) );
  AO22X1 U2814 ( .A0(n2662), .A1(BA_RA[0]), .B0(B3_LAST_RA[0]), .B1(n2663), 
        .Y(n1544) );
  AO22X1 U2815 ( .A0(n2675), .A1(BA_RA[2]), .B0(B0_LAST_RA[2]), .B1(n2676), 
        .Y(n1500) );
  AO22X1 U2816 ( .A0(n2671), .A1(BA_RA[2]), .B0(B1_LAST_RA[2]), .B1(n2672), 
        .Y(n1514) );
  AO22X1 U2817 ( .A0(n2667), .A1(BA_RA[2]), .B0(B2_LAST_RA[2]), .B1(n2668), 
        .Y(n1528) );
  AO22X1 U2818 ( .A0(n2662), .A1(BA_RA[2]), .B0(B3_LAST_RA[2]), .B1(n2663), 
        .Y(n1542) );
  AO22X1 U2819 ( .A0(n2675), .A1(BA_RA[8]), .B0(B0_LAST_RA[8]), .B1(n2676), 
        .Y(n1494) );
  AO22X1 U2820 ( .A0(n2675), .A1(BA_RA[4]), .B0(B0_LAST_RA[4]), .B1(n2676), 
        .Y(n1498) );
  AO22X1 U2821 ( .A0(n2671), .A1(BA_RA[8]), .B0(B1_LAST_RA[8]), .B1(n2672), 
        .Y(n1508) );
  AO22X1 U2822 ( .A0(n2671), .A1(BA_RA[4]), .B0(B1_LAST_RA[4]), .B1(n2672), 
        .Y(n1512) );
  AO22X1 U2823 ( .A0(n2667), .A1(BA_RA[8]), .B0(B2_LAST_RA[8]), .B1(n2668), 
        .Y(n1522) );
  AO22X1 U2824 ( .A0(n2667), .A1(BA_RA[4]), .B0(B2_LAST_RA[4]), .B1(n2668), 
        .Y(n1526) );
  AO22X1 U2825 ( .A0(n2662), .A1(BA_RA[8]), .B0(B3_LAST_RA[8]), .B1(n2663), 
        .Y(n1536) );
  AO22X1 U2826 ( .A0(n2662), .A1(BA_RA[4]), .B0(B3_LAST_RA[4]), .B1(n2663), 
        .Y(n1540) );
  AO22X1 U2827 ( .A0(n2675), .A1(BA_RA[1]), .B0(B0_LAST_RA[1]), .B1(n2676), 
        .Y(n1501) );
  AO22X1 U2828 ( .A0(n2671), .A1(BA_RA[1]), .B0(B1_LAST_RA[1]), .B1(n2672), 
        .Y(n1515) );
  AO22X1 U2829 ( .A0(n2667), .A1(BA_RA[1]), .B0(B2_LAST_RA[1]), .B1(n2668), 
        .Y(n1529) );
  AO22X1 U2830 ( .A0(n2662), .A1(BA_RA[1]), .B0(B3_LAST_RA[1]), .B1(n2663), 
        .Y(n1543) );
  AO22X1 U2831 ( .A0(n2675), .A1(BA_RA[5]), .B0(B0_LAST_RA[5]), .B1(n2676), 
        .Y(n1497) );
  AO22X1 U2832 ( .A0(n2671), .A1(BA_RA[5]), .B0(B1_LAST_RA[5]), .B1(n2672), 
        .Y(n1511) );
  AO22X1 U2833 ( .A0(n2667), .A1(BA_RA[5]), .B0(B2_LAST_RA[5]), .B1(n2668), 
        .Y(n1525) );
  AO22X1 U2834 ( .A0(n2662), .A1(BA_RA[5]), .B0(B3_LAST_RA[5]), .B1(n2663), 
        .Y(n1539) );
  AO22X1 U2835 ( .A0(n2675), .A1(BA_RA[3]), .B0(B0_LAST_RA[3]), .B1(n2676), 
        .Y(n1499) );
  AO22X1 U2836 ( .A0(n2671), .A1(BA_RA[3]), .B0(B1_LAST_RA[3]), .B1(n2672), 
        .Y(n1513) );
  AO22X1 U2837 ( .A0(n2667), .A1(BA_RA[3]), .B0(B2_LAST_RA[3]), .B1(n2668), 
        .Y(n1527) );
  AO22X1 U2838 ( .A0(n2662), .A1(BA_RA[3]), .B0(B3_LAST_RA[3]), .B1(n2663), 
        .Y(n1541) );
  AO22X1 U2839 ( .A0(n2675), .A1(BA_RA[7]), .B0(B0_LAST_RA[7]), .B1(n2676), 
        .Y(n1495) );
  AO22X1 U2840 ( .A0(n2671), .A1(BA_RA[7]), .B0(B1_LAST_RA[7]), .B1(n2672), 
        .Y(n1509) );
  AO22X1 U2841 ( .A0(n2667), .A1(BA_RA[7]), .B0(B2_LAST_RA[7]), .B1(n2668), 
        .Y(n1523) );
  AO22X1 U2842 ( .A0(n2662), .A1(BA_RA[7]), .B0(B3_LAST_RA[7]), .B1(n2663), 
        .Y(n1537) );
  AO22X1 U2843 ( .A0(n2675), .A1(BA_RA[6]), .B0(B0_LAST_RA[6]), .B1(n2676), 
        .Y(n1496) );
  AO22X1 U2844 ( .A0(n2671), .A1(BA_RA[6]), .B0(B1_LAST_RA[6]), .B1(n2672), 
        .Y(n1510) );
  AO22X1 U2845 ( .A0(n2667), .A1(BA_RA[6]), .B0(B2_LAST_RA[6]), .B1(n2668), 
        .Y(n1524) );
  AO22X1 U2846 ( .A0(n2662), .A1(BA_RA[6]), .B0(B3_LAST_RA[6]), .B1(n2663), 
        .Y(n1538) );
  AO22X1 U2847 ( .A0(n2675), .A1(BA_RA[11]), .B0(B0_LAST_RA[11]), .B1(n2676), 
        .Y(n1491) );
  AO22X1 U2848 ( .A0(n2671), .A1(BA_RA[11]), .B0(B1_LAST_RA[11]), .B1(n2672), 
        .Y(n1505) );
  AO22X1 U2849 ( .A0(n2667), .A1(BA_RA[11]), .B0(B2_LAST_RA[11]), .B1(n2668), 
        .Y(n1519) );
  AO22X1 U2850 ( .A0(n2662), .A1(BA_RA[11]), .B0(B3_LAST_RA[11]), .B1(n2663), 
        .Y(n1533) );
  XOR2X1 U2851 ( .A(ras_cnt_4_), .B(n2872), .Y(ras_cnt865_4_) );
  NOR2X1 U2852 ( .A(ras_cnt_3_), .B(carry_3_), .Y(n2872) );
  XOR2X1 U2853 ( .A(ras_cnt_3_), .B(carry_3_), .Y(n2873) );
  OR2X1 U1_B_1 ( .A(ras_cnt_1_), .B(ras_cnt_0_), .Y(carry_2_) );
  OR2X1 U1_B_2 ( .A(ras_cnt_2_), .B(carry_2_), .Y(carry_3_) );
  XOR2X1 U2854 ( .A(ras_cnt_2_), .B(carry_2_), .Y(n2874) );
  XOR2X1 U2855 ( .A(ras_cnt_1_), .B(ras_cnt_0_), .Y(n2875) );
  DFFSX1 RAS_EMPTY_reg ( .D(RAS_EMPTY471), .CK(ACLK), .SN(ARESETB), .Q(
        RAS_EMPTY) );
  DFFRX1 ras_cnt_reg_0_ ( .D(n206_0_), .CK(ACLK), .RN(ARESETB), .Q(ras_cnt_0_), 
        .QN(n2846) );
  DFFRX1 ras_cnt_reg_1_ ( .D(n206_1_), .CK(ACLK), .RN(ARESETB), .Q(ras_cnt_1_), 
        .QN(n2785) );
  DFFRX1 ras_cnt_reg_4_ ( .D(n206_4_), .CK(ACLK), .RN(ARESETB), .Q(ras_cnt_4_), 
        .QN(n2868) );
  DFFRX1 ras_cnt_reg_3_ ( .D(n206_3_), .CK(ACLK), .RN(ARESETB), .Q(ras_cnt_3_), 
        .QN(n2784) );
  DFFRX1 ras_cnt_reg_2_ ( .D(n206_2_), .CK(ACLK), .RN(ARESETB), .Q(ras_cnt_2_), 
        .QN(n2723) );
  DFFRX1 l_b0_last_ra_reg_0_ ( .D(n1502), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[0]) );
  DFFRX1 l_b1_last_ra_reg_0_ ( .D(n1516), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[0]) );
  DFFRX1 l_b2_last_ra_reg_0_ ( .D(n1530), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[0]) );
  DFFRX1 l_b3_last_ra_reg_0_ ( .D(n1544), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[0]) );
  DFFRX1 l_b0_last_ra_reg_6_ ( .D(n1496), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[6]) );
  DFFRX1 l_b0_last_ra_reg_1_ ( .D(n1501), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[1]) );
  DFFRX1 l_b1_last_ra_reg_6_ ( .D(n1510), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[6]) );
  DFFRX1 l_b1_last_ra_reg_1_ ( .D(n1515), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[1]) );
  DFFRX1 l_b2_last_ra_reg_6_ ( .D(n1524), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[6]) );
  DFFRX1 l_b2_last_ra_reg_1_ ( .D(n1529), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[1]) );
  DFFRX1 l_b3_last_ra_reg_6_ ( .D(n1538), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[6]) );
  DFFRX1 l_b3_last_ra_reg_1_ ( .D(n1543), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[1]) );
  DFFRX1 l_b0_last_ra_reg_9_ ( .D(n1493), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[9]) );
  DFFRX1 l_b0_last_ra_reg_2_ ( .D(n1500), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[2]) );
  DFFRX1 l_b1_last_ra_reg_9_ ( .D(n1507), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[9]) );
  DFFRX1 l_b1_last_ra_reg_2_ ( .D(n1514), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[2]) );
  DFFRX1 l_b2_last_ra_reg_9_ ( .D(n1521), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[9]) );
  DFFRX1 l_b2_last_ra_reg_2_ ( .D(n1528), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[2]) );
  DFFRX1 l_b3_last_ra_reg_9_ ( .D(n1535), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[9]) );
  DFFRX1 l_b3_last_ra_reg_2_ ( .D(n1542), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[2]) );
  DFFRX1 l_b0_last_ra_reg_11_ ( .D(n1491), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[11]) );
  DFFRX1 l_b0_last_ra_reg_3_ ( .D(n1499), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[3]) );
  DFFRX1 l_b1_last_ra_reg_11_ ( .D(n1505), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[11]) );
  DFFRX1 l_b1_last_ra_reg_3_ ( .D(n1513), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[3]) );
  DFFRX1 l_b2_last_ra_reg_11_ ( .D(n1519), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[11]) );
  DFFRX1 l_b2_last_ra_reg_3_ ( .D(n1527), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[3]) );
  DFFRX1 l_b3_last_ra_reg_11_ ( .D(n1533), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[11]) );
  DFFRX1 l_b3_last_ra_reg_3_ ( .D(n1541), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[3]) );
  DFFRX1 l_b0_last_ra_reg_5_ ( .D(n1497), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[5]) );
  DFFRX1 l_b0_last_ra_reg_4_ ( .D(n1498), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[4]) );
  DFFRX1 l_b1_last_ra_reg_5_ ( .D(n1511), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[5]) );
  DFFRX1 l_b1_last_ra_reg_4_ ( .D(n1512), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[4]) );
  DFFRX1 l_b2_last_ra_reg_5_ ( .D(n1525), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[5]) );
  DFFRX1 l_b2_last_ra_reg_4_ ( .D(n1526), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[4]) );
  DFFRX1 l_b3_last_ra_reg_5_ ( .D(n1539), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[5]) );
  DFFRX1 l_b3_last_ra_reg_4_ ( .D(n1540), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[4]) );
  DFFRX1 l_b0_last_ra_reg_12_ ( .D(n1490), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[12]) );
  DFFRX1 l_b1_last_ra_reg_12_ ( .D(n1504), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[12]) );
  DFFRX1 l_b2_last_ra_reg_12_ ( .D(n1518), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[12]) );
  DFFRX1 l_b3_last_ra_reg_10_ ( .D(n1534), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[10]) );
  DFFRX1 l_b3_last_ra_reg_12_ ( .D(n1532), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[12]) );
  DFFRX1 l_b0_last_ra_reg_10_ ( .D(n1492), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[10]) );
  DFFRX1 l_b1_last_ra_reg_10_ ( .D(n1506), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[10]) );
  DFFRX1 l_b2_last_ra_reg_10_ ( .D(n1520), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[10]) );
  DFFRX1 l_b0_last_ra_reg_7_ ( .D(n1495), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[7]) );
  DFFRX1 l_b1_last_ra_reg_7_ ( .D(n1509), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[7]) );
  DFFRX1 l_b2_last_ra_reg_7_ ( .D(n1523), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[7]) );
  DFFRX1 l_b3_last_ra_reg_7_ ( .D(n1537), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[7]) );
  DFFRX1 l_b0_last_ra_reg_8_ ( .D(n1494), .CK(ACLK), .RN(ARESETB), .Q(
        B0_LAST_RA[8]) );
  DFFRX1 l_b1_last_ra_reg_8_ ( .D(n1508), .CK(ACLK), .RN(ARESETB), .Q(
        B1_LAST_RA[8]) );
  DFFRX1 l_b2_last_ra_reg_8_ ( .D(n1522), .CK(ACLK), .RN(ARESETB), .Q(
        B2_LAST_RA[8]) );
  DFFRX1 l_b3_last_ra_reg_8_ ( .D(n1536), .CK(ACLK), .RN(ARESETB), .Q(
        B3_LAST_RA[8]) );
  DFFSX1 l_b3_last_ra_reg_13_ ( .D(n1531), .CK(ACLK), .SN(ARESETB), .Q(
        B3_LAST_RA[13]) );
  DFFSX1 l_b0_last_ra_reg_13_ ( .D(n1489), .CK(ACLK), .SN(ARESETB), .Q(
        B0_LAST_RA[13]) );
  DFFSX1 l_b1_last_ra_reg_13_ ( .D(n1503), .CK(ACLK), .SN(ARESETB), .Q(
        B1_LAST_RA[13]) );
  DFFSX1 l_b2_last_ra_reg_13_ ( .D(n1517), .CK(ACLK), .SN(ARESETB), .Q(
        B2_LAST_RA[13]) );
  DFFRX1 ras_7_data_reg_16_ ( .D(n1688), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[16]), .QN(n2849) );
  DFFRX1 ras_7_data_reg_14_ ( .D(n1690), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[14]), .QN(n2861) );
  DFFRX1 ras_7_data_reg_13_ ( .D(n1691), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[13]), .QN(n2850) );
  DFFRX1 ras_7_data_reg_12_ ( .D(n1692), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[12]), .QN(n2862) );
  DFFRX1 ras_7_data_reg_11_ ( .D(n1693), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[11]), .QN(n2851) );
  DFFRX1 ras_7_data_reg_10_ ( .D(n1694), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[10]), .QN(n2852) );
  DFFRX1 ras_7_data_reg_9_ ( .D(n1695), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[9]), .QN(n2863) );
  DFFRX1 ras_7_data_reg_8_ ( .D(n1696), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[8]), .QN(n2864) );
  DFFRX1 ras_7_data_reg_7_ ( .D(n1697), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[7]), .QN(n2853) );
  DFFRX1 ras_7_data_reg_6_ ( .D(n1698), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[6]), .QN(n2854) );
  DFFRX1 ras_7_data_reg_5_ ( .D(n1699), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[5]), .QN(n2855) );
  DFFRX1 ras_7_data_reg_4_ ( .D(n1700), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[4]), .QN(n2856) );
  DFFRX1 ras_7_data_reg_3_ ( .D(n1701), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[3]), .QN(n2865) );
  DFFRX1 ras_7_data_reg_2_ ( .D(n1702), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[2]), .QN(n2866) );
  DFFRX1 ras_7_data_reg_1_ ( .D(n1703), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[1]), .QN(n2857) );
  DFFRX1 ras_7_data_reg_0_ ( .D(n1704), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[0]), .QN(n2858) );
  DFFRX1 ras_7_data_reg_19_ ( .D(n1685), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[19]), .QN(n2847) );
  DFFRX1 ras_7_data_reg_18_ ( .D(n1686), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[18]), .QN(n2859) );
  DFFRX1 ras_7_data_reg_17_ ( .D(n1687), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[17]), .QN(n2848) );
  DFFRX1 ras_7_data_reg_15_ ( .D(n1689), .CK(ACLK), .RN(ARESETB), .Q(
        ras_7_data[15]), .QN(n2860) );
  DFFRX1 ras_1_data_reg_19_ ( .D(n1565), .CK(ACLK), .RN(ARESETB), .QN(n2826)
         );
  DFFRX1 ras_1_data_reg_18_ ( .D(n1566), .CK(ACLK), .RN(ARESETB), .QN(n2838)
         );
  DFFRX1 ras_1_data_reg_17_ ( .D(n1567), .CK(ACLK), .RN(ARESETB), .QN(n2827)
         );
  DFFRX1 ras_1_data_reg_16_ ( .D(n1568), .CK(ACLK), .RN(ARESETB), .QN(n2828)
         );
  DFFRX1 ras_1_data_reg_15_ ( .D(n1569), .CK(ACLK), .RN(ARESETB), .QN(n2839)
         );
  DFFRX1 ras_1_data_reg_14_ ( .D(n1570), .CK(ACLK), .RN(ARESETB), .QN(n2840)
         );
  DFFRX1 ras_1_data_reg_13_ ( .D(n1571), .CK(ACLK), .RN(ARESETB), .QN(n2829)
         );
  DFFRX1 ras_1_data_reg_12_ ( .D(n1572), .CK(ACLK), .RN(ARESETB), .QN(n2841)
         );
  DFFRX1 ras_1_data_reg_11_ ( .D(n1573), .CK(ACLK), .RN(ARESETB), .QN(n2830)
         );
  DFFRX1 ras_1_data_reg_10_ ( .D(n1574), .CK(ACLK), .RN(ARESETB), .QN(n2831)
         );
  DFFRX1 ras_1_data_reg_9_ ( .D(n1575), .CK(ACLK), .RN(ARESETB), .QN(n2842) );
  DFFRX1 ras_1_data_reg_8_ ( .D(n1576), .CK(ACLK), .RN(ARESETB), .QN(n2843) );
  DFFRX1 ras_1_data_reg_7_ ( .D(n1577), .CK(ACLK), .RN(ARESETB), .QN(n2832) );
  DFFRX1 ras_1_data_reg_6_ ( .D(n1578), .CK(ACLK), .RN(ARESETB), .QN(n2833) );
  DFFRX1 ras_1_data_reg_5_ ( .D(n1579), .CK(ACLK), .RN(ARESETB), .QN(n2834) );
  DFFRX1 ras_1_data_reg_4_ ( .D(n1580), .CK(ACLK), .RN(ARESETB), .QN(n2835) );
  DFFRX1 ras_1_data_reg_3_ ( .D(n1581), .CK(ACLK), .RN(ARESETB), .QN(n2844) );
  DFFRX1 ras_1_data_reg_2_ ( .D(n1582), .CK(ACLK), .RN(ARESETB), .QN(n2845) );
  DFFRX1 ras_1_data_reg_1_ ( .D(n1583), .CK(ACLK), .RN(ARESETB), .QN(n2836) );
  DFFRX1 ras_1_data_reg_0_ ( .D(n1584), .CK(ACLK), .RN(ARESETB), .QN(n2837) );
  DFFRX1 ras_2_data_reg_19_ ( .D(n1585), .CK(ACLK), .RN(ARESETB), .QN(n2724)
         );
  DFFRX1 ras_2_data_reg_18_ ( .D(n1586), .CK(ACLK), .RN(ARESETB), .QN(n2736)
         );
  DFFRX1 ras_2_data_reg_17_ ( .D(n1587), .CK(ACLK), .RN(ARESETB), .QN(n2725)
         );
  DFFRX1 ras_2_data_reg_16_ ( .D(n1588), .CK(ACLK), .RN(ARESETB), .QN(n2726)
         );
  DFFRX1 ras_2_data_reg_15_ ( .D(n1589), .CK(ACLK), .RN(ARESETB), .QN(n2737)
         );
  DFFRX1 ras_2_data_reg_14_ ( .D(n1590), .CK(ACLK), .RN(ARESETB), .QN(n2738)
         );
  DFFRX1 ras_2_data_reg_13_ ( .D(n1591), .CK(ACLK), .RN(ARESETB), .QN(n2727)
         );
  DFFRX1 ras_2_data_reg_12_ ( .D(n1592), .CK(ACLK), .RN(ARESETB), .QN(n2739)
         );
  DFFRX1 ras_2_data_reg_11_ ( .D(n1593), .CK(ACLK), .RN(ARESETB), .QN(n2728)
         );
  DFFRX1 ras_2_data_reg_10_ ( .D(n1594), .CK(ACLK), .RN(ARESETB), .QN(n2729)
         );
  DFFRX1 ras_2_data_reg_9_ ( .D(n1595), .CK(ACLK), .RN(ARESETB), .QN(n2740) );
  DFFRX1 ras_2_data_reg_8_ ( .D(n1596), .CK(ACLK), .RN(ARESETB), .QN(n2741) );
  DFFRX1 ras_2_data_reg_7_ ( .D(n1597), .CK(ACLK), .RN(ARESETB), .QN(n2730) );
  DFFRX1 ras_2_data_reg_6_ ( .D(n1598), .CK(ACLK), .RN(ARESETB), .QN(n2731) );
  DFFRX1 ras_2_data_reg_5_ ( .D(n1599), .CK(ACLK), .RN(ARESETB), .QN(n2732) );
  DFFRX1 ras_2_data_reg_4_ ( .D(n1600), .CK(ACLK), .RN(ARESETB), .QN(n2733) );
  DFFRX1 ras_2_data_reg_3_ ( .D(n1601), .CK(ACLK), .RN(ARESETB), .QN(n2762) );
  DFFRX1 ras_2_data_reg_2_ ( .D(n1602), .CK(ACLK), .RN(ARESETB), .QN(n2742) );
  DFFRX1 ras_2_data_reg_1_ ( .D(n1603), .CK(ACLK), .RN(ARESETB), .QN(n2734) );
  DFFRX1 ras_2_data_reg_0_ ( .D(n1604), .CK(ACLK), .RN(ARESETB), .QN(n2735) );
  DFFRX1 ras_3_data_reg_19_ ( .D(n1605), .CK(ACLK), .RN(ARESETB), .QN(n2805)
         );
  DFFRX1 ras_3_data_reg_18_ ( .D(n1606), .CK(ACLK), .RN(ARESETB), .QN(n2817)
         );
  DFFRX1 ras_3_data_reg_17_ ( .D(n1607), .CK(ACLK), .RN(ARESETB), .QN(n2806)
         );
  DFFRX1 ras_3_data_reg_16_ ( .D(n1608), .CK(ACLK), .RN(ARESETB), .QN(n2807)
         );
  DFFRX1 ras_3_data_reg_15_ ( .D(n1609), .CK(ACLK), .RN(ARESETB), .QN(n2818)
         );
  DFFRX1 ras_3_data_reg_14_ ( .D(n1610), .CK(ACLK), .RN(ARESETB), .QN(n2819)
         );
  DFFRX1 ras_3_data_reg_13_ ( .D(n1611), .CK(ACLK), .RN(ARESETB), .QN(n2808)
         );
  DFFRX1 ras_3_data_reg_12_ ( .D(n1612), .CK(ACLK), .RN(ARESETB), .QN(n2820)
         );
  DFFRX1 ras_3_data_reg_11_ ( .D(n1613), .CK(ACLK), .RN(ARESETB), .QN(n2809)
         );
  DFFRX1 ras_3_data_reg_10_ ( .D(n1614), .CK(ACLK), .RN(ARESETB), .QN(n2810)
         );
  DFFRX1 ras_3_data_reg_9_ ( .D(n1615), .CK(ACLK), .RN(ARESETB), .QN(n2821) );
  DFFRX1 ras_3_data_reg_8_ ( .D(n1616), .CK(ACLK), .RN(ARESETB), .QN(n2822) );
  DFFRX1 ras_3_data_reg_7_ ( .D(n1617), .CK(ACLK), .RN(ARESETB), .QN(n2811) );
  DFFRX1 ras_3_data_reg_6_ ( .D(n1618), .CK(ACLK), .RN(ARESETB), .QN(n2812) );
  DFFRX1 ras_3_data_reg_5_ ( .D(n1619), .CK(ACLK), .RN(ARESETB), .QN(n2813) );
  DFFRX1 ras_3_data_reg_4_ ( .D(n1620), .CK(ACLK), .RN(ARESETB), .QN(n2814) );
  DFFRX1 ras_3_data_reg_3_ ( .D(n1621), .CK(ACLK), .RN(ARESETB), .QN(n2824) );
  DFFRX1 ras_3_data_reg_2_ ( .D(n1622), .CK(ACLK), .RN(ARESETB), .QN(n2823) );
  DFFRX1 ras_3_data_reg_1_ ( .D(n1623), .CK(ACLK), .RN(ARESETB), .QN(n2815) );
  DFFRX1 ras_3_data_reg_0_ ( .D(n1624), .CK(ACLK), .RN(ARESETB), .QN(n2816) );
  DFFRX1 ras_4_data_reg_19_ ( .D(n1625), .CK(ACLK), .RN(ARESETB), .QN(n2743)
         );
  DFFRX1 ras_4_data_reg_18_ ( .D(n1626), .CK(ACLK), .RN(ARESETB), .QN(n2755)
         );
  DFFRX1 ras_4_data_reg_17_ ( .D(n1627), .CK(ACLK), .RN(ARESETB), .QN(n2744)
         );
  DFFRX1 ras_4_data_reg_16_ ( .D(n1628), .CK(ACLK), .RN(ARESETB), .QN(n2745)
         );
  DFFRX1 ras_4_data_reg_15_ ( .D(n1629), .CK(ACLK), .RN(ARESETB), .QN(n2756)
         );
  DFFRX1 ras_4_data_reg_14_ ( .D(n1630), .CK(ACLK), .RN(ARESETB), .QN(n2757)
         );
  DFFRX1 ras_4_data_reg_13_ ( .D(n1631), .CK(ACLK), .RN(ARESETB), .QN(n2746)
         );
  DFFRX1 ras_4_data_reg_12_ ( .D(n1632), .CK(ACLK), .RN(ARESETB), .QN(n2758)
         );
  DFFRX1 ras_4_data_reg_11_ ( .D(n1633), .CK(ACLK), .RN(ARESETB), .QN(n2747)
         );
  DFFRX1 ras_4_data_reg_10_ ( .D(n1634), .CK(ACLK), .RN(ARESETB), .QN(n2748)
         );
  DFFRX1 ras_4_data_reg_9_ ( .D(n1635), .CK(ACLK), .RN(ARESETB), .QN(n2759) );
  DFFRX1 ras_4_data_reg_8_ ( .D(n1636), .CK(ACLK), .RN(ARESETB), .QN(n2760) );
  DFFRX1 ras_4_data_reg_7_ ( .D(n1637), .CK(ACLK), .RN(ARESETB), .QN(n2749) );
  DFFRX1 ras_4_data_reg_6_ ( .D(n1638), .CK(ACLK), .RN(ARESETB), .QN(n2750) );
  DFFRX1 ras_4_data_reg_5_ ( .D(n1639), .CK(ACLK), .RN(ARESETB), .QN(n2751) );
  DFFRX1 ras_4_data_reg_4_ ( .D(n1640), .CK(ACLK), .RN(ARESETB), .QN(n2752) );
  DFFRX1 ras_4_data_reg_3_ ( .D(n1641), .CK(ACLK), .RN(ARESETB), .QN(n2763) );
  DFFRX1 ras_4_data_reg_2_ ( .D(n1642), .CK(ACLK), .RN(ARESETB), .QN(n2761) );
  DFFRX1 ras_4_data_reg_1_ ( .D(n1643), .CK(ACLK), .RN(ARESETB), .QN(n2753) );
  DFFRX1 ras_4_data_reg_0_ ( .D(n1644), .CK(ACLK), .RN(ARESETB), .QN(n2754) );
  DFFRX1 ras_5_data_reg_19_ ( .D(n1645), .CK(ACLK), .RN(ARESETB), .QN(n2786)
         );
  DFFRX1 ras_5_data_reg_18_ ( .D(n1646), .CK(ACLK), .RN(ARESETB), .QN(n2798)
         );
  DFFRX1 ras_5_data_reg_17_ ( .D(n1647), .CK(ACLK), .RN(ARESETB), .QN(n2787)
         );
  DFFRX1 ras_5_data_reg_16_ ( .D(n1648), .CK(ACLK), .RN(ARESETB), .QN(n2788)
         );
  DFFRX1 ras_5_data_reg_15_ ( .D(n1649), .CK(ACLK), .RN(ARESETB), .QN(n2799)
         );
  DFFRX1 ras_5_data_reg_14_ ( .D(n1650), .CK(ACLK), .RN(ARESETB), .QN(n2800)
         );
  DFFRX1 ras_5_data_reg_13_ ( .D(n1651), .CK(ACLK), .RN(ARESETB), .QN(n2789)
         );
  DFFRX1 ras_5_data_reg_12_ ( .D(n1652), .CK(ACLK), .RN(ARESETB), .QN(n2801)
         );
  DFFRX1 ras_5_data_reg_11_ ( .D(n1653), .CK(ACLK), .RN(ARESETB), .QN(n2790)
         );
  DFFRX1 ras_5_data_reg_10_ ( .D(n1654), .CK(ACLK), .RN(ARESETB), .QN(n2791)
         );
  DFFRX1 ras_5_data_reg_9_ ( .D(n1655), .CK(ACLK), .RN(ARESETB), .QN(n2802) );
  DFFRX1 ras_5_data_reg_8_ ( .D(n1656), .CK(ACLK), .RN(ARESETB), .QN(n2803) );
  DFFRX1 ras_5_data_reg_7_ ( .D(n1657), .CK(ACLK), .RN(ARESETB), .QN(n2792) );
  DFFRX1 ras_5_data_reg_6_ ( .D(n1658), .CK(ACLK), .RN(ARESETB), .QN(n2793) );
  DFFRX1 ras_5_data_reg_5_ ( .D(n1659), .CK(ACLK), .RN(ARESETB), .QN(n2794) );
  DFFRX1 ras_5_data_reg_4_ ( .D(n1660), .CK(ACLK), .RN(ARESETB), .QN(n2795) );
  DFFRX1 ras_5_data_reg_3_ ( .D(n1661), .CK(ACLK), .RN(ARESETB), .QN(n2825) );
  DFFRX1 ras_5_data_reg_2_ ( .D(n1662), .CK(ACLK), .RN(ARESETB), .QN(n2804) );
  DFFRX1 ras_5_data_reg_1_ ( .D(n1663), .CK(ACLK), .RN(ARESETB), .QN(n2796) );
  DFFRX1 ras_5_data_reg_0_ ( .D(n1664), .CK(ACLK), .RN(ARESETB), .QN(n2797) );
  DFFRX1 ras_6_data_reg_19_ ( .D(n1665), .CK(ACLK), .RN(ARESETB), .QN(n2764)
         );
  DFFRX1 ras_6_data_reg_18_ ( .D(n1666), .CK(ACLK), .RN(ARESETB), .QN(n2776)
         );
  DFFRX1 ras_6_data_reg_17_ ( .D(n1667), .CK(ACLK), .RN(ARESETB), .QN(n2765)
         );
  DFFRX1 ras_6_data_reg_16_ ( .D(n1668), .CK(ACLK), .RN(ARESETB), .QN(n2766)
         );
  DFFRX1 ras_6_data_reg_15_ ( .D(n1669), .CK(ACLK), .RN(ARESETB), .QN(n2777)
         );
  DFFRX1 ras_6_data_reg_14_ ( .D(n1670), .CK(ACLK), .RN(ARESETB), .QN(n2778)
         );
  DFFRX1 ras_6_data_reg_13_ ( .D(n1671), .CK(ACLK), .RN(ARESETB), .QN(n2767)
         );
  DFFRX1 ras_6_data_reg_12_ ( .D(n1672), .CK(ACLK), .RN(ARESETB), .QN(n2779)
         );
  DFFRX1 ras_6_data_reg_11_ ( .D(n1673), .CK(ACLK), .RN(ARESETB), .QN(n2768)
         );
  DFFRX1 ras_6_data_reg_10_ ( .D(n1674), .CK(ACLK), .RN(ARESETB), .QN(n2769)
         );
  DFFRX1 ras_6_data_reg_9_ ( .D(n1675), .CK(ACLK), .RN(ARESETB), .QN(n2780) );
  DFFRX1 ras_6_data_reg_8_ ( .D(n1676), .CK(ACLK), .RN(ARESETB), .QN(n2781) );
  DFFRX1 ras_6_data_reg_7_ ( .D(n1677), .CK(ACLK), .RN(ARESETB), .QN(n2770) );
  DFFRX1 ras_6_data_reg_6_ ( .D(n1678), .CK(ACLK), .RN(ARESETB), .QN(n2771) );
  DFFRX1 ras_6_data_reg_5_ ( .D(n1679), .CK(ACLK), .RN(ARESETB), .QN(n2772) );
  DFFRX1 ras_6_data_reg_4_ ( .D(n1680), .CK(ACLK), .RN(ARESETB), .QN(n2773) );
  DFFRX1 ras_6_data_reg_3_ ( .D(n1681), .CK(ACLK), .RN(ARESETB), .QN(n2782) );
  DFFRX1 ras_6_data_reg_2_ ( .D(n1682), .CK(ACLK), .RN(ARESETB), .QN(n2783) );
  DFFRX1 ras_6_data_reg_1_ ( .D(n1683), .CK(ACLK), .RN(ARESETB), .QN(n2774) );
  DFFRX1 ras_6_data_reg_0_ ( .D(n1684), .CK(ACLK), .RN(ARESETB), .QN(n2775) );
  DFFRX1 RAS_FULL_reg ( .D(RAS_FULL486), .CK(ACLK), .RN(ARESETB), .Q(RAS_FULL)
         );
  OAI31X1 U2856 ( .A0(n2713), .A1(ras_cnt_1_), .A2(ras_cnt_0_), .B0(n2714), 
        .Y(n2710) );
  AO22X1 U2857 ( .A0(n2667), .A1(BA_RA[10]), .B0(B2_LAST_RA[10]), .B1(n2668), 
        .Y(n1520) );
  AO22X1 U2858 ( .A0(n2671), .A1(BA_RA[10]), .B0(B1_LAST_RA[10]), .B1(n2672), 
        .Y(n1506) );
  AO22X1 U2859 ( .A0(n2675), .A1(BA_RA[10]), .B0(B0_LAST_RA[10]), .B1(n2676), 
        .Y(n1492) );
  AO22X1 U2860 ( .A0(n2662), .A1(BA_RA[10]), .B0(B3_LAST_RA[10]), .B1(n2663), 
        .Y(n1534) );
  AO22X1 U2861 ( .A0(BA_RA[10]), .A1(n2458), .B0(ras_7_data[15]), .B1(n2459), 
        .Y(n1689) );
  INVX1 U2862 ( .A(n2696), .Y(n2692) );
  NOR3BX1 U2863 ( .AN(n2715), .B(CMD[2]), .C(CMD[0]), .Y(n2714) );
  AO22X1 U2864 ( .A0(n2662), .A1(BA_RA[12]), .B0(B3_LAST_RA[12]), .B1(n2663), 
        .Y(n1532) );
  AO22X1 U2865 ( .A0(n2675), .A1(BA_RA[12]), .B0(B0_LAST_RA[12]), .B1(n2676), 
        .Y(n1490) );
  AO22X1 U2866 ( .A0(n2667), .A1(BA_RA[12]), .B0(B2_LAST_RA[12]), .B1(n2668), 
        .Y(n1518) );
  AO22X1 U2867 ( .A0(n2671), .A1(BA_RA[12]), .B0(B1_LAST_RA[12]), .B1(n2672), 
        .Y(n1504) );
  AO22X1 U2868 ( .A0(BA_RA[12]), .A1(n2458), .B0(ras_7_data[17]), .B1(n2459), 
        .Y(n1687) );
  NAND2BX1 U2869 ( .AN(n2463), .B(n2464), .Y(n2462) );
  NAND3BX1 U2870 ( .AN(n2530), .B(n2529), .C(n2871), .Y(n2634) );
  NAND3BX1 U2871 ( .AN(n2530), .B(n2529), .C(n2464), .Y(n2533) );
  NAND3BX1 U2872 ( .AN(n2529), .B(n2530), .C(n2871), .Y(n2610) );
  AO22X1 U2873 ( .A0(BA_BA[0]), .A1(n2458), .B0(ras_7_data[18]), .B1(n2459), 
        .Y(n1686) );
  AO22X1 U2874 ( .A0(BA_BA[1]), .A1(n2458), .B0(ras_7_data[19]), .B1(n2459), 
        .Y(n1685) );
  NAND3BX1 U2875 ( .AN(BA_BA[0]), .B(BA_REQ), .C(BA_BA[1]), .Y(n2669) );
  NAND3BX1 U2876 ( .AN(n2666), .B(BA_BA[0]), .C(BA_BA[1]), .Y(n2664) );
  NAND3BX1 U2877 ( .AN(BA_BA[1]), .B(n2523), .C(BA_REQ), .Y(n2677) );
  NAND3BX1 U2878 ( .AN(BA_BA[1]), .B(BA_REQ), .C(BA_BA[0]), .Y(n2673) );
endmodule


module SDRCas ( ARESETB, ACLK, BA_BA, BA_RA, BA_CA, BA_TT, BA_ID, BA_RW, 
        BA_REQ, BA_PM, CMD, B0_LAST_RA, B1_LAST_RA, B2_LAST_RA, B3_LAST_RA, 
        CAS_0_BA, CAS_0_RA, CAS_0_CA, CAS_0_TT, CAS_0_ID, CAS_0_RW, CAS_0_PM, 
        CAS_0_FINAL, CAS_0_NEWROW, CAS_EMPTY, CAS_FULL );
  input [1:0] BA_BA;
  input [12:0] BA_RA;
  input [10:0] BA_CA;
  input [4:0] BA_TT;
  input [3:0] BA_ID;
  input [5:0] CMD;
  input [13:0] B0_LAST_RA;
  input [13:0] B1_LAST_RA;
  input [13:0] B2_LAST_RA;
  input [13:0] B3_LAST_RA;
  output [1:0] CAS_0_BA;
  output [12:0] CAS_0_RA;
  output [10:0] CAS_0_CA;
  output [4:0] CAS_0_TT;
  output [3:0] CAS_0_ID;
  input ARESETB, ACLK, BA_RW, BA_REQ, BA_PM;
  output CAS_0_RW, CAS_0_PM, CAS_0_FINAL, CAS_0_NEWROW, CAS_EMPTY, CAS_FULL;
  wire   cas_1_final, cas_2_final, cas_3_final, cas_4_newrow, cas_5_final,
         cas_5_newrow, cas_6_final, n181_3_, n181_2_, n181_1_, n181_0_,
         n429_4_, n429_3_, n429_2_, n429_1_, n429_0_, CAS_EMPTY914,
         CAS_FULL922, cas_cnt_4_, cas_cnt_3_, cas_cnt_2_, cas_cnt_1_,
         cas_cnt_0_, cas_cnt_b0_pos_3_, cas_cnt_b0_pos_2_, cas_cnt_b0_pos_1_,
         cas_cnt_b0_pos_0_, cas_cnt_b1_pos_3_, cas_cnt_b1_pos_2_,
         cas_cnt_b1_pos_1_, cas_cnt_b1_pos_0_, cas_cnt_b2_pos_4_,
         cas_cnt_b2_pos_3_, cas_cnt_b2_pos_2_, cas_cnt_b2_pos_1_,
         cas_cnt_b2_pos_0_, cas_cnt_b3_pos_3_, cas_cnt_b3_pos_2_,
         cas_cnt_b3_pos_1_, cas_cnt_b3_pos_0_, cas_cnt1375_4_, cas_cnt1375_3_,
         cas_cnt1375_2_, cas_cnt1375_1_, cas_cnt1419_3_, cas_cnt1419_2_,
         cas_cnt1419_1_, n2968, n2969, n2970, n2971, n2972, n2973, n2974,
         n2975, n2976, n2977, n2978, n2979, n2980, n2982, n2983, n2984, n2985,
         n2987, n2988, n2989, n2990, n2991, n2992, n2993, n2994, n2995, n2996,
         n2997, n2998, n2999, n3000, n3001, n3002, n3003, n3004, n3005, n3006,
         n3007, n3008, n3009, n3010, n3011, n3012, n3013, n3014, n3015, n3016,
         n3017, n3018, n3019, n3020, n3021, n3022, n3023, n3024, n3025, n3026,
         n3027, n3028, n3029, n3030, n3031, n3032, n3033, n3034, n3035, n3036,
         n3037, n3038, n3039, n3040, n3041, n3042, n3043, n3044, n3045, n3046,
         n3047, n3048, n3049, n3050, n3051, n3052, n3053, n3054, n3055, n3056,
         n3057, n3058, n3059, n3060, n3061, n3062, n3063, n3064, n3065, n3066,
         n3067, n3068, n3069, n3070, n3071, n3072, n3073, n3074, n3075, n3076,
         n3077, n3078, n3079, n3080, n3081, n3082, n3083, n3084, n3085, n3086,
         n3087, n3088, n3089, n3090, n3091, n3092, n3093, n3094, n3095, n3096,
         n3097, n3098, n3099, n3100, n3101, n3102, n3103, n3104, n3105, n3106,
         n3107, n3108, n3109, n3110, n3111, n3112, n3113, n3114, n3115, n3116,
         n3117, n3118, n3119, n3120, n3121, n3122, n3123, n3124, n3125, n3126,
         n3127, n3128, n3129, n3130, n3131, n3132, n3133, n3134, n3135, n3136,
         n3137, n3138, n3139, n3140, n3141, n3142, n3143, n3144, n3145, n3146,
         n3147, n3148, n3149, n3150, n3151, n3152, n3153, n3154, n3155, n3156,
         n3157, n3158, n3159, n3160, n3161, n3162, n3163, n3164, n3165, n3166,
         n3167, n3168, n3169, n3170, n3171, n3172, n3173, n3174, n3175, n3176,
         n3177, n3178, n3179, n3180, n3181, n3182, n3183, n3184, n3185, n3186,
         n3187, n3188, n3189, n3190, n3191, n3192, n3193, n3194, n3195, n3196,
         n3197, n3198, n3199, n3200, n3201, n3202, n3203, n3204, n3205, n3206,
         n3207, n3208, n3209, n3210, n3211, n3212, n3213, n3214, n3215, n3216,
         n3217, n3218, n3219, n3220, n3221, n3222, n3223, n3224, n3225, n3226,
         n3227, n3228, n3229, n3230, n3231, n3232, n3233, n3234, n3235, n3236,
         n3237, n3238, n3239, n3240, n3241, n3242, n3243, n3244, n3245, n3246,
         n3247, n3248, n3249, n3250, n3251, n3252, n3253, n3254, n3255, n3256,
         n3257, n3258, n3259, n3260, n3261, n3262, n3263, n3264, n3265, n3266,
         n3267, n3268, n3269, n3270, n3271, n3272, n3273, n3274, n3275, n3276,
         n3277, n3278, n3279, n3280, n3281, n3282, n3283, n3284, n3285, n3286,
         n3287, n3288, n3289, n3290, n3291, n3292, n3293, n3294, n3295, n3296,
         n3297, n3298, n3299, n3300, n3301, n3302, n3303, n3304, n3305, n3306,
         n3307, n3308, n3309, n3310, n3311, n3312, n3313, n3314, n3315, n3316,
         n3317, n3318, n3319, n3320, n3321, n3322, n3323, n3324, n3325, n3326,
         n3327, n3328, n3329, n3330, n3331, n3332, n3333, n3334, n3335, n3336,
         n3337, n3338, carry, carry0, carry1, carry2, n1, n2, n3, carry3,
         carry4, carry5, carry6, carry7, carry8, carry_3_, carry_2_, n5016,
         n5017, n5018, n5019, n5021, n5022, n5023, n5025, n5026, n5027, n5028,
         n5030, n5031, n5032, n5033, n5034, n5035, n5037, n5038, n5040, n5042,
         n5045, n5048, n5051, n5054, n5057, n5060, n5063, n5066, n5069, n5072,
         n5075, n5078, n5081, n5084, n5087, n5090, n5093, n5096, n5099, n5102,
         n5105, n5108, n5111, n5114, n5117, n5120, n5123, n5126, n5129, n5135,
         n5138, n5141, n5144, n5147, n5149, n5150, n5151, n5152, n5153, n5154,
         n5156, n5157, n5158, n5159, n5160, n5161, n5162, n5163, n5164, n5165,
         n5167, n5168, n5169, n5170, n5172, n5208, n5210, n5211, n5212, n5214,
         n5215, n5216, n5217, n5218, n5220, n5221, n5222, n5223, n5224, n5226,
         n5227, n5228, n5229, n5230, n5232, n5233, n5270, n5271, n5272, n5273,
         n5274, n5275, n5276, n5279, n5280, n5281, n5282, n5283, n5284, n5285,
         n5286, n5287, n5289, n5290, n5327, n5328, n5330, n5331, n5333, n5334,
         n5335, n5337, n5338, n5339, n5340, n5341, n5343, n5379, n5384, n5385,
         n5387, n5388, n5389, n5391, n5392, n5393, n5394, n5395, n5396, n5398,
         n5434, n5437, n5438, n5439, n5440, n5441, n5442, n5443, n5444, n5445,
         n5446, n5447, n5449, n5451, n5452, n5453, n5454, n5455, n5456, n5458,
         n5460, n5461, n5463, n5467, n5468, n5471, n5476, n5477, n5478, n5479,
         n5481, n5482, n5483, n5484, n5485, n5486, n5487, n5488, n5489, n5490,
         n5491, n5492, n5494, n5496, n5497, n5498, n5499, n5501, n5503, n5504,
         n5507, n5509, n5510, n5512, n5513, n5515, n5518, n5519, n5520, n5521,
         n5522, n5523, n5524, n5525, n5526, n5527, n5528, n5529, n5530, n5531,
         n5532, n5533, n5534, n5535, n5536, n5537, n5538, n5539, n5540, n5541,
         n5542, n5543, n5544, n5545, n5546, n5547, n5548, n5550, n5554, n5557,
         n5558, n5559, n5560, n5561, n5562, n5563, n5564, n5566, n5570, n5573,
         n5574, n5575, n5576, n5577, n5578, n5579, n5580, n5581, n5582, n5583,
         n5584, n5585, n5586, n5589, n5594, n5600, n5601, n5602, n5605, n5608,
         n5609, n5610, n5611, n5612, n5613, n5614, n5615, n5616, n5617, n5618,
         n5619, n5620, n5623, n5624, n5625, n5629, n5630, n5631, n5632, n5633,
         n5634, n5635, n5637, n5638, n5639, n5642, n5643, n5644, n5645, n5646,
         n5648, n5650, n5651, n5652, n5653, n5654, n5657, n5658, n5659, n5661,
         n5662, n5665, n5666, n5668, n5669, n5670, n5671, n5673, n5675, n5676,
         n5677, n5678, n5679, n5680, n5681, n5682, n5683, n5684, n5685, n5686,
         n5687, n5688, n5689, n5690, n5691, n5692, n5693, n5694, n5695, n5696,
         n5697, n5698, n5699, n5700, n5701, n5702, n5703, n5704, n5705, n5706,
         n5707, n5708, n5709, n5710, n5711, n5712, n5713, n5714, n5715, n5716,
         n5717, n5718, n5719, n5720, n5721, n5722, n5723, n5724, n5725, n5726,
         n5727, n5728, n5729, n5730, n5731, n5732, n5733, n5734, n5735, n5736,
         n5737, n5738, n5739, n5740, n5741, n5742, n5743, n5744, n5745, n5746,
         n5747, n5748, n5749, n5750, n5751, n5752, n5753, n5754, n5755, n5756,
         n5757, n5758, n5759, n5760, n5761, n5762, n5763, n5764, n5765, n5766,
         n5767, n5768, n5769, n5770, n5771, n5772, n5773, n5774, n5775, n5776,
         n5777, n5778, n5779, n5780, n5781, n5782, n5783, n5784, n5785, n5786,
         n5787, n5788, n5789, n5790, n5791, n5792, n5793, n5794, n5795, n5796,
         n5797, n5798, n5799, n5800, n5801, n5802, n5803, n5804, n5805, n5806,
         n5807, n5808, n5809, n5810, n5811, n5812, n5813, n5814, n5815, n5816,
         n5817, n5818, n5819, n5820, n5821, n5822, n5823, n5824, n5825, n5826,
         n5827, n5828, n5829, n5830, n5831, n5832, n5833, n5834, n5835, n5836,
         n5837, n5838, n5839, n5840, n5841, n5842, n5843, n5844, n5845, n5846,
         n5847, n5848, n5849, n5850, n5851, n5852, n5853, n5854, n5855, n5856,
         n5857, n5858, n5859, n5860, n5861, n5862, n5863, n5864, n5865, n5866,
         n5867, n5868, n5869, n5870, n5871, n5872, n5873, n5874, n5875, n5876,
         n5877, n5878, n5879, n5880, n5881, n5882, n5883, n5884, n5885, n5886,
         n5887, n5888, n5889, n5890, n5891, n5892, n5893, n5894, n5895, n5896,
         n5897, n5898, n5899, n5900, n5901, n5902, n5903, n5904, n5905, n5906,
         n5907, n5908, n5909, n5910, n5911, n5912, n5913, n5914, n5915, n5916,
         n5917, n5918, n5919, n5920, n5921, n5922, n5923, n5924, n5925, n5926,
         n5927, n5928, n5929, n5930, n5931, n5932, n5933, n5934, n5935, n5936,
         n5937, n5938, n5939, n5940, n5941, n5942, n5943, n5944, n5945, n5946,
         n5947, n5948, n5949, n5950, n5951, n5952, n5953, n5954, n5955, n5956,
         n5957, n5958, n5959, n5960, n5961, n5962, n5963, n5964, n5965, n5966,
         n5967, n5968, n5969, n5970, n5971, n5972, n5973, n5974, n5975, n5976,
         n5977, n5978, n5979, n5980, n5981, n5982, n5983, n5984, n5985, n5986,
         n5987, n5988, n5989, n5990, n5991, n5992, n5993, n5994, n5995, n5996,
         n5997, n5998, n5999, n6000, n6001, n6002, n6003, n6004, n6005, n6006,
         n6007, n6008, n6009, n6010, n6011, n6012, n6013, n6014, n6015, n6016,
         n6017, n6018, n6019, n6020, n6021, n6022, n6023, n6024, n6025, n6026,
         n6027, n6028, n6029, n6030, n6031, n6032, n6033, n6034, n6035, n6036,
         n6037, n6038, n6039, n6040, n6041, n6042, n6043, n6044, n6045, n6046,
         n6047, n6048, n6049, n6050, n6051, n6052, n6053, n6054, n6055, n6056,
         n6057, n6058, n6059, n6060, n6061, n6062, n6063, n6064, n6065, n6066,
         n6067, n6068, n6069, n6070, n6071, n6072, n6073, n6074, n6075, n6076,
         n6077, n6078, n6079, n6080, n6081, n6082, n6083, n6084, n6085, n6086,
         n6087, n6088, n6089, n6090, n6091, n6092, n6093, n6094, n6095, n6096,
         n6097, n6098, n6099, n6100, n6101, n6102, n6103, n6104, n6105, n6106,
         n6107, n6108, n6109, n6110, n6111, n6112, n6113, n6114, n6115, n6116,
         n6117, n6118, n6119, n6120, n6121;
  wire   [36:0] cas_7_data;

  AHHCONX2 U1_1_1 ( .A(n181_1_), .CI(n181_0_), .S(cas_cnt1419_1_), .CON(n3) );
  AHHCONX2 U1_1_2 ( .A(n181_2_), .CI(carry2), .S(cas_cnt1419_2_), .CON(n2) );
  AHHCONX2 U1_1_3 ( .A(n181_3_), .CI(carry1), .S(cas_cnt1419_3_), .CON(n1) );
  NAND2BX4 U5136 ( .AN(n181_2_), .B(n5612), .Y(n5328) );
  INVX3 U5322 ( .A(BA_RA[12]), .Y(n5129) );
  NAND2BX4 U5323 ( .AN(CMD[1]), .B(n5676), .Y(n5675) );
  OAI222X1 U5324 ( .A0(n5218), .A1(n5909), .B0(n5096), .B1(n6105), .C0(n5733), 
        .C1(n5223), .Y(n3237) );
  OAI222X1 U5325 ( .A0(n5218), .A1(n5772), .B0(n5108), .B1(n6072), .C0(n5892), 
        .C1(n5716), .Y(n3233) );
  BUFX4 U5326 ( .A(n5385), .Y(n5679) );
  NAND2BX4 U5327 ( .AN(n5228), .B(n6107), .Y(n5716) );
  NAND2BX2 U5328 ( .AN(n5228), .B(n6107), .Y(n6108) );
  NAND2BX4 U5329 ( .AN(n6014), .B(n6105), .Y(n6107) );
  NAND2BX1 U5330 ( .AN(n5151), .B(n6022), .Y(n6092) );
  OA22X2 U5331 ( .A0(n6101), .A1(n5856), .B0(n6007), .B1(n6103), .Y(n5275) );
  NAND2BX2 U5332 ( .AN(n5284), .B(n5276), .Y(n6103) );
  INVX1 U5333 ( .A(n5208), .Y(n5680) );
  INVX1 U5334 ( .A(n5680), .Y(n5681) );
  INVX1 U5335 ( .A(n5680), .Y(n5682) );
  INVX3 U5336 ( .A(n6075), .Y(n5683) );
  INVX3 U5337 ( .A(n5683), .Y(n5684) );
  INVX3 U5338 ( .A(n5683), .Y(n5685) );
  INVX1 U5339 ( .A(n5683), .Y(n5686) );
  INVX1 U5340 ( .A(n5683), .Y(n5687) );
  INVX1 U5341 ( .A(n5683), .Y(n5688) );
  INVX1 U5342 ( .A(n5168), .Y(n5689) );
  INVX1 U5343 ( .A(n5689), .Y(n5690) );
  INVX1 U5344 ( .A(n5689), .Y(n5691) );
  INVX1 U5345 ( .A(n5689), .Y(n5692) );
  INVX1 U5346 ( .A(n5689), .Y(n5693) );
  INVX1 U5347 ( .A(n5689), .Y(n5694) );
  INVX1 U5348 ( .A(n6110), .Y(n5695) );
  INVX1 U5349 ( .A(n5695), .Y(n5696) );
  INVX1 U5350 ( .A(n5695), .Y(n5697) );
  INVX1 U5351 ( .A(n5695), .Y(n5698) );
  INVX1 U5352 ( .A(n5695), .Y(n5699) );
  INVX1 U5353 ( .A(n5695), .Y(n5700) );
  INVX1 U5354 ( .A(n6074), .Y(n5701) );
  INVX1 U5355 ( .A(n5701), .Y(n5702) );
  INVX1 U5356 ( .A(n5701), .Y(n5703) );
  INVX1 U5357 ( .A(n5701), .Y(n5704) );
  INVX1 U5358 ( .A(n5701), .Y(n5705) );
  INVX1 U5359 ( .A(n5701), .Y(n5706) );
  INVX1 U5360 ( .A(n6111), .Y(n5707) );
  INVX1 U5361 ( .A(n5707), .Y(n5708) );
  INVX1 U5362 ( .A(n5707), .Y(n5709) );
  INVX1 U5363 ( .A(n5707), .Y(n5710) );
  INVX1 U5364 ( .A(n5707), .Y(n5711) );
  INVX1 U5365 ( .A(n5707), .Y(n5712) );
  NAND2BX2 U5366 ( .AN(n5151), .B(n5210), .Y(n6075) );
  NAND2BX1 U5367 ( .AN(n5151), .B(n5210), .Y(n5168) );
  BUFX4 U5368 ( .A(n6088), .Y(n5713) );
  NAND2BX4 U5369 ( .AN(n6014), .B(n6099), .Y(n6101) );
  NAND2BX4 U5370 ( .AN(n6014), .B(n5037), .Y(n6118) );
  NAND2BX2 U5371 ( .AN(n5151), .B(n5025), .Y(n5037) );
  NAND2BX1 U5372 ( .AN(n6014), .B(n5392), .Y(n5714) );
  NAND2BX1 U5373 ( .AN(n6014), .B(n5392), .Y(n5715) );
  NAND2BX2 U5374 ( .AN(n5284), .B(n6100), .Y(n6102) );
  OAI222X4 U5375 ( .A0(n6100), .A1(n5906), .B0(n5051), .B1(n6099), .C0(n5802), 
        .C1(n6102), .Y(n3213) );
  OAI222X4 U5376 ( .A0(n6100), .A1(n5902), .B0(n5117), .B1(n5289), .C0(n5795), 
        .C1(n6102), .Y(n3191) );
  OAI222X4 U5377 ( .A0(n6100), .A1(n5904), .B0(n5078), .B1(n6099), .C0(n5799), 
        .C1(n6102), .Y(n3204) );
  NAND2BX2 U5378 ( .AN(n6014), .B(n5289), .Y(n6100) );
  NAND2BX2 U5379 ( .AN(n5151), .B(n5611), .Y(n6080) );
  NAND2BX4 U5380 ( .AN(n6014), .B(n6093), .Y(n6094) );
  NAND2BX4 U5381 ( .AN(n6014), .B(n6081), .Y(n6083) );
  INVX2 U5382 ( .A(n5150), .Y(n6014) );
  OA22X2 U5383 ( .A0(n6119), .A1(n6020), .B0(n5855), .B1(n6121), .Y(n5027) );
  OAI222X4 U5384 ( .A0(n6119), .A1(n5808), .B0(n5096), .B1(n6077), .C0(n6121), 
        .C1(n5974), .Y(n3315) );
  NAND2BX4 U5385 ( .AN(n6014), .B(n6117), .Y(n6119) );
  NAND2BX4 U5386 ( .AN(n5228), .B(n5218), .Y(n5223) );
  NAND2BX2 U5387 ( .AN(n6014), .B(n6073), .Y(n5218) );
  NAND2BX4 U5388 ( .AN(n5682), .B(n6113), .Y(n5163) );
  NAND2BX4 U5389 ( .AN(n6014), .B(n5684), .Y(n6113) );
  NAND2BX4 U5390 ( .AN(n5681), .B(n6112), .Y(n6114) );
  OAI222X4 U5391 ( .A0(n6112), .A1(n5890), .B0(n6012), .B1(n5687), .C0(n5821), 
        .C1(n6114), .Y(n3264) );
  OAI222X4 U5392 ( .A0(n6112), .A1(n5891), .B0(n5117), .B1(n5691), .C0(n5807), 
        .C1(n6114), .Y(n3269) );
  OAI222X4 U5393 ( .A0(n6112), .A1(n5894), .B0(n5078), .B1(n5688), .C0(n5814), 
        .C1(n6114), .Y(n3282) );
  NAND2BX4 U5394 ( .AN(n6014), .B(n5685), .Y(n6112) );
  NAND2BX4 U5395 ( .AN(n6014), .B(n5610), .Y(n6082) );
  NAND2BX4 U5396 ( .AN(n5151), .B(n5611), .Y(n5610) );
  OA22X1 U5397 ( .A0(n5463), .A1(n6050), .B0(n5463), .B1(n6057), .Y(n5594) );
  NAND2BX2 U5398 ( .AN(n181_0_), .B(n181_1_), .Y(n5153) );
  OR4X6 U5399 ( .A(CMD[5]), .B(CMD[3]), .C(CMD[2]), .D(n5675), .Y(n5150) );
  OAI33X1 U5400 ( .A0(n5485), .A1(B3_LAST_RA[0]), .A2(n5461), .B0(n5512), .B1(
        n6013), .B2(n5513), .Y(n5482) );
  INVX1 U5401 ( .A(n5271), .Y(n5212) );
  INVX3 U5402 ( .A(n5442), .Y(n5611) );
  OR4X2 U5403 ( .A(n5529), .B(n5530), .C(n5531), .D(n5532), .Y(n5485) );
  INVX1 U5404 ( .A(n5617), .Y(n181_3_) );
  INVX1 U5405 ( .A(n5216), .Y(n5270) );
  INVX1 U5406 ( .A(n5396), .Y(n5286) );
  INVX1 U5407 ( .A(n5287), .Y(n5341) );
  OA22X1 U5408 ( .A0(n5747), .A1(n5449), .B0(n6055), .B1(n5449), .Y(n5605) );
  INVX1 U5409 ( .A(n5158), .Y(n5210) );
  OR2X2 U5410 ( .A(n6010), .B(n6011), .Y(n5437) );
  INVX3 U5411 ( .A(n5211), .Y(n181_0_) );
  NAND2BX2 U5412 ( .AN(n5151), .B(n6017), .Y(n5392) );
  NAND2BX1 U5413 ( .AN(n5151), .B(n5270), .Y(n6073) );
  NAND2BX1 U5414 ( .AN(n5151), .B(n5210), .Y(n6110) );
  NAND2BX1 U5415 ( .AN(n5162), .B(n5022), .Y(n5169) );
  INVX1 U5416 ( .A(n5016), .Y(n5159) );
  OAI222X1 U5417 ( .A0(n5958), .A1(n5290), .B0(n5129), .B1(n6098), .C0(n6101), 
        .C1(n5850), .Y(n3187) );
  OAI222X1 U5418 ( .A0(n5959), .A1(n5290), .B0(n5042), .B1(n6099), .C0(n6101), 
        .C1(n5853), .Y(n3216) );
  OAI222X1 U5419 ( .A0(n6119), .A1(n5846), .B0(n5135), .B1(n6116), .C0(n6121), 
        .C1(n5999), .Y(n3302) );
  OAI222X1 U5420 ( .A0(n5040), .A1(n6005), .B0(n5129), .B1(n6117), .C0(n6119), 
        .C1(n5849), .Y(n3304) );
  OAI222X1 U5421 ( .A0(n6119), .A1(n5844), .B0(n5120), .B1(n6117), .C0(n6121), 
        .C1(n6003), .Y(n3307) );
  OAI222X1 U5422 ( .A0(n6119), .A1(n5847), .B0(n5108), .B1(n6116), .C0(n6121), 
        .C1(n6000), .Y(n3311) );
  OAI222X1 U5423 ( .A0(n5040), .A1(n6006), .B0(n5105), .B1(n6117), .C0(n6119), 
        .C1(n5851), .Y(n3312) );
  OAI222X1 U5424 ( .A0(n6119), .A1(n5845), .B0(n6116), .B1(n5084), .C0(n6121), 
        .C1(n6002), .Y(n3319) );
  OAI222X1 U5425 ( .A0(n5040), .A1(n6004), .B0(n6076), .B1(n5072), .C0(n6119), 
        .C1(n5852), .Y(n3323) );
  OAI222X1 U5426 ( .A0(n6119), .A1(n5848), .B0(n6117), .B1(n5069), .C0(n6121), 
        .C1(n6001), .Y(n3324) );
  DFFRX1 CAS_0_RA_reg_11_ ( .D(n3067), .CK(ACLK), .RN(ARESETB), .Q(
        CAS_0_RA[11]), .QN(n2990) );
  DFFRX1 CAS_0_BA_reg_1_ ( .D(n3064), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_BA[1]), 
        .QN(n2969) );
  DFFRX1 CAS_0_BA_reg_0_ ( .D(n3065), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_BA[0]), 
        .QN(n2968) );
  DFFRX2 CAS_0_RA_reg_3_ ( .D(n3075), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_RA[3]), 
        .QN(n2994) );
  DFFSX1 CAS_EMPTY_reg ( .D(CAS_EMPTY914), .CK(ACLK), .SN(ARESETB), .Q(
        CAS_EMPTY) );
  INVX1 U5427 ( .A(n5230), .Y(n5717) );
  DFFRX2 CAS_0_RA_reg_2_ ( .D(n3076), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_RA[2]), 
        .QN(n2993) );
  INVX3 U5428 ( .A(n5150), .Y(n5149) );
  DFFRX2 CAS_0_RA_reg_12_ ( .D(n3066), .CK(ACLK), .RN(ARESETB), .Q(
        CAS_0_RA[12]), .QN(n2991) );
  AND2X1 U5429 ( .A(n5149), .B(n5646), .Y(n6008) );
  AND2X1 U5430 ( .A(n5150), .B(n5858), .Y(n6009) );
  OR2X2 U5431 ( .A(n6008), .B(n6009), .Y(n5616) );
  NAND2BX1 U5432 ( .AN(n5616), .B(n5612), .Y(n5272) );
  AND2X1 U5433 ( .A(n5149), .B(n5648), .Y(n6010) );
  AND2X1 U5434 ( .A(n5150), .B(n5859), .Y(n6011) );
  NAND3BX2 U5435 ( .AN(n5328), .B(n5437), .C(n5211), .Y(n5442) );
  INVX1 U5436 ( .A(BA_BA[0]), .Y(n6012) );
  INVX1 U5437 ( .A(n5327), .Y(n5274) );
  DFFRX1 CAS_0_RA_reg_8_ ( .D(n3070), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_RA[8]), 
        .QN(n2999) );
  DFFRX1 CAS_0_RA_reg_7_ ( .D(n3071), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_RA[7]), 
        .QN(n2998) );
  DFFRX1 CAS_0_RA_reg_5_ ( .D(n3073), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_RA[5]), 
        .QN(n2996) );
  DFFRX1 CAS_0_RA_reg_1_ ( .D(n3077), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_RA[1]), 
        .QN(n2992) );
  DFFRX1 CAS_0_RA_reg_10_ ( .D(n3068), .CK(ACLK), .RN(ARESETB), .Q(
        CAS_0_RA[10]), .QN(n2989) );
  DFFRX1 CAS_0_RA_reg_9_ ( .D(n3069), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_RA[9]), 
        .QN(n3000) );
  DFFRX1 CAS_0_RA_reg_6_ ( .D(n3072), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_RA[6]), 
        .QN(n2997) );
  INVX1 U5438 ( .A(BA_RA[10]), .Y(n5123) );
  DFFRX1 CAS_0_RA_reg_4_ ( .D(n3074), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_RA[4]), 
        .QN(n2995) );
  INVX1 U5439 ( .A(n5494), .Y(n6013) );
  NAND2BX1 U5440 ( .AN(n5284), .B(n6101), .Y(n5279) );
  INVX1 U5441 ( .A(n6092), .Y(n5379) );
  NAND2BX2 U5442 ( .AN(n5151), .B(n5274), .Y(n6099) );
  INVX1 U5443 ( .A(BA_RA[8]), .Y(n5117) );
  OA22X4 U5444 ( .A0(n5481), .A1(n5482), .B0(n5483), .B1(n5484), .Y(n6023) );
  NAND2BX4 U5445 ( .AN(n181_3_), .B(n5618), .Y(n5670) );
  OAI222X1 U5446 ( .A0(n6100), .A1(n5897), .B0(n6012), .B1(n6099), .C0(n5780), 
        .C1(n6102), .Y(n3186) );
  DFFRX1 CAS_0_RW_reg ( .D(n3099), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_RW), .QN(
        n3001) );
  NAND2BX1 U5447 ( .AN(n5035), .B(n6119), .Y(n5030) );
  INVX1 U5448 ( .A(n5328), .Y(n6018) );
  INVX1 U5449 ( .A(BA_RA[11]), .Y(n6015) );
  INVX3 U5450 ( .A(BA_RA[11]), .Y(n5126) );
  INVX1 U5451 ( .A(BA_BA[1]), .Y(n6016) );
  NAND2BX1 U5452 ( .AN(n5443), .B(n6083), .Y(n5438) );
  NAND2BX1 U5453 ( .AN(n5443), .B(n5439), .Y(n6085) );
  NAND2BX1 U5454 ( .AN(n5443), .B(n6082), .Y(n6084) );
  INVX1 U5455 ( .A(n5232), .Y(n5228) );
  NAND2BX2 U5456 ( .AN(n5151), .B(n5025), .Y(n6117) );
  INVX1 U5457 ( .A(n2), .Y(carry1) );
  INVX1 U5458 ( .A(BA_BA[1]), .Y(n5135) );
  NAND2BX1 U5459 ( .AN(n5341), .B(n5286), .Y(n5026) );
  INVX1 U5460 ( .A(n5229), .Y(n5022) );
  NAND3BX1 U5461 ( .AN(n5230), .B(n6023), .C(n5221), .Y(n5229) );
  INVX1 U5462 ( .A(n3), .Y(carry2) );
  INVX1 U5463 ( .A(n5600), .Y(n5455) );
  NAND2BX1 U5464 ( .AN(n5619), .B(n5609), .Y(n5613) );
  INVX1 U5465 ( .A(n5220), .Y(n5230) );
  NOR3X1 U5466 ( .A(n5554), .B(n6032), .C(n6033), .Y(n6031) );
  DFFRX4 CAS_0_RA_reg_0_ ( .D(n3078), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_RA[0]), 
        .QN(n2988) );
  NAND2BX4 U5467 ( .AN(n5434), .B(n5713), .Y(n6091) );
  NAND2BX1 U5468 ( .AN(n6014), .B(n6086), .Y(n6088) );
  NAND2BX1 U5469 ( .AN(n6014), .B(n6092), .Y(n6095) );
  NAND2BX1 U5470 ( .AN(n6014), .B(n5392), .Y(n6089) );
  NAND2BX1 U5471 ( .AN(n6014), .B(n6080), .Y(n5439) );
  XOR2X4 U5472 ( .A(CMD[4]), .B(CMD[0]), .Y(n5676) );
  NAND2BX1 U5473 ( .AN(n5151), .B(n6022), .Y(n5338) );
  NAND2BX1 U5474 ( .AN(n5151), .B(n5270), .Y(n5232) );
  NAND2BX1 U5475 ( .AN(BA_BA[0]), .B(BA_BA[1]), .Y(n5463) );
  NAND2BX1 U5476 ( .AN(n5286), .B(n5341), .Y(n5162) );
  NAND2BX1 U5477 ( .AN(n181_0_), .B(n5212), .Y(n5216) );
  INVX3 U5478 ( .A(n5437), .Y(n181_1_) );
  AND3X1 U5479 ( .A(n6018), .B(n5437), .C(n181_0_), .Y(n6017) );
  NAND2BX1 U5480 ( .AN(n5211), .B(n5212), .Y(n5158) );
  NAND3BX1 U5481 ( .AN(n5220), .B(n6023), .C(n5221), .Y(n5395) );
  OAI221X1 U5482 ( .A0(n5545), .A1(n5546), .B0(n5547), .B1(n5548), .C0(n5093), 
        .Y(n5481) );
  INVX1 U5483 ( .A(BA_REQ), .Y(n5151) );
  NAND2BX1 U5484 ( .AN(n5499), .B(n6025), .Y(n5513) );
  OAI2BB1X1 U5485 ( .A0N(cas_cnt1375_3_), .A1N(n5659), .B0(n6019), .Y(n429_3_)
         );
  AOI22X1 U5486 ( .A0(cas_cnt_3_), .A1(n5661), .B0(cas_cnt1419_3_), .B1(n5662), 
        .Y(n6019) );
  NAND3BX1 U5487 ( .AN(n5518), .B(n5519), .C(n5520), .Y(n5499) );
  OAI21X1 U5488 ( .A0(n6115), .A1(n6020), .B0(n5156), .Y(n3297) );
  OAI21X1 U5489 ( .A0(n6109), .A1(n6021), .B0(n5214), .Y(n3258) );
  NAND2BX1 U5490 ( .AN(n5581), .B(n5582), .Y(n5441) );
  INVX1 U5491 ( .A(n5668), .Y(n5659) );
  NAND2BX1 U5492 ( .AN(n5662), .B(n5666), .Y(n5668) );
  NAND2BX1 U5493 ( .AN(n5035), .B(n6118), .Y(n6120) );
  NAND2BX1 U5494 ( .AN(n5035), .B(n5028), .Y(n6121) );
  NAND2BX1 U5495 ( .AN(n5434), .B(n5715), .Y(n6090) );
  NAND2BX1 U5496 ( .AN(n5379), .B(n6095), .Y(n6096) );
  NAND2BX1 U5497 ( .AN(n5379), .B(n6094), .Y(n6097) );
  NAND2BX1 U5498 ( .AN(n5434), .B(n5679), .Y(n5387) );
  NAND2BX1 U5499 ( .AN(n5379), .B(n5331), .Y(n5333) );
  NAND2BX1 U5500 ( .AN(n6113), .B(n5169), .Y(n5170) );
  INVX1 U5501 ( .A(n5666), .Y(n5661) );
  INVX1 U5502 ( .A(n5439), .Y(n5445) );
  INVX1 U5503 ( .A(n5028), .Y(n5032) );
  INVX1 U5504 ( .A(n6106), .Y(n5217) );
  INVX1 U5505 ( .A(n5161), .Y(n5160) );
  INVX1 U5506 ( .A(n5169), .Y(n5167) );
  NAND2BX1 U5507 ( .AN(n6014), .B(n5232), .Y(n6106) );
  NAND2BX1 U5508 ( .AN(n6014), .B(n6071), .Y(n5276) );
  NAND2BX1 U5509 ( .AN(n6014), .B(n5690), .Y(n5161) );
  NAND2BX1 U5510 ( .AN(n6014), .B(n6077), .Y(n5028) );
  NAND2BX1 U5511 ( .AN(n6014), .B(n5665), .Y(n5666) );
  NAND2BX1 U5512 ( .AN(n1), .B(n5662), .Y(n5657) );
  NAND2BX1 U5513 ( .AN(n6014), .B(n6067), .Y(n5385) );
  NAND2BX1 U5514 ( .AN(n6014), .B(n6068), .Y(n5331) );
  NAND2BX1 U5515 ( .AN(n5150), .B(n5686), .Y(n5172) );
  NAND2BX1 U5516 ( .AN(n5150), .B(n5392), .Y(n5398) );
  NAND2BX1 U5517 ( .AN(n5150), .B(n6069), .Y(n5343) );
  NAND2BX1 U5518 ( .AN(n5150), .B(n6105), .Y(n5233) );
  NAND2BX1 U5519 ( .AN(n5150), .B(n6099), .Y(n5290) );
  NAND2BX1 U5520 ( .AN(n5150), .B(n6117), .Y(n5040) );
  INVX1 U5521 ( .A(n6079), .Y(n5019) );
  NAND2BX1 U5522 ( .AN(n6095), .B(n5339), .Y(n5340) );
  NAND2BX1 U5523 ( .AN(n5714), .B(n5393), .Y(n5394) );
  INVX1 U5524 ( .A(n5458), .Y(n5507) );
  INVX1 U5525 ( .A(n5456), .Y(n5501) );
  INVX1 U5526 ( .A(n5463), .Y(n5494) );
  NOR2X1 U5527 ( .A(n5153), .B(n5328), .Y(n6022) );
  INVX1 U5528 ( .A(n5152), .Y(n5025) );
  NAND2BX1 U5529 ( .AN(n5153), .B(n5154), .Y(n5152) );
  INVX1 U5530 ( .A(n5665), .Y(n5662) );
  INVX1 U5531 ( .A(n5289), .Y(n5284) );
  INVX1 U5532 ( .A(n6081), .Y(n5443) );
  INVX1 U5533 ( .A(n5037), .Y(n5035) );
  INVX1 U5534 ( .A(n6110), .Y(n5208) );
  INVX1 U5535 ( .A(n6086), .Y(n5434) );
  INVX1 U5536 ( .A(n5339), .Y(n5337) );
  INVX1 U5537 ( .A(n5162), .Y(n5157) );
  INVX1 U5538 ( .A(n5638), .Y(n5642) );
  INVX1 U5539 ( .A(n5632), .Y(n5634) );
  INVX1 U5540 ( .A(n5624), .Y(n5629) );
  INVX1 U5541 ( .A(n5614), .Y(n5619) );
  NAND2BX1 U5542 ( .AN(BA_BA[0]), .B(n6016), .Y(n5458) );
  NAND2BX1 U5543 ( .AN(n5151), .B(n5017), .Y(n6078) );
  NAND2BX1 U5544 ( .AN(n5151), .B(n5017), .Y(n5644) );
  NAND2BX1 U5545 ( .AN(n5151), .B(n5017), .Y(n6079) );
  NAND2BX2 U5546 ( .AN(n5151), .B(n6017), .Y(n6086) );
  NAND2BX1 U5547 ( .AN(n5151), .B(n5274), .Y(n5289) );
  NAND2BX2 U5548 ( .AN(n5151), .B(n5270), .Y(n6105) );
  NAND2BX1 U5549 ( .AN(n5151), .B(n5611), .Y(n6081) );
  NAND2BX1 U5550 ( .AN(n5151), .B(n5612), .Y(n5665) );
  NAND2BX2 U5551 ( .AN(n6012), .B(BA_BA[1]), .Y(n5461) );
  NAND2BX1 U5552 ( .AN(n5018), .B(n5285), .Y(n5283) );
  INVX1 U5553 ( .A(BA_RA[2]), .Y(n5099) );
  INVX1 U5554 ( .A(BA_RA[4]), .Y(n5105) );
  INVX1 U5555 ( .A(BA_RA[5]), .Y(n5108) );
  INVX1 U5556 ( .A(BA_RA[7]), .Y(n5114) );
  INVX1 U5557 ( .A(BA_RA[3]), .Y(n5102) );
  NAND2BX2 U5558 ( .AN(n5026), .B(n5285), .Y(n5339) );
  NAND3BX1 U5559 ( .AN(n6023), .B(n5230), .C(n5221), .Y(n5273) );
  NAND2BX1 U5560 ( .AN(n5151), .B(n6022), .Y(n6093) );
  NAND2BX1 U5561 ( .AN(n5151), .B(n5270), .Y(n6104) );
  NAND2BX1 U5562 ( .AN(n5151), .B(n5270), .Y(n6072) );
  NAND2BX1 U5563 ( .AN(n5151), .B(n5210), .Y(n6111) );
  NAND2BX1 U5564 ( .AN(n5151), .B(n6017), .Y(n6087) );
  NAND2BX1 U5565 ( .AN(n5151), .B(n5274), .Y(n6098) );
  NAND2BX1 U5566 ( .AN(n5151), .B(n5274), .Y(n6070) );
  NAND2BX1 U5567 ( .AN(n5151), .B(n6022), .Y(n6068) );
  NAND2BX1 U5568 ( .AN(n5151), .B(n5210), .Y(n6074) );
  NAND2BX1 U5569 ( .AN(n5151), .B(n6017), .Y(n6066) );
  NAND2BX1 U5570 ( .AN(n5151), .B(n5025), .Y(n6116) );
  NAND2BX1 U5571 ( .AN(n5151), .B(n5025), .Y(n6076) );
  NAND2BX1 U5572 ( .AN(n5151), .B(n6022), .Y(n6069) );
  NAND2BX1 U5573 ( .AN(n5151), .B(n6017), .Y(n6067) );
  NAND2BX1 U5574 ( .AN(n5151), .B(n5274), .Y(n6071) );
  NAND2BX1 U5575 ( .AN(n5151), .B(n5025), .Y(n6077) );
  NAND3BX1 U5576 ( .AN(n5328), .B(n181_0_), .C(n181_1_), .Y(n5327) );
  INVX1 U5577 ( .A(n5645), .Y(n5017) );
  NAND3BX1 U5578 ( .AN(n5272), .B(n181_0_), .C(n181_1_), .Y(n5645) );
  INVX1 U5579 ( .A(n5272), .Y(n5154) );
  NAND2BX1 U5580 ( .AN(n181_1_), .B(n5154), .Y(n5271) );
  INVX1 U5581 ( .A(n5222), .Y(n5215) );
  INVX1 U5582 ( .A(n429_4_), .Y(n5654) );
  INVX1 U5583 ( .A(n5478), .Y(n5454) );
  NAND2BX1 U5584 ( .AN(n5151), .B(n5494), .Y(n5624) );
  NAND2BX1 U5585 ( .AN(n5151), .B(n5507), .Y(n5638) );
  NAND2BX1 U5586 ( .AN(n5151), .B(n5501), .Y(n5632) );
  OR2X1 U5587 ( .A(n5151), .B(n5461), .Y(n5614) );
  INVX1 U5588 ( .A(BA_RA[1]), .Y(n5096) );
  INVX1 U5589 ( .A(BA_RA[9]), .Y(n5120) );
  INVX1 U5590 ( .A(BA_RA[0]), .Y(n5093) );
  NAND2BX1 U5591 ( .AN(n5629), .B(n5623), .Y(n5625) );
  NAND2BX1 U5592 ( .AN(n5642), .B(n5637), .Y(n5639) );
  NAND2BX1 U5593 ( .AN(n5634), .B(n5631), .Y(n5633) );
  NAND2BX1 U5594 ( .AN(n5619), .B(n5613), .Y(n5615) );
  INVX1 U5595 ( .A(BA_TT[4]), .Y(n5057) );
  INVX1 U5596 ( .A(BA_TT[3]), .Y(n5054) );
  INVX1 U5597 ( .A(BA_TT[2]), .Y(n5051) );
  INVX1 U5598 ( .A(BA_TT[1]), .Y(n5048) );
  INVX1 U5599 ( .A(BA_TT[0]), .Y(n5045) );
  INVX1 U5600 ( .A(BA_RA[6]), .Y(n5111) );
  INVX1 U5601 ( .A(BA_PM), .Y(n5038) );
  INVX1 U5602 ( .A(BA_CA[10]), .Y(n5090) );
  INVX1 U5603 ( .A(BA_CA[9]), .Y(n5087) );
  INVX1 U5604 ( .A(BA_CA[8]), .Y(n5084) );
  INVX1 U5605 ( .A(BA_CA[0]), .Y(n5060) );
  INVX1 U5606 ( .A(BA_CA[7]), .Y(n5081) );
  INVX1 U5607 ( .A(BA_CA[6]), .Y(n5078) );
  INVX1 U5608 ( .A(BA_CA[5]), .Y(n5075) );
  INVX1 U5609 ( .A(BA_CA[4]), .Y(n5072) );
  INVX1 U5610 ( .A(BA_CA[3]), .Y(n5069) );
  INVX1 U5611 ( .A(BA_CA[2]), .Y(n5066) );
  INVX1 U5612 ( .A(BA_CA[1]), .Y(n5063) );
  INVX1 U5613 ( .A(BA_RW), .Y(n5042) );
  DFFRX1 CAS_0_TT_reg_3_ ( .D(n3091), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_TT[3]), 
        .QN(n3005) );
  DFFRX1 CAS_0_TT_reg_2_ ( .D(n3092), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_TT[2]), 
        .QN(n3004) );
  DFFRX1 CAS_0_TT_reg_1_ ( .D(n3093), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_TT[1]), 
        .QN(n3003) );
  DFFRX1 CAS_0_TT_reg_0_ ( .D(n3094), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_TT[0]), 
        .QN(n3002) );
  NAND2BX1 U5614 ( .AN(n5396), .B(n5341), .Y(n5222) );
  NAND2BX1 U5615 ( .AN(n5286), .B(n5287), .Y(n5018) );
  NOR4BX1 U5616 ( .AN(n5652), .B(n5658), .C(n429_3_), .D(n429_2_), .Y(
        CAS_EMPTY914) );
  NAND3BX1 U5617 ( .AN(n429_0_), .B(n6040), .C(n5657), .Y(n5658) );
  NAND2X1 U5618 ( .A(n5657), .B(n6040), .Y(n429_4_) );
  NAND2BX2 U5619 ( .AN(n5458), .B(n5601), .Y(n5478) );
  INVX1 U5620 ( .A(n5616), .Y(n181_2_) );
  INVX3 U5621 ( .A(n5440), .Y(n5221) );
  NAND3BX2 U5622 ( .AN(n5441), .B(n5442), .C(BA_REQ), .Y(n5440) );
  INVX3 U5623 ( .A(n5395), .Y(n5285) );
  NAND3BX1 U5624 ( .AN(n5496), .B(n5497), .C(n5498), .Y(n5491) );
  INVX1 U5625 ( .A(n5499), .Y(n5498) );
  NAND3BX1 U5626 ( .AN(n5503), .B(n5504), .C(n6028), .Y(n5489) );
  NAND3BX1 U5627 ( .AN(n5509), .B(n5510), .C(n6031), .Y(n5487) );
  NAND3BX1 U5628 ( .AN(n5533), .B(n5534), .C(n5535), .Y(n5532) );
  NAND3BX1 U5629 ( .AN(n5542), .B(n5543), .C(n5544), .Y(n5529) );
  NAND3BX1 U5630 ( .AN(n5539), .B(n5540), .C(n5541), .Y(n5530) );
  OAI31X1 U5631 ( .A0(n5273), .A1(n6017), .A2(n5162), .B0(n5384), .Y(n3141) );
  OA22X1 U5632 ( .A0(n5679), .A1(n5854), .B0(n5998), .B1(n6091), .Y(n5384) );
  INVX3 U5633 ( .A(n5670), .Y(n5612) );
  OAI222X1 U5634 ( .A0(n6107), .A1(n5763), .B0(n5066), .B1(n6073), .C0(n5869), 
        .C1(n6108), .Y(n3247) );
  OAI222X1 U5635 ( .A0(n5735), .A1(n5233), .B0(n5054), .B1(n6073), .C0(n6107), 
        .C1(n5937), .Y(n3251) );
  OAI222X1 U5636 ( .A0(n6106), .A1(n5764), .B0(n5038), .B1(n6073), .C0(n5870), 
        .C1(n6108), .Y(n3256) );
  OAI222X1 U5637 ( .A0(n6112), .A1(n5869), .B0(n5066), .B1(n5709), .C0(n5816), 
        .C1(n6114), .Y(n3286) );
  OAI222X1 U5638 ( .A0(n5836), .A1(n5172), .B0(n5054), .B1(n5688), .C0(n6113), 
        .C1(n5735), .Y(n3290) );
  OAI222X1 U5639 ( .A0(n5161), .A1(n5870), .B0(n5038), .B1(n5690), .C0(n5822), 
        .C1(n6114), .Y(n3295) );
  OAI222X1 U5640 ( .A0(n5713), .A1(n5927), .B0(n5066), .B1(n6067), .C0(n5761), 
        .C1(n6090), .Y(n3130) );
  OAI222X1 U5641 ( .A0(n5936), .A1(n5398), .B0(n5054), .B1(n6067), .C0(n5679), 
        .C1(n5757), .Y(n3134) );
  OAI222X1 U5642 ( .A0(n5713), .A1(n5935), .B0(n5038), .B1(n6067), .C0(n5762), 
        .C1(n6090), .Y(n3139) );
  OAI222X1 U5643 ( .A0(n6094), .A1(n5761), .B0(n5066), .B1(n5338), .C0(n5871), 
        .C1(n6096), .Y(n3169) );
  OAI222X1 U5644 ( .A0(n5823), .A1(n5343), .B0(n5054), .B1(n5338), .C0(n5331), 
        .C1(n5936), .Y(n3173) );
  OAI222X1 U5645 ( .A0(n6094), .A1(n5762), .B0(n5038), .B1(n6092), .C0(n5872), 
        .C1(n6096), .Y(n3178) );
  OAI222X1 U5646 ( .A0(n6100), .A1(n5871), .B0(n5066), .B1(n6071), .C0(n5763), 
        .C1(n6102), .Y(n3208) );
  OAI222X1 U5647 ( .A0(n5937), .A1(n5290), .B0(n5054), .B1(n6071), .C0(n6101), 
        .C1(n5823), .Y(n3212) );
  OAI222X1 U5648 ( .A0(n5276), .A1(n5872), .B0(n5038), .B1(n6071), .C0(n5764), 
        .C1(n6102), .Y(n3217) );
  OAI222X1 U5649 ( .A0(n5938), .A1(n5398), .B0(n5147), .B1(n6066), .C0(n5713), 
        .C1(n5758), .Y(n3103) );
  OAI222X1 U5650 ( .A0(n5736), .A1(n5233), .B0(n5147), .B1(n6072), .C0(n5218), 
        .C1(n5943), .Y(n3220) );
  OAI222X1 U5651 ( .A0(n5737), .A1(n5233), .B0(n5138), .B1(n6072), .C0(n6107), 
        .C1(n5944), .Y(n3223) );
  OAI222X1 U5652 ( .A0(n5738), .A1(n5233), .B0(n5129), .B1(n6104), .C0(n6106), 
        .C1(n5958), .Y(n3226) );
  OAI222X1 U5653 ( .A0(n6107), .A1(n5771), .B0(n5111), .B1(n6104), .C0(n5873), 
        .C1(n5223), .Y(n3232) );
  OAI222X1 U5654 ( .A0(n6107), .A1(n5773), .B0(n5102), .B1(n6104), .C0(n5874), 
        .C1(n6108), .Y(n3235) );
  OAI222X1 U5655 ( .A0(n6107), .A1(n5774), .B0(n5093), .B1(n6104), .C0(n5875), 
        .C1(n6108), .Y(n3238) );
  OAI222X1 U5656 ( .A0(n5946), .A1(n5233), .B0(n5090), .B1(n6072), .C0(n5218), 
        .C1(n5826), .Y(n3239) );
  OAI222X1 U5657 ( .A0(n5218), .A1(n5775), .B0(n5084), .B1(n6104), .C0(n5876), 
        .C1(n6108), .Y(n3241) );
  OAI222X1 U5658 ( .A0(n5947), .A1(n5233), .B0(n5072), .B1(n6072), .C0(n6107), 
        .C1(n5827), .Y(n3245) );
  OAI222X1 U5659 ( .A0(n5739), .A1(n5233), .B0(n5063), .B1(n6104), .C0(n5218), 
        .C1(n5945), .Y(n3248) );
  OAI222X1 U5660 ( .A0(n5218), .A1(n5777), .B0(n5057), .B1(n6072), .C0(n5877), 
        .C1(n6108), .Y(n3250) );
  OAI222X1 U5661 ( .A0(n5838), .A1(n5172), .B0(n5147), .B1(n5712), .C0(n6112), 
        .C1(n5736), .Y(n3259) );
  OAI222X1 U5662 ( .A0(n5839), .A1(n5172), .B0(n5138), .B1(n5691), .C0(n5161), 
        .C1(n5737), .Y(n3262) );
  OAI222X1 U5663 ( .A0(n5849), .A1(n5172), .B0(n5129), .B1(n5703), .C0(n6113), 
        .C1(n5738), .Y(n3265) );
  OAI222X1 U5664 ( .A0(n6113), .A1(n5724), .B0(n5120), .B1(n5692), .C0(n5844), 
        .C1(n5163), .Y(n3268) );
  OAI222X1 U5665 ( .A0(n6112), .A1(n5873), .B0(n5111), .B1(n5693), .C0(n5818), 
        .C1(n5163), .Y(n3271) );
  OAI222X1 U5666 ( .A0(n6112), .A1(n5874), .B0(n5102), .B1(n5694), .C0(n5819), 
        .C1(n6114), .Y(n3274) );
  OAI222X1 U5667 ( .A0(n6113), .A1(n5732), .B0(n5099), .B1(n5692), .C0(n5810), 
        .C1(n5163), .Y(n3275) );
  OAI222X1 U5668 ( .A0(n6112), .A1(n5875), .B0(n5093), .B1(n5702), .C0(n5820), 
        .C1(n6114), .Y(n3277) );
  OAI222X1 U5669 ( .A0(n6113), .A1(n5876), .B0(n5084), .B1(n5693), .C0(n5845), 
        .C1(n6114), .Y(n3280) );
  OAI222X1 U5670 ( .A0(n5840), .A1(n5172), .B0(n5081), .B1(n5700), .C0(n6112), 
        .C1(n5740), .Y(n3281) );
  OAI222X1 U5671 ( .A0(n6113), .A1(n5725), .B0(n5075), .B1(n5698), .C0(n5815), 
        .C1(n5163), .Y(n3283) );
  OAI222X1 U5672 ( .A0(n5841), .A1(n5172), .B0(n5063), .B1(n5710), .C0(n6112), 
        .C1(n5739), .Y(n3287) );
  OAI222X1 U5673 ( .A0(n6113), .A1(n5877), .B0(n5057), .B1(n5699), .C0(n5803), 
        .C1(n6114), .Y(n3289) );
  OAI222X1 U5674 ( .A0(n6112), .A1(n5726), .B0(n5048), .B1(n5711), .C0(n5805), 
        .C1(n5163), .Y(n3292) );
  OAI222X1 U5675 ( .A0(n6113), .A1(n5727), .B0(n5045), .B1(n5700), .C0(n5806), 
        .C1(n5163), .Y(n3293) );
  OAI222X1 U5676 ( .A0(n5939), .A1(n5398), .B0(n5138), .B1(n6087), .C0(n5679), 
        .C1(n5759), .Y(n3106) );
  OAI222X1 U5677 ( .A0(n5940), .A1(n5398), .B0(n5129), .B1(n6066), .C0(n6089), 
        .C1(n5751), .Y(n3109) );
  OAI222X1 U5678 ( .A0(n6089), .A1(n5911), .B0(n5120), .B1(n6087), .C0(n5719), 
        .C1(n6091), .Y(n3112) );
  OAI222X1 U5679 ( .A0(n5679), .A1(n5912), .B0(n5111), .B1(n6087), .C0(n5765), 
        .C1(n5387), .Y(n3115) );
  OAI222X1 U5680 ( .A0(n5713), .A1(n5918), .B0(n5102), .B1(n6087), .C0(n5766), 
        .C1(n6090), .Y(n3118) );
  OAI222X1 U5681 ( .A0(n5679), .A1(n5919), .B0(n5099), .B1(n6087), .C0(n5720), 
        .C1(n5387), .Y(n3119) );
  OAI222X1 U5682 ( .A0(n5713), .A1(n5921), .B0(n5093), .B1(n6066), .C0(n5767), 
        .C1(n6090), .Y(n3121) );
  OAI222X1 U5683 ( .A0(n6089), .A1(n5923), .B0(n5084), .B1(n6087), .C0(n5768), 
        .C1(n6091), .Y(n3124) );
  OAI222X1 U5684 ( .A0(n5941), .A1(n5398), .B0(n5081), .B1(n6066), .C0(n5679), 
        .C1(n5755), .Y(n3125) );
  OAI222X1 U5685 ( .A0(n5679), .A1(n5925), .B0(n5075), .B1(n6066), .C0(n5721), 
        .C1(n5387), .Y(n3127) );
  OAI222X1 U5686 ( .A0(n5942), .A1(n5398), .B0(n5063), .B1(n6087), .C0(n5713), 
        .C1(n5756), .Y(n3131) );
  OAI222X1 U5687 ( .A0(n6089), .A1(n5929), .B0(n5057), .B1(n6066), .C0(n5769), 
        .C1(n6091), .Y(n3133) );
  OAI222X1 U5688 ( .A0(n5713), .A1(n5931), .B0(n5048), .B1(n6087), .C0(n5722), 
        .C1(n5387), .Y(n3136) );
  OAI222X1 U5689 ( .A0(n6089), .A1(n5932), .B0(n5045), .B1(n6066), .C0(n5723), 
        .C1(n5387), .Y(n3137) );
  OAI222X1 U5690 ( .A0(n5824), .A1(n5343), .B0(n5147), .B1(n6069), .C0(n6094), 
        .C1(n5938), .Y(n3142) );
  OAI222X1 U5691 ( .A0(n5825), .A1(n5343), .B0(n5138), .B1(n5338), .C0(n5331), 
        .C1(n5939), .Y(n3145) );
  OAI222X1 U5692 ( .A0(n5850), .A1(n5343), .B0(n5129), .B1(n5338), .C0(n6095), 
        .C1(n5940), .Y(n3148) );
  OAI222X1 U5693 ( .A0(n6095), .A1(n5719), .B0(n5120), .B1(n5338), .C0(n5770), 
        .C1(n6097), .Y(n3151) );
  OAI222X1 U5694 ( .A0(n5331), .A1(n5765), .B0(n5111), .B1(n5338), .C0(n5878), 
        .C1(n5333), .Y(n3154) );
  OAI222X1 U5695 ( .A0(n6094), .A1(n5766), .B0(n5102), .B1(n5338), .C0(n5879), 
        .C1(n6096), .Y(n3157) );
  OAI222X1 U5696 ( .A0(n5331), .A1(n5720), .B0(n5099), .B1(n5338), .C0(n5796), 
        .C1(n5333), .Y(n3158) );
  OAI222X1 U5697 ( .A0(n6094), .A1(n5767), .B0(n5093), .B1(n5338), .C0(n5880), 
        .C1(n6096), .Y(n3160) );
  OAI222X1 U5698 ( .A0(n6095), .A1(n5768), .B0(n5084), .B1(n5338), .C0(n5881), 
        .C1(n6097), .Y(n3163) );
  OAI222X1 U5699 ( .A0(n5834), .A1(n5343), .B0(n5081), .B1(n6069), .C0(n5331), 
        .C1(n5941), .Y(n3164) );
  OAI222X1 U5700 ( .A0(n5331), .A1(n5721), .B0(n5075), .B1(n5338), .C0(n5776), 
        .C1(n5333), .Y(n3166) );
  OAI222X1 U5701 ( .A0(n5828), .A1(n5343), .B0(n5063), .B1(n6069), .C0(n6094), 
        .C1(n5942), .Y(n3170) );
  OAI222X1 U5702 ( .A0(n6095), .A1(n5769), .B0(n5057), .B1(n6069), .C0(n5882), 
        .C1(n6097), .Y(n3172) );
  OAI222X1 U5703 ( .A0(n6094), .A1(n5722), .B0(n5048), .B1(n5338), .C0(n5778), 
        .C1(n5333), .Y(n3175) );
  OAI222X1 U5704 ( .A0(n6095), .A1(n5723), .B0(n5045), .B1(n5338), .C0(n5779), 
        .C1(n5333), .Y(n3176) );
  OAI222X1 U5705 ( .A0(n5943), .A1(n5290), .B0(n5147), .B1(n6070), .C0(n6100), 
        .C1(n5824), .Y(n3181) );
  OAI222X1 U5706 ( .A0(n5944), .A1(n5290), .B0(n5138), .B1(n6070), .C0(n5276), 
        .C1(n5825), .Y(n3184) );
  OAI222X1 U5707 ( .A0(n6101), .A1(n5770), .B0(n5120), .B1(n6070), .C0(n5883), 
        .C1(n6103), .Y(n3190) );
  OAI222X1 U5708 ( .A0(n6100), .A1(n5878), .B0(n5111), .B1(n6098), .C0(n5771), 
        .C1(n5279), .Y(n3193) );
  OAI222X1 U5709 ( .A0(n6101), .A1(n5898), .B0(n5108), .B1(n6070), .C0(n5772), 
        .C1(n6103), .Y(n3194) );
  OAI222X1 U5710 ( .A0(n6100), .A1(n5879), .B0(n5102), .B1(n6098), .C0(n5773), 
        .C1(n6102), .Y(n3196) );
  OAI222X1 U5711 ( .A0(n6100), .A1(n5880), .B0(n5093), .B1(n6098), .C0(n5774), 
        .C1(n6102), .Y(n3199) );
  OAI222X1 U5712 ( .A0(n5826), .A1(n5290), .B0(n5090), .B1(n6070), .C0(n6100), 
        .C1(n5951), .Y(n3200) );
  OAI222X1 U5713 ( .A0(n6101), .A1(n5881), .B0(n5084), .B1(n6098), .C0(n5775), 
        .C1(n6103), .Y(n3202) );
  OAI222X1 U5714 ( .A0(n6101), .A1(n5776), .B0(n5075), .B1(n6098), .C0(n5884), 
        .C1(n5279), .Y(n3205) );
  OAI222X1 U5715 ( .A0(n5827), .A1(n5290), .B0(n5072), .B1(n6070), .C0(n6101), 
        .C1(n5952), .Y(n3206) );
  OAI222X1 U5716 ( .A0(n5945), .A1(n5290), .B0(n5063), .B1(n6098), .C0(n6100), 
        .C1(n5828), .Y(n3209) );
  OAI222X1 U5717 ( .A0(n6101), .A1(n5882), .B0(n5057), .B1(n6070), .C0(n5777), 
        .C1(n6103), .Y(n3211) );
  OAI222X1 U5718 ( .A0(n6100), .A1(n5778), .B0(n5048), .B1(n6098), .C0(n5885), 
        .C1(n5279), .Y(n3214) );
  OAI222X1 U5719 ( .A0(n6101), .A1(n5779), .B0(n5045), .B1(n6070), .C0(n5886), 
        .C1(n5279), .Y(n3215) );
  OAI222X1 U5720 ( .A0(n5218), .A1(n5883), .B0(n5120), .B1(n6072), .C0(n5724), 
        .C1(n5223), .Y(n3229) );
  OAI222X1 U5721 ( .A0(n5218), .A1(n5884), .B0(n5075), .B1(n6104), .C0(n5725), 
        .C1(n5223), .Y(n3244) );
  OAI222X1 U5722 ( .A0(n5218), .A1(n5885), .B0(n5048), .B1(n6104), .C0(n5726), 
        .C1(n5223), .Y(n3253) );
  OAI222X1 U5723 ( .A0(n5218), .A1(n5886), .B0(n5045), .B1(n6072), .C0(n5727), 
        .C1(n5223), .Y(n3254) );
  OAI222X1 U5724 ( .A0(n6107), .A1(n5791), .B0(n5144), .B1(n5232), .C0(n5888), 
        .C1(n5716), .Y(n3221) );
  OAI222X1 U5725 ( .A0(n6112), .A1(n5887), .B0(n5141), .B1(n5696), .C0(n5813), 
        .C1(n5163), .Y(n3261) );
  OAI222X1 U5726 ( .A0(n6107), .A1(n5792), .B0(n5141), .B1(n6105), .C0(n5887), 
        .C1(n5223), .Y(n3222) );
  OAI222X1 U5727 ( .A0(n5218), .A1(n5793), .B0(n5135), .B1(n5232), .C0(n5889), 
        .C1(n6108), .Y(n3224) );
  OAI222X1 U5728 ( .A0(n6107), .A1(n5780), .B0(n6012), .B1(n6105), .C0(n5890), 
        .C1(n6108), .Y(n3225) );
  OAI222X1 U5729 ( .A0(n5741), .A1(n5233), .B0(n5123), .B1(n6105), .C0(n5218), 
        .C1(n5954), .Y(n3228) );
  OAI222X1 U5730 ( .A0(n6107), .A1(n5795), .B0(n5117), .B1(n5232), .C0(n5891), 
        .C1(n5716), .Y(n3230) );
  OAI222X1 U5731 ( .A0(n5742), .A1(n5233), .B0(n5114), .B1(n6105), .C0(n6107), 
        .C1(n5955), .Y(n3231) );
  OAI222X1 U5732 ( .A0(n5743), .A1(n5233), .B0(n5105), .B1(n6105), .C0(n6106), 
        .C1(n5956), .Y(n3234) );
  OAI222X1 U5733 ( .A0(n6107), .A1(n5798), .B0(n5087), .B1(n6105), .C0(n5893), 
        .C1(n5223), .Y(n3240) );
  OAI222X1 U5734 ( .A0(n5740), .A1(n5233), .B0(n5081), .B1(n6105), .C0(n6107), 
        .C1(n5957), .Y(n3242) );
  OAI222X1 U5735 ( .A0(n6107), .A1(n5799), .B0(n5078), .B1(n6105), .C0(n5894), 
        .C1(n6108), .Y(n3243) );
  OAI222X1 U5736 ( .A0(n6107), .A1(n5801), .B0(n5060), .B1(n6105), .C0(n5895), 
        .C1(n5223), .Y(n3249) );
  OAI222X1 U5737 ( .A0(n6107), .A1(n5802), .B0(n5051), .B1(n6105), .C0(n5896), 
        .C1(n5716), .Y(n3252) );
  OAI222X1 U5738 ( .A0(n5744), .A1(n5233), .B0(n5042), .B1(n6105), .C0(n5218), 
        .C1(n5959), .Y(n3255) );
  OAI222X1 U5739 ( .A0(n6112), .A1(n5888), .B0(n5144), .B1(n5702), .C0(n5812), 
        .C1(n6114), .Y(n3260) );
  OAI222X1 U5740 ( .A0(n6113), .A1(n5889), .B0(n5135), .B1(n5703), .C0(n5846), 
        .C1(n6114), .Y(n3263) );
  OAI222X1 U5741 ( .A0(n6113), .A1(n5731), .B0(n6015), .B1(n5704), .C0(n5809), 
        .C1(n5163), .Y(n3266) );
  OAI222X1 U5742 ( .A0(n5842), .A1(n5172), .B0(n5123), .B1(n5697), .C0(n6112), 
        .C1(n5741), .Y(n3267) );
  OAI222X1 U5743 ( .A0(n5843), .A1(n5172), .B0(n5114), .B1(n5694), .C0(n5161), 
        .C1(n5742), .Y(n3270) );
  OAI222X1 U5744 ( .A0(n6113), .A1(n5892), .B0(n5108), .B1(n5696), .C0(n5847), 
        .C1(n6114), .Y(n3272) );
  OAI222X1 U5745 ( .A0(n5851), .A1(n5172), .B0(n5105), .B1(n5697), .C0(n6113), 
        .C1(n5743), .Y(n3273) );
  OAI222X1 U5746 ( .A0(n6113), .A1(n5733), .B0(n5096), .B1(n5698), .C0(n5808), 
        .C1(n5163), .Y(n3276) );
  OAI222X1 U5747 ( .A0(n5835), .A1(n5172), .B0(n5090), .B1(n5699), .C0(n6112), 
        .C1(n5946), .Y(n3278) );
  OAI222X1 U5748 ( .A0(n6112), .A1(n5893), .B0(n5087), .B1(n5705), .C0(n5817), 
        .C1(n5163), .Y(n3279) );
  OAI222X1 U5749 ( .A0(n5852), .A1(n5172), .B0(n5072), .B1(n5706), .C0(n6113), 
        .C1(n5947), .Y(n3284) );
  OAI222X1 U5750 ( .A0(n6113), .A1(n5734), .B0(n5069), .B1(n5684), .C0(n5848), 
        .C1(n5163), .Y(n3285) );
  OAI222X1 U5751 ( .A0(n6112), .A1(n5895), .B0(n5060), .B1(n5685), .C0(n5811), 
        .C1(n5163), .Y(n3288) );
  OAI222X1 U5752 ( .A0(n6112), .A1(n5896), .B0(n5051), .B1(n5686), .C0(n5804), 
        .C1(n6114), .Y(n3291) );
  OAI222X1 U5753 ( .A0(n5837), .A1(n5172), .B0(n5042), .B1(n5687), .C0(n6113), 
        .C1(n5744), .Y(n3294) );
  OAI222X1 U5754 ( .A0(n5713), .A1(n5933), .B0(n5144), .B1(n6086), .C0(n5781), 
        .C1(n6090), .Y(n3104) );
  OAI222X1 U5755 ( .A0(n5679), .A1(n5934), .B0(n5141), .B1(n5392), .C0(n5782), 
        .C1(n5387), .Y(n3105) );
  OAI222X1 U5756 ( .A0(n6089), .A1(n5913), .B0(n5135), .B1(n6086), .C0(n5783), 
        .C1(n6091), .Y(n3107) );
  OAI222X1 U5757 ( .A0(n5713), .A1(n5914), .B0(n6012), .B1(n5392), .C0(n5784), 
        .C1(n6090), .Y(n3108) );
  OAI222X1 U5758 ( .A0(n5679), .A1(n5915), .B0(n6015), .B1(n6086), .C0(n5728), 
        .C1(n5387), .Y(n3110) );
  OAI222X1 U5759 ( .A0(n5948), .A1(n5398), .B0(n5123), .B1(n5392), .C0(n5713), 
        .C1(n5752), .Y(n3111) );
  OAI222X1 U5760 ( .A0(n5713), .A1(n5916), .B0(n5117), .B1(n6086), .C0(n5785), 
        .C1(n6090), .Y(n3113) );
  OAI222X1 U5761 ( .A0(n5949), .A1(n5398), .B0(n5114), .B1(n5392), .C0(n5679), 
        .C1(n5753), .Y(n3114) );
  OAI222X1 U5762 ( .A0(n6089), .A1(n5917), .B0(n5108), .B1(n5392), .C0(n5786), 
        .C1(n6091), .Y(n3116) );
  OAI222X1 U5763 ( .A0(n5950), .A1(n5398), .B0(n5105), .B1(n5392), .C0(n6089), 
        .C1(n5754), .Y(n3117) );
  OAI222X1 U5764 ( .A0(n6089), .A1(n5920), .B0(n5096), .B1(n5392), .C0(n5729), 
        .C1(n6091), .Y(n3120) );
  OAI222X1 U5765 ( .A0(n5829), .A1(n5398), .B0(n5090), .B1(n5392), .C0(n5713), 
        .C1(n5867), .Y(n3122) );
  OAI222X1 U5766 ( .A0(n5679), .A1(n5922), .B0(n5087), .B1(n5392), .C0(n5787), 
        .C1(n5387), .Y(n3123) );
  OAI222X1 U5767 ( .A0(n5713), .A1(n5924), .B0(n5078), .B1(n5392), .C0(n5788), 
        .C1(n6090), .Y(n3126) );
  OAI222X1 U5768 ( .A0(n5830), .A1(n5398), .B0(n5072), .B1(n5392), .C0(n6089), 
        .C1(n5868), .Y(n3128) );
  OAI222X1 U5769 ( .A0(n6089), .A1(n5926), .B0(n5069), .B1(n5392), .C0(n5730), 
        .C1(n6091), .Y(n3129) );
  OAI222X1 U5770 ( .A0(n5679), .A1(n5928), .B0(n5060), .B1(n5392), .C0(n5789), 
        .C1(n5387), .Y(n3132) );
  OAI222X1 U5771 ( .A0(n5713), .A1(n5930), .B0(n5051), .B1(n5392), .C0(n5790), 
        .C1(n6090), .Y(n3135) );
  OAI222X1 U5772 ( .A0(n5953), .A1(n5398), .B0(n5042), .B1(n5392), .C0(n6089), 
        .C1(n5760), .Y(n3138) );
  OAI222X1 U5773 ( .A0(n6094), .A1(n5781), .B0(n5144), .B1(n5338), .C0(n5899), 
        .C1(n6096), .Y(n3143) );
  OAI222X1 U5774 ( .A0(n5331), .A1(n5782), .B0(n5141), .B1(n5338), .C0(n5900), 
        .C1(n5333), .Y(n3144) );
  OAI222X1 U5775 ( .A0(n6095), .A1(n5783), .B0(n5135), .B1(n6069), .C0(n5901), 
        .C1(n6097), .Y(n3146) );
  OAI222X1 U5776 ( .A0(n6094), .A1(n5784), .B0(n6012), .B1(n5338), .C0(n5897), 
        .C1(n6096), .Y(n3147) );
  OAI222X1 U5777 ( .A0(n5331), .A1(n5728), .B0(n6015), .B1(n6069), .C0(n5794), 
        .C1(n5333), .Y(n3149) );
  OAI222X1 U5778 ( .A0(n5831), .A1(n5343), .B0(n5123), .B1(n5338), .C0(n6094), 
        .C1(n5948), .Y(n3150) );
  OAI222X1 U5779 ( .A0(n6094), .A1(n5785), .B0(n5117), .B1(n6068), .C0(n5902), 
        .C1(n6096), .Y(n3152) );
  OAI222X1 U5780 ( .A0(n5832), .A1(n5343), .B0(n5114), .B1(n6069), .C0(n5331), 
        .C1(n5949), .Y(n3153) );
  OAI222X1 U5781 ( .A0(n6095), .A1(n5786), .B0(n5108), .B1(n5338), .C0(n5898), 
        .C1(n6097), .Y(n3155) );
  OAI222X1 U5782 ( .A0(n5833), .A1(n5343), .B0(n5105), .B1(n6069), .C0(n6095), 
        .C1(n5950), .Y(n3156) );
  OAI222X1 U5783 ( .A0(n6095), .A1(n5729), .B0(n5096), .B1(n6069), .C0(n5797), 
        .C1(n6097), .Y(n3159) );
  OAI222X1 U5784 ( .A0(n5951), .A1(n5343), .B0(n5090), .B1(n5338), .C0(n6094), 
        .C1(n5829), .Y(n3161) );
  OAI222X1 U5785 ( .A0(n5331), .A1(n5787), .B0(n5087), .B1(n6069), .C0(n5903), 
        .C1(n5333), .Y(n3162) );
  OAI222X1 U5786 ( .A0(n6094), .A1(n5788), .B0(n5078), .B1(n5338), .C0(n5904), 
        .C1(n6096), .Y(n3165) );
  OAI222X1 U5787 ( .A0(n5952), .A1(n5343), .B0(n5072), .B1(n5338), .C0(n6095), 
        .C1(n5830), .Y(n3167) );
  OAI222X1 U5788 ( .A0(n6095), .A1(n5730), .B0(n5069), .B1(n5338), .C0(n5800), 
        .C1(n6097), .Y(n3168) );
  OAI222X1 U5789 ( .A0(n5331), .A1(n5789), .B0(n5060), .B1(n5338), .C0(n5905), 
        .C1(n5333), .Y(n3171) );
  OAI222X1 U5790 ( .A0(n6094), .A1(n5790), .B0(n5051), .B1(n6069), .C0(n5906), 
        .C1(n6096), .Y(n3174) );
  OAI222X1 U5791 ( .A0(n5853), .A1(n5343), .B0(n5042), .B1(n6069), .C0(n6095), 
        .C1(n5953), .Y(n3177) );
  OAI222X1 U5792 ( .A0(n6100), .A1(n5899), .B0(n5144), .B1(n5289), .C0(n5791), 
        .C1(n6102), .Y(n3182) );
  OAI222X1 U5793 ( .A0(n6100), .A1(n5900), .B0(n5141), .B1(n6099), .C0(n5792), 
        .C1(n5279), .Y(n3183) );
  OAI222X1 U5794 ( .A0(n6101), .A1(n5901), .B0(n5135), .B1(n5289), .C0(n5793), 
        .C1(n6103), .Y(n3185) );
  OAI222X1 U5795 ( .A0(n6101), .A1(n5794), .B0(n6015), .B1(n5289), .C0(n5907), 
        .C1(n5279), .Y(n3188) );
  OAI222X1 U5796 ( .A0(n5954), .A1(n5290), .B0(n5123), .B1(n6099), .C0(n6100), 
        .C1(n5831), .Y(n3189) );
  OAI222X1 U5797 ( .A0(n5955), .A1(n5290), .B0(n5114), .B1(n6099), .C0(n5276), 
        .C1(n5832), .Y(n3192) );
  OAI222X1 U5798 ( .A0(n5956), .A1(n5290), .B0(n5105), .B1(n6099), .C0(n6101), 
        .C1(n5833), .Y(n3195) );
  OAI222X1 U5799 ( .A0(n6101), .A1(n5796), .B0(n5099), .B1(n6099), .C0(n5908), 
        .C1(n5279), .Y(n3197) );
  OAI222X1 U5800 ( .A0(n6101), .A1(n5797), .B0(n5096), .B1(n6099), .C0(n5909), 
        .C1(n6103), .Y(n3198) );
  OAI222X1 U5801 ( .A0(n6100), .A1(n5903), .B0(n5087), .B1(n6099), .C0(n5798), 
        .C1(n5279), .Y(n3201) );
  OAI222X1 U5802 ( .A0(n5957), .A1(n5290), .B0(n5081), .B1(n6099), .C0(n6100), 
        .C1(n5834), .Y(n3203) );
  OAI222X1 U5803 ( .A0(n6101), .A1(n5800), .B0(n5069), .B1(n6099), .C0(n5910), 
        .C1(n6103), .Y(n3207) );
  OAI222X1 U5804 ( .A0(n6100), .A1(n5905), .B0(n5060), .B1(n6099), .C0(n5801), 
        .C1(n5279), .Y(n3210) );
  OAI222X1 U5805 ( .A0(n5218), .A1(n5907), .B0(n6015), .B1(n5232), .C0(n5731), 
        .C1(n5223), .Y(n3227) );
  OAI222X1 U5806 ( .A0(n5218), .A1(n5908), .B0(n5099), .B1(n6105), .C0(n5732), 
        .C1(n5223), .Y(n3236) );
  OAI222X1 U5807 ( .A0(n5218), .A1(n5910), .B0(n5069), .B1(n6105), .C0(n5734), 
        .C1(n5223), .Y(n3246) );
  NAND2BX1 U5808 ( .AN(n5019), .B(n5021), .Y(n3337) );
  AO21X1 U5809 ( .A0(n5022), .A1(n5023), .B0(n5960), .Y(n5021) );
  INVX1 U5810 ( .A(n5018), .Y(n5023) );
  OAI32X1 U5811 ( .A0(n5016), .A1(n5017), .A2(n5018), .B0(n5019), .B1(n5855), 
        .Y(n3338) );
  OA21X2 U5812 ( .A0(n5585), .A1(n5586), .B0(n6014), .Y(n5584) );
  OAI31X1 U5813 ( .A0(n5650), .A1(n5651), .A2(n5652), .B0(n5653), .Y(
        CAS_FULL922) );
  INVX1 U5814 ( .A(n429_2_), .Y(n5651) );
  NOR2BX1 U5815 ( .AN(n5654), .B(n429_3_), .Y(n5653) );
  INVX1 U5816 ( .A(n429_0_), .Y(n5650) );
  OAI31X1 U5817 ( .A0(n5273), .A1(n6022), .A2(n5026), .B0(n5330), .Y(n3180) );
  OA22X1 U5818 ( .A0(n5331), .A1(n5998), .B0(n5856), .B1(n6097), .Y(n5330) );
  INVX1 U5819 ( .A(n429_1_), .Y(n5652) );
  NAND2BX1 U5820 ( .AN(n5629), .B(n5602), .Y(n5623) );
  NAND2BX1 U5821 ( .AN(n5634), .B(n5608), .Y(n5631) );
  NAND2BX1 U5822 ( .AN(n5642), .B(n5601), .Y(n5637) );
  OAI222X1 U5823 ( .A0(n6045), .A1(n5637), .B0(n5618), .B1(n5638), .C0(n6044), 
        .C1(n5639), .Y(n3044) );
  OAI222X1 U5824 ( .A0(n6055), .A1(n5631), .B0(n5618), .B1(n5632), .C0(n6054), 
        .C1(n5633), .Y(n3049) );
  OAI222X1 U5825 ( .A0(n6058), .A1(n5623), .B0(n5618), .B1(n5624), .C0(n6057), 
        .C1(n5625), .Y(n3054) );
  OAI222X1 U5826 ( .A0(n5745), .A1(n5637), .B0(n5617), .B1(n5638), .C0(n6041), 
        .C1(n5639), .Y(n3045) );
  OAI222X1 U5827 ( .A0(n5747), .A1(n5631), .B0(n5617), .B1(n5632), .C0(n6051), 
        .C1(n5633), .Y(n3050) );
  OAI222X1 U5828 ( .A0(n5718), .A1(n5623), .B0(n5617), .B1(n5624), .C0(n6050), 
        .C1(n5625), .Y(n3055) );
  OAI222X1 U5829 ( .A0(n6048), .A1(n5613), .B0(n5614), .B1(n5618), .C0(n6047), 
        .C1(n5615), .Y(n3059) );
  OAI222X1 U5830 ( .A0(n5746), .A1(n5613), .B0(n5614), .B1(n5617), .C0(n6042), 
        .C1(n5615), .Y(n3060) );
  OAI222X1 U5831 ( .A0(n5863), .A1(n5631), .B0(n5437), .B1(n5632), .C0(n6062), 
        .C1(n5633), .Y(n3052) );
  OAI222X1 U5832 ( .A0(n5750), .A1(n5613), .B0(n5437), .B1(n5614), .C0(n6060), 
        .C1(n5615), .Y(n3062) );
  OAI222X1 U5833 ( .A0(n5864), .A1(n5637), .B0(n5616), .B1(n5638), .C0(n6064), 
        .C1(n5639), .Y(n3046) );
  OAI222X1 U5834 ( .A0(n5861), .A1(n5631), .B0(n5616), .B1(n5632), .C0(n6061), 
        .C1(n5633), .Y(n3051) );
  OAI222X1 U5835 ( .A0(n5865), .A1(n5623), .B0(n5616), .B1(n5624), .C0(n6052), 
        .C1(n5625), .Y(n3056) );
  OAI222X1 U5836 ( .A0(n5748), .A1(n5613), .B0(n5616), .B1(n5614), .C0(n6043), 
        .C1(n5615), .Y(n3061) );
  INVX1 U5837 ( .A(BA_ID[3]), .Y(n5147) );
  INVX1 U5838 ( .A(BA_ID[2]), .Y(n5144) );
  INVX1 U5839 ( .A(BA_ID[1]), .Y(n5141) );
  INVX1 U5840 ( .A(BA_ID[0]), .Y(n5138) );
  INVX1 U5841 ( .A(cas_cnt1375_2_), .Y(n5646) );
  NAND3BX1 U5842 ( .AN(B2_LAST_RA[0]), .B(n5521), .C(n5497), .Y(n5512) );
  INVX1 U5843 ( .A(n5496), .Y(n5521) );
  INVX1 U5844 ( .A(cas_cnt1375_1_), .Y(n5648) );
  INVX1 U5845 ( .A(B3_LAST_RA[0]), .Y(n5486) );
  INVX1 U5846 ( .A(cas_cnt1375_4_), .Y(n5671) );
  OAI31X1 U5847 ( .A0(n5630), .A1(n5718), .A2(n6058), .B0(n6014), .Y(n5602) );
  NAND3BX1 U5848 ( .AN(n5865), .B(cas_cnt_b2_pos_1_), .C(cas_cnt_b2_pos_0_), 
        .Y(n5630) );
  INVX1 U5849 ( .A(cas_cnt1375_3_), .Y(n5673) );
  NAND3BX1 U5850 ( .AN(B2_LAST_RA[13]), .B(n5527), .C(n5528), .Y(n5496) );
  XOR2X1 U5851 ( .A(n5096), .B(B2_LAST_RA[1]), .Y(n5527) );
  XOR2X1 U5852 ( .A(n5126), .B(B2_LAST_RA[11]), .Y(n5528) );
  NAND3BX1 U5853 ( .AN(B0_LAST_RA[13]), .B(n5563), .C(n5564), .Y(n5509) );
  XOR2X1 U5854 ( .A(n5096), .B(B0_LAST_RA[1]), .Y(n5563) );
  XOR2X1 U5855 ( .A(n5126), .B(B0_LAST_RA[11]), .Y(n5564) );
  NAND3BX1 U5856 ( .AN(B1_LAST_RA[13]), .B(n5579), .C(n5580), .Y(n5503) );
  XOR2X1 U5857 ( .A(n5096), .B(B1_LAST_RA[1]), .Y(n5579) );
  XOR2X1 U5858 ( .A(n5126), .B(B1_LAST_RA[11]), .Y(n5580) );
  XOR2X1 U5859 ( .A(n5114), .B(B2_LAST_RA[7]), .Y(n5519) );
  XOR2X1 U5860 ( .A(n5117), .B(B2_LAST_RA[8]), .Y(n5520) );
  XOR2X1 U5861 ( .A(BA_RA[9]), .B(B2_LAST_RA[9]), .Y(n5518) );
  XOR2X1 U5862 ( .A(n5129), .B(B1_LAST_RA[12]), .Y(n5576) );
  XOR2X1 U5863 ( .A(n5129), .B(B0_LAST_RA[12]), .Y(n5560) );
  XOR2X1 U5864 ( .A(n5129), .B(B2_LAST_RA[12]), .Y(n5524) );
  XOR2X1 U5865 ( .A(n5099), .B(B3_LAST_RA[2]), .Y(n5535) );
  XOR2X1 U5866 ( .A(n5108), .B(B3_LAST_RA[5]), .Y(n5544) );
  XOR2X1 U5867 ( .A(n5105), .B(B3_LAST_RA[4]), .Y(n5543) );
  XOR2X1 U5868 ( .A(n5117), .B(B3_LAST_RA[8]), .Y(n5541) );
  XOR2X1 U5869 ( .A(n5114), .B(B3_LAST_RA[7]), .Y(n5540) );
  OAI2BB1X1 U5870 ( .A0N(cas_cnt1375_2_), .A1N(n5659), .B0(n6024), .Y(n429_2_)
         );
  AOI22X1 U5871 ( .A0(cas_cnt_2_), .A1(n5661), .B0(cas_cnt1419_2_), .B1(n5662), 
        .Y(n6024) );
  XOR2X1 U5872 ( .A(BA_RA[9]), .B(B1_LAST_RA[9]), .Y(n5570) );
  XOR2X1 U5873 ( .A(BA_RA[9]), .B(B0_LAST_RA[9]), .Y(n5554) );
  XOR2X1 U5874 ( .A(BA_RA[9]), .B(B3_LAST_RA[9]), .Y(n5539) );
  XOR2X1 U5875 ( .A(BA_RA[6]), .B(B1_LAST_RA[6]), .Y(n5566) );
  XOR2X1 U5876 ( .A(BA_RA[6]), .B(B0_LAST_RA[6]), .Y(n5550) );
  XOR2X1 U5877 ( .A(BA_RA[6]), .B(B2_LAST_RA[6]), .Y(n5515) );
  XOR2X1 U5878 ( .A(BA_RA[6]), .B(B3_LAST_RA[6]), .Y(n5542) );
  XOR2X1 U5879 ( .A(BA_RA[3]), .B(B3_LAST_RA[3]), .Y(n5533) );
  OAI222X1 U5880 ( .A0(n181_0_), .A1(n5665), .B0(n5666), .B1(n5963), .C0(
        cas_cnt_0_), .C1(n5668), .Y(n429_0_) );
  OAI31X1 U5881 ( .A0(n5224), .A1(n5866), .A2(n5218), .B0(n5226), .Y(n3257) );
  INVX1 U5882 ( .A(n5227), .Y(n5224) );
  AOI31X1 U5883 ( .A0(cas_5_final), .A1(n6107), .A2(n5227), .B0(n5228), .Y(
        n5226) );
  NAND2BX1 U5884 ( .AN(n5222), .B(n5022), .Y(n5227) );
  OAI31X1 U5885 ( .A0(n5031), .A1(n5032), .A2(n5960), .B0(n5033), .Y(n3335) );
  INVX1 U5886 ( .A(n5034), .Y(n5031) );
  AOI31X1 U5887 ( .A0(n5032), .A1(cas_6_final), .A2(n5034), .B0(n5035), .Y(
        n5033) );
  NAND2BX1 U5888 ( .AN(n5026), .B(n5022), .Y(n5034) );
  AO21X1 U5889 ( .A0(cas_cnt1375_1_), .A1(n5659), .B0(n5669), .Y(n429_1_) );
  AO22X1 U5890 ( .A0(cas_cnt_1_), .A1(n5661), .B0(cas_cnt1419_1_), .B1(n5662), 
        .Y(n5669) );
  NAND4BX1 U5891 ( .AN(B3_LAST_RA[13]), .B(n5536), .C(n5537), .D(n5538), .Y(
        n5531) );
  XOR2X1 U5892 ( .A(n5123), .B(B3_LAST_RA[10]), .Y(n5536) );
  XOR2X1 U5893 ( .A(n5126), .B(B3_LAST_RA[11]), .Y(n5538) );
  XOR2X1 U5894 ( .A(n5129), .B(B3_LAST_RA[12]), .Y(n5537) );
  OAI221X1 U5895 ( .A0(n5863), .A1(n5449), .B0(n5750), .B1(n5451), .C0(n5467), 
        .Y(n5287) );
  AOI222X1 U5896 ( .A0(n6014), .A1(n5468), .B0(n5454), .B1(cas_cnt_b0_pos_1_), 
        .C0(n5455), .C1(cas_cnt_b2_pos_1_), .Y(n5467) );
  OAI221X1 U5897 ( .A0(n5861), .A1(n5449), .B0(n5748), .B1(n5451), .C0(n5452), 
        .Y(n5220) );
  AOI222X1 U5898 ( .A0(n6014), .A1(n5453), .B0(n5454), .B1(cas_cnt_b0_pos_2_), 
        .C0(n5455), .C1(cas_cnt_b2_pos_2_), .Y(n5452) );
  OAI31X1 U5899 ( .A0(n5643), .A1(n5745), .A2(n6045), .B0(n6014), .Y(n5601) );
  NAND3BX1 U5900 ( .AN(n5864), .B(cas_cnt_b0_pos_1_), .C(cas_cnt_b0_pos_0_), 
        .Y(n5643) );
  NAND3X1 U5901 ( .A(B2_LAST_RA[0]), .B(n5494), .C(n6025), .Y(n5492) );
  NAND3X1 U5902 ( .A(B0_LAST_RA[0]), .B(n5507), .C(n6037), .Y(n5488) );
  NAND3X1 U5903 ( .A(B1_LAST_RA[0]), .B(n5501), .C(n6034), .Y(n5490) );
  NAND3BX1 U5904 ( .AN(B0_LAST_RA[0]), .B(n5557), .C(n5510), .Y(n5547) );
  INVX1 U5905 ( .A(n5509), .Y(n5557) );
  NAND3BX1 U5906 ( .AN(B1_LAST_RA[0]), .B(n5573), .C(n5504), .Y(n5545) );
  INVX1 U5907 ( .A(n5503), .Y(n5573) );
  OAI221X1 U5908 ( .A0(n5746), .A1(n5451), .B0(n6048), .B1(n5451), .C0(n5605), 
        .Y(n5581) );
  AOI211X1 U5909 ( .A0(n5455), .A1(cas_cnt_b2_pos_4_), .B0(n5583), .C0(n5584), 
        .Y(n5582) );
  OAI31X1 U5910 ( .A0(n5635), .A1(n5747), .A2(n6055), .B0(n5149), .Y(n5608) );
  NAND3BX1 U5911 ( .AN(n5861), .B(cas_cnt_b1_pos_1_), .C(cas_cnt_b1_pos_0_), 
        .Y(n5635) );
  OAI31X1 U5912 ( .A0(n5620), .A1(n5746), .A2(n6048), .B0(n6014), .Y(n5609) );
  NAND3BX1 U5913 ( .AN(n5748), .B(cas_cnt_b3_pos_1_), .C(cas_cnt_b3_pos_0_), 
        .Y(n5620) );
  AO22X1 U5914 ( .A0(cas_7_data[27]), .A1(n6078), .B0(n5019), .B1(BA_RA[9]), 
        .Y(n3016) );
  AO22X1 U5915 ( .A0(cas_7_data[18]), .A1(n6078), .B0(n5019), .B1(BA_RA[0]), 
        .Y(n3025) );
  AO22X1 U5916 ( .A0(cas_7_data[20]), .A1(n5644), .B0(n5019), .B1(BA_RA[2]), 
        .Y(n3023) );
  AO22X1 U5917 ( .A0(cas_7_data[26]), .A1(n5644), .B0(n5019), .B1(BA_RA[8]), 
        .Y(n3017) );
  AO22X1 U5918 ( .A0(cas_7_data[22]), .A1(n6079), .B0(n5019), .B1(BA_RA[4]), 
        .Y(n3021) );
  AO22X1 U5919 ( .A0(cas_7_data[19]), .A1(n6079), .B0(n5019), .B1(BA_RA[1]), 
        .Y(n3024) );
  AO22X1 U5920 ( .A0(cas_7_data[23]), .A1(n5644), .B0(n5019), .B1(BA_RA[5]), 
        .Y(n3020) );
  AO22X1 U5921 ( .A0(cas_7_data[21]), .A1(n6078), .B0(n5019), .B1(BA_RA[3]), 
        .Y(n3022) );
  AO22X1 U5922 ( .A0(cas_7_data[25]), .A1(n6079), .B0(n5019), .B1(BA_RA[7]), 
        .Y(n3018) );
  INVX1 U5923 ( .A(n5574), .Y(n5504) );
  NAND4BX1 U5924 ( .AN(n5575), .B(n5576), .C(n5577), .D(n5578), .Y(n5574) );
  XOR2X1 U5925 ( .A(n5099), .B(B1_LAST_RA[2]), .Y(n5578) );
  XOR2X1 U5926 ( .A(n5102), .B(B1_LAST_RA[3]), .Y(n5577) );
  INVX1 U5927 ( .A(n5558), .Y(n5510) );
  NAND4BX1 U5928 ( .AN(n5559), .B(n5560), .C(n5561), .D(n5562), .Y(n5558) );
  XOR2X1 U5929 ( .A(n5099), .B(B0_LAST_RA[2]), .Y(n5562) );
  XOR2X1 U5930 ( .A(n5102), .B(B0_LAST_RA[3]), .Y(n5561) );
  INVX1 U5931 ( .A(n5522), .Y(n5497) );
  NAND4BX1 U5932 ( .AN(n5523), .B(n5524), .C(n5525), .D(n5526), .Y(n5522) );
  XOR2X1 U5933 ( .A(n5099), .B(B2_LAST_RA[2]), .Y(n5526) );
  XOR2X1 U5934 ( .A(n5102), .B(B2_LAST_RA[3]), .Y(n5525) );
  AO22X1 U5935 ( .A0(cas_7_data[24]), .A1(n6078), .B0(n5019), .B1(BA_RA[6]), 
        .Y(n3019) );
  AO22X1 U5936 ( .A0(cas_7_data[6]), .A1(n6078), .B0(BA_TT[4]), .B1(n5019), 
        .Y(n3037) );
  AO22X1 U5937 ( .A0(cas_7_data[29]), .A1(n5644), .B0(n5019), .B1(BA_RA[11]), 
        .Y(n3014) );
  NOR3X1 U5938 ( .A(n5515), .B(n6026), .C(n6027), .Y(n6025) );
  XNOR2X1 U5939 ( .A(n5105), .B(B2_LAST_RA[4]), .Y(n6026) );
  XNOR2X1 U5940 ( .A(n5108), .B(B2_LAST_RA[5]), .Y(n6027) );
  OAI222X1 U5941 ( .A0(n6119), .A1(n5803), .B0(n6076), .B1(n5057), .C0(n6121), 
        .C1(n5969), .Y(n3328) );
  OAI222X1 U5942 ( .A0(n5040), .A1(n5989), .B0(n6076), .B1(n5090), .C0(n6118), 
        .C1(n5835), .Y(n3317) );
  OAI222X1 U5943 ( .A0(n5040), .A1(n5990), .B0(n6116), .B1(n5054), .C0(n6119), 
        .C1(n5836), .Y(n3329) );
  OAI222X1 U5944 ( .A0(n6118), .A1(n5804), .B0(n6117), .B1(n5051), .C0(n6120), 
        .C1(n5970), .Y(n3330) );
  OAI222X1 U5945 ( .A0(n6118), .A1(n5805), .B0(n6116), .B1(n5048), .C0(n5030), 
        .C1(n5971), .Y(n3331) );
  OAI222X1 U5946 ( .A0(n5040), .A1(n5991), .B0(n6117), .B1(n5042), .C0(n6119), 
        .C1(n5837), .Y(n3333) );
  OAI222X1 U5947 ( .A0(n6119), .A1(n5806), .B0(n6076), .B1(n5045), .C0(n5030), 
        .C1(n5972), .Y(n3332) );
  OAI222X1 U5948 ( .A0(n6118), .A1(n5807), .B0(n5117), .B1(n6077), .C0(n6120), 
        .C1(n5973), .Y(n3308) );
  OAI222X1 U5949 ( .A0(n6119), .A1(n5809), .B0(n6015), .B1(n6076), .C0(n5030), 
        .C1(n5975), .Y(n3305) );
  OAI222X1 U5950 ( .A0(n6119), .A1(n5810), .B0(n5099), .B1(n6076), .C0(n5030), 
        .C1(n5976), .Y(n3314) );
  OAI222X1 U5951 ( .A0(n6118), .A1(n5811), .B0(n6117), .B1(n5060), .C0(n5030), 
        .C1(n5977), .Y(n3327) );
  OAI222X1 U5952 ( .A0(n5854), .A1(n6084), .B0(n6083), .B1(n5677), .C0(n5222), 
        .C1(n5273), .Y(n3102) );
  OAI222X1 U5953 ( .A0(n5040), .A1(n5992), .B0(n6076), .B1(n5147), .C0(n6118), 
        .C1(n5838), .Y(n3298) );
  OAI222X1 U5954 ( .A0(n6118), .A1(n5812), .B0(n6117), .B1(n5144), .C0(n6120), 
        .C1(n5978), .Y(n3299) );
  OAI222X1 U5955 ( .A0(n6118), .A1(n5813), .B0(n6117), .B1(n5141), .C0(n5030), 
        .C1(n5979), .Y(n3300) );
  OAI222X1 U5956 ( .A0(n5040), .A1(n5993), .B0(n6116), .B1(n5138), .C0(n5028), 
        .C1(n5839), .Y(n3301) );
  OAI222X1 U5957 ( .A0(n5040), .A1(n5994), .B0(n6117), .B1(n5081), .C0(n6118), 
        .C1(n5840), .Y(n3320) );
  OAI222X1 U5958 ( .A0(n6118), .A1(n5814), .B0(n6117), .B1(n5078), .C0(n6120), 
        .C1(n5980), .Y(n3321) );
  OAI222X1 U5959 ( .A0(n6119), .A1(n5815), .B0(n6116), .B1(n5075), .C0(n5030), 
        .C1(n5981), .Y(n3322) );
  OAI222X1 U5960 ( .A0(n6118), .A1(n5816), .B0(n6076), .B1(n5066), .C0(n6120), 
        .C1(n5982), .Y(n3325) );
  OAI222X1 U5961 ( .A0(n5040), .A1(n5995), .B0(n6116), .B1(n5063), .C0(n6118), 
        .C1(n5841), .Y(n3326) );
  OAI222X1 U5962 ( .A0(n6118), .A1(n5817), .B0(n6117), .B1(n5087), .C0(n5030), 
        .C1(n5983), .Y(n3318) );
  OAI222X1 U5963 ( .A0(n6083), .A1(n2991), .B0(n5129), .B1(n6081), .C0(n5751), 
        .C1(n5438), .Y(n3066) );
  OAI222X1 U5964 ( .A0(n6083), .A1(n3000), .B0(n5120), .B1(n6081), .C0(n5911), 
        .C1(n5438), .Y(n3069) );
  OAI222X1 U5965 ( .A0(n6083), .A1(n2997), .B0(n5111), .B1(n6081), .C0(n5912), 
        .C1(n5438), .Y(n3072) );
  OAI222X1 U5966 ( .A0(n6118), .A1(n5818), .B0(n5111), .B1(n6117), .C0(n5030), 
        .C1(n5984), .Y(n3310) );
  OAI222X1 U5967 ( .A0(n6118), .A1(n5819), .B0(n5102), .B1(n6117), .C0(n6120), 
        .C1(n5985), .Y(n3313) );
  OAI222X1 U5968 ( .A0(n6118), .A1(n5820), .B0(n5093), .B1(n6117), .C0(n6120), 
        .C1(n5986), .Y(n3316) );
  OAI222X1 U5969 ( .A0(n6118), .A1(n5821), .B0(n6012), .B1(n5037), .C0(n6120), 
        .C1(n5987), .Y(n3303) );
  OAI222X1 U5970 ( .A0(n5040), .A1(n5996), .B0(n5123), .B1(n5037), .C0(n6118), 
        .C1(n5842), .Y(n3306) );
  OAI222X1 U5971 ( .A0(n5040), .A1(n5997), .B0(n5114), .B1(n5037), .C0(n5028), 
        .C1(n5843), .Y(n3309) );
  OAI222X1 U5972 ( .A0(n5028), .A1(n5822), .B0(n6077), .B1(n5038), .C0(n6120), 
        .C1(n5988), .Y(n3334) );
  OAI222X1 U5973 ( .A0(n6082), .A1(n2969), .B0(n5135), .B1(n6080), .C0(n5913), 
        .C1(n6085), .Y(n3064) );
  OAI222X1 U5974 ( .A0(n5439), .A1(n2968), .B0(n6012), .B1(n5610), .C0(n5914), 
        .C1(n6084), .Y(n3065) );
  OAI222X1 U5975 ( .A0(n6082), .A1(n2990), .B0(n6015), .B1(n6080), .C0(n5915), 
        .C1(n6085), .Y(n3067) );
  OAI222X1 U5976 ( .A0(n5439), .A1(n2989), .B0(n5123), .B1(n5610), .C0(n5752), 
        .C1(n6084), .Y(n3068) );
  OAI222X1 U5977 ( .A0(n6082), .A1(n2999), .B0(n5117), .B1(n6080), .C0(n5916), 
        .C1(n6085), .Y(n3070) );
  OAI222X1 U5978 ( .A0(n6083), .A1(n2998), .B0(n5114), .B1(n5610), .C0(n5753), 
        .C1(n6084), .Y(n3071) );
  OAI222X1 U5979 ( .A0(n6082), .A1(n2996), .B0(n5108), .B1(n6080), .C0(n5917), 
        .C1(n6085), .Y(n3073) );
  OAI222X1 U5980 ( .A0(n6082), .A1(n2995), .B0(n5105), .B1(n5610), .C0(n5754), 
        .C1(n6084), .Y(n3074) );
  OAI222X1 U5981 ( .A0(n6083), .A1(n2994), .B0(n5102), .B1(n5610), .C0(n5918), 
        .C1(n5438), .Y(n3075) );
  OAI222X1 U5982 ( .A0(n6082), .A1(n2993), .B0(n5099), .B1(n6080), .C0(n5919), 
        .C1(n6085), .Y(n3076) );
  OAI222X1 U5983 ( .A0(n6083), .A1(n2992), .B0(n5096), .B1(n5610), .C0(n5920), 
        .C1(n6084), .Y(n3077) );
  OAI222X1 U5984 ( .A0(n6083), .A1(n2988), .B0(n5093), .B1(n6080), .C0(n5921), 
        .C1(n5438), .Y(n3078) );
  OAI222X1 U5985 ( .A0(n6082), .A1(n2971), .B0(n5090), .B1(n6080), .C0(n5867), 
        .C1(n6085), .Y(n3079) );
  OAI222X1 U5986 ( .A0(n6082), .A1(n2980), .B0(n5087), .B1(n5610), .C0(n5922), 
        .C1(n6084), .Y(n3080) );
  OAI222X1 U5987 ( .A0(n6083), .A1(n2979), .B0(n5084), .B1(n5610), .C0(n5923), 
        .C1(n5438), .Y(n3081) );
  OAI222X1 U5988 ( .A0(n6082), .A1(n2978), .B0(n5081), .B1(n6080), .C0(n5755), 
        .C1(n6085), .Y(n3082) );
  OAI222X1 U5989 ( .A0(n6083), .A1(n2977), .B0(n5078), .B1(n5610), .C0(n5924), 
        .C1(n6084), .Y(n3083) );
  OAI222X1 U5990 ( .A0(n6083), .A1(n2976), .B0(n5075), .B1(n6080), .C0(n5925), 
        .C1(n5438), .Y(n3084) );
  OAI222X1 U5991 ( .A0(n6082), .A1(n2975), .B0(n5072), .B1(n6080), .C0(n5868), 
        .C1(n6085), .Y(n3085) );
  OAI222X1 U5992 ( .A0(n6082), .A1(n2974), .B0(n5069), .B1(n5610), .C0(n5926), 
        .C1(n6084), .Y(n3086) );
  OAI222X1 U5993 ( .A0(n6083), .A1(n2973), .B0(n5066), .B1(n5610), .C0(n5927), 
        .C1(n5438), .Y(n3087) );
  OAI222X1 U5994 ( .A0(n6082), .A1(n2972), .B0(n5063), .B1(n6080), .C0(n5756), 
        .C1(n6085), .Y(n3088) );
  OAI222X1 U5995 ( .A0(n6083), .A1(n2970), .B0(n5060), .B1(n5610), .C0(n5928), 
        .C1(n6084), .Y(n3089) );
  OAI222X1 U5996 ( .A0(n6083), .A1(n3006), .B0(n5057), .B1(n6080), .C0(n5929), 
        .C1(n5438), .Y(n3090) );
  OAI222X1 U5997 ( .A0(n6082), .A1(n3005), .B0(n5054), .B1(n6080), .C0(n5757), 
        .C1(n6085), .Y(n3091) );
  OAI222X1 U5998 ( .A0(n6082), .A1(n3004), .B0(n5051), .B1(n5610), .C0(n5930), 
        .C1(n6084), .Y(n3092) );
  OAI222X1 U5999 ( .A0(n6083), .A1(n3003), .B0(n5048), .B1(n5610), .C0(n5931), 
        .C1(n5438), .Y(n3093) );
  OAI222X1 U6000 ( .A0(n6082), .A1(n3002), .B0(n5045), .B1(n6080), .C0(n5932), 
        .C1(n6085), .Y(n3094) );
  OAI222X1 U6001 ( .A0(n6083), .A1(n2985), .B0(n5147), .B1(n5610), .C0(n5758), 
        .C1(n6084), .Y(n3095) );
  OAI222X1 U6002 ( .A0(n6083), .A1(n2984), .B0(n5144), .B1(n6080), .C0(n5933), 
        .C1(n5438), .Y(n3096) );
  OAI222X1 U6003 ( .A0(n6082), .A1(n2983), .B0(n5141), .B1(n6080), .C0(n5934), 
        .C1(n6085), .Y(n3097) );
  OAI222X1 U6004 ( .A0(n6082), .A1(n2982), .B0(n5138), .B1(n5610), .C0(n5759), 
        .C1(n6084), .Y(n3098) );
  OAI222X1 U6005 ( .A0(n6083), .A1(n3001), .B0(n5042), .B1(n5610), .C0(n5760), 
        .C1(n5438), .Y(n3099) );
  OAI222X1 U6006 ( .A0(n6082), .A1(n2987), .B0(n5038), .B1(n6080), .C0(n5935), 
        .C1(n6085), .Y(n3100) );
  AO22X1 U6007 ( .A0(cas_7_data[17]), .A1(n5644), .B0(BA_CA[10]), .B1(n5019), 
        .Y(n3026) );
  AO22X1 U6008 ( .A0(cas_7_data[1]), .A1(n5644), .B0(BA_RW), .B1(n5019), .Y(
        n3042) );
  AO22X1 U6009 ( .A0(cas_7_data[5]), .A1(n5644), .B0(BA_TT[3]), .B1(n5019), 
        .Y(n3038) );
  AO22X1 U6010 ( .A0(cas_7_data[4]), .A1(n6078), .B0(BA_TT[2]), .B1(n5019), 
        .Y(n3039) );
  AO22X1 U6011 ( .A0(cas_7_data[3]), .A1(n6078), .B0(BA_TT[1]), .B1(n5019), 
        .Y(n3040) );
  AO22X1 U6012 ( .A0(cas_7_data[2]), .A1(n5644), .B0(BA_TT[0]), .B1(n5019), 
        .Y(n3041) );
  NAND2BX1 U6013 ( .AN(n5443), .B(n5444), .Y(n3101) );
  AO21X1 U6014 ( .A0(n5445), .A1(n5678), .B0(n5446), .Y(n5444) );
  OAI32X1 U6015 ( .A0(n5447), .A1(n5222), .A2(n5717), .B0(cas_1_final), .B1(
        n5445), .Y(n5446) );
  NAND3BX1 U6016 ( .AN(n5441), .B(BA_REQ), .C(n6023), .Y(n5447) );
  AO22X1 U6017 ( .A0(cas_7_data[7]), .A1(n5644), .B0(BA_CA[0]), .B1(n5019), 
        .Y(n3036) );
  AO22X1 U6018 ( .A0(cas_7_data[0]), .A1(n6078), .B0(BA_PM), .B1(n5019), .Y(
        n3043) );
  AO22X1 U6019 ( .A0(cas_7_data[36]), .A1(n6078), .B0(BA_ID[3]), .B1(n5019), 
        .Y(n3007) );
  AO22X1 U6020 ( .A0(cas_7_data[35]), .A1(n5644), .B0(BA_ID[2]), .B1(n5019), 
        .Y(n3008) );
  AO22X1 U6021 ( .A0(cas_7_data[34]), .A1(n6079), .B0(BA_ID[1]), .B1(n5019), 
        .Y(n3009) );
  AO22X1 U6022 ( .A0(cas_7_data[33]), .A1(n6078), .B0(BA_ID[0]), .B1(n5019), 
        .Y(n3010) );
  AO22X1 U6023 ( .A0(cas_7_data[16]), .A1(n6078), .B0(BA_CA[9]), .B1(n5019), 
        .Y(n3027) );
  AO22X1 U6024 ( .A0(cas_7_data[15]), .A1(n6078), .B0(BA_CA[8]), .B1(n5019), 
        .Y(n3028) );
  AO22X1 U6025 ( .A0(cas_7_data[14]), .A1(n5644), .B0(BA_CA[7]), .B1(n5019), 
        .Y(n3029) );
  AO22X1 U6026 ( .A0(cas_7_data[13]), .A1(n5644), .B0(BA_CA[6]), .B1(n5019), 
        .Y(n3030) );
  AO22X1 U6027 ( .A0(cas_7_data[12]), .A1(n6078), .B0(BA_CA[5]), .B1(n5019), 
        .Y(n3031) );
  AO22X1 U6028 ( .A0(cas_7_data[11]), .A1(n5644), .B0(BA_CA[4]), .B1(n5019), 
        .Y(n3032) );
  AO22X1 U6029 ( .A0(cas_7_data[10]), .A1(n6078), .B0(BA_CA[3]), .B1(n5019), 
        .Y(n3033) );
  AO22X1 U6030 ( .A0(cas_7_data[9]), .A1(n6078), .B0(BA_CA[2]), .B1(n5019), 
        .Y(n3034) );
  AO22X1 U6031 ( .A0(cas_7_data[8]), .A1(n5644), .B0(BA_CA[1]), .B1(n5019), 
        .Y(n3035) );
  AOI32X1 U6032 ( .A0(n5157), .A1(n5158), .A2(n5159), .B0(cas_5_newrow), .B1(
        n5160), .Y(n5156) );
  NAND2BX1 U6033 ( .AN(n5681), .B(n5161), .Y(n6115) );
  AOI32X1 U6034 ( .A0(n5215), .A1(n5216), .A2(n5159), .B0(cas_4_newrow), .B1(
        n5217), .Y(n5214) );
  NAND2BX1 U6035 ( .AN(n5228), .B(n6106), .Y(n6109) );
  NOR3X1 U6036 ( .A(n5570), .B(n6029), .C(n6030), .Y(n6028) );
  XNOR2X1 U6037 ( .A(n5114), .B(B1_LAST_RA[7]), .Y(n6029) );
  XNOR2X1 U6038 ( .A(n5117), .B(B1_LAST_RA[8]), .Y(n6030) );
  XNOR2X1 U6039 ( .A(n5114), .B(B0_LAST_RA[7]), .Y(n6032) );
  XNOR2X1 U6040 ( .A(n5117), .B(B0_LAST_RA[8]), .Y(n6033) );
  NOR3X1 U6041 ( .A(n5566), .B(n6035), .C(n6036), .Y(n6034) );
  XNOR2X1 U6042 ( .A(n5105), .B(B1_LAST_RA[4]), .Y(n6035) );
  XNOR2X1 U6043 ( .A(n5108), .B(B1_LAST_RA[5]), .Y(n6036) );
  NOR3X1 U6044 ( .A(n5550), .B(n6038), .C(n6039), .Y(n6037) );
  XNOR2X1 U6045 ( .A(n5105), .B(B0_LAST_RA[4]), .Y(n6038) );
  XNOR2X1 U6046 ( .A(n5108), .B(B0_LAST_RA[5]), .Y(n6039) );
  OAI221X1 U6047 ( .A0(n5749), .A1(n5449), .B0(n5862), .B1(n5451), .C0(n5476), 
        .Y(n5396) );
  AOI222X1 U6048 ( .A0(n6014), .A1(n5477), .B0(n5454), .B1(cas_cnt_b0_pos_0_), 
        .C0(n5455), .C1(cas_cnt_b2_pos_0_), .Y(n5476) );
  AO21X1 U6049 ( .A0(cas_1_final), .A1(n5388), .B0(n5389), .Y(n3140) );
  OAI31X1 U6050 ( .A0(n5388), .A1(n5968), .A2(n5391), .B0(n6066), .Y(n5389) );
  INVX1 U6051 ( .A(n5394), .Y(n5388) );
  AO21X1 U6052 ( .A0(cas_2_final), .A1(n5334), .B0(n5335), .Y(n3179) );
  OAI31X1 U6053 ( .A0(n5334), .A1(n5966), .A2(n5337), .B0(n5338), .Y(n5335) );
  INVX1 U6054 ( .A(n5340), .Y(n5334) );
  AO21X1 U6055 ( .A0(cas_5_final), .A1(n5164), .B0(n5165), .Y(n3296) );
  OAI31X1 U6056 ( .A0(n5164), .A1(n5967), .A2(n5167), .B0(n5708), .Y(n5165) );
  INVX1 U6057 ( .A(n5170), .Y(n5164) );
  OAI31X1 U6058 ( .A0(n5280), .A1(n5866), .A2(n5281), .B0(n5282), .Y(n3218) );
  INVX1 U6059 ( .A(n5283), .Y(n5280) );
  INVX1 U6060 ( .A(n5276), .Y(n5281) );
  OAI31X1 U6061 ( .A0(n5016), .A1(n5025), .A2(n5026), .B0(n5027), .Y(n3336) );
  OAI31X1 U6062 ( .A0(n5273), .A1(n5274), .A2(n5018), .B0(n5275), .Y(n3219) );
  AOI22X1 U6063 ( .A0(cas_cnt_4_), .A1(n5661), .B0(cas_cnt1375_4_), .B1(n5659), 
        .Y(n6040) );
  XOR2X1 U6064 ( .A(n5096), .B(B3_LAST_RA[1]), .Y(n5534) );
  OAI222X1 U6065 ( .A0(n5964), .A1(n5637), .B0(n5437), .B1(n5638), .C0(n6063), 
        .C1(n5639), .Y(n3047) );
  OAI222X1 U6066 ( .A0(n5965), .A1(n5623), .B0(n5437), .B1(n5624), .C0(n6065), 
        .C1(n5625), .Y(n3057) );
  OAI222X1 U6067 ( .A0(n5961), .A1(n5637), .B0(n5211), .B1(n5638), .C0(
        cas_cnt_b0_pos_0_), .C1(n5639), .Y(n3048) );
  OAI222X1 U6068 ( .A0(n5749), .A1(n5631), .B0(n5211), .B1(n5632), .C0(
        cas_cnt_b1_pos_0_), .C1(n5633), .Y(n3053) );
  OAI222X1 U6069 ( .A0(n5962), .A1(n5623), .B0(n5211), .B1(n5624), .C0(
        cas_cnt_b2_pos_0_), .C1(n5625), .Y(n3058) );
  OAI222X1 U6070 ( .A0(n5862), .A1(n5613), .B0(n5211), .B1(n5614), .C0(
        cas_cnt_b3_pos_0_), .C1(n5615), .Y(n3063) );
  XNOR2X1 U1_A_14 ( .A(cas_cnt_1_), .B(cas_cnt_0_), .Y(cas_cnt1375_1_) );
  XNOR2X1 U1_A_34 ( .A(cas_cnt_3_), .B(carry), .Y(cas_cnt1375_3_) );
  XNOR2X1 U1_A_24 ( .A(cas_cnt_2_), .B(carry0), .Y(cas_cnt1375_2_) );
  XOR2X1 U6071 ( .A(cas_cnt_b0_pos_3_), .B(carry_3_), .Y(n6041) );
  XOR2X1 U6072 ( .A(cas_cnt_b3_pos_3_), .B(carry3), .Y(n6042) );
  XOR2X1 U6073 ( .A(cas_cnt_b3_pos_2_), .B(carry4), .Y(n6043) );
  OR2X1 U1_B_1 ( .A(cas_cnt_b0_pos_1_), .B(cas_cnt_b0_pos_0_), .Y(carry_2_) );
  OR2X1 U1_B_12 ( .A(cas_cnt_b2_pos_1_), .B(cas_cnt_b2_pos_0_), .Y(carry6) );
  OR2X1 U1_B_11 ( .A(cas_cnt_b1_pos_1_), .B(cas_cnt_b1_pos_0_), .Y(carry8) );
  OR2X1 U1_B_13 ( .A(cas_cnt_b3_pos_1_), .B(cas_cnt_b3_pos_0_), .Y(carry4) );
  OR2X1 U1_B_14 ( .A(cas_cnt_1_), .B(cas_cnt_0_), .Y(carry0) );
  OR2X1 U1_B_2 ( .A(cas_cnt_b0_pos_2_), .B(carry_2_), .Y(carry_3_) );
  OR2X1 U1_B_22 ( .A(cas_cnt_b2_pos_2_), .B(carry6), .Y(carry5) );
  OR2X1 U1_B_21 ( .A(cas_cnt_b1_pos_2_), .B(carry8), .Y(carry7) );
  OR2X1 U1_B_23 ( .A(cas_cnt_b3_pos_2_), .B(carry4), .Y(carry3) );
  OR2X1 U1_B_24 ( .A(cas_cnt_2_), .B(carry0), .Y(carry) );
  XOR2X1 U6074 ( .A(n6045), .B(n6046), .Y(n6044) );
  NOR2X1 U6075 ( .A(cas_cnt_b0_pos_3_), .B(carry_3_), .Y(n6046) );
  XOR2X1 U6076 ( .A(n6048), .B(n6049), .Y(n6047) );
  NOR2X1 U6077 ( .A(cas_cnt_b3_pos_3_), .B(carry3), .Y(n6049) );
  XOR2X1 U6078 ( .A(cas_cnt_b2_pos_3_), .B(carry5), .Y(n6050) );
  XOR2X1 U6079 ( .A(cas_cnt_b1_pos_3_), .B(carry7), .Y(n6051) );
  XOR2X1 U6080 ( .A(cas_cnt_b2_pos_2_), .B(carry6), .Y(n6052) );
  XOR2X1 U6081 ( .A(cas_cnt_4_), .B(n6053), .Y(cas_cnt1375_4_) );
  NOR2X1 U6082 ( .A(cas_cnt_3_), .B(carry), .Y(n6053) );
  XOR2X1 U6083 ( .A(n6055), .B(n6056), .Y(n6054) );
  NOR2X1 U6084 ( .A(cas_cnt_b1_pos_3_), .B(carry7), .Y(n6056) );
  XOR2X1 U6085 ( .A(n6058), .B(n6059), .Y(n6057) );
  NOR2X1 U6086 ( .A(cas_cnt_b2_pos_3_), .B(carry5), .Y(n6059) );
  XOR2X1 U6087 ( .A(cas_cnt_b3_pos_1_), .B(cas_cnt_b3_pos_0_), .Y(n6060) );
  XOR2X1 U6088 ( .A(cas_cnt_b1_pos_2_), .B(carry8), .Y(n6061) );
  XOR2X1 U6089 ( .A(cas_cnt_b1_pos_1_), .B(cas_cnt_b1_pos_0_), .Y(n6062) );
  XOR2X1 U6090 ( .A(cas_cnt_b0_pos_1_), .B(cas_cnt_b0_pos_0_), .Y(n6063) );
  XOR2X1 U6091 ( .A(cas_cnt_b0_pos_2_), .B(carry_2_), .Y(n6064) );
  XOR2X1 U6092 ( .A(cas_cnt_b2_pos_1_), .B(cas_cnt_b2_pos_0_), .Y(n6065) );
  DFFRX1 CAS_0_TT_reg_4_ ( .D(n3090), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_TT[4]), 
        .QN(n3006) );
  DFFSX1 cas_cnt_b0_pos_reg_0_ ( .D(n3048), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b0_pos_0_), .QN(n5961) );
  DFFSX1 cas_cnt_b2_pos_reg_0_ ( .D(n3058), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b2_pos_0_), .QN(n5962) );
  DFFSX1 cas_cnt_b1_pos_reg_0_ ( .D(n3053), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b1_pos_0_), .QN(n5749) );
  DFFSX1 cas_cnt_b3_pos_reg_0_ ( .D(n3063), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b3_pos_0_), .QN(n5862) );
  DFFSX1 cas_cnt_b0_pos_reg_1_ ( .D(n3047), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b0_pos_1_), .QN(n5964) );
  DFFSX1 cas_cnt_b2_pos_reg_1_ ( .D(n3057), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b2_pos_1_), .QN(n5965) );
  DFFSX1 cas_cnt_b1_pos_reg_1_ ( .D(n3052), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b1_pos_1_), .QN(n5863) );
  DFFSX1 cas_cnt_b3_pos_reg_1_ ( .D(n3062), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b3_pos_1_), .QN(n5750) );
  DFFSX1 cas_cnt_b0_pos_reg_2_ ( .D(n3046), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b0_pos_2_), .QN(n5864) );
  DFFSX1 cas_cnt_b2_pos_reg_2_ ( .D(n3056), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b2_pos_2_), .QN(n5865) );
  DFFRX1 cas_cnt_reg_0_ ( .D(n429_0_), .CK(ACLK), .RN(ARESETB), .Q(cas_cnt_0_), 
        .QN(n5963) );
  DFFSX1 cas_cnt_b1_pos_reg_3_ ( .D(n3050), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b1_pos_3_), .QN(n5747) );
  DFFSX1 cas_cnt_b1_pos_reg_2_ ( .D(n3051), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b1_pos_2_), .QN(n5861) );
  DFFSX1 cas_cnt_b2_pos_reg_3_ ( .D(n3055), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b2_pos_3_), .QN(n5718) );
  DFFSX1 cas_cnt_b3_pos_reg_2_ ( .D(n3061), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b3_pos_2_), .QN(n5748) );
  DFFRX1 cas_cnt_reg_3_ ( .D(n429_3_), .CK(ACLK), .RN(ARESETB), .Q(cas_cnt_3_), 
        .QN(n5857) );
  DFFRX1 cas_cnt_reg_2_ ( .D(n429_2_), .CK(ACLK), .RN(ARESETB), .Q(cas_cnt_2_), 
        .QN(n5858) );
  DFFRX1 cas_cnt_reg_1_ ( .D(n429_1_), .CK(ACLK), .RN(ARESETB), .Q(cas_cnt_1_), 
        .QN(n5859) );
  DFFRX1 cas_cnt_reg_4_ ( .D(n429_4_), .CK(ACLK), .RN(ARESETB), .Q(cas_cnt_4_), 
        .QN(n5860) );
  DFFSX1 cas_cnt_b0_pos_reg_3_ ( .D(n3045), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b0_pos_3_), .QN(n5745) );
  DFFSX1 cas_cnt_b3_pos_reg_3_ ( .D(n3060), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b3_pos_3_), .QN(n5746) );
  DFFSX1 cas_cnt_b2_pos_reg_4_ ( .D(n3054), .CK(ACLK), .SN(ARESETB), .Q(
        cas_cnt_b2_pos_4_), .QN(n6058) );
  DFFSX1 cas_cnt_b0_pos_reg_4_ ( .D(n3044), .CK(ACLK), .SN(ARESETB), .QN(n6045) );
  DFFSX1 cas_cnt_b1_pos_reg_4_ ( .D(n3049), .CK(ACLK), .SN(ARESETB), .QN(n6055) );
  DFFSX1 cas_cnt_b3_pos_reg_4_ ( .D(n3059), .CK(ACLK), .SN(ARESETB), .QN(n6048) );
  DFFRX1 cas_7_newrow_reg ( .D(n3338), .CK(ACLK), .RN(ARESETB), .QN(n5855) );
  DFFRX1 cas_7_data_reg_36_ ( .D(n3007), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[36]), .QN(n5992) );
  DFFRX1 cas_7_data_reg_35_ ( .D(n3008), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[35]), .QN(n5978) );
  DFFRX1 cas_7_data_reg_34_ ( .D(n3009), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[34]), .QN(n5979) );
  DFFRX1 cas_7_data_reg_33_ ( .D(n3010), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[33]), .QN(n5993) );
  DFFRX1 cas_7_data_reg_29_ ( .D(n3014), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[29]), .QN(n5975) );
  DFFRX1 cas_7_data_reg_27_ ( .D(n3016), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[27]), .QN(n6003) );
  DFFRX1 cas_7_data_reg_26_ ( .D(n3017), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[26]), .QN(n5973) );
  DFFRX1 cas_7_data_reg_25_ ( .D(n3018), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[25]), .QN(n5997) );
  DFFRX1 cas_7_data_reg_24_ ( .D(n3019), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[24]), .QN(n5984) );
  DFFRX1 cas_7_data_reg_23_ ( .D(n3020), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[23]), .QN(n6000) );
  DFFRX1 cas_7_data_reg_22_ ( .D(n3021), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[22]), .QN(n6006) );
  DFFRX1 cas_7_data_reg_21_ ( .D(n3022), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[21]), .QN(n5985) );
  DFFRX1 cas_7_data_reg_20_ ( .D(n3023), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[20]), .QN(n5976) );
  DFFRX1 cas_7_data_reg_19_ ( .D(n3024), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[19]), .QN(n5974) );
  DFFRX1 cas_7_data_reg_18_ ( .D(n3025), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[18]), .QN(n5986) );
  DFFRX1 cas_7_data_reg_17_ ( .D(n3026), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[17]), .QN(n5989) );
  DFFRX1 cas_7_data_reg_16_ ( .D(n3027), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[16]), .QN(n5983) );
  DFFRX1 cas_7_data_reg_15_ ( .D(n3028), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[15]), .QN(n6002) );
  DFFRX1 cas_7_data_reg_14_ ( .D(n3029), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[14]), .QN(n5994) );
  DFFRX1 cas_7_data_reg_13_ ( .D(n3030), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[13]), .QN(n5980) );
  DFFRX1 cas_7_data_reg_12_ ( .D(n3031), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[12]), .QN(n5981) );
  DFFRX1 cas_7_data_reg_11_ ( .D(n3032), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[11]), .QN(n6004) );
  DFFRX1 cas_7_data_reg_10_ ( .D(n3033), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[10]), .QN(n6001) );
  DFFRX1 cas_7_data_reg_9_ ( .D(n3034), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[9]), .QN(n5982) );
  DFFRX1 cas_7_data_reg_8_ ( .D(n3035), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[8]), .QN(n5995) );
  DFFRX1 cas_7_data_reg_7_ ( .D(n3036), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[7]), .QN(n5977) );
  DFFRX1 cas_7_data_reg_6_ ( .D(n3037), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[6]), .QN(n5969) );
  DFFRX1 cas_7_data_reg_5_ ( .D(n3038), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[5]), .QN(n5990) );
  DFFRX1 cas_7_data_reg_4_ ( .D(n3039), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[4]), .QN(n5970) );
  DFFRX1 cas_7_data_reg_3_ ( .D(n3040), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[3]), .QN(n5971) );
  DFFRX1 cas_7_data_reg_2_ ( .D(n3041), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[2]), .QN(n5972) );
  DFFRX1 cas_7_data_reg_1_ ( .D(n3042), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[1]), .QN(n5991) );
  DFFRX1 cas_7_data_reg_0_ ( .D(n3043), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[0]), .QN(n5988) );
  DFFRX1 cas_2_final_reg ( .D(n3179), .CK(ACLK), .RN(ARESETB), .Q(cas_2_final), 
        .QN(n5968) );
  DFFRX1 cas_3_final_reg ( .D(n3218), .CK(ACLK), .RN(ARESETB), .Q(cas_3_final), 
        .QN(n5966) );
  DFFRX1 cas_6_newrow_reg ( .D(n3336), .CK(ACLK), .RN(ARESETB), .QN(n6020) );
  DFFRX1 cas_4_newrow_reg ( .D(n3258), .CK(ACLK), .RN(ARESETB), .Q(
        cas_4_newrow), .QN(n6007) );
  DFFRX1 cas_6_final_reg ( .D(n3335), .CK(ACLK), .RN(ARESETB), .Q(cas_6_final), 
        .QN(n5967) );
  DFFRX1 cas_7_data_reg_32_ ( .D(n3011), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[32]), .QN(n5999) );
  DFFRX1 cas_7_data_reg_31_ ( .D(n3012), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[31]), .QN(n5987) );
  DFFRX1 cas_7_data_reg_30_ ( .D(n3013), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[30]), .QN(n6005) );
  DFFRX1 cas_7_data_reg_28_ ( .D(n3015), .CK(ACLK), .RN(ARESETB), .Q(
        cas_7_data[28]), .QN(n5996) );
  DFFRX1 cas_4_final_reg ( .D(n3257), .CK(ACLK), .RN(ARESETB), .QN(n5866) );
  DFFRX1 cas_1_data_reg_36_ ( .D(n3103), .CK(ACLK), .RN(ARESETB), .QN(n5758)
         );
  DFFRX1 cas_1_data_reg_35_ ( .D(n3104), .CK(ACLK), .RN(ARESETB), .QN(n5933)
         );
  DFFRX1 cas_1_data_reg_34_ ( .D(n3105), .CK(ACLK), .RN(ARESETB), .QN(n5934)
         );
  DFFRX1 cas_1_data_reg_33_ ( .D(n3106), .CK(ACLK), .RN(ARESETB), .QN(n5759)
         );
  DFFRX1 cas_1_data_reg_32_ ( .D(n3107), .CK(ACLK), .RN(ARESETB), .QN(n5913)
         );
  DFFRX1 cas_1_data_reg_31_ ( .D(n3108), .CK(ACLK), .RN(ARESETB), .QN(n5914)
         );
  DFFRX1 cas_1_data_reg_30_ ( .D(n3109), .CK(ACLK), .RN(ARESETB), .QN(n5751)
         );
  DFFRX1 cas_1_data_reg_29_ ( .D(n3110), .CK(ACLK), .RN(ARESETB), .QN(n5915)
         );
  DFFRX1 cas_1_data_reg_28_ ( .D(n3111), .CK(ACLK), .RN(ARESETB), .QN(n5752)
         );
  DFFRX1 cas_1_data_reg_27_ ( .D(n3112), .CK(ACLK), .RN(ARESETB), .QN(n5911)
         );
  DFFRX1 cas_1_data_reg_26_ ( .D(n3113), .CK(ACLK), .RN(ARESETB), .QN(n5916)
         );
  DFFRX1 cas_1_data_reg_25_ ( .D(n3114), .CK(ACLK), .RN(ARESETB), .QN(n5753)
         );
  DFFRX1 cas_1_data_reg_24_ ( .D(n3115), .CK(ACLK), .RN(ARESETB), .QN(n5912)
         );
  DFFRX1 cas_1_data_reg_23_ ( .D(n3116), .CK(ACLK), .RN(ARESETB), .QN(n5917)
         );
  DFFRX1 cas_1_data_reg_22_ ( .D(n3117), .CK(ACLK), .RN(ARESETB), .QN(n5754)
         );
  DFFRX1 cas_1_data_reg_21_ ( .D(n3118), .CK(ACLK), .RN(ARESETB), .QN(n5918)
         );
  DFFRX1 cas_1_data_reg_20_ ( .D(n3119), .CK(ACLK), .RN(ARESETB), .QN(n5919)
         );
  DFFRX1 cas_1_data_reg_19_ ( .D(n3120), .CK(ACLK), .RN(ARESETB), .QN(n5920)
         );
  DFFRX1 cas_1_data_reg_18_ ( .D(n3121), .CK(ACLK), .RN(ARESETB), .QN(n5921)
         );
  DFFRX1 cas_1_data_reg_17_ ( .D(n3122), .CK(ACLK), .RN(ARESETB), .QN(n5867)
         );
  DFFRX1 cas_1_data_reg_16_ ( .D(n3123), .CK(ACLK), .RN(ARESETB), .QN(n5922)
         );
  DFFRX1 cas_1_data_reg_15_ ( .D(n3124), .CK(ACLK), .RN(ARESETB), .QN(n5923)
         );
  DFFRX1 cas_1_data_reg_14_ ( .D(n3125), .CK(ACLK), .RN(ARESETB), .QN(n5755)
         );
  DFFRX1 cas_1_data_reg_13_ ( .D(n3126), .CK(ACLK), .RN(ARESETB), .QN(n5924)
         );
  DFFRX1 cas_1_data_reg_12_ ( .D(n3127), .CK(ACLK), .RN(ARESETB), .QN(n5925)
         );
  DFFRX1 cas_1_data_reg_11_ ( .D(n3128), .CK(ACLK), .RN(ARESETB), .QN(n5868)
         );
  DFFRX1 cas_1_data_reg_10_ ( .D(n3129), .CK(ACLK), .RN(ARESETB), .QN(n5926)
         );
  DFFRX1 cas_1_data_reg_9_ ( .D(n3130), .CK(ACLK), .RN(ARESETB), .QN(n5927) );
  DFFRX1 cas_1_data_reg_8_ ( .D(n3131), .CK(ACLK), .RN(ARESETB), .QN(n5756) );
  DFFRX1 cas_1_data_reg_7_ ( .D(n3132), .CK(ACLK), .RN(ARESETB), .QN(n5928) );
  DFFRX1 cas_1_data_reg_6_ ( .D(n3133), .CK(ACLK), .RN(ARESETB), .QN(n5929) );
  DFFRX1 cas_1_data_reg_5_ ( .D(n3134), .CK(ACLK), .RN(ARESETB), .QN(n5757) );
  DFFRX1 cas_1_data_reg_4_ ( .D(n3135), .CK(ACLK), .RN(ARESETB), .QN(n5930) );
  DFFRX1 cas_1_data_reg_3_ ( .D(n3136), .CK(ACLK), .RN(ARESETB), .QN(n5931) );
  DFFRX1 cas_1_data_reg_2_ ( .D(n3137), .CK(ACLK), .RN(ARESETB), .QN(n5932) );
  DFFRX1 cas_1_data_reg_1_ ( .D(n3138), .CK(ACLK), .RN(ARESETB), .QN(n5760) );
  DFFRX1 cas_1_data_reg_0_ ( .D(n3139), .CK(ACLK), .RN(ARESETB), .QN(n5935) );
  DFFRX1 cas_1_newrow_reg ( .D(n3141), .CK(ACLK), .RN(ARESETB), .QN(n5854) );
  DFFRX1 cas_2_data_reg_36_ ( .D(n3142), .CK(ACLK), .RN(ARESETB), .QN(n5938)
         );
  DFFRX1 cas_2_data_reg_35_ ( .D(n3143), .CK(ACLK), .RN(ARESETB), .QN(n5781)
         );
  DFFRX1 cas_2_data_reg_34_ ( .D(n3144), .CK(ACLK), .RN(ARESETB), .QN(n5782)
         );
  DFFRX1 cas_2_data_reg_33_ ( .D(n3145), .CK(ACLK), .RN(ARESETB), .QN(n5939)
         );
  DFFRX1 cas_2_data_reg_32_ ( .D(n3146), .CK(ACLK), .RN(ARESETB), .QN(n5783)
         );
  DFFRX1 cas_2_data_reg_31_ ( .D(n3147), .CK(ACLK), .RN(ARESETB), .QN(n5784)
         );
  DFFRX1 cas_2_data_reg_30_ ( .D(n3148), .CK(ACLK), .RN(ARESETB), .QN(n5940)
         );
  DFFRX1 cas_2_data_reg_29_ ( .D(n3149), .CK(ACLK), .RN(ARESETB), .QN(n5728)
         );
  DFFRX1 cas_2_data_reg_28_ ( .D(n3150), .CK(ACLK), .RN(ARESETB), .QN(n5948)
         );
  DFFRX1 cas_2_data_reg_27_ ( .D(n3151), .CK(ACLK), .RN(ARESETB), .QN(n5719)
         );
  DFFRX1 cas_2_data_reg_26_ ( .D(n3152), .CK(ACLK), .RN(ARESETB), .QN(n5785)
         );
  DFFRX1 cas_2_data_reg_25_ ( .D(n3153), .CK(ACLK), .RN(ARESETB), .QN(n5949)
         );
  DFFRX1 cas_2_data_reg_24_ ( .D(n3154), .CK(ACLK), .RN(ARESETB), .QN(n5765)
         );
  DFFRX1 cas_2_data_reg_23_ ( .D(n3155), .CK(ACLK), .RN(ARESETB), .QN(n5786)
         );
  DFFRX1 cas_2_data_reg_22_ ( .D(n3156), .CK(ACLK), .RN(ARESETB), .QN(n5950)
         );
  DFFRX1 cas_2_data_reg_21_ ( .D(n3157), .CK(ACLK), .RN(ARESETB), .QN(n5766)
         );
  DFFRX1 cas_2_data_reg_20_ ( .D(n3158), .CK(ACLK), .RN(ARESETB), .QN(n5720)
         );
  DFFRX1 cas_2_data_reg_19_ ( .D(n3159), .CK(ACLK), .RN(ARESETB), .QN(n5729)
         );
  DFFRX1 cas_2_data_reg_18_ ( .D(n3160), .CK(ACLK), .RN(ARESETB), .QN(n5767)
         );
  DFFRX1 cas_2_data_reg_17_ ( .D(n3161), .CK(ACLK), .RN(ARESETB), .QN(n5829)
         );
  DFFRX1 cas_2_data_reg_16_ ( .D(n3162), .CK(ACLK), .RN(ARESETB), .QN(n5787)
         );
  DFFRX1 cas_2_data_reg_15_ ( .D(n3163), .CK(ACLK), .RN(ARESETB), .QN(n5768)
         );
  DFFRX1 cas_2_data_reg_14_ ( .D(n3164), .CK(ACLK), .RN(ARESETB), .QN(n5941)
         );
  DFFRX1 cas_2_data_reg_13_ ( .D(n3165), .CK(ACLK), .RN(ARESETB), .QN(n5788)
         );
  DFFRX1 cas_2_data_reg_12_ ( .D(n3166), .CK(ACLK), .RN(ARESETB), .QN(n5721)
         );
  DFFRX1 cas_2_data_reg_11_ ( .D(n3167), .CK(ACLK), .RN(ARESETB), .QN(n5830)
         );
  DFFRX1 cas_2_data_reg_10_ ( .D(n3168), .CK(ACLK), .RN(ARESETB), .QN(n5730)
         );
  DFFRX1 cas_2_data_reg_9_ ( .D(n3169), .CK(ACLK), .RN(ARESETB), .QN(n5761) );
  DFFRX1 cas_2_data_reg_8_ ( .D(n3170), .CK(ACLK), .RN(ARESETB), .QN(n5942) );
  DFFRX1 cas_2_data_reg_7_ ( .D(n3171), .CK(ACLK), .RN(ARESETB), .QN(n5789) );
  DFFRX1 cas_2_data_reg_6_ ( .D(n3172), .CK(ACLK), .RN(ARESETB), .QN(n5769) );
  DFFRX1 cas_2_data_reg_5_ ( .D(n3173), .CK(ACLK), .RN(ARESETB), .QN(n5936) );
  DFFRX1 cas_2_data_reg_4_ ( .D(n3174), .CK(ACLK), .RN(ARESETB), .QN(n5790) );
  DFFRX1 cas_2_data_reg_3_ ( .D(n3175), .CK(ACLK), .RN(ARESETB), .QN(n5722) );
  DFFRX1 cas_2_data_reg_2_ ( .D(n3176), .CK(ACLK), .RN(ARESETB), .QN(n5723) );
  DFFRX1 cas_2_data_reg_1_ ( .D(n3177), .CK(ACLK), .RN(ARESETB), .QN(n5953) );
  DFFRX1 cas_2_data_reg_0_ ( .D(n3178), .CK(ACLK), .RN(ARESETB), .QN(n5762) );
  DFFRX1 cas_2_newrow_reg ( .D(n3180), .CK(ACLK), .RN(ARESETB), .QN(n5998) );
  DFFRX1 cas_3_data_reg_36_ ( .D(n3181), .CK(ACLK), .RN(ARESETB), .QN(n5824)
         );
  DFFRX1 cas_3_data_reg_35_ ( .D(n3182), .CK(ACLK), .RN(ARESETB), .QN(n5899)
         );
  DFFRX1 cas_3_data_reg_34_ ( .D(n3183), .CK(ACLK), .RN(ARESETB), .QN(n5900)
         );
  DFFRX1 cas_3_data_reg_33_ ( .D(n3184), .CK(ACLK), .RN(ARESETB), .QN(n5825)
         );
  DFFRX1 cas_3_data_reg_32_ ( .D(n3185), .CK(ACLK), .RN(ARESETB), .QN(n5901)
         );
  DFFRX1 cas_3_data_reg_31_ ( .D(n3186), .CK(ACLK), .RN(ARESETB), .QN(n5897)
         );
  DFFRX1 cas_3_data_reg_30_ ( .D(n3187), .CK(ACLK), .RN(ARESETB), .QN(n5850)
         );
  DFFRX1 cas_3_data_reg_29_ ( .D(n3188), .CK(ACLK), .RN(ARESETB), .QN(n5794)
         );
  DFFRX1 cas_3_data_reg_28_ ( .D(n3189), .CK(ACLK), .RN(ARESETB), .QN(n5831)
         );
  DFFRX1 cas_3_data_reg_27_ ( .D(n3190), .CK(ACLK), .RN(ARESETB), .QN(n5770)
         );
  DFFRX1 cas_3_data_reg_26_ ( .D(n3191), .CK(ACLK), .RN(ARESETB), .QN(n5902)
         );
  DFFRX1 cas_3_data_reg_25_ ( .D(n3192), .CK(ACLK), .RN(ARESETB), .QN(n5832)
         );
  DFFRX1 cas_3_data_reg_24_ ( .D(n3193), .CK(ACLK), .RN(ARESETB), .QN(n5878)
         );
  DFFRX1 cas_3_data_reg_23_ ( .D(n3194), .CK(ACLK), .RN(ARESETB), .QN(n5898)
         );
  DFFRX1 cas_3_data_reg_22_ ( .D(n3195), .CK(ACLK), .RN(ARESETB), .QN(n5833)
         );
  DFFRX1 cas_3_data_reg_21_ ( .D(n3196), .CK(ACLK), .RN(ARESETB), .QN(n5879)
         );
  DFFRX1 cas_3_data_reg_20_ ( .D(n3197), .CK(ACLK), .RN(ARESETB), .QN(n5796)
         );
  DFFRX1 cas_3_data_reg_19_ ( .D(n3198), .CK(ACLK), .RN(ARESETB), .QN(n5797)
         );
  DFFRX1 cas_3_data_reg_18_ ( .D(n3199), .CK(ACLK), .RN(ARESETB), .QN(n5880)
         );
  DFFRX1 cas_3_data_reg_17_ ( .D(n3200), .CK(ACLK), .RN(ARESETB), .QN(n5951)
         );
  DFFRX1 cas_3_data_reg_16_ ( .D(n3201), .CK(ACLK), .RN(ARESETB), .QN(n5903)
         );
  DFFRX1 cas_3_data_reg_15_ ( .D(n3202), .CK(ACLK), .RN(ARESETB), .QN(n5881)
         );
  DFFRX1 cas_3_data_reg_14_ ( .D(n3203), .CK(ACLK), .RN(ARESETB), .QN(n5834)
         );
  DFFRX1 cas_3_data_reg_13_ ( .D(n3204), .CK(ACLK), .RN(ARESETB), .QN(n5904)
         );
  DFFRX1 cas_3_data_reg_12_ ( .D(n3205), .CK(ACLK), .RN(ARESETB), .QN(n5776)
         );
  DFFRX1 cas_3_data_reg_11_ ( .D(n3206), .CK(ACLK), .RN(ARESETB), .QN(n5952)
         );
  DFFRX1 cas_3_data_reg_10_ ( .D(n3207), .CK(ACLK), .RN(ARESETB), .QN(n5800)
         );
  DFFRX1 cas_3_data_reg_9_ ( .D(n3208), .CK(ACLK), .RN(ARESETB), .QN(n5871) );
  DFFRX1 cas_3_data_reg_8_ ( .D(n3209), .CK(ACLK), .RN(ARESETB), .QN(n5828) );
  DFFRX1 cas_3_data_reg_7_ ( .D(n3210), .CK(ACLK), .RN(ARESETB), .QN(n5905) );
  DFFRX1 cas_3_data_reg_6_ ( .D(n3211), .CK(ACLK), .RN(ARESETB), .QN(n5882) );
  DFFRX1 cas_3_data_reg_5_ ( .D(n3212), .CK(ACLK), .RN(ARESETB), .QN(n5823) );
  DFFRX1 cas_3_data_reg_4_ ( .D(n3213), .CK(ACLK), .RN(ARESETB), .QN(n5906) );
  DFFRX1 cas_3_data_reg_3_ ( .D(n3214), .CK(ACLK), .RN(ARESETB), .QN(n5778) );
  DFFRX1 cas_3_data_reg_2_ ( .D(n3215), .CK(ACLK), .RN(ARESETB), .QN(n5779) );
  DFFRX1 cas_3_data_reg_1_ ( .D(n3216), .CK(ACLK), .RN(ARESETB), .QN(n5853) );
  DFFRX1 cas_3_data_reg_0_ ( .D(n3217), .CK(ACLK), .RN(ARESETB), .QN(n5872) );
  DFFRX1 cas_3_newrow_reg ( .D(n3219), .CK(ACLK), .RN(ARESETB), .QN(n5856) );
  DFFRX1 cas_4_data_reg_36_ ( .D(n3220), .CK(ACLK), .RN(ARESETB), .QN(n5943)
         );
  DFFRX1 cas_4_data_reg_35_ ( .D(n3221), .CK(ACLK), .RN(ARESETB), .QN(n5791)
         );
  DFFRX1 cas_4_data_reg_34_ ( .D(n3222), .CK(ACLK), .RN(ARESETB), .QN(n5792)
         );
  DFFRX1 cas_4_data_reg_33_ ( .D(n3223), .CK(ACLK), .RN(ARESETB), .QN(n5944)
         );
  DFFRX1 cas_4_data_reg_32_ ( .D(n3224), .CK(ACLK), .RN(ARESETB), .QN(n5793)
         );
  DFFRX1 cas_4_data_reg_31_ ( .D(n3225), .CK(ACLK), .RN(ARESETB), .QN(n5780)
         );
  DFFRX1 cas_4_data_reg_30_ ( .D(n3226), .CK(ACLK), .RN(ARESETB), .QN(n5958)
         );
  DFFRX1 cas_4_data_reg_29_ ( .D(n3227), .CK(ACLK), .RN(ARESETB), .QN(n5907)
         );
  DFFRX1 cas_4_data_reg_28_ ( .D(n3228), .CK(ACLK), .RN(ARESETB), .QN(n5954)
         );
  DFFRX1 cas_4_data_reg_27_ ( .D(n3229), .CK(ACLK), .RN(ARESETB), .QN(n5883)
         );
  DFFRX1 cas_4_data_reg_26_ ( .D(n3230), .CK(ACLK), .RN(ARESETB), .QN(n5795)
         );
  DFFRX1 cas_4_data_reg_25_ ( .D(n3231), .CK(ACLK), .RN(ARESETB), .QN(n5955)
         );
  DFFRX1 cas_4_data_reg_24_ ( .D(n3232), .CK(ACLK), .RN(ARESETB), .QN(n5771)
         );
  DFFRX1 cas_4_data_reg_23_ ( .D(n3233), .CK(ACLK), .RN(ARESETB), .QN(n5772)
         );
  DFFRX1 cas_4_data_reg_22_ ( .D(n3234), .CK(ACLK), .RN(ARESETB), .QN(n5956)
         );
  DFFRX1 cas_4_data_reg_21_ ( .D(n3235), .CK(ACLK), .RN(ARESETB), .QN(n5773)
         );
  DFFRX1 cas_4_data_reg_20_ ( .D(n3236), .CK(ACLK), .RN(ARESETB), .QN(n5908)
         );
  DFFRX1 cas_4_data_reg_19_ ( .D(n3237), .CK(ACLK), .RN(ARESETB), .QN(n5909)
         );
  DFFRX1 cas_4_data_reg_18_ ( .D(n3238), .CK(ACLK), .RN(ARESETB), .QN(n5774)
         );
  DFFRX1 cas_4_data_reg_17_ ( .D(n3239), .CK(ACLK), .RN(ARESETB), .QN(n5826)
         );
  DFFRX1 cas_4_data_reg_16_ ( .D(n3240), .CK(ACLK), .RN(ARESETB), .QN(n5798)
         );
  DFFRX1 cas_4_data_reg_15_ ( .D(n3241), .CK(ACLK), .RN(ARESETB), .QN(n5775)
         );
  DFFRX1 cas_4_data_reg_14_ ( .D(n3242), .CK(ACLK), .RN(ARESETB), .QN(n5957)
         );
  DFFRX1 cas_4_data_reg_13_ ( .D(n3243), .CK(ACLK), .RN(ARESETB), .QN(n5799)
         );
  DFFRX1 cas_4_data_reg_12_ ( .D(n3244), .CK(ACLK), .RN(ARESETB), .QN(n5884)
         );
  DFFRX1 cas_4_data_reg_11_ ( .D(n3245), .CK(ACLK), .RN(ARESETB), .QN(n5827)
         );
  DFFRX1 cas_4_data_reg_10_ ( .D(n3246), .CK(ACLK), .RN(ARESETB), .QN(n5910)
         );
  DFFRX1 cas_4_data_reg_9_ ( .D(n3247), .CK(ACLK), .RN(ARESETB), .QN(n5763) );
  DFFRX1 cas_4_data_reg_8_ ( .D(n3248), .CK(ACLK), .RN(ARESETB), .QN(n5945) );
  DFFRX1 cas_4_data_reg_7_ ( .D(n3249), .CK(ACLK), .RN(ARESETB), .QN(n5801) );
  DFFRX1 cas_4_data_reg_6_ ( .D(n3250), .CK(ACLK), .RN(ARESETB), .QN(n5777) );
  DFFRX1 cas_4_data_reg_5_ ( .D(n3251), .CK(ACLK), .RN(ARESETB), .QN(n5937) );
  DFFRX1 cas_4_data_reg_4_ ( .D(n3252), .CK(ACLK), .RN(ARESETB), .QN(n5802) );
  DFFRX1 cas_4_data_reg_3_ ( .D(n3253), .CK(ACLK), .RN(ARESETB), .QN(n5885) );
  DFFRX1 cas_4_data_reg_2_ ( .D(n3254), .CK(ACLK), .RN(ARESETB), .QN(n5886) );
  DFFRX1 cas_4_data_reg_1_ ( .D(n3255), .CK(ACLK), .RN(ARESETB), .QN(n5959) );
  DFFRX1 cas_4_data_reg_0_ ( .D(n3256), .CK(ACLK), .RN(ARESETB), .QN(n5764) );
  DFFRX1 cas_5_data_reg_36_ ( .D(n3259), .CK(ACLK), .RN(ARESETB), .QN(n5736)
         );
  DFFRX1 cas_5_data_reg_35_ ( .D(n3260), .CK(ACLK), .RN(ARESETB), .QN(n5888)
         );
  DFFRX1 cas_5_data_reg_34_ ( .D(n3261), .CK(ACLK), .RN(ARESETB), .QN(n5887)
         );
  DFFRX1 cas_5_data_reg_33_ ( .D(n3262), .CK(ACLK), .RN(ARESETB), .QN(n5737)
         );
  DFFRX1 cas_5_data_reg_32_ ( .D(n3263), .CK(ACLK), .RN(ARESETB), .QN(n5889)
         );
  DFFRX1 cas_5_data_reg_31_ ( .D(n3264), .CK(ACLK), .RN(ARESETB), .QN(n5890)
         );
  DFFRX1 cas_5_data_reg_30_ ( .D(n3265), .CK(ACLK), .RN(ARESETB), .QN(n5738)
         );
  DFFRX1 cas_5_data_reg_29_ ( .D(n3266), .CK(ACLK), .RN(ARESETB), .QN(n5731)
         );
  DFFRX1 cas_5_data_reg_28_ ( .D(n3267), .CK(ACLK), .RN(ARESETB), .QN(n5741)
         );
  DFFRX1 cas_5_data_reg_27_ ( .D(n3268), .CK(ACLK), .RN(ARESETB), .QN(n5724)
         );
  DFFRX1 cas_5_data_reg_26_ ( .D(n3269), .CK(ACLK), .RN(ARESETB), .QN(n5891)
         );
  DFFRX1 cas_5_data_reg_25_ ( .D(n3270), .CK(ACLK), .RN(ARESETB), .QN(n5742)
         );
  DFFRX1 cas_5_data_reg_24_ ( .D(n3271), .CK(ACLK), .RN(ARESETB), .QN(n5873)
         );
  DFFRX1 cas_5_data_reg_23_ ( .D(n3272), .CK(ACLK), .RN(ARESETB), .QN(n5892)
         );
  DFFRX1 cas_5_data_reg_22_ ( .D(n3273), .CK(ACLK), .RN(ARESETB), .QN(n5743)
         );
  DFFRX1 cas_5_data_reg_21_ ( .D(n3274), .CK(ACLK), .RN(ARESETB), .QN(n5874)
         );
  DFFRX1 cas_5_data_reg_20_ ( .D(n3275), .CK(ACLK), .RN(ARESETB), .QN(n5732)
         );
  DFFRX1 cas_5_data_reg_19_ ( .D(n3276), .CK(ACLK), .RN(ARESETB), .QN(n5733)
         );
  DFFRX1 cas_5_data_reg_18_ ( .D(n3277), .CK(ACLK), .RN(ARESETB), .QN(n5875)
         );
  DFFRX1 cas_5_data_reg_17_ ( .D(n3278), .CK(ACLK), .RN(ARESETB), .QN(n5946)
         );
  DFFRX1 cas_5_data_reg_16_ ( .D(n3279), .CK(ACLK), .RN(ARESETB), .QN(n5893)
         );
  DFFRX1 cas_5_data_reg_15_ ( .D(n3280), .CK(ACLK), .RN(ARESETB), .QN(n5876)
         );
  DFFRX1 cas_5_data_reg_14_ ( .D(n3281), .CK(ACLK), .RN(ARESETB), .QN(n5740)
         );
  DFFRX1 cas_5_data_reg_13_ ( .D(n3282), .CK(ACLK), .RN(ARESETB), .QN(n5894)
         );
  DFFRX1 cas_5_data_reg_12_ ( .D(n3283), .CK(ACLK), .RN(ARESETB), .QN(n5725)
         );
  DFFRX1 cas_5_data_reg_11_ ( .D(n3284), .CK(ACLK), .RN(ARESETB), .QN(n5947)
         );
  DFFRX1 cas_5_data_reg_10_ ( .D(n3285), .CK(ACLK), .RN(ARESETB), .QN(n5734)
         );
  DFFRX1 cas_5_data_reg_9_ ( .D(n3286), .CK(ACLK), .RN(ARESETB), .QN(n5869) );
  DFFRX1 cas_5_data_reg_8_ ( .D(n3287), .CK(ACLK), .RN(ARESETB), .QN(n5739) );
  DFFRX1 cas_5_data_reg_7_ ( .D(n3288), .CK(ACLK), .RN(ARESETB), .QN(n5895) );
  DFFRX1 cas_5_data_reg_6_ ( .D(n3289), .CK(ACLK), .RN(ARESETB), .QN(n5877) );
  DFFRX1 cas_5_data_reg_5_ ( .D(n3290), .CK(ACLK), .RN(ARESETB), .QN(n5735) );
  DFFRX1 cas_5_data_reg_4_ ( .D(n3291), .CK(ACLK), .RN(ARESETB), .QN(n5896) );
  DFFRX1 cas_5_data_reg_3_ ( .D(n3292), .CK(ACLK), .RN(ARESETB), .QN(n5726) );
  DFFRX1 cas_5_data_reg_2_ ( .D(n3293), .CK(ACLK), .RN(ARESETB), .QN(n5727) );
  DFFRX1 cas_5_data_reg_1_ ( .D(n3294), .CK(ACLK), .RN(ARESETB), .QN(n5744) );
  DFFRX1 cas_5_data_reg_0_ ( .D(n3295), .CK(ACLK), .RN(ARESETB), .QN(n5870) );
  DFFRX1 cas_6_data_reg_36_ ( .D(n3298), .CK(ACLK), .RN(ARESETB), .QN(n5838)
         );
  DFFRX1 cas_6_data_reg_35_ ( .D(n3299), .CK(ACLK), .RN(ARESETB), .QN(n5812)
         );
  DFFRX1 cas_6_data_reg_34_ ( .D(n3300), .CK(ACLK), .RN(ARESETB), .QN(n5813)
         );
  DFFRX1 cas_6_data_reg_33_ ( .D(n3301), .CK(ACLK), .RN(ARESETB), .QN(n5839)
         );
  DFFRX1 cas_6_data_reg_32_ ( .D(n3302), .CK(ACLK), .RN(ARESETB), .QN(n5846)
         );
  DFFRX1 cas_6_data_reg_31_ ( .D(n3303), .CK(ACLK), .RN(ARESETB), .QN(n5821)
         );
  DFFRX1 cas_6_data_reg_30_ ( .D(n3304), .CK(ACLK), .RN(ARESETB), .QN(n5849)
         );
  DFFRX1 cas_6_data_reg_29_ ( .D(n3305), .CK(ACLK), .RN(ARESETB), .QN(n5809)
         );
  DFFRX1 cas_6_data_reg_28_ ( .D(n3306), .CK(ACLK), .RN(ARESETB), .QN(n5842)
         );
  DFFRX1 cas_6_data_reg_27_ ( .D(n3307), .CK(ACLK), .RN(ARESETB), .QN(n5844)
         );
  DFFRX1 cas_6_data_reg_26_ ( .D(n3308), .CK(ACLK), .RN(ARESETB), .QN(n5807)
         );
  DFFRX1 cas_6_data_reg_25_ ( .D(n3309), .CK(ACLK), .RN(ARESETB), .QN(n5843)
         );
  DFFRX1 cas_6_data_reg_24_ ( .D(n3310), .CK(ACLK), .RN(ARESETB), .QN(n5818)
         );
  DFFRX1 cas_6_data_reg_23_ ( .D(n3311), .CK(ACLK), .RN(ARESETB), .QN(n5847)
         );
  DFFRX1 cas_6_data_reg_22_ ( .D(n3312), .CK(ACLK), .RN(ARESETB), .QN(n5851)
         );
  DFFRX1 cas_6_data_reg_21_ ( .D(n3313), .CK(ACLK), .RN(ARESETB), .QN(n5819)
         );
  DFFRX1 cas_6_data_reg_20_ ( .D(n3314), .CK(ACLK), .RN(ARESETB), .QN(n5810)
         );
  DFFRX1 cas_6_data_reg_19_ ( .D(n3315), .CK(ACLK), .RN(ARESETB), .QN(n5808)
         );
  DFFRX1 cas_6_data_reg_18_ ( .D(n3316), .CK(ACLK), .RN(ARESETB), .QN(n5820)
         );
  DFFRX1 cas_6_data_reg_17_ ( .D(n3317), .CK(ACLK), .RN(ARESETB), .QN(n5835)
         );
  DFFRX1 cas_6_data_reg_16_ ( .D(n3318), .CK(ACLK), .RN(ARESETB), .QN(n5817)
         );
  DFFRX1 cas_6_data_reg_15_ ( .D(n3319), .CK(ACLK), .RN(ARESETB), .QN(n5845)
         );
  DFFRX1 cas_6_data_reg_14_ ( .D(n3320), .CK(ACLK), .RN(ARESETB), .QN(n5840)
         );
  DFFRX1 cas_6_data_reg_13_ ( .D(n3321), .CK(ACLK), .RN(ARESETB), .QN(n5814)
         );
  DFFRX1 cas_6_data_reg_12_ ( .D(n3322), .CK(ACLK), .RN(ARESETB), .QN(n5815)
         );
  DFFRX1 cas_6_data_reg_11_ ( .D(n3323), .CK(ACLK), .RN(ARESETB), .QN(n5852)
         );
  DFFRX1 cas_6_data_reg_10_ ( .D(n3324), .CK(ACLK), .RN(ARESETB), .QN(n5848)
         );
  DFFRX1 cas_6_data_reg_9_ ( .D(n3325), .CK(ACLK), .RN(ARESETB), .QN(n5816) );
  DFFRX1 cas_6_data_reg_8_ ( .D(n3326), .CK(ACLK), .RN(ARESETB), .QN(n5841) );
  DFFRX1 cas_6_data_reg_7_ ( .D(n3327), .CK(ACLK), .RN(ARESETB), .QN(n5811) );
  DFFRX1 cas_6_data_reg_6_ ( .D(n3328), .CK(ACLK), .RN(ARESETB), .QN(n5803) );
  DFFRX1 cas_6_data_reg_5_ ( .D(n3329), .CK(ACLK), .RN(ARESETB), .QN(n5836) );
  DFFRX1 cas_6_data_reg_4_ ( .D(n3330), .CK(ACLK), .RN(ARESETB), .QN(n5804) );
  DFFRX1 cas_6_data_reg_3_ ( .D(n3331), .CK(ACLK), .RN(ARESETB), .QN(n5805) );
  DFFRX1 cas_6_data_reg_2_ ( .D(n3332), .CK(ACLK), .RN(ARESETB), .QN(n5806) );
  DFFRX1 cas_6_data_reg_1_ ( .D(n3333), .CK(ACLK), .RN(ARESETB), .QN(n5837) );
  DFFRX1 cas_6_data_reg_0_ ( .D(n3334), .CK(ACLK), .RN(ARESETB), .QN(n5822) );
  DFFRX1 cas_7_final_reg ( .D(n3337), .CK(ACLK), .RN(ARESETB), .QN(n5960) );
  DFFRX1 CAS_0_NEWROW_reg ( .D(n3102), .CK(ACLK), .RN(ARESETB), .Q(
        CAS_0_NEWROW), .QN(n5677) );
  DFFRX1 CAS_0_FINAL_reg ( .D(n3101), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_FINAL), 
        .QN(n5678) );
  DFFRX1 CAS_FULL_reg ( .D(CAS_FULL922), .CK(ACLK), .RN(ARESETB), .Q(CAS_FULL)
         );
  DFFRX1 cas_5_final_reg ( .D(n3296), .CK(ACLK), .RN(ARESETB), .Q(cas_5_final)
         );
  DFFRX1 cas_1_final_reg ( .D(n3140), .CK(ACLK), .RN(ARESETB), .Q(cas_1_final)
         );
  DFFRX1 cas_5_newrow_reg ( .D(n3297), .CK(ACLK), .RN(ARESETB), .Q(
        cas_5_newrow), .QN(n6021) );
  DFFRX1 CAS_0_CA_reg_10_ ( .D(n3079), .CK(ACLK), .RN(ARESETB), .Q(
        CAS_0_CA[10]), .QN(n2971) );
  DFFRX1 CAS_0_CA_reg_6_ ( .D(n3083), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_CA[6]), 
        .QN(n2977) );
  DFFRX1 CAS_0_CA_reg_2_ ( .D(n3087), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_CA[2]), 
        .QN(n2973) );
  DFFRX1 CAS_0_CA_reg_1_ ( .D(n3088), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_CA[1]), 
        .QN(n2972) );
  DFFRX1 CAS_0_CA_reg_0_ ( .D(n3089), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_CA[0]), 
        .QN(n2970) );
  DFFRX1 CAS_0_CA_reg_5_ ( .D(n3084), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_CA[5]), 
        .QN(n2976) );
  DFFRX1 CAS_0_CA_reg_4_ ( .D(n3085), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_CA[4]), 
        .QN(n2975) );
  DFFRX1 CAS_0_CA_reg_8_ ( .D(n3081), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_CA[8]), 
        .QN(n2979) );
  DFFRX1 CAS_0_CA_reg_7_ ( .D(n3082), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_CA[7]), 
        .QN(n2978) );
  DFFRX1 CAS_0_CA_reg_9_ ( .D(n3080), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_CA[9]), 
        .QN(n2980) );
  DFFRX1 CAS_0_CA_reg_3_ ( .D(n3086), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_CA[3]), 
        .QN(n2974) );
  DFFRX1 CAS_0_ID_reg_3_ ( .D(n3095), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_ID[3]), 
        .QN(n2985) );
  DFFRX1 CAS_0_ID_reg_2_ ( .D(n3096), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_ID[2]), 
        .QN(n2984) );
  DFFRX1 CAS_0_ID_reg_1_ ( .D(n3097), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_ID[1]), 
        .QN(n2983) );
  DFFRX1 CAS_0_ID_reg_0_ ( .D(n3098), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_ID[0]), 
        .QN(n2982) );
  DFFRX1 CAS_0_PM_reg ( .D(n3100), .CK(ACLK), .RN(ARESETB), .Q(CAS_0_PM), .QN(
        n2987) );
  OA22X1 U6093 ( .A0(n5456), .A1(n6051), .B0(n5456), .B1(n6054), .Y(n5589) );
  INVX1 U6094 ( .A(n5393), .Y(n5391) );
  XOR2X1 U6095 ( .A(n5150), .B(cas_cnt_0_), .Y(n5211) );
  AO22X1 U6096 ( .A0(n5149), .A1(n5671), .B0(n5150), .B1(n5860), .Y(n5618) );
  AO22X2 U6097 ( .A0(n5149), .A1(n5673), .B0(n5150), .B1(n5857), .Y(n5617) );
  AOI31X1 U6098 ( .A0(n5281), .A1(cas_3_final), .A2(n5283), .B0(n5284), .Y(
        n5282) );
  NAND3BX1 U6099 ( .AN(n5458), .B(n6031), .C(n6037), .Y(n5548) );
  OAI221X1 U6100 ( .A0(n5458), .A1(n6041), .B0(n5458), .B1(n6044), .C0(n5589), 
        .Y(n5586) );
  NAND2BX2 U6101 ( .AN(BA_BA[1]), .B(BA_BA[0]), .Y(n5456) );
  AO22X1 U6102 ( .A0(cas_7_data[28]), .A1(n6079), .B0(n5019), .B1(BA_RA[10]), 
        .Y(n3015) );
  XOR2X1 U6103 ( .A(BA_RA[10]), .B(B1_LAST_RA[10]), .Y(n5575) );
  XOR2X1 U6104 ( .A(BA_RA[10]), .B(B2_LAST_RA[10]), .Y(n5523) );
  XOR2X1 U6105 ( .A(BA_RA[10]), .B(B0_LAST_RA[10]), .Y(n5559) );
  NAND2BX2 U6106 ( .AN(n5463), .B(n5602), .Y(n5600) );
  OA22X1 U6107 ( .A0(cas_cnt_b3_pos_0_), .A1(n5461), .B0(cas_cnt_b2_pos_0_), 
        .B1(n5463), .Y(n5479) );
  NAND3BX1 U6108 ( .AN(n5456), .B(n6028), .C(n6034), .Y(n5546) );
  NAND2BX1 U6109 ( .AN(n5456), .B(n5608), .Y(n5449) );
  OAI221X1 U6110 ( .A0(n5456), .A1(n6062), .B0(n5458), .B1(n6063), .C0(n5471), 
        .Y(n5468) );
  OAI221X1 U6111 ( .A0(cas_cnt_b1_pos_0_), .A1(n5456), .B0(cas_cnt_b0_pos_0_), 
        .B1(n5458), .C0(n5479), .Y(n5477) );
  OAI31X1 U6112 ( .A0(n5485), .A1(n5486), .A2(n5461), .B0(BA_RA[0]), .Y(n5484)
         );
  NAND2BX1 U6113 ( .AN(n5461), .B(n5609), .Y(n5451) );
  OAI221X1 U6114 ( .A0(n5456), .A1(n6061), .B0(n5458), .B1(n6064), .C0(n5460), 
        .Y(n5453) );
  OAI221X1 U6115 ( .A0(n5461), .A1(n6042), .B0(n5461), .B1(n6047), .C0(n5594), 
        .Y(n5585) );
  NAND3BX1 U6116 ( .AN(n6023), .B(n5220), .C(n5221), .Y(n5016) );
  AO22X1 U6117 ( .A0(cas_7_data[30]), .A1(n6078), .B0(n5019), .B1(BA_RA[12]), 
        .Y(n3013) );
  AO22X1 U6118 ( .A0(cas_7_data[31]), .A1(n6079), .B0(n5019), .B1(BA_BA[0]), 
        .Y(n3012) );
  NAND2BX2 U6119 ( .AN(n5162), .B(n5285), .Y(n5393) );
  OAI222X1 U6120 ( .A0(n5487), .A1(n5488), .B0(n5489), .B1(n5490), .C0(n5491), 
        .C1(n5492), .Y(n5483) );
  OAI222X1 U6121 ( .A0(n6045), .A1(n5478), .B0(n5745), .B1(n5478), .C0(n5718), 
        .C1(n5600), .Y(n5583) );
  AO22X1 U6122 ( .A0(cas_7_data[32]), .A1(n5644), .B0(n5019), .B1(BA_BA[1]), 
        .Y(n3011) );
  OA22X1 U6123 ( .A0(n5461), .A1(n6060), .B0(n5463), .B1(n6065), .Y(n5471) );
  OA22X1 U6124 ( .A0(n5461), .A1(n6043), .B0(n5463), .B1(n6052), .Y(n5460) );
endmodule


module SDRAi ( ARESETB, PORESETB, ACLK, nACLK, FCLK, AWAddr, AWId, AWLen, 
        AWValid, AWReady, AWBurst, WLast, WStrb, WData, WValid, WReady, WId, 
        BResp, BValid, BReady, BId, ARAddr, ARId, ARLen, ARValid, ARReady, 
        ARBurst, RData, RValid, RReady, RLast, RId, RResp, RQFull, WQFull, 
        BA_STS, BA_AA, BA_REQ, BA_TT, BA_RW, BA_ID, BA_PM, SD_DQE, SD_DQI, 
        SD_DQO, SD_DQM );
  input [25:0] AWAddr;
  input [3:0] AWId;
  input [3:0] AWLen;
  input [1:0] AWBurst;
  input [3:0] WStrb;
  input [31:0] WData;
  input [3:0] WId;
  output [1:0] BResp;
  output [3:0] BId;
  input [25:0] ARAddr;
  input [3:0] ARId;
  input [3:0] ARLen;
  input [1:0] ARBurst;
  output [31:0] RData;
  output [3:0] RId;
  output [1:0] RResp;
  input [16:0] BA_STS;
  output [25:0] BA_AA;
  output [4:0] BA_TT;
  output [3:0] BA_ID;
  input [31:0] SD_DQI;
  output [31:0] SD_DQO;
  output [3:0] SD_DQM;
  input ARESETB, PORESETB, ACLK, nACLK, FCLK, AWValid, WLast, WValid, BReady,
         ARValid, RReady;
  output AWReady, WReady, BValid, ARReady, RValid, RLast, RQFull, WQFull,
         BA_REQ, BA_RW, BA_PM, SD_DQE;
  wire   WQWrData_35_, WQWrData_34_, WQWrData_33_, WQWrData_32_, WriteLatA0_3_,
         WriteLatA0_2_, WriteLatA0_1_, WriteLatA0_0_, tWIdle, tWWDat, tWWReq,
         tWWSpi, tRRReq, tRRSpi, tRDIdle, tRDReq, WriteAck, iWValid,
         WriteLatAA_25_, WriteLatAA_24_, WriteLatAA_23_, WriteLatAA_22_,
         WriteLatAA_21_, WriteLatAA_20_, WriteLatAA_19_, WriteLatAA_18_,
         WriteLatAA_17_, WriteLatAA_16_, WriteLatAA_15_, WriteLatAA_14_,
         WriteLatAA_13_, WriteLatAA_12_, WriteLatAA_11_, WriteLatAA_10_,
         WriteLatAA_9_, WriteLatAA_8_, WriteLatAA_7_, WriteLatAA_6_,
         WriteLatAA_5_, WriteLatAA_4_, WriteLatAA_3_, WriteLatAA_1_, WBLQFull,
         WBLQWrite, WBLQEmpty, iWQRead, WrAddrHold, n_1314, WQEmpty,
         DelayiWQRead, Out16BitSel, RQHFull, RBLQFull, ReadLatAA_25_,
         ReadLatAA_24_, ReadLatAA_23_, ReadLatAA_22_, ReadLatAA_21_,
         ReadLatAA_20_, ReadLatAA_19_, ReadLatAA_18_, ReadLatAA_17_,
         ReadLatAA_16_, ReadLatAA_15_, ReadLatAA_14_, ReadLatAA_13_,
         ReadLatAA_12_, ReadLatAA_11_, ReadLatAA_10_, ReadLatAA_9_,
         ReadLatAA_8_, ReadLatAA_7_, ReadLatAA_6_, ReadLatAA_5_, ReadLatAA_4_,
         ReadLatAA_3_, ReadLatAA_1_, ReadLatTT_0_, ReadLatA0_3_, ReadLatA0_2_,
         ReadLatA0_1_, ReadLatA0_0_, iDelayReadLast, In16BitSel, n_5173,
         RQRead, IncRdLastCnt, RQWrite, RQEmpty, RdAddrHold, AckMem251,
         WPageMisCal403_3_, WPageMisCal403_2_, WPageMisCal403_1_,
         WPageMisCal408_3_, WPageMisCal408_2_, WPageMisCal408_1_,
         LatchedWBL_3_, LatchedWBL_2_, LatchedWBL_1_, LatchedWBL_0_,
         WrWrapAddrSt_3_, WrWrapAddrSt_2_, WrWrapAddrSt_1_, WrWrapAddrSt_0_,
         WrWrapCnt1356_3_, WrWrapCnt1356_2_, WrWrapCnt1356_1_, n1361_29_,
         n1361_30_, n1361_31_, WrWrapCnt1377_4_, WrWrapCnt1377_3_,
         WrWrapCnt1377_2_, WrWrapCnt1377_1_, WrWrapCnt1390_5_,
         WrWrapCnt1390_4_, WrWrapCnt1390_3_, WrWrapCnt1390_2_,
         WrWrapCnt1390_1_, n1391_27_, n1391_28_, n1391_29_, n1391_30_,
         n1391_31_, n1393_29_, n1393_30_, n1393_31_, a1416_30_, a1416_29_,
         a1416_28_, a1416_27_, a1416_26_, a1416_25_, a1416_24_, a1416_23_,
         a1416_22_, a1416_21_, a1416_20_, a1416_19_, a1416_18_, a1416_17_,
         a1416_15_, a1416_13_, a1416_12_, a1416_9_, a1416_6_, a1416_5_,
         a1416_4_, a1416_3_, a1416_2_, a1416_1_, RPageMisCal1700_3_,
         RPageMisCal1700_2_, RPageMisCal1700_1_, RPageMisCal1705_3_,
         RPageMisCal1705_2_, RPageMisCal1705_1_, RSpi2Addr1902_24_,
         RSpi2Addr1902_23_, RSpi2Addr1902_22_, RSpi2Addr1902_21_,
         RSpi2Addr1902_20_, RSpi2Addr1902_19_, RSpi2Addr1902_18_,
         RSpi2Addr1902_17_, RSpi2Addr1902_16_, RSpi2Addr1902_15_,
         RSpi2Addr1902_14_, RSpi2Addr1902_13_, RSpi2Addr1902_12_,
         RSpi2Addr1902_11_, RSpi2Addr1902_10_, RSpi2Addr1902_9_,
         RSpi2Addr1902_8_, RSpi2Addr1914_24_, RSpi2Addr1914_23_,
         RSpi2Addr1914_22_, RSpi2Addr1914_21_, RSpi2Addr1914_20_,
         RSpi2Addr1914_19_, RSpi2Addr1914_18_, RSpi2Addr1914_17_,
         RSpi2Addr1914_16_, RSpi2Addr1914_15_, RSpi2Addr1914_14_,
         RSpi2Addr1914_13_, RSpi2Addr1914_12_, RSpi2Addr1914_11_,
         RSpi2Addr1914_10_, RSpi2Addr1914_9_, RSpi2Addr1926_24_,
         RSpi2Addr1926_23_, RSpi2Addr1926_22_, RSpi2Addr1926_21_,
         RSpi2Addr1926_20_, RSpi2Addr1926_19_, RSpi2Addr1926_18_,
         RSpi2Addr1926_17_, RSpi2Addr1926_16_, RSpi2Addr1926_15_,
         RSpi2Addr1926_14_, RSpi2Addr1926_13_, RSpi2Addr1926_12_,
         RSpi2Addr1926_11_, RSpi2Addr1926_10_, RSpi2Addr1938_24_,
         RSpi2Addr1938_23_, RSpi2Addr1938_22_, RSpi2Addr1938_21_,
         RSpi2Addr1938_20_, RSpi2Addr1938_19_, RSpi2Addr1938_18_,
         RSpi2Addr1938_17_, RSpi2Addr1938_16_, RSpi2Addr1938_15_,
         RSpi2Addr1938_14_, RSpi2Addr1938_13_, RSpi2Addr1938_12_,
         RSpi2Addr1938_11_, n2790, LatchedRBL_3_, LatchedRBL_2_, LatchedRBL_1_,
         LatchedRBL_0_, RdWrapAddrSt_3_, RdWrapAddrSt_2_, RdWrapAddrSt_1_,
         RdWrapAddrSt_0_, RdWrapCnt3036_6_, RdWrapCnt3036_5_, RdWrapCnt3036_4_,
         RdWrapCnt3036_3_, RdWrapCnt3036_2_, RdWrapCnt3036_1_, RBLQEmpty,
         n5127, n5128, n5129, n5130, n5131, n5132, n5133, n5134, n5135, n5136,
         n5137, n5138, n5139, n5140, n5141, n5142, n5143, n5144, n5145, n5146,
         n5147, n5148, n5149, n5150, n5151, n5152, n5153, n5154, n5155, n5156,
         n5157, n5158, n5159, n5160, n5161, n5162, n5163, n5164, n5165, n5166,
         n5167, n5168, n5169, n5170, n5171, n5172, n5173, n5174, n5175, n5176,
         n5177, n5178, n5179, n5180, n5181, n5182, n5183, n5184, n5185, n5186,
         n5187, n5188, n5189, n5190, n5191, n5192, n5193, n5194, n5195, n5196,
         n5197, n5198, n5199, n5200, n5201, n5202, n5203, n5204, n5205, n5206,
         n5207, n5208, n5209, n5210, n5211, n5212, n5213, n5214, n5215, n5216,
         n5217, n5218, n5219, n5220, n5221, n5222, n5223, n5224, n5225, n5226,
         n5227, n5228, n5229, n5230, n5231, n5232, n5233, n5234, n5235, n5236,
         n5237, n5238, n5239, n5240, n5241, n5242, n5243, n5244, n5245, n5246,
         n5247, n5248, n5249, n5250, n5251, n5252, n5253, n5254, n5255, n5256,
         n5257, n5258, n5259, n5260, n5261, n5262, n5263, n5264, n5265, n5266,
         n5267, n5268, n5269, n5270, n5271, n5272, n5273, n5274, n5275, n5276,
         n5277, n5278, n5279, n5280, n5281, n5282, n5283, n5284, n5285, n5286,
         n5287, n5288, n5289, n5290, n5291, n5292, n5293, n5294, n5295, n5296,
         n5297, n5298, n5299, n5300, n5301, n5302, n5303, n5304, n5305, n5306,
         n5307, n5308, n5309, n5310, n5311, n5312, n5313, n5314, n5315, n5316,
         n5317, n5318, n5319, n5320, n5321, n5322, n5323, n5324, n5325, n5326,
         n5327, n5328, n5332, n5334, n5336, n5338, n5340, n5342, n5344, n5347,
         n5356, carry, carry0, carry1, n724, n820, n920, carry2, carry3, n720,
         n819, carry4, n818, n918, carry5, carry6, carry7, n618, n718, n817,
         carry8, carry9, n165, n29, n310, carry10, carry11, carry12, n164, n28,
         n39, n413, carry13, carry14, carry15, carry16, n160, n27, n38, n412,
         carry17, carry18, n159, n26, n37, carry19, carry20, n816, n916, n1016,
         carry_17_, carry21, carry22, carry23, carry24, carry25, carry26,
         carry27, carry28, carry29, carry30, carry31, carry32, carry33,
         carry34, carry35, n19, n24, n35, n410, n516, n616, n716, n815, n915,
         n1015, n1115, n1214, n1314, n1414, n157, n163, n172, carry_16_,
         carry36, carry37, carry38, carry39, carry40, carry41, carry42,
         carry43, carry44, carry45, carry46, carry47, carry48, n18, n23, n34,
         n43, n515, n615, n715, n814, n914, n1014, n1114, n1213, n1313, n1413,
         n156, n162, carry_15_, carry49, carry50, carry51, carry52, carry53,
         carry54, carry55, carry56, carry57, carry58, carry59, carry60,
         carry61, n17, n22, n33, n42, n514, n614, n714, n810, n910, n1010,
         n1113, n1210, n1310, n1410, n155, carry_14_, carry_13_, carry_12_,
         carry_11_, carry_10_, carry_9_, carry_8_, carry_7_, carry62, carry63,
         carry64, carry65, carry66, n11, n21, n32, n41, n510, n610, n710, n8,
         n9, n10, n1110, n12, n13, n14, carry_6_, carry_5_, carry_4_, carry_3_,
         carry_2_, n1, n2, n3, n4, n5, n6, g_array, g_array0, g_array1,
         g_array2, g_array3, g_array4, g_array5, g_array6, g_array7, g_array8,
         g_array9, g_array10, g_array11, g_array12, g_array13, g_array14,
         g_array15, pog_array, pog_array0, pog_array1, pog_array2, pog_array3,
         pog_array4, pog_array5, part_diff_3_, part_diff_2_, part_diff_1_, n31,
         n5506, n5508, n5510, n5512, n5515, n5548, n5550, n5551, n5552, n5554,
         n5555, n5556, n5558, n5560, n5561, n5562, n5563, n5565, n5566, n5567,
         n5568, n5569, n5571, n5572, n5573, n5575, n5576, n5579, n5581, n5582,
         n5583, n5586, n5587, n5588, n5589, n5591, n5592, n5593, n5594, n5595,
         n5596, n5597, n5598, n5599, n5601, n5602, n5603, n5604, n5605, n5606,
         n5607, n5608, n5610, n5611, n5612, n5613, n5614, n5615, n5616, n5617,
         n5618, n5619, n5620, n5621, n5623, n5624, n5625, n5626, n5627, n5628,
         n5629, n5630, n5631, n5633, n5634, n5635, n5636, n5637, n5638, n5640,
         n5641, n5642, n5643, n5644, n5645, n5646, n5647, n5648, n5650, n5651,
         n5652, n5653, n5654, n5655, n5656, n5658, n5659, n5660, n5661, n5662,
         n5663, n5664, n5666, n5667, n5668, n5669, n5670, n5671, n5672, n5673,
         n5674, n5676, n5679, n5680, n5681, n5682, n5683, n5684, n5685, n5688,
         n5691, n5692, n5693, n5694, n5695, n5696, n5697, n5698, n5699, n5700,
         n5701, n5702, n5703, n5706, n5707, n5708, n5709, n5710, n5711, n5712,
         n5713, n5714, n5715, n5716, n5717, n5718, n5719, n5720, n5721, n5722,
         n5723, n5724, n5725, n5726, n5727, n5728, n5729, n5730, n5731, n5732,
         n5733, n5735, n5736, n5737, n5738, n5739, n5740, n5741, n5742, n5743,
         n5744, n5745, n5747, n5748, n5749, n5751, n5755, n5756, n5757, n5758,
         n5759, n5760, n5761, n5762, n5764, n5765, n5766, n5767, n5772, n5773,
         n5775, n5778, n5779, n5780, n5782, n5783, n5784, n5785, n5786, n5789,
         n5790, n5791, n5792, n5793, n5794, n5795, n5796, n5797, n5798, n5799,
         n5800, n5801, n5802, n5803, n5804, n5805, n5806, n5807, n5808, n5809,
         n5810, n5811, n5812, n5813, n5814, n5815, n5816, n5817, n5818, n5819,
         n5820, n5822, n5823, n5825, n5829, n5832, n5835, n5836, n5838, n5839,
         n5840, n5841, n5843, n5844, n5845, n5847, n5848, n5851, n5852, n5854,
         n5855, n5856, n5857, n5858, n5859, n5861, n5862, n5863, n5864, n5865,
         n5866, n5867, n5868, n5870, n5871, n5872, n5873, n5874, n5875, n5876,
         n5877, n5878, n5879, n5880, n5881, n5882, n5883, n5884, n5885, n5887,
         n5888, n5889, n5890, n5891, n5892, n5893, n5894, n5895, n5896, n5897,
         n5898, n5899, n5900, n5901, n5902, n5904, n5905, n5906, n5907, n5908,
         n5909, n5910, n5911, n5912, n5913, n5914, n5915, n5916, n5917, n5918,
         n5919, n5920, n5921, n5922, n5923, n5924, n5925, n5927, n5928, n5929,
         n5930, n5931, n5932, n5933, n5935, n5936, n5937, n5938, n5939, n5940,
         n5941, n5942, n5943, n5944, n5945, n5947, n5948, n5949, n5950, n5951,
         n5952, n5953, n5954, n5955, n5956, n5957, n5958, n5959, n5960, n5961,
         n5963, n5964, n5965, n5966, n5968, n5970, n5971, n5972, n5973, n5976,
         n5977, n5978, n5979, n5980, n5981, n5982, n5983, n5984, n5985, n5987,
         n5988, n5989, n5990, n5991, n5992, n5994, n5995, n5999, n6000, n6001,
         n6003, n6005, n6006, n6007, n6008, n6009, n6010, n6011, n6012, n6013,
         n6014, n6015, n6016, n6017, n6019, n6020, n6021, n6022, n6023, n6024,
         n6026, n6028, n6030, n6031, n6034, n6035, n6036, n6038, n6039, n6043,
         n6044, n6048, n6049, n6050, n6052, n6053, n6055, n6056, n6057, n6058,
         n6059, n6060, n6061, n6062, n6063, n6064, n6065, n6066, n6067, n6068,
         n6069, n6070, n6071, n6072, n6073, n6074, n6075, n6076, n6077, n6079,
         n6080, n6081, n6082, n6084, n6085, n6087, n6088, n6089, n6090, n6091,
         n6092, n6093, n6094, n6095, n6096, n6097, n6098, n6099, n6100, n6101,
         n6102, n6103, n6104, n6105, n6106, n6107, n6108, n6109, n6110, n6111,
         n6112, n6113, n6114, n6115, n6117, n6118, n6119, n6120, n6122, n6124,
         n6125, n6126, n6127, n6128, n6129, n6130, n6131, n6132, n6133, n6134,
         n6136, n6138, n6141, n6142, n6143, n6144, n6145, n6146, n6147, n6148,
         n6149, n6150, n6151, n6153, n6154, n6155, n6160, n6161, n6163, n6165,
         n6167, n6168, n6169, n6170, n6171, n6172, n6173, n6174, n6175, n6176,
         n6177, n6179, n6180, n6181, n6182, n6183, n6185, n6186, n6187, n6188,
         n6189, n6190, n6191, n6193, n6196, n6197, n6198, n6199, n6200, n6201,
         n6202, n6203, n6204, n6205, n6206, n6207, n6210, n6211, n6212, n6213,
         n6214, n6215, n6216, n6217, n6218, n6219, n6220, n6221, n6222, n6223,
         n6224, n6225, n6227, n6228, n6229, n6230, n6231, n6232, n6233, n6234,
         n6235, n6236, n6237, n6239, n6241, n6242, n6243, n6244, n6245, n6247,
         n6248, n6249, n6250, n6251, n6253, n6254, n6255, n6256, n6257, n6258,
         n6259, n6260, n6262, n6263, n6264, n6265, n6266, n6267, n6268, n6271,
         n6272, n6273, n6274, n6275, n6276, n6277, n6278, n6279, n6280, n6281,
         n6282, n6283, n6284, n6285, n6286, n6287, n6288, n6289, n6290, n6291,
         n6292, n6293, n6294, n6295, n6296, n6297, n6298, n6299, n6300, n6303,
         n6304, n6305, n6306, n6307, n6308, n6309, n6310, n6311, n6312, n6313,
         n6314, n6315, n6316, n6317, n6318, n6319, n6320, n6321, n6322, n6323,
         n6324, n6325, n6326, n6327, n6328, n6329, n6330, n6331, n6332, n6333,
         n6334, n6335, n6336, n6337, n6338, n6339, n6340, n6341, n6342, n6343,
         n6344, n6345, n6346, n6347, n6348, n6349, n6350, n6351, n6352, n6353,
         n6354, n6355, n6356, n6357, n6358, n6359, n6360, n6361, n6362, n6363,
         n6364, n6365, n6366, n6367, n6368, n6369, n6370, n6371, n6372, n6373,
         n6374, n6375, n6376, n6377, n6378, n6379, n6380, n6381, n6382, n6383,
         n6384, n6385, n6386, n6387, n6388, n6389, n6390, n6391, n6392, n6393,
         n6394, n6395, n6396, n6397, n6398, n6399, n6400, n6401, n6402, n6403,
         n6404, n6405, n6406, n6407, n6408, n6409, n6410, n6411, n6412, n6413,
         n6414, n6415, n6416, n6417, n6418, n6419, n6420, n6421, n6422, n6423,
         n6424, n6425, n6426, n6427, n6428, n6429, n6430, n6431, n6432, n6433,
         n6434, n6435, n6436, n6437, n6438, n6439, n6440, n6441, n6442, n6443,
         n6444, n6445, n6446, n6447, n6448, n6449, n6450, n6451, n6452, n6453,
         n6454, n6455, n6456, n6457, n6458, n6459, n6460, n6461, n6462, n6463,
         n6464, n6465, n6466, n6467, n6468, n6469, n6470;
  wire   [1:0] WriteLatBB;
  wire   [35:0] RQWrData;
  wire   [1:0] NxtStRD;
  wire   [4:0] NxtStW;
  wire   [3:0] WriteReqID;
  wire   [3:0] WBurstCnt;
  wire   [9:0] WBLQRdData;
  wire   [5:0] WrWrapCnt;
  wire   [5:0] WQIncAddr;
  wire   [35:0] WQRdData;
  wire   [2:0] NxtStR;
  wire   [1:0] ReadLatBB;
  wire   [3:0] ReadReqID;
  wire   [3:0] iDelayReadId;
  wire   [31:0] RdDataMemFd;
  wire   [9:0] RBLQRdData;
  wire   [7:0] RQIncAddr;
  wire   [3:0] RBurstCnt;
  wire   [3:0] RdLastCnt;
  wire   [7:0] RdWrapCnt;
  assign RResp[0] = 1'b0;
  assign RResp[1] = 1'b0;
  assign BResp[0] = 1'b0;
  assign BResp[1] = 1'b0;

  SDRWQ WDatBuf ( .nRST(ARESETB), .Clk(ACLK), .WriteEn(iWValid), .ReadEn(
        iWQRead), .DelayReadEn(DelayiWQRead), .WrData({WQWrData_35_, 
        WQWrData_34_, WQWrData_33_, WQWrData_32_, WData}), .RdData(WQRdData), 
        .FullFlag(WQFull), .EmptyFlag(WQEmpty), .WrapCnt(WrWrapCnt), 
        .IncRdCnt(WQIncAddr), .AddrHold(WrAddrHold) );
  SDRRQ RDatBuf ( .nRST(ARESETB), .nClk(nACLK), .Clk(ACLK), .WriteEn(RQWrite), 
        .ReadEn(RQRead), .WrData(RQWrData), .RdData({RId, RData}), .FullFlag(
        RQFull), .HFullFlag(RQHFull), .EmptyFlag(RQEmpty), .WrapCnt(RdWrapCnt), 
        .IncRdCnt(RQIncAddr), .AddrHold(RdAddrHold) );
  SDRBLQ_BLQCD0_BLQD1_BLQW9 WBLBuf ( .nRST(ARESETB), .Clk(ACLK), .WriteEn(
        WBLQWrite), .ReadEn(n_1314), .WrData({WriteLatBB, WriteLatA0_3_, 
        WriteLatA0_2_, WriteLatA0_1_, WriteLatA0_0_, n6463, n6464, n6465, 
        n5338}), .RdData(WBLQRdData), .FullFlag(WBLQFull), .EmptyFlag(
        WBLQEmpty) );
  SDRBLQ_BLQCD3_BLQD15_BLQW9 RBLBuf ( .nRST(ARESETB), .Clk(ACLK), .WriteEn(
        n5356), .ReadEn(n_5173), .WrData({ARBurst, ARAddr[3:0], ARLen}), 
        .RdData(RBLQRdData), .FullFlag(RBLQFull), .EmptyFlag(RBLQEmpty) );
  DFFRX4 ReadLatA0_reg_8_ ( .D(n5220), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_8_), .QN(n6320) );
  DFFRX4 ReadLatA0_reg_9_ ( .D(n5219), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_9_), .QN(n6387) );
  DFFRX4 ReadLatA0_reg_10_ ( .D(n5218), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_10_), .QN(n6366) );
  AHHCONX2 U1_1_110 ( .A(LatchedWBL_1_), .CI(LatchedWBL_0_), .S(n1361_31_), 
        .CON(n310) );
  AHHCONX2 U1_1_27 ( .A(LatchedWBL_2_), .CI(carry9), .S(n1361_30_), .CON(n29)
         );
  AHHCONX2 U1_1_37 ( .A(LatchedWBL_3_), .CI(carry8), .S(n1361_29_), .CON(n165)
         );
  AHHCONX2 U1_1_19 ( .A(WrWrapCnt[1]), .CI(WrWrapCnt[0]), .S(WrWrapCnt1377_1_), 
        .CON(n413) );
  AHHCONX2 U1_1_26 ( .A(WrWrapCnt[2]), .CI(carry12), .S(WrWrapCnt1377_2_), 
        .CON(n39) );
  AHHCONX2 U1_1_36 ( .A(WrWrapCnt[3]), .CI(carry11), .S(WrWrapCnt1377_3_), 
        .CON(n28) );
  AHHCONX2 U1_1_45 ( .A(WrWrapCnt[4]), .CI(carry10), .S(WrWrapCnt1377_4_), 
        .CON(n164) );
  AHHCONX2 U1_1_18 ( .A(WBLQRdData[1]), .CI(WBLQRdData[0]), .S(n1393_31_), 
        .CON(n37) );
  AHHCONX2 U1_1_25 ( .A(WBLQRdData[2]), .CI(carry18), .S(n1393_30_), .CON(n26)
         );
  AHHCONX2 U1_1_35 ( .A(WBLQRdData[3]), .CI(carry17), .S(n1393_29_), .CON(n159) );
  AHHCONX2 U1_1_171 ( .A(ReadLatAA_24_), .CI(carry_17_), .S(RSpi2Addr1902_24_), 
        .CON(n19) );
  AHHCONX2 U1_1_162 ( .A(ReadLatAA_23_), .CI(carry21), .S(RSpi2Addr1902_23_), 
        .CON(n24) );
  AHHCONX2 U1_1_34 ( .A(ReadLatAA_10_), .CI(carry34), .S(RSpi2Addr1902_10_), 
        .CON(n157) );
  AHHCONX2 U1_1_54 ( .A(ReadLatAA_12_), .CI(carry32), .S(RSpi2Addr1902_12_), 
        .CON(n1314) );
  AHHCONX2 U1_1_64 ( .A(ReadLatAA_13_), .CI(carry31), .S(RSpi2Addr1902_13_), 
        .CON(n1214) );
  AHHCONX2 U1_1_93 ( .A(ReadLatAA_16_), .CI(carry28), .S(RSpi2Addr1902_16_), 
        .CON(n915) );
  AHHCONX2 U1_1_103 ( .A(ReadLatAA_17_), .CI(carry27), .S(RSpi2Addr1902_17_), 
        .CON(n815) );
  AHHCONX2 U1_1_133 ( .A(ReadLatAA_20_), .CI(carry24), .S(RSpi2Addr1902_20_), 
        .CON(n516) );
  AHHCONX2 U1_1_143 ( .A(ReadLatAA_21_), .CI(carry23), .S(RSpi2Addr1902_21_), 
        .CON(n410) );
  AHHCONX2 U1_1_153 ( .A(ReadLatAA_22_), .CI(carry22), .S(RSpi2Addr1902_22_), 
        .CON(n35) );
  AHHCONX2 U1_1_23 ( .A(ReadLatAA_10_), .CI(n6423), .S(RSpi2Addr1914_10_), 
        .CON(n156) );
  AHHCONX2 U1_1_33 ( .A(ReadLatAA_11_), .CI(carry48), .S(RSpi2Addr1914_11_), 
        .CON(n1413) );
  AHHCONX2 U1_1_43 ( .A(ReadLatAA_12_), .CI(carry47), .S(RSpi2Addr1914_12_), 
        .CON(n1313) );
  AHHCONX2 U1_1_53 ( .A(ReadLatAA_13_), .CI(carry46), .S(RSpi2Addr1914_13_), 
        .CON(n1213) );
  AHHCONX2 U1_1_63 ( .A(ReadLatAA_14_), .CI(carry45), .S(RSpi2Addr1914_14_), 
        .CON(n1114) );
  AHHCONX2 U1_1_82 ( .A(ReadLatAA_16_), .CI(carry43), .S(RSpi2Addr1914_16_), 
        .CON(n914) );
  AHHCONX2 U1_1_92 ( .A(ReadLatAA_17_), .CI(carry42), .S(RSpi2Addr1914_17_), 
        .CON(n814) );
  AHHCONX2 U1_1_102 ( .A(ReadLatAA_18_), .CI(carry41), .S(RSpi2Addr1914_18_), 
        .CON(n715) );
  AHHCONX2 U1_1_122 ( .A(ReadLatAA_20_), .CI(carry39), .S(RSpi2Addr1914_20_), 
        .CON(n515) );
  AHHCONX2 U1_1_132 ( .A(ReadLatAA_21_), .CI(carry38), .S(RSpi2Addr1914_21_), 
        .CON(n43) );
  AHHCONX2 U1_1_142 ( .A(ReadLatAA_22_), .CI(carry37), .S(RSpi2Addr1914_22_), 
        .CON(n34) );
  AHHCONX2 U1_1_152 ( .A(ReadLatAA_23_), .CI(carry36), .S(RSpi2Addr1914_23_), 
        .CON(n23) );
  AHHCONX2 U1_1_161 ( .A(ReadLatAA_24_), .CI(carry_16_), .S(RSpi2Addr1914_24_), 
        .CON(n18) );
  AHHCONX2 U1_1_22 ( .A(ReadLatAA_11_), .CI(carry61), .S(RSpi2Addr1926_11_), 
        .CON(n1410) );
  AHHCONX2 U1_1_32 ( .A(ReadLatAA_12_), .CI(carry60), .S(RSpi2Addr1926_12_), 
        .CON(n1310) );
  AHHCONX2 U1_1_42 ( .A(ReadLatAA_13_), .CI(carry59), .S(RSpi2Addr1926_13_), 
        .CON(n1210) );
  AHHCONX2 U1_1_52 ( .A(ReadLatAA_14_), .CI(carry58), .S(RSpi2Addr1926_14_), 
        .CON(n1113) );
  AHHCONX2 U1_1_62 ( .A(ReadLatAA_15_), .CI(carry57), .S(RSpi2Addr1926_15_), 
        .CON(n1010) );
  AHHCONX2 U1_1_71 ( .A(ReadLatAA_16_), .CI(carry56), .S(RSpi2Addr1926_16_), 
        .CON(n910) );
  AHHCONX2 U1_1_101 ( .A(ReadLatAA_19_), .CI(carry53), .S(RSpi2Addr1926_19_), 
        .CON(n614) );
  AHHCONX2 U1_1_112 ( .A(ReadLatAA_20_), .CI(carry52), .S(RSpi2Addr1926_20_), 
        .CON(n514) );
  AHHCONX2 U1_1_121 ( .A(ReadLatAA_21_), .CI(carry51), .S(RSpi2Addr1926_21_), 
        .CON(n42) );
  AHHCONX2 U1_1_141 ( .A(ReadLatAA_23_), .CI(carry49), .S(RSpi2Addr1926_23_), 
        .CON(n22) );
  AHHCONX2 U1_1_21 ( .A(ReadLatAA_12_), .CI(carry66), .S(RSpi2Addr1938_12_), 
        .CON(n13) );
  AHHCONX2 U1_1_31 ( .A(ReadLatAA_13_), .CI(carry65), .S(RSpi2Addr1938_13_), 
        .CON(n12) );
  AHHCONX2 U1_1_41 ( .A(ReadLatAA_14_), .CI(carry64), .S(RSpi2Addr1938_14_), 
        .CON(n1110) );
  AHHCONX2 U1_1_51 ( .A(ReadLatAA_15_), .CI(carry63), .S(RSpi2Addr1938_15_), 
        .CON(n10) );
  AHHCONX2 U1_1_61 ( .A(ReadLatAA_16_), .CI(carry62), .S(RSpi2Addr1938_16_), 
        .CON(n9) );
  AHHCONX2 U1_1_7 ( .A(ReadLatAA_17_), .CI(carry_7_), .S(RSpi2Addr1938_17_), 
        .CON(n8) );
  AHHCONX2 U1_1_8 ( .A(ReadLatAA_18_), .CI(carry_8_), .S(RSpi2Addr1938_18_), 
        .CON(n710) );
  AHHCONX2 U1_1_9 ( .A(ReadLatAA_19_), .CI(carry_9_), .S(RSpi2Addr1938_19_), 
        .CON(n610) );
  AHHCONX2 U1_1_10 ( .A(ReadLatAA_20_), .CI(carry_10_), .S(RSpi2Addr1938_20_), 
        .CON(n510) );
  AHHCONX2 U1_1_111 ( .A(ReadLatAA_21_), .CI(carry_11_), .S(RSpi2Addr1938_21_), 
        .CON(n41) );
  AHHCONX2 U1_1_13 ( .A(ReadLatAA_23_), .CI(carry_13_), .S(RSpi2Addr1938_23_), 
        .CON(n21) );
  AHHCONX2 U1_1_14 ( .A(ReadLatAA_24_), .CI(carry_14_), .S(RSpi2Addr1938_24_), 
        .CON(n11) );
  AHHCONX2 U1_1_1 ( .A(RdWrapCnt[1]), .CI(RdWrapCnt[0]), .S(RdWrapCnt3036_1_), 
        .CON(n6) );
  AHHCONX2 U1_1_2 ( .A(RdWrapCnt[2]), .CI(carry_2_), .S(RdWrapCnt3036_2_), 
        .CON(n5) );
  AHHCONX2 U1_1_3 ( .A(RdWrapCnt[3]), .CI(carry_3_), .S(RdWrapCnt3036_3_), 
        .CON(n4) );
  AHHCONX2 U1_1_4 ( .A(RdWrapCnt[4]), .CI(carry_4_), .S(RdWrapCnt3036_4_), 
        .CON(n3) );
  AHHCONX2 U1_1_5 ( .A(RdWrapCnt[5]), .CI(carry_5_), .S(RdWrapCnt3036_5_), 
        .CON(n2) );
  AHHCONX2 U1_1_6 ( .A(RdWrapCnt[6]), .CI(carry_6_), .S(RdWrapCnt3036_6_), 
        .CON(n1) );
  AHHCONX2 U1_1_12 ( .A(ReadLatAA_22_), .CI(carry_12_), .S(RSpi2Addr1938_22_), 
        .CON(n32) );
  AHHCONX2 U1_1_72 ( .A(ReadLatAA_15_), .CI(carry44), .S(RSpi2Addr1914_15_), 
        .CON(n1014) );
  AHHCONX2 U1_1_113 ( .A(ReadLatAA_19_), .CI(carry40), .S(RSpi2Addr1914_19_), 
        .CON(n615) );
  AHHCONX2 U1_1_24 ( .A(ReadLatAA_9_), .CI(carry35), .S(RSpi2Addr1902_9_), 
        .CON(n163) );
  AHHCONX2 U1_1_44 ( .A(ReadLatAA_11_), .CI(carry33), .S(RSpi2Addr1902_11_), 
        .CON(n1414) );
  AHHCONX2 U1_1_123 ( .A(ReadLatAA_19_), .CI(carry25), .S(RSpi2Addr1902_19_), 
        .CON(n616) );
  AHHCONX2 U1_1_83 ( .A(ReadLatAA_15_), .CI(carry29), .S(RSpi2Addr1902_15_), 
        .CON(n1015) );
  AHHCONX2 U1_1_114 ( .A(ReadLatAA_18_), .CI(carry26), .S(RSpi2Addr1902_18_), 
        .CON(n716) );
  AHHCONX2 U1_1_73 ( .A(ReadLatAA_14_), .CI(carry30), .S(RSpi2Addr1902_14_), 
        .CON(n1115) );
  AHHCONX2 U1_1_17 ( .A(ReadLatAA_8_), .CI(ReadLatAA_7_), .S(RSpi2Addr1902_8_), 
        .CON(n172) );
  OAI221X4 U3314 ( .A0(n6094), .A1(n6077), .B0(n6095), .B1(n6030), .C0(n6308), 
        .Y(n6093) );
  INVX2 U3603 ( .A(n6084), .Y(n6082) );
  DFFRX2 ReadLatA0_reg_7_ ( .D(n5221), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_7_), .QN(n6363) );
  NAND2X8 U3604 ( .A(ARReady), .B(ARValid), .Y(n6453) );
  OAI222X1 U3605 ( .A0(RdWrapCnt[2]), .A1(n5623), .B0(n5623), .B1(n6384), .C0(
        RdWrapCnt[2]), .C1(n6384), .Y(n5673) );
  NAND2X1 U3606 ( .A(RSpi2Addr1902_24_), .B(n6013), .Y(n6424) );
  INVX3 U3607 ( .A(n35), .Y(carry21) );
  INVX3 U3608 ( .A(n516), .Y(carry23) );
  INVX1 U3609 ( .A(n6016), .Y(n6072) );
  INVX1 U3610 ( .A(n6059), .Y(n6071) );
  OAI222X1 U3611 ( .A0(RdWrapCnt[1]), .A1(n5594), .B0(n5594), .B1(n6373), .C0(
        RdWrapCnt[1]), .C1(n6373), .Y(n5674) );
  OAI222X1 U3612 ( .A0(RdWrapCnt[3]), .A1(n5633), .B0(n5633), .B1(n6385), .C0(
        RdWrapCnt[3]), .C1(n6385), .Y(n5638) );
  AOI221X1 U3613 ( .A0(n1), .A1(n6437), .B0(RdWrapCnt[6]), .B1(n5591), .C0(
        n5659), .Y(n5670) );
  NAND2BX1 U3614 ( .AN(n6419), .B(WriteLatAA_12_), .Y(n6266) );
  NAND3BX2 U3615 ( .AN(n6352), .B(WriteLatAA_18_), .C(n6179), .Y(n6173) );
  NAND2BX1 U3616 ( .AN(n6306), .B(n6251), .Y(n6191) );
  INVX3 U3617 ( .A(n6207), .Y(n6179) );
  NAND4BX1 U3618 ( .AN(n6351), .B(WriteLatAA_16_), .C(n6461), .D(n6427), .Y(
        n6207) );
  AHHCONX2 U1_1_11 ( .A(ReadLatAA_11_), .CI(ReadLatAA_10_), .S(
        RSpi2Addr1938_11_), .CON(n14) );
  OAI211X1 U3619 ( .A0(n6073), .A1(n6074), .B0(n6075), .C0(n6076), .Y(n6062)
         );
  INVX1 U3620 ( .A(n6113), .Y(n6105) );
  NAND2X1 U3621 ( .A(RSpi2Addr1938_24_), .B(n6071), .Y(n6421) );
  INVX3 U3622 ( .A(n716), .Y(carry25) );
  OAI221X1 U3623 ( .A0(n6092), .A1(n6064), .B0(n6085), .B1(n6074), .C0(n6076), 
        .Y(n6091) );
  AHHCONX2 U1_1_91 ( .A(ReadLatAA_18_), .CI(carry54), .S(RSpi2Addr1926_18_), 
        .CON(n714) );
  INVX3 U3624 ( .A(n810), .Y(carry54) );
  INVX3 U3625 ( .A(n24), .Y(carry_17_) );
  INVX3 U3626 ( .A(n410), .Y(carry22) );
  NAND2BX1 U3627 ( .AN(n6357), .B(n6429), .Y(n6113) );
  OAI211X1 U3628 ( .A0(WriteLatAA_20_), .A1(n6141), .B0(n6142), .C0(n6143), 
        .Y(BA_AA[20]) );
  OAI211X1 U3629 ( .A0(WriteLatAA_21_), .A1(n6124), .B0(n6125), .C0(n6126), 
        .Y(BA_AA[21]) );
  OAI31X1 U3630 ( .A0(n5809), .A1(WBLQRdData[2]), .A2(WBLQRdData[1]), .B0(
        n5817), .Y(n5738) );
  INVX6 U3631 ( .A(n6453), .Y(n5356) );
  AOI222X1 U3632 ( .A0(RdWrapCnt[4]), .A1(n5640), .B0(RdWrapCnt3036_4_), .B1(
        n5612), .C0(RQIncAddr[4]), .C1(n5607), .Y(n5636) );
  AOI222X1 U3633 ( .A0(RdWrapCnt[5]), .A1(n5640), .B0(RdWrapCnt3036_5_), .B1(
        n5612), .C0(RQIncAddr[5]), .C1(n5607), .Y(n5645) );
  OAI222X1 U3634 ( .A0(n5596), .A1(n5599), .B0(n5569), .B1(n6417), .C0(
        RdWrapCnt[0]), .C1(n5601), .Y(n5587) );
  AOI32X1 U3635 ( .A0(RdWrapCnt[0]), .A1(n6418), .A2(n5591), .B0(n5592), .B1(
        n5593), .Y(n5589) );
  AOI222X1 U3636 ( .A0(n5658), .A1(n5569), .B0(RQIncAddr[6]), .B1(n5607), .C0(
        RdWrapCnt[6]), .C1(n5659), .Y(n5655) );
  AOI32X1 U3637 ( .A0(RdWrapCnt[3]), .A1(n5630), .A2(n5591), .B0(
        RdWrapCnt3036_3_), .B1(n5612), .Y(n5625) );
  AOI222X1 U3638 ( .A0(n5597), .A1(n5627), .B0(RdWrapCnt[3]), .B1(n5586), .C0(
        RQIncAddr[3]), .C1(n5607), .Y(n5626) );
  AOI32X1 U3639 ( .A0(RdWrapCnt[2]), .A1(n5620), .A2(n5591), .B0(
        RdWrapCnt3036_2_), .B1(n5612), .Y(n5615) );
  AOI222X1 U3640 ( .A0(n5597), .A1(n5617), .B0(RdWrapCnt[2]), .B1(n5586), .C0(
        RQIncAddr[2]), .C1(n5607), .Y(n5616) );
  AOI32X1 U3641 ( .A0(n5611), .A1(RdWrapCnt[1]), .A2(n5591), .B0(
        RdWrapCnt3036_1_), .B1(n5612), .Y(n5604) );
  AOI222X1 U3642 ( .A0(n5597), .A1(n5606), .B0(RdWrapCnt[1]), .B1(n5586), .C0(
        RQIncAddr[1]), .C1(n5607), .Y(n5605) );
  DFFRX2 WrWrapCnt_reg_5_ ( .D(n5195), .CK(ACLK), .RN(ARESETB), .Q(
        WrWrapCnt[5]) );
  DFFRX2 WrWrapCnt_reg_3_ ( .D(n5197), .CK(ACLK), .RN(ARESETB), .Q(
        WrWrapCnt[3]) );
  DFFRX2 WrWrapCnt_reg_2_ ( .D(n5198), .CK(ACLK), .RN(ARESETB), .Q(
        WrWrapCnt[2]) );
  DFFRX2 WrWrapCnt_reg_1_ ( .D(n5199), .CK(ACLK), .RN(ARESETB), .Q(
        WrWrapCnt[1]) );
  DFFRX1 WrWrapCnt_reg_0_ ( .D(n5200), .CK(ACLK), .RN(ARESETB), .Q(
        WrWrapCnt[0]) );
  DFFRX1 RdWrapCnt_reg_6_ ( .D(n5278), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapCnt[6]) );
  DFFRX1 RdWrapCnt_reg_3_ ( .D(n5281), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapCnt[3]) );
  DFFRX1 RdWrapCnt_reg_2_ ( .D(n5282), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapCnt[2]) );
  DFFRX1 RdWrapCnt_reg_1_ ( .D(n5283), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapCnt[1]) );
  DFFRX1 RdDataMem_reg_31_ ( .D(n5295), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[31]), .QN(n5142) );
  DFFRX1 RdDataMem_reg_30_ ( .D(n5296), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[30]), .QN(n5141) );
  DFFRX1 RdDataMem_reg_29_ ( .D(n5297), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[29]), .QN(n5140) );
  DFFRX1 RdDataMem_reg_28_ ( .D(n5298), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[28]), .QN(n5139) );
  DFFRX1 RdDataMem_reg_27_ ( .D(n5299), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[27]), .QN(n5138) );
  DFFRX1 RdDataMem_reg_26_ ( .D(n5300), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[26]), .QN(n5137) );
  DFFRX1 RdDataMem_reg_25_ ( .D(n5301), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[25]), .QN(n5136) );
  DFFRX1 RdDataMem_reg_24_ ( .D(n5302), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[24]), .QN(n5135) );
  DFFRX1 RdDataMem_reg_23_ ( .D(n5303), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[23]), .QN(n5134) );
  DFFRX1 RdDataMem_reg_22_ ( .D(n5304), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[22]), .QN(n5133) );
  DFFRX1 RdDataMem_reg_21_ ( .D(n5305), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[21]), .QN(n5132) );
  DFFRX1 RdDataMem_reg_20_ ( .D(n5306), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[20]), .QN(n5131) );
  DFFRX1 RdDataMem_reg_19_ ( .D(n5307), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[19]), .QN(n5130) );
  DFFRX1 RdDataMem_reg_18_ ( .D(n5308), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[18]), .QN(n5129) );
  DFFRX1 RdDataMem_reg_17_ ( .D(n5309), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[17]), .QN(n5128) );
  DFFRX1 RdDataMem_reg_16_ ( .D(n5310), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[16]), .QN(n5127) );
  DFFRX1 RdDataMem_reg_15_ ( .D(n5311), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[15]) );
  DFFRX1 RdDataMem_reg_14_ ( .D(n5312), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[14]) );
  DFFRX1 RdDataMem_reg_13_ ( .D(n5313), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[13]) );
  DFFRX1 RdDataMem_reg_12_ ( .D(n5314), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[12]) );
  DFFRX1 RdDataMem_reg_11_ ( .D(n5315), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[11]) );
  DFFRX1 RdDataMem_reg_10_ ( .D(n5316), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[10]) );
  DFFRX1 RdDataMem_reg_9_ ( .D(n5317), .CK(ACLK), .RN(ARESETB), .Q(RQWrData[9]) );
  DFFRX1 RdDataMem_reg_8_ ( .D(n5318), .CK(ACLK), .RN(ARESETB), .Q(RQWrData[8]) );
  DFFRX1 RdDataMem_reg_7_ ( .D(n5319), .CK(ACLK), .RN(ARESETB), .Q(RQWrData[7]) );
  DFFRX1 RdDataMem_reg_6_ ( .D(n5320), .CK(ACLK), .RN(ARESETB), .Q(RQWrData[6]) );
  DFFRX1 RdDataMem_reg_5_ ( .D(n5321), .CK(ACLK), .RN(ARESETB), .Q(RQWrData[5]) );
  DFFRX1 RdDataMem_reg_4_ ( .D(n5322), .CK(ACLK), .RN(ARESETB), .Q(RQWrData[4]) );
  DFFRX1 RdDataMem_reg_3_ ( .D(n5323), .CK(ACLK), .RN(ARESETB), .Q(RQWrData[3]) );
  DFFRX1 RdDataMem_reg_2_ ( .D(n5324), .CK(ACLK), .RN(ARESETB), .Q(RQWrData[2]) );
  DFFRX1 RdDataMem_reg_1_ ( .D(n5325), .CK(ACLK), .RN(ARESETB), .Q(RQWrData[1]) );
  DFFRX1 RdDataMem_reg_0_ ( .D(n5326), .CK(ACLK), .RN(ARESETB), .Q(RQWrData[0]) );
  OA21X2 U3643 ( .A0(pog_array1), .A1(g_array9), .B0(g_array1), .Y(n6311) );
  OR2X1 U3644 ( .A(BA_STS[14]), .B(n6446), .Y(n6317) );
  AO21X1 U3645 ( .A0(pog_array3), .A1(g_array11), .B0(g_array4), .Y(n6346) );
  DFFRX1 RdWrapCnt_reg_4_ ( .D(n5280), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapCnt[4]), .QN(n6348) );
  AOI22X1 U3646 ( .A0(n6097), .A1(n6239), .B0(n6262), .B1(n6099), .Y(n6355) );
  DFFRX1 RdWrapCnt_reg_5_ ( .D(n5279), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapCnt[5]), .QN(n6411) );
  DFFRX1 WrWrapCnt_reg_4_ ( .D(n5196), .CK(ACLK), .RN(ARESETB), .Q(
        WrWrapCnt[4]), .QN(n6412) );
  DFFRX1 RdWrapCnt_reg_7_ ( .D(n5277), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapCnt[7]), .QN(n6413) );
  DFFRX1 RdWrapCnt_reg_0_ ( .D(n5284), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapCnt[0]), .QN(n6417) );
  DFFRX1 iDelayReadLast_reg ( .D(BA_STS[5]), .CK(ACLK), .RN(ARESETB), .Q(
        iDelayReadLast) );
  DFFRX1 RdIdMem_reg_0_ ( .D(iDelayReadId[0]), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[32]) );
  DFFRX1 RdIdMem_reg_1_ ( .D(iDelayReadId[1]), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[33]) );
  DFFRX1 RdIdMem_reg_2_ ( .D(iDelayReadId[2]), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[34]) );
  DFFRX1 RdIdMem_reg_3_ ( .D(iDelayReadId[3]), .CK(ACLK), .RN(ARESETB), .Q(
        RQWrData[35]) );
  DFFRX1 iDelayReadId_reg_0_ ( .D(BA_STS[6]), .CK(ACLK), .RN(ARESETB), .Q(
        iDelayReadId[0]) );
  DFFRX1 iDelayReadId_reg_1_ ( .D(BA_STS[7]), .CK(ACLK), .RN(ARESETB), .Q(
        iDelayReadId[1]) );
  DFFRX1 iDelayReadId_reg_2_ ( .D(BA_STS[8]), .CK(ACLK), .RN(ARESETB), .Q(
        iDelayReadId[2]) );
  DFFRX1 iDelayReadId_reg_3_ ( .D(BA_STS[9]), .CK(ACLK), .RN(ARESETB), .Q(
        iDelayReadId[3]) );
  NAND2X1 U3647 ( .A(WriteLatAA_24_), .B(n6062), .Y(n6420) );
  NAND2X1 U3648 ( .A(RSpi2Addr1926_24_), .B(n6072), .Y(n6422) );
  AND3X4 U3649 ( .A(n6420), .B(n6421), .C(n6422), .Y(n6070) );
  DFFRX2 ReadLatA0_reg_12_ ( .D(n5216), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_12_) );
  OAI211X2 U3650 ( .A0(WriteLatAA_24_), .A1(n6068), .B0(n6069), .C0(n6070), 
        .Y(BA_AA[24]) );
  INVX4 U3651 ( .A(n162), .Y(n6423) );
  AHHCONX4 U1_1_16 ( .A(ReadLatAA_9_), .CI(ReadLatAA_8_), .S(RSpi2Addr1914_9_), 
        .CON(n162) );
  INVX1 U3652 ( .A(n21), .Y(carry_14_) );
  NAND2X2 U3653 ( .A(RSpi2Addr1914_24_), .B(n6015), .Y(n6426) );
  INVX3 U3654 ( .A(n156), .Y(carry48) );
  NAND2BX2 U3655 ( .AN(n5820), .B(WValid), .Y(n5818) );
  INVX1 U3656 ( .A(n514), .Y(carry51) );
  INVX1 U3657 ( .A(n614), .Y(carry52) );
  INVX1 U3658 ( .A(n714), .Y(carry53) );
  INVX1 U3659 ( .A(n42), .Y(carry50) );
  INVX3 U3660 ( .A(n23), .Y(carry_16_) );
  INVX3 U3661 ( .A(n5818), .Y(iWValid) );
  DFFRX4 ReadLatA0_reg_11_ ( .D(n5217), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_11_) );
  INVX1 U3662 ( .A(n6103), .Y(n6092) );
  NAND2BX1 U3663 ( .AN(n6314), .B(n6085), .Y(n6103) );
  INVX1 U3664 ( .A(n6093), .Y(n6076) );
  INVX1 U3665 ( .A(n6191), .Y(n6153) );
  INVX1 U3666 ( .A(n6100), .Y(n6095) );
  INVX1 U3667 ( .A(n6104), .Y(n6085) );
  AND2X2 U3668 ( .A(WriteLatAA_20_), .B(n6428), .Y(n6429) );
  INVX1 U3669 ( .A(n6266), .Y(n6251) );
  AND3X4 U3670 ( .A(n6424), .B(n6425), .C(n6426), .Y(n6069) );
  INVX1 U3671 ( .A(n814), .Y(carry41) );
  INVX1 U3672 ( .A(n155), .Y(carry61) );
  INVX4 U3673 ( .A(n616), .Y(carry24) );
  INVX1 U3674 ( .A(n515), .Y(carry38) );
  INVX1 U3675 ( .A(n510), .Y(carry_11_) );
  INVX1 U3676 ( .A(n615), .Y(carry39) );
  INVX1 U3677 ( .A(n610), .Y(carry_10_) );
  INVX1 U3678 ( .A(n43), .Y(carry37) );
  INVX1 U3679 ( .A(n41), .Y(carry_12_) );
  INVX1 U3680 ( .A(n715), .Y(carry40) );
  INVX1 U3681 ( .A(n710), .Y(carry_9_) );
  INVX1 U3682 ( .A(n32), .Y(carry_13_) );
  INVX1 U3683 ( .A(n1410), .Y(carry60) );
  INVX1 U3684 ( .A(n1310), .Y(carry59) );
  INVX1 U3685 ( .A(n1413), .Y(carry47) );
  INVX1 U3686 ( .A(n1010), .Y(carry56) );
  INVX1 U3687 ( .A(n1114), .Y(carry44) );
  INVX1 U3688 ( .A(n1113), .Y(carry57) );
  INVX1 U3689 ( .A(n1014), .Y(carry43) );
  INVX1 U3690 ( .A(n1313), .Y(carry46) );
  INVX1 U3691 ( .A(n1213), .Y(carry45) );
  INVX1 U3692 ( .A(n1210), .Y(carry58) );
  INVX1 U3693 ( .A(n34), .Y(carry36) );
  INVX1 U3694 ( .A(n914), .Y(carry42) );
  INVX3 U3695 ( .A(n172), .Y(carry35) );
  DFFRX1 ReadLatA0_reg_24_ ( .D(n5204), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_24_) );
  NAND2X1 U3696 ( .A(n6014), .B(ReadLatAA_24_), .Y(n6425) );
  INVX3 U3697 ( .A(n815), .Y(carry26) );
  INVX1 U3698 ( .A(n5751), .Y(n_1314) );
  AND2X2 U3699 ( .A(WriteLatAA_14_), .B(n6153), .Y(n6427) );
  AOI222X1 U3700 ( .A0(WriteLatAA_22_), .A1(n6109), .B0(RSpi2Addr1938_22_), 
        .B1(n6071), .C0(RSpi2Addr1926_22_), .C1(n6072), .Y(n6108) );
  AOI222X1 U3701 ( .A0(RSpi2Addr1902_22_), .A1(n6013), .B0(n6014), .B1(
        ReadLatAA_22_), .C0(RSpi2Addr1914_22_), .C1(n6015), .Y(n6107) );
  OAI211X1 U3702 ( .A0(WriteLatAA_22_), .A1(n6106), .B0(n6107), .C0(n6108), 
        .Y(BA_AA[22]) );
  NAND2BX1 U3703 ( .AN(WrAddrHold), .B(iWQRead), .Y(n5548) );
  INVX1 U3704 ( .A(n5819), .Y(iWQRead) );
  INVX1 U3705 ( .A(n8), .Y(carry_8_) );
  INVX1 U3706 ( .A(n157), .Y(carry33) );
  OR4X1 U3707 ( .A(WBurstCnt[0]), .B(WBLQEmpty), .C(n5789), .D(n5548), .Y(
        n5751) );
  INVX1 U3708 ( .A(n33), .Y(carry49) );
  INVX1 U3709 ( .A(n1110), .Y(carry63) );
  INVX1 U3710 ( .A(n1314), .Y(carry31) );
  INVX1 U3711 ( .A(n13), .Y(carry65) );
  INVX1 U3712 ( .A(n1414), .Y(carry32) );
  INVX1 U3713 ( .A(n14), .Y(carry66) );
  INVX1 U3714 ( .A(n1214), .Y(carry30) );
  INVX1 U3715 ( .A(n12), .Y(carry64) );
  INVX1 U3716 ( .A(n9), .Y(carry_7_) );
  INVX1 U3717 ( .A(n915), .Y(carry27) );
  INVX1 U3718 ( .A(n1015), .Y(carry28) );
  INVX1 U3719 ( .A(n10), .Y(carry62) );
  INVX1 U3720 ( .A(n1115), .Y(carry29) );
  INVX1 U3721 ( .A(n163), .Y(carry34) );
  BUFX2 U3722 ( .A(g_array14), .Y(n6457) );
  BUFX2 U3723 ( .A(g_array14), .Y(n6456) );
  BUFX2 U3724 ( .A(g_array14), .Y(n6458) );
  DFFRX1 WriteLatA0_reg_11_ ( .D(n5159), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_11_), .QN(n6419) );
  AND2X1 U3725 ( .A(WriteLatAA_19_), .B(n6160), .Y(n6428) );
  NAND2BX1 U3726 ( .AN(n6354), .B(n6177), .Y(n6172) );
  OA21X1 U3727 ( .A0(WriteLatAA_13_), .A1(n6355), .B0(n6258), .Y(n6255) );
  AOI2BB1X1 U3728 ( .A0N(WriteLatAA_23_), .A1N(n6077), .B0(n6430), .Y(n6075)
         );
  OAI22X1 U3729 ( .A0(n6079), .A1(n6064), .B0(WriteLatAA_23_), .B1(n6030), .Y(
        n6430) );
  XNOR3X1 U3730 ( .A(WQIncAddr[5]), .B(n1391_27_), .C(n160), .Y(
        WrWrapCnt1390_5_) );
  OAI2BB1X1 U3731 ( .A0N(WrWrapCnt[5]), .A1N(n5733), .B0(n6431), .Y(n5195) );
  OAI21X1 U3732 ( .A0(n5735), .A1(n5736), .B0(n5707), .Y(n6431) );
  OR4X1 U3733 ( .A(a1416_28_), .B(a1416_27_), .C(a1416_30_), .D(a1416_29_), 
        .Y(n5773) );
  INVX1 U1_2_5_26 ( .A(n6458), .Y(a1416_28_) );
  INVX1 U1_2_5_25 ( .A(n6458), .Y(a1416_27_) );
  INVX1 U1_2_5_28 ( .A(n6457), .Y(a1416_30_) );
  OR4X1 U3734 ( .A(a1416_23_), .B(a1416_25_), .C(a1416_13_), .D(a1416_12_), 
        .Y(n5758) );
  INVX1 U1_2_5_11 ( .A(n6456), .Y(a1416_13_) );
  INVX1 U1_2_5_27 ( .A(n6456), .Y(a1416_29_) );
  INVX1 U1_2_5_10 ( .A(n6457), .Y(a1416_12_) );
  INVX1 U1_2_5_15 ( .A(n6456), .Y(a1416_17_) );
  INVX1 U1_2_5_16 ( .A(n6457), .Y(a1416_18_) );
  INVX1 U1_2_5_13 ( .A(n6458), .Y(a1416_15_) );
  INVX1 U1_2_5_7 ( .A(n6458), .Y(a1416_9_) );
  INVX1 U1_2_5_17 ( .A(n6457), .Y(a1416_19_) );
  INVX1 U1_2_5_21 ( .A(n6456), .Y(a1416_23_) );
  INVX1 U1_2_5_23 ( .A(n6457), .Y(a1416_25_) );
  INVX1 U1_2_5_24 ( .A(n6456), .Y(a1416_26_) );
  INVX1 U1_2_5_18 ( .A(n6456), .Y(a1416_20_) );
  INVX1 U1_2_5_22 ( .A(n6457), .Y(a1416_24_) );
  INVX1 U1_2_5_19 ( .A(n6458), .Y(a1416_21_) );
  INVX1 U1_2_5_20 ( .A(n6458), .Y(a1416_22_) );
  INVX1 U3735 ( .A(n6244), .Y(n6280) );
  INVX1 U3736 ( .A(n6218), .Y(n6063) );
  INVX1 U3737 ( .A(n5602), .Y(n5593) );
  NAND2BX1 U3738 ( .AN(n6097), .B(n6030), .Y(n6244) );
  NAND2BX1 U3739 ( .AN(n6098), .B(n6280), .Y(n6218) );
  INVX1 U3740 ( .A(n6030), .Y(n6099) );
  INVX1 U3741 ( .A(n6286), .Y(n6279) );
  INVX1 U3742 ( .A(n5719), .Y(n5710) );
  INVX1 U3743 ( .A(n6057), .Y(n6013) );
  INVX1 U3744 ( .A(n5870), .Y(n5922) );
  AO21X1 U3745 ( .A0(pog_array3), .A1(g_array11), .B0(g_array3), .Y(n6432) );
  NAND3BX1 U3746 ( .AN(a1416_6_), .B(g_array15), .C(g_array13), .Y(n5762) );
  INVX1 U1_2_4_5 ( .A(g_array12), .Y(g_array15) );
  INVX1 U1_2_4_14 ( .A(n31), .Y(g_array13) );
  INVX1 U1_2_5_4 ( .A(n6432), .Y(a1416_6_) );
  INVX1 U3747 ( .A(n31), .Y(g_array14) );
  INVX1 U3748 ( .A(n5941), .Y(n5882) );
  AOI21X1 U1_4_3_5 ( .A0(pog_array3), .A1(g_array11), .B0(g_array3), .Y(
        g_array12) );
  NAND2BX1 U3749 ( .AN(n5586), .B(n5591), .Y(n5602) );
  INVX1 U1_2_2_2 ( .A(g_array8), .Y(g_array11) );
  INVX1 U3750 ( .A(n5569), .Y(n5586) );
  INVX1 U3751 ( .A(n5599), .Y(n5607) );
  INVX1 U1_2_1_0 ( .A(g_array6), .Y(g_array9) );
  INVX1 U3752 ( .A(n5641), .Y(n5597) );
  INVX1 U3753 ( .A(n5816), .Y(n5794) );
  INVX1 U3754 ( .A(n5601), .Y(n5612) );
  INVX1 U3755 ( .A(n5944), .Y(n5961) );
  NAND2BX1 U3756 ( .AN(n5987), .B(n5875), .Y(n6030) );
  NAND2BX1 U3757 ( .AN(n_1314), .B(n6434), .Y(n5719) );
  NAND2BX1 U3758 ( .AN(n6314), .B(n6160), .Y(n6174) );
  NAND2BX1 U3759 ( .AN(n6314), .B(n6288), .Y(n6286) );
  NOR2X1 U3760 ( .A(n6314), .B(n6187), .Y(n6433) );
  AO22X1 U3761 ( .A0(n6094), .A1(n6098), .B0(n6095), .B1(n6099), .Y(n6084) );
  INVX1 U3762 ( .A(n6064), .Y(n6096) );
  INVX1 U3763 ( .A(n6074), .Y(n6097) );
  INVX1 U3764 ( .A(n6077), .Y(n6098) );
  INVX1 U3765 ( .A(BA_RW), .Y(n6009) );
  INVX1 U3766 ( .A(n6147), .Y(n6133) );
  INVX1 U3767 ( .A(n6172), .Y(n6160) );
  INVX1 U3768 ( .A(n5712), .Y(n5721) );
  INVX1 U3769 ( .A(n6148), .Y(n6122) );
  AOI222X1 U3770 ( .A0(n6097), .A1(n6428), .B0(n6098), .B1(n6133), .C0(n6122), 
        .C1(n6096), .Y(n6150) );
  INVX1 U3771 ( .A(n6299), .Y(n5995) );
  INVX1 U3772 ( .A(n6264), .Y(n6239) );
  INVX1 U3773 ( .A(n6271), .Y(n6260) );
  INVX1 U3774 ( .A(n5718), .Y(n5723) );
  INVX1 U3775 ( .A(n6232), .Y(n6223) );
  INVX1 U3776 ( .A(n6175), .Y(n6161) );
  INVX1 U3777 ( .A(n6130), .Y(n6119) );
  INVX1 U3778 ( .A(n6138), .Y(n6128) );
  NAND2BX1 U3779 ( .AN(n6314), .B(n6429), .Y(n6138) );
  INVX1 U3780 ( .A(n5729), .Y(n5748) );
  OR2X1 U3781 ( .A(BA_RW), .B(n5847), .Y(n5870) );
  NAND2BX1 U3782 ( .AN(n6299), .B(n6295), .Y(n6059) );
  NAND2BX1 U3783 ( .AN(RBLQRdData[3]), .B(RBLQRdData[0]), .Y(n5696) );
  NAND2BX1 U3784 ( .AN(n5987), .B(n6295), .Y(n6057) );
  NAND2BX1 U3785 ( .AN(n5964), .B(n6427), .Y(n6233) );
  NAND2BX1 U3786 ( .AN(BA_RW), .B(BA_PM), .Y(n5864) );
  INVX1 U3787 ( .A(n6022), .Y(n6014) );
  INVX1 U3788 ( .A(n6021), .Y(n6015) );
  OAI221X1 U3789 ( .A0(n6288), .A1(n6074), .B0(n6267), .B1(n6030), .C0(n6289), 
        .Y(n6278) );
  INVX1 U3790 ( .A(n6250), .Y(n6289) );
  INVX1 U3791 ( .A(n5979), .Y(n5841) );
  AO22X1 U3792 ( .A0(n6097), .A1(n6264), .B0(n6099), .B1(n6263), .Y(n6249) );
  AO22X1 U3793 ( .A0(n6117), .A1(n6099), .B0(n6098), .B1(n6119), .Y(n6132) );
  INVX1 U3794 ( .A(n5598), .Y(n5595) );
  OAI221X1 U3795 ( .A0(n6177), .A1(n6077), .B0(n6160), .B1(n6074), .C0(n6308), 
        .Y(n6176) );
  INVX1 U3796 ( .A(n5610), .Y(n5693) );
  INVX1 U3797 ( .A(n5964), .Y(n6267) );
  AO21X1 U3798 ( .A0(n6235), .A1(n6099), .B0(n6221), .Y(n6234) );
  INVX1 U3799 ( .A(n6233), .Y(n6235) );
  INVX1 U3800 ( .A(n6190), .Y(n6236) );
  INVX1 U3801 ( .A(n5832), .Y(n5873) );
  INVX1 U3802 ( .A(n5838), .Y(n5872) );
  INVX1 U3803 ( .A(n5927), .Y(n5912) );
  INVX1 U3804 ( .A(n5928), .Y(n5918) );
  INVX1 U3805 ( .A(n6263), .Y(n6262) );
  INVX1 U3806 ( .A(n6202), .Y(n6204) );
  INVX1 U3807 ( .A(n6019), .Y(n6017) );
  NAND2BX1 U3808 ( .AN(n5778), .B(n5744), .Y(n5816) );
  NAND2BX1 U3809 ( .AN(n5994), .B(n5989), .Y(n5941) );
  NAND3BX1 U3810 ( .AN(n5943), .B(n5944), .C(n5945), .Y(n5879) );
  AO21X1 U3811 ( .A0(n5702), .A1(n5579), .B0(n5695), .Y(n5699) );
  INVX1 U3812 ( .A(n5696), .Y(n5702) );
  AOI21X1 U1_4_1_2 ( .A0(pog_array4), .A1(g_array6), .B0(g_array5), .Y(
        g_array8) );
  NOR2X1 U1_5_0_2 ( .A(pog_array1), .B(pog_array0), .Y(pog_array4) );
  OAI21X1 U1_4_0_2 ( .A0(pog_array0), .A1(g_array1), .B0(g_array0), .Y(
        g_array5) );
  INVX1 U1_3_0_3 ( .A(pog_array), .Y(pog_array3) );
  INVX1 U1_2_3_6 ( .A(g_array10), .Y(n31) );
  OAI21X1 U1_4_2_6 ( .A0(pog_array5), .A1(g_array8), .B0(g_array7), .Y(
        g_array10) );
  INVX1 U3813 ( .A(pog_array3), .Y(pog_array5) );
  INVX1 U3814 ( .A(g_array3), .Y(g_array7) );
  OR4X1 U3815 ( .A(a1416_19_), .B(a1416_21_), .C(n5772), .D(n5773), .Y(n5755)
         );
  OR3X2 U3816 ( .A(a1416_5_), .B(a1416_9_), .C(n31), .Y(n5772) );
  INVX1 U1_2_0_3 ( .A(g_array), .Y(g_array4) );
  INVX1 U3817 ( .A(n5942), .Y(n5881) );
  INVX1 U3818 ( .A(n5807), .Y(n1391_27_) );
  NAND2BX1 U3819 ( .AN(n5805), .B(n159), .Y(n5807) );
  INVX1 U3820 ( .A(n5700), .Y(n5628) );
  OAI211X1 U3821 ( .A0(n5572), .A1(n5696), .B0(RBLQRdData[7]), .C0(n5701), .Y(
        n5700) );
  INVX1 U3822 ( .A(n5699), .Y(n5701) );
  OR2X1 U3823 ( .A(n5506), .B(n5987), .Y(n5944) );
  INVX1 U3824 ( .A(n5930), .Y(n5911) );
  INVX1 U3825 ( .A(n5937), .Y(n5917) );
  INVX1 U3826 ( .A(n5906), .Y(n5888) );
  INVX1 U3827 ( .A(n5904), .Y(n5898) );
  NOR4BBX1 U3828 ( .AN(n6435), .BN(n6436), .C(n5755), .D(n5756), .Y(n6434) );
  NOR4X1 U3829 ( .A(a1416_24_), .B(a1416_23_), .C(a1416_26_), .D(a1416_25_), 
        .Y(n6435) );
  NOR4X1 U3830 ( .A(a1416_20_), .B(a1416_19_), .C(a1416_22_), .D(a1416_21_), 
        .Y(n6436) );
  INVX1 U3831 ( .A(n6035), .Y(n6034) );
  INVX1 U3832 ( .A(n5871), .Y(n5867) );
  INVX1 U3833 ( .A(RBLQRdData[2]), .Y(n5579) );
  NAND4BX1 U3834 ( .AN(n5618), .B(n5610), .C(n5672), .D(n_5173), .Y(n5599) );
  NOR2BX1 U3835 ( .AN(n5598), .B(n5628), .Y(n5672) );
  NAND2BX1 U3836 ( .AN(RQRead), .B(n6459), .Y(n5569) );
  OAI31X1 U3837 ( .A0(n5688), .A1(n5595), .A2(n5628), .B0(n_5173), .Y(n5641)
         );
  NAND2BX1 U3838 ( .AN(n5618), .B(n5610), .Y(n5688) );
  NAND2BX1 U3839 ( .AN(n5586), .B(n6437), .Y(n5601) );
  NAND2X1 U3840 ( .A(pog_array2), .B(g_array2), .Y(g_array6) );
  INVX1 U3841 ( .A(n6460), .Y(n_5173) );
  INVX1 U3842 ( .A(n1393_30_), .Y(n5798) );
  INVX1 U3843 ( .A(n1393_29_), .Y(n5802) );
  INVX1 U3844 ( .A(n1393_31_), .Y(n5795) );
  INVX1 U3845 ( .A(n5648), .Y(n5591) );
  AO21X1 U3846 ( .A0(n5651), .A1(n5591), .B0(n5586), .Y(n5640) );
  AO21X1 U3847 ( .A0(n5591), .A1(n5650), .B0(n5586), .Y(n5659) );
  INVX1 U3848 ( .A(n5717), .Y(n5715) );
  INVX1 U3849 ( .A(RBLQRdData[1]), .Y(n5572) );
  INVX1 U3850 ( .A(n5631), .Y(n5630) );
  INVX1 U3851 ( .A(n5621), .Y(n5620) );
  INVX1 U3852 ( .A(n5844), .Y(n5845) );
  NAND3BX1 U3853 ( .AN(BA_STS[16]), .B(BA_STS[15]), .C(n5875), .Y(n6064) );
  NAND3BX1 U3854 ( .AN(BA_STS[15]), .B(BA_STS[16]), .C(n5875), .Y(n6074) );
  AO21X1 U3855 ( .A0(n6307), .A1(n6356), .B0(n5979), .Y(BA_RW) );
  OAI221X1 U3856 ( .A0(n6059), .A1(n6066), .B0(n6016), .B1(n6067), .C0(n6022), 
        .Y(n6065) );
  INVX1 U3857 ( .A(n11), .Y(n6066) );
  INVX1 U3858 ( .A(n17), .Y(n6067) );
  NAND3BX1 U3859 ( .AN(BA_STS[15]), .B(BA_STS[16]), .C(n6295), .Y(n6016) );
  NAND2BX1 U3860 ( .AN(n6470), .B(n6353), .Y(n5979) );
  NAND3BX1 U3861 ( .AN(n5719), .B(n6412), .C(n618), .Y(n5732) );
  NAND2BX1 U3862 ( .AN(n5925), .B(n5995), .Y(n6077) );
  NAND4BX1 U3863 ( .AN(n6351), .B(n6153), .C(n6442), .D(n6154), .Y(n6147) );
  INVX1 U3864 ( .A(n6155), .Y(n6154) );
  NAND3BX1 U3865 ( .AN(n6313), .B(n6461), .C(n6223), .Y(n6217) );
  NAND3BX1 U3866 ( .AN(n6352), .B(n6442), .C(n6151), .Y(n6148) );
  NAND3BX1 U3867 ( .AN(n_1314), .B(n6440), .C(n5707), .Y(n5779) );
  NAND3BX1 U3868 ( .AN(n5737), .B(n5738), .C(n_1314), .Y(n5712) );
  NAND3BX1 U3869 ( .AN(n5739), .B(n5740), .C(n5741), .Y(n5737) );
  NAND2BX1 U3870 ( .AN(n6434), .B(n5751), .Y(n5718) );
  NAND2BX1 U3871 ( .AN(BA_STS[15]), .B(n5994), .Y(n5987) );
  NAND2BX1 U3872 ( .AN(n6470), .B(n6290), .Y(n6250) );
  NAND2BX1 U3873 ( .AN(n6268), .B(n6251), .Y(n6264) );
  NAND2BX1 U3874 ( .AN(n6419), .B(n6279), .Y(n6271) );
  NAND2BX1 U3875 ( .AN(n6318), .B(n6161), .Y(n6149) );
  NAND2BX1 U3876 ( .AN(n6352), .B(n6196), .Y(n6187) );
  NAND2BX1 U3877 ( .AN(n6000), .B(BA_STS[16]), .Y(n6299) );
  NAND2BX1 U3878 ( .AN(n6316), .B(n6133), .Y(n6130) );
  NAND2BX1 U3879 ( .AN(n6365), .B(n6085), .Y(n6081) );
  NAND2BX1 U3880 ( .AN(n6312), .B(n6151), .Y(n6202) );
  NAND2BX1 U3881 ( .AN(n6358), .B(n6260), .Y(n6253) );
  INVX1 U3882 ( .A(n5790), .Y(n5791) );
  INVX1 U3883 ( .A(n6115), .Y(n6112) );
  NAND2BX1 U3884 ( .AN(n6357), .B(n6117), .Y(n6115) );
  AO21X1 U3885 ( .A0(n5710), .A1(n5749), .B0(n5548), .Y(n5729) );
  INVX1 U3886 ( .A(n618), .Y(n5749) );
  OAI222X1 U3887 ( .A0(n6064), .A1(n6080), .B0(n6074), .B1(n6081), .C0(n6082), 
        .C1(n6365), .Y(n6055) );
  NAND2BX1 U3888 ( .AN(n6359), .B(n6105), .Y(n6104) );
  INVX1 U3889 ( .A(n5548), .Y(n5707) );
  INVX1 U3890 ( .A(n5868), .Y(n6295) );
  INVX1 U3891 ( .A(n6203), .Y(n6151) );
  INVX1 U3892 ( .A(n5925), .Y(n5875) );
  AO21X1 U3893 ( .A0(n6161), .A1(n6099), .B0(n6171), .Y(n6170) );
  OAI222X1 U3894 ( .A0(n6172), .A1(n6074), .B0(n6173), .B1(n6077), .C0(n6064), 
        .C1(n6174), .Y(n6171) );
  INVX1 U3895 ( .A(n6131), .Y(n6117) );
  INVX1 U3896 ( .A(n6222), .Y(n6136) );
  NAND3BX1 U3897 ( .AN(n6312), .B(n6462), .C(n6210), .Y(n6222) );
  OAI222X1 U3898 ( .A0(n6136), .A1(n6030), .B0(n6461), .B1(n6063), .C0(n6216), 
        .C1(n6064), .Y(n6214) );
  INVX1 U3899 ( .A(n6217), .Y(n6216) );
  AO22X1 U3900 ( .A0(RSpi2Addr1902_16_), .A1(n6013), .B0(RSpi2Addr1926_16_), 
        .B1(n6072), .Y(n6219) );
  INVX1 U3901 ( .A(n6173), .Y(n6177) );
  OAI221X1 U3902 ( .A0(n5780), .A1(n5751), .B0(n6439), .B1(n6382), .C0(n5782), 
        .Y(n5185) );
  OAI221X1 U3903 ( .A0(n5707), .A1(n6440), .B0(n5778), .B1(n5751), .C0(n5779), 
        .Y(n5186) );
  OAI221X1 U3904 ( .A0(n6428), .A1(n6074), .B0(n6145), .B1(n6030), .C0(n6146), 
        .Y(n6144) );
  INVX1 U3905 ( .A(n6149), .Y(n6145) );
  AOI221X1 U3906 ( .A0(n6098), .A1(n6147), .B0(n6096), .B1(n6148), .C0(n6470), 
        .Y(n6146) );
  OAI221X1 U3907 ( .A0(n6433), .A1(n6064), .B0(n6185), .B1(n6030), .C0(n6186), 
        .Y(n6183) );
  AOI221X1 U3908 ( .A0(n6098), .A1(n6155), .B0(n6097), .B1(n6187), .C0(n6188), 
        .Y(n6186) );
  OAI221X1 U3909 ( .A0(n6429), .A1(n6074), .B0(n6128), .B1(n6064), .C0(n6129), 
        .Y(n6127) );
  AOI221X1 U3910 ( .A0(n6098), .A1(n6130), .B0(n6099), .B1(n6131), .C0(n6470), 
        .Y(n6129) );
  INVX1 U3911 ( .A(n6080), .Y(n6079) );
  AOI222X1 U3912 ( .A0(n6087), .A1(n6096), .B0(n6098), .B1(n6102), .C0(n6112), 
        .C1(n6099), .Y(n6114) );
  OAI221X1 U3913 ( .A0(n6179), .A1(n6077), .B0(n6196), .B1(n6074), .C0(n6201), 
        .Y(n6200) );
  AOI221X1 U3914 ( .A0(n6099), .A1(n6202), .B0(n6096), .B1(n6203), .C0(n6470), 
        .Y(n6201) );
  INVX1 U3915 ( .A(n6268), .Y(n6288) );
  INVX1 U3916 ( .A(n6206), .Y(n6196) );
  NAND2BX1 U3917 ( .AN(n6354), .B(n6179), .Y(n6206) );
  INVX1 U3918 ( .A(n6118), .Y(n6102) );
  NAND2BX1 U3919 ( .AN(n6357), .B(n6119), .Y(n6118) );
  OAI211X1 U3920 ( .A0(n6105), .A1(n6074), .B0(n6110), .C0(n6111), .Y(n6109)
         );
  OA21X2 U3921 ( .A0(n6112), .A1(n6030), .B0(n6308), .Y(n6111) );
  OA22X1 U3922 ( .A0(n6087), .A1(n6064), .B0(n6102), .B1(n6077), .Y(n6110) );
  OR2X1 U3923 ( .A(n6312), .B(n6174), .Y(n6175) );
  OR2X1 U3924 ( .A(n6306), .B(n6253), .Y(n6232) );
  INVX1 U3925 ( .A(n5742), .Y(n5716) );
  OAI31X1 U3926 ( .A0(n5743), .A1(n5744), .A2(n5739), .B0(n_1314), .Y(n5742)
         );
  NAND2BX1 U3927 ( .AN(n5745), .B(n5738), .Y(n5743) );
  INVX1 U3928 ( .A(n6101), .Y(n6094) );
  NAND2BX1 U3929 ( .AN(n6359), .B(n6102), .Y(n6101) );
  INVX1 U3930 ( .A(BA_STS[16]), .Y(n5994) );
  INVX1 U3931 ( .A(n6193), .Y(n6185) );
  NAND2BX1 U3932 ( .AN(n6312), .B(n6433), .Y(n6193) );
  NAND2BX1 U3933 ( .AN(n6312), .B(n6092), .Y(n6100) );
  INVX1 U3934 ( .A(BA_STS[15]), .Y(n6000) );
  INVX1 U3935 ( .A(n6062), .Y(n6061) );
  AFHCONX2 U1_24 ( .A(n6444), .B(n6464), .CI(carry0), .S(WPageMisCal403_2_), 
        .CON(n820) );
  INVX1 U3936 ( .A(n920), .Y(carry0) );
  AFHCONX2 U1_22 ( .A(n6444), .B(n6464), .CI(carry0), .S(WPageMisCal408_2_), 
        .CON(n918) );
  AND2X2 U3937 ( .A(BA_STS[14]), .B(n5861), .Y(BA_TT[4]) );
  AO22X1 U3938 ( .A0(BA_STS[14]), .A1(n5862), .B0(n5861), .B1(n5506), .Y(
        BA_TT[3]) );
  AO22X1 U3939 ( .A0(BA_STS[14]), .A1(n5899), .B0(n5862), .B1(n5506), .Y(
        BA_TT[2]) );
  AO22X1 U3940 ( .A0(BA_STS[14]), .A1(n5919), .B0(n5899), .B1(n5506), .Y(
        BA_TT[1]) );
  AO21X1 U3941 ( .A0(BA_STS[14]), .A1(BA_REQ), .B0(n5919), .Y(BA_TT[0]) );
  OAI31X1 U3942 ( .A0(n5696), .A1(RBLQRdData[2]), .A2(RBLQRdData[1]), .B0(
        n5697), .Y(n5610) );
  NOR2BX1 U3943 ( .AN(RBLQRdData[5]), .B(n5695), .Y(n5697) );
  NAND3BX1 U3944 ( .AN(BA_STS[16]), .B(BA_STS[15]), .C(n6295), .Y(n6021) );
  NAND2BX1 U3945 ( .AN(n5952), .B(n6470), .Y(n5832) );
  AFHCONX2 U1_34 ( .A(WriteLatAA_3_), .B(n6463), .CI(carry), .S(
        WPageMisCal403_3_), .CON(n724) );
  INVX1 U3946 ( .A(n820), .Y(carry) );
  NAND2BX1 U3947 ( .AN(n6307), .B(n6009), .Y(n6022) );
  NAND2BX1 U3948 ( .AN(n6312), .B(n6279), .Y(n5964) );
  AFHCONX2 U1_32 ( .A(WriteLatAA_3_), .B(n6463), .CI(carry4), .S(
        WPageMisCal408_3_), .CON(n818) );
  INVX1 U3949 ( .A(n918), .Y(carry4) );
  NAND2BX1 U3950 ( .AN(n6351), .B(n6098), .Y(n6190) );
  NAND2BX1 U3951 ( .AN(n5695), .B(RBLQRdData[4]), .Y(n5598) );
  NAND2BX1 U3952 ( .AN(n6308), .B(n5952), .Y(n5838) );
  NAND2BX1 U3953 ( .AN(n6266), .B(n6267), .Y(n6263) );
  AO21X1 U3954 ( .A0(n5932), .A1(n5879), .B0(n5933), .Y(n5927) );
  XOR3X1 U3955 ( .A(n6465), .B(carry1), .C(WriteLatAA_1_), .Y(n5932) );
  AO22X1 U3956 ( .A0(WPageMisCal408_1_), .A1(n5881), .B0(WPageMisCal403_1_), 
        .B1(n5882), .Y(n5933) );
  OR2X1 U3957 ( .A(n6307), .B(n5976), .Y(n5847) );
  INVX1 U3958 ( .A(n5980), .Y(BA_PM) );
  NAND2BX1 U3959 ( .AN(n6307), .B(n5976), .Y(n5980) );
  AO21X1 U3960 ( .A0(n6099), .A1(n6312), .B0(n6470), .Y(n6026) );
  AO21X1 U3961 ( .A0(n6462), .A1(n6024), .B0(n6097), .Y(n6020) );
  INVX1 U3962 ( .A(n5916), .Y(n5897) );
  OAI222X1 U3963 ( .A0(n6468), .A1(n5917), .B0(n5918), .B1(n5917), .C0(n6468), 
        .C1(n5918), .Y(n5916) );
  OAI221X1 U3964 ( .A0(n6462), .A1(n6064), .B0(n6462), .B1(n6030), .C0(n6300), 
        .Y(n6019) );
  INVX1 U3965 ( .A(n6026), .Y(n6300) );
  OAI211X1 U3966 ( .A0(n5863), .A1(n5864), .B0(n5865), .C0(n5866), .Y(n5861)
         );
  XOR3X1 U3967 ( .A(n5890), .B(n6323), .C(n5871), .Y(n5863) );
  AOI222X1 U3968 ( .A0(n5872), .A1(n6463), .B0(n5873), .B1(n5874), .C0(n5875), 
        .C1(n5876), .Y(n5865) );
  OA22X1 U3969 ( .A0(n5867), .A1(n5868), .B0(n6323), .B1(n5870), .Y(n5866) );
  INVX1 U3970 ( .A(n5855), .Y(RQRead) );
  NAND2BX1 U3971 ( .AN(n5829), .B(RReady), .Y(n5855) );
  NAND2BX1 U3972 ( .AN(RBLQRdData[8]), .B(RBLQRdData[9]), .Y(n5695) );
  XOR3X1 U3973 ( .A(n6463), .B(n5877), .C(n5876), .Y(n5874) );
  OAI222X1 U3974 ( .A0(n6464), .A1(n5888), .B0(n5889), .B1(n5888), .C0(n6464), 
        .C1(n5889), .Y(n5877) );
  NAND2BX1 U3975 ( .AN(n5920), .B(n5921), .Y(n5899) );
  OAI33X1 U3976 ( .A0(n5864), .A1(n5917), .A2(n5936), .B0(n5864), .B1(n5937), 
        .B2(n5938), .Y(n5920) );
  AOI211X1 U3977 ( .A0(n5922), .A1(n6468), .B0(n5923), .C0(n5924), .Y(n5921)
         );
  INVX1 U3978 ( .A(n5936), .Y(n5938) );
  OR2X1 U3979 ( .A(n5642), .B(n5634), .Y(n5643) );
  AFHCONX2 U1_1 ( .A(ReadLatAA_1_), .B(n6468), .CI(carry3), .S(
        RPageMisCal1705_1_), .CON(n1016) );
  AFHCONX2 U1_12 ( .A(WriteLatAA_1_), .B(n6465), .CI(carry1), .S(
        WPageMisCal408_1_) );
  AFHCONX2 U1_13 ( .A(ReadLatAA_1_), .B(n6468), .CI(carry3), .S(
        RPageMisCal1700_1_) );
  AFHCONX2 U1_14 ( .A(WriteLatAA_1_), .B(n6465), .CI(carry1), .S(
        WPageMisCal403_1_), .CON(n920) );
  INVX1 U3980 ( .A(n5820), .Y(WReady) );
  INVX1 U3981 ( .A(n6007), .Y(carry3) );
  NAND2BX1 U3982 ( .AN(n6360), .B(n6008), .Y(n6007) );
  INVX1 U3983 ( .A(n5972), .Y(carry1) );
  NAND2BX1 U3984 ( .AN(n6441), .B(n5973), .Y(n5972) );
  AO22X1 U3985 ( .A0(n6097), .A1(n6210), .B0(n6236), .B1(n6427), .Y(n6221) );
  OAI211X1 U3986 ( .A0(n5900), .A1(n5864), .B0(n5901), .C0(n5902), .Y(n5862)
         );
  XOR3X1 U3987 ( .A(n6467), .B(n5897), .C(n5904), .Y(n5900) );
  AOI222X1 U3988 ( .A0(n5872), .A1(n6464), .B0(n5873), .B1(n5905), .C0(n5875), 
        .C1(n5906), .Y(n5901) );
  OA22X1 U3989 ( .A0(n5898), .A1(n5868), .B0(n6364), .B1(n5870), .Y(n5902) );
  OAI222X1 U3990 ( .A0(n6467), .A1(n5897), .B0(n5898), .B1(n5897), .C0(n6467), 
        .C1(n5898), .Y(n5890) );
  OR2X1 U3991 ( .A(n5660), .B(n5653), .Y(n5661) );
  AO21X1 U3992 ( .A0(n5939), .A1(n5879), .B0(n5940), .Y(n5928) );
  XOR3X1 U3993 ( .A(n6468), .B(carry3), .C(ReadLatAA_1_), .Y(n5939) );
  AO22X1 U3994 ( .A0(RPageMisCal1705_1_), .A1(n5881), .B0(RPageMisCal1700_1_), 
        .B1(n5882), .Y(n5940) );
  AO22X1 U3995 ( .A0(n5751), .A1(WrWrapAddrSt_3_), .B0(n5739), .B1(n_1314), 
        .Y(n5191) );
  AO22X1 U3996 ( .A0(n5751), .A1(WrWrapAddrSt_1_), .B0(n5775), .B1(n_1314), 
        .Y(n5193) );
  AO22X1 U3997 ( .A0(n5751), .A1(WrWrapAddrSt_2_), .B0(n5745), .B1(n_1314), 
        .Y(n5192) );
  AO22X1 U3998 ( .A0(n5751), .A1(WrWrapAddrSt_0_), .B0(n_1314), .B1(n5744), 
        .Y(n5194) );
  OAI222X1 U3999 ( .A0(n6064), .A1(n6232), .B0(n6191), .B1(n6190), .C0(n6355), 
        .C1(n6306), .Y(n6245) );
  OAI33X1 U4000 ( .A0(n5832), .A1(n5911), .A2(n5929), .B0(n5832), .B1(n5930), 
        .B2(n5931), .Y(n5923) );
  INVX1 U4001 ( .A(n5929), .Y(n5931) );
  XOR2X1 U4002 ( .A(n5927), .B(n6465), .Y(n5929) );
  OAI222X1 U4003 ( .A0(n5947), .A1(n5868), .B0(n5935), .B1(n5925), .C0(n6441), 
        .C1(n5838), .Y(n5951) );
  OAI222X1 U4004 ( .A0(n5918), .A1(n5868), .B0(n5912), .B1(n5925), .C0(n6319), 
        .C1(n5838), .Y(n5924) );
  AO22X1 U4005 ( .A0(n6196), .A1(n6097), .B0(n6098), .B1(n6179), .Y(n6205) );
  AO22X1 U4006 ( .A0(RSpi2Addr1902_12_), .A1(n6013), .B0(RSpi2Addr1926_12_), 
        .B1(n6072), .Y(n6275) );
  AO22X1 U4007 ( .A0(RSpi2Addr1902_11_), .A1(n6013), .B0(RSpi2Addr1926_11_), 
        .B1(n6072), .Y(n6284) );
  AO22X1 U4008 ( .A0(RSpi2Addr1902_10_), .A1(n6013), .B0(RSpi2Addr1926_10_), 
        .B1(n6072), .Y(n6294) );
  AO22X1 U4009 ( .A0(RSpi2Addr1902_13_), .A1(n6013), .B0(RSpi2Addr1926_13_), 
        .B1(n6072), .Y(n6257) );
  AO22X1 U4010 ( .A0(RSpi2Addr1902_14_), .A1(n6013), .B0(RSpi2Addr1926_14_), 
        .B1(n6072), .Y(n6247) );
  OAI32X1 U4011 ( .A0(n6190), .A1(n6191), .A2(n6155), .B0(n6074), .B1(n6187), 
        .Y(n6189) );
  AOI32X1 U4012 ( .A0(n6099), .A1(n6461), .A2(n6136), .B0(n6461), .B1(n6221), 
        .Y(n6220) );
  INVX1 U4013 ( .A(n5954), .Y(n5973) );
  INVX1 U4014 ( .A(n5851), .Y(ARReady) );
  INVX1 U4015 ( .A(n5978), .Y(n6008) );
  INVX1 U4016 ( .A(n6163), .Y(n6043) );
  INVX1 U4017 ( .A(n6165), .Y(n6048) );
  INVX1 U4018 ( .A(n5843), .Y(AWReady) );
  AO21X1 U4019 ( .A0(n6098), .A1(n6266), .B0(n6250), .Y(n6265) );
  INVX1 U4020 ( .A(n5694), .Y(n5608) );
  NAND2BX1 U4021 ( .AN(n5596), .B(n5595), .Y(n5694) );
  INVX1 U4022 ( .A(n6290), .Y(n6297) );
  INVX1 U4023 ( .A(n5910), .Y(n5889) );
  OAI222X1 U4024 ( .A0(n6465), .A1(n5911), .B0(n5912), .B1(n5911), .C0(n6465), 
        .C1(n5912), .Y(n5910) );
  INVX1 U4025 ( .A(n5971), .Y(n5909) );
  OAI222X1 U4026 ( .A0(n6465), .A1(WriteLatAA_1_), .B0(carry1), .B1(
        WriteLatAA_1_), .C0(n6465), .C1(carry1), .Y(n5971) );
  INVX1 U4027 ( .A(n6006), .Y(n5915) );
  OAI222X1 U4028 ( .A0(n6468), .A1(ReadLatAA_1_), .B0(carry3), .B1(
        ReadLatAA_1_), .C0(n6468), .C1(carry3), .Y(n6006) );
  INVX1 U4029 ( .A(n5970), .Y(n5887) );
  OAI222X1 U4030 ( .A0(n6464), .A1(n5909), .B0(n6444), .B1(n5909), .C0(n6464), 
        .C1(n6444), .Y(n5970) );
  INVX1 U4031 ( .A(n6005), .Y(n5896) );
  OAI222X1 U4032 ( .A0(n6467), .A1(n5915), .B0(n6443), .B1(n5915), .C0(n6467), 
        .C1(n6443), .Y(n6005) );
  INVX1 U4033 ( .A(n6287), .Y(n6277) );
  OAI221X1 U4034 ( .A0(n6268), .A1(n6074), .B0(n5964), .B1(n6030), .C0(n6190), 
        .Y(n6287) );
  INVX1 U4035 ( .A(n5981), .Y(n5985) );
  INVX1 U4036 ( .A(n37), .Y(carry18) );
  AFHCONX2 U1_2 ( .A(n6443), .B(n6467), .CI(carry20), .S(RPageMisCal1705_2_), 
        .CON(n916) );
  INVX1 U4037 ( .A(n1016), .Y(carry20) );
  XOR2X1 U4038 ( .A(n5928), .B(n6468), .Y(n5936) );
  NAND2BX1 U4039 ( .AN(g_array4), .B(n165), .Y(g_array3) );
  XOR2X1 U4040 ( .A(n5506), .B(BA_STS[15]), .Y(n5989) );
  NAND2X1 U4041 ( .A(n6044), .B(n6043), .Y(n6035) );
  NAND2X1 U4042 ( .A(n6049), .B(n6048), .Y(n6039) );
  AFHCONX2 U1_3 ( .A(ReadLatAA_3_), .B(n6466), .CI(carry19), .S(
        RPageMisCal1705_3_), .CON(n816) );
  INVX1 U4043 ( .A(n916), .Y(carry19) );
  AFHCONX2 U1_33 ( .A(ReadLatAA_3_), .B(n6466), .CI(carry2), .S(
        RPageMisCal1700_3_), .CON(n720) );
  INVX1 U4044 ( .A(n819), .Y(carry2) );
  NAND2BX1 U4045 ( .AN(WBLQRdData[3]), .B(WBLQRdData[0]), .Y(n5809) );
  AO21X1 U4046 ( .A0(n5891), .A1(n5879), .B0(n5892), .Y(n5871) );
  AO22X1 U4047 ( .A0(RPageMisCal1705_3_), .A1(n5881), .B0(RPageMisCal1700_3_), 
        .B1(n5882), .Y(n5892) );
  NAND2BX1 U4048 ( .AN(n5893), .B(n5894), .Y(n5891) );
  AOI33X1 U4049 ( .A0(n5895), .A1(n6323), .A2(n5896), .B0(n6466), .B1(
        ReadLatAA_3_), .B2(n5896), .Y(n5894) );
  AO21X1 U4050 ( .A0(n5913), .A1(n5879), .B0(n5914), .Y(n5904) );
  XOR3X1 U4051 ( .A(n6467), .B(n6443), .C(n5915), .Y(n5913) );
  AO22X1 U4052 ( .A0(RPageMisCal1705_2_), .A1(n5881), .B0(RPageMisCal1700_2_), 
        .B1(n5882), .Y(n5914) );
  NAND2BX1 U4053 ( .AN(BA_STS[14]), .B(n5995), .Y(n5942) );
  NAND2BX1 U4054 ( .AN(n6441), .B(n5935), .Y(n5930) );
  NAND2BX1 U4055 ( .AN(n6360), .B(n5947), .Y(n5937) );
  NOR2X1 X0_2_3 ( .A(n6305), .B(n1361_29_), .Y(pog_array) );
  INVX1 U4056 ( .A(n5698), .Y(n5618) );
  NAND2BX1 U4057 ( .AN(n5699), .B(RBLQRdData[6]), .Y(n5698) );
  NOR2X1 X0_2_2 ( .A(n6327), .B(n1361_30_), .Y(pog_array0) );
  AO21X1 U4058 ( .A0(n5813), .A1(n5784), .B0(n5814), .Y(n5811) );
  INVX1 U4059 ( .A(n5809), .Y(n5813) );
  NAND2X1 X0_1_3 ( .A(n6305), .B(n1361_29_), .Y(g_array) );
  AO21X1 U4060 ( .A0(n5907), .A1(n5879), .B0(n5908), .Y(n5906) );
  XOR3X1 U4061 ( .A(n6464), .B(n6444), .C(n5909), .Y(n5907) );
  AO22X1 U4062 ( .A0(WPageMisCal408_2_), .A1(n5881), .B0(WPageMisCal403_2_), 
        .B1(n5882), .Y(n5908) );
  INVX1 U4063 ( .A(n5812), .Y(n5803) );
  OAI222X1 U4064 ( .A0(n1393_30_), .A1(n5799), .B0(n5799), .B1(n5741), .C0(
        n1393_30_), .C1(n5741), .Y(n5812) );
  NAND4BBX1 U4065 ( .AN(n5757), .BN(n5758), .C(n5759), .D(n5760), .Y(n5756) );
  AND4X1 U4066 ( .A(n5764), .B(n5765), .C(n5766), .D(n5767), .Y(n5759) );
  AOI31X1 U4067 ( .A0(n6305), .A1(n6327), .A2(n5761), .B0(n5762), .Y(n5760) );
  OR4X1 U4068 ( .A(a1416_15_), .B(a1416_15_), .C(a1416_18_), .D(a1416_17_), 
        .Y(n5757) );
  INVX1 U4069 ( .A(n5999), .Y(n5945) );
  OAI33X1 U4070 ( .A0(n5506), .A1(BA_STS[15]), .A2(n5994), .B0(n6000), .B1(
        BA_STS[16]), .B2(BA_STS[14]), .Y(n5999) );
  NAND2X1 X0_1_2 ( .A(n6327), .B(n1361_30_), .Y(g_array0) );
  AFHCONX2 U1_23 ( .A(n6443), .B(n6467), .CI(carry20), .S(RPageMisCal1700_2_), 
        .CON(n819) );
  XOR3X1 U4071 ( .A(n6464), .B(n5889), .C(n5888), .Y(n5905) );
  OAI32X1 U4072 ( .A0(n5942), .A1(n816), .A2(n6366), .B0(n720), .B1(n5941), 
        .Y(n5992) );
  AOI33X1 U4073 ( .A0(n1393_31_), .A1(n5775), .A2(n5794), .B0(n5738), .B1(
        n5795), .B2(n5794), .Y(n5793) );
  AOI33X1 U4074 ( .A0(n5745), .A1(n5798), .A2(n5799), .B0(n1393_30_), .B1(
        n5741), .B2(n5799), .Y(n5797) );
  AOI33X1 U4075 ( .A0(n5739), .A1(n5802), .A2(n5803), .B0(n1393_29_), .B1(
        n5804), .B2(n5803), .Y(n5801) );
  AO21X1 U4076 ( .A0(n5878), .A1(n5879), .B0(n5880), .Y(n5876) );
  AO22X1 U4077 ( .A0(WPageMisCal408_3_), .A1(n5881), .B0(WPageMisCal403_3_), 
        .B1(n5882), .Y(n5880) );
  NAND2BX1 U4078 ( .AN(n5883), .B(n5884), .Y(n5878) );
  AOI33X1 U4079 ( .A0(n5885), .A1(n6325), .A2(n5887), .B0(n6463), .B1(
        WriteLatAA_3_), .B2(n5887), .Y(n5884) );
  INVX1 U4080 ( .A(BA_STS[14]), .Y(n5506) );
  OAI33X1 U4081 ( .A0(n5887), .A1(n6463), .A2(n5885), .B0(n5887), .B1(
        WriteLatAA_3_), .B2(n6325), .Y(n5883) );
  OAI33X1 U4082 ( .A0(n5896), .A1(n6466), .A2(n5895), .B0(n5896), .B1(
        ReadLatAA_3_), .B2(n6323), .Y(n5893) );
  INVX1 U4083 ( .A(n5740), .Y(n5744) );
  INVX1 U4084 ( .A(WBLQRdData[0]), .Y(n5778) );
  INVX1 U4085 ( .A(n5738), .Y(n5775) );
  INVX1 U4086 ( .A(WBLQRdData[2]), .Y(n5784) );
  INVX1 U4087 ( .A(n5988), .Y(n5943) );
  NAND2BX1 U4088 ( .AN(BA_STS[16]), .B(n5989), .Y(n5988) );
  INVX1 U4089 ( .A(WriteLatAA_3_), .Y(n5885) );
  INVX1 U4090 ( .A(ReadLatAA_3_), .Y(n5895) );
  INVX1 U4091 ( .A(n5815), .Y(n5799) );
  OAI222X1 U4092 ( .A0(n1393_31_), .A1(n5816), .B0(n5738), .B1(n5816), .C0(
        n1393_31_), .C1(n5738), .Y(n5815) );
  INVX1 U4093 ( .A(n5808), .Y(n5805) );
  OAI222X1 U4094 ( .A0(n1393_29_), .A1(n5803), .B0(n5803), .B1(n5804), .C0(
        n1393_29_), .C1(n5804), .Y(n5808) );
  NAND3BX1 U4095 ( .AN(n5651), .B(n6411), .C(n6348), .Y(n5650) );
  NOR2X1 X0_2_1 ( .A(n6310), .B(n1361_31_), .Y(pog_array1) );
  XOR2X1 U4096 ( .A(n6326), .B(a1416_3_), .Y(n5765) );
  XOR2X1 U0_5_2 ( .A(part_diff_2_), .B(n6311), .Y(a1416_3_) );
  NAND2BX1 U0_3_2 ( .AN(pog_array0), .B(g_array0), .Y(part_diff_2_) );
  XOR2X1 U4097 ( .A(n6382), .B(a1416_2_), .Y(n5766) );
  XOR2X1 U0_5_1 ( .A(part_diff_1_), .B(g_array9), .Y(a1416_2_) );
  NAND2BX1 U0_3_1 ( .AN(pog_array1), .B(g_array1), .Y(part_diff_1_) );
  NAND2BX1 U4098 ( .AN(n5703), .B(n6383), .Y(n6460) );
  NAND2BX1 U4099 ( .AN(n5703), .B(n6383), .Y(n5567) );
  NAND2BX1 U4100 ( .AN(n5703), .B(n6383), .Y(n6459) );
  NAND2BX1 U4101 ( .AN(n5676), .B(n6460), .Y(n5648) );
  NAND2X1 X0_1_1 ( .A(n6310), .B(n1361_31_), .Y(g_array1) );
  INVX1 U4102 ( .A(n5825), .Y(n5823) );
  NAND2BX1 U4103 ( .AN(n6377), .B(n6445), .Y(n5825) );
  AO21X1 U4104 ( .A0(n5740), .A1(n5778), .B0(n5794), .Y(n5717) );
  NOR2X1 X0_2_0 ( .A(n6329), .B(n6367), .Y(pog_array2) );
  NAND2X1 X0_1_0 ( .A(n6329), .B(n6367), .Y(g_array2) );
  INVX1 U4105 ( .A(RQEmpty), .Y(n5859) );
  INVX1 U4106 ( .A(n26), .Y(carry17) );
  INVX1 U4107 ( .A(n5741), .Y(n5745) );
  OAI221X1 U4108 ( .A0(n5567), .A1(n5568), .B0(n5569), .B1(n6370), .C0(n5571), 
        .Y(n5288) );
  INVX1 U4109 ( .A(RBLQRdData[0]), .Y(n5568) );
  OAI221X1 U4110 ( .A0(n5567), .A1(n5572), .B0(n5573), .B1(n6372), .C0(n5575), 
        .Y(n5287) );
  INVX1 U4111 ( .A(n5576), .Y(n5573) );
  OAI32X1 U4112 ( .A0(n5648), .A1(n6411), .A2(n6348), .B0(n5602), .B1(n5650), 
        .Y(n5647) );
  AO21X1 U4113 ( .A0(n6437), .A1(n5667), .B0(n5658), .Y(n5666) );
  INVX1 U4114 ( .A(n1), .Y(n5667) );
  AND2X2 U4115 ( .A(n5676), .B(n5567), .Y(n6437) );
  INVX1 U4116 ( .A(NxtStRD[1]), .Y(n5703) );
  INVX1 U4117 ( .A(n5804), .Y(n5739) );
  INVX1 U4118 ( .A(WBLQRdData[1]), .Y(n5780) );
  INVX1 U4119 ( .A(n5638), .Y(n5651) );
  XOR2X1 U4120 ( .A(n165), .B(n6346), .Y(a1416_5_) );
  XOR2X1 U4121 ( .A(n6385), .B(n5633), .Y(n5631) );
  XOR2X1 U4122 ( .A(n6384), .B(n5623), .Y(n5621) );
  XOR2X1 U4123 ( .A(n6440), .B(a1416_1_), .Y(n5767) );
  NAND2BX1 U0_3_0 ( .AN(pog_array2), .B(g_array2), .Y(a1416_1_) );
  XOR2X1 U4124 ( .A(n6324), .B(n5550), .Y(n5292) );
  INVX1 U4125 ( .A(n5566), .Y(RLast) );
  AO22X1 U4126 ( .A0(n6444), .A1(n6470), .B0(n6014), .B1(n6443), .Y(BA_AA[2])
         );
  AO22X1 U4127 ( .A0(n6470), .A1(WriteLatAA_3_), .B0(n6014), .B1(ReadLatAA_3_), 
        .Y(BA_AA[3]) );
  AO22X1 U4128 ( .A0(n6470), .A1(WriteLatAA_1_), .B0(n6014), .B1(ReadLatAA_1_), 
        .Y(BA_AA[1]) );
  AO22X1 U4129 ( .A0(n6470), .A1(n5973), .B0(n6014), .B1(n6008), .Y(BA_AA[0])
         );
  NOR2BX1 U4130 ( .AN(n6310), .B(WrWrapAddrSt_0_), .Y(n5761) );
  INVX1 U4131 ( .A(n5829), .Y(RValid) );
  NAND2BX1 U4132 ( .AN(n6349), .B(n5841), .Y(n5844) );
  NAND2BX1 U4133 ( .AN(n5506), .B(n5512), .Y(n5515) );
  INVX1 U4134 ( .A(n5611), .Y(n5613) );
  INVX1 U4135 ( .A(n5594), .Y(n5592) );
  INVX1 U4136 ( .A(BA_STS[3]), .Y(AckMem251) );
  NAND2BX1 U4137 ( .AN(n5843), .B(AWValid), .Y(n6455) );
  NAND2BX1 U4138 ( .AN(n5843), .B(AWValid), .Y(n6454) );
  NAND2BX1 U4139 ( .AN(n5843), .B(AWValid), .Y(n5790) );
  NAND2BX1 U4140 ( .AN(n5818), .B(WLast), .Y(n5835) );
  INVX1 U4141 ( .A(n6055), .Y(n6068) );
  NAND2BX1 U4142 ( .AN(n5851), .B(ARValid), .Y(n5706) );
  NAND2BX1 U4143 ( .AN(n5851), .B(ARValid), .Y(n6451) );
  NAND2BX1 U4144 ( .AN(n5851), .B(ARValid), .Y(n6452) );
  NAND4BX1 U4145 ( .AN(n6313), .B(n6461), .C(WriteLatAA_17_), .D(
        WriteLatAA_16_), .Y(n6155) );
  NAND4BX1 U4146 ( .AN(n6134), .B(WriteLatAA_20_), .C(n6442), .D(n6136), .Y(
        n6131) );
  NAND3BX1 U4147 ( .AN(n6352), .B(WriteLatAA_16_), .C(n6461), .Y(n6134) );
  NAND4X1 U4148 ( .A(WriteLatAA_16_), .B(n6461), .C(n6462), .D(n6210), .Y(
        n6203) );
  NAND3BX1 U4149 ( .AN(n6359), .B(WriteLatAA_23_), .C(n6087), .Y(n6080) );
  NAND2BX1 U4150 ( .AN(tRRReq), .B(n6009), .Y(n5868) );
  NAND2BX1 U4151 ( .AN(WriteLatAA_10_), .B(n6098), .Y(n6290) );
  NAND2BX1 U4152 ( .AN(n6470), .B(tWWSpi), .Y(n5925) );
  NAND3BX1 U4153 ( .AN(WBurstCnt[3]), .B(n6326), .C(n6382), .Y(n5789) );
  NAND2BX1 U4154 ( .AN(n6354), .B(WriteLatAA_10_), .Y(n6268) );
  NAND2BX1 U4155 ( .AN(WBurstCnt[1]), .B(n6439), .Y(n5785) );
  OA21X2 U4156 ( .A0(n6030), .A1(n6149), .B0(n6150), .Y(n6141) );
  AOI222X1 U4157 ( .A0(WriteLatAA_20_), .A1(n6144), .B0(RSpi2Addr1938_20_), 
        .B1(n6071), .C0(RSpi2Addr1926_20_), .C1(n6072), .Y(n6143) );
  AOI222X1 U4158 ( .A0(RSpi2Addr1902_20_), .A1(n6013), .B0(n6014), .B1(
        ReadLatAA_20_), .C0(RSpi2Addr1914_20_), .C1(n6015), .Y(n6142) );
  AOI221X1 U4159 ( .A0(n6128), .A1(n6096), .B0(n6097), .B1(n6429), .C0(n6132), 
        .Y(n6124) );
  AOI222X1 U4160 ( .A0(WriteLatAA_21_), .A1(n6127), .B0(RSpi2Addr1938_21_), 
        .B1(n6071), .C0(RSpi2Addr1926_21_), .C1(n6072), .Y(n6126) );
  AOI222X1 U4161 ( .A0(RSpi2Addr1902_21_), .A1(n6013), .B0(n6014), .B1(
        ReadLatAA_21_), .C0(RSpi2Addr1914_21_), .C1(n6015), .Y(n6125) );
  OAI211X1 U4162 ( .A0(n6167), .A1(n6318), .B0(n6168), .C0(n6169), .Y(
        BA_AA[19]) );
  AOI221X1 U4163 ( .A0(n6099), .A1(n6175), .B0(n6096), .B1(n6174), .C0(n6176), 
        .Y(n6167) );
  AOI222X1 U4164 ( .A0(n6170), .A1(n6318), .B0(RSpi2Addr1938_19_), .B1(n6071), 
        .C0(RSpi2Addr1926_19_), .C1(n6072), .Y(n6169) );
  AOI222X1 U4165 ( .A0(RSpi2Addr1902_19_), .A1(n6013), .B0(n6014), .B1(
        ReadLatAA_19_), .C0(RSpi2Addr1914_19_), .C1(n6015), .Y(n6168) );
  OAI221X1 U4166 ( .A0(n6461), .A1(n6224), .B0(n6225), .B1(n6322), .C0(n6227), 
        .Y(BA_AA[15]) );
  AOI222X1 U4167 ( .A0(n6096), .A1(n6232), .B0(n6099), .B1(n6233), .C0(n6096), 
        .C1(n6313), .Y(n6225) );
  AOI31X1 U4168 ( .A0(n6096), .A1(WriteLatAA_14_), .A2(n6223), .B0(n6234), .Y(
        n6224) );
  OAI211X1 U4169 ( .A0(WriteLatAA_16_), .A1(n6211), .B0(n6212), .C0(n6213), 
        .Y(BA_AA[16]) );
  OA21X2 U4170 ( .A0(n6064), .A1(n6217), .B0(n6220), .Y(n6211) );
  AOI221X1 U4171 ( .A0(RSpi2Addr1914_16_), .A1(n6015), .B0(n6014), .B1(
        ReadLatAA_16_), .C0(n6219), .Y(n6212) );
  AOI222X1 U4172 ( .A0(WriteLatAA_16_), .A1(n6214), .B0(WriteLatAA_16_), .B1(
        n6215), .C0(RSpi2Addr1938_16_), .C1(n6071), .Y(n6213) );
  OAI211X1 U4173 ( .A0(n6241), .A1(n6313), .B0(n6242), .C0(n6243), .Y(
        BA_AA[14]) );
  AOI32X1 U4174 ( .A0(WriteLatAA_14_), .A1(n6306), .A2(n6244), .B0(n6245), 
        .B1(n6313), .Y(n6243) );
  AOI211X1 U4175 ( .A0(RSpi2Addr1938_14_), .A1(n6071), .B0(n6247), .C0(n6248), 
        .Y(n6242) );
  AOI211X1 U4176 ( .A0(n6096), .A1(n6232), .B0(n6249), .C0(n6188), .Y(n6241)
         );
  OAI211X1 U4177 ( .A0(WriteLatAA_18_), .A1(n6180), .B0(n6181), .C0(n6182), 
        .Y(BA_AA[18]) );
  AOI221X1 U4178 ( .A0(n6185), .A1(n6099), .B0(n6433), .B1(n6096), .C0(n6189), 
        .Y(n6180) );
  AOI222X1 U4179 ( .A0(RSpi2Addr1902_18_), .A1(n6013), .B0(n6014), .B1(
        ReadLatAA_18_), .C0(RSpi2Addr1914_18_), .C1(n6015), .Y(n6181) );
  AOI222X1 U4180 ( .A0(WriteLatAA_18_), .A1(n6183), .B0(RSpi2Addr1938_18_), 
        .B1(n6071), .C0(RSpi2Addr1926_18_), .C1(n6072), .Y(n6182) );
  OAI211X1 U4181 ( .A0(WriteLatAA_17_), .A1(n6197), .B0(n6198), .C0(n6199), 
        .Y(BA_AA[17]) );
  AOI221X1 U4182 ( .A0(n6151), .A1(n6096), .B0(n6204), .B1(n6099), .C0(n6205), 
        .Y(n6197) );
  AOI222X1 U4183 ( .A0(RSpi2Addr1902_17_), .A1(n6013), .B0(n6014), .B1(
        ReadLatAA_17_), .C0(RSpi2Addr1914_17_), .C1(n6015), .Y(n6198) );
  AOI222X1 U4184 ( .A0(WriteLatAA_17_), .A1(n6200), .B0(RSpi2Addr1938_17_), 
        .B1(n6071), .C0(RSpi2Addr1926_17_), .C1(n6072), .Y(n6199) );
  AHHCONX2 U1_1_131 ( .A(ReadLatAA_22_), .CI(carry50), .S(RSpi2Addr1926_22_), 
        .CON(n33) );
  OAI2BB2X1 U4185 ( .A0N(WrWrapCnt[4]), .A1N(n5729), .B0(n5728), .B1(n5548), 
        .Y(n5196) );
  AOI211X1 U4186 ( .A0(WQIncAddr[4]), .A1(n5721), .B0(n5730), .C0(n5731), .Y(
        n5728) );
  INVX1 U4187 ( .A(n5732), .Y(n5731) );
  AO22X1 U4188 ( .A0(WrWrapCnt1377_4_), .A1(n5723), .B0(WrWrapCnt1390_4_), 
        .B1(n5716), .Y(n5730) );
  OAI211X1 U4189 ( .A0(WriteLatAA_23_), .A1(n6088), .B0(n6089), .C0(n6090), 
        .Y(BA_AA[23]) );
  AOI221X1 U4190 ( .A0(n6092), .A1(n6096), .B0(n6097), .B1(n6085), .C0(n6084), 
        .Y(n6088) );
  AOI222X1 U4191 ( .A0(WriteLatAA_23_), .A1(n6091), .B0(RSpi2Addr1938_23_), 
        .B1(n6071), .C0(RSpi2Addr1926_23_), .C1(n6072), .Y(n6090) );
  AHHCONX2 U1_1_151 ( .A(ReadLatAA_24_), .CI(carry_15_), .S(RSpi2Addr1926_24_), 
        .CON(n17) );
  INVX3 U4192 ( .A(n22), .Y(carry_15_) );
  INVX1 U4193 ( .A(n6081), .Y(n6073) );
  OAI211X1 U4194 ( .A0(n6050), .A1(n6328), .B0(n6052), .C0(n6053), .Y(
        BA_AA[25]) );
  AO21X1 U4195 ( .A0(n6060), .A1(n6061), .B0(n6371), .Y(n6052) );
  AOI32X1 U4196 ( .A0(WriteLatAA_24_), .A1(n6371), .A2(n6055), .B0(n6056), 
        .B1(n6328), .Y(n6053) );
  BUFX2 U4197 ( .A(WriteLatAA_15_), .Y(n6461) );
  BUFX2 U4198 ( .A(tWWReq), .Y(n6470) );
  AHHCONX2 U1_1_81 ( .A(ReadLatAA_17_), .CI(carry55), .S(RSpi2Addr1926_17_), 
        .CON(n810) );
  AO22X1 U4199 ( .A0(WriteLatBB[1]), .A1(n6455), .B0(AWBurst[1]), .B1(n5791), 
        .Y(n5143) );
  AO22X1 U4200 ( .A0(WriteLatBB[0]), .A1(n6454), .B0(AWBurst[0]), .B1(n5791), 
        .Y(n5144) );
  AO22X1 U4201 ( .A0(WriteLatAA_25_), .A1(n5790), .B0(AWAddr[25]), .B1(n5791), 
        .Y(n5145) );
  AO22X1 U4202 ( .A0(WriteLatAA_24_), .A1(n6455), .B0(AWAddr[24]), .B1(n5791), 
        .Y(n5146) );
  AO22X1 U4203 ( .A0(WriteLatAA_23_), .A1(n6454), .B0(AWAddr[23]), .B1(n5791), 
        .Y(n5147) );
  AO22X1 U4204 ( .A0(WriteLatAA_22_), .A1(n5790), .B0(AWAddr[22]), .B1(n5791), 
        .Y(n5148) );
  AO22X1 U4205 ( .A0(WriteLatAA_21_), .A1(n6455), .B0(AWAddr[21]), .B1(n5791), 
        .Y(n5149) );
  AO22X1 U4206 ( .A0(WriteLatAA_20_), .A1(n6454), .B0(AWAddr[20]), .B1(n5791), 
        .Y(n5150) );
  AO22X1 U4207 ( .A0(WriteLatAA_19_), .A1(n5790), .B0(AWAddr[19]), .B1(n5791), 
        .Y(n5151) );
  AO22X1 U4208 ( .A0(WriteLatAA_18_), .A1(n6455), .B0(AWAddr[18]), .B1(n5791), 
        .Y(n5152) );
  AO22X1 U4209 ( .A0(WriteLatAA_17_), .A1(n6454), .B0(AWAddr[17]), .B1(n5791), 
        .Y(n5153) );
  AO22X1 U4210 ( .A0(WriteLatAA_16_), .A1(n5790), .B0(AWAddr[16]), .B1(n5791), 
        .Y(n5154) );
  AO22X1 U4211 ( .A0(WriteLatAA_15_), .A1(n6455), .B0(AWAddr[15]), .B1(n5791), 
        .Y(n5155) );
  AO22X1 U4212 ( .A0(WriteLatAA_14_), .A1(n6454), .B0(AWAddr[14]), .B1(n5791), 
        .Y(n5156) );
  AO22X1 U4213 ( .A0(WriteLatAA_13_), .A1(n5790), .B0(AWAddr[13]), .B1(n5791), 
        .Y(n5157) );
  AO22X1 U4214 ( .A0(WriteLatAA_12_), .A1(n6455), .B0(AWAddr[12]), .B1(n5791), 
        .Y(n5158) );
  AO22X1 U4215 ( .A0(WriteLatAA_11_), .A1(n6454), .B0(AWAddr[11]), .B1(n5791), 
        .Y(n5159) );
  AO22X1 U4216 ( .A0(WriteLatAA_10_), .A1(n5790), .B0(AWAddr[10]), .B1(n5791), 
        .Y(n5160) );
  AO22X1 U4217 ( .A0(WriteLatAA_9_), .A1(n6455), .B0(AWAddr[9]), .B1(n5791), 
        .Y(n5161) );
  AO22X1 U4218 ( .A0(WriteLatAA_8_), .A1(n6454), .B0(AWAddr[8]), .B1(n5791), 
        .Y(n5162) );
  AO22X1 U4219 ( .A0(WriteLatAA_7_), .A1(n5790), .B0(AWAddr[7]), .B1(n5791), 
        .Y(n5163) );
  AO22X1 U4220 ( .A0(WriteLatAA_6_), .A1(n6455), .B0(AWAddr[6]), .B1(n5791), 
        .Y(n5164) );
  AO22X1 U4221 ( .A0(WriteLatAA_5_), .A1(n6454), .B0(AWAddr[5]), .B1(n5791), 
        .Y(n5165) );
  AO22X1 U4222 ( .A0(WriteLatAA_4_), .A1(n6455), .B0(AWAddr[4]), .B1(n5791), 
        .Y(n5166) );
  AO22X1 U4223 ( .A0(WriteLatA0_3_), .A1(n6455), .B0(AWAddr[3]), .B1(n5791), 
        .Y(n5167) );
  AO22X1 U4224 ( .A0(WriteLatA0_2_), .A1(n6454), .B0(AWAddr[2]), .B1(n5791), 
        .Y(n5168) );
  AO22X1 U4225 ( .A0(WriteLatA0_1_), .A1(n6454), .B0(AWAddr[1]), .B1(n5791), 
        .Y(n5169) );
  AO22X1 U4226 ( .A0(WriteLatA0_0_), .A1(n6455), .B0(AWAddr[0]), .B1(n5791), 
        .Y(n5170) );
  AO22X1 U4227 ( .A0(n5332), .A1(n6454), .B0(AWLen[3]), .B1(n5791), .Y(n5171)
         );
  AO22X1 U4228 ( .A0(n5334), .A1(n6455), .B0(AWLen[2]), .B1(n5791), .Y(n5172)
         );
  AO22X1 U4229 ( .A0(n5336), .A1(n6455), .B0(AWLen[1]), .B1(n5791), .Y(n5173)
         );
  AO22X1 U4230 ( .A0(n5338), .A1(n6454), .B0(AWLen[0]), .B1(n5791), .Y(n5174)
         );
  AO22X1 U4231 ( .A0(WriteReqID[3]), .A1(n6454), .B0(AWId[3]), .B1(n5791), .Y(
        n5175) );
  AO22X1 U4232 ( .A0(WriteReqID[2]), .A1(n6455), .B0(AWId[2]), .B1(n5791), .Y(
        n5176) );
  AO22X1 U4233 ( .A0(WriteReqID[1]), .A1(n6454), .B0(AWId[1]), .B1(n5791), .Y(
        n5177) );
  AO22X1 U4234 ( .A0(WriteReqID[0]), .A1(n6455), .B0(AWId[0]), .B1(n5791), .Y(
        n5178) );
  AO22X1 U4235 ( .A0(BId[3]), .A1(n6455), .B0(AWId[3]), .B1(n5791), .Y(n5179)
         );
  AO22X1 U4236 ( .A0(BId[2]), .A1(n6454), .B0(AWId[2]), .B1(n5791), .Y(n5180)
         );
  AO22X1 U4237 ( .A0(BId[1]), .A1(n6454), .B0(AWId[1]), .B1(n5791), .Y(n5181)
         );
  AO22X1 U4238 ( .A0(BId[0]), .A1(n6455), .B0(AWId[0]), .B1(n5791), .Y(n5182)
         );
  NAND2BX1 U4239 ( .AN(WQEmpty), .B(BA_STS[0]), .Y(n5819) );
  OR2X1 U4240 ( .A(WBurstCnt[1]), .B(n5779), .Y(n5782) );
  INVX1 U4241 ( .A(n6237), .Y(n6210) );
  NAND3BX1 U4242 ( .AN(n6306), .B(WriteLatAA_14_), .C(n6239), .Y(n6237) );
  NOR2BX1 U4243 ( .AN(n6228), .B(n6229), .Y(n6227) );
  AOI221X1 U4244 ( .A0(RSpi2Addr1914_15_), .A1(n6015), .B0(n6014), .B1(
        ReadLatAA_15_), .C0(n6231), .Y(n6228) );
  AO22X1 U4245 ( .A0(RSpi2Addr1938_15_), .A1(n6071), .B0(n6461), .B1(n6215), 
        .Y(n6229) );
  AO22X1 U4246 ( .A0(RSpi2Addr1902_15_), .A1(n6013), .B0(RSpi2Addr1926_15_), 
        .B1(n6072), .Y(n6231) );
  OAI221X1 U4247 ( .A0(n6210), .A1(n6074), .B0(WriteLatAA_14_), .B1(n6077), 
        .C0(n6230), .Y(n6215) );
  INVX1 U4248 ( .A(n6188), .Y(n6230) );
  AO22X1 U4249 ( .A0(WrWrapCnt1390_5_), .A1(n5716), .B0(WQIncAddr[5]), .B1(
        n5721), .Y(n5736) );
  OAI222X1 U4250 ( .A0(n5783), .A1(n6326), .B0(n5751), .B1(n5784), .C0(
        WBurstCnt[2]), .C1(n5782), .Y(n5184) );
  INVX1 U4251 ( .A(n5785), .Y(n5783) );
  OAI32X1 U4252 ( .A0(n5718), .A1(n164), .A2(WrWrapCnt[5]), .B0(WrWrapCnt[5]), 
        .B1(n5732), .Y(n5735) );
  INVX1 U4253 ( .A(n6120), .Y(n6087) );
  NAND3BX1 U4254 ( .AN(n6316), .B(WriteLatAA_21_), .C(n6122), .Y(n6120) );
  AO22X1 U4255 ( .A0(WrWrapCnt[3]), .A1(n5548), .B0(n5707), .B1(n5726), .Y(
        n5197) );
  OAI2BB1X1 U4256 ( .A0N(WQIncAddr[3]), .A1N(n5721), .B0(n5727), .Y(n5726) );
  AOI222X1 U4257 ( .A0(WrWrapCnt1390_3_), .A1(n5716), .B0(WrWrapCnt1377_3_), 
        .B1(n5723), .C0(WrWrapCnt1356_3_), .C1(n5710), .Y(n5727) );
  AO22X1 U4258 ( .A0(WrWrapCnt[2]), .A1(n5548), .B0(n5707), .B1(n5724), .Y(
        n5198) );
  OAI2BB1X1 U4259 ( .A0N(WQIncAddr[2]), .A1N(n5721), .B0(n5725), .Y(n5724) );
  AOI222X1 U4260 ( .A0(WrWrapCnt1390_2_), .A1(n5716), .B0(WrWrapCnt1377_2_), 
        .B1(n5723), .C0(WrWrapCnt1356_2_), .C1(n5710), .Y(n5725) );
  AO22X1 U4261 ( .A0(WrWrapCnt[1]), .A1(n5548), .B0(n5707), .B1(n5720), .Y(
        n5199) );
  OAI2BB1X1 U4262 ( .A0N(WQIncAddr[1]), .A1N(n5721), .B0(n5722), .Y(n5720) );
  AOI222X1 U4263 ( .A0(WrWrapCnt1390_1_), .A1(n5716), .B0(WrWrapCnt1377_1_), 
        .B1(n5723), .C0(WrWrapCnt1356_1_), .C1(n5710), .Y(n5722) );
  OAI2BB1X1 U4264 ( .A0N(n5707), .A1N(n5708), .B0(n5709), .Y(n5200) );
  AOI32X1 U4265 ( .A0(WrWrapCnt[0]), .A1(n6367), .A2(n5710), .B0(WrWrapCnt[0]), 
        .B1(n5548), .Y(n5709) );
  OAI211X1 U4266 ( .A0(n5711), .A1(n5712), .B0(n5713), .C0(n5714), .Y(n5708)
         );
  OA22X1 U4267 ( .A0(WrWrapCnt[0]), .A1(n5718), .B0(carry7), .B1(n5719), .Y(
        n5713) );
  OAI221X1 U4268 ( .A0(n5791), .A1(n6409), .B0(n6349), .B1(n5838), .C0(n5839), 
        .Y(NxtStW[0]) );
  AOI33X1 U4269 ( .A0(n5840), .A1(n6409), .A2(n5841), .B0(WriteAck), .B1(
        tWWSpi), .B2(n6454), .Y(n5839) );
  NOR2BX1 U4270 ( .AN(n6438), .B(tWWDat), .Y(n5840) );
  OAI221X1 U4271 ( .A0(n5356), .A1(n6315), .B0(n5844), .B1(n5847), .C0(n5848), 
        .Y(NxtStR[0]) );
  AOI32X1 U4272 ( .A0(n6315), .A1(n6356), .A2(n6307), .B0(tRRSpi), .B1(n5845), 
        .Y(n5848) );
  OAI32X1 U4273 ( .A0(n5791), .A1(WriteAck), .A2(n6353), .B0(n6349), .B1(n5832), .Y(NxtStW[4]) );
  AO21X1 U4274 ( .A0(tWWDat), .A1(n5835), .B0(n5791), .Y(NxtStW[1]) );
  AO21X1 U4275 ( .A0(tRRReq), .A1(n5844), .B0(n5356), .Y(NxtStR[1]) );
  OAI21X1 U4276 ( .A0(n6438), .A1(BReady), .B0(n5835), .Y(NxtStW[2]) );
  OAI221X1 U4277 ( .A0(n5718), .A1(n5747), .B0(n5719), .B1(n6412), .C0(n5748), 
        .Y(n5733) );
  INVX1 U4278 ( .A(n164), .Y(n5747) );
  OAI31X1 U4279 ( .A0(n5782), .A1(WBurstCnt[3]), .A2(WBurstCnt[2]), .B0(n5786), 
        .Y(n5183) );
  AOI222X1 U4280 ( .A0(WBLQRdData[3]), .A1(n_1314), .B0(WBurstCnt[3]), .B1(
        n5785), .C0(WBurstCnt[3]), .C1(WBurstCnt[2]), .Y(n5786) );
  AOI33X1 U4281 ( .A0(n5715), .A1(WQIncAddr[0]), .A2(n5716), .B0(n5717), .B1(
        n5711), .B2(n5716), .Y(n5714) );
  AND2X2 U4282 ( .A(n6440), .B(n5707), .Y(n6439) );
  NAND3BX1 U4283 ( .AN(tRRSpi), .B(n6307), .C(n5841), .Y(BA_REQ) );
  NAND4BX1 U4284 ( .AN(WQFull), .B(n5836), .C(tWWDat), .D(WriteAck), .Y(n5820)
         );
  INVX1 U4285 ( .A(WBLQFull), .Y(n5836) );
  NAND3BX1 U4286 ( .AN(n6281), .B(n6282), .C(n6283), .Y(BA_AA[11]) );
  OA21X2 U4287 ( .A0(WriteLatAA_11_), .A1(n6277), .B0(n6285), .Y(n6282) );
  AO22X1 U4288 ( .A0(RSpi2Addr1938_11_), .A1(n6071), .B0(WriteLatAA_11_), .B1(
        n6278), .Y(n6281) );
  AOI221X1 U4289 ( .A0(RSpi2Addr1914_11_), .A1(n6015), .B0(n6014), .B1(
        ReadLatAA_11_), .C0(n6284), .Y(n6283) );
  NAND3BX1 U4290 ( .AN(n6291), .B(n6292), .C(n6293), .Y(BA_AA[10]) );
  AOI211X1 U4291 ( .A0(n6296), .A1(n6020), .B0(n6297), .C0(n6298), .Y(n6292)
         );
  AO22X1 U4292 ( .A0(n6071), .A1(n6366), .B0(WriteLatAA_10_), .B1(n6019), .Y(
        n6291) );
  AOI221X1 U4293 ( .A0(RSpi2Addr1914_10_), .A1(n6015), .B0(n6014), .B1(
        ReadLatAA_10_), .C0(n6294), .Y(n6293) );
  OR3X2 U4294 ( .A(n6463), .B(n6464), .C(n6441), .Y(n6049) );
  NAND3BX1 U4295 ( .AN(n6466), .B(n6364), .C(ReadLatTT_0_), .Y(n6044) );
  NAND2BX1 U4296 ( .AN(ReadLatBB[0]), .B(ReadLatBB[1]), .Y(n6163) );
  NAND2BX1 U4297 ( .AN(WriteLatBB[0]), .B(WriteLatBB[1]), .Y(n6165) );
  NAND2X1 U4298 ( .A(ReadLatA0_0_), .B(n6163), .Y(n5978) );
  NAND2X1 U4299 ( .A(WriteLatA0_0_), .B(n6165), .Y(n5954) );
  NAND2BX1 U4300 ( .AN(RQEmpty), .B(tRDReq), .Y(n5829) );
  NAND2BX1 U4301 ( .AN(n5643), .B(RQIncAddr[5]), .Y(n5653) );
  OAI211X1 U4302 ( .A0(n5981), .A1(n5982), .B0(n5983), .C0(n5984), .Y(n5976)
         );
  NAND3BX1 U4303 ( .AN(n5945), .B(ReadLatAA_8_), .C(ReadLatAA_7_), .Y(n5982)
         );
  NAND3BX1 U4304 ( .AN(n5990), .B(n5991), .C(n5992), .Y(n5983) );
  AOI32X1 U4305 ( .A0(n5943), .A1(ReadLatAA_7_), .A2(n5985), .B0(n5985), .B1(
        n5961), .Y(n5984) );
  OAI222X1 U4306 ( .A0(RQIncAddr[3]), .A1(n5629), .B0(n5628), .B1(n5629), .C0(
        RQIncAddr[3]), .C1(n5628), .Y(n5634) );
  OAI211X1 U4307 ( .A0(n6272), .A1(n6358), .B0(n6273), .C0(n6274), .Y(
        BA_AA[12]) );
  AOI221X1 U4308 ( .A0(n6218), .A1(n6419), .B0(n6096), .B1(n6271), .C0(n6278), 
        .Y(n6272) );
  AOI21X1 U4309 ( .A0(RSpi2Addr1938_12_), .A1(n6071), .B0(n6276), .Y(n6273) );
  AOI221X1 U4310 ( .A0(RSpi2Addr1914_12_), .A1(n6015), .B0(n6014), .B1(
        ReadLatAA_12_), .C0(n6275), .Y(n6274) );
  OAI211X1 U4311 ( .A0(n6254), .A1(n6306), .B0(n6255), .C0(n6256), .Y(
        BA_AA[13]) );
  AOI211X1 U4312 ( .A0(n6096), .A1(n6253), .B0(n6249), .C0(n6265), .Y(n6254)
         );
  AOI221X1 U4313 ( .A0(RSpi2Addr1914_13_), .A1(n6015), .B0(n6014), .B1(
        ReadLatAA_13_), .C0(n6257), .Y(n6256) );
  OAI221X1 U4314 ( .A0(ReadLatAA_8_), .A1(n6021), .B0(n6320), .B1(n6022), .C0(
        n6023), .Y(BA_AA[8]) );
  AOI222X1 U4315 ( .A0(RSpi2Addr1902_8_), .A1(n6013), .B0(n6024), .B1(n6314), 
        .C0(n6462), .C1(n6026), .Y(n6023) );
  OAI221X1 U4316 ( .A0(ReadLatAA_3_), .A1(n5896), .B0(n6466), .B1(n5896), .C0(
        n6001), .Y(n5981) );
  AOI211X1 U4317 ( .A0(n5895), .A1(n6323), .B0(n6376), .C0(n6003), .Y(n6001)
         );
  NAND2BX1 U4318 ( .AN(n6379), .B(ReadLatAA_5_), .Y(n6003) );
  OAI221X1 U4319 ( .A0(WriteLatAA_3_), .A1(n5887), .B0(n6463), .B1(n5887), 
        .C0(n5966), .Y(n5956) );
  AOI211X1 U4320 ( .A0(n5885), .A1(n6325), .B0(n6375), .C0(n5968), .Y(n5966)
         );
  NAND2BX1 U4321 ( .AN(n6378), .B(WriteLatAA_5_), .Y(n5968) );
  INVX1 U4322 ( .A(n5955), .Y(n5952) );
  OAI211X1 U4323 ( .A0(n5956), .A1(n5957), .B0(n5958), .C0(n5959), .Y(n5955)
         );
  NAND3BX1 U4324 ( .AN(n5945), .B(n6462), .C(WriteLatAA_7_), .Y(n5957) );
  NAND4BX1 U4325 ( .AN(n6404), .B(WriteLatAA_6_), .C(WriteLatAA_4_), .D(n5963), 
        .Y(n5958) );
  OR4X1 U4326 ( .A(BA_STS[4]), .B(n6315), .C(RQHFull), .D(RBLQFull), .Y(n5851)
         );
  INVX1 U4327 ( .A(WStrb[0]), .Y(WQWrData_32_) );
  INVX1 U4328 ( .A(WStrb[1]), .Y(WQWrData_33_) );
  INVX1 U4329 ( .A(WStrb[2]), .Y(WQWrData_34_) );
  INVX1 U4330 ( .A(WStrb[3]), .Y(WQWrData_35_) );
  OAI32X1 U4331 ( .A0(n6049), .A1(n6465), .A2(n6361), .B0(n6048), .B1(n6361), 
        .Y(WriteLatAA_1_) );
  OAI32X1 U4332 ( .A0(n6044), .A1(n6468), .A2(n6362), .B0(n6043), .B1(n6362), 
        .Y(ReadLatAA_1_) );
  BUFX2 U4333 ( .A(n5336), .Y(n6465) );
  BUFX2 U4334 ( .A(n5332), .Y(n6463) );
  BUFX2 U4335 ( .A(n5334), .Y(n6464) );
  BUFX2 U4336 ( .A(n5344), .Y(n6468) );
  OAI32X1 U4337 ( .A0(n5964), .A1(n818), .A2(n5942), .B0(n5941), .B1(n5965), 
        .Y(n5963) );
  NAND4BX1 U4338 ( .AN(n724), .B(WriteLatAA_7_), .C(WriteLatAA_9_), .D(n6462), 
        .Y(n5965) );
  BUFX2 U4339 ( .A(WriteLatAA_8_), .Y(n6462) );
  OAI33X1 U4340 ( .A0(n6271), .A1(WriteLatAA_12_), .A2(n6064), .B0(n6277), 
        .B1(WriteLatAA_12_), .B2(n6419), .Y(n6276) );
  NAND2BX1 U4341 ( .AN(n5948), .B(n5949), .Y(n5919) );
  OAI33X1 U4342 ( .A0(n5864), .A1(n5947), .A2(n6360), .B0(n5864), .B1(
        ReadLatTT_0_), .B2(n5977), .Y(n5948) );
  AOI211X1 U4343 ( .A0(n5922), .A1(ReadLatTT_0_), .B0(n5950), .C0(n5951), .Y(
        n5949) );
  INVX1 U4344 ( .A(n5947), .Y(n5977) );
  BUFX2 U4345 ( .A(n5342), .Y(n6467) );
  BUFX2 U4346 ( .A(n5340), .Y(n6466) );
  OA22X1 U4347 ( .A0(WriteLatAA_24_), .A1(n6063), .B0(WriteLatAA_24_), .B1(
        n6064), .Y(n6060) );
  AO22X1 U4348 ( .A0(tWWReq), .A1(n6349), .B0(BValid), .B1(BReady), .Y(
        NxtStW[3]) );
  AO21X1 U4349 ( .A0(n6013), .A1(n6363), .B0(n6028), .Y(BA_AA[7]) );
  OAI222X1 U4350 ( .A0(n6312), .A1(n6308), .B0(WriteLatAA_7_), .B1(n6030), 
        .C0(n6363), .C1(n6022), .Y(n6028) );
  AO21X1 U4351 ( .A0(n6099), .A1(WriteLatAA_7_), .B0(n6096), .Y(n6024) );
  AND2X2 U4352 ( .A(WriteLatAA_18_), .B(WriteLatAA_19_), .Y(n6442) );
  OAI222X1 U4353 ( .A0(iWQRead), .A1(n6410), .B0(BA_STS[14]), .B1(n6410), .C0(
        n5548), .C1(n5506), .Y(n5293) );
  AO22X1 U4354 ( .A0(n5751), .A1(LatchedWBL_0_), .B0(n_1314), .B1(
        WBLQRdData[0]), .Y(n5190) );
  AO22X1 U4355 ( .A0(n5751), .A1(LatchedWBL_3_), .B0(WBLQRdData[3]), .B1(
        n_1314), .Y(n5187) );
  AO22X1 U4356 ( .A0(n5751), .A1(LatchedWBL_2_), .B0(WBLQRdData[2]), .B1(
        n_1314), .Y(n5188) );
  AO22X1 U4357 ( .A0(n5751), .A1(LatchedWBL_1_), .B0(n_1314), .B1(
        WBLQRdData[1]), .Y(n5189) );
  OAI33X1 U4358 ( .A0(n5832), .A1(n5935), .A2(n6441), .B0(n5832), .B1(n5338), 
        .B2(n5953), .Y(n5950) );
  INVX1 U4359 ( .A(n5935), .Y(n5953) );
  AO22X1 U4360 ( .A0(n6014), .A1(ReadLatAA_14_), .B0(RSpi2Addr1914_14_), .B1(
        n6015), .Y(n6248) );
  AOI33X1 U4361 ( .A0(n6279), .A1(n6419), .A2(n6096), .B0(WriteLatAA_11_), 
        .B1(n6286), .B2(n6096), .Y(n6285) );
  AOI32X1 U4362 ( .A0(WriteLatAA_12_), .A1(n6306), .A2(n6259), .B0(
        RSpi2Addr1938_13_), .B1(n6071), .Y(n6258) );
  AO22X1 U4363 ( .A0(n6260), .A1(n6096), .B0(n6236), .B1(WriteLatAA_11_), .Y(
        n6259) );
  OAI211X1 U4364 ( .A0(WriteLatAA_9_), .A1(n6010), .B0(n6011), .C0(n6012), .Y(
        BA_AA[9]) );
  INVX1 U4365 ( .A(n6020), .Y(n6010) );
  AOI222X1 U4366 ( .A0(RSpi2Addr1902_9_), .A1(n6013), .B0(n6014), .B1(
        ReadLatAA_9_), .C0(RSpi2Addr1914_9_), .C1(n6015), .Y(n6012) );
  OAI211X1 U4367 ( .A0(tWWSpi), .A1(tWIdle), .B0(n6303), .C0(n6304), .Y(n5843)
         );
  INVX1 U4368 ( .A(WQFull), .Y(n6304) );
  INVX1 U4369 ( .A(BA_STS[4]), .Y(n6303) );
  OAI211X1 U4370 ( .A0(n5653), .A1(n5654), .B0(n5655), .C0(n5656), .Y(n5278)
         );
  NAND2BX1 U4371 ( .AN(n5641), .B(n5660), .Y(n5654) );
  AOI32X1 U4372 ( .A0(n5597), .A1(RQIncAddr[6]), .A2(n5653), .B0(
        RdWrapCnt3036_6_), .B1(n5612), .Y(n5656) );
  OAI211X1 U4373 ( .A0(n5661), .A1(n5662), .B0(n5663), .C0(n5664), .Y(n5277)
         );
  NAND2BX1 U4374 ( .AN(n5641), .B(n5671), .Y(n5662) );
  OA22X1 U4375 ( .A0(n5670), .A1(n6413), .B0(n5599), .B1(n5671), .Y(n5663) );
  AOI33X1 U4376 ( .A0(n5569), .A1(n6413), .A2(n5666), .B0(n5597), .B1(
        RQIncAddr[7]), .B2(n5661), .Y(n5664) );
  OAI211X1 U4377 ( .A0(n5643), .A1(n5644), .B0(n5645), .C0(n5646), .Y(n5279)
         );
  NAND2BX1 U4378 ( .AN(n5641), .B(n5652), .Y(n5644) );
  AOI31X1 U4379 ( .A0(n5597), .A1(RQIncAddr[5]), .A2(n5643), .B0(n5647), .Y(
        n5646) );
  OAI211X1 U4380 ( .A0(n5634), .A1(n5635), .B0(n5636), .C0(n5637), .Y(n5280)
         );
  NAND2BX1 U4381 ( .AN(n5641), .B(n5642), .Y(n5635) );
  AOI33X1 U4382 ( .A0(n5638), .A1(n6348), .A2(n5593), .B0(n5597), .B1(
        RQIncAddr[4]), .B2(n5634), .Y(n5637) );
  AOI211X1 U4383 ( .A0(n6280), .A1(n6064), .B0(WriteLatAA_9_), .C0(n6351), .Y(
        n6298) );
  AOI32X1 U4384 ( .A0(n5943), .A1(WriteLatAA_7_), .A2(n5960), .B0(n5961), .B1(
        n5960), .Y(n5959) );
  INVX1 U4385 ( .A(n5956), .Y(n5960) );
  INVX1 U4386 ( .A(n5692), .Y(n5619) );
  OAI222X1 U4387 ( .A0(RQIncAddr[1]), .A1(n5608), .B0(n5693), .B1(n5608), .C0(
        RQIncAddr[1]), .C1(n5693), .Y(n5692) );
  INVX1 U4388 ( .A(n5691), .Y(n5629) );
  OAI222X1 U4389 ( .A0(RQIncAddr[2]), .A1(n5619), .B0(n5618), .B1(n5619), .C0(
        RQIncAddr[2]), .C1(n5618), .Y(n5691) );
  INVX1 U4390 ( .A(n29), .Y(carry8) );
  AFHCONX2 U1_11 ( .A(WQIncAddr[1]), .B(n1391_31_), .CI(carry16), .S(
        WrWrapCnt1390_1_), .CON(n412) );
  NOR2BX1 U4391 ( .AN(WQIncAddr[0]), .B(n5715), .Y(carry16) );
  NAND2BX1 U4392 ( .AN(n5792), .B(n5793), .Y(n1391_31_) );
  OAI33X1 U4393 ( .A0(n5794), .A1(n5795), .A2(n5775), .B0(n5738), .B1(
        n1393_31_), .B2(n5794), .Y(n5792) );
  AFHCONX2 U1_21 ( .A(WQIncAddr[2]), .B(n1391_30_), .CI(carry15), .S(
        WrWrapCnt1390_2_), .CON(n38) );
  INVX1 U4394 ( .A(n412), .Y(carry15) );
  NAND2BX1 U4395 ( .AN(n5796), .B(n5797), .Y(n1391_30_) );
  OAI33X1 U4396 ( .A0(n5799), .A1(n1393_30_), .A2(n5745), .B0(n5799), .B1(
        n5798), .B2(n5741), .Y(n5796) );
  AFHCONX2 U1_31 ( .A(WQIncAddr[3]), .B(n1391_29_), .CI(carry14), .S(
        WrWrapCnt1390_3_), .CON(n27) );
  INVX1 U4397 ( .A(n38), .Y(carry14) );
  NAND2BX1 U4398 ( .AN(n5800), .B(n5801), .Y(n1391_29_) );
  OAI33X1 U4399 ( .A0(n5803), .A1(n1393_29_), .A2(n5739), .B0(n5803), .B1(
        n5802), .B2(n5804), .Y(n5800) );
  AFHCONX2 U1_4 ( .A(WQIncAddr[4]), .B(n1391_28_), .CI(carry13), .S(
        WrWrapCnt1390_4_), .CON(n160) );
  INVX1 U4400 ( .A(n27), .Y(carry13) );
  AO21X1 U4401 ( .A0(n5805), .A1(n5806), .B0(n1391_27_), .Y(n1391_28_) );
  INVX1 U4402 ( .A(n159), .Y(n5806) );
  XOR2X1 U4403 ( .A(n5954), .B(n5338), .Y(n5935) );
  XOR2X1 U4404 ( .A(n5978), .B(ReadLatTT_0_), .Y(n5947) );
  INVX1 U4405 ( .A(n310), .Y(carry9) );
  NAND2BX1 U4406 ( .AN(n5811), .B(WBLQRdData[6]), .Y(n5741) );
  NOR2BX1 U4407 ( .AN(WBLQRdData[5]), .B(n5814), .Y(n5817) );
  NAND2BX1 U4408 ( .AN(n5814), .B(WBLQRdData[4]), .Y(n5740) );
  OAI32X1 U4409 ( .A0(n6036), .A1(n6319), .A2(n6368), .B0(n6038), .B1(n6368), 
        .Y(WriteLatAA_3_) );
  NAND2BX1 U4410 ( .AN(n6463), .B(n5338), .Y(n6036) );
  INVX1 U4411 ( .A(n6039), .Y(n6038) );
  OAI32X1 U4412 ( .A0(n6031), .A1(n6321), .A2(n6369), .B0(n6034), .B1(n6369), 
        .Y(ReadLatAA_3_) );
  NAND2BX1 U4413 ( .AN(n6466), .B(ReadLatTT_0_), .Y(n6031) );
  AND2X2 U4414 ( .A(ReadLatA0_2_), .B(n6035), .Y(n6443) );
  NAND2BX1 U4415 ( .AN(WBLQRdData[8]), .B(WBLQRdData[9]), .Y(n5814) );
  XOR3X1 U4416 ( .A(RQIncAddr[3]), .B(n5628), .C(n5629), .Y(n5627) );
  NOR2BX1 U4417 ( .AN(WriteLatAA_9_), .B(WriteLatAA_10_), .Y(n6296) );
  AND2X2 U4418 ( .A(WriteLatA0_2_), .B(n6039), .Y(n6444) );
  AO22X1 U4419 ( .A0(tRRSpi), .A1(n5844), .B0(BA_PM), .B1(n5845), .Y(NxtStR[2]) );
  OAI211X1 U4420 ( .A0(n5602), .A1(n5624), .B0(n5625), .C0(n5626), .Y(n5281)
         );
  NAND2BX1 U4421 ( .AN(RdWrapCnt[3]), .B(n5631), .Y(n5624) );
  NAND4BX1 U4422 ( .AN(RBurstCnt[2]), .B(n6370), .C(n5854), .D(RQRead), .Y(
        n5566) );
  NOR2BX1 U4423 ( .AN(n6372), .B(RBurstCnt[3]), .Y(n5854) );
  XOR2X1 U4424 ( .A(n5566), .B(IncRdLastCnt), .Y(n5550) );
  NAND3BX1 U4425 ( .AN(RBurstCnt[0]), .B(n6459), .C(n5569), .Y(n5571) );
  XOR2X1 U4426 ( .A(n6386), .B(a1416_4_), .Y(n5764) );
  XOR2X1 U0_5_3 ( .A(part_diff_3_), .B(g_array8), .Y(a1416_4_) );
  NAND2BX1 U0_3_3 ( .AN(pog_array), .B(g_array), .Y(part_diff_3_) );
  NAND2BX1 U4427 ( .AN(RdWrapCnt[0]), .B(LatchedRBL_0_), .Y(n5594) );
  OR2X1 U4428 ( .A(RBurstCnt[1]), .B(n5571), .Y(n5575) );
  AO22X1 U4429 ( .A0(tRDIdle), .A1(n5852), .B0(tRDReq), .B1(n5566), .Y(
        NxtStRD[1]) );
  OAI211X1 U4430 ( .A0(n5809), .A1(n5780), .B0(WBLQRdData[7]), .C0(n5810), .Y(
        n5804) );
  INVX1 U4431 ( .A(n5811), .Y(n5810) );
  AO21X1 U4432 ( .A0(RBurstCnt[0]), .A1(n6459), .B0(n5586), .Y(n5576) );
  NOR3BX1 U4433 ( .AN(ReadLatAA_7_), .B(n6387), .C(n6320), .Y(n5991) );
  NOR2BX1 U4434 ( .AN(WQRdData[34]), .B(n6317), .Y(SD_DQM[2]) );
  NOR2BX1 U4435 ( .AN(WQRdData[35]), .B(n6317), .Y(SD_DQM[3]) );
  NOR2BX1 U4436 ( .AN(WQRdData[16]), .B(n6317), .Y(SD_DQO[16]) );
  NOR2BX1 U4437 ( .AN(WQRdData[17]), .B(n6317), .Y(SD_DQO[17]) );
  NOR2BX1 U4438 ( .AN(WQRdData[18]), .B(n6317), .Y(SD_DQO[18]) );
  NOR2BX1 U4439 ( .AN(WQRdData[19]), .B(n6317), .Y(SD_DQO[19]) );
  NOR2BX1 U4440 ( .AN(WQRdData[20]), .B(n6317), .Y(SD_DQO[20]) );
  NOR2BX1 U4441 ( .AN(WQRdData[21]), .B(n6317), .Y(SD_DQO[21]) );
  NOR2BX1 U4442 ( .AN(WQRdData[22]), .B(n6317), .Y(SD_DQO[22]) );
  NOR2BX1 U4443 ( .AN(WQRdData[23]), .B(n6317), .Y(SD_DQO[23]) );
  NOR2BX1 U4444 ( .AN(WQRdData[24]), .B(n6317), .Y(SD_DQO[24]) );
  NOR2BX1 U4445 ( .AN(WQRdData[25]), .B(n6317), .Y(SD_DQO[25]) );
  NOR2BX1 U4446 ( .AN(WQRdData[26]), .B(n6317), .Y(SD_DQO[26]) );
  NOR2BX1 U4447 ( .AN(WQRdData[27]), .B(n6317), .Y(SD_DQO[27]) );
  NOR2BX1 U4448 ( .AN(WQRdData[28]), .B(n6317), .Y(SD_DQO[28]) );
  NOR2BX1 U4449 ( .AN(WQRdData[29]), .B(n6317), .Y(SD_DQO[29]) );
  NOR2BX1 U4450 ( .AN(WQRdData[30]), .B(n6317), .Y(SD_DQO[30]) );
  NOR2BX1 U4451 ( .AN(WQRdData[31]), .B(n6317), .Y(SD_DQO[31]) );
  AO22X1 U4452 ( .A0(WQRdData[32]), .A1(n5822), .B0(WQRdData[34]), .B1(n5823), 
        .Y(SD_DQM[0]) );
  AO22X1 U4453 ( .A0(WQRdData[33]), .A1(n5822), .B0(WQRdData[35]), .B1(n5823), 
        .Y(SD_DQM[1]) );
  AO22X1 U4454 ( .A0(WQRdData[0]), .A1(n5822), .B0(WQRdData[16]), .B1(n5823), 
        .Y(SD_DQO[0]) );
  AO22X1 U4455 ( .A0(WQRdData[1]), .A1(n5822), .B0(WQRdData[17]), .B1(n5823), 
        .Y(SD_DQO[1]) );
  AO22X1 U4456 ( .A0(WQRdData[2]), .A1(n5822), .B0(WQRdData[18]), .B1(n5823), 
        .Y(SD_DQO[2]) );
  AO22X1 U4457 ( .A0(WQRdData[3]), .A1(n5822), .B0(WQRdData[19]), .B1(n5823), 
        .Y(SD_DQO[3]) );
  AO22X1 U4458 ( .A0(WQRdData[4]), .A1(n5822), .B0(WQRdData[20]), .B1(n5823), 
        .Y(SD_DQO[4]) );
  AO22X1 U4459 ( .A0(WQRdData[5]), .A1(n5822), .B0(WQRdData[21]), .B1(n5823), 
        .Y(SD_DQO[5]) );
  AO22X1 U4460 ( .A0(WQRdData[6]), .A1(n5822), .B0(WQRdData[22]), .B1(n5823), 
        .Y(SD_DQO[6]) );
  AO22X1 U4461 ( .A0(WQRdData[7]), .A1(n5822), .B0(WQRdData[23]), .B1(n5823), 
        .Y(SD_DQO[7]) );
  AO22X1 U4462 ( .A0(WQRdData[8]), .A1(n5822), .B0(WQRdData[24]), .B1(n5823), 
        .Y(SD_DQO[8]) );
  AO22X1 U4463 ( .A0(WQRdData[9]), .A1(n5822), .B0(WQRdData[25]), .B1(n5823), 
        .Y(SD_DQO[9]) );
  AO22X1 U4464 ( .A0(WQRdData[10]), .A1(n5822), .B0(WQRdData[26]), .B1(n5823), 
        .Y(SD_DQO[10]) );
  AO22X1 U4465 ( .A0(WQRdData[11]), .A1(n5822), .B0(WQRdData[27]), .B1(n5823), 
        .Y(SD_DQO[11]) );
  AO22X1 U4466 ( .A0(WQRdData[12]), .A1(n5822), .B0(WQRdData[28]), .B1(n5823), 
        .Y(SD_DQO[12]) );
  AO22X1 U4467 ( .A0(WQRdData[13]), .A1(n5822), .B0(WQRdData[29]), .B1(n5823), 
        .Y(SD_DQO[13]) );
  AO22X1 U4468 ( .A0(WQRdData[14]), .A1(n5822), .B0(WQRdData[30]), .B1(n5823), 
        .Y(SD_DQO[14]) );
  AO22X1 U4469 ( .A0(WQRdData[15]), .A1(n5822), .B0(WQRdData[31]), .B1(n5823), 
        .Y(SD_DQO[15]) );
  XNOR3X1 U4470 ( .A(n5608), .B(RQIncAddr[1]), .C(n5610), .Y(n5606) );
  XOR3X1 U4471 ( .A(RQIncAddr[2]), .B(n5618), .C(n5619), .Y(n5617) );
  NAND3BX1 U4472 ( .AN(n5587), .B(n5588), .C(n5589), .Y(n5284) );
  AOI33X1 U4473 ( .A0(n5595), .A1(n5596), .A2(n5597), .B0(RQIncAddr[0]), .B1(
        n5598), .B2(n5597), .Y(n5588) );
  AO21X1 U4474 ( .A0(IncRdLastCnt), .A1(n6324), .B0(n5550), .Y(n5551) );
  AO21X1 U4475 ( .A0(RdLastCnt[0]), .A1(n6309), .B0(n5551), .Y(n5555) );
  OAI222X1 U4476 ( .A0(n5512), .A1(n5142), .B0(BA_STS[14]), .B1(n6330), .C0(
        n6388), .C1(n5515), .Y(n5295) );
  OAI222X1 U4477 ( .A0(n5512), .A1(n5141), .B0(BA_STS[14]), .B1(n6331), .C0(
        n6389), .C1(n5515), .Y(n5296) );
  OAI222X1 U4478 ( .A0(n5512), .A1(n5140), .B0(BA_STS[14]), .B1(n6332), .C0(
        n6390), .C1(n5515), .Y(n5297) );
  OAI222X1 U4479 ( .A0(n5512), .A1(n5139), .B0(BA_STS[14]), .B1(n6333), .C0(
        n6391), .C1(n5515), .Y(n5298) );
  OAI222X1 U4480 ( .A0(n5512), .A1(n5138), .B0(BA_STS[14]), .B1(n6334), .C0(
        n6392), .C1(n5515), .Y(n5299) );
  OAI222X1 U4481 ( .A0(n5512), .A1(n5137), .B0(BA_STS[14]), .B1(n6335), .C0(
        n6393), .C1(n5515), .Y(n5300) );
  OAI222X1 U4482 ( .A0(n5512), .A1(n5136), .B0(BA_STS[14]), .B1(n6336), .C0(
        n6394), .C1(n5515), .Y(n5301) );
  OAI222X1 U4483 ( .A0(n5512), .A1(n5135), .B0(BA_STS[14]), .B1(n6337), .C0(
        n6395), .C1(n5515), .Y(n5302) );
  OAI222X1 U4484 ( .A0(n5512), .A1(n5134), .B0(BA_STS[14]), .B1(n6338), .C0(
        n6396), .C1(n5515), .Y(n5303) );
  OAI222X1 U4485 ( .A0(n5512), .A1(n5133), .B0(BA_STS[14]), .B1(n6339), .C0(
        n6397), .C1(n5515), .Y(n5304) );
  OAI222X1 U4486 ( .A0(n5512), .A1(n5132), .B0(BA_STS[14]), .B1(n6340), .C0(
        n6398), .C1(n5515), .Y(n5305) );
  OAI222X1 U4487 ( .A0(n5512), .A1(n5131), .B0(BA_STS[14]), .B1(n6341), .C0(
        n6399), .C1(n5515), .Y(n5306) );
  OAI222X1 U4488 ( .A0(n5512), .A1(n5130), .B0(BA_STS[14]), .B1(n6342), .C0(
        n6400), .C1(n5515), .Y(n5307) );
  OAI222X1 U4489 ( .A0(n5512), .A1(n5129), .B0(BA_STS[14]), .B1(n6343), .C0(
        n6401), .C1(n5515), .Y(n5308) );
  OAI222X1 U4490 ( .A0(n5512), .A1(n5128), .B0(BA_STS[14]), .B1(n6344), .C0(
        n6402), .C1(n5515), .Y(n5309) );
  OAI222X1 U4491 ( .A0(n5512), .A1(n5127), .B0(BA_STS[14]), .B1(n6345), .C0(
        n6403), .C1(n5515), .Y(n5310) );
  OAI222X1 U4492 ( .A0(n6447), .A1(n6408), .B0(n5567), .B1(n5579), .C0(
        RBurstCnt[2]), .C1(n5575), .Y(n5286) );
  INVX1 U4493 ( .A(n5668), .Y(n5658) );
  NAND3BX1 U4494 ( .AN(RdWrapCnt[6]), .B(n5591), .C(n5669), .Y(n5668) );
  INVX1 U4495 ( .A(n5650), .Y(n5669) );
  OAI32X1 U4496 ( .A0(n5550), .A1(RdLastCnt[3]), .A2(n5562), .B0(n5563), .B1(
        n6374), .Y(n5289) );
  OA22X1 U4497 ( .A0(n6350), .A1(n5561), .B0(IncRdLastCnt), .B1(n5565), .Y(
        n5562) );
  AOI221X1 U4498 ( .A0(RdLastCnt[2]), .A1(n6407), .B0(RdLastCnt[1]), .B1(n6350), .C0(n5555), .Y(n5563) );
  OAI221X1 U4499 ( .A0(n6447), .A1(n6347), .B0(n6459), .B1(n5581), .C0(n5582), 
        .Y(n5285) );
  INVX1 U4500 ( .A(RBLQRdData[3]), .Y(n5581) );
  AOI33X1 U4501 ( .A0(n6408), .A1(n6347), .A2(n5583), .B0(RBurstCnt[2]), .B1(
        RBurstCnt[3]), .B2(n6459), .Y(n5582) );
  INVX1 U4502 ( .A(n5575), .Y(n5583) );
  NOR2X1 U4503 ( .A(n5506), .B(n6446), .Y(n6445) );
  OAI211X1 U4504 ( .A0(n5602), .A1(n5614), .B0(n5615), .C0(n5616), .Y(n5282)
         );
  NAND2BX1 U4505 ( .AN(RdWrapCnt[2]), .B(n5621), .Y(n5614) );
  OAI211X1 U4506 ( .A0(n5602), .A1(n5603), .B0(n5604), .C0(n5605), .Y(n5283)
         );
  NAND2BX1 U4507 ( .AN(RdWrapCnt[1]), .B(n5613), .Y(n5603) );
  INVX1 U4508 ( .A(RQIncAddr[0]), .Y(n5596) );
  INVX1 U4509 ( .A(n5856), .Y(n5852) );
  OAI2BB1X1 U4510 ( .A0N(n5857), .A1N(n6374), .B0(n5858), .Y(n5856) );
  INVX1 U4511 ( .A(n5565), .Y(n5857) );
  NOR2BX1 U4512 ( .AN(n5859), .B(RBLQEmpty), .Y(n5858) );
  NAND3X1 U4513 ( .A(ReadLatAA_5_), .B(ReadLatAA_6_), .C(ReadLatAA_4_), .Y(
        n5990) );
  INVX1 U4514 ( .A(n5674), .Y(n5623) );
  INVX1 U4515 ( .A(n5673), .Y(n5633) );
  AOI21X1 U4516 ( .A0(RBurstCnt[1]), .A1(n5567), .B0(n5576), .Y(n6447) );
  OAI2BB1X1 U4517 ( .A0N(SD_DQE), .A1N(n6377), .B0(n6317), .Y(n5822) );
  AFHCONX2 U2_3 ( .A(WrWrapCnt[3]), .B(n6406), .CI(carry5), .S(
        WrWrapCnt1356_3_), .CON(n618) );
  INVX1 U4518 ( .A(n718), .Y(carry5) );
  AFHCONX2 U2_1 ( .A(WrWrapCnt[1]), .B(n6380), .CI(carry7), .S(
        WrWrapCnt1356_1_), .CON(n817) );
  AFHCONX2 U2_2 ( .A(WrWrapCnt[2]), .B(n6381), .CI(carry6), .S(
        WrWrapCnt1356_2_), .CON(n718) );
  INVX1 U4519 ( .A(n817), .Y(carry6) );
  NOR3BX1 U4520 ( .AN(WriteAck), .B(n6308), .C(WBLQFull), .Y(WBLQWrite) );
  INVX1 U4521 ( .A(n28), .Y(carry10) );
  NOR2X1 U4522 ( .A(n6448), .B(RQFull), .Y(RQWrite) );
  INVX1 U4523 ( .A(n3), .Y(carry_5_) );
  INVX1 U4524 ( .A(n4), .Y(carry_4_) );
  INVX1 U4525 ( .A(n413), .Y(carry12) );
  INVX1 U4526 ( .A(n39), .Y(carry11) );
  INVX1 U4527 ( .A(n5), .Y(carry_3_) );
  INVX1 U4528 ( .A(n6), .Y(carry_2_) );
  NAND3BX1 U4529 ( .AN(RdLastCnt[2]), .B(n6309), .C(n6324), .Y(n5565) );
  NAND3BX1 U4530 ( .AN(n5679), .B(n5680), .C(n5681), .Y(n5676) );
  XOR2X1 U4531 ( .A(n6347), .B(RdWrapAddrSt_3_), .Y(n5680) );
  XOR2X1 U4532 ( .A(RdWrapAddrSt_2_), .B(RBurstCnt[2]), .Y(n5679) );
  AOI211X1 U4533 ( .A0(n5682), .A1(n5683), .B0(n5684), .C0(n5685), .Y(n5681)
         );
  XOR2X1 U4534 ( .A(RdWrapAddrSt_0_), .B(RBurstCnt[0]), .Y(n5684) );
  XOR2X1 U4535 ( .A(RdWrapAddrSt_1_), .B(RBurstCnt[1]), .Y(n5685) );
  AO22X1 U4536 ( .A0(ReadReqID[3]), .A1(n6009), .B0(WriteReqID[3]), .B1(n5979), 
        .Y(BA_ID[3]) );
  AO22X1 U4537 ( .A0(ReadReqID[2]), .A1(n6009), .B0(WriteReqID[2]), .B1(n5979), 
        .Y(BA_ID[2]) );
  AO22X1 U4538 ( .A0(ReadReqID[1]), .A1(n6009), .B0(WriteReqID[1]), .B1(n5979), 
        .Y(BA_ID[1]) );
  AO22X1 U4539 ( .A0(ReadReqID[0]), .A1(n6009), .B0(WriteReqID[0]), .B1(n5979), 
        .Y(BA_ID[0]) );
  BUFX2 U4540 ( .A(n5347), .Y(n6469) );
  NAND2BX1 U4541 ( .AN(WrWrapCnt[0]), .B(LatchedWBL_0_), .Y(carry7) );
  AO22X1 U4542 ( .A0(n6470), .A1(WriteLatAA_6_), .B0(n6014), .B1(ReadLatAA_6_), 
        .Y(BA_AA[6]) );
  AO22X1 U4543 ( .A0(n6470), .A1(WriteLatAA_5_), .B0(n6014), .B1(ReadLatAA_5_), 
        .Y(BA_AA[5]) );
  AO22X1 U4544 ( .A0(n6470), .A1(WriteLatAA_4_), .B0(n6014), .B1(ReadLatAA_4_), 
        .Y(BA_AA[4]) );
  NOR2X1 U4545 ( .A(RdWrapAddrSt_0_), .B(RdWrapAddrSt_1_), .Y(n5682) );
  NOR2X1 U4546 ( .A(RdWrapAddrSt_2_), .B(RdWrapAddrSt_3_), .Y(n5683) );
  INVX1 U4547 ( .A(n2), .Y(carry_6_) );
  AO22X1 U4548 ( .A0(RdWrapAddrSt_3_), .A1(n6459), .B0(n5628), .B1(n_5173), 
        .Y(n5273) );
  AO22X1 U4549 ( .A0(RdWrapAddrSt_1_), .A1(n5567), .B0(n5693), .B1(n_5173), 
        .Y(n5275) );
  AO22X1 U4550 ( .A0(RdWrapAddrSt_2_), .A1(n6459), .B0(n5618), .B1(n_5173), 
        .Y(n5274) );
  AO22X1 U4551 ( .A0(RdWrapAddrSt_0_), .A1(n5567), .B0(n5595), .B1(n_5173), 
        .Y(n5276) );
  AO22X1 U4552 ( .A0(RdDataMemFd[15]), .A1(n5510), .B0(RQWrData[15]), .B1(
        n6449), .Y(n5311) );
  AO22X1 U4553 ( .A0(RdDataMemFd[14]), .A1(n5510), .B0(RQWrData[14]), .B1(
        n6449), .Y(n5312) );
  AO22X1 U4554 ( .A0(RdDataMemFd[13]), .A1(n5510), .B0(RQWrData[13]), .B1(
        n6449), .Y(n5313) );
  AO22X1 U4555 ( .A0(RdDataMemFd[12]), .A1(n5510), .B0(RQWrData[12]), .B1(
        n6449), .Y(n5314) );
  AO22X1 U4556 ( .A0(RdDataMemFd[11]), .A1(n5510), .B0(RQWrData[11]), .B1(
        n6449), .Y(n5315) );
  AO22X1 U4557 ( .A0(RdDataMemFd[10]), .A1(n5510), .B0(RQWrData[10]), .B1(
        n6449), .Y(n5316) );
  AO22X1 U4558 ( .A0(RdDataMemFd[9]), .A1(n5510), .B0(RQWrData[9]), .B1(n6449), 
        .Y(n5317) );
  AO22X1 U4559 ( .A0(RdDataMemFd[8]), .A1(n5510), .B0(RQWrData[8]), .B1(n6449), 
        .Y(n5318) );
  AO22X1 U4560 ( .A0(RdDataMemFd[7]), .A1(n5510), .B0(RQWrData[7]), .B1(n6449), 
        .Y(n5319) );
  AO22X1 U4561 ( .A0(RdDataMemFd[6]), .A1(n5510), .B0(RQWrData[6]), .B1(n6449), 
        .Y(n5320) );
  AO22X1 U4562 ( .A0(RdDataMemFd[5]), .A1(n5510), .B0(RQWrData[5]), .B1(n6449), 
        .Y(n5321) );
  AO22X1 U4563 ( .A0(RdDataMemFd[4]), .A1(n5510), .B0(RQWrData[4]), .B1(n6449), 
        .Y(n5322) );
  AO22X1 U4564 ( .A0(RdDataMemFd[3]), .A1(n5510), .B0(RQWrData[3]), .B1(n6449), 
        .Y(n5323) );
  AO22X1 U4565 ( .A0(RdDataMemFd[2]), .A1(n5510), .B0(RQWrData[2]), .B1(n6449), 
        .Y(n5324) );
  AO22X1 U4566 ( .A0(RdDataMemFd[1]), .A1(n5510), .B0(RQWrData[1]), .B1(n6449), 
        .Y(n5325) );
  AO22X1 U4567 ( .A0(RdDataMemFd[0]), .A1(n5510), .B0(RQWrData[0]), .B1(n6449), 
        .Y(n5326) );
  AO22X1 U4568 ( .A0(LatchedRBL_3_), .A1(n5567), .B0(RBLQRdData[3]), .B1(
        n_5173), .Y(n5269) );
  AO22X1 U4569 ( .A0(LatchedRBL_2_), .A1(n5567), .B0(RBLQRdData[2]), .B1(
        n_5173), .Y(n5270) );
  AO22X1 U4570 ( .A0(LatchedRBL_1_), .A1(n6459), .B0(RBLQRdData[1]), .B1(
        n_5173), .Y(n5271) );
  AO22X1 U4571 ( .A0(LatchedRBL_0_), .A1(n5567), .B0(RBLQRdData[0]), .B1(
        n_5173), .Y(n5272) );
  OAI221X1 U4572 ( .A0(tRDReq), .A1(tRDIdle), .B0(n5852), .B1(n6416), .C0(
        n5566), .Y(NxtStRD[0]) );
  AO21X1 U4573 ( .A0(RdLastCnt[2]), .A1(n5555), .B0(n5556), .Y(n5290) );
  OAI33X1 U4574 ( .A0(n6309), .A1(IncRdLastCnt), .A2(n6350), .B0(n5550), .B1(
        RdLastCnt[2]), .B2(n5558), .Y(n5556) );
  AOI31X1 U4575 ( .A0(n6324), .A1(n6309), .A2(n6407), .B0(n5560), .Y(n5558) );
  INVX1 U4576 ( .A(n5561), .Y(n5560) );
  AO21X1 U4577 ( .A0(RdLastCnt[1]), .A1(n5551), .B0(n5552), .Y(n5291) );
  OAI33X1 U4578 ( .A0(n6309), .A1(IncRdLastCnt), .A2(n6324), .B0(n5550), .B1(
        RdLastCnt[1]), .B2(n5554), .Y(n5552) );
  XOR2X1 U4579 ( .A(RdLastCnt[0]), .B(IncRdLastCnt), .Y(n5554) );
  XOR2X1 U4580 ( .A(n5594), .B(LatchedRBL_1_), .Y(n5611) );
  NAND3BX1 U4581 ( .AN(n6407), .B(RdLastCnt[0]), .C(RdLastCnt[1]), .Y(n5561)
         );
  NAND2BX1 U4582 ( .AN(In16BitSel), .B(BA_STS[14]), .Y(n5512) );
  XOR2X1 U4583 ( .A(Out16BitSel), .B(n6445), .Y(n5294) );
  NOR2X1 U4584 ( .A(n5506), .B(n6450), .Y(n6449) );
  INVX1 U4585 ( .A(n6449), .Y(n5510) );
  AO22X1 U4586 ( .A0(SD_DQI[31]), .A1(n6469), .B0(RdDataMemFd[31]), .B1(n6405), 
        .Y(n5237) );
  AO22X1 U4587 ( .A0(SD_DQI[30]), .A1(n6469), .B0(RdDataMemFd[30]), .B1(n6405), 
        .Y(n5238) );
  AO22X1 U4588 ( .A0(SD_DQI[29]), .A1(n6469), .B0(RdDataMemFd[29]), .B1(n6405), 
        .Y(n5239) );
  AO22X1 U4589 ( .A0(SD_DQI[28]), .A1(n6469), .B0(RdDataMemFd[28]), .B1(n6405), 
        .Y(n5240) );
  AO22X1 U4590 ( .A0(SD_DQI[27]), .A1(n6469), .B0(RdDataMemFd[27]), .B1(n6405), 
        .Y(n5241) );
  AO22X1 U4591 ( .A0(SD_DQI[26]), .A1(n6469), .B0(RdDataMemFd[26]), .B1(n6405), 
        .Y(n5242) );
  AO22X1 U4592 ( .A0(SD_DQI[25]), .A1(n6469), .B0(RdDataMemFd[25]), .B1(n6405), 
        .Y(n5243) );
  AO22X1 U4593 ( .A0(SD_DQI[24]), .A1(n6469), .B0(RdDataMemFd[24]), .B1(n6405), 
        .Y(n5244) );
  AO22X1 U4594 ( .A0(SD_DQI[23]), .A1(n6469), .B0(RdDataMemFd[23]), .B1(n6405), 
        .Y(n5245) );
  AO22X1 U4595 ( .A0(SD_DQI[22]), .A1(n6469), .B0(RdDataMemFd[22]), .B1(n6405), 
        .Y(n5246) );
  AO22X1 U4596 ( .A0(SD_DQI[21]), .A1(n6469), .B0(RdDataMemFd[21]), .B1(n6405), 
        .Y(n5247) );
  AO22X1 U4597 ( .A0(SD_DQI[20]), .A1(n6469), .B0(RdDataMemFd[20]), .B1(n6405), 
        .Y(n5248) );
  AO22X1 U4598 ( .A0(SD_DQI[19]), .A1(n6469), .B0(RdDataMemFd[19]), .B1(n6405), 
        .Y(n5249) );
  AO22X1 U4599 ( .A0(SD_DQI[18]), .A1(n6469), .B0(RdDataMemFd[18]), .B1(n6405), 
        .Y(n5250) );
  AO22X1 U4600 ( .A0(SD_DQI[17]), .A1(n6469), .B0(RdDataMemFd[17]), .B1(n6405), 
        .Y(n5251) );
  AO22X1 U4601 ( .A0(SD_DQI[16]), .A1(n6469), .B0(RdDataMemFd[16]), .B1(n6405), 
        .Y(n5252) );
  AO22X1 U4602 ( .A0(SD_DQI[15]), .A1(n6469), .B0(RdDataMemFd[15]), .B1(n6405), 
        .Y(n5253) );
  AO22X1 U4603 ( .A0(SD_DQI[14]), .A1(n6469), .B0(RdDataMemFd[14]), .B1(n6405), 
        .Y(n5254) );
  AO22X1 U4604 ( .A0(SD_DQI[13]), .A1(n6469), .B0(RdDataMemFd[13]), .B1(n6405), 
        .Y(n5255) );
  AO22X1 U4605 ( .A0(SD_DQI[12]), .A1(n6469), .B0(RdDataMemFd[12]), .B1(n6405), 
        .Y(n5256) );
  AO22X1 U4606 ( .A0(SD_DQI[11]), .A1(n6469), .B0(RdDataMemFd[11]), .B1(n6405), 
        .Y(n5257) );
  AO22X1 U4607 ( .A0(SD_DQI[10]), .A1(n6469), .B0(RdDataMemFd[10]), .B1(n6405), 
        .Y(n5258) );
  AO22X1 U4608 ( .A0(SD_DQI[9]), .A1(n6469), .B0(RdDataMemFd[9]), .B1(n6405), 
        .Y(n5259) );
  AO22X1 U4609 ( .A0(SD_DQI[8]), .A1(n6469), .B0(RdDataMemFd[8]), .B1(n6405), 
        .Y(n5260) );
  AO22X1 U4610 ( .A0(SD_DQI[7]), .A1(n6469), .B0(RdDataMemFd[7]), .B1(n6405), 
        .Y(n5261) );
  AO22X1 U4611 ( .A0(SD_DQI[6]), .A1(n6469), .B0(RdDataMemFd[6]), .B1(n6405), 
        .Y(n5262) );
  AO22X1 U4612 ( .A0(SD_DQI[5]), .A1(n6469), .B0(RdDataMemFd[5]), .B1(n6405), 
        .Y(n5263) );
  AO22X1 U4613 ( .A0(SD_DQI[4]), .A1(n6469), .B0(RdDataMemFd[4]), .B1(n6405), 
        .Y(n5264) );
  AO22X1 U4614 ( .A0(SD_DQI[3]), .A1(n6469), .B0(RdDataMemFd[3]), .B1(n6405), 
        .Y(n5265) );
  AO22X1 U4615 ( .A0(SD_DQI[2]), .A1(n6469), .B0(RdDataMemFd[2]), .B1(n6405), 
        .Y(n5266) );
  AO22X1 U4616 ( .A0(SD_DQI[1]), .A1(n6469), .B0(RdDataMemFd[1]), .B1(n6405), 
        .Y(n5267) );
  AO22X1 U4617 ( .A0(n6469), .A1(SD_DQI[0]), .B0(RdDataMemFd[0]), .B1(n6405), 
        .Y(n5268) );
  INVX1 U4618 ( .A(RQIncAddr[7]), .Y(n5671) );
  INVX1 U4619 ( .A(RQIncAddr[5]), .Y(n5652) );
  INVX1 U4620 ( .A(RQIncAddr[6]), .Y(n5660) );
  INVX1 U4621 ( .A(RQIncAddr[4]), .Y(n5642) );
  OAI31X1 U4622 ( .A0(n5506), .A1(RdAddrHold), .A2(n6415), .B0(n5508), .Y(
        n5328) );
  OA22X1 U4623 ( .A0(n2790), .A1(n6414), .B0(BA_STS[14]), .B1(n6414), .Y(n5508) );
  INVX1 U4624 ( .A(WQIncAddr[0]), .Y(n5711) );
  XOR2X1 U4625 ( .A(n2790), .B(In16BitSel), .Y(n5327) );
  DFFRX1 WriteLatA0_reg_16_ ( .D(n5154), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_16_) );
  DFFRX1 WriteLatA0_reg_10_ ( .D(n5160), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_10_), .QN(n6351) );
  DFFRX1 WriteLatA0_reg_9_ ( .D(n5161), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_9_), .QN(n6354) );
  DFFRX1 WriteLatA0_reg_17_ ( .D(n5153), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_17_), .QN(n6352) );
  DFFRX1 WriteLatA0_reg_12_ ( .D(n5158), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_12_), .QN(n6358) );
  DFFRX1 WriteLatA0_reg_14_ ( .D(n5156), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_14_), .QN(n6313) );
  DFFRX1 WriteLatA0_reg_18_ ( .D(n5152), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_18_) );
  DFFRX1 CurStW_reg_4_ ( .D(NxtStW[4]), .CK(ACLK), .RN(ARESETB), .Q(tWWSpi), 
        .QN(n6353) );
  DFFRX1 ReadLatA0_reg_14_ ( .D(n5214), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_14_) );
  DFFRX1 WriteLatA0_reg_13_ ( .D(n5157), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_13_), .QN(n6306) );
  DFFRX1 ReadLatA0_reg_16_ ( .D(n5212), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_16_) );
  DFFRX1 ReadLatA0_reg_15_ ( .D(n5213), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_15_) );
  DFFRX1 ReadLatA0_reg_13_ ( .D(n5215), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_13_) );
  DFFRX1 WriteLatA0_reg_15_ ( .D(n5155), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_15_), .QN(n6322) );
  DFFRX1 CurStW_reg_3_ ( .D(NxtStW[3]), .CK(ACLK), .RN(ARESETB), .Q(tWWReq), 
        .QN(n6308) );
  DFFRX1 WriteLatTT_reg_0_ ( .D(n5174), .CK(ACLK), .RN(ARESETB), .Q(n5338), 
        .QN(n6441) );
  DFFRX1 WrAddrHold_reg ( .D(n5293), .CK(ACLK), .RN(ARESETB), .Q(WrAddrHold), 
        .QN(n6410) );
  DFFRX1 RdAddrHold_reg ( .D(n5328), .CK(ACLK), .RN(ARESETB), .Q(RdAddrHold), 
        .QN(n6414) );
  DFFRX1 ReadLatTT_reg_0_ ( .D(n5232), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatTT_0_), .QN(n6360) );
  DFFRX1 WriteLatA0_reg_7_ ( .D(n5163), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_7_), .QN(n6312) );
  DFFRX1 WriteLatA0_reg_23_ ( .D(n5147), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_23_), .QN(n6365) );
  DFFRX1 WriteLatA0_reg_20_ ( .D(n5150), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_20_), .QN(n6316) );
  DFFRX1 WriteLatA0_reg_21_ ( .D(n5149), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_21_), .QN(n6357) );
  DFFRX1 CurStRD_reg_1_ ( .D(NxtStRD[1]), .CK(ACLK), .RN(ARESETB), .Q(tRDReq), 
        .QN(n6383) );
  DFFRX1 WriteLatA0_reg_19_ ( .D(n5151), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_19_), .QN(n6318) );
  DFFRX1 ReadLatA0_reg_22_ ( .D(n5206), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_22_) );
  DFFRX1 ReadLatA0_reg_18_ ( .D(n5210), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_18_) );
  DFFRX1 ReadLatA0_reg_17_ ( .D(n5211), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_17_) );
  DFFRX1 WriteLatA0_reg_1_ ( .D(n5169), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatA0_1_), .QN(n6361) );
  DFFRX1 WriteLatA0_reg_0_ ( .D(n5170), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatA0_0_) );
  DFFRX1 CurStR_reg_2_ ( .D(NxtStR[2]), .CK(ACLK), .RN(ARESETB), .Q(tRRSpi), 
        .QN(n6356) );
  DFFRX1 ReadLatA0_reg_23_ ( .D(n5205), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_23_) );
  DFFRX1 ReadLatA0_reg_21_ ( .D(n5207), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_21_) );
  DFFRX1 ReadLatA0_reg_20_ ( .D(n5208), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_20_) );
  DFFRX1 ReadLatA0_reg_19_ ( .D(n5209), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_19_) );
  DFFRX1 WriteLatA0_reg_22_ ( .D(n5148), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_22_), .QN(n6359) );
  DFFRX1 CurStR_reg_1_ ( .D(NxtStR[1]), .CK(ACLK), .RN(ARESETB), .Q(tRRReq), 
        .QN(n6307) );
  DFFRX1 ReadLatA0_reg_1_ ( .D(n5227), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatA0_1_), .QN(n6362) );
  DFFRX1 ReadLatA0_reg_0_ ( .D(n5228), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatA0_0_) );
  DFFRX1 WriteLatA0_reg_8_ ( .D(n5162), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_8_), .QN(n6314) );
  DFFRX1 WriteLatTT_reg_3_ ( .D(n5171), .CK(ACLK), .RN(ARESETB), .Q(n5332), 
        .QN(n6325) );
  DFFRX1 WriteLatTT_reg_2_ ( .D(n5172), .CK(ACLK), .RN(ARESETB), .Q(n5334) );
  DFFRX1 WriteLatTT_reg_1_ ( .D(n5173), .CK(ACLK), .RN(ARESETB), .Q(n5336), 
        .QN(n6319) );
  DFFRX1 ReadLatTT_reg_1_ ( .D(n5231), .CK(ACLK), .RN(ARESETB), .Q(n5344), 
        .QN(n6321) );
  DFFRX1 WriteLatBB_reg_1_ ( .D(n5143), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatBB[1]) );
  DFFRX1 WriteLatBB_reg_0_ ( .D(n5144), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatBB[0]) );
  DFFRX1 ReadLatTT_reg_3_ ( .D(n5229), .CK(ACLK), .RN(ARESETB), .Q(n5340), 
        .QN(n6323) );
  DFFRX1 ReadLatTT_reg_2_ ( .D(n5230), .CK(ACLK), .RN(ARESETB), .Q(n5342), 
        .QN(n6364) );
  DFFRX1 ReadLatBB_reg_1_ ( .D(n5201), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatBB[1]) );
  DFFRX1 ReadLatBB_reg_0_ ( .D(n5202), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatBB[0]) );
  DFFRX1 LatchedWBL_reg_0_ ( .D(n5190), .CK(ACLK), .RN(ARESETB), .Q(
        LatchedWBL_0_), .QN(n6367) );
  DFFRX1 CurStW_reg_2_ ( .D(NxtStW[2]), .CK(ACLK), .RN(ARESETB), .Q(BValid), 
        .QN(n6438) );
  DFFRX1 AckMem_reg ( .D(AckMem251), .CK(ACLK), .RN(ARESETB), .Q(WriteAck), 
        .QN(n6349) );
  DFFRX1 LatchedWBL_reg_2_ ( .D(n5188), .CK(ACLK), .RN(ARESETB), .Q(
        LatchedWBL_2_), .QN(n6381) );
  DFFRX1 LatchedWBL_reg_1_ ( .D(n5189), .CK(ACLK), .RN(ARESETB), .Q(
        LatchedWBL_1_), .QN(n6380) );
  DFFRX1 WriteLatA0_reg_3_ ( .D(n5167), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatA0_3_), .QN(n6368) );
  DFFRX1 WriteLatA0_reg_2_ ( .D(n5168), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatA0_2_) );
  DFFSX1 CurStW_reg_0_ ( .D(NxtStW[0]), .CK(ACLK), .SN(ARESETB), .Q(tWIdle), 
        .QN(n6409) );
  DFFRX1 WriteLatA0_reg_25_ ( .D(n5145), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_25_), .QN(n6371) );
  DFFSX1 CurStR_reg_0_ ( .D(NxtStR[0]), .CK(ACLK), .SN(ARESETB), .QN(n6315) );
  DFFRX1 ReadLatA0_reg_25_ ( .D(n5203), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_25_), .QN(n6328) );
  DFFRX1 ReadLatA0_reg_3_ ( .D(n5225), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatA0_3_), .QN(n6369) );
  DFFRX1 ReadLatA0_reg_2_ ( .D(n5226), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatA0_2_) );
  DFFRX1 CurStW_reg_1_ ( .D(NxtStW[1]), .CK(ACLK), .RN(ARESETB), .Q(tWWDat) );
  DFFRX1 BId_reg_3_ ( .D(n5179), .CK(ACLK), .RN(ARESETB), .Q(BId[3]) );
  DFFRX1 BId_reg_2_ ( .D(n5180), .CK(ACLK), .RN(ARESETB), .Q(BId[2]) );
  DFFRX1 BId_reg_1_ ( .D(n5181), .CK(ACLK), .RN(ARESETB), .Q(BId[1]) );
  DFFRX1 BId_reg_0_ ( .D(n5182), .CK(ACLK), .RN(ARESETB), .Q(BId[0]) );
  DFFRX1 WriteLatA0_reg_24_ ( .D(n5146), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_24_) );
  DFFRX1 WriteLatA0_reg_4_ ( .D(n5166), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_4_), .QN(n6378) );
  DFFRX1 WriteLatA0_reg_6_ ( .D(n5164), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_6_), .QN(n6375) );
  DFFRX1 WriteLatA0_reg_5_ ( .D(n5165), .CK(ACLK), .RN(ARESETB), .Q(
        WriteLatAA_5_), .QN(n6404) );
  DFFRX1 ReadLatA0_reg_4_ ( .D(n5224), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_4_), .QN(n6379) );
  DFFRX1 ReadLatA0_reg_6_ ( .D(n5222), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_6_), .QN(n6376) );
  DFFRX1 ReadLatA0_reg_5_ ( .D(n5223), .CK(ACLK), .RN(ARESETB), .Q(
        ReadLatAA_5_) );
  DFFRX1 LatchedRBL_reg_1_ ( .D(n5271), .CK(ACLK), .RN(ARESETB), .Q(
        LatchedRBL_1_), .QN(n6373) );
  DFFRX1 LatchedRBL_reg_0_ ( .D(n5272), .CK(ACLK), .RN(ARESETB), .Q(
        LatchedRBL_0_), .QN(n6418) );
  DFFRX1 LatchedWBL_reg_3_ ( .D(n5187), .CK(ACLK), .RN(ARESETB), .Q(
        LatchedWBL_3_), .QN(n6406) );
  DFFRX1 RdDataMemFd_reg_15_ ( .D(n5253), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[15]), .QN(n6388) );
  DFFRX1 RdDataMemFd_reg_14_ ( .D(n5254), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[14]), .QN(n6389) );
  DFFRX1 RdDataMemFd_reg_13_ ( .D(n5255), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[13]), .QN(n6390) );
  DFFRX1 RdDataMemFd_reg_12_ ( .D(n5256), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[12]), .QN(n6391) );
  DFFRX1 RdDataMemFd_reg_11_ ( .D(n5257), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[11]), .QN(n6392) );
  DFFRX1 RdDataMemFd_reg_10_ ( .D(n5258), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[10]), .QN(n6393) );
  DFFRX1 RdDataMemFd_reg_9_ ( .D(n5259), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[9]), .QN(n6394) );
  DFFRX1 RdDataMemFd_reg_8_ ( .D(n5260), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[8]), .QN(n6395) );
  DFFRX1 RdDataMemFd_reg_7_ ( .D(n5261), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[7]), .QN(n6396) );
  DFFRX1 RdDataMemFd_reg_6_ ( .D(n5262), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[6]), .QN(n6397) );
  DFFRX1 RdDataMemFd_reg_5_ ( .D(n5263), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[5]), .QN(n6398) );
  DFFRX1 RdDataMemFd_reg_4_ ( .D(n5264), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[4]), .QN(n6399) );
  DFFRX1 RdDataMemFd_reg_3_ ( .D(n5265), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[3]), .QN(n6400) );
  DFFRX1 RdDataMemFd_reg_2_ ( .D(n5266), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[2]), .QN(n6401) );
  DFFRX1 RdDataMemFd_reg_1_ ( .D(n5267), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[1]), .QN(n6402) );
  DFFRX1 RdDataMemFd_reg_0_ ( .D(n5268), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[0]), .QN(n6403) );
  DFFRX1 DelayxWQRead_reg ( .D(DelayiWQRead), .CK(ACLK), .RN(ARESETB), .Q(
        SD_DQE), .QN(n6446) );
  DFFRX1 RdDataMemFd_reg_31_ ( .D(n5237), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[31]), .QN(n6330) );
  DFFRX1 RdDataMemFd_reg_30_ ( .D(n5238), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[30]), .QN(n6331) );
  DFFRX1 RdDataMemFd_reg_29_ ( .D(n5239), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[29]), .QN(n6332) );
  DFFRX1 RdDataMemFd_reg_28_ ( .D(n5240), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[28]), .QN(n6333) );
  DFFRX1 RdDataMemFd_reg_27_ ( .D(n5241), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[27]), .QN(n6334) );
  DFFRX1 RdDataMemFd_reg_26_ ( .D(n5242), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[26]), .QN(n6335) );
  DFFRX1 RdDataMemFd_reg_25_ ( .D(n5243), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[25]), .QN(n6336) );
  DFFRX1 RdDataMemFd_reg_24_ ( .D(n5244), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[24]), .QN(n6337) );
  DFFRX1 RdDataMemFd_reg_23_ ( .D(n5245), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[23]), .QN(n6338) );
  DFFRX1 RdDataMemFd_reg_22_ ( .D(n5246), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[22]), .QN(n6339) );
  DFFRX1 RdDataMemFd_reg_21_ ( .D(n5247), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[21]), .QN(n6340) );
  DFFRX1 RdDataMemFd_reg_20_ ( .D(n5248), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[20]), .QN(n6341) );
  DFFRX1 RdDataMemFd_reg_19_ ( .D(n5249), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[19]), .QN(n6342) );
  DFFRX1 RdDataMemFd_reg_18_ ( .D(n5250), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[18]), .QN(n6343) );
  DFFRX1 RdDataMemFd_reg_17_ ( .D(n5251), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[17]), .QN(n6344) );
  DFFRX1 RdDataMemFd_reg_16_ ( .D(n5252), .CK(FCLK), .RN(ARESETB), .Q(
        RdDataMemFd[16]), .QN(n6345) );
  DFFRX1 WrWrapAddrSt_reg_3_ ( .D(n5191), .CK(ACLK), .RN(ARESETB), .Q(
        WrWrapAddrSt_3_), .QN(n6305) );
  DFFRX1 WrWrapAddrSt_reg_2_ ( .D(n5192), .CK(ACLK), .RN(ARESETB), .Q(
        WrWrapAddrSt_2_), .QN(n6327) );
  DFFRX1 WrWrapAddrSt_reg_1_ ( .D(n5193), .CK(ACLK), .RN(ARESETB), .Q(
        WrWrapAddrSt_1_), .QN(n6310) );
  DFFRX1 WrWrapAddrSt_reg_0_ ( .D(n5194), .CK(ACLK), .RN(ARESETB), .Q(
        WrWrapAddrSt_0_), .QN(n6329) );
  DFFRX1 RdLastCnt_reg_0_ ( .D(n5292), .CK(ACLK), .RN(ARESETB), .Q(
        RdLastCnt[0]), .QN(n6324) );
  DFFRX1 RBurstCnt_reg_2_ ( .D(n5286), .CK(ACLK), .RN(ARESETB), .Q(
        RBurstCnt[2]), .QN(n6408) );
  DFFRX1 RBurstCnt_reg_0_ ( .D(n5288), .CK(ACLK), .RN(ARESETB), .Q(
        RBurstCnt[0]), .QN(n6370) );
  DFFRX1 RBurstCnt_reg_1_ ( .D(n5287), .CK(ACLK), .RN(ARESETB), .Q(
        RBurstCnt[1]), .QN(n6372) );
  DFFRX1 RdLastCnt_reg_1_ ( .D(n5291), .CK(ACLK), .RN(ARESETB), .Q(
        RdLastCnt[1]), .QN(n6309) );
  DFFRX1 WBurstCnt_reg_0_ ( .D(n5186), .CK(ACLK), .RN(ARESETB), .Q(
        WBurstCnt[0]), .QN(n6440) );
  DFFRX1 RdLastCnt_reg_2_ ( .D(n5290), .CK(ACLK), .RN(ARESETB), .Q(
        RdLastCnt[2]), .QN(n6350) );
  DFFRX1 RdWrapAddrSt_reg_2_ ( .D(n5274), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapAddrSt_2_) );
  DFFRX1 RdWrapAddrSt_reg_0_ ( .D(n5276), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapAddrSt_0_) );
  DFFRX1 RBurstCnt_reg_3_ ( .D(n5285), .CK(ACLK), .RN(ARESETB), .Q(
        RBurstCnt[3]), .QN(n6347) );
  DFFSX1 CurStRD_reg_0_ ( .D(NxtStRD[0]), .CK(ACLK), .SN(ARESETB), .Q(tRDIdle), 
        .QN(n6416) );
  DFFRX1 WBurstCnt_reg_3_ ( .D(n5183), .CK(ACLK), .RN(ARESETB), .Q(
        WBurstCnt[3]), .QN(n6386) );
  DFFRX1 WBurstCnt_reg_1_ ( .D(n5185), .CK(ACLK), .RN(ARESETB), .Q(
        WBurstCnt[1]), .QN(n6382) );
  DFFRX1 Out16BitSel_reg ( .D(n5294), .CK(ACLK), .RN(ARESETB), .Q(Out16BitSel), 
        .QN(n6377) );
  DFFRX1 WBurstCnt_reg_2_ ( .D(n5184), .CK(ACLK), .RN(ARESETB), .Q(
        WBurstCnt[2]), .QN(n6326) );
  DFFRX1 LatchedRBL_reg_3_ ( .D(n5269), .CK(ACLK), .RN(ARESETB), .Q(
        LatchedRBL_3_), .QN(n6385) );
  DFFRX1 LatchedRBL_reg_2_ ( .D(n5270), .CK(ACLK), .RN(ARESETB), .Q(
        LatchedRBL_2_), .QN(n6384) );
  DFFRX1 RdLastCnt_reg_3_ ( .D(n5289), .CK(ACLK), .RN(ARESETB), .Q(
        RdLastCnt[3]), .QN(n6374) );
  DFFRX1 RdWrapAddrSt_reg_3_ ( .D(n5273), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapAddrSt_3_) );
  DFFRX1 RdWrapAddrSt_reg_1_ ( .D(n5275), .CK(ACLK), .RN(ARESETB), .Q(
        RdWrapAddrSt_1_) );
  DFFRX1 ReadLatchEnFd_reg ( .D(BA_STS[1]), .CK(FCLK), .RN(ARESETB), .Q(n5347), 
        .QN(n6405) );
  DFFRX1 RdDataRdy_reg ( .D(n2790), .CK(ACLK), .RN(ARESETB), .QN(n6448) );
  DFFRX1 RdLastMem_reg ( .D(iDelayReadLast), .CK(ACLK), .RN(ARESETB), .Q(
        IncRdLastCnt), .QN(n6407) );
  DFFRX1 iDelayReadFlag_reg ( .D(n6469), .CK(ACLK), .RN(ARESETB), .Q(n2790), 
        .QN(n6415) );
  DFFRX1 In16BitSel_reg ( .D(n5327), .CK(ACLK), .RN(ARESETB), .Q(In16BitSel), 
        .QN(n6450) );
  DFFRX1 DelayiWQRead_reg ( .D(iWQRead), .CK(ACLK), .RN(ARESETB), .Q(
        DelayiWQRead) );
  DFFRX1 WriteLatID_reg_3_ ( .D(n5175), .CK(ACLK), .RN(ARESETB), .Q(
        WriteReqID[3]) );
  DFFRX1 WriteLatID_reg_2_ ( .D(n5176), .CK(ACLK), .RN(ARESETB), .Q(
        WriteReqID[2]) );
  DFFRX1 WriteLatID_reg_1_ ( .D(n5177), .CK(ACLK), .RN(ARESETB), .Q(
        WriteReqID[1]) );
  DFFRX1 WriteLatID_reg_0_ ( .D(n5178), .CK(ACLK), .RN(ARESETB), .Q(
        WriteReqID[0]) );
  DFFRX1 ReadLatID_reg_3_ ( .D(n5233), .CK(ACLK), .RN(ARESETB), .Q(
        ReadReqID[3]) );
  DFFRX1 ReadLatID_reg_2_ ( .D(n5234), .CK(ACLK), .RN(ARESETB), .Q(
        ReadReqID[2]) );
  DFFRX1 ReadLatID_reg_1_ ( .D(n5235), .CK(ACLK), .RN(ARESETB), .Q(
        ReadReqID[1]) );
  DFFRX1 ReadLatID_reg_0_ ( .D(n5236), .CK(ACLK), .RN(ARESETB), .Q(
        ReadReqID[0]) );
  AO21X1 U4626 ( .A0(n6098), .A1(n6191), .B0(n6250), .Y(n6188) );
  AO22X1 U4627 ( .A0(ReadLatAA_13_), .A1(n6453), .B0(ARAddr[13]), .B1(n5356), 
        .Y(n5215) );
  AO22X1 U4628 ( .A0(ReadLatAA_16_), .A1(n6453), .B0(ARAddr[16]), .B1(n5356), 
        .Y(n5212) );
  AO22X1 U4629 ( .A0(ReadLatAA_19_), .A1(n6453), .B0(ARAddr[19]), .B1(n5356), 
        .Y(n5209) );
  AO22X1 U4630 ( .A0(ReadLatAA_22_), .A1(n6453), .B0(ARAddr[22]), .B1(n5356), 
        .Y(n5206) );
  AO22X1 U4631 ( .A0(ReadLatAA_25_), .A1(n6453), .B0(ARAddr[25]), .B1(n5356), 
        .Y(n5203) );
  AO22X1 U4632 ( .A0(ReadLatBB[1]), .A1(n6452), .B0(ARBurst[1]), .B1(n5356), 
        .Y(n5201) );
  AO22X1 U4633 ( .A0(ReadLatAA_24_), .A1(n6451), .B0(ARAddr[24]), .B1(n5356), 
        .Y(n5204) );
  AO22X1 U4634 ( .A0(ReadLatAA_21_), .A1(n5706), .B0(ARAddr[21]), .B1(n5356), 
        .Y(n5207) );
  AO22X1 U4635 ( .A0(ReadLatAA_18_), .A1(n6452), .B0(ARAddr[18]), .B1(n5356), 
        .Y(n5210) );
  AO22X1 U4636 ( .A0(ReadLatAA_15_), .A1(n6451), .B0(ARAddr[15]), .B1(n5356), 
        .Y(n5213) );
  AO22X1 U4637 ( .A0(ReadLatAA_12_), .A1(n5706), .B0(ARAddr[12]), .B1(n5356), 
        .Y(n5216) );
  AO22X1 U4638 ( .A0(ReadLatAA_7_), .A1(n6452), .B0(ARAddr[7]), .B1(n5356), 
        .Y(n5221) );
  AO22X1 U4639 ( .A0(ReadLatAA_6_), .A1(n6451), .B0(ARAddr[6]), .B1(n5356), 
        .Y(n5222) );
  AO22X1 U4640 ( .A0(ReadLatA0_3_), .A1(n5706), .B0(ARAddr[3]), .B1(n5356), 
        .Y(n5225) );
  AO22X1 U4641 ( .A0(ReadLatA0_1_), .A1(n6452), .B0(ARAddr[1]), .B1(n5356), 
        .Y(n5227) );
  AO22X1 U4642 ( .A0(ReadLatA0_0_), .A1(n6451), .B0(ARAddr[0]), .B1(n5356), 
        .Y(n5228) );
  AO22X1 U4643 ( .A0(n5344), .A1(n5706), .B0(ARLen[1]), .B1(n5356), .Y(n5231)
         );
  AO22X1 U4644 ( .A0(ReadReqID[3]), .A1(n6452), .B0(ARId[3]), .B1(n5356), .Y(
        n5233) );
  AO22X1 U4645 ( .A0(ReadReqID[2]), .A1(n6451), .B0(ARId[2]), .B1(n5356), .Y(
        n5234) );
  AO22X1 U4646 ( .A0(ReadLatAA_8_), .A1(n5706), .B0(ARAddr[8]), .B1(n5356), 
        .Y(n5220) );
  AO22X1 U4647 ( .A0(ReadReqID[0]), .A1(n6452), .B0(ARId[0]), .B1(n5356), .Y(
        n5236) );
  AO22X1 U4648 ( .A0(ReadReqID[1]), .A1(n6451), .B0(ARId[1]), .B1(n5356), .Y(
        n5235) );
  AO22X1 U4649 ( .A0(ReadLatTT_0_), .A1(n5706), .B0(ARLen[0]), .B1(n5356), .Y(
        n5232) );
  AO22X1 U4650 ( .A0(n6467), .A1(n6452), .B0(ARLen[2]), .B1(n5356), .Y(n5230)
         );
  AO22X1 U4651 ( .A0(n6466), .A1(n6451), .B0(ARLen[3]), .B1(n5356), .Y(n5229)
         );
  AO22X1 U4652 ( .A0(ReadLatA0_2_), .A1(n5706), .B0(ARAddr[2]), .B1(n5356), 
        .Y(n5226) );
  AO22X1 U4653 ( .A0(ReadLatAA_4_), .A1(n6452), .B0(ARAddr[4]), .B1(n5356), 
        .Y(n5224) );
  AO22X1 U4654 ( .A0(ReadLatAA_5_), .A1(n6451), .B0(ARAddr[5]), .B1(n5356), 
        .Y(n5223) );
  AO22X1 U4655 ( .A0(ReadLatAA_14_), .A1(n5706), .B0(ARAddr[14]), .B1(n5356), 
        .Y(n5214) );
  AO22X1 U4656 ( .A0(ReadLatAA_17_), .A1(n6452), .B0(ARAddr[17]), .B1(n5356), 
        .Y(n5211) );
  AO22X1 U4657 ( .A0(ReadLatAA_20_), .A1(n6451), .B0(ARAddr[20]), .B1(n5356), 
        .Y(n5208) );
  AO22X1 U4658 ( .A0(ReadLatAA_23_), .A1(n5706), .B0(ARAddr[23]), .B1(n5356), 
        .Y(n5205) );
  AO22X1 U4659 ( .A0(ReadLatBB[0]), .A1(n6452), .B0(ARBurst[0]), .B1(n5356), 
        .Y(n5202) );
  AO22X1 U4660 ( .A0(ReadLatAA_11_), .A1(n6451), .B0(ARAddr[11]), .B1(n5356), 
        .Y(n5217) );
  AOI221X1 U4661 ( .A0(n19), .A1(n6013), .B0(n18), .B1(n6015), .C0(n6065), .Y(
        n6050) );
  AOI222X1 U4662 ( .A0(RSpi2Addr1902_23_), .A1(n6013), .B0(n6014), .B1(
        ReadLatAA_23_), .C0(RSpi2Addr1914_23_), .C1(n6015), .Y(n6089) );
  AO22X1 U4663 ( .A0(ReadLatAA_9_), .A1(n5706), .B0(ARAddr[9]), .B1(n5356), 
        .Y(n5219) );
  OA22X1 U4664 ( .A0(ReadLatAA_9_), .A1(n6016), .B0(n6017), .B1(n6354), .Y(
        n6011) );
  OAI221X1 U4665 ( .A0(n19), .A1(n6057), .B0(n18), .B1(n6021), .C0(n6058), .Y(
        n6056) );
  OA21X1 U4666 ( .A0(n6113), .A1(n6074), .B0(n6114), .Y(n6106) );
  AO22X1 U4667 ( .A0(ReadLatAA_10_), .A1(n6453), .B0(ARAddr[10]), .B1(n5356), 
        .Y(n5218) );
  OA22X1 U4668 ( .A0(n11), .A1(n6059), .B0(n17), .B1(n6016), .Y(n6058) );
  AHHCONX2 U1_1_15 ( .A(ReadLatAA_10_), .CI(ReadLatAA_9_), .S(
        RSpi2Addr1926_10_), .CON(n155) );
  INVX3 U4669 ( .A(n910), .Y(carry55) );
endmodule


module SDRBLQ_BLQCD3_BLQD15_BLQW9 ( nRST, Clk, WriteEn, ReadEn, WrData, RdData, 
        FullFlag, EmptyFlag );
  input [9:0] WrData;
  output [9:0] RdData;
  input nRST, Clk, WriteEn, ReadEn;
  output FullFlag, EmptyFlag;
  wire   \FIFO[0][9] , \FIFO[0][8] , \FIFO[0][7] , \FIFO[0][6] , \FIFO[0][5] ,
         \FIFO[0][4] , \FIFO[0][3] , \FIFO[0][2] , \FIFO[0][1] , \FIFO[0][0] ,
         \FIFO[1][9] , \FIFO[1][8] , \FIFO[1][7] , \FIFO[1][6] , \FIFO[1][5] ,
         \FIFO[1][4] , \FIFO[1][3] , \FIFO[1][2] , \FIFO[1][1] , \FIFO[1][0] ,
         \FIFO[2][9] , \FIFO[2][8] , \FIFO[2][7] , \FIFO[2][6] , \FIFO[2][5] ,
         \FIFO[2][4] , \FIFO[2][3] , \FIFO[2][2] , \FIFO[2][1] , \FIFO[2][0] ,
         \FIFO[3][9] , \FIFO[3][8] , \FIFO[3][7] , \FIFO[3][6] , \FIFO[3][5] ,
         \FIFO[3][4] , \FIFO[3][3] , \FIFO[3][2] , \FIFO[3][1] , \FIFO[3][0] ,
         \FIFO[4][9] , \FIFO[4][8] , \FIFO[4][7] , \FIFO[4][6] , \FIFO[4][5] ,
         \FIFO[4][4] , \FIFO[4][3] , \FIFO[4][2] , \FIFO[4][1] , \FIFO[4][0] ,
         \FIFO[5][9] , \FIFO[5][8] , \FIFO[5][7] , \FIFO[5][6] , \FIFO[5][5] ,
         \FIFO[5][4] , \FIFO[5][3] , \FIFO[5][2] , \FIFO[5][1] , \FIFO[5][0] ,
         \FIFO[6][9] , \FIFO[6][8] , \FIFO[6][7] , \FIFO[6][6] , \FIFO[6][5] ,
         \FIFO[6][4] , \FIFO[6][3] , \FIFO[6][2] , \FIFO[6][1] , \FIFO[6][0] ,
         \FIFO[7][9] , \FIFO[7][8] , \FIFO[7][7] , \FIFO[7][6] , \FIFO[7][5] ,
         \FIFO[7][4] , \FIFO[7][3] , \FIFO[7][2] , \FIFO[7][1] , \FIFO[7][0] ,
         \FIFO[8][9] , \FIFO[8][8] , \FIFO[8][7] , \FIFO[8][6] , \FIFO[8][5] ,
         \FIFO[8][4] , \FIFO[8][3] , \FIFO[8][2] , \FIFO[8][1] , \FIFO[8][0] ,
         \FIFO[9][9] , \FIFO[9][8] , \FIFO[9][7] , \FIFO[9][6] , \FIFO[9][5] ,
         \FIFO[9][4] , \FIFO[9][3] , \FIFO[9][2] , \FIFO[9][1] , \FIFO[9][0] ,
         \FIFO[10][9] , \FIFO[10][8] , \FIFO[10][7] , \FIFO[10][6] ,
         \FIFO[10][5] , \FIFO[10][4] , \FIFO[10][3] , \FIFO[10][2] ,
         \FIFO[10][1] , \FIFO[10][0] , \FIFO[11][9] , \FIFO[11][8] ,
         \FIFO[11][7] , \FIFO[11][6] , \FIFO[11][5] , \FIFO[11][4] ,
         \FIFO[11][3] , \FIFO[11][2] , \FIFO[11][1] , \FIFO[11][0] ,
         \FIFO[12][9] , \FIFO[12][8] , \FIFO[12][7] , \FIFO[12][6] ,
         \FIFO[12][5] , \FIFO[12][4] , \FIFO[12][3] , \FIFO[12][2] ,
         \FIFO[12][1] , \FIFO[12][0] , \FIFO[13][9] , \FIFO[13][8] ,
         \FIFO[13][7] , \FIFO[13][6] , \FIFO[13][5] , \FIFO[13][4] ,
         \FIFO[13][3] , \FIFO[13][2] , \FIFO[13][1] , \FIFO[13][0] ,
         \FIFO[14][9] , \FIFO[14][8] , \FIFO[14][7] , \FIFO[14][6] ,
         \FIFO[14][5] , \FIFO[14][4] , \FIFO[14][3] , \FIFO[14][2] ,
         \FIFO[14][1] , \FIFO[14][0] , \FIFO[15][9] , \FIFO[15][8] ,
         \FIFO[15][7] , \FIFO[15][6] , \FIFO[15][5] , \FIFO[15][4] ,
         \FIFO[15][3] , \FIFO[15][2] , \FIFO[15][1] , \FIFO[15][0] , WrCnt_3_,
         WrCnt_2_, WrCnt_1_, WrCnt_0_, FIFO232, FIFO2320, FIFO2321, FIFO2322,
         FIFO2323, FIFO2324, FIFO2325, FIFO2326, FIFO2327, FIFO2328, FIFO2329,
         FIFO23210, FIFO23211, FIFO23212, FIFO23213, FIFO23214, FIFO23215,
         FIFO23216, FIFO23217, FIFO23218, FIFO23219, FIFO23220, FIFO23221,
         FIFO23222, FIFO23223, FIFO23224, FIFO23225, FIFO23226, FIFO23227,
         FIFO23228, FIFO23229, FIFO23230, FIFO23231, FIFO23232, FIFO23233,
         FIFO23234, FIFO23235, FIFO23236, FIFO23237, FIFO23238, FIFO23239,
         FIFO23240, FIFO23241, FIFO23242, FIFO23243, FIFO23244, FIFO23245,
         FIFO23246, FIFO23247, FIFO23248, FIFO23249, FIFO23250, FIFO23251,
         FIFO23252, FIFO23253, FIFO23254, FIFO23255, FIFO23256, FIFO23257,
         FIFO23258, FIFO23259, FIFO23260, FIFO23261, FIFO23262, FIFO23263,
         FIFO23264, FIFO23265, FIFO23266, FIFO23267, FIFO23268, FIFO23269,
         FIFO23270, FIFO23271, FIFO23272, FIFO23273, FIFO23274, FIFO23275,
         FIFO23276, FIFO23277, FIFO23278, FIFO23279, FIFO23280, FIFO23281,
         FIFO23282, FIFO23283, FIFO23284, FIFO23285, FIFO23286, FIFO23287,
         FIFO23288, FIFO23289, FIFO23290, FIFO23291, FIFO23292, FIFO23293,
         FIFO23294, FIFO23295, FIFO23296, FIFO23297, FIFO23298, FIFO23299,
         FIFO232100, FIFO232101, FIFO232102, FIFO232103, FIFO232104,
         FIFO232105, FIFO232106, FIFO232107, FIFO232108, FIFO232109,
         FIFO232110, FIFO232111, FIFO232112, FIFO232113, FIFO232114,
         FIFO232115, FIFO232116, FIFO232117, FIFO232118, FIFO232119,
         FIFO232120, FIFO232121, FIFO232122, FIFO232123, FIFO232124,
         FIFO232125, FIFO232126, FIFO232127, FIFO232128, FIFO232129,
         FIFO232130, FIFO232131, FIFO232132, FIFO232133, FIFO232134,
         FIFO232135, FIFO232136, FIFO232137, FIFO232138, FIFO232139,
         FIFO232140, FIFO232141, FIFO232142, FIFO232143, FIFO232144,
         FIFO232145, FIFO232146, FIFO232147, FIFO232148, FIFO232149,
         FIFO232150, FIFO232151, FIFO232152, FIFO232153, FIFO232154,
         FIFO232155, FIFO232156, FIFO232157, FIFO232158, n1768, n1769, n1770,
         n1771, n1772, n1773, n1774, n1775, n1776, n1777, n1778, n1779, n1780,
         n1781, n1782, n1783, n1784, n1785, n1786, n1787, n1788, n1789, n1790,
         n1791, n1792, n1895, n1897, n1902, n1917, n1920, n1921, n1923, n1924,
         n1926, n1927, n1928, n1930, n1931, n1932, n1934, n1935, n1937, n1938,
         n1939, n1940, n1941, n1942, n1943, n1944, n1946, n1948, n1949, n1951,
         n1953, n1955, n1957, n1958, n1960, n1962, n1964, n1966, n1967, n1969,
         n1971, n1973, n1975, n1977, n1979, n1980, n1981, n1982, n1985, n1990,
         n1995, n2000, n2003, n2004, n2005, n2006, n2009, n2014, n2019, n2024,
         n2027, n2028, n2029, n2030, n2033, n2038, n2043, n2048, n2051, n2052,
         n2053, n2054, n2057, n2062, n2067, n2072, n2075, n2076, n2077, n2078,
         n2081, n2086, n2091, n2096, n2099, n2100, n2101, n2102, n2105, n2110,
         n2115, n2120, n2123, n2124, n2125, n2126, n2129, n2134, n2139, n2144,
         n2147, n2148, n2149, n2150, n2153, n2158, n2163, n2168, n2171, n2172,
         n2173, n2174, n2177, n2180, n2181, n2184, n2188, n2192, n2195, n2196,
         n2199, n2202, n2207, n2208, n2209, n2210, n2211, n2212, n2213, n2214,
         n2215, n2216, n2217, n2218, n2219, n2220, n2221, n2222, n2223, n2224,
         n2225, n2226, n2227, n2228, n2229, n2230, n2231, n2232, n2233, n2234,
         n2235, n2236, n2237, n2238, n2239, n2240, n2241, n2242, n2243, n2244,
         n2245, n2246, n2247, n2248, n2249, n2250, n2251, n2252, n2253, n2254,
         n2255, n2256, n2257, n2258, n2259, n2260, n2261, n2262, n2263, n2264,
         n2265, n2266, n2267, n2268, n2269, n2270, n2271, n2272, n2273, n2274,
         n2275, n2276, n2277, n2278, n2279, n2280, n2281, n2282, n2283, n2284,
         n2285, n2286, n2287, n2288, n2289, n2290, n2291, n2292, n2293, n2294,
         n2295, n2296, n2297, n2298, n2299, n2300, n2301, n2302, n2303, n2304,
         n2305, n2306, n2307, n2308, n2309, n2310, n2311, n2312, n2313, n2314,
         n2315, n2316, n2317, n2318, n2319, n2320, n2321, n2322, n2323, n2324,
         n2325, n2326, n2327, n2328, n2329, n2330, n2331, n2332, n2333, n2334,
         n2336, n2337, n2338, n2339, n2340, n2341, n2342, n2343, n2344, n2345,
         n2346, n2348, n2350, n2351, n2352, n2353, n2354, n2355, n2356, n2357,
         n2358, n2359, n2360, n2361, n2362, n2363, n2364, n2365, n2366, n2367,
         n2368, n2369, n2370, n2371, n2372, n2373, n2374, n2375, n2376, n2377,
         n2378, n2379, n2380, n2381, n2382, n2383, n2384, n2385, n2386, n2387,
         n2388, n2389, n2390, n2391, n2392, n2393, n2394, n2395, n2396, n2397,
         n2398, n2399, n2400, n2401, n2402, n2403, n2404, n2405, n2406, n2407,
         n2408, n2409, n2410, n2411, n2412, n2413, n2414, n2415, n2416, n2417,
         n2418, n2419, n2420, n2421, n2422, n2423, n2424, n2425, n2426, n2427,
         n2428, n2429, n2430, n2431, n2432, n2433, n2434, n2435, n2436, n2437,
         n2438, n2439, n2440, n2441, n2442, n2443, n2444, n2445, n2446, n2447,
         n2448, n2449, n2450, n2451, n2452, n2453, n2454, n2455, n2456, n2457,
         n2458, n2459, n2460, n2461, n2462, n2463, n2464, n2465, n2466, n2467,
         n2468, n2469, n2470, n2471, n2472, n2473, n2474, n2475, n2476, n2477,
         n2478, n2479, n2480, n2481, n2482, n2483, n2484, n2485, n2486, n2487,
         n2488, n2489, n2490, n2491, n2492, n2493, n2494, n2495, n2496, n2497,
         n2498, n2499, n2500, n2501, n2502, n2503, n2504, n2505, n2506, n2507,
         n2508, n2509, n2510, n2511, n2512, n2513, n2514, n2515, n2516, n2517,
         n2518, n2519, n2520, n2521, n2522, n2523, n2524, n2525, n2526, n2527,
         n2528, n2529, n2530, n2531, n2532, n2533, n2534, n2535, n2536, n2537,
         n2538, n2539, n2540, n2541, n2542, n2543, n2544, n2545, n2546, n2547,
         n2548, n2549, n2550, n2551, n2552, n2553, n2554, n2555, n2556, n2557,
         n2558, n2559, n2560, n2561, n2562, n2563, n2564, n2565, n2566, n2567;
  wire   [3:0] RdCnt;

  XOR2X4 U1899 ( .A(n1917), .B(WriteEn), .Y(n1895) );
  INVX6 U1900 ( .A(n1895), .Y(n1902) );
  NAND2X1 U1901 ( .A(n1917), .B(n1902), .Y(n2350) );
  NAND2BX1 U1902 ( .AN(n1917), .B(n1902), .Y(n1897) );
  INVX1 U1903 ( .A(ReadEn), .Y(n1917) );
  NAND2BX1 U1904 ( .AN(n1930), .B(n1939), .Y(n1934) );
  INVX1 U1905 ( .A(WriteEn), .Y(n1930) );
  OR4X1 U1906 ( .A(n2003), .B(n2004), .C(n2005), .D(n2006), .Y(RdData[7]) );
  NAND2BX1 U1907 ( .AN(n1917), .B(n1928), .Y(n1923) );
  INVX1 U1908 ( .A(n2219), .Y(n2220) );
  INVX1 U1909 ( .A(n2242), .Y(n2243) );
  INVX1 U1910 ( .A(n2222), .Y(n2223) );
  INVX1 U1911 ( .A(n2558), .Y(n2221) );
  INVX1 U1912 ( .A(n2240), .Y(n2241) );
  INVX1 U1913 ( .A(n2224), .Y(n2225) );
  INVX1 U1914 ( .A(n2207), .Y(n2208) );
  INVX1 U1915 ( .A(n2238), .Y(n2239) );
  XOR2X1 U1916 ( .A(n2520), .B(n1934), .Y(n1769) );
  OAI222X1 U1917 ( .A0(n2350), .A1(n2351), .B0(n1897), .B1(n2531), .C0(n1902), 
        .C1(n2376), .Y(n1778) );
  OAI222X1 U1918 ( .A0(n2350), .A1(n2524), .B0(n1897), .B1(n2376), .C0(n1902), 
        .C1(n2351), .Y(n1779) );
  OAI222X1 U1919 ( .A0(n2350), .A1(n2373), .B0(n1897), .B1(n2351), .C0(n1902), 
        .C1(n2524), .Y(n1780) );
  OAI222X1 U1920 ( .A0(n2350), .A1(n2447), .B0(n1897), .B1(n2524), .C0(n1902), 
        .C1(n2373), .Y(n1781) );
  OAI222X1 U1921 ( .A0(n2350), .A1(n2525), .B0(n1897), .B1(n2373), .C0(n1902), 
        .C1(n2447), .Y(n1782) );
  OAI222X1 U1922 ( .A0(n2350), .A1(n2374), .B0(n1897), .B1(n2447), .C0(n1902), 
        .C1(n2525), .Y(n1783) );
  OAI222X1 U1923 ( .A0(n2350), .A1(n2448), .B0(n1897), .B1(n2525), .C0(n1902), 
        .C1(n2374), .Y(n1784) );
  OAI222X1 U1924 ( .A0(n2350), .A1(n2526), .B0(n1897), .B1(n2374), .C0(n1902), 
        .C1(n2448), .Y(n1785) );
  OAI222X1 U1925 ( .A0(n2350), .A1(n2375), .B0(n1897), .B1(n2448), .C0(n1902), 
        .C1(n2526), .Y(n1786) );
  OAI222X1 U1926 ( .A0(n2350), .A1(n2449), .B0(n1897), .B1(n2526), .C0(n1902), 
        .C1(n2375), .Y(n1787) );
  OAI222X1 U1927 ( .A0(n2350), .A1(n2527), .B0(n1897), .B1(n2375), .C0(n1902), 
        .C1(n2449), .Y(n1788) );
  OAI222X1 U1928 ( .A0(n2372), .A1(n2350), .B0(n1897), .B1(n2449), .C0(n1902), 
        .C1(n2527), .Y(n1789) );
  OAI222X1 U1929 ( .A0(n2530), .A1(n2350), .B0(n1897), .B1(n2527), .C0(n1902), 
        .C1(n2372), .Y(n1790) );
  OAI221X1 U1930 ( .A0(WriteEn), .A1(n2519), .B0(n1930), .B1(n1931), .C0(n1932), .Y(n1770) );
  OAI221X1 U1931 ( .A0(n1935), .A1(n2535), .B0(n1930), .B1(n2559), .C0(n1938), 
        .Y(n1768) );
  INVX1 U1932 ( .A(n1934), .Y(n1935) );
  OR4X1 U1933 ( .A(n2051), .B(n2052), .C(n2053), .D(n2054), .Y(RdData[5]) );
  OAI221X1 U1934 ( .A0(n1971), .A1(n2494), .B0(n1973), .B1(n2425), .C0(n2072), 
        .Y(n2051) );
  NAND2BX1 U1935 ( .AN(n2202), .B(n1928), .Y(n1926) );
  NAND2BX1 U1936 ( .AN(n1927), .B(n1928), .Y(n1949) );
  NAND2BX1 U1937 ( .AN(n1920), .B(n2532), .Y(n1958) );
  NAND2BX1 U1938 ( .AN(n2196), .B(n1928), .Y(n1967) );
  NAND2BX1 U1939 ( .AN(n1921), .B(n2180), .Y(n1951) );
  NAND2BX1 U1940 ( .AN(n2181), .B(n2532), .Y(n1960) );
  NAND2BX1 U1941 ( .AN(n1921), .B(n2195), .Y(n1969) );
  OR2X1 U1942 ( .A(n2202), .B(n1921), .Y(n1977) );
  OR4X1 U1943 ( .A(n2075), .B(n2076), .C(n2077), .D(n2078), .Y(RdData[4]) );
  OAI221X1 U1944 ( .A0(n1971), .A1(n2495), .B0(n1973), .B1(n2426), .C0(n2096), 
        .Y(n2075) );
  OAI221X1 U1945 ( .A0(n1962), .A1(n2478), .B0(n1964), .B1(n2422), .C0(n2091), 
        .Y(n2076) );
  OR4X1 U1946 ( .A(n2171), .B(n2172), .C(n2173), .D(n2174), .Y(RdData[0]) );
  OAI221X1 U1947 ( .A0(n1971), .A1(n2499), .B0(n1973), .B1(n2385), .C0(n2199), 
        .Y(n2171) );
  OAI221X1 U1948 ( .A0(n1962), .A1(n2353), .B0(n1964), .B1(n2488), .C0(n2192), 
        .Y(n2172) );
  OAI221X1 U1949 ( .A0(n1953), .A1(n2380), .B0(n1955), .B1(n2484), .C0(n2184), 
        .Y(n2173) );
  OR4X1 U1950 ( .A(n2099), .B(n2100), .C(n2101), .D(n2102), .Y(RdData[3]) );
  OAI221X1 U1951 ( .A0(n1971), .A1(n2496), .B0(n1973), .B1(n2384), .C0(n2120), 
        .Y(n2099) );
  OAI221X1 U1952 ( .A0(n1962), .A1(n2451), .B0(n1964), .B1(n2382), .C0(n2115), 
        .Y(n2100) );
  OAI221X1 U1953 ( .A0(n1953), .A1(n2379), .B0(n1955), .B1(n2454), .C0(n2110), 
        .Y(n2101) );
  OR2X1 U1954 ( .A(n2202), .B(n2181), .Y(n1973) );
  NAND2BX1 U1955 ( .AN(n2181), .B(n2195), .Y(n1964) );
  NAND2BX1 U1956 ( .AN(n2181), .B(n2180), .Y(n1946) );
  NAND2BX1 U1957 ( .AN(n1921), .B(n2532), .Y(n1955) );
  NAND2BX1 U1958 ( .AN(n1920), .B(n2195), .Y(n1962) );
  NAND2BX1 U1959 ( .AN(n1920), .B(n2180), .Y(n1944) );
  NAND2BX1 U1960 ( .AN(n2188), .B(n2532), .Y(n1953) );
  OR4X1 U1961 ( .A(n2123), .B(n2124), .C(n2125), .D(n2126), .Y(RdData[2]) );
  OAI221X1 U1962 ( .A0(n1971), .A1(n2497), .B0(n1973), .B1(n2427), .C0(n2144), 
        .Y(n2123) );
  OAI221X1 U1963 ( .A0(n1962), .A1(n2364), .B0(n1964), .B1(n2486), .C0(n2139), 
        .Y(n2124) );
  OAI221X1 U1964 ( .A0(n1953), .A1(n2418), .B0(n1955), .B1(n2482), .C0(n2134), 
        .Y(n2125) );
  OR4X1 U1965 ( .A(n2147), .B(n2148), .C(n2149), .D(n2150), .Y(RdData[1]) );
  OAI221X1 U1966 ( .A0(n1971), .A1(n2498), .B0(n1973), .B1(n2428), .C0(n2168), 
        .Y(n2147) );
  OAI221X1 U1967 ( .A0(n1962), .A1(n2365), .B0(n1964), .B1(n2487), .C0(n2163), 
        .Y(n2148) );
  OAI221X1 U1968 ( .A0(n1953), .A1(n2419), .B0(n1955), .B1(n2483), .C0(n2158), 
        .Y(n2149) );
  OR4X1 U1969 ( .A(n1979), .B(n1980), .C(n1981), .D(n1982), .Y(RdData[8]) );
  OR4X1 U1970 ( .A(n1940), .B(n1941), .C(n1942), .D(n1943), .Y(RdData[9]) );
  OAI221X1 U1971 ( .A0(n1971), .A1(n2457), .B0(n1973), .B1(n2383), .C0(n2000), 
        .Y(n1979) );
  OAI221X1 U1972 ( .A0(n1962), .A1(n2352), .B0(n1964), .B1(n2485), .C0(n1966), 
        .Y(n1941) );
  OA22X1 U1973 ( .A0(n1967), .A1(n2458), .B0(n1969), .B1(n2391), .Y(n1966) );
  OAI221X1 U1974 ( .A0(n1962), .A1(n2477), .B0(n1964), .B1(n2421), .C0(n2067), 
        .Y(n2052) );
  OA22X1 U1975 ( .A0(n1967), .A1(n2358), .B0(n1969), .B1(n2503), .Y(n2067) );
  OAI221X1 U1976 ( .A0(n1944), .A1(n2354), .B0(n1946), .B1(n2386), .C0(n1948), 
        .Y(n1943) );
  OA22X1 U1977 ( .A0(n1949), .A1(n2466), .B0(n1951), .B1(n2390), .Y(n1948) );
  OAI221X1 U1978 ( .A0(n1944), .A1(n2367), .B0(n1946), .B1(n2432), .C0(n2057), 
        .Y(n2054) );
  OA22X1 U1979 ( .A0(n1949), .A1(n2468), .B0(n1951), .B1(n2393), .Y(n2057) );
  OAI221X1 U1980 ( .A0(n1944), .A1(n2490), .B0(n1946), .B1(n2435), .C0(n2153), 
        .Y(n2150) );
  OA22X1 U1981 ( .A0(n1949), .A1(n2471), .B0(n1951), .B1(n2397), .Y(n2153) );
  OAI221X1 U1982 ( .A0(n1944), .A1(n2489), .B0(n1946), .B1(n2434), .C0(n2129), 
        .Y(n2126) );
  OA22X1 U1983 ( .A0(n1949), .A1(n2470), .B0(n1951), .B1(n2395), .Y(n2129) );
  OAI221X1 U1984 ( .A0(n1944), .A1(n2356), .B0(n1946), .B1(n2388), .C0(n2105), 
        .Y(n2102) );
  OA22X1 U1985 ( .A0(n1949), .A1(n2469), .B0(n1951), .B1(n2394), .Y(n2105) );
  OAI221X1 U1986 ( .A0(n1953), .A1(n2378), .B0(n1955), .B1(n2453), .C0(n1990), 
        .Y(n1981) );
  OA22X1 U1987 ( .A0(n1958), .A1(n2464), .B0(n1960), .B1(n2403), .Y(n1990) );
  OAI221X1 U1988 ( .A0(n1971), .A1(n2492), .B0(n1973), .B1(n2423), .C0(n1975), 
        .Y(n1940) );
  OA22X1 U1989 ( .A0(n1926), .A1(n2473), .B0(n1977), .B1(n2402), .Y(n1975) );
  OA22X1 U1990 ( .A0(n1926), .A1(n2474), .B0(n1977), .B1(n2404), .Y(n2000) );
  OAI221X1 U1991 ( .A0(n1953), .A1(n2377), .B0(n1955), .B1(n2452), .C0(n1957), 
        .Y(n1942) );
  OA22X1 U1992 ( .A0(n1958), .A1(n2463), .B0(n1960), .B1(n2401), .Y(n1957) );
  OAI221X1 U1993 ( .A0(n1944), .A1(n2355), .B0(n1946), .B1(n2387), .C0(n1985), 
        .Y(n1982) );
  OA22X1 U1994 ( .A0(n1949), .A1(n2467), .B0(n1951), .B1(n2392), .Y(n1985) );
  OAI221X1 U1995 ( .A0(n1962), .A1(n2450), .B0(n1964), .B1(n2381), .C0(n1995), 
        .Y(n1980) );
  OA22X1 U1996 ( .A0(n1967), .A1(n2357), .B0(n1969), .B1(n2461), .Y(n1995) );
  OA22X1 U1997 ( .A0(n1958), .A1(n2412), .B0(n1960), .B1(n2362), .Y(n2158) );
  OA22X1 U1998 ( .A0(n1967), .A1(n2459), .B0(n1969), .B1(n2398), .Y(n2163) );
  OA22X1 U1999 ( .A0(n1926), .A1(n2515), .B0(n1977), .B1(n2409), .Y(n2168) );
  OA22X1 U2000 ( .A0(n1958), .A1(n2411), .B0(n1960), .B1(n2361), .Y(n2134) );
  OA22X1 U2001 ( .A0(n1967), .A1(n2501), .B0(n1969), .B1(n2396), .Y(n2139) );
  OA22X1 U2002 ( .A0(n1926), .A1(n2514), .B0(n1977), .B1(n2444), .Y(n2144) );
  OAI221X1 U2003 ( .A0(n1953), .A1(n2416), .B0(n1955), .B1(n2480), .C0(n2062), 
        .Y(n2053) );
  OA22X1 U2004 ( .A0(n1958), .A1(n2506), .B0(n1960), .B1(n2405), .Y(n2062) );
  OA22X1 U2005 ( .A0(n1958), .A1(n2465), .B0(n1960), .B1(n2407), .Y(n2110) );
  OA22X1 U2006 ( .A0(n1967), .A1(n2359), .B0(n1969), .B1(n2462), .Y(n2115) );
  OA22X1 U2007 ( .A0(n1926), .A1(n2475), .B0(n1977), .B1(n2408), .Y(n2120) );
  OA22X1 U2008 ( .A0(n1958), .A1(n2413), .B0(n1960), .B1(n2363), .Y(n2184) );
  OA22X1 U2009 ( .A0(n1967), .A1(n2460), .B0(n1969), .B1(n2400), .Y(n2192) );
  OA22X1 U2010 ( .A0(n1926), .A1(n2516), .B0(n1977), .B1(n2410), .Y(n2199) );
  OAI221X1 U2011 ( .A0(n1944), .A1(n2491), .B0(n1946), .B1(n2389), .C0(n2177), 
        .Y(n2174) );
  OA22X1 U2012 ( .A0(n1949), .A1(n2472), .B0(n1951), .B1(n2399), .Y(n2177) );
  INVX1 U2013 ( .A(n2188), .Y(n1928) );
  INVX1 U2014 ( .A(n1927), .Y(n2180) );
  INVX1 U2015 ( .A(n2196), .Y(n2195) );
  OR4X1 U2016 ( .A(n2027), .B(n2028), .C(n2029), .D(n2030), .Y(RdData[6]) );
  OAI221X1 U2017 ( .A0(n1971), .A1(n2493), .B0(n1973), .B1(n2424), .C0(n2048), 
        .Y(n2027) );
  OAI221X1 U2018 ( .A0(n1962), .A1(n2476), .B0(n1964), .B1(n2420), .C0(n2043), 
        .Y(n2028) );
  OA22X1 U2019 ( .A0(n1967), .A1(n2369), .B0(n1969), .B1(n2502), .Y(n2043) );
  OAI221X1 U2020 ( .A0(n1944), .A1(n2366), .B0(n1946), .B1(n2431), .C0(n2033), 
        .Y(n2030) );
  OA22X1 U2021 ( .A0(n1949), .A1(n2509), .B0(n1951), .B1(n2438), .Y(n2033) );
  OAI221X1 U2022 ( .A0(n1944), .A1(n2368), .B0(n1946), .B1(n2433), .C0(n2081), 
        .Y(n2078) );
  OA22X1 U2023 ( .A0(n1949), .A1(n2510), .B0(n1951), .B1(n2360), .Y(n2081) );
  OAI221X1 U2024 ( .A0(n1953), .A1(n2415), .B0(n1955), .B1(n2479), .C0(n2038), 
        .Y(n2029) );
  OA22X1 U2025 ( .A0(n1958), .A1(n2505), .B0(n1960), .B1(n2440), .Y(n2038) );
  OAI221X1 U2026 ( .A0(n1953), .A1(n2417), .B0(n1955), .B1(n2481), .C0(n2086), 
        .Y(n2077) );
  OA22X1 U2027 ( .A0(n1958), .A1(n2507), .B0(n1960), .B1(n2406), .Y(n2086) );
  OA22X1 U2028 ( .A0(n1926), .A1(n2512), .B0(n1977), .B1(n2442), .Y(n2072) );
  OA22X1 U2029 ( .A0(n1926), .A1(n2511), .B0(n1977), .B1(n2441), .Y(n2048) );
  OA22X1 U2030 ( .A0(n1967), .A1(n2429), .B0(n1969), .B1(n2504), .Y(n2091) );
  OA22X1 U2031 ( .A0(n1926), .A1(n2513), .B0(n1977), .B1(n2443), .Y(n2096) );
  OR2X1 U2032 ( .A(n1920), .B(n2202), .Y(n1971) );
  OAI221X1 U2033 ( .A0(n1962), .A1(n2371), .B0(n1964), .B1(n2518), .C0(n2019), 
        .Y(n2004) );
  OA22X1 U2034 ( .A0(n1967), .A1(n2500), .B0(n1969), .B1(n2437), .Y(n2019) );
  OAI221X1 U2035 ( .A0(n1944), .A1(n2521), .B0(n1946), .B1(n2430), .C0(n2009), 
        .Y(n2006) );
  OA22X1 U2036 ( .A0(n1949), .A1(n2508), .B0(n1951), .B1(n2436), .Y(n2009) );
  OAI221X1 U2037 ( .A0(n1953), .A1(n2414), .B0(n1955), .B1(n2517), .C0(n2014), 
        .Y(n2005) );
  OA22X1 U2038 ( .A0(n1958), .A1(n2445), .B0(n1960), .B1(n2370), .Y(n2014) );
  OAI221X1 U2039 ( .A0(n1971), .A1(n2522), .B0(n1973), .B1(n2446), .C0(n2024), 
        .Y(n2003) );
  OA22X1 U2040 ( .A0(n1926), .A1(n2523), .B0(n1977), .B1(n2439), .Y(n2024) );
  OAI221X1 U2041 ( .A0(n1924), .A1(n2533), .B0(n1917), .B1(n1926), .C0(n1927), 
        .Y(n1772) );
  INVX1 U2042 ( .A(n1923), .Y(n1924) );
  OAI221X1 U2043 ( .A0(ReadEn), .A1(n2455), .B0(n1917), .B1(n1920), .C0(n1921), 
        .Y(n1774) );
  NAND2BX1 U2044 ( .AN(n2338), .B(n1939), .Y(n2559) );
  NAND2BX1 U2045 ( .AN(n1931), .B(n2344), .Y(n2551) );
  NAND2BX1 U2046 ( .AN(n1938), .B(n1939), .Y(n2545) );
  NAND2BX1 U2047 ( .AN(n1931), .B(n2534), .Y(n2567) );
  NAND2BX1 U2048 ( .AN(n1931), .B(n2336), .Y(n2565) );
  NAND2BX1 U2049 ( .AN(n2338), .B(n2345), .Y(n2549) );
  NAND2BX1 U2050 ( .AN(n1938), .B(n2339), .Y(n2557) );
  NAND2BX1 U2051 ( .AN(n2341), .B(n2534), .Y(n2543) );
  NAND2BX1 U2052 ( .AN(n2338), .B(n1939), .Y(n1937) );
  NAND2BX1 U2053 ( .AN(n1931), .B(n2344), .Y(n2550) );
  NAND2BX1 U2054 ( .AN(n1931), .B(n2534), .Y(n2566) );
  NAND2BX1 U2055 ( .AN(n1938), .B(n1939), .Y(n2544) );
  NAND2BX1 U2056 ( .AN(n1931), .B(n2336), .Y(n2564) );
  NAND2BX1 U2057 ( .AN(n1938), .B(n2339), .Y(n2556) );
  NAND2BX1 U2058 ( .AN(n2338), .B(n2345), .Y(n2548) );
  NAND2BX1 U2059 ( .AN(n2341), .B(n2534), .Y(n2542) );
  XOR2X1 U2060 ( .A(n2456), .B(n1923), .Y(n1773) );
  NAND2BX1 U2061 ( .AN(n2338), .B(n2339), .Y(n2560) );
  NAND2BX1 U2062 ( .AN(n2338), .B(n2339), .Y(n2561) );
  NAND2BX1 U2063 ( .AN(n1938), .B(n2345), .Y(n2538) );
  NAND2BX1 U2064 ( .AN(n1938), .B(n2345), .Y(n2539) );
  NAND2BX1 U2065 ( .AN(n1932), .B(n2337), .Y(n2546) );
  NAND2BX1 U2066 ( .AN(n1932), .B(n2337), .Y(n2547) );
  NAND2BX1 U2067 ( .AN(n2342), .B(n2534), .Y(n2552) );
  NAND2BX1 U2068 ( .AN(n2342), .B(n2534), .Y(n2553) );
  NAND2BX1 U2069 ( .AN(n1931), .B(n2337), .Y(n2562) );
  NAND2BX1 U2070 ( .AN(n2341), .B(n2337), .Y(n2536) );
  NAND2BX1 U2071 ( .AN(n2341), .B(n2337), .Y(n2537) );
  NAND2BX1 U2072 ( .AN(n1931), .B(n2337), .Y(n2563) );
  NAND2BX1 U2073 ( .AN(n1932), .B(n2534), .Y(n2554) );
  NAND2BX1 U2074 ( .AN(n1932), .B(n2534), .Y(n2555) );
  NAND2BX1 U2075 ( .AN(n2348), .B(n1939), .Y(n2540) );
  NAND2BX1 U2076 ( .AN(n2348), .B(n1939), .Y(n2541) );
  INVX1 U2077 ( .A(n2342), .Y(n1939) );
  INVX1 U2078 ( .A(n2348), .Y(n2337) );
  INVX1 U2079 ( .A(n1932), .Y(n2345) );
  INVX1 U2080 ( .A(n2341), .Y(n2339) );
  INVX1 U2081 ( .A(n1938), .Y(n2336) );
  INVX1 U2082 ( .A(n2338), .Y(n2344) );
  OAI221X1 U2083 ( .A0(n2423), .A1(n2561), .B0(n2352), .B1(n2563), .C0(n2253), 
        .Y(n2252) );
  OA22X1 U2084 ( .A0(n2354), .A1(n2564), .B0(n2463), .B1(n2566), .Y(n2253) );
  OAI221X1 U2085 ( .A0(n2383), .A1(n2561), .B0(n2450), .B1(n2563), .C0(n2262), 
        .Y(n2261) );
  OA22X1 U2086 ( .A0(n2355), .A1(n2565), .B0(n2464), .B1(n2567), .Y(n2262) );
  OAI221X1 U2087 ( .A0(n2446), .A1(n2560), .B0(n2371), .B1(n2562), .C0(n2271), 
        .Y(n2270) );
  OA22X1 U2088 ( .A0(n2521), .A1(n2564), .B0(n2445), .B1(n2566), .Y(n2271) );
  OAI221X1 U2089 ( .A0(n2424), .A1(n2560), .B0(n2476), .B1(n2562), .C0(n2280), 
        .Y(n2279) );
  OA22X1 U2090 ( .A0(n2366), .A1(n2564), .B0(n2505), .B1(n2566), .Y(n2280) );
  OAI221X1 U2091 ( .A0(n2425), .A1(n2561), .B0(n2477), .B1(n2563), .C0(n2289), 
        .Y(n2288) );
  OA22X1 U2092 ( .A0(n2367), .A1(n2565), .B0(n2506), .B1(n2567), .Y(n2289) );
  OAI221X1 U2093 ( .A0(n2426), .A1(n2560), .B0(n2478), .B1(n2562), .C0(n2298), 
        .Y(n2297) );
  OA22X1 U2094 ( .A0(n2368), .A1(n2565), .B0(n2507), .B1(n2567), .Y(n2298) );
  OAI221X1 U2095 ( .A0(n2384), .A1(n2560), .B0(n2451), .B1(n2562), .C0(n2307), 
        .Y(n2306) );
  OA22X1 U2096 ( .A0(n2356), .A1(n2564), .B0(n2465), .B1(n2566), .Y(n2307) );
  OAI221X1 U2097 ( .A0(n2427), .A1(n2561), .B0(n2364), .B1(n2563), .C0(n2316), 
        .Y(n2315) );
  OA22X1 U2098 ( .A0(n2489), .A1(n2565), .B0(n2411), .B1(n2567), .Y(n2316) );
  OAI221X1 U2099 ( .A0(n2428), .A1(n2561), .B0(n2365), .B1(n2563), .C0(n2325), 
        .Y(n2324) );
  OA22X1 U2100 ( .A0(n2490), .A1(n2564), .B0(n2412), .B1(n2566), .Y(n2325) );
  OAI221X1 U2101 ( .A0(n2385), .A1(n2560), .B0(n2353), .B1(n2562), .C0(n2334), 
        .Y(n2333) );
  OA22X1 U2102 ( .A0(n2491), .A1(n2564), .B0(n2413), .B1(n2566), .Y(n2334) );
  OAI221X1 U2103 ( .A0(n2377), .A1(n2553), .B0(n2452), .B1(n2555), .C0(n2254), 
        .Y(n2251) );
  OA22X1 U2104 ( .A0(n2386), .A1(n2556), .B0(n2559), .B1(n2473), .Y(n2254) );
  OAI221X1 U2105 ( .A0(n2378), .A1(n2553), .B0(n2453), .B1(n2555), .C0(n2263), 
        .Y(n2260) );
  OA22X1 U2106 ( .A0(n2387), .A1(n2557), .B0(n1937), .B1(n2474), .Y(n2263) );
  OAI221X1 U2107 ( .A0(n2414), .A1(n2552), .B0(n2517), .B1(n2554), .C0(n2272), 
        .Y(n2269) );
  OA22X1 U2108 ( .A0(n2430), .A1(n2556), .B0(n1937), .B1(n2523), .Y(n2272) );
  OAI221X1 U2109 ( .A0(n2415), .A1(n2552), .B0(n2479), .B1(n2554), .C0(n2281), 
        .Y(n2278) );
  OA22X1 U2110 ( .A0(n2431), .A1(n2556), .B0(n2559), .B1(n2511), .Y(n2281) );
  OAI221X1 U2111 ( .A0(n2416), .A1(n2553), .B0(n2480), .B1(n2555), .C0(n2290), 
        .Y(n2287) );
  OA22X1 U2112 ( .A0(n2432), .A1(n2557), .B0(n1937), .B1(n2512), .Y(n2290) );
  OAI221X1 U2113 ( .A0(n2417), .A1(n2552), .B0(n2481), .B1(n2554), .C0(n2299), 
        .Y(n2296) );
  OA22X1 U2114 ( .A0(n2433), .A1(n2557), .B0(n2559), .B1(n2513), .Y(n2299) );
  OAI221X1 U2115 ( .A0(n2379), .A1(n2552), .B0(n2454), .B1(n2554), .C0(n2308), 
        .Y(n2305) );
  OA22X1 U2116 ( .A0(n2388), .A1(n2556), .B0(n2559), .B1(n2475), .Y(n2308) );
  OAI221X1 U2117 ( .A0(n2418), .A1(n2553), .B0(n2482), .B1(n2555), .C0(n2317), 
        .Y(n2314) );
  OA22X1 U2118 ( .A0(n2434), .A1(n2557), .B0(n1937), .B1(n2514), .Y(n2317) );
  OAI221X1 U2119 ( .A0(n2419), .A1(n2553), .B0(n2483), .B1(n2555), .C0(n2326), 
        .Y(n2323) );
  OA22X1 U2120 ( .A0(n2435), .A1(n2556), .B0(n1937), .B1(n2515), .Y(n2326) );
  OAI221X1 U2121 ( .A0(n2380), .A1(n2552), .B0(n2484), .B1(n2554), .C0(n2340), 
        .Y(n2332) );
  OA22X1 U2122 ( .A0(n2389), .A1(n2556), .B0(n2559), .B1(n2516), .Y(n2340) );
  OA22X1 U2123 ( .A0(n2401), .A1(n2542), .B0(n2466), .B1(n2544), .Y(n2256) );
  OA22X1 U2124 ( .A0(n2402), .A1(n2548), .B0(n2492), .B1(n2550), .Y(n2255) );
  OA22X1 U2125 ( .A0(n2403), .A1(n2543), .B0(n2467), .B1(n2545), .Y(n2265) );
  OA22X1 U2126 ( .A0(n2404), .A1(n2549), .B0(n2457), .B1(n2551), .Y(n2264) );
  OA22X1 U2127 ( .A0(n2370), .A1(n2542), .B0(n2508), .B1(n2544), .Y(n2274) );
  OA22X1 U2128 ( .A0(n2439), .A1(n2548), .B0(n2522), .B1(n2550), .Y(n2273) );
  OA22X1 U2129 ( .A0(n2440), .A1(n2542), .B0(n2509), .B1(n2544), .Y(n2283) );
  OA22X1 U2130 ( .A0(n2441), .A1(n2548), .B0(n2493), .B1(n2550), .Y(n2282) );
  OA22X1 U2131 ( .A0(n2405), .A1(n2543), .B0(n2468), .B1(n2545), .Y(n2292) );
  OA22X1 U2132 ( .A0(n2442), .A1(n2549), .B0(n2494), .B1(n2551), .Y(n2291) );
  OA22X1 U2133 ( .A0(n2406), .A1(n2543), .B0(n2510), .B1(n2545), .Y(n2301) );
  OA22X1 U2134 ( .A0(n2443), .A1(n2549), .B0(n2495), .B1(n2551), .Y(n2300) );
  OA22X1 U2135 ( .A0(n2407), .A1(n2542), .B0(n2469), .B1(n2544), .Y(n2310) );
  OA22X1 U2136 ( .A0(n2408), .A1(n2548), .B0(n2496), .B1(n2550), .Y(n2309) );
  OA22X1 U2137 ( .A0(n2361), .A1(n2543), .B0(n2470), .B1(n2545), .Y(n2319) );
  OA22X1 U2138 ( .A0(n2444), .A1(n2549), .B0(n2497), .B1(n2551), .Y(n2318) );
  OA22X1 U2139 ( .A0(n2362), .A1(n2542), .B0(n2471), .B1(n2544), .Y(n2328) );
  OA22X1 U2140 ( .A0(n2409), .A1(n2548), .B0(n2498), .B1(n2550), .Y(n2327) );
  OA22X1 U2141 ( .A0(n2363), .A1(n2542), .B0(n2472), .B1(n2544), .Y(n2346) );
  OA22X1 U2142 ( .A0(n2410), .A1(n2548), .B0(n2499), .B1(n2550), .Y(n2343) );
  NAND2BX1 U2143 ( .AN(n1931), .B(n2344), .Y(n2224) );
  NAND2BX1 U2144 ( .AN(n1931), .B(n2336), .Y(n2207) );
  NAND2BX1 U2145 ( .AN(n2338), .B(n2345), .Y(n2222) );
  NAND2BX1 U2146 ( .AN(n1938), .B(n2339), .Y(n2219) );
  NAND2BX1 U2147 ( .AN(n2338), .B(n1939), .Y(n2558) );
  NAND2BX1 U2148 ( .AN(n1938), .B(n1939), .Y(n2242) );
  NAND2BX1 U2149 ( .AN(n2341), .B(n2534), .Y(n2240) );
  NAND2BX1 U2150 ( .AN(n1931), .B(n2534), .Y(n2238) );
  INVX1 U2151 ( .A(n2244), .Y(n2245) );
  NAND2BX1 U2152 ( .AN(n1938), .B(n2345), .Y(n2244) );
  INVX1 U2153 ( .A(n2226), .Y(n2227) );
  NAND2BX1 U2154 ( .AN(n2338), .B(n2339), .Y(n2226) );
  INVX1 U2155 ( .A(n2230), .Y(n2231) );
  NAND2BX1 U2156 ( .AN(n1932), .B(n2337), .Y(n2230) );
  INVX1 U2157 ( .A(n2236), .Y(n2237) );
  NAND2BX1 U2158 ( .AN(n1932), .B(n2534), .Y(n2236) );
  INVX1 U2159 ( .A(n2246), .Y(n2247) );
  NAND2BX1 U2160 ( .AN(n2341), .B(n2337), .Y(n2246) );
  INVX1 U2161 ( .A(n2232), .Y(n2233) );
  NAND2BX1 U2162 ( .AN(n1931), .B(n2337), .Y(n2232) );
  INVX1 U2163 ( .A(n2228), .Y(n2229) );
  NAND2BX1 U2164 ( .AN(n2348), .B(n1939), .Y(n2228) );
  INVX1 U2165 ( .A(n2234), .Y(n2235) );
  NAND2BX1 U2166 ( .AN(n2342), .B(n2534), .Y(n2234) );
  AO22X1 U2167 ( .A0(WrData[9]), .A1(WriteEn), .B0(n2248), .B1(n1930), .Y(
        n2209) );
  OR4X1 U2168 ( .A(n2249), .B(n2250), .C(n2251), .D(n2252), .Y(n2248) );
  OAI221X1 U2169 ( .A0(n2391), .A1(n2547), .B0(n2485), .B1(n2537), .C0(n2255), 
        .Y(n2250) );
  OAI221X1 U2170 ( .A0(n2390), .A1(n2539), .B0(n2458), .B1(n2541), .C0(n2256), 
        .Y(n2249) );
  AO22X1 U2171 ( .A0(WrData[8]), .A1(WriteEn), .B0(n2257), .B1(n1930), .Y(
        n2210) );
  OR4X1 U2172 ( .A(n2258), .B(n2259), .C(n2260), .D(n2261), .Y(n2257) );
  OAI221X1 U2173 ( .A0(n2461), .A1(n2547), .B0(n2381), .B1(n2537), .C0(n2264), 
        .Y(n2259) );
  OAI221X1 U2174 ( .A0(n2392), .A1(n2539), .B0(n2357), .B1(n2541), .C0(n2265), 
        .Y(n2258) );
  AO22X1 U2175 ( .A0(WrData[7]), .A1(WriteEn), .B0(n2266), .B1(n1930), .Y(
        n2211) );
  OR4X1 U2176 ( .A(n2267), .B(n2268), .C(n2269), .D(n2270), .Y(n2266) );
  OAI221X1 U2177 ( .A0(n2437), .A1(n2546), .B0(n2518), .B1(n2536), .C0(n2273), 
        .Y(n2268) );
  OAI221X1 U2178 ( .A0(n2436), .A1(n2538), .B0(n2500), .B1(n2540), .C0(n2274), 
        .Y(n2267) );
  AO22X1 U2179 ( .A0(WrData[6]), .A1(WriteEn), .B0(n2275), .B1(n1930), .Y(
        n2212) );
  OR4X1 U2180 ( .A(n2276), .B(n2277), .C(n2278), .D(n2279), .Y(n2275) );
  OAI221X1 U2181 ( .A0(n2502), .A1(n2546), .B0(n2420), .B1(n2536), .C0(n2282), 
        .Y(n2277) );
  OAI221X1 U2182 ( .A0(n2438), .A1(n2538), .B0(n2369), .B1(n2540), .C0(n2283), 
        .Y(n2276) );
  AO22X1 U2183 ( .A0(WrData[5]), .A1(WriteEn), .B0(n2284), .B1(n1930), .Y(
        n2213) );
  OR4X1 U2184 ( .A(n2285), .B(n2286), .C(n2287), .D(n2288), .Y(n2284) );
  OAI221X1 U2185 ( .A0(n2503), .A1(n2547), .B0(n2421), .B1(n2537), .C0(n2291), 
        .Y(n2286) );
  OAI221X1 U2186 ( .A0(n2393), .A1(n2539), .B0(n2358), .B1(n2541), .C0(n2292), 
        .Y(n2285) );
  AO22X1 U2187 ( .A0(WrData[4]), .A1(WriteEn), .B0(n2293), .B1(n1930), .Y(
        n2214) );
  OR4X1 U2188 ( .A(n2294), .B(n2295), .C(n2296), .D(n2297), .Y(n2293) );
  OAI221X1 U2189 ( .A0(n2504), .A1(n2546), .B0(n2422), .B1(n2536), .C0(n2300), 
        .Y(n2295) );
  OAI221X1 U2190 ( .A0(n2360), .A1(n2538), .B0(n2429), .B1(n2540), .C0(n2301), 
        .Y(n2294) );
  AO22X1 U2191 ( .A0(WrData[3]), .A1(WriteEn), .B0(n2302), .B1(n1930), .Y(
        n2215) );
  OR4X1 U2192 ( .A(n2303), .B(n2304), .C(n2305), .D(n2306), .Y(n2302) );
  OAI221X1 U2193 ( .A0(n2462), .A1(n2546), .B0(n2382), .B1(n2536), .C0(n2309), 
        .Y(n2304) );
  OAI221X1 U2194 ( .A0(n2394), .A1(n2538), .B0(n2359), .B1(n2540), .C0(n2310), 
        .Y(n2303) );
  AO22X1 U2195 ( .A0(WrData[2]), .A1(WriteEn), .B0(n2311), .B1(n1930), .Y(
        n2216) );
  OR4X1 U2196 ( .A(n2312), .B(n2313), .C(n2314), .D(n2315), .Y(n2311) );
  OAI221X1 U2197 ( .A0(n2396), .A1(n2547), .B0(n2486), .B1(n2537), .C0(n2318), 
        .Y(n2313) );
  OAI221X1 U2198 ( .A0(n2395), .A1(n2539), .B0(n2501), .B1(n2541), .C0(n2319), 
        .Y(n2312) );
  AO22X1 U2199 ( .A0(WrData[1]), .A1(WriteEn), .B0(n2320), .B1(n1930), .Y(
        n2217) );
  OR4X1 U2200 ( .A(n2321), .B(n2322), .C(n2323), .D(n2324), .Y(n2320) );
  OAI221X1 U2201 ( .A0(n2398), .A1(n2547), .B0(n2487), .B1(n2537), .C0(n2327), 
        .Y(n2322) );
  OAI221X1 U2202 ( .A0(n2397), .A1(n2539), .B0(n2459), .B1(n2541), .C0(n2328), 
        .Y(n2321) );
  AO22X1 U2203 ( .A0(WrData[0]), .A1(WriteEn), .B0(n2329), .B1(n1930), .Y(
        n2218) );
  OR4X1 U2204 ( .A(n2330), .B(n2331), .C(n2332), .D(n2333), .Y(n2329) );
  OAI221X1 U2205 ( .A0(n2400), .A1(n2546), .B0(n2488), .B1(n2536), .C0(n2343), 
        .Y(n2331) );
  OAI221X1 U2206 ( .A0(n2399), .A1(n2538), .B0(n2460), .B1(n2540), .C0(n2346), 
        .Y(n2330) );
  XOR2X1 U2207 ( .A(WriteEn), .B(WrCnt_0_), .Y(n1771) );
  OAI2BB2X1 U2208 ( .A0N(EmptyFlag), .A1N(n1895), .B0(n2530), .B1(n1897), .Y(
        n1792) );
  OAI222X1 U2209 ( .A0(n2350), .A1(n2376), .B0(n1897), .B1(n2529), .C0(n1902), 
        .C1(n2531), .Y(n1777) );
  OAI222X1 U2210 ( .A0(n2528), .A1(n2350), .B0(n1897), .B1(n2372), .C0(n2530), 
        .C1(n1902), .Y(n1791) );
  AO22X1 U2211 ( .A0(\FIFO[0][9] ), .A1(n2537), .B0(n2247), .B1(n2209), .Y(
        FIFO232) );
  AO22X1 U2212 ( .A0(\FIFO[0][8] ), .A1(n2536), .B0(n2247), .B1(n2210), .Y(
        FIFO2320) );
  AO22X1 U2213 ( .A0(\FIFO[0][7] ), .A1(n2536), .B0(n2247), .B1(n2211), .Y(
        FIFO2321) );
  AO22X1 U2214 ( .A0(\FIFO[0][6] ), .A1(n2537), .B0(n2247), .B1(n2212), .Y(
        FIFO2322) );
  AO22X1 U2215 ( .A0(\FIFO[0][5] ), .A1(n2537), .B0(n2247), .B1(n2213), .Y(
        FIFO2323) );
  AO22X1 U2216 ( .A0(\FIFO[0][4] ), .A1(n2536), .B0(n2247), .B1(n2214), .Y(
        FIFO2324) );
  AO22X1 U2217 ( .A0(\FIFO[0][3] ), .A1(n2537), .B0(n2247), .B1(n2215), .Y(
        FIFO2325) );
  AO22X1 U2218 ( .A0(\FIFO[0][2] ), .A1(n2536), .B0(n2247), .B1(n2216), .Y(
        FIFO2326) );
  AO22X1 U2219 ( .A0(\FIFO[0][1] ), .A1(n2536), .B0(n2247), .B1(n2217), .Y(
        FIFO2327) );
  AO22X1 U2220 ( .A0(\FIFO[0][0] ), .A1(n2537), .B0(n2247), .B1(n2218), .Y(
        FIFO2328) );
  AO22X1 U2221 ( .A0(\FIFO[1][9] ), .A1(n2563), .B0(n2233), .B1(n2209), .Y(
        FIFO2329) );
  AO22X1 U2222 ( .A0(\FIFO[1][8] ), .A1(n2562), .B0(n2233), .B1(n2210), .Y(
        FIFO23210) );
  AO22X1 U2223 ( .A0(\FIFO[1][7] ), .A1(n2562), .B0(n2233), .B1(n2211), .Y(
        FIFO23211) );
  AO22X1 U2224 ( .A0(\FIFO[1][6] ), .A1(n2563), .B0(n2233), .B1(n2212), .Y(
        FIFO23212) );
  AO22X1 U2225 ( .A0(\FIFO[1][5] ), .A1(n2563), .B0(n2233), .B1(n2213), .Y(
        FIFO23213) );
  AO22X1 U2226 ( .A0(\FIFO[1][4] ), .A1(n2562), .B0(n2233), .B1(n2214), .Y(
        FIFO23214) );
  AO22X1 U2227 ( .A0(\FIFO[1][3] ), .A1(n2563), .B0(n2233), .B1(n2215), .Y(
        FIFO23215) );
  AO22X1 U2228 ( .A0(\FIFO[1][2] ), .A1(n2562), .B0(n2233), .B1(n2216), .Y(
        FIFO23216) );
  AO22X1 U2229 ( .A0(\FIFO[1][1] ), .A1(n2562), .B0(n2233), .B1(n2217), .Y(
        FIFO23217) );
  AO22X1 U2230 ( .A0(\FIFO[1][0] ), .A1(n2563), .B0(n2233), .B1(n2218), .Y(
        FIFO23218) );
  AO22X1 U2231 ( .A0(\FIFO[2][9] ), .A1(n2547), .B0(n2231), .B1(n2209), .Y(
        FIFO23219) );
  AO22X1 U2232 ( .A0(\FIFO[2][8] ), .A1(n2546), .B0(n2231), .B1(n2210), .Y(
        FIFO23220) );
  AO22X1 U2233 ( .A0(\FIFO[2][7] ), .A1(n2546), .B0(n2231), .B1(n2211), .Y(
        FIFO23221) );
  AO22X1 U2234 ( .A0(\FIFO[2][6] ), .A1(n2547), .B0(n2231), .B1(n2212), .Y(
        FIFO23222) );
  AO22X1 U2235 ( .A0(\FIFO[2][5] ), .A1(n2547), .B0(n2231), .B1(n2213), .Y(
        FIFO23223) );
  AO22X1 U2236 ( .A0(\FIFO[2][4] ), .A1(n2546), .B0(n2231), .B1(n2214), .Y(
        FIFO23224) );
  AO22X1 U2237 ( .A0(\FIFO[2][3] ), .A1(n2547), .B0(n2231), .B1(n2215), .Y(
        FIFO23225) );
  AO22X1 U2238 ( .A0(\FIFO[2][2] ), .A1(n2546), .B0(n2231), .B1(n2216), .Y(
        FIFO23226) );
  AO22X1 U2239 ( .A0(\FIFO[2][1] ), .A1(n2546), .B0(n2231), .B1(n2217), .Y(
        FIFO23227) );
  AO22X1 U2240 ( .A0(\FIFO[2][0] ), .A1(n2547), .B0(n2231), .B1(n2218), .Y(
        FIFO23228) );
  AO22X1 U2241 ( .A0(\FIFO[3][9] ), .A1(n2541), .B0(n2229), .B1(n2209), .Y(
        FIFO23229) );
  AO22X1 U2242 ( .A0(\FIFO[3][8] ), .A1(n2540), .B0(n2229), .B1(n2210), .Y(
        FIFO23230) );
  AO22X1 U2243 ( .A0(\FIFO[3][7] ), .A1(n2540), .B0(n2229), .B1(n2211), .Y(
        FIFO23231) );
  AO22X1 U2244 ( .A0(\FIFO[3][6] ), .A1(n2541), .B0(n2229), .B1(n2212), .Y(
        FIFO23232) );
  AO22X1 U2245 ( .A0(\FIFO[3][5] ), .A1(n2541), .B0(n2229), .B1(n2213), .Y(
        FIFO23233) );
  AO22X1 U2246 ( .A0(\FIFO[3][4] ), .A1(n2540), .B0(n2229), .B1(n2214), .Y(
        FIFO23234) );
  AO22X1 U2247 ( .A0(\FIFO[3][3] ), .A1(n2541), .B0(n2229), .B1(n2215), .Y(
        FIFO23235) );
  AO22X1 U2248 ( .A0(\FIFO[3][2] ), .A1(n2540), .B0(n2229), .B1(n2216), .Y(
        FIFO23236) );
  AO22X1 U2249 ( .A0(\FIFO[3][1] ), .A1(n2540), .B0(n2229), .B1(n2217), .Y(
        FIFO23237) );
  AO22X1 U2250 ( .A0(\FIFO[3][0] ), .A1(n2541), .B0(n2229), .B1(n2218), .Y(
        FIFO23238) );
  AO22X1 U2251 ( .A0(\FIFO[4][9] ), .A1(n2561), .B0(n2227), .B1(n2209), .Y(
        FIFO23239) );
  AO22X1 U2252 ( .A0(\FIFO[4][8] ), .A1(n2560), .B0(n2227), .B1(n2210), .Y(
        FIFO23240) );
  AO22X1 U2253 ( .A0(\FIFO[4][7] ), .A1(n2560), .B0(n2227), .B1(n2211), .Y(
        FIFO23241) );
  AO22X1 U2254 ( .A0(\FIFO[4][6] ), .A1(n2561), .B0(n2227), .B1(n2212), .Y(
        FIFO23242) );
  AO22X1 U2255 ( .A0(\FIFO[4][5] ), .A1(n2561), .B0(n2227), .B1(n2213), .Y(
        FIFO23243) );
  AO22X1 U2256 ( .A0(\FIFO[4][4] ), .A1(n2560), .B0(n2227), .B1(n2214), .Y(
        FIFO23244) );
  AO22X1 U2257 ( .A0(\FIFO[4][3] ), .A1(n2561), .B0(n2227), .B1(n2215), .Y(
        FIFO23245) );
  AO22X1 U2258 ( .A0(\FIFO[4][2] ), .A1(n2560), .B0(n2227), .B1(n2216), .Y(
        FIFO23246) );
  AO22X1 U2259 ( .A0(\FIFO[4][1] ), .A1(n2560), .B0(n2227), .B1(n2217), .Y(
        FIFO23247) );
  AO22X1 U2260 ( .A0(\FIFO[4][0] ), .A1(n2561), .B0(n2227), .B1(n2218), .Y(
        FIFO23248) );
  AO22X1 U2261 ( .A0(\FIFO[5][9] ), .A1(n2551), .B0(n2225), .B1(n2209), .Y(
        FIFO23249) );
  AO22X1 U2262 ( .A0(\FIFO[5][8] ), .A1(n2551), .B0(n2225), .B1(n2210), .Y(
        FIFO23250) );
  AO22X1 U2263 ( .A0(\FIFO[5][7] ), .A1(n2550), .B0(n2225), .B1(n2211), .Y(
        FIFO23251) );
  AO22X1 U2264 ( .A0(\FIFO[5][6] ), .A1(n2551), .B0(n2225), .B1(n2212), .Y(
        FIFO23252) );
  AO22X1 U2265 ( .A0(\FIFO[5][5] ), .A1(n2224), .B0(n2225), .B1(n2213), .Y(
        FIFO23253) );
  AO22X1 U2266 ( .A0(\FIFO[5][4] ), .A1(n2550), .B0(n2225), .B1(n2214), .Y(
        FIFO23254) );
  AO22X1 U2267 ( .A0(\FIFO[5][3] ), .A1(n2551), .B0(n2225), .B1(n2215), .Y(
        FIFO23255) );
  AO22X1 U2268 ( .A0(\FIFO[5][2] ), .A1(n2224), .B0(n2225), .B1(n2216), .Y(
        FIFO23256) );
  AO22X1 U2269 ( .A0(\FIFO[5][1] ), .A1(n2550), .B0(n2225), .B1(n2217), .Y(
        FIFO23257) );
  AO22X1 U2270 ( .A0(\FIFO[5][0] ), .A1(n2551), .B0(n2225), .B1(n2218), .Y(
        FIFO23258) );
  AO22X1 U2271 ( .A0(\FIFO[6][9] ), .A1(n2549), .B0(n2223), .B1(n2209), .Y(
        FIFO23259) );
  AO22X1 U2272 ( .A0(\FIFO[6][8] ), .A1(n2549), .B0(n2223), .B1(n2210), .Y(
        FIFO23260) );
  AO22X1 U2273 ( .A0(\FIFO[6][7] ), .A1(n2548), .B0(n2223), .B1(n2211), .Y(
        FIFO23261) );
  AO22X1 U2274 ( .A0(\FIFO[6][6] ), .A1(n2549), .B0(n2223), .B1(n2212), .Y(
        FIFO23262) );
  AO22X1 U2275 ( .A0(\FIFO[6][5] ), .A1(n2222), .B0(n2223), .B1(n2213), .Y(
        FIFO23263) );
  AO22X1 U2276 ( .A0(\FIFO[6][4] ), .A1(n2548), .B0(n2223), .B1(n2214), .Y(
        FIFO23264) );
  AO22X1 U2277 ( .A0(\FIFO[6][3] ), .A1(n2549), .B0(n2223), .B1(n2215), .Y(
        FIFO23265) );
  AO22X1 U2278 ( .A0(\FIFO[6][2] ), .A1(n2222), .B0(n2223), .B1(n2216), .Y(
        FIFO23266) );
  AO22X1 U2279 ( .A0(\FIFO[6][1] ), .A1(n2548), .B0(n2223), .B1(n2217), .Y(
        FIFO23267) );
  AO22X1 U2280 ( .A0(\FIFO[6][0] ), .A1(n2549), .B0(n2223), .B1(n2218), .Y(
        FIFO23268) );
  AO22X1 U2281 ( .A0(\FIFO[7][9] ), .A1(n1937), .B0(n2221), .B1(n2209), .Y(
        FIFO23269) );
  AO22X1 U2282 ( .A0(\FIFO[7][8] ), .A1(n2559), .B0(n2221), .B1(n2210), .Y(
        FIFO23270) );
  AO22X1 U2283 ( .A0(\FIFO[7][7] ), .A1(n2559), .B0(n2221), .B1(n2211), .Y(
        FIFO23271) );
  AO22X1 U2284 ( .A0(\FIFO[7][6] ), .A1(n1937), .B0(n2221), .B1(n2212), .Y(
        FIFO23272) );
  AO22X1 U2285 ( .A0(\FIFO[7][5] ), .A1(n2558), .B0(n2221), .B1(n2213), .Y(
        FIFO23273) );
  AO22X1 U2286 ( .A0(\FIFO[7][4] ), .A1(n2559), .B0(n2221), .B1(n2214), .Y(
        FIFO23274) );
  AO22X1 U2287 ( .A0(\FIFO[7][3] ), .A1(n1937), .B0(n2221), .B1(n2215), .Y(
        FIFO23275) );
  AO22X1 U2288 ( .A0(\FIFO[7][2] ), .A1(n2558), .B0(n2221), .B1(n2216), .Y(
        FIFO23276) );
  AO22X1 U2289 ( .A0(\FIFO[7][1] ), .A1(n2559), .B0(n2221), .B1(n2217), .Y(
        FIFO23277) );
  AO22X1 U2290 ( .A0(\FIFO[7][0] ), .A1(n1937), .B0(n2221), .B1(n2218), .Y(
        FIFO23278) );
  AO22X1 U2291 ( .A0(\FIFO[8][9] ), .A1(n2557), .B0(n2220), .B1(n2209), .Y(
        FIFO23279) );
  AO22X1 U2292 ( .A0(\FIFO[8][8] ), .A1(n2557), .B0(n2220), .B1(n2210), .Y(
        FIFO23280) );
  AO22X1 U2293 ( .A0(\FIFO[8][7] ), .A1(n2556), .B0(n2220), .B1(n2211), .Y(
        FIFO23281) );
  AO22X1 U2294 ( .A0(\FIFO[8][6] ), .A1(n2557), .B0(n2220), .B1(n2212), .Y(
        FIFO23282) );
  AO22X1 U2295 ( .A0(\FIFO[8][5] ), .A1(n2219), .B0(n2220), .B1(n2213), .Y(
        FIFO23283) );
  AO22X1 U2296 ( .A0(\FIFO[8][4] ), .A1(n2556), .B0(n2220), .B1(n2214), .Y(
        FIFO23284) );
  AO22X1 U2297 ( .A0(\FIFO[8][3] ), .A1(n2557), .B0(n2220), .B1(n2215), .Y(
        FIFO23285) );
  AO22X1 U2298 ( .A0(\FIFO[8][2] ), .A1(n2219), .B0(n2220), .B1(n2216), .Y(
        FIFO23286) );
  AO22X1 U2299 ( .A0(\FIFO[8][1] ), .A1(n2556), .B0(n2220), .B1(n2217), .Y(
        FIFO23287) );
  AO22X1 U2300 ( .A0(\FIFO[8][0] ), .A1(n2557), .B0(n2220), .B1(n2218), .Y(
        FIFO23288) );
  AO22X1 U2301 ( .A0(\FIFO[9][9] ), .A1(n2565), .B0(n2208), .B1(n2209), .Y(
        FIFO23289) );
  AO22X1 U2302 ( .A0(\FIFO[9][8] ), .A1(n2565), .B0(n2208), .B1(n2210), .Y(
        FIFO23290) );
  AO22X1 U2303 ( .A0(\FIFO[9][7] ), .A1(n2564), .B0(n2208), .B1(n2211), .Y(
        FIFO23291) );
  AO22X1 U2304 ( .A0(\FIFO[9][6] ), .A1(n2565), .B0(n2208), .B1(n2212), .Y(
        FIFO23292) );
  AO22X1 U2305 ( .A0(\FIFO[9][5] ), .A1(n2207), .B0(n2208), .B1(n2213), .Y(
        FIFO23293) );
  AO22X1 U2306 ( .A0(\FIFO[9][4] ), .A1(n2564), .B0(n2208), .B1(n2214), .Y(
        FIFO23294) );
  AO22X1 U2307 ( .A0(\FIFO[9][3] ), .A1(n2565), .B0(n2208), .B1(n2215), .Y(
        FIFO23295) );
  AO22X1 U2308 ( .A0(\FIFO[9][2] ), .A1(n2207), .B0(n2208), .B1(n2216), .Y(
        FIFO23296) );
  AO22X1 U2309 ( .A0(\FIFO[9][1] ), .A1(n2564), .B0(n2208), .B1(n2217), .Y(
        FIFO23297) );
  AO22X1 U2310 ( .A0(\FIFO[9][0] ), .A1(n2565), .B0(n2208), .B1(n2218), .Y(
        FIFO23298) );
  AO22X1 U2311 ( .A0(\FIFO[10][9] ), .A1(n2539), .B0(n2245), .B1(n2209), .Y(
        FIFO23299) );
  AO22X1 U2312 ( .A0(\FIFO[10][8] ), .A1(n2538), .B0(n2245), .B1(n2210), .Y(
        FIFO232100) );
  AO22X1 U2313 ( .A0(\FIFO[10][7] ), .A1(n2538), .B0(n2245), .B1(n2211), .Y(
        FIFO232101) );
  AO22X1 U2314 ( .A0(\FIFO[10][6] ), .A1(n2539), .B0(n2245), .B1(n2212), .Y(
        FIFO232102) );
  AO22X1 U2315 ( .A0(\FIFO[10][5] ), .A1(n2539), .B0(n2245), .B1(n2213), .Y(
        FIFO232103) );
  AO22X1 U2316 ( .A0(\FIFO[10][4] ), .A1(n2538), .B0(n2245), .B1(n2214), .Y(
        FIFO232104) );
  AO22X1 U2317 ( .A0(\FIFO[10][3] ), .A1(n2539), .B0(n2245), .B1(n2215), .Y(
        FIFO232105) );
  AO22X1 U2318 ( .A0(\FIFO[10][2] ), .A1(n2538), .B0(n2245), .B1(n2216), .Y(
        FIFO232106) );
  AO22X1 U2319 ( .A0(\FIFO[10][1] ), .A1(n2538), .B0(n2245), .B1(n2217), .Y(
        FIFO232107) );
  AO22X1 U2320 ( .A0(\FIFO[10][0] ), .A1(n2539), .B0(n2245), .B1(n2218), .Y(
        FIFO232108) );
  AO22X1 U2321 ( .A0(\FIFO[11][9] ), .A1(n2545), .B0(n2243), .B1(n2209), .Y(
        FIFO232109) );
  AO22X1 U2322 ( .A0(\FIFO[11][8] ), .A1(n2545), .B0(n2243), .B1(n2210), .Y(
        FIFO232110) );
  AO22X1 U2323 ( .A0(\FIFO[11][7] ), .A1(n2544), .B0(n2243), .B1(n2211), .Y(
        FIFO232111) );
  AO22X1 U2324 ( .A0(\FIFO[11][6] ), .A1(n2545), .B0(n2243), .B1(n2212), .Y(
        FIFO232112) );
  AO22X1 U2325 ( .A0(\FIFO[11][5] ), .A1(n2242), .B0(n2243), .B1(n2213), .Y(
        FIFO232113) );
  AO22X1 U2326 ( .A0(\FIFO[11][4] ), .A1(n2544), .B0(n2243), .B1(n2214), .Y(
        FIFO232114) );
  AO22X1 U2327 ( .A0(\FIFO[11][3] ), .A1(n2545), .B0(n2243), .B1(n2215), .Y(
        FIFO232115) );
  AO22X1 U2328 ( .A0(\FIFO[11][2] ), .A1(n2242), .B0(n2243), .B1(n2216), .Y(
        FIFO232116) );
  AO22X1 U2329 ( .A0(\FIFO[11][1] ), .A1(n2544), .B0(n2243), .B1(n2217), .Y(
        FIFO232117) );
  AO22X1 U2330 ( .A0(\FIFO[11][0] ), .A1(n2545), .B0(n2243), .B1(n2218), .Y(
        FIFO232118) );
  AO22X1 U2331 ( .A0(\FIFO[12][9] ), .A1(n2543), .B0(n2241), .B1(n2209), .Y(
        FIFO232119) );
  AO22X1 U2332 ( .A0(\FIFO[12][8] ), .A1(n2543), .B0(n2241), .B1(n2210), .Y(
        FIFO232120) );
  AO22X1 U2333 ( .A0(\FIFO[12][7] ), .A1(n2542), .B0(n2241), .B1(n2211), .Y(
        FIFO232121) );
  AO22X1 U2334 ( .A0(\FIFO[12][6] ), .A1(n2543), .B0(n2241), .B1(n2212), .Y(
        FIFO232122) );
  AO22X1 U2335 ( .A0(\FIFO[12][5] ), .A1(n2240), .B0(n2241), .B1(n2213), .Y(
        FIFO232123) );
  AO22X1 U2336 ( .A0(\FIFO[12][4] ), .A1(n2542), .B0(n2241), .B1(n2214), .Y(
        FIFO232124) );
  AO22X1 U2337 ( .A0(\FIFO[12][3] ), .A1(n2543), .B0(n2241), .B1(n2215), .Y(
        FIFO232125) );
  AO22X1 U2338 ( .A0(\FIFO[12][2] ), .A1(n2240), .B0(n2241), .B1(n2216), .Y(
        FIFO232126) );
  AO22X1 U2339 ( .A0(\FIFO[12][1] ), .A1(n2542), .B0(n2241), .B1(n2217), .Y(
        FIFO232127) );
  AO22X1 U2340 ( .A0(\FIFO[12][0] ), .A1(n2543), .B0(n2241), .B1(n2218), .Y(
        FIFO232128) );
  AO22X1 U2341 ( .A0(\FIFO[13][9] ), .A1(n2567), .B0(n2239), .B1(n2209), .Y(
        FIFO232129) );
  AO22X1 U2342 ( .A0(\FIFO[13][8] ), .A1(n2567), .B0(n2239), .B1(n2210), .Y(
        FIFO232130) );
  AO22X1 U2343 ( .A0(\FIFO[13][7] ), .A1(n2566), .B0(n2239), .B1(n2211), .Y(
        FIFO232131) );
  AO22X1 U2344 ( .A0(\FIFO[13][6] ), .A1(n2567), .B0(n2239), .B1(n2212), .Y(
        FIFO232132) );
  AO22X1 U2345 ( .A0(\FIFO[13][5] ), .A1(n2238), .B0(n2239), .B1(n2213), .Y(
        FIFO232133) );
  AO22X1 U2346 ( .A0(\FIFO[13][4] ), .A1(n2566), .B0(n2239), .B1(n2214), .Y(
        FIFO232134) );
  AO22X1 U2347 ( .A0(\FIFO[13][3] ), .A1(n2567), .B0(n2239), .B1(n2215), .Y(
        FIFO232135) );
  AO22X1 U2348 ( .A0(\FIFO[13][2] ), .A1(n2238), .B0(n2239), .B1(n2216), .Y(
        FIFO232136) );
  AO22X1 U2349 ( .A0(\FIFO[13][1] ), .A1(n2566), .B0(n2239), .B1(n2217), .Y(
        FIFO232137) );
  AO22X1 U2350 ( .A0(\FIFO[13][0] ), .A1(n2567), .B0(n2239), .B1(n2218), .Y(
        FIFO232138) );
  AO22X1 U2351 ( .A0(\FIFO[14][9] ), .A1(n2555), .B0(n2237), .B1(n2209), .Y(
        FIFO232139) );
  AO22X1 U2352 ( .A0(\FIFO[14][8] ), .A1(n2554), .B0(n2237), .B1(n2210), .Y(
        FIFO232140) );
  AO22X1 U2353 ( .A0(\FIFO[14][7] ), .A1(n2554), .B0(n2237), .B1(n2211), .Y(
        FIFO232141) );
  AO22X1 U2354 ( .A0(\FIFO[14][6] ), .A1(n2555), .B0(n2237), .B1(n2212), .Y(
        FIFO232142) );
  AO22X1 U2355 ( .A0(\FIFO[14][5] ), .A1(n2555), .B0(n2237), .B1(n2213), .Y(
        FIFO232143) );
  AO22X1 U2356 ( .A0(\FIFO[14][4] ), .A1(n2554), .B0(n2237), .B1(n2214), .Y(
        FIFO232144) );
  AO22X1 U2357 ( .A0(\FIFO[14][3] ), .A1(n2555), .B0(n2237), .B1(n2215), .Y(
        FIFO232145) );
  AO22X1 U2358 ( .A0(\FIFO[14][2] ), .A1(n2554), .B0(n2237), .B1(n2216), .Y(
        FIFO232146) );
  AO22X1 U2359 ( .A0(\FIFO[14][1] ), .A1(n2554), .B0(n2237), .B1(n2217), .Y(
        FIFO232147) );
  AO22X1 U2360 ( .A0(\FIFO[14][0] ), .A1(n2555), .B0(n2237), .B1(n2218), .Y(
        FIFO232148) );
  AO22X1 U2361 ( .A0(\FIFO[15][9] ), .A1(n2553), .B0(n2235), .B1(n2209), .Y(
        FIFO232149) );
  AO22X1 U2362 ( .A0(\FIFO[15][8] ), .A1(n2552), .B0(n2235), .B1(n2210), .Y(
        FIFO232150) );
  AO22X1 U2363 ( .A0(\FIFO[15][7] ), .A1(n2552), .B0(n2235), .B1(n2211), .Y(
        FIFO232151) );
  AO22X1 U2364 ( .A0(\FIFO[15][6] ), .A1(n2553), .B0(n2235), .B1(n2212), .Y(
        FIFO232152) );
  AO22X1 U2365 ( .A0(\FIFO[15][5] ), .A1(n2553), .B0(n2235), .B1(n2213), .Y(
        FIFO232153) );
  AO22X1 U2366 ( .A0(\FIFO[15][4] ), .A1(n2552), .B0(n2235), .B1(n2214), .Y(
        FIFO232154) );
  AO22X1 U2367 ( .A0(\FIFO[15][3] ), .A1(n2553), .B0(n2235), .B1(n2215), .Y(
        FIFO232155) );
  AO22X1 U2368 ( .A0(\FIFO[15][2] ), .A1(n2552), .B0(n2235), .B1(n2216), .Y(
        FIFO232156) );
  AO22X1 U2369 ( .A0(\FIFO[15][1] ), .A1(n2552), .B0(n2235), .B1(n2217), .Y(
        FIFO232157) );
  AO22X1 U2370 ( .A0(\FIFO[15][0] ), .A1(n2553), .B0(n2235), .B1(n2218), .Y(
        FIFO232158) );
  OAI2BB2X1 U2371 ( .A0N(FullFlag), .A1N(n1895), .B0(n2531), .B1(n2350), .Y(
        n1776) );
  NAND2BX1 U2372 ( .AN(RdCnt[0]), .B(RdCnt[1]), .Y(n1921) );
  NAND2BX1 U2373 ( .AN(RdCnt[0]), .B(n2455), .Y(n2181) );
  NAND2BX1 U2374 ( .AN(RdCnt[3]), .B(RdCnt[2]), .Y(n2202) );
  NAND2BX1 U2375 ( .AN(RdCnt[2]), .B(RdCnt[3]), .Y(n1927) );
  NAND2X1 U2376 ( .A(RdCnt[0]), .B(RdCnt[1]), .Y(n2188) );
  NAND2BX1 U2377 ( .AN(RdCnt[2]), .B(n2533), .Y(n2196) );
  NAND2BX1 U2378 ( .AN(RdCnt[1]), .B(RdCnt[0]), .Y(n1920) );
  NOR2X1 U2379 ( .A(n2456), .B(n2533), .Y(n2532) );
  NAND2BX1 U2380 ( .AN(WrCnt_2_), .B(WrCnt_3_), .Y(n1938) );
  NAND2BX1 U2381 ( .AN(WrCnt_3_), .B(WrCnt_2_), .Y(n2338) );
  NAND2BX1 U2382 ( .AN(WrCnt_0_), .B(WrCnt_1_), .Y(n1932) );
  NAND2BX1 U2383 ( .AN(WrCnt_0_), .B(n2519), .Y(n2341) );
  NAND2BX1 U2384 ( .AN(WrCnt_1_), .B(WrCnt_0_), .Y(n1931) );
  NAND2BX1 U2385 ( .AN(WrCnt_2_), .B(n2535), .Y(n2348) );
  NAND2X1 U2386 ( .A(WrCnt_0_), .B(WrCnt_1_), .Y(n2342) );
  XOR2X1 U2387 ( .A(ReadEn), .B(RdCnt[0]), .Y(n1775) );
  NOR2X1 U2388 ( .A(n2520), .B(n2535), .Y(n2534) );
  DFFRX1 RdCnt_reg_0_ ( .D(n1775), .CK(Clk), .RN(nRST), .Q(RdCnt[0]) );
  DFFRX1 RdCnt_reg_3_ ( .D(n1772), .CK(Clk), .RN(nRST), .Q(RdCnt[3]), .QN(
        n2533) );
  DFFRX1 RdCnt_reg_1_ ( .D(n1774), .CK(Clk), .RN(nRST), .Q(RdCnt[1]), .QN(
        n2455) );
  DFFRX1 RdCnt_reg_2_ ( .D(n1773), .CK(Clk), .RN(nRST), .Q(RdCnt[2]), .QN(
        n2456) );
  DFFRX1 DatCnt_reg_16_ ( .D(n1776), .CK(Clk), .RN(nRST), .Q(FullFlag), .QN(
        n2529) );
  DFFRX1 FIFO_reg ( .D(FIFO232), .CK(Clk), .RN(nRST), .Q(\FIFO[0][9] ), .QN(
        n2485) );
  DFFRX1 FIFO_reg0 ( .D(FIFO2320), .CK(Clk), .RN(nRST), .Q(\FIFO[0][8] ), .QN(
        n2381) );
  DFFRX1 FIFO_reg1 ( .D(FIFO2323), .CK(Clk), .RN(nRST), .Q(\FIFO[0][5] ), .QN(
        n2421) );
  DFFRX1 FIFO_reg2 ( .D(FIFO2324), .CK(Clk), .RN(nRST), .Q(\FIFO[0][4] ), .QN(
        n2422) );
  DFFRX1 FIFO_reg3 ( .D(FIFO2325), .CK(Clk), .RN(nRST), .Q(\FIFO[0][3] ), .QN(
        n2382) );
  DFFRX1 FIFO_reg4 ( .D(FIFO2326), .CK(Clk), .RN(nRST), .Q(\FIFO[0][2] ), .QN(
        n2486) );
  DFFRX1 FIFO_reg5 ( .D(FIFO2327), .CK(Clk), .RN(nRST), .Q(\FIFO[0][1] ), .QN(
        n2487) );
  DFFRX1 FIFO_reg6 ( .D(FIFO2328), .CK(Clk), .RN(nRST), .Q(\FIFO[0][0] ), .QN(
        n2488) );
  DFFRX1 FIFO_reg7 ( .D(FIFO2329), .CK(Clk), .RN(nRST), .Q(\FIFO[1][9] ), .QN(
        n2352) );
  DFFRX1 FIFO_reg8 ( .D(FIFO23210), .CK(Clk), .RN(nRST), .Q(\FIFO[1][8] ), 
        .QN(n2450) );
  DFFRX1 FIFO_reg9 ( .D(FIFO23213), .CK(Clk), .RN(nRST), .Q(\FIFO[1][5] ), 
        .QN(n2477) );
  DFFRX1 FIFO_reg10 ( .D(FIFO23214), .CK(Clk), .RN(nRST), .Q(\FIFO[1][4] ), 
        .QN(n2478) );
  DFFRX1 FIFO_reg11 ( .D(FIFO23215), .CK(Clk), .RN(nRST), .Q(\FIFO[1][3] ), 
        .QN(n2451) );
  DFFRX1 FIFO_reg12 ( .D(FIFO23216), .CK(Clk), .RN(nRST), .Q(\FIFO[1][2] ), 
        .QN(n2364) );
  DFFRX1 FIFO_reg13 ( .D(FIFO23217), .CK(Clk), .RN(nRST), .Q(\FIFO[1][1] ), 
        .QN(n2365) );
  DFFRX1 FIFO_reg14 ( .D(FIFO23218), .CK(Clk), .RN(nRST), .Q(\FIFO[1][0] ), 
        .QN(n2353) );
  DFFRX1 FIFO_reg15 ( .D(FIFO23219), .CK(Clk), .RN(nRST), .Q(\FIFO[2][9] ), 
        .QN(n2391) );
  DFFRX1 FIFO_reg16 ( .D(FIFO23220), .CK(Clk), .RN(nRST), .Q(\FIFO[2][8] ), 
        .QN(n2461) );
  DFFRX1 FIFO_reg17 ( .D(FIFO23223), .CK(Clk), .RN(nRST), .Q(\FIFO[2][5] ), 
        .QN(n2503) );
  DFFRX1 FIFO_reg18 ( .D(FIFO23224), .CK(Clk), .RN(nRST), .Q(\FIFO[2][4] ), 
        .QN(n2504) );
  DFFRX1 FIFO_reg19 ( .D(FIFO23225), .CK(Clk), .RN(nRST), .Q(\FIFO[2][3] ), 
        .QN(n2462) );
  DFFRX1 FIFO_reg20 ( .D(FIFO23226), .CK(Clk), .RN(nRST), .Q(\FIFO[2][2] ), 
        .QN(n2396) );
  DFFRX1 FIFO_reg21 ( .D(FIFO23227), .CK(Clk), .RN(nRST), .Q(\FIFO[2][1] ), 
        .QN(n2398) );
  DFFRX1 FIFO_reg22 ( .D(FIFO23228), .CK(Clk), .RN(nRST), .Q(\FIFO[2][0] ), 
        .QN(n2400) );
  DFFRX1 FIFO_reg23 ( .D(FIFO23229), .CK(Clk), .RN(nRST), .Q(\FIFO[3][9] ), 
        .QN(n2458) );
  DFFRX1 FIFO_reg24 ( .D(FIFO23230), .CK(Clk), .RN(nRST), .Q(\FIFO[3][8] ), 
        .QN(n2357) );
  DFFRX1 FIFO_reg25 ( .D(FIFO23233), .CK(Clk), .RN(nRST), .Q(\FIFO[3][5] ), 
        .QN(n2358) );
  DFFRX1 FIFO_reg26 ( .D(FIFO23234), .CK(Clk), .RN(nRST), .Q(\FIFO[3][4] ), 
        .QN(n2429) );
  DFFRX1 FIFO_reg27 ( .D(FIFO23235), .CK(Clk), .RN(nRST), .Q(\FIFO[3][3] ), 
        .QN(n2359) );
  DFFRX1 FIFO_reg28 ( .D(FIFO23236), .CK(Clk), .RN(nRST), .Q(\FIFO[3][2] ), 
        .QN(n2501) );
  DFFRX1 FIFO_reg29 ( .D(FIFO23237), .CK(Clk), .RN(nRST), .Q(\FIFO[3][1] ), 
        .QN(n2459) );
  DFFRX1 FIFO_reg30 ( .D(FIFO23238), .CK(Clk), .RN(nRST), .Q(\FIFO[3][0] ), 
        .QN(n2460) );
  DFFRX1 FIFO_reg31 ( .D(FIFO23239), .CK(Clk), .RN(nRST), .Q(\FIFO[4][9] ), 
        .QN(n2423) );
  DFFRX1 FIFO_reg32 ( .D(FIFO23240), .CK(Clk), .RN(nRST), .Q(\FIFO[4][8] ), 
        .QN(n2383) );
  DFFRX1 FIFO_reg33 ( .D(FIFO23243), .CK(Clk), .RN(nRST), .Q(\FIFO[4][5] ), 
        .QN(n2425) );
  DFFRX1 FIFO_reg34 ( .D(FIFO23244), .CK(Clk), .RN(nRST), .Q(\FIFO[4][4] ), 
        .QN(n2426) );
  DFFRX1 FIFO_reg35 ( .D(FIFO23245), .CK(Clk), .RN(nRST), .Q(\FIFO[4][3] ), 
        .QN(n2384) );
  DFFRX1 FIFO_reg36 ( .D(FIFO23246), .CK(Clk), .RN(nRST), .Q(\FIFO[4][2] ), 
        .QN(n2427) );
  DFFRX1 FIFO_reg37 ( .D(FIFO23247), .CK(Clk), .RN(nRST), .Q(\FIFO[4][1] ), 
        .QN(n2428) );
  DFFRX1 FIFO_reg38 ( .D(FIFO23248), .CK(Clk), .RN(nRST), .Q(\FIFO[4][0] ), 
        .QN(n2385) );
  DFFRX1 FIFO_reg39 ( .D(FIFO23249), .CK(Clk), .RN(nRST), .Q(\FIFO[5][9] ), 
        .QN(n2492) );
  DFFRX1 FIFO_reg40 ( .D(FIFO23250), .CK(Clk), .RN(nRST), .Q(\FIFO[5][8] ), 
        .QN(n2457) );
  DFFRX1 FIFO_reg41 ( .D(FIFO23253), .CK(Clk), .RN(nRST), .Q(\FIFO[5][5] ), 
        .QN(n2494) );
  DFFRX1 FIFO_reg42 ( .D(FIFO23254), .CK(Clk), .RN(nRST), .Q(\FIFO[5][4] ), 
        .QN(n2495) );
  DFFRX1 FIFO_reg43 ( .D(FIFO23255), .CK(Clk), .RN(nRST), .Q(\FIFO[5][3] ), 
        .QN(n2496) );
  DFFRX1 FIFO_reg44 ( .D(FIFO23256), .CK(Clk), .RN(nRST), .Q(\FIFO[5][2] ), 
        .QN(n2497) );
  DFFRX1 FIFO_reg45 ( .D(FIFO23257), .CK(Clk), .RN(nRST), .Q(\FIFO[5][1] ), 
        .QN(n2498) );
  DFFRX1 FIFO_reg46 ( .D(FIFO23258), .CK(Clk), .RN(nRST), .Q(\FIFO[5][0] ), 
        .QN(n2499) );
  DFFRX1 FIFO_reg47 ( .D(FIFO23259), .CK(Clk), .RN(nRST), .Q(\FIFO[6][9] ), 
        .QN(n2402) );
  DFFRX1 FIFO_reg48 ( .D(FIFO23260), .CK(Clk), .RN(nRST), .Q(\FIFO[6][8] ), 
        .QN(n2404) );
  DFFRX1 FIFO_reg49 ( .D(FIFO23263), .CK(Clk), .RN(nRST), .Q(\FIFO[6][5] ), 
        .QN(n2442) );
  DFFRX1 FIFO_reg50 ( .D(FIFO23264), .CK(Clk), .RN(nRST), .Q(\FIFO[6][4] ), 
        .QN(n2443) );
  DFFRX1 FIFO_reg51 ( .D(FIFO23265), .CK(Clk), .RN(nRST), .Q(\FIFO[6][3] ), 
        .QN(n2408) );
  DFFRX1 FIFO_reg52 ( .D(FIFO23266), .CK(Clk), .RN(nRST), .Q(\FIFO[6][2] ), 
        .QN(n2444) );
  DFFRX1 FIFO_reg53 ( .D(FIFO23267), .CK(Clk), .RN(nRST), .Q(\FIFO[6][1] ), 
        .QN(n2409) );
  DFFRX1 FIFO_reg54 ( .D(FIFO23268), .CK(Clk), .RN(nRST), .Q(\FIFO[6][0] ), 
        .QN(n2410) );
  DFFRX1 FIFO_reg55 ( .D(FIFO23269), .CK(Clk), .RN(nRST), .Q(\FIFO[7][9] ), 
        .QN(n2473) );
  DFFRX1 FIFO_reg56 ( .D(FIFO23270), .CK(Clk), .RN(nRST), .Q(\FIFO[7][8] ), 
        .QN(n2474) );
  DFFRX1 FIFO_reg57 ( .D(FIFO23273), .CK(Clk), .RN(nRST), .Q(\FIFO[7][5] ), 
        .QN(n2512) );
  DFFRX1 FIFO_reg58 ( .D(FIFO23274), .CK(Clk), .RN(nRST), .Q(\FIFO[7][4] ), 
        .QN(n2513) );
  DFFRX1 FIFO_reg59 ( .D(FIFO23275), .CK(Clk), .RN(nRST), .Q(\FIFO[7][3] ), 
        .QN(n2475) );
  DFFRX1 FIFO_reg60 ( .D(FIFO23276), .CK(Clk), .RN(nRST), .Q(\FIFO[7][2] ), 
        .QN(n2514) );
  DFFRX1 FIFO_reg61 ( .D(FIFO23277), .CK(Clk), .RN(nRST), .Q(\FIFO[7][1] ), 
        .QN(n2515) );
  DFFRX1 FIFO_reg62 ( .D(FIFO23278), .CK(Clk), .RN(nRST), .Q(\FIFO[7][0] ), 
        .QN(n2516) );
  DFFRX1 FIFO_reg63 ( .D(FIFO23279), .CK(Clk), .RN(nRST), .Q(\FIFO[8][9] ), 
        .QN(n2386) );
  DFFRX1 FIFO_reg64 ( .D(FIFO23280), .CK(Clk), .RN(nRST), .Q(\FIFO[8][8] ), 
        .QN(n2387) );
  DFFRX1 FIFO_reg65 ( .D(FIFO23283), .CK(Clk), .RN(nRST), .Q(\FIFO[8][5] ), 
        .QN(n2432) );
  DFFRX1 FIFO_reg66 ( .D(FIFO23284), .CK(Clk), .RN(nRST), .Q(\FIFO[8][4] ), 
        .QN(n2433) );
  DFFRX1 FIFO_reg67 ( .D(FIFO23285), .CK(Clk), .RN(nRST), .Q(\FIFO[8][3] ), 
        .QN(n2388) );
  DFFRX1 FIFO_reg68 ( .D(FIFO23286), .CK(Clk), .RN(nRST), .Q(\FIFO[8][2] ), 
        .QN(n2434) );
  DFFRX1 FIFO_reg69 ( .D(FIFO23287), .CK(Clk), .RN(nRST), .Q(\FIFO[8][1] ), 
        .QN(n2435) );
  DFFRX1 FIFO_reg70 ( .D(FIFO23288), .CK(Clk), .RN(nRST), .Q(\FIFO[8][0] ), 
        .QN(n2389) );
  DFFRX1 FIFO_reg71 ( .D(FIFO23289), .CK(Clk), .RN(nRST), .Q(\FIFO[9][9] ), 
        .QN(n2354) );
  DFFRX1 FIFO_reg72 ( .D(FIFO23290), .CK(Clk), .RN(nRST), .Q(\FIFO[9][8] ), 
        .QN(n2355) );
  DFFRX1 FIFO_reg73 ( .D(FIFO23293), .CK(Clk), .RN(nRST), .Q(\FIFO[9][5] ), 
        .QN(n2367) );
  DFFRX1 FIFO_reg74 ( .D(FIFO23294), .CK(Clk), .RN(nRST), .Q(\FIFO[9][4] ), 
        .QN(n2368) );
  DFFRX1 FIFO_reg75 ( .D(FIFO23295), .CK(Clk), .RN(nRST), .Q(\FIFO[9][3] ), 
        .QN(n2356) );
  DFFRX1 FIFO_reg76 ( .D(FIFO23296), .CK(Clk), .RN(nRST), .Q(\FIFO[9][2] ), 
        .QN(n2489) );
  DFFRX1 FIFO_reg77 ( .D(FIFO23297), .CK(Clk), .RN(nRST), .Q(\FIFO[9][1] ), 
        .QN(n2490) );
  DFFRX1 FIFO_reg78 ( .D(FIFO23298), .CK(Clk), .RN(nRST), .Q(\FIFO[9][0] ), 
        .QN(n2491) );
  DFFRX1 FIFO_reg79 ( .D(FIFO23299), .CK(Clk), .RN(nRST), .Q(\FIFO[10][9] ), 
        .QN(n2390) );
  DFFRX1 FIFO_reg80 ( .D(FIFO232100), .CK(Clk), .RN(nRST), .Q(\FIFO[10][8] ), 
        .QN(n2392) );
  DFFRX1 FIFO_reg81 ( .D(FIFO232103), .CK(Clk), .RN(nRST), .Q(\FIFO[10][5] ), 
        .QN(n2393) );
  DFFRX1 FIFO_reg82 ( .D(FIFO232104), .CK(Clk), .RN(nRST), .Q(\FIFO[10][4] ), 
        .QN(n2360) );
  DFFRX1 FIFO_reg83 ( .D(FIFO232105), .CK(Clk), .RN(nRST), .Q(\FIFO[10][3] ), 
        .QN(n2394) );
  DFFRX1 FIFO_reg84 ( .D(FIFO232106), .CK(Clk), .RN(nRST), .Q(\FIFO[10][2] ), 
        .QN(n2395) );
  DFFRX1 FIFO_reg85 ( .D(FIFO232107), .CK(Clk), .RN(nRST), .Q(\FIFO[10][1] ), 
        .QN(n2397) );
  DFFRX1 FIFO_reg86 ( .D(FIFO232108), .CK(Clk), .RN(nRST), .Q(\FIFO[10][0] ), 
        .QN(n2399) );
  DFFRX1 FIFO_reg87 ( .D(FIFO232109), .CK(Clk), .RN(nRST), .Q(\FIFO[11][9] ), 
        .QN(n2466) );
  DFFRX1 FIFO_reg88 ( .D(FIFO232110), .CK(Clk), .RN(nRST), .Q(\FIFO[11][8] ), 
        .QN(n2467) );
  DFFRX1 FIFO_reg89 ( .D(FIFO232113), .CK(Clk), .RN(nRST), .Q(\FIFO[11][5] ), 
        .QN(n2468) );
  DFFRX1 FIFO_reg90 ( .D(FIFO232114), .CK(Clk), .RN(nRST), .Q(\FIFO[11][4] ), 
        .QN(n2510) );
  DFFRX1 FIFO_reg91 ( .D(FIFO232115), .CK(Clk), .RN(nRST), .Q(\FIFO[11][3] ), 
        .QN(n2469) );
  DFFRX1 FIFO_reg92 ( .D(FIFO232116), .CK(Clk), .RN(nRST), .Q(\FIFO[11][2] ), 
        .QN(n2470) );
  DFFRX1 FIFO_reg93 ( .D(FIFO232117), .CK(Clk), .RN(nRST), .Q(\FIFO[11][1] ), 
        .QN(n2471) );
  DFFRX1 FIFO_reg94 ( .D(FIFO232118), .CK(Clk), .RN(nRST), .Q(\FIFO[11][0] ), 
        .QN(n2472) );
  DFFRX1 FIFO_reg95 ( .D(FIFO232119), .CK(Clk), .RN(nRST), .Q(\FIFO[12][9] ), 
        .QN(n2401) );
  DFFRX1 FIFO_reg96 ( .D(FIFO232120), .CK(Clk), .RN(nRST), .Q(\FIFO[12][8] ), 
        .QN(n2403) );
  DFFRX1 FIFO_reg97 ( .D(FIFO232123), .CK(Clk), .RN(nRST), .Q(\FIFO[12][5] ), 
        .QN(n2405) );
  DFFRX1 FIFO_reg98 ( .D(FIFO232124), .CK(Clk), .RN(nRST), .Q(\FIFO[12][4] ), 
        .QN(n2406) );
  DFFRX1 FIFO_reg99 ( .D(FIFO232125), .CK(Clk), .RN(nRST), .Q(\FIFO[12][3] ), 
        .QN(n2407) );
  DFFRX1 FIFO_reg100 ( .D(FIFO232126), .CK(Clk), .RN(nRST), .Q(\FIFO[12][2] ), 
        .QN(n2361) );
  DFFRX1 FIFO_reg101 ( .D(FIFO232127), .CK(Clk), .RN(nRST), .Q(\FIFO[12][1] ), 
        .QN(n2362) );
  DFFRX1 FIFO_reg102 ( .D(FIFO232128), .CK(Clk), .RN(nRST), .Q(\FIFO[12][0] ), 
        .QN(n2363) );
  DFFRX1 FIFO_reg103 ( .D(FIFO232129), .CK(Clk), .RN(nRST), .Q(\FIFO[13][9] ), 
        .QN(n2463) );
  DFFRX1 FIFO_reg104 ( .D(FIFO232130), .CK(Clk), .RN(nRST), .Q(\FIFO[13][8] ), 
        .QN(n2464) );
  DFFRX1 FIFO_reg105 ( .D(FIFO232133), .CK(Clk), .RN(nRST), .Q(\FIFO[13][5] ), 
        .QN(n2506) );
  DFFRX1 FIFO_reg106 ( .D(FIFO232134), .CK(Clk), .RN(nRST), .Q(\FIFO[13][4] ), 
        .QN(n2507) );
  DFFRX1 FIFO_reg107 ( .D(FIFO232135), .CK(Clk), .RN(nRST), .Q(\FIFO[13][3] ), 
        .QN(n2465) );
  DFFRX1 FIFO_reg108 ( .D(FIFO232136), .CK(Clk), .RN(nRST), .Q(\FIFO[13][2] ), 
        .QN(n2411) );
  DFFRX1 FIFO_reg109 ( .D(FIFO232137), .CK(Clk), .RN(nRST), .Q(\FIFO[13][1] ), 
        .QN(n2412) );
  DFFRX1 FIFO_reg110 ( .D(FIFO232138), .CK(Clk), .RN(nRST), .Q(\FIFO[13][0] ), 
        .QN(n2413) );
  DFFRX1 FIFO_reg111 ( .D(FIFO232139), .CK(Clk), .RN(nRST), .Q(\FIFO[14][9] ), 
        .QN(n2452) );
  DFFRX1 FIFO_reg112 ( .D(FIFO232140), .CK(Clk), .RN(nRST), .Q(\FIFO[14][8] ), 
        .QN(n2453) );
  DFFRX1 FIFO_reg113 ( .D(FIFO232143), .CK(Clk), .RN(nRST), .Q(\FIFO[14][5] ), 
        .QN(n2480) );
  DFFRX1 FIFO_reg114 ( .D(FIFO232144), .CK(Clk), .RN(nRST), .Q(\FIFO[14][4] ), 
        .QN(n2481) );
  DFFRX1 FIFO_reg115 ( .D(FIFO232145), .CK(Clk), .RN(nRST), .Q(\FIFO[14][3] ), 
        .QN(n2454) );
  DFFRX1 FIFO_reg116 ( .D(FIFO232146), .CK(Clk), .RN(nRST), .Q(\FIFO[14][2] ), 
        .QN(n2482) );
  DFFRX1 FIFO_reg117 ( .D(FIFO232147), .CK(Clk), .RN(nRST), .Q(\FIFO[14][1] ), 
        .QN(n2483) );
  DFFRX1 FIFO_reg118 ( .D(FIFO232148), .CK(Clk), .RN(nRST), .Q(\FIFO[14][0] ), 
        .QN(n2484) );
  DFFRX1 FIFO_reg119 ( .D(FIFO232149), .CK(Clk), .RN(nRST), .Q(\FIFO[15][9] ), 
        .QN(n2377) );
  DFFRX1 FIFO_reg120 ( .D(FIFO232150), .CK(Clk), .RN(nRST), .Q(\FIFO[15][8] ), 
        .QN(n2378) );
  DFFRX1 FIFO_reg121 ( .D(FIFO232153), .CK(Clk), .RN(nRST), .Q(\FIFO[15][5] ), 
        .QN(n2416) );
  DFFRX1 FIFO_reg122 ( .D(FIFO232154), .CK(Clk), .RN(nRST), .Q(\FIFO[15][4] ), 
        .QN(n2417) );
  DFFRX1 FIFO_reg123 ( .D(FIFO232155), .CK(Clk), .RN(nRST), .Q(\FIFO[15][3] ), 
        .QN(n2379) );
  DFFRX1 FIFO_reg124 ( .D(FIFO232156), .CK(Clk), .RN(nRST), .Q(\FIFO[15][2] ), 
        .QN(n2418) );
  DFFRX1 FIFO_reg125 ( .D(FIFO232157), .CK(Clk), .RN(nRST), .Q(\FIFO[15][1] ), 
        .QN(n2419) );
  DFFRX1 FIFO_reg126 ( .D(FIFO232158), .CK(Clk), .RN(nRST), .Q(\FIFO[15][0] ), 
        .QN(n2380) );
  DFFRX1 FIFO_reg127 ( .D(FIFO2321), .CK(Clk), .RN(nRST), .Q(\FIFO[0][7] ), 
        .QN(n2518) );
  DFFRX1 FIFO_reg128 ( .D(FIFO2322), .CK(Clk), .RN(nRST), .Q(\FIFO[0][6] ), 
        .QN(n2420) );
  DFFRX1 FIFO_reg129 ( .D(FIFO23211), .CK(Clk), .RN(nRST), .Q(\FIFO[1][7] ), 
        .QN(n2371) );
  DFFRX1 FIFO_reg130 ( .D(FIFO23212), .CK(Clk), .RN(nRST), .Q(\FIFO[1][6] ), 
        .QN(n2476) );
  DFFRX1 FIFO_reg131 ( .D(FIFO23221), .CK(Clk), .RN(nRST), .Q(\FIFO[2][7] ), 
        .QN(n2437) );
  DFFRX1 FIFO_reg132 ( .D(FIFO23222), .CK(Clk), .RN(nRST), .Q(\FIFO[2][6] ), 
        .QN(n2502) );
  DFFRX1 FIFO_reg133 ( .D(FIFO23231), .CK(Clk), .RN(nRST), .Q(\FIFO[3][7] ), 
        .QN(n2500) );
  DFFRX1 FIFO_reg134 ( .D(FIFO23232), .CK(Clk), .RN(nRST), .Q(\FIFO[3][6] ), 
        .QN(n2369) );
  DFFRX1 FIFO_reg135 ( .D(FIFO23241), .CK(Clk), .RN(nRST), .Q(\FIFO[4][7] ), 
        .QN(n2446) );
  DFFRX1 FIFO_reg136 ( .D(FIFO23242), .CK(Clk), .RN(nRST), .Q(\FIFO[4][6] ), 
        .QN(n2424) );
  DFFRX1 FIFO_reg137 ( .D(FIFO23251), .CK(Clk), .RN(nRST), .Q(\FIFO[5][7] ), 
        .QN(n2522) );
  DFFRX1 FIFO_reg138 ( .D(FIFO23252), .CK(Clk), .RN(nRST), .Q(\FIFO[5][6] ), 
        .QN(n2493) );
  DFFRX1 FIFO_reg139 ( .D(FIFO23261), .CK(Clk), .RN(nRST), .Q(\FIFO[6][7] ), 
        .QN(n2439) );
  DFFRX1 FIFO_reg140 ( .D(FIFO23262), .CK(Clk), .RN(nRST), .Q(\FIFO[6][6] ), 
        .QN(n2441) );
  DFFRX1 FIFO_reg141 ( .D(FIFO23271), .CK(Clk), .RN(nRST), .Q(\FIFO[7][7] ), 
        .QN(n2523) );
  DFFRX1 FIFO_reg142 ( .D(FIFO23272), .CK(Clk), .RN(nRST), .Q(\FIFO[7][6] ), 
        .QN(n2511) );
  DFFRX1 FIFO_reg143 ( .D(FIFO23281), .CK(Clk), .RN(nRST), .Q(\FIFO[8][7] ), 
        .QN(n2430) );
  DFFRX1 FIFO_reg144 ( .D(FIFO23282), .CK(Clk), .RN(nRST), .Q(\FIFO[8][6] ), 
        .QN(n2431) );
  DFFRX1 FIFO_reg145 ( .D(FIFO23291), .CK(Clk), .RN(nRST), .Q(\FIFO[9][7] ), 
        .QN(n2521) );
  DFFRX1 FIFO_reg146 ( .D(FIFO23292), .CK(Clk), .RN(nRST), .Q(\FIFO[9][6] ), 
        .QN(n2366) );
  DFFRX1 FIFO_reg147 ( .D(FIFO232101), .CK(Clk), .RN(nRST), .Q(\FIFO[10][7] ), 
        .QN(n2436) );
  DFFRX1 FIFO_reg148 ( .D(FIFO232102), .CK(Clk), .RN(nRST), .Q(\FIFO[10][6] ), 
        .QN(n2438) );
  DFFRX1 FIFO_reg149 ( .D(FIFO232111), .CK(Clk), .RN(nRST), .Q(\FIFO[11][7] ), 
        .QN(n2508) );
  DFFRX1 FIFO_reg150 ( .D(FIFO232112), .CK(Clk), .RN(nRST), .Q(\FIFO[11][6] ), 
        .QN(n2509) );
  DFFRX1 FIFO_reg151 ( .D(FIFO232121), .CK(Clk), .RN(nRST), .Q(\FIFO[12][7] ), 
        .QN(n2370) );
  DFFRX1 FIFO_reg152 ( .D(FIFO232122), .CK(Clk), .RN(nRST), .Q(\FIFO[12][6] ), 
        .QN(n2440) );
  DFFRX1 FIFO_reg153 ( .D(FIFO232131), .CK(Clk), .RN(nRST), .Q(\FIFO[13][7] ), 
        .QN(n2445) );
  DFFRX1 FIFO_reg154 ( .D(FIFO232132), .CK(Clk), .RN(nRST), .Q(\FIFO[13][6] ), 
        .QN(n2505) );
  DFFRX1 FIFO_reg155 ( .D(FIFO232141), .CK(Clk), .RN(nRST), .Q(\FIFO[14][7] ), 
        .QN(n2517) );
  DFFRX1 FIFO_reg156 ( .D(FIFO232142), .CK(Clk), .RN(nRST), .Q(\FIFO[14][6] ), 
        .QN(n2479) );
  DFFRX1 FIFO_reg157 ( .D(FIFO232151), .CK(Clk), .RN(nRST), .Q(\FIFO[15][7] ), 
        .QN(n2414) );
  DFFRX1 FIFO_reg158 ( .D(FIFO232152), .CK(Clk), .RN(nRST), .Q(\FIFO[15][6] ), 
        .QN(n2415) );
  DFFRX1 WrCnt_reg_0_ ( .D(n1771), .CK(Clk), .RN(nRST), .Q(WrCnt_0_) );
  DFFRX1 WrCnt_reg_3_ ( .D(n1768), .CK(Clk), .RN(nRST), .Q(WrCnt_3_), .QN(
        n2535) );
  DFFRX1 WrCnt_reg_1_ ( .D(n1770), .CK(Clk), .RN(nRST), .Q(WrCnt_1_), .QN(
        n2519) );
  DFFSX1 DatCnt_reg_0_ ( .D(n1792), .CK(Clk), .SN(nRST), .Q(EmptyFlag), .QN(
        n2528) );
  DFFRX1 WrCnt_reg_2_ ( .D(n1769), .CK(Clk), .RN(nRST), .Q(WrCnt_2_), .QN(
        n2520) );
  DFFRX1 DatCnt_reg_15_ ( .D(n1777), .CK(Clk), .RN(nRST), .QN(n2531) );
  DFFRX1 DatCnt_reg_1_ ( .D(n1791), .CK(Clk), .RN(nRST), .QN(n2530) );
  DFFRX1 DatCnt_reg_14_ ( .D(n1778), .CK(Clk), .RN(nRST), .QN(n2376) );
  DFFRX1 DatCnt_reg_13_ ( .D(n1779), .CK(Clk), .RN(nRST), .QN(n2351) );
  DFFRX1 DatCnt_reg_12_ ( .D(n1780), .CK(Clk), .RN(nRST), .QN(n2524) );
  DFFRX1 DatCnt_reg_11_ ( .D(n1781), .CK(Clk), .RN(nRST), .QN(n2373) );
  DFFRX1 DatCnt_reg_10_ ( .D(n1782), .CK(Clk), .RN(nRST), .QN(n2447) );
  DFFRX1 DatCnt_reg_9_ ( .D(n1783), .CK(Clk), .RN(nRST), .QN(n2525) );
  DFFRX1 DatCnt_reg_8_ ( .D(n1784), .CK(Clk), .RN(nRST), .QN(n2374) );
  DFFRX1 DatCnt_reg_7_ ( .D(n1785), .CK(Clk), .RN(nRST), .QN(n2448) );
  DFFRX1 DatCnt_reg_6_ ( .D(n1786), .CK(Clk), .RN(nRST), .QN(n2526) );
  DFFRX1 DatCnt_reg_5_ ( .D(n1787), .CK(Clk), .RN(nRST), .QN(n2375) );
  DFFRX1 DatCnt_reg_4_ ( .D(n1788), .CK(Clk), .RN(nRST), .QN(n2449) );
  DFFRX1 DatCnt_reg_3_ ( .D(n1789), .CK(Clk), .RN(nRST), .QN(n2527) );
  DFFRX1 DatCnt_reg_2_ ( .D(n1790), .CK(Clk), .RN(nRST), .QN(n2372) );
endmodule


module SDRBLQ_BLQCD0_BLQD1_BLQW9 ( nRST, Clk, WriteEn, ReadEn, WrData, RdData, 
        FullFlag, EmptyFlag );
  input [9:0] WrData;
  output [9:0] RdData;
  input nRST, Clk, WriteEn, ReadEn;
  output FullFlag, EmptyFlag;
  wire   DatCnt_1_, RdCnt_0_, \FIFO[0][9] , \FIFO[0][8] , \FIFO[0][7] ,
         \FIFO[0][6] , \FIFO[0][5] , \FIFO[0][4] , \FIFO[0][3] , \FIFO[0][2] ,
         \FIFO[0][1] , \FIFO[0][0] , \FIFO[1][9] , \FIFO[1][8] , \FIFO[1][7] ,
         \FIFO[1][6] , \FIFO[1][5] , \FIFO[1][4] , \FIFO[1][3] , \FIFO[1][2] ,
         \FIFO[1][1] , \FIFO[1][0] , WrCnt_0_, FIFO230, FIFO2300, FIFO2301,
         FIFO2302, FIFO2303, FIFO2304, FIFO2305, FIFO2306, FIFO2307, FIFO2308,
         FIFO2309, FIFO23010, FIFO23011, FIFO23012, FIFO23013, FIFO23014,
         FIFO23015, FIFO23016, FIFO23017, FIFO23018, n534, n535, n536, n537,
         n538, n542, n544, n545, n547, n549, n550, n552, n554, n555, n556,
         n557, n558, n559, n560, n561;

  INVX1 U246 ( .A(n542), .Y(n545) );
  INVX1 U247 ( .A(ReadEn), .Y(n544) );
  XOR2X1 U248 ( .A(n544), .B(WriteEn), .Y(n542) );
  OAI32X1 U249 ( .A0(n542), .A1(n555), .A2(n544), .B0(n545), .B1(n558), .Y(
        n538) );
  OAI32X1 U250 ( .A0(n542), .A1(ReadEn), .A2(n555), .B0(n545), .B1(n556), .Y(
        n536) );
  XOR2X1 U251 ( .A(ReadEn), .B(n561), .Y(n535) );
  INVX1 U252 ( .A(n554), .Y(n550) );
  INVX1 U253 ( .A(WriteEn), .Y(n549) );
  AO21X1 U254 ( .A0(n542), .A1(DatCnt_1_), .B0(n547), .Y(n537) );
  OAI33X1 U255 ( .A0(n542), .A1(n556), .A2(n544), .B0(n542), .B1(ReadEn), .B2(
        n558), .Y(n547) );
  AO22X1 U256 ( .A0(\FIFO[1][0] ), .A1(n561), .B0(\FIFO[0][0] ), .B1(n557), 
        .Y(RdData[0]) );
  AO22X1 U257 ( .A0(\FIFO[1][6] ), .A1(n561), .B0(\FIFO[0][6] ), .B1(n557), 
        .Y(RdData[6]) );
  AO22X1 U258 ( .A0(\FIFO[1][5] ), .A1(n561), .B0(\FIFO[0][5] ), .B1(n557), 
        .Y(RdData[5]) );
  AO22X1 U259 ( .A0(\FIFO[1][4] ), .A1(n561), .B0(\FIFO[0][4] ), .B1(n557), 
        .Y(RdData[4]) );
  AO22X1 U260 ( .A0(\FIFO[1][2] ), .A1(n561), .B0(\FIFO[0][2] ), .B1(n557), 
        .Y(RdData[2]) );
  AO22X1 U261 ( .A0(\FIFO[1][1] ), .A1(n561), .B0(\FIFO[0][1] ), .B1(n557), 
        .Y(RdData[1]) );
  AO22X1 U262 ( .A0(\FIFO[1][3] ), .A1(n561), .B0(\FIFO[0][3] ), .B1(n557), 
        .Y(RdData[3]) );
  AO22X1 U263 ( .A0(\FIFO[1][9] ), .A1(n561), .B0(\FIFO[0][9] ), .B1(n557), 
        .Y(RdData[9]) );
  AO22X1 U264 ( .A0(\FIFO[1][8] ), .A1(n561), .B0(\FIFO[0][8] ), .B1(n557), 
        .Y(RdData[8]) );
  BUFX2 U265 ( .A(RdCnt_0_), .Y(n561) );
  AO22X1 U266 ( .A0(\FIFO[1][7] ), .A1(n561), .B0(\FIFO[0][7] ), .B1(n557), 
        .Y(RdData[7]) );
  NAND2BX1 U267 ( .AN(WrCnt_0_), .B(WriteEn), .Y(n554) );
  NOR2X1 U268 ( .A(n549), .B(n560), .Y(n559) );
  INVX1 U269 ( .A(n559), .Y(n552) );
  AO22X1 U270 ( .A0(\FIFO[0][0] ), .A1(n554), .B0(n550), .B1(WrData[0]), .Y(
        FIFO2308) );
  AO22X1 U271 ( .A0(\FIFO[1][0] ), .A1(n552), .B0(WrData[0]), .B1(n559), .Y(
        FIFO23018) );
  AO22X1 U272 ( .A0(\FIFO[1][9] ), .A1(n552), .B0(WrData[9]), .B1(n559), .Y(
        FIFO2309) );
  AO22X1 U273 ( .A0(\FIFO[1][8] ), .A1(n552), .B0(WrData[8]), .B1(n559), .Y(
        FIFO23010) );
  AO22X1 U274 ( .A0(\FIFO[1][7] ), .A1(n552), .B0(WrData[7]), .B1(n559), .Y(
        FIFO23011) );
  AO22X1 U275 ( .A0(\FIFO[1][6] ), .A1(n552), .B0(WrData[6]), .B1(n559), .Y(
        FIFO23012) );
  AO22X1 U276 ( .A0(\FIFO[1][5] ), .A1(n552), .B0(WrData[5]), .B1(n559), .Y(
        FIFO23013) );
  AO22X1 U277 ( .A0(\FIFO[1][4] ), .A1(n552), .B0(WrData[4]), .B1(n559), .Y(
        FIFO23014) );
  AO22X1 U278 ( .A0(\FIFO[1][3] ), .A1(n552), .B0(WrData[3]), .B1(n559), .Y(
        FIFO23015) );
  AO22X1 U279 ( .A0(\FIFO[1][2] ), .A1(n552), .B0(WrData[2]), .B1(n559), .Y(
        FIFO23016) );
  AO22X1 U280 ( .A0(\FIFO[1][1] ), .A1(n552), .B0(WrData[1]), .B1(n559), .Y(
        FIFO23017) );
  AO22X1 U281 ( .A0(\FIFO[0][2] ), .A1(n554), .B0(n550), .B1(WrData[2]), .Y(
        FIFO2306) );
  AO22X1 U282 ( .A0(\FIFO[0][3] ), .A1(n554), .B0(n550), .B1(WrData[3]), .Y(
        FIFO2305) );
  AO22X1 U283 ( .A0(\FIFO[0][1] ), .A1(n554), .B0(n550), .B1(WrData[1]), .Y(
        FIFO2307) );
  AO22X1 U284 ( .A0(\FIFO[0][8] ), .A1(n554), .B0(n550), .B1(WrData[8]), .Y(
        FIFO2300) );
  AO22X1 U285 ( .A0(\FIFO[0][9] ), .A1(n554), .B0(n550), .B1(WrData[9]), .Y(
        FIFO230) );
  AO22X1 U286 ( .A0(\FIFO[0][7] ), .A1(n554), .B0(n550), .B1(WrData[7]), .Y(
        FIFO2301) );
  AO22X1 U287 ( .A0(\FIFO[0][6] ), .A1(n554), .B0(n550), .B1(WrData[6]), .Y(
        FIFO2302) );
  AO22X1 U288 ( .A0(\FIFO[0][5] ), .A1(n554), .B0(n550), .B1(WrData[5]), .Y(
        FIFO2303) );
  AO22X1 U289 ( .A0(\FIFO[0][4] ), .A1(n554), .B0(n550), .B1(WrData[4]), .Y(
        FIFO2304) );
  AO21X1 U290 ( .A0(WrCnt_0_), .A1(n549), .B0(n550), .Y(n534) );
  DFFRX1 DatCnt_reg_2_ ( .D(n536), .CK(Clk), .RN(nRST), .Q(FullFlag), .QN(n556) );
  DFFRX1 RdCnt_reg_0_ ( .D(n535), .CK(Clk), .RN(nRST), .Q(RdCnt_0_), .QN(n557)
         );
  DFFRX1 FIFO_reg ( .D(FIFO2309), .CK(Clk), .RN(nRST), .Q(\FIFO[1][9] ) );
  DFFRX1 FIFO_reg0 ( .D(FIFO23010), .CK(Clk), .RN(nRST), .Q(\FIFO[1][8] ) );
  DFFRX1 FIFO_reg1 ( .D(FIFO23013), .CK(Clk), .RN(nRST), .Q(\FIFO[1][5] ) );
  DFFRX1 FIFO_reg2 ( .D(FIFO23014), .CK(Clk), .RN(nRST), .Q(\FIFO[1][4] ) );
  DFFRX1 FIFO_reg3 ( .D(FIFO23015), .CK(Clk), .RN(nRST), .Q(\FIFO[1][3] ) );
  DFFRX1 FIFO_reg4 ( .D(FIFO23016), .CK(Clk), .RN(nRST), .Q(\FIFO[1][2] ) );
  DFFRX1 FIFO_reg5 ( .D(FIFO23017), .CK(Clk), .RN(nRST), .Q(\FIFO[1][1] ) );
  DFFRX1 FIFO_reg6 ( .D(FIFO23018), .CK(Clk), .RN(nRST), .Q(\FIFO[1][0] ) );
  DFFRX1 FIFO_reg7 ( .D(FIFO230), .CK(Clk), .RN(nRST), .Q(\FIFO[0][9] ) );
  DFFRX1 FIFO_reg8 ( .D(FIFO2300), .CK(Clk), .RN(nRST), .Q(\FIFO[0][8] ) );
  DFFRX1 FIFO_reg9 ( .D(FIFO2303), .CK(Clk), .RN(nRST), .Q(\FIFO[0][5] ) );
  DFFRX1 FIFO_reg10 ( .D(FIFO2304), .CK(Clk), .RN(nRST), .Q(\FIFO[0][4] ) );
  DFFRX1 FIFO_reg11 ( .D(FIFO2305), .CK(Clk), .RN(nRST), .Q(\FIFO[0][3] ) );
  DFFRX1 FIFO_reg12 ( .D(FIFO2306), .CK(Clk), .RN(nRST), .Q(\FIFO[0][2] ) );
  DFFRX1 FIFO_reg13 ( .D(FIFO2307), .CK(Clk), .RN(nRST), .Q(\FIFO[0][1] ) );
  DFFRX1 FIFO_reg14 ( .D(FIFO2308), .CK(Clk), .RN(nRST), .Q(\FIFO[0][0] ) );
  DFFRX1 FIFO_reg15 ( .D(FIFO23011), .CK(Clk), .RN(nRST), .Q(\FIFO[1][7] ) );
  DFFRX1 FIFO_reg16 ( .D(FIFO23012), .CK(Clk), .RN(nRST), .Q(\FIFO[1][6] ) );
  DFFRX1 FIFO_reg17 ( .D(FIFO2301), .CK(Clk), .RN(nRST), .Q(\FIFO[0][7] ) );
  DFFRX1 FIFO_reg18 ( .D(FIFO2302), .CK(Clk), .RN(nRST), .Q(\FIFO[0][6] ) );
  DFFSX1 DatCnt_reg_0_ ( .D(n538), .CK(Clk), .SN(nRST), .Q(EmptyFlag), .QN(
        n558) );
  DFFRX1 DatCnt_reg_1_ ( .D(n537), .CK(Clk), .RN(nRST), .Q(DatCnt_1_), .QN(
        n555) );
  DFFRX1 WrCnt_reg_0_ ( .D(n534), .CK(Clk), .RN(nRST), .Q(WrCnt_0_), .QN(n560)
         );
endmodule


module SDRRQ ( nRST, nClk, Clk, WriteEn, ReadEn, WrData, RdData, FullFlag, 
        HFullFlag, EmptyFlag, WrapCnt, IncRdCnt, AddrHold );
  input [35:0] WrData;
  output [35:0] RdData;
  input [7:0] WrapCnt;
  output [7:0] IncRdCnt;
  input nRST, nClk, Clk, WriteEn, ReadEn, AddrHold;
  output FullFlag, HFullFlag, EmptyFlag;
  wire   DatCnt_7_, DatCnt_5_, DatCnt_4_, DatCnt_3_, DatCnt_2_, DatCnt_1_,
         DatCnt_0_, n_207, n_208, WrCnt104_6_, WrCnt104_5_, WrCnt104_4_,
         WrCnt104_3_, WrCnt104_2_, WrCnt104_1_, IncRdCnt171_6_, IncRdCnt171_5_,
         IncRdCnt171_4_, IncRdCnt171_3_, IncRdCnt171_2_, IncRdCnt171_1_,
         DatCnt268_7_, DatCnt268_6_, DatCnt268_5_, DatCnt268_4_, DatCnt268_3_,
         DatCnt268_2_, DatCnt268_1_, DatCnt272_6_, DatCnt272_5_, DatCnt272_4_,
         DatCnt272_3_, DatCnt272_2_, DatCnt272_1_, n532, n533, n534, n535,
         n536, n537, n538, n539, n540, n541, n542, n543, n544, n545, n546,
         n547, n548, n549, n550, n551, n552, n553, n554, n555, carry, carry0,
         carry1, carry2, carry3, n12, n22, n32, n42, n52, n62, carry4, carry5,
         carry6, carry7, carry8, n11, n21, n31, n41, n51, n61, carry_7_,
         carry9, carry10, carry11, carry12, carry13, carry_6_, carry_5_,
         carry_4_, carry_3_, carry_2_, n1, n2, n3, n4, n5, n6, n556, n557,
         n559, n560, n561, n562, n563, n564, n565, n566, n567, n568, n569,
         n570, n572, n573, n574, n575, n577, n578, n579, n582, n584, n586,
         n587, n589, n591, n592, n593, n594, n595, n596, n597, n598, n599,
         n600;
  wire   [7:0] WrCnt;

  RF2SH256x32 RQL ( .CENB(n_208), .AB(WrCnt), .DB(WrData[31:0]), .CENA(n_207), 
        .AA(WrapCnt), .CLKB(Clk), .CLKA(nClk), .QA(RdData[31:0]) );
  RF2SH256x4 RQH ( .CENB(n_208), .AB(WrCnt), .DB(WrData[35:32]), .CENA(n_207), 
        .AA(WrapCnt), .CLKB(Clk), .CLKA(nClk), .QA(RdData[35:32]) );
  AHHCONX2 U1_1_12 ( .A(WrCnt[1]), .CI(WrCnt[0]), .S(WrCnt104_1_), .CON(n62)
         );
  AHHCONX2 U1_1_22 ( .A(WrCnt[2]), .CI(carry3), .S(WrCnt104_2_), .CON(n52) );
  AHHCONX2 U1_1_32 ( .A(WrCnt[3]), .CI(carry2), .S(WrCnt104_3_), .CON(n42) );
  AHHCONX2 U1_1_42 ( .A(WrCnt[4]), .CI(carry1), .S(WrCnt104_4_), .CON(n32) );
  AHHCONX2 U1_1_52 ( .A(WrCnt[5]), .CI(carry0), .S(WrCnt104_5_), .CON(n22) );
  AHHCONX2 U1_1_62 ( .A(WrCnt[6]), .CI(carry), .S(WrCnt104_6_), .CON(n12) );
  AHHCONX2 U1_1_11 ( .A(IncRdCnt[1]), .CI(IncRdCnt[0]), .S(IncRdCnt171_1_), 
        .CON(n61) );
  AHHCONX2 U1_1_21 ( .A(IncRdCnt[2]), .CI(carry8), .S(IncRdCnt171_2_), .CON(
        n51) );
  AHHCONX2 U1_1_31 ( .A(IncRdCnt[3]), .CI(carry7), .S(IncRdCnt171_3_), .CON(
        n41) );
  AHHCONX2 U1_1_41 ( .A(IncRdCnt[4]), .CI(carry6), .S(IncRdCnt171_4_), .CON(
        n31) );
  AHHCONX2 U1_1_51 ( .A(IncRdCnt[5]), .CI(carry5), .S(IncRdCnt171_5_), .CON(
        n21) );
  AHHCONX2 U1_1_61 ( .A(IncRdCnt[6]), .CI(carry4), .S(IncRdCnt171_6_), .CON(
        n11) );
  AHHCONX2 U1_1_1 ( .A(DatCnt_1_), .CI(DatCnt_0_), .S(DatCnt272_1_), .CON(n6)
         );
  AHHCONX2 U1_1_2 ( .A(DatCnt_2_), .CI(carry_2_), .S(DatCnt272_2_), .CON(n5)
         );
  AHHCONX2 U1_1_3 ( .A(DatCnt_3_), .CI(carry_3_), .S(DatCnt272_3_), .CON(n4)
         );
  AHHCONX2 U1_1_4 ( .A(DatCnt_4_), .CI(carry_4_), .S(DatCnt272_4_), .CON(n3)
         );
  AHHCONX2 U1_1_5 ( .A(DatCnt_5_), .CI(carry_5_), .S(DatCnt272_5_), .CON(n2)
         );
  AHHCONX2 U1_1_6 ( .A(HFullFlag), .CI(carry_6_), .S(DatCnt272_6_), .CON(n1)
         );
  OAI31X1 U285 ( .A0(n574), .A1(n12), .A2(WrCnt[7]), .B0(n579), .Y(n532) );
  DFFRX1 WrCnt_reg_6_ ( .D(n533), .CK(Clk), .RN(nRST), .Q(WrCnt[6]) );
  DFFRX1 WrCnt_reg_5_ ( .D(n534), .CK(Clk), .RN(nRST), .Q(WrCnt[5]) );
  DFFRX1 WrCnt_reg_4_ ( .D(n535), .CK(Clk), .RN(nRST), .Q(WrCnt[4]) );
  DFFRX1 WrCnt_reg_3_ ( .D(n536), .CK(Clk), .RN(nRST), .Q(WrCnt[3]) );
  DFFRX1 WrCnt_reg_2_ ( .D(n537), .CK(Clk), .RN(nRST), .Q(WrCnt[2]) );
  DFFRX1 WrCnt_reg_1_ ( .D(n538), .CK(Clk), .RN(nRST), .Q(WrCnt[1]) );
  DFFRX1 WrCnt_reg_0_ ( .D(n539), .CK(Clk), .RN(nRST), .Q(WrCnt[0]), .QN(n591)
         );
  DFFRX1 WrCnt_reg_7_ ( .D(n532), .CK(Clk), .RN(nRST), .Q(WrCnt[7]), .QN(n599)
         );
  INVX1 U286 ( .A(n556), .Y(n562) );
  NAND2BX1 U287 ( .AN(n573), .B(n557), .Y(n556) );
  INVX1 U288 ( .A(n559), .Y(n560) );
  NAND2BX1 U289 ( .AN(ReadEn), .B(n557), .Y(n559) );
  INVX1 U290 ( .A(n563), .Y(n557) );
  INVX1 U291 ( .A(ReadEn), .Y(n573) );
  XOR2X1 U292 ( .A(n574), .B(ReadEn), .Y(n563) );
  INVX1 U293 ( .A(n574), .Y(n578) );
  INVX1 U294 ( .A(n1), .Y(n572) );
  INVX1 U295 ( .A(WriteEn), .Y(n_208) );
  NOR4BX1 U296 ( .AN(n586), .B(DatCnt_4_), .C(n587), .D(DatCnt_3_), .Y(
        EmptyFlag) );
  NAND3BX1 U297 ( .AN(HFullFlag), .B(n596), .C(n594), .Y(n587) );
  AND4X1 U298 ( .A(n589), .B(n592), .C(n595), .D(n593), .Y(n586) );
  NOR2X1 U299 ( .A(n600), .B(ReadEn), .Y(n_207) );
  INVX1 U300 ( .A(AddrHold), .Y(n589) );
  NAND2BX1 U301 ( .AN(AddrHold), .B(WriteEn), .Y(n574) );
  INVX1 U302 ( .A(n21), .Y(carry4) );
  INVX1 U303 ( .A(n22), .Y(carry) );
  INVX1 U304 ( .A(n2), .Y(carry_6_) );
  NOR4BX1 U305 ( .AN(n582), .B(n593), .C(n584), .D(n597), .Y(FullFlag) );
  AND4X1 U306 ( .A(DatCnt_7_), .B(HFullFlag), .C(DatCnt_5_), .D(DatCnt_4_), 
        .Y(n582) );
  NAND3BX1 U307 ( .AN(AddrHold), .B(DatCnt_1_), .C(DatCnt_0_), .Y(n584) );
  INVX1 U308 ( .A(n5), .Y(carry_3_) );
  INVX1 U309 ( .A(n3), .Y(carry_5_) );
  INVX1 U310 ( .A(n6), .Y(carry_2_) );
  INVX1 U311 ( .A(n41), .Y(carry6) );
  INVX1 U312 ( .A(n62), .Y(carry3) );
  INVX1 U313 ( .A(n61), .Y(carry8) );
  INVX1 U314 ( .A(n52), .Y(carry2) );
  INVX1 U315 ( .A(n51), .Y(carry7) );
  INVX1 U316 ( .A(n42), .Y(carry1) );
  INVX1 U317 ( .A(n32), .Y(carry0) );
  NAND2BX1 U318 ( .AN(n569), .B(n570), .Y(n548) );
  AO22X1 U319 ( .A0(DatCnt_7_), .A1(n563), .B0(DatCnt268_7_), .B1(n562), .Y(
        n569) );
  AOI33X1 U320 ( .A0(n594), .A1(n572), .A2(n560), .B0(DatCnt_7_), .B1(n1), 
        .B2(n560), .Y(n570) );
  XNOR2X1 U1_A_7 ( .A(DatCnt_7_), .B(carry_7_), .Y(DatCnt268_7_) );
  OR2X1 U1_B_1 ( .A(DatCnt_1_), .B(DatCnt_0_), .Y(carry13) );
  OR2X1 U1_B_3 ( .A(DatCnt_3_), .B(carry12), .Y(carry11) );
  OR2X1 U1_B_5 ( .A(DatCnt_5_), .B(carry10), .Y(carry9) );
  OR2X1 U1_B_2 ( .A(DatCnt_2_), .B(carry13), .Y(carry12) );
  OR2X1 U1_B_4 ( .A(DatCnt_4_), .B(carry11), .Y(carry10) );
  INVX1 U321 ( .A(n4), .Y(carry_4_) );
  OAI222X1 U322 ( .A0(DatCnt_0_), .A1(n556), .B0(n557), .B1(n592), .C0(
        DatCnt_0_), .C1(n559), .Y(n555) );
  INVX1 U323 ( .A(n31), .Y(carry5) );
  AO22X1 U324 ( .A0(WrCnt[6]), .A1(n574), .B0(WrCnt104_6_), .B1(n578), .Y(n533) );
  AO22X1 U325 ( .A0(IncRdCnt[6]), .A1(n573), .B0(IncRdCnt171_6_), .B1(ReadEn), 
        .Y(n541) );
  AO22X1 U326 ( .A0(IncRdCnt[5]), .A1(n573), .B0(IncRdCnt171_5_), .B1(ReadEn), 
        .Y(n542) );
  AO22X1 U327 ( .A0(IncRdCnt[4]), .A1(n573), .B0(IncRdCnt171_4_), .B1(ReadEn), 
        .Y(n543) );
  AO22X1 U328 ( .A0(IncRdCnt[3]), .A1(n573), .B0(IncRdCnt171_3_), .B1(ReadEn), 
        .Y(n544) );
  AO22X1 U329 ( .A0(IncRdCnt[2]), .A1(n573), .B0(IncRdCnt171_2_), .B1(ReadEn), 
        .Y(n545) );
  AO22X1 U330 ( .A0(IncRdCnt[1]), .A1(n573), .B0(IncRdCnt171_1_), .B1(ReadEn), 
        .Y(n546) );
  OR2X1 U1_B_6 ( .A(HFullFlag), .B(carry9), .Y(carry_7_) );
  AO21X1 U331 ( .A0(DatCnt272_6_), .A1(n560), .B0(n568), .Y(n549) );
  AO22X1 U332 ( .A0(DatCnt268_6_), .A1(n562), .B0(HFullFlag), .B1(n563), .Y(
        n568) );
  XNOR2X1 U1_A_6 ( .A(HFullFlag), .B(carry9), .Y(DatCnt268_6_) );
  AO21X1 U333 ( .A0(DatCnt272_5_), .A1(n560), .B0(n567), .Y(n550) );
  AO22X1 U334 ( .A0(DatCnt268_5_), .A1(n562), .B0(DatCnt_5_), .B1(n563), .Y(
        n567) );
  XNOR2X1 U1_A_5 ( .A(DatCnt_5_), .B(carry10), .Y(DatCnt268_5_) );
  AO21X1 U335 ( .A0(DatCnt272_4_), .A1(n560), .B0(n566), .Y(n551) );
  AO22X1 U336 ( .A0(DatCnt268_4_), .A1(n562), .B0(DatCnt_4_), .B1(n563), .Y(
        n566) );
  XNOR2X1 U1_A_4 ( .A(DatCnt_4_), .B(carry11), .Y(DatCnt268_4_) );
  AO21X1 U337 ( .A0(DatCnt272_3_), .A1(n560), .B0(n565), .Y(n552) );
  AO22X1 U338 ( .A0(DatCnt268_3_), .A1(n562), .B0(DatCnt_3_), .B1(n563), .Y(
        n565) );
  XNOR2X1 U1_A_3 ( .A(DatCnt_3_), .B(carry12), .Y(DatCnt268_3_) );
  AO21X1 U339 ( .A0(DatCnt272_2_), .A1(n560), .B0(n564), .Y(n553) );
  AO22X1 U340 ( .A0(DatCnt268_2_), .A1(n562), .B0(DatCnt_2_), .B1(n563), .Y(
        n564) );
  XNOR2X1 U1_A_2 ( .A(DatCnt_2_), .B(carry13), .Y(DatCnt268_2_) );
  AO21X1 U341 ( .A0(DatCnt272_1_), .A1(n560), .B0(n561), .Y(n554) );
  AO22X1 U342 ( .A0(DatCnt268_1_), .A1(n562), .B0(DatCnt_1_), .B1(n563), .Y(
        n561) );
  XNOR2X1 U1_A_1 ( .A(DatCnt_1_), .B(DatCnt_0_), .Y(DatCnt268_1_) );
  OAI31X1 U343 ( .A0(n573), .A1(n11), .A2(IncRdCnt[7]), .B0(n575), .Y(n540) );
  OA22X1 U344 ( .A0(ReadEn), .A1(n598), .B0(n598), .B1(n577), .Y(n575) );
  INVX1 U345 ( .A(n11), .Y(n577) );
  AOI2BB2X1 U346 ( .A0N(n578), .A1N(n599), .B0(WrCnt[7]), .B1(n12), .Y(n579)
         );
  XOR2X1 U347 ( .A(n591), .B(n574), .Y(n539) );
  XOR2X1 U348 ( .A(ReadEn), .B(IncRdCnt[0]), .Y(n547) );
  AO22X1 U349 ( .A0(WrCnt[5]), .A1(n574), .B0(WrCnt104_5_), .B1(n578), .Y(n534) );
  AO22X1 U350 ( .A0(WrCnt[4]), .A1(n574), .B0(WrCnt104_4_), .B1(n578), .Y(n535) );
  AO22X1 U351 ( .A0(WrCnt[3]), .A1(n574), .B0(WrCnt104_3_), .B1(n578), .Y(n536) );
  AO22X1 U352 ( .A0(WrCnt[2]), .A1(n574), .B0(WrCnt104_2_), .B1(n578), .Y(n537) );
  AO22X1 U353 ( .A0(WrCnt[1]), .A1(n574), .B0(WrCnt104_1_), .B1(n578), .Y(n538) );
  DFFRX1 DatCnt_reg_0_ ( .D(n555), .CK(Clk), .RN(nRST), .Q(DatCnt_0_), .QN(
        n592) );
  DFFRX1 DatCnt_reg_3_ ( .D(n552), .CK(Clk), .RN(nRST), .Q(DatCnt_3_), .QN(
        n597) );
  DFFRX1 DatCnt_reg_1_ ( .D(n554), .CK(Clk), .RN(nRST), .Q(DatCnt_1_), .QN(
        n595) );
  DFFRX1 DatCnt_reg_5_ ( .D(n550), .CK(Clk), .RN(nRST), .Q(DatCnt_5_), .QN(
        n596) );
  DFFRX1 DatCnt_reg_2_ ( .D(n553), .CK(Clk), .RN(nRST), .Q(DatCnt_2_), .QN(
        n593) );
  DFFRX1 DatCnt_reg_7_ ( .D(n548), .CK(Clk), .RN(nRST), .Q(DatCnt_7_), .QN(
        n594) );
  DFFRX1 DatCnt_reg_6_ ( .D(n549), .CK(Clk), .RN(nRST), .Q(HFullFlag) );
  DFFRX1 DatCnt_reg_4_ ( .D(n551), .CK(Clk), .RN(nRST), .Q(DatCnt_4_) );
  DFFRX1 DelayReadEn_reg ( .D(ReadEn), .CK(Clk), .RN(nRST), .Q(n600) );
  DFFRX1 IncRdCnt_reg_0_ ( .D(n547), .CK(Clk), .RN(nRST), .Q(IncRdCnt[0]) );
  DFFRX1 IncRdCnt_reg_1_ ( .D(n546), .CK(Clk), .RN(nRST), .Q(IncRdCnt[1]) );
  DFFRX1 IncRdCnt_reg_3_ ( .D(n544), .CK(Clk), .RN(nRST), .Q(IncRdCnt[3]) );
  DFFRX1 IncRdCnt_reg_2_ ( .D(n545), .CK(Clk), .RN(nRST), .Q(IncRdCnt[2]) );
  DFFRX1 IncRdCnt_reg_7_ ( .D(n540), .CK(Clk), .RN(nRST), .Q(IncRdCnt[7]), 
        .QN(n598) );
  DFFRX1 IncRdCnt_reg_5_ ( .D(n542), .CK(Clk), .RN(nRST), .Q(IncRdCnt[5]) );
  DFFRX1 IncRdCnt_reg_6_ ( .D(n541), .CK(Clk), .RN(nRST), .Q(IncRdCnt[6]) );
  DFFRX1 IncRdCnt_reg_4_ ( .D(n543), .CK(Clk), .RN(nRST), .Q(IncRdCnt[4]) );
endmodule


module SDRWQ ( nRST, Clk, WriteEn, ReadEn, DelayReadEn, WrData, RdData, 
        FullFlag, HFullFlag, EmptyFlag, WrapCnt, IncRdCnt, AddrHold );
  input [35:0] WrData;
  output [35:0] RdData;
  input [5:0] WrapCnt;
  output [5:0] IncRdCnt;
  input nRST, Clk, WriteEn, ReadEn, DelayReadEn, AddrHold;
  output FullFlag, HFullFlag, EmptyFlag;
  wire   n_157, n_158, WrCnt95_4_, WrCnt95_3_, WrCnt95_2_, WrCnt95_1_,
         IncRdCnt164_4_, IncRdCnt164_3_, IncRdCnt164_2_, IncRdCnt164_1_,
         DatCnt268_5_, DatCnt268_4_, DatCnt268_3_, DatCnt268_2_, DatCnt268_1_,
         DatCnt272_4_, DatCnt272_3_, DatCnt272_2_, DatCnt272_1_, n480, n481,
         n482, n483, n484, n485, n486, n487, n488, n489, n490, n491, n492,
         n493, n494, n495, n496, n497, carry, carry0, carry1, n12, n22, n32,
         n42, carry2, carry3, carry4, n11, n21, n31, n41, carry_5_, carry5,
         carry6, carry7, carry_4_, carry_3_, carry_2_, n1, n2, n3, n4, n499,
         n501, n502, n503, n504, n505, n506, n507, n508, n509, n510, n511,
         n513, n514, n515, n516, n518, n519, n522, n526, n527, n529, n530,
         n531, n532, n533, n534, n535, n536, n537, n538, n539, n540, n541,
         n542, n543, n544, n545, n546, n547, n548, n549, n550, n551, n552,
         n553, n554, n555, n556, n557, n558, n559, n560, n561, n562, n563,
         n564, n565, n566, n567, n568, n569, n570;
  wire   [5:0] DatCnt;
  wire   [5:0] WrCnt;

  RF2SH64x32 WQL ( .CENB(n_158), .AB(WrCnt), .DB({n531, n562, n561, n560, n559, 
        n558, n557, n556, n555, n554, n553, n552, n551, n550, n549, n548, n546, 
        n545, n544, n543, n542, n541, n540, n539, n538, n537, n536, n535, n534, 
        n533, n532, n547}), .CENA(n_157), .AA(WrapCnt), .CLKB(Clk), .CLKA(Clk), 
        .QA(RdData[31:0]) );
  RF2SH64x4 WQH ( .CENB(n_158), .AB(WrCnt), .DB(WrData[35:32]), .CENA(n_157), 
        .AA(WrapCnt), .CLKB(Clk), .CLKA(Clk), .QA(RdData[35:32]) );
  AHHCONX2 U1_1_12 ( .A(WrCnt[1]), .CI(WrCnt[0]), .S(WrCnt95_1_), .CON(n42) );
  AHHCONX2 U1_1_22 ( .A(WrCnt[2]), .CI(carry1), .S(WrCnt95_2_), .CON(n32) );
  AHHCONX2 U1_1_32 ( .A(WrCnt[3]), .CI(carry0), .S(WrCnt95_3_), .CON(n22) );
  AHHCONX2 U1_1_42 ( .A(WrCnt[4]), .CI(carry), .S(WrCnt95_4_), .CON(n12) );
  AHHCONX2 U1_1_11 ( .A(IncRdCnt[1]), .CI(IncRdCnt[0]), .S(IncRdCnt164_1_), 
        .CON(n41) );
  AHHCONX2 U1_1_21 ( .A(IncRdCnt[2]), .CI(carry4), .S(IncRdCnt164_2_), .CON(
        n31) );
  AHHCONX2 U1_1_31 ( .A(IncRdCnt[3]), .CI(carry3), .S(IncRdCnt164_3_), .CON(
        n21) );
  AHHCONX2 U1_1_41 ( .A(IncRdCnt[4]), .CI(carry2), .S(IncRdCnt164_4_), .CON(
        n11) );
  AHHCONX2 U1_1_1 ( .A(DatCnt[1]), .CI(DatCnt[0]), .S(DatCnt272_1_), .CON(n4)
         );
  AHHCONX2 U1_1_2 ( .A(DatCnt[2]), .CI(carry_2_), .S(DatCnt272_2_), .CON(n3)
         );
  AHHCONX2 U1_1_3 ( .A(DatCnt[3]), .CI(carry_3_), .S(DatCnt272_3_), .CON(n2)
         );
  AHHCONX2 U1_1_4 ( .A(DatCnt[4]), .CI(carry_4_), .S(DatCnt272_4_), .CON(n1)
         );
  XOR2X4 U194 ( .A(n515), .B(WriteEn), .Y(n505) );
  BUFX2 U238 ( .A(WrData[31]), .Y(n531) );
  BUFX2 U239 ( .A(WrData[1]), .Y(n532) );
  BUFX2 U240 ( .A(WrData[2]), .Y(n533) );
  BUFX2 U241 ( .A(WrData[3]), .Y(n534) );
  BUFX2 U242 ( .A(WrData[4]), .Y(n535) );
  BUFX2 U243 ( .A(WrData[5]), .Y(n536) );
  BUFX2 U244 ( .A(WrData[6]), .Y(n537) );
  BUFX2 U245 ( .A(WrData[7]), .Y(n538) );
  BUFX2 U246 ( .A(WrData[8]), .Y(n539) );
  BUFX2 U247 ( .A(WrData[9]), .Y(n540) );
  BUFX2 U248 ( .A(WrData[10]), .Y(n541) );
  BUFX2 U249 ( .A(WrData[11]), .Y(n542) );
  BUFX2 U250 ( .A(WrData[12]), .Y(n543) );
  BUFX2 U251 ( .A(WrData[13]), .Y(n544) );
  BUFX2 U252 ( .A(WrData[14]), .Y(n545) );
  BUFX2 U253 ( .A(WrData[15]), .Y(n546) );
  BUFX2 U254 ( .A(WrData[0]), .Y(n547) );
  BUFX2 U255 ( .A(WrData[16]), .Y(n548) );
  BUFX2 U256 ( .A(WrData[17]), .Y(n549) );
  BUFX2 U257 ( .A(WrData[18]), .Y(n550) );
  BUFX2 U258 ( .A(WrData[19]), .Y(n551) );
  BUFX2 U259 ( .A(WrData[20]), .Y(n552) );
  BUFX2 U260 ( .A(WrData[21]), .Y(n553) );
  BUFX2 U261 ( .A(WrData[22]), .Y(n554) );
  BUFX2 U262 ( .A(WrData[23]), .Y(n555) );
  BUFX2 U263 ( .A(WrData[24]), .Y(n556) );
  BUFX2 U264 ( .A(WrData[25]), .Y(n557) );
  BUFX2 U265 ( .A(WrData[26]), .Y(n558) );
  BUFX2 U266 ( .A(WrData[27]), .Y(n559) );
  BUFX2 U267 ( .A(WrData[28]), .Y(n560) );
  BUFX2 U268 ( .A(WrData[29]), .Y(n561) );
  BUFX2 U269 ( .A(WrData[30]), .Y(n562) );
  NAND2BX1 U270 ( .AN(n514), .B(n499), .Y(n502) );
  DFFRX1 WrCnt_reg_5_ ( .D(n480), .CK(Clk), .RN(nRST), .Q(WrCnt[5]), .QN(n570)
         );
  DFFRX1 WrCnt_reg_4_ ( .D(n481), .CK(Clk), .RN(nRST), .Q(WrCnt[4]) );
  DFFRX1 WrCnt_reg_3_ ( .D(n482), .CK(Clk), .RN(nRST), .Q(WrCnt[3]) );
  DFFRX1 WrCnt_reg_2_ ( .D(n483), .CK(Clk), .RN(nRST), .Q(WrCnt[2]) );
  DFFRX1 WrCnt_reg_1_ ( .D(n484), .CK(Clk), .RN(nRST), .Q(WrCnt[1]) );
  DFFRX1 WrCnt_reg_0_ ( .D(n485), .CK(Clk), .RN(nRST), .Q(WrCnt[0]) );
  INVX1 U271 ( .A(n505), .Y(n499) );
  AOI2BB2X1 U272 ( .A0N(WriteEn), .A1N(n570), .B0(WrCnt[5]), .B1(n12), .Y(n519) );
  INVX1 U273 ( .A(n502), .Y(n503) );
  INVX1 U274 ( .A(n501), .Y(n506) );
  INVX1 U275 ( .A(WriteEn), .Y(n_158) );
  NAND2BX1 U276 ( .AN(n515), .B(n499), .Y(n501) );
  INVX1 U277 ( .A(n515), .Y(n514) );
  AND4X1 U278 ( .A(n565), .B(n563), .C(n564), .D(n567), .Y(n529) );
  INVX1 U279 ( .A(n1), .Y(n513) );
  NAND2BX1 U280 ( .AN(AddrHold), .B(ReadEn), .Y(n515) );
  XOR2X1 U281 ( .A(WriteEn), .B(WrCnt[0]), .Y(n485) );
  AND4X1 U282 ( .A(n527), .B(n568), .C(n566), .D(n529), .Y(EmptyFlag) );
  INVX1 U283 ( .A(AddrHold), .Y(n527) );
  OAI222X1 U284 ( .A0(n499), .A1(n566), .B0(DatCnt[0]), .B1(n501), .C0(
        DatCnt[0]), .C1(n502), .Y(n497) );
  NAND2BX1 U285 ( .AN(n510), .B(n511), .Y(n492) );
  AO22X1 U286 ( .A0(DatCnt[5]), .A1(n505), .B0(DatCnt268_5_), .B1(n506), .Y(
        n510) );
  AOI33X1 U287 ( .A0(n567), .A1(n513), .A2(n503), .B0(DatCnt[5]), .B1(n1), 
        .B2(n503), .Y(n511) );
  XNOR2X1 U1_A_5 ( .A(DatCnt[5]), .B(carry_5_), .Y(DatCnt268_5_) );
  AO22X1 U288 ( .A0(WrCnt[4]), .A1(n_158), .B0(WrCnt95_4_), .B1(WriteEn), .Y(
        n481) );
  AO22X1 U289 ( .A0(WrCnt[3]), .A1(n_158), .B0(WrCnt95_3_), .B1(WriteEn), .Y(
        n482) );
  AO22X1 U290 ( .A0(WrCnt[2]), .A1(n_158), .B0(WrCnt95_2_), .B1(WriteEn), .Y(
        n483) );
  AO22X1 U291 ( .A0(WrCnt[1]), .A1(n_158), .B0(WrCnt95_1_), .B1(WriteEn), .Y(
        n484) );
  AO21X1 U292 ( .A0(DatCnt272_4_), .A1(n503), .B0(n509), .Y(n493) );
  AO22X1 U293 ( .A0(DatCnt[4]), .A1(n505), .B0(DatCnt268_4_), .B1(n506), .Y(
        n509) );
  XNOR2X1 U1_A_4 ( .A(DatCnt[4]), .B(carry5), .Y(DatCnt268_4_) );
  AO21X1 U294 ( .A0(DatCnt272_3_), .A1(n503), .B0(n508), .Y(n494) );
  AO22X1 U295 ( .A0(DatCnt[3]), .A1(n505), .B0(DatCnt268_3_), .B1(n506), .Y(
        n508) );
  XNOR2X1 U1_A_3 ( .A(DatCnt[3]), .B(carry6), .Y(DatCnt268_3_) );
  AO21X1 U296 ( .A0(DatCnt272_2_), .A1(n503), .B0(n507), .Y(n495) );
  AO22X1 U297 ( .A0(DatCnt[2]), .A1(n505), .B0(DatCnt268_2_), .B1(n506), .Y(
        n507) );
  XNOR2X1 U1_A_2 ( .A(DatCnt[2]), .B(carry7), .Y(DatCnt268_2_) );
  AO21X1 U298 ( .A0(DatCnt272_1_), .A1(n503), .B0(n504), .Y(n496) );
  AO22X1 U299 ( .A0(DatCnt[1]), .A1(n505), .B0(DatCnt268_1_), .B1(n506), .Y(
        n504) );
  XNOR2X1 U1_A_1 ( .A(DatCnt[1]), .B(DatCnt[0]), .Y(DatCnt268_1_) );
  OAI31X1 U300 ( .A0(n_158), .A1(n12), .A2(WrCnt[5]), .B0(n519), .Y(n480) );
  NOR4BX1 U301 ( .AN(HFullFlag), .B(n522), .C(n563), .D(n564), .Y(FullFlag) );
  NAND3BX1 U302 ( .AN(n565), .B(DatCnt[1]), .C(DatCnt[0]), .Y(n522) );
  INVX1 U303 ( .A(n526), .Y(HFullFlag) );
  NAND2BX1 U304 ( .AN(AddrHold), .B(DatCnt[5]), .Y(n526) );
  XOR2X1 U305 ( .A(n530), .B(n515), .Y(n491) );
  NOR2X1 U306 ( .A(ReadEn), .B(DelayReadEn), .Y(n_157) );
  AO22X1 U307 ( .A0(IncRdCnt[4]), .A1(n515), .B0(IncRdCnt164_4_), .B1(n514), 
        .Y(n487) );
  AO22X1 U308 ( .A0(IncRdCnt[3]), .A1(n515), .B0(IncRdCnt164_3_), .B1(n514), 
        .Y(n488) );
  AO22X1 U309 ( .A0(IncRdCnt[2]), .A1(n515), .B0(IncRdCnt164_2_), .B1(n514), 
        .Y(n489) );
  AO22X1 U310 ( .A0(IncRdCnt[1]), .A1(n515), .B0(IncRdCnt164_1_), .B1(n514), 
        .Y(n490) );
  OAI31X1 U311 ( .A0(n515), .A1(n11), .A2(IncRdCnt[5]), .B0(n516), .Y(n486) );
  OA22X1 U312 ( .A0(n569), .A1(n518), .B0(n514), .B1(n569), .Y(n516) );
  INVX1 U313 ( .A(n11), .Y(n518) );
  INVX1 U314 ( .A(n22), .Y(carry) );
  INVX1 U315 ( .A(n21), .Y(carry2) );
  INVX1 U316 ( .A(n2), .Y(carry_4_) );
  INVX1 U317 ( .A(n4), .Y(carry_2_) );
  INVX1 U318 ( .A(n42), .Y(carry1) );
  INVX1 U319 ( .A(n41), .Y(carry4) );
  INVX1 U320 ( .A(n32), .Y(carry0) );
  INVX1 U321 ( .A(n31), .Y(carry3) );
  INVX1 U322 ( .A(n3), .Y(carry_3_) );
  OR2X1 U1_B_1 ( .A(DatCnt[1]), .B(DatCnt[0]), .Y(carry7) );
  OR2X1 U1_B_2 ( .A(DatCnt[2]), .B(carry7), .Y(carry6) );
  OR2X1 U1_B_3 ( .A(DatCnt[3]), .B(carry6), .Y(carry5) );
  OR2X1 U1_B_4 ( .A(DatCnt[4]), .B(carry5), .Y(carry_5_) );
  DFFRX1 DatCnt_reg_0_ ( .D(n497), .CK(Clk), .RN(nRST), .Q(DatCnt[0]), .QN(
        n566) );
  DFFRX1 DatCnt_reg_1_ ( .D(n496), .CK(Clk), .RN(nRST), .Q(DatCnt[1]), .QN(
        n568) );
  DFFRX1 DatCnt_reg_4_ ( .D(n493), .CK(Clk), .RN(nRST), .Q(DatCnt[4]), .QN(
        n564) );
  DFFRX1 DatCnt_reg_3_ ( .D(n494), .CK(Clk), .RN(nRST), .Q(DatCnt[3]), .QN(
        n563) );
  DFFRX1 DatCnt_reg_2_ ( .D(n495), .CK(Clk), .RN(nRST), .Q(DatCnt[2]), .QN(
        n565) );
  DFFRX1 DatCnt_reg_5_ ( .D(n492), .CK(Clk), .RN(nRST), .Q(DatCnt[5]), .QN(
        n567) );
  DFFRX1 IncRdCnt_reg_0_ ( .D(n491), .CK(Clk), .RN(nRST), .Q(IncRdCnt[0]), 
        .QN(n530) );
  DFFRX1 IncRdCnt_reg_3_ ( .D(n488), .CK(Clk), .RN(nRST), .Q(IncRdCnt[3]) );
  DFFRX1 IncRdCnt_reg_2_ ( .D(n489), .CK(Clk), .RN(nRST), .Q(IncRdCnt[2]) );
  DFFRX1 IncRdCnt_reg_1_ ( .D(n490), .CK(Clk), .RN(nRST), .Q(IncRdCnt[1]) );
  DFFRX1 IncRdCnt_reg_5_ ( .D(n486), .CK(Clk), .RN(nRST), .Q(IncRdCnt[5]), 
        .QN(n569) );
  DFFRX1 IncRdCnt_reg_4_ ( .D(n487), .CK(Clk), .RN(nRST), .Q(IncRdCnt[4]) );
endmodule


module SDRRDS ( ACLK, ARESETn, INFORMATION_S, VALID_S, READY_S, INFORMATION_R, 
        VALID_R, READY_R );
  input [38:0] INFORMATION_S;
  output [38:0] INFORMATION_R;
  input ACLK, ARESETn, VALID_S, READY_R;
  output READY_S, VALID_R;
  wire   que_len, n557, n558, n559, n560, n561, n562, n563, n564, n565, n566,
         n567, n568, n569, n570, n571, n572, n573, n574, n575, n576, n577,
         n578, n579, n580, n581, n582, n583, n584, n585, n586, n587, n588,
         n589, n590, n591, n592, n593, n594, n595, n596, n597, n598, n599,
         n600, n601, n602, n603, n604, n605, n606, n607, n608, n609, n610,
         n611, n612, n613, n614, n615, n616, n617, n618, n619, n620, n621,
         n622, n623, n624, n625, n626, n627, n628, n629, n630, n631, n632,
         n633, n634, n635, n636, n637, n638, n639, n640, n641, n642, n643,
         n644, n645, n646, n647, n648, n649, n650, n651, n652, n653, n654,
         n655, n656, n657, n658, n659, n660, n661, n662, n663, n664, n665,
         n666, n667, n668, n669, n670, n671, n672, n673, n674, n675, n685,
         n687, n688, n690, n691, n692, n693, n695, n697, n699, n701, n703,
         n705, n707, n709, n711, n713, n715, n717, n719, n721, n723, n725,
         n727, n729, n731, n733, n735, n737, n739, n741, n743, n745, n747,
         n749, n751, n753, n755, n757, n759, n761, n763, n765, n767, n769,
         n770, n771, n772, n773, n774, n775, n776, n777, n778, n779, n780,
         n781, n782, n783, n784, n785, n786, n787, n788, n789, n790, n791,
         n792, n793, n794, n795, n796, n797, n798, n799, n800, n801, n802,
         n803, n804, n805, n806, n807, n808, n809, n810, n811, n812, n813,
         n814, n815, n816, n817, n818;
  wire   [38:0] INFORMATION_1;

  AO21X4 U576 ( .A0(n770), .A1(n771), .B0(READY_R), .Y(n812) );
  AO21X2 U577 ( .A0(n770), .A1(n771), .B0(READY_R), .Y(n693) );
  INVX1 U578 ( .A(n817), .Y(n688) );
  NAND2BX1 U579 ( .AN(n771), .B(n693), .Y(n690) );
  NAND2BX1 U580 ( .AN(n771), .B(n812), .Y(n814) );
  NAND2BX1 U581 ( .AN(n771), .B(n812), .Y(n813) );
  NAND2BX1 U582 ( .AN(n685), .B(READY_S), .Y(n817) );
  NAND2BX1 U583 ( .AN(n685), .B(READY_S), .Y(n687) );
  NAND2BX1 U584 ( .AN(n685), .B(READY_S), .Y(n818) );
  INVX1 U585 ( .A(VALID_S), .Y(n685) );
  NAND2BX1 U586 ( .AN(que_len), .B(n693), .Y(n692) );
  NAND2BX1 U587 ( .AN(que_len), .B(n693), .Y(n816) );
  NAND2BX1 U588 ( .AN(que_len), .B(n812), .Y(n815) );
  OAI222X1 U589 ( .A0(n772), .A1(n813), .B0(n765), .B1(n815), .C0(n812), .C1(
        n586), .Y(n598) );
  INVX1 U590 ( .A(INFORMATION_S[36]), .Y(n765) );
  OAI222X1 U591 ( .A0(n773), .A1(n690), .B0(n769), .B1(n692), .C0(n693), .C1(
        n588), .Y(n596) );
  INVX1 U592 ( .A(INFORMATION_S[38]), .Y(n769) );
  OAI222X1 U593 ( .A0(n774), .A1(n814), .B0(n767), .B1(n816), .C0(n812), .C1(
        n587), .Y(n597) );
  INVX1 U594 ( .A(INFORMATION_S[37]), .Y(n767) );
  OAI222X1 U595 ( .A0(n775), .A1(n690), .B0(n763), .B1(n692), .C0(n693), .C1(
        n585), .Y(n599) );
  INVX1 U596 ( .A(INFORMATION_S[35]), .Y(n763) );
  OAI222X1 U597 ( .A0(n776), .A1(n814), .B0(n761), .B1(n816), .C0(n812), .C1(
        n584), .Y(n600) );
  INVX1 U598 ( .A(INFORMATION_S[34]), .Y(n761) );
  OAI222X1 U599 ( .A0(n777), .A1(n813), .B0(n759), .B1(n815), .C0(n812), .C1(
        n583), .Y(n601) );
  INVX1 U600 ( .A(INFORMATION_S[33]), .Y(n759) );
  OAI222X1 U601 ( .A0(n778), .A1(n690), .B0(n757), .B1(n692), .C0(n693), .C1(
        n582), .Y(n602) );
  INVX1 U602 ( .A(INFORMATION_S[32]), .Y(n757) );
  OAI222X1 U603 ( .A0(n779), .A1(n814), .B0(n755), .B1(n816), .C0(n693), .C1(
        n581), .Y(n603) );
  INVX1 U604 ( .A(INFORMATION_S[31]), .Y(n755) );
  OAI222X1 U605 ( .A0(n780), .A1(n813), .B0(n753), .B1(n815), .C0(n812), .C1(
        n580), .Y(n604) );
  INVX1 U606 ( .A(INFORMATION_S[30]), .Y(n753) );
  OAI222X1 U607 ( .A0(n781), .A1(n690), .B0(n751), .B1(n692), .C0(n693), .C1(
        n578), .Y(n605) );
  INVX1 U608 ( .A(INFORMATION_S[29]), .Y(n751) );
  OAI222X1 U609 ( .A0(n782), .A1(n814), .B0(n749), .B1(n816), .C0(n693), .C1(
        n577), .Y(n606) );
  INVX1 U610 ( .A(INFORMATION_S[28]), .Y(n749) );
  OAI222X1 U611 ( .A0(n783), .A1(n813), .B0(n747), .B1(n815), .C0(n812), .C1(
        n576), .Y(n607) );
  INVX1 U612 ( .A(INFORMATION_S[27]), .Y(n747) );
  OAI222X1 U613 ( .A0(n784), .A1(n690), .B0(n745), .B1(n692), .C0(n693), .C1(
        n575), .Y(n608) );
  INVX1 U614 ( .A(INFORMATION_S[26]), .Y(n745) );
  OAI222X1 U615 ( .A0(n785), .A1(n814), .B0(n743), .B1(n816), .C0(n812), .C1(
        n574), .Y(n609) );
  INVX1 U616 ( .A(INFORMATION_S[25]), .Y(n743) );
  OAI222X1 U617 ( .A0(n786), .A1(n813), .B0(n741), .B1(n815), .C0(n812), .C1(
        n573), .Y(n610) );
  INVX1 U618 ( .A(INFORMATION_S[24]), .Y(n741) );
  OAI222X1 U619 ( .A0(n787), .A1(n690), .B0(n739), .B1(n692), .C0(n693), .C1(
        n572), .Y(n611) );
  INVX1 U620 ( .A(INFORMATION_S[23]), .Y(n739) );
  OAI222X1 U621 ( .A0(n788), .A1(n814), .B0(n737), .B1(n816), .C0(n693), .C1(
        n571), .Y(n612) );
  INVX1 U622 ( .A(INFORMATION_S[22]), .Y(n737) );
  OAI222X1 U623 ( .A0(n789), .A1(n813), .B0(n735), .B1(n815), .C0(n812), .C1(
        n570), .Y(n613) );
  INVX1 U624 ( .A(INFORMATION_S[21]), .Y(n735) );
  OAI222X1 U625 ( .A0(n790), .A1(n690), .B0(n733), .B1(n692), .C0(n693), .C1(
        n569), .Y(n614) );
  INVX1 U626 ( .A(INFORMATION_S[20]), .Y(n733) );
  OAI222X1 U627 ( .A0(n791), .A1(n814), .B0(n731), .B1(n816), .C0(n812), .C1(
        n567), .Y(n615) );
  INVX1 U628 ( .A(INFORMATION_S[19]), .Y(n731) );
  OAI222X1 U629 ( .A0(n792), .A1(n813), .B0(n729), .B1(n815), .C0(n812), .C1(
        n566), .Y(n616) );
  INVX1 U630 ( .A(INFORMATION_S[18]), .Y(n729) );
  OAI222X1 U631 ( .A0(n793), .A1(n690), .B0(n727), .B1(n692), .C0(n693), .C1(
        n565), .Y(n617) );
  INVX1 U632 ( .A(INFORMATION_S[17]), .Y(n727) );
  OAI222X1 U633 ( .A0(n794), .A1(n814), .B0(n725), .B1(n816), .C0(n812), .C1(
        n564), .Y(n618) );
  INVX1 U634 ( .A(INFORMATION_S[16]), .Y(n725) );
  OAI222X1 U635 ( .A0(n795), .A1(n813), .B0(n723), .B1(n815), .C0(n812), .C1(
        n563), .Y(n619) );
  INVX1 U636 ( .A(INFORMATION_S[15]), .Y(n723) );
  OAI222X1 U637 ( .A0(n796), .A1(n690), .B0(n721), .B1(n692), .C0(n693), .C1(
        n562), .Y(n620) );
  INVX1 U638 ( .A(INFORMATION_S[14]), .Y(n721) );
  OAI222X1 U639 ( .A0(n797), .A1(n814), .B0(n719), .B1(n816), .C0(n812), .C1(
        n561), .Y(n621) );
  INVX1 U640 ( .A(INFORMATION_S[13]), .Y(n719) );
  OAI222X1 U641 ( .A0(n798), .A1(n813), .B0(n717), .B1(n815), .C0(n812), .C1(
        n560), .Y(n622) );
  INVX1 U642 ( .A(INFORMATION_S[12]), .Y(n717) );
  OAI222X1 U643 ( .A0(n799), .A1(n690), .B0(n715), .B1(n692), .C0(n693), .C1(
        n559), .Y(n623) );
  INVX1 U644 ( .A(INFORMATION_S[11]), .Y(n715) );
  OAI222X1 U645 ( .A0(n800), .A1(n814), .B0(n713), .B1(n816), .C0(n693), .C1(
        n558), .Y(n624) );
  INVX1 U646 ( .A(INFORMATION_S[10]), .Y(n713) );
  OAI222X1 U647 ( .A0(n801), .A1(n813), .B0(n711), .B1(n815), .C0(n812), .C1(
        n595), .Y(n625) );
  INVX1 U648 ( .A(INFORMATION_S[9]), .Y(n711) );
  OAI222X1 U649 ( .A0(n802), .A1(n690), .B0(n709), .B1(n692), .C0(n693), .C1(
        n594), .Y(n626) );
  INVX1 U650 ( .A(INFORMATION_S[8]), .Y(n709) );
  OAI222X1 U651 ( .A0(n803), .A1(n814), .B0(n707), .B1(n816), .C0(n693), .C1(
        n593), .Y(n627) );
  INVX1 U652 ( .A(INFORMATION_S[7]), .Y(n707) );
  OAI222X1 U653 ( .A0(n804), .A1(n813), .B0(n705), .B1(n815), .C0(n812), .C1(
        n592), .Y(n628) );
  INVX1 U654 ( .A(INFORMATION_S[6]), .Y(n705) );
  OAI222X1 U655 ( .A0(n805), .A1(n690), .B0(n703), .B1(n692), .C0(n693), .C1(
        n591), .Y(n629) );
  INVX1 U656 ( .A(INFORMATION_S[5]), .Y(n703) );
  OAI222X1 U657 ( .A0(n806), .A1(n814), .B0(n701), .B1(n816), .C0(n812), .C1(
        n590), .Y(n630) );
  INVX1 U658 ( .A(INFORMATION_S[4]), .Y(n701) );
  OAI222X1 U659 ( .A0(n807), .A1(n813), .B0(n699), .B1(n815), .C0(n812), .C1(
        n589), .Y(n631) );
  INVX1 U660 ( .A(INFORMATION_S[3]), .Y(n699) );
  OAI222X1 U661 ( .A0(n808), .A1(n690), .B0(n697), .B1(n692), .C0(n693), .C1(
        n579), .Y(n632) );
  INVX1 U662 ( .A(INFORMATION_S[2]), .Y(n697) );
  OAI222X1 U663 ( .A0(n809), .A1(n814), .B0(n695), .B1(n816), .C0(n693), .C1(
        n568), .Y(n633) );
  INVX1 U664 ( .A(INFORMATION_S[1]), .Y(n695) );
  OAI222X1 U665 ( .A0(n810), .A1(n813), .B0(n691), .B1(n815), .C0(n812), .C1(
        n557), .Y(n634) );
  INVX1 U666 ( .A(INFORMATION_S[0]), .Y(n691) );
  AO22X1 U667 ( .A0(INFORMATION_1[35]), .A1(n687), .B0(INFORMATION_S[35]), 
        .B1(n688), .Y(n638) );
  AO22X1 U668 ( .A0(INFORMATION_1[34]), .A1(n818), .B0(INFORMATION_S[34]), 
        .B1(n688), .Y(n639) );
  AO22X1 U669 ( .A0(INFORMATION_1[33]), .A1(n817), .B0(INFORMATION_S[33]), 
        .B1(n688), .Y(n640) );
  AO22X1 U670 ( .A0(INFORMATION_1[32]), .A1(n687), .B0(INFORMATION_S[32]), 
        .B1(n688), .Y(n641) );
  AO22X1 U671 ( .A0(INFORMATION_1[31]), .A1(n818), .B0(INFORMATION_S[31]), 
        .B1(n688), .Y(n642) );
  AO22X1 U672 ( .A0(INFORMATION_1[30]), .A1(n817), .B0(INFORMATION_S[30]), 
        .B1(n688), .Y(n643) );
  AO22X1 U673 ( .A0(INFORMATION_1[29]), .A1(n687), .B0(INFORMATION_S[29]), 
        .B1(n688), .Y(n644) );
  AO22X1 U674 ( .A0(INFORMATION_1[28]), .A1(n818), .B0(INFORMATION_S[28]), 
        .B1(n688), .Y(n645) );
  AO22X1 U675 ( .A0(INFORMATION_1[27]), .A1(n817), .B0(INFORMATION_S[27]), 
        .B1(n688), .Y(n646) );
  AO22X1 U676 ( .A0(INFORMATION_1[26]), .A1(n687), .B0(INFORMATION_S[26]), 
        .B1(n688), .Y(n647) );
  AO22X1 U677 ( .A0(INFORMATION_1[25]), .A1(n818), .B0(INFORMATION_S[25]), 
        .B1(n688), .Y(n648) );
  AO22X1 U678 ( .A0(INFORMATION_1[24]), .A1(n817), .B0(INFORMATION_S[24]), 
        .B1(n688), .Y(n649) );
  AO22X1 U679 ( .A0(INFORMATION_1[23]), .A1(n687), .B0(INFORMATION_S[23]), 
        .B1(n688), .Y(n650) );
  AO22X1 U680 ( .A0(INFORMATION_1[22]), .A1(n818), .B0(INFORMATION_S[22]), 
        .B1(n688), .Y(n651) );
  AO22X1 U681 ( .A0(INFORMATION_1[21]), .A1(n817), .B0(INFORMATION_S[21]), 
        .B1(n688), .Y(n652) );
  AO22X1 U682 ( .A0(INFORMATION_1[20]), .A1(n687), .B0(INFORMATION_S[20]), 
        .B1(n688), .Y(n653) );
  AO22X1 U683 ( .A0(INFORMATION_1[19]), .A1(n818), .B0(INFORMATION_S[19]), 
        .B1(n688), .Y(n654) );
  AO22X1 U684 ( .A0(INFORMATION_1[18]), .A1(n817), .B0(INFORMATION_S[18]), 
        .B1(n688), .Y(n655) );
  AO22X1 U685 ( .A0(INFORMATION_1[17]), .A1(n687), .B0(INFORMATION_S[17]), 
        .B1(n688), .Y(n656) );
  AO22X1 U686 ( .A0(INFORMATION_1[16]), .A1(n818), .B0(INFORMATION_S[16]), 
        .B1(n688), .Y(n657) );
  AO22X1 U687 ( .A0(INFORMATION_1[15]), .A1(n687), .B0(INFORMATION_S[15]), 
        .B1(n688), .Y(n658) );
  AO22X1 U688 ( .A0(INFORMATION_1[14]), .A1(n687), .B0(INFORMATION_S[14]), 
        .B1(n688), .Y(n659) );
  AO22X1 U689 ( .A0(INFORMATION_1[13]), .A1(n818), .B0(INFORMATION_S[13]), 
        .B1(n688), .Y(n660) );
  AO22X1 U690 ( .A0(INFORMATION_1[12]), .A1(n818), .B0(INFORMATION_S[12]), 
        .B1(n688), .Y(n661) );
  AO22X1 U691 ( .A0(INFORMATION_1[11]), .A1(n687), .B0(INFORMATION_S[11]), 
        .B1(n688), .Y(n662) );
  AO22X1 U692 ( .A0(INFORMATION_1[10]), .A1(n818), .B0(INFORMATION_S[10]), 
        .B1(n688), .Y(n663) );
  AO22X1 U693 ( .A0(INFORMATION_1[9]), .A1(n687), .B0(INFORMATION_S[9]), .B1(
        n688), .Y(n664) );
  AO22X1 U694 ( .A0(INFORMATION_1[8]), .A1(n687), .B0(INFORMATION_S[8]), .B1(
        n688), .Y(n665) );
  AO22X1 U695 ( .A0(INFORMATION_1[7]), .A1(n818), .B0(INFORMATION_S[7]), .B1(
        n688), .Y(n666) );
  AO22X1 U696 ( .A0(INFORMATION_1[6]), .A1(n818), .B0(INFORMATION_S[6]), .B1(
        n688), .Y(n667) );
  AO22X1 U697 ( .A0(INFORMATION_1[5]), .A1(n687), .B0(INFORMATION_S[5]), .B1(
        n688), .Y(n668) );
  AO22X1 U698 ( .A0(INFORMATION_1[4]), .A1(n818), .B0(INFORMATION_S[4]), .B1(
        n688), .Y(n669) );
  OAI32X1 U699 ( .A0(n770), .A1(READY_R), .A2(n685), .B0(READY_R), .B1(n771), 
        .Y(n675) );
  OAI221X1 U700 ( .A0(READY_R), .A1(n770), .B0(n770), .B1(n771), .C0(n685), 
        .Y(n674) );
  NAND2X1 U701 ( .A(n811), .B(que_len), .Y(READY_S) );
  AO22X1 U702 ( .A0(INFORMATION_1[3]), .A1(n687), .B0(INFORMATION_S[3]), .B1(
        n688), .Y(n670) );
  AO22X1 U703 ( .A0(INFORMATION_1[2]), .A1(n687), .B0(INFORMATION_S[2]), .B1(
        n688), .Y(n671) );
  AO22X1 U704 ( .A0(INFORMATION_1[1]), .A1(n818), .B0(INFORMATION_S[1]), .B1(
        n688), .Y(n672) );
  AO22X1 U705 ( .A0(INFORMATION_1[0]), .A1(n818), .B0(INFORMATION_S[0]), .B1(
        n688), .Y(n673) );
  AO22X1 U706 ( .A0(INFORMATION_1[36]), .A1(n817), .B0(INFORMATION_S[36]), 
        .B1(n688), .Y(n637) );
  AO22X1 U707 ( .A0(INFORMATION_1[38]), .A1(n687), .B0(INFORMATION_S[38]), 
        .B1(n688), .Y(n635) );
  AO22X1 U708 ( .A0(INFORMATION_1[37]), .A1(n818), .B0(INFORMATION_S[37]), 
        .B1(n688), .Y(n636) );
  DFFRX1 que_len_reg ( .D(n675), .CK(ACLK), .RN(ARESETn), .Q(que_len), .QN(
        n771) );
  DFFSX1 ready_r_ff_reg ( .D(READY_R), .CK(ACLK), .SN(ARESETn), .QN(n811) );
  DFFRX1 VALID_R_reg ( .D(n674), .CK(ACLK), .RN(ARESETn), .Q(VALID_R), .QN(
        n770) );
  DFFRX1 INFORMATION_0_reg_38_ ( .D(n596), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[38]), .QN(n588) );
  DFFRX1 INFORMATION_0_reg_37_ ( .D(n597), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[37]), .QN(n587) );
  DFFRX1 INFORMATION_0_reg_36_ ( .D(n598), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[36]), .QN(n586) );
  DFFRX1 INFORMATION_0_reg_35_ ( .D(n599), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[35]), .QN(n585) );
  DFFRX1 INFORMATION_0_reg_34_ ( .D(n600), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[34]), .QN(n584) );
  DFFRX1 INFORMATION_0_reg_33_ ( .D(n601), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[33]), .QN(n583) );
  DFFRX1 INFORMATION_0_reg_32_ ( .D(n602), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[32]), .QN(n582) );
  DFFRX1 INFORMATION_0_reg_31_ ( .D(n603), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[31]), .QN(n581) );
  DFFRX1 INFORMATION_0_reg_30_ ( .D(n604), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[30]), .QN(n580) );
  DFFRX1 INFORMATION_0_reg_29_ ( .D(n605), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[29]), .QN(n578) );
  DFFRX1 INFORMATION_0_reg_28_ ( .D(n606), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[28]), .QN(n577) );
  DFFRX1 INFORMATION_0_reg_27_ ( .D(n607), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[27]), .QN(n576) );
  DFFRX1 INFORMATION_0_reg_26_ ( .D(n608), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[26]), .QN(n575) );
  DFFRX1 INFORMATION_0_reg_25_ ( .D(n609), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[25]), .QN(n574) );
  DFFRX1 INFORMATION_0_reg_24_ ( .D(n610), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[24]), .QN(n573) );
  DFFRX1 INFORMATION_0_reg_23_ ( .D(n611), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[23]), .QN(n572) );
  DFFRX1 INFORMATION_0_reg_22_ ( .D(n612), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[22]), .QN(n571) );
  DFFRX1 INFORMATION_0_reg_21_ ( .D(n613), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[21]), .QN(n570) );
  DFFRX1 INFORMATION_0_reg_20_ ( .D(n614), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[20]), .QN(n569) );
  DFFRX1 INFORMATION_0_reg_19_ ( .D(n615), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[19]), .QN(n567) );
  DFFRX1 INFORMATION_0_reg_18_ ( .D(n616), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[18]), .QN(n566) );
  DFFRX1 INFORMATION_0_reg_17_ ( .D(n617), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[17]), .QN(n565) );
  DFFRX1 INFORMATION_0_reg_16_ ( .D(n618), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[16]), .QN(n564) );
  DFFRX1 INFORMATION_0_reg_15_ ( .D(n619), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[15]), .QN(n563) );
  DFFRX1 INFORMATION_0_reg_14_ ( .D(n620), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[14]), .QN(n562) );
  DFFRX1 INFORMATION_0_reg_13_ ( .D(n621), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[13]), .QN(n561) );
  DFFRX1 INFORMATION_0_reg_12_ ( .D(n622), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[12]), .QN(n560) );
  DFFRX1 INFORMATION_0_reg_11_ ( .D(n623), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[11]), .QN(n559) );
  DFFRX1 INFORMATION_0_reg_10_ ( .D(n624), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[10]), .QN(n558) );
  DFFRX1 INFORMATION_0_reg_9_ ( .D(n625), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[9]), .QN(n595) );
  DFFRX1 INFORMATION_0_reg_8_ ( .D(n626), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[8]), .QN(n594) );
  DFFRX1 INFORMATION_0_reg_7_ ( .D(n627), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[7]), .QN(n593) );
  DFFRX1 INFORMATION_0_reg_6_ ( .D(n628), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[6]), .QN(n592) );
  DFFRX1 INFORMATION_0_reg_5_ ( .D(n629), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[5]), .QN(n591) );
  DFFRX1 INFORMATION_0_reg_4_ ( .D(n630), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[4]), .QN(n590) );
  DFFRX1 INFORMATION_0_reg_3_ ( .D(n631), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[3]), .QN(n589) );
  DFFRX1 INFORMATION_0_reg_2_ ( .D(n632), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[2]), .QN(n579) );
  DFFRX1 INFORMATION_0_reg_1_ ( .D(n633), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[1]), .QN(n568) );
  DFFRX1 INFORMATION_0_reg_0_ ( .D(n634), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_R[0]), .QN(n557) );
  DFFRX1 INFORMATION_1_reg_38_ ( .D(n635), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[38]), .QN(n773) );
  DFFRX1 INFORMATION_1_reg_37_ ( .D(n636), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[37]), .QN(n774) );
  DFFRX1 INFORMATION_1_reg_36_ ( .D(n637), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[36]), .QN(n772) );
  DFFRX1 INFORMATION_1_reg_35_ ( .D(n638), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[35]), .QN(n775) );
  DFFRX1 INFORMATION_1_reg_34_ ( .D(n639), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[34]), .QN(n776) );
  DFFRX1 INFORMATION_1_reg_33_ ( .D(n640), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[33]), .QN(n777) );
  DFFRX1 INFORMATION_1_reg_32_ ( .D(n641), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[32]), .QN(n778) );
  DFFRX1 INFORMATION_1_reg_31_ ( .D(n642), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[31]), .QN(n779) );
  DFFRX1 INFORMATION_1_reg_30_ ( .D(n643), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[30]), .QN(n780) );
  DFFRX1 INFORMATION_1_reg_29_ ( .D(n644), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[29]), .QN(n781) );
  DFFRX1 INFORMATION_1_reg_28_ ( .D(n645), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[28]), .QN(n782) );
  DFFRX1 INFORMATION_1_reg_27_ ( .D(n646), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[27]), .QN(n783) );
  DFFRX1 INFORMATION_1_reg_26_ ( .D(n647), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[26]), .QN(n784) );
  DFFRX1 INFORMATION_1_reg_25_ ( .D(n648), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[25]), .QN(n785) );
  DFFRX1 INFORMATION_1_reg_24_ ( .D(n649), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[24]), .QN(n786) );
  DFFRX1 INFORMATION_1_reg_23_ ( .D(n650), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[23]), .QN(n787) );
  DFFRX1 INFORMATION_1_reg_22_ ( .D(n651), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[22]), .QN(n788) );
  DFFRX1 INFORMATION_1_reg_21_ ( .D(n652), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[21]), .QN(n789) );
  DFFRX1 INFORMATION_1_reg_20_ ( .D(n653), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[20]), .QN(n790) );
  DFFRX1 INFORMATION_1_reg_19_ ( .D(n654), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[19]), .QN(n791) );
  DFFRX1 INFORMATION_1_reg_18_ ( .D(n655), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[18]), .QN(n792) );
  DFFRX1 INFORMATION_1_reg_17_ ( .D(n656), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[17]), .QN(n793) );
  DFFRX1 INFORMATION_1_reg_16_ ( .D(n657), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[16]), .QN(n794) );
  DFFRX1 INFORMATION_1_reg_15_ ( .D(n658), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[15]), .QN(n795) );
  DFFRX1 INFORMATION_1_reg_14_ ( .D(n659), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[14]), .QN(n796) );
  DFFRX1 INFORMATION_1_reg_13_ ( .D(n660), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[13]), .QN(n797) );
  DFFRX1 INFORMATION_1_reg_12_ ( .D(n661), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[12]), .QN(n798) );
  DFFRX1 INFORMATION_1_reg_11_ ( .D(n662), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[11]), .QN(n799) );
  DFFRX1 INFORMATION_1_reg_10_ ( .D(n663), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[10]), .QN(n800) );
  DFFRX1 INFORMATION_1_reg_9_ ( .D(n664), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[9]), .QN(n801) );
  DFFRX1 INFORMATION_1_reg_8_ ( .D(n665), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[8]), .QN(n802) );
  DFFRX1 INFORMATION_1_reg_7_ ( .D(n666), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[7]), .QN(n803) );
  DFFRX1 INFORMATION_1_reg_6_ ( .D(n667), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[6]), .QN(n804) );
  DFFRX1 INFORMATION_1_reg_5_ ( .D(n668), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[5]), .QN(n805) );
  DFFRX1 INFORMATION_1_reg_4_ ( .D(n669), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[4]), .QN(n806) );
  DFFRX1 INFORMATION_1_reg_3_ ( .D(n670), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[3]), .QN(n807) );
  DFFRX1 INFORMATION_1_reg_2_ ( .D(n671), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[2]), .QN(n808) );
  DFFRX1 INFORMATION_1_reg_1_ ( .D(n672), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[1]), .QN(n809) );
  DFFRX1 INFORMATION_1_reg_0_ ( .D(n673), .CK(ACLK), .RN(ARESETn), .Q(
        INFORMATION_1[0]), .QN(n810) );
endmodule

