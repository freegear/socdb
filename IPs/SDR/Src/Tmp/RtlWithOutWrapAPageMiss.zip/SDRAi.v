
`timescale 1ns/10ps

module SDRAi (
    		ARESETB,
    		PORESETB,
    		ACLK,
    		FCLK,
    		
			AWAddr,
			AWId,
			AWLen,
			AWValid,
			AWReady,
    		
    		WLast,
    		WStrb,
    		WData,
    		WValid,
    		WReady,
    		WId,
    		
    		BResp,
    		BValid,
    		BReady,
    		BId,
    		
			ARAddr,
			ARId,
			ARLen,
			ARValid,
			ARReady,
    		
    		RData,
    		RValid,
    		RReady,
    		RLast,
    		RId,
    		RResp,
    		
    		RQFull,
    		WQFull,
    		
    		BA_STS,
    		BA_AA,
    		BA_REQ,
    		BA_TT,
    		BA_RW,
    		BA_ID,
    		
    		SD_DQE,
    		SD_DQI,
    		SD_DQO,
    		SD_DQM
);

`include "../Rtl/SDRPara.v"

input    		ARESETB;  // asynchronous reset
input			PORESETB;
input    		ACLK;
input    		FCLK;

// Write Command
input  [AW:0]	AWAddr;
input  [ID:0] 	AWId;
input  [BL:0] 	AWLen;
input			AWValid;
output			AWReady;

// Write Data
input			WLast;
input  [BW:0] 	WStrb;
input  [ID:0] 	WId;
input  [DW:0] 	WData ; // data input
input			WValid;
output			WReady;

// Write Response
output [ID:0] 	BId;
output [1:0]	BResp;
input			BReady;
output			BValid;

// Read Command
input  [AW:0]	ARAddr;
input  [ID:0] 	ARId;
input  [BL:0] 	ARLen;
input			ARValid;
output			ARReady;

// Read Data
input			RReady;
output			RLast;
output          RValid;
output [DW:0] 	RData; // data output
output [ID:0] 	RId;
output [1:0]	RResp;

output			RQFull;
output			WQFull;

// Controller
input  [13:0]   BA_STS; // status
output [AW:0]	BA_AA;
output			BA_REQ;
output [BL:0]   BA_TT;
output [ID:0]	BA_ID;
output			BA_RW;

// SDRAM
output    		SD_DQE; // dq output enable
input  [DW:0]	SD_DQI; // data input
output [DW:0] 	SD_DQO; // data output
output [BW:0]	SD_DQM;
//-------------------------------------------------------------
//reg [ID:0] 		BId;

reg    			SD_DQE;
wire[DW:0]		SD_DQO;
wire[BW:0]		SD_DQM;

//reg 			RValid;
//reg [1:0] 		RResp;

reg        		ReadLatchEnFd;
reg [DW:0] 		RdDataMemFd;
reg [DW:0] 		RdDataMem;

reg        		iDelayReadFlag;
reg        		RdDataRdy;

reg        		iDelayReadLast;
reg				RdLastMem;

reg [ID:0] 		iDelayReadId;
reg [ID:0]		RdIdMem;

// Command Acknology
wire DiValid = BA_STS[0];
wire DoValid = BA_STS[1];
wire QueEmp  = BA_STS[2];	// RAS/CAS Queue Empty
wire QueFul  = BA_STS[3];	// RAS/CAS Queue Full
wire QueErr  = BA_STS[4];	// RAS/CAS Queue Error
wire RdLast  = BA_STS[5];
wire [ID:0] RdId = BA_STS[9:6];
wire [ID:0] WrId = BA_STS[13:10];

reg  AckQue;
always @(negedge ARESETB or posedge ACLK)
  	if (!ARESETB) AckQue <= 1'b0;
  	else          AckQue <= ~QueFul;

wire AWQWrite, AWQRead;
wire AWQFull;
wire AWQEmpty;
wire [AWQW:0]	AWQWrData = {AWId, AWLen, AWAddr};
wire [AWQW:0]	AWQRdData;

wire ARQWrite, ARQRead;
wire ARQFull;
wire ARQEmpty;
wire [ARQW:0]	ARQWrData = {ARId, ARLen, ARAddr};
wire [ARQW:0]	ARQRdData;

wire WQWrite, WQRead;
wire WQFull;
wire WQEmpty;
//wire [WQW:0]	WQWrData = {WId, ~WStrb, WData};
wire [WQW:0]	WQWrData = {~WStrb, WData};
wire [WQW:0]	WQRdData;

wire RQWrite, RQRead;
wire RQFull;
wire RQEmpty;
wire [RQW:0]	RQWrData = {RdIdMem, RdLastMem, RdDataMem};
wire [RQW:0]	RQRdData;

wire WrReqEn;
wire RdReqEn;
wire WriteAck;
wire ReadAck;
wire RespAck;

parameter W_IDLE = 2'b01;
parameter W_WREQ = 2'b10;

reg [1:0]  CurStW, NxtStW;

wire  tWIdle  = CurStW[0];
wire  tWWReq  = CurStW[1];

parameter S_IDLE = 2'b01;
parameter S_RESP = 2'b10;

reg [1:0]  CurStS, NxtStS;

wire  tSIdle  = CurStS[0];
wire  tSResp  = CurStS[1];

parameter R_IDLE = 2'b01;
parameter R_RREQ = 2'b10;

reg [1:0]  CurStR, NxtStR;

wire  tRIdle  = CurStR[0];
wire  tRRReq  = CurStR[1];
//-------------------------------------------------------------
// Write Command Path
wire    iAWReady = ~AWQFull & AWValid & ~WQFull;
assign  AWReady  =  iAWReady;

assign  AWQWrite =  iAWReady;
assign  AWQRead  =  tWWReq & WriteAck;

SDRAWQ WCmdBuf (
			.nRST		(ARESETB), 
			.Clk		(ACLK), 
			.WriteEn	(AWQWrite), 
			.ReadEn		(AWQRead), 
			.WrData		(AWQWrData), 
			.RdData		(AWQRdData), 
			.FullFlag	(AWQFull), 
			.EmptyFlag	(AWQEmpty)
);

// Write Control State Machine
always @(negedge ARESETB or posedge ACLK)
  	if (!ARESETB) CurStW <= W_IDLE;
  	else          CurStW <= NxtStW;

always @(tWIdle or tWWReq or WrReqEn or WriteAck) begin
  	NxtStW = W_IDLE;
  	case(1'b1)	// synopsys parallel_case
  	  	tWIdle  : 	if (WrReqEn)	NxtStW = W_WREQ;
  	  	          	else        	NxtStW = W_IDLE;
  	  	          	            
  	  	tWWReq  : 	if (WriteAck)	NxtStW = W_IDLE;
  	  	          	else        	NxtStW = W_WREQ;
  	  	                        
  	  	default :               	NxtStW = W_IDLE;
  	endcase
end

assign WrReqEn  = WLast & WValid & WReady & ~AWQEmpty;
assign WriteAck = AckQue & ~AWQEmpty;
//-------------------------------------------------------------
// Write Response Path
always @(negedge ARESETB or posedge ACLK)
  	if (!ARESETB) CurStS <= S_IDLE;
  	else          CurStS <= NxtStS;

always @(tSIdle or tSResp or RespAck or BReady) begin
  	NxtStS = S_IDLE;
  	case(1'b1)	// synopsys parallel_case
  	  	tSIdle  : 	if (RespAck)	NxtStS = S_RESP;
  	  	          	else        	NxtStS = S_IDLE;
  	  	          	            
  	  	tSResp  : 	if (BReady)		NxtStS = S_IDLE;
  	  	          	else    		NxtStS = S_RESP;

  	  	default :               	NxtStS = S_IDLE;
  	endcase
end

assign RespAck  = ~tWWReq & WLast & WValid & WReady;

reg [ID:0] LatchedBId;

assign BValid   = tSResp;
assign BResp    = tSResp ? 2'b0 : 2'b11; // No Need WId, because not support interleaved Data Write
assign BId      = tSResp ? LatchedBId : 2'b0;

always @(negedge ARESETB or posedge ACLK)
  	if 		(!ARESETB) LatchedBId <= 0;
  	else if (RespAck)  LatchedBId <= AWQRdData[AW+BL+ID+2:AW+ID+2];
//-------------------------------------------------------------
// Read Command Path
assign  ARReady  = tRIdle & ~ARQFull & ARValid & ~RQFull;

assign  ARQWrite =  ARReady;
assign  ARQRead  =  tRRReq & ReadAck;

SDRARQ RCmdBuf (
			.nRST		(ARESETB), 
			.Clk		(ACLK), 
			.WriteEn	(ARQWrite), 
			.ReadEn		(ARQRead), 
			.WrData		(ARQWrData), 
			.RdData		(ARQRdData), 
			.FullFlag	(ARQFull), 
			.EmptyFlag	(ARQEmpty)
);

// Read Control State Machine
always @(negedge ARESETB or posedge ACLK)
  	if (!ARESETB) CurStR <= R_IDLE;
  	else          CurStR <= NxtStR;

always @(tRIdle or tRRReq or RdReqEn or ReadAck) begin
  	NxtStR = R_IDLE;
  	case(1'b1)	// synopsys parallel_case
  	  	tRIdle  : 	if (RdReqEn)	NxtStR = R_RREQ;
  	  	          	else        	NxtStR = R_IDLE;
  	  	          	            
  	  	tRRReq  : 	if (ReadAck)	NxtStR = R_IDLE;
  	  	          	else        	NxtStR = R_RREQ;
  	  	                        
  	  	default :               	NxtStR = R_IDLE;
  	endcase
end

assign RdReqEn = ~ARQEmpty & ~RQFull;
assign ReadAck =  AckQue & ~ARQEmpty & ~tWWReq; // Read Mask When Write Request

// Command Mux. to Controller
assign BA_REQ = tWWReq | tRRReq;
assign BA_AA  = tWWReq ? AWQRdData[AW:0]         : ARQRdData[AW:0];
assign BA_TT  = tWWReq ? AWQRdData[AW+BL+1:AW+1] : ARQRdData[AW+BL+1:AW+1];
assign BA_RW  = tWWReq;
assign BA_ID  = tWWReq ? AWQRdData[AW+BL+ID+2:AW+ID+2] : ARQRdData[AW+BL+ID+2:AW+ID+2];
//-------------------------------------------------------------
// Write Data Path
assign  WReady  = ~WQFull & WValid & AckQue;

assign  WQWrite =  WReady;
assign  WQRead  = ~WQEmpty & DiValid;

SDRWQ WDatBuf (
			.nRST		(ARESETB), 
			.Clk		(ACLK), 
			.WriteEn	(WQWrite), 
			.ReadEn		(WQRead), 
			.WrData		(WQWrData), 
			.RdData		(WQRdData), 
			.FullFlag	(WQFull), 
			.EmptyFlag	(WQEmpty)
);

always@(negedge ARESETB or posedge ACLK) 
	if (!ARESETB) SD_DQE <= 1'b0;
	else          SD_DQE <= ~WQEmpty & DiValid;

assign SD_DQO = WQRdData[DW:0];
assign SD_DQM = WQRdData[DW+BW+1:DW+1];
//-------------------------------------------------------------
// Read Data Path
always@(negedge ARESETB or posedge ACLK) 
    if (!ARESETB) begin
        iDelayReadFlag <= 0;
        RdDataRdy      <= 0;
        iDelayReadLast <= 0;
        RdLastMem	   <= 0;
        iDelayReadId   <= 0;
        RdIdMem	   	   <= 0;
        
    end
    else begin
        iDelayReadFlag <= ReadLatchEnFd;
        RdDataRdy      <= iDelayReadFlag;
        iDelayReadLast <= RdLast;
        RdLastMem      <= iDelayReadLast;
        iDelayReadId   <= RdId;
        RdIdMem	   	   <= iDelayReadId;
    end

always @(negedge ARESETB or posedge FCLK) // Latch enable delay for READ by Feedback Clock
    if (!ARESETB) ReadLatchEnFd <= 1'b0;
    else          ReadLatchEnFd <= DoValid;

always @(negedge ARESETB or posedge FCLK)
    if      (!ARESETB)      RdDataMemFd <= 0;
    else if (ReadLatchEnFd) RdDataMemFd <= SD_DQI;

always @(negedge ARESETB or posedge ACLK)
    if (!ARESETB) RdDataMem <= 0;
    else          RdDataMem <= RdDataMemFd;

wire    iRReady = ~RQEmpty & RReady;
assign  RQWrite = ~RQFull  & RdDataRdy;
assign  RQRead  =  iRReady & RValid;

SDRRQ RDatBuf (
			.nRST		(ARESETB), 
			.Clk		(ACLK), 
			.WriteEn	(RQWrite), 
			.ReadEn		(RQRead), 
			.WrData		(RQWrData), 
			.RdData		(RQRdData), 
			.FullFlag	(RQFull), 
			.EmptyFlag	(RQEmpty)
);

assign  RValid = iRReady;
assign  RResp  = iRReady ? 2'b0 : 2'b11;

assign  RData = RQRdData;
assign  RLast = RQRdData[DW+1];
assign  RId	  = RQRdData[DW+ID+2:DW+2];

//-------------------------------------------------------------
// synopsys translate_off
// -----------------------------------------------------------------------------
// START OF PROTOCOL CHECKERS
// -----------------------------------------------------------------------------
wire WriteReq = BA_REQ & AckQue &  BA_RW;
wire ReadReq  = BA_REQ & AckQue & ~BA_RW;

// -----------------------------------------------------------------------------
// END OF PROTOCOL CHECKERS
// -----------------------------------------------------------------------------
// synopsys translate_on

endmodule