`timescale 1ns/10ps
`celldefine

module PHV018 (VPP, PAD);
inout VPP, PAD;
  tran (VPP, PAD);
endmodule

`endcelldefine
