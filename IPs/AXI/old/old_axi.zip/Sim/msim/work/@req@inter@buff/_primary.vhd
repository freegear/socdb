library verilog;
use verilog.vl_types.all;
entity ReqInterBuff is
    generic(
        MASTER_WID      : integer := 4
    );
    port(
        ACLK            : in     vl_logic;
        ARESETn         : in     vl_logic;
        AWVALID         : in     vl_logic;
        AWREADY         : in     vl_logic;
        MASTERNUM       : in     vl_logic_vector;
        BVALID          : in     vl_logic;
        BREADY          : in     vl_logic;
        CtlData         : out    vl_logic_vector;
        ReqFull         : out    vl_logic
    );
end ReqInterBuff;
