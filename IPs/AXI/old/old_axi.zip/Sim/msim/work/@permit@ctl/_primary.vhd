library verilog;
use verilog.vl_types.all;
entity PermitCtl is
    generic(
        SLAVEWID        : integer := 3;
        SLAVECNTWID     : integer := 5;
        ADDR_WID        : integer := 32
    );
    port(
        ACLK            : in     vl_logic;
        ARESETn         : in     vl_logic;
        SlaveNum        : in     vl_logic_vector;
        AREADY          : in     vl_logic;
        AVALID          : in     vl_logic;
        LAST            : in     vl_logic;
        READY           : in     vl_logic;
        RVALID          : in     vl_logic;
        CtlData2datach  : out    vl_logic_vector;
        CtlData2resch   : out    vl_logic_vector;
        CtlData2writech : out    vl_logic_vector;
        CtlData2rddatach: out    vl_logic_vector
    );
end PermitCtl;
