analyze -f verilog -lib WORK ../Rtl/NFAPBIF.v
analyze -f verilog -lib WORK ../Rtl/NFCtrl.v
analyze -f verilog -lib WORK ../Rtl/NFBoot.v  
analyze -f verilog -lib WORK ../Rtl/NFEcc.v
analyze -f verilog -lib WORK ../Rtl/NFCmdQ.v
analyze -f verilog -lib WORK ../Rtl/NFDFIFO.v
analyze -f verilog -lib WORK ../Rtl/NFEcc8.v
analyze -f verilog -lib WORK ../Rtl/NFEcc16.v
analyze -f verilog -lib WORK ../Rtl/NFRnBFilter.v
analyze -f verilog -lib WORK ../Rtl/NFTop.v

elaborate $TopDesign -lib WORK
