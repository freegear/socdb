source /tools/synopsys/fm_2004.06/admin/setup/.synopsys_fm.setup
set verification_set_undriven_signals 0

read_verilog -container r -libname WORK { /LDisk/HomeM2P0/thlee/Project/nand_syn/Rtl/NFTop.v }
read_verilog -container r -libname WORK { /LDisk/HomeM2P0/thlee/Project/nand_syn/Rtl/NFAPBIF.v }
read_verilog -container r -libname WORK { /LDisk/HomeM2P0/thlee/Project/nand_syn/Rtl/NFBoot.v }
read_verilog -container r -libname WORK { /LDisk/HomeM2P0/thlee/Project/nand_syn/Rtl/NFCmdQ.v }
read_verilog -container r -libname WORK { /LDisk/HomeM2P0/thlee/Project/nand_syn/Rtl/NFCtrl.v }
read_verilog -container r -libname WORK { /LDisk/HomeM2P0/thlee/Project/nand_syn/Rtl/NFDFIFO.v }
read_verilog -container r -libname WORK { /LDisk/HomeM2P0/thlee/Project/nand_syn/Rtl/NFEcc.v }
read_verilog -container r -libname WORK { /LDisk/HomeM2P0/thlee/Project/nand_syn/Rtl/NFEcc8.v }
read_verilog -container r -libname WORK { /LDisk/HomeM2P0/thlee/Project/nand_syn/Rtl/NFEcc16.v }
read_verilog -container r -libname WORK { /LDisk/HomeM2P0/thlee/Project/nand_syn/Rtl/NFRnBFilter.v }

read_db -container r { /LDisk/HomeM2P0/thlee/Project/nand_syn/Syn_top/SynDB/RF2SH8x32_slow_syn.db } 
read_db -container r { /LDisk/HomeM2P0/thlee/Project/nand_syn/Syn_top/SynDB/slow.db } 

set_top r:/WORK/NFTop
 
read_verilog -container i -libname WORK { /LDisk/HomeM2P0/thlee/Project/nand_syn/Syn_top/Net/NFTop.noscan.v }

read_db -container i { /LDisk/HomeM2P0/thlee/Project/nand_syn/Syn_top/SynDB/RF2SH8x32_slow_syn.db } 
read_db -container i { /LDisk/HomeM2P0/thlee/Project/nand_syn/Syn_top/SynDB/slow.db } 

set_top i:/WORK/NFTop

set_reference_design  r:/WORK/NFTop
set_implementation_design  i:/WORK/NFTop

#source cutpoint.tcl


#set_constant -type port r:/WORK/CCH_TOP/TEST_MODE 0
#set_constant -type port r:/WORK/CCH_TOP/TEST_SE 0
#set_constant -type port r:/WORK/CCH_TOP/BistMode 0
#set_constant -type port r:/WORK/CCH_TOP/ByPass 0

#set_constant -type port i:/WORK/CCH_TOP/TEST_MODE 0
#set_constant -type port i:/WORK/CCH_TOP/TEST_SE 0
#set_constant -type port i:/WORK/CCH_TOP/BistMode 0
#set_constant -type port i:/WORK/CCH_TOP/ByPass 0


match 

#set_dont_verify r:/WORK/zb_pad_top/VDD_digi_regu 
#set_dont_verify r:/WORK/zb_pad_top/DCCOUP 
#set_dont_verify r:/WORK/zb_pad_top/i_SPY05_TOP_v3/VDD1_8_D_M 
#set_dont_verify r:/WORK/zb_pad_top/i_SPY05_TOP_v3/DCCOUP 


verify 



