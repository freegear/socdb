@set HTC_ERR_FORMAT=%%f(%%l) : error %%c : %%s
@set HTC_WARN_FORMAT=%%f(%%l) : warning %%c : %%s
@del *.hex >nul
@del *.lst >nul
@del *.sym >nul
del outerror.txt
..\bin\cv8 < usb.in
@copy map v8_demo.map
@del map
@del *.sdb >nul
@del *.obj >nul
@del *.lst >nul
v8dis32 v8_demo.hex >v8_demo.lst
v8dis32 -a v8_demo.hex >v8_demo-asm.asm
