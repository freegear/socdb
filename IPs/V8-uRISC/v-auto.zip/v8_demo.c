// v8_demo.c

#include <intrpt.h>

#include "vauto.h"


//#include "host.h"
#include "usb_drv.h"

//#include "printer.h"

#include "i2c.h"	// eeprom routines

void interrupt main2(void);
void interrupt Interrupt0Stub(void);
void interrupt Interrupt1Stub(void);
void interrupt Interrupt2Stub(void);
void interrupt Interrupt3Stub(void);
void interrupt Interrupt4Stub(void);
//void interrupt Interrupt5Stub(void);
void interrupt Interrupt6Stub(void);
void interrupt Interrupt7Stub(void);

void main()
{

	asm("global _main2");
	asm("jmp _main2");
}



#pragma interrupt_level 1
void interrupt main2()
{

	CONTROL_REG = 0x00;
	asm("stp 3");	// set interrupt flag to keep interrupts from distracting us

// trap all interrupts
	Interrupt0 = (WORD)Interrupt0Stub;
	Interrupt1 = (WORD)Interrupt1Stub;
	Interrupt2 = (WORD)Interrupt2Stub;
	Interrupt3 = (WORD)Interrupt3Stub;
	Interrupt4 = (WORD)Interrupt4Stub;
//	Interrupt5 = (WORD)Interrupt5Stub;
	Interrupt6 = (WORD)Interrupt6Stub;
	Interrupt7 = (WORD)Interrupt7Stub;

	asm("clp 3");	// clear interrupt flag, we're ready to handle interrupts now

	UsbInit();
	UsbInit();
	UsbEnableReset();

	CONTROL_REG = 0xc8;
	asm("clp 3");	// clear interrupt flag

	for (;;)
		{
		}
}


#pragma interrupt_level 1
void interrupt Interrupt0Stub()	// dummy handler, calls InterruptStub and whines
{
}
#pragma interrupt_level 1
void interrupt Interrupt1Stub()	// dummy handler, calls InterruptStub and whines
{
}
#pragma interrupt_level 1
void interrupt Interrupt2Stub()	// dummy handler, calls InterruptStub and whines
{
}
#pragma interrupt_level 1
void interrupt Interrupt3Stub()	// dummy handler, calls InterruptStub and whines
{
}
#pragma interrupt_level 1
void interrupt Interrupt4Stub()	// dummy handler, calls InterruptStub and whines
{
}
//#pragma interrupt_level 1
//void interrupt Interrupt5Stub()	// dummy handler, calls InterruptStub and whines
//{
//	InterruptStub("\r\nInt5 ");
//}
#pragma interrupt_level 1
void interrupt Interrupt6Stub()	// dummy handler, calls InterruptStub and whines
{
}
#pragma interrupt_level 1
void interrupt Interrupt7Stub()	// dummy handler, calls InterruptStub and whines
{
}

