---------------------------------------------------------------------
--
-- File: BISTROM.VHD
-- Revision: $Name:  $
-- Description: Full Functional Model of a 512x8 ROM.
--      Initializes from an Intel Hex format file called bistrom.hex.
--
-- Copyright 1996 VAutomation Inc. Nashua NH. All rights reserved.
-- VAutomation Inc. 20 Trafalgar Sq. Nashua NH 03063 (603)882-2282.
-- This software is provided under license and contains proprietary
-- and confidential material which is the property of VAutomation Inc.
--
---------------------------------------------------------------------
-- This product is licensed to:
-- $name$ of $company$
-- for use at site(s):
-- $site$
---------------------------------------------------------------------
-- $Log: bistrom.vhd,v $
-- Revision 1.7  1999/08/30 14:53:42  scott
-- Fixed bug in array indexing types driving signal romout
--
-- Revision 1.6  1999/08/25 17:55:14  scott
-- Modified the code to use std_ulogic(_vector) and
-- IEEE numeric_std package
--
-- Revision 1.5  1998/04/13 15:20:28  eric
-- added the Altera architecture.
--
-- Revision 1.4  1998/01/19 18:42:19  eric
-- fixed length of filename for Unix.
--
-- Revision 1.3  1998/01/19 17:50:00  eric
-- Changed to the new ROMBLDR ROM.
--
-- Revision 1.1  1996/11/11  15:07:39  eric
-- Initial revision
--
---------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
-- synopsys translate_off
use work.v8_pkg.all;
-- synopsys translate_on


----------------- Entity declaration --------------------------------

entity bistrom is
  port(
    clk     : IN std_ulogic := '0';
    addr    : in  std_ulogic_vector(8 downto 0);  -- Address
    rom_enb : in  std_ulogic;                     -- enable the ROM
    rom_out : out std_ulogic_vector(7 downto 0)   -- Data port
    ); 
end bistrom;

-- synopsys translate_off
architecture behavioral of bistrom is   ----------- Architecture-----
  signal romout : std_ulogic_vector(7 downto 0);
  signal data   : std_ulogic_vector(7 downto 0);
begin

  init:process
    variable ram_core : byte_array( 0 to (512)-1);  -- 512 bytes
    constant infile   : string(1 to 11) := "bistrom.hex";
-- but we just couldn't seem to get that to work...
  begin
    init_ramcore(ram_core,infile,"bistrom");
    loop
      wait on addr;
      romout <= to_stdulogicvector(
        ram_core(vec2int(to_stdlogicvector(addr))));
    end loop;
  end process;

  rom_out <=  romout after 5 ns when rom_enb='1' else
              "ZZZZZZZZ" after 5 ns;
end behavioral;
-- synopsys translate_on

architecture altera of bistrom is       ------------ Architecture -----
  component lpm_rom
    generic(
      LPM_WIDTH           : positive;
      LPM_TYPE            : string := "L_ROM";
      LPM_WIDTHAD         : positive;
      LPM_NUMWORDS        : string := "UNUSED";
      LPM_FILE            : string;
      LPM_ADDRESS_CONTROL : string := "REGISTERED";
      LPM_OUTDATA         : string := "REGISTERED";
      LPM_HINT            : string := "UNUSED"
      );
    port(
      address  : in  std_ulogic_vector(LPM_WIDTHAD-1 downto 0);
      inclock  : in  std_ulogic := '1';
      outclock : in  std_ulogic := '1';
      memenab  : in  std_ulogic := '1';
      q        : out std_ulogic_vector(LPM_WIDTH-1 downto 0)
      );
  end component;
  constant LPM_WIDTH   : positive := 8;
  constant LPM_WIDTHAD : positive := 9;
begin
  bistrom_alt : lpm_rom
    generic map(
      LPM_WIDTH           => LPM_WIDTH,
      LPM_TYPE            => "L_ROM",
      LPM_WIDTHAD         => LPM_WIDTHAD,
      LPM_NUMWORDS        => "512",
      LPM_FILE            => "bistrom.hex",
      LPM_ADDRESS_CONTROL => "UNREGISTERED",
      LPM_OUTDATA         => "UNREGISTERED",
      LPM_HINT            => " ")
    port map(
      address => addr,
      q       => rom_out);
end altera;

-- synopsys translate_off
LIBRARY unisim; -- VITAL library
-- synopsys translate_on

-------------------------------------------------------------------------------
-- Virtex version of bootrom instantiated as a select RAM ramb4_s8 (512x8 RAM)
-- see Xilinx's Libraries Guide document for more information on the primitive.
--
-- Note this model _should_ work in simulation.Untested as yet. 4/14/00 3:08pm
-------------------------------------------------------------------------------
ARCHITECTURE virtex OF bistrom IS
  COMPONENT ramb4_s8
  -- synopsys translate_off
    GENERIC (
      TimingChecksOn : boolean := FALSE;
      INIT_00 : bit_vector(255 DOWNTO 0);
      INIT_01 : bit_vector(255 DOWNTO 0);
      INIT_02 : bit_vector(255 DOWNTO 0);
      INIT_03 : bit_vector(255 DOWNTO 0);
      INIT_04 : bit_vector(255 DOWNTO 0);
      INIT_05 : bit_vector(255 DOWNTO 0);
      INIT_06 : bit_vector(255 DOWNTO 0);
      INIT_07 : bit_vector(255 DOWNTO 0);
      INIT_08 : bit_vector(255 DOWNTO 0);
      INIT_09 : bit_vector(255 DOWNTO 0);
      INIT_0A : bit_vector(255 DOWNTO 0);
      INIT_0B : bit_vector(255 DOWNTO 0);
      INIT_0C : bit_vector(255 DOWNTO 0);
      INIT_0D : bit_vector(255 DOWNTO 0);
      INIT_0E : bit_vector(255 DOWNTO 0);
      INIT_0F : bit_vector(255 DOWNTO 0)
    );
    -- synopsys translate_on
    PORT (
      we, en, rst, clk : IN  std_logic;
      addr             : IN  std_logic_vector(8 DOWNTO 0);
      di               : IN  std_logic_vector(7 DOWNTO 0);
      do               : OUT std_logic_vector(7 DOWNTO 0)
    );
  END COMPONENT;
--  FOR u_bootrom : ramb4_s8 USE ENTITY unisim.ramb4_s8(ramb4_s8_v);
    
  CONSTANT BOOT_INIT_00   : bit_vector := X"bf016abf77e401e502e740e6fb91c6c4d4c0e700e62800e404e50410bc0006bc";
  CONSTANT BOOT_INIT_01   : bit_vector := X"72555453e39000ca98400053bf740053bf750053bf730053bff890793ae10069";
  CONSTANT BOOT_INIT_02   : bit_vector := X"313131316971007ebf0069bf810000bccf98520053bff69043c47252d40053bf";
  CONSTANT BOOT_INIT_03   : bit_vector := X"e181b98c8df6f1986301fe5c0075bc6c04940791c48584b98919007ebf0069bf";
  CONSTANT BOOT_INIT_04   : bit_vector := X"e500e400e300e2a0e10202c801e05c5eb989210fe1495937e10491793fe1215f";
  CONSTANT BOOT_INIT_05   : bit_vector := X"469f012fbf00e04d9f012fbf00e0549f012fbf110169bf6e0169bfe0e700e604";
  CONSTANT BOOT_INIT_06   : bit_vector := X"730b2872520109bfd40148bf329f012fbf1901e00169bf6e0165bf5c0165bf6c";
  CONSTANT BOOT_INIT_07   : bit_vector := X"0165bf5c0169bf6e0169bf6c590148bf0109bf760148bf2a9879a0e0f091c6c4";
  CONSTANT BOOT_INIT_08   : bit_vector := X"0169bf6ce0e702e6a2e10148bfb95c0169bf6e0169bf6ceb9169b90202c8285e";
  CONSTANT BOOT_INIT_09   : bit_vector := X"5c0169bf6e0199305e0169bf6c5909e18100a5bc0165bf5e0165bf5c0169bf6e";
  CONSTANT BOOT_INIT_0A   : bit_vector := X"0169bf307069029f590169bf5c0169bf5e0169bf6c08e181b989ed90410165bf";
  CONSTANT BOOT_INIT_0B   : bit_vector := X"000000003e35303530b9f491c4d60498f4fb986701feb9b90169bfb989e89041";
  CONSTANT BOOT_INIT_0C   : bit_vector := X"0000000000000000000000000000000000000000000000000000000000000000";
  CONSTANT BOOT_INIT_0D   : bit_vector := X"0000000000000000000000000000000000000000000000000000000000000000";
  CONSTANT BOOT_INIT_0E   : bit_vector := X"0000000000000000000000000000000000000000000000000000000000000000";
  CONSTANT BOOT_INIT_0F   : bit_vector := X"0000000000000000000000000000000000000000000000000000000000000000";
  CONSTANT BOOT_S_INIT_00 : string := "bf016abf77e401e502e740e6fb91c6c4d4c0e700e62800e404e50410bc0006bc";
  CONSTANT BOOT_S_INIT_01 : string := "72555453e39000ca98400053bf740053bf750053bf730053bff890793ae10069";
  CONSTANT BOOT_S_INIT_02 : string := "313131316971007ebf0069bf810000bccf98520053bff69043c47252d40053bf";
  CONSTANT BOOT_S_INIT_03 : string := "e181b98c8df6f1986301fe5c0075bc6c04940791c48584b98919007ebf0069bf";
  CONSTANT BOOT_S_INIT_04 : string := "e500e400e300e2a0e10202c801e05c5eb989210fe1495937e10491793fe1215f";
  CONSTANT BOOT_S_INIT_05 : string := "469f012fbf00e04d9f012fbf00e0549f012fbf110169bf6e0169bfe0e700e604";
  CONSTANT BOOT_S_INIT_06 : string := "730b2872520109bfd40148bf329f012fbf1901e00169bf6e0165bf5c0165bf6c";
  CONSTANT BOOT_S_INIT_07 : string := "0165bf5c0169bf6e0169bf6c590148bf0109bf760148bf2a9879a0e0f091c6c4";
  CONSTANT BOOT_S_INIT_08 : string := "0169bf6ce0e702e6a2e10148bfb95c0169bf6e0169bf6ceb9169b90202c8285e";
  CONSTANT BOOT_S_INIT_09 : string := "5c0169bf6e0199305e0169bf6c5909e18100a5bc0165bf5e0165bf5c0169bf6e";
  CONSTANT BOOT_S_INIT_0A : string := "0169bf307069029f590169bf5c0169bf5e0169bf6c08e181b989ed90410165bf";
  CONSTANT BOOT_S_INIT_0B : string := "000000003e35303530b9f491c4d60498f4fb986701feb9b90169bfb989e89041";
  CONSTANT BOOT_S_INIT_0C : string := "0000000000000000000000000000000000000000000000000000000000000000";
  CONSTANT BOOT_S_INIT_0D : string := "0000000000000000000000000000000000000000000000000000000000000000";
  CONSTANT BOOT_S_INIT_0E : string := "0000000000000000000000000000000000000000000000000000000000000000";
  CONSTANT BOOT_S_INIT_0F : string := "0000000000000000000000000000000000000000000000000000000000000000";
  ATTRIBUTE INIT_00 : string;
  ATTRIBUTE INIT_00 OF u_bootrom : LABEL IS BOOT_S_INIT_00;
  ATTRIBUTE INIT_01 : string;
  ATTRIBUTE INIT_01 OF u_bootrom : LABEL IS BOOT_S_INIT_01;
  ATTRIBUTE INIT_02 : string;
  ATTRIBUTE INIT_02 OF u_bootrom : LABEL IS BOOT_S_INIT_02;
  ATTRIBUTE INIT_03 : string;
  ATTRIBUTE INIT_03 OF u_bootrom : LABEL IS BOOT_S_INIT_03;
  ATTRIBUTE INIT_04 : string;
  ATTRIBUTE INIT_04 OF u_bootrom : LABEL IS BOOT_S_INIT_04;
  ATTRIBUTE INIT_05 : string;
  ATTRIBUTE INIT_05 OF u_bootrom : LABEL IS BOOT_S_INIT_05;
  ATTRIBUTE INIT_06 : string;
  ATTRIBUTE INIT_06 OF u_bootrom : LABEL IS BOOT_S_INIT_06;
  ATTRIBUTE INIT_07 : string;
  ATTRIBUTE INIT_07 OF u_bootrom : LABEL IS BOOT_S_INIT_07;
  ATTRIBUTE INIT_08 : string;
  ATTRIBUTE INIT_08 OF u_bootrom : LABEL IS BOOT_S_INIT_08;
  ATTRIBUTE INIT_09 : string;
  ATTRIBUTE INIT_09 OF u_bootrom : LABEL IS BOOT_S_INIT_09;
  ATTRIBUTE INIT_0A : string;
  ATTRIBUTE INIT_0A OF u_bootrom : LABEL IS BOOT_S_INIT_0A;
  ATTRIBUTE INIT_0B : string;
  ATTRIBUTE INIT_0B OF u_bootrom : LABEL IS BOOT_S_INIT_0B;
  ATTRIBUTE INIT_0C : string;
  ATTRIBUTE INIT_0C OF u_bootrom : LABEL IS BOOT_S_INIT_0C;
  ATTRIBUTE INIT_0D : string;
  ATTRIBUTE INIT_0D OF u_bootrom : LABEL IS BOOT_S_INIT_0D;
  ATTRIBUTE INIT_0E : string;
  ATTRIBUTE INIT_0E OF u_bootrom : LABEL IS BOOT_S_INIT_0E;
  ATTRIBUTE INIT_0F : string;
  ATTRIBUTE INIT_0F OF u_bootrom : LABEL IS BOOT_S_INIT_0F;

  SIGNAL boot_we_i,boot_rst_i : std_ulogic;
  SIGNAL boot_en_i,boot_clk_i : std_ulogic;  
  SIGNAL boot_di_i : std_logic_vector(7 DOWNTO 0);
  SIGNAL boot_addr_i : std_logic_vector(8 DOWNTO 0);
  SIGNAL boot_do_i : std_logic_vector(7 DOWNTO 0);
  
BEGIN
  u_bootrom: ramb4_s8
    -- synopsys translate_off
    GENERIC MAP (
        INIT_00 => BOOT_INIT_00,
        INIT_01 => BOOT_INIT_01,
        INIT_02 => BOOT_INIT_02,
        INIT_03 => BOOT_INIT_03,
        INIT_04 => BOOT_INIT_04,
        INIT_05 => BOOT_INIT_05,
        INIT_06 => BOOT_INIT_06,
        INIT_07 => BOOT_INIT_07,
        INIT_08 => BOOT_INIT_08,
        INIT_09 => BOOT_INIT_09,
        INIT_0A => BOOT_INIT_0A,
        INIT_0B => BOOT_INIT_0B,
        INIT_0C => BOOT_INIT_0C,
        INIT_0D => BOOT_INIT_0D,
        INIT_0E => BOOT_INIT_0E,
        INIT_0F => BOOT_INIT_0F
      )
    -- synopsys translate_on
    PORT MAP (
      we   => boot_we_i,
      en   => boot_en_i,
      rst  => boot_rst_i,
      clk  => boot_clk_i,
      addr => boot_addr_i,
      di   => boot_di_i,
      do   => boot_do_i
    );
  boot_en_i   <= rom_enb;
  boot_clk_i  <= NOT clk; -- invert clk since v8 needs data next cycle
  boot_addr_i <= std_logic_vector(addr(8 DOWNTO 0));
  boot_we_i   <= '0';             -- never write this RAM
  boot_di_i   <= (OTHERS => '0'); -- it's acting like a ROM
  boot_rst_i <= '0'; -- no reset, init RAM with init attributes
  rom_out <= std_ulogic_vector(boot_do_i);

END virtex;
