#!/tools/bin/perl
##!/usr/local/bin/perl
#####################################################################
## Copyright 1999 VAutomation Inc. Nashua NH USA. All rights reserved.
## This software is provided under license and contains proprietary
## and confidential material which is the property of VAutomation Inc.
## HTTP://www.vautomation.com
######################################################################
#  
# File Name: $RCSfile: hex2const.pl,v $
# Revision: $Name:  $
#
# Description:
# This script reads in an intel hex file 
# and annotates a vhdl file with the initialization
# strings for a  xilinx block select ram.  Each select
# ram is 4096 bits.
#
# Usage: hex2const.pl const_prefix in.hex template.vhd
#
# Output: out.vhd is modified with the hex file contents.
#  
#  The following constants are modified in out.vhd:
#
#    CONSTANT <const_prefix>INIT_00 : bit_vector := "XXX... XXX" -- bytes 31:0
#    CONSTANT <const_prefix>INIT_01 : bit_vector := "XXX... XXX" -- bytes 63:32
#    CONSTANT <const_prefix>INIT_02 : bit_vector := "XXX... XXX" -- bytes 95:64 
#    CONSTANT <const_prefix>INIT_03 : bit_vector := "XXX... XXX" -- bytes 127:96
#    CONSTANT <const_prefix>INIT_04 : bit_vector := "XXX... XXX" -- bytes 159:128
#    CONSTANT <const_prefix INIT_05 : bit_vector := "XXX... XXX" -- bytes 191:160
#    CONSTANT <const_prefix>INIT_06 : bit_vector := "XXX... XXX" -- bytes 223:192
#    CONSTANT <const_prefix>INIT_07 : bit_vector := "XXX... XXX" -- bytes 255:224
#    CONSTANT <const_prefix>INIT_08 : bit_vector := "XXX... XXX" -- bytes 287:256
#    CONSTANT <const_prefix>INIT_09 : bit_vector := "XXX... XXX" -- bytes 319:288
#    CONSTANT <const_prefix>INIT_0A : bit_vector := "XXX... XXX" -- bytes 351:320
#    CONSTANT <const_prefix>INIT_0B : bit_vector := "XXX... XXX" -- bytes 383:352
#    CONSTANT <const_prefix>INIT_0C : bit_vector := "XXX... XXX" -- bytes 415:384
#    CONSTANT <const_prefix>INIT_0D : bit_vector := "XXX... XXX" -- bytes 447:416
#    CONSTANT <const_prefix>INIT_0E : bit_vector := "XXX... XXX" -- bytes 479:448
#    CONSTANT <const_prefix>INIT_0F : bit_vector := "XXX... XXX" -- bytes 511:480
#    CONSTANT <const_prefix>S_INIT_00 : string := "XXX... XXX" -- bytes 31:0
#    CONSTANT <const_prefix>S_INIT_01 : string := "XXX... XXX" -- bytes 63:32
#    CONSTANT <const_prefix>S_INIT_02 : string := "XXX... XXX" -- bytes 95:64 
#    CONSTANT <const_prefix>S_INIT_03 : string := "XXX... XXX" -- bytes 127:96
#    CONSTANT <const_prefix>S_INIT_04 : string := "XXX... XXX" -- bytes 159:128
#    CONSTANT <const_prefix>S_INIT_05 : string := "XXX... XXX" -- bytes 191:160
#    CONSTANT <const_prefix>S_INIT_06 : string := "XXX... XXX" -- bytes 223:192
#    CONSTANT <const_prefix>S_INIT_07 : string := "XXX... XXX" -- bytes 255:224
#    CONSTANT <const_prefix>S_INIT_08 : string := "XXX... XXX" -- bytes 287:256
#    CONSTANT <const_prefix>S_INIT_09 : string := "XXX... XXX" -- bytes 319:288
#    CONSTANT <const_prefix>S_INIT_0A : string := "XXX... XXX" -- bytes 351:320
#    CONSTANT <const_prefix>S_INIT_0B : string := "XXX... XXX" -- bytes 383:352
#    CONSTANT <const_prefix>S_INIT_0C : string := "XXX... XXX" -- bytes 415:384
#    CONSTANT <const_prefix>S_INIT_0D : string := "XXX... XXX" -- bytes 447:416
#    CONSTANT <const_prefix>S_INIT_0E : string := "XXX... XXX" -- bytes 479:448
#    CONSTANT <const_prefix>S_INIT_0F : string := "XXX... XXX" -- bytes 511:480
#
#    Note: The original template.vhd is renamed to template.vhd_orig.
#

sub usage {
    die "$0 const_prefix in.hex out.vhd";
}

if ($#ARGV != 2) {
    &usage;
}

$prefix=$ARGV[0];
$hexfile=$ARGV[1];
$infile=$ARGV[2];
$outfile="$ARGV[2]_tmp";
$origfile="$ARGV[2]_orig";
$imagesize=512;
$linestochange=16;
$imageline=$imagesize/$linestochange;
$lincnt=$linestochange;
$lincnt_s=$linestochange;

#
# build memory image
#
$baseaddr=0;
open(HEX,$hexfile) || die "Cannot open $hexfile: $!";
for ($i=0; $i < $imagesize; $i++) {
    $memimage[$i]=1000;
}
while (<HEX>) {
    #remove leading spaces & colon
    chop;
    s/\s*:([0-9A-Fa-f]+)/\1/;
    $numbytes=hex(substr($_,0,2));
    $_=substr($_,2);
    $address=hex(substr($_,0,4));
    $_=substr($_,4);
    $type=hex(substr($_,0,2));
    $_=substr($_,2);
    if ($type == 0) {
	for ($i=0; $i < $numbytes; $i++) {
	    $addresseff=($baseaddr+$address+$i) % $imagesize;
	    if ($memimage[$addresseff]==1000) {
		$memimage[$addresseff]=hex(substr($_,0,2));
		$_=substr($_,2);
		#print $addresseff . " <= " . $memimage[$addresseff] . "\n";
	    } else {
		die "Aliasing found in memory image file at address:" . $addresseff;
	    }
	}
    } elsif ($type == 1) {
	# do nothing
    } elsif ($type == 2) {
	$baseaddr=16 * hex(substr($_,0,4));
	#print "base address found: " . $baseaddr . "\n";
    } elsif ($type == 3) {
	# do nothing
    } elsif ($type == 4) {
	$baseaddr=(2**16) * hex(substr($_,0,4));
	#print "base address found: " . $baseaddr . "\n";
    } elsif ($type == 5) {
	# do nothing
    } else {
	die "Unknown record type";
    }
}
close(HEX);
for ($i=0; $i < $imagesize; $i++) {
    if ($memimage[$i]==1000) {
	# default value is zero
	$memimage[$i]=0;	
    }
    #print $i . " -> " .  $memimage[$i] . "\n";
}

#
# open template file & manipulate constants
#
open(TMPL, $infile) || die "Cannot open $infile: $!";
open(OUT, ">" . $outfile) || die "Cannot open $outfile: $!";
$astr="\\s*[Cc][Oo][Nn][Ss][Tt][Aa][Nn][Tt]\\s+${prefix}INIT_0";
$astr_s="\\s*[Cc][Oo][Nn][Ss][Tt][Aa][Nn][Tt]\\s+${prefix}S_INIT_0";
$bstr=".";
$cstr="\\s*:\\s*[Bb][Ii][Tt]_[Vv][Ee][Cc][Tt][Oo][Rr]\\s*:=\\s*X\"";
$cstr_s="\\s*:\\s*[Ss][Tt][Rr][Ii][Nn][Gg]\\s*:=\\s*\"";
$dstr="[0-9A-Fa-f]+";
$estr="\"\\s*;";
while(<TMPL>) {
    chop;
    if (/${astr}${bstr}${cstr}${dstr}${estr}/) {
	$a=$b=$c=$d=$e=$_;
        $a=~s/(${astr})${bstr}${cstr}${dstr}${estr}/\1/;
        $b=~s/${astr}(${bstr})${cstr}${dstr}${estr}/\1/;
        $c=~s/${astr}${bstr}(${cstr})${dstr}${estr}/\1/;
        $d=~s/${astr}${bstr}${cstr}(${dstr})${estr}/\1/;
        $e=~s/${astr}${bstr}${cstr}${dstr}(${estr})/\1/;
        print OUT $a . $b . $c;
        for ($i=((hex($b)+1)*($imageline))-1; $i >= (hex($b)*$imageline); $i--) {
	    printf OUT "%2.2x", $memimage[$i];
        }
        print OUT $e . "\n";
        $lincnt--;
    } elsif (/${astr_s}${bstr}${cstr_s}${dstr}${estr}/) {
	$a=$b=$c=$d=$e=$_;
        $a=~s/(${astr_s})${bstr}${cstr_s}${dstr}${estr}/\1/;
        $b=~s/${astr_s}(${bstr})${cstr_s}${dstr}${estr}/\1/;
        $c=~s/${astr_s}${bstr}(${cstr_s})${dstr}${estr}/\1/;
        $d=~s/${astr_s}${bstr}${cstr_s}(${dstr})${estr}/\1/;
        $e=~s/${astr_s}${bstr}${cstr_s}${dstr}(${estr})/\1/;
        print OUT $a . $b . $c;
        for ($i=((hex($b)+1)*($imageline))-1; $i >= (hex($b)*$imageline); $i--) {
	    printf OUT "%2.2x", $memimage[$i];
        }
        print OUT $e . "\n";
        $lincnt_s--;
    } else {
	print OUT $_ . "\n";
    }
}

close(TMPL);
close(OUT);

if ($lincnt || $lincnt_s) {
    die "Error! $linestochange lines were not altered.";
}

#
# Rename Files
#
rename($infile, $origfile);
rename($outfile, $infile);
